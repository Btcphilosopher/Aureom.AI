# Apple TV Operating System & Media Platform - Backend Contract

Production-grade RESTful API contract for the living-room television platform. All payloads use UTF-8 JSON with ISO 8601 timestamps.

---

## 1. Authentication & Device Link
### `POST /v1/auth/device-code`
Initiates fast television activation via mobile QR code or 6-digit pin.

#### Request:
```json
{
  "device_id": "appletv_4k_gen4_a16_098234",
  "client_version": "tvOS 20.4",
  "platform": "living_room_tv"
}
```

#### Response: `200 OK`
```json
{
  "device_code": "ATV-894-321",
  "verification_url": "https://activate.apple.tv",
  "expires_in_seconds": 900,
  "interval": 5
}
```

---

## 2. Household Profiles
### `GET /v1/profiles`
Returns active household members and parental controls configuration.

#### Response: `200 OK`
```json
{
  "active_profile_id": "prof_primary",
  "profiles": [
    {
      "id": "prof_primary",
      "name": "Alex",
      "avatar_initials": "AL",
      "avatar_color": 4278822143,
      "is_kids_profile": false,
      "max_maturity": "MA",
      "preferred_language": "en-US"
    },
    {
      "id": "prof_kids",
      "name": "Kids Room",
      "avatar_initials": "KD",
      "avatar_color": 4281397592,
      "is_kids_profile": true,
      "max_maturity": "PG",
      "parental_controls": {
        "is_enabled": true,
        "max_allowed_rating": "PG",
        "pin_required": true,
        "restrict_purchases": true
      }
    }
  ]
}
```

---

## 3. Catalog & Content
### `GET /v1/content/{id}`
Returns full cinematic metadata, video/audio formats, and stream endpoints.

#### Response: `200 OK`
```json
{
  "id": "film_last_horizon",
  "title": "The Last Horizon",
  "subtitle": "A Deep Space Odyssey",
  "type": "MOVIE",
  "year": 2026,
  "duration_minutes": 148,
  "maturity_rating": "PG-13",
  "video_format": "DOLBY_VISION",
  "audio_format": "DOLBY_ATMOS",
  "rating_score": 9.6,
  "genres": ["Sci-Fi", "Drama", "Adventure"],
  "cast": ["Elena Vance", "Marcus Kane", "Dr. Sofia Lind"],
  "directors": ["K. Aris"],
  "stream": {
    "hls_manifest_url": "https://stream.apple.tv/live/horizon_master.m3u8",
    "drm_system": "FAIRPLAY_STREAMING",
    "license_server_url": "https://fps.license.apple.tv/acquire"
  }
}
```

---

## 4. Recommendations Engine
### `POST /v1/recommendations`
Context-aware recommendation scoring taking household profile, watch progress, and time of day into account.

#### Request:
```json
{
  "profile_id": "prof_primary",
  "time_of_day_hour": 20,
  "recent_content_ids": ["film_last_horizon", "series_northern_lights"],
  "limit": 10
}
```

#### Response: `200 OK`
```json
{
  "rails": [
    {
      "title": "Continue Watching",
      "items": [
        {
          "content_id": "film_last_horizon",
          "resume_position_seconds": 2520,
          "total_duration_seconds": 8880,
          "remaining_minutes": 106
        }
      ]
    },
    {
      "title": "Because You Watched The Last Horizon",
      "items": [
        { "content_id": "film_orbital", "match_score": 94.2 },
        { "content_id": "series_atlantic", "match_score": 89.0 }
      ]
    }
  ]
}
```

---

## 5. Live Television & EPG
### `GET /v1/live/guide?start_epoch=1791453600&duration_hours=4`
Returns multi-channel timetable grid for the Electronic Programme Guide.

#### Response: `200 OK`
```json
{
  "channels": [
    {
      "id": "ch_bbc_one",
      "channel_number": 101,
      "name": "BBC One HD",
      "resolution": "4K 60fps",
      "programmes": [
        {
          "id": "prog_bbc_1",
          "title": "BBC News at Ten",
          "start_time": "2026-10-08T18:00:00Z",
          "end_time": "2026-10-08T19:00:00Z",
          "is_live_now": true
        }
      ]
    }
  ]
}
```

---

## 6. Store & StoreKit 2 Purchases
### `POST /v1/store/purchase`
Executes StoreKit / TV app purchase verification.

#### Request:
```json
{
  "product_id": "sub_appletv_plus",
  "receipt_jws": "eyJhbGciOiJFUzI1NiIsIng1YyI6WyJNSUlC...[StoreKit2 JWS Token]",
  "profile_id": "prof_primary"
}
```

#### Response: `200 OK`
```json
{
  "transaction_id": "tx_tv_9823471029",
  "status": "ENTITLED",
  "active_entitlements": ["apple_tv_plus_4k"],
  "expires_date": "2026-11-08T00:00:00Z"
}
```
