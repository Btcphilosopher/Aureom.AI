package com.example.aureom.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkspaceDao {
    @Query("SELECT * FROM workspaces")
    fun getAllWorkspaces(): Flow<List<WorkspaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkspace(workspace: WorkspaceEntity)

    @Delete
    suspend fun deleteWorkspace(workspace: WorkspaceEntity)
}

@Dao
interface TabGroupDao {
    @Query("SELECT * FROM tab_groups WHERE workspaceId = :workspaceId")
    fun getGroupsForWorkspace(workspaceId: String): Flow<List<TabGroupEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGroup(group: TabGroupEntity)

    @Query("DELETE FROM tab_groups WHERE id = :id")
    suspend fun deleteGroupById(id: String)
}

@Dao
interface BrowserTabDao {
    @Query("SELECT * FROM browser_tabs WHERE workspaceId = :workspaceId ORDER BY orderIndex ASC")
    fun getTabsForWorkspace(workspaceId: String): Flow<List<BrowserTabEntity>>

    @Query("SELECT * FROM browser_tabs")
    fun getAllTabs(): Flow<List<BrowserTabEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTab(tab: BrowserTabEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTabs(tabs: List<BrowserTabEntity>)

    @Query("DELETE FROM browser_tabs WHERE id = :id")
    suspend fun deleteTabById(id: String)

    @Query("DELETE FROM browser_tabs WHERE workspaceId = :workspaceId")
    suspend fun deleteTabsForWorkspace(workspaceId: String)
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY dateAdded DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteBookmarkById(id: String)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history_entries ORDER BY visitTimestamp DESC")
    fun getAllHistory(): Flow<List<HistoryEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(entry: HistoryEntryEntity)

    @Query("DELETE FROM history_entries WHERE id = :id")
    suspend fun deleteHistoryById(id: String)

    @Query("DELETE FROM history_entries")
    suspend fun clearAllHistory()
}

@Dao
interface ReadingListDao {
    @Query("SELECT * FROM reading_list ORDER BY savedTimestamp DESC")
    fun getAllReadingItems(): Flow<List<ReadingListItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReadingItem(item: ReadingListItemEntity)

    @Query("DELETE FROM reading_list WHERE id = :id")
    suspend fun deleteReadingItemById(id: String)
}

@Dao
interface ResearchNoteDao {
    @Query("SELECT * FROM research_notes ORDER BY savedDate DESC")
    fun getAllResearchNotes(): Flow<List<ResearchNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: ResearchNoteEntity)

    @Query("DELETE FROM research_notes WHERE id = :id")
    suspend fun deleteNoteById(id: String)
}

@Dao
interface PageWatchDao {
    @Query("SELECT * FROM page_watches ORDER BY lastChecked DESC")
    fun getAllPageWatches(): Flow<List<PageWatchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPageWatch(pageWatch: PageWatchEntity)

    @Query("DELETE FROM page_watches WHERE id = :id")
    suspend fun deletePageWatchById(id: String)
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY timestamp DESC")
    fun getAllDownloads(): Flow<List<DownloadTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadTaskEntity)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteDownloadById(id: String)
}

@Dao
interface SitePermissionDao {
    @Query("SELECT * FROM site_permissions WHERE domain = :domain")
    suspend fun getPermissionForDomain(domain: String): SitePermissionEntity?

    @Query("SELECT * FROM site_permissions")
    fun getAllPermissions(): Flow<List<SitePermissionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPermission(permission: SitePermissionEntity)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM browser_settings")
    fun getAllSettings(): Flow<List<BrowserSettingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetting(setting: BrowserSettingEntity)
}
