package com.example.aureom.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevToolsSheet(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var activeTab by remember { mutableStateOf("Console") } // Console, Network, DOM, Source, Storage
    val activeViewportMode by viewModel.activeViewportMode.collectAsState()
    val currentUrl by viewModel.currentUrl.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .testTag("devtools_sheet")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Code, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("WEB INSPECTOR & DIAGNOSTICS", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Viewport Switcher
                    FilterChip(
                        selected = activeViewportMode == "Desktop",
                        onClick = { viewModel.setViewportMode("Desktop") },
                        label = { Text("Desktop") }
                    )
                    Spacer(Modifier.width(4.dp))
                    FilterChip(
                        selected = activeViewportMode == "Tablet",
                        onClick = { viewModel.setViewportMode("Tablet") },
                        label = { Text("Tablet") }
                    )
                    Spacer(Modifier.width(4.dp))
                    FilterChip(
                        selected = activeViewportMode == "Mobile",
                        onClick = { viewModel.setViewportMode("Mobile") },
                        label = { Text("Mobile") }
                    )
                    Spacer(Modifier.width(12.dp))
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close Inspector") }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Navigation Tabs
            ScrollableTabRow(selectedTabIndex = listOf("Console", "Network", "DOM", "Source", "Storage").indexOf(activeTab)) {
                listOf("Console", "Network", "DOM", "Source", "Storage").forEach { tab ->
                    Tab(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        text = { Text(tab) }
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // Tool Content
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0F1115),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(0.4f)),
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    when (activeTab) {
                        "Console" -> {
                            Text("[Aureom Inspector] Target: $currentUrl", color = Color(0xFFD4AF37), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            Text("[Log] Content security policy verified (Strict Mode).", color = Color.LightGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            Text("[Log] WebAssembly JIT engine initialized.", color = Color.LightGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            Text("[Warning] Third-party cookie blocked by Aureom Shield.", color = Color(0xFFFFB74D), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                        "Network" -> {
                            Text("GET $currentUrl (200 OK - 182 KB - 14ms)", color = Color(0xFF81C784), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            Text("GET https://aureom.net/styles.css (200 OK - 12 KB - 4ms)", color = Color(0xFF81C784), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            Text("GET https://telemetry.tracker.com/pixel.gif (BLOCKED BY SHIELD)", color = Color(0xFFE57373), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                        "DOM" -> {
                            Text("<!DOCTYPE html>\n<html>\n  <head>\n    <title>Aureom Page</title>\n  </head>\n  <body>\n    <main id=\"app\">\n      <h1>Supermodernist Web Engine</h1>\n    </main>\n  </body>\n</html>", color = Color.LightGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                        "Source" -> {
                            Text("// Aureom Page Source Stream\nfunction init() {\n    console.log('Engine active');\n}", color = Color.LightGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                        "Storage" -> {
                            Text("Local Storage: 2 keys (aureom_session_token, aureom_theme_mode)\nSession Storage: 1 key\nCookies: 4 domain isolated items", color = Color.LightGray, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
