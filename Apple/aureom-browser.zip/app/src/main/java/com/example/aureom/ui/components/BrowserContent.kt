package com.example.aureom.ui.components

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.aureom.engine.ExtensionManager
import com.example.aureom.engine.TrackerBlocker
import com.example.aureom.ui.MainViewModel
import com.example.aureom.ui.screens.*

@Composable
fun BrowserContent(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentUrl by viewModel.currentUrl.collectAsState()
    val isVerticalTabsMode by viewModel.isVerticalTabsMode.collectAsState()
    val isReaderMode by viewModel.isReaderMode.collectAsState()
    val isDevToolsOpen by viewModel.isDevToolsOpen.collectAsState()
    val isPrivacyCentreOpen by viewModel.isPrivacyCentreOpen.collectAsState()
    val isPerformanceCentreOpen by viewModel.isPerformanceCentreOpen.collectAsState()
    val isResearchWorkspaceOpen by viewModel.isResearchWorkspaceOpen.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val isCommandPaletteOpen by viewModel.isCommandPaletteOpen.collectAsState()
    val isGuidedDemoTourOpen by viewModel.isGuidedDemoTourOpen.collectAsState()
    val activeExtensionOverlay by viewModel.activeExtensionOverlay.collectAsState()
    val activeViewportMode by viewModel.activeViewportMode.collectAsState()
    val splitViewTabId by viewModel.splitViewTabId.collectAsState()

    val tabs by viewModel.tabs.collectAsState()
    val activeTabId by viewModel.activeTabId.collectAsState()

    Box(modifier = modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Vertical Tab Sidebar (when enabled)
            AnimatedVisibility(visible = isVerticalTabsMode) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .width(200.dp)
                        .fillMaxHeight()
                        .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(0.4f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "TABS & WORKSPACES",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp, fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(12.dp))
                        tabs.forEach { tab ->
                            val isActive = tab.id == activeTabId
                            Surface(
                                onClick = { viewModel.selectTab(tab.id, tab.url, tab.title) },
                                shape = RoundedCornerShape(6.dp),
                                color = if (isActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                            ) {
                                Text(
                                    tab.title,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Main Viewport Canvas (Responsive Viewport Container)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                val viewportWidthFraction = when (activeViewportMode) {
                    "Tablet" -> 0.75f
                    "Mobile" -> 0.45f
                    else -> 1.0f
                }

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(viewportWidthFraction)
                        .border(
                            if (activeViewportMode != "Desktop") 1.dp else 0.dp,
                            MaterialTheme.colorScheme.primary
                        )
                ) {
                    if (isReaderMode) {
                        ReaderModeScreen(viewModel = viewModel)
                    } else if (currentUrl.startsWith("aureom://")) {
                        StartPageScreen(viewModel = viewModel)
                    } else {
                        // Embedded Web Engine WebView
                        val context = LocalContext.current
                        AndroidView(
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.databaseEnabled = true
                                    settings.setSupportZoom(true)
                                    webViewClient = object : WebViewClient() {
                                        override fun shouldInterceptRequest(
                                            view: WebView?,
                                            request: WebResourceRequest?
                                        ): WebResourceResponse? {
                                            val reqUrl = request?.url?.toString() ?: ""
                                            if (TrackerBlocker.isTrackerUrl(reqUrl)) {
                                                // Block tracker network call
                                                return WebResourceResponse("text/plain", "UTF-8", null)
                                            }
                                            return super.shouldInterceptRequest(view, request)
                                        }

                                        override fun onPageFinished(view: WebView?, url: String?) {
                                            super.onPageFinished(view, url)
                                            // Apply extension overlays if active
                                            if (activeExtensionOverlay == "ruler") {
                                                view?.evaluateJavascript(ExtensionManager.getReadingRulerJs(), null)
                                            } else if (activeExtensionOverlay == "typography") {
                                                view?.evaluateJavascript(ExtensionManager.getTypographyControllerJs("Serif", 18), null)
                                            }
                                        }
                                    }
                                    loadUrl(currentUrl)
                                }
                            },
                            update = { webView ->
                                if (webView.url != currentUrl) {
                                    webView.loadUrl(currentUrl)
                                }
                            },
                            modifier = Modifier.fillMaxSize().testTag("aureom_webview_canvas")
                        )
                    }
                }
            }
        }

        // Overlays & Sheets
        if (isPrivacyCentreOpen) {
            PrivacyCentreSheet(viewModel = viewModel, onDismiss = { viewModel.togglePrivacyCentre() })
        }

        if (isPerformanceCentreOpen) {
            PerformanceCentreSheet(viewModel = viewModel, onDismiss = { viewModel.togglePerformanceCentre() })
        }

        if (isResearchWorkspaceOpen) {
            ResearchWorkspaceScreen(viewModel = viewModel, onDismiss = { viewModel.toggleResearchWorkspace() })
        }

        if (isDevToolsOpen) {
            DevToolsSheet(viewModel = viewModel, onDismiss = { viewModel.toggleDevTools() })
        }

        if (isSettingsOpen) {
            SettingsScreen(viewModel = viewModel, onDismiss = { viewModel.toggleSettings() })
        }

        if (isCommandPaletteOpen) {
            CommandPaletteDialog(viewModel = viewModel, onDismiss = { viewModel.toggleCommandPalette() })
        }

        if (isGuidedDemoTourOpen) {
            GuidedDemoTour(viewModel = viewModel, onDismiss = { viewModel.dismissTour() })
        }
    }
}
