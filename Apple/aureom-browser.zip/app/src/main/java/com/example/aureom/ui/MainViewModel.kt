package com.example.aureom.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.aureom.data.*
import com.example.aureom.engine.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BrowserRepository.getInstance(application)

    // Workspaces
    val workspaces: StateFlow<List<WorkspaceEntity>> = repository.workspaces
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeWorkspaceId = MutableStateFlow("personal")
    val activeWorkspaceId: StateFlow<String> = _activeWorkspaceId.asStateFlow()

    // Tabs for active workspace
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val tabs: StateFlow<List<BrowserTabEntity>> = _activeWorkspaceId
        .flatMapLatest { repository.getTabsForWorkspace(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val tabGroups: StateFlow<List<TabGroupEntity>> = _activeWorkspaceId
        .flatMapLatest { repository.getGroupsForWorkspace(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeTabId = MutableStateFlow("tab_home")
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    private val _splitViewTabId = MutableStateFlow<String?>(null)
    val splitViewTabId: StateFlow<String?> = _splitViewTabId.asStateFlow()

    // Persistent items
    val bookmarks: StateFlow<List<BookmarkEntity>> = repository.bookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<HistoryEntryEntity>> = repository.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val readingList: StateFlow<List<ReadingListItemEntity>> = repository.readingList
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val researchNotes: StateFlow<List<ResearchNoteEntity>> = repository.researchNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pageWatches: StateFlow<List<PageWatchEntity>> = repository.pageWatches
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloads: StateFlow<List<DownloadTaskEntity>> = repository.downloads
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Tab State
    private val _currentUrl = MutableStateFlow("aureom://start")
    val currentUrl: StateFlow<String> = _currentUrl.asStateFlow()

    private val _currentTitle = MutableStateFlow("Aureom Start Desk")
    val currentTitle: StateFlow<String> = _currentTitle.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _loadProgress = MutableStateFlow(100)
    val loadProgress: StateFlow<Int> = _loadProgress.asStateFlow()

    private val _pageZoom = MutableStateFlow(1.0f)
    val pageZoom: StateFlow<Float> = _pageZoom.asStateFlow()

    private val _privacyTelemetry = MutableStateFlow(TrackerBlocker.inspectUrl("aureom://start"))
    val privacyTelemetry: StateFlow<PrivacyTelemetry> = _privacyTelemetry.asStateFlow()

    // Panel states
    private val _isReaderMode = MutableStateFlow(false)
    val isReaderMode: StateFlow<Boolean> = _isReaderMode.asStateFlow()

    private val _isDevToolsOpen = MutableStateFlow(false)
    val isDevToolsOpen: StateFlow<Boolean> = _isDevToolsOpen.asStateFlow()

    private val _isPrivacyCentreOpen = MutableStateFlow(false)
    val isPrivacyCentreOpen: StateFlow<Boolean> = _isPrivacyCentreOpen.asStateFlow()

    private val _isPerformanceCentreOpen = MutableStateFlow(false)
    val isPerformanceCentreOpen: StateFlow<Boolean> = _isPerformanceCentreOpen.asStateFlow()

    private val _isResearchWorkspaceOpen = MutableStateFlow(false)
    val isResearchWorkspaceOpen: StateFlow<Boolean> = _isResearchWorkspaceOpen.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _isCommandPaletteOpen = MutableStateFlow(false)
    val isCommandPaletteOpen: StateFlow<Boolean> = _isCommandPaletteOpen.asStateFlow()

    private val _isGuidedDemoTourOpen = MutableStateFlow(false)
    val isGuidedDemoTourOpen: StateFlow<Boolean> = _isGuidedDemoTourOpen.asStateFlow()

    private val _guidedTourStep = MutableStateFlow(0)
    val guidedTourStep: StateFlow<Int> = _guidedTourStep.asStateFlow()

    private val _isVerticalTabsMode = MutableStateFlow(false)
    val isVerticalTabsMode: StateFlow<Boolean> = _isVerticalTabsMode.asStateFlow()

    private val _activeExtensionOverlay = MutableStateFlow<String?>(null)
    val activeExtensionOverlay: StateFlow<String?> = _activeExtensionOverlay.asStateFlow()

    private val _activeViewportMode = MutableStateFlow("Desktop") // Desktop, Tablet, Mobile
    val activeViewportMode: StateFlow<String> = _activeViewportMode.asStateFlow()

    // Local Intelligence Result State
    private val _intelligenceResult = MutableStateFlow<IntelligenceResult?>(null)
    val intelligenceResult: StateFlow<IntelligenceResult?> = _intelligenceResult.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedDefaultDataIfEmpty()
        }
    }

    fun selectWorkspace(workspaceId: String) {
        _activeWorkspaceId.value = workspaceId
        viewModelScope.launch {
            val workspaceTabs = repository.getTabsForWorkspace(workspaceId).first()
            if (workspaceTabs.isNotEmpty()) {
                selectTab(workspaceTabs.first().id, workspaceTabs.first().url, workspaceTabs.first().title)
            } else {
                openNewTab("aureom://start", "Aureom Start Desk")
            }
        }
    }

    fun selectTab(tabId: String, url: String, title: String) {
        _activeTabId.value = tabId
        _currentUrl.value = url
        _currentTitle.value = title
        _privacyTelemetry.value = TrackerBlocker.inspectUrl(url)
        _isReaderMode.value = false
    }

    fun openNewTab(url: String = "aureom://start", title: String = "Aureom Start Desk") {
        val newId = "tab_" + UUID.randomUUID().toString().take(8)
        val newTab = BrowserTabEntity(
            id = newId,
            title = title,
            url = url,
            workspaceId = _activeWorkspaceId.value,
            orderIndex = (tabs.value.maxOfOrNull { it.orderIndex } ?: 0) + 1
        )
        viewModelScope.launch {
            repository.insertTab(newTab)
            selectTab(newId, url, title)
        }
    }

    fun closeTab(tabId: String) {
        viewModelScope.launch {
            repository.deleteTab(tabId)
            val remaining = tabs.value.filter { it.id != tabId }
            if (remaining.isNotEmpty()) {
                val next = remaining.last()
                selectTab(next.id, next.url, next.title)
            } else {
                openNewTab("aureom://start", "Aureom Start Desk")
            }
        }
    }

    fun duplicateTab(tab: BrowserTabEntity) {
        openNewTab(tab.url, tab.title)
    }

    fun navigateToUrl(urlInput: String) {
        val formattedUrl = when {
            urlInput.startsWith("aureom://") -> urlInput
            urlInput.startsWith("http://") || urlInput.startsWith("https://") -> urlInput
            urlInput.contains(".") && !urlInput.contains(" ") -> "https://$urlInput"
            else -> "https://duckduckgo.com/?q=${android.net.Uri.encode(urlInput)}"
        }

        val domain = try {
            formattedUrl.removePrefix("https://").removePrefix("http://").removePrefix("www.").substringBefore("/")
        } catch (e: Exception) { "aureom.net" }

        val pageTitle = if (formattedUrl.startsWith("aureom://")) "Aureom Start Desk" else "Web Page - $domain"

        _currentUrl.value = formattedUrl
        _currentTitle.value = pageTitle
        _privacyTelemetry.value = TrackerBlocker.inspectUrl(formattedUrl)

        // Update active tab in DB
        val activeId = _activeTabId.value
        viewModelScope.launch {
            val existing = tabs.value.find { it.id == activeId }
            if (existing != null) {
                repository.insertTab(existing.copy(url = formattedUrl, title = pageTitle))
            }
            // Save to history
            if (!formattedUrl.startsWith("aureom://")) {
                repository.insertHistory(
                    HistoryEntryEntity(
                        id = UUID.randomUUID().toString(),
                        title = pageTitle,
                        url = formattedUrl,
                        domain = domain,
                        workspaceId = _activeWorkspaceId.value
                    )
                )
            }
        }
    }

    fun toggleBookmarkCurrentPage() {
        val url = _currentUrl.value
        val title = _currentTitle.value
        viewModelScope.launch {
            val existing = bookmarks.value.find { it.url == url }
            if (existing != null) {
                repository.deleteBookmark(existing.id)
            } else {
                repository.insertBookmark(
                    BookmarkEntity(
                        id = UUID.randomUUID().toString(),
                        title = title,
                        url = url,
                        folderName = "Favorites"
                    )
                )
            }
        }
    }

    fun addToReadingList() {
        val url = _currentUrl.value
        val title = _currentTitle.value
        viewModelScope.launch {
            repository.insertReadingItem(
                ReadingListItemEntity(
                    id = UUID.randomUUID().toString(),
                    title = title,
                    url = url,
                    domain = _privacyTelemetry.value.domain,
                    excerpt = "Saved article from $title"
                )
            )
        }
    }

    fun addResearchNote(excerpt: String, notes: String) {
        val url = _currentUrl.value
        val title = _currentTitle.value
        viewModelScope.launch {
            repository.insertResearchNote(
                ResearchNoteEntity(
                    id = UUID.randomUUID().toString(),
                    title = title,
                    url = url,
                    domain = _privacyTelemetry.value.domain,
                    excerpt = excerpt.ifBlank { "Excerpt from $title" },
                    userNotes = notes
                )
            )
        }
    }

    fun addPageWatch() {
        val url = _currentUrl.value
        val title = _currentTitle.value
        viewModelScope.launch {
            repository.insertPageWatch(
                PageWatchEntity(
                    id = UUID.randomUUID().toString(),
                    title = title,
                    url = url,
                    status = "Monitoring",
                    lastContentPreview = "Initial baseline capture recorded."
                )
            )
        }
    }

    fun createTabGroup(name: String) {
        viewModelScope.launch {
            val group = TabGroupEntity(
                id = "group_" + UUID.randomUUID().toString().take(6),
                workspaceId = _activeWorkspaceId.value,
                name = name
            )
            repository.insertTabGroup(group)
        }
    }

    fun createWorkspace(name: String) {
        viewModelScope.launch {
            val ws = WorkspaceEntity(
                id = name.lowercase().replace(" ", "_"),
                name = name,
                iconName = "folder"
            )
            repository.insertWorkspace(ws)
            selectWorkspace(ws.id)
        }
    }

    // AI Intelligence triggers
    fun summarizeCurrentPage() {
        viewModelScope.launch {
            val res = LocalIntelligenceService.summarizePage(_currentTitle.value, _currentUrl.value, _currentUrl.value)
            _intelligenceResult.value = res
        }
    }

    fun askPageQuestion(question: String) {
        viewModelScope.launch {
            val res = LocalIntelligenceService.askPageQuestion(question, _currentTitle.value, _currentUrl.value)
            _intelligenceResult.value = res
        }
    }

    fun translateCurrentPage(targetLang: String) {
        viewModelScope.launch {
            val res = LocalIntelligenceService.translatePage(targetLang, _currentTitle.value, _currentUrl.value)
            _intelligenceResult.value = res
        }
    }

    // Toggle panels
    fun toggleReaderMode() { _isReaderMode.value = !_isReaderMode.value }
    fun toggleDevTools() { _isDevToolsOpen.value = !_isDevToolsOpen.value }
    fun togglePrivacyCentre() { _isPrivacyCentreOpen.value = !_isPrivacyCentreOpen.value }
    fun togglePerformanceCentre() { _isPerformanceCentreOpen.value = !_isPerformanceCentreOpen.value }
    fun toggleResearchWorkspace() { _isResearchWorkspaceOpen.value = !_isResearchWorkspaceOpen.value }
    fun toggleSettings() { _isSettingsOpen.value = !_isSettingsOpen.value }
    fun toggleCommandPalette() { _isCommandPaletteOpen.value = !_isCommandPaletteOpen.value }
    fun toggleVerticalTabs() { _isVerticalTabsMode.value = !_isVerticalTabsMode.value }
    fun toggleSplitView(tabId: String?) {
        _splitViewTabId.value = if (_splitViewTabId.value == tabId) null else tabId
    }

    fun toggleExtensionOverlay(extId: String) {
        _activeExtensionOverlay.value = if (_activeExtensionOverlay.value == extId) null else extId
    }

    fun setViewportMode(mode: String) { _activeViewportMode.value = mode }
    fun setPageZoom(zoom: Float) { _pageZoom.value = zoom.coerceIn(0.5f, 2.0f) }

    fun startGuidedTour() {
        _guidedTourStep.value = 1
        _isGuidedDemoTourOpen.value = true
    }

    fun nextTourStep() {
        if (_guidedTourStep.value >= 17) {
            _isGuidedDemoTourOpen.value = false
            _guidedTourStep.value = 0
        } else {
            _guidedTourStep.value += 1
        }
    }

    fun dismissTour() {
        _isGuidedDemoTourOpen.value = false
        _guidedTourStep.value = 0
    }
}
