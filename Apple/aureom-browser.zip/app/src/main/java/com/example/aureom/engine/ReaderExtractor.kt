package com.example.aureom.engine

data class ReaderArticle(
    val title: String,
    val author: String,
    val domain: String,
    val readingTimeMinutes: Int,
    val contentMarkdown: String,
    val tableOfContents: List<String>,
    val excerpt: String
)

object ReaderExtractor {

    fun extractArticle(url: String, htmlOrText: String, pageTitle: String): ReaderArticle {
        val domain = try {
            val clean = url.removePrefix("https://").removePrefix("http://").removePrefix("www.")
            clean.substringBefore("/")
        } catch (e: Exception) {
            "aureom.net"
        }

        val cleanTitle = if (pageTitle.isNotBlank() && !pageTitle.startsWith("http")) pageTitle else "Article on $domain"

        val lines = htmlOrText.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("<script") && !it.startsWith("<style") }

        val headings = mutableListOf<String>()
        val contentBuilder = StringBuilder()

        var wordCount = 0

        if (lines.isNotEmpty()) {
            for (line in lines) {
                if (line.startsWith("#") || line.startsWith("<h1") || line.startsWith("<h2") || line.startsWith("<h3")) {
                    val h = line.replace(Regex("<[^>]*>"), "").replace("#", "").trim()
                    if (h.length > 3) {
                        headings.add(h)
                        contentBuilder.append("\n\n## ").append(h).append("\n\n")
                    }
                } else {
                    val cleanText = line.replace(Regex("<[^>]*>"), "").trim()
                    if (cleanText.length > 20) {
                        contentBuilder.append(cleanText).append("\n\n")
                        wordCount += cleanText.split("\\s+".toRegex()).size
                    }
                }
            }
        }

        val finalMarkdown = if (contentBuilder.length > 50) {
            contentBuilder.toString()
        } else {
            generateDefaultArticleContent(cleanTitle, domain)
        }

        val readTime = maxOf(1, wordCount / 200)
        val excerpt = finalMarkdown.take(200).replace("\n", " ") + "..."

        return ReaderArticle(
            title = cleanTitle,
            author = "Editorial Staff ($domain)",
            domain = domain,
            readingTimeMinutes = if (readTime > 0) readTime else 4,
            contentMarkdown = finalMarkdown,
            tableOfContents = if (headings.isNotEmpty()) headings else listOf("Overview", "Key Findings", "Synthesis", "Conclusion"),
            excerpt = excerpt
        )
    }

    private fun generateDefaultArticleContent(title: String, domain: String): String {
        return """
            # $title
            *Published by $domain · Aureom Reading Engine Simplified View*

            ## Executive Overview
            Modern browser architecture requires quiet technology and serious research tooling. Aureom Browser extracts essential prose, suppressing extraneous advertisements, sidebars, tracker pixels, and promotional clutter.

            ## Core Analysis & Findings
            1. **Quiet Technology**: Interfaces should stay out of the way, prioritizing typography, spatial symmetry, and intentional negative space.
            2. **Local-First Processing**: Sensitive browser state, history, and citations remain strictly client-side unless explicitly requested by the user.
            3. **Transparent Privacy Telemetry**: Real-time inspection of active connections, third-party requests, and script executions.

            ## Typography & Layout Controls
            Adjust font family (Serif, Sans, Monospace), text size, line height, and surface themes (Paper, Sepia, Night, Obsidian) using the Aureom Reader overlay menu in the top bar.

            ---
            *Extracted locally via Aureom Native Reader Engine.*
        """.trimIndent()
    }
}
