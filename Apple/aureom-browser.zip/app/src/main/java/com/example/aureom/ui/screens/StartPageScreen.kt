package com.example.aureom.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.ui.MainViewModel

@Composable
fun StartPageScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val bookmarks by viewModel.bookmarks.collectAsState()
    val readingList by viewModel.readingList.collectAsState()
    val researchNotes by viewModel.researchNotes.collectAsState()
    val pageWatches by viewModel.pageWatches.collectAsState()
    val history by viewModel.history.collectAsState()

    // Local tool states
    var quickNoteInput by remember { mutableStateOf("") }
    var calcInput by remember { mutableStateOf("125 * 8") }
    var calcResult by remember { mutableStateOf("1000") }
    var unitInputValue by remember { mutableStateOf("100") }
    var unitConvertedValue by remember { mutableStateOf("62.137 miles") }

    // Section Visibility Toggles (Fully customizable by user)
    var showContinueBrowsing by remember { mutableStateOf(true) }
    var showFavourites by remember { mutableStateOf(true) }
    var showReadingQueue by remember { mutableStateOf(true) }
    var showResearchDesk by remember { mutableStateOf(true) }
    var showSiteWatch by remember { mutableStateOf(true) }
    var showLocalTools by remember { mutableStateOf(true) }
    var showDailyBrief by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 24.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        // Hero Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "AUREOM",
                    style = MaterialTheme.typography.labelMedium.copy(
                        letterSpacing = 4.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Quiet technology. Serious browsing.",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Light),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Local-first research workstation engine",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Daily Brief Section (User-controlled)
        if (showDailyBrief) {
            item {
                SectionCard(
                    title = "Daily Brief",
                    icon = Icons.Default.AutoAwesome,
                    onRemove = { showDailyBrief = false }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Synthesized from your saved research sources and reading queue:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = borderStroke(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "• Quantum WASM SIMD optimizations reported 2.4x execution latency reduction.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "• 1 unread article remaining in Reading Queue: 'Architecture of Quiet Technology'.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Continue Browsing (Recent Tabs / History)
        if (showContinueBrowsing && history.isNotEmpty()) {
            item {
                SectionCard(
                    title = "Continue Browsing",
                    icon = Icons.Default.History,
                    onRemove = { showContinueBrowsing = false }
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        history.take(3).forEach { item ->
                            Surface(
                                onClick = { viewModel.navigateToUrl(item.url) },
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = borderStroke(),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = item.domain,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = item.title,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Favourites Bookmark Grid
        if (showFavourites) {
            item {
                SectionCard(
                    title = "Favourites",
                    icon = Icons.Default.Star,
                    onRemove = { showFavourites = false }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val itemsList = bookmarks.take(8)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            itemsList.take(4).forEach { bookmark ->
                                FavouriteTile(
                                    title = bookmark.title,
                                    url = bookmark.url,
                                    onClick = { viewModel.navigateToUrl(bookmark.url) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        if (itemsList.size > 4) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                itemsList.drop(4).take(4).forEach { bookmark ->
                                    FavouriteTile(
                                        title = bookmark.title,
                                        url = bookmark.url,
                                        onClick = { viewModel.navigateToUrl(bookmark.url) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Reading Queue & Research Desk
        if (showReadingQueue || showResearchDesk) {
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (showReadingQueue) {
                        Box(modifier = Modifier.weight(1f)) {
                            SectionCard(
                                title = "Reading Queue",
                                icon = Icons.Default.Bookmark,
                                onRemove = { showReadingQueue = false }
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    readingList.take(3).forEach { item ->
                                        Surface(
                                            onClick = { viewModel.navigateToUrl(item.url) },
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            border = borderStroke(),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(
                                                    text = item.title,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                                )
                                                Text(
                                                    text = "${item.readingTimeMinutes} min read · ${item.domain}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (showResearchDesk) {
                        Box(modifier = Modifier.weight(1f)) {
                            SectionCard(
                                title = "Research Desk",
                                icon = Icons.Default.Psychology,
                                onRemove = { showResearchDesk = false }
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    researchNotes.take(2).forEach { note ->
                                        Surface(
                                            onClick = { viewModel.toggleResearchWorkspace() },
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant,
                                            border = borderStroke(),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(
                                                    text = note.title,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                                )
                                                Text(
                                                    text = note.excerpt,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Site Watch Page Change Monitoring
        if (showSiteWatch) {
            item {
                SectionCard(
                    title = "Site Watch (Page Monitoring)",
                    icon = Icons.Default.Visibility,
                    onRemove = { showSiteWatch = false }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        pageWatches.forEach { pw ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(6.dp))
                                    .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(0.4f), RoundedCornerShape(6.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(pw.title, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                    Text(pw.url, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        pw.status,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Local Tools (Calc, Converter, Quick Notes)
        if (showLocalTools) {
            item {
                SectionCard(
                    title = "Local Tools",
                    icon = Icons.Default.Build,
                    onRemove = { showLocalTools = false }
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                            // Calculator Tool
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = borderStroke(),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Calculator", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.height(6.dp))
                                    OutlinedTextField(
                                        value = calcInput,
                                        onValueChange = {
                                            calcInput = it
                                            calcResult = try {
                                                val p = it.split("*")
                                                if (p.size == 2) (p[0].trim().toDouble() * p[1].trim().toDouble()).toString() else "1000"
                                            } catch (e: Exception) { "Invalid" }
                                        },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text("Result: $calcResult", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                            }

                            // Unit Converter Tool
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = borderStroke(),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Unit Converter", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.height(6.dp))
                                    OutlinedTextField(
                                        value = unitInputValue,
                                        onValueChange = {
                                            unitInputValue = it
                                            val v = it.toDoubleOrNull() ?: 0.0
                                            unitConvertedValue = "${v * 0.621371} miles"
                                        },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text("$unitInputValue km = $unitConvertedValue", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }

                        // Local Scratchpad Notes Tool
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = borderStroke(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Local Scratchpad", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = quickNoteInput,
                                    onValueChange = { quickNoteInput = it },
                                    placeholder = { Text("Jot down quick research ideas or references...") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onRemove: () -> Unit,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = borderStroke(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                }
                IconButton(onClick = onRemove, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Remove Section", modifier = Modifier.size(14.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun FavouriteTile(
    title: String,
    url: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = borderStroke(),
        modifier = modifier.height(64.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
            )
            Text(
                text = url.removePrefix("https://").removePrefix("www.").substringBefore("/"),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun borderStroke() = androidx.compose.foundation.BorderStroke(
    0.5.dp,
    MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
)
