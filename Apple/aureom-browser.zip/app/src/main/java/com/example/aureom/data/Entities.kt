package com.example.aureom.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workspaces")
data class WorkspaceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val iconName: String = "folder",
    val themeMode: String = "system", // light, dark, system
    val customStartPageUrl: String? = null,
    val isPrivate: Boolean = false,
    val defaultSearchEngine: String = "DuckDuckGo"
)

@Entity(tableName = "tab_groups")
data class TabGroupEntity(
    @PrimaryKey val id: String,
    val workspaceId: String,
    val name: String,
    val colorHex: String = "#D4AF37",
    val isCollapsed: Boolean = false,
    val parentGroupId: String? = null
)

@Entity(tableName = "browser_tabs")
data class BrowserTabEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val iconUrl: String? = null,
    val workspaceId: String,
    val groupId: String? = null,
    val isPinned: Boolean = false,
    val isSuspended: Boolean = false,
    val isPrivate: Boolean = false,
    val orderIndex: Int = 0,
    val createdTimestamp: Long = System.currentTimeMillis(),
    val lastAccessedTimestamp: Long = System.currentTimeMillis(),
    val previewColor: String = "#1A1D24",
    val note: String? = null,
    val customCss: String? = null
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val folderName: String = "Favorites",
    val tags: String = "",
    val dateAdded: Long = System.currentTimeMillis(),
    val iconUrl: String? = null
)

@Entity(tableName = "history_entries")
data class HistoryEntryEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val domain: String,
    val visitTimestamp: Long = System.currentTimeMillis(),
    val visitCount: Int = 1,
    val workspaceId: String = "personal",
    val excerpt: String? = null
)

@Entity(tableName = "reading_list")
data class ReadingListItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val domain: String,
    val savedTimestamp: Long = System.currentTimeMillis(),
    val readingTimeMinutes: Int = 3,
    val isRead: Boolean = false,
    val isArchived: Boolean = false,
    val contentMarkdown: String = "",
    val author: String = "Unknown",
    val excerpt: String = ""
)

@Entity(tableName = "research_notes")
data class ResearchNoteEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val domain: String,
    val author: String? = null,
    val publicationDate: String? = null,
    val savedDate: Long = System.currentTimeMillis(),
    val excerpt: String,
    val userNotes: String = "",
    val tagsJson: String = "[]",
    val sourceStatus: String = "Active"
)

@Entity(tableName = "page_watches")
data class PageWatchEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val selector: String = "body",
    val checkIntervalMinutes: Int = 60,
    val lastChecked: Long = System.currentTimeMillis(),
    val status: String = "Monitoring", // Monitoring, Changed, No change, Paused
    val lastHash: String = "",
    val lastContentPreview: String = "",
    val notificationEnabled: Boolean = true
)

@Entity(tableName = "downloads")
data class DownloadTaskEntity(
    @PrimaryKey val id: String,
    val fileName: String,
    val fileType: String,
    val fileSize: Long,
    val sourceDomain: String,
    val destinationPath: String,
    val status: String = "Completed", // Active, Paused, Completed, Failed
    val bytesDownloaded: Long = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "site_permissions")
data class SitePermissionEntity(
    @PrimaryKey val domain: String,
    val cameraAccess: String = "Ask", // Granted, Denied, Ask
    val micAccess: String = "Ask",
    val locationAccess: String = "Ask",
    val notificationsAccess: String = "Ask",
    val jsEnabled: Boolean = true,
    val trackersBlockedCount: Int = 0
)

@Entity(tableName = "browser_settings")
data class BrowserSettingEntity(
    @PrimaryKey val key: String,
    val value: String
)
