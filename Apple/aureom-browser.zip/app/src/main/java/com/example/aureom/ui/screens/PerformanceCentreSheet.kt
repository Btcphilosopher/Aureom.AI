package com.example.aureom.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerformanceCentreSheet(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var isBatterySaverEnabled by remember { mutableStateOf(false) }
    var isDataSaverEnabled by remember { mutableStateOf(false) }
    var isAutoSuspendEnabled by remember { mutableStateOf(true) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .testTag("performance_centre_sheet")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "PERFORMANCE OBSERVABILITY",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        )
                        Text(
                            text = "Real-Time Engine Telemetry",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close Performance Centre")
                }
            }

            Spacer(Modifier.height(20.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PerfMetricRow("Page Load Timing", "14 ms", isPrimary = true)
                    PerfMetricRow("DOM Content Loaded", "8 ms")
                    PerfMetricRow("First Contentful Paint", "11 ms")
                    PerfMetricRow("Resource Count", "18 requests")
                    PerfMetricRow("Transfer Size", "182 KB")
                    PerfMetricRow("Renderer Memory Estimate", "42 MB")
                    PerfMetricRow("CPU Core Allocation", "Idle (0.4%)")
                }
            }

            Spacer(Modifier.height(20.dp))

            // Resource Controls
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tab & Power Controls", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))

                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Suspend Inactive Background Tabs", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = isAutoSuspendEnabled, onCheckedChange = { isAutoSuspendEnabled = it })
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Battery-Conscious Mode", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = isBatterySaverEnabled, onCheckedChange = { isBatterySaverEnabled = it })
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Data-Saving Mode (Compress Media)", style = MaterialTheme.typography.bodySmall)
                        Switch(checked = isDataSaverEnabled, onCheckedChange = { isDataSaverEnabled = it })
                    }
                }
            }
        }
    }
}

@Composable
private fun PerfMetricRow(label: String, value: String, isPrimary: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = if (isPrimary) FontWeight.Bold else FontWeight.Normal),
            color = if (isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }
}
