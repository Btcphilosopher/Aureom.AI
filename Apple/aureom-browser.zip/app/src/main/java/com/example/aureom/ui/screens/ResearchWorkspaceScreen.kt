package com.example.aureom.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResearchWorkspaceScreen(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val researchNotes by viewModel.researchNotes.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var noteExcerptInput by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }
    var exportFormat by remember { mutableStateOf("Markdown") } // Markdown, JSON, BibTeX
    var exportedText by remember { mutableStateOf<String?>(null) }

    val filteredNotes = remember(researchNotes, searchQuery) {
        if (searchQuery.isBlank()) researchNotes
        else researchNotes.filter { it.title.contains(searchQuery, true) || it.excerpt.contains(searchQuery, true) }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .testTag("research_workspace_sheet")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "RESEARCH WORKSPACE",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        )
                        Text(
                            text = "Citation Capture & Synthesis Workstation",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close Workspace")
                }
            }

            Spacer(Modifier.height(16.dp))

            // Quick Citation Capture Card
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Capture New Citation / Note", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = noteExcerptInput,
                        onValueChange = { noteExcerptInput = it },
                        placeholder = { Text("Selected excerpt / quote...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = noteInput,
                        onValueChange = { noteInput = it },
                        placeholder = { Text("Your analytical notes / annotations...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            viewModel.addResearchNote(noteExcerptInput, noteInput)
                            noteExcerptInput = ""
                            noteInput = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Save Citation")
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Export Actions Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search citations & notes...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                Spacer(Modifier.width(12.dp))

                Button(
                    onClick = {
                        exportedText = when (exportFormat) {
                            "JSON" -> researchNotes.joinToString(",\n", "[\n", "\n]") { "  {\"title\": \"${it.title}\", \"url\": \"${it.url}\", \"excerpt\": \"${it.excerpt}\"}" }
                            "BibTeX" -> researchNotes.joinToString("\n\n") { "@article{${it.domain},\n  title={${it.title}},\n  url={${it.url}},\n  author={${it.author ?: "Staff"}}\n}" }
                            else -> researchNotes.joinToString("\n\n---\n\n") { "# ${it.title}\nURL: ${it.url}\nAuthor: ${it.author ?: "Unknown"}\nExcerpt: ${it.excerpt}\nNotes: ${it.userNotes}" }
                        }
                    }
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Export ($exportFormat)")
                }
            }

            exportedText?.let { exported ->
                Spacer(Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Exported Payload Preview", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            IconButton(onClick = { exportedText = null }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close Preview", modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(exported, style = MaterialTheme.typography.bodySmall, maxLines = 8)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Research Library List
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(filteredNotes, key = { it.id }) { note ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(note.domain, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text(note.publicationDate ?: "2026", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(note.title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "\"${note.excerpt}\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (note.userNotes.isNotBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "Note: ${note.userNotes}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
