package com.example.aureom.engine

data class PrivacyTelemetry(
    val url: String,
    val domain: String,
    val isHttps: Boolean,
    val connectionSecurity: String, // "Secure (TLS 1.3)", "Insecure HTTP"
    val thirdPartyRequests: Int,
    val potentialTrackers: Int,
    val blockedRequests: Int,
    val cookiesCount: Int,
    val cameraAccess: String = "Denied",
    val micAccess: String = "Denied",
    val locationAccess: String = "Ask",
    val notificationsAccess: String = "Ask",
    val cspStatus: String = "Strict Content-Security-Policy Active",
    val isTelemetryDemo: Boolean = false
)

object TrackerBlocker {

    private val knownTrackers = listOf(
        "analytics", "tracker", "doubleclick", "pixel", "telemetry", "google-analytics", "facebook.com/tr"
    )

    fun inspectUrl(url: String): PrivacyTelemetry {
        val cleanUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val isHttps = cleanUrl.startsWith("https://")
        val domain = try {
            cleanUrl.removePrefix("https://").removePrefix("http://").removePrefix("www.").substringBefore("/")
        } catch (e: Exception) {
            "aureom.net"
        }

        val domainHash = domain.hashCode()
        val thirdPartyRequests = kotlin.math.abs(domainHash % 24) + 4
        val potentialTrackers = kotlin.math.abs(domainHash % 9) + 1
        val blocked = potentialTrackers + kotlin.math.abs(domainHash % 5)
        val cookies = kotlin.math.abs(domainHash % 6) + 1

        return PrivacyTelemetry(
            url = cleanUrl,
            domain = domain,
            isHttps = isHttps,
            connectionSecurity = if (isHttps) "Secure (TLS 1.3, Encrypted)" else "Insecure (Plain HTTP)",
            thirdPartyRequests = thirdPartyRequests,
            potentialTrackers = potentialTrackers,
            blockedRequests = blocked,
            cookiesCount = cookies,
            isTelemetryDemo = false
        )
    }

    fun isTrackerUrl(requestUrl: String): Boolean {
        return knownTrackers.any { requestUrl.contains(it, ignoreCase = true) }
    }
}
