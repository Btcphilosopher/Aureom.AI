package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val AureomDarkColorScheme = darkColorScheme(
    primary = AureomGold,
    onPrimary = AureomObsidianBg,
    primaryContainer = AureomObsidianSurfaceVariant,
    onPrimaryContainer = AureomGoldLight,
    secondary = AureomGoldDark,
    onSecondary = AureomObsidianBg,
    background = AureomObsidianBg,
    onBackground = AureomTextPrimaryDark,
    surface = AureomObsidianSurface,
    onSurface = AureomTextPrimaryDark,
    surfaceVariant = AureomObsidianSurfaceVariant,
    onSurfaceVariant = AureomTextSecondaryDark,
    outline = AureomObsidianBorder
)

private val AureomLightColorScheme = lightColorScheme(
    primary = AureomGoldDark,
    onPrimary = AureomPorcelainBg,
    primaryContainer = AureomPorcelainSurfaceVariant,
    onPrimaryContainer = AureomObsidianBg,
    secondary = AureomGold,
    onSecondary = AureomObsidianBg,
    background = AureomPorcelainBg,
    onBackground = AureomTextPrimaryLight,
    surface = AureomPorcelainSurface,
    onSurface = AureomTextPrimaryLight,
    surfaceVariant = AureomPorcelainSurfaceVariant,
    onSurfaceVariant = AureomTextSecondaryLight,
    outline = AureomPorcelainBorder
)

@Composable
fun AureomTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AureomDarkColorScheme else AureomLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
