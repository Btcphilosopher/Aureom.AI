package com.example.aureom.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

class BrowserRepository(private val db: AureomDatabase) {

    val workspaces: Flow<List<WorkspaceEntity>> = db.workspaceDao().getAllWorkspaces()
    val bookmarks: Flow<List<BookmarkEntity>> = db.bookmarkDao().getAllBookmarks()
    val history: Flow<List<HistoryEntryEntity>> = db.historyDao().getAllHistory()
    val readingList: Flow<List<ReadingListItemEntity>> = db.readingListDao().getAllReadingItems()
    val researchNotes: Flow<List<ResearchNoteEntity>> = db.researchNoteDao().getAllResearchNotes()
    val pageWatches: Flow<List<PageWatchEntity>> = db.pageWatchDao().getAllPageWatches()
    val downloads: Flow<List<DownloadTaskEntity>> = db.downloadDao().getAllDownloads()
    val permissions: Flow<List<SitePermissionEntity>> = db.sitePermissionDao().getAllPermissions()
    val settings: Flow<List<BrowserSettingEntity>> = db.settingsDao().getAllSettings()

    fun getTabsForWorkspace(workspaceId: String): Flow<List<BrowserTabEntity>> =
        db.browserTabDao().getTabsForWorkspace(workspaceId)

    fun getGroupsForWorkspace(workspaceId: String): Flow<List<TabGroupEntity>> =
        db.tabGroupDao().getGroupsForWorkspace(workspaceId)

    suspend fun seedDefaultDataIfEmpty() {
        val existingWorkspaces = db.workspaceDao().getAllWorkspaces().first()
        if (existingWorkspaces.isEmpty()) {
            val defaultWorkspaces = listOf(
                WorkspaceEntity(id = "personal", name = "Personal", iconName = "person", themeMode = "system", defaultSearchEngine = "DuckDuckGo"),
                WorkspaceEntity(id = "research", name = "Research", iconName = "school", themeMode = "dark", defaultSearchEngine = "Kagi"),
                WorkspaceEntity(id = "development", name = "Development", iconName = "code", themeMode = "dark", defaultSearchEngine = "Google"),
                WorkspaceEntity(id = "finance", name = "Finance", iconName = "trending_up", themeMode = "light", defaultSearchEngine = "DuckDuckGo"),
                WorkspaceEntity(id = "writing", name = "Writing", iconName = "edit", themeMode = "system", defaultSearchEngine = "Ecosia"),
                WorkspaceEntity(id = "travel", name = "Travel", iconName = "flight", themeMode = "system", defaultSearchEngine = "Google"),
                WorkspaceEntity(id = "private", name = "Private", iconName = "lock", themeMode = "dark", isPrivate = true, defaultSearchEngine = "DuckDuckGo")
            )
            defaultWorkspaces.forEach { db.workspaceDao().insertWorkspace(it) }

            // Default Tab Group for Research
            val researchGroup = TabGroupEntity(id = "group_economics", workspaceId = "research", name = "Economics & Tech", colorHex = "#D4AF37")
            db.tabGroupDao().insertGroup(researchGroup)

            // Default Tabs for Personal Workspace
            val tab1 = BrowserTabEntity(
                id = "tab_home",
                title = "Aureom Start Desk",
                url = "aureom://start",
                workspaceId = "personal",
                isPinned = true,
                orderIndex = 0
            )
            val tab2 = BrowserTabEntity(
                id = "tab_wikipedia",
                title = "Quantum Computing - Wikipedia",
                url = "https://en.wikipedia.org/wiki/Quantum_computing",
                workspaceId = "personal",
                orderIndex = 1
            )
            val tab3 = BrowserTabEntity(
                id = "tab_research_doc",
                title = "ArXiv Computer Science Research",
                url = "https://arxiv.org",
                workspaceId = "research",
                groupId = "group_economics",
                orderIndex = 0
            )
            db.browserTabDao().insertTab(tab1)
            db.browserTabDao().insertTab(tab2)
            db.browserTabDao().insertTab(tab3)

            // Default Bookmarks
            listOf(
                BookmarkEntity(id = "b1", title = "Nature Science Journal", url = "https://www.nature.com", folderName = "Research"),
                BookmarkEntity(id = "b2", title = "ArXiv Repository", url = "https://arxiv.org", folderName = "Research"),
                BookmarkEntity(id = "b3", title = "DuckDuckGo Search", url = "https://duckduckgo.com", folderName = "Favorites"),
                BookmarkEntity(id = "b4", title = "GitHub Engineering", url = "https://github.com", folderName = "Dev")
            ).forEach { db.bookmarkDao().insertBookmark(it) }

            // Default Reading List
            listOf(
                ReadingListItemEntity(
                    id = "r1",
                    title = "The Architecture of Quiet Technology in the Late 2020s",
                    url = "https://aureom.net/essays/quiet-tech",
                    domain = "aureom.net",
                    readingTimeMinutes = 5,
                    excerpt = "How restrained software design and client-side processing eliminate digital friction."
                )
            ).forEach { db.readingListDao().insertReadingItem(it) }

            // Default Research Note
            listOf(
                ResearchNoteEntity(
                    id = "rn1",
                    title = "Next-Gen Web Assembly Performance Benchmarks",
                    url = "https://aureom.net/research/wasm-benchmarks",
                    domain = "aureom.net",
                    author = "Dr. H. Vance",
                    publicationDate = "2026-08-14",
                    excerpt = "WASM SIMD execution speed achieved 2.4x latency reduction over classic JS engines.",
                    userNotes = "Key reference for our upcoming browser rendering engine optimization.",
                    tagsJson = "[\"WASM\", \"Performance\", \"Browser Engines\"]"
                )
            ).forEach { db.researchNoteDao().insertNote(it) }

            // Default Page Watch
            listOf(
                PageWatchEntity(
                    id = "pw1",
                    title = "Aureom Architecture Releases",
                    url = "https://aureom.net/releases",
                    status = "Monitoring",
                    lastContentPreview = "Version 2.4.0 quiet build verified."
                )
            ).forEach { db.pageWatchDao().insertPageWatch(it) }

            // Default Downloads
            listOf(
                DownloadTaskEntity(
                    id = "dl1",
                    fileName = "Aureom_Browser_Spec_2026.pdf",
                    fileType = "application/pdf",
                    fileSize = 4280000,
                    sourceDomain = "aureom.net",
                    destinationPath = "/storage/emulated/0/Download/Aureom_Browser_Spec_2026.pdf",
                    status = "Completed",
                    bytesDownloaded = 4280000
                )
            ).forEach { db.downloadDao().insertDownload(it) }
        }
    }

    suspend fun insertTab(tab: BrowserTabEntity) = db.browserTabDao().insertTab(tab)
    suspend fun deleteTab(id: String) = db.browserTabDao().deleteTabById(id)
    suspend fun insertWorkspace(workspace: WorkspaceEntity) = db.workspaceDao().insertWorkspace(workspace)
    suspend fun insertBookmark(bookmark: BookmarkEntity) = db.bookmarkDao().insertBookmark(bookmark)
    suspend fun deleteBookmark(id: String) = db.bookmarkDao().deleteBookmarkById(id)
    suspend fun insertHistory(entry: HistoryEntryEntity) = db.historyDao().insertHistory(entry)
    suspend fun clearHistory() = db.historyDao().clearAllHistory()
    suspend fun insertReadingItem(item: ReadingListItemEntity) = db.readingListDao().insertReadingItem(item)
    suspend fun insertResearchNote(note: ResearchNoteEntity) = db.researchNoteDao().insertNote(note)
    suspend fun deleteResearchNote(id: String) = db.researchNoteDao().deleteNoteById(id)
    suspend fun insertPageWatch(pageWatch: PageWatchEntity) = db.pageWatchDao().insertPageWatch(pageWatch)
    suspend fun insertDownload(download: DownloadTaskEntity) = db.downloadDao().insertDownload(download)
    suspend fun insertTabGroup(group: TabGroupEntity) = db.tabGroupDao().insertGroup(group)

    companion object {
        @Volatile
        private var INSTANCE: BrowserRepository? = null

        fun getInstance(context: Context): BrowserRepository {
            return INSTANCE ?: synchronized(this) {
                val db = AureomDatabase.getDatabase(context)
                val repo = BrowserRepository(db)
                INSTANCE = repo
                repo
            }
        }
    }
}
