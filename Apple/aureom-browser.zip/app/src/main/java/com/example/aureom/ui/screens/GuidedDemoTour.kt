package com.example.aureom.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.aureom.ui.MainViewModel

data class TourStepInfo(
    val stepIndex: Int,
    val title: String,
    val description: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@Composable
fun GuidedDemoTour(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val step by viewModel.guidedTourStep.collectAsState()

    val steps = remember {
        listOf(
            TourStepInfo(1, "1. Quiet Technology Shell", "Supermodernist interface designed with restraint, precision typography, and zero intrusive chrome.", Icons.Default.Palette),
            TourStepInfo(2, "2. Contextual Workspaces", "Separate browsing contexts (Personal, Research, Dev, Finance, Private) with isolated tabs & settings.", Icons.Default.Folder),
            TourStepInfo(3, "3. Flexible Tab Management", "Horizontal tab strip or Vertical sidebar tabs with pinning, tab groups, and auto-suspension.", Icons.Default.ViewSidebar),
            TourStepInfo(4, "4. Command System & Omnibox", "Instant omnibox execution with commands like /calc, /convert, /reader, /privacy, /research.", Icons.Default.Terminal),
            TourStepInfo(5, "5. Real-Time Privacy Transparency", "Shield panel displaying active connection TLS 1.3 status, third-party requests, and blocked trackers.", Icons.Default.Shield),
            TourStepInfo(6, "6. Superior Start Desk", "Customizable launch desk with Daily Brief, Favourites grid, Reading Queue, and local scratchpad.", Icons.Default.Dashboard),
            TourStepInfo(7, "7. Native Article Reader Engine", "Clutter-free reading layout with typography family controls (Serif, Sans, Mono), themes, and TOC.", Icons.Default.MenuBook),
            TourStepInfo(8, "8. Research Workspace", "Dedicated workstation for capturing citations, quotes, publication dates, and analytical notes.", Icons.Default.Psychology),
            TourStepInfo(9, "9. Multi-Format Citation Export", "Export research references directly into Markdown, JSON, or academic BibTeX formats.", Icons.Default.Download),
            TourStepInfo(10, "10. Page Watch Site Monitoring", "Monitor external web pages for silent content changes and updates with automatic diff tracking.", Icons.Default.Visibility),
            TourStepInfo(11, "11. Local Desktop Tools", "Built-in offline tools including scratchpad notes, math calculator, and unit converter.", Icons.Default.Build),
            TourStepInfo(12, "12. Integrated Local Intelligence", "Gemini 3.5 Flash API or local offline engine for page summaries, Q&A, and translations.", Icons.Default.AutoAwesome),
            TourStepInfo(13, "13. Web Inspector & Dev Tools", "Full developer tools overlay featuring Console logs, Network waterfall, DOM tree, and Viewport switcher.", Icons.Default.Code),
            TourStepInfo(14, "14. Local Extension Architecture", "Working local extensions: Reading Ruler, Typography Controller, and Citation Collector.", Icons.Default.Extension),
            TourStepInfo(15, "15. Performance Observability", "Real-time telemetry measuring page load timing (ms), DOM memory allocation, and CPU load.", Icons.Default.Speed),
            TourStepInfo(16, "16. 16-Category Comprehensive Settings", "Complete browser configuration covering General, Security, Privacy, Shortcuts, and Extensions.", Icons.Default.Settings),
            TourStepInfo(17, "17. Cross-Device Configuration Export", "JSON export/import for browser state, history, bookmarks, and workspace configurations.", Icons.Default.Share)
        )
    }

    val currentStepInfo = steps.find { it.stepIndex == step } ?: steps.first()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("guided_demo_tour_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(currentStepInfo.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("GUIDED DEMO TOUR (${step}/17)", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close Tour", modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(Modifier.height(16.dp))

                Text(currentStepInfo.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(Modifier.height(8.dp))
                Text(currentStepInfo.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Skip Tour")
                    }

                    Button(
                        onClick = { viewModel.nextTourStep() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(if (step < 17) "Next Capability →" else "Finish Walkthrough ✓")
                    }
                }
            }
        }
    }
}
