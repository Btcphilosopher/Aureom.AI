package com.example.aureom.engine

data class AureomExtension(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val isEnabled: Boolean,
    val permissions: List<String>
)

object ExtensionManager {

    val defaultExtensions = mutableListOf(
        AureomExtension(
            id = "ext_reading_ruler",
            name = "Reading Ruler",
            version = "1.2.0",
            description = "Provides a high-contrast horizontal focus guideline overlay across the viewport for guided speed-reading.",
            isEnabled = true,
            permissions = listOf("activeTab", "overlay")
        ),
        AureomExtension(
            id = "ext_typography_controller",
            name = "Page Typography Controller",
            version = "2.0.1",
            description = "Overrides web page fonts, line heights, and letter-spacing to enhance legibility and accessibility.",
            isEnabled = true,
            permissions = listOf("activeTab", "customCss")
        ),
        AureomExtension(
            id = "ext_citation_collector",
            name = "Research Citation Collector",
            version = "1.5.0",
            description = "Captures metadata, URL, publication date, and selected text into your local Research Desk in one tap.",
            isEnabled = true,
            permissions = listOf("activeTab", "researchStorage")
        )
    )

    fun getReadingRulerJs(): String {
        return """
            (function() {
                var existing = document.getElementById('aureom-reading-ruler');
                if (existing) { existing.remove(); return; }
                var ruler = document.createElement('div');
                ruler.id = 'aureom-reading-ruler';
                ruler.style.position = 'fixed';
                ruler.style.top = '40%';
                ruler.style.left = '0';
                ruler.style.width = '100%';
                ruler.style.height = '32px';
                ruler.style.backgroundColor = 'rgba(212, 175, 55, 0.15)';
                ruler.style.borderTop = '1px solid #D4AF37';
                ruler.style.borderBottom = '1px solid #D4AF37';
                ruler.style.pointerEvents = 'none';
                ruler.style.zIndex = '999999';
                document.body.appendChild(ruler);
            })();
        """.trimIndent()
    }

    fun getTypographyControllerJs(fontFamily: String, fontSizePx: Int): String {
        return """
            (function() {
                var style = document.getElementById('aureom-typography-override');
                if (!style) {
                    style = document.createElement('style');
                    style.id = 'aureom-typography-override';
                    document.head.appendChild(style);
                }
                style.innerHTML = 'p, span, h1, h2, h3, li, article { font-family: "$fontFamily", sans-serif !important; font-size: ${fontSizePx}px !important; line-height: 1.6 !important; }';
            })();
        """.trimIndent()
    }

    fun getCitationCollectorJs(): String {
        return """
            (function() {
                var selection = window.getSelection() ? window.getSelection().toString() : '';
                var title = document.title || 'Untitled Page';
                var url = window.location.href;
                alert('Citation Captured!\nTitle: ' + title + '\nSelection: ' + (selection || 'Full Page'));
            })();
        """.trimIndent()
    }
}
