package com.example.aureom.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.aureom.ui.MainViewModel

data class PaletteCommand(val key: String, val title: String, val description: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val action: () -> Unit)

@Composable
fun CommandPaletteDialog(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }

    val allCommands = remember {
        listOf(
            PaletteCommand("/reader", "Toggle Reader Mode", "Open clean article reader layout", Icons.Default.MenuBook) { viewModel.toggleReaderMode(); onDismiss() },
            PaletteCommand("/privacy", "Open Privacy Centre", "View real-time connection privacy telemetry", Icons.Default.Shield) { viewModel.togglePrivacyCentre(); onDismiss() },
            PaletteCommand("/research", "Open Research Workspace", "Access research notes, citations, and export library", Icons.Default.Psychology) { viewModel.toggleResearchWorkspace(); onDismiss() },
            PaletteCommand("/inspect", "Open Web Inspector", "View DOM source, network logs, and console diagnostics", Icons.Default.Code) { viewModel.toggleDevTools(); onDismiss() },
            PaletteCommand("/settings", "Open Settings", "Configure browser options, workspaces, and extensions", Icons.Default.Settings) { viewModel.toggleSettings(); onDismiss() },
            PaletteCommand("/newtab", "Open New Tab", "Create a blank tab on Aureom Start Desk", Icons.Default.Add) { viewModel.openNewTab(); onDismiss() },
            PaletteCommand("/summarize", "Summarize Active Page", "Generate AI executive summary and key points", Icons.Default.AutoAwesome) { viewModel.summarizeCurrentPage(); onDismiss() },
            PaletteCommand("/tour", "Start Interactive Tour", "Take step-by-step feature walkthrough", Icons.Default.Help) { viewModel.startGuidedTour(); onDismiss() }
        )
    }

    val filtered = remember(query) {
        if (query.isBlank()) allCommands
        else allCommands.filter { it.key.contains(query, true) || it.title.contains(query, true) || it.description.contains(query, true) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface,
            border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.primary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("command_palette_dialog")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text("COMMAND PALETTE (Cmd+K)", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                }

                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Type a command or URL... (e.g., /reader, /privacy)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(filtered) { cmd ->
                        Surface(
                            onClick = cmd.action,
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(cmd.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(cmd.title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                    Text(cmd.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
