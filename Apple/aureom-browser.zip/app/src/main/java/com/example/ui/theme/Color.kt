package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aureom Supermodernist Quiet Luxury Palette
val AureomGold = Color(0xFFD4AF37)
val AureomGoldDark = Color(0xFFC5A059)
val AureomGoldLight = Color(0xFFE8C872)

val AureomObsidianBg = Color(0xFF0F1115)
val AureomObsidianSurface = Color(0xFF171A21)
val AureomObsidianSurfaceVariant = Color(0xFF222631)
val AureomObsidianBorder = Color(0xFF2E3442)

val AureomPorcelainBg = Color(0xFFF5F6F8)
val AureomPorcelainSurface = Color(0xFFFFFFFF)
val AureomPorcelainSurfaceVariant = Color(0xFFEAECEF)
val AureomPorcelainBorder = Color(0xFFD8DCE2)

val AureomTextPrimaryDark = Color(0xFFF1F3F5)
val AureomTextSecondaryDark = Color(0xFF9EA6B5)
val AureomTextPrimaryLight = Color(0xFF111418)
val AureomTextSecondaryLight = Color(0xFF5A6270)
