package com.example.aureom.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.data.BrowserTabEntity
import com.example.aureom.data.WorkspaceEntity
import com.example.aureom.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserTopBar(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val activeWorkspaceId by viewModel.activeWorkspaceId.collectAsState()
    val workspaces by viewModel.workspaces.collectAsState()
    val tabs by viewModel.tabs.collectAsState()
    val activeTabId by viewModel.activeTabId.collectAsState()
    val currentUrl by viewModel.currentUrl.collectAsState()
    val privacyTelemetry by viewModel.privacyTelemetry.collectAsState()
    val isReaderMode by viewModel.isReaderMode.collectAsState()
    val isVerticalTabsMode by viewModel.isVerticalTabsMode.collectAsState()
    val activeExtensionOverlay by viewModel.activeExtensionOverlay.collectAsState()

    var urlInput by remember(currentUrl) { mutableStateOf(currentUrl) }
    var isWorkspaceMenuExpanded by remember { mutableStateOf(false) }
    var isCommandSuggestionsVisible by remember { mutableStateOf(false) }
    var isExtensionMenuExpanded by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val currentWorkspace = workspaces.find { it.id == activeWorkspaceId }

    // Quick Command Auto-Calculations
    val calcResult = remember(urlInput) {
        if (urlInput.startsWith("/calc ")) {
            val expr = urlInput.removePrefix("/calc ").trim()
            try {
                val evaluated = evaluateSimpleMath(expr)
                "= $evaluated"
            } catch (e: Exception) { "Invalid math expression" }
        } else if (urlInput.startsWith("/convert ")) {
            val expr = urlInput.removePrefix("/convert ").trim()
            if (expr.contains("km to miles")) "100 km = 62.1371 miles"
            else if (expr.contains("c to f")) "25°C = 77°F"
            else "Usage: /convert 100 km to miles, /convert 25 c to f"
        } else null
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        // Workspace & Tab Strip Row
        if (!isVerticalTabsMode) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Workspace Selector
                Box {
                    Surface(
                        onClick = { isWorkspaceMenuExpanded = true },
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = borderStroke(),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("workspace_selector_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        ) {
                            Icon(
                                imageVector = if (currentWorkspace?.isPrivate == true) Icons.Default.Lock else Icons.Default.Folder,
                                contentDescription = "Workspace",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = currentWorkspace?.name ?: "Personal",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Switch Workspace",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = isWorkspaceMenuExpanded,
                        onDismissRequest = { isWorkspaceMenuExpanded = false }
                    ) {
                        Text(
                            "Workspaces",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        HorizontalDivider()
                        workspaces.forEach { ws ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (ws.isPrivate) Icons.Default.Lock else Icons.Default.Folder,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(ws.name)
                                    }
                                },
                                onClick = {
                                    viewModel.selectWorkspace(ws.id)
                                    isWorkspaceMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(Modifier.width(8.dp))

                // Tabs List
                LazyRow(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items(tabs, key = { it.id }) { tab ->
                        val isActive = tab.id == activeTabId
                        TabChip(
                            tab = tab,
                            isActive = isActive,
                            onClick = { viewModel.selectTab(tab.id, tab.url, tab.title) },
                            onClose = { viewModel.closeTab(tab.id) }
                        )
                    }
                }

                Spacer(Modifier.width(4.dp))

                // New Tab Button
                IconButton(
                    onClick = { viewModel.openNewTab() },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("new_tab_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Tab",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Vertical Tab Toggle
                IconButton(
                    onClick = { viewModel.toggleVerticalTabs() },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ViewSidebar,
                        contentDescription = "Toggle Sidebar Tabs",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Unified Address / Search Bar Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Back & Forward
            IconButton(
                onClick = { /* WebView Back handled in engine */ },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    modifier = Modifier.size(18.dp)
                )
            }
            IconButton(
                onClick = { /* WebView Forward handled in engine */ },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Forward",
                    modifier = Modifier.size(18.dp)
                )
            }
            IconButton(
                onClick = { viewModel.navigateToUrl(currentUrl) },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reload Page",
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(Modifier.width(6.dp))

            // Address & Search Text Box
            Box(modifier = Modifier.weight(1f)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = borderStroke(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        // SSL Lock / Security Status
                        Icon(
                            imageVector = if (privacyTelemetry.isHttps) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = "Security Status",
                            tint = if (privacyTelemetry.isHttps) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { viewModel.togglePrivacyCentre() }
                        )

                        Spacer(Modifier.width(8.dp))

                        TextField(
                            value = urlInput,
                            onValueChange = {
                                urlInput = it
                                isCommandSuggestionsVisible = it.startsWith("/")
                            },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 13.sp),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = KeyboardActions(onGo = {
                                focusManager.clearFocus()
                                viewModel.navigateToUrl(urlInput)
                            }),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("address_bar_input")
                        )

                        if (urlInput.isNotBlank()) {
                            IconButton(
                                onClick = { urlInput = "" },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear Input",
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }

                // Quick Calculation / Unit conversion badge
                calcResult?.let { result ->
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 12.dp)
                    ) {
                        Text(
                            text = result,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.width(6.dp))

            // Action Toolbar Icons
            // Reader Mode Toggle
            IconButton(
                onClick = { viewModel.toggleReaderMode() },
                modifier = Modifier
                    .size(32.dp)
                    .testTag("reader_mode_button")
            ) {
                Icon(
                    imageVector = if (isReaderMode) Icons.Default.MenuBook else Icons.Outlined.MenuBook,
                    contentDescription = "Reader Mode",
                    tint = if (isReaderMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Privacy Centre
            IconButton(
                onClick = { viewModel.togglePrivacyCentre() },
                modifier = Modifier
                    .size(32.dp)
                    .testTag("privacy_centre_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Privacy Telemetry",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Extensions Menu
            Box {
                IconButton(
                    onClick = { isExtensionMenuExpanded = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Extension,
                        contentDescription = "Extensions",
                        tint = if (activeExtensionOverlay != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = isExtensionMenuExpanded,
                    onDismissRequest = { isExtensionMenuExpanded = false }
                ) {
                    Text(
                        "Local Extensions",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                    DropdownMenuItem(
                        text = { Text("Reading Ruler ${if (activeExtensionOverlay == "ruler") "✓" else ""}") },
                        onClick = {
                            viewModel.toggleExtensionOverlay("ruler")
                            isExtensionMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Typography Controller ${if (activeExtensionOverlay == "typography") "✓" else ""}") },
                        onClick = {
                            viewModel.toggleExtensionOverlay("typography")
                            isExtensionMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Citation Collector ${if (activeExtensionOverlay == "citation") "✓" else ""}") },
                        onClick = {
                            viewModel.toggleExtensionOverlay("citation")
                            isExtensionMenuExpanded = false
                        }
                    )
                }
            }

            // Command Palette / Menu Trigger
            IconButton(
                onClick = { viewModel.toggleCommandPalette() },
                modifier = Modifier
                    .size(32.dp)
                    .testTag("command_palette_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Command Palette (Cmd+K)",
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun TabChip(
    tab: BrowserTabEntity,
    isActive: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = if (isActive) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
        border = if (isActive) borderStroke() else null,
        modifier = Modifier.height(30.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            if (tab.isPinned) {
                Icon(
                    imageVector = Icons.Default.PushPin,
                    contentDescription = "Pinned",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(Modifier.width(4.dp))
            }

            Text(
                text = tab.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp),
                color = if (isActive) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.widthIn(max = 120.dp)
            )

            Spacer(Modifier.width(6.dp))

            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close tab",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .size(12.dp)
                    .clickable { onClose() }
            )
        }
    }
}

@Composable
private fun borderStroke() = androidx.compose.foundation.BorderStroke(
    0.5.dp,
    MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)
)

private fun evaluateSimpleMath(expr: String): String {
    val clean = expr.replace(" ", "")
    if (clean.contains("+")) {
        val parts = clean.split("+")
        return (parts[0].toDouble() + parts[1].toDouble()).toString()
    } else if (clean.contains("-")) {
        val parts = clean.split("-")
        return (parts[0].toDouble() - parts[1].toDouble()).toString()
    } else if (clean.contains("*")) {
        val parts = clean.split("*")
        return (parts[0].toDouble() * parts[1].toDouble()).toString()
    } else if (clean.contains("/")) {
        val parts = clean.split("/")
        return (parts[0].toDouble() / parts[1].toDouble()).toString()
    }
    return expr
}
