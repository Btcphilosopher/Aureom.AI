package com.example.aureom.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.engine.ReaderArticle
import com.example.aureom.engine.ReaderExtractor
import com.example.aureom.ui.MainViewModel

@Composable
fun ReaderModeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val currentUrl by viewModel.currentUrl.collectAsState()
    val currentTitle by viewModel.currentTitle.collectAsState()

    val article = remember(currentUrl, currentTitle) {
        ReaderExtractor.extractArticle(currentUrl, "", currentTitle)
    }

    // Typography & Theme Controls
    var fontSizeSp by remember { mutableStateOf(16) }
    var fontFamilyChoice by remember { mutableStateOf("Serif") } // Serif, Sans, Mono
    var activeTheme by remember { mutableStateOf("Paper") } // Paper, Sepia, Night, Charcoal
    var isTocVisible by remember { mutableStateOf(true) }
    var isSideBySideView by remember { mutableStateOf(false) }

    val themeBg = when (activeTheme) {
        "Sepia" -> Color(0xFFFBF0D9)
        "Night" -> Color(0xFF111418)
        "Charcoal" -> Color(0xFF1C2026)
        else -> Color(0xFFFAFBFD) // Paper
    }

    val themeFg = when (activeTheme) {
        "Sepia" -> Color(0xFF433225)
        "Night" -> Color(0xFFECEFF4)
        "Charcoal" -> Color(0xFFE5E9F0)
        else -> Color(0xFF1A1D24) // Paper
    }

    val fontFamily = when (fontFamilyChoice) {
        "Serif" -> FontFamily.Serif
        "Mono" -> FontFamily.Monospace
        else -> FontFamily.SansSerif
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(themeBg)
            .testTag("reader_mode_view")
    ) {
        // Reader Toolbar
        Surface(
            color = themeBg,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Font Controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { fontSizeSp = (fontSizeSp - 1).coerceAtLeast(12) }) {
                        Text("A-", color = themeFg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Text("${fontSizeSp}sp", color = themeFg, style = MaterialTheme.typography.labelSmall)
                    IconButton(onClick = { fontSizeSp = (fontSizeSp + 1).coerceAtMost(28) }) {
                        Text("A+", color = themeFg, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    Spacer(Modifier.width(8.dp))

                    // Font Family Selector
                    FilterChip(
                        selected = fontFamilyChoice == "Serif",
                        onClick = { fontFamilyChoice = "Serif" },
                        label = { Text("Serif") }
                    )
                    Spacer(Modifier.width(4.dp))
                    FilterChip(
                        selected = fontFamilyChoice == "Sans",
                        onClick = { fontFamilyChoice = "Sans" },
                        label = { Text("Sans") }
                    )
                    Spacer(Modifier.width(4.dp))
                    FilterChip(
                        selected = fontFamilyChoice == "Mono",
                        onClick = { fontFamilyChoice = "Mono" },
                        label = { Text("Mono") }
                    )
                }

                // Theme Controls & Actions
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Theme Choice
                    IconButton(onClick = {
                        activeTheme = when (activeTheme) {
                            "Paper" -> "Sepia"
                            "Sepia" -> "Night"
                            "Night" -> "Charcoal"
                            else -> "Paper"
                        }
                    }) {
                        Icon(Icons.Default.Palette, contentDescription = "Change Reader Theme", tint = themeFg)
                    }

                    IconButton(onClick = { isTocVisible = !isTocVisible }) {
                        Icon(Icons.Default.List, contentDescription = "Toggle TOC", tint = themeFg)
                    }

                    IconButton(onClick = { isSideBySideView = !isSideBySideView }) {
                        Icon(Icons.Default.VerticalSplit, contentDescription = "Side-by-side view", tint = themeFg)
                    }

                    IconButton(onClick = { viewModel.addToReadingList() }) {
                        Icon(Icons.Default.BookmarkBorder, contentDescription = "Save to Reading List", tint = themeFg)
                    }

                    IconButton(onClick = { viewModel.toggleReaderMode() }) {
                        Icon(Icons.Default.Close, contentDescription = "Exit Reader View", tint = themeFg)
                    }
                }
            }
        }

        // Article Content
        Row(modifier = Modifier.fillMaxSize()) {
            // TOC Sidebar
            AnimatedVisibility(visible = isTocVisible) {
                Surface(
                    color = themeBg,
                    modifier = Modifier
                        .width(220.dp)
                        .fillMaxHeight()
                        .border(0.5.dp, themeFg.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "CONTENTS",
                            style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 2.sp, fontWeight = FontWeight.Bold),
                            color = themeFg.copy(alpha = 0.6f)
                        )
                        Spacer(Modifier.height(12.dp))
                        article.tableOfContents.forEach { section ->
                            Text(
                                text = "• $section",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = fontFamily),
                                color = themeFg,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Article Reader Canvas
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(horizontal = 32.dp, vertical = 24.dp)
            ) {
                item {
                    Text(
                        text = article.title,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = fontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = (fontSizeSp + 10).sp
                        ),
                        color = themeFg
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "${article.author} · ${article.readingTimeMinutes} min read",
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = fontFamily),
                        color = themeFg.copy(alpha = 0.7f)
                    )
                    Spacer(Modifier.height(24.dp))
                    HorizontalDivider(color = themeFg.copy(alpha = 0.2f))
                    Spacer(Modifier.height(24.dp))
                }

                item {
                    Text(
                        text = article.contentMarkdown,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontFamily = fontFamily,
                            fontSize = fontSizeSp.sp,
                            lineHeight = (fontSizeSp * 1.6).sp
                        ),
                        color = themeFg
                    )
                }
            }
        }
    }
}
