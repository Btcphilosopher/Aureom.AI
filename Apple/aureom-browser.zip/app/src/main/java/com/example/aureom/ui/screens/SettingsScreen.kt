package com.example.aureom.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.aureom.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var activeCategory by remember { mutableStateOf("General") }

    val categories = listOf(
        "General", "Appearance", "Tabs", "Workspaces", "Search",
        "Privacy", "Security", "Permissions", "Downloads", "Reading",
        "Accessibility", "Performance", "Extensions", "Shortcuts", "Data", "About"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .testTag("settings_screen")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text("AUREOM BROWSER SETTINGS", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close Settings") }
            }

            Spacer(Modifier.height(12.dp))

            // Categories Selector Bar
            ScrollableTabRow(selectedTabIndex = categories.indexOf(activeCategory)) {
                categories.forEach { cat ->
                    Tab(
                        selected = activeCategory == cat,
                        onClick = { activeCategory = cat },
                        text = { Text(cat, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Settings Panels
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    when (activeCategory) {
                        "General" -> SettingsCard("General Preferences") {
                            Text("Default Search Engine: DuckDuckGo", style = MaterialTheme.typography.bodyMedium)
                            Text("Start Page Layout: Custom Start Desk", style = MaterialTheme.typography.bodyMedium)
                            Text("Language: English (US)", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Appearance" -> SettingsCard("Appearance & Quiet Design") {
                            Text("Theme Mode: Dark Titanium (Supermodernist)", style = MaterialTheme.typography.bodyMedium)
                            Text("Accent Color: Aureom Gold (#D4AF37)", style = MaterialTheme.typography.bodyMedium)
                            Text("UI Layout Density: Compact Desktop", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Tabs" -> SettingsCard("Tab Management & Workspaces") {
                            Text("Default Tab View: Horizontal Strip / Vertical Sidebar", style = MaterialTheme.typography.bodyMedium)
                            Text("Tab Suspension: Auto-suspend after 30 minutes idle", style = MaterialTheme.typography.bodyMedium)
                            Text("Duplicate Tab Warning: Enabled", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Workspaces" -> SettingsCard("Workspace Customization") {
                            Text("Personal Workspace (Default)", style = MaterialTheme.typography.bodyMedium)
                            Text("Research Workspace (Dark Mode, Kagi Search)", style = MaterialTheme.typography.bodyMedium)
                            Text("Private Workspace (Encrypted local vault)", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Search" -> SettingsCard("Search & Omnibox Settings") {
                            Text("Omnibox Autocomplete: Enabled", style = MaterialTheme.typography.bodyMedium)
                            Text("Local Calculations (/calc): Active", style = MaterialTheme.typography.bodyMedium)
                            Text("Unit Conversion (/convert): Active", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Privacy" -> SettingsCard("Privacy Transparency & Telemetry") {
                            Text("Third-Party Tracker Blocking: Strict Mode (Active)", style = MaterialTheme.typography.bodyMedium)
                            Text("Fingerprinting Shield: Active", style = MaterialTheme.typography.bodyMedium)
                            Text("External Network Transmission: Zero (100% Client-Side)", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Security" -> SettingsCard("Security & Certificates") {
                            Text("HTTPS Upgrade Engine: Active", style = MaterialTheme.typography.bodyMedium)
                            Text("Strict Content-Security-Policy Enforcement: Active", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Permissions" -> SettingsCard("Site Permissions Defaults") {
                            Text("Camera: Ask before access", style = MaterialTheme.typography.bodyMedium)
                            Text("Microphone: Ask before access", style = MaterialTheme.typography.bodyMedium)
                            Text("Location: Ask before access", style = MaterialTheme.typography.bodyMedium)
                            Text("Notifications: Ask before access", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Downloads" -> SettingsCard("Downloads Manager") {
                            Text("Download Location: /storage/emulated/0/Download/", style = MaterialTheme.typography.bodyMedium)
                            Text("Download Confirmation: Always ask", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Reading" -> SettingsCard("Reader Engine Preferences") {
                            Text("Default Font Family: Serif", style = MaterialTheme.typography.bodyMedium)
                            Text("Default Font Size: 16sp", style = MaterialTheme.typography.bodyMedium)
                            Text("Default Surface Theme: Paper", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Accessibility" -> SettingsCard("Accessibility & Legibility") {
                            Text("Minimum Font Size: 12sp", style = MaterialTheme.typography.bodyMedium)
                            Text("High Contrast Guide (Reading Ruler): Available", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Performance" -> SettingsCard("Performance & Power Observability") {
                            Text("Page Load Metrics Telemetry: Enabled", style = MaterialTheme.typography.bodyMedium)
                            Text("Memory Limit Per Tab: 512 MB", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Extensions" -> SettingsCard("Local Extension Architecture") {
                            Text("1. Reading Ruler (Active)", style = MaterialTheme.typography.bodyMedium)
                            Text("2. Page Typography Controller (Active)", style = MaterialTheme.typography.bodyMedium)
                            Text("3. Research Citation Collector (Active)", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Shortcuts" -> SettingsCard("Keyboard & Command Shortcuts") {
                            Text("Cmd/Ctrl + K: Command Palette", style = MaterialTheme.typography.bodyMedium)
                            Text("Cmd/Ctrl + T: New Tab", style = MaterialTheme.typography.bodyMedium)
                            Text("Cmd/Ctrl + W: Close Active Tab", style = MaterialTheme.typography.bodyMedium)
                            Text("Cmd/Ctrl + Shift + R: Toggle Reader Mode", style = MaterialTheme.typography.bodyMedium)
                        }
                        "Data" -> SettingsCard("Local Data Management & Portability") {
                            Text("Export Browser Configuration (JSON): Available", style = MaterialTheme.typography.bodyMedium)
                            Text("Import Browser Configuration (JSON): Available", style = MaterialTheme.typography.bodyMedium)
                            Text("Clear All Local Data & History: Available", style = MaterialTheme.typography.bodyMedium)
                        }
                        "About" -> SettingsCard("About Aureom Browser & System Statement") {
                            Text("AUREOM BROWSER v2.4.0 (2026 Build)", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Engine Architecture: Android System WebView Wrapper with Aureom Native Compose Shell & Room Database Persistence.\n\n" +
                                "System Statement & Environment Transparency:\n" +
                                "Aureom Browser operates as an independent, privacy-first desktop-class browser shell built in Kotlin and Jetpack Compose. Web rendering is powered by the host WebView engine, supplemented with Aureom client-side tracker blocking, reader extraction, research desk, and local intelligence engines.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary))
            Spacer(Modifier.height(4.dp))
            content()
        }
    }
}
