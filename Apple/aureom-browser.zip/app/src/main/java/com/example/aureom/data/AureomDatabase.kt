package com.example.aureom.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        WorkspaceEntity::class,
        TabGroupEntity::class,
        BrowserTabEntity::class,
        BookmarkEntity::class,
        HistoryEntryEntity::class,
        ReadingListItemEntity::class,
        ResearchNoteEntity::class,
        PageWatchEntity::class,
        DownloadTaskEntity::class,
        SitePermissionEntity::class,
        BrowserSettingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AureomDatabase : RoomDatabase() {
    abstract fun workspaceDao(): WorkspaceDao
    abstract fun tabGroupDao(): TabGroupDao
    abstract fun browserTabDao(): BrowserTabDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun historyDao(): HistoryDao
    abstract fun readingListDao(): ReadingListDao
    abstract fun researchNoteDao(): ResearchNoteDao
    abstract fun pageWatchDao(): PageWatchDao
    abstract fun downloadDao(): DownloadDao
    abstract fun sitePermissionDao(): SitePermissionDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AureomDatabase? = null

        fun getDatabase(context: Context): AureomDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AureomDatabase::class.java,
                    "aureom_browser_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
