#' ArmTarget: Target Object Model for HARD ARM
#'
#' @description
#' Represents an acquired system object (File, Directory, Dataset, Text, Log, Process, Job, Command Output).
#' The robotic arm strictly requires a valid ArmTarget before initiating operations.
#'
#' @export
ArmTarget <- R6::R6Class(
  "ArmTarget",
  public = list(
    target_id = NULL,
    path = NULL,
    type = NULL, # FILE, DIRECTORY, DATASET, TEXT, LOG, PROCESS, JOB, COMMAND_OUTPUT
    size = 0,
    lines = 0,
    permissions = NULL,
    hash = NULL,
    mime_type = NULL,
    metadata = list(),
    status = "ACQUIRED",
    snapshot = NULL,
    acquired_at = NULL,
    
    initialize = function(path, type = "UNKNOWN", metadata = list()) {
      self$target_id <- paste0("TGT-", format(Sys.time(), "%Y%m%d%H%M%S-"), sample(1000:9999, 1))
      self$path <- path
      self$type <- type
      self$metadata <- metadata
      self$acquired_at <- Sys.time()
      self$status <- "ACQUIRED"
    },
    
    update_hash = function(computed_hash) {
      self$hash <- computed_hash
    },
    
    set_snapshot = function(snapshot_obj) {
      self$snapshot <- snapshot_obj
    },
    
    summary = function() {
      list(
        target_id = self$target_id,
        path = self$path,
        type = self$type,
        size_bytes = self$size,
        size_human = self$format_size(self$size),
        lines = self$lines,
        hash = self$hash,
        status = self$status,
        acquired_at = as.character(self$acquired_at)
      )
    },
    
    format_size = function(bytes) {
      if (is.null(bytes) || bytes == 0) return("0 B")
      units <- c("B", "KB", "MB", "GB", "TB")
      i <- floor(log(bytes, 1024))
      i <- min(i, length(units) - 1)
      sprintf("%.2f %s", bytes / (1024^i), units[i + 1])
    }
  )
)

#' CommandTarget: Explicit Command Output Target
#' @export
CommandTarget <- R6::R6Class(
  "CommandTarget",
  inherit = ArmTarget,
  public = list(
    command = NULL,
    args = character(),
    exit_code = 0,
    stdout = character(),
    stderr = character(),
    duration_sec = 0,
    
    initialize = function(command, args = character(), stdout = "", stderr = "", exit_code = 0, duration_sec = 0) {
      super$initialize(path = sprintf("cmd://%s", command), type = "COMMAND_OUTPUT")
      self$command <- command
      self$args <- args
      self$stdout <- stdout
      self$stderr <- stderr
      self$exit_code <- exit_code
      self$duration_sec <- duration_sec
      self$size <- nchar(paste(stdout, collapse = "\n"))
      self$lines <- length(stdout)
      self$hash <- digest::digest(stdout, algo = "sha256")
    }
  )
)
