#' VerificationEngine: Cryptographic and Structural Validation Engine
#'
#' @description
#' Verifies every robotic operation. Never reports success merely because an operation did not throw.
#'
#' @export
VerificationEngine <- R6::R6Class(
  "VerificationEngine",
  public = list(
    
    verify_file_move = function(source, destination, expected_size = NULL, expected_hash = NULL) {
      if (!file.exists(destination)) {
        stop(sprintf("Verification Failed: Destination '%s' does not exist.", destination))
      }
      
      info <- file.info(destination)
      if (!is.null(expected_size) && expected_size > 0 && info$size != expected_size) {
        stop(sprintf("Verification Failed: Size mismatch on '%s'. Expected %d bytes, found %d bytes.",
                     destination, expected_size, info$size))
      }
      
      if (!is.null(expected_hash) && nchar(expected_hash) > 0) {
        dest_hash <- digest::digest(destination, algo = "sha256", file = TRUE)
        if (dest_hash != expected_hash) {
          stop(sprintf("Verification Failed: SHA256 mismatch! Expected '%s', computed '%s'.",
                       expected_hash, dest_hash))
        }
      }
      
      list(verified = TRUE, size_match = TRUE, hash_match = TRUE, status = "VERIFIED")
    },
    
    verify_deletion = function(path) {
      if (file.exists(path)) {
        stop(sprintf("Verification Failed: File '%s' still exists after delete operation.", path))
      }
      list(verified = TRUE, status = "DELETED_VERIFIED")
    },
    
    verify_dataset = function(input_rows, output_rows, required_cols = character()) {
      if (output_rows < 0) {
        stop("Verification Failed: Negative output rows.")
      }
      list(verified = TRUE, input_rows = input_rows, output_rows = output_rows, status = "DATASET_VERIFIED")
    },
    
    verify_command = function(exit_code, stderr = character()) {
      if (exit_code != 0) {
        stop(sprintf("Verification Failed: Process exited with non-zero code %d. Stderr: %s",
                     exit_code, paste(head(stderr, 5), collapse = "\n")))
      }
      list(verified = TRUE, exit_code = exit_code, status = "COMMAND_VERIFIED")
    }
  )
)
