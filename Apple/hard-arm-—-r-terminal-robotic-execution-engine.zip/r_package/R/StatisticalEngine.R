#' StatisticalEngine: R Analytical and Statistical Arm Engine
#'
#' @description
#' Provides deep statistical inspection, summary statistics, outlier calculation,
#' and deterministic pipeline transformation of acquired dataset targets.
#'
#' @export
StatisticalEngine <- R6::R6Class(
  "StatisticalEngine",
  public = list(
    active_dataset = NULL,
    active_path = NULL,
    
    load_dataset = function(path) {
      if (!file.exists(path)) {
        stop(sprintf("Dataset target file '%s' does not exist.", path))
      }
      
      ext <- tolower(tools::file_ext(path))
      df <- if (ext == "csv") {
        data.table::fread(path, data.table = FALSE)
      } else if (ext %in% c("tsv", "txt")) {
        data.table::fread(path, sep = "\t", data.table = FALSE)
      } else if (ext == "json") {
        jsonlite::fromJSON(path)
      } else {
        read.csv(path, stringsAsFactors = FALSE)
      }
      
      self$active_dataset <- as.data.frame(df)
      self$active_path <- path
      self$inspect()
    },
    
    inspect = function() {
      if (is.null(self$active_dataset)) {
        stop("No active dataset loaded in statistical arm.")
      }
      
      df <- self$active_dataset
      n_rows <- nrow(df)
      n_cols <- ncol(df)
      
      col_types <- vapply(df, function(x) {
        if (is.numeric(x)) "NUMERIC"
        else if (is.logical(x)) "LOGICAL"
        else if (inherits(x, "Date") || inherits(x, "POSIXt")) "DATETIME"
        else "TEXT"
      }, character(1))
      
      num_count <- sum(col_types == "NUMERIC")
      text_count <- sum(col_types == "TEXT")
      log_count <- sum(col_types == "LOGICAL")
      
      total_cells <- n_rows * n_cols
      missing_cells <- sum(is.na(df))
      missing_pct <- if (total_cells > 0) round((missing_cells / total_cells) * 100, 2) else 0
      
      duplicate_rows <- sum(duplicated(df))
      
      list(
        rows = n_rows,
        columns = n_cols,
        numeric_cols = num_count,
        text_cols = text_count,
        logical_cols = log_count,
        missing_pct = missing_pct,
        duplicate_rows = duplicate_rows,
        col_names = names(df),
        col_types = as.list(col_types)
      )
    },
    
    analyse_column = function(col_name = NULL) {
      if (is.null(self$active_dataset)) {
        stop("No active dataset loaded in statistical arm.")
      }
      
      df <- self$active_dataset
      if (is.null(col_name)) {
        # Default to first numeric column or first column
        num_cols <- names(df)[vapply(df, is.numeric, logical(1))]
        col_name <- if (length(num_cols) > 0) num_cols[1] else names(df)[1]
      }
      
      if (!col_name %in% names(df)) {
        stop(sprintf("Column '%s' not found in dataset. Available: %s",
                     col_name, paste(names(df), collapse = ", ")))
      }
      
      vec <- df[[col_name]]
      
      if (is.numeric(vec)) {
        clean_vec <- vec[!is.na(vec)]
        q <- quantile(clean_vec, probs = c(0, 0.25, 0.5, 0.75, 1))
        iqr_val <- q[4] - q[2]
        lower_bound <- q[2] - (1.5 * iqr_val)
        upper_bound <- q[4] + (1.5 * iqr_val)
        outliers <- clean_vec[clean_vec < lower_bound | clean_vec > upper_bound]
        
        return(list(
          column = col_name,
          type = "NUMERIC",
          count = length(vec),
          missing = sum(is.na(vec)),
          mean = mean(clean_vec),
          median = median(clean_vec),
          sd = sd(clean_vec),
          min = unname(q[1]),
          q25 = unname(q[2]),
          median_q50 = unname(q[3]),
          q75 = unname(q[4]),
          max = unname(q[5]),
          iqr = unname(iqr_val),
          outlier_count = length(outliers),
          outlier_bounds = c(lower = unname(lower_bound), upper = unname(upper_bound))
        ))
      }
      
      # Categorical summary
      tab <- sort(table(as.character(vec), useNA = "ifany"), decreasing = TRUE)
      list(
        column = col_name,
        type = "CATEGORICAL",
        count = length(vec),
        distinct = length(unique(vec)),
        missing = sum(is.na(vec)),
        top_frequencies = head(as.list(tab), 10)
      )
    },
    
    filter = function(col_name, op, value) {
      if (is.null(self$active_dataset)) stop("No active dataset.")
      df <- self$active_dataset
      if (!col_name %in% names(df)) stop(sprintf("Column '%s' not found.", col_name))
      
      vec <- df[[col_name]]
      # Type cast value to match column
      num_val <- suppressWarnings(as.numeric(value))
      target_val <- if (is.numeric(vec) && !is.na(num_val)) num_val else value
      
      mask <- switch(op,
        ">" = vec > target_val,
        ">=" = vec >= target_val,
        "<" = vec < target_val,
        "<=" = vec <= target_val,
        "==" = vec == target_val,
        "!=" = vec != target_val,
        "%in%" = vec %in% strsplit(value, ",")[[1]],
        vec == target_val
      )
      
      mask[is.na(mask)] <- FALSE
      self$active_dataset <- df[mask, , drop = FALSE]
      invisible(nrow(self$active_dataset))
    },
    
    group_summarise = function(group_col, target_col, op = "sum") {
      if (is.null(self$active_dataset)) stop("No active dataset.")
      df <- self$active_dataset
      
      res <- aggregate(df[[target_col]], by = list(Group = df[[group_col]]), FUN = function(x) {
        clean <- x[!is.na(x)]
        switch(op,
          "sum" = sum(clean),
          "mean" = mean(clean),
          "count" = length(clean),
          "min" = min(clean),
          "max" = max(clean),
          sum(clean)
        )
      })
      names(res) <- c(group_col, sprintf("%s_%s", op, target_col))
      self$active_dataset <- res
      invisible(nrow(res))
    },
    
    sort = function(col_name, descending = FALSE) {
      if (is.null(self$active_dataset)) stop("No active dataset.")
      df <- self$active_dataset
      ord <- order(df[[col_name]], decreasing = descending)
      self$active_dataset <- df[ord, , drop = FALSE]
      invisible(nrow(self$active_dataset))
    },
    
    write_dataset = function(destination_path) {
      if (is.null(self$active_dataset)) stop("No active dataset.")
      dir_name <- dirname(destination_path)
      if (!dir.exists(dir_name) && dir_name != ".") {
        dir.create(dir_name, recursive = TRUE, showWarnings = FALSE)
      }
      
      write.csv(self$active_dataset, destination_path, row.names = FALSE)
      invisible(destination_path)
    }
  )
)
