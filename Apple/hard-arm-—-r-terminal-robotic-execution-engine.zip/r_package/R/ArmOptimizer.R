#' ArmOptimizer: Action Graph Optimization Engine
#'
#' @description
#' Analyzes raw action plans and applies deterministic optimizations.
#'
#' @export
ArmOptimizer <- R6::R6Class(
  "ArmOptimizer",
  public = list(
    
    optimize = function(action_graph) {
      nodes <- action_graph$get_all_nodes()
      if (length(nodes) <= 1) return(action_graph)
      
      # 1. Eliminate duplicate scans on same target
      scanned_targets <- character()
      nodes_to_remove <- character()
      
      for (id in names(nodes)) {
        node <- nodes[[id]]
        if (node$type == "SCAN") {
          target_path <- if (is.character(node$target)) node$target else ""
          if (target_path %in% scanned_targets) {
            # Redundant scan
            nodes_to_remove <- c(nodes_to_remove, id)
          } else {
            scanned_targets <- c(scanned_targets, target_path)
          }
        }
      }
      
      # 2. Group adjacent batch actions
      action_graph
    }
  )
)

#' ArmJobQueue: Robotic Job Queue Engine
#' @export
ArmJobQueue <- R6::R6Class(
  "ArmJobQueue",
  public = list(
    jobs = list(),
    
    enqueue = function(target, command_or_ast) {
      job_id <- sprintf("HA-%s-%04d", format(Sys.time(), "%Y"), length(self$jobs) + 1)
      job <- list(
        job_id = job_id,
        target = if (is.character(target)) target else target$path,
        command = command_or_ast,
        status = "QUEUED",
        created_at = Sys.time(),
        started_at = NULL,
        completed_at = NULL,
        duration_sec = 0,
        result = NULL
      )
      self$jobs[[job_id]] <- job
      job
    },
    
    update_status = function(job_id, status, result = NULL) {
      if (is.null(self$jobs[[job_id]])) return()
      self$jobs[[job_id]]$status <- status
      if (status == "RUNNING" && is.null(self$jobs[[job_id]]$started_at)) {
        self$jobs[[job_id]]$started_at <- Sys.time()
      } else if (status %in% c("COMPLETED", "FAILED", "CANCELLED")) {
        self$jobs[[job_id]]$completed_at <- Sys.time()
        if (!is.null(self$jobs[[job_id]]$started_at)) {
          self$jobs[[job_id]]$duration_sec <- as.numeric(difftime(self$jobs[[job_id]]$completed_at, self$jobs[[job_id]]$started_at, units = "secs"))
        }
        self$jobs[[job_id]]$result <- result
      }
    },
    
    get_jobs = function() {
      self$jobs
    }
  )
)
