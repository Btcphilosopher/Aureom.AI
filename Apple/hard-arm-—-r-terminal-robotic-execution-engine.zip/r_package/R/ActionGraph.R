#' ActionGraph: Directed Acyclic Graph of Robotic Arm Actions
#'
#' @description
#' Defines discrete action nodes and manages dependencies for deterministic execution.
#'
#' @export
ActionNode <- R6::R6Class(
  "ActionNode",
  public = list(
    action_id = NULL,
    type = NULL, # SCAN, SELECT, GRAB, MOVE, COPY, RENAME, EDIT, TRANSFORM, DELETE, EXECUTE, ANALYSE, WRITE, VERIFY, RELEASE
    target = NULL,
    parameters = list(),
    dependencies = character(),
    status = "PENDING", # PENDING, RUNNING, COMPLETED, FAILED, SKIPPED
    result = NULL,
    duration_ms = 0,
    created_at = NULL,
    
    initialize = function(action_id, type, target = NULL, parameters = list(), dependencies = character()) {
      self$action_id <- action_id
      self$type <- type
      self$target <- target
      self$parameters <- parameters
      self$dependencies <- dependencies
      self$status <- "PENDING"
      self$created_at <- Sys.time()
    },
    
    as_list = function() {
      list(
        action_id = self$action_id,
        type = self$type,
        target = if (is.character(self$target)) self$target else if (!is.null(self$target$path)) self$target$path else NULL,
        parameters = self$parameters,
        dependencies = self$dependencies,
        status = self$status,
        duration_ms = self$duration_ms
      )
    }
  )
)

#' ActionGraph: Graph Orchestrator
#' @export
ActionGraph <- R6::R6Class(
  "ActionGraph",
  public = list(
    nodes = list(),
    node_counter = 0,
    
    initialize = function() {
      self$nodes <- list()
      self$node_counter <- 0
    },
    
    add_node = function(type, target = NULL, parameters = list(), dependencies = character()) {
      self$node_counter <- self$node_counter + 1
      id <- sprintf("ACT-%03d", self$node_counter)
      node <- ActionNode$new(
        action_id = id,
        type = type,
        target = target,
        parameters = parameters,
        dependencies = dependencies
      )
      self$nodes[[id]] <- node
      node
    },
    
    get_node = function(action_id) {
      self$nodes[[action_id]]
    },
    
    get_all_nodes = function() {
      self$nodes
    },
    
    get_execution_order = function() {
      # Topological sort
      visited <- list()
      order <- character()
      
      visit <- function(node_id) {
        if (!is.null(visited[[node_id]])) {
          if (visited[[node_id]] == "temp") stop(sprintf("Cycle detected in action graph at node: %s", node_id))
          return()
        }
        visited[[node_id]] <<- "temp"
        node <- self$nodes[[node_id]]
        for (dep in node$dependencies) {
          if (!is.null(self$nodes[[dep]])) {
            visit(dep)
          }
        }
        visited[[node_id]] <<- "perm"
        order <<- c(order, node_id)
      }
      
      for (node_id in names(self$nodes)) {
        if (is.null(visited[[node_id]])) {
          visit(node_id)
        }
      }
      
      order
    },
    
    estimate_cost = function() {
      total_bytes <- 0
      target_count <- 0
      dangerous_ops <- 0
      
      for (node in self$nodes) {
        if (node$type %in% c("MOVE", "COPY", "DELETE", "WRITE")) {
          target_count <- target_count + 1
          if (!is.null(node$parameters$size_bytes)) {
            total_bytes <- total_bytes + node$parameters$size_bytes
          }
        }
        if (node$type == "DELETE" || isTRUE(node$parameters$overwrite)) {
          dangerous_ops <- dangerous_ops + 1
        }
      }
      
      list(
        total_actions = length(self$nodes),
        target_count = target_count,
        estimated_bytes = total_bytes,
        dangerous_ops = dangerous_ops
      )
    },
    
    reset = function() {
      self$nodes <- list()
      self$node_counter <- 0
    }
  )
)
