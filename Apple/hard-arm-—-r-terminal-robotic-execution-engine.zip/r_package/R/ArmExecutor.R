#' ArmExecutor: Robotic Arm Action Execution Engine
#'
#' @description
#' Executes action graphs with discrete step reporting, error recovery, and verification.
#'
#' @export
ArmExecutor <- R6::R6Class(
  "ArmExecutor",
  public = list(
    verification_engine = NULL,
    snapshot_engine = NULL,
    journal = NULL,
    statistical_engine = NULL,
    
    initialize = function(verification_engine, snapshot_engine, journal, statistical_engine) {
      self$verification_engine <- verification_engine
      self$snapshot_engine <- snapshot_engine
      self$journal <- journal
      self$statistical_engine <- statistical_engine
    },
    
    execute_graph = function(job_id, action_graph, dry_run = FALSE, on_progress = NULL) {
      order <- action_graph$get_execution_order()
      total_actions <- length(order)
      completed_count <- 0
      bytes_processed <- 0
      
      if (dry_run) {
        cost <- action_graph$estimate_cost()
        return(list(
          dry_run = TRUE,
          status = "DRY_RUN_COMPLETE",
          total_actions = total_actions,
          estimated_bytes = cost$estimated_bytes,
          target_count = cost$target_count,
          message = sprintf("DRY RUN: %d actions would be performed. Estimated movement: %.2f MB.",
                            total_actions, cost$estimated_bytes / (1024^2))
        ))
      }
      
      start_time <- Sys.time()
      
      for (i in seq_along(order)) {
        node_id <- order[i]
        node <- action_graph$get_node(node_id)
        node$status <- "RUNNING"
        
        node_start <- Sys.time()
        
        tryCatch({
          res <- self$execute_single_node(node)
          node$status <- "COMPLETED"
          node$result <- res
          node$duration_ms <- as.numeric(difftime(Sys.time(), node_start, units = "secs")) * 1000
          
          if (!is.null(node$parameters$size_bytes)) {
            bytes_processed <- bytes_processed + node$parameters$size_bytes
          }
          
          self$journal$log_action(
            job_id = job_id,
            action_id = node$action_id,
            operation = node$type,
            target = node$target,
            status = "COMPLETED",
            original_hash = if (!is.null(res$orig_hash)) res$orig_hash else "",
            result_hash = if (!is.null(res$dest_hash)) res$dest_hash else "",
            duration_ms = node$duration_ms
          )
          
          completed_count <- completed_count + 1
          if (is.function(on_progress)) {
            on_progress(completed_count, total_actions, node)
          }
          
        }, error = function(e) {
          node$status <- "FAILED"
          node$duration_ms <- as.numeric(difftime(Sys.time(), node_start, units = "secs")) * 1000
          
          self$journal$log_action(
            job_id = job_id,
            action_id = node$action_id,
            operation = node$type,
            target = node$target,
            status = "FAILED",
            error_msg = e$message,
            duration_ms = node$duration_ms
          )
          
          stop(sprintf("Robotic Arm Action %s (%s) FAILED on target '%s': %s",
                       node$action_id, node$type, node$target, e$message))
        })
      }
      
      total_duration <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
      self$journal$log_job_end(job_id, "COMPLETED", duration_sec = total_duration, bytes_processed = bytes_processed)
      
      list(
        status = "COMPLETE",
        completed_actions = completed_count,
        total_actions = total_actions,
        duration_sec = total_duration,
        bytes_processed = bytes_processed
      )
    },
    
    execute_single_node = function(node) {
      switch(node$type,
        "SCAN" = {
          list(status = "SCANNED", target = node$target)
        },
        
        "VALIDATE" = {
          dest <- node$parameters$destination
          if (!is.null(dest)) {
            dir_name <- dirname(dest)
            if (!dir.exists(dir_name) && dir_name != ".") {
              dir.create(dir_name, recursive = TRUE, showWarnings = FALSE)
            }
          }
          list(status = "VALIDATED")
        },
        
        "LOCK" = {
          list(status = "LOCKED", target = node$target)
        },
        
        "MOVE" = {
          src <- node$parameters$source
          dest <- node$parameters$destination
          if (!file.exists(src)) stop(sprintf("Source '%s' does not exist.", src))
          
          dest_dir <- dirname(dest)
          if (!dir.exists(dest_dir) && dest_dir != ".") dir.create(dest_dir, recursive = TRUE, showWarnings = FALSE)
          
          orig_hash <- digest::digest(src, algo = "sha256", file = TRUE)
          success <- file.rename(src, dest)
          if (!success) {
            # Fallback for cross-device moves
            file.copy(src, dest, overwrite = TRUE)
            unlink(src, recursive = TRUE)
          }
          dest_hash <- digest::digest(dest, algo = "sha256", file = TRUE)
          list(status = "MOVED", orig_hash = orig_hash, dest_hash = dest_hash)
        },
        
        "COPY" = {
          src <- node$parameters$source
          dest <- node$parameters$destination
          if (!file.exists(src)) stop(sprintf("Source '%s' does not exist.", src))
          dest_dir <- dirname(dest)
          if (!dir.exists(dest_dir) && dest_dir != ".") dir.create(dest_dir, recursive = TRUE, showWarnings = FALSE)
          orig_hash <- digest::digest(src, algo = "sha256", file = TRUE)
          file.copy(src, dest, overwrite = TRUE)
          dest_hash <- digest::digest(dest, algo = "sha256", file = TRUE)
          list(status = "COPIED", orig_hash = orig_hash, dest_hash = dest_hash)
        },
        
        "DELETE" = {
          target <- node$target
          if (file.exists(target)) {
            unlink(target, recursive = TRUE)
          }
          list(status = "DELETED")
        },
        
        "TRANSFORM" = {
          p <- node$parameters
          if (!is.null(p$op) && !is.null(p$column)) {
            self$statistical_engine$filter(p$column, p$op, p$value)
          }
          list(status = "TRANSFORMED")
        },
        
        "WRITE" = {
          dest <- node$parameters$destination
          self$statistical_engine$write_dataset(dest)
          list(status = "WRITTEN", destination = dest)
        },
        
        "VERIFY" = {
          p <- node$parameters
          if (!is.null(p$expected_hash)) {
            self$verification_engine$verify_file_move(
              source = node$target,
              destination = node$target,
              expected_size = p$expected_size,
              expected_hash = p$expected_hash
            )
          }
          list(status = "VERIFIED")
        },
        
        "RELEASE" = {
          list(status = "RELEASED")
        },
        
        "SNAPSHOT" = {
          target_obj <- list(path = node$target, type = "FILE", size = file.info(node$target)$size, hash = digest::digest(node$target, algo = "sha256", file = TRUE))
          snap <- self$snapshot_engine$create_snapshot(target_obj, reason = node$parameters$reason)
          list(status = "SNAPSHOT_CREATED", snapshot_id = snap$snapshot_id)
        },
        
        {
          list(status = "EXECUTED_GENERIC")
        }
      )
    }
  )
)
