#' GrabEngine: Target Acquisition and Streaming Inspector
#'
#' @description
#' Handles deterministic target resolution, chunked hashing, and streaming acquisition.
#'
#' @export
GrabEngine <- R6::R6Class(
  "GrabEngine",
  public = list(
    chunk_size_bytes = 1048576, # 1 MB stream chunk
    
    initialize = function(chunk_size_bytes = 1048576) {
      self$chunk_size_bytes <- chunk_size_bytes
    },
    
    grab_target = function(path_or_glob, on_progress = NULL) {
      if (grepl("[*?]", path_or_glob)) {
        files <- Sys.glob(path_or_glob)
        if (length(files) == 0) {
          stop(sprintf("No targets matched glob pattern: '%s'", path_or_glob))
        }
        return(lapply(files, function(f) self$acquire_single_path(f, on_progress)))
      }
      
      self$acquire_single_path(path_or_glob, on_progress)
    },
    
    acquire_single_path = function(path, on_progress = NULL) {
      if (!file.exists(path)) {
        stop(sprintf("Target does not exist: '%s'", path))
      }
      
      is_dir <- dir.exists(path)
      info <- file.info(path)
      
      if (is_dir) {
        files_in_dir <- list.files(path, recursive = TRUE, all.files = TRUE, full.names = TRUE)
        total_size <- sum(file.info(files_in_dir)$size, na.rm = TRUE)
        
        target <- ArmTarget$new(path = path, type = "DIRECTORY", metadata = list(
          file_count = length(files_in_dir),
          top_files = head(basename(files_in_dir), 10)
        ))
        target$size <- total_size
        target$lines <- length(files_in_dir)
        target$permissions <- as.character(info$mode)
        target$hash <- digest::digest(paste(basename(files_in_dir), collapse = "|"), algo = "sha256")
        return(target)
      }
      
      # Single File Target
      ext <- tolower(tools::file_ext(path))
      type <- switch(ext,
        "csv" = "DATASET",
        "tsv" = "DATASET",
        "parquet" = "DATASET",
        "json" = "DATASET",
        "log" = "LOG",
        "txt" = "TEXT",
        "md" = "TEXT",
        "r" = "SOURCE_CODE",
        "py" = "SOURCE_CODE",
        "sh" = "SOURCE_CODE",
        "pdf" = "DOCUMENT",
        "FILE"
      )
      
      target <- ArmTarget$new(path = path, type = type)
      target$size <- info$size
      target$permissions <- as.character(info$mode)
      
      # Streaming acquisition for hash & line counting
      stream_res <- self$stream_inspect_file(path, info$size, on_progress)
      target$hash <- stream_res$hash
      target$lines <- stream_res$lines
      target$metadata <- stream_res$metadata
      
      target
    },
    
    stream_inspect_file = function(path, file_size, on_progress = NULL) {
      con <- file(path, "rb")
      on.exit(close(con))
      
      lines_count <- 0
      bytes_read <- 0
      hasher <- digest::digest(raw(0), algo = "sha256", serialize = FALSE)
      
      # For small/medium files, read lines directly
      if (file_size < 50 * 1024 * 1024) { # < 50 MB
        raw_data <- readBin(con, what = "raw", n = file_size)
        file_hash <- digest::digest(raw_data, algo = "sha256", serialize = FALSE)
        # Count newlines in raw buffer (0x0a)
        lines_count <- sum(raw_data == as.raw(10))
        if (lines_count == 0 && length(raw_data) > 0) lines_count <- 1
        
        if (is.function(on_progress)) on_progress(100)
        return(list(hash = file_hash, lines = lines_count, metadata = list(streaming = FALSE)))
      }
      
      # Streaming chunked read for large targets
      total_chunks <- ceiling(file_size / self$chunk_size_bytes)
      chunk_idx <- 0
      
      while (bytes_read < file_size) {
        chunk <- readBin(con, what = "raw", n = self$chunk_size_bytes)
        if (length(chunk) == 0) break
        bytes_read <- bytes_read + length(chunk)
        chunk_idx <- chunk_idx + 1
        lines_count <- lines_count + sum(chunk == as.raw(10))
        
        if (is.function(on_progress)) {
          pct <- round((bytes_read / file_size) * 100)
          on_progress(pct)
        }
      }
      
      # Compute whole file digest
      file_hash <- digest::digest(path, algo = "sha256", file = TRUE)
      
      list(
        hash = file_hash,
        lines = lines_count,
        metadata = list(streaming = TRUE, chunks = chunk_idx)
      )
    },
    
    grab_command = function(executable, args = character()) {
      start_time <- Sys.time()
      out_file <- tempfile(fileext = ".out")
      err_file <- tempfile(fileext = ".err")
      on.exit({
        if (file.exists(out_file)) unlink(out_file)
        if (file.exists(err_file)) unlink(err_file)
      })
      
      exit_code <- system2(
        command = executable,
        args = args,
        stdout = out_file,
        stderr = err_file
      )
      
      duration <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
      stdout_text <- if (file.exists(out_file)) readLines(out_file, warn = FALSE) else character()
      stderr_text <- if (file.exists(err_file)) readLines(err_file, warn = FALSE) else character()
      
      CommandTarget$new(
        command = executable,
        args = args,
        stdout = stdout_text,
        stderr = stderr_text,
        exit_code = exit_code,
        duration_sec = duration
      )
    }
  )
)
