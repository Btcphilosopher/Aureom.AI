#' WatchMode: Continuous Robotic Directory Surveillance
#'
#' @description
#' Continuously monitors directories, performs stability checks, acquires new files,
#' executes plans, verifies, and records processed file hashes to avoid duplicate processing.
#'
#' @export
WatchMode <- R6::R6Class(
  "WatchMode",
  public = list(
    watch_dir = NULL,
    processed_hashes = character(),
    is_running = FALSE,
    arm_controller = NULL,
    
    initialize = function(watch_dir, arm_controller) {
      self$watch_dir <- watch_dir
      self$arm_controller <- arm_controller
      self$processed_hashes <- character()
      self$is_running <- FALSE
    },
    
    start_watching = function(interval_sec = 2, max_iterations = 10, on_event = NULL) {
      if (!dir.exists(self$watch_dir)) {
        stop(sprintf("Watch directory '%s' does not exist.", self$watch_dir))
      }
      
      self$is_running <- TRUE
      iter <- 0
      
      while (self$is_running && iter < max_iterations) {
        iter <- iter + 1
        files <- list.files(self$watch_dir, full.names = TRUE, recursive = FALSE)
        
        for (f in files) {
          # Check if already processed
          f_hash <- digest::digest(f, algo = "sha256", file = TRUE)
          if (!f_hash %in% self$processed_hashes) {
            # Stability check: ensure file is not still being written
            size1 <- file.info(f)$size
            Sys.sleep(0.5)
            size2 <- file.info(f)$size
            
            if (size1 == size2 && size1 > 0) {
              if (is.function(on_event)) {
                on_event("ACQUIRED", f)
              }
              
              # Robotic arm execution on new target
              self$arm_controller$grab(f)
              self$arm_controller$inspect()
              self$processed_hashes <- c(self$processed_hashes, f_hash)
            }
          }
        }
        
        Sys.sleep(interval_sec)
      }
      
      self$is_running <- FALSE
      invisible(length(self$processed_hashes))
    },
    
    stop_watching = function() {
      self$is_running <- FALSE
    }
  )
)
