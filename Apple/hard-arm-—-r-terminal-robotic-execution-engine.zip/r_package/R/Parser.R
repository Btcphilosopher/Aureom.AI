#' Parser: Deterministic Command Lexer and Parser for HARD ARM
#'
#' @description
#' Strictly converts user terminal commands into AST nodes without using `eval()`.
#'
#' @export
Parser <- R6::R6Class(
  "Parser",
  public = list(
    
    parse = function(command_str) {
      if (is.null(command_str) || nchar(trimws(command_str)) == 0) {
        return(NULL)
      }
      
      lines <- strsplit(trimws(command_str), "\n")[[1]]
      lines <- trimws(lines)
      lines <- lines[nchar(lines) > 0 & !grepl("^#", lines)]
      
      if (length(lines) > 1) {
        nodes <- lapply(lines, self$parse_single_line)
        return(AST$WorkflowNode(nodes = nodes))
      }
      
      self$parse_single_line(lines[1])
    },
    
    parse_single_line = function(line) {
      line <- trimws(line)
      # Strip leading "hardarm " if present
      if (grepl("^hardarm\\s+", line)) {
        line <- sub("^hardarm\\s+", "", line)
      }
      
      tokens <- self$tokenize(line)
      if (length(tokens) == 0) return(NULL)
      
      verb <- tolower(tokens[1])
      rest <- if (length(tokens) > 1) tokens[-1] else character()
      
      switch(verb,
        "grab" = {
          if (length(rest) == 0) stop("Syntax error: 'grab' requires a target path or pattern.")
          target <- rest[1]
          flags <- list(
            plan = "--plan" %in% rest,
            execute = "--execute" %in% rest,
            dry_run = "--dry-run" %in% rest
          )
          AST$GrabNode(target, flags)
        },
        "grab-output" = {
          # Syntax: grab-output -- ls -lah
          sep_idx <- which(rest == "--")
          if (length(sep_idx) == 0 || sep_idx == length(rest)) {
            stop("Syntax error: 'grab-output' requires '-- <command> [args...]'")
          }
          exec <- rest[sep_idx + 1]
          args <- if (length(rest) > sep_idx + 1) rest[(sep_idx + 2):length(rest)] else character()
          AST$GrabOutputNode(exec, args)
        },
        "inspect" = AST$InspectNode(if (length(rest) > 0) rest[1] else "ALL"),
        "analyse" = ,
        "analyze" = {
          col <- if (length(rest) > 0) rest[1] else NULL
          AST$AnalyseNode(col)
        },
        "filter" = {
          # Syntax: filter revenue > 1000  OR  filter region == 'North'
          if (length(rest) < 3) stop("Syntax error: 'filter' requires '<col> <op> <val>' (e.g. filter revenue > 1000)")
          col <- rest[1]
          op <- rest[2]
          val <- paste(rest[3:length(rest)], collapse = " ")
          # Unquote if quoted string
          val <- gsub("^['\"]|['\"]$", "", val)
          AST$FilterNode(col, op, val)
        },
        "group" = {
          # Syntax: group by region
          if (length(rest) >= 2 && tolower(rest[1]) == "by") {
            AST$GroupNode(rest[2])
          } else if (length(rest) >= 1) {
            AST$GroupNode(rest[1])
          } else {
            stop("Syntax error: 'group' requires 'by <col>'")
          }
        },
        "summarise" = ,
        "summarize" = {
          if (length(rest) == 0) stop("Syntax error: 'summarise' requires '<column>'")
          AST$SummariseNode(rest[1])
        },
        "sort" = {
          # Syntax: sort revenue descending  OR  sort revenue asc
          if (length(rest) == 0) stop("Syntax error: 'sort' requires '<column>'")
          col <- rest[1]
          desc <- if (length(rest) > 1 && tolower(rest[2]) %in% c("desc", "descending")) TRUE else FALSE
          AST$SortNode(col, desc)
        },
        "move" = {
          # Syntax: move to Archive/  OR  move A.txt to Archive/A.txt
          if ("to" %in% tolower(rest)) {
            to_idx <- which(tolower(rest) == "to")[1]
            dest <- rest[to_idx + 1]
            src <- if (to_idx > 1) rest[1] else NULL
            AST$MoveNode(dest, src)
          } else if (length(rest) >= 1) {
            AST$MoveNode(rest[1])
          } else {
            stop("Syntax error: 'move' requires 'to <destination>'")
          }
        },
        "copy" = {
          if ("to" %in% tolower(rest)) {
            to_idx <- which(tolower(rest) == "to")[1]
            dest <- rest[to_idx + 1]
            src <- if (to_idx > 1) rest[1] else NULL
            AST$CopyNode(dest, src)
          } else {
            AST$CopyNode(rest[1])
          }
        },
        "rename" = {
          if ("to" %in% tolower(rest)) {
            to_idx <- which(tolower(rest) == "to")[1]
            AST$RenameNode(rest[to_idx + 1])
          } else {
            AST$RenameNode(rest[1])
          }
        },
        "delete" = {
          force <- "--force" %in% rest || "force" %in% tolower(rest)
          AST$DeleteNode(force = force)
        },
        "write" = ,
        "save" = {
          if (length(rest) == 0) stop("Syntax error: 'write' requires a destination path.")
          AST$WriteNode(rest[1])
        },
        "find" = {
          if (length(rest) == 0) stop("Syntax error: 'find' requires a pattern (e.g. find '*.py')")
          AST$FindNode(gsub("^['\"]|['\"]$", "", rest[1]))
        },
        "verify" = AST$VerifyNode(),
        "release" = AST$ReleaseNode(),
        "snapshot" = AST$SnapshotNode(),
        "restore" = {
          if (length(rest) == 0) stop("Syntax error: 'restore' requires a snapshot ID.")
          AST$RestoreNode(rest[1])
        },
        "plan" = AST$PlanNode(),
        "preview" = AST$PreviewNode(),
        "execute" = {
          dry_run <- "--dry-run" %in% rest
          AST$ExecuteNode(dry_run = dry_run)
        },
        "watch" = {
          if (length(rest) == 0) stop("Syntax error: 'watch' requires a directory path.")
          AST$WatchNode(rest[1])
        },
        "telemetry" = AST$TelemetryNode(),
        "jobs" = AST$JobsNode(),
        "history" = {
          lim <- if (length(rest) > 0 && grepl("^\\d+$", rest[1])) as.integer(rest[1]) else 20
          AST$HistoryNode(lim)
        },
        "status" = AST$StatusNode(),
        stop(sprintf("Unknown HARD ARM command: '%s'. Type 'status' or 'inspect' for guidance.", verb))
      )
    },
    
    tokenize = function(line) {
      # Handle quotes safely without shell injection
      m <- gregexpr('"[^"]*"|\'[^\']*\'|\\S+', line)
      regmatches(line, m)[[1]]
    }
  )
)
