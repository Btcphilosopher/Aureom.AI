#' Gripper: Virtual Robotic Gripper Controller
#'
#' @description
#' Represents physical ownership/lock of a target object.
#' Gripper States: OPEN, APPROACHING, GRIPPING, LOCKED, RELEASING, RELEASED.
#'
#' @export
Gripper <- R6::R6Class(
  "Gripper",
  public = list(
    state = "OPEN", # OPEN, APPROACHING, GRIPPING, LOCKED, RELEASING, RELEASED
    locked_target = NULL,
    grip_force_pct = 0,
    lock_timestamp = NULL,
    
    initialize = function() {
      self$state <- "OPEN"
      self$locked_target <- NULL
      self$grip_force_pct <- 0
    },
    
    approach = function(target) {
      self$state <- "APPROACHING"
      self$grip_force_pct <- 25
      Sys.sleep(0.01)
      invisible(TRUE)
    },
    
    grip = function(target) {
      self$approach(target)
      self$state <- "GRIPPING"
      self$grip_force_pct <- 75
      Sys.sleep(0.01)
      invisible(TRUE)
    },
    
    lock = function(target) {
      self$grip(target)
      self$state <- "LOCKED"
      self$grip_force_pct <- 100
      self$locked_target <- target
      self$lock_timestamp <- Sys.time()
      invisible(TRUE)
    },
    
    release = function() {
      self$state <- "RELEASING"
      self$grip_force_pct <- 50
      Sys.sleep(0.01)
      self$locked_target <- NULL
      self$grip_force_pct <- 0
      self$state <- "RELEASED"
      invisible(TRUE)
    },
    
    is_locked = function() {
      self$state == "LOCKED" && !is.null(self$locked_target)
    },
    
    status = function() {
      list(
        state = self$state,
        grip_pct = self$grip_force_pct,
        target = if (!is.null(self$locked_target)) self$locked_target$path else NULL,
        locked = self$is_locked()
      )
    }
  )
)
