#' ActionJournal: Transactional SQLite Audit Log
#'
#' @description
#' Records all jobs, robotic movements, actions, hashes, and verification statuses in SQLite.
#'
#' @export
ActionJournal <- R6::R6Class(
  "ActionJournal",
  public = list(
    db_path = NULL,
    con = NULL,
    
    initialize = function(db_path = file.path(tempdir(), "hardarm_journal.sqlite")) {
      self$db_path <- db_path
      self$con <- DBI::dbConnect(RSQLite::SQLite(), self$db_path)
      self$init_schema()
    },
    
    init_schema = function() {
      DBI::dbExecute(self$con, "
        CREATE TABLE IF NOT EXISTS jobs (
          job_id TEXT PRIMARY KEY,
          target_path TEXT,
          target_type TEXT,
          status TEXT,
          total_actions INTEGER,
          started_at TEXT,
          completed_at TEXT,
          duration_sec REAL,
          bytes_processed REAL
        )
      ")
      
      DBI::dbExecute(self$con, "
        CREATE TABLE IF NOT EXISTS actions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          job_id TEXT,
          action_id TEXT,
          operation TEXT,
          target TEXT,
          status TEXT,
          original_hash TEXT,
          result_hash TEXT,
          duration_ms REAL,
          error_msg TEXT,
          timestamp TEXT
        )
      ")
    },
    
    log_job_start = function(job_id, target_path, target_type, total_actions) {
      query <- "INSERT INTO jobs (job_id, target_path, target_type, status, total_actions, started_at)
                VALUES (?, ?, ?, 'RUNNING', ?, ?)"
      DBI::dbExecute(self$con, query, params = list(
        job_id, target_path, target_type, total_actions, as.character(Sys.time())
      ))
    },
    
    log_action = function(job_id, action_id, operation, target, status, original_hash = "", result_hash = "", duration_ms = 0, error_msg = "") {
      query <- "INSERT INTO actions (job_id, action_id, operation, target, status, original_hash, result_hash, duration_ms, error_msg, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
      DBI::dbExecute(self$con, query, params = list(
        job_id, action_id, operation, as.character(target), status, original_hash, result_hash, duration_ms, error_msg, as.character(Sys.time())
      ))
    },
    
    log_job_end = function(job_id, status, duration_sec = 0, bytes_processed = 0) {
      query <- "UPDATE jobs SET status = ?, completed_at = ?, duration_sec = ?, bytes_processed = ? WHERE job_id = ?"
      DBI::dbExecute(self$con, query, params = list(
        status, as.character(Sys.time()), duration_sec, bytes_processed, job_id
      ))
    },
    
    get_history = function(limit = 20) {
      query <- sprintf("SELECT * FROM jobs ORDER BY started_at DESC LIMIT %d", as.integer(limit))
      DBI::dbGetQuery(self$con, query)
    },
    
    get_job_actions = function(job_id) {
      query <- "SELECT * FROM actions WHERE job_id = ? ORDER BY id ASC"
      DBI::dbGetQuery(self$con, query, params = list(job_id))
    },
    
    get_telemetry_summary = function() {
      jobs_df <- DBI::dbGetQuery(self$con, "SELECT COUNT(*) as total_jobs, SUM(CASE WHEN status='COMPLETED' THEN 1 ELSE 0 END) as success_jobs, SUM(bytes_processed) as total_bytes, AVG(duration_sec) as avg_duration FROM jobs")
      actions_df <- DBI::dbGetQuery(self$con, "SELECT COUNT(*) as total_actions, SUM(CASE WHEN status='COMPLETED' THEN 1 ELSE 0 END) as success_actions FROM actions")
      
      list(
        total_jobs = if (!is.na(jobs_df$total_jobs)) jobs_df$total_jobs else 0,
        success_jobs = if (!is.na(jobs_df$success_jobs)) jobs_df$success_jobs else 0,
        total_actions = if (!is.na(actions_df$total_actions)) actions_df$total_actions else 0,
        total_bytes = if (!is.na(jobs_df$total_bytes)) jobs_df$total_bytes else 0,
        avg_duration_sec = if (!is.na(jobs_df$avg_duration)) jobs_df$avg_duration else 0
      )
    },
    
    finalize = function() {
      if (!is.null(self$con)) {
        DBI::dbDisconnect(self$con)
      }
    }
  )
)
