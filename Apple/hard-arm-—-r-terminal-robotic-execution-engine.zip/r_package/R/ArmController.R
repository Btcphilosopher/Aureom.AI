#' ArmController: Main Robotic Arm Controller for HARD ARM
#'
#' @description
#' The central coordinator orchestrating state, gripper, planning, safety, execution, and verification.
#'
#' @export
ArmController <- R6::R6Class(
  "ArmController",
  public = list(
    state = NULL,
    gripper = NULL,
    current_target = NULL,
    grab_engine = NULL,
    parser = NULL,
    planner = NULL,
    safety = NULL,
    executor = NULL,
    verification = NULL,
    snapshot_engine = NULL,
    journal = NULL,
    statistical_engine = NULL,
    batch_engine = NULL,
    optimizer = NULL,
    job_queue = NULL,
    telemetry_engine = NULL,
    current_plan = NULL,
    
    initialize = function() {
      self$state <- ArmState$new()
      self$gripper <- Gripper$new()
      self$grab_engine <- GrabEngine$new()
      self$parser <- Parser$new()
      self$planner <- ArmPlanner$new()
      self$safety <- SafetyController$new()
      self$verification <- VerificationEngine$new()
      self$snapshot_engine <- SnapshotEngine$new()
      self$journal <- ActionJournal$new()
      self$statistical_engine <- StatisticalEngine$new()
      self$batch_engine <- BatchEngine$new()
      self$optimizer <- ArmOptimizer$new()
      self$job_queue <- ArmJobQueue$new()
      self$telemetry_engine <- Telemetry$new(self$journal)
      
      self$executor <- ArmExecutor$new(
        verification_engine = self$verification,
        snapshot_engine = self$snapshot_engine,
        journal = self$journal,
        statistical_engine = self$statistical_engine
      )
    },
    
    grab = function(target_path, flags = list()) {
      self$state$transition("TARGETING", reason = sprintf("Targeting '%s'", target_path))
      self$gripper$approach(target_path)
      
      self$state$transition("GRABBING", reason = "Streaming target acquisition")
      self$gripper$grip(target_path)
      
      target_obj <- self$grab_engine$grab_target(target_path)
      
      if (is.list(target_obj) && !inherits(target_obj, "ArmTarget")) {
        # Batch target acquisition
        self$current_target <- target_obj
      } else {
        self$current_target <- target_obj
        if (target_obj$type == "DATASET") {
          tryCatch(self$statistical_engine$load_dataset(target_obj$path), error = function(e) NULL)
        }
      }
      
      self$gripper$lock(self$current_target)
      self$state$transition("HOLDING", reason = "Target secured in gripper lock")
      
      if (isTRUE(flags$plan)) {
        self$plan()
      }
      if (isTRUE(flags$execute)) {
        self$execute(dry_run = isTRUE(flags$dry_run))
      }
      
      self$current_target
    },
    
    grab_output = function(command, args = character()) {
      self$state$transition("TARGETING", reason = sprintf("Targeting command '%s'", command))
      self$state$transition("GRABBING", reason = "Executing command subprocess")
      
      target <- self$grab_engine$grab_command(command, args)
      self$current_target <- target
      self$gripper$lock(target)
      self$state$transition("HOLDING", reason = "Command output secured in gripper")
      target
    },
    
    inspect = function(sub_type = "ALL") {
      if (is.null(self$current_target)) stop("No target currently held by robotic arm. Run 'grab <path>' first.")
      self$state$transition("ANALYSING", reason = "Inspecting held target")
      
      if (is.list(self$current_target) && !inherits(self$current_target, "ArmTarget")) {
        # Batch inspection
        total_size <- sum(vapply(self$current_target, function(x) x$size, numeric(1)))
        return(list(
          type = "BATCH",
          count = length(self$current_target),
          total_size_bytes = total_size,
          targets = lapply(self$current_target, function(t) t$summary())
        ))
      }
      
      tgt <- self$current_target
      res <- tgt$summary()
      
      if (tgt$type == "DATASET") {
        res$dataset_profile <- tryCatch(self$statistical_engine$inspect(), error = function(e) list(error = e$message))
      }
      
      self$state$transition("HOLDING", reason = "Inspection completed")
      res
    },
    
    analyse = function(column = NULL) {
      if (is.null(self$current_target)) stop("No target held by robotic arm.")
      self$state$transition("ANALYSING", reason = sprintf("Statistical analysis on column '%s'", if (!is.null(column)) column else "default"))
      
      res <- self$statistical_engine$analyse_column(column)
      self$state$transition("HOLDING", reason = "Statistical analysis complete")
      res
    },
    
    plan = function(ast_node = NULL) {
      if (is.null(self$current_target)) stop("No target currently held by arm.")
      self$state$transition("PLANNING", reason = "Constructing robotic action graph")
      
      if (is.null(ast_node)) {
        # Default inspection/verification plan
        ast_node <- AST$InspectNode()
      }
      
      if (is.list(self$current_target) && !inherits(self$current_target, "ArmTarget")) {
        self$current_plan <- self$planner$plan_batch(self$current_target, "MOVE")
      } else {
        self$current_plan <- self$planner$plan_operation(self$current_target, ast_node, optimizer = self$optimizer)
      }
      
      self$state$transition("HOLDING", reason = "Plan generated and cached")
      self$current_plan
    },
    
    preview = function() {
      if (is.null(self$current_plan)) {
        self$plan()
      }
      
      cost <- self$current_plan$estimate_cost()
      nodes <- self$current_plan$get_all_nodes()
      
      list(
        total_actions = length(nodes),
        actions = lapply(nodes, function(n) n$as_list()),
        estimated_bytes = cost$estimated_bytes,
        dangerous_ops = cost$dangerous_ops
      )
    },
    
    execute = function(dry_run = FALSE, on_progress = NULL) {
      if (is.null(self$current_plan)) {
        self$plan()
      }
      
      # Safety validation
      safety_check <- self$safety$validate_action_graph(self$current_plan, dry_run = dry_run)
      
      self$state$transition(if (dry_run) "PLANNING" else "EXECUTING", reason = if (dry_run) "Simulating dry-run" else "Executing robotic actions")
      
      job_id <- sprintf("HA-%s-%06d", format(Sys.time(), "%Y"), sample(100000:999999, 1))
      tgt_path <- if (inherits(self$current_target, "ArmTarget")) self$current_target$path else "batch_targets"
      tgt_type <- if (inherits(self$current_target, "ArmTarget")) self$current_target$type else "BATCH"
      
      if (!dry_run) {
        self$journal$log_job_start(job_id, tgt_path, tgt_type, length(self$current_plan$get_all_nodes()))
      }
      
      res <- self$executor$execute_graph(job_id, self$current_plan, dry_run = dry_run, on_progress = on_progress)
      
      self$state$transition(if (dry_run) "HOLDING" else "VERIFYING", reason = "Verifying operation results")
      
      if (!dry_run) {
        self$state$transition("COMPLETE", reason = "Robotic execution verified successfully")
      }
      
      res
    },
    
    verify = function() {
      if (is.null(self$current_target)) stop("No target to verify.")
      self$state$transition("VERIFYING", reason = "Performing verification check")
      
      tgt <- self$current_target
      if (file.exists(tgt$path)) {
        curr_hash <- digest::digest(tgt$path, algo = "sha256", file = TRUE)
        match <- (curr_hash == tgt$hash)
        res <- list(path = tgt$path, verified = match, initial_hash = tgt$hash, current_hash = curr_hash)
      } else {
        res <- list(path = tgt$path, verified = FALSE, error = "Target path no longer exists")
      }
      
      self$state$transition("HOLDING", reason = "Verification finished")
      res
    },
    
    release = function() {
      self$state$transition("RELEASING", reason = "Releasing gripper lock")
      self$gripper$release()
      target_rel <- self$current_target
      self$current_target <- NULL
      self$current_plan <- NULL
      self$state$transition("IDLE", reason = "Arm in home position")
      
      list(status = "RELEASED", released_target = if (!is.null(target_rel$path)) target_rel$path else "targets")
    },
    
    snapshot = function() {
      if (is.null(self$current_target)) stop("No target to snapshot.")
      self$snapshot_engine$create_snapshot(self$current_target, reason = "Manual snapshot request")
    },
    
    restore = function(snapshot_id) {
      self$snapshot_engine$restore_snapshot(snapshot_id)
    },
    
    jobs = function() {
      self$job_queue$get_jobs()
    },
    
    telemetry = function() {
      self$telemetry_engine$get_metrics()
    },
    
    history = function(limit = 20) {
      self$journal$get_history(limit)
    },
    
    status = function() {
      list(
        arm_state = self$state$get_state(),
        gripper = self$gripper$status(),
        target = if (!is.null(self$current_target)) self$current_target$summary() else NULL,
        has_plan = !is.null(self$current_plan)
      )
    },
    
    dispatch_command = function(cmd_str) {
      ast <- self$parser$parse(cmd_str)
      if (is.null(ast)) return(NULL)
      
      switch(ast$type,
        "GRAB" = self$grab(ast$params$target, ast$params$flags),
        "GRAB_OUTPUT" = self$grab_output(ast$params$executable, ast$params$args),
        "INSPECT" = self$inspect(ast$params$sub_type),
        "ANALYSE" = self$analyse(ast$params$column),
        "FILTER" = {
          self$statistical_engine$filter(ast$params$column, ast$params$op, ast$params$value)
          list(status = "FILTER_APPLIED", rows = nrow(self$statistical_engine$active_dataset))
        },
        "GROUP" = {
          list(status = "GROUPED", column = ast$params$column)
        },
        "SUMMARISE" = {
          self$statistical_engine$group_summarise(group_col = names(self$statistical_engine$active_dataset)[1], target_col = ast$params$column, op = ast$params$op)
          list(status = "SUMMARISED", data = head(self$statistical_engine$active_dataset, 5))
        },
        "SORT" = {
          self$statistical_engine$sort(ast$params$column, ast$params$descending)
          list(status = "SORTED", column = ast$params$column)
        },
        "WRITE" = {
          self$statistical_engine$write_dataset(ast$params$destination)
          list(status = "WRITTEN", path = ast$params$destination)
        },
        "MOVE" = {
          self$plan(ast)
          self$execute()
        },
        "COPY" = {
          self$plan(ast)
          self$execute()
        },
        "RENAME" = {
          self$plan(ast)
          self$execute()
        },
        "DELETE" = {
          self$plan(ast)
          self$execute()
        },
        "PLAN" = self$plan(),
        "PREVIEW" = self$preview(),
        "EXECUTE" = self$execute(dry_run = isTRUE(ast$params$dry_run)),
        "VERIFY" = self$verify(),
        "RELEASE" = self$release(),
        "SNAPSHOT" = self$snapshot(),
        "RESTORE" = self$restore(ast$params$snapshot_id),
        "TELEMETRY" = self$telemetry(),
        "JOBS" = self$jobs(),
        "HISTORY" = self$history(ast$params$limit),
        "STATUS" = self$status(),
        "WORKFLOW" = {
          results <- list()
          for (node in ast$params$nodes) {
            results[[length(results) + 1]] <- self$dispatch_command(node$type)
          }
          results
        },
        stop(sprintf("Unhandled AST node: '%s'", ast$type))
      )
    }
  )
)
