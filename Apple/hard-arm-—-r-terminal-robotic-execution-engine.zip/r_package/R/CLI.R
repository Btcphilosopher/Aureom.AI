#' CLI: Terminal Interface and Banner Formatter for HARD ARM
#'
#' @description
#' Provides robotic-style terminal UI rendering, progress indicators, box drawing, and interactive REPL.
#'
#' @export
CLI <- R6::R6Class(
  "CLI",
  public = list(
    arm = NULL,
    
    initialize = function(arm_controller = NULL) {
      self$arm <- if (!is.null(arm_controller)) arm_controller else ArmController$new()
    },
    
    print_banner = function() {
      cat("\n")
      cat("╔══════════════════════════════════════════════════════════════════════════╗\n")
      cat("║                                HARD ARM                                  ║\n")
      cat("║                 R TERMINAL ROBOTIC EXECUTION ENGINE                      ║\n")
      cat("║                   Industrial Safety & Verification                       ║\n")
      cat("╚══════════════════════════════════════════════════════════════════════════╝\n\n")
    },
    
    print_target_acquired = function(target) {
      cat("────────────────────────────────────────────────────────────\n")
      cat("TARGET ACQUIRED\n\n")
      cat(sprintf("  Path:        %s\n", target$path))
      cat(sprintf("  Object Type: %s\n", target$type))
      cat(sprintf("  Size:        %s\n", target$format_size(target$size)))
      cat(sprintf("  Lines:       %s\n", format(target$lines, big.mark = ",")))
      cat(sprintf("  SHA256:      %s\n", if (!is.null(target$hash)) target$hash else "STREAMING..."))
      cat("  Status:      ✓ Accessible | ✓ Locked in Gripper\n")
      cat("────────────────────────────────────────────────────────────\n\n")
    },
    
    print_gripper_status = function(gripper) {
      cat("GRIPPER STATUS\n")
      cat(sprintf("  State:    %s\n", gripper$state))
      bar_len <- 20
      filled <- round((gripper$grip_force_pct / 100) * bar_len)
      bar <- paste0(strrep("█", filled), strrep("░", bar_len - filled))
      cat(sprintf("  Force:    [%s] %d%%\n\n", bar, gripper$grip_force_pct))
    },
    
    print_progress = function(current, total, current_action) {
      pct <- if (total > 0) round((current / total) * 100) else 100
      bar_len <- 20
      filled <- round((pct / 100) * bar_len)
      bar <- paste0(strrep("█", filled), strrep("░", bar_len - filled))
      cat(sprintf("\rARM ACTION: [%s] %d/%d (%d%%) | Type: %s", bar, current, total, pct, current_action$type))
      if (current >= total) cat("\n")
    },
    
    repl = function() {
      self$print_banner()
      cat("Type 'grab <target>', 'inspect', 'plan', 'execute', 'telemetry', or 'help'.\n\n")
      
      repeat {
        prompt_str <- sprintf("hardarm [%s]> ", self$arm$state$get_state())
        input <- readline(prompt = prompt_str)
        if (is.null(input) || input == "exit" || input == "quit") {
          cat("Releasing arm and shutting down engine.\n")
          self$arm$release()
          break
        }
        
        tryCatch({
          res <- self$arm$dispatch_command(input)
          if (!is.null(res)) {
            if (is.character(res)) cat(res, "\n")
            else print(res)
          }
        }, error = function(e) {
          cat(sprintf("ERROR: %s\n", e$message))
        })
      }
    }
  )
)

#' hardarm_cli: Entrypoint for Command Line Execution
#' @export
hardarm_cli <- function(args = commandArgs(trailingOnly = TRUE)) {
  arm <- ArmController$new()
  cli <- CLI$new(arm)
  
  if (length(args) == 0) {
    cli$repl()
    return(invisible())
  }
  
  cmd <- paste(args, collapse = " ")
  res <- arm$dispatch_command(cmd)
  if (!is.null(res)) print(res)
}
