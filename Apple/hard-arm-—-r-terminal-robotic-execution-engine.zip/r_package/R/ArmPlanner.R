#' ArmPlanner: Robotic Action Planner
#'
#' @description
#' Converts requested high-level actions and AST into discrete, deterministic robotic action graphs.
#'
#' @export
ArmPlanner <- R6::R6Class(
  "ArmPlanner",
  public = list(
    
    plan_operation = function(current_target, ast_node, optimizer = NULL) {
      graph <- ActionGraph$new()
      
      if (is.null(ast_node)) {
        stop("Cannot plan operation: AST node is NULL.")
      }
      
      switch(ast_node$type,
        "MOVE" = {
          dest <- ast_node$params$destination
          src <- if (!is.null(ast_node$params$source)) ast_node$params$source else current_target$path
          
          # 1. SCAN
          n_scan <- graph$add_node("SCAN", target = src, parameters = list(description = sprintf("Scan source '%s'", src)))
          # 2. VALIDATE DESTINATION
          n_dest <- graph$add_node("VALIDATE", target = dest, parameters = list(description = sprintf("Check destination '%s'", dest)), dependencies = n_scan$action_id)
          # 3. LOCK TARGET
          n_lock <- graph$add_node("LOCK", target = src, parameters = list(description = sprintf("Secure gripper lock on '%s'", src)), dependencies = n_dest$action_id)
          # 4. MOVE
          n_move <- graph$add_node("MOVE", target = src, parameters = list(destination = dest, source = src, size_bytes = current_target$size), dependencies = n_lock$action_id)
          # 5. VERIFY
          n_verify <- graph$add_node("VERIFY", target = dest, parameters = list(expected_size = current_target$size, expected_hash = current_target$hash), dependencies = n_move$action_id)
          # 6. RELEASE
          graph$add_node("RELEASE", target = dest, parameters = list(description = "Release gripper lock"), dependencies = n_verify$action_id)
        },
        
        "COPY" = {
          dest <- ast_node$params$destination
          src <- if (!is.null(ast_node$params$source)) ast_node$params$source else current_target$path
          
          n_scan <- graph$add_node("SCAN", target = src)
          n_lock <- graph$add_node("LOCK", target = src, dependencies = n_scan$action_id)
          n_copy <- graph$add_node("COPY", target = src, parameters = list(destination = dest, source = src, size_bytes = current_target$size), dependencies = n_lock$action_id)
          n_verify <- graph$add_node("VERIFY", target = dest, parameters = list(expected_size = current_target$size, expected_hash = current_target$hash), dependencies = n_copy$action_id)
          graph$add_node("RELEASE", target = dest, dependencies = n_verify$action_id)
        },
        
        "DELETE" = {
          src <- current_target$path
          n_scan <- graph$add_node("SCAN", target = src)
          n_snap <- graph$add_node("SNAPSHOT", target = src, parameters = list(reason = "Pre-deletion snapshot"), dependencies = n_scan$action_id)
          n_lock <- graph$add_node("LOCK", target = src, dependencies = n_snap$action_id)
          n_del <- graph$add_node("DELETE", target = src, parameters = list(force = ast_node$params$force), dependencies = n_lock$action_id)
          n_verify <- graph$add_node("VERIFY", target = src, parameters = list(check_deleted = TRUE), dependencies = n_del$action_id)
          graph$add_node("RELEASE", dependencies = n_verify$action_id)
        },
        
        "FILTER" = ,
        "GROUP" = ,
        "SUMMARISE" = ,
        "SORT" = {
          # Data transformations as robotic arm movements
          src <- current_target$path
          n_lock <- graph$add_node("LOCK", target = src)
          n_trans <- graph$add_node("TRANSFORM", target = src, parameters = ast_node$params, dependencies = n_lock$action_id)
          n_verify <- graph$add_node("VERIFY", target = src, parameters = list(type = "DATA_INTEGRITY"), dependencies = n_trans$action_id)
          graph$add_node("RELEASE", target = src, dependencies = n_verify$action_id)
        },
        
        "WRITE" = {
          dest <- ast_node$params$destination
          n_lock <- graph$add_node("LOCK", target = current_target$path)
          n_write <- graph$add_node("WRITE", target = current_target$path, parameters = list(destination = dest), dependencies = n_lock$action_id)
          n_verify <- graph$add_node("VERIFY", target = dest, parameters = list(check_exists = TRUE), dependencies = n_write$action_id)
          graph$add_node("RELEASE", target = dest, dependencies = n_verify$action_id)
        },
        
        "ANALYSE" = {
          src <- current_target$path
          n_lock <- graph$add_node("LOCK", target = src)
          n_ana <- graph$add_node("ANALYSE", target = src, parameters = ast_node$params, dependencies = n_lock$action_id)
          graph$add_node("RELEASE", target = src, dependencies = n_ana$action_id)
        },
        
        # Generic single-action graph
        {
          n_act <- graph$add_node(ast_node$type, target = if (!is.null(current_target)) current_target$path else NULL, parameters = ast_node$params)
        }
      )
      
      if (!is.null(optimizer)) {
        graph <- optimizer$optimize(graph)
      }
      
      graph
    },
    
    plan_batch = function(targets, operation, destination = NULL) {
      graph <- ActionGraph$new()
      n_scan <- graph$add_node("SCAN", parameters = list(target_count = length(targets)))
      
      last_id <- n_scan$action_id
      for (i in seq_along(targets)) {
        tgt <- targets[[i]]
        n_lock <- graph$add_node("LOCK", target = tgt$path, dependencies = last_id)
        dest_path <- if (!is.null(destination)) file.path(destination, basename(tgt$path)) else NULL
        
        n_act <- graph$add_node(operation, target = tgt$path, parameters = list(destination = dest_path, size_bytes = tgt$size), dependencies = n_lock$action_id)
        n_ver <- graph$add_node("VERIFY", target = dest_path, parameters = list(expected_size = tgt$size, expected_hash = tgt$hash), dependencies = n_act$action_id)
        last_id <- n_ver$action_id
      }
      
      graph$add_node("RELEASE", dependencies = last_id)
      graph
    }
  )
)
