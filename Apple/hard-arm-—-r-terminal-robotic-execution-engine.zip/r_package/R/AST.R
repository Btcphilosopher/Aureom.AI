#' AST: Abstract Syntax Tree Nodes for HARD ARM
#'
#' @description
#' Defines strongly typed AST nodes for deterministic command evaluation.
#'
#' @export
AST <- list(
  Node = R6::R6Class("ASTNode",
    public = list(
      type = "BASE_NODE",
      params = list(),
      initialize = function(type, params = list()) {
        self$type <- type
        self$params <- params
      },
      as_list = function() {
        list(type = self$type, params = self$params)
      }
    )
  ),
  
  GrabNode = function(target, flags = list()) {
    AST$Node$new("GRAB", list(target = target, flags = flags))
  },
  
  GrabOutputNode = function(executable, args = character()) {
    AST$Node$new("GRAB_OUTPUT", list(executable = executable, args = args))
  },
  
  InspectNode = function(sub_type = "ALL") {
    AST$Node$new("INSPECT", list(sub_type = sub_type))
  },
  
  AnalyseNode = function(target_col = NULL) {
    AST$Node$new("ANALYSE", list(column = target_col))
  },
  
  FilterNode = function(column, op, value) {
    AST$Node$new("FILTER", list(column = column, op = op, value = value))
  },
  
  GroupNode = function(column) {
    AST$Node$new("GROUP", list(column = column))
  },
  
  SummariseNode = function(column, op = "sum") {
    AST$Node$new("SUMMARISE", list(column = column, op = op))
  },
  
  SortNode = function(column, descending = FALSE) {
    AST$Node$new("SORT", list(column = column, descending = descending))
  },
  
  MoveNode = function(destination, source = NULL) {
    AST$Node$new("MOVE", list(destination = destination, source = source))
  },
  
  CopyNode = function(destination, source = NULL) {
    AST$Node$new("COPY", list(destination = destination, source = source))
  },
  
  RenameNode = function(new_name) {
    AST$Node$new("RENAME", list(new_name = new_name))
  },
  
  DeleteNode = function(force = FALSE) {
    AST$Node$new("DELETE", list(force = force))
  },
  
  WriteNode = function(destination) {
    AST$Node$new("WRITE", list(destination = destination))
  },
  
  FindNode = function(pattern) {
    AST$Node$new("FIND", list(pattern = pattern))
  },
  
  VerifyNode = function() {
    AST$Node$new("VERIFY", list())
  },
  
  ReleaseNode = function() {
    AST$Node$new("RELEASE", list())
  },
  
  SnapshotNode = function() {
    AST$Node$new("SNAPSHOT", list())
  },
  
  RestoreNode = function(snapshot_id) {
    AST$Node$new("RESTORE", list(snapshot_id = snapshot_id))
  },
  
  PlanNode = function() {
    AST$Node$new("PLAN", list())
  },
  
  PreviewNode = function() {
    AST$Node$new("PREVIEW", list())
  },
  
  ExecuteNode = function(dry_run = FALSE) {
    AST$Node$new("EXECUTE", list(dry_run = dry_run))
  },
  
  WatchNode = function(directory) {
    AST$Node$new("WATCH", list(directory = directory))
  },
  
  TelemetryNode = function() {
    AST$Node$new("TELEMETRY", list())
  },
  
  JobsNode = function() {
    AST$Node$new("JOBS", list())
  },
  
  HistoryNode = function(limit = 20) {
    AST$Node$new("HISTORY", list(limit = limit))
  },
  
  StatusNode = function() {
    AST$Node$new("STATUS", list())
  },
  
  WorkflowNode = function(nodes = list()) {
    AST$Node$new("WORKFLOW", list(nodes = nodes))
  }
)
