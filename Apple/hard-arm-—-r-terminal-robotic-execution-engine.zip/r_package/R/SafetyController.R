#' SafetyController: Robotic Safety Guard and Policy Enforcer
#'
#' @description
#' Enforces strict safety policies, checks protected paths, and requires confirmation for dangerous actions.
#'
#' @export
SafetyController <- R6::R6Class(
  "SafetyController",
  public = list(
    protected_paths = c(
      "/", "/etc", "/usr", "/System", "/Library", "/bin", "/sbin", "/boot",
      "/dev", "/proc", "/sys", "/var/root", "/private/etc"
    ),
    max_batch_targets = 50000,
    max_file_size_bytes = 100 * 1024 * 1024 * 1024, # 100 GB
    require_confirmation_for_destructive = TRUE,
    
    initialize = function(protected_paths = NULL, max_batch_targets = 50000) {
      if (!is.null(protected_paths)) self$protected_paths <- protected_paths
      self$max_batch_targets <- max_batch_targets
    },
    
    validate_path = function(path) {
      if (is.null(path) || !is.character(path) || nchar(trimws(path)) == 0) {
        stop("Safety Violation: Empty path provided to safety controller.")
      }
      
      clean_path <- normalizePath(path, winslash = "/", mustWork = FALSE)
      
      for (prot in self$protected_paths) {
        if (clean_path == prot || grepl(paste0("^", prot, "/?$"), clean_path)) {
          stop(sprintf("CRITICAL SAFETY VIOLATION: Path '%s' is in protected system directory '%s'. Operation BLOCKED.", path, prot))
        }
      }
      
      invisible(TRUE)
    },
    
    validate_action_graph = function(graph, dry_run = FALSE) {
      cost <- graph$estimate_cost()
      
      if (cost$target_count > self$max_batch_targets) {
        stop(sprintf("Safety Violation: Batch size (%d targets) exceeds maximum allowed limit (%d).",
                     cost$target_count, self$max_batch_targets))
      }
      
      for (node in graph$get_all_nodes()) {
        if (!is.null(node$target) && is.character(node$target)) {
          self$validate_path(node$target)
        }
        if (!is.null(node$parameters$destination)) {
          self$validate_path(node$parameters$destination)
        }
      }
      
      if (cost$dangerous_ops > 0 && !dry_run && self$require_confirmation_for_destructive) {
        # Mark as requiring explicit token/confirmation
        return(list(safe = TRUE, requires_confirmation = TRUE, summary = cost))
      }
      
      list(safe = TRUE, requires_confirmation = FALSE, summary = cost)
    }
  )
)
