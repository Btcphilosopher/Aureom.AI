#' ReportEngine: Job and Execution Audit Report Generator
#'
#' @description
#' Formats robotic job histories into TXT, CSV, JSON, HTML, and Markdown reports.
#'
#' @export
ReportEngine <- R6::R6Class(
  "ReportEngine",
  public = list(
    
    generate_txt = function(job_record, actions_list) {
      lines <- c(
        "╔════════════════════════════════════════════════════════════╗",
        "║                HARD ARM JOB EXECUTION REPORT               ║",
        "╚════════════════════════════════════════════════════════════╝",
        sprintf("Job ID:         %s", job_record$job_id),
        sprintf("Target:         %s", job_record$target_path),
        sprintf("Target Type:    %s", job_record$target_type),
        sprintf("Status:         %s", job_record$status),
        sprintf("Total Actions:  %d", job_record$total_actions),
        sprintf("Started At:     %s", job_record$started_at),
        sprintf("Completed At:   %s", job_record$completed_at),
        sprintf("Duration:       %.3f sec", job_record$duration_sec),
        sprintf("Verification:   %s", if (job_record$status == "COMPLETED") "PASSED (100% Verified)" else "FAILED"),
        "────────────────────────────────────────────────────────────",
        "ACTIONS BREAKDOWN:",
        ""
      )
      
      for (i in seq_len(nrow(actions_list))) {
        act <- actions_list[i, ]
        lines <- c(lines, sprintf(" [%s] %-10s -> %-20s (Status: %s, %.1f ms)",
                                  act$action_id, act$operation, act$target, act$status, act$duration_ms))
      }
      
      lines <- c(lines, "────────────────────────────────────────────────────────────", "ROBOTIC ENGINE STATUS: ALL TARGETS SECURE & RELEASED")
      paste(lines, collapse = "\n")
    },
    
    generate_json = function(job_record, actions_list) {
      jsonlite::toJSON(list(
        job = as.list(job_record),
        actions = actions_list
      ), auto_unbox = TRUE, pretty = TRUE)
    },
    
    generate_html = function(job_record, actions_list) {
      sprintf("<!DOCTYPE html><html><head><title>Hard Arm Report %s</title><style>body{font-family:monospace;background:#09090b;color:#f4f4f5;padding:24px;}.card{border:1px solid #27272a;padding:16px;border-radius:8px;background:#18181b;}</style></head><body><div class='card'><h1>HARD ARM REPORT: %s</h1><p>Status: %s | Duration: %.2fs</p></div></body></html>",
              job_record$job_id, job_record$job_id, job_record$status, job_record$duration_sec)
    }
  )
)
