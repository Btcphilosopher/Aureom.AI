#' ArmState: Virtual Robotic Arm State Machine
#'
#' @description
#' Defines and controls valid state transitions for the HARD ARM execution engine.
#' All robotic state changes are validated and logged with timestamps.
#'
#' @export
ArmState <- R6::R6Class(
  "ArmState",
  public = list(
    VALID_STATES = c(
      "IDLE", "SCANNING", "TARGETING", "GRABBING", "HOLDING",
      "ANALYSING", "PLANNING", "MOVING", "EXECUTING", "VERIFYING",
      "RELEASING", "COMPLETE", "ERROR"
    ),
    
    current_state = "IDLE",
    history = list(),
    
    initialize = function(initial_state = "IDLE") {
      self$transition(initial_state, reason = "Arm initialized")
    },
    
    get_state = function() {
      self$current_state
    },
    
    is_state = function(state) {
      self$current_state == state
    },
    
    transition = function(new_state, reason = "") {
      if (!new_state %in% self$VALID_STATES) {
        stop(sprintf("Invalid Arm state requested: '%s'. Valid states: %s",
                     new_state, paste(self$VALID_STATES, collapse = ", ")))
      }
      
      prev_state <- self$current_state
      self$current_state <- new_state
      
      record <- list(
        timestamp = Sys.time(),
        from = prev_state,
        to = new_state,
        reason = reason
      )
      self$history[[length(self$history) + 1]] <- record
      
      invisible(self$current_state)
    },
    
    get_history = function() {
      self$history
    },
    
    reset = function() {
      self$transition("IDLE", reason = "Arm state reset to home position")
    }
  )
)
