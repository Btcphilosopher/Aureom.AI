#' SnapshotEngine: Safety Snapshots and Rollback Manager
#'
#' @description
#' Captures pre-mutation state of targets allowing auditable rollback and restoration.
#'
#' @export
SnapshotEngine <- R6::R6Class(
  "SnapshotEngine",
  public = list(
    storage_dir = NULL,
    snapshots = list(),
    
    initialize = function(storage_dir = file.path(tempdir(), "hardarm_snapshots")) {
      self$storage_dir <- storage_dir
      if (!dir.exists(self$storage_dir)) {
        dir.create(self$storage_dir, recursive = TRUE, showWarnings = FALSE)
      }
    },
    
    create_snapshot = function(target, reason = "Manual snapshot") {
      if (is.null(target) || is.null(target$path) || !file.exists(target$path)) {
        stop("Cannot create snapshot: target does not exist on disk.")
      }
      
      snap_id <- sprintf("SNAP-%s-%04d", format(Sys.time(), "%Y%m%d-%H%M%S"), sample(1000:9999, 1))
      backup_path <- file.path(self$storage_dir, paste0(snap_id, "_", basename(target$path)))
      
      if (dir.exists(target$path)) {
        # Copy directory structure
        dir.create(backup_path, recursive = TRUE, showWarnings = FALSE)
        file.copy(list.files(target$path, full.names = TRUE), backup_path, recursive = TRUE)
      } else {
        file.copy(target$path, backup_path, overwrite = TRUE)
      }
      
      record <- list(
        snapshot_id = snap_id,
        original_path = target$path,
        backup_path = backup_path,
        type = target$type,
        size_bytes = target$size,
        hash = target$hash,
        reason = reason,
        created_at = Sys.time()
      )
      
      self$snapshots[[snap_id]] <- record
      record
    },
    
    restore_snapshot = function(snapshot_id) {
      if (is.null(self$snapshots[[snapshot_id]])) {
        stop(sprintf("Snapshot ID '%s' not found.", snapshot_id))
      }
      
      record <- self$snapshots[[snapshot_id]]
      if (!file.exists(record$backup_path)) {
        stop(sprintf("Snapshot backup file missing at '%s'.", record$backup_path))
      }
      
      if (dir.exists(record$backup_path)) {
        dir.create(record$original_path, recursive = TRUE, showWarnings = FALSE)
        file.copy(list.files(record$backup_path, full.names = TRUE), record$original_path, recursive = TRUE, overwrite = TRUE)
      } else {
        file.copy(record$backup_path, record$original_path, overwrite = TRUE)
      }
      
      record$restored_at <- Sys.time()
      record
    },
    
    list_snapshots = function() {
      self$snapshots
    }
  )
)
