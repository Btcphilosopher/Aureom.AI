test_that("StatisticalEngine calculates summary stats, outliers, and data pipelines", {
  tmp_csv <- tempfile(fileext = ".csv")
  df <- data.frame(
    id = 1:100,
    region = rep(c("North", "South", "East", "West"), 25),
    revenue = c(rnorm(98, mean = 5000, sd = 500), 25000, 100), # With 2 outliers
    status = rep(TRUE, 100)
  )
  write.csv(df, tmp_csv, row.names = FALSE)
  on.exit(unlink(tmp_csv))
  
  stat_arm <- StatisticalEngine$new()
  profile <- stat_arm$load_dataset(tmp_csv)
  
  expect_equal(profile$rows, 100)
  expect_equal(profile$columns, 4)
  expect_equal(profile$numeric_cols, 2)
  
  ana <- stat_arm$analyse_column("revenue")
  expect_equal(ana$type, "NUMERIC")
  expect_true(ana$mean > 4500)
  expect_true(ana$outlier_count >= 1)
  
  # Test pipeline: filter -> group & summarise -> sort -> write
  stat_arm$filter("revenue", ">", 4000)
  expect_true(nrow(stat_arm$active_dataset) > 50)
  
  stat_arm$group_summarise(group_col = "region", target_col = "revenue", op = "sum")
  expect_equal(nrow(stat_arm$active_dataset), 4)
  
  out_csv <- tempfile(fileext = ".csv")
  on.exit(unlink(out_csv), add = TRUE)
  stat_arm$write_dataset(out_csv)
  expect_true(file.exists(out_csv))
})
