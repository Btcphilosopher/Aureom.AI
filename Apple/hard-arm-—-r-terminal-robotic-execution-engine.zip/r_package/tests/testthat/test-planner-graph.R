test_that("ArmPlanner builds action graph with topological sorting", {
  planner <- ArmPlanner$new()
  target <- ArmTarget$new(path = "report.pdf", type = "DOCUMENT")
  target$size <- 2048
  target$hash <- "fakehash1234567890abcdef"
  
  ast_move <- AST$MoveNode(destination = "Archive/report.pdf")
  graph <- planner$plan_operation(target, ast_move)
  
  nodes <- graph$get_all_nodes()
  expect_true(length(nodes) >= 5)
  
  order <- graph$get_execution_order()
  expect_equal(length(order), length(nodes))
  
  cost <- graph$estimate_cost()
  expect_equal(cost$target_count, 1)
  expect_equal(cost$estimated_bytes, 2048)
})

test_that("Cycle detection halts malformed action graphs", {
  graph <- ActionGraph$new()
  n1 <- graph$add_node("SCAN")
  n2 <- graph$add_node("MOVE", dependencies = n1$action_id)
  # Inject manual cycle
  n1$dependencies <- n2$action_id
  
  expect_error(graph$get_execution_order(), "Cycle detected")
})
