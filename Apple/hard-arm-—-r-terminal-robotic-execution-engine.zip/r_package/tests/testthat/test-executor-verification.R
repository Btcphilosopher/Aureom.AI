test_that("VerificationEngine confirms SHA256 and size matching", {
  tmp_src <- tempfile(fileext = ".txt")
  writeLines("Deterministic robotic test payload", tmp_src)
  on.exit(unlink(tmp_src))
  
  ver <- VerificationEngine$new()
  hash <- digest::digest(tmp_src, algo = "sha256", file = TRUE)
  sz <- file.info(tmp_src)$size
  
  res <- ver$verify_file_move(tmp_src, tmp_src, expected_size = sz, expected_hash = hash)
  expect_true(res$verified)
  
  expect_error(ver$verify_file_move(tmp_src, tmp_src, expected_size = sz, expected_hash = "wronghash"))
  expect_error(ver$verify_file_move(tmp_src, "nonexistent.txt"))
})

test_that("ArmExecutor executes action graph and logs to SQLite journal", {
  tmp_dir <- tempdir()
  src_file <- file.path(tmp_dir, "hardarm_test_src.txt")
  dest_file <- file.path(tmp_dir, "hardarm_test_dest.txt")
  writeLines("Robotic execution payload", src_file)
  on.exit({
    if (file.exists(src_file)) unlink(src_file)
    if (file.exists(dest_file)) unlink(dest_file)
  })
  
  arm <- ArmController$new()
  arm$grab(src_file)
  ast_move <- AST$MoveNode(destination = dest_file)
  arm$plan(ast_move)
  
  exec_res <- arm$execute()
  expect_equal(exec_res$status, "COMPLETE")
  expect_true(file.exists(dest_file))
  expect_false(file.exists(src_file))
  
  hist <- arm$history(5)
  expect_true(nrow(hist) >= 1)
})
