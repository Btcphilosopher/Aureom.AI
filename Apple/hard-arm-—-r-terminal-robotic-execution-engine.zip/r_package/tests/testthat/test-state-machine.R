test_that("ArmState transitions are valid and logged", {
  state <- ArmState$new()
  expect_equal(state$get_state(), "IDLE")
  
  state$transition("TARGETING", reason = "Finding file")
  expect_equal(state$get_state(), "TARGETING")
  
  state$transition("GRABBING", reason = "Engaging gripper")
  expect_equal(state$get_state(), "GRABBING")
  
  state$transition("HOLDING")
  expect_equal(state$get_state(), "HOLDING")
  
  expect_error(state$transition("INVALID_STATE"))
  
  hist <- state$get_history()
  expect_true(length(hist) >= 4)
})

test_that("Gripper transitions approach, lock and release correctly", {
  gripper <- Gripper$new()
  expect_equal(gripper$state, "OPEN")
  expect_equal(gripper$grip_force_pct, 0)
  
  target <- ArmTarget$new(path = "test.txt", type = "FILE")
  gripper$lock(target)
  
  expect_equal(gripper$state, "LOCKED")
  expect_equal(gripper$grip_force_pct, 100)
  expect_true(gripper$is_locked())
  
  gripper$release()
  expect_equal(gripper$state, "RELEASED")
  expect_equal(gripper$grip_force_pct, 0)
  expect_false(gripper$is_locked())
})
