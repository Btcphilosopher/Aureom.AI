test_that("SafetyController blocks protected system root and critical directories", {
  safety <- SafetyController$new()
  
  expect_error(safety$validate_path("/etc"), "CRITICAL SAFETY VIOLATION")
  expect_error(safety$validate_path("/etc/passwd"), "CRITICAL SAFETY VIOLATION")
  expect_error(safety$validate_path("/System"), "CRITICAL SAFETY VIOLATION")
  expect_error(safety$validate_path("/"), "CRITICAL SAFETY VIOLATION")
  
  # Safe user path should pass
  expect_true(safety$validate_path("/tmp/safe_folder/file.txt"))
})

test_that("SnapshotEngine creates backups and restores safely", {
  tmp_file <- tempfile(fileext = ".txt")
  writeLines("Original state before mutation", tmp_file)
  on.exit(unlink(tmp_file))
  
  engine <- SnapshotEngine$new()
  target <- ArmTarget$new(path = tmp_file, type = "TEXT")
  target$size <- file.info(tmp_file)$size
  target$hash <- digest::digest(tmp_file, algo = "sha256", file = TRUE)
  
  snap <- engine$create_snapshot(target, reason = "Test snapshot")
  expect_true(nchar(snap$snapshot_id) > 0)
  expect_true(file.exists(snap$backup_path))
  
  # Mutate original
  writeLines("Corrupted state", tmp_file)
  expect_equal(readLines(tmp_file), "Corrupted state")
  
  # Restore
  engine$restore_snapshot(snap$snapshot_id)
  expect_equal(readLines(tmp_file), "Original state before mutation")
})
