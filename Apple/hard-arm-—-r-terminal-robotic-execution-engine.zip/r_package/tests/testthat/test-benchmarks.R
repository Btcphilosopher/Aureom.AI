test_that("Performance benchmark scales predictably across file volumes", {
  tmp_dir <- file.path(tempdir(), "hardarm_bench")
  dir.create(tmp_dir, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(tmp_dir, recursive = TRUE))
  
  # Create 50 benchmark micro-files
  for (i in 1:50) {
    writeLines(sprintf("Record #%d with sha256 entropy", i), file.path(tmp_dir, sprintf("file_%03d.txt", i)))
  }
  
  arm <- ArmController$new()
  t0 <- Sys.time()
  targets <- arm$grab(file.path(tmp_dir, "*.txt"))
  elapsed <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  
  expect_equal(length(targets), 50)
  expect_true(elapsed < 2.0) # Sub-2-second batch acquisition
})
