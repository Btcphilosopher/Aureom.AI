test_that("Parser generates deterministic AST nodes without eval", {
  parser <- Parser$new()
  
  node1 <- parser$parse("grab project/")
  expect_equal(node1$type, "GRAB")
  expect_equal(node1$params$target, "project/")
  
  node2 <- parser$parse("filter revenue > 1000")
  expect_equal(node2$type, "FILTER")
  expect_equal(node2$params$column, "revenue")
  expect_equal(node2$params$op, ">")
  expect_equal(node2$params$value, "1000")
  
  node3 <- parser$parse("move to Archive/")
  expect_equal(node3$type, "MOVE")
  expect_equal(node3$params$destination, "Archive/")
  
  node4 <- parser$parse("grab-output -- ls -lah")
  expect_equal(node4$type, "GRAB_OUTPUT")
  expect_equal(node4$params$executable, "ls")
  expect_equal(node4$params$args, "-lah")
  
  expect_error(parser$parse("unknown_command_xyz"))
})
