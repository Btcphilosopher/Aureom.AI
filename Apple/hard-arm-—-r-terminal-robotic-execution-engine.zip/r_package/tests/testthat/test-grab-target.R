test_that("GrabEngine acquires files with streaming sha256 and lines count", {
  tmp_file <- tempfile(fileext = ".txt")
  writeLines(c("Line 1", "Line 2", "Line 3", "Line 4"), tmp_file)
  on.exit(unlink(tmp_file))
  
  engine <- GrabEngine$new()
  target <- engine$grab_target(tmp_file)
  
  expect_equal(target$type, "TEXT")
  expect_equal(target$lines, 4)
  expect_true(nchar(target$hash) == 64) # SHA256 hex string
  expect_true(target$size > 0)
})

test_that("GrabEngine captures CommandTarget via system2", {
  engine <- GrabEngine$new()
  cmd_target <- engine$grab_command("echo", c("HARD", "ARM"))
  
  expect_equal(cmd_target$type, "COMMAND_OUTPUT")
  expect_equal(cmd_target$exit_code, 0)
  expect_true(grepl("HARD ARM", paste(cmd_target$stdout, collapse = " ")))
})
