library(testthat)
library(hardarm)

test_check("hardarm")
