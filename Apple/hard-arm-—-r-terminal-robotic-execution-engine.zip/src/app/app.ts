import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { HardarmEngineService } from './services/hardarm-engine.service';
import { RPackageExportService } from './services/r-package-export.service';
import { GripperHud } from './components/gripper-hud/gripper-hud';
import { ActionGraphComponent } from './components/action-graph/action-graph';
import { StatisticalStudioComponent } from './components/statistical-studio/statistical-studio';
import { JournalViewerComponent } from './components/journal-viewer/journal-viewer';
import { VfsExplorerComponent } from './components/vfs-explorer/vfs-explorer';
import { RCodeViewerComponent } from './components/r-code-viewer/r-code-viewer';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatIconModule,
    GripperHud,
    ActionGraphComponent,
    StatisticalStudioComponent,
    JournalViewerComponent,
    VfsExplorerComponent,
    RCodeViewerComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  public engine = inject(HardarmEngineService);
  public rExport = inject(RPackageExportService);

  public activeTab = signal<'graph' | 'stats' | 'target' | 'journal' | 'vfs' | 'rcode'>('graph');
  public commandInput = new FormControl('', { nonNullable: true });
  private historyIndex = -1;

  @ViewChild('terminalBody') terminalBody!: ElementRef<HTMLDivElement>;

  constructor() {
    effect(() => {
      // Auto-scroll terminal on new log lines
      this.engine.terminalLogs();
      setTimeout(() => {
        if (this.terminalBody?.nativeElement) {
          this.terminalBody.nativeElement.scrollTop = this.terminalBody.nativeElement.scrollHeight;
        }
      }, 50);
    });
  }

  public onSubmitCommand(): void {
    const val = this.commandInput.value.trim();
    if (!val) return;
    this.commandInput.setValue('');
    this.historyIndex = -1;
    this.engine.executeCommand(val);
  }

  public onKeyDown(event: KeyboardEvent): void {
    const history = this.engine.commandHistory;
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      if (history.length === 0) return;
      if (this.historyIndex === -1) {
        this.historyIndex = history.length - 1;
      } else if (this.historyIndex > 0) {
        this.historyIndex--;
      }
      this.commandInput.setValue(history[this.historyIndex]);
    } else if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (this.historyIndex === -1) return;
      if (this.historyIndex < history.length - 1) {
        this.historyIndex++;
        this.commandInput.setValue(history[this.historyIndex]);
      } else {
        this.historyIndex = -1;
        this.commandInput.setValue('');
      }
    }
  }

  public runPresetWorkflow(type: 'sales' | 'batch' | 'logs'): void {
    if (type === 'sales') {
      const script = `grab sales.csv\ninspect\nanalyse revenue\nfilter revenue > 1000\nsummarise revenue\nsort revenue desc\nplan\nexecute\nverify\nrelease`;
      this.engine.runWorkflowScript(script);
      this.activeTab.set('stats');
    } else if (type === 'batch') {
      const script = `grab incoming/*.pdf\ninspect\nplan\npreview\nexecute\nverify\nrelease`;
      this.engine.runWorkflowScript(script);
      this.activeTab.set('graph');
    } else if (type === 'logs') {
      const script = `grab server.log\ninspect\nplan\nexecute --dry-run\nverify\nrelease`;
      this.engine.runWorkflowScript(script);
      this.activeTab.set('target');
    }
  }

  public downloadRZip(): void {
    this.rExport.exportZip();
  }
}
