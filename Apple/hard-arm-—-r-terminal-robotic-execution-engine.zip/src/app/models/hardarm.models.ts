export type ArmStateType =
  | 'IDLE'
  | 'SCANNING'
  | 'TARGETING'
  | 'GRABBING'
  | 'HOLDING'
  | 'ANALYSING'
  | 'PLANNING'
  | 'MOVING'
  | 'EXECUTING'
  | 'VERIFYING'
  | 'RELEASING'
  | 'COMPLETE'
  | 'ERROR';

export type GripperStateType =
  | 'OPEN'
  | 'APPROACHING'
  | 'GRIPPING'
  | 'LOCKED'
  | 'RELEASING'
  | 'RELEASED';

export type TargetType =
  | 'FILE'
  | 'DIRECTORY'
  | 'DATASET'
  | 'TEXT'
  | 'LOG'
  | 'PROCESS'
  | 'JOB'
  | 'COMMAND_OUTPUT'
  | 'SOURCE_CODE'
  | 'DOCUMENT';

export interface ArmTarget {
  target_id: string;
  path: string;
  type: TargetType;
  size: number;
  lines: number;
  permissions: string;
  hash: string;
  metadata: Record<string, unknown>;
  status: string;
  acquired_at: string;
  contentPreview?: string;
  commandData?: {
    command: string;
    args: string[];
    exit_code: number;
    stdout: string[];
    stderr: string[];
    duration_sec: number;
  };
}

export type ActionNodeType =
  | 'SCAN'
  | 'SELECT'
  | 'GRAB'
  | 'MOVE'
  | 'COPY'
  | 'RENAME'
  | 'EDIT'
  | 'TRANSFORM'
  | 'DELETE'
  | 'EXECUTE'
  | 'ANALYSE'
  | 'WRITE'
  | 'VERIFY'
  | 'RELEASE'
  | 'SNAPSHOT'
  | 'VALIDATE'
  | 'LOCK';

export type ActionStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'SKIPPED';

export interface ActionNode {
  action_id: string;
  type: ActionNodeType;
  target?: string;
  parameters: Record<string, unknown>;
  dependencies: string[];
  status: ActionStatus;
  result?: unknown;
  duration_ms: number;
  created_at: string;
}

export interface ActionGraph {
  nodes: Record<string, ActionNode>;
  executionOrder: string[];
  totalActions: number;
  targetCount: number;
  estimatedBytes: number;
  dangerousOps: number;
}

export interface DatasetProfile {
  rows: number;
  columns: number;
  numericCount: number;
  textCount: number;
  logicalCount: number;
  missingPct: number;
  duplicateRows: number;
  colNames: string[];
  colTypes: Record<string, string>;
  previewRows: Record<string, string | number | boolean>[];
}

export interface ColumnAnalysis {
  column: string;
  type: 'NUMERIC' | 'CATEGORICAL';
  count: number;
  missing: number;
  mean?: number;
  median?: number;
  sd?: number;
  min?: number;
  max?: number;
  q25?: number;
  q75?: number;
  iqr?: number;
  outlierCount?: number;
  outliers?: number[];
  outlierBounds?: { lower: number; upper: number };
  distinct?: number;
  topFrequencies?: Record<string, number>;
}

export interface Snapshot {
  snapshot_id: string;
  original_path: string;
  backup_data: string;
  type: string;
  size_bytes: number;
  hash: string;
  reason: string;
  created_at: string;
  restored_at?: string;
}

export interface JobRecord {
  job_id: string;
  target_path: string;
  target_type: string;
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  total_actions: number;
  started_at: string;
  completed_at?: string;
  duration_sec: number;
  bytes_processed: number;
}

export interface ActionLog {
  id: number;
  job_id: string;
  action_id: string;
  operation: string;
  target: string;
  status: 'COMPLETED' | 'FAILED' | 'RUNNING';
  original_hash: string;
  result_hash: string;
  duration_ms: number;
  error_msg?: string;
  timestamp: string;
}

export interface TelemetryMetrics {
  jobs: number;
  operations: number;
  success_pct: number;
  error_pct: number;
  total_bytes: number;
  mean_throughput_mb_s: number;
  cpu_utilization_pct: number;
  memory_usage_mb: number;
  worker_count: number;
  timestamp: string;
}

export interface VirtualFile {
  path: string;
  name: string;
  isDir: boolean;
  size: number;
  lines: number;
  content: string;
  mimeType: string;
  hash: string;
  modifiedAt: string;
}

export interface TerminalOutputLine {
  id: string;
  type: 'command' | 'output' | 'banner' | 'success' | 'error' | 'warning' | 'box' | 'progress';
  text: string;
  timestamp: string;
}
