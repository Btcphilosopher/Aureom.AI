import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HardarmEngineService } from '../../services/hardarm-engine.service';

@Component({
  selector: 'app-action-graph',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-zinc-900/90 border border-zinc-800 rounded-xl p-5 shadow-lg backdrop-blur-md flex flex-col gap-4">
      <!-- Header & Stats -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-indigo-400 text-lg">account_tree</mat-icon>
            <h3 class="text-sm font-mono font-semibold tracking-wider text-zinc-200 uppercase">Robotic Action Graph (DAG)</h3>
          </div>
          <p class="text-xs text-zinc-400 mt-0.5">Topologically sorted discrete action pipeline with cycle prevention</p>
        </div>

        <!-- Action Buttons -->
        <div class="flex items-center gap-2">
          <button (click)="engine.executeCommand('plan')"
                  [disabled]="!engine.currentTarget() || engine.isExecuting()"
                  class="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-mono text-zinc-200 border border-zinc-700/60 transition-colors">
            <mat-icon class="text-xs text-indigo-400">schema</mat-icon> Re-Plan
          </button>
          <button (click)="engine.executeCommand('execute --dry-run')"
                  [disabled]="!engine.currentPlan() || engine.isExecuting()"
                  class="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-mono text-zinc-200 border border-zinc-700/60 transition-colors">
            <mat-icon class="text-xs text-cyan-400">visibility</mat-icon> Dry Run
          </button>
          <button (click)="engine.executeCommand('execute')"
                  [disabled]="!engine.currentPlan() || engine.isExecuting()"
                  class="flex items-center gap-1 px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-mono font-bold text-zinc-950 shadow-md transition-colors">
            <mat-icon class="text-xs">play_arrow</mat-icon> Execute Plan
          </button>
        </div>
      </div>

      <!-- Execution Progress Bar if running -->
      @if (engine.isExecuting()) {
        <div class="bg-zinc-950 p-3 rounded-lg border border-amber-500/40 flex flex-col gap-2">
          <div class="flex justify-between items-center text-xs font-mono">
            <span class="text-amber-400 font-semibold flex items-center gap-1.5">
              <mat-icon class="text-xs animate-spin">sync</mat-icon>
              Executing: {{ engine.executionProgress().currentAction }}
            </span>
            <span class="text-zinc-400 font-mono">{{ engine.executionProgress().current }} / {{ engine.executionProgress().total }} ({{ engine.executionProgress().pct }}%)</span>
          </div>
          <div class="w-full bg-zinc-900 rounded-full h-2 overflow-hidden">
            <div class="bg-amber-400 h-full rounded-full transition-all duration-200" [style.width.%]="engine.executionProgress().pct"></div>
          </div>
        </div>
      }

      <!-- Plan Graph Display -->
      @if (engine.currentPlan(); as plan) {
        <!-- DAG Nodes Flow -->
        <div class="space-y-3 py-2">
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            @for (actionId of plan.executionOrder; track actionId; let idx = $index) {
              @let node = plan.nodes[actionId];
              <div class="p-3.5 rounded-xl border transition-all duration-200 flex flex-col justify-between gap-3 relative overflow-hidden"
                   [class.bg-zinc-950]="node.status === 'PENDING'"
                   [class.border-zinc-800]="node.status === 'PENDING'"
                   [class.bg-amber-500/10]="node.status === 'RUNNING'"
                   [class.border-amber-500/60]="node.status === 'RUNNING'"
                   [class.shadow-[0_0_12px_#f59e0b20]]="node.status === 'RUNNING'"
                   [class.bg-emerald-950/20]="node.status === 'COMPLETED'"
                   [class.border-emerald-500/40]="node.status === 'COMPLETED'">

                <!-- Top Row: Sequence, Type, Status Badge -->
                <div class="flex items-start justify-between gap-2">
                  <div class="flex items-center gap-2">
                    <span class="w-5 h-5 rounded-full bg-zinc-800 text-zinc-400 text-[10px] font-mono flex items-center justify-center font-bold">
                      {{ idx + 1 }}
                    </span>
                    <span class="text-xs font-mono font-bold"
                          [class.text-amber-400]="node.type === 'EXECUTE' || node.type === 'TRANSFORM' || node.type === 'MOVE'"
                          [class.text-emerald-400]="node.type === 'VERIFY' || node.type === 'LOCK'"
                          [class.text-indigo-300]="node.type === 'SCAN' || node.type === 'VALIDATE'"
                          [class.text-zinc-300]="node.type === 'RELEASE'">
                      {{ node.type }}
                    </span>
                  </div>

                  <span class="px-2 py-0.5 text-[9px] font-mono rounded font-semibold border uppercase"
                        [class.bg-emerald-500/10]="node.status === 'COMPLETED'"
                        [class.text-emerald-400]="node.status === 'COMPLETED'"
                        [class.border-emerald-500/30]="node.status === 'COMPLETED'"
                        [class.bg-amber-500/10]="node.status === 'RUNNING'"
                        [class.text-amber-400]="node.status === 'RUNNING'"
                        [class.border-amber-500/30]="node.status === 'RUNNING'"
                        [class.bg-zinc-800]="node.status === 'PENDING'"
                        [class.text-zinc-500]="node.status === 'PENDING'"
                        [class.border-zinc-700]="node.status === 'PENDING'">
                    {{ node.status }}
                  </span>
                </div>

                <!-- Middle: Parameters & Target -->
                <div class="text-xs font-mono space-y-1">
                  <div class="text-zinc-300 truncate">
                    <span class="text-zinc-500">Target:</span> {{ node.target || 'Current Grip' }}
                  </div>
                  @if (node.parameters['desc']) {
                    <div class="text-zinc-400 text-[11px]">{{ node.parameters['desc'] }}</div>
                  }
                  @if (node.dependencies.length > 0) {
                    <div class="text-[10px] text-zinc-500 flex items-center gap-1">
                      <mat-icon class="text-[10px]">subdirectory_arrow_right</mat-icon>
                      Depends on: {{ node.dependencies.join(', ') }}
                    </div>
                  }
                </div>

                <!-- Bottom: Action ID and Duration -->
                <div class="flex items-center justify-between pt-2 border-t border-zinc-800/60 text-[10px] font-mono text-zinc-500">
                  <span>{{ node.action_id }}</span>
                  <span>{{ node.duration_ms ? node.duration_ms + 'ms' : '0.0ms' }}</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Plan Meta Footer -->
        <div class="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-zinc-800/80 text-xs font-mono text-zinc-400">
          <div class="flex items-center gap-4">
            <span>Total Nodes: <strong class="text-zinc-200">{{ plan.totalActions }}</strong></span>
            <span>Target Volume: <strong class="text-zinc-200">{{ engine.formatBytes(plan.estimatedBytes) }}</strong></span>
            <span>Dangerous Ops: <strong class="text-emerald-400">{{ plan.dangerousOps }}</strong></span>
          </div>
          <span class="text-emerald-400 flex items-center gap-1">
            <mat-icon class="text-xs">check_circle</mat-icon> Topological Sorting Verified (0 Cycles)
          </span>
        </div>
      } @else {
        <!-- Empty Plan State -->
        <div class="py-10 text-center flex flex-col items-center justify-center gap-2 text-zinc-500">
          <mat-icon class="text-3xl text-zinc-600">account_tree</mat-icon>
          <p class="text-xs font-mono">No action graph constructed yet.</p>
          <button (click)="engine.executeCommand('plan')"
                  [disabled]="!engine.currentTarget()"
                  class="mt-2 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-mono text-zinc-200 transition-colors">
            Generate Action Graph for {{ engine.currentTarget()?.path || 'Target' }}
          </button>
        </div>
      }
    </div>
  `
})
export class ActionGraphComponent {
  public engine = inject(HardarmEngineService);
}
