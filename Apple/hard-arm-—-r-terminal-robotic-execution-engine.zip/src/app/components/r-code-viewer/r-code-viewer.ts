import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RPackageExportService, RPackageFile } from '../../services/r-package-export.service';

@Component({
  selector: 'app-r-code-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-zinc-900/90 border border-zinc-800 rounded-xl p-5 shadow-lg backdrop-blur-md flex flex-col gap-5">
      <!-- Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-blue-400 text-lg">integration_instructions</mat-icon>
            <h3 class="text-sm font-mono font-semibold tracking-wider text-zinc-200 uppercase">R Package Source Code &amp; Manifest</h3>
          </div>
          <p class="text-xs text-zinc-400 mt-0.5">Industrial R 4.4+ package architecture ready for R CMD build &amp; devtools::install()</p>
        </div>

        <button (click)="downloadZip()"
                class="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-mono font-bold text-white shadow-md transition-colors">
          <mat-icon class="text-xs">download</mat-icon> Download Package (.ZIP)
        </button>
      </div>

      <!-- File Browser + Code Previewer -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <!-- File List -->
        <div class="space-y-1.5 max-h-96 overflow-y-auto pr-1">
          @for (file of rExport.getPackageFiles(); track file.path) {
            <button (click)="selectedFile.set(file)"
                    class="w-full text-left p-2.5 rounded-lg border text-xs font-mono transition-all flex flex-col gap-0.5"
                    [class.bg-blue-600/10]="selectedFile().path === file.path"
                    [class.border-blue-500/50]="selectedFile().path === file.path"
                    [class.text-blue-300]="selectedFile().path === file.path"
                    [class.bg-zinc-950]="selectedFile().path !== file.path"
                    [class.border-zinc-800]="selectedFile().path !== file.path"
                    [class.text-zinc-400]="selectedFile().path !== file.path">
              <div class="flex items-center justify-between">
                <span class="font-bold truncate">{{ file.path }}</span>
                <span class="text-[9px] uppercase px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800">{{ file.category }}</span>
              </div>
              <span class="text-[10px] text-zinc-500 truncate">{{ file.description }}</span>
            </button>
          }
        </div>

        <!-- Code Content Viewer -->
        <div class="md:col-span-2 bg-zinc-950 rounded-xl border border-zinc-800 p-4 flex flex-col gap-3">
          @if (selectedFile(); as file) {
            <div class="flex items-center justify-between border-b border-zinc-850 pb-2">
              <span class="text-xs font-mono font-bold text-zinc-200">{{ file.path }}</span>
              <span class="text-[11px] font-mono text-zinc-500">{{ file.content.split('\n').length }} lines</span>
            </div>
            <pre class="text-xs font-mono text-zinc-300 overflow-x-auto max-h-80 overflow-y-auto leading-relaxed p-2 bg-zinc-900/50 rounded-lg border border-zinc-850"><code>{{ file.content }}</code></pre>
          }
        </div>
      </div>
    </div>
  `
})
export class RCodeViewerComponent {
  public rExport = inject(RPackageExportService);
  public selectedFile = signal<RPackageFile>(this.rExport.getPackageFiles()[0]);

  public downloadZip(): void {
    this.rExport.exportZip();
  }
}
