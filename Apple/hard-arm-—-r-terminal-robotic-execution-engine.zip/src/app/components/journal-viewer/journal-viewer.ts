import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HardarmEngineService } from '../../services/hardarm-engine.service';

@Component({
  selector: 'app-journal-viewer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-zinc-900/90 border border-zinc-800 rounded-xl p-5 shadow-lg backdrop-blur-md flex flex-col gap-5">
      <!-- Section Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400 text-lg">history_edu</mat-icon>
            <h3 class="text-sm font-mono font-semibold tracking-wider text-zinc-200 uppercase">Action Journal &amp; Snapshot Vault</h3>
          </div>
          <p class="text-xs text-zinc-400 mt-0.5">SQLite transaction audit trail, pre-mutation snapshots, and rollback engine</p>
        </div>

        <button (click)="engine.executeCommand('snapshot')"
                [disabled]="!engine.currentTarget()"
                class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-mono text-zinc-200 border border-zinc-700/60 transition-colors">
          <mat-icon class="text-xs text-amber-400">camera</mat-icon> Capture Snapshot
        </button>
      </div>

      <!-- Pre-mutation Snapshot Vault -->
      <div class="space-y-3">
        <div class="flex items-center justify-between">
          <span class="text-xs font-mono font-bold text-zinc-300 flex items-center gap-1.5">
            <mat-icon class="text-xs text-amber-400">save</mat-icon> Pre-Mutation Snapshots ({{ engine.snapshots().length }})
          </span>
        </div>

        @if (engine.snapshots().length > 0) {
          <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            @for (snap of engine.snapshots(); track snap.snapshot_id) {
              <div class="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-between gap-3 text-xs font-mono">
                <div class="min-w-0 space-y-0.5">
                  <div class="flex items-center gap-2">
                    <span class="text-amber-400 font-bold">{{ snap.snapshot_id }}</span>
                    <span class="text-[10px] text-zinc-500 truncate">{{ snap.original_path }}</span>
                  </div>
                  <div class="text-[11px] text-zinc-400 truncate">{{ snap.reason }}</div>
                  <div class="text-[10px] text-zinc-500">SHA256: {{ snap.hash.slice(0, 16) }}... • {{ engine.formatBytes(snap.size_bytes) }}</div>
                </div>

                <button (click)="engine.executeCommand('restore ' + snap.snapshot_id)"
                        class="px-2.5 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-mono flex items-center gap-1 shrink-0 transition-colors">
                  <mat-icon class="text-xs">restore</mat-icon> Rollback
                </button>
              </div>
            }
          </div>
        } @else {
          <div class="p-4 rounded-lg bg-zinc-950 border border-dashed border-zinc-800 text-center text-xs font-mono text-zinc-500">
            No snapshots recorded yet. Pre-mutation snapshots are captured automatically before destructive edits or moves.
          </div>
        }
      </div>

      <!-- SQLite Transaction Audit Journal Table -->
      <div class="space-y-3 pt-2">
        <div class="flex items-center justify-between">
          <span class="text-xs font-mono font-bold text-zinc-300 flex items-center gap-1.5">
            <mat-icon class="text-xs text-indigo-400">table_rows</mat-icon> SQLite Transaction Audit Journal
          </span>
          <span class="text-[10px] font-mono text-zinc-500">Persisted in ~/.hardarm/journal.sqlite</span>
        </div>

        <div class="overflow-x-auto border border-zinc-800 rounded-lg max-h-72 overflow-y-auto">
          <table class="w-full text-left text-xs font-mono border-collapse">
            <thead class="bg-zinc-950 sticky top-0 border-b border-zinc-800 text-zinc-400">
              <tr>
                <th class="p-2.5 border-r border-zinc-800">Action ID</th>
                <th class="p-2.5 border-r border-zinc-800">Job ID</th>
                <th class="p-2.5 border-r border-zinc-800">Operation</th>
                <th class="p-2.5 border-r border-zinc-800">Target</th>
                <th class="p-2.5 border-r border-zinc-800">Duration</th>
                <th class="p-2.5">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-zinc-900">
              @for (log of engine.actionsLog(); track log.id) {
                <tr class="hover:bg-zinc-950/60 transition-colors">
                  <td class="p-2 border-r border-zinc-850 text-zinc-400">{{ log.action_id }}</td>
                  <td class="p-2 border-r border-zinc-850 text-zinc-500">{{ log.job_id }}</td>
                  <td class="p-2 border-r border-zinc-850 font-bold"
                      [class.text-amber-400]="log.operation === 'TRANSFORM' || log.operation === 'MOVE'"
                      [class.text-emerald-400]="log.operation === 'VERIFY' || log.operation === 'LOCK'"
                      [class.text-indigo-400]="log.operation === 'SCAN' || log.operation === 'RELEASE'">
                    {{ log.operation }}
                  </td>
                  <td class="p-2 border-r border-zinc-850 text-zinc-300 truncate max-w-[150px]">{{ log.target }}</td>
                  <td class="p-2 border-r border-zinc-850 text-zinc-500">{{ log.duration_ms }}ms</td>
                  <td class="p-2">
                    <span class="px-2 py-0.5 text-[9px] rounded font-semibold border"
                          [class.bg-emerald-500/10]="log.status === 'COMPLETED'"
                          [class.text-emerald-400]="log.status === 'COMPLETED'"
                          [class.border-emerald-500/30]="log.status === 'COMPLETED'">
                      {{ log.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class JournalViewerComponent {
  public engine = inject(HardarmEngineService);
}
