import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HardarmEngineService } from '../../services/hardarm-engine.service';

@Component({
  selector: 'app-gripper-hud',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-zinc-900/90 border border-zinc-800 rounded-xl p-4 shadow-lg backdrop-blur-md flex flex-col gap-4">
      <!-- Gripper Header -->
      <div class="flex items-center justify-between border-b border-zinc-800/80 pb-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-amber-400 text-lg">precision_manufacturing</mat-icon>
          <span class="text-xs font-mono font-semibold tracking-wider text-zinc-300 uppercase">Kinematic Gripper HUD</span>
        </div>
        <span class="px-2 py-0.5 text-[10px] font-mono rounded border"
              [class.bg-emerald-500/10]="engine.gripperState() === 'LOCKED'"
              [class.text-emerald-400]="engine.gripperState() === 'LOCKED'"
              [class.border-emerald-500/30]="engine.gripperState() === 'LOCKED'"
              [class.bg-amber-500/10]="engine.gripperState() === 'GRIPPING' || engine.gripperState() === 'APPROACHING'"
              [class.text-amber-400]="engine.gripperState() === 'GRIPPING' || engine.gripperState() === 'APPROACHING'"
              [class.border-amber-500/30]="engine.gripperState() === 'GRIPPING' || engine.gripperState() === 'APPROACHING'"
              [class.bg-zinc-800]="engine.gripperState() === 'OPEN' || engine.gripperState() === 'RELEASED'"
              [class.text-zinc-400]="engine.gripperState() === 'OPEN' || engine.gripperState() === 'RELEASED'"
              [class.border-zinc-700]="engine.gripperState() === 'OPEN' || engine.gripperState() === 'RELEASED'">
          {{ engine.gripperState() }}
        </span>
      </div>

      <!-- Gripper Mechanical Visualizer -->
      <div class="relative h-32 bg-zinc-950/80 rounded-lg border border-zinc-800/60 overflow-hidden flex items-center justify-center p-3">
        <!-- Background Grid -->
        <div class="absolute inset-0 bg-[linear-gradient(to_right,#27272a15_1px,transparent_1px),linear-gradient(to_bottom,#27272a15_1px,transparent_1px)] bg-[size:16px_16px]"></div>

        <!-- Center Target Object -->
        <div class="z-10 flex flex-col items-center justify-center text-center transition-all duration-300"
             [class.scale-105]="engine.gripperState() === 'LOCKED'"
             [class.opacity-40]="!engine.currentTarget()">
          @if (engine.currentTarget(); as tgt) {
            <div class="w-14 h-14 rounded-lg bg-zinc-900 border-2 flex items-center justify-center shadow-xl transition-all"
                 [class.border-amber-500]="engine.gripperState() === 'LOCKED'"
                 [class.border-zinc-700]="engine.gripperState() !== 'LOCKED'">
              <mat-icon class="text-2xl" [class.text-amber-400]="engine.gripperState() === 'LOCKED'" [class.text-zinc-400]="engine.gripperState() !== 'LOCKED'">
                @switch (tgt.type) {
                  @case ('DATASET') { table_chart }
                  @case ('LOG') { article }
                  @case ('DIRECTORY') { folder_open }
                  @case ('COMMAND_OUTPUT') { terminal }
                  @case ('SOURCE_CODE') { code }
                  @default { description }
                }
              </mat-icon>
            </div>
            <span class="mt-1 text-[11px] font-mono text-zinc-300 truncate max-w-[120px] font-medium">{{ tgt.path }}</span>
            <span class="text-[9px] font-mono text-zinc-500">{{ engine.formatBytes(tgt.size) }}</span>
          } @else {
            <div class="w-12 h-12 rounded-lg border border-dashed border-zinc-700 flex items-center justify-center text-zinc-600">
              <mat-icon class="text-xl">crop_free</mat-icon>
            </div>
            <span class="mt-1 text-[10px] font-mono text-zinc-500">NO TARGET ACQUIRED</span>
          }
        </div>

        <!-- Left Gripper Jaw -->
        <div class="absolute top-1/2 -translate-y-1/2 w-12 h-16 border-r-4 border-y-2 rounded-r-md transition-all duration-500 flex items-center justify-start pl-1"
             [style.left.px]="calculateLeftJawPos()"
             [class.border-amber-500]="engine.gripperState() === 'LOCKED'"
             [class.bg-amber-500/10]="engine.gripperState() === 'LOCKED'"
             [class.border-zinc-600]="engine.gripperState() !== 'LOCKED'"
             [class.bg-zinc-800/40]="engine.gripperState() !== 'LOCKED'">
          <div class="w-2 h-8 bg-zinc-700 rounded-sm"></div>
        </div>

        <!-- Right Gripper Jaw -->
        <div class="absolute top-1/2 -translate-y-1/2 w-12 h-16 border-l-4 border-y-2 rounded-l-md transition-all duration-500 flex items-center justify-end pr-1"
             [style.right.px]="calculateRightJawPos()"
             [class.border-amber-500]="engine.gripperState() === 'LOCKED'"
             [class.bg-amber-500/10]="engine.gripperState() === 'LOCKED'"
             [class.border-zinc-600]="engine.gripperState() !== 'LOCKED'"
             [class.bg-zinc-800/40]="engine.gripperState() !== 'LOCKED'">
          <div class="w-2 h-8 bg-zinc-700 rounded-sm"></div>
        </div>

        <!-- Scanning Beam Animation -->
        @if (engine.armState() === 'SCANNING' || engine.armState() === 'TARGETING') {
          <div class="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse top-1/2 shadow-[0_0_8px_#22d3ee]"></div>
        }
      </div>

      <!-- Gripper Force Gauge & Status -->
      <div class="space-y-1.5">
        <div class="flex justify-between items-center text-[11px] font-mono">
          <span class="text-zinc-400 flex items-center gap-1">
            <mat-icon class="text-xs text-zinc-500">speed</mat-icon> Clamping Force
          </span>
          <span class="font-bold" [class.text-amber-400]="engine.gripForcePct() > 0" [class.text-zinc-500]="engine.gripForcePct() === 0">
            {{ engine.gripForcePct() }}%
          </span>
        </div>
        <div class="w-full bg-zinc-950 rounded-full h-2 overflow-hidden border border-zinc-800/80 p-0.5">
          <div class="h-full rounded-full transition-all duration-300"
               [style.width.%]="engine.gripForcePct()"
               [class.bg-gradient-to-r]="true"
               [class.from-amber-600]="true"
               [class.to-amber-400]="true"
               [class.shadow-[0_0_10px_#f59e0b]]="engine.gripForcePct() === 100">
          </div>
        </div>
      </div>

      <!-- Quick Action Commands -->
      <div class="grid grid-cols-2 gap-2 pt-1">
        <button (click)="engine.executeCommand('verify')"
                [disabled]="!engine.currentTarget()"
                class="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-mono text-zinc-200 border border-zinc-700/60 transition-colors">
          <mat-icon class="text-xs text-emerald-400">verified</mat-icon> Verify Hash
        </button>
        <button (click)="engine.executeCommand('release')"
                [disabled]="!engine.currentTarget()"
                class="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-red-950/40 hover:text-red-300 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-mono text-zinc-300 border border-zinc-700/60 transition-colors">
          <mat-icon class="text-xs text-amber-400">lock_open</mat-icon> Release Target
        </button>
      </div>
    </div>
  `
})
export class GripperHud {
  public engine = inject(HardarmEngineService);

  public calculateLeftJawPos(): number {
    const pct = this.engine.gripForcePct();
    // 0% -> 12px, 100% -> 72px
    return 12 + (pct / 100) * 60;
  }

  public calculateRightJawPos(): number {
    const pct = this.engine.gripForcePct();
    return 12 + (pct / 100) * 60;
  }
}
