import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { HardarmEngineService } from '../../services/hardarm-engine.service';

@Component({
  selector: 'app-statistical-studio',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-zinc-900/90 border border-zinc-800 rounded-xl p-5 shadow-lg backdrop-blur-md flex flex-col gap-5">
      <!-- Studio Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-lg">query_stats</mat-icon>
            <h3 class="text-sm font-mono font-semibold tracking-wider text-zinc-200 uppercase">Statistical Arm & Outlier Studio</h3>
          </div>
          <p class="text-xs text-zinc-400 mt-0.5">High-performance data.table pipeline simulation, outlier radar & summary quantiles</p>
        </div>

        @if (!engine.datasetProfile()) {
          <button (click)="engine.executeCommand('grab sales.csv')"
                  class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-mono font-bold text-white transition-colors shadow-sm">
            <mat-icon class="text-xs">table_view</mat-icon> Grab 'sales.csv' Demo
          </button>
        }
      </div>

      @if (engine.datasetProfile(); as profile) {
        <!-- Profile Overview Badges -->
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
          <div class="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80 flex flex-col">
            <span class="text-[10px] font-mono text-zinc-500 uppercase">Total Rows</span>
            <span class="text-lg font-mono font-bold text-zinc-200">{{ profile.rows.toLocaleString() }}</span>
          </div>
          <div class="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80 flex flex-col">
            <span class="text-[10px] font-mono text-zinc-500 uppercase">Columns</span>
            <span class="text-lg font-mono font-bold text-zinc-200">{{ profile.columns }}</span>
          </div>
          <div class="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80 flex flex-col">
            <span class="text-[10px] font-mono text-zinc-500 uppercase">Numeric Vectors</span>
            <span class="text-lg font-mono font-bold text-emerald-400">{{ profile.numericCount }}</span>
          </div>
          <div class="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80 flex flex-col">
            <span class="text-[10px] font-mono text-zinc-500 uppercase">Text / Categorical</span>
            <span class="text-lg font-mono font-bold text-indigo-400">{{ profile.textCount }}</span>
          </div>
          <div class="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80 flex flex-col">
            <span class="text-[10px] font-mono text-zinc-500 uppercase">Missing Values</span>
            <span class="text-lg font-mono font-bold text-zinc-400">{{ profile.missingPct }}%</span>
          </div>
          <div class="bg-zinc-950 p-3 rounded-lg border border-zinc-800/80 flex flex-col">
            <span class="text-[10px] font-mono text-zinc-500 uppercase">Duplicates</span>
            <span class="text-lg font-mono font-bold text-zinc-400">{{ profile.duplicateRows }}</span>
          </div>
        </div>

        <!-- Column Inspector & Outlier Radar -->
        <div class="bg-zinc-950/60 p-4 rounded-xl border border-zinc-800 flex flex-col gap-4">
          <div class="flex flex-wrap items-center justify-between gap-3">
            <div class="flex items-center gap-2">
              <span class="text-xs font-mono text-zinc-400">Select Column to Profile:</span>
              <div class="flex flex-wrap gap-1.5">
                @for (col of profile.colNames; track col) {
                  <button (click)="engine.executeCommand('analyse ' + col)"
                          class="px-2.5 py-1 text-xs font-mono rounded-md border transition-all"
                          [class.bg-emerald-500/20]="engine.activeColumnAnalysis()?.column === col"
                          [class.border-emerald-500]="engine.activeColumnAnalysis()?.column === col"
                          [class.text-emerald-300]="engine.activeColumnAnalysis()?.column === col"
                          [class.bg-zinc-800]="engine.activeColumnAnalysis()?.column !== col"
                          [class.border-zinc-700]="engine.activeColumnAnalysis()?.column !== col"
                          [class.text-zinc-300]="engine.activeColumnAnalysis()?.column !== col">
                    {{ col }}
                    <span class="text-[9px] opacity-60">({{ profile.colTypes[col] }})</span>
                  </button>
                }
              </div>
            </div>
          </div>

          <!-- Active Analysis Card -->
          @if (engine.activeColumnAnalysis(); as ana) {
            @if (ana.type === 'NUMERIC') {
              <div class="p-4 rounded-lg bg-zinc-900 border border-zinc-800 space-y-4">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <mat-icon class="text-emerald-400 text-sm">show_chart</mat-icon>
                    <span class="text-xs font-mono font-bold text-zinc-200">Parametric Distribution: {{ ana.column }}</span>
                  </div>
                  @if ((ana.outlierCount || 0) > 0) {
                    <span class="px-2 py-0.5 text-[10px] font-mono rounded bg-red-500/10 text-red-400 border border-red-500/30 flex items-center gap-1 font-bold">
                      <mat-icon class="text-xs">warning</mat-icon> {{ ana.outlierCount }} OUTLIERS DETECTED
                    </span>
                  }
                </div>

                <!-- Stats Grid -->
                <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-xs font-mono">
                  <div class="p-2 rounded bg-zinc-950 border border-zinc-800">
                    <div class="text-[10px] text-zinc-500">Mean</div>
                    <div class="font-bold text-zinc-200">{{ ana.mean }}</div>
                  </div>
                  <div class="p-2 rounded bg-zinc-950 border border-zinc-800">
                    <div class="text-[10px] text-zinc-500">Median (Q2)</div>
                    <div class="font-bold text-zinc-200">{{ ana.median }}</div>
                  </div>
                  <div class="p-2 rounded bg-zinc-950 border border-zinc-800">
                    <div class="text-[10px] text-zinc-500">Min / Max</div>
                    <div class="font-bold text-zinc-200">{{ ana.min }} / {{ ana.max }}</div>
                  </div>
                  <div class="p-2 rounded bg-zinc-950 border border-zinc-800">
                    <div class="text-[10px] text-zinc-500">Q1 (25%)</div>
                    <div class="font-bold text-zinc-200">{{ ana.q25 }}</div>
                  </div>
                  <div class="p-2 rounded bg-zinc-950 border border-zinc-800">
                    <div class="text-[10px] text-zinc-500">Q3 (75%)</div>
                    <div class="font-bold text-zinc-200">{{ ana.q75 }}</div>
                  </div>
                  <div class="p-2 rounded bg-zinc-950 border border-zinc-800">
                    <div class="text-[10px] text-zinc-500">IQR Spread</div>
                    <div class="font-bold text-zinc-200">{{ ana.iqr }}</div>
                  </div>
                  <div class="p-2 rounded bg-zinc-950 border border-zinc-800">
                    <div class="text-[10px] text-zinc-500">Normal Range</div>
                    <div class="font-bold text-emerald-400">[{{ ana.outlierBounds?.lower }} .. {{ ana.outlierBounds?.upper }}]</div>
                  </div>
                </div>

                @if (ana.outliers && ana.outliers.length > 0) {
                  <div class="p-3 rounded bg-red-950/20 border border-red-900/40 text-xs font-mono">
                    <span class="text-red-400 font-bold">Outlier Observations (Exceeding ±1.5 IQR):</span>
                    <div class="mt-1 flex flex-wrap gap-2">
                      @for (outlier of ana.outliers; track $index) {
                        <span class="px-2 py-0.5 rounded bg-red-900/40 text-red-300 border border-red-700/50">
                          {{ outlier }}
                        </span>
                      }
                    </div>
                  </div>
                }
              </div>
            } @else {
              <!-- Categorical Breakdown -->
              <div class="p-4 rounded-lg bg-zinc-900 border border-zinc-800 space-y-3">
                <span class="text-xs font-mono font-bold text-zinc-200">Categorical Frequency Distribution: {{ ana.column }} ({{ ana.distinct }} Distinct)</span>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  @for (item of getFrequencyEntries(ana.topFrequencies); track item[0]) {
                    <div class="p-2 rounded bg-zinc-950 border border-zinc-800 text-xs font-mono flex justify-between items-center">
                      <span class="text-zinc-300">{{ item[0] }}</span>
                      <span class="font-bold text-indigo-400">{{ item[1] }}</span>
                    </div>
                  }
                </div>
              </div>
            }
          }
        </div>

        <!-- Interactive Data Pipeline Simulator -->
        <div class="bg-zinc-950 p-4 rounded-xl border border-zinc-800 flex flex-col gap-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400 text-sm">tune</mat-icon>
            <h4 class="text-xs font-mono font-bold tracking-wide text-zinc-200 uppercase">Robotic Data Transformation Pipeline</h4>
          </div>

          <!-- Quick Pipeline Action Buttons -->
          <div class="flex flex-wrap items-center gap-2">
            <button (click)="engine.executeCommand('filter revenue > 1000')"
                    class="px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-mono text-zinc-200 flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs text-amber-400">filter_alt</mat-icon> Filter: revenue > 1000
            </button>
            <button (click)="engine.executeCommand('filter customer_rating >= 4.0')"
                    class="px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-mono text-zinc-200 flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs text-amber-400">star</mat-icon> Filter: rating &ge; 4.0
            </button>
            <button (click)="engine.executeCommand('summarise revenue')"
                    class="px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-mono text-zinc-200 flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs text-indigo-400">functions</mat-icon> Group &amp; Summarise Revenue
            </button>
            <button (click)="engine.executeCommand('sort revenue desc')"
                    class="px-2.5 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-mono text-zinc-200 flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs text-cyan-400">sort</mat-icon> Sort: Descending
            </button>
            <button (click)="engine.executeCommand('write reports/output_sales.csv')"
                    class="px-2.5 py-1.5 rounded-lg bg-emerald-600/80 hover:bg-emerald-600 border border-emerald-500 text-xs font-mono text-white flex items-center gap-1.5 transition-colors">
              <mat-icon class="text-xs">save</mat-icon> Export to CSV
            </button>
          </div>

          <!-- Dataset Table Preview -->
          <div class="overflow-x-auto border border-zinc-800 rounded-lg max-h-60 overflow-y-auto">
            <table class="w-full text-left text-xs font-mono border-collapse">
              <thead class="bg-zinc-900 sticky top-0 border-b border-zinc-800 text-zinc-400">
                <tr>
                  <th class="p-2.5 border-r border-zinc-800 w-12 text-center">#</th>
                  @for (col of profile.colNames; track col) {
                    <th class="p-2.5 border-r border-zinc-800 font-semibold">{{ col }}</th>
                  }
                </tr>
              </thead>
              <tbody class="divide-y divide-zinc-900">
                @for (row of profile.previewRows.slice(0, 15); track $index; let idx = $index) {
                  <tr class="hover:bg-zinc-900/50 transition-colors">
                    <td class="p-2 text-center text-zinc-600 border-r border-zinc-850">{{ idx + 1 }}</td>
                    @for (col of profile.colNames; track col) {
                      <td class="p-2 border-r border-zinc-850 text-zinc-300">
                        {{ row[col] }}
                      </td>
                    }
                  </tr>
                }
              </tbody>
            </table>
          </div>
          @if (profile.rows > 15) {
            <span class="text-[11px] font-mono text-zinc-500 text-right">Showing first 15 of {{ profile.rows }} rows.</span>
          }
        </div>
      } @else {
        <!-- Empty State -->
        <div class="py-12 text-center flex flex-col items-center justify-center gap-3 text-zinc-500">
          <mat-icon class="text-4xl text-zinc-600">query_stats</mat-icon>
          <p class="text-xs font-mono">No dataset loaded in the statistical arm.</p>
          <button (click)="engine.executeCommand('grab sales.csv')"
                  class="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-mono font-bold text-white transition-colors">
            Acquire 'sales.csv'
          </button>
        </div>
      }
    </div>
  `
})
export class StatisticalStudioComponent {
  public engine = inject(HardarmEngineService);

  public getFrequencyEntries(obj?: Record<string, number>): [string, number][] {
    if (!obj) return [];
    return Object.entries(obj);
  }
}
