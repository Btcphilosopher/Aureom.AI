import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { VirtualFsService } from '../../services/virtual-fs.service';
import { HardarmEngineService } from '../../services/hardarm-engine.service';

@Component({
  selector: 'app-vfs-explorer',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-zinc-900/90 border border-zinc-800 rounded-xl p-5 shadow-lg backdrop-blur-md flex flex-col gap-4">
      <!-- Section Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-lg">folder_open</mat-icon>
            <h3 class="text-sm font-mono font-semibold tracking-wider text-zinc-200 uppercase">Virtual Filesystem Sandbox</h3>
          </div>
          <p class="text-xs text-zinc-400 mt-0.5">Isolated workspace targets ready for robotic acquisition, analysis, and verification</p>
        </div>

        <button (click)="resetWorkspace()"
                class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-mono text-zinc-300 border border-zinc-700/60 transition-colors">
          <mat-icon class="text-xs">restart_alt</mat-icon> Reset Workspace
        </button>
      </div>

      <!-- File Grid / List -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        @for (file of fs.getAllFiles(); track file.path) {
          <div class="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700 transition-all flex flex-col justify-between gap-2.5">
            <div class="flex items-start justify-between gap-2">
              <div class="flex items-center gap-2.5 min-w-0">
                <div class="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center shrink-0">
                  <mat-icon class="text-sm"
                            [class.text-emerald-400]="file.name.endsWith('.csv')"
                            [class.text-amber-400]="file.name.endsWith('.log')"
                            [class.text-indigo-400]="file.name.endsWith('.json')"
                            [class.text-red-400]="file.name.endsWith('.pdf')"
                            [class.text-cyan-400]="file.name.endsWith('.py') || file.name.endsWith('.sh')">
                    @if (file.name.endsWith('.csv')) { table_chart }
                    @else if (file.name.endsWith('.log')) { article }
                    @else if (file.name.endsWith('.json')) { data_object }
                    @else if (file.name.endsWith('.pdf')) { picture_as_pdf }
                    @else if (file.name.endsWith('.py')) { code }
                    @else { description }
                  </mat-icon>
                </div>
                <div class="min-w-0">
                  <div class="text-xs font-mono font-bold text-zinc-200 truncate">{{ file.path }}</div>
                  <div class="text-[10px] font-mono text-zinc-500">
                    {{ engine.formatBytes(file.size) }} • {{ file.lines }} lines
                  </div>
                </div>
              </div>

              <button (click)="engine.executeCommand('grab ' + file.path)"
                      class="px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-mono font-bold flex items-center gap-1 shrink-0 transition-colors shadow-sm">
                <mat-icon class="text-xs">precision_manufacturing</mat-icon> Grab
              </button>
            </div>

            <!-- Hash String -->
            <div class="text-[9px] font-mono text-zinc-500 truncate bg-zinc-900/60 p-1.5 rounded border border-zinc-850">
              SHA256: {{ file.hash }}
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class VfsExplorerComponent {
  public fs = inject(VirtualFsService);
  public engine = inject(HardarmEngineService);

  public resetWorkspace(): void {
    this.fs.initDefaultWorkspace();
    this.engine.appendTerminalOutput('output', 'Virtual filesystem workspace reset to factory defaults.');
  }
}
