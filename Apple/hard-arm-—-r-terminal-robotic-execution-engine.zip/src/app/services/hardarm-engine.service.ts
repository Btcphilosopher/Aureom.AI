import { Injectable, signal, inject } from '@angular/core';
import { VirtualFsService } from './virtual-fs.service';
import {
  ArmStateType,
  GripperStateType,
  ArmTarget,
  ActionNode,
  ActionGraph,
  ActionNodeType,
  DatasetProfile,
  ColumnAnalysis,
  Snapshot,
  JobRecord,
  ActionLog,
  TelemetryMetrics,
  TerminalOutputLine,
  TargetType
} from '../models/hardarm.models';

@Injectable({
  providedIn: 'root',
})
export class HardarmEngineService {
  private fs = inject(VirtualFsService);

  // Reactive Signals for UI HUD
  public armState = signal<ArmStateType>('IDLE');
  public gripperState = signal<GripperStateType>('OPEN');
  public gripForcePct = signal<number>(0);
  public currentTarget = signal<ArmTarget | null>(null);
  public currentPlan = signal<ActionGraph | null>(null);
  public terminalLogs = signal<TerminalOutputLine[]>([]);
  public datasetProfile = signal<DatasetProfile | null>(null);
  public activeColumnAnalysis = signal<ColumnAnalysis | null>(null);
  public snapshots = signal<Snapshot[]>([]);
  public jobsHistory = signal<JobRecord[]>([]);
  public actionsLog = signal<ActionLog[]>([]);
  public isExecuting = signal<boolean>(false);
  public executionProgress = signal<{ current: number; total: number; pct: number; currentAction?: string }>({
    current: 0,
    total: 0,
    pct: 0
  });
  public telemetry = signal<TelemetryMetrics>({
    jobs: 142,
    operations: 1842,
    success_pct: 99.85,
    error_pct: 0.15,
    total_bytes: 4892410294,
    mean_throughput_mb_s: 284.5,
    cpu_utilization_pct: 22.4,
    memory_usage_mb: 138.6,
    worker_count: 4,
    timestamp: new Date().toISOString()
  });
  public isWatching = signal<boolean>(false);
  public watchDirectory = signal<string | null>(null);

  // Command History for Terminal navigation (Up/Down arrow)
  public commandHistory: string[] = [
    'grab sales.csv',
    'inspect',
    'analyse revenue',
    'filter revenue > 1000',
    'plan',
    'execute',
    'verify',
    'release'
  ];

  constructor() {
    this.appendTerminalOutput('banner', 'HARD ARM KERNEL v1.0.0 INITIALIZED');
    this.appendTerminalOutput('output', 'Robotic Arm State: IDLE | Gripper: OPEN | Safety Guard: STRICT_ACTIVE');
    this.appendTerminalOutput('output', "Type 'grab <target>' or click quick action targets below to acquire an object.\n");
    
    // Initialize with a default job in the audit journal
    this.initDefaultAuditLogs();
  }

  private initDefaultAuditLogs(): void {
    const defaultJob: JobRecord = {
      job_id: 'HA-2026-000184',
      target_path: 'sales.csv',
      target_type: 'DATASET',
      status: 'COMPLETED',
      total_actions: 7,
      started_at: new Date(Date.now() - 3600000).toISOString(),
      completed_at: new Date(Date.now() - 3595000).toISOString(),
      duration_sec: 4.82,
      bytes_processed: 2458000
    };
    this.jobsHistory.set([defaultJob]);

    this.actionsLog.set([
      { id: 1, job_id: 'HA-2026-000184', action_id: 'ACT-001', operation: 'SCAN', target: 'sales.csv', status: 'COMPLETED', original_hash: '3f8e4a9...', result_hash: '3f8e4a9...', duration_ms: 12.4, timestamp: new Date(Date.now() - 3600000).toISOString() },
      { id: 2, job_id: 'HA-2026-000184', action_id: 'ACT-002', operation: 'LOCK', target: 'sales.csv', status: 'COMPLETED', original_hash: '3f8e4a9...', result_hash: '3f8e4a9...', duration_ms: 25.1, timestamp: new Date(Date.now() - 3599000).toISOString() },
      { id: 3, job_id: 'HA-2026-000184', action_id: 'ACT-003', operation: 'TRANSFORM', target: 'sales.csv', status: 'COMPLETED', original_hash: '3f8e4a9...', result_hash: '9a7c2b1...', duration_ms: 84.0, timestamp: new Date(Date.now() - 3598000).toISOString() },
      { id: 4, job_id: 'HA-2026-000184', action_id: 'ACT-004', operation: 'VERIFY', target: 'reports/regional_revenue.csv', status: 'COMPLETED', original_hash: '9a7c2b1...', result_hash: '9a7c2b1...', duration_ms: 15.2, timestamp: new Date(Date.now() - 3596000).toISOString() },
      { id: 5, job_id: 'HA-2026-000184', action_id: 'ACT-005', operation: 'RELEASE', target: 'reports/regional_revenue.csv', status: 'COMPLETED', original_hash: '9a7c2b1...', result_hash: '9a7c2b1...', duration_ms: 8.1, timestamp: new Date(Date.now() - 3595000).toISOString() }
    ]);
  }

  // ==========================================
  // DISPATCH COMMAND (Deterministic Interpreter)
  // ==========================================
  public async executeCommand(rawCommand: string): Promise<void> {
    const trimmed = rawCommand.trim();
    if (!trimmed) return;

    this.appendTerminalOutput('command', `hardarm> ${trimmed}`);
    if (!this.commandHistory.includes(trimmed)) {
      this.commandHistory.push(trimmed);
    }

    // Strip leading "hardarm " if present
    const cmd = trimmed.replace(/^hardarm\s+/, '');
    const tokens = this.tokenize(cmd);
    if (tokens.length === 0) return;

    const verb = tokens[0].toLowerCase();
    const rest = tokens.slice(1);

    try {
      switch (verb) {
        case 'grab':
          await this.handleGrab(rest);
          break;
        case 'grab-output':
          await this.handleGrabOutput(rest);
          break;
        case 'inspect':
          await this.handleInspect();
          break;
        case 'analyse':
        case 'analyze':
          await this.handleAnalyse(rest[0]);
          break;
        case 'plan':
          await this.handlePlan();
          break;
        case 'preview':
          await this.handlePreview();
          break;
        case 'execute':
          await this.handleExecute(rest.includes('--dry-run'));
          break;
        case 'verify':
          await this.handleVerify();
          break;
        case 'release':
          await this.handleRelease();
          break;
        case 'filter':
          await this.handleFilter(rest);
          break;
        case 'group':
          await this.handleGroup(rest);
          break;
        case 'summarise':
        case 'summarize':
          await this.handleSummarise(rest);
          break;
        case 'sort':
          await this.handleSort(rest);
          break;
        case 'write':
        case 'save':
          await this.handleWrite(rest[0]);
          break;
        case 'move':
          await this.handleMove(rest);
          break;
        case 'copy':
          await this.handleCopy(rest);
          break;
        case 'delete':
          await this.handleDelete(rest.includes('--force'));
          break;
        case 'find':
          await this.handleFind(rest[0]);
          break;
        case 'snapshot':
          await this.handleSnapshot();
          break;
        case 'restore':
          await this.handleRestore(rest[0]);
          break;
        case 'diff':
          await this.handleDiff();
          break;
        case 'jobs':
          await this.handleJobs();
          break;
        case 'telemetry':
          await this.handleTelemetry();
          break;
        case 'history':
          await this.handleHistory();
          break;
        case 'status':
          await this.handleStatus();
          break;
        case 'watch':
          await this.handleWatch(rest[0]);
          break;
        case 'clear':
        case 'cls':
          this.terminalLogs.set([]);
          break;
        case 'help':
          this.printHelp();
          break;
        default:
          this.appendTerminalOutput('error', `Unknown command: '${verb}'. Type 'help' for command syntax.`);
      }
    } catch (err: unknown) {
      this.armState.set('ERROR');
      const msg = err instanceof Error ? err.message : String(err);
      this.appendTerminalOutput('error', `ROBOTIC ARM ERROR: ${msg}`);
    }
  }

  // ==========================================
  // GRAB / TARGET ACQUISITION
  // ==========================================
  public async handleGrab(args: string[]): Promise<void> {
    if (args.length === 0) {
      this.appendTerminalOutput('error', "Syntax error: 'grab' requires a target path (e.g. 'grab sales.csv', 'grab project/', 'grab incoming/*.pdf')");
      return;
    }

    const targetPath = args[0];
    const hasPlanFlag = args.includes('--plan');
    const hasExecuteFlag = args.includes('--execute');
    const hasDryRun = args.includes('--dry-run');

    this.armState.set('TARGETING');
    this.gripperState.set('APPROACHING');
    this.gripForcePct.set(25);
    this.appendTerminalOutput('box', `\nGRAB\nTarget: ${targetPath}\nAcquiring...`);

    // Robotic servo delay simulation
    await this.delay(120);

    this.armState.set('GRABBING');
    this.gripperState.set('GRIPPING');
    this.gripForcePct.set(75);

    // Glob check
    if (targetPath.includes('*') || targetPath.includes('?')) {
      const matched = this.fs.getFilesMatchingGlob(targetPath);
      if (matched.length === 0) {
        throw new Error(`No targets matched glob pattern '${targetPath}'`);
      }

      const totalSize = matched.reduce((acc, f) => acc + f.size, 0);
      const totalLines = matched.reduce((acc, f) => acc + f.lines, 0);

      const targetObj: ArmTarget = {
        target_id: `TGT-${Date.now()}`,
        path: targetPath,
        type: 'FILE',
        size: totalSize,
        lines: totalLines,
        permissions: 'rwxr-xr-x',
        hash: matched[0].hash,
        metadata: { matchCount: matched.length, files: matched.map(m => m.path) },
        status: 'LOCKED',
        acquired_at: new Date().toISOString()
      };

      this.currentTarget.set(targetObj);
      this.gripForcePct.set(100);
      this.gripperState.set('LOCKED');
      this.armState.set('HOLDING');

      this.appendTerminalOutput('success', `TARGET ACQUISITION [BATCH]\nFound: ${matched.length} files\nTotal Size: ${this.formatBytes(totalSize)}\nTARGETS LOCKED: ${matched.length}\n✓ Accessible | ✓ Target Locked`);
      return;
    }

    // Directory check
    if (this.fs.isDirectory(targetPath)) {
      const dirFiles = this.fs.getFilesInDirectory(targetPath);
      const totalSize = dirFiles.reduce((acc, f) => acc + f.size, 0);
      const totalLines = dirFiles.reduce((acc, f) => acc + f.lines, 0);

      const targetObj: ArmTarget = {
        target_id: `TGT-${Date.now()}`,
        path: targetPath,
        type: 'DIRECTORY',
        size: totalSize,
        lines: totalLines,
        permissions: 'rwxr-xr-x',
        hash: dirFiles.length > 0 ? dirFiles[0].hash : 'empty_dir',
        metadata: { fileCount: dirFiles.length, files: dirFiles.map(d => d.path) },
        status: 'LOCKED',
        acquired_at: new Date().toISOString()
      };

      this.currentTarget.set(targetObj);
      this.gripForcePct.set(100);
      this.gripperState.set('LOCKED');
      this.armState.set('HOLDING');

      this.printTargetAcquiredCard(targetObj);

      if (hasPlanFlag) await this.handlePlan();
      if (hasExecuteFlag) await this.handleExecute(hasDryRun);
      return;
    }

    // Single File Target
    const vfile = this.fs.getFile(targetPath);
    if (!vfile) {
      throw new Error(`Target does not exist on filesystem: '${targetPath}'`);
    }

    const type = this.detectTargetType(targetPath);
    const targetObj: ArmTarget = {
      target_id: `TGT-${Date.now()}`,
      path: vfile.path,
      type,
      size: vfile.size,
      lines: vfile.lines,
      permissions: 'rw-r--r--',
      hash: vfile.hash,
      metadata: { mimeType: vfile.mimeType },
      status: 'LOCKED',
      acquired_at: new Date().toISOString(),
      contentPreview: vfile.content.slice(0, 1000)
    };

    this.currentTarget.set(targetObj);
    this.gripForcePct.set(100);
    this.gripperState.set('LOCKED');
    this.armState.set('HOLDING');

    // Auto load dataset profile if dataset
    if (type === 'DATASET') {
      this.loadDatasetProfile(vfile.content);
    }

    this.printTargetAcquiredCard(targetObj);

    if (hasPlanFlag) await this.handlePlan();
    if (hasExecuteFlag) await this.handleExecute(hasDryRun);
  }

  public async handleGrabOutput(args: string[]): Promise<void> {
    const sepIdx = args.indexOf('--');
    if (sepIdx === -1 || sepIdx === args.length - 1) {
      this.appendTerminalOutput('error', "Syntax error: 'grab-output' requires '-- <command> [args...]'");
      return;
    }

    const executable = args[sepIdx + 1];
    const execArgs = args.slice(sepIdx + 2);

    this.armState.set('TARGETING');
    this.appendTerminalOutput('box', `GRAB-OUTPUT\nSubprocess: ${executable} ${execArgs.join(' ')}\nExecuting via explicit system2()...`);

    await this.delay(150);

    const stdoutLines = [
      `total 48`,
      `drwxr-xr-x   6 hardarm staff  192 Sep  8 07:20 .`,
      `drwxr-xr-x  14 hardarm staff  448 Sep  8 07:19 ..`,
      `-rw-r--r--   1 hardarm staff 8420 Sep  8 07:20 sales.csv`,
      `-rw-r--r--   1 hardarm staff 4182 Sep  8 07:20 server.log`,
      `-rw-r--r--   1 hardarm staff  842 Sep  8 07:20 config.json`
    ];

    const targetObj: ArmTarget = {
      target_id: `CMD-${Date.now()}`,
      path: `cmd://${executable}`,
      type: 'COMMAND_OUTPUT',
      size: stdoutLines.join('\n').length,
      lines: stdoutLines.length,
      permissions: 'r-xr-xr-x',
      hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      metadata: { command: executable, args: execArgs },
      status: 'LOCKED',
      acquired_at: new Date().toISOString(),
      contentPreview: stdoutLines.join('\n'),
      commandData: {
        command: executable,
        args: execArgs,
        exit_code: 0,
        stdout: stdoutLines,
        stderr: [],
        duration_sec: 0.042
      }
    };

    this.currentTarget.set(targetObj);
    this.gripForcePct.set(100);
    this.gripperState.set('LOCKED');
    this.armState.set('HOLDING');

    this.appendTerminalOutput('success', `COMMAND TARGET ACQUIRED\nCommand: ${executable} ${execArgs.join(' ')}\nExit Code: 0\nLines Captured: ${stdoutLines.length}\nDuration: 42ms\n✓ Target secured in virtual gripper`);
  }

  // ==========================================
  // INSPECT & ANALYSE
  // ==========================================
  public async handleInspect(): Promise<void> {
    const tgt = this.currentTarget();
    if (!tgt) {
      throw new Error("No target held in robotic arm. Use 'grab <path>' first.");
    }

    this.armState.set('ANALYSING');
    this.appendTerminalOutput('box', `INSPECTION REPORT\nTarget ID: ${tgt.target_id}\nPath:      ${tgt.path}\nType:      ${tgt.type}\nSize:      ${this.formatBytes(tgt.size)}\nLines:     ${tgt.lines.toLocaleString()}\nSHA256:    ${tgt.hash}\nStatus:    ${tgt.status}`);

    if (tgt.type === 'DATASET' && this.datasetProfile()) {
      const p = this.datasetProfile()!;
      this.appendTerminalOutput('output', `DATASET PROFILE:\n  Rows: ${p.rows.toLocaleString()} | Columns: ${p.columns}\n  Numeric: ${p.numericCount} | Text: ${p.textCount} | Logical: ${p.logicalCount}\n  Missing: ${p.missingPct}% | Duplicates: ${p.duplicateRows}\n  Columns: ${p.colNames.join(', ')}`);
    } else if (tgt.type === 'LOG') {
      this.appendTerminalOutput('output', `LOG PROFILE:\n  Total Events: ${tgt.lines}\n  Errors Detected: 18\n  Warnings: 36\n  Timestamp Span: 2026-09-08 00:00:00 - 06:39:48`);
    } else if (tgt.type === 'DIRECTORY') {
      const count = (tgt.metadata['fileCount'] || tgt.lines);
      this.appendTerminalOutput('output', `DIRECTORY STRUCTURE:\n  Contained Files: ${count}\n  Structure: Recursive Tree Validated`);
    }

    this.armState.set('HOLDING');
  }

  public async handleAnalyse(colName?: string): Promise<void> {
    const tgt = this.currentTarget();
    if (!tgt) throw new Error("No target held by arm. Run 'grab sales.csv' first.");

    this.armState.set('ANALYSING');
    const profile = this.datasetProfile();

    if (!profile) {
      // Fallback for non-dataset
      this.appendTerminalOutput('output', `ANALYSIS:\nTarget '${tgt.path}' analyzed. Hash: ${tgt.hash}`);
      this.armState.set('HOLDING');
      return;
    }

    const targetCol = colName || (profile.colNames.find(c => profile.colTypes[c] === 'NUMERIC') || profile.colNames[0]);
    const isNumeric = profile.colTypes[targetCol] === 'NUMERIC';

    if (isNumeric) {
      // Compute accurate statistics & outliers
      const values = profile.previewRows.map(r => Number(r[targetCol])).filter(v => !isNaN(v));
      values.sort((a, b) => a - b);

      const count = values.length;
      const sum = values.reduce((a, b) => a + b, 0);
      const mean = Math.round((sum / count) * 100) / 100;
      const median = values[Math.floor(count / 2)];
      const min = values[0];
      const max = values[count - 1];
      const q25 = values[Math.floor(count * 0.25)];
      const q75 = values[Math.floor(count * 0.75)];
      const iqr = q75 - q25;
      const lowerBound = q25 - 1.5 * iqr;
      const upperBound = q75 + 1.5 * iqr;
      const outliers = values.filter(v => v < lowerBound || v > upperBound);

      const analysis: ColumnAnalysis = {
        column: targetCol,
        type: 'NUMERIC',
        count,
        missing: 0,
        mean,
        median,
        min,
        max,
        q25,
        q75,
        iqr,
        outlierCount: outliers.length,
        outliers: outliers.slice(0, 5),
        outlierBounds: { lower: Math.round(lowerBound), upper: Math.round(upperBound) }
      };

      this.activeColumnAnalysis.set(analysis);

      this.appendTerminalOutput('box', `STATISTICAL ARM ANALYSIS: [${targetCol}]\n\n  Count:     ${count}\n  Mean:      ${mean}\n  Median:    ${median}\n  Min / Max: ${min} / ${max}\n  Q1 (25%):  ${q25}\n  Q3 (75%):  ${q75}\n  IQR:       ${iqr}\n  Outliers:  ${outliers.length} detected (${outliers.slice(0, 3).join(', ')}...)\n  Bounds:    [${Math.round(lowerBound)} .. ${Math.round(upperBound)}]`);
    } else {
      // Categorical summary
      const counts: Record<string, number> = {};
      profile.previewRows.forEach(r => {
        const val = String(r[targetCol]);
        counts[val] = (counts[val] || 0) + 1;
      });

      const analysis: ColumnAnalysis = {
        column: targetCol,
        type: 'CATEGORICAL',
        count: profile.previewRows.length,
        missing: 0,
        distinct: Object.keys(counts).length,
        topFrequencies: counts
      };
      this.activeColumnAnalysis.set(analysis);

      this.appendTerminalOutput('box', `CATEGORICAL ANALYSIS: [${targetCol}]\n  Distinct Values: ${analysis.distinct}\n  Frequencies:\n${Object.entries(counts).map(([k, v]) => `    - ${k}: ${v}`).join('\n')}`);
    }

    this.armState.set('HOLDING');
  }

  // ==========================================
  // ROBOTIC PLANNER & DAG BUILDER
  // ==========================================
  public async handlePlan(): Promise<void> {
    const tgt = this.currentTarget();
    if (!tgt) throw new Error("No target held to plan operations for.");

    this.armState.set('PLANNING');
    this.appendTerminalOutput('output', 'Generating deterministic robotic action graph...');

    const graph: ActionGraph = {
      nodes: {},
      executionOrder: [],
      totalActions: 0,
      targetCount: 1,
      estimatedBytes: tgt.size,
      dangerousOps: 0
    };

    const addNode = (type: ActionNodeType, targetPath: string, params: Record<string, unknown>, deps: string[] = []): ActionNode => {
      const idx = Object.keys(graph.nodes).length + 1;
      const id = `ACT-${String(idx).padStart(3, '0')}`;
      const node: ActionNode = {
        action_id: id,
        type,
        target: targetPath,
        parameters: params,
        dependencies: deps,
        status: 'PENDING',
        duration_ms: 0,
        created_at: new Date().toISOString()
      };
      graph.nodes[id] = node;
      graph.executionOrder.push(id);
      return node;
    };

    if (tgt.type === 'DATASET') {
      const n1 = addNode('SCAN', tgt.path, { desc: `Scan schema for ${tgt.path}` });
      const n2 = addNode('LOCK', tgt.path, { desc: `Lock dataset in memory` }, [n1.action_id]);
      const n3 = addNode('TRANSFORM', tgt.path, { desc: `Filter & calculate statistical vectors` }, [n2.action_id]);
      const n4 = addNode('VERIFY', tgt.path, { desc: `Validate row counts and types` }, [n3.action_id]);
      addNode('RELEASE', tgt.path, { desc: `Release lock` }, [n4.action_id]);
    } else {
      const n1 = addNode('SCAN', tgt.path, { desc: `Scan metadata on ${tgt.path}` });
      const n2 = addNode('VALIDATE', tgt.path, { desc: `Check filesystem permissions` }, [n1.action_id]);
      const n3 = addNode('LOCK', tgt.path, { desc: `Gripper lock` }, [n2.action_id]);
      const n4 = addNode('EXECUTE', tgt.path, { desc: `Execute operation` }, [n3.action_id]);
      const n5 = addNode('VERIFY', tgt.path, { expected_hash: tgt.hash, size: tgt.size }, [n4.action_id]);
      addNode('RELEASE', tgt.path, { desc: `Release target` }, [n5.action_id]);
    }

    graph.totalActions = Object.keys(graph.nodes).length;
    this.currentPlan.set(graph);
    this.armState.set('HOLDING');

    this.appendTerminalOutput('success', `ACTION GRAPH CONSTRUCTED (${graph.totalActions} nodes):\n${graph.executionOrder.map((id, i) => `  ${i + 1}. [${id}] ${graph.nodes[id].type} -> ${String(graph.nodes[id].parameters['desc'] || graph.nodes[id].target)}`).join('\n')}\n✓ Ready for execution or preview.`);
  }

  public async handlePreview(): Promise<void> {
    if (!this.currentPlan()) {
      await this.handlePlan();
    }
    const plan = this.currentPlan()!;
    this.appendTerminalOutput('box', `PLAN PREVIEW\nTotal Actions: ${plan.totalActions}\nTarget Movement: ${this.formatBytes(plan.estimatedBytes)}\nDangerous Ops: ${plan.dangerousOps}\nDependencies: Linear DAG (Topologically Validated)\nType 'execute' to start robotic motion.`);
  }

  // ==========================================
  // EXECUTION ENGINE
  // ==========================================
  public async handleExecute(dryRun = false): Promise<void> {
    if (!this.currentPlan()) {
      await this.handlePlan();
    }
    const plan = this.currentPlan()!;
    const tgt = this.currentTarget();

    if (dryRun) {
      this.appendTerminalOutput('warning', `DRY RUN INITIATED\n${plan.totalActions} actions simulated.\nNo filesystem changes will occur.\nEstimated movement: ${this.formatBytes(plan.estimatedBytes)}\nVerification: PASSED`);
      return;
    }

    this.isExecuting.set(true);
    this.armState.set('EXECUTING');
    this.appendTerminalOutput('box', `ROBOTIC EXECUTION COMMENCED\nExecuting ${plan.totalActions} actions in strict topological sequence...\n`);

    const jobId = `HA-${new Date().getFullYear()}-${String(Math.floor(100000 + Math.random() * 900000))}`;
    const startTime = Date.now();

    const order = plan.executionOrder;
    for (let i = 0; i < order.length; i++) {
      const node = plan.nodes[order[i]];
      node.status = 'RUNNING';
      this.executionProgress.set({
        current: i + 1,
        total: order.length,
        pct: Math.round(((i + 1) / order.length) * 100),
        currentAction: `[${node.action_id}] ${node.type}`
      });

      const nodeStart = Date.now();
      await this.delay(100); // Visual execution tick
      node.status = 'COMPLETED';
      node.duration_ms = Date.now() - nodeStart;

      // Log action to journal
      const actionLog: ActionLog = {
        id: this.actionsLog().length + 1,
        job_id: jobId,
        action_id: node.action_id,
        operation: node.type,
        target: node.target || (tgt?.path || 'unknown'),
        status: 'COMPLETED',
        original_hash: tgt?.hash || 'hash_init',
        result_hash: tgt?.hash || 'hash_final',
        duration_ms: node.duration_ms,
        timestamp: new Date().toISOString()
      };
      this.actionsLog.update(logs => [actionLog, ...logs]);

      this.appendTerminalOutput('output', `  ✓ [${node.action_id}] ${node.type.padEnd(10)} -> ${node.target || 'target'} (${node.duration_ms}ms)`);
    }

    const durationSec = ((Date.now() - startTime) / 1000);
    this.armState.set('VERIFYING');
    await this.delay(80);

    const jobRecord: JobRecord = {
      job_id: jobId,
      target_path: tgt?.path || 'batch',
      target_type: tgt?.type || 'FILE',
      status: 'COMPLETED',
      total_actions: plan.totalActions,
      started_at: new Date(startTime).toISOString(),
      completed_at: new Date().toISOString(),
      duration_sec: Math.round(durationSec * 100) / 100,
      bytes_processed: plan.estimatedBytes
    };
    this.jobsHistory.update(jobs => [jobRecord, ...jobs]);

    // Update telemetry
    this.telemetry.update(t => ({
      ...t,
      jobs: t.jobs + 1,
      operations: t.operations + plan.totalActions,
      total_bytes: t.total_bytes + plan.estimatedBytes,
      timestamp: new Date().toISOString()
    }));

    this.isExecuting.set(false);
    this.armState.set('COMPLETE');
    this.appendTerminalOutput('success', `\nJOB ${jobId} COMPLETE\nAll ${plan.totalActions} operations executed and cryptographically verified.\nDuration: ${jobRecord.duration_sec}s | Throughput: 284 MB/s\nStatus: ✓ COMPLETE`);
  }

  // ==========================================
  // DATA PIPELINE OPERATIONS
  // ==========================================
  public async handleFilter(args: string[]): Promise<void> {
    if (args.length < 3) {
      throw new Error("Syntax: filter <column> <op> <value> (e.g. filter revenue > 1000)");
    }
    const [col, op, ...valParts] = args;
    const valStr = valParts.join(' ').replace(/^['"]|['"]$/g, '');
    const numVal = Number(valStr);

    const profile = this.datasetProfile();
    if (!profile) throw new Error("No dataset currently active in statistical arm.");

    this.armState.set('MOVING');
    this.appendTerminalOutput('output', `Statistical Arm: Filtering rows where ${col} ${op} ${valStr}...`);

    const prevCount = profile.previewRows.length;
    const filteredRows = profile.previewRows.filter(row => {
      const cell = row[col];
      const cellNum = Number(cell);
      const isNumComparison = !isNaN(cellNum) && !isNaN(numVal);

      if (isNumComparison) {
        if (op === '>') return cellNum > numVal;
        if (op === '>=') return cellNum >= numVal;
        if (op === '<') return cellNum < numVal;
        if (op === '<=') return cellNum <= numVal;
        if (op === '==' || op === '=') return cellNum === numVal;
        if (op === '!=') return cellNum !== numVal;
      } else {
        if (op === '==' || op === '=') return String(cell) === valStr;
        if (op === '!=') return String(cell) !== valStr;
      }
      return true;
    });

    profile.previewRows = filteredRows;
    profile.rows = filteredRows.length;
    this.datasetProfile.set({ ...profile });
    this.armState.set('HOLDING');

    this.appendTerminalOutput('success', `FILTER APPLIED: ${prevCount} rows -> ${filteredRows.length} rows remaining.`);
  }

  public async handleGroup(args: string[]): Promise<void> {
    const col = (args[0]?.toLowerCase() === 'by' ? args[1] : args[0]);
    if (!col) throw new Error("Syntax: group by <column> (e.g. group by region)");
    this.appendTerminalOutput('output', `Grouped virtual dataset by column: '${col}'`);
  }

  public async handleSummarise(args: string[]): Promise<void> {
    const col = args[0] || 'revenue';
    const profile = this.datasetProfile();
    if (!profile) throw new Error("No dataset loaded.");

    this.appendTerminalOutput('output', `Summarising dataset on column '${col}'...`);
    const groupCol = profile.colNames.find(c => profile.colTypes[c] === 'TEXT') || profile.colNames[0];

    const grouped: Record<string, number> = {};
    profile.previewRows.forEach(r => {
      const g = String(r[groupCol]);
      const val = Number(r[col]) || 0;
      grouped[g] = (grouped[g] || 0) + val;
    });

    const summaryRows = Object.entries(grouped).map(([grp, sum]) => ({
      [groupCol]: grp,
      [`sum_${col}`]: Math.round(sum)
    }));

    profile.previewRows = summaryRows;
    profile.rows = summaryRows.length;
    profile.colNames = [groupCol, `sum_${col}`];
    profile.colTypes = { [groupCol]: 'TEXT', [`sum_${col}`]: 'NUMERIC' };
    profile.columns = 2;
    this.datasetProfile.set({ ...profile });

    this.appendTerminalOutput('box', `SUMMARISE RESULTS:\n${summaryRows.map(s => `  ${s[groupCol]}: ${s[`sum_${col}`].toLocaleString()}`).join('\n')}`);
  }

  public async handleSort(args: string[]): Promise<void> {
    const col = args[0];
    const isDesc = args.includes('desc') || args.includes('descending');
    const profile = this.datasetProfile();
    if (!profile) throw new Error("No dataset loaded.");

    profile.previewRows.sort((a, b) => {
      const valA = a[col];
      const valB = b[col];
      const numA = Number(valA);
      const numB = Number(valB);

      if (!isNaN(numA) && !isNaN(numB)) {
        return isDesc ? numB - numA : numA - numB;
      }
      return isDesc ? String(valB).localeCompare(String(valA)) : String(valA).localeCompare(String(valB));
    });

    this.datasetProfile.set({ ...profile });
    this.appendTerminalOutput('success', `SORT APPLIED: Sorted by '${col}' ${isDesc ? 'DESCENDING' : 'ASCENDING'}.`);
  }

  public async handleWrite(destPath?: string): Promise<void> {
    if (!destPath) throw new Error("Syntax: write <destination_path> (e.g. write reports/regional_sales.csv)");
    const profile = this.datasetProfile();
    if (!profile) throw new Error("No active data to write.");

    const headers = profile.colNames.join(',');
    const rows = profile.previewRows.map(r => profile.colNames.map(c => r[c]).join(','));
    const content = [headers, ...rows].join('\n');

    this.fs.createVirtualFile(destPath, content, 'text/csv');
    this.appendTerminalOutput('success', `DATASET SAVED: Written ${profile.rows} records to '${destPath}' with verified SHA256.`);
  }

  // ==========================================
  // FILESYSTEM MOVEMENTS & SAFETY
  // ==========================================
  public async handleMove(args: string[]): Promise<void> {
    const tgt = this.currentTarget();
    let src = tgt?.path;
    let dest = args[0];

    if (args.includes('to')) {
      const toIdx = args.indexOf('to');
      dest = args[toIdx + 1];
      if (toIdx > 0) src = args[0];
    }

    if (!src || !dest) throw new Error("Syntax: move to <destination> OR move <source> to <destination>");

    this.validateSafetyPath(dest);
    this.armState.set('MOVING');

    // Create auto snapshot before moving
    if (tgt) {
      await this.createAutoSnapshot(tgt, `Pre-move snapshot before moving to ${dest}`);
    }

    const success = this.fs.moveFile(src, dest);
    if (!success) throw new Error(`Move failed: could not locate source '${src}'`);

    this.armState.set('VERIFYING');
    const newFile = this.fs.getFile(dest);

    if (newFile && tgt) {
      tgt.path = dest;
      tgt.hash = newFile.hash;
      this.currentTarget.set({ ...tgt });
    }

    this.armState.set('HOLDING');
    this.appendTerminalOutput('success', `ROBOTIC MOVE COMPLETE\nSource:      ${src}\nDestination: ${dest}\nSHA256:      ${newFile?.hash}\nStatus:      ✓ Verified & Transferred`);
  }

  public async handleCopy(args: string[]): Promise<void> {
    const tgt = this.currentTarget();
    const dest = args[args.indexOf('to') + 1] || args[0];
    if (!tgt || !dest) throw new Error("Syntax: copy to <destination>");

    this.fs.copyFile(tgt.path, dest);
    this.appendTerminalOutput('success', `COPIED: Target '${tgt.path}' replicated to '${dest}'.`);
  }

  public async handleDelete(force = false): Promise<void> {
    const tgt = this.currentTarget();
    if (!tgt) throw new Error("No target held to delete.");

    this.validateSafetyPath(tgt.path);
    if (!force) {
      await this.createAutoSnapshot(tgt, `Pre-delete safety backup of ${tgt.path}`);
    }

    this.fs.deleteFile(tgt.path);
    await this.handleRelease();
    this.appendTerminalOutput('warning', `TARGET DELETED: '${tgt.path}' removed from disk.\nSnapshot captured: Use 'restore <snapshot_id>' if required.`);
  }

  public async handleFind(pattern: string): Promise<void> {
    if (!pattern) throw new Error("Syntax: find '<pattern>' (e.g. find '*.py')");
    const cleanPattern = pattern.replace(/^['"]|['"]$/g, '');
    const matched = this.fs.getFilesMatchingGlob(cleanPattern);

    this.appendTerminalOutput('box', `DISCOVERED TARGETS (${matched.length} matches):\n${matched.map(m => `  - ${m.path} (${this.formatBytes(m.size)}, ${m.lines} lines)`).join('\n')}`);
  }

  // ==========================================
  // SNAPSHOT & RESTORE
  // ==========================================
  public async handleSnapshot(): Promise<void> {
    const tgt = this.currentTarget();
    if (!tgt) throw new Error("No target currently held to snapshot.");
    const snap = await this.createAutoSnapshot(tgt, 'Manual user snapshot');
    this.appendTerminalOutput('success', `SNAPSHOT STORED: ${snap.snapshot_id} (SHA256: ${snap.hash.slice(0, 16)}...)`);
  }

  public async handleRestore(snapId?: string): Promise<void> {
    if (!snapId) {
      const snaps = this.snapshots();
      if (snaps.length === 0) throw new Error("No snapshots available.");
      this.appendTerminalOutput('box', `AVAILABLE SNAPSHOTS:\n${snaps.map(s => `  - ${s.snapshot_id} -> ${s.original_path} (${s.created_at})`).join('\n')}\nType 'restore <snapshot_id>' to rollback.`);
      return;
    }

    const snap = this.snapshots().find(s => s.snapshot_id === snapId);
    if (!snap) throw new Error(`Snapshot ID '${snapId}' not found.`);

    this.fs.createVirtualFile(snap.original_path, snap.backup_data, 'text/plain');
    this.appendTerminalOutput('success', `RESTORE COMPLETE: Target '${snap.original_path}' restored to snapshot state (${snap.snapshot_id}).`);
  }

  public async handleDiff(): Promise<void> {
    const tgt = this.currentTarget();
    if (!tgt) throw new Error("No target held for diff.");
    this.appendTerminalOutput('output', `DIFF ENGINE: Target '${tgt.path}' integrity verified against initial lock state. No unsanctioned mutations detected.`);
  }

  // ==========================================
  // VERIFY & RELEASE
  // ==========================================
  public async handleVerify(): Promise<void> {
    const tgt = this.currentTarget();
    if (!tgt) throw new Error("No target currently in gripper.");

    this.armState.set('VERIFYING');
    await this.delay(100);

    const vfile = this.fs.getFile(tgt.path);
    if (!vfile || vfile.hash !== tgt.hash) {
      throw new Error(`Verification Failed: Target '${tgt.path}' hash mismatch or target deleted.`);
    }

    this.armState.set('HOLDING');
    this.appendTerminalOutput('success', `VERIFICATION RESULT\nTarget:       ${tgt.path}\nSize Check:   ${vfile.size} bytes (MATCH)\nHash Match:   ${vfile.hash.slice(0, 24)}... (MATCH)\nStatus:       ✓ 100% CRYPTOGRAPHICALLY VERIFIED`);
  }

  public async handleRelease(): Promise<void> {
    this.armState.set('RELEASING');
    this.gripperState.set('RELEASING');
    this.gripForcePct.set(30);

    await this.delay(100);

    this.gripperState.set('RELEASED');
    this.gripForcePct.set(0);
    this.currentTarget.set(null);
    this.currentPlan.set(null);
    this.datasetProfile.set(null);
    this.activeColumnAnalysis.set(null);
    this.armState.set('IDLE');

    this.appendTerminalOutput('output', `TARGET RELEASED: Gripper in home position. Arm state: IDLE.\n`);
  }

  // ==========================================
  // TELEMETRY & SYSTEM DIAGNOSTICS
  // ==========================================
  public async handleTelemetry(): Promise<void> {
    const t = this.telemetry();
    this.appendTerminalOutput('box', `ARM TELEMETRY\n\n  Jobs:            ${t.jobs}\n  Operations:      ${t.operations.toLocaleString()}\n\n  Success Rate:    ${t.success_pct}%\n  Failure Rate:    ${t.error_pct}%\n\n  Data Processed:  ${this.formatBytes(t.total_bytes)}\n  Mean Throughput: ${t.mean_throughput_mb_s} MB/s\n\n  CPU Load:        ${t.cpu_utilization_pct}%\n  RAM Usage:       ${t.memory_usage_mb} MB\n  Active Workers:  ${t.worker_count}`);
  }

  public async handleJobs(): Promise<void> {
    const jobs = this.jobsHistory();
    this.appendTerminalOutput('box', `JOB QUEUE & HISTORY (${jobs.length} records):\n${jobs.map(j => `  [${j.job_id}] ${j.target_path.padEnd(16)} | ${j.status.padEnd(9)} | ${j.total_actions} ops | ${j.duration_sec}s`).join('\n')}`);
  }

  public async handleHistory(): Promise<void> {
    const logs = this.actionsLog().slice(0, 10);
    this.appendTerminalOutput('box', `TRANSACTION JOURNAL (Latest 10 actions):\n${logs.map(l => `  [${l.action_id}] ${l.operation.padEnd(10)} -> ${l.target.padEnd(18)} | ${l.duration_ms}ms | ${l.status}`).join('\n')}`);
  }

  public async handleStatus(): Promise<void> {
    const s = this.armState();
    const g = this.gripperState();
    const f = this.gripForcePct();
    const t = this.currentTarget();

    this.appendTerminalOutput('box', `HARD ARM ENGINE STATUS\n  Arm State:     ${s}\n  Gripper:       ${g} (${f}% force)\n  Target Locked: ${t ? `${t.path} (${t.type})` : 'NONE'}\n  Plan Cached:   ${this.currentPlan() ? 'YES' : 'NO'}\n  Watch Mode:    ${this.isWatching() ? `ACTIVE (${this.watchDirectory()})` : 'INACTIVE'}`);
  }

  public async handleWatch(dirPath?: string): Promise<void> {
    const targetDir = dirPath || 'incoming';
    if (!this.fs.exists(targetDir)) {
      throw new Error(`Watch directory '${targetDir}' does not exist.`);
    }

    this.isWatching.set(true);
    this.watchDirectory.set(targetDir);
    this.appendTerminalOutput('box', `WATCH MODE ENGAGED\nSurveillance active on: '${targetDir}'\nPolling interval: 2000ms | Stability verification: ON\nType 'status' or re-run command to review events.`);
  }

  // ==========================================
  // SCRIPT & WORKFLOW EXECUTION
  // ==========================================
  public async runWorkflowScript(scriptContent: string): Promise<void> {
    this.appendTerminalOutput('box', `EXECUTING .hardarm WORKFLOW SCRIPT...`);
    const lines = scriptContent.split('\n').map(l => l.trim()).filter(l => l && !l.startsWith('#'));

    for (const line of lines) {
      await this.executeCommand(line);
      await this.delay(120);
    }

    this.appendTerminalOutput('success', `WORKFLOW COMPLETED SUCCESSFULLY.`);
  }

  // ==========================================
  // HELPER UTILITIES
  // ==========================================
  private async createAutoSnapshot(target: ArmTarget, reason: string): Promise<Snapshot> {
    const vfile = this.fs.getFile(target.path);
    const snapId = `SNAP-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const snapshot: Snapshot = {
      snapshot_id: snapId,
      original_path: target.path,
      backup_data: vfile ? vfile.content : (target.contentPreview || ''),
      type: target.type,
      size_bytes: target.size,
      hash: target.hash,
      reason,
      created_at: new Date().toISOString()
    };

    this.snapshots.update(s => [snapshot, ...s]);
    return snapshot;
  }

  private loadDatasetProfile(content: string): void {
    const lines = content.split('\n').filter(l => l.trim().length > 0);
    if (lines.length === 0) return;

    const colNames = lines[0].split(',').map(c => c.trim());
    const previewRows: Record<string, string | number | boolean>[] = [];
    const colTypes: Record<string, string> = {};

    colNames.forEach(col => {
      colTypes[col] = 'NUMERIC';
    });

    for (let i = 1; i < lines.length; i++) {
      const parts = lines[i].split(',').map(p => p.trim());
      const row: Record<string, string | number | boolean> = {};
      colNames.forEach((c, ci) => {
        const val = parts[ci] || '';
        row[c] = isNaN(Number(val)) ? val : Number(val);
        if (isNaN(Number(val))) colTypes[c] = 'TEXT';
      });
      previewRows.push(row);
    }

    const numCount = Object.values(colTypes).filter(t => t === 'NUMERIC').length;
    const textCount = Object.values(colTypes).filter(t => t === 'TEXT').length;

    this.datasetProfile.set({
      rows: previewRows.length,
      columns: colNames.length,
      numericCount: numCount,
      textCount,
      logicalCount: 0,
      missingPct: 0.8,
      duplicateRows: 0,
      colNames,
      colTypes,
      previewRows
    });
  }

  private validateSafetyPath(path: string): void {
    const protectedPaths = ['/', '/etc', '/usr', '/System', '/Library', '/bin', '/sbin', '/boot', '/dev'];
    const norm = path.trim().replace(/\/+$/, '');
    for (const prot of protectedPaths) {
      if (norm === prot || norm.startsWith(`${prot}/`)) {
        throw new Error(`CRITICAL SAFETY VIOLATION: Path '${path}' is in protected system root '${prot}'. Operation BLOCKED.`);
      }
    }
  }

  private detectTargetType(path: string): TargetType {
    const ext = path.split('.').pop()?.toLowerCase();
    if (ext === 'csv' || ext === 'tsv' || ext === 'parquet' || ext === 'json') return 'DATASET';
    if (ext === 'log') return 'LOG';
    if (ext === 'py' || ext === 'r' || ext === 'sh' || ext === 'js' || ext === 'ts') return 'SOURCE_CODE';
    if (ext === 'pdf' || ext === 'docx' || ext === 'md') return 'DOCUMENT';
    if (ext === 'txt') return 'TEXT';
    return 'FILE';
  }

  private printTargetAcquiredCard(target: ArmTarget): void {
    const text = `────────────────────────────────────────────────────────────\nTARGET ACQUIRED\n\n  Target:      ${target.path}\n  Object Type: ${target.type}\n  Size:        ${this.formatBytes(target.size)}\n  Lines:       ${target.lines.toLocaleString()}\n  SHA256:      ${target.hash}\n  Status:      ✓ Accessible | ✓ Locked in Gripper\n────────────────────────────────────────────────────────────`;
    this.appendTerminalOutput('box', text);
  }

  private printHelp(): void {
    const helpText = `HARD ARM COMMAND SYNTAX:
  grab <target>               Acquire file, directory, or pattern ('grab sales.csv', 'grab incoming/*.pdf')
  grab-output -- <cmd> [args] Acquire explicit command output ('grab-output -- ls -lah')
  inspect                     Inspect metadata, MIME, hashes, and structure
  analyse [column]            Deep statistical analysis, quantiles, IQR, and outliers
  plan                        Construct discrete robotic action graph
  preview                     Preview planned operations, byte movements, and safety checks
  execute [--dry-run]         Execute action graph with step-by-step verification
  verify                      Perform cryptographic SHA256 integrity verification
  release                     Release virtual gripper lock back to IDLE position
  filter <col> <op> <val>     Filter active dataset (e.g. 'filter revenue > 1000')
  group by <col>              Group active dataset
  summarise <col>             Summarise numeric vectors
  sort <col> [desc]           Sort dataset rows
  write <destination>         Write modified dataset to target destination
  move to <destination>       Move target with pre-flight snapshot and validation
  copy to <destination>       Replicate target
  delete [--force]            Delete target with safety backup
  find "<pattern>"            Search for files matching pattern
  snapshot                    Store explicit target backup
  restore <snapshot_id>       Rollback target to previous snapshot
  telemetry                   Display throughput, CPU, RAM, and operation metrics
  jobs                        Display job queue and completed jobs
  history                     Display transaction journal from SQLite audit log
  watch <dir>                 Continuous directory surveillance mode
  status                      Display robotic arm and gripper state`;
    this.appendTerminalOutput('box', helpText);
  }

  public appendTerminalOutput(type: TerminalOutputLine['type'], text: string): void {
    const line: TerminalOutputLine = {
      id: `line-${Date.now()}-${Math.random()}`,
      type,
      text,
      timestamp: new Date().toLocaleTimeString()
    };
    this.terminalLogs.update(logs => [...logs, line]);
  }

  public formatBytes(bytes: number): string {
    if (!bytes || bytes === 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${units[i]}`;
  }

  private tokenize(line: string): string[] {
    const regex = /[^\s"']+|"([^"]*)"|'([^']*)'/g;
    const tokens: string[] = [];
    let match: RegExpExecArray | null;
    while ((match = regex.exec(line)) !== null) {
      tokens.push(match[1] || match[2] || match[0]);
    }
    return tokens;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
