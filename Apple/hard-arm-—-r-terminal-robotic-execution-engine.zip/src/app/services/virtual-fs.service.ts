import { Injectable } from '@angular/core';
import { VirtualFile } from '../models/hardarm.models';

@Injectable({
  providedIn: 'root',
})
export class VirtualFsService {
  private files = new Map<string, VirtualFile>();

  constructor() {
    this.initDefaultWorkspace();
  }

  public initDefaultWorkspace(): void {
    this.files.clear();

    // 1. sales.csv (Rich dataset with numerical distribution and outliers)
    const salesHeader = 'transaction_id,region,category,revenue,units_sold,cost,customer_rating,is_discounted';
    const regions = ['North', 'South', 'East', 'West'];
    const categories = ['Electronics', 'Hardware', 'Robotics', 'Sensors', 'Hydraulics'];
    const salesRows: string[] = [];

    // Deterministic sales data generator
    for (let i = 1; i <= 250; i++) {
      const reg = regions[(i * 7) % regions.length];
      const cat = categories[(i * 3) % categories.length];
      // Inject some outliers at specific indices
      let rev = Math.round(500 + ((i * 37) % 4500));
      if (i === 42) rev = 28500; // Positive outlier
      if (i === 119) rev = 41200; // Extreme outlier
      if (i === 203) rev = 35; // Low outlier

      const units = Math.max(1, (i % 25) + 1);
      const cost = Math.round(rev * 0.58);
      const rating = (3.5 + ((i % 15) * 0.1)).toFixed(1);
      const disc = (i % 3 === 0) ? 'TRUE' : 'FALSE';

      salesRows.push(`TXN-${10000 + i},${reg},${cat},${rev},${units},${cost},${rating},${disc}`);
    }
    const salesContent = [salesHeader, ...salesRows].join('\n');
    this.createVirtualFile('sales.csv', salesContent, 'text/csv');
    this.createVirtualFile('data/sales.csv', salesContent, 'text/csv');

    // 2. server.log (Log file with error patterns and timestamps)
    const logLines: string[] = [];
    const logSeverities = ['INFO', 'INFO', 'INFO', 'WARN', 'ERROR', 'DEBUG'];
    const logModules = ['KERNEL', 'ROBOTIC_ARM', 'GRIPPER_SERVO', 'AST_PARSER', 'STORAGE_IO', 'SAFETY_GUARD'];
    const logMessages = [
      'Target acquisition channel open',
      'Servo current draw within nominal boundaries (1.42A)',
      'Sub-millisecond topological sort complete',
      'Buffer cache hit ratio at 99.4%',
      'Warning: high I/O burst detected on /data volume',
      'Hydraulic lock verified at 100% clamping force',
      'Error: checksum mismatch in transient socket payload (recovered)',
      'Telemetry beacon heartbeat transmitted successfully'
    ];

    for (let i = 0; i < 400; i++) {
      const hour = String(Math.floor(i / 60)).padStart(2, '0');
      const min = String(i % 60).padStart(2, '0');
      const sec = String((i * 13) % 60).padStart(2, '0');
      const sev = (i % 23 === 0) ? 'ERROR' : (i % 11 === 0 ? 'WARN' : logSeverities[i % logSeverities.length]);
      const mod = logModules[i % logModules.length];
      const msg = logMessages[i % logMessages.length];
      logLines.push(`2026-09-08 ${hour}:${min}:${sec}.214 [${sev}] [${mod}] ${msg} (Event #HA-${9000 + i})`);
    }
    const logContent = logLines.join('\n');
    this.createVirtualFile('server.log', logContent, 'text/plain');
    this.createVirtualFile('logs/server.log', logContent, 'text/plain');

    // 3. config.json
    const configObj = {
      engine: 'HARD ARM R-4.4 Robotic Controller',
      version: '1.0.0',
      hardware_profile: 'Industrial-Virtual-Arm-MKIV',
      safety_controller: {
        strict_mode: true,
        protected_roots: ['/', '/etc', '/usr', '/System', '/Library'],
        max_batch_size: 50000,
        require_confirmation: true
      },
      concurrency: {
        worker_pool_max: 8,
        dynamic_cpu_throttle_pct: 85,
        memory_limit_mb: 4096
      },
      telemetry: {
        persistence_backend: 'SQLite3',
        journal_retention_days: 90,
        streaming_chunk_bytes: 1048576
      }
    };
    this.createVirtualFile('config.json', JSON.stringify(configObj, null, 2), 'application/json');

    // 4. project directory files
    this.createVirtualFile('project/main.py', `# HARD ARM Pipeline Target\nimport sys\nimport os\n\ndef run_pipeline():\n    print("Robotic data intake initiated")\n    return 0\n\nif __name__ == "__main__":\n    sys.exit(run_pipeline())\n`, 'text/x-python');
    this.createVirtualFile('project/utils.py', `def format_bytes(b):\n    return f"{b / (1024**2):.2f} MB"\n`, 'text/x-python');
    this.createVirtualFile('project/README.md', `# Project Alpha\nControlled robotic workspace target.\n`, 'text/markdown');

    // 5. incoming/ folder for batch movements and watch mode
    this.createVirtualFile('incoming/report_q1.pdf', '%PDF-1.4 Q1 Financial and Robotic Telemetry Audit Report', 'application/pdf');
    this.createVirtualFile('incoming/report_q2.pdf', '%PDF-1.4 Q2 Financial and Robotic Telemetry Audit Report', 'application/pdf');
    this.createVirtualFile('incoming/report_q3.pdf', '%PDF-1.4 Q3 Financial and Robotic Telemetry Audit Report', 'application/pdf');
    this.createVirtualFile('incoming/sensor_dump.csv', 'sensor_id,axis_x,axis_y,axis_z,temp_c\nS1,0.02,0.98,0.11,42.5\nS2,0.01,0.99,0.08,41.9\nS3,0.04,0.97,0.14,43.2\n', 'text/csv');
  }

  public getFile(path: string): VirtualFile | undefined {
    const clean = this.normalizePath(path);
    return this.files.get(clean);
  }

  public getAllFiles(): VirtualFile[] {
    return Array.from(this.files.values());
  }

  public getFilesMatchingGlob(pattern: string): VirtualFile[] {
    const cleanPattern = this.normalizePath(pattern);
    const regexStr = cleanPattern
      .replace(/\./g, '\\.')
      .replace(/\*/g, '.*')
      .replace(/\?/g, '.');
    const regex = new RegExp(`^${regexStr}$`, 'i');

    return Array.from(this.files.values()).filter(f => regex.test(f.path) || regex.test(f.name));
  }

  public getFilesInDirectory(dirPath: string): VirtualFile[] {
    const cleanDir = this.normalizePath(dirPath).replace(/\/+$/, '');
    return Array.from(this.files.values()).filter(f => {
      if (cleanDir === '' || cleanDir === '.') return !f.path.includes('/');
      return f.path.startsWith(`${cleanDir}/`);
    });
  }

  public exists(path: string): boolean {
    const clean = this.normalizePath(path);
    if (this.files.has(clean)) return true;
    // Check if directory
    return Array.from(this.files.keys()).some(k => k.startsWith(`${clean}/`));
  }

  public isDirectory(path: string): boolean {
    const clean = this.normalizePath(path);
    return Array.from(this.files.keys()).some(k => k.startsWith(`${clean}/`));
  }

  public createVirtualFile(path: string, content: string, mimeType = 'text/plain'): VirtualFile {
    const clean = this.normalizePath(path);
    const name = clean.split('/').pop() || clean;
    const lines = content.split('\n').length;
    const size = new TextEncoder().encode(content).length;
    const hash = this.simpleSha256(content);

    const vfile: VirtualFile = {
      path: clean,
      name,
      isDir: false,
      size,
      lines,
      content,
      mimeType,
      hash,
      modifiedAt: new Date().toISOString()
    };

    this.files.set(clean, vfile);
    return vfile;
  }

  public moveFile(sourcePath: string, destPath: string): boolean {
    const srcClean = this.normalizePath(sourcePath);
    const destClean = this.normalizePath(destPath);

    const file = this.files.get(srcClean);
    if (!file) return false;

    this.files.delete(srcClean);
    file.path = destClean;
    file.name = destClean.split('/').pop() || destClean;
    file.modifiedAt = new Date().toISOString();
    this.files.set(destClean, file);
    return true;
  }

  public copyFile(sourcePath: string, destPath: string): boolean {
    const srcClean = this.normalizePath(sourcePath);
    const destClean = this.normalizePath(destPath);

    const file = this.files.get(srcClean);
    if (!file) return false;

    this.createVirtualFile(destClean, file.content, file.mimeType);
    return true;
  }

  public deleteFile(path: string): boolean {
    const clean = this.normalizePath(path);
    if (this.files.has(clean)) {
      this.files.delete(clean);
      return true;
    }

    // If directory, delete all children
    let deletedCount = 0;
    for (const k of Array.from(this.files.keys())) {
      if (k === clean || k.startsWith(`${clean}/`)) {
        this.files.delete(k);
        deletedCount++;
      }
    }
    return deletedCount > 0;
  }

  public normalizePath(path: string): string {
    return path.trim().replace(/^\.\//, '').replace(/\\/g, '/');
  }

  private simpleSha256(str: string): string {
    // Deterministic string hash algorithm producing 64-char hex
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57, h3 = 0x67452301, h4 = 0xefcdab89;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
      h3 = Math.imul(h3 ^ (ch << 2), 2246822519);
      h4 = Math.imul(h4 ^ (ch << 3), 3266489917);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822519) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489917);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2654435761) ^ Math.imul(h3 ^ (h3 >>> 13), 1597334677);
    h3 = Math.imul(h3 ^ (h3 >>> 16), 3266489917) ^ Math.imul(h4 ^ (h4 >>> 13), 2246822519);
    h4 = Math.imul(h4 ^ (h4 >>> 16), 1597334677) ^ Math.imul(h1 ^ (h1 >>> 13), 2654435761);

    const toHex = (n: number) => (n >>> 0).toString(16).padStart(8, '0');
    return (toHex(h1) + toHex(h2) + toHex(h3) + toHex(h4) + toHex(h2 ^ h3) + toHex(h1 ^ h4) + toHex(h3 ^ h4) + toHex(h1 ^ h2)).slice(0, 64);
  }
}
