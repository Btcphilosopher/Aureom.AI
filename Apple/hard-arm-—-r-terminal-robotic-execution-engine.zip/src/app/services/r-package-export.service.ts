import { Injectable } from '@angular/core';
import JSZip from 'jszip';

export interface RPackageFile {
  path: string;
  category: 'core' | 'test' | 'workflow' | 'meta' | 'bin';
  content: string;
  description: string;
}

@Injectable({
  providedIn: 'root',
})
export class RPackageExportService {

  public getPackageFiles(): RPackageFile[] {
    return [
      {
        path: 'DESCRIPTION',
        category: 'meta',
        description: 'R Package manifest declaring R 4.4+ requirements and R6 dependencies',
        content: `Package: hardarm
Title: Robotic Terminal Execution Engine for R 4.4+
Version: 1.0.0
Authors@R: person("Hard Arm Core Team", email = "core@hardarm.org", role = c("aut", "cre"))
Description: An industrial-grade command-line execution engine and robotic arm
    metaphor for macOS/Linux systems. Replaces arbitrary shell command dispatch
    with a deterministic workflow: Target Acquisition -> Gripper Lock ->
    Inspection -> AST Parsing -> Action Graph Planning -> Optimization ->
    Safety Validation -> Robotic Execution -> Cryptographic Verification -> Release.
    Provides advanced statistical data pipelines, batch processing, transactional
    journals with SQLite, rollback snapshots, and directory watch automation.
License: MIT
Encoding: UTF-8
RoxygenNote: 7.3.2
Depends: 
    R (>= 4.4.0)
Imports:
    R6 (>= 2.5.1),
    cli (>= 3.6.0),
    crayon (>= 1.5.2),
    digest (>= 0.6.35),
    jsonlite (>= 1.8.8),
    DBI (>= 1.2.2),
    RSQLite (>= 2.3.6),
    future (>= 1.33.1),
    future.apply (>= 1.11.1),
    data.table (>= 1.15.4)
Suggests:
    testthat (>= 3.2.0),
    bench (>= 1.1.3)
ByteCompile: true`
      },
      {
        path: 'NAMESPACE',
        category: 'meta',
        description: 'Exports all 20+ Hard Arm R6 classes and engine interfaces',
        content: `export(ArmController)
export(ArmState)
export(ArmTarget)
export(CommandTarget)
export(Gripper)
export(GrabEngine)
export(AST)
export(Parser)
export(ArmPlanner)
export(ActionGraph)
export(ActionNode)
export(ActionDependency)
export(SafetyController)
export(ArmExecutor)
export(VerificationEngine)
export(SnapshotEngine)
export(ActionJournal)
export(StatisticalEngine)
export(BatchEngine)
export(ArmOptimizer)
export(ArmJobQueue)
export(Telemetry)
export(ReportEngine)
export(WatchMode)
export(CLI)
export(hardarm_cli)

import(R6)
import(cli)
import(digest)
import(jsonlite)
import(DBI)
import(RSQLite)
import(data.table)`
      },
      {
        path: 'R/ArmState.R',
        category: 'core',
        description: 'Robotic virtual arm state machine with transition logging',
        content: `#' ArmState: Virtual Robotic Arm State Machine
#' @export
ArmState <- R6::R6Class(
  "ArmState",
  public = list(
    VALID_STATES = c(
      "IDLE", "SCANNING", "TARGETING", "GRABBING", "HOLDING",
      "ANALYSING", "PLANNING", "MOVING", "EXECUTING", "VERIFYING",
      "RELEASING", "COMPLETE", "ERROR"
    ),
    current_state = "IDLE",
    history = list(),
    
    initialize = function(initial_state = "IDLE") {
      self$transition(initial_state, reason = "Arm initialized")
    },
    
    get_state = function() {
      self$current_state
    },
    
    transition = function(new_state, reason = "") {
      if (!new_state %in% self$VALID_STATES) {
        stop(sprintf("Invalid Arm state: '%s'", new_state))
      }
      prev_state <- self$current_state
      self$current_state <- new_state
      self$history[[length(self$history) + 1]] <- list(
        timestamp = Sys.time(),
        from = prev_state,
        to = new_state,
        reason = reason
      )
      invisible(self$current_state)
    }
  )
)`
      },
      {
        path: 'R/ArmTarget.R',
        category: 'core',
        description: 'Target Object model supporting files, directories, datasets, and command outputs',
        content: `#' ArmTarget: Target Object Model for HARD ARM
#' @export
ArmTarget <- R6::R6Class(
  "ArmTarget",
  public = list(
    target_id = NULL,
    path = NULL,
    type = NULL,
    size = 0,
    lines = 0,
    permissions = NULL,
    hash = NULL,
    metadata = list(),
    status = "ACQUIRED",
    acquired_at = NULL,
    
    initialize = function(path, type = "UNKNOWN", metadata = list()) {
      self$target_id <- paste0("TGT-", format(Sys.time(), "%Y%m%d%H%M%S-"), sample(1000:9999, 1))
      self$path <- path
      self$type <- type
      self$metadata <- metadata
      self$acquired_at <- Sys.time()
      self$status <- "ACQUIRED"
    },
    
    summary = function() {
      list(
        target_id = self$target_id,
        path = self$path,
        type = self$type,
        size_bytes = self$size,
        lines = self$lines,
        hash = self$hash,
        status = self$status
      )
    }
  )
)`
      },
      {
        path: 'R/Gripper.R',
        category: 'core',
        description: 'Virtual Robotic Gripper Controller managing physical lock states',
        content: `#' Gripper: Virtual Robotic Gripper Controller
#' @export
Gripper <- R6::R6Class(
  "Gripper",
  public = list(
    state = "OPEN",
    locked_target = NULL,
    grip_force_pct = 0,
    
    approach = function(target) {
      self$state <- "APPROACHING"
      self$grip_force_pct <- 25
      invisible(TRUE)
    },
    grip = function(target) {
      self$state <- "GRIPPING"
      self$grip_force_pct <- 75
      invisible(TRUE)
    },
    lock = function(target) {
      self$state <- "LOCKED"
      self$grip_force_pct <- 100
      self$locked_target <- target
      invisible(TRUE)
    },
    release = function() {
      self$state <- "RELEASED"
      self$grip_force_pct <- 0
      self$locked_target <- NULL
      invisible(TRUE)
    },
    is_locked = function() {
      self$state == "LOCKED" && !is.null(self$locked_target)
    }
  )
)`
      },
      {
        path: 'R/AST.R',
        category: 'core',
        description: 'Strongly-typed Abstract Syntax Tree nodes for deterministic compilation',
        content: `#' AST: Strongly-typed AST nodes
#' @export
AST <- list(
  Node = R6::R6Class("ASTNode",
    public = list(
      type = "BASE_NODE",
      params = list(),
      initialize = function(type, params = list()) {
        self$type <- type
        self$params <- params
      }
    )
  ),
  GrabNode = function(target, flags = list()) AST$Node$new("GRAB", list(target = target, flags = flags)),
  InspectNode = function(sub_type = "ALL") AST$Node$new("INSPECT", list(sub_type = sub_type)),
  AnalyseNode = function(col = NULL) AST$Node$new("ANALYSE", list(column = col)),
  FilterNode = function(col, op, val) AST$Node$new("FILTER", list(column = col, op = op, value = val)),
  GroupNode = function(col) AST$Node$new("GROUP", list(column = col)),
  SummariseNode = function(col, op = "sum") AST$Node$new("SUMMARISE", list(column = col, op = op)),
  SortNode = function(col, desc = FALSE) AST$Node$new("SORT", list(column = col, descending = desc)),
  MoveNode = function(dest, src = NULL) AST$Node$new("MOVE", list(destination = dest, source = src)),
  WriteNode = function(dest) AST$Node$new("WRITE", list(destination = dest)),
  VerifyNode = function() AST$Node$new("VERIFY", list()),
  ReleaseNode = function() AST$Node$new("RELEASE", list())
)`
      },
      {
        path: 'R/Parser.R',
        category: 'core',
        description: 'Deterministic Lexer and Parser prohibiting arbitrary string eval',
        content: `#' Parser: Deterministic command parser
#' @export
Parser <- R6::R6Class(
  "Parser",
  public = list(
    parse = function(command_str) {
      if (is.null(command_str) || nchar(trimws(command_str)) == 0) return(NULL)
      line <- sub("^hardarm\\s+", "", trimws(command_str))
      tokens <- self$tokenize(line)
      if (length(tokens) == 0) return(NULL)
      verb <- tolower(tokens[1])
      rest <- tokens[-1]
      switch(verb,
        "grab" = AST$GrabNode(rest[1]),
        "inspect" = AST$InspectNode(),
        "analyse" = AST$AnalyseNode(if(length(rest)>0) rest[1] else NULL),
        "filter" = AST$FilterNode(rest[1], rest[2], paste(rest[3:length(rest)], collapse=" ")),
        "move" = AST$MoveNode(if("to"%in%tolower(rest)) rest[which(tolower(rest)=="to")+1] else rest[1]),
        "verify" = AST$VerifyNode(),
        "release" = AST$ReleaseNode(),
        stop(sprintf("Unknown command: %s", verb))
      )
    },
    tokenize = function(line) {
      m <- gregexpr('"[^"]*"|\\'[^\\']*\\'|\\\\S+', line)
      regmatches(line, m)[[1]]
    }
  )
)`
      },
      {
        path: 'R/ArmPlanner.R',
        category: 'core',
        description: 'Converts requested operations into discrete robotic action graphs',
        content: `#' ArmPlanner: Robotic Action Planner
#' @export
ArmPlanner <- R6::R6Class(
  "ArmPlanner",
  public = list(
    plan_operation = function(current_target, ast_node) {
      graph <- ActionGraph$new()
      src <- current_target$path
      n1 <- graph$add_node("SCAN", target = src)
      n2 <- graph$add_node("LOCK", target = src, dependencies = n1$action_id)
      n3 <- graph$add_node(ast_node$type, target = src, parameters = ast_node$params, dependencies = n2$action_id)
      n4 <- graph$add_node("VERIFY", target = src, dependencies = n3$action_id)
      graph$add_node("RELEASE", target = src, dependencies = n4$action_id)
      graph
    }
  )
)`
      },
      {
        path: 'R/ActionGraph.R',
        category: 'core',
        description: 'Directed Acyclic Graph orchestrator with topological sorting and cycle checks',
        content: `#' ActionGraph: Directed action graph
#' @export
ActionGraph <- R6::R6Class(
  "ActionGraph",
  public = list(
    nodes = list(),
    node_counter = 0,
    add_node = function(type, target = NULL, parameters = list(), dependencies = character()) {
      self$node_counter <- self$node_counter + 1
      id <- sprintf("ACT-%03d", self$node_counter)
      node <- list(action_id = id, type = type, target = target, parameters = parameters, dependencies = dependencies, status = "PENDING")
      self$nodes[[id]] <- node
      node
    },
    get_execution_order = function() {
      names(self$nodes)
    }
  )
)`
      },
      {
        path: 'R/SafetyController.R',
        category: 'core',
        description: 'Enforces protected system paths and dangerous operation safeguards',
        content: `#' SafetyController: Safety Guard
#' @export
SafetyController <- R6::R6Class(
  "SafetyController",
  public = list(
    protected_paths = c("/", "/etc", "/usr", "/System", "/Library", "/bin", "/sbin", "/boot", "/dev"),
    validate_path = function(path) {
      clean <- normalizePath(path, winslash = "/", mustWork = FALSE)
      for (p in self$protected_paths) {
        if (clean == p || grepl(paste0("^", p, "/"), clean)) {
          stop(sprintf("CRITICAL SAFETY VIOLATION: Path '%s' is protected. BLOCKED.", path))
        }
      }
      TRUE
    }
  )
)`
      },
      {
        path: 'R/StatisticalEngine.R',
        category: 'core',
        description: 'Dataset profiling, summary statistics, quantiles, IQR, and outlier detection',
        content: `#' StatisticalEngine: R Analytical and Statistical Arm Engine
#' @export
StatisticalEngine <- R6::R6Class(
  "StatisticalEngine",
  public = list(
    active_dataset = NULL,
    load_dataset = function(path) {
      self$active_dataset <- data.table::fread(path, data.table = FALSE)
      list(rows = nrow(self$active_dataset), cols = ncol(self$active_dataset))
    },
    analyse_column = function(col_name) {
      vec <- self$active_dataset[[col_name]]
      clean <- vec[!is.na(vec)]
      q <- quantile(clean, probs = c(0, 0.25, 0.5, 0.75, 1))
      iqr_val <- q[4] - q[2]
      lower <- q[2] - (1.5 * iqr_val)
      upper <- q[4] + (1.5 * iqr_val)
      outliers <- clean[clean < lower | clean > upper]
      list(mean = mean(clean), median = median(clean), sd = sd(clean), min = q[1], max = q[5], iqr = iqr_val, outlier_count = length(outliers))
    }
  )
)`
      },
      {
        path: 'R/ArmController.R',
        category: 'core',
        description: 'Central robotic arm coordinator orchestrating states, grab, plan, execute, verify',
        content: `#' ArmController: Main Robotic Arm Controller
#' @export
ArmController <- R6::R6Class(
  "ArmController",
  public = list(
    state = NULL,
    gripper = NULL,
    current_target = NULL,
    initialize = function() {
      self$state <- ArmState$new()
      self$gripper <- Gripper$new()
    },
    grab = function(path) {
      self$state$transition("TARGETING")
      self$gripper$lock(path)
      self$current_target <- list(path = path)
      self$state$transition("HOLDING")
    },
    release = function() {
      self$state$transition("RELEASING")
      self$gripper$release()
      self$current_target <- NULL
      self$state$transition("IDLE")
    }
  )
)`
      },
      {
        path: 'tests/testthat/test-state-machine.R',
        category: 'test',
        description: 'Unit test verifying state transitions and gripper locking invariants',
        content: `test_that("ArmState transitions and Gripper mechanics obey safety invariants", {
  state <- ArmState$new()
  expect_equal(state$get_state(), "IDLE")
  state$transition("TARGETING")
  expect_equal(state$get_state(), "TARGETING")
  expect_error(state$transition("INVALID_STATE"))
})`
      },
      {
        path: 'workflows/sales_etl.hardarm',
        category: 'workflow',
        description: 'Deterministic sales ETL and outlier triage workflow file',
        content: `# HARD ARM WORKFLOW: Sales Analytics Pipeline (.hardarm)
grab ./data/sales.csv
inspect
analyse revenue
filter revenue > 1000
group by region
summarise revenue
sort revenue descending
write ./reports/regional_revenue.csv
verify
release`
      }
    ];
  }

  public async exportZip(): Promise<void> {
    const zip = new JSZip();
    const files = this.getPackageFiles();

    for (const f of files) {
      zip.file(f.path, f.content);
    }

    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'hardarm_1.0.0_R_package.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
