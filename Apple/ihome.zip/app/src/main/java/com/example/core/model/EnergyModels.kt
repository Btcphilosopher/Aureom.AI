package com.example.core.model

enum class FlowDirection {
    CHARGING_IMPORTING,
    DISCHARGING_EXPORTING,
    IDLE
}

data class PowerFlowState(
    val solarKw: Double = 3.4,
    val homeLoadKw: Double = 1.8,
    val batteryKw: Double = 2.1,
    val batteryDirection: FlowDirection = FlowDirection.CHARGING_IMPORTING, // Charging or Discharging
    val gridKw: Double = 1.6,
    val gridDirection: FlowDirection = FlowDirection.DISCHARGING_EXPORTING, // Exporting surplus
    val evKw: Double = 7.4,
    val hvacKw: Double = 1.2,
    val waterHeatingKw: Double = 0.8,
    val appliancesKw: Double = 0.6,
    val lightingKw: Double = 0.3
)

data class EnergyStats(
    val todaySolarKwh: Double = 18.6,
    val todayConsumptionKwh: Double = 24.2,
    val todayGridImportKwh: Double = 9.4,
    val todayGridExportKwh: Double = 3.8,
    val todayEvKwh: Double = 12.1,
    val todayHeatingKwh: Double = 6.3,
    val costTodayPounds: Double = 3.84,
    val costForecastPounds: Double = 4.12,
    val weekKwh: Double = 168.4,
    val monthKwh: Double = 684.2,
    val peakDemandKw: Double = 8.4,
    val peakThresholdKw: Double = 10.0,
    val baseloadWatts: Double = 320.0,
    val selfConsumptionPct: Int = 74,
    val selfSufficiencyPct: Int = 68,
    val homeEnergyScore: Int = 87
)

data class HomeMeterState(
    val voltageV: Double = 230.2,
    val currentA: Double = 7.8,
    val activePowerKw: Double = 1.72,
    val powerFactor: Double = 0.98,
    val frequencyHz: Double = 50.01,
    val totalImportKwh: Double = 14208.5,
    val totalExportKwh: Double = 6821.3,
    val phaseCount: Int = 1
)

data class SolarArrayState(
    val currentGenerationKw: Double = 3.4,
    val peakCapacityKw: Double = 8.4,
    val todayGenerationKwh: Double = 18.6,
    val forecastGenerationKwh: Double = 22.1,
    val selfConsumptionPct: Int = 71,
    val panelEfficiencyPct: Double = 21.4,
    val inverterEfficiencyPct: Double = 97.8
)

enum class BatteryMode {
    AUTO,
    MAX_SELF_CONSUMPTION,
    GRID_CHARGE,
    BACKUP,
    ECONOMIC,
    CARBON_AWARE
}

data class BatteryState(
    val socPct: Int = 74,
    val availableKwh: Double = 10.0,
    val capacityKwh: Double = 13.5,
    val powerKw: Double = 2.1, // positive if charging, negative if discharging
    val voltageV: Double = 402.0,
    val currentA: Double = 5.2,
    val temperatureC: Double = 23.4,
    val healthPct: Int = 99,
    val cycleCount: Int = 184,
    val activeMode: BatteryMode = BatteryMode.MAX_SELF_CONSUMPTION,
    val isOutageActive: Boolean = false,
    val backupRuntimeHours: Double = 11.7 // e.g. 11h 42m
)

enum class EVSmartMode {
    FAST,
    SCHEDULED,
    CHEAPEST,
    CLEANEST,
    SOLAR_SURPLUS,
    BALANCED
}

enum class V2HStatus {
    AVAILABLE,
    IN_USE,
    NOT_SUPPORTED,
    UNKNOWN
}

data class EVChargingState(
    val vehicleName: String = "BMW iX xDrive50",
    val socPct: Int = 68,
    val targetSocPct: Int = 90,
    val isCharging: Boolean = true,
    val isPluggedIn: Boolean = true,
    val chargingRateKw: Double = 7.4,
    val maxChargerKw: Double = 11.0,
    val readyTime: String = "07:00",
    val departureTime: String = "07:30",
    val activeMode: EVSmartMode = EVSmartMode.CHEAPEST,
    val v2hStatus: V2HStatus = V2HStatus.AVAILABLE,
    val estimatedEnergyNeededKwh: Double = 21.4,
    val estimatedCostPounds: Double = 2.14,
    val recommendedWindow: String = "01:30 – 04:45 (Off-peak @ 7.5p/kWh)"
)

data class EnergyOptimizationRecommendation(
    val id: String,
    val title: String,
    val actionText: String,
    val estimatedSavingPounds: Double,
    val reason: String,
    val carbonBenefit: String,
    val deadlineOrConstraint: String,
    val category: String, // EV, Battery, Appliance, Heating
    val isAccepted: Boolean = false
)

data class TariffRate(
    val supplier: String = "Octopus Agile / Flux",
    val currentRatePence: Double = 14.8,
    val offPeakRatePence: Double = 7.5,
    val peakRatePence: Double = 28.4,
    val exportRatePence: Double = 15.0,
    val standingChargePencePerDay: Double = 45.0,
    val offPeakWindow: String = "00:30 – 04:30",
    val peakWindow: String = "16:00 – 19:00"
)

data class CarbonIntensityState(
    val currentGCo2PerKwh: Int = 142,
    val rating: String = "LOW",
    val tonightForecast: String = "Very Low (Wind surplus)",
    val tomorrowForecast: String = "Low (Solar & Nuclear base)"
)

data class WaterSystemState(
    val cylinderTempC: Double = 54.0,
    val targetTempC: Double = 58.0,
    val isHeating: Boolean = false,
    val heatingType: String = "Heat Pump Water Cylinder (250 L)",
    val nextOptimisationWindow: String = "04:30 (Pre-heat on low tariff)",
    val mainValveOpen: Boolean = true,
    val flowRateLpm: Double = 0.0,
    val waterPressureBar: Double = 3.2,
    val leakDetected: Boolean = false,
    val lastTestDate: String = "Today, 06:00"
)

data class SmartAppliance(
    val id: String,
    val name: String,
    val type: String,
    val powerWatts: Double,
    val state: String, // Ready, Running, Paused, Done
    val programme: String,
    val remainingMinutes: Int,
    val suggestedStartTime: String? = null,
    val loadShiftSavingPounds: Double = 0.0,
    val priority: LoadPriority = LoadPriority.DEFERRABLE
)
