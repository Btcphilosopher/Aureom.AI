package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.theme.*

@Composable
fun AutomationsScreen(
    automations: List<AutomationRule>,
    scenes: List<SceneItem>,
    activityLogs: List<ActivityTimelineItem>,
    onToggleAutomation: (AutomationId) -> Unit,
    onRunScene: (SceneId) -> Unit,
    modifier: Modifier = Modifier
) {
    var simulatedAutomation by remember { mutableStateOf<AutomationRule?>(null) }
    var simulationFeedback by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppleDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "DETERMINISTIC LOGIC & SCENES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )
                Text(
                    text = "iAutomation",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppleTextPrimary
                )
            }
        }

        // Scenes Gallery
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "WHOLE-HOME SCENES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    scenes.forEach { scene ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (scene.isActive) AppleElectricBlue.copy(alpha = 0.15f) else AppleDarkSurfaceElevated)
                                .border(1.dp, if (scene.isActive) AppleElectricBlue else AppleBorder, RoundedCornerShape(12.dp))
                                .clickable { onRunScene(scene.id) }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = scene.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (scene.isActive) AppleElectricBlue else AppleTextPrimary
                                )
                                Text(
                                    text = scene.description,
                                    fontSize = 12.sp,
                                    color = AppleTextSecondary
                                )
                                Text(
                                    text = "Affects: ${scene.affectedSubsystems.joinToString(", ")}",
                                    fontSize = 10.sp,
                                    color = AppleTextTertiary
                                )
                            }

                            Button(
                                onClick = { onRunScene(scene.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (scene.isActive) AppleElectricBlue else AppleDarkSurfaceHighlight
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text(if (scene.isActive) "ACTIVE" else "EXECUTE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Automation Simulator Modal/Box
        if (simulatedAutomation != null) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(AppleDarkSurfaceHighlight)
                        .border(1.5.dp, AppleSolarAmber, RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Rounded.Science, contentDescription = null, tint = AppleSolarAmber)
                            Text(
                                text = "AUTOMATION DRY-RUN SIMULATOR",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleSolarAmber
                            )
                        }

                        IconButton(onClick = {
                            simulatedAutomation = null
                            simulationFeedback = null
                        }) {
                            Icon(imageVector = Icons.Rounded.Close, contentDescription = "Close", tint = AppleTextSecondary)
                        }
                    }

                    Text(
                        text = "Rule: ${simulatedAutomation?.name}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppleTextPrimary
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(AppleDarkSurface)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(simulatedAutomation?.triggerSummary ?: "", fontSize = 11.sp, color = AppleElectricBlue)
                        Text(simulatedAutomation?.conditionSummary ?: "", fontSize = 11.sp, color = AppleWaterCyan)
                        Text(simulatedAutomation?.actionSummary ?: "", fontSize = 11.sp, color = AppleEnergyGreen)
                    }

                    if (simulationFeedback != null) {
                        Text(
                            text = simulationFeedback!!,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = AppleEnergyGreen
                        )
                    } else {
                        Button(
                            onClick = {
                                simulationFeedback = "✓ DRY-RUN SUCCESS: No hardware locks conflicted. Cooldown respected. Estimated energy impact: neutral."
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleSolarAmber),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("RUN SAFETY CHECK & DRY RUN", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Active Automations List
        item {
            Text(
                text = "ACTIVE AUTOMATION RULES",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                color = AppleTextSecondary
            )
        }

        items(automations) { auto ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = auto.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppleTextPrimary
                        )
                        Text(
                            text = "Category: ${auto.category} · Last run: ${auto.lastRunTime}",
                            fontSize = 11.sp,
                            color = AppleTextSecondary
                        )
                    }

                    Switch(
                        checked = auto.isEnabled,
                        onCheckedChange = { onToggleAutomation(auto.id) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = AppleElectricBlue,
                            uncheckedThumbColor = AppleTextSecondary,
                            uncheckedTrackColor = AppleDarkSurfaceHighlight
                        ),
                        modifier = Modifier.testTag("auto_switch_${auto.id.value}")
                    )
                }

                // Logic steps
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(AppleDarkSurfaceElevated)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(text = auto.triggerSummary, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = AppleElectricBlue)
                    Text(text = auto.conditionSummary, fontSize = 11.sp, color = AppleTextSecondary)
                    Text(text = auto.actionSummary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = AppleEnergyGreen)
                }

                // Simulate Test Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Test in Simulator →",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppleSolarAmber,
                        modifier = Modifier
                            .clickable {
                                simulatedAutomation = auto
                                simulationFeedback = null
                            }
                            .padding(4.dp)
                    )
                }
            }
        }

        // Home Activity Timeline
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "HOME ACTIVITY & AUDIT TIMELINE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                activityLogs.forEach { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(AppleDarkSurfaceElevated)
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = log.timestamp,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppleTextSecondary
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = log.title,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = when (log.severity) {
                                    SystemSeverity.CRITICAL -> AppleCriticalRed
                                    SystemSeverity.WARNING -> AppleSolarAmber
                                    SystemSeverity.NOTICE -> AppleElectricBlue
                                    SystemSeverity.INFO -> AppleTextPrimary
                                }
                            )
                            Text(
                                text = log.detail,
                                fontSize = 11.sp,
                                color = AppleTextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(AppleDarkSurfaceHighlight)
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = log.subsystem.uppercase(),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleTextTertiary
                            )
                        }
                    }
                }
            }
        }
    }
}
