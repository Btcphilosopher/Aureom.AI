package com.example.data.repository

import com.example.core.database.AppDatabase
import com.example.core.model.*
import com.example.core.simulation.DigitalTwinEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeRepository(
    private val database: AppDatabase,
    private val twinEngine: DigitalTwinEngine,
    private val scope: CoroutineScope
) {
    val simTime = twinEngine.simTime
    val powerFlow = twinEngine.powerFlow
    val energyStats = twinEngine.energyStats
    val meter = twinEngine.meter
    val solar = twinEngine.solar
    val battery = twinEngine.battery
    val ev = twinEngine.ev
    val security = twinEngine.security
    val water = twinEngine.water
    val carbon = twinEngine.carbon
    val tariff = twinEngine.tariff
    val appliances = twinEngine.appliances
    val recommendations = twinEngine.recommendations
    val isOutageSimulated = twinEngine.isOutageSimulated
    val isLeakSimulated = twinEngine.isLeakSimulated
    val presence = twinEngine.presence

    private val _rooms = MutableStateFlow<List<Room>>(emptyList())
    val rooms: StateFlow<List<Room>> = _rooms.asStateFlow()

    private val _devices = MutableStateFlow<List<Device>>(emptyList())
    val devices: StateFlow<List<Device>> = _devices.asStateFlow()

    private val _scenes = MutableStateFlow<List<SceneItem>>(emptyList())
    val scenes: StateFlow<List<SceneItem>> = _scenes.asStateFlow()

    private val _automations = MutableStateFlow<List<AutomationRule>>(emptyList())
    val automations: StateFlow<List<AutomationRule>> = _automations.asStateFlow()

    private val _activityLogs = MutableStateFlow<List<ActivityTimelineItem>>(emptyList())
    val activityLogs: StateFlow<List<ActivityTimelineItem>> = _activityLogs.asStateFlow()

    private val _cameras = MutableStateFlow<List<CameraFeed>>(emptyList())
    val cameras: StateFlow<List<CameraFeed>> = _cameras.asStateFlow()

    private val _threadStatus = MutableStateFlow(ThreadNetworkStatus())
    val threadStatus: StateFlow<ThreadNetworkStatus> = _threadStatus.asStateFlow()

    private val _homeHub = MutableStateFlow(HomeHubStatus())
    val homeHub: StateFlow<HomeHubStatus> = _homeHub.asStateFlow()

    private val _matterNodes = MutableStateFlow<List<MatterNodeState>>(emptyList())
    val matterNodes: StateFlow<List<MatterNodeState>> = _matterNodes.asStateFlow()

    init {
        initializeInitialData()
    }

    private fun initializeInitialData() {
        val initialRooms = listOf(
            Room(
                id = RoomId("room_living"),
                floorName = "Ground Floor",
                name = "Living Room",
                targetTempC = 21.0,
                currentTempC = 21.4,
                humidityPct = 48,
                co2Ppm = 610,
                pm25 = 4.0,
                airQualityRating = "EXCELLENT",
                heatingActive = true,
                coolingActive = false,
                estimatedHeatingMinutes = 18,
                lightsCountOn = 2,
                totalLightsCount = 3,
                blindsOpenPct = 60,
                activeMediaTitle = "Apple TV 4K · Ambient Acoustics"
            ),
            Room(
                id = RoomId("room_kitchen"),
                floorName = "Ground Floor",
                name = "Kitchen",
                targetTempC = 20.5,
                currentTempC = 20.8,
                humidityPct = 52,
                co2Ppm = 640,
                pm25 = 6.2,
                airQualityRating = "GOOD",
                heatingActive = false,
                coolingActive = false,
                estimatedHeatingMinutes = 0,
                lightsCountOn = 1,
                totalLightsCount = 2,
                blindsOpenPct = 100,
                activeMediaTitle = null
            ),
            Room(
                id = RoomId("room_bedroom"),
                floorName = "First Floor",
                name = "Primary Bedroom",
                targetTempC = 19.5,
                currentTempC = 19.8,
                humidityPct = 45,
                co2Ppm = 580,
                pm25 = 3.5,
                airQualityRating = "EXCELLENT",
                heatingActive = false,
                coolingActive = false,
                estimatedHeatingMinutes = 0,
                lightsCountOn = 0,
                totalLightsCount = 2,
                blindsOpenPct = 20,
                activeMediaTitle = null
            ),
            Room(
                id = RoomId("room_office"),
                floorName = "First Floor",
                name = "Office",
                targetTempC = 21.0,
                currentTempC = 20.9,
                humidityPct = 46,
                co2Ppm = 595,
                pm25 = 3.8,
                airQualityRating = "EXCELLENT",
                heatingActive = true,
                coolingActive = false,
                estimatedHeatingMinutes = 12,
                lightsCountOn = 2,
                totalLightsCount = 2,
                blindsOpenPct = 80,
                activeMediaTitle = "Studio Monitors · Focus Flow"
            ),
            Room(
                id = RoomId("room_garage"),
                floorName = "Ground Floor",
                name = "Garage & EV Bay",
                targetTempC = 16.0,
                currentTempC = 16.4,
                humidityPct = 58,
                co2Ppm = 490,
                pm25 = 5.0,
                airQualityRating = "GOOD",
                heatingActive = false,
                coolingActive = false,
                estimatedHeatingMinutes = 0,
                lightsCountOn = 1,
                totalLightsCount = 1,
                blindsOpenPct = 0,
                activeMediaTitle = null
            )
        )
        _rooms.value = initialRooms

        val initialDevices = listOf(
            // Living Room
            Device(
                id = DeviceId("dev_lr_ceiling"),
                roomId = RoomId("room_living"),
                name = "Living Room Ceiling Lights",
                category = DeviceCategory.LIGHT,
                capabilities = setOf(DeviceCapability.POWER_SWITCH, DeviceCapability.BRIGHTNESS, DeviceCapability.COLOR_TEMPERATURE),
                isOn = true,
                brightnessPct = 72,
                colorTempK = 3000,
                powerDrawWatts = 36.0
            ),
            Device(
                id = DeviceId("dev_lr_lamp"),
                roomId = RoomId("room_living"),
                name = "Reading Floor Lamp",
                category = DeviceCategory.LIGHT,
                capabilities = setOf(DeviceCapability.POWER_SWITCH, DeviceCapability.BRIGHTNESS, DeviceCapability.COLOR_TEMPERATURE),
                isOn = false,
                brightnessPct = 50,
                colorTempK = 2700,
                powerDrawWatts = 0.0
            ),
            Device(
                id = DeviceId("dev_lr_wall"),
                roomId = RoomId("room_living"),
                name = "Architectural Wall Sconces",
                category = DeviceCategory.LIGHT,
                capabilities = setOf(DeviceCapability.POWER_SWITCH, DeviceCapability.BRIGHTNESS),
                isOn = true,
                brightnessPct = 40,
                colorTempK = 2700,
                powerDrawWatts = 18.0
            ),
            Device(
                id = DeviceId("dev_lr_blinds"),
                roomId = RoomId("room_living"),
                name = "South Garden Blinds",
                category = DeviceCategory.BLINDS,
                capabilities = setOf(DeviceCapability.BLINDS_POSITION),
                positionPct = 60
            ),
            Device(
                id = DeviceId("dev_lr_thermostat"),
                roomId = RoomId("room_living"),
                name = "Living Room Underfloor HVAC",
                category = DeviceCategory.CLIMATE,
                capabilities = setOf(DeviceCapability.THERMOSTAT_CONTROL),
                isOn = true,
                targetTempC = 21.0,
                currentTempC = 21.4,
                powerDrawWatts = 420.0
            ),

            // Kitchen
            Device(
                id = DeviceId("dev_kitch_pendant"),
                roomId = RoomId("room_kitchen"),
                name = "Kitchen Island Pendants",
                category = DeviceCategory.LIGHT,
                capabilities = setOf(DeviceCapability.POWER_SWITCH, DeviceCapability.BRIGHTNESS),
                isOn = true,
                brightnessPct = 85,
                colorTempK = 3500,
                powerDrawWatts = 45.0
            ),
            Device(
                id = DeviceId("dev_kitch_under"),
                roomId = RoomId("room_kitchen"),
                name = "Cabinet Task Lights",
                category = DeviceCategory.LIGHT,
                capabilities = setOf(DeviceCapability.POWER_SWITCH, DeviceCapability.BRIGHTNESS),
                isOn = false,
                brightnessPct = 100,
                powerDrawWatts = 0.0
            ),

            // Bedroom
            Device(
                id = DeviceId("dev_bed_ambient"),
                roomId = RoomId("room_bedroom"),
                name = "Bedroom Cove Lighting",
                category = DeviceCategory.LIGHT,
                capabilities = setOf(DeviceCapability.POWER_SWITCH, DeviceCapability.BRIGHTNESS, DeviceCapability.COLOR_TEMPERATURE),
                isOn = false,
                brightnessPct = 30,
                colorTempK = 2700,
                powerDrawWatts = 0.0
            ),
            Device(
                id = DeviceId("dev_bed_blinds"),
                roomId = RoomId("room_bedroom"),
                name = "Blackout Automated Shades",
                category = DeviceCategory.BLINDS,
                capabilities = setOf(DeviceCapability.BLINDS_POSITION),
                positionPct = 20
            ),

            // Office
            Device(
                id = DeviceId("dev_office_light"),
                roomId = RoomId("room_office"),
                name = "Office Diffused Light Bar",
                category = DeviceCategory.LIGHT,
                capabilities = setOf(DeviceCapability.POWER_SWITCH, DeviceCapability.BRIGHTNESS, DeviceCapability.COLOR_TEMPERATURE),
                isOn = true,
                brightnessPct = 90,
                colorTempK = 4000,
                powerDrawWatts = 28.0
            ),

            // Security Locks
            Device(
                id = DeviceId("dev_lock_front"),
                roomId = RoomId("room_living"),
                name = "Front Entrance Smart Deadbolt",
                category = DeviceCategory.SECURITY_LOCK,
                capabilities = setOf(DeviceCapability.LOCK_CONTROL),
                isLocked = true,
                health = DeviceHealth(batteryPct = 91, signalStrength = "EXCELLENT")
            ),
            Device(
                id = DeviceId("dev_lock_back"),
                roomId = RoomId("room_kitchen"),
                name = "Patio Garden Sliding Lock",
                category = DeviceCategory.SECURITY_LOCK,
                capabilities = setOf(DeviceCapability.LOCK_CONTROL),
                isLocked = true,
                health = DeviceHealth(batteryPct = 84, signalStrength = "GOOD")
            ),
            Device(
                id = DeviceId("dev_lock_garage"),
                roomId = RoomId("room_garage"),
                name = "Garage Automated Heavy Door",
                category = DeviceCategory.SECURITY_LOCK,
                capabilities = setOf(DeviceCapability.LOCK_CONTROL),
                isLocked = true,
                health = DeviceHealth(batteryPct = 98, signalStrength = "EXCELLENT")
            )
        )
        _devices.value = initialDevices

        _scenes.value = listOf(
            SceneItem(SceneId("scene_arrive"), "Arrive Home", "arrive", "Unlock garage, warm lighting 60%, climate 21°C", listOf("Locks", "Lighting", "Climate")),
            SceneItem(SceneId("scene_night"), "Good Night", "night", "Lock all doors, downstairs lights off, arm security, set night HVAC", listOf("Locks", "Lighting", "Security", "Climate", "EV")),
            SceneItem(SceneId("scene_leave"), "Leave Home", "leave", "Arm security Away, turn off all lights, eco climate", listOf("Security", "Lighting", "Climate")),
            SceneItem(SceneId("scene_movie"), "Movie Night", "movie", "Dim living room 15% warm, close blinds, Apple TV ready", listOf("Lighting", "Blinds", "Media")),
            SceneItem(SceneId("scene_dinner"), "Dinner", "dinner", "Pendants 70% warm, gentle acoustic playlist, soft ambient", listOf("Lighting", "Media")),
            SceneItem(SceneId("scene_energy"), "Energy Save", "energysave", "Pause deferrable loads, optimize EV charging, eco heating", listOf("iEnergy", "EV", "Climate"))
        )

        _automations.value = listOf(
            AutomationRule(
                id = AutomationId("auto_solar_ev"),
                name = "Solar Surplus EV Smart Charge",
                triggerSummary = "WHEN Solar generation > 4.0 kW",
                conditionSummary = "AND Battery SOC > 80% AND EV is plugged in",
                actionSummary = "THEN Start EV charging at modulated solar surplus rate",
                isEnabled = true,
                category = "iEnergy",
                lastRunTime = "Today, 12:45"
            ),
            AutomationRule(
                id = AutomationId("auto_sunset"),
                name = "Sunset Ambient Transition",
                triggerSummary = "WHEN Astronomical Sunset occurs",
                conditionSummary = "AND Someone is Home",
                actionSummary = "THEN Set downstairs lights to 40% (2700K Warm) and close blinds",
                isEnabled = true,
                category = "Lighting",
                lastRunTime = "Yesterday, 18:24"
            ),
            AutomationRule(
                id = AutomationId("auto_leak_shutoff"),
                name = "Emergency Water Leak Protection",
                triggerSummary = "WHEN Water leak detected in any zone",
                conditionSummary = "AND Valve is Open",
                actionSummary = "THEN Immediately close main smart valve & alert all household phones",
                isEnabled = true,
                category = "Security",
                lastRunTime = "Never (Active Standby)"
            ),
            AutomationRule(
                id = AutomationId("auto_preheat"),
                name = "Off-Peak Thermal Pre-conditioning",
                triggerSummary = "WHEN Time is 04:30 on low tariff rate",
                conditionSummary = "AND Outdoor temp < 10°C",
                actionSummary = "THEN Heat water cylinder to 58°C and boost living zones to 21°C",
                isEnabled = true,
                category = "Comfort",
                lastRunTime = "Today, 04:30"
            )
        )

        _activityLogs.value = listOf(
            ActivityTimelineItem("act_1", "14:32", "Solar Generation Increased", "Array output exceeded 3.4 kW under clear sky", "Energy", SystemSeverity.INFO),
            ActivityTimelineItem("act_2", "14:35", "Home Battery Began Charging", "Surplus power directed to 13.5 kWh battery storage", "Energy", SystemSeverity.INFO),
            ActivityTimelineItem("act_3", "15:02", "EV Scheduled Window Calculated", "Optimized charging window set for 01:30 – 04:45", "EV", SystemSeverity.INFO),
            ActivityTimelineItem("act_4", "16:41", "Front Door Unlocked via Digital Key", "Tom arrived home · Welcome scene engaged", "Security", SystemSeverity.NOTICE),
            ActivityTimelineItem("act_5", "16:41", "Hallway & Living Room Lighting Activated", "Circadian warm white 60% applied", "Lighting", SystemSeverity.INFO),
            ActivityTimelineItem("act_6", "16:42", "Living Zone Target Reached", "Thermostat maintained 21.4°C comfortably", "Climate", SystemSeverity.INFO)
        )

        _cameras.value = listOf(
            CameraFeed(
                deviceId = DeviceId("cam_doorbell"),
                name = "Front Doorbell Pro",
                location = "Entrance Porch",
                isOnline = true,
                recentDetections = listOf(
                    CameraDetection("det_1", "16:40", "Person", "Tom recognized at front door"),
                    CameraDetection("det_2", "13:12", "Package", "Courier delivered parcel to porch doorstep")
                )
            ),
            CameraFeed(
                deviceId = DeviceId("cam_garden"),
                name = "Garden & Terrace Camera",
                location = "South Garden",
                isOnline = true,
                recentDetections = listOf(
                    CameraDetection("det_3", "11:05", "Motion", "Tree branches in wind")
                )
            ),
            CameraFeed(
                deviceId = DeviceId("cam_garage"),
                name = "Garage & Driveway Camera",
                location = "EV Charging Bay",
                isOnline = true,
                recentDetections = listOf(
                    CameraDetection("det_4", "16:38", "Vehicle", "BMW iX arrived in bay")
                )
            )
        )

        _matterNodes.value = listOf(
            MatterNodeState("node_01", "Daikin Altherma Heat Pump", "Daikin", "PAIRED", listOf(
                MatterClusterInfo(1, "0x0201", "Thermostat", 14),
                MatterClusterInfo(2, "0x0b04", "Electrical Measurement", 8)
            )),
            MatterNodeState("node_02", "iHome Power Gateway", "iHome", "COMMISSIONED", listOf(
                MatterClusterInfo(1, "0x0091", "Energy EVSE", 12),
                MatterClusterInfo(2, "0x0093", "Electrical Energy", 16)
            )),
            MatterNodeState("node_03", "Schlage Encode Deadbolt", "Schlage", "PAIRED", listOf(
                MatterClusterInfo(1, "0x0101", "Door Lock", 22)
            )),
            MatterNodeState("node_04", "Philips Hue Bridge Pro", "Signify", "PAIRED", listOf(
                MatterClusterInfo(1, "0x0006", "On/Off", 6),
                MatterClusterInfo(2, "0x0008", "Level Control", 10),
                MatterClusterInfo(3, "0x0300", "Color Control", 18)
            ))
        )
    }

    fun toggleDevicePower(deviceId: DeviceId) {
        _devices.value = _devices.value.map { dev ->
            if (dev.id == deviceId) {
                val nextOn = !dev.isOn
                dev.copy(isOn = nextOn, powerDrawWatts = if (nextOn) 30.0 else 0.0)
            } else dev
        }
    }

    fun setDeviceBrightness(deviceId: DeviceId, brightness: Int) {
        _devices.value = _devices.value.map { dev ->
            if (dev.id == deviceId) {
                dev.copy(brightnessPct = brightness, isOn = brightness > 0)
            } else dev
        }
    }

    fun setDeviceColorTemp(deviceId: DeviceId, kelvin: Int) {
        _devices.value = _devices.value.map { dev ->
            if (dev.id == deviceId) {
                dev.copy(colorTempK = kelvin)
            } else dev
        }
    }

    fun setRoomTargetTemp(roomId: RoomId, targetTemp: Double) {
        _rooms.value = _rooms.value.map { rm ->
            if (rm.id == roomId) {
                rm.copy(
                    targetTempC = targetTemp,
                    heatingActive = targetTemp > rm.currentTempC,
                    coolingActive = targetTemp < rm.currentTempC
                )
            } else rm
        }
    }

    fun toggleDeviceLock(deviceId: DeviceId) {
        _devices.value = _devices.value.map { dev ->
            if (dev.id == deviceId) {
                val nextLocked = !dev.isLocked
                recordActivity(
                    title = if (nextLocked) "Door Locked" else "Door Unlocked",
                    detail = "${dev.name} changed state via app security control",
                    subsystem = "Security",
                    severity = if (nextLocked) SystemSeverity.INFO else SystemSeverity.NOTICE
                )
                dev.copy(isLocked = nextLocked)
            } else dev
        }
    }

    fun setBlindsPosition(deviceId: DeviceId, position: Int) {
        _devices.value = _devices.value.map { dev ->
            if (dev.id == deviceId) dev.copy(positionPct = position) else dev
        }
    }

    fun runScene(sceneId: SceneId) {
        val scene = _scenes.value.find { it.id == sceneId } ?: return
        _scenes.value = _scenes.value.map { it.copy(isActive = it.id == sceneId) }

        when (sceneId.value) {
            "scene_night" -> {
                // Lock doors, turn off downstairs lights, adjust climate
                _devices.value = _devices.value.map { dev ->
                    when (dev.category) {
                        DeviceCategory.SECURITY_LOCK -> dev.copy(isLocked = true)
                        DeviceCategory.LIGHT -> if (dev.roomId.value in listOf("room_living", "room_kitchen")) dev.copy(isOn = false) else dev
                        else -> dev
                    }
                }
                twinEngine.setSecurityMode(SecurityArmMode.NIGHT_ARMED)
            }
            "scene_arrive" -> {
                _devices.value = _devices.value.map { dev ->
                    when (dev.id.value) {
                        "dev_lr_ceiling" -> dev.copy(isOn = true, brightnessPct = 70, colorTempK = 3000)
                        "dev_lock_front" -> dev.copy(isLocked = false)
                        else -> dev
                    }
                }
                twinEngine.setSecurityMode(SecurityArmMode.HOME_ARMED)
            }
            "scene_leave" -> {
                _devices.value = _devices.value.map { dev ->
                    if (dev.category == DeviceCategory.LIGHT) dev.copy(isOn = false) else dev
                }
                twinEngine.setSecurityMode(SecurityArmMode.AWAY_ARMED)
            }
            "scene_movie" -> {
                _devices.value = _devices.value.map { dev ->
                    if (dev.roomId.value == "room_living" && dev.category == DeviceCategory.LIGHT) {
                        dev.copy(isOn = true, brightnessPct = 15, colorTempK = 2700)
                    } else dev
                }
            }
            "scene_energy" -> {
                twinEngine.setEVMode(EVSmartMode.CHEAPEST)
            }
        }

        recordActivity(
            title = "Scene Activated: ${scene.name}",
            detail = scene.description,
            subsystem = "System",
            severity = SystemSeverity.INFO
        )
    }

    fun toggleAutomation(id: AutomationId) {
        _automations.value = _automations.value.map {
            if (it.id == id) it.copy(isEnabled = !it.isEnabled) else it
        }
    }

    fun recordActivity(title: String, detail: String, subsystem: String, severity: SystemSeverity) {
        val newItem = ActivityTimelineItem(
            id = "act_${System.currentTimeMillis()}",
            timestamp = twinEngine.simTime.value.formatted,
            title = title,
            detail = detail,
            subsystem = subsystem,
            severity = severity
        )
        _activityLogs.value = listOf(newItem) + _activityLogs.value.take(49)
    }

    // Pass-through simulation controls
    fun toggleDemoMode() = twinEngine.toggleDemoMode()
    fun setSimulationTime(hour: Int, minute: Int, scenario: String = "Manual") = twinEngine.setSimulationTime(hour, minute, scenario)
    fun togglePowerOutage() = twinEngine.togglePowerOutage()
    fun toggleWaterLeak() = twinEngine.toggleWaterLeak()
    fun toggleEVCharging() = twinEngine.toggleEVCharging()
    fun setEVMode(mode: EVSmartMode) = twinEngine.setEVMode(mode)
    fun setBatteryMode(mode: BatteryMode) = twinEngine.setBatteryMode(mode)
    fun setSecurityMode(mode: SecurityArmMode) = twinEngine.setSecurityMode(mode)
    fun toggleWaterValve() = twinEngine.toggleWaterValve()
}
