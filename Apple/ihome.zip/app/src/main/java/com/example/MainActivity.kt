package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.*
import com.example.ui.MainViewModel
import com.example.ui.NavDestination
import com.example.ui.components.CommandPaletteModal
import com.example.ui.components.HomeCommand
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScaffold(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScaffold(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val isCommandPaletteOpen by viewModel.isCommandPaletteOpen.collectAsStateWithLifecycle()

    val simTime by viewModel.repository.simTime.collectAsStateWithLifecycle()
    val powerFlow by viewModel.repository.powerFlow.collectAsStateWithLifecycle()
    val energyStats by viewModel.repository.energyStats.collectAsStateWithLifecycle()
    val meter by viewModel.repository.meter.collectAsStateWithLifecycle()
    val solar by viewModel.repository.solar.collectAsStateWithLifecycle()
    val battery by viewModel.repository.battery.collectAsStateWithLifecycle()
    val ev by viewModel.repository.ev.collectAsStateWithLifecycle()
    val security by viewModel.repository.security.collectAsStateWithLifecycle()
    val water by viewModel.repository.water.collectAsStateWithLifecycle()
    val carbon by viewModel.repository.carbon.collectAsStateWithLifecycle()
    val tariff by viewModel.repository.tariff.collectAsStateWithLifecycle()
    val recommendations by viewModel.repository.recommendations.collectAsStateWithLifecycle()
    val appliances by viewModel.repository.appliances.collectAsStateWithLifecycle()
    val isOutage by viewModel.repository.isOutageSimulated.collectAsStateWithLifecycle()
    val isLeak by viewModel.repository.isLeakSimulated.collectAsStateWithLifecycle()

    val rooms by viewModel.repository.rooms.collectAsStateWithLifecycle()
    val devices by viewModel.repository.devices.collectAsStateWithLifecycle()
    val scenes by viewModel.repository.scenes.collectAsStateWithLifecycle()
    val automations by viewModel.repository.automations.collectAsStateWithLifecycle()
    val activityLogs by viewModel.repository.activityLogs.collectAsStateWithLifecycle()
    val cameras by viewModel.repository.cameras.collectAsStateWithLifecycle()
    val threadStatus by viewModel.repository.threadStatus.collectAsStateWithLifecycle()
    val homeHub by viewModel.repository.homeHub.collectAsStateWithLifecycle()
    val matterNodes by viewModel.repository.matterNodes.collectAsStateWithLifecycle()
    val selectedRoomIdForDetails by viewModel.selectedRoomIdForDetails.collectAsStateWithLifecycle()

    BackHandler(enabled = currentScreen != NavDestination.HOME) {
        viewModel.navigateTo(NavDestination.HOME)
    }

    val commands = remember {
        listOf(
            HomeCommand("cmd_home", "Go to Home", "Main dashboard and status overview", Icons.Rounded.Home, "Navigation") {
                viewModel.navigateTo(NavDestination.HOME)
            },
            HomeCommand("cmd_energy", "Open iEnergy Hub", "Whole-home power bus, solar & storage", Icons.Rounded.Bolt, "Energy") {
                viewModel.navigateTo(NavDestination.ENERGY)
            },
            HomeCommand("cmd_ev", "Show EV Charging", "Configure BMW iX charging schedule", Icons.Rounded.ElectricCar, "Transport") {
                viewModel.navigateTo(NavDestination.ENERGY)
            },
            HomeCommand("cmd_rooms", "View Rooms & Devices", "Control lights, heating, blinds per room", Icons.Rounded.MeetingRoom, "Rooms") {
                viewModel.navigateTo(NavDestination.ROOMS)
            },
            HomeCommand("cmd_security", "Security & Locks", "View door deadbolts & iVision cameras", Icons.Rounded.Shield, "Security") {
                viewModel.navigateTo(NavDestination.SECURITY)
            },
            HomeCommand("cmd_auto", "Automations & Scenes", "Automated rules and scenario simulator", Icons.Rounded.AutoAwesome, "Automations") {
                viewModel.navigateTo(NavDestination.AUTOMATIONS)
            },
            HomeCommand("cmd_network", "Matter & Thread Network", "Mesh health and privacy transparency", Icons.Rounded.Hub, "System") {
                viewModel.navigateTo(NavDestination.NETWORK)
            },
            HomeCommand("cmd_night", "Run Good Night Scene", "Lock all doors, arm security, set HVAC", Icons.Rounded.Bedtime, "Scene") {
                viewModel.runScene(SceneId("scene_night"))
            },
            HomeCommand("cmd_ev_toggle", "Toggle EV Charging", "Start or pause vehicle charge session", Icons.Rounded.Power, "EV") {
                viewModel.toggleEVCharging()
            },
            HomeCommand("cmd_outage", "Toggle Power Outage Simulation", "Test home battery microgrid backup", Icons.Rounded.Warning, "Simulation") {
                viewModel.toggleOutage()
            },
            HomeCommand("cmd_leak", "Toggle Water Leak Simulation", "Test automatic smart valve isolation", Icons.Rounded.WaterDamage, "Simulation") {
                viewModel.toggleLeak()
            }
        )
    }

    if (isCommandPaletteOpen) {
        CommandPaletteModal(
            commands = commands,
            onDismiss = { viewModel.closeCommandPalette() }
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(AppleDarkBackground)) {
        val isWideScreen = maxWidth > 680.dp

        Row(modifier = Modifier.fillMaxSize()) {
            // Adaptive Side Navigation Rail on wide screens (tablets)
            if (isWideScreen) {
                NavigationRail(
                    containerColor = AppleDarkSurface,
                    contentColor = AppleTextPrimary,
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(96.dp)
                        .border(1.dp, AppleBorder)
                ) {
                    Spacer(modifier = Modifier.height(16.dp))
                    IconButton(
                        onClick = { viewModel.openCommandPalette() },
                        modifier = Modifier
                            .size(44.dp)
                            .background(AppleDarkSurfaceHighlight, RoundedCornerShape(12.dp))
                    ) {
                        Icon(imageVector = Icons.Rounded.Search, contentDescription = "Command Palette", tint = AppleElectricBlue)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    NavigationRailItem(
                        selected = currentScreen == NavDestination.HOME,
                        onClick = { viewModel.navigateTo(NavDestination.HOME) },
                        icon = { Icon(Icons.Rounded.Home, contentDescription = "Home") },
                        label = { Text("Home", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = AppleElectricBlue,
                            indicatorColor = AppleElectricBlue,
                            unselectedIconColor = AppleTextSecondary,
                            unselectedTextColor = AppleTextSecondary
                        )
                    )
                    NavigationRailItem(
                        selected = currentScreen == NavDestination.ROOMS,
                        onClick = { viewModel.navigateTo(NavDestination.ROOMS) },
                        icon = { Icon(Icons.Rounded.MeetingRoom, contentDescription = "Rooms") },
                        label = { Text("Rooms", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = AppleElectricBlue,
                            indicatorColor = AppleElectricBlue,
                            unselectedIconColor = AppleTextSecondary,
                            unselectedTextColor = AppleTextSecondary
                        )
                    )
                    NavigationRailItem(
                        selected = currentScreen == NavDestination.ENERGY,
                        onClick = { viewModel.navigateTo(NavDestination.ENERGY) },
                        icon = { Icon(Icons.Rounded.Bolt, contentDescription = "Energy") },
                        label = { Text("iEnergy", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = AppleEnergyGreen,
                            indicatorColor = AppleEnergyGreen,
                            unselectedIconColor = AppleTextSecondary,
                            unselectedTextColor = AppleTextSecondary
                        )
                    )
                    NavigationRailItem(
                        selected = currentScreen == NavDestination.SECURITY,
                        onClick = { viewModel.navigateTo(NavDestination.SECURITY) },
                        icon = { Icon(Icons.Rounded.Shield, contentDescription = "Security") },
                        label = { Text("Security", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = AppleElectricBlue,
                            indicatorColor = AppleElectricBlue,
                            unselectedIconColor = AppleTextSecondary,
                            unselectedTextColor = AppleTextSecondary
                        )
                    )
                    NavigationRailItem(
                        selected = currentScreen == NavDestination.AUTOMATIONS,
                        onClick = { viewModel.navigateTo(NavDestination.AUTOMATIONS) },
                        icon = { Icon(Icons.Rounded.AutoAwesome, contentDescription = "Automations") },
                        label = { Text("Auto", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = AppleSolarAmber,
                            indicatorColor = AppleSolarAmber,
                            unselectedIconColor = AppleTextSecondary,
                            unselectedTextColor = AppleTextSecondary
                        )
                    )
                    NavigationRailItem(
                        selected = currentScreen == NavDestination.NETWORK,
                        onClick = { viewModel.navigateTo(NavDestination.NETWORK) },
                        icon = { Icon(Icons.Rounded.Hub, contentDescription = "System") },
                        label = { Text("Matter", fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = AppleElectricBlue,
                            indicatorColor = AppleElectricBlue,
                            unselectedIconColor = AppleTextSecondary,
                            unselectedTextColor = AppleTextSecondary
                        )
                    )
                }
            }

            // Main Content Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Top Bar for mobile / general
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.statusBars)
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AppleDarkSurfaceElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Home,
                                    contentDescription = null,
                                    tint = AppleElectricBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "iHome",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleTextPrimary
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Search / Command Palette Trigger
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(AppleDarkSurfaceElevated)
                                    .border(1.dp, AppleBorder, RoundedCornerShape(12.dp))
                                    .clickable { viewModel.openCommandPalette() }
                                    .testTag("open_command_palette_btn")
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Search,
                                        contentDescription = "Search",
                                        tint = AppleTextSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "⌘K",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AppleTextSecondary
                                    )
                                }
                            }

                            // Matter & Network status icon
                            IconButton(
                                onClick = { viewModel.navigateTo(NavDestination.NETWORK) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(AppleDarkSurfaceElevated, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Hub,
                                    contentDescription = "Matter & Network",
                                    tint = AppleElectricBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Selected View
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        when (currentScreen) {
                            NavDestination.HOME -> HomeScreen(
                                simTime = simTime,
                                powerFlow = powerFlow,
                                rooms = rooms,
                                security = security,
                                ev = ev,
                                scenes = scenes,
                                isOutage = isOutage,
                                isLeak = isLeak,
                                onNavigateToEnergy = { viewModel.navigateTo(NavDestination.ENERGY) },
                                onNavigateToRooms = { roomId -> viewModel.openRoomDetails(roomId) },
                                onNavigateToSecurity = { viewModel.navigateTo(NavDestination.SECURITY) },
                                onNavigateToEV = { viewModel.navigateTo(NavDestination.ENERGY) },
                                onRunScene = { sceneId -> viewModel.runScene(sceneId) },
                                onToggleDemoMode = { viewModel.toggleDemoMode() },
                                onTogglePowerOutage = { viewModel.toggleOutage() },
                                onToggleWaterLeak = { viewModel.toggleLeak() },
                                onSetSimHour = { hr -> viewModel.setSimHour(hr) }
                            )

                            NavDestination.ROOMS -> RoomsScreen(
                                rooms = rooms,
                                devices = devices,
                                initialSelectedRoomId = selectedRoomIdForDetails,
                                onToggleDevicePower = { id -> viewModel.toggleDevicePower(id) },
                                onSetBrightness = { id, br -> viewModel.setDeviceBrightness(id, br) },
                                onSetColorTemp = { id, k -> viewModel.setDeviceColorTemp(id, k) },
                                onSetRoomTargetTemp = { id, t -> viewModel.setRoomTargetTemp(id, t) },
                                onSetBlindsPosition = { id, pos -> viewModel.setBlinds(id, pos) }
                            )

                            NavDestination.ENERGY -> EnergyScreen(
                                powerFlow = powerFlow,
                                energyStats = energyStats,
                                meter = meter,
                                solar = solar,
                                battery = battery,
                                ev = ev,
                                tariff = tariff,
                                carbon = carbon,
                                recommendations = recommendations,
                                appliances = appliances,
                                isOutage = isOutage,
                                onSetBatteryMode = { mode -> viewModel.setBatteryMode(mode) },
                                onSetEVMode = { mode -> viewModel.setEVMode(mode) },
                                onToggleEVCharging = { viewModel.toggleEVCharging() }
                            )

                            NavDestination.SECURITY -> SecurityScreen(
                                security = security,
                                locks = devices.filter { it.category == DeviceCategory.SECURITY_LOCK },
                                cameras = cameras,
                                water = water,
                                isLeak = isLeak,
                                onToggleLock = { id -> viewModel.toggleLock(id) },
                                onSetSecurityMode = { mode -> viewModel.setSecurityMode(mode) },
                                onToggleWaterValve = { viewModel.toggleWaterValve() }
                            )

                            NavDestination.AUTOMATIONS -> AutomationsScreen(
                                automations = automations,
                                scenes = scenes,
                                activityLogs = activityLogs,
                                onToggleAutomation = { id -> viewModel.toggleAutomation(id) },
                                onRunScene = { id -> viewModel.runScene(id) }
                            )

                            NavDestination.NETWORK -> NetworkPrivacyScreen(
                                threadStatus = threadStatus,
                                homeHub = homeHub,
                                matterNodes = matterNodes
                            )
                        }
                    }
                }

                // Phone Mode Bottom Navigation Bar
                if (!isWideScreen) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        NavigationBar(
                            containerColor = AppleDarkSurface.copy(alpha = 0.95f),
                            contentColor = AppleTextPrimary,
                            tonalElevation = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, AppleBorder.copy(alpha = 0.6f))
                        ) {
                            NavigationBarItem(
                                selected = currentScreen == NavDestination.HOME,
                                onClick = { viewModel.navigateTo(NavDestination.HOME) },
                                icon = { Icon(Icons.Rounded.Home, contentDescription = "Home") },
                                label = { Text("Home", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_item_home"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = AppleElectricBlue,
                                    indicatorColor = AppleElectricBlue,
                                    unselectedIconColor = AppleTextSecondary,
                                    unselectedTextColor = AppleTextSecondary
                                )
                            )

                            NavigationBarItem(
                                selected = currentScreen == NavDestination.ROOMS,
                                onClick = { viewModel.navigateTo(NavDestination.ROOMS) },
                                icon = { Icon(Icons.Rounded.MeetingRoom, contentDescription = "Rooms") },
                                label = { Text("Rooms", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_item_rooms"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = AppleElectricBlue,
                                    indicatorColor = AppleElectricBlue,
                                    unselectedIconColor = AppleTextSecondary,
                                    unselectedTextColor = AppleTextSecondary
                                )
                            )

                            NavigationBarItem(
                                selected = currentScreen == NavDestination.ENERGY,
                                onClick = { viewModel.navigateTo(NavDestination.ENERGY) },
                                icon = { Icon(Icons.Rounded.Bolt, contentDescription = "iEnergy") },
                                label = { Text("iEnergy", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_item_energy"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = AppleEnergyGreen,
                                    indicatorColor = AppleEnergyGreen,
                                    unselectedIconColor = AppleTextSecondary,
                                    unselectedTextColor = AppleTextSecondary
                                )
                            )

                            NavigationBarItem(
                                selected = currentScreen == NavDestination.SECURITY,
                                onClick = { viewModel.navigateTo(NavDestination.SECURITY) },
                                icon = { Icon(Icons.Rounded.Shield, contentDescription = "Security") },
                                label = { Text("Security", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_item_security"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = AppleElectricBlue,
                                    indicatorColor = AppleElectricBlue,
                                    unselectedIconColor = AppleTextSecondary,
                                    unselectedTextColor = AppleTextSecondary
                                )
                            )

                            NavigationBarItem(
                                selected = currentScreen == NavDestination.AUTOMATIONS,
                                onClick = { viewModel.navigateTo(NavDestination.AUTOMATIONS) },
                                icon = { Icon(Icons.Rounded.AutoAwesome, contentDescription = "Automations") },
                                label = { Text("Auto", fontSize = 10.sp) },
                                modifier = Modifier.testTag("nav_item_automations"),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = AppleSolarAmber,
                                    indicatorColor = AppleSolarAmber,
                                    unselectedIconColor = AppleTextSecondary,
                                    unselectedTextColor = AppleTextSecondary
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
