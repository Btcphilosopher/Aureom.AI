package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.components.LiveEnergyFlowCanvas
import com.example.ui.theme.*

@Composable
fun EnergyScreen(
    powerFlow: PowerFlowState,
    energyStats: EnergyStats,
    meter: HomeMeterState,
    solar: SolarArrayState,
    battery: BatteryState,
    ev: EVChargingState,
    tariff: TariffRate,
    carbon: CarbonIntensityState,
    recommendations: List<EnergyOptimizationRecommendation>,
    appliances: List<SmartAppliance>,
    isOutage: Boolean,
    onSetBatteryMode: (BatteryMode) -> Unit,
    onSetEVMode: (EVSmartMode) -> Unit,
    onToggleEVCharging: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedHistoryTab by remember { mutableStateOf("DAY") }
    var selectedMetricType by remember { mutableStateOf("kWh") } // kWh, £, kgCO2

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppleDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title & High-level Home Energy Score
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "RESIDENTIAL POWER & STORAGE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "iEnergy",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppleTextPrimary
                    )

                    // Home Energy Score Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(AppleEnergyGreen.copy(alpha = 0.15f))
                            .border(1.dp, AppleEnergyGreen, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "87 / 100",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleEnergyGreen
                            )
                            Text(
                                text = "EXCELLENT",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleEnergyGreen
                            )
                        }
                    }
                }
            }
        }

        // Live Power Bus Visualizer
        item {
            LiveEnergyFlowCanvas(
                powerFlow = powerFlow,
                isOutage = isOutage
            )
        }

        // Whole-Home Power Command Matrix
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "WHOLE-HOME POWER SUMMARY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricBox(
                        title = "HOME DEMAND",
                        value = "%.1f kW".format(powerFlow.homeLoadKw),
                        subtext = "Baseload: %.0f W".format(energyStats.baseloadWatts),
                        color = AppleTextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "SOLAR GEN",
                        value = "%.1f kW".format(powerFlow.solarKw),
                        subtext = "Peak: 8.4 kWp",
                        color = AppleSolarAmber,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricBox(
                        title = "BATTERY SOC",
                        value = "${battery.socPct}%",
                        subtext = "%.1f kWh avail".format(battery.availableKwh),
                        color = AppleEnergyGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "EV VEHICLE",
                        value = "%.1f kW".format(powerFlow.evKw),
                        subtext = "${ev.socPct}% · Ready ${ev.readyTime}",
                        color = AppleElectricBlue,
                        modifier = Modifier.weight(1f)
                    )
                }

                Divider(color = AppleDivider)

                // Today Totals Breakdown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MiniStat(label = "Solar Today", value = "%.1f kWh".format(energyStats.todaySolarKwh))
                    MiniStat(label = "Import", value = "%.1f kWh".format(energyStats.todayGridImportKwh))
                    MiniStat(label = "Export", value = "%.1f kWh".format(energyStats.todayGridExportKwh))
                    MiniStat(label = "Cost Today", value = "£%.2f".format(energyStats.costTodayPounds))
                }
            }
        }

        // Electricity Meter
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "UTILITY SMART METER · PHASE 1",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = AppleTextSecondary
                    )
                    Text(
                        text = "${tariff.supplier}",
                        fontSize = 11.sp,
                        color = AppleElectricBlue
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MeterCell(label = "VOLTAGE", value = "%.1f V".format(meter.voltageV))
                    MeterCell(label = "CURRENT", value = "%.1f A".format(meter.currentA))
                    MeterCell(label = "POWER", value = "%.2f kW".format(meter.activePowerKw))
                    MeterCell(label = "POWER FACTOR", value = "%.2f PF".format(meter.powerFactor))
                    MeterCell(label = "FREQ", value = "%.1f Hz".format(meter.frequencyHz))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Current Tariff: ${tariff.currentRatePence}p / kWh (Off-peak: ${tariff.offPeakRatePence}p @ ${tariff.offPeakWindow})",
                        fontSize = 11.sp,
                        color = AppleTextSecondary
                    )
                    Text(
                        text = "Grid CO₂: ${carbon.currentGCo2PerKwh} g/kWh (${carbon.rating})",
                        fontSize = 11.sp,
                        color = if (carbon.rating == "HIGH") AppleCriticalRed else AppleEnergyGreen
                    )
                }
            }
        }

        // iBattery Deep Controller
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "iBATTERY STORAGE · 13.5 kWh LFP",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = AppleTextSecondary
                        )
                        Text(
                            text = if (isOutage) "BACKUP RESERVE ENGAGED · RUNTIME ~${battery.backupRuntimeHours}h"
                            else "${battery.socPct}% SOC · ${battery.healthPct}% Health (Cycle #${battery.cycleCount})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isOutage) AppleCriticalRed else AppleEnergyGreen
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(AppleDarkSurfaceHighlight)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${battery.voltageV}V · ${battery.temperatureC}°C",
                            fontSize = 11.sp,
                            color = AppleTextSecondary
                        )
                    }
                }

                // Battery Mode Selector
                Text(
                    text = "STORAGE OPERATING MODE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppleTextTertiary
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(BatteryMode.values()) { mode ->
                        val isSelected = battery.activeMode == mode
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) AppleEnergyGreen else AppleDarkSurfaceElevated)
                                .clickable { onSetBatteryMode(mode) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = mode.name.replace("_", " "),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.Black else AppleTextPrimary
                            )
                        }
                    }
                }
            }
        }

        // iEV Smart Charging Controller
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "iEV CHARGING · ${ev.vehicleName.uppercase()}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = AppleTextSecondary
                        )
                        Text(
                            text = "${ev.socPct}% → ${ev.targetSocPct}% · Ready ${ev.readyTime}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppleElectricBlue
                        )
                    }

                    Button(
                        onClick = onToggleEVCharging,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (ev.isCharging) AppleElectricBlue else AppleDarkSurfaceHighlight
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("toggle_ev_charging_btn")
                    ) {
                        Text(
                            text = if (ev.isCharging) "PAUSE CHARGE" else "START CHARGE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // V2H status tag
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(AppleDarkSurfaceElevated)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Vehicle-to-Home (V2H)", fontSize = 11.sp, color = AppleTextSecondary)
                    Text(
                        text = if (ev.v2hStatus == V2HStatus.AVAILABLE) "BIDIRECTIONAL AVAILABLE" else "NOT SUPPORTED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (ev.v2hStatus == V2HStatus.AVAILABLE) AppleEnergyGreen else AppleTextTertiary
                    )
                }

                // Smart EV Modes
                Text(
                    text = "OPTIMISATION ALGORITHM",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppleTextTertiary
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(EVSmartMode.values()) { mode ->
                        val isSelected = ev.activeMode == mode
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) AppleElectricBlue else AppleDarkSurfaceElevated)
                                .clickable { onSetEVMode(mode) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = mode.name.replace("_", " "),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else AppleTextPrimary
                            )
                        }
                    }
                }

                // Explainability box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(AppleDarkSurfaceHighlight)
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "WHY CHARGE AT THIS RATE?",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppleTextSecondary
                        )
                        Text(
                            text = "Mode: ${ev.activeMode} · Window ${ev.recommendedWindow} · Saving ~£${ev.estimatedCostPounds} vs peak rate.",
                            fontSize = 12.sp,
                            color = AppleTextPrimary
                        )
                    }
                }
            }
        }

        // Energy Optimization Engine Recommendations
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "iENERGY OPTIMISATION ENGINE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                recommendations.forEach { rec ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(AppleDarkSurface)
                            .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = rec.title.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleSolarAmber
                            )
                            Text(
                                text = "+£%.2f SAVING".format(rec.estimatedSavingPounds),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleEnergyGreen
                            )
                        }

                        Text(
                            text = rec.actionText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = AppleTextPrimary
                        )

                        Text(
                            text = "Reason: ${rec.reason}",
                            fontSize = 12.sp,
                            color = AppleTextSecondary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Carbon: ${rec.carbonBenefit}",
                                fontSize = 11.sp,
                                color = AppleWaterCyan
                            )
                            Text(
                                text = rec.deadlineOrConstraint,
                                fontSize = 11.sp,
                                color = AppleTextTertiary
                            )
                        }
                    }
                }
            }
        }

        // Load Priority Classification & Shiftable Appliances
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "APPLIANCE LOAD SHIFTING & PRIORITIES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                appliances.forEach { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(AppleDarkSurfaceElevated)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = app.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AppleTextPrimary)
                            Text(
                                text = "${app.programme} · ${app.state}" + (if (app.suggestedStartTime != null) " · Shift to ${app.suggestedStartTime}" else ""),
                                fontSize = 11.sp,
                                color = AppleTextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = app.priority.name,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (app.priority) {
                                    LoadPriority.CRITICAL -> AppleCriticalRed
                                    LoadPriority.IMPORTANT -> AppleSolarAmber
                                    LoadPriority.FLEXIBLE -> AppleElectricBlue
                                    LoadPriority.DEFERRABLE -> AppleEnergyGreen
                                }
                            )
                            if (app.loadShiftSavingPounds > 0) {
                                Text(
                                    text = "Save £%.2f".format(app.loadShiftSavingPounds),
                                    fontSize = 10.sp,
                                    color = AppleEnergyGreen
                                )
                            }
                        }
                    }
                }
            }
        }

        // Energy History & Period Selector
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HISTORICAL ENERGY ANALYSIS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = AppleTextSecondary
                    )

                    // Unit toggle (£ / kWh / kgCO2)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(AppleDarkSurfaceHighlight)
                            .padding(2.dp)
                    ) {
                        listOf("kWh", "£", "CO₂").forEach { unit ->
                            val isSel = selectedMetricType == unit
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) AppleElectricBlue else Color.Transparent)
                                    .clickable { selectedMetricType = unit }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = unit, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.White else AppleTextSecondary)
                            }
                        }
                    }
                }

                // Tabs: DAY, WEEK, MONTH, YEAR
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("DAY", "WEEK", "MONTH", "YEAR").forEach { tab ->
                        val isSel = selectedHistoryTab == tab
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) AppleDarkSurfaceElevated else Color.Transparent)
                                .border(if (isSel) 1.dp else 0.dp, if (isSel) AppleBorder else Color.Transparent, RoundedCornerShape(8.dp))
                                .clickable { selectedHistoryTab = tab }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tab,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) AppleTextPrimary else AppleTextTertiary
                            )
                        }
                    }
                }

                // Synthetic 24-hr Bar Visualization
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp)
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    val bars = listOf(15, 12, 10, 14, 18, 30, 55, 70, 85, 95, 100, 92, 80, 68, 60, 52, 75, 90, 85, 60, 45, 35, 25, 18)
                    bars.forEachIndexed { idx, heightPct ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.Bottom,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .fillMaxHeight(heightPct / 100f)
                                    .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                    .background(if (idx in 8..16) AppleSolarAmber else AppleElectricBlue)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("00:00", fontSize = 10.sp, color = AppleTextTertiary)
                    Text("06:00", fontSize = 10.sp, color = AppleTextTertiary)
                    Text("12:00 Solar Peak", fontSize = 10.sp, color = AppleSolarAmber)
                    Text("18:00 Peak", fontSize = 10.sp, color = AppleTextTertiary)
                    Text("23:00", fontSize = 10.sp, color = AppleTextTertiary)
                }
            }
        }
    }
}

@Composable
private fun MetricBox(
    title: String,
    value: String,
    subtext: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(AppleDarkSurfaceElevated)
            .padding(12.dp)
    ) {
        Text(text = title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AppleTextSecondary, letterSpacing = 0.5.sp)
        Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
        Text(text = subtext, fontSize = 11.sp, color = AppleTextTertiary)
    }
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 10.sp, color = AppleTextTertiary)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AppleTextPrimary)
    }
}

@Composable
private fun MeterCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AppleTextTertiary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AppleTextPrimary)
    }
}
