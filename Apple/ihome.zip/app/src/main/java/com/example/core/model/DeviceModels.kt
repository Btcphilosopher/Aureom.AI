package com.example.core.model

enum class DeviceCapability {
    POWER_SWITCH,
    BRIGHTNESS,
    COLOR_TEMPERATURE,
    RGB_COLOR,
    THERMOSTAT_CONTROL,
    LOCK_CONTROL,
    ENERGY_METER,
    EV_CHARGER,
    BATTERY_STORAGE,
    SOLAR_INVERTER,
    CAMERA_STREAM,
    MOTION_DETECTION,
    DOOR_SENSOR,
    WINDOW_SENSOR,
    WATER_VALVE,
    WATER_LEAK_SENSOR,
    AIR_QUALITY_SENSOR,
    BLINDS_POSITION,
    MEDIA_PLAYBACK
}

enum class DeviceCategory {
    LIGHT,
    CLIMATE,
    SECURITY_LOCK,
    SECURITY_SENSOR,
    CAMERA,
    ENERGY,
    EV,
    WATER,
    APPLIANCE,
    BLINDS,
    MEDIA
}

enum class ConnectivityType {
    MATTER_OVER_THREAD,
    MATTER_OVER_WIFI,
    THREAD_NATIVE,
    WIFI_LAN,
    BLE
}

data class DeviceHealth(
    val isOnline: Boolean = true,
    val batteryPct: Int? = null,
    val signalStrength: String = "GOOD",
    val lastSeenSecondsAgo: Int = 3,
    val firmwareVersion: String = "v2.4.1"
)

data class Device(
    val id: DeviceId,
    val roomId: RoomId,
    val name: String,
    val category: DeviceCategory,
    val capabilities: Set<DeviceCapability>,
    val connectivity: ConnectivityType = ConnectivityType.MATTER_OVER_THREAD,
    val health: DeviceHealth = DeviceHealth(),
    val isOn: Boolean = false,
    val brightnessPct: Int = 100,
    val colorTempK: Int = 3000,
    val targetTempC: Double = 21.0,
    val currentTempC: Double = 21.2,
    val positionPct: Int = 100, // for blinds, 100 = open
    val powerDrawWatts: Double = 0.0,
    val isLocked: Boolean = true,
    val customAttributes: Map<String, String> = emptyMap()
)

data class Room(
    val id: RoomId,
    val floorName: String,
    val name: String,
    val targetTempC: Double = 21.0,
    val currentTempC: Double = 21.4,
    val humidityPct: Int = 48,
    val co2Ppm: Int = 612,
    val pm25: Double = 4.0,
    val airQualityRating: String = "GOOD",
    val heatingActive: Boolean = true,
    val coolingActive: Boolean = false,
    val estimatedHeatingMinutes: Int = 22,
    val lightsCountOn: Int = 2,
    val totalLightsCount: Int = 3,
    val blindsOpenPct: Int = 60,
    val activeMediaTitle: String? = "Living Room Audio · Ambient Acoustics"
)

data class Floor(
    val name: String,
    val rooms: List<Room>
)

data class CameraDetection(
    val id: String,
    val timestamp: String,
    val type: String, // Person, Vehicle, Package, Motion
    val description: String,
    val confidencePct: Int = 96
)

data class CameraFeed(
    val deviceId: DeviceId,
    val name: String,
    val location: String,
    val isOnline: Boolean = true,
    val recentDetections: List<CameraDetection> = emptyList(),
    val isRecording: Boolean = true
)

enum class SecurityArmMode {
    DISARMED,
    HOME_ARMED,
    AWAY_ARMED,
    NIGHT_ARMED
}

data class SecurityStatus(
    val armMode: SecurityArmMode = SecurityArmMode.HOME_ARMED,
    val isAlarmTriggered: Boolean = false,
    val allDoorsLocked: Boolean = true,
    val allWindowsClosed: Boolean = true,
    val garageDoorClosed: Boolean = true,
    val activeCamerasCount: Int = 3,
    val motionSensorsNormal: Boolean = true,
    val smokeNormal: Boolean = true,
    val coNormal: Boolean = true,
    val waterLeakNormal: Boolean = true,
    val emergencyTriggered: String? = null
)
