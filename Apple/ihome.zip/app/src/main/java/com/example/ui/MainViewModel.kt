package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.database.AppDatabase
import com.example.core.model.*
import com.example.core.simulation.DigitalTwinEngine
import com.example.data.repository.HomeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class NavDestination {
    HOME,
    ROOMS,
    ENERGY,
    SECURITY,
    AUTOMATIONS,
    NETWORK
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    private val twinEngine = DigitalTwinEngine(viewModelScope)
    val repository = HomeRepository(database, twinEngine, viewModelScope)

    private val _currentScreen = MutableStateFlow(NavDestination.HOME)
    val currentScreen: StateFlow<NavDestination> = _currentScreen.asStateFlow()

    private val _selectedRoomIdForDetails = MutableStateFlow<RoomId?>(null)
    val selectedRoomIdForDetails: StateFlow<RoomId?> = _selectedRoomIdForDetails.asStateFlow()

    private val _isCommandPaletteOpen = MutableStateFlow(false)
    val isCommandPaletteOpen: StateFlow<Boolean> = _isCommandPaletteOpen.asStateFlow()

    fun navigateTo(dest: NavDestination) {
        _currentScreen.value = dest
    }

    fun openRoomDetails(roomId: RoomId?) {
        _selectedRoomIdForDetails.value = roomId
        _currentScreen.value = NavDestination.ROOMS
    }

    fun openCommandPalette() {
        _isCommandPaletteOpen.value = true
    }

    fun closeCommandPalette() {
        _isCommandPaletteOpen.value = false
    }

    // Proxy actions
    fun toggleDevicePower(id: DeviceId) = repository.toggleDevicePower(id)
    fun setDeviceBrightness(id: DeviceId, brightness: Int) = repository.setDeviceBrightness(id, brightness)
    fun setDeviceColorTemp(id: DeviceId, kelvin: Int) = repository.setDeviceColorTemp(id, kelvin)
    fun setRoomTargetTemp(id: RoomId, temp: Double) = repository.setRoomTargetTemp(id, temp)
    fun toggleLock(id: DeviceId) = repository.toggleDeviceLock(id)
    fun setBlinds(id: DeviceId, pos: Int) = repository.setBlindsPosition(id, pos)
    fun runScene(id: SceneId) = repository.runScene(id)
    fun toggleAutomation(id: AutomationId) = repository.toggleAutomation(id)
    fun toggleDemoMode() = repository.toggleDemoMode()
    fun toggleOutage() = repository.togglePowerOutage()
    fun toggleLeak() = repository.toggleWaterLeak()
    fun setSimHour(hour: Int) = repository.setSimulationTime(hour, 0)
    fun setBatteryMode(mode: BatteryMode) = repository.setBatteryMode(mode)
    fun setEVMode(mode: EVSmartMode) = repository.setEVMode(mode)
    fun toggleEVCharging() = repository.toggleEVCharging()
    fun setSecurityMode(mode: SecurityArmMode) = repository.setSecurityMode(mode)
    fun toggleWaterValve() = repository.toggleWaterValve()
}
