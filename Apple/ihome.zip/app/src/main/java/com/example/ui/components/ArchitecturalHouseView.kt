package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ElectricCar
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Room
import com.example.core.model.RoomId
import com.example.ui.theme.*

@Composable
fun ArchitecturalHouseView(
    rooms: List<Room>,
    selectedRoomId: RoomId?,
    onRoomSelected: (RoomId) -> Unit,
    modifier: Modifier = Modifier
) {
    val livingRoom = rooms.find { it.id.value == "room_living" }
    val kitchen = rooms.find { it.id.value == "room_kitchen" }
    val bedroom = rooms.find { it.id.value == "room_bedroom" }
    val office = rooms.find { it.id.value == "room_office" }
    val garage = rooms.find { it.id.value == "room_garage" }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(AppleDarkSurface)
            .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "APPLE HOUSE 01 · ARCHITECTURAL BLUEPRINT",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                color = AppleTextSecondary
            )
            Text(
                text = "Tap room to inspect",
                fontSize = 11.sp,
                color = AppleTextTertiary
            )
        }

        // Floor 1 Header / Label
        Text(
            text = "FIRST FLOOR",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = AppleTextTertiary,
            letterSpacing = 0.8.sp
        )

        // Top floor: Primary Bedroom (full width)
        bedroom?.let { rm ->
            BlueprintRoomCell(
                room = rm,
                isSelected = selectedRoomId == rm.id,
                onClick = { onRoomSelected(rm.id) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
            )
        }

        // Middle Upper: Office & Bathroom / Dressing
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            office?.let { rm ->
                BlueprintRoomCell(
                    room = rm,
                    isSelected = selectedRoomId == rm.id,
                    onClick = { onRoomSelected(rm.id) },
                    modifier = Modifier
                        .weight(1f)
                        .height(64.dp)
                )
            }
            // Secondary Bathroom cell
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(64.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(AppleDarkSurfaceElevated.copy(alpha = 0.5f))
                    .border(1.dp, AppleBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("BATHROOM", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = AppleTextSecondary)
                    Text("22.0°C · 54%", fontSize = 12.sp, color = AppleTextTertiary)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "GROUND FLOOR",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = AppleTextTertiary,
            letterSpacing = 0.8.sp
        )

        // Living Room (wide main open space)
        livingRoom?.let { rm ->
            BlueprintRoomCell(
                room = rm,
                isSelected = selectedRoomId == rm.id,
                onClick = { onRoomSelected(rm.id) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
            )
        }

        // Ground Floor bottom: Kitchen & Garage (with EV Bay)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            kitchen?.let { rm ->
                BlueprintRoomCell(
                    room = rm,
                    isSelected = selectedRoomId == rm.id,
                    onClick = { onRoomSelected(rm.id) },
                    modifier = Modifier
                        .weight(1f)
                        .height(68.dp)
                )
            }
            garage?.let { rm ->
                BlueprintRoomCell(
                    room = rm,
                    isSelected = selectedRoomId == rm.id,
                    onClick = { onRoomSelected(rm.id) },
                    badgeText = "EV ⚡",
                    modifier = Modifier
                        .weight(1f)
                        .height(68.dp)
                )
            }
        }
    }
}

@Composable
private fun BlueprintRoomCell(
    room: Room,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    badgeText: String? = null
) {
    val bgColor by animateColorAsState(
        if (isSelected) AppleDarkSurfaceHighlight else AppleDarkSurfaceElevated,
        label = "bg"
    )
    val borderColor by animateColorAsState(
        if (isSelected) AppleElectricBlue else AppleBorder,
        label = "border"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .border(if (isSelected) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .testTag("room_cell_${room.id.value}")
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = room.name.uppercase(),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isSelected) AppleElectricBlue else AppleTextPrimary,
                    letterSpacing = 0.5.sp
                )
                if (badgeText != null) {
                    Text(
                        text = badgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppleEnergyGreen
                    )
                } else if (room.lightsCountOn > 0) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.Lightbulb,
                            contentDescription = "Active lights",
                            tint = AppleSolarAmber,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "${room.lightsCountOn}",
                            fontSize = 11.sp,
                            color = AppleSolarAmber,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Thermostat,
                        contentDescription = "Temperature",
                        tint = if (room.heatingActive) AppleSolarAmber else AppleTextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${room.currentTempC}°C",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AppleTextPrimary
                    )
                    if (room.heatingActive) {
                        Text(
                            text = "HEAT",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppleSolarAmber
                        )
                    }
                }

                Text(
                    text = "${room.humidityPct}% RH",
                    fontSize = 11.sp,
                    color = AppleTextTertiary
                )
            }
        }
    }
}
