package com.example.core.simulation

import com.example.core.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

data class HouseSimulationTime(
    val hour: Int = 14,
    val minute: Int = 30,
    val isDemoRunning: Boolean = false,
    val scenarioName: String = "Normal Afternoon"
) {
    val formatted: String
        get() = "%02d:%02d".format(hour, minute)
}

class DigitalTwinEngine(
    private val scope: CoroutineScope
) {
    private val _simTime = MutableStateFlow(HouseSimulationTime())
    val simTime: StateFlow<HouseSimulationTime> = _simTime.asStateFlow()

    private val _powerFlow = MutableStateFlow(PowerFlowState())
    val powerFlow: StateFlow<PowerFlowState> = _powerFlow.asStateFlow()

    private val _energyStats = MutableStateFlow(EnergyStats())
    val energyStats: StateFlow<EnergyStats> = _energyStats.asStateFlow()

    private val _meter = MutableStateFlow(HomeMeterState())
    val meter: StateFlow<HomeMeterState> = _meter.asStateFlow()

    private val _solar = MutableStateFlow(SolarArrayState())
    val solar: StateFlow<SolarArrayState> = _solar.asStateFlow()

    private val _battery = MutableStateFlow(BatteryState())
    val battery: StateFlow<BatteryState> = _battery.asStateFlow()

    private val _ev = MutableStateFlow(EVChargingState())
    val ev: StateFlow<EVChargingState> = _ev.asStateFlow()

    private val _security = MutableStateFlow(SecurityStatus())
    val security: StateFlow<SecurityStatus> = _security.asStateFlow()

    private val _water = MutableStateFlow(WaterSystemState())
    val water: StateFlow<WaterSystemState> = _water.asStateFlow()

    private val _carbon = MutableStateFlow(CarbonIntensityState())
    val carbon: StateFlow<CarbonIntensityState> = _carbon.asStateFlow()

    private val _tariff = MutableStateFlow(TariffRate())
    val tariff: StateFlow<TariffRate> = _tariff.asStateFlow()

    private val _isOutageSimulated = MutableStateFlow(false)
    val isOutageSimulated: StateFlow<Boolean> = _isOutageSimulated.asStateFlow()

    private val _isLeakSimulated = MutableStateFlow(false)
    val isLeakSimulated: StateFlow<Boolean> = _isLeakSimulated.asStateFlow()

    private val _presence = MutableStateFlow(PresenceState.HOME)
    val presence: StateFlow<PresenceState> = _presence.asStateFlow()

    private val _appliances = MutableStateFlow(
        listOf(
            SmartAppliance("app_1", "Miele AutoDos Dishwasher", "Dishwasher", 0.0, "Ready", "Eco 50°C", 0, "01:15", 0.62, LoadPriority.DEFERRABLE),
            SmartAppliance("app_2", "Samsung HeatPump Dryer", "Dryer", 0.0, "Standby", "Synthetics Low", 0, "02:00", 0.48, LoadPriority.DEFERRABLE),
            SmartAppliance("app_3", "Liebherr Monolith Fridge", "Refrigerator", 110.0, "Running", "TwinCool 3°C", 0, null, 0.0, LoadPriority.CRITICAL),
            SmartAppliance("app_4", "Daikin Altherma 3 Heat Pump", "Heat Pump", 1200.0, "Running", "Weather Comp 42°C", 0, null, 0.0, LoadPriority.IMPORTANT)
        )
    )
    val appliances: StateFlow<List<SmartAppliance>> = _appliances.asStateFlow()

    private val _recommendations = MutableStateFlow(
        listOf(
            EnergyOptimizationRecommendation(
                id = "rec_ev",
                title = "Smart EV Schedule",
                actionText = "Shift charging to 01:30 – 04:45",
                estimatedSavingPounds = 2.84,
                reason = "Night tariff (7.5p/kWh vs 14.8p/kWh). Departure set for 07:00.",
                carbonBenefit = "Moderate (High wind generation tonight)",
                deadlineOrConstraint = "Departure 07:00 · Target 90%",
                category = "EV"
            ),
            EnergyOptimizationRecommendation(
                id = "rec_water",
                title = "Hot Water Pre-heating",
                actionText = "Heat water cylinder at 04:30",
                estimatedSavingPounds = 0.95,
                reason = "Heat pump COP optimal before morning peak demand.",
                carbonBenefit = "Low carbon off-peak power",
                deadlineOrConstraint = "Ready for 06:30 showers",
                category = "Water"
            ),
            EnergyOptimizationRecommendation(
                id = "rec_dish",
                title = "Dishwasher Load Shift",
                actionText = "Delay start until 01:15",
                estimatedSavingPounds = 0.62,
                reason = "Off-peak window matches cycle duration (135 min).",
                carbonBenefit = "Shifts 1.4 kWh from evening peak",
                deadlineOrConstraint = "Dishes clean before 07:00",
                category = "Appliance"
            )
        )
    )
    val recommendations: StateFlow<List<EnergyOptimizationRecommendation>> = _recommendations.asStateFlow()

    init {
        startTelemetryLoop()
    }

    private fun startTelemetryLoop() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(2500)
                if (_simTime.value.isDemoRunning) {
                    advanceDemoTime()
                } else {
                    addTelemetryJitter()
                }
            }
        }
    }

    private fun advanceDemoTime() {
        val current = _simTime.value
        var nextMin = current.minute + 15
        var nextHour = current.hour
        if (nextMin >= 60) {
            nextMin = 0
            nextHour = (nextHour + 1) % 24
        }
        val scenario = when (nextHour) {
            in 6..7 -> "06:30 Wake & Morning Comfort"
            in 8..11 -> "09:00 Solar Rises & House Empty"
            in 12..15 -> "12:30 Solar Peak Surplus"
            in 16..19 -> "17:30 Residents Return & Cooking"
            in 20..22 -> "21:00 Evening Relax & Lights Dim"
            else -> "23:00 Good Night & Off-peak EV Charge"
        }
        _simTime.value = current.copy(hour = nextHour, minute = nextMin, scenarioName = scenario)
        recomputePhysicsForTime(nextHour, nextMin)
    }

    private fun addTelemetryJitter() {
        val currentHour = _simTime.value.hour
        val currentMin = _simTime.value.minute
        recomputePhysicsForTime(currentHour, currentMin, addFluctuation = true)
    }

    fun setSimulationTime(hour: Int, minute: Int, scenarioName: String = "Manual Control") {
        _simTime.value = HouseSimulationTime(
            hour = hour.coerceIn(0, 23),
            minute = minute.coerceIn(0, 59),
            isDemoRunning = false,
            scenarioName = scenarioName
        )
        recomputePhysicsForTime(hour, minute)
    }

    fun toggleDemoMode() {
        val current = _simTime.value
        _simTime.value = current.copy(isDemoRunning = !current.isDemoRunning)
    }

    fun togglePowerOutage() {
        val next = !_isOutageSimulated.value
        _isOutageSimulated.value = next
        if (next) {
            _battery.value = _battery.value.copy(
                activeMode = BatteryMode.BACKUP,
                isOutageActive = true,
                backupRuntimeHours = 11.7
            )
        } else {
            _battery.value = _battery.value.copy(
                activeMode = BatteryMode.MAX_SELF_CONSUMPTION,
                isOutageActive = false
            )
        }
        recomputePhysicsForTime(_simTime.value.hour, _simTime.value.minute)
    }

    fun toggleWaterLeak() {
        val next = !_isLeakSimulated.value
        _isLeakSimulated.value = next
        if (next) {
            // Emergency automation automatically closes smart valve
            _water.value = _water.value.copy(
                leakDetected = true,
                mainValveOpen = false,
                flowRateLpm = 0.0
            )
            _security.value = _security.value.copy(
                waterLeakNormal = false,
                emergencyTriggered = "Water Leak detected in Ground Floor Utility. Smart valve automatically isolated."
            )
        } else {
            _water.value = _water.value.copy(
                leakDetected = false,
                mainValveOpen = true,
                flowRateLpm = 0.0
            )
            _security.value = _security.value.copy(
                waterLeakNormal = true,
                emergencyTriggered = null
            )
        }
    }

    fun setEVMode(mode: EVSmartMode) {
        _ev.value = _ev.value.copy(activeMode = mode)
    }

    fun toggleEVCharging() {
        val evCurrent = _ev.value
        val nextCharging = !evCurrent.isCharging
        _ev.value = evCurrent.copy(
            isCharging = nextCharging,
            chargingRateKw = if (nextCharging) 7.4 else 0.0
        )
        recomputePhysicsForTime(_simTime.value.hour, _simTime.value.minute)
    }

    fun setBatteryMode(mode: BatteryMode) {
        _battery.value = _battery.value.copy(activeMode = mode)
    }

    fun setSecurityMode(mode: SecurityArmMode) {
        _security.value = _security.value.copy(
            armMode = mode,
            allDoorsLocked = mode != SecurityArmMode.DISARMED,
            allWindowsClosed = true,
            garageDoorClosed = true
        )
    }

    fun toggleWaterValve() {
        val current = _water.value
        _water.value = current.copy(mainValveOpen = !current.mainValveOpen)
    }

    /**
     * Exact power balancing according to physics:
     * Generation (Solar + GridImport + BatteryDischarge) == Consumption (HomeLoad + EV + BatteryCharge + GridExport)
     */
    private fun recomputePhysicsForTime(hour: Int, minute: Int, addFluctuation: Boolean = false) {
        val jitter = if (addFluctuation) (Random.nextDouble() - 0.5) * 0.1 else 0.0

        // 1. Solar generation curve based on hour (peak around 12:30)
        val solarBaseKw = when (hour) {
            in 6..8 -> 0.8 + (hour - 6) * 1.1
            in 9..11 -> 3.2 + (hour - 9) * 1.3
            in 12..14 -> 5.8 + (14 - hour) * 0.4
            in 15..17 -> 3.4 - (hour - 15) * 1.2
            in 18..19 -> max(0.0, 0.6 - (hour - 18) * 0.4)
            else -> 0.0
        }
        val currentSolarKw = max(0.0, (solarBaseKw + jitter)).let { (it * 10).roundToInt() / 10.0 }

        // 2. Base home loads (HVAC, lighting, appliances, baseload)
        val isOccupied = hour in 6..8 || hour in 17..23
        val hvacKw = if (hour in 6..9 || hour in 17..22) 1.4 else 0.7
        val lightingKw = if (hour >= 18 || hour <= 7) 0.5 else 0.1
        val appliancesKw = if (hour in 18..20) 1.2 else 0.4
        val baseloadKw = 0.35
        val homeLoadKw = (hvacKw + lightingKw + appliancesKw + baseloadKw + jitter * 0.5)
            .let { (it * 10).roundToInt() / 10.0 }

        // 3. EV Load
        val evCurrent = _ev.value
        val evKw = if (evCurrent.isCharging) {
            when (evCurrent.activeMode) {
                EVSmartMode.SOLAR_SURPLUS -> max(0.0, currentSolarKw - homeLoadKw).coerceAtMost(7.4)
                EVSmartMode.CHEAPEST -> if (hour in 0..4 || hour >= 23) 7.4 else 0.0
                EVSmartMode.FAST -> 7.4
                else -> 7.4
            }
        } else 0.0

        val totalDemand = homeLoadKw + evKw
        val isOutage = _isOutageSimulated.value

        var batteryKw = 0.0
        var batteryDir = FlowDirection.IDLE
        var gridKw = 0.0
        var gridDir = FlowDirection.IDLE

        if (isOutage) {
            // Grid is down: Solar supplies what it can, battery supplies the rest. No export/import.
            gridKw = 0.0
            gridDir = FlowDirection.IDLE
            val surplus = currentSolarKw - totalDemand
            if (surplus > 0) {
                batteryKw = surplus.coerceAtMost(3.6)
                batteryDir = FlowDirection.CHARGING_IMPORTING
            } else {
                batteryKw = (totalDemand - currentSolarKw).coerceAtMost(5.0)
                batteryDir = FlowDirection.DISCHARGING_EXPORTING
            }
        } else {
            // Normal Grid connected
            val surplus = currentSolarKw - totalDemand
            if (surplus > 0) {
                // Surplus solar: First charge battery up to 3.2 kW, then export remainder to grid
                val currentSoc = _battery.value.socPct
                if (currentSoc < 100) {
                    val chargeCapacity = 3.2
                    batteryKw = min(surplus, chargeCapacity)
                    batteryDir = FlowDirection.CHARGING_IMPORTING
                    val exportRemainder = surplus - batteryKw
                    if (exportRemainder > 0.1) {
                        gridKw = exportRemainder
                        gridDir = FlowDirection.DISCHARGING_EXPORTING // exporting to grid
                    }
                } else {
                    gridKw = surplus
                    gridDir = FlowDirection.DISCHARGING_EXPORTING
                }
            } else {
                // Deficit: Load exceeds solar
                val deficit = totalDemand - currentSolarKw
                val currentSoc = _battery.value.socPct
                if (currentSoc > 20 && _battery.value.activeMode != BatteryMode.BACKUP) {
                    val dischargeCapacity = 3.0
                    batteryKw = min(deficit, dischargeCapacity)
                    batteryDir = FlowDirection.DISCHARGING_EXPORTING // discharging from battery
                    val importRemainder = deficit - batteryKw
                    if (importRemainder > 0.05) {
                        gridKw = importRemainder
                        gridDir = FlowDirection.CHARGING_IMPORTING // importing from grid
                    }
                } else {
                    gridKw = deficit
                    gridDir = FlowDirection.CHARGING_IMPORTING
                }
            }
        }

        // Clean precision
        val finalSolar = (currentSolarKw * 10).roundToInt() / 10.0
        val finalHomeLoad = (homeLoadKw * 10).roundToInt() / 10.0
        val finalEv = (evKw * 10).roundToInt() / 10.0
        val finalBattery = (batteryKw * 10).roundToInt() / 10.0
        val finalGrid = (gridKw * 10).roundToInt() / 10.0

        _powerFlow.value = PowerFlowState(
            solarKw = finalSolar,
            homeLoadKw = finalHomeLoad,
            batteryKw = finalBattery,
            batteryDirection = batteryDir,
            gridKw = finalGrid,
            gridDirection = gridDir,
            evKw = finalEv,
            hvacKw = (hvacKw * 10).roundToInt() / 10.0,
            waterHeatingKw = if (hour in 4..5) 1.8 else 0.0,
            appliancesKw = (appliancesKw * 10).roundToInt() / 10.0,
            lightingKw = (lightingKw * 10).roundToInt() / 10.0
        )

        // Meter state
        val totalActiveKw = if (gridDir == FlowDirection.CHARGING_IMPORTING) finalGrid else -finalGrid
        val currentAmps = (max(0.2, finalGrid) * 1000.0 / 230.0).let { (it * 10).roundToInt() / 10.0 }
        _meter.value = _meter.value.copy(
            activePowerKw = totalActiveKw,
            currentA = currentAmps,
            voltageV = 230.0 + (if (finalSolar > 4.0) 2.4 else -1.2)
        )

        // Solar stats
        _solar.value = _solar.value.copy(
            currentGenerationKw = finalSolar,
            todayGenerationKwh = (14.2 + (hour * 0.6)).let { (it * 10).roundToInt() / 10.0 }
        )

        // Battery state update
        val batterySocDelta = if (batteryDir == FlowDirection.CHARGING_IMPORTING) 1 else if (batteryDir == FlowDirection.DISCHARGING_EXPORTING) -1 else 0
        val newSoc = (_battery.value.socPct + (if (addFluctuation) batterySocDelta else 0)).coerceIn(15, 100)
        val runtimeEstimate = if (finalHomeLoad > 0) ((newSoc / 100.0) * 13.5) / max(0.5, finalHomeLoad) else 18.0
        _battery.value = _battery.value.copy(
            socPct = newSoc,
            powerKw = finalBattery,
            backupRuntimeHours = (runtimeEstimate * 10).roundToInt() / 10.0
        )

        // Carbon
        _carbon.value = _carbon.value.copy(
            currentGCo2PerKwh = if (hour in 11..16) 112 else if (hour in 17..20) 228 else 142,
            rating = if (hour in 11..16) "VERY LOW" else if (hour in 17..20) "HIGH" else "LOW"
        )
    }
}
