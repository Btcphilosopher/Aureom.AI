package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.FlowDirection
import com.example.core.model.PowerFlowState
import com.example.ui.theme.*

@Composable
fun LiveEnergyFlowCanvas(
    powerFlow: PowerFlowState,
    isOutage: Boolean,
    modifier: Modifier = Modifier
) {
    // Pulse animation for flow lines
    val infiniteTransition = rememberInfiniteTransition(label = "energyPulse")
    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulsePhase"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(AppleDarkSurface)
            .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "iENERGY · REAL-TIME POWER BUS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )
                Text(
                    text = if (isOutage) "GRID OFFLINE · MICROGRID ACTIVE" else "230V SINGLE-PHASE BALANCED",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isOutage) AppleCriticalRed else AppleEnergyGreen
                )
            }

            // Power balance tag
            val totalIn = powerFlow.solarKw + (if (powerFlow.gridDirection == FlowDirection.CHARGING_IMPORTING) powerFlow.gridKw else 0.0) +
                    (if (powerFlow.batteryDirection == FlowDirection.DISCHARGING_EXPORTING) powerFlow.batteryKw else 0.0)
            val totalOut = powerFlow.homeLoadKw + powerFlow.evKw + (if (powerFlow.gridDirection == FlowDirection.DISCHARGING_EXPORTING) powerFlow.gridKw else 0.0) +
                    (if (powerFlow.batteryDirection == FlowDirection.CHARGING_IMPORTING) powerFlow.batteryKw else 0.0)

            Text(
                text = "IN %.1f kW = OUT %.1f kW".format(totalIn, totalOut),
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = AppleTextTertiary
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 2D Engineering Diagram
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
        ) {
            // Background Canvas drawing the connection lines and animated dots
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                // Node coordinates
                val solarPos = Offset(w * 0.5f, h * 0.12f)
                val homePos = Offset(w * 0.5f, h * 0.50f)
                val batteryPos = Offset(w * 0.20f, h * 0.50f)
                val evPos = Offset(w * 0.80f, h * 0.50f)
                val gridPos = Offset(w * 0.5f, h * 0.88f)

                // 1. Solar -> Home line
                drawFlowLine(
                    start = solarPos,
                    end = homePos,
                    color = AppleSolarAmber,
                    active = powerFlow.solarKw > 0.1,
                    pulseProgress = pulsePhase,
                    forward = true
                )

                // 2. Battery <-> Home line
                if (powerFlow.batteryKw > 0.05) {
                    val forward = powerFlow.batteryDirection == FlowDirection.DISCHARGING_EXPORTING // battery to home
                    drawFlowLine(
                        start = batteryPos,
                        end = homePos,
                        color = AppleEnergyGreen,
                        active = true,
                        pulseProgress = pulsePhase,
                        forward = forward
                    )
                } else {
                    drawLine(
                        color = AppleBorder,
                        start = batteryPos,
                        end = homePos,
                        strokeWidth = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }

                // 3. Home -> EV line
                if (powerFlow.evKw > 0.1) {
                    drawFlowLine(
                        start = homePos,
                        end = evPos,
                        color = AppleElectricBlue,
                        active = true,
                        pulseProgress = pulsePhase,
                        forward = true
                    )
                } else {
                    drawLine(
                        color = AppleBorder,
                        start = homePos,
                        end = evPos,
                        strokeWidth = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }

                // 4. Grid <-> Home line
                if (!isOutage && powerFlow.gridKw > 0.05) {
                    val forward = powerFlow.gridDirection == FlowDirection.CHARGING_IMPORTING // grid to home
                    drawFlowLine(
                        start = gridPos,
                        end = homePos,
                        color = if (forward) AppleElectricBlue else AppleEnergyGreen,
                        active = true,
                        pulseProgress = pulsePhase,
                        forward = forward
                    )
                } else {
                    drawLine(
                        color = if (isOutage) AppleCriticalRed.copy(alpha = 0.4f) else AppleBorder,
                        start = gridPos,
                        end = homePos,
                        strokeWidth = 2.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }
            }

            // Interactive Node Widgets placed on top of coordinates
            // Top: Solar
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .width(130.dp)
            ) {
                EnergyNodeCard(
                    title = "SOLAR",
                    value = "%.1f kW".format(powerFlow.solarKw),
                    subtext = "Array Gen",
                    color = AppleSolarAmber
                )
            }

            // Left: Battery
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(105.dp)
            ) {
                val dirSymbol = when (powerFlow.batteryDirection) {
                    FlowDirection.CHARGING_IMPORTING -> "↓ Charge"
                    FlowDirection.DISCHARGING_EXPORTING -> "↑ Supply"
                    FlowDirection.IDLE -> "Standby"
                }
                EnergyNodeCard(
                    title = "BATTERY",
                    value = "%.1f kW".format(powerFlow.batteryKw),
                    subtext = dirSymbol,
                    color = AppleEnergyGreen
                )
            }

            // Center: Home
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .width(120.dp)
            ) {
                EnergyNodeCard(
                    title = "HOME LOAD",
                    value = "%.1f kW".format(powerFlow.homeLoadKw),
                    subtext = "Live Demand",
                    color = AppleTextPrimary,
                    isCenter = true
                )
            }

            // Right: EV
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(105.dp)
            ) {
                EnergyNodeCard(
                    title = "EV CAR",
                    value = "%.1f kW".format(powerFlow.evKw),
                    subtext = if (powerFlow.evKw > 0.1) "Charging" else "Ready",
                    color = AppleElectricBlue
                )
            }

            // Bottom: Grid
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .width(130.dp)
            ) {
                val gridLabel = if (isOutage) "OFFLINE" else when (powerFlow.gridDirection) {
                    FlowDirection.CHARGING_IMPORTING -> "Importing"
                    FlowDirection.DISCHARGING_EXPORTING -> "Exporting"
                    FlowDirection.IDLE -> "Balanced"
                }
                EnergyNodeCard(
                    title = "GRID",
                    value = if (isOutage) "0.0 kW" else "%.1f kW".format(powerFlow.gridKw),
                    subtext = gridLabel,
                    color = if (isOutage) AppleCriticalRed else if (powerFlow.gridDirection == FlowDirection.DISCHARGING_EXPORTING) AppleEnergyGreen else AppleElectricBlue
                )
            }
        }
    }
}

@Composable
private fun EnergyNodeCard(
    title: String,
    value: String,
    subtext: String,
    color: Color,
    isCenter: Boolean = false
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isCenter) AppleDarkSurfaceElevated else AppleDarkSurfaceHighlight)
            .border(
                1.dp,
                if (isCenter) AppleTextSecondary.copy(alpha = 0.4f) else color.copy(alpha = 0.5f),
                RoundedCornerShape(10.dp)
            )
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = AppleTextSecondary,
            letterSpacing = 0.5.sp
        )
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = subtext,
            fontSize = 9.sp,
            color = AppleTextTertiary
        )
    }
}

private fun DrawScope.drawFlowLine(
    start: Offset,
    end: Offset,
    color: Color,
    active: Boolean,
    pulseProgress: Float,
    forward: Boolean
) {
    // Solid trace
    drawLine(
        color = color.copy(alpha = if (active) 0.35f else 0.1f),
        start = start,
        end = end,
        strokeWidth = 3.dp.toPx(),
        cap = StrokeCap.Round
    )

    if (active) {
        // Animated moving pulse dot
        val t = if (forward) pulseProgress else (1f - pulseProgress)
        val pulsePos = Offset(
            x = start.x + (end.x - start.x) * t,
            y = start.y + (end.y - start.y) * t
        )
        drawCircle(
            color = color,
            radius = 4.5.dp.toPx(),
            center = pulsePos
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.8f),
            radius = 2.dp.toPx(),
            center = pulsePos
        )
    }
}
