package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.core.simulation.HouseSimulationTime
import com.example.ui.components.ArchitecturalHouseView
import com.example.ui.components.LiveEnergyFlowCanvas
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    simTime: HouseSimulationTime,
    powerFlow: PowerFlowState,
    rooms: List<Room>,
    security: SecurityStatus,
    ev: EVChargingState,
    scenes: List<SceneItem>,
    isOutage: Boolean,
    isLeak: Boolean,
    onNavigateToEnergy: () -> Unit,
    onNavigateToRooms: (RoomId?) -> Unit,
    onNavigateToSecurity: () -> Unit,
    onNavigateToEV: () -> Unit,
    onRunScene: (SceneId) -> Unit,
    onToggleDemoMode: () -> Unit,
    onTogglePowerOutage: () -> Unit,
    onToggleWaterLeak: () -> Unit,
    onSetSimHour: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val livingRoom = rooms.find { it.id.value == "room_living" }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppleDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Apple OS Header with Greeting & House Identity
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val greeting = when (simTime.hour) {
                        in 5..11 -> "Good morning"
                        in 12..17 -> "Good afternoon"
                        else -> "Good evening"
                    }
                    Text(
                        text = "$greeting · Apple House",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = AppleTextSecondary
                    )

                    // Simulation mode pill
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (simTime.isDemoRunning) AppleSolarAmber.copy(alpha = 0.2f) else AppleDarkSurfaceElevated)
                            .border(1.dp, if (simTime.isDemoRunning) AppleSolarAmber else AppleBorder, RoundedCornerShape(12.dp))
                            .clickable { onToggleDemoMode() }
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (simTime.isDemoRunning) AppleSolarAmber else AppleEnergyGreen)
                        )
                        Text(
                            text = if (simTime.isDemoRunning) "DEMO RUNNING (${simTime.formatted})" else "TIME ${simTime.formatted}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (simTime.isDemoRunning) AppleSolarAmber else AppleTextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "HOME",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.5).sp,
                            color = AppleTextPrimary
                        )
                        Text(
                            text = "Comfortable · Secure · Efficient",
                            fontSize = 14.sp,
                            color = AppleTextSecondary
                        )
                    }

                    // Emergency Badge if active
                    if (isOutage || isLeak) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AppleCriticalRed.copy(alpha = 0.2f))
                                .border(1.dp, AppleCriticalRed, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isOutage) "GRID OUTAGE" else "LEAK ISOLATED",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleCriticalRed
                            )
                        }
                    }
                }
            }
        }

        // 2. High-Level House Status Strip
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusMetricItem(icon = Icons.Rounded.Thermostat, title = "21.4°C", subtitle = "Living Zone", tint = AppleSolarAmber)
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(AppleDivider))
                StatusMetricItem(icon = Icons.Rounded.Air, title = "Good", subtitle = "Air Quality", tint = AppleWaterCyan)
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(AppleDivider))
                StatusMetricItem(icon = Icons.Rounded.People, title = "2 Home", subtitle = "Tom & Sarah", tint = AppleElectricBlue)
                Box(modifier = Modifier.width(1.dp).height(24.dp).background(AppleDivider))
                StatusMetricItem(
                    icon = if (security.allDoorsLocked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                    title = if (security.allDoorsLocked) "Locked" else "Open",
                    subtitle = "Security",
                    tint = if (security.allDoorsLocked) AppleEnergyGreen else AppleSolarAmber
                )
            }
        }

        // 3. Quick Actions
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "QUICK ACTIONS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    items(scenes) { scene ->
                        QuickActionPill(
                            title = scene.name,
                            iconName = scene.iconName,
                            isActive = scene.isActive,
                            onClick = { onRunScene(scene.id) }
                        )
                    }
                }
            }
        }

        // 4. Live Power Flow Bus (iEnergy Primary Visualizer)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "iENERGY · POWER FLOW",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = AppleTextSecondary
                    )
                    Text(
                        text = "Open iEnergy Hub →",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = AppleElectricBlue,
                        modifier = Modifier
                            .clickable { onNavigateToEnergy() }
                            .testTag("nav_to_energy_button")
                    )
                }

                LiveEnergyFlowCanvas(
                    powerFlow = powerFlow,
                    isOutage = isOutage
                )
            }
        }

        // 5. Architectural House Blueprint
        item {
            ArchitecturalHouseView(
                rooms = rooms,
                selectedRoomId = null,
                onRoomSelected = { roomId -> onNavigateToRooms(roomId) }
            )
        }

        // 6. Subsystem Status Cards (Climate, Security, Vehicle)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "SYSTEM STATUS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                // Climate Card
                SubsystemSummaryCard(
                    title = "CLIMATE",
                    headline = "Living Room 21.4°C · Target 21.0°C",
                    subtext = "Heating ON · Heat Pump COP 3.8 · 48% RH",
                    icon = Icons.Rounded.Thermostat,
                    accentColor = AppleSolarAmber,
                    onClick = { onNavigateToRooms(RoomId("room_living")) }
                )

                // Security Card
                SubsystemSummaryCard(
                    title = "SECURITY",
                    headline = if (security.allDoorsLocked) "All Doors Locked · 3 Cameras Active" else "Front Door Unlocked",
                    subtext = "Perimeter secure · Motion sensors normal · No alerts",
                    icon = Icons.Rounded.Shield,
                    accentColor = if (security.allDoorsLocked) AppleEnergyGreen else AppleCriticalRed,
                    onClick = { onNavigateToSecurity() }
                )

                // Vehicle Card
                SubsystemSummaryCard(
                    title = "VEHICLE",
                    headline = "${ev.vehicleName} · ${ev.socPct}%",
                    subtext = if (ev.isCharging) "Charging at ${ev.chargingRateKw} kW · Ready ${ev.readyTime} (Target ${ev.targetSocPct}%)" else "Plugged In · Standby",
                    icon = Icons.Rounded.ElectricCar,
                    accentColor = AppleElectricBlue,
                    onClick = { onNavigateToEV() }
                )
            }
        }

        // 7. Digital Twin Simulation Controller
        item {
            DigitalTwinSimulationBar(
                simTime = simTime,
                isOutage = isOutage,
                isLeak = isLeak,
                onToggleDemo = onToggleDemoMode,
                onToggleOutage = onTogglePowerOutage,
                onToggleLeak = onToggleWaterLeak,
                onSetHour = onSetSimHour
            )
        }
    }
}

@Composable
private fun StatusMetricItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
        Column {
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AppleTextPrimary)
            Text(text = subtitle, fontSize = 10.sp, color = AppleTextSecondary)
        }
    }
}

@Composable
private fun QuickActionPill(
    title: String,
    iconName: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    val icon = when (iconName) {
        "night" -> Icons.Rounded.Bedtime
        "arrive" -> Icons.Rounded.Home
        "leave" -> Icons.Rounded.ExitToApp
        "movie" -> Icons.Rounded.Movie
        "dinner" -> Icons.Rounded.Restaurant
        else -> Icons.Rounded.Bolt
    }

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isActive) AppleElectricBlue else AppleDarkSurfaceElevated)
            .border(1.dp, if (isActive) AppleElectricBlue else AppleBorder, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("quick_action_${iconName}")
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isActive) Color.White else AppleTextPrimary,
            modifier = Modifier.size(14.dp)
        )
        Text(
            text = title.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (isActive) Color.White else AppleTextPrimary,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
private fun SubsystemSummaryCard(
    title: String,
    headline: String,
    subtext: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(AppleDarkSurface)
            .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("summary_card_${title.lowercase()}")
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(accentColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(22.dp))
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor,
                letterSpacing = 0.8.sp
            )
            Text(
                text = headline,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = AppleTextPrimary
            )
            Text(
                text = subtext,
                fontSize = 11.sp,
                color = AppleTextSecondary
            )
        }

        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = AppleTextTertiary,
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun DigitalTwinSimulationBar(
    simTime: HouseSimulationTime,
    isOutage: Boolean,
    isLeak: Boolean,
    onToggleDemo: () -> Unit,
    onToggleOutage: () -> Unit,
    onToggleLeak: () -> Unit,
    onSetHour: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(AppleDarkSurfaceHighlight)
            .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DIGITAL TWIN SIMULATOR",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = AppleSolarAmber
                )
                Text(
                    text = "Scenario: ${simTime.scenarioName}",
                    fontSize = 11.sp,
                    color = AppleTextSecondary
                )
            }

            Button(
                onClick = onToggleDemo,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (simTime.isDemoRunning) AppleSolarAmber else AppleElectricBlue
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("run_simulation_button")
            ) {
                Text(
                    text = if (simTime.isDemoRunning) "PAUSE DEMO" else "RUN SIMULATION",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Hour Quick Jumps (06:30, 09:00, 12:30, 17:30, 21:00, 23:00)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf(6 to "06:30 Wake", 9 to "09:00 Solar", 12 to "12:30 Peak", 17 to "17:30 Return", 21 to "21:00 Dim", 23 to "23:00 Night").forEach { (hr, label) ->
                val isSelected = simTime.hour == hr
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) AppleElectricBlue else AppleDarkSurfaceElevated)
                        .clickable { onSetHour(hr) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = label.split(" ")[0],
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else AppleTextSecondary
                    )
                }
            }
        }

        // Outage & Leak emergency test triggers
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onToggleOutage,
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .testTag("simulate_outage_toggle"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (isOutage) AppleCriticalRed else AppleTextSecondary
                ),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isOutage) AppleCriticalRed else AppleBorder)
                )
            ) {
                Text(
                    text = if (isOutage) "RESTORE GRID" else "SIMULATE OUTAGE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = onToggleLeak,
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .testTag("simulate_leak_toggle"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (isLeak) AppleCriticalRed else AppleTextSecondary
                ),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = androidx.compose.ui.graphics.SolidColor(if (isLeak) AppleCriticalRed else AppleBorder)
                )
            ) {
                Text(
                    text = if (isLeak) "CLEAR LEAK" else "SIMULATE LEAK",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
