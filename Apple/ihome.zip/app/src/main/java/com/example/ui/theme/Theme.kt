package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val AppleColorScheme = darkColorScheme(
    primary = AppleElectricBlue,
    onPrimary = Color.White,
    primaryContainer = AppleDarkSurfaceElevated,
    onPrimaryContainer = AppleTextPrimary,
    secondary = AppleEnergyGreen,
    onSecondary = Color.Black,
    secondaryContainer = AppleDarkSurfaceHighlight,
    onSecondaryContainer = AppleTextPrimary,
    tertiary = AppleSolarAmber,
    onTertiary = Color.Black,
    background = AppleDarkBackground,
    onBackground = AppleTextPrimary,
    surface = AppleDarkSurface,
    onSurface = AppleTextPrimary,
    surfaceVariant = AppleDarkSurfaceElevated,
    onSurfaceVariant = AppleTextSecondary,
    outline = AppleBorder,
    outlineVariant = AppleDivider,
    error = AppleCriticalRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = AppleDarkBackground.toArgb()
            window.navigationBarColor = AppleDarkBackground.toArgb()
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = false
            insetsController.isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = AppleColorScheme,
        typography = Typography,
        content = content
    )
}
