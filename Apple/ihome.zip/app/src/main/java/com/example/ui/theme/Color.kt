package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Apple-inspired Smart Home Palette (Graphite & Pure Accents)
val AppleDarkBackground = Color(0xFF0C0E12)
val AppleDarkSurface = Color(0xFF14171E)
val AppleDarkSurfaceElevated = Color(0xFF1B202A)
val AppleDarkSurfaceHighlight = Color(0xFF242A37)
val AppleBorder = Color(0xFF282E3C)
val AppleDivider = Color(0xFF1F2430)

// Apple Semantic Accent Colors
val AppleEnergyGreen = Color(0xFF30D158)      // Healthy solar, high battery, safe
val AppleSolarAmber = Color(0xFFFF9F0A)       // Solar generation, warmth, lighting
val AppleElectricBlue = Color(0xFF0A84FF)     // Grid, connectivity, EV, flow
val AppleWaterCyan = Color(0xFF64D2FF)        // Water system, cooling, air quality
val AppleCriticalRed = Color(0xFFFF453A)      // Alarms, leaks, grid outage, unlocked security
val AppleSoftLilac = Color(0xFFBF5AF2)        // Scenes, automations
val AppleTextPrimary = Color(0xFFF5F5F7)      // Crisp warm white
val AppleTextSecondary = Color(0xFF86868B)    // Apple secondary gray
val AppleTextTertiary = Color(0xFF636366)     // Muted caption
val AppleTextDim = Color(0xFF48484A)
