package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.theme.*

@Composable
fun RoomsScreen(
    rooms: List<Room>,
    devices: List<Device>,
    initialSelectedRoomId: RoomId?,
    onToggleDevicePower: (DeviceId) -> Unit,
    onSetBrightness: (DeviceId, Int) -> Unit,
    onSetColorTemp: (DeviceId, Int) -> Unit,
    onSetRoomTargetTemp: (RoomId, Double) -> Unit,
    onSetBlindsPosition: (DeviceId, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedRoomId by remember {
        mutableStateOf(initialSelectedRoomId ?: rooms.firstOrNull()?.id ?: RoomId("room_living"))
    }

    val currentRoom = rooms.find { it.id == selectedRoomId } ?: rooms.firstOrNull()
    val roomDevices = devices.filter { it.roomId == selectedRoomId }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppleDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "ZONED ENVIRONMENTS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )
                Text(
                    text = "Rooms & Devices",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppleTextPrimary
                )
            }
        }

        // Room Selector Horizontal Tabs
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(rooms) { rm ->
                    val isSelected = rm.id == selectedRoomId
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) AppleElectricBlue else AppleDarkSurfaceElevated)
                            .border(1.dp, if (isSelected) AppleElectricBlue else AppleBorder, RoundedCornerShape(12.dp))
                            .clickable { selectedRoomId = rm.id }
                            .testTag("room_tab_${rm.id.value}")
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Column {
                            Text(
                                text = rm.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else AppleTextPrimary
                            )
                            Text(
                                text = "${rm.currentTempC}°C · ${rm.floorName}",
                                fontSize = 10.sp,
                                color = if (isSelected) Color.White.copy(alpha = 0.8f) else AppleTextSecondary
                            )
                        }
                    }
                }
            }
        }

        if (currentRoom != null) {
            // Room Overview Card (Climate, Air Quality, Media)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(AppleDarkSurface)
                        .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = currentRoom.name.uppercase(),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleTextPrimary
                            )
                            Text(
                                text = "${currentRoom.floorName} · ${currentRoom.humidityPct}% Humidity",
                                fontSize = 12.sp,
                                color = AppleTextSecondary
                            )
                        }

                        // Air Quality Pill
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(AppleWaterCyan.copy(alpha = 0.15f))
                                .border(1.dp, AppleWaterCyan, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "CO₂ ${currentRoom.co2Ppm} ppm · PM2.5 ${currentRoom.pm25} µg",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppleWaterCyan
                            )
                        }
                    }

                    // Climate Predictive Heating Control
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(AppleDarkSurfaceElevated)
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    imageVector = Icons.Rounded.Thermostat,
                                    contentDescription = null,
                                    tint = AppleSolarAmber,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text("iClimate Precision Target", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = AppleTextPrimary)
                            }

                            Text(
                                text = if (currentRoom.heatingActive) "HEATING ACTIVE (~${currentRoom.estimatedHeatingMinutes}m to target)" else "TARGET REACHED",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (currentRoom.heatingActive) AppleSolarAmber else AppleEnergyGreen
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Current: ${currentRoom.currentTempC}°C",
                                fontSize = 13.sp,
                                color = AppleTextSecondary
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                IconButton(
                                    onClick = { onSetRoomTargetTemp(currentRoom.id, currentRoom.targetTempC - 0.5) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(AppleDarkSurfaceHighlight, CircleShape)
                                ) {
                                    Icon(imageVector = Icons.Rounded.Remove, contentDescription = "Decrease", tint = AppleTextPrimary)
                                }

                                Text(
                                    text = "%.1f°C".format(currentRoom.targetTempC),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AppleSolarAmber
                                )

                                IconButton(
                                    onClick = { onSetRoomTargetTemp(currentRoom.id, currentRoom.targetTempC + 0.5) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(AppleDarkSurfaceHighlight, CircleShape)
                                ) {
                                    Icon(imageVector = Icons.Rounded.Add, contentDescription = "Increase", tint = AppleTextPrimary)
                                }
                            }
                        }
                    }

                    // Media Status if active
                    if (currentRoom.activeMediaTitle != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(AppleDarkSurfaceHighlight)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(imageVector = Icons.Rounded.Speaker, contentDescription = null, tint = AppleElectricBlue)
                            Column {
                                Text("AUDIO / MEDIA", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AppleTextTertiary)
                                Text(currentRoom.activeMediaTitle, fontSize = 12.sp, color = AppleTextPrimary)
                            }
                        }
                    }
                }
            }

            // Lights Subsystem Section
            val lightDevices = roomDevices.filter { it.category == DeviceCategory.LIGHT }
            if (lightDevices.isNotEmpty()) {
                item {
                    Text(
                        text = "LIGHTING (${lightDevices.count { it.isOn }} ACTIVE)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = AppleTextSecondary
                    )
                }

                items(lightDevices) { light ->
                    LightControlCard(
                        device = light,
                        onToggle = { onToggleDevicePower(light.id) },
                        onBrightnessChange = { onSetBrightness(light.id, it) },
                        onColorTempChange = { onSetColorTemp(light.id, it) }
                    )
                }
            }

            // Blinds / Shades Section
            val blindDevices = roomDevices.filter { it.category == DeviceCategory.BLINDS }
            if (blindDevices.isNotEmpty()) {
                item {
                    Text(
                        text = "AUTOMATED SHADES & BLINDS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = AppleTextSecondary
                    )
                }

                items(blindDevices) { blind ->
                    BlindsControlCard(
                        device = blind,
                        onPositionChange = { onSetBlindsPosition(blind.id, it) }
                    )
                }
            }

            // Other Devices & Locks
            val otherDevices = roomDevices.filter { it.category != DeviceCategory.LIGHT && it.category != DeviceCategory.BLINDS }
            if (otherDevices.isNotEmpty()) {
                item {
                    Text(
                        text = "OTHER DEVICES & HARDWARE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = AppleTextSecondary
                    )
                }

                items(otherDevices) { dev ->
                    OtherDeviceCard(device = dev)
                }
            }
        }
    }
}

@Composable
private fun LightControlCard(
    device: Device,
    onToggle: () -> Unit,
    onBrightnessChange: (Int) -> Unit,
    onColorTempChange: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(AppleDarkSurface)
            .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (device.isOn) AppleSolarAmber.copy(alpha = 0.2f) else AppleDarkSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lightbulb,
                        contentDescription = null,
                        tint = if (device.isOn) AppleSolarAmber else AppleTextTertiary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(text = device.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AppleTextPrimary)
                    Text(
                        text = if (device.isOn) "${device.brightnessPct}% · ${device.colorTempK}K Warm" else "OFF",
                        fontSize = 11.sp,
                        color = AppleTextSecondary
                    )
                }
            }

            Switch(
                checked = device.isOn,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = AppleSolarAmber,
                    uncheckedThumbColor = AppleTextSecondary,
                    uncheckedTrackColor = AppleDarkSurfaceHighlight
                ),
                modifier = Modifier.testTag("light_switch_${device.id.value}")
            )
        }

        if (device.isOn) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Brightness", fontSize = 10.sp, color = AppleTextTertiary)
                    Text("${device.brightnessPct}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AppleSolarAmber)
                }
                Slider(
                    value = device.brightnessPct.toFloat(),
                    onValueChange = { onBrightnessChange(it.toInt()) },
                    valueRange = 1f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = AppleSolarAmber,
                        activeTrackColor = AppleSolarAmber,
                        inactiveTrackColor = AppleDarkSurfaceHighlight
                    ),
                    modifier = Modifier.height(28.dp)
                )

                // Color Temperature Presets
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("White Balance", fontSize = 10.sp, color = AppleTextTertiary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(2700 to "2700K Warm", 3000 to "3000K Soft", 4000 to "4000K Neutral", 5000 to "5000K Daylight").forEach { (kelvin, label) ->
                            val isSel = device.colorTempK == kelvin
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) AppleSolarAmber else AppleDarkSurfaceElevated)
                                    .clickable { onColorTempChange(kelvin) }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = label.split(" ")[0],
                                    fontSize = 9.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) Color.Black else AppleTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BlindsControlCard(
    device: Device,
    onPositionChange: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(AppleDarkSurface)
            .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(imageVector = Icons.Rounded.Blinds, contentDescription = null, tint = AppleElectricBlue)
                Column {
                    Text(text = device.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AppleTextPrimary)
                    Text(text = "${device.positionPct}% Open", fontSize = 11.sp, color = AppleTextSecondary)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = { onPositionChange(0) },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("Close", fontSize = 10.sp)
                }
                Button(
                    onClick = { onPositionChange(100) },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("Open", fontSize = 10.sp)
                }
            }
        }

        Slider(
            value = device.positionPct.toFloat(),
            onValueChange = { onPositionChange(it.toInt()) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = AppleElectricBlue,
                activeTrackColor = AppleElectricBlue,
                inactiveTrackColor = AppleDarkSurfaceHighlight
            )
        )
    }
}

@Composable
private fun OtherDeviceCard(device: Device) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(AppleDarkSurface)
            .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(
                imageVector = if (device.category == DeviceCategory.SECURITY_LOCK) Icons.Rounded.Lock else Icons.Rounded.Devices,
                contentDescription = null,
                tint = if (device.isLocked) AppleEnergyGreen else AppleCriticalRed
            )
            Column {
                Text(text = device.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AppleTextPrimary)
                Text(
                    text = "${device.connectivity.name.replace("_", " ")} · ${device.health.signalStrength} Signal",
                    fontSize = 11.sp,
                    color = AppleTextSecondary
                )
            }
        }

        if (device.health.batteryPct != null) {
            Text(
                text = "${device.health.batteryPct}% BAT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = AppleTextTertiary
            )
        }
    }
}
