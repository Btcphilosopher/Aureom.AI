package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rooms")
data class RoomEntity(
    @PrimaryKey val id: String,
    val floorName: String,
    val name: String,
    val targetTempC: Double,
    val currentTempC: Double,
    val humidityPct: Int,
    val co2Ppm: Int,
    val airQualityRating: String
)

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val id: String,
    val roomId: String,
    val name: String,
    val category: String,
    val isOn: Boolean,
    val brightnessPct: Int,
    val colorTempK: Int,
    val targetTempC: Double,
    val currentTempC: Double,
    val positionPct: Int,
    val powerDrawWatts: Double,
    val isLocked: Boolean
)

@Entity(tableName = "scenes")
data class SceneEntity(
    @PrimaryKey val id: String,
    val name: String,
    val iconName: String,
    val description: String,
    val isActive: Boolean
)

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val triggerSummary: String,
    val conditionSummary: String,
    val actionSummary: String,
    val isEnabled: Boolean,
    val category: String
)

@Entity(tableName = "activity_logs")
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: String,
    val title: String,
    val detail: String,
    val subsystem: String,
    val severity: String
)

@Entity(tableName = "energy_history")
data class EnergySnapshotEntity(
    @PrimaryKey val timestampIso: String,
    val solarKwh: Double,
    val consumptionKwh: Double,
    val gridImportKwh: Double,
    val gridExportKwh: Double,
    val costPounds: Double
)
