package com.example.core.model

data class SceneItem(
    val id: SceneId,
    val name: String,
    val iconName: String, // morning, night, arrive, leave, movie, dinner, energysave
    val description: String,
    val affectedSubsystems: List<String>,
    val isActive: Boolean = false
)

data class AutomationRule(
    val id: AutomationId,
    val name: String,
    val triggerSummary: String,
    val conditionSummary: String,
    val actionSummary: String,
    val isEnabled: Boolean = true,
    val category: String, // Solar, Security, Comfort, Lighting, EV
    val lastRunTime: String = "Today, 14:32"
)

data class ActivityTimelineItem(
    val id: String,
    val timestamp: String,
    val title: String,
    val detail: String,
    val subsystem: String, // Energy, Security, Climate, Lighting, EV
    val severity: SystemSeverity = SystemSeverity.INFO
)

data class MatterClusterInfo(
    val endpointId: Int,
    val clusterId: String,
    val name: String,
    val attributeCount: Int
)

data class MatterNodeState(
    val nodeId: String,
    val deviceName: String,
    val vendor: String,
    val status: String,
    val endpoints: List<MatterClusterInfo>
)

data class ThreadNetworkStatus(
    val borderRouterOnline: Boolean = true,
    val borderRouterName: String = "iHome Hub Pro (Thread 1.3)",
    val meshNodeCount: Int = 17,
    val routerCount: Int = 5,
    val endDeviceCount: Int = 12,
    val networkHealth: String = "EXCELLENT",
    val weakLinksCount: Int = 0,
    val panId: String = "0x7F2A",
    val channel: Int = 25
)

data class HomeHubStatus(
    val primaryHubName: String = "iHome Hub (Ground Floor Utility)",
    val backupHubName: String = "Living Room Apple TV 4K",
    val state: String = "ONLINE",
    val localControlLatencyMs: Int = 18,
    val cloudSyncState: String = "ENCRYPTED_SYNCED",
    val matterFabricCount: Int = 2
)
