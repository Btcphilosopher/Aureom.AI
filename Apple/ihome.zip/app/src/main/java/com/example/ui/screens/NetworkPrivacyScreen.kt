package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.theme.*

@Composable
fun NetworkPrivacyScreen(
    threadStatus: ThreadNetworkStatus,
    homeHub: HomeHubStatus,
    matterNodes: List<MatterNodeState>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppleDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "INFRASTRUCTURE & INTEGRITY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )
                Text(
                    text = "Matter, Thread & Privacy",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppleTextPrimary
                )
            }
        }

        // Local Hub & Connectivity Overview
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "LOCAL HOME HUB ARCHITECTURE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = homeHub.primaryHubName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AppleTextPrimary)
                        Text(text = "Backup Hub: ${homeHub.backupHubName}", fontSize = 12.sp, color = AppleTextSecondary)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(AppleEnergyGreen.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("ONLINE · 18ms", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AppleEnergyGreen)
                    }
                }

                Divider(color = AppleDivider)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HubStat(label = "INTERNET", value = "ONLINE")
                    HubStat(label = "WI-FI", value = "GOOD (5 GHz)")
                    HubStat(label = "THREAD", value = "ACTIVE")
                    HubStat(label = "MATTER FABRIC", value = "2 FABRICS")
                }
            }
        }

        // Thread Mesh Network
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "THREAD LOW-POWER IP MESH",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = AppleTextSecondary
                        )
                        Text(
                            text = "${threadStatus.borderRouterName}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppleElectricBlue
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(AppleDarkSurfaceHighlight)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("PAN ${threadStatus.panId} · CH ${threadStatus.channel}", fontSize = 10.sp, color = AppleTextSecondary)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HubStat(label = "MESH NODES", value = "${threadStatus.meshNodeCount}")
                    HubStat(label = "ROUTERS", value = "${threadStatus.routerCount}")
                    HubStat(label = "ENDPOINTS", value = "${threadStatus.endDeviceCount}")
                    HubStat(label = "TOPOLOGY HEALTH", value = threadStatus.networkHealth)
                }
            }
        }

        // Matter Paired Clusters
        item {
            Text(
                text = "MATTER COMMISSIONED DEVICES",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                color = AppleTextSecondary
            )
        }

        items(matterNodes) { node ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = node.deviceName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AppleTextPrimary)
                        Text(text = "${node.vendor} · Node ${node.nodeId}", fontSize = 11.sp, color = AppleTextSecondary)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AppleEnergyGreen.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(text = node.status, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AppleEnergyGreen)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    node.endpoints.forEach { ep ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AppleDarkSurfaceElevated)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "EP ${ep.endpointId}: ${ep.name}",
                                fontSize = 10.sp,
                                color = AppleElectricBlue
                            )
                        }
                    }
                }
            }
        }

        // Privacy Centre
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "HOME PRIVACY & DATA TRANSPARENCY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )

                PrivacyRow(title = "CAMERAS", status = "100% Local Processing", desc = "Video never streams to public clouds; analysis runs on local neural hardware.")
                PrivacyRow(title = "ENERGY TELEMETRY", status = "Stored on Device", desc = "All kWh and tariff records persist strictly within local SQLite storage.")
                PrivacyRow(title = "PRESENCE & LOCATION", status = "Geofence Token Only", desc = "Raw GPS never logged. State transitions operate purely on-device.")
                PrivacyRow(title = "MICROPHONES / VOICE", status = "Disabled", desc = "No external acoustic transmission or third-party listening.")
            }
        }
    }
}

@Composable
private fun HubStat(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AppleTextTertiary)
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppleTextPrimary)
    }
}

@Composable
private fun PrivacyRow(title: String, status: String, desc: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(AppleDarkSurfaceElevated)
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppleTextPrimary)
            Text(text = status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AppleEnergyGreen)
        }
        Text(text = desc, fontSize = 11.sp, color = AppleTextSecondary)
    }
}
