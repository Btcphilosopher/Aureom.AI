package com.example.core.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface RoomDao {
    @Query("SELECT * FROM rooms")
    fun getAllRooms(): Flow<List<RoomEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRooms(rooms: List<RoomEntity>)

    @Update
    suspend fun updateRoom(room: RoomEntity)
}

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices")
    fun getAllDevices(): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM devices WHERE roomId = :roomId")
    fun getDevicesByRoom(roomId: String): Flow<List<DeviceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevices(devices: List<DeviceEntity>)

    @Update
    suspend fun updateDevice(device: DeviceEntity)

    @Query("UPDATE devices SET isOn = :isOn WHERE id = :id")
    suspend fun setDevicePower(id: String, isOn: Boolean)

    @Query("UPDATE devices SET brightnessPct = :brightness WHERE id = :id")
    suspend fun setBrightness(id: String, brightness: Int)

    @Query("UPDATE devices SET targetTempC = :temp WHERE id = :id")
    suspend fun setTargetTemp(id: String, temp: Double)

    @Query("UPDATE devices SET isLocked = :isLocked WHERE id = :id")
    suspend fun setLocked(id: String, isLocked: Boolean)
}

@Dao
interface AutomationDao {
    @Query("SELECT * FROM automations")
    fun getAllAutomations(): Flow<List<AutomationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAutomations(automations: List<AutomationEntity>)

    @Query("UPDATE automations SET isEnabled = :isEnabled WHERE id = :id")
    suspend fun setAutomationEnabled(id: String, isEnabled: Boolean)

    @Query("SELECT * FROM scenes")
    fun getAllScenes(): Flow<List<SceneEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScenes(scenes: List<SceneEntity>)

    @Query("UPDATE scenes SET isActive = :isActive WHERE id = :id")
    suspend fun setSceneActive(id: String, isActive: Boolean)
}

@Dao
interface ActivityDao {
    @Query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 50")
    fun getRecentActivities(): Flow<List<ActivityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: ActivityEntity)
}

@Database(
    entities = [
        RoomEntity::class,
        DeviceEntity::class,
        SceneEntity::class,
        AutomationEntity::class,
        ActivityEntity::class,
        EnergySnapshotEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun roomDao(): RoomDao
    abstract fun deviceDao(): DeviceDao
    abstract fun automationDao(): AutomationDao
    abstract fun activityDao(): ActivityDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ihome_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
