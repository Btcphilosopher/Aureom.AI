package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.*
import com.example.ui.components.SecurityActionConfirmationDialog
import com.example.ui.theme.*

@Composable
fun SecurityScreen(
    security: SecurityStatus,
    locks: List<Device>,
    cameras: List<CameraFeed>,
    water: WaterSystemState,
    isLeak: Boolean,
    onToggleLock: (DeviceId) -> Unit,
    onSetSecurityMode: (SecurityArmMode) -> Unit,
    onToggleWaterValve: () -> Unit,
    modifier: Modifier = Modifier
) {
    var pendingConfirmationAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var confirmationTitle by remember { mutableStateOf("") }
    var confirmationMessage by remember { mutableStateOf("") }

    if (pendingConfirmationAction != null) {
        SecurityActionConfirmationDialog(
            title = confirmationTitle,
            message = confirmationMessage,
            confirmButtonText = "Confirm Action",
            isDestructive = confirmationTitle.contains("Unlock", ignoreCase = true) || confirmationTitle.contains("Disarm", ignoreCase = true),
            onConfirm = {
                pendingConfirmationAction?.invoke()
                pendingConfirmationAction = null
            },
            onDismiss = { pendingConfirmationAction = null }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppleDarkBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "PERIMETER & ACCESS CONTROL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp,
                    color = AppleTextSecondary
                )
                Text(
                    text = "iSecure",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = AppleTextPrimary
                )
            }
        }

        // Security Arm Mode Switcher
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ALARM SYSTEM MODE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = AppleTextSecondary
                    )
                    Text(
                        text = if (security.allDoorsLocked) "SECURE · ARMED" else "PERIMETER ATTENTION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (security.allDoorsLocked) AppleEnergyGreen else AppleSolarAmber
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        SecurityArmMode.HOME_ARMED to "HOME",
                        SecurityArmMode.AWAY_ARMED to "AWAY",
                        SecurityArmMode.NIGHT_ARMED to "NIGHT",
                        SecurityArmMode.DISARMED to "DISARM"
                    ).forEach { (mode, label) ->
                        val isSel = security.armMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSel) AppleElectricBlue else AppleDarkSurfaceElevated)
                                .clickable {
                                    if (mode == SecurityArmMode.DISARMED) {
                                        confirmationTitle = "Disarm Home Alarm?"
                                        confirmationMessage = "Disarming will disable motion sensors and perimeter intrusion detection."
                                        pendingConfirmationAction = { onSetSecurityMode(mode) }
                                    } else {
                                        onSetSecurityMode(mode)
                                    }
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) Color.White else AppleTextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Emergency Alert Banner if triggered
        if (security.emergencyTriggered != null || isLeak) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(AppleCriticalRed.copy(alpha = 0.2f))
                        .border(1.5.dp, AppleCriticalRed, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(imageVector = Icons.Rounded.Warning, contentDescription = null, tint = AppleCriticalRed)
                        Column {
                            Text("SECURITY EMERGENCY DETECTED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppleCriticalRed)
                            Text(
                                text = security.emergencyTriggered ?: "Water leak sensor activated. Smart isolation valve closed.",
                                fontSize = 12.sp,
                                color = AppleTextPrimary
                            )
                        }
                    }
                }
            }
        }

        // Perimeter Smart Locks
        item {
            Text(
                text = "PERIMETER LOCKS & ENTRANCES",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                color = AppleTextSecondary
            )
        }

        items(locks) { lock ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (lock.isLocked) AppleEnergyGreen.copy(alpha = 0.15f) else AppleSolarAmber.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (lock.isLocked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                            contentDescription = null,
                            tint = if (lock.isLocked) AppleEnergyGreen else AppleSolarAmber,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(text = lock.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AppleTextPrimary)
                        Text(
                            text = if (lock.isLocked) "LOCKED · Secured" else "UNLOCKED · Open",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (lock.isLocked) AppleEnergyGreen else AppleSolarAmber
                        )
                        Text(
                            text = "Battery: ${lock.health.batteryPct ?: 90}% · Matter over Thread",
                            fontSize = 10.sp,
                            color = AppleTextTertiary
                        )
                    }
                }

                Button(
                    onClick = {
                        if (lock.isLocked) {
                            // Require explicit confirmation before unlocking door
                            confirmationTitle = "Unlock ${lock.name}?"
                            confirmationMessage = "Are you sure you want to unlock this entrance? Anyone physically outside will be able to enter."
                            pendingConfirmationAction = { onToggleLock(lock.id) }
                        } else {
                            onToggleLock(lock.id)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (lock.isLocked) AppleDarkSurfaceHighlight else AppleEnergyGreen
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("lock_action_btn_${lock.id.value}")
                ) {
                    Text(
                        text = if (lock.isLocked) "UNLOCK" else "LOCK",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (lock.isLocked) AppleTextPrimary else Color.Black
                    )
                }
            }
        }

        // iVision Camera Feeds & AI Detections
        item {
            Text(
                text = "iVISION SURVEILLANCE & EVENT TIMELINE",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.sp,
                color = AppleTextSecondary
            )
        }

        items(cameras) { cam ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Rounded.Videocam, contentDescription = null, tint = AppleElectricBlue)
                        Column {
                            Text(text = cam.name, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = AppleTextPrimary)
                            Text(text = "${cam.location} · 4K HDR", fontSize = 11.sp, color = AppleTextSecondary)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(AppleEnergyGreen.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("LIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = AppleEnergyGreen)
                    }
                }

                // Simulated Optical Preview Frame
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(AppleDarkSurfaceElevated)
                        .border(1.dp, AppleBorder, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Rounded.CameraOutdoor,
                            contentDescription = null,
                            tint = AppleTextSecondary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Live Stream Active · On-Device Analysis",
                            fontSize = 11.sp,
                            color = AppleTextSecondary
                        )
                    }
                }

                // Recent Detections
                if (cam.recentDetections.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "RECENT DETECTIONS (DEVICE VISION)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppleTextTertiary
                        )
                        cam.recentDetections.forEach { det ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AppleDarkSurfaceHighlight)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "${det.timestamp} · ${det.type}: ${det.description}", fontSize = 11.sp, color = AppleTextPrimary)
                                Text(text = "${det.confidencePct}% match", fontSize = 10.sp, color = AppleEnergyGreen)
                            }
                        }
                    }
                }
            }
        }

        // iWater Smart Valve & Leak System
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(AppleDarkSurface)
                    .border(1.dp, AppleBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "iWATER · SMART MAIN ISOLATION VALVE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp,
                            color = AppleTextSecondary
                        )
                        Text(
                            text = if (water.mainValveOpen) "VALVE OPEN · Pressure 3.2 bar" else "VALVE CLOSED · ISOLATED",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (water.mainValveOpen) AppleEnergyGreen else AppleCriticalRed
                        )
                    }

                    Button(
                        onClick = onToggleWaterValve,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (water.mainValveOpen) AppleCriticalRed else AppleEnergyGreen
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (water.mainValveOpen) "SHUT VALVE" else "OPEN VALVE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Text(
                    text = "Automated leak defense: If any moisture sensor in the house triggers, this motorised valve cuts household mains in under 800ms.",
                    fontSize = 11.sp,
                    color = AppleTextSecondary
                )
            }
        }
    }
}
