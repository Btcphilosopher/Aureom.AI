package com.example.core.model

@JvmInline
value class HomeId(val value: String)

@JvmInline
value class RoomId(val value: String)

@JvmInline
value class DeviceId(val value: String)

@JvmInline
value class AutomationId(val value: String)

@JvmInline
value class SceneId(val value: String)

@JvmInline
value class PowerReading(val kw: Double)

@JvmInline
value class EnergyReading(val kwh: Double)

@JvmInline
value class Temperature(val celsius: Double)

@JvmInline
value class Voltage(val volts: Double)

@JvmInline
value class Current(val amperes: Double)

@JvmInline
value class EnergyPrice(val pencePerKwh: Double)

@JvmInline
value class CarbonIntensity(val gCo2PerKwh: Int)

enum class NetworkStatus {
    ONLINE,
    LOCAL_ONLY,
    CLOUD_SYNCED,
    OFFLINE,
    DEGRADED
}

enum class PresenceState {
    HOME,
    AWAY,
    SLEEPING,
    ARRIVING,
    LEAVING,
    UNKNOWN
}

enum class LoadPriority {
    CRITICAL,    // e.g. Refrigerator, Medical, Security
    IMPORTANT,   // e.g. Heating, Hot Water base
    FLEXIBLE,    // e.g. EV, Battery charging
    DEFERRABLE   // e.g. Dishwasher, Washing Machine, Pool pump
}

enum class SystemSeverity {
    INFO,
    NOTICE,
    WARNING,
    CRITICAL
}
