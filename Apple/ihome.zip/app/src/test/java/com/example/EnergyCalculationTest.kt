package com.example

import com.example.core.model.*
import org.junit.Assert.*
import org.junit.Test

class EnergyCalculationTest {

    @Test
    fun testPowerAccountingReconciliation() {
        // Solar + GridImport + BatteryDischarge = HomeLoad + EV + BatteryCharge + GridExport
        val solarKw = 5.0
        val homeLoadKw = 2.0
        val batteryKw = 1.0 // charging
        val gridKw = 2.0 // export
        val evKw = 0.0

        val totalGenerationOrInflow = solarKw
        val totalConsumptionOrOutflow = homeLoadKw + batteryKw + gridKw + evKw

        assertEquals("Power inflow must reconcile exactly with outflow", totalGenerationOrInflow, totalConsumptionOrOutflow, 0.001)
    }

    @Test
    fun testBatteryOutageBackupRuntimeCalculation() {
        val batteryCapacityKwh = 13.5
        val socPct = 74
        val homeLoadKw = 1.4

        val availableEnergy = (socPct / 100.0) * batteryCapacityKwh
        val estimatedRuntimeHours = availableEnergy / homeLoadKw

        assertTrue("Runtime should exceed 7 hours under 1.4 kW load", estimatedRuntimeHours > 7.0)
    }

    @Test
    fun testEVOffPeakSavingsCalculation() {
        val energyNeededKwh = 21.4
        val peakRatePence = 28.4
        val offPeakRatePence = 7.5

        val costAtPeak = (energyNeededKwh * peakRatePence) / 100.0
        val costAtOffPeak = (energyNeededKwh * offPeakRatePence) / 100.0
        val saving = costAtPeak - costAtOffPeak

        assertTrue("Smart shifting to off-peak must yield savings", saving > 4.0)
    }

    @Test
    fun testHeatingPredictiveControl() {
        val currentTemp = 18.0
        val targetTemp = 21.0
        val degreesNeeded = targetTemp - currentTemp
        val thermalRateMinutesPerDegree = 8.0 // 8 minutes per degree C

        val estimatedMinutes = degreesNeeded * thermalRateMinutesPerDegree
        assertEquals(24.0, estimatedMinutes, 0.1)
    }
}
