"use client";

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from "react";
import {
  BrowserTab,
  BrowserWindow,
  TabGroup,
  Bookmark,
  BookmarkFolder,
  HistoryItem,
  ReadingListItem,
  DownloadItem,
  SitePermission,
  WebExtension,
  BrowserSettings,
  ConsoleLog,
  NetworkRequest,
  PerformanceMetrics,
  ReaderConfig,
  SecurityCertificateInfo,
  WindowType,
} from "@/types/browser";
import {
  loadFromStorage,
  saveToStorage,
  DEFAULT_SETTINGS,
  INITIAL_BOOKMARKS,
  INITIAL_FOLDERS,
  INITIAL_HISTORY,
  INITIAL_READING_LIST,
  INITIAL_DOWNLOADS,
  INITIAL_TAB_GROUPS,
  INITIAL_EXTENSIONS,
  INITIAL_SITE_PERMISSIONS,
} from "@/lib/storage";
import { resolveUrl, getDomainFromUrl, getFaviconForUrl, CURATED_PAGES, SEARCH_PROVIDERS } from "@/lib/curatedWebData";

interface BrowserContextType {
  // Windows
  windows: BrowserWindow[];
  activeWindowId: string;
  activeWindow: BrowserWindow | undefined;
  createNewWindow: (type?: WindowType) => void;
  closeWindow: (windowId: string) => void;
  activateWindow: (windowId: string) => void;
  toggleMinimizeWindow: (windowId: string) => void;
  toggleMaximizeWindow: (windowId: string) => void;

  // Tabs
  tabs: BrowserTab[];
  activeTab: BrowserTab | undefined;
  activeTabId: string;
  setActiveTabId: (tabId: string) => void;
  createNewTab: (url?: string, groupId?: string, windowId?: string) => string;
  closeTab: (tabId: string) => void;
  duplicateTab: (tabId: string) => void;
  reopenClosedTab: () => void;
  togglePinTab: (tabId: string) => void;
  toggleMuteTab: (tabId: string) => void;
  reorderTabs: (sourceIndex: number, destinationIndex: number) => void;
  setTabGroup: (tabId: string, groupId?: string) => void;

  // Tab Groups
  tabGroups: TabGroup[];
  createTabGroup: (name: string, color: string) => string;
  deleteTabGroup: (groupId: string) => void;
  updateTabGroup: (groupId: string, name: string, color: string) => void;

  // Navigation
  navigate: (inputUrlOrQuery: string) => void;
  goBack: () => void;
  goForward: () => void;
  reload: () => void;
  stop: () => void;
  toggleReaderMode: () => void;
  setZoomLevel: (zoom: number) => void;
  canGoBack: boolean;
  canGoForward: boolean;

  // Modals & Panels
  isSidebarOpen: boolean;
  setIsSidebarOpen: (open: boolean) => void;
  sidebarTab: "groups" | "bookmarks" | "history" | "reading" | "downloads" | "extensions" | "permissions";
  setSidebarTab: (tab: "groups" | "bookmarks" | "history" | "reading" | "downloads" | "extensions" | "permissions") => void;
  isAIDrawerOpen: boolean;
  setIsAIDrawerOpen: (open: boolean) => void;
  isWebInspectorOpen: boolean;
  setIsWebInspectorOpen: (open: boolean) => void;
  inspectorActiveTab: "elements" | "console" | "network" | "performance" | "storage";
  setInspectorActiveTab: (tab: "elements" | "console" | "network" | "performance" | "storage") => void;
  isPrivacyDashboardOpen: boolean;
  setIsPrivacyDashboardOpen: (open: boolean) => void;
  isCertificateModalOpen: boolean;
  setIsCertificateModalOpen: (open: boolean) => void;
  isDownloadsPopoverOpen: boolean;
  setIsDownloadsPopoverOpen: (open: boolean) => void;
  isExtensionsPopoverOpen: boolean;
  setIsExtensionsPopoverOpen: (open: boolean) => void;
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
  settingsActiveTab: string;
  setSettingsActiveTab: (tab: string) => void;
  isTabOverviewOpen: boolean;
  setIsTabOverviewOpen: (open: boolean) => void;
  isNativeCodeModalOpen: boolean;
  setIsNativeCodeModalOpen: (open: boolean) => void;
  isFindBarOpen: boolean;
  setIsFindBarOpen: (open: boolean) => void;
  findQuery: string;
  setFindQuery: (q: string) => void;

  // Collections
  bookmarks: Bookmark[];
  bookmarkFolders: BookmarkFolder[];
  addBookmark: (title: string, url: string, folderId?: string | null) => void;
  removeBookmark: (id: string) => void;
  editBookmark: (id: string, title: string, url: string, folderId?: string | null) => void;
  createBookmarkFolder: (name: string, parentId?: string | null) => void;

  history: HistoryItem[];
  clearHistory: (period: "hour" | "today" | "all") => void;

  readingList: ReadingListItem[];
  addToReadingList: (url: string, title: string, previewText?: string) => void;
  removeFromReadingList: (id: string) => void;
  toggleReadingListRead: (id: string) => void;

  downloads: DownloadItem[];
  startDownload: (filename: string, sourceUrl: string, totalBytes?: number) => void;
  cancelDownload: (id: string) => void;
  pauseDownload: (id: string) => void;
  resumeDownload: (id: string) => void;

  sitePermissions: Record<string, SitePermission>;
  updateSitePermission: (domain: string, patch: Partial<SitePermission>) => void;

  extensions: WebExtension[];
  toggleExtension: (id: string) => void;

  settings: BrowserSettings;
  updateSettings: (patch: Partial<BrowserSettings>) => void;

  readerConfig: ReaderConfig;
  setReaderConfig: React.Dispatch<React.SetStateAction<ReaderConfig>>;

  // Developer Logs & Diagnostics
  consoleLogs: ConsoleLog[];
  addConsoleLog: (level: ConsoleLog["level"], message: string, source?: string) => void;
  clearConsoleLogs: () => void;
  networkRequests: NetworkRequest[];
  clearNetworkRequests: () => void;
  performanceMetrics: PerformanceMetrics;
  certificateInfo: SecurityCertificateInfo;
  blockedTrackersCount: number;
}

const BrowserContext = createContext<BrowserContextType | null>(null);

export function BrowserProvider({ children }: { children: React.ReactNode }) {
  // Initialize Window & Tabs
  const [windows, setWindows] = useState<BrowserWindow[]>(() => {
    return [
      {
        id: "win-main-1",
        title: "MACWEB.OS - Apple Silicon Native",
        type: "normal",
        tabIds: ["tab-1", "tab-2", "tab-3"],
        activeTabId: "tab-1",
        isMinimized: false,
        isMaximized: false,
        bounds: { x: 0, y: 0, width: 1200, height: 800 },
        zIndex: 10,
      },
    ];
  });

  const [activeWindowId, setActiveWindowId] = useState<string>("win-main-1");

  const [tabs, setTabs] = useState<BrowserTab[]>(() => {
    return [
      {
        id: "tab-1",
        windowId: "win-main-1",
        title: "Apple - macOS Sequoia & Silicon Innovation",
        url: "https://apple.com",
        favicon: "",
        loadingState: "finished",
        progress: 100,
        isMuted: false,
        isPinned: false,
        isPrivate: false,
        groupId: "group-work",
        historyStack: ["https://apple.com"],
        historyIndex: 0,
        zoomLevel: 100,
        createdAt: Date.now() - 60000,
        lastActiveAt: Date.now(),
        isPlayingAudio: false,
      },
      {
        id: "tab-2",
        windowId: "win-main-1",
        title: "GitHub - macweb-os / macweb-browser",
        url: "https://github.com",
        favicon: "🐙",
        loadingState: "finished",
        progress: 100,
        isMuted: false,
        isPinned: false,
        isPrivate: false,
        groupId: "group-work",
        historyStack: ["https://github.com"],
        historyIndex: 0,
        zoomLevel: 100,
        createdAt: Date.now() - 40000,
        lastActiveAt: Date.now() - 20000,
      },
      {
        id: "tab-3",
        windowId: "win-main-1",
        title: "WebKit Standards Testbench & WebGL Lab",
        url: "https://html5test.webkit.macweb.os",
        favicon: "🧪",
        loadingState: "finished",
        progress: 100,
        isMuted: false,
        isPinned: true,
        isPrivate: false,
        groupId: "group-research",
        historyStack: ["https://html5test.webkit.macweb.os"],
        historyIndex: 0,
        zoomLevel: 100,
        createdAt: Date.now() - 30000,
        lastActiveAt: Date.now() - 10000,
        isPlayingAudio: true,
      },
    ];
  });

  const [closedTabsStack, setClosedTabsStack] = useState<BrowserTab[]>([]);
  const [tabGroups, setTabGroups] = useState<TabGroup[]>(() => loadFromStorage("macweb_tab_groups", INITIAL_TAB_GROUPS));
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => loadFromStorage("macweb_bookmarks", INITIAL_BOOKMARKS));
  const [bookmarkFolders, setBookmarkFolders] = useState<BookmarkFolder[]>(() => loadFromStorage("macweb_folders", INITIAL_FOLDERS));
  const [history, setHistory] = useState<HistoryItem[]>(() => loadFromStorage("macweb_history", INITIAL_HISTORY));
  const [readingList, setReadingList] = useState<ReadingListItem[]>(() => loadFromStorage("macweb_reading_list", INITIAL_READING_LIST));
  const [downloads, setDownloads] = useState<DownloadItem[]>(() => loadFromStorage("macweb_downloads", INITIAL_DOWNLOADS));
  const [sitePermissions, setSitePermissions] = useState<Record<string, SitePermission>>(() => loadFromStorage("macweb_permissions", INITIAL_SITE_PERMISSIONS));
  const [extensions, setExtensions] = useState<WebExtension[]>(() => loadFromStorage("macweb_extensions", INITIAL_EXTENSIONS));
  const [settings, setSettings] = useState<BrowserSettings>(() => loadFromStorage("macweb_settings", DEFAULT_SETTINGS));

  // Modals & Drawers
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [sidebarTab, setSidebarTab] = useState<"groups" | "bookmarks" | "history" | "reading" | "downloads" | "extensions" | "permissions">("bookmarks");
  const [isAIDrawerOpen, setIsAIDrawerOpen] = useState(false);
  const [isWebInspectorOpen, setIsWebInspectorOpen] = useState(false);
  const [inspectorActiveTab, setInspectorActiveTab] = useState<"elements" | "console" | "network" | "performance" | "storage">("elements");
  const [isPrivacyDashboardOpen, setIsPrivacyDashboardOpen] = useState(false);
  const [isCertificateModalOpen, setIsCertificateModalOpen] = useState(false);
  const [isDownloadsPopoverOpen, setIsDownloadsPopoverOpen] = useState(false);
  const [isExtensionsPopoverOpen, setIsExtensionsPopoverOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsActiveTab, setSettingsActiveTab] = useState("general");
  const [isTabOverviewOpen, setIsTabOverviewOpen] = useState(false);
  const [isNativeCodeModalOpen, setIsNativeCodeModalOpen] = useState(false);
  const [isFindBarOpen, setIsFindBarOpen] = useState(false);
  const [findQuery, setFindQuery] = useState("");
  const [blockedTrackersCount, setBlockedTrackersCount] = useState(48);

  const [readerConfig, setReaderConfig] = useState<ReaderConfig>({
    fontSize: 18,
    fontFamily: "serif",
    columnWidth: "standard",
    lineHeight: "relaxed",
    theme: "light",
  });

  // Developer Diagnostics State
  const [consoleLogs, setConsoleLogs] = useState<ConsoleLog[]>(() => [
    { id: "log-1", level: "info", message: "[WebKit2::ProcessLauncher] WebContent process (PID 48212) initialized in sandboxed state.", source: "WebKitCore", timestamp: 1718000000000, count: 1 },
    { id: "log-2", level: "log", message: "[MACWEB.OS] Window session restored with 3 active tabs. Metal hardware acceleration active.", source: "MacWebEngine", timestamp: 1718000010000, count: 1 },
    { id: "log-3", level: "log", message: "[ContentBlocker] 14 telemetry scripts blocked on apple.com according to declarative rules.", source: "ContentRuleListStore", timestamp: 1718000025000, count: 1 },
    { id: "log-4", level: "debug", message: "[AudioContext] Active audio node outputting to CoreAudio output device (Built-in Speakers).", source: "WebAudio", timestamp: 1718000040000, count: 1 },
  ]);

  const [networkRequests, setNetworkRequests] = useState<NetworkRequest[]>(() => [
    {
      id: "net-1",
      url: "https://apple.com/main.css",
      method: "GET" as const,
      status: 200,
      statusText: "OK",
      type: "stylesheet" as const,
      size: 48120,
      time: 28,
      startTime: 1718000000000,
      headers: { Accept: "text/css" } as Record<string, string>,
      responseHeaders: { "Content-Type": "text/css", "Cache-Control": "max-age=31536000" } as Record<string, string>,
    },
    {
      id: "net-2",
      url: "https://apple.com/sequoia-hero.webp",
      method: "GET" as const,
      status: 200,
      statusText: "OK",
      type: "image" as const,
      size: 142000,
      time: 64,
      startTime: 1718000001000,
      headers: { Accept: "image/webp" } as Record<string, string>,
      responseHeaders: { "Content-Type": "image/webp" } as Record<string, string>,
    },
    {
      id: "net-3",
      url: "https://apple.com/api/telemetry",
      method: "POST" as const,
      status: 403,
      statusText: "Blocked by WebKit ContentBlocker",
      type: "xhr" as const,
      size: 0,
      time: 2,
      startTime: 1718000002000,
      headers: {} as Record<string, string>,
      responseHeaders: {} as Record<string, string>,
    },
    {
      id: "net-4",
      url: "https://apple.com/app.js",
      method: "GET" as const,
      status: 200,
      statusText: "OK",
      type: "script" as const,
      size: 92400,
      time: 42,
      startTime: 1718000003000,
      headers: {} as Record<string, string>,
      responseHeaders: {} as Record<string, string>,
    },
  ]);

  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetrics>({
    fps: 60,
    memoryMB: 48.2,
    cpuPercent: 3.8,
    domNodes: 642,
    loadTimeMs: 142,
    dnsTimeMs: 12,
    ttfbMs: 34,
    domContentLoadedMs: 88,
    webContentProcessState: "Active",
  });

  // Sync to localStorage
  useEffect(() => { saveToStorage("macweb_bookmarks", bookmarks); }, [bookmarks]);
  useEffect(() => { saveToStorage("macweb_folders", bookmarkFolders); }, [bookmarkFolders]);
  useEffect(() => { saveToStorage("macweb_history", history); }, [history]);
  useEffect(() => { saveToStorage("macweb_reading_list", readingList); }, [readingList]);
  useEffect(() => { saveToStorage("macweb_downloads", downloads); }, [downloads]);
  useEffect(() => { saveToStorage("macweb_tab_groups", tabGroups); }, [tabGroups]);
  useEffect(() => { saveToStorage("macweb_permissions", sitePermissions); }, [sitePermissions]);
  useEffect(() => { saveToStorage("macweb_extensions", extensions); }, [extensions]);
  useEffect(() => { saveToStorage("macweb_settings", settings); }, [settings]);

  // Performance simulation loop
  useEffect(() => {
    const interval = setInterval(() => {
      setPerformanceMetrics((prev) => ({
        ...prev,
        fps: Math.floor(59 + Math.random() * 2),
        cpuPercent: parseFloat((2.5 + Math.random() * 2.8).toFixed(1)),
        memoryMB: parseFloat((45 + tabs.length * 12.4 + (Math.random() * 2 - 1)).toFixed(1)),
      }));
    }, 2500);
    return () => clearInterval(interval);
  }, [tabs.length]);

  // Active window & Active Tab
  const activeWindow = useMemo(() => {
    return windows.find((w) => w.id === activeWindowId) || windows[0];
  }, [windows, activeWindowId]);

  const activeTabId = activeWindow?.activeTabId || tabs[0]?.id;

  const activeTab = useMemo(() => {
    return tabs.find((t) => t.id === activeTabId) || tabs[0];
  }, [tabs, activeTabId]);

  const canGoBack = activeTab ? activeTab.historyIndex > 0 : false;
  const canGoForward = activeTab ? activeTab.historyIndex < activeTab.historyStack.length - 1 : false;

  const addConsoleLog = useCallback((level: ConsoleLog["level"], message: string, source: string = "Page") => {
    setConsoleLogs((prev) => [
      ...prev,
      {
        id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        level,
        message,
        source,
        timestamp: Date.now(),
        count: 1,
      },
    ]);
  }, []);

  const clearConsoleLogs = useCallback(() => {
    setConsoleLogs([]);
  }, []);

  const clearNetworkRequests = useCallback(() => {
    setNetworkRequests([]);
  }, []);

  // Window Management
  const createNewWindow = useCallback((type: WindowType = "normal") => {
    const newWinId = `win-${Date.now()}`;
    const newTabId = `tab-${Date.now()}`;
    const isPrivate = type === "private";

    const newTab: BrowserTab = {
      id: newTabId,
      windowId: newWinId,
      title: isPrivate ? "Private Browsing" : "Start Page",
      url: "macweb://newtab",
      favicon: isPrivate ? "🕵️" : "🧭",
      loadingState: "finished",
      progress: 100,
      isMuted: false,
      isPinned: false,
      isPrivate,
      historyStack: ["macweb://newtab"],
      historyIndex: 0,
      zoomLevel: 100,
      createdAt: Date.now(),
      lastActiveAt: Date.now(),
    };

    const newWindow: BrowserWindow = {
      id: newWinId,
      title: isPrivate ? "MACWEB.OS (Private Window)" : "MACWEB.OS",
      type,
      tabIds: [newTabId],
      activeTabId: newTabId,
      isMinimized: false,
      isMaximized: false,
      bounds: {
        x: 40 + (windows.length % 5) * 30,
        y: 40 + (windows.length % 5) * 30,
        width: 1150,
        height: 750,
      },
      zIndex: windows.length + 10,
    };

    setTabs((prev) => [...prev, newTab]);
    setWindows((prev) => [...prev, newWindow]);
    setActiveWindowId(newWinId);
  }, [windows.length]);

  const closeWindow = useCallback((winId: string) => {
    setWindows((prev) => {
      if (prev.length <= 1) {
        // If closing the last window, create a clean default one
        const freshTabId = `tab-${Date.now()}`;
        const freshWinId = `win-${Date.now()}`;
        const freshTab: BrowserTab = {
          id: freshTabId,
          windowId: freshWinId,
          title: "Start Page",
          url: "macweb://newtab",
          favicon: "🧭",
          loadingState: "finished",
          progress: 100,
          isMuted: false,
          isPinned: false,
          isPrivate: false,
          historyStack: ["macweb://newtab"],
          historyIndex: 0,
          zoomLevel: 100,
          createdAt: Date.now(),
          lastActiveAt: Date.now(),
        };
        setTabs([freshTab]);
        setActiveWindowId(freshWinId);
        return [
          {
            id: freshWinId,
            title: "MACWEB.OS",
            type: "normal",
            tabIds: [freshTabId],
            activeTabId: freshTabId,
            isMinimized: false,
            isMaximized: false,
            bounds: { x: 0, y: 0, width: 1200, height: 800 },
            zIndex: 10,
          },
        ];
      }
      const remaining = prev.filter((w) => w.id !== winId);
      // Clean up tabs belonging to this window
      setTabs((tabList) => tabList.filter((t) => t.windowId !== winId));
      if (activeWindowId === winId) {
        setActiveWindowId(remaining[remaining.length - 1].id);
      }
      return remaining;
    });
  }, [activeWindowId]);

  const activateWindow = useCallback((winId: string) => {
    setActiveWindowId(winId);
    setWindows((prev) =>
      prev.map((w) => ({
        ...w,
        zIndex: w.id === winId ? Math.max(...prev.map((p) => p.zIndex)) + 1 : w.zIndex,
      }))
    );
  }, []);

  const toggleMinimizeWindow = useCallback((winId: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === winId ? { ...w, isMinimized: !w.isMinimized } : w))
    );
  }, []);

  const toggleMaximizeWindow = useCallback((winId: string) => {
    setWindows((prev) =>
      prev.map((w) => (w.id === winId ? { ...w, isMaximized: !w.isMaximized } : w))
    );
  }, []);

  // Tab Operations
  const setActiveTabId = useCallback((tabId: string) => {
    if (!activeWindow) return;
    setWindows((prev) =>
      prev.map((w) => (w.id === activeWindow.id ? { ...w, activeTabId: tabId } : w))
    );
    setTabs((prev) =>
      prev.map((t) => (t.id === tabId ? { ...t, lastActiveAt: Date.now() } : t))
    );
  }, [activeWindow]);

  const createNewTab = useCallback((url: string = "macweb://newtab", groupId?: string, targetWindowId?: string): string => {
    const winId = targetWindowId || activeWindow?.id || windows[0]?.id;
    const targetWin = windows.find((w) => w.id === winId);
    const isPrivate = targetWin?.type === "private";
    const newTabId = `tab-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`;

    const pageInfo = CURATED_PAGES[url];
    const initialTitle = pageInfo ? pageInfo.title : url === "macweb://newtab" ? "Start Page" : getDomainFromUrl(url);
    const favicon = pageInfo ? pageInfo.favicon : getFaviconForUrl(url);

    const newTab: BrowserTab = {
      id: newTabId,
      windowId: winId,
      title: initialTitle,
      url,
      favicon,
      loadingState: "finished",
      progress: 100,
      isMuted: false,
      isPinned: false,
      isPrivate: isPrivate || false,
      groupId,
      historyStack: [url],
      historyIndex: 0,
      zoomLevel: 100,
      createdAt: Date.now(),
      lastActiveAt: Date.now(),
    };

    setTabs((prev) => [...prev, newTab]);
    setWindows((prev) =>
      prev.map((w) => (w.id === winId ? { ...w, tabIds: [...w.tabIds, newTabId], activeTabId: newTabId } : w))
    );

    return newTabId;
  }, [activeWindow, windows]);

  const closeTab = useCallback((tabId: string) => {
    const tabToClose = tabs.find((t) => t.id === tabId);
    if (!tabToClose) return;

    // Save for Reopen Tab
    setClosedTabsStack((prev) => [tabToClose, ...prev.slice(0, 19)]);

    const winId = tabToClose.windowId;
    const remainingTabsInWin = tabs.filter((t) => t.windowId === winId && t.id !== tabId);

    if (remainingTabsInWin.length === 0) {
      // If closing the last tab in the window, either create a new tab or close window
      if (windows.length > 1) {
        closeWindow(winId);
        return;
      } else {
        const freshTabId = createNewTab("macweb://newtab", undefined, winId);
        setTabs((prev) => prev.filter((t) => t.id !== tabId));
        return;
      }
    }

    setTabs((prev) => prev.filter((t) => t.id !== tabId));
    setWindows((prev) =>
      prev.map((w) => {
        if (w.id === winId) {
          const nextTabIds = w.tabIds.filter((id) => id !== tabId);
          const nextActiveId = w.activeTabId === tabId ? nextTabIds[nextTabIds.length - 1] : w.activeTabId;
          return { ...w, tabIds: nextTabIds, activeTabId: nextActiveId };
        }
        return w;
      })
    );
  }, [tabs, windows, closeWindow, createNewTab]);

  const duplicateTab = useCallback((tabId: string) => {
    const tab = tabs.find((t) => t.id === tabId);
    if (!tab) return;
    createNewTab(tab.url, tab.groupId, tab.windowId);
  }, [tabs, createNewTab]);

  const reopenClosedTab = useCallback(() => {
    if (closedTabsStack.length === 0) return;
    const [tabToRestore, ...rest] = closedTabsStack;
    setClosedTabsStack(rest);

    const winId = activeWindow?.id || windows[0]?.id;
    const restoredTab: BrowserTab = {
      ...tabToRestore,
      id: `tab-${Date.now()}`,
      windowId: winId,
      lastActiveAt: Date.now(),
    };

    setTabs((prev) => [...prev, restoredTab]);
    setWindows((prev) =>
      prev.map((w) => (w.id === winId ? { ...w, tabIds: [...w.tabIds, restoredTab.id], activeTabId: restoredTab.id } : w))
    );
  }, [closedTabsStack, activeWindow, windows]);

  const togglePinTab = useCallback((tabId: string) => {
    setTabs((prev) =>
      prev.map((t) => (t.id === tabId ? { ...t, isPinned: !t.isPinned } : t))
    );
  }, []);

  const toggleMuteTab = useCallback((tabId: string) => {
    setTabs((prev) =>
      prev.map((t) => (t.id === tabId ? { ...t, isMuted: !t.isMuted } : t))
    );
  }, []);

  const reorderTabs = useCallback((sourceIndex: number, destinationIndex: number) => {
    if (!activeWindow) return;
    const currentTabIds = [...activeWindow.tabIds];
    const [removed] = currentTabIds.splice(sourceIndex, 1);
    currentTabIds.splice(destinationIndex, 0, removed);

    setWindows((prev) =>
      prev.map((w) => (w.id === activeWindow.id ? { ...w, tabIds: currentTabIds } : w))
    );
  }, [activeWindow]);

  const setTabGroup = useCallback((tabId: string, groupId?: string) => {
    setTabs((prev) =>
      prev.map((t) => (t.id === tabId ? { ...t, groupId } : t))
    );
  }, []);

  // Tab Groups
  const createTabGroup = useCallback((name: string, color: string): string => {
    const newGroup: TabGroup = {
      id: `group-${Date.now()}`,
      name,
      color,
      collapsed: false,
      createdAt: Date.now(),
    };
    setTabGroups((prev) => [...prev, newGroup]);
    return newGroup.id;
  }, []);

  const deleteTabGroup = useCallback((groupId: string) => {
    setTabGroups((prev) => prev.filter((g) => g.id !== groupId));
    setTabs((prev) =>
      prev.map((t) => (t.groupId === groupId ? { ...t, groupId: undefined } : t))
    );
  }, []);

  const updateTabGroup = useCallback((groupId: string, name: string, color: string) => {
    setTabGroups((prev) =>
      prev.map((g) => (g.id === groupId ? { ...g, name, color } : g))
    );
  }, []);

  // Navigation Logic
  const navigate = useCallback((inputUrlOrQuery: string) => {
    if (!activeTab) return;

    const defaultEngine = SEARCH_PROVIDERS.find((p) => p.id === settings.defaultSearchEngineId) || SEARCH_PROVIDERS[0];
    const resolved = resolveUrl(inputUrlOrQuery, defaultEngine.searchUrlTemplate);
    const targetUrl = resolved.url;

    // Simulate WebKit loading progress
    setTabs((prev) =>
      prev.map((t) => {
        if (t.id === activeTab.id) {
          const nextStack = t.historyStack.slice(0, t.historyIndex + 1);
          nextStack.push(targetUrl);
          const pageInfo = CURATED_PAGES[targetUrl];
          const newTitle = pageInfo ? pageInfo.title : resolved.isSearch ? `Search: ${inputUrlOrQuery}` : resolved.domain;
          const newFavicon = pageInfo ? pageInfo.favicon : getFaviconForUrl(targetUrl);

          return {
            ...t,
            url: targetUrl,
            title: newTitle,
            favicon: newFavicon,
            loadingState: "loading",
            progress: 15,
            historyStack: nextStack,
            historyIndex: nextStack.length - 1,
            readerModeActive: false,
            isPlayingAudio: targetUrl.includes("html5test") || targetUrl.includes("bbc"),
          };
        }
        return t;
      })
    );

    // Record History (unless private window)
    if (!activeTab.isPrivate && !targetUrl.startsWith("macweb://")) {
      const domain = getDomainFromUrl(targetUrl);
      const pageInfo = CURATED_PAGES[targetUrl];
      const title = pageInfo ? pageInfo.title : targetUrl;
      const favicon = pageInfo ? pageInfo.favicon : getFaviconForUrl(targetUrl);

      setHistory((prev) => {
        const existing = prev.find((h) => h.url === targetUrl);
        if (existing) {
          return [
            { ...existing, timestamp: Date.now(), visitCount: existing.visitCount + 1 },
            ...prev.filter((h) => h.url !== targetUrl),
          ];
        }
        return [
          {
            id: `hist-${Date.now()}`,
            url: targetUrl,
            title,
            favicon,
            timestamp: Date.now(),
            visitCount: 1,
            isPrivate: false,
            domain,
          },
          ...prev,
        ];
      });
    }

    // Add Network request simulation
    setNetworkRequests((prev) => [
      {
        id: `net-${Date.now()}`,
        url: targetUrl,
        method: "GET",
        status: 200,
        statusText: "OK",
        type: "document",
        size: Math.floor(18000 + Math.random() * 45000),
        time: Math.floor(65 + Math.random() * 120),
        startTime: Date.now(),
        headers: { "Accept": "text/html,application/xhtml+xml" },
        responseHeaders: { "Content-Type": "text/html; charset=UTF-8", "Server": "WebKit-Engine" },
      },
      ...prev.slice(0, 49),
    ]);

    // Animate progress to finished
    setTimeout(() => {
      setTabs((prev) =>
        prev.map((t) => (t.id === activeTab.id ? { ...t, progress: 65 } : t))
      );
    }, 150);

    setTimeout(() => {
      setTabs((prev) =>
        prev.map((t) => (t.id === activeTab.id ? { ...t, progress: 100, loadingState: "finished" } : t))
      );
    }, 400);
  }, [activeTab, settings.defaultSearchEngineId]);

  const goBack = useCallback(() => {
    if (!activeTab || activeTab.historyIndex <= 0) return;
    const nextIndex = activeTab.historyIndex - 1;
    const prevUrl = activeTab.historyStack[nextIndex];
    const pageInfo = CURATED_PAGES[prevUrl];

    setTabs((prev) =>
      prev.map((t) => {
        if (t.id === activeTab.id) {
          return {
            ...t,
            url: prevUrl,
            title: pageInfo ? pageInfo.title : getDomainFromUrl(prevUrl),
            favicon: pageInfo ? pageInfo.favicon : getFaviconForUrl(prevUrl),
            historyIndex: nextIndex,
            loadingState: "finished",
            progress: 100,
          };
        }
        return t;
      })
    );
  }, [activeTab]);

  const goForward = useCallback(() => {
    if (!activeTab || activeTab.historyIndex >= activeTab.historyStack.length - 1) return;
    const nextIndex = activeTab.historyIndex + 1;
    const nextUrl = activeTab.historyStack[nextIndex];
    const pageInfo = CURATED_PAGES[nextUrl];

    setTabs((prev) =>
      prev.map((t) => {
        if (t.id === activeTab.id) {
          return {
            ...t,
            url: nextUrl,
            title: pageInfo ? pageInfo.title : getDomainFromUrl(nextUrl),
            favicon: pageInfo ? pageInfo.favicon : getFaviconForUrl(nextUrl),
            historyIndex: nextIndex,
            loadingState: "finished",
            progress: 100,
          };
        }
        return t;
      })
    );
  }, [activeTab]);

  const reload = useCallback(() => {
    if (!activeTab) return;
    setTabs((prev) =>
      prev.map((t) => (t.id === activeTab.id ? { ...t, loadingState: "loading", progress: 20 } : t))
    );
    setTimeout(() => {
      setTabs((prev) =>
        prev.map((t) => (t.id === activeTab.id ? { ...t, progress: 100, loadingState: "finished" } : t))
      );
    }, 300);
  }, [activeTab]);

  const stop = useCallback(() => {
    if (!activeTab) return;
    setTabs((prev) =>
      prev.map((t) => (t.id === activeTab.id ? { ...t, loadingState: "finished", progress: 100 } : t))
    );
  }, [activeTab]);

  const toggleReaderMode = useCallback(() => {
    if (!activeTab) return;
    setTabs((prev) =>
      prev.map((t) => (t.id === activeTab.id ? { ...t, readerModeActive: !t.readerModeActive } : t))
    );
  }, [activeTab]);

  const setZoomLevel = useCallback((zoom: number) => {
    if (!activeTab) return;
    setTabs((prev) =>
      prev.map((t) => (t.id === activeTab.id ? { ...t, zoomLevel: Math.max(50, Math.min(300, zoom)) } : t))
    );
  }, [activeTab]);

  // Bookmarks
  const addBookmark = useCallback((title: string, url: string, folderId: string | null = "folder-favorites") => {
    const newBm: Bookmark = {
      id: `bm-${Date.now()}`,
      folderId,
      title,
      url,
      favicon: getFaviconForUrl(url),
      createdAt: Date.now(),
      order: bookmarks.length,
    };
    setBookmarks((prev) => [...prev, newBm]);
  }, [bookmarks.length]);

  const removeBookmark = useCallback((id: string) => {
    setBookmarks((prev) => prev.filter((b) => b.id !== id));
  }, []);

  const editBookmark = useCallback((id: string, title: string, url: string, folderId: string | null = null) => {
    setBookmarks((prev) =>
      prev.map((b) => (b.id === id ? { ...b, title, url, folderId, favicon: getFaviconForUrl(url) } : b))
    );
  }, []);

  const createBookmarkFolder = useCallback((name: string, parentId: string | null = null) => {
    const newFolder: BookmarkFolder = {
      id: `folder-${Date.now()}`,
      parentId,
      name,
      createdAt: Date.now(),
      order: bookmarkFolders.length,
    };
    setBookmarkFolders((prev) => [...prev, newFolder]);
  }, [bookmarkFolders.length]);

  // History Clear
  const clearHistory = useCallback((period: "hour" | "today" | "all") => {
    const now = Date.now();
    if (period === "all") {
      setHistory([]);
    } else if (period === "today") {
      const startOfDay = new Date().setHours(0, 0, 0, 0);
      setHistory((prev) => prev.filter((h) => h.timestamp < startOfDay));
    } else if (period === "hour") {
      const oneHourAgo = now - 1000 * 60 * 60;
      setHistory((prev) => prev.filter((h) => h.timestamp < oneHourAgo));
    }
  }, []);

  // Reading List
  const addToReadingList = useCallback((url: string, title: string, previewText?: string) => {
    const existing = readingList.find((r) => r.url === url);
    if (existing) return;

    const newItem: ReadingListItem = {
      id: `read-${Date.now()}`,
      url,
      title,
      favicon: getFaviconForUrl(url),
      savedTimestamp: Date.now(),
      isRead: false,
      previewText: previewText || "Saved WebKit Article",
      readingTimeMinutes: 4,
    };
    setReadingList((prev) => [newItem, ...prev]);
  }, [readingList]);

  const removeFromReadingList = useCallback((id: string) => {
    setReadingList((prev) => prev.filter((r) => r.id !== id));
  }, []);

  const toggleReadingListRead = useCallback((id: string) => {
    setReadingList((prev) =>
      prev.map((r) => (r.id === id ? { ...r, isRead: !r.isRead } : r))
    );
  }, []);

  // Downloads
  const startDownload = useCallback((filename: string, sourceUrl: string, totalBytes: number = 84000000) => {
    const newDl: DownloadItem = {
      id: `dl-${Date.now()}`,
      filename,
      sourceUrl,
      totalBytes,
      receivedBytes: 0,
      speedBytesPerSec: 12500000,
      status: "downloading",
      destinationPath: `~/Downloads/${filename}`,
      startedAt: Date.now(),
      mimeType: filename.endsWith(".dmg") ? "application/x-apple-diskimage" : filename.endsWith(".zip") ? "application/zip" : "application/pdf",
    };

    setDownloads((prev) => [newDl, ...prev]);
    setIsDownloadsPopoverOpen(true);

    // Simulate download progress
    let received = 0;
    const interval = setInterval(() => {
      received += totalBytes / 10;
      if (received >= totalBytes) {
        clearInterval(interval);
        setDownloads((prev) =>
          prev.map((d) => (d.id === newDl.id ? { ...d, receivedBytes: totalBytes, status: "completed", completedAt: Date.now(), speedBytesPerSec: 0 } : d))
        );
      } else {
        setDownloads((prev) =>
          prev.map((d) => (d.id === newDl.id ? { ...d, receivedBytes: Math.min(totalBytes, received) } : d))
        );
      }
    }, 400);
  }, []);

  const cancelDownload = useCallback((id: string) => {
    setDownloads((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: "cancelled", speedBytesPerSec: 0 } : d))
    );
  }, []);

  const pauseDownload = useCallback((id: string) => {
    setDownloads((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: "paused", speedBytesPerSec: 0 } : d))
    );
  }, []);

  const resumeDownload = useCallback((id: string) => {
    setDownloads((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: "downloading", speedBytesPerSec: 11200000 } : d))
    );
  }, []);

  // Permissions
  const updateSitePermission = useCallback((domain: string, patch: Partial<SitePermission>) => {
    setSitePermissions((prev) => {
      const current = prev[domain] || {
        domain,
        camera: "ask",
        microphone: "ask",
        location: "ask",
        notifications: "ask",
        mediaAutoplay: "allow",
        popups: "block",
        contentBlocking: true,
        zoomLevel: 100,
      };
      return {
        ...prev,
        [domain]: { ...current, ...patch },
      };
    });
  }, []);

  // Extensions
  const toggleExtension = useCallback((id: string) => {
    setExtensions((prev) =>
      prev.map((e) => (e.id === id ? { ...e, enabled: !e.enabled } : e))
    );
  }, []);

  // Settings
  const updateSettings = useCallback((patch: Partial<BrowserSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  // Security certificate information for active tab
  const certificateInfo: SecurityCertificateInfo = useMemo(() => {
    const domain = activeTab ? getDomainFromUrl(activeTab.url) : "apple.com";
    return {
      domain,
      subject: `CN=${domain}, O=${domain.toUpperCase()} Inc, C=US`,
      issuer: "DigiCert Global Root G2 (Apple WebKit Verified)",
      validFrom: "2025-01-01 00:00:00 UTC",
      validTo: "2027-01-01 23:59:59 UTC",
      protocol: "TLS 1.3 (Authenticated)",
      cipher: "TLS_AES_256_GCM_SHA384 (256-bit AES)",
      keyExchange: "ECDHE_RSA with X25519 (253 bits)",
      isSecure: !activeTab?.url.startsWith("http://"),
      hstsEnabled: true,
    };
  }, [activeTab]);

  return (
    <BrowserContext.Provider
      value={{
        windows,
        activeWindowId,
        activeWindow,
        createNewWindow,
        closeWindow,
        activateWindow,
        toggleMinimizeWindow,
        toggleMaximizeWindow,

        tabs: tabs.filter((t) => t.windowId === activeWindow?.id),
        activeTab,
        activeTabId,
        setActiveTabId,
        createNewTab,
        closeTab,
        duplicateTab,
        reopenClosedTab,
        togglePinTab,
        toggleMuteTab,
        reorderTabs,
        setTabGroup,

        tabGroups,
        createTabGroup,
        deleteTabGroup,
        updateTabGroup,

        navigate,
        goBack,
        goForward,
        reload,
        stop,
        toggleReaderMode,
        setZoomLevel,
        canGoBack,
        canGoForward,

        isSidebarOpen,
        setIsSidebarOpen,
        sidebarTab,
        setSidebarTab,
        isAIDrawerOpen,
        setIsAIDrawerOpen,
        isWebInspectorOpen,
        setIsWebInspectorOpen,
        inspectorActiveTab,
        setInspectorActiveTab,
        isPrivacyDashboardOpen,
        setIsPrivacyDashboardOpen,
        isCertificateModalOpen,
        setIsCertificateModalOpen,
        isDownloadsPopoverOpen,
        setIsDownloadsPopoverOpen,
        isExtensionsPopoverOpen,
        setIsExtensionsPopoverOpen,
        isSettingsOpen,
        setIsSettingsOpen,
        settingsActiveTab,
        setSettingsActiveTab,
        isTabOverviewOpen,
        setIsTabOverviewOpen,
        isNativeCodeModalOpen,
        setIsNativeCodeModalOpen,
        isFindBarOpen,
        setIsFindBarOpen,
        findQuery,
        setFindQuery,

        bookmarks,
        bookmarkFolders,
        addBookmark,
        removeBookmark,
        editBookmark,
        createBookmarkFolder,

        history,
        clearHistory,

        readingList,
        addToReadingList,
        removeFromReadingList,
        toggleReadingListRead,

        downloads,
        startDownload,
        cancelDownload,
        pauseDownload,
        resumeDownload,

        sitePermissions,
        updateSitePermission,

        extensions,
        toggleExtension,

        settings,
        updateSettings,

        readerConfig,
        setReaderConfig,

        consoleLogs,
        addConsoleLog,
        clearConsoleLogs,
        networkRequests,
        clearNetworkRequests,
        performanceMetrics,
        certificateInfo,
        blockedTrackersCount,
      }}
    >
      {children}
    </BrowserContext.Provider>
  );
}

export function useBrowser() {
  const context = useContext(BrowserContext);
  if (!context) {
    throw new Error("useBrowser must be used within a BrowserProvider");
  }
  return context;
}
