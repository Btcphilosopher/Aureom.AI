export type WindowType = "normal" | "private";

export interface BrowserTab {
  id: string;
  windowId: string;
  title: string;
  url: string;
  favicon?: string;
  loadingState: "idle" | "loading" | "finished" | "failed";
  progress: number; // 0 to 100
  isMuted: boolean;
  isPinned: boolean;
  isPrivate: boolean;
  groupId?: string;
  historyStack: string[];
  historyIndex: number;
  zoomLevel: number; // 100 default
  createdAt: number;
  lastActiveAt: number;
  isPlayingAudio?: boolean;
  readerModeActive?: boolean;
  contentSnapshot?: string;
}

export interface TabGroup {
  id: string;
  name: string;
  color: string; // hex or tailwind name
  collapsed?: boolean;
  createdAt: number;
}

export interface BrowserWindow {
  id: string;
  title: string;
  type: WindowType;
  tabIds: string[];
  activeTabId: string;
  isMinimized: boolean;
  isMaximized: boolean;
  bounds: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  zIndex: number;
}

export interface BrowserSession {
  id: string;
  name: string;
  windows: BrowserWindow[];
  tabs: BrowserTab[];
  tabGroups: TabGroup[];
  activeWindowId: string;
  savedAt: number;
}

export interface Bookmark {
  id: string;
  folderId: string | null;
  title: string;
  url: string;
  favicon?: string;
  createdAt: number;
  order: number;
  tags?: string[];
}

export interface BookmarkFolder {
  id: string;
  parentId: string | null;
  name: string;
  createdAt: number;
  order: number;
}

export interface HistoryItem {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  timestamp: number;
  visitCount: number;
  isPrivate: boolean;
  domain: string;
}

export interface ReadingListItem {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  savedTimestamp: number;
  isRead: boolean;
  previewText?: string;
  readingTimeMinutes?: number;
}

export interface DownloadItem {
  id: string;
  filename: string;
  sourceUrl: string;
  totalBytes: number;
  receivedBytes: number;
  speedBytesPerSec: number;
  status: "downloading" | "paused" | "completed" | "cancelled" | "failed";
  destinationPath: string;
  startedAt: number;
  completedAt?: number;
  mimeType: string;
}

export interface SitePermission {
  domain: string;
  camera: "allow" | "deny" | "ask";
  microphone: "allow" | "deny" | "ask";
  location: "allow" | "deny" | "ask";
  notifications: "allow" | "deny" | "ask";
  mediaAutoplay: "allow" | "deny" | "ask";
  popups: "allow" | "block";
  contentBlocking: boolean;
  zoomLevel: number;
}

export interface WebExtension {
  id: string;
  name: string;
  version: string;
  description: string;
  icon: string;
  author: string;
  enabled: boolean;
  permissions: string[];
  hasPopup: boolean;
  popupTitle?: string;
}

export interface SearchProvider {
  id: string;
  name: string;
  icon: string;
  searchUrlTemplate: string; // e.g., "https://www.google.com/search?q={query}"
  suggestUrlTemplate?: string;
  isDefault: boolean;
}

export interface SecurityCertificateInfo {
  domain: string;
  subject: string;
  issuer: string;
  validFrom: string;
  validTo: string;
  protocol: string; // "TLS 1.3"
  cipher: string; // "TLS_AES_256_GCM_SHA384"
  keyExchange: string; // "ECDHE_RSA with X25519"
  isSecure: boolean;
  hstsEnabled: boolean;
}

export interface ConsoleLog {
  id: string;
  level: "log" | "info" | "warn" | "error" | "debug";
  message: string;
  source: string;
  timestamp: number;
  count: number;
}

export interface NetworkRequest {
  id: string;
  url: string;
  method: "GET" | "POST" | "PUT" | "DELETE" | "OPTIONS";
  status: number;
  statusText: string;
  type: "document" | "stylesheet" | "script" | "image" | "font" | "xhr" | "fetch" | "other";
  size: number; // in bytes
  time: number; // in ms
  startTime: number;
  headers: Record<string, string>;
  responseHeaders: Record<string, string>;
}

export interface PerformanceMetrics {
  fps: number;
  memoryMB: number;
  cpuPercent: number;
  domNodes: number;
  loadTimeMs: number;
  dnsTimeMs: number;
  ttfbMs: number;
  domContentLoadedMs: number;
  webContentProcessState: "Active" | "Suspended" | "Terminated" | "Background";
}

export interface ReaderConfig {
  fontSize: number; // 14 to 32
  fontFamily: "serif" | "sans" | "mono";
  columnWidth: "narrow" | "standard" | "wide";
  lineHeight: "tight" | "relaxed" | "loose";
  theme: "light" | "sepia" | "slate" | "dark";
}

export interface BrowserSettings {
  homepage: "newtab" | "blank" | "custom";
  customHomepageUrl: string;
  defaultSearchEngineId: string;
  defaultDownloadLocation: string;
  openTabsOnStartup: "newtab" | "restore" | "custom";
  contentBlockingEnabled: boolean;
  blockTrackers: boolean;
  blockCryptominers: boolean;
  blockSocialWidgets: boolean;
  doNotTrack: boolean;
  httpsOnlyMode: boolean;
  developerModeEnabled: boolean;
  soundEffectsEnabled: boolean;
  reduceMotion: boolean;
  theme: "system" | "light" | "dark";
  newTabWallpaper: string;
}

export interface BrowserCommand {
  id: string;
  type: "OpenURL" | "CloseTab" | "Reload" | "Bookmark" | "CreateTabGroup" | "SearchPage" | "ToggleReader" | "ClearHistory";
  params: Record<string, any>;
  description: string;
}
