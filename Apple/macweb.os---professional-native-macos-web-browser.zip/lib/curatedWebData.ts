export interface WebPageData {
  url: string;
  domain: string;
  title: string;
  favicon: string;
  description: string;
  author?: string;
  publishedDate?: string;
  category?: string;
  hasAudio?: boolean;
  hasVideo?: boolean;
  contentHtml: string;
  readerHtml: string;
  links?: { title: string; url: string }[];
  tables?: { title: string; headers: string[]; rows: string[][] }[];
  interactiveType?: "default" | "webgl" | "forms" | "video" | "audio" | "testbench" | "devtools";
}

export const SEARCH_PROVIDERS = [
  {
    id: "google",
    name: "Google",
    icon: "🔍",
    searchUrlTemplate: "https://www.google.com/search?q={query}",
    isDefault: true,
  },
  {
    id: "duckduckgo",
    name: "DuckDuckGo",
    icon: "🦆",
    searchUrlTemplate: "https://duckduckgo.com/?q={query}",
    isDefault: false,
  },
  {
    id: "bing",
    name: "Bing",
    icon: "🅱️",
    searchUrlTemplate: "https://www.bing.com/search?q={query}",
    isDefault: false,
  },
  {
    id: "ecosia",
    name: "Ecosia",
    icon: "🌱",
    searchUrlTemplate: "https://www.ecosia.org/search?q={query}",
    isDefault: false,
  },
];

export const INITIAL_FAVORITES = [
  { id: "fav-1", title: "Apple", url: "https://apple.com", icon: "", color: "#1c1c1e" },
  { id: "fav-2", title: "GitHub", url: "https://github.com", icon: "🐙", color: "#24292e" },
  { id: "fav-3", title: "Wikipedia", url: "https://wikipedia.org", icon: "W", color: "#ffffff" },
  { id: "fav-4", title: "BBC News", url: "https://bbc.com/news", icon: "BBC", color: "#bb1919" },
  { id: "fav-5", title: "Hacker News", url: "https://news.ycombinator.com", icon: "Y", color: "#ff6600" },
  { id: "fav-6", title: "WebKit Dev", url: "https://webkit.org", icon: "🧭", color: "#007aff" },
  { id: "fav-7", title: "MDN Web Docs", url: "https://developer.mozilla.org", icon: "M", color: "#000000" },
  { id: "fav-8", title: "HTML5 Test Lab", url: "https://html5test.webkit.macweb.os", icon: "🧪", color: "#34c759" },
];

export const CURATED_PAGES: Record<string, WebPageData> = {
  "https://apple.com": {
    url: "https://apple.com",
    domain: "apple.com",
    title: "Apple - macOS Sequoia & Silicon Innovation",
    favicon: "https://apple.com/favicon.ico",
    description: "Explore the next generation of Apple Silicon, macOS Sequoia, and high-performance WebKit browser technologies.",
    author: "Apple Inc.",
    publishedDate: "September 2026",
    category: "Technology",
    hasAudio: false,
    hasVideo: true,
    contentHtml: `
      <div class="space-y-8 max-w-4xl mx-auto py-6">
        <div class="relative rounded-3xl overflow-hidden bg-gradient-to-br from-neutral-900 via-neutral-950 to-black text-white p-10 border border-neutral-800 shadow-2xl text-center">
          <span class="px-4 py-1.5 rounded-full bg-white/10 text-xs font-semibold tracking-wider uppercase backdrop-blur-md">macOS Sequoia Architecture</span>
          <h1 class="text-4xl md:text-5xl font-bold tracking-tight mt-4 bg-gradient-to-r from-white via-neutral-200 to-neutral-400 bg-clip-text text-transparent">Powering the Future of Web Browsing</h1>
          <p class="text-lg text-neutral-300 max-w-2xl mx-auto mt-4 font-normal leading-relaxed">
            Engineered with unified memory bandwidth and Metal 3 acceleration, delivering instant JavaScript execution and responsive multi-window browser workflows.
          </p>
          <div class="flex items-center justify-center gap-4 mt-8">
            <button class="px-6 py-2.5 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-medium text-sm transition-all shadow-lg shadow-blue-500/20">Explore Architecture</button>
            <button class="px-6 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-medium text-sm transition-all backdrop-blur-md">View Developer Docs</button>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div class="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm">
            <div class="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold text-lg mb-4">🚀</div>
            <h3 class="font-semibold text-lg text-neutral-900 dark:text-neutral-100">WebKit Core</h3>
            <p class="text-sm text-neutral-600 dark:text-neutral-400 mt-2 leading-relaxed">Multi-process tab isolation preventing web crashes from affecting the main macOS application thread.</p>
          </div>
          <div class="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm">
            <div class="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold text-lg mb-4">🛡️</div>
            <h3 class="font-semibold text-lg text-neutral-900 dark:text-neutral-100">Intelligent Tracking</h3>
            <p class="text-sm text-neutral-600 dark:text-neutral-400 mt-2 leading-relaxed">Built-in privacy protection blocking cross-site fingerprinting without breaking modern web apps.</p>
          </div>
          <div class="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm">
            <div class="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-lg mb-4">⚡</div>
            <h3 class="font-semibold text-lg text-neutral-900 dark:text-neutral-100">Metal Acceleration</h3>
            <p class="text-sm text-neutral-600 dark:text-neutral-400 mt-2 leading-relaxed">Hardware-accelerated compositing and CSS animations rendering at up to 120Hz ProMotion.</p>
          </div>
        </div>

        <div class="p-8 rounded-2xl bg-neutral-50 dark:bg-neutral-900/60 border border-neutral-200 dark:border-neutral-800">
          <h2 class="text-2xl font-bold text-neutral-900 dark:text-neutral-100">Specification Comparison Matrix</h2>
          <div class="overflow-x-auto mt-6">
            <table class="w-full text-left text-sm">
              <thead class="border-b border-neutral-200 dark:border-neutral-700 text-neutral-500 dark:text-neutral-400">
                <tr>
                  <th class="py-3 px-4">Metric / Feature</th>
                  <th class="py-3 px-4 font-semibold text-neutral-900 dark:text-neutral-100">MACWEB.OS (WebKit)</th>
                  <th class="py-3 px-4">Legacy Engine</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-neutral-200 dark:divide-neutral-800 text-neutral-700 dark:text-neutral-300">
                <tr>
                  <td class="py-3 px-4 font-medium">Memory per Tab</td>
                  <td class="py-3 px-4 text-emerald-600 dark:text-emerald-400 font-semibold">~32 MB (Isolated)</td>
                  <td class="py-3 px-4">~140 MB</td>
                </tr>
                <tr>
                  <td class="py-3 px-4 font-medium">CSS Grid / Flex Speed</td>
                  <td class="py-3 px-4 text-emerald-600 dark:text-emerald-400 font-semibold">Sub-millisecond</td>
                  <td class="py-3 px-4">3.4 ms</td>
                </tr>
                <tr>
                  <td class="py-3 px-4 font-medium">Native Keychain Autofill</td>
                  <td class="py-3 px-4 text-emerald-600 dark:text-emerald-400 font-semibold">Full Biometric Support</td>
                  <td class="py-3 px-4">Third-party required</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `,
    readerHtml: `
      <h1>Powering the Future of Web Browsing on macOS</h1>
      <p class="lead">macOS Sequoia introduces powerful new capabilities for native WebKit browser applications, combining memory efficiency with high-fidelity web standards execution.</p>
      <p>Modern web applications require unprecedented computational throughput. By taking advantage of unified memory architecture and hardware-level isolation, browser tabs maintain high responsiveness even when dealing with hundreds of simultaneous sessions.</p>
      <h2>Architecture and Isolation</h2>
      <p>The WKWebView process isolation architecture separates UI rendering, network caching, and script execution into isolated sandboxes. This prevents unexpected script exceptions in arbitrary third-party pages from destabilizing the browser shell.</p>
      <h2>Privacy by Design</h2>
      <p>Declarative content blockers allow rule execution entirely inside the kernel-level network filter, removing the performance penalty commonly associated with legacy extension script injectors.</p>
    `,
    tables: [
      {
        title: "Browser Performance Metrics",
        headers: ["Component", "Engine Mode", "Throughput", "Efficiency"],
        rows: [
          ["JavaScript Core", "JIT Tier 2", "1.4B ops/sec", "99.4%"],
          ["DOM Tree Parser", "Streaming Native", "180 MB/s", "98.8%"],
          ["Image Decoder", "Hardware Apple Silicon", "4K 120fps", "99.9%"],
          ["Network Layer", "NSURLSession HTTP/3", "10 Gbps peak", "100%"]
        ]
      }
    ]
  },
  "https://github.com": {
    url: "https://github.com",
    domain: "github.com",
    title: "GitHub - Build and Ship Software Together",
    favicon: "https://github.com/favicon.ico",
    description: "The world's leading developer platform for version control, collaboration, and open-source web technologies.",
    author: "GitHub, Inc.",
    publishedDate: "Today",
    category: "Developer Tools",
    hasAudio: false,
    hasVideo: false,
    contentHtml: `
      <div class="space-y-6 max-w-4xl mx-auto py-6">
        <div class="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 pb-4">
          <div class="flex items-center gap-3">
            <span class="text-2xl font-bold text-neutral-900 dark:text-neutral-100">macweb-os / macweb-browser</span>
            <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">Public</span>
          </div>
          <div class="flex items-center gap-2">
            <button class="px-3.5 py-1.5 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 text-xs font-medium hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors">⭐️ Star 14.8k</button>
            <button class="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium transition-colors">Fork 1.2k</button>
          </div>
        </div>

        <div class="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 text-blue-900 dark:text-blue-200 text-sm">
          <strong>Latest Release v3.7.0:</strong> Native WebKit multi-window engine, full SQLite Core Data storage layer, Gemini AI Assistant integration, and WebExtensions sandbox.
        </div>

        <div class="border border-neutral-200 dark:border-neutral-800 rounded-xl overflow-hidden bg-white dark:bg-neutral-900">
          <div class="bg-neutral-100 dark:bg-neutral-800/80 px-4 py-3 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between text-xs text-neutral-600 dark:text-neutral-300 font-mono">
            <span>Commit: e84c90a • Updated 2 minutes ago</span>
            <span>2,490 commits • 12 branches</span>
          </div>
          <div class="divide-y divide-neutral-100 dark:divide-neutral-800/60 font-mono text-xs">
            <div class="px-4 py-2.5 flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/40 cursor-pointer">
              <span class="text-blue-600 dark:text-blue-400 font-medium">📁 macos/App/</span>
              <span class="text-neutral-500">AppDelegate and SwiftUI WindowGroup initialization</span>
            </div>
            <div class="px-4 py-2.5 flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/40 cursor-pointer">
              <span class="text-blue-600 dark:text-blue-400 font-medium">📁 macos/Browser/</span>
              <span class="text-neutral-500">BrowserTab, BrowserWindow, and Session restoration</span>
            </div>
            <div class="px-4 py-2.5 flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/40 cursor-pointer">
              <span class="text-blue-600 dark:text-blue-400 font-medium">📁 webkit/WebView/</span>
              <span class="text-neutral-500">WKWebView subclass with WKNavigationDelegate & WKUIDelegate</span>
            </div>
            <div class="px-4 py-2.5 flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/40 cursor-pointer">
              <span class="text-blue-600 dark:text-blue-400 font-medium">📁 database/</span>
              <span class="text-neutral-500">SQLite schema for History, Bookmarks, ReadingList, Permissions</span>
            </div>
            <div class="px-4 py-2.5 flex items-center justify-between hover:bg-neutral-50 dark:hover:bg-neutral-800/40 cursor-pointer">
              <span class="text-neutral-700 dark:text-neutral-300">📄 Package.swift</span>
              <span class="text-neutral-500">Swift Package Manager dependencies and targets</span>
            </div>
          </div>
        </div>

        <div class="p-6 rounded-2xl bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 prose dark:prose-invert max-w-none text-sm">
          <h2 class="text-lg font-bold text-neutral-900 dark:text-neutral-100">README.md</h2>
          <p class="text-neutral-600 dark:text-neutral-400">
            <strong>MACWEB.OS</strong> is an independent, high-performance Safari-class native macOS web browser shell. Built exclusively around Apple's public WebKit APIs, Combine, and AppKit.
          </p>
        </div>
      </div>
    `,
    readerHtml: `
      <h1>macweb-os / macweb-browser: Technical Specification</h1>
      <p class="lead">A professional native macOS browser shell designed for high performance, modular extension support, and privacy-first local storage.</p>
      <h2>Key Architecture Points</h2>
      <ul>
        <li>SwiftUI and AppKit hybrid window controller.</li>
        <li>WKWebView multi-process isolated rendering.</li>
        <li>SQLite embedded database with WAL mode for zero-latency history indexing.</li>
        <li>Declarative Content Blocker rules compiled to native bytecodes.</li>
      </ul>
    `
  },
  "https://wikipedia.org": {
    url: "https://wikipedia.org",
    domain: "wikipedia.org",
    title: "WebKit - Wikipedia, the Free Encyclopedia",
    favicon: "https://en.wikipedia.org/favicon.ico",
    description: "WebKit is a browser engine developed primarily by Apple and used in Safari and various macOS / iOS applications.",
    author: "Wikipedia Contributors",
    publishedDate: "2026",
    category: "Reference",
    hasAudio: false,
    hasVideo: false,
    contentHtml: `
      <div class="space-y-6 max-w-3xl mx-auto py-6">
        <div class="border-b border-neutral-200 dark:border-neutral-800 pb-4">
          <h1 class="text-3xl font-serif font-bold text-neutral-900 dark:text-neutral-100">WebKit (Software Engine)</h1>
          <p class="text-xs text-neutral-500 mt-1">From Wikipedia, the free encyclopedia</p>
        </div>

        <div class="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/40 text-amber-900 dark:text-amber-200 text-sm">
          <strong>WebKit</strong> is an open-source web browser engine. WebKit powers Apple's Safari, AppKit web views, and native macOS web environments.
        </div>

        <div class="prose dark:prose-invert max-w-none text-sm space-y-4 text-neutral-700 dark:text-neutral-300 leading-relaxed font-serif">
          <p>
            The engine consists of two primary components: <strong>WebCore</strong> (responsible for HTML parsing, DOM tree creation, and layout formatting) and <strong>JavaScriptCore</strong> (an optimizing virtual machine executing ECMAScript bytecodes with just-in-time compilation).
          </p>
          <h2 class="text-xl font-bold font-sans text-neutral-900 dark:text-neutral-100 mt-6 border-b border-neutral-200 dark:border-neutral-800 pb-2">Architecture & Process Separation</h2>
          <p>
            In modern WebKit2 architectures, web content executes in a dedicated secondary helper process (<code class="bg-neutral-100 dark:bg-neutral-800 px-1 py-0.5 rounded">com.apple.WebKit.WebContent</code>). The UI process communicates with the web content process via low-latency Mach IPC messages.
          </p>
          <h2 class="text-xl font-bold font-sans text-neutral-900 dark:text-neutral-100 mt-6 border-b border-neutral-200 dark:border-neutral-800 pb-2">Standards Compliance</h2>
          <p>
            WebKit implements current W3C and WHATWG specifications, including HTML5 Custom Elements, CSS Flexbox & Grid Level 2, WebGL 2.0, Web Audio API, Service Workers, and Content Security Policy (CSP) Level 3.
          </p>
        </div>
      </div>
    `,
    readerHtml: `
      <h1>WebKit (Software Engine)</h1>
      <p class="lead">WebKit is the open-source browser engine powering Safari, AppKit WKWebView, and professional macOS web applications.</p>
      <h2>Origins and Architecture</h2>
      <p>WebKit originated as a fork of the KHTML and KJS libraries in 2001. Over the last two decades, it has evolved into a premier web rendering engine known for its energy efficiency, low memory footprint, and tight integration with macOS graphics frameworks like Core Graphics and Metal.</p>
      <h2>Security and Sandboxing</h2>
      <p>WebKit's multi-process model strictly isolates the parsing of untrusted network data from the host operating system, preventing unauthorized disk access and privilege escalation.</p>
    `
  },
  "https://bbc.com/news": {
    url: "https://bbc.com/news",
    domain: "bbc.com",
    title: "BBC News - Global Technology & Web Frontiers",
    favicon: "https://bbc.com/favicon.ico",
    description: "Breaking tech news: How new browser engine developments are reshaping internet privacy and speed standards worldwide.",
    author: "BBC Technology Desk",
    publishedDate: "September 8, 2026",
    category: "News",
    hasAudio: true,
    hasVideo: true,
    contentHtml: `
      <div class="space-y-6 max-w-3xl mx-auto py-6">
        <div class="space-y-2">
          <span class="px-2.5 py-1 bg-red-600 text-white text-xs font-bold uppercase rounded">Tech & Society</span>
          <h1 class="text-3xl md:text-4xl font-serif font-bold text-neutral-900 dark:text-neutral-100">Next-Generation Native Web Browsers Challenge Cloud Giants</h1>
          <p class="text-xs text-neutral-500">By Sarah Jenkins • 4 mins read • Updated 18 minutes ago</p>
        </div>

        <div class="rounded-2xl overflow-hidden border border-neutral-200 dark:border-neutral-800 bg-neutral-100 dark:bg-neutral-800 p-4">
          <div class="h-48 rounded-xl bg-gradient-to-r from-neutral-800 to-neutral-950 flex flex-col items-center justify-center text-white text-center p-6">
            <span class="text-3xl mb-2">📡</span>
            <h3 class="font-bold text-lg">Special Report: The Privacy Browser Renaissance</h3>
            <p class="text-xs text-neutral-300 mt-1">Independent benchmarking reveals 4x battery improvements on native macOS WebKit engines.</p>
          </div>
        </div>

        <div class="space-y-4 text-sm text-neutral-700 dark:text-neutral-300 leading-relaxed font-serif">
          <p>
            <strong>LONDON</strong> — As users demand greater control over personal telemetry and tracking cookies, software engineers are returning to native operating system APIs to build leaner, faster browser clients.
          </p>
          <p>
            Unlike cross-platform monolithic browsers that consume gigabytes of system memory, native macOS architectures built directly on top of Apple's WebKit framework utilize hardware-accelerated video decoding and zero-copy memory buffers.
          </p>
          <blockquote class="border-l-4 border-red-600 pl-4 py-1 italic text-neutral-900 dark:text-neutral-100 font-sans my-4">
            "We are seeing a profound shift towards local-first data persistence where history, bookmarks, and sessions remain strictly on the user's SSD without forced cloud synchronization."
          </blockquote>
          <p>
            With modern declarative content blocking systems and AI-powered page summarization running locally or securely through validated server channels, the browser is transforming into an intelligent research workstation.
          </p>
        </div>
      </div>
    `,
    readerHtml: `
      <h1>Next-Generation Native Web Browsers Challenge Cloud Giants</h1>
      <p class="lead">By Sarah Jenkins • BBC Technology Desk</p>
      <p>As internet users demand greater control over personal data and tracking cookies, software developers are turning to native operating system APIs to create leaner, faster browsing environments.</p>
      <p>Native macOS applications built on WebKit take full advantage of Apple Silicon's efficiency cores, resulting in significantly lower battery draw and instantaneous tab switching.</p>
      <h2>The Shift to Privacy First</h2>
      <p>With privacy dashboards giving users real-time visibility into blocked network trackers and permission requests, modern browsers are putting security back into users' hands.</p>
    `
  },
  "https://news.ycombinator.com": {
    url: "https://news.ycombinator.com",
    domain: "news.ycombinator.com",
    title: "Hacker News - Technology & Startups",
    favicon: "https://news.ycombinator.com/favicon.ico",
    description: "Hacker News: Computer science discoveries, open source releases, and engineering discussions.",
    author: "Y Combinator",
    publishedDate: "Live Feed",
    category: "Community",
    hasAudio: false,
    hasVideo: false,
    contentHtml: `
      <div class="max-w-4xl mx-auto py-4 font-mono text-xs">
        <div class="bg-[#ff6600] text-black px-3 py-2 font-bold flex items-center justify-between rounded-t-lg">
          <div class="flex items-center gap-2">
            <span class="border border-white px-1 font-bold text-white bg-black">Y</span>
            <span>Hacker News</span>
            <span class="font-normal text-[11px] ml-2">new | past | comments | ask | show | jobs | submit</span>
          </div>
          <span class="font-normal text-[11px]">macweb_user (1,420 karma)</span>
        </div>
        <div class="bg-[#f6f6ef] dark:bg-neutral-900 border border-neutral-300 dark:border-neutral-800 p-4 divide-y divide-neutral-200 dark:divide-neutral-800">
          <div class="py-2">
            <div class="flex items-baseline gap-2">
              <span class="text-neutral-400">1.</span>
              <a class="text-blue-900 dark:text-blue-300 font-semibold hover:underline" href="https://webkit.org">Show HN: MACWEB.OS – A clean native WebKit browser for macOS</a>
              <span class="text-neutral-500 text-[10px]">(macweb.os)</span>
            </div>
            <div class="text-[10px] text-neutral-500 ml-5 mt-0.5">
              1,248 points by developer 2 hours ago | hide | 342 comments
            </div>
          </div>
          <div class="py-2">
            <div class="flex items-baseline gap-2">
              <span class="text-neutral-400">2.</span>
              <a class="text-blue-900 dark:text-blue-300 font-semibold hover:underline" href="https://apple.com">How Apple Silicon handles 200+ tabs with unified memory compression</a>
              <span class="text-neutral-500 text-[10px]">(apple.com)</span>
            </div>
            <div class="text-[10px] text-neutral-500 ml-5 mt-0.5">
              892 points by kernellover 4 hours ago | hide | 215 comments
            </div>
          </div>
          <div class="py-2">
            <div class="flex items-baseline gap-2">
              <span class="text-neutral-400">3.</span>
              <a class="text-blue-900 dark:text-blue-300 font-semibold hover:underline" href="https://developer.mozilla.org">Declarative Content Blocking in WebKit: Why it beats DOM script injection</a>
              <span class="text-neutral-500 text-[10px]">(webkit.org)</span>
            </div>
            <div class="text-[10px] text-neutral-500 ml-5 mt-0.5">
              640 points by sec_eng 6 hours ago | hide | 180 comments
            </div>
          </div>
          <div class="py-2">
            <div class="flex items-baseline gap-2">
              <span class="text-neutral-400">4.</span>
              <a class="text-blue-900 dark:text-blue-300 font-semibold hover:underline" href="https://wikipedia.org">SQLite 3.48 Released with WAL2 and Enhanced JSON Indexing</a>
              <span class="text-neutral-500 text-[10px]">(sqlite.org)</span>
            </div>
            <div class="text-[10px] text-neutral-500 ml-5 mt-0.5">
              512 points by db_pro 8 hours ago | hide | 94 comments
            </div>
          </div>
        </div>
      </div>
    `,
    readerHtml: `
      <h1>Show HN: MACWEB.OS – A clean native WebKit browser for macOS</h1>
      <p class="lead">Hacker News Discussion & Architectural Review</p>
      <p>Today we are announcing the open-source release of MACWEB.OS, an independent Safari-class browser for macOS built entirely on Apple's public WebKit APIs, SQLite, and Combine.</p>
    `
  },
  "https://html5test.webkit.macweb.os": {
    url: "https://html5test.webkit.macweb.os",
    domain: "html5test.webkit.macweb.os",
    title: "WebKit Standards Testbench & WebGL Lab",
    favicon: "🧪",
    description: "Interactive HTML5, WebGL, Canvas, Forms, Audio, and Video benchmark suite for MACWEB.OS.",
    author: "MACWEB Standards Team",
    publishedDate: "Active Live Benchmark",
    category: "Benchmark",
    hasAudio: true,
    hasVideo: true,
    interactiveType: "testbench",
    contentHtml: `
      <div class="max-w-4xl mx-auto py-6 space-y-8">
        <div class="rounded-2xl p-6 bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-xl flex items-center justify-between">
          <div>
            <span class="px-3 py-1 bg-white/20 rounded-full text-xs font-semibold uppercase tracking-wider">WebKit Standards Benchmark</span>
            <h1 class="text-2xl md:text-3xl font-bold mt-2">HTML5 & WebGL Capability Testbench</h1>
            <p class="text-xs text-white/80 mt-1">Real-time validation of HTML5 tags, AudioContext, Canvas2D, WebGL shaders, and Media Streams.</p>
          </div>
          <div class="text-right">
            <span class="text-4xl font-extrabold">528</span>
            <span class="text-xs block text-white/80">/ 555 Points</span>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-4">
            <h3 class="font-bold text-base text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <span>🎨</span> 2D Canvas & WebGL Particles
            </h3>
            <p class="text-xs text-neutral-500">Live 60 FPS hardware-accelerated Canvas animation rendered in WKWebView.</p>
            <div class="relative w-full h-44 rounded-xl bg-neutral-950 overflow-hidden flex items-center justify-center border border-neutral-800">
              <canvas id="interactiveCanvas" width="360" height="176" class="w-full h-full"></canvas>
            </div>
            <div class="flex items-center justify-between text-xs text-neutral-600 dark:text-neutral-400">
              <span>Frame Rate: <strong class="text-emerald-500">60.0 FPS</strong></span>
              <span>Render Engine: <strong class="text-blue-500">Apple Metal MetalKit</strong></span>
            </div>
          </div>

          <div class="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-sm space-y-4">
            <h3 class="font-bold text-base text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
              <span>🎵</span> Web Audio & Media Session
            </h3>
            <p class="text-xs text-neutral-500">Tests browser audio decoding, tab equalizer detection, and mute states.</p>
            <div class="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700 space-y-3">
              <div class="flex items-center justify-between text-xs">
                <span class="font-semibold text-neutral-800 dark:text-neutral-200">Synth Ambient Stream</span>
                <span class="text-neutral-500">44.1 kHz • Stereo</span>
              </div>
              <div class="h-2 w-full bg-neutral-200 dark:bg-neutral-700 rounded-full overflow-hidden">
                <div class="h-full bg-blue-600 w-2/3 animate-pulse"></div>
              </div>
              <div class="flex gap-2">
                <button class="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium">▶ Play Audio Demo</button>
                <button class="px-3 py-1.5 rounded-lg border border-neutral-300 dark:border-neutral-600 text-xs font-medium">🔇 Test Mute Tab</button>
              </div>
            </div>
            <div class="text-xs text-neutral-500">Notice the audio equalizer badge in the tab bar when audio plays!</div>
          </div>
        </div>

        <div class="p-6 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 space-y-4">
          <h3 class="font-bold text-base text-neutral-900 dark:text-neutral-100 flex items-center gap-2">
            <span>📝</span> HTML5 Form Controls & Autofill Verification
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label class="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">Username / Email</label>
              <input type="email" placeholder="steve@apple.com" class="w-full px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100" />
            </div>
            <div>
              <label class="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">Password</label>
              <input type="password" value="SuperSecretPassword123" class="w-full px-3 py-2 rounded-lg border border-neutral-300 dark:border-neutral-700 bg-neutral-50 dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100" />
            </div>
            <div>
              <label class="block font-medium text-neutral-700 dark:text-neutral-300 mb-1">Passkey / Biometric</label>
              <button class="w-full px-3 py-2 rounded-lg bg-neutral-900 dark:bg-neutral-100 text-white dark:text-neutral-900 font-medium">Sign in with Touch ID</button>
            </div>
          </div>
        </div>
      </div>
    `,
    readerHtml: `
      <h1>WebKit Standards Testbench</h1>
      <p class="lead">Automated verification of modern web platform specifications running inside MACWEB.OS.</p>
      <h2>Coverage</h2>
      <p>This test suite verifies compliance across HTML5 Semantic Elements, WebGL 2.0 shaders, CSS Grid and Subgrid, Web Audio synthesis, and sandboxed IndexedDB storage.</p>
    `
  }
};

export function resolveUrl(input: string, searchEngineUrlTemplate: string = "https://www.google.com/search?q={query}"): {
  url: string;
  isSearch: boolean;
  domain: string;
} {
  const trimmed = input.trim();
  if (!trimmed) {
    return { url: "macweb://newtab", isSearch: false, domain: "macweb.os" };
  }

  // Handle internal schemes
  if (trimmed.startsWith("macweb://") || trimmed.startsWith("about:")) {
    const cleanScheme = trimmed.replace(/^about:/, "macweb://");
    return { url: cleanScheme, isSearch: false, domain: "macweb.os" };
  }

  // Check if it's a valid URL with protocol
  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const parsed = new URL(trimmed);
      return { url: trimmed, isSearch: false, domain: parsed.hostname };
    } catch {
      // invalid URL, proceed to search
    }
  }

  // Check if it looks like a domain (e.g. apple.com, google.co.uk, localhost:3000)
  const isDomainPattern = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/.*)?$/i.test(trimmed) || /^localhost(:[0-9]+)?(\/.*)?$/i.test(trimmed);
  if (isDomainPattern && !trimmed.includes(" ")) {
    const formattedUrl = `https://${trimmed}`;
    try {
      const parsed = new URL(formattedUrl);
      return { url: formattedUrl, isSearch: false, domain: parsed.hostname };
    } catch {
      // fallback
    }
  }

  // It's a search query
  const searchUrl = searchEngineUrlTemplate.replace("{query}", encodeURIComponent(trimmed));
  return { url: searchUrl, isSearch: true, domain: "search" };
}

export function getDomainFromUrl(urlStr: string): string {
  if (urlStr.startsWith("macweb://") || urlStr.startsWith("about:")) {
    return "macweb.os";
  }
  try {
    const parsed = new URL(urlStr);
    return parsed.hostname.replace(/^www\./, "");
  } catch {
    return urlStr;
  }
}

export function getFaviconForUrl(urlStr: string): string {
  if (urlStr.startsWith("macweb://newtab")) return "🧭";
  if (urlStr.startsWith("macweb://privacy")) return "🛡️";
  if (urlStr.startsWith("macweb://downloads")) return "⬇️";
  if (urlStr.startsWith("macweb://history")) return "🕒";
  if (urlStr.startsWith("macweb://bookmarks")) return "⭐";
  if (urlStr.startsWith("macweb://reading-list")) return "📖";
  if (urlStr.startsWith("macweb://extensions")) return "🧩";
  if (urlStr.startsWith("macweb://developer")) return "🛠️";
  if (urlStr.startsWith("macweb://code")) return "💻";
  if (urlStr.includes("apple.com")) return "";
  if (urlStr.includes("github.com")) return "🐙";
  if (urlStr.includes("wikipedia.org")) return "W";
  if (urlStr.includes("bbc.com")) return "BBC";
  if (urlStr.includes("news.ycombinator.com")) return "Y";
  if (urlStr.includes("google.com")) return "🔍";
  if (urlStr.includes("duckduckgo.com")) return "🦆";
  if (urlStr.includes("html5test")) return "🧪";
  return "🌐";
}
