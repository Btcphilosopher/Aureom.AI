import {
  Bookmark,
  BookmarkFolder,
  HistoryItem,
  ReadingListItem,
  DownloadItem,
  SitePermission,
  WebExtension,
  BrowserSettings,
  TabGroup,
  BrowserSession,
  BrowserWindow,
  BrowserTab,
} from "@/types/browser";
import { SEARCH_PROVIDERS } from "./curatedWebData";

const STORAGE_KEYS = {
  SETTINGS: "macweb_settings",
  BOOKMARKS: "macweb_bookmarks",
  BOOKMARK_FOLDERS: "macweb_bookmark_folders",
  HISTORY: "macweb_history",
  READING_LIST: "macweb_reading_list",
  DOWNLOADS: "macweb_downloads",
  TAB_GROUPS: "macweb_tab_groups",
  SITE_PERMISSIONS: "macweb_site_permissions",
  EXTENSIONS: "macweb_extensions",
  SESSIONS: "macweb_sessions",
  RECOVERY_SNAPSHOT: "macweb_recovery_snapshot",
};

export const DEFAULT_SETTINGS: BrowserSettings = {
  homepage: "newtab",
  customHomepageUrl: "https://apple.com",
  defaultSearchEngineId: "google",
  defaultDownloadLocation: "~/Downloads",
  openTabsOnStartup: "restore",
  contentBlockingEnabled: true,
  blockTrackers: true,
  blockCryptominers: true,
  blockSocialWidgets: true,
  doNotTrack: true,
  httpsOnlyMode: false,
  developerModeEnabled: true,
  soundEffectsEnabled: true,
  reduceMotion: false,
  theme: "system",
  newTabWallpaper: "sequoia-gradient",
};

export const INITIAL_FOLDERS: BookmarkFolder[] = [
  { id: "folder-favorites", parentId: null, name: "Favorites Bar", createdAt: Date.now() - 100000, order: 0 },
  { id: "folder-dev", parentId: null, name: "Developer Resources", createdAt: Date.now() - 90000, order: 1 },
  { id: "folder-news", parentId: null, name: "News & Media", createdAt: Date.now() - 80000, order: 2 },
];

export const INITIAL_BOOKMARKS: Bookmark[] = [
  { id: "bm-1", folderId: "folder-favorites", title: "Apple", url: "https://apple.com", favicon: "", createdAt: Date.now() - 50000, order: 0 },
  { id: "bm-2", folderId: "folder-favorites", title: "GitHub", url: "https://github.com", favicon: "🐙", createdAt: Date.now() - 48000, order: 1 },
  { id: "bm-3", folderId: "folder-favorites", title: "Wikipedia", url: "https://wikipedia.org", favicon: "W", createdAt: Date.now() - 46000, order: 2 },
  { id: "bm-4", folderId: "folder-dev", title: "WebKit Open Source", url: "https://webkit.org", favicon: "🧭", createdAt: Date.now() - 40000, order: 0 },
  { id: "bm-5", folderId: "folder-dev", title: "MDN Web Docs", url: "https://developer.mozilla.org", favicon: "M", createdAt: Date.now() - 38000, order: 1 },
  { id: "bm-6", folderId: "folder-dev", title: "HTML5 Test Lab", url: "https://html5test.webkit.macweb.os", favicon: "🧪", createdAt: Date.now() - 36000, order: 2 },
  { id: "bm-7", folderId: "folder-news", title: "BBC News", url: "https://bbc.com/news", favicon: "BBC", createdAt: Date.now() - 30000, order: 0 },
  { id: "bm-8", folderId: "folder-news", title: "Hacker News", url: "https://news.ycombinator.com", favicon: "Y", createdAt: Date.now() - 28000, order: 1 },
];

export const INITIAL_TAB_GROUPS: TabGroup[] = [
  { id: "group-work", name: "Work & Code", color: "#007aff", collapsed: false, createdAt: Date.now() - 70000 },
  { id: "group-personal", name: "Personal News", color: "#ff9500", collapsed: false, createdAt: Date.now() - 60000 },
  { id: "group-research", name: "WebKit Research", color: "#34c759", collapsed: false, createdAt: Date.now() - 50000 },
];

export const INITIAL_HISTORY: HistoryItem[] = [
  { id: "hist-1", url: "https://apple.com", title: "Apple - macOS Sequoia & Silicon Innovation", favicon: "", timestamp: Date.now() - 1000 * 60 * 15, visitCount: 14, isPrivate: false, domain: "apple.com" },
  { id: "hist-2", url: "https://github.com", title: "GitHub - Build and Ship Software Together", favicon: "🐙", timestamp: Date.now() - 1000 * 60 * 45, visitCount: 22, isPrivate: false, domain: "github.com" },
  { id: "hist-3", url: "https://news.ycombinator.com", title: "Hacker News - Technology & Startups", favicon: "Y", timestamp: Date.now() - 1000 * 60 * 60 * 3, visitCount: 31, isPrivate: false, domain: "news.ycombinator.com" },
  { id: "hist-4", url: "https://wikipedia.org", title: "WebKit - Wikipedia, the Free Encyclopedia", favicon: "W", timestamp: Date.now() - 1000 * 60 * 60 * 25, visitCount: 8, isPrivate: false, domain: "wikipedia.org" },
  { id: "hist-5", url: "https://bbc.com/news", title: "BBC News - Global Technology & Web Frontiers", favicon: "BBC", timestamp: Date.now() - 1000 * 60 * 60 * 50, visitCount: 5, isPrivate: false, domain: "bbc.com" },
  { id: "hist-6", url: "https://html5test.webkit.macweb.os", title: "WebKit Standards Testbench & WebGL Lab", favicon: "🧪", timestamp: Date.now() - 1000 * 60 * 60 * 120, visitCount: 19, isPrivate: false, domain: "html5test.webkit.macweb.os" },
];

export const INITIAL_READING_LIST: ReadingListItem[] = [
  {
    id: "read-1",
    url: "https://apple.com",
    title: "macOS Sequoia & Silicon Architecture Whitepaper",
    favicon: "",
    savedTimestamp: Date.now() - 1000 * 60 * 60 * 4,
    isRead: false,
    previewText: "Detailed overview of unified memory architecture, Metal 3 pipeline, and WebKit process isolation.",
    readingTimeMinutes: 5,
  },
  {
    id: "read-2",
    url: "https://bbc.com/news",
    title: "Next-Generation Native Web Browsers Challenge Cloud Giants",
    favicon: "BBC",
    savedTimestamp: Date.now() - 1000 * 60 * 60 * 20,
    isRead: true,
    previewText: "How engineers are returning to native Swift and AppKit frameworks for 4x battery improvements.",
    readingTimeMinutes: 4,
  },
  {
    id: "read-3",
    url: "https://wikipedia.org",
    title: "WebKit Software Architecture & History",
    favicon: "W",
    savedTimestamp: Date.now() - 1000 * 60 * 60 * 48,
    isRead: false,
    previewText: "In-depth history of the WebCore layout engine and JavaScriptCore bytecode VM.",
    readingTimeMinutes: 8,
  },
];

export const INITIAL_DOWNLOADS: DownloadItem[] = [
  {
    id: "dl-1",
    filename: "macweb-os-v3.7-release.dmg",
    sourceUrl: "https://github.com/macweb-os/releases/download/v3.7/macweb-os.dmg",
    totalBytes: 94371840,
    receivedBytes: 94371840,
    speedBytesPerSec: 0,
    status: "completed",
    destinationPath: "~/Downloads/macweb-os-v3.7-release.dmg",
    startedAt: Date.now() - 1000 * 60 * 30,
    completedAt: Date.now() - 1000 * 60 * 28,
    mimeType: "application/x-apple-diskimage",
  },
  {
    id: "dl-2",
    filename: "webkit-architecture-diagram.pdf",
    sourceUrl: "https://developer.apple.com/webkit/docs/architecture.pdf",
    totalBytes: 8400000,
    receivedBytes: 8400000,
    speedBytesPerSec: 0,
    status: "completed",
    destinationPath: "~/Downloads/webkit-architecture-diagram.pdf",
    startedAt: Date.now() - 1000 * 60 * 120,
    completedAt: Date.now() - 1000 * 60 * 119,
    mimeType: "application/pdf",
  },
];

export const INITIAL_EXTENSIONS: WebExtension[] = [
  {
    id: "ext-dark-reader",
    name: "Dark Reader Pro",
    version: "4.9.72",
    description: "Inverts colors and generates smooth, eye-pleasing dark themes for every website.",
    icon: "🌙",
    author: "Dark Theme Lab",
    enabled: true,
    permissions: ["activeTab", "storage", "<all_urls>"],
    hasPopup: true,
    popupTitle: "Dark Reader Settings",
  },
  {
    id: "ext-adblock",
    name: "AdBlock Plus for WebKit",
    version: "3.18.2",
    description: "High-performance declarative content blocking rules using native WebKit content filtering.",
    icon: "🛡️",
    author: "Privacy Shield Org",
    enabled: true,
    permissions: ["declarativeNetRequest", "storage"],
    hasPopup: true,
    popupTitle: "AdBlock Statistics",
  },
  {
    id: "ext-json-viewer",
    name: "JSON Formatter & Inspector",
    version: "2.1.0",
    description: "Automatically formats raw JSON payloads into an interactive collapsible tree view with syntax highlighting.",
    icon: "📦",
    author: "Developer Tools Team",
    enabled: true,
    permissions: ["webNavigation"],
    hasPopup: false,
  },
  {
    id: "ext-1password",
    name: "1Password / Keychain Passwords",
    version: "8.10.4",
    description: "Fills credentials and Passkeys seamlessly using macOS Keychain biometrics.",
    icon: "🔑",
    author: "AgileBits",
    enabled: true,
    permissions: ["contextMenus", "storage", "biometrics"],
    hasPopup: true,
    popupTitle: "1Password Quick Access",
  },
  {
    id: "ext-react-devtools",
    name: "React & Web DevTools",
    version: "5.3.1",
    description: "Inspects React component hierarchies, props, and state inside WebKit Web Inspector.",
    icon: "⚛️",
    author: "Meta Open Source",
    enabled: true,
    permissions: ["devtools"],
    hasPopup: false,
  },
];

export const INITIAL_SITE_PERMISSIONS: Record<string, SitePermission> = {
  "apple.com": {
    domain: "apple.com",
    camera: "ask",
    microphone: "ask",
    location: "allow",
    notifications: "allow",
    mediaAutoplay: "allow",
    popups: "block",
    contentBlocking: true,
    zoomLevel: 100,
  },
  "github.com": {
    domain: "github.com",
    camera: "deny",
    microphone: "deny",
    location: "deny",
    notifications: "allow",
    mediaAutoplay: "allow",
    popups: "allow",
    contentBlocking: false,
    zoomLevel: 100,
  },
  "html5test.webkit.macweb.os": {
    domain: "html5test.webkit.macweb.os",
    camera: "allow",
    microphone: "allow",
    location: "allow",
    notifications: "allow",
    mediaAutoplay: "allow",
    popups: "allow",
    contentBlocking: false,
    zoomLevel: 100,
  },
};

// Safe local storage helpers
export function loadFromStorage<T>(key: string, defaultValue: T): T {
  if (typeof window === "undefined") return defaultValue;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw) as T;
  } catch {
    return defaultValue;
  }
}

export function saveToStorage<T>(key: string, value: T): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.warn(`Failed to save to localStorage key: ${key}`, err);
  }
}
