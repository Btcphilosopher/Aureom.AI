import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  try {
    const { prompt, systemInstruction, context } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: "GEMINI_API_KEY is not configured in server environment." },
        { status: 500 }
      );
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const combinedPrompt = context
      ? `[PAGE / CONTEXT INFORMATION]:\n${context}\n\n[USER INSTRUCTION]:\n${prompt}`
      : prompt;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: combinedPrompt,
      config: {
        systemInstruction:
          systemInstruction ||
          "You are MACWEB.OS AI Browser Copilot, an intelligent, privacy-conscious Safari-class browser companion for macOS. Provide clear, structured, high-value answers, summaries, comparisons, or data extractions based on the web content.",
      },
    });

    const text = response.text || "No response generated.";
    return NextResponse.json({ text });
  } catch (error: unknown) {
    console.error("Gemini API Error:", error);
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error occurred";
    return NextResponse.json({ error: errorMessage }, { status: 500 });
  }
}
