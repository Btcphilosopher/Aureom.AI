import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'MACWEB.OS - Professional Native macOS Web Browser',
  description: 'A high-performance Safari-class macOS web browser shell built around WebKit architecture with multi-tab browsing, multi-window sessions, omnibox search, reader mode, extensions, privacy dashboard, and AI assistant.',
  openGraph: {
    title: 'MACWEB.OS - Professional Native macOS Web Browser',
    description: 'A high-performance Safari-class macOS web browser shell built around WebKit architecture with multi-tab browsing, multi-window sessions, omnibox search, reader mode, extensions, privacy dashboard, and AI assistant.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MACWEB.OS - Professional Native macOS Web Browser',
    description: 'A high-performance Safari-class macOS web browser shell built around WebKit architecture with multi-tab browsing, multi-window sessions, omnibox search, reader mode, extensions, privacy dashboard, and AI assistant.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
