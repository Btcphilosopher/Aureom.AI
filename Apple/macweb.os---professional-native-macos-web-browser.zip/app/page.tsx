"use client";

import React, { useEffect } from "react";
import { BrowserProvider, useBrowser } from "@/context/BrowserContext";
import { MenuBar } from "@/components/macOS/MenuBar";
import { BrowserWindow } from "@/components/BrowserWindow";
import {
  Compass,
  Plus,
  Shield,
  Sparkles,
  Layers,
  Code,
  Folder,
  Settings,
  HelpCircle,
  ExternalLink,
} from "lucide-react";

function BrowserDesktop() {
  const {
    windows,
    activeWindowId,
    activateWindow,
    createNewWindow,
    createNewTab,
    closeTab,
    activeTabId,
    reload,
    isWebInspectorOpen,
    setIsWebInspectorOpen,
    isAIDrawerOpen,
    setIsAIDrawerOpen,
    isTabOverviewOpen,
    setIsTabOverviewOpen,
    isFindBarOpen,
    setIsFindBarOpen,
    isSettingsOpen,
    setIsSettingsOpen,
    isNativeCodeModalOpen,
    setIsNativeCodeModalOpen,
    toggleReaderMode,
    addBookmark,
    activeTab,
  } = useBrowser();

  // Global Keyboard Shortcuts (⌘T, ⌘W, ⌘N, ⌘⇧N, ⌘R, ⌘L, ⌘F, ⌘D, ⌘J, ⌘⌥I, ⌘⇧\)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isCmdOrCtrl = e.metaKey || e.ctrlKey;
      if (!isCmdOrCtrl) return;

      if (e.key === "t" && !e.shiftKey) {
        e.preventDefault();
        createNewTab("macweb://newtab");
      } else if (e.key === "w" && !e.shiftKey) {
        e.preventDefault();
        if (activeTabId) closeTab(activeTabId);
      } else if (e.key === "n" && !e.shiftKey) {
        e.preventDefault();
        createNewWindow("normal");
      } else if (e.key === "N" && e.shiftKey) {
        e.preventDefault();
        createNewWindow("private");
      } else if (e.key === "r" && !e.shiftKey) {
        e.preventDefault();
        reload();
      } else if (e.key === "f" && !e.shiftKey) {
        e.preventDefault();
        setIsFindBarOpen(true);
      } else if (e.key === "j" && !e.shiftKey) {
        e.preventDefault();
        setIsAIDrawerOpen(!isAIDrawerOpen);
      } else if (e.key === "d" && !e.shiftKey) {
        e.preventDefault();
        if (activeTab) addBookmark(activeTab.title, activeTab.url);
      } else if (e.key === "i" && e.altKey) {
        e.preventDefault();
        setIsWebInspectorOpen(!isWebInspectorOpen);
      } else if (e.key === "\\" && e.shiftKey) {
        e.preventDefault();
        setIsTabOverviewOpen(!isTabOverviewOpen);
      } else if (e.key === "," && !e.shiftKey) {
        e.preventDefault();
        setIsSettingsOpen(!isSettingsOpen);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    createNewTab,
    closeTab,
    activeTabId,
    createNewWindow,
    reload,
    isAIDrawerOpen,
    setIsAIDrawerOpen,
    isWebInspectorOpen,
    setIsWebInspectorOpen,
    isTabOverviewOpen,
    setIsTabOverviewOpen,
    isFindBarOpen,
    setIsFindBarOpen,
    isSettingsOpen,
    setIsSettingsOpen,
    addBookmark,
    activeTab,
  ]);

  return (
    <div
      id="macweb-desktop-container"
      className="w-screen h-screen overflow-hidden flex flex-col bg-gradient-to-br from-[#1c1d22] via-[#121316] to-[#090a0d] text-neutral-100 select-none relative font-sans"
    >
      {/* macOS Top Menu Bar */}
      <MenuBar />

      {/* Main Desktop Space */}
      <div className="flex-1 w-full relative p-2 sm:p-3 overflow-hidden flex flex-col items-center justify-center">
        {windows.map((win) => (
          <div
            key={win.id}
            className={`w-full h-full max-w-full max-h-full transition-all duration-150 ${
              win.id === activeWindowId ? "z-20 scale-100" : "z-10 scale-[0.99] opacity-90 hidden"
            }`}
          >
            <BrowserWindow browserWindow={win} />
          </div>
        ))}
      </div>

      {/* Bottom Floating macOS Dock */}
      <div className="w-full flex justify-center pb-2 pointer-events-none">
        <div className="pointer-events-auto h-12 px-3 bg-neutral-900/80 dark:bg-black/70 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-2xl flex items-center gap-2">
          {/* MacWeb Browser Icon */}
          <button
            onClick={() => createNewWindow("normal")}
            title="MACWEB.OS Browser (Click to New Window)"
            className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md hover:scale-110 hover:-translate-y-1 transition-all"
          >
            <Compass className="w-5 h-5" />
          </button>

          {/* New Private Window */}
          <button
            onClick={() => createNewWindow("private")}
            title="Open Private Window (⌘⇧N)"
            className="w-9 h-9 rounded-xl bg-purple-900/60 border border-purple-500/40 flex items-center justify-center text-purple-300 hover:scale-110 hover:-translate-y-1 transition-all"
          >
            <Shield className="w-5 h-5" />
          </button>

          {/* AI Copilot */}
          <button
            onClick={() => setIsAIDrawerOpen(!isAIDrawerOpen)}
            title="AI Browser Assistant (⌘J)"
            className="w-9 h-9 rounded-xl bg-blue-900/60 border border-blue-500/40 flex items-center justify-center text-blue-300 hover:scale-110 hover:-translate-y-1 transition-all"
          >
            <Sparkles className="w-5 h-5" />
          </button>

          {/* Tab Overview */}
          <button
            onClick={() => setIsTabOverviewOpen(!isTabOverviewOpen)}
            title="Tab Overview (⌘⇧\)"
            className="w-9 h-9 rounded-xl bg-neutral-800 border border-white/10 flex items-center justify-center text-neutral-200 hover:scale-110 hover:-translate-y-1 transition-all"
          >
            <Layers className="w-5 h-5" />
          </button>

          {/* Web Inspector */}
          <button
            onClick={() => setIsWebInspectorOpen(!isWebInspectorOpen)}
            title="Developer Web Inspector (⌘⌥I)"
            className="w-9 h-9 rounded-xl bg-neutral-800 border border-white/10 flex items-center justify-center text-emerald-400 hover:scale-110 hover:-translate-y-1 transition-all"
          >
            <Code className="w-5 h-5" />
          </button>

          <div className="h-5 w-px bg-white/20 mx-0.5" />

          {/* Swift Native Architecture Explorer */}
          <button
            onClick={() => setIsNativeCodeModalOpen(true)}
            title="Inspect Swift & WebKit Native Source"
            className="w-9 h-9 rounded-xl bg-orange-950/60 border border-orange-500/40 flex items-center justify-center text-orange-400 hover:scale-110 hover:-translate-y-1 transition-all"
          >
            <span className="font-mono font-bold text-xs">SWIFT</span>
          </button>

          {/* Settings */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            title="Browser Settings (⌘,)"
            className="w-9 h-9 rounded-xl bg-neutral-800 border border-white/10 flex items-center justify-center text-neutral-300 hover:scale-110 hover:-translate-y-1 transition-all"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Page() {
  return (
    <BrowserProvider>
      <BrowserDesktop />
    </BrowserProvider>
  );
}
