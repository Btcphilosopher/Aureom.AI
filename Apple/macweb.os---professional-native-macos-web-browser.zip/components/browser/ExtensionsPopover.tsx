"use client";

import React from "react";
import { useBrowser } from "@/context/BrowserContext";
import { Puzzle, X, Settings2, ExternalLink } from "lucide-react";

export function ExtensionsPopover() {
  const {
    isExtensionsPopoverOpen,
    setIsExtensionsPopoverOpen,
    extensions,
    toggleExtension,
    setIsSettingsOpen,
    setSettingsActiveTab,
  } = useBrowser();

  if (!isExtensionsPopoverOpen) return null;

  return (
    <div
      id="extensions-popover"
      className="absolute top-20 right-14 w-80 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-2xl border border-neutral-300 dark:border-neutral-700 rounded-2xl shadow-2xl overflow-hidden z-50 select-none text-xs"
    >
      {/* Header */}
      <div className="p-3 bg-neutral-100 dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Puzzle className="w-4 h-4 text-purple-500" />
          <span className="font-bold text-neutral-900 dark:text-white">WebExtensions</span>
        </div>
        <button
          onClick={() => setIsExtensionsPopoverOpen(false)}
          className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-white rounded"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Extension Items */}
      <div className="p-2 space-y-2 max-h-80 overflow-y-auto">
        {extensions.map((ext) => (
          <div
            key={ext.id}
            className="p-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 space-y-1.5"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">{ext.icon}</span>
                <div>
                  <div className="font-semibold text-neutral-900 dark:text-white">{ext.name}</div>
                  <div className="text-[10px] text-neutral-400">v{ext.version}</div>
                </div>
              </div>

              <button
                onClick={() => toggleExtension(ext.id)}
                className={`w-9 h-5 rounded-full p-0.5 transition-colors shrink-0 ${
                  ext.enabled ? "bg-blue-600" : "bg-neutral-300 dark:bg-neutral-700"
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    ext.enabled ? "translate-x-4" : "translate-x-0"
                  }`}
                />
              </button>
            </div>
            <p className="text-[11px] text-neutral-500 dark:text-neutral-400 leading-snug">
              {ext.description}
            </p>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="p-2.5 bg-neutral-100 dark:bg-neutral-950 border-t border-neutral-200 dark:border-neutral-800 flex justify-between items-center text-[11px]">
        <button
          onClick={() => {
            setIsSettingsOpen(true);
            setSettingsActiveTab("extensions");
            setIsExtensionsPopoverOpen(false);
          }}
          className="text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
        >
          <Settings2 className="w-3 h-3" /> Manage Extensions...
        </button>
      </div>
    </div>
  );
}
