"use client";

import React from "react";
import { useBrowser } from "@/context/BrowserContext";
import {
  Download,
  X,
  Play,
  Pause,
  Trash2,
  FolderOpen,
  FileCheck,
  RotateCcw,
} from "lucide-react";

export function DownloadManagerPopover() {
  const {
    isDownloadsPopoverOpen,
    setIsDownloadsPopoverOpen,
    downloads,
    cancelDownload,
    pauseDownload,
    resumeDownload,
    startDownload,
  } = useBrowser();

  if (!isDownloadsPopoverOpen) return null;

  return (
    <div
      id="downloads-popover"
      className="absolute top-20 right-6 w-84 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-2xl border border-neutral-300 dark:border-neutral-700 rounded-2xl shadow-2xl overflow-hidden z-50 select-none text-xs"
    >
      {/* Header */}
      <div className="p-3 bg-neutral-100 dark:bg-neutral-950 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Download className="w-4 h-4 text-blue-500" />
          <span className="font-bold text-neutral-900 dark:text-white">Downloads</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => startDownload("macweb-demo-sample.zip", "https://webkit.org/demo.zip", 45000000)}
            className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold hover:underline"
          >
            + Test Download
          </button>
          <button
            onClick={() => setIsDownloadsPopoverOpen(false)}
            className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-white rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Downloads List */}
      <div className="p-2 space-y-2 max-h-80 overflow-y-auto">
        {downloads.length === 0 ? (
          <div className="p-6 text-center text-neutral-400 text-xs">
            No active or recent downloads.
          </div>
        ) : (
          downloads.map((dl) => (
            <div
              key={dl.id}
              className="p-2.5 rounded-xl bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700 space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-neutral-900 dark:text-white truncate flex-1">
                  {dl.filename}
                </span>
                <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded capitalize ${
                  dl.status === "completed"
                    ? "bg-emerald-500/20 text-emerald-600 dark:text-emerald-400"
                    : dl.status === "downloading"
                    ? "bg-blue-500/20 text-blue-600 dark:text-blue-400 animate-pulse"
                    : "bg-neutral-200 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-400"
                }`}>
                  {dl.status}
                </span>
              </div>

              {dl.status === "downloading" && (
                <div className="space-y-1">
                  <div className="h-1.5 w-full bg-neutral-200 dark:bg-neutral-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 transition-all"
                      style={{ width: `${(dl.receivedBytes / dl.totalBytes) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-neutral-400">
                    <span>{(dl.receivedBytes / 1048576).toFixed(1)} MB / {(dl.totalBytes / 1048576).toFixed(1)} MB</span>
                    <span>{(dl.speedBytesPerSec / 1048576).toFixed(1)} MB/s</span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between pt-1 border-t border-neutral-200 dark:border-neutral-700/60 text-[10px]">
                <span className="text-neutral-400 truncate max-w-[150px]">{dl.destinationPath}</span>
                <div className="flex items-center gap-1.5">
                  {dl.status === "downloading" ? (
                    <button
                      onClick={() => pauseDownload(dl.id)}
                      className="p-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded text-neutral-600 dark:text-neutral-300"
                    >
                      <Pause className="w-3 h-3" />
                    </button>
                  ) : dl.status === "paused" ? (
                    <button
                      onClick={() => resumeDownload(dl.id)}
                      className="p-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded text-neutral-600 dark:text-neutral-300"
                    >
                      <Play className="w-3 h-3" />
                    </button>
                  ) : null}

                  <button
                    onClick={() => cancelDownload(dl.id)}
                    className="p-1 hover:bg-rose-100 dark:hover:bg-rose-900/30 text-neutral-400 hover:text-rose-500 rounded"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
