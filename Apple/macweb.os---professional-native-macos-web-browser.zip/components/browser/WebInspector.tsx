"use client";

import React, { useState } from "react";
import { useBrowser } from "@/context/BrowserContext";
import {
  Code,
  Terminal,
  Activity,
  Gauge,
  Database,
  X,
  Trash2,
  Play,
  CheckCircle,
  AlertTriangle,
  AlertCircle,
  Info,
  ChevronRight,
  ChevronDown,
  Layers,
} from "lucide-react";

export function WebInspector() {
  const {
    isWebInspectorOpen,
    setIsWebInspectorOpen,
    inspectorActiveTab,
    setInspectorActiveTab,
    consoleLogs,
    addConsoleLog,
    clearConsoleLogs,
    networkRequests,
    clearNetworkRequests,
    performanceMetrics,
    activeTab,
  } = useBrowser();

  const [consoleInput, setConsoleInput] = useState("");
  const [selectedDomNode, setSelectedDomNode] = useState("body");
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    html: true,
    body: true,
    main: true,
  });

  if (!isWebInspectorOpen) return null;

  const toggleNode = (nodeId: string) => {
    setExpandedNodes((prev) => ({ ...prev, [nodeId]: !prev[nodeId] }));
  };

  const handleConsoleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!consoleInput.trim()) return;

    addConsoleLog("log", `> ${consoleInput}`, "User REPL");

    try {
      if (consoleInput === "navigator.userAgent") {
        addConsoleLog("info", `"${navigator.userAgent} MACWEB.OS/3.7"`, "Console");
      } else if (consoleInput === "document.title") {
        addConsoleLog("info", `"${activeTab?.title || "MACWEB.OS"}"`, "Console");
      } else if (consoleInput === "window.location.href") {
        addConsoleLog("info", `"${activeTab?.url || "macweb://newtab"}"`, "Console");
      } else {
        // Safe math / basic expression evaluation
        const res = new Function(`return (${consoleInput})`)();
        addConsoleLog("info", String(res), "Evaluator");
      }
    } catch (err: any) {
      addConsoleLog("error", `Uncaught ${err.toString()}`, "Evaluator");
    }

    setConsoleInput("");
  };

  const getLogIcon = (level: string) => {
    switch (level) {
      case "error":
        return <AlertCircle className="w-3.5 h-3.5 text-rose-500 shrink-0" />;
      case "warn":
        return <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />;
      case "info":
        return <Info className="w-3.5 h-3.5 text-blue-400 shrink-0" />;
      default:
        return <CheckCircle className="w-3.5 h-3.5 text-neutral-400 shrink-0" />;
    }
  };

  return (
    <div
      id="browser-web-inspector"
      className="h-72 w-full bg-neutral-900 border-t border-neutral-700 text-neutral-200 flex flex-col select-none text-xs z-30 shrink-0 font-mono"
    >
      {/* Inspector Top Bar */}
      <div className="h-8 px-3 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between font-sans">
        <div className="flex items-center gap-1">
          {[
            { id: "elements", label: "Elements", icon: Code },
            { id: "console", label: "Console", icon: Terminal, badge: consoleLogs.length },
            { id: "network", label: "Network", icon: Activity, badge: networkRequests.length },
            { id: "performance", label: "Performance", icon: Gauge },
            { id: "storage", label: "Storage", icon: Database },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = inspectorActiveTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setInspectorActiveTab(tab.id as any)}
                className={`px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                  isActive
                    ? "bg-neutral-800 text-white border border-neutral-700"
                    : "text-neutral-400 hover:bg-neutral-900 hover:text-neutral-200"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="text-[10px] px-1 rounded-full bg-neutral-700 text-neutral-300 font-mono">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-emerald-400 font-mono flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            WebKit Inspector Connected
          </span>
          <button
            onClick={() => setIsWebInspectorOpen(false)}
            className="p-1 hover:bg-neutral-800 text-neutral-400 hover:text-white rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Inspector Content Area */}
      <div className="flex-1 overflow-hidden flex">
        {/* ELEMENTS TAB */}
        {inspectorActiveTab === "elements" && (
          <div className="w-full h-full flex divide-x divide-neutral-800">
            {/* DOM Tree */}
            <div className="flex-1 p-3 overflow-y-auto space-y-1 select-text">
              <div className="text-neutral-500 text-[11px]">&lt;!DOCTYPE html&gt;</div>
              <div className="text-purple-400">&lt;html lang=&quot;en&quot;&gt;</div>

              <div className="pl-4 space-y-0.5">
                <div className="text-purple-400">&lt;head&gt; ... &lt;/head&gt;</div>

                <div className="text-purple-400">&lt;body class=&quot;bg-canvas antialiased&quot;&gt;</div>

                <div className="pl-4 space-y-0.5">
                  <div
                    onClick={() => setSelectedDomNode("header")}
                    className={`cursor-pointer px-1 rounded ${selectedDomNode === "header" ? "bg-blue-600/30 text-white" : "hover:bg-neutral-800"}`}
                  >
                    <span className="text-purple-400">&lt;header</span> <span className="text-amber-300">class</span>=<span className="text-emerald-300">&quot;site-nav sticky&quot;</span><span className="text-purple-400">&gt;</span>
                  </div>

                  <div
                    onClick={() => setSelectedDomNode("main")}
                    className={`cursor-pointer px-1 rounded ${selectedDomNode === "main" ? "bg-blue-600/30 text-white" : "hover:bg-neutral-800"}`}
                  >
                    <span className="text-purple-400">&lt;main</span> <span className="text-amber-300">id</span>=<span className="text-emerald-300">&quot;app-root&quot;</span> <span className="text-amber-300">role</span>=<span className="text-emerald-300">&quot;main&quot;</span><span className="text-purple-400">&gt;</span>
                  </div>

                  <div className="pl-4 text-neutral-400 text-[11px]">
                    &lt;!-- WebKit Render Pipeline: GPU Accelerated Texture --&gt;
                  </div>

                  <div className="text-purple-400">&lt;/main&gt;</div>
                  <div className="text-purple-400">&lt;footer&gt; ... &lt;/footer&gt;</div>
                </div>

                <div className="text-purple-400">&lt;/body&gt;</div>
              </div>
              <div className="text-purple-400">&lt;/html&gt;</div>
            </div>

            {/* Computed Styles & Box Model */}
            <div className="w-72 p-3 overflow-y-auto space-y-3 bg-neutral-950 font-sans text-xs">
              <div className="font-semibold text-neutral-400 uppercase tracking-wider text-[10px]">
                Computed Box Model
              </div>

              {/* Box Model visual */}
              <div className="border border-dashed border-amber-500/50 p-2 text-center text-[10px] text-amber-400 rounded-lg">
                margin (0px)
                <div className="border border-solid border-yellow-500/60 p-2 text-yellow-300 my-1 rounded">
                  border (1px)
                  <div className="border border-dashed border-emerald-500/60 p-2 text-emerald-300 my-1 rounded">
                    padding (16px)
                    <div className="bg-blue-600/40 p-2 text-blue-200 font-bold rounded">
                      1200 × 750
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-1 font-mono text-[11px]">
                <div className="flex justify-between text-neutral-400">
                  <span>display</span>
                  <span className="text-neutral-200">flex</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>font-family</span>
                  <span className="text-neutral-200">system-ui, -apple-system</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>box-sizing</span>
                  <span className="text-neutral-200">border-box</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* CONSOLE TAB */}
        {inspectorActiveTab === "console" && (
          <div className="w-full h-full flex flex-col">
            <div className="px-3 py-1 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between text-[11px]">
              <span className="text-neutral-400">Filter: All ({consoleLogs.length})</span>
              <button
                onClick={clearConsoleLogs}
                className="hover:text-rose-400 flex items-center gap-1 text-neutral-400"
              >
                <Trash2 className="w-3 h-3" /> Clear Console
              </button>
            </div>

            <div className="flex-1 p-3 overflow-y-auto space-y-1 select-text">
              {consoleLogs.map((log) => (
                <div
                  key={log.id}
                  className={`flex items-start gap-2 py-1 px-1.5 rounded ${
                    log.level === "error"
                      ? "bg-rose-950/30 text-rose-300"
                      : log.level === "warn"
                      ? "bg-amber-950/30 text-amber-300"
                      : "hover:bg-neutral-800/60 text-neutral-300"
                  }`}
                >
                  {getLogIcon(log.level)}
                  <span className="flex-1 break-all">{log.message}</span>
                  <span className="text-[10px] text-neutral-500 font-sans">{log.source}</span>
                </div>
              ))}
            </div>

            {/* Console REPL Prompt */}
            <form onSubmit={handleConsoleSubmit} className="p-2 bg-neutral-950 border-t border-neutral-800 flex items-center gap-2">
              <span className="text-blue-400 font-bold">&gt;</span>
              <input
                type="text"
                value={consoleInput}
                onChange={(e) => setConsoleInput(e.target.value)}
                placeholder="Type JavaScript expression to evaluate (e.g. document.title, navigator.userAgent, 42 * 10)..."
                className="w-full bg-transparent text-xs text-white focus:outline-none placeholder:text-neutral-600 font-mono"
              />
            </form>
          </div>
        )}

        {/* NETWORK TAB */}
        {inspectorActiveTab === "network" && (
          <div className="w-full h-full flex flex-col">
            <div className="px-3 py-1 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between text-[11px] font-sans">
              <span className="text-neutral-400">{networkRequests.length} requests • 248 KB transferred</span>
              <button onClick={clearNetworkRequests} className="hover:text-rose-400 flex items-center gap-1 text-neutral-400">
                <Trash2 className="w-3 h-3" /> Clear
              </button>
            </div>

            <div className="flex-1 overflow-y-auto">
              <table className="w-full text-left border-collapse text-[11px]">
                <thead>
                  <tr className="bg-neutral-950 text-neutral-400 border-b border-neutral-800 font-sans">
                    <th className="p-2">Name</th>
                    <th className="p-2">Status</th>
                    <th className="p-2">Type</th>
                    <th className="p-2">Size</th>
                    <th className="p-2">Time</th>
                    <th className="p-2">Waterfall</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60 font-mono">
                  {networkRequests.map((req) => (
                    <tr key={req.id} className="hover:bg-neutral-800/50">
                      <td className="p-2 truncate max-w-[200px] text-neutral-200">{req.url}</td>
                      <td className="p-2">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${req.status === 200 ? "bg-emerald-950 text-emerald-400" : "bg-rose-950 text-rose-400"}`}>
                          {req.status}
                        </span>
                      </td>
                      <td className="p-2 text-neutral-400">{req.type}</td>
                      <td className="p-2 text-neutral-400">{(req.size / 1024).toFixed(1)} KB</td>
                      <td className="p-2 text-neutral-400">{req.time} ms</td>
                      <td className="p-2 w-32">
                        <div className="w-full h-2 bg-neutral-800 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500 rounded-full" style={{ width: `${Math.min(100, req.time * 1.5)}%` }} />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PERFORMANCE TAB */}
        {inspectorActiveTab === "performance" && (
          <div className="w-full h-full p-4 overflow-y-auto font-sans space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-1">
                <div className="text-[10px] text-neutral-400 font-semibold uppercase">Frame Rate</div>
                <div className="text-2xl font-bold text-emerald-400 font-mono">{performanceMetrics.fps} FPS</div>
                <div className="text-[10px] text-neutral-500">Metal Pipeline 60Hz Target</div>
              </div>

              <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-1">
                <div className="text-[10px] text-neutral-400 font-semibold uppercase">WebContent RAM</div>
                <div className="text-2xl font-bold text-blue-400 font-mono">{performanceMetrics.memoryMB} MB</div>
                <div className="text-[10px] text-neutral-500">Sandboxed Process Isolation</div>
              </div>

              <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-1">
                <div className="text-[10px] text-neutral-400 font-semibold uppercase">CPU Usage</div>
                <div className="text-2xl font-bold text-amber-400 font-mono">{performanceMetrics.cpuPercent}%</div>
                <div className="text-[10px] text-neutral-500">Apple Silicon Efficiency Core</div>
              </div>

              <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-1">
                <div className="text-[10px] text-neutral-400 font-semibold uppercase">DOM Nodes</div>
                <div className="text-2xl font-bold text-purple-400 font-mono">{performanceMetrics.domNodes}</div>
                <div className="text-[10px] text-neutral-500">Layout Tree Elements</div>
              </div>
            </div>

            <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-2">
              <div className="font-semibold text-neutral-300 text-xs">WebKit Navigation Timings</div>
              <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                <div className="p-2 bg-neutral-900 rounded-lg">DNS Resolution: {performanceMetrics.dnsTimeMs}ms</div>
                <div className="p-2 bg-neutral-900 rounded-lg">TTFB: {performanceMetrics.ttfbMs}ms</div>
                <div className="p-2 bg-neutral-900 rounded-lg">DOMContentLoaded: {performanceMetrics.domContentLoadedMs}ms</div>
              </div>
            </div>
          </div>
        )}

        {/* STORAGE TAB */}
        {inspectorActiveTab === "storage" && (
          <div className="w-full h-full p-4 overflow-y-auto font-sans space-y-4">
            <div className="space-y-2">
              <div className="font-semibold text-neutral-300 text-xs">Local Key-Value Storage</div>
              <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 space-y-1.5 font-mono text-xs">
                <div className="flex justify-between border-b border-neutral-800 pb-1 text-neutral-400 text-[10px]">
                  <span>Key</span>
                  <span>Value</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-blue-400">macweb_settings</span>
                  <span className="text-neutral-400 truncate max-w-xs">{`{"contentBlocking": true, "theme": "system"}`}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-blue-400">macweb_tab_groups</span>
                  <span className="text-neutral-400 truncate max-w-xs">{`[3 Tab Groups Configured]`}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
