"use client";

import React from "react";
import { useBrowser } from "@/context/BrowserContext";
import {
  Shield,
  X,
  Lock,
  EyeOff,
  CheckCircle,
  AlertTriangle,
  Flame,
  Fingerprint,
} from "lucide-react";

export function PrivacyDashboardModal() {
  const {
    isPrivacyDashboardOpen,
    setIsPrivacyDashboardOpen,
    blockedTrackersCount,
    settings,
    updateSettings,
    clearHistory,
  } = useBrowser();

  if (!isPrivacyDashboardOpen) return null;

  return (
    <div
      id="privacy-dashboard-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 select-none"
      onClick={() => setIsPrivacyDashboardOpen(false)}
    >
      <div
        id="privacy-dashboard-modal"
        className="w-full max-w-xl bg-neutral-900 border border-neutral-700 text-neutral-100 rounded-3xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">Privacy Report & Content Blocker</h2>
              <p className="text-xs text-neutral-400">Declarative WebKit Protection against tracking and profiling</p>
            </div>
          </div>
          <button
            onClick={() => setIsPrivacyDashboardOpen(false)}
            className="p-1.5 rounded-xl hover:bg-neutral-800 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stats Section */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800">
              <div className="text-2xl font-black text-emerald-400 font-mono">{blockedTrackersCount}</div>
              <div className="text-[10px] text-neutral-400 uppercase font-semibold mt-1">Trackers Blocked</div>
            </div>
            <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800">
              <div className="text-2xl font-black text-blue-400 font-mono">100%</div>
              <div className="text-[10px] text-neutral-400 uppercase font-semibold mt-1">Sandboxed State</div>
            </div>
            <div className="p-3 bg-neutral-950 rounded-2xl border border-neutral-800">
              <div className="text-2xl font-black text-purple-400 font-mono">0</div>
              <div className="text-[10px] text-neutral-400 uppercase font-semibold mt-1">Third-Party Cookies</div>
            </div>
          </div>

          {/* Privacy Toggles */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
              Active Protection Engine
            </h3>

            {[
              {
                id: "contentBlockingEnabled",
                label: "Declarative Content Blocking",
                desc: "Filters ads and scripts before network requests are dispatched.",
                checked: settings.contentBlockingEnabled,
              },
              {
                id: "blockTrackers",
                label: "Intelligent Tracker Prevention (ITP)",
                desc: "Prevents cross-site cookie tracking using on-device heuristics.",
                checked: settings.blockTrackers,
              },
              {
                id: "blockCryptominers",
                label: "Cryptomining & Fingerprinting Shield",
                desc: "Blocks canvas fingerprinting and background WebAssembly CPU mining.",
                checked: settings.blockCryptominers,
              },
              {
                id: "httpsOnlyMode",
                label: "Enforce HTTPS Upgrades",
                desc: "Automatically upgrades all insecure HTTP requests to encrypted TLS 1.3.",
                checked: settings.httpsOnlyMode,
              },
            ].map((item) => (
              <div
                key={item.id}
                className="p-3 bg-neutral-950/60 rounded-2xl border border-neutral-800/80 flex items-center justify-between"
              >
                <div className="pr-4">
                  <div className="text-xs font-semibold text-neutral-200">{item.label}</div>
                  <div className="text-[11px] text-neutral-400 mt-0.5">{item.desc}</div>
                </div>
                <button
                  onClick={() => updateSettings({ [item.id]: !item.checked })}
                  className={`w-10 h-6 rounded-full p-0.5 transition-colors shrink-0 ${
                    item.checked ? "bg-emerald-600" : "bg-neutral-800"
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      item.checked ? "translate-x-4" : "translate-x-0"
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>

          {/* Top Prevented Trackers List */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
              Top Blocked Trackers on This Session
            </h3>
            <div className="divide-y divide-neutral-800 bg-neutral-950 rounded-2xl border border-neutral-800 overflow-hidden text-xs">
              {[
                { domain: "doubleclick.net", count: 18, type: "Advertising Tracker" },
                { domain: "google-analytics.com", count: 14, type: "Telemetry Profiler" },
                { domain: "facebook.net", count: 9, type: "Social Graph Widget" },
                { domain: "criteo.com", count: 7, type: "Behavioral Retargeting" },
              ].map((trk) => (
                <div key={trk.domain} className="p-3 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-neutral-200 font-mono">{trk.domain}</div>
                    <div className="text-[10px] text-neutral-400">{trk.type}</div>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-lg">
                    {trk.count} blocked
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between text-xs">
          <button
            onClick={() => {
              clearHistory("all");
              setIsPrivacyDashboardOpen(false);
            }}
            className="text-rose-400 hover:underline font-semibold"
          >
            Clear All Browsing Data & Cache
          </button>
          <button
            onClick={() => setIsPrivacyDashboardOpen(false)}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
