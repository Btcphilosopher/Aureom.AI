"use client";

import React, { useState } from "react";
import { useBrowser } from "@/context/BrowserContext";
import {
  Folder,
  Bookmark as BookmarkIcon,
  Clock,
  BookOpen,
  Download,
  Puzzle,
  ShieldCheck,
  Plus,
  Trash2,
  ExternalLink,
  Search,
  CheckCircle2,
  ChevronRight,
  ChevronDown,
  Layers,
  X,
  Play,
  Pause,
  RotateCcw,
} from "lucide-react";

export function Sidebar() {
  const {
    isSidebarOpen,
    setIsSidebarOpen,
    sidebarTab,
    setSidebarTab,
    tabGroups,
    createTabGroup,
    deleteTabGroup,
    tabs,
    setActiveTabId,
    createNewTab,
    bookmarks,
    bookmarkFolders,
    removeBookmark,
    createBookmarkFolder,
    history,
    clearHistory,
    readingList,
    removeFromReadingList,
    toggleReadingListRead,
    downloads,
    cancelDownload,
    pauseDownload,
    resumeDownload,
    extensions,
    toggleExtension,
    sitePermissions,
    updateSitePermission,
    navigate,
  } = useBrowser();

  const [historySearch, setHistorySearch] = useState("");
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupColor, setNewGroupColor] = useState("#007aff");
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);

  if (!isSidebarOpen) return null;

  const sidebarTabs = [
    { id: "groups", label: "Tab Groups", icon: Layers },
    { id: "bookmarks", label: "Bookmarks", icon: BookmarkIcon },
    { id: "history", label: "History", icon: Clock },
    { id: "reading", label: "Reading List", icon: BookOpen },
    { id: "downloads", label: "Downloads", icon: Download },
    { id: "extensions", label: "Extensions", icon: Puzzle },
    { id: "permissions", label: "Permissions", icon: ShieldCheck },
  ] as const;

  const filteredHistory = history.filter(
    (h) =>
      h.title.toLowerCase().includes(historySearch.toLowerCase()) ||
      h.url.toLowerCase().includes(historySearch.toLowerCase())
  );

  return (
    <div
      id="browser-sidebar"
      className="w-72 h-full bg-neutral-100/95 dark:bg-neutral-900/95 backdrop-blur-xl border-r border-neutral-300/80 dark:border-neutral-800 flex flex-col select-none shrink-0 z-20"
    >
      {/* Sidebar Header with Segmented Navigation Icons */}
      <div className="p-2 border-b border-neutral-200 dark:border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-1">
          {sidebarTabs.map((t) => {
            const Icon = t.icon;
            const isActive = sidebarTab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setSidebarTab(t.id)}
                title={t.label}
                className={`p-1.5 rounded-lg text-xs flex items-center justify-center transition-colors ${
                  isActive
                    ? "bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-sm border border-neutral-200 dark:border-neutral-700 font-semibold"
                    : "text-neutral-500 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-800"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
              </button>
            );
          })}
        </div>

        <button
          onClick={() => setIsSidebarOpen(false)}
          className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-800"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Sidebar Body */}
      <div className="flex-1 overflow-y-auto p-3 text-xs">
        {/* TAB GROUPS TAB */}
        {sidebarTab === "groups" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider text-[10px]">
                Tab Groups
              </span>
              <button
                onClick={() => setIsCreatingGroup(!isCreatingGroup)}
                className="text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-medium"
              >
                <Plus className="w-3 h-3" /> New Group
              </button>
            </div>

            {isCreatingGroup && (
              <div className="p-2.5 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 space-y-2">
                <input
                  type="text"
                  placeholder="Group Name (e.g. Work, Research)"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  className="w-full px-2 py-1 bg-neutral-100 dark:bg-neutral-900 rounded-lg border border-neutral-300 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 focus:outline-none"
                />
                <div className="flex items-center gap-2">
                  {["#007aff", "#ff9500", "#34c759", "#af52de", "#ff2d55"].map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => setNewGroupColor(col)}
                      className={`w-4 h-4 rounded-full transition-transform ${
                        newGroupColor === col ? "scale-125 ring-2 ring-blue-500" : ""
                      }`}
                      style={{ backgroundColor: col }}
                    />
                  ))}
                  <button
                    onClick={() => {
                      if (newGroupName.trim()) {
                        createTabGroup(newGroupName.trim(), newGroupColor);
                        setNewGroupName("");
                        setIsCreatingGroup(false);
                      }
                    }}
                    className="ml-auto px-2 py-0.5 bg-blue-600 text-white rounded font-medium text-[11px]"
                  >
                    Add
                  </button>
                </div>
              </div>
            )}

            {tabGroups.map((group) => {
              const groupTabs = tabs.filter((t) => t.groupId === group.id);
              return (
                <div
                  key={group.id}
                  className="bg-white dark:bg-neutral-800/80 rounded-xl border border-neutral-200 dark:border-neutral-700/80 p-2.5 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: group.color }} />
                      <span className="font-semibold text-neutral-800 dark:text-neutral-200">{group.name}</span>
                      <span className="text-[10px] text-neutral-400">({groupTabs.length})</span>
                    </div>
                    <button
                      onClick={() => deleteTabGroup(group.id)}
                      className="text-neutral-400 hover:text-rose-500 p-0.5"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="space-y-1 pl-3">
                    {groupTabs.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => setActiveTabId(t.id)}
                        className="w-full text-left py-1 px-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-700 flex items-center gap-1.5 truncate text-neutral-700 dark:text-neutral-300"
                      >
                        <span className="text-[11px]">{t.favicon || "🌐"}</span>
                        <span className="truncate">{t.title}</span>
                      </button>
                    ))}
                    <button
                      onClick={() => createNewTab("macweb://newtab", group.id)}
                      className="w-full text-left py-1 px-1.5 rounded text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 text-[11px]"
                    >
                      <Plus className="w-2.5 h-2.5" /> Add Tab to Group
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* BOOKMARKS TAB */}
        {sidebarTab === "bookmarks" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider text-[10px]">
                Bookmarks & Folders
              </span>
              <button
                onClick={() => setIsCreatingFolder(!isCreatingFolder)}
                className="text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-medium"
              >
                <Plus className="w-3 h-3" /> New Folder
              </button>
            </div>

            {isCreatingFolder && (
              <div className="p-2 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 flex gap-2">
                <input
                  type="text"
                  placeholder="Folder Name"
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  className="flex-1 px-2 py-1 bg-neutral-100 dark:bg-neutral-900 rounded-lg text-neutral-800 dark:text-neutral-200 focus:outline-none"
                />
                <button
                  onClick={() => {
                    if (newFolderName.trim()) {
                      createBookmarkFolder(newFolderName.trim());
                      setNewFolderName("");
                      setIsCreatingFolder(false);
                    }
                  }}
                  className="px-2.5 py-1 bg-blue-600 text-white rounded font-medium text-[11px]"
                >
                  Create
                </button>
              </div>
            )}

            {/* Folders & Bookmarks List */}
            {bookmarkFolders.map((folder) => {
              const folderBookmarks = bookmarks.filter((b) => b.folderId === folder.id);
              return (
                <div key={folder.id} className="space-y-1">
                  <div className="flex items-center gap-1.5 font-semibold text-neutral-600 dark:text-neutral-400 py-1">
                    <Folder className="w-3.5 h-3.5 text-blue-500 fill-blue-500/20" />
                    <span>{folder.name}</span>
                  </div>
                  <div className="pl-4 space-y-1 border-l border-neutral-200 dark:border-neutral-800 ml-1.5">
                    {folderBookmarks.map((bm) => (
                      <div
                        key={bm.id}
                        className="group flex items-center justify-between py-1 px-1.5 rounded-lg hover:bg-neutral-200/70 dark:hover:bg-neutral-800"
                      >
                        <button
                          onClick={() => navigate(bm.url)}
                          className="flex items-center gap-1.5 truncate text-left text-neutral-800 dark:text-neutral-200 flex-1"
                        >
                          <span>{bm.favicon || "⭐"}</span>
                          <span className="truncate font-medium">{bm.title}</span>
                        </button>
                        <button
                          onClick={() => removeBookmark(bm.id)}
                          className="opacity-0 group-hover:opacity-100 text-neutral-400 hover:text-rose-500 p-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* HISTORY TAB */}
        {sidebarTab === "history" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider text-[10px]">
                Browsing History
              </span>
              <button
                onClick={() => clearHistory("today")}
                className="text-rose-500 hover:underline text-[11px] font-medium"
              >
                Clear Today
              </button>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search history..."
                value={historySearch}
                onChange={(e) => setHistorySearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 text-neutral-800 dark:text-neutral-200 focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              {filteredHistory.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigate(item.url)}
                  className="w-full text-left p-2 rounded-xl bg-white dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700/60 hover:border-blue-500/50 transition-colors space-y-0.5"
                >
                  <div className="flex items-center gap-1.5 truncate font-medium text-neutral-900 dark:text-neutral-100">
                    <span>{item.favicon || "🌐"}</span>
                    <span className="truncate">{item.title}</span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-neutral-400">
                    <span className="truncate">{item.domain}</span>
                    <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* READING LIST TAB */}
        {sidebarTab === "reading" && (
          <div className="space-y-3">
            <span className="font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider text-[10px]">
              Reading List ({readingList.filter((r) => !r.isRead).length} Unread)
            </span>

            <div className="space-y-2">
              {readingList.map((item) => (
                <div
                  key={item.id}
                  className={`p-2.5 rounded-xl border transition-all ${
                    item.isRead
                      ? "bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 opacity-60"
                      : "bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 shadow-sm"
                  }`}
                >
                  <div className="flex items-start justify-between gap-1">
                    <button
                      onClick={() => navigate(item.url)}
                      className="font-semibold text-neutral-900 dark:text-neutral-100 text-left hover:text-blue-500"
                    >
                      {item.title}
                    </button>
                    <button
                      onClick={() => removeFromReadingList(item.id)}
                      className="text-neutral-400 hover:text-rose-500 p-0.5 shrink-0"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                  <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 line-clamp-2">
                    {item.previewText}
                  </p>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-neutral-100 dark:border-neutral-700/60 text-[10px]">
                    <span className="text-neutral-400 font-mono">{item.readingTimeMinutes} min read</span>
                    <button
                      onClick={() => toggleReadingListRead(item.id)}
                      className="text-blue-600 dark:text-blue-400 font-medium hover:underline flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      {item.isRead ? "Mark Unread" : "Mark Read"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* DOWNLOADS TAB */}
        {sidebarTab === "downloads" && (
          <div className="space-y-3">
            <span className="font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider text-[10px]">
              Downloads (~/Downloads)
            </span>

            <div className="space-y-2">
              {downloads.map((dl) => (
                <div
                  key={dl.id}
                  className="p-2.5 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-neutral-900 dark:text-neutral-100 truncate">{dl.filename}</span>
                    <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-neutral-100 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-300">
                      {dl.status}
                    </span>
                  </div>

                  {dl.status === "downloading" && (
                    <div className="space-y-1">
                      <div className="h-1.5 w-full bg-neutral-200 dark:bg-neutral-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 transition-all"
                          style={{ width: `${(dl.receivedBytes / dl.totalBytes) * 100}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-[10px] text-neutral-400">
                        <span>{(dl.receivedBytes / 1048576).toFixed(1)} MB / {(dl.totalBytes / 1048576).toFixed(1)} MB</span>
                        <span>{(dl.speedBytesPerSec / 1048576).toFixed(1)} MB/s</span>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] text-neutral-400">{dl.destinationPath}</span>
                    <div className="flex items-center gap-1">
                      {dl.status === "downloading" ? (
                        <button onClick={() => pauseDownload(dl.id)} className="p-1 hover:text-blue-500">
                          <Pause className="w-3 h-3" />
                        </button>
                      ) : dl.status === "paused" ? (
                        <button onClick={() => resumeDownload(dl.id)} className="p-1 hover:text-blue-500">
                          <Play className="w-3 h-3" />
                        </button>
                      ) : null}
                      <button onClick={() => cancelDownload(dl.id)} className="p-1 hover:text-rose-500">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* EXTENSIONS TAB */}
        {sidebarTab === "extensions" && (
          <div className="space-y-3">
            <span className="font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider text-[10px]">
              Installed WebExtensions
            </span>

            <div className="space-y-2">
              {extensions.map((ext) => (
                <div
                  key={ext.id}
                  className="p-2.5 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-base">{ext.icon}</span>
                      <div>
                        <div className="font-semibold text-neutral-900 dark:text-neutral-100">{ext.name}</div>
                        <div className="text-[10px] text-neutral-400">v{ext.version} • {ext.author}</div>
                      </div>
                    </div>
                    <button
                      onClick={() => toggleExtension(ext.id)}
                      className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                        ext.enabled ? "bg-blue-600" : "bg-neutral-300 dark:bg-neutral-700"
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full bg-white transition-transform ${
                          ext.enabled ? "translate-x-4" : "translate-x-0"
                        }`}
                      />
                    </button>
                  </div>
                  <p className="text-[11px] text-neutral-500 dark:text-neutral-400">{ext.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SITE PERMISSIONS TAB */}
        {sidebarTab === "permissions" && (
          <div className="space-y-3">
            <span className="font-semibold text-neutral-700 dark:text-neutral-300 uppercase tracking-wider text-[10px]">
              Website Permissions
            </span>

            <div className="space-y-2">
              {Object.entries(sitePermissions).map(([domain, perm]) => (
                <div
                  key={domain}
                  className="p-2.5 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 space-y-2"
                >
                  <div className="font-semibold text-neutral-900 dark:text-neutral-100">{domain}</div>
                  <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                    <div className="flex justify-between bg-neutral-50 dark:bg-neutral-900 p-1.5 rounded-lg">
                      <span className="text-neutral-500">Camera</span>
                      <span className="font-medium capitalize">{perm.camera}</span>
                    </div>
                    <div className="flex justify-between bg-neutral-50 dark:bg-neutral-900 p-1.5 rounded-lg">
                      <span className="text-neutral-500">Location</span>
                      <span className="font-medium capitalize">{perm.location}</span>
                    </div>
                    <div className="flex justify-between bg-neutral-50 dark:bg-neutral-900 p-1.5 rounded-lg">
                      <span className="text-neutral-500">Notifications</span>
                      <span className="font-medium capitalize">{perm.notifications}</span>
                    </div>
                    <div className="flex justify-between bg-neutral-50 dark:bg-neutral-900 p-1.5 rounded-lg">
                      <span className="text-neutral-500">Block Ads</span>
                      <span className="font-medium">{perm.contentBlocking ? "Yes" : "No"}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
