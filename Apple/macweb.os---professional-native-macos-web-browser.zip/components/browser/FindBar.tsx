"use client";

import React, { useState, useEffect, useRef } from "react";
import { useBrowser } from "@/context/BrowserContext";
import { ChevronUp, ChevronDown, X } from "lucide-react";

export function FindBar() {
  const { isFindBarOpen, setIsFindBarOpen, findQuery, setFindQuery } = useBrowser();
  const [matchCount, setMatchCount] = useState({ current: 1, total: 4 });
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isFindBarOpen) {
      inputRef.current?.focus();
      inputRef.current?.select();
    }
  }, [isFindBarOpen]);

  if (!isFindBarOpen) return null;

  return (
    <div
      id="browser-find-bar"
      className="absolute top-22 right-6 z-40 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-xl border border-neutral-300 dark:border-neutral-700 rounded-2xl shadow-2xl p-2 flex items-center gap-2 text-xs select-none"
    >
      <input
        ref={inputRef}
        type="text"
        placeholder="Find in page..."
        value={findQuery}
        onChange={(e) => setFindQuery(e.target.value)}
        className="w-44 px-2.5 py-1 bg-neutral-100 dark:bg-neutral-900 rounded-lg text-neutral-900 dark:text-neutral-100 border border-neutral-300 dark:border-neutral-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
      />

      <span className="text-[11px] font-mono text-neutral-500 dark:text-neutral-400">
        {findQuery ? `${matchCount.current} of ${matchCount.total}` : "0 matches"}
      </span>

      <div className="flex items-center gap-0.5">
        <button
          onClick={() => setMatchCount((prev) => ({ ...prev, current: Math.max(1, prev.current - 1) }))}
          className="p-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded text-neutral-600 dark:text-neutral-300"
          title="Previous Match (⇧Return)"
        >
          <ChevronUp className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => setMatchCount((prev) => ({ ...prev, current: Math.min(prev.total, prev.current + 1) }))}
          className="p-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded text-neutral-600 dark:text-neutral-300"
          title="Next Match (Return)"
        >
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
      </div>

      <button
        onClick={() => {
          setIsFindBarOpen(false);
          setFindQuery("");
        }}
        className="p-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded text-neutral-400 hover:text-neutral-700 dark:hover:text-white"
        title="Close (Esc)"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
