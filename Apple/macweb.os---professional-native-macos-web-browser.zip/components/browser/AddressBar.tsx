"use client";

import React, { useState, useEffect, useRef } from "react";
import { useBrowser } from "@/context/BrowserContext";
import { SEARCH_PROVIDERS, getDomainFromUrl, CURATED_PAGES } from "@/lib/curatedWebData";
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  X,
  Lock,
  Unlock,
  Search,
  BookOpen,
  Sparkles,
  Shield,
  Download,
  Puzzle,
  Sidebar as SidebarIcon,
  Code,
  Bookmark as BookmarkIcon,
  Globe,
  Clock,
  ExternalLink,
  ChevronDown,
} from "lucide-react";

export function AddressBar() {
  const {
    activeTab,
    canGoBack,
    canGoForward,
    goBack,
    goForward,
    reload,
    stop,
    navigate,
    toggleReaderMode,
    isSidebarOpen,
    setIsSidebarOpen,
    isAIDrawerOpen,
    setIsAIDrawerOpen,
    isWebInspectorOpen,
    setIsWebInspectorOpen,
    isPrivacyDashboardOpen,
    setIsPrivacyDashboardOpen,
    isCertificateModalOpen,
    setIsCertificateModalOpen,
    isDownloadsPopoverOpen,
    setIsDownloadsPopoverOpen,
    isExtensionsPopoverOpen,
    setIsExtensionsPopoverOpen,
    bookmarks,
    history,
    tabs,
    setActiveTabId,
    addBookmark,
    downloads,
    extensions,
    settings,
    updateSettings,
    blockedTrackersCount,
  } = useBrowser();

  const [inputVal, setInputVal] = useState("");
  const [prevTabId, setPrevTabId] = useState<string | null>(null);
  const [prevTabUrl, setPrevTabUrl] = useState<string | null>(null);
  const [isFocused, setIsFocused] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showSearchEngineMenu, setShowSearchEngineMenu] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Sync input value when activeTab changes without triggering cascading effect setState
  if (activeTab && (activeTab.id !== prevTabId || activeTab.url !== prevTabUrl)) {
    setPrevTabId(activeTab.id);
    setPrevTabUrl(activeTab.url);
    if (!isFocused) {
      setInputVal(activeTab.url === "macweb://newtab" ? "" : activeTab.url);
    }
  }

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
        setShowSearchEngineMenu(false);
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);
    return () => document.removeEventListener("mousedown", handleOutsideClick);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    navigate(inputVal);
    setShowSuggestions(false);
    inputRef.current?.blur();
  };

  const handleSuggestionClick = (urlOrQuery: string) => {
    navigate(urlOrQuery);
    setShowSuggestions(false);
    inputRef.current?.blur();
  };

  const currentEngine = SEARCH_PROVIDERS.find((p) => p.id === settings.defaultSearchEngineId) || SEARCH_PROVIDERS[0];
  const isSecure = activeTab ? !activeTab.url.startsWith("http://") : true;
  const isDownloading = downloads.some((d) => d.status === "downloading");
  const activeExtensionsCount = extensions.filter((e) => e.enabled).length;

  // Filter ranked suggestions based on input
  const query = inputVal.toLowerCase().trim();
  const historyMatches = query
    ? history.filter((h) => h.title.toLowerCase().includes(query) || h.url.toLowerCase().includes(query)).slice(0, 3)
    : history.slice(0, 3);
  const bookmarkMatches = query
    ? bookmarks.filter((b) => b.title.toLowerCase().includes(query) || b.url.toLowerCase().includes(query)).slice(0, 3)
    : bookmarks.slice(0, 3);
  const openTabMatches = query
    ? tabs.filter((t) => t.title.toLowerCase().includes(query) || t.url.toLowerCase().includes(query)).slice(0, 2)
    : [];

  return (
    <div
      id="browser-toolbar"
      ref={containerRef}
      className="h-12 w-full bg-neutral-100 dark:bg-neutral-900 border-b border-neutral-300/80 dark:border-neutral-800 px-3 flex items-center justify-between gap-2 select-none relative z-40"
    >
      {/* Left Navigation & Sidebar Controls */}
      <div className="flex items-center gap-1">
        {/* Sidebar Toggle */}
        <button
          id="btn-sidebar-toggle"
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          title="Toggle Sidebar (⌘⌃S)"
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
            isSidebarOpen
              ? "bg-neutral-300 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100"
              : "text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-800"
          }`}
        >
          <SidebarIcon className="w-4 h-4" />
        </button>

        {/* Back Button */}
        <button
          id="btn-nav-back"
          onClick={goBack}
          disabled={!canGoBack}
          title="Back (⌘[)"
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
            canGoBack
              ? "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-800"
              : "text-neutral-400 dark:text-neutral-600 opacity-40 cursor-not-allowed"
          }`}
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        {/* Forward Button */}
        <button
          id="btn-nav-forward"
          onClick={goForward}
          disabled={!canGoForward}
          title="Forward (⌘])"
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
            canGoForward
              ? "text-neutral-700 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-800"
              : "text-neutral-400 dark:text-neutral-600 opacity-40 cursor-not-allowed"
          }`}
        >
          <ArrowRight className="w-4 h-4" />
        </button>

        {/* Reload / Stop Button */}
        {activeTab?.loadingState === "loading" ? (
          <button
            id="btn-nav-stop"
            onClick={stop}
            title="Stop Loading (⌘.)"
            className="w-8 h-8 rounded-lg flex items-center justify-center text-rose-500 hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        ) : (
          <button
            id="btn-nav-reload"
            onClick={reload}
            title="Reload Page (⌘R)"
            className="w-8 h-8 rounded-lg flex items-center justify-center text-neutral-700 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Center Omnibox / Address Bar */}
      <div className="flex-1 max-w-2xl relative mx-2">
        <form onSubmit={handleSubmit} className="relative w-full">
          <div
            className={`w-full h-8.5 rounded-xl flex items-center px-3 gap-2 transition-all border ${
              isFocused
                ? "bg-white dark:bg-neutral-800 border-blue-500 shadow-sm ring-2 ring-blue-500/20"
                : "bg-white/80 dark:bg-neutral-800/80 border-neutral-300 dark:border-neutral-700 hover:border-neutral-400 dark:hover:border-neutral-600"
            }`}
          >
            {/* Security Indicator / Lock Icon */}
            <button
              type="button"
              id="btn-cert-modal"
              onClick={() => setIsCertificateModalOpen(!isCertificateModalOpen)}
              title={isSecure ? "Connection is Secure (TLS 1.3)" : "Not Secure"}
              className="shrink-0 flex items-center gap-1 text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white"
            >
              {isSecure ? (
                <Lock className="w-3.5 h-3.5 text-neutral-500 dark:text-neutral-400" />
              ) : (
                <Unlock className="w-3.5 h-3.5 text-amber-500" />
              )}
            </button>

            {/* URL / Search Input */}
            <input
              id="omnibox-input"
              ref={inputRef}
              type="text"
              value={inputVal}
              onChange={(e) => {
                setInputVal(e.target.value);
                setShowSuggestions(true);
              }}
              onFocus={() => {
                setIsFocused(true);
                setShowSuggestions(true);
              }}
              onBlur={() => {
                setIsFocused(false);
              }}
              placeholder="Search or enter website address"
              className="w-full bg-transparent text-xs text-neutral-900 dark:text-neutral-100 placeholder:text-neutral-400 focus:outline-none font-medium"
            />

            {/* Clear Input Button */}
            {inputVal && isFocused && (
              <button
                type="button"
                onClick={() => setInputVal("")}
                className="p-1 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
              >
                <X className="w-3 h-3" />
              </button>
            )}

            {/* Search Engine Switcher */}
            <div className="relative shrink-0">
              <button
                type="button"
                onClick={() => setShowSearchEngineMenu(!showSearchEngineMenu)}
                title={`Search with ${currentEngine.name}`}
                className="flex items-center gap-1 text-[11px] font-medium text-neutral-500 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white px-1.5 py-0.5 rounded hover:bg-neutral-100 dark:hover:bg-neutral-700"
              >
                <span>{currentEngine.icon}</span>
                <ChevronDown className="w-2.5 h-2.5" />
              </button>

              {showSearchEngineMenu && (
                <div className="absolute right-0 top-7 w-44 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-xl shadow-xl p-1 text-xs z-50">
                  <div className="px-2 py-1 text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">
                    Default Search Engine
                  </div>
                  {SEARCH_PROVIDERS.map((provider) => (
                    <button
                      key={provider.id}
                      type="button"
                      onClick={() => {
                        updateSettings({ defaultSearchEngineId: provider.id });
                        setShowSearchEngineMenu(false);
                      }}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between text-xs ${
                        provider.id === settings.defaultSearchEngineId
                          ? "bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 font-semibold"
                          : "hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{provider.icon}</span>
                        <span>{provider.name}</span>
                      </span>
                      {provider.id === settings.defaultSearchEngineId && <span>✓</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Reader Mode Button inside URL bar */}
            {activeTab?.url.startsWith("https://") && (
              <button
                type="button"
                onClick={toggleReaderMode}
                title="Toggle Reader Mode (⌘⇧R)"
                className={`p-1 rounded transition-colors ${
                  activeTab.readerModeActive
                    ? "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/40"
                    : "text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Loading Progress Bar below address bar */}
          {activeTab?.loadingState === "loading" && (
            <div className="absolute bottom-0 left-2 right-2 h-0.5 bg-neutral-200 dark:bg-neutral-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${activeTab.progress}%` }}
              />
            </div>
          )}
        </form>

        {/* Omnibox Ranked Suggestions Dropdown */}
        {showSuggestions && (
          <div className="absolute left-0 right-0 top-10 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-2xl border border-neutral-200 dark:border-neutral-700 rounded-2xl shadow-2xl overflow-hidden p-2 text-xs z-50 max-h-96 overflow-y-auto divide-y divide-neutral-100 dark:divide-neutral-700/60">
            {/* Search Query suggestion */}
            {inputVal.trim() && (
              <div className="pb-2">
                <button
                  onMouseDown={() => handleSuggestionClick(inputVal)}
                  className="w-full text-left px-3 py-2 rounded-xl flex items-center justify-between hover:bg-blue-50 dark:hover:bg-blue-900/30 text-blue-600 dark:text-blue-400 group"
                >
                  <div className="flex items-center gap-2.5">
                    <Search className="w-3.5 h-3.5 text-blue-500" />
                    <span className="font-medium">{currentEngine.name} Search: &quot;{inputVal}&quot;</span>
                  </div>
                  <span className="text-[10px] text-neutral-400 font-mono">Return ↵</span>
                </button>
              </div>
            )}

            {/* Open Tabs matches */}
            {openTabMatches.length > 0 && (
              <div className="py-2">
                <div className="px-3 py-1 text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">
                  Switch to Open Tab
                </div>
                {openTabMatches.map((t) => (
                  <button
                    key={t.id}
                    onMouseDown={() => {
                      setActiveTabId(t.id);
                      setShowSuggestions(false);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-700"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span>{t.favicon || "🌐"}</span>
                      <span className="truncate text-neutral-800 dark:text-neutral-200">{t.title}</span>
                    </div>
                    <span className="text-[10px] bg-blue-500/10 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded font-mono">
                      TAB
                    </span>
                  </button>
                ))}
              </div>
            )}

            {/* Bookmarks matches */}
            {bookmarkMatches.length > 0 && (
              <div className="py-2">
                <div className="px-3 py-1 text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">
                  Bookmarks
                </div>
                {bookmarkMatches.map((b) => (
                  <button
                    key={b.id}
                    onMouseDown={() => handleSuggestionClick(b.url)}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-700"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <BookmarkIcon className="w-3 h-3 text-amber-500 shrink-0" />
                      <span className="truncate font-medium text-neutral-800 dark:text-neutral-200">{b.title}</span>
                    </div>
                    <span className="text-[10px] text-neutral-400 truncate max-w-[140px] font-mono">{b.url}</span>
                  </button>
                ))}
              </div>
            )}

            {/* History matches */}
            {historyMatches.length > 0 && (
              <div className="py-2">
                <div className="px-3 py-1 text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">
                  History
                </div>
                {historyMatches.map((h) => (
                  <button
                    key={h.id}
                    onMouseDown={() => handleSuggestionClick(h.url)}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-neutral-100 dark:hover:bg-neutral-700"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Clock className="w-3 h-3 text-neutral-400 shrink-0" />
                      <span className="truncate text-neutral-700 dark:text-neutral-300">{h.title}</span>
                    </div>
                    <span className="text-[10px] text-neutral-400 truncate max-w-[140px] font-mono">{h.domain}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Right Quick Action Toolbar Buttons */}
      <div className="flex items-center gap-1">
        {/* Bookmark Current Page */}
        <button
          id="btn-bookmark-action"
          onClick={() => {
            if (activeTab) addBookmark(activeTab.title, activeTab.url);
          }}
          title="Add Bookmark (⌘D)"
          className="w-8 h-8 rounded-lg flex items-center justify-center text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors"
        >
          <BookmarkIcon className="w-4 h-4" />
        </button>

        {/* AI Assistant Button (Gemini 3.8 Flash) */}
        <button
          id="btn-ai-copilot"
          onClick={() => setIsAIDrawerOpen(!isAIDrawerOpen)}
          title="AI Browser Assistant & Page Analysis (⌘J)"
          className={`h-8 px-2.5 rounded-lg flex items-center gap-1.5 text-xs font-semibold transition-all ${
            isAIDrawerOpen
              ? "bg-blue-600 text-white shadow-sm"
              : "bg-blue-500/10 text-blue-600 dark:text-blue-400 hover:bg-blue-500/20"
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">AI Copilot</span>
        </button>

        {/* Extensions Popover Trigger */}
        <button
          id="btn-extensions-trigger"
          onClick={() => setIsExtensionsPopoverOpen(!isExtensionsPopoverOpen)}
          title={`WebExtensions (${activeExtensionsCount} Active)`}
          className={`w-8 h-8 rounded-lg flex items-center justify-center relative transition-colors ${
            isExtensionsPopoverOpen
              ? "bg-neutral-300 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100"
              : "text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-800"
          }`}
        >
          <Puzzle className="w-4 h-4" />
          {activeExtensionsCount > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-blue-500" />
          )}
        </button>

        {/* Downloads Popover Trigger */}
        <button
          id="btn-downloads-trigger"
          onClick={() => setIsDownloadsPopoverOpen(!isDownloadsPopoverOpen)}
          title="Download Manager"
          className={`w-8 h-8 rounded-lg flex items-center justify-center relative transition-colors ${
            isDownloadsPopoverOpen
              ? "bg-neutral-300 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100"
              : "text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-800"
          }`}
        >
          <Download className="w-4 h-4" />
          {isDownloading && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          )}
        </button>

        {/* Privacy Shield Trigger */}
        <button
          id="btn-privacy-shield-trigger"
          onClick={() => setIsPrivacyDashboardOpen(!isPrivacyDashboardOpen)}
          title={`Privacy Shield: ${blockedTrackersCount} Trackers Blocked`}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-emerald-600 dark:text-emerald-400 hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors"
        >
          <Shield className="w-4 h-4" />
        </button>

        {/* Web Inspector Toggle */}
        <button
          id="btn-inspector-trigger"
          onClick={() => setIsWebInspectorOpen(!isWebInspectorOpen)}
          title="Web Inspector & Developer Tools (⌘⌥I)"
          className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors ${
            isWebInspectorOpen
              ? "bg-neutral-300 dark:bg-neutral-700 text-neutral-900 dark:text-neutral-100"
              : "text-neutral-600 dark:text-neutral-400 hover:bg-neutral-200 dark:hover:bg-neutral-800"
          }`}
        >
          <Code className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
