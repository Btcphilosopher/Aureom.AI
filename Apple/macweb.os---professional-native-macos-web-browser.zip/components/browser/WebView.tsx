"use client";

import React, { useState, useRef } from "react";
import { useBrowser } from "@/context/BrowserContext";
import { CURATED_PAGES, getDomainFromUrl } from "@/lib/curatedWebData";
import { NewTabPage } from "./NewTabPage";
import { ReaderModeView } from "./ReaderModeView";
import {
  ExternalLink,
  Shield,
  RotateCw,
  Sparkles,
  Bookmark,
  Code,
  ArrowLeft,
  ArrowRight,
  Copy,
  Search,
} from "lucide-react";

export function WebView() {
  const {
    activeTab,
    navigate,
    goBack,
    goForward,
    reload,
    canGoBack,
    canGoForward,
    addBookmark,
    setIsAIDrawerOpen,
    setIsWebInspectorOpen,
    setInspectorActiveTab,
    createNewTab,
  } = useBrowser();

  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    visible: boolean;
  }>({ x: 0, y: 0, visible: false });

  const webViewContainerRef = useRef<HTMLDivElement>(null);

  if (!activeTab) return null;

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    const rect = webViewContainerRef.current?.getBoundingClientRect();
    if (rect) {
      setContextMenu({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        visible: true,
      });
    }
  };

  const closeContextMenu = () => {
    if (contextMenu.visible) {
      setContextMenu((prev) => ({ ...prev, visible: false }));
    }
  };

  // If Reader Mode is active on this tab
  if (activeTab.readerModeActive) {
    return <ReaderModeView />;
  }

  // If Start Page / New Tab
  if (activeTab.url === "macweb://newtab") {
    return <NewTabPage />;
  }

  const curatedPage = CURATED_PAGES[activeTab.url];

  return (
    <div
      id="browser-webkit-viewport"
      ref={webViewContainerRef}
      onClick={closeContextMenu}
      onContextMenu={handleContextMenu}
      className="w-full h-full relative overflow-y-auto bg-white dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 select-text font-sans"
      style={{
        zoom: `${activeTab.zoomLevel}%`,
      }}
    >
      {curatedPage ? (
        // Curated Interactive Web Page
        <div className="w-full min-h-full pb-16">
          {/* Mock Website Header */}
          <div className="border-b border-neutral-200 dark:border-neutral-800 bg-neutral-50/80 dark:bg-neutral-950/80 backdrop-blur-md px-6 py-3 flex items-center justify-between text-xs sticky top-0 z-10">
            <div className="flex items-center gap-3">
              <span className="text-xl">{curatedPage.favicon}</span>
              <div>
                <div className="font-bold text-neutral-900 dark:text-neutral-100">{curatedPage.title}</div>
                <div className="text-[10px] text-neutral-500">{activeTab.url}</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsAIDrawerOpen(true)}
                className="px-2.5 py-1 bg-blue-600 text-white rounded-lg font-semibold flex items-center gap-1.5 shadow-sm text-xs"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ask AI</span>
              </button>
            </div>
          </div>

          {/* Website Body Content */}
          <div className="max-w-4xl mx-auto p-8 space-y-6">
            <div
              className="text-sm leading-relaxed text-neutral-700 dark:text-neutral-300"
              dangerouslySetInnerHTML={{ __html: curatedPage.contentHtml }}
            />

            {/* Quick Interactive Links inside Curated Page */}
            <div className="pt-6 border-t border-neutral-200 dark:border-neutral-800 space-y-3">
              <div className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                Explore Linked WebKit Standards & Resources
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  { title: "WebKit Standards Testbench", url: "https://html5test.webkit.macweb.os", icon: "🧪" },
                  { title: "Apple Developer Documentation", url: "https://apple.com", icon: "" },
                  { title: "GitHub WebKit Repositories", url: "https://github.com", icon: "🐙" },
                  { title: "MDN WebKit Specifications", url: "https://developer.mozilla.org", icon: "M" },
                ].map((link) => (
                  <button
                    key={link.url}
                    onClick={() => navigate(link.url)}
                    className="p-3 rounded-xl bg-neutral-100 dark:bg-neutral-800/80 hover:bg-neutral-200 dark:hover:bg-neutral-700/80 flex items-center gap-3 text-left transition-colors"
                  >
                    <span className="text-xl">{link.icon}</span>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate">{link.title}</div>
                      <div className="text-[10px] text-neutral-400 truncate">{link.url}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        // Search Engine / Custom URL Web View
        <div className="w-full min-h-full p-8 flex flex-col items-center justify-start space-y-6">
          <div className="w-full max-w-3xl space-y-6">
            <div className="p-4 bg-neutral-100 dark:bg-neutral-800/60 rounded-2xl border border-neutral-200 dark:border-neutral-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Search className="w-5 h-5 text-blue-500" />
                <div>
                  <div className="text-sm font-bold text-neutral-900 dark:text-white">Web Search Results</div>
                  <div className="text-xs text-neutral-500">{activeTab.url}</div>
                </div>
              </div>
              <button
                onClick={() => setIsAIDrawerOpen(true)}
                className="px-3 py-1.5 bg-blue-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Summarize Results</span>
              </button>
            </div>

            {/* Generated Search Results */}
            <div className="space-y-4">
              {[
                {
                  title: `${activeTab.title} - Official Documentation & Specification`,
                  url: activeTab.url,
                  snippet: "Explore native WebKit rendering engine features, AppKit process isolation, and 60 FPS Metal pipelines designed for macOS.",
                },
                {
                  title: `Understanding Modern Browser Architectures and WebKit Process Models`,
                  url: `https://webkit.org/blog/modern-architecture`,
                  snippet: "Comprehensive guide to sandboxing, WebContent isolation, network process architecture, and declarative content filtering.",
                },
                {
                  title: `Apple Developer: Building High-Performance macOS Applications with SwiftUI`,
                  url: `https://apple.com/developer/macos`,
                  snippet: "Native window groups, toolbar items, visual effect views, and system keybindings for Safari-class browser shells.",
                },
              ].map((res, i) => (
                <div
                  key={i}
                  className="p-4 bg-white dark:bg-neutral-800/40 rounded-2xl border border-neutral-200 dark:border-neutral-700/60 space-y-1.5 hover:border-blue-500/50 transition-colors"
                >
                  <div className="text-[11px] text-neutral-400 font-mono">{res.url}</div>
                  <button
                    onClick={() => navigate(res.url)}
                    className="text-base font-bold text-blue-600 dark:text-blue-400 hover:underline text-left block"
                  >
                    {res.title}
                  </button>
                  <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                    {res.snippet}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* macOS Right-Click Context Menu */}
      {contextMenu.visible && (
        <div
          className="absolute bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-xl shadow-2xl p-1 text-xs text-neutral-200 z-50 w-52 space-y-0.5"
          style={{ top: `${contextMenu.y}px`, left: `${contextMenu.x}px` }}
        >
          <button
            onClick={() => {
              goBack();
              closeContextMenu();
            }}
            disabled={!canGoBack}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-blue-600 hover:text-white flex items-center justify-between disabled:opacity-40"
          >
            <span className="flex items-center gap-2"><ArrowLeft className="w-3.5 h-3.5" /> Back</span>
            <span className="text-[10px] text-neutral-400">⌘[</span>
          </button>

          <button
            onClick={() => {
              goForward();
              closeContextMenu();
            }}
            disabled={!canGoForward}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-blue-600 hover:text-white flex items-center justify-between disabled:opacity-40"
          >
            <span className="flex items-center gap-2"><ArrowRight className="w-3.5 h-3.5" /> Forward</span>
            <span className="text-[10px] text-neutral-400">⌘]</span>
          </button>

          <button
            onClick={() => {
              reload();
              closeContextMenu();
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-blue-600 hover:text-white flex items-center justify-between"
          >
            <span className="flex items-center gap-2"><RotateCw className="w-3.5 h-3.5" /> Reload</span>
            <span className="text-[10px] text-neutral-400">⌘R</span>
          </button>

          <div className="h-px bg-white/10 my-1" />

          <button
            onClick={() => {
              createNewTab(activeTab.url);
              closeContextMenu();
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-blue-600 hover:text-white flex items-center gap-2"
          >
            <ExternalLink className="w-3.5 h-3.5" /> Open in New Tab
          </button>

          <button
            onClick={() => {
              addBookmark(activeTab.title, activeTab.url);
              closeContextMenu();
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-blue-600 hover:text-white flex items-center gap-2"
          >
            <Bookmark className="w-3.5 h-3.5" /> Add to Bookmarks
          </button>

          <button
            onClick={() => {
              setIsAIDrawerOpen(true);
              closeContextMenu();
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-blue-600 hover:text-white flex items-center gap-2 text-blue-400"
          >
            <Sparkles className="w-3.5 h-3.5" /> Ask AI About Page
          </button>

          <div className="h-px bg-white/10 my-1" />

          <button
            onClick={() => {
              setIsWebInspectorOpen(true);
              setInspectorActiveTab("elements");
              closeContextMenu();
            }}
            className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-blue-600 hover:text-white flex items-center justify-between"
          >
            <span className="flex items-center gap-2"><Code className="w-3.5 h-3.5" /> Inspect Element</span>
            <span className="text-[10px] text-neutral-400">⌘⌥I</span>
          </button>
        </div>
      )}
    </div>
  );
}
