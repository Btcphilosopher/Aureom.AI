"use client";

import React, { useState } from "react";
import { useBrowser } from "@/context/BrowserContext";
import {
  Search,
  Plus,
  Shield,
  BookOpen,
  Sparkles,
  ExternalLink,
  Code,
  Layers,
  Settings,
  Cpu,
} from "lucide-react";

export function NewTabPage() {
  const {
    navigate,
    bookmarks,
    history,
    readingList,
    setIsAIDrawerOpen,
    setIsPrivacyDashboardOpen,
    setIsNativeCodeModalOpen,
    blockedTrackersCount,
    settings,
    addBookmark,
  } = useBrowser();

  const [searchVal, setSearchVal] = useState("");

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchVal.trim()) return;
    navigate(searchVal.trim());
  };

  const favorites = bookmarks.filter((b) => b.folderId === "folder-favorites" || !b.folderId);
  const frequentlyVisited = history.slice(0, 6);

  return (
    <div
      id="browser-newtab-page"
      className="w-full h-full overflow-y-auto bg-gradient-to-br from-neutral-100 via-neutral-200/50 to-neutral-100 dark:from-neutral-950 dark:via-neutral-900 dark:to-neutral-950 text-neutral-800 dark:text-neutral-200 p-8 flex flex-col items-center justify-start select-none"
    >
      <div className="w-full max-w-4xl space-y-10 py-6">
        {/* Hero Apple Silicon Branding & Search */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 text-xs font-semibold tracking-wide border border-blue-500/20">
            <Cpu className="w-3.5 h-3.5" />
            <span>macOS Sequoia • WebKit Public Engine • Apple Silicon Optimized</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-neutral-900 dark:text-white font-sans">
            MACWEB<span className="text-blue-500">.OS</span>
          </h1>

          <p className="text-sm text-neutral-600 dark:text-neutral-400 max-w-md mx-auto">
            High-performance native browser architecture powered by Apple&apos;s documented WebKit APIs and declarative privacy shields.
          </p>

          {/* Centralized Search Bar */}
          <form onSubmit={handleSearchSubmit} className="max-w-xl mx-auto pt-2">
            <div className="relative flex items-center">
              <Search className="w-4 h-4 text-neutral-400 absolute left-4" />
              <input
                type="text"
                value={searchVal}
                onChange={(e) => setSearchVal(e.target.value)}
                placeholder="Search the web or enter URL..."
                className="w-full pl-11 pr-24 py-3 bg-white/90 dark:bg-neutral-800/90 backdrop-blur-xl border border-neutral-300 dark:border-neutral-700 rounded-2xl shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-sm font-medium text-neutral-900 dark:text-white"
              />
              <button
                type="submit"
                className="absolute right-2 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-xl transition-colors shadow-sm"
              >
                Search
              </button>
            </div>
          </form>
        </div>

        {/* Favorites Grid */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Favorites
            </h2>
            <button
              onClick={() => addBookmark("New Bookmark", "https://apple.com")}
              className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 font-medium"
            >
              <Plus className="w-3 h-3" /> Add Favorite
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
            {favorites.map((fav) => (
              <button
                key={fav.id}
                onClick={() => navigate(fav.url)}
                className="group p-3.5 bg-white/80 dark:bg-neutral-800/80 backdrop-blur-md rounded-2xl border border-neutral-200 dark:border-neutral-700/80 hover:border-blue-500/50 hover:shadow-md transition-all flex flex-col items-center text-center gap-2"
              >
                <div className="w-12 h-12 rounded-xl bg-neutral-100 dark:bg-neutral-700 flex items-center justify-center text-2xl shadow-inner group-hover:scale-110 transition-transform">
                  {fav.favicon || "⭐"}
                </div>
                <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 truncate w-full">
                  {fav.title}
                </span>
              </button>
            ))}

            <button
              onClick={() => navigate("https://html5test.webkit.macweb.os")}
              className="group p-3.5 bg-white/80 dark:bg-neutral-800/80 backdrop-blur-md rounded-2xl border border-neutral-200 dark:border-neutral-700/80 hover:border-blue-500/50 hover:shadow-md transition-all flex flex-col items-center text-center gap-2"
            >
              <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center text-2xl shadow-inner group-hover:scale-110 transition-transform">
                🧪
              </div>
              <span className="text-xs font-semibold text-blue-600 dark:text-blue-400 truncate w-full">
                HTML5 Test Lab
              </span>
            </button>
          </div>
        </div>

        {/* Frequently Visited & Privacy Banner */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Frequently Visited */}
          <div className="md:col-span-2 p-4 bg-white/80 dark:bg-neutral-800/80 backdrop-blur-md rounded-2xl border border-neutral-200 dark:border-neutral-700/80 space-y-3 shadow-sm">
            <h2 className="text-xs font-bold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              Frequently Visited
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {frequentlyVisited.map((item) => (
                <button
                  key={item.id}
                  onClick={() => navigate(item.url)}
                  className="p-2.5 rounded-xl hover:bg-neutral-100 dark:hover:bg-neutral-700/60 flex items-center gap-2.5 text-left transition-colors"
                >
                  <span className="text-base">{item.favicon || "🌐"}</span>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-neutral-900 dark:text-neutral-100 truncate">{item.title}</div>
                    <div className="text-[10px] text-neutral-400 truncate">{item.domain} • {item.visitCount} visits</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Privacy Report Summary Card */}
          <div className="p-4 bg-gradient-to-br from-emerald-500/10 via-teal-500/5 to-transparent border border-emerald-500/20 rounded-2xl flex flex-col justify-between space-y-3">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400">
                <Shield className="w-5 h-5" />
                <span className="font-bold text-sm">Privacy Report</span>
              </div>
              <div className="text-3xl font-extrabold text-neutral-900 dark:text-white font-mono">
                {blockedTrackersCount}
              </div>
              <p className="text-xs text-neutral-600 dark:text-neutral-400">
                Trackers prevented from profiling your identity across web domains.
              </p>
            </div>

            <button
              onClick={() => setIsPrivacyDashboardOpen(true)}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold transition-colors shadow-sm text-center"
            >
              View Full Privacy Audit
            </button>
          </div>
        </div>

        {/* Quick Launchpad Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            onClick={() => setIsAIDrawerOpen(true)}
            className="px-4 py-2 bg-white/80 dark:bg-neutral-800/80 backdrop-blur-md rounded-xl border border-neutral-200 dark:border-neutral-700 text-xs font-semibold text-neutral-700 dark:text-neutral-200 hover:border-blue-500 flex items-center gap-2 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-500" />
            <span>AI Browser Assistant</span>
          </button>

          <button
            onClick={() => setIsNativeCodeModalOpen(true)}
            className="px-4 py-2 bg-white/80 dark:bg-neutral-800/80 backdrop-blur-md rounded-xl border border-neutral-200 dark:border-neutral-700 text-xs font-semibold text-neutral-700 dark:text-neutral-200 hover:border-blue-500 flex items-center gap-2 transition-all"
          >
            <Code className="w-3.5 h-3.5 text-emerald-500" />
            <span>Native Swift Codebase (Xcode)</span>
          </button>
        </div>
      </div>
    </div>
  );
}
