"use client";

import React from "react";
import { useBrowser } from "@/context/BrowserContext";
import { ShieldCheck, Lock, X, CheckCircle2, Key, Award } from "lucide-react";

export function CertificateModal() {
  const { isCertificateModalOpen, setIsCertificateModalOpen, certificateInfo } = useBrowser();

  if (!isCertificateModalOpen) return null;

  return (
    <div
      id="certificate-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 select-none"
      onClick={() => setIsCertificateModalOpen(false)}
    >
      <div
        id="certificate-modal"
        className="w-full max-w-md bg-neutral-900 border border-neutral-700 text-neutral-100 rounded-3xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold">Security Certificate</h3>
              <p className="text-[11px] text-neutral-400 font-mono">{certificateInfo.domain}</p>
            </div>
          </div>
          <button
            onClick={() => setIsCertificateModalOpen(false)}
            className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Certificate Details */}
        <div className="p-5 space-y-4 text-xs">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold bg-emerald-950/40 p-2.5 rounded-xl border border-emerald-800/40">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>This website identity is verified by Apple WebKit Trust Store.</span>
          </div>

          <div className="space-y-2 bg-neutral-950 p-3.5 rounded-2xl border border-neutral-800 font-mono text-[11px]">
            <div>
              <div className="text-[10px] text-neutral-500 uppercase font-sans font-bold">Issued To</div>
              <div className="text-neutral-200 mt-0.5">{certificateInfo.subject}</div>
            </div>

            <div className="pt-2 border-t border-neutral-800">
              <div className="text-[10px] text-neutral-500 uppercase font-sans font-bold">Issued By</div>
              <div className="text-neutral-200 mt-0.5">{certificateInfo.issuer}</div>
            </div>

            <div className="pt-2 border-t border-neutral-800">
              <div className="text-[10px] text-neutral-500 uppercase font-sans font-bold">Validity Period</div>
              <div className="text-neutral-300 mt-0.5">Valid until: {certificateInfo.validTo}</div>
            </div>

            <div className="pt-2 border-t border-neutral-800">
              <div className="text-[10px] text-neutral-500 uppercase font-sans font-bold">Technical Specifications</div>
              <div className="text-neutral-300 mt-0.5 space-y-1">
                <div>Protocol: <span className="text-blue-400">{certificateInfo.protocol}</span></div>
                <div>Cipher: <span className="text-blue-400">{certificateInfo.cipher}</span></div>
                <div>Key Exchange: <span className="text-blue-400">{certificateInfo.keyExchange}</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-neutral-950 border-t border-neutral-800 flex justify-end">
          <button
            onClick={() => setIsCertificateModalOpen(false)}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
