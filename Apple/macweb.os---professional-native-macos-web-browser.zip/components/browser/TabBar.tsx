"use client";

import React, { useState } from "react";
import { useBrowser } from "@/context/BrowserContext";
import { BrowserTab } from "@/types/browser";
import {
  Plus,
  X,
  Volume2,
  VolumeX,
  Pin,
  Sparkles,
  Folder,
  Layers,
  ChevronDown,
} from "lucide-react";

export function TabBar() {
  const {
    tabs,
    activeTabId,
    setActiveTabId,
    createNewTab,
    closeTab,
    togglePinTab,
    toggleMuteTab,
    tabGroups,
    setTabGroup,
    createTabGroup,
    isTabOverviewOpen,
    setIsTabOverviewOpen,
  } = useBrowser();

  const [hoveredTabId, setHoveredTabId] = useState<string | null>(null);
  const [activeGroupMenuTabId, setActiveGroupMenuTabId] = useState<string | null>(null);
  const [draggedTabIndex, setDraggedTabIndex] = useState<number | null>(null);

  const pinnedTabs = tabs.filter((t) => t.isPinned);
  const regularTabs = tabs.filter((t) => !t.isPinned);

  const getGroup = (groupId?: string) => tabGroups.find((g) => g.id === groupId);

  return (
    <div
      id="browser-tab-bar"
      className="h-10 w-full flex items-center bg-neutral-200/90 dark:bg-neutral-900/90 backdrop-blur-md px-2 gap-1 select-none border-b border-neutral-300/80 dark:border-neutral-800 relative z-30"
    >
      {/* Pinned Tabs */}
      {pinnedTabs.map((tab) => {
        const isActive = tab.id === activeTabId;
        return (
          <div
            key={tab.id}
            onClick={() => setActiveTabId(tab.id)}
            title={`${tab.title} (Pinned)`}
            className={`h-7 px-2.5 rounded-lg flex items-center gap-1.5 cursor-pointer text-xs font-medium transition-all ${
              isActive
                ? "bg-white dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100 shadow-sm border border-neutral-300/60 dark:border-neutral-700"
                : "text-neutral-600 dark:text-neutral-400 hover:bg-white/50 dark:hover:bg-neutral-800/50"
            }`}
          >
            <span className="text-sm">{tab.favicon || "🌐"}</span>
            <Pin className="w-2.5 h-2.5 text-blue-500 fill-blue-500 rotate-45" />
            {tab.isPlayingAudio && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleMuteTab(tab.id);
                }}
                className="hover:text-blue-500 ml-0.5"
              >
                {tab.isMuted ? (
                  <VolumeX className="w-3 h-3 text-rose-500" />
                ) : (
                  <Volume2 className="w-3 h-3 text-blue-500 animate-pulse" />
                )}
              </button>
            )}
          </div>
        );
      })}

      {pinnedTabs.length > 0 && <div className="h-4 w-px bg-neutral-300 dark:bg-neutral-700 mx-1"></div>}

      {/* Regular Tabs */}
      <div className="flex-1 flex items-center gap-1 overflow-x-auto no-scrollbar max-w-full">
        {regularTabs.map((tab, idx) => {
          const isActive = tab.id === activeTabId;
          const group = getGroup(tab.groupId);

          return (
            <div
              key={tab.id}
              draggable
              onDragStart={() => setDraggedTabIndex(idx)}
              onClick={() => setActiveTabId(tab.id)}
              onMouseEnter={() => setHoveredTabId(tab.id)}
              onMouseLeave={() => setHoveredTabId(null)}
              className={`group relative h-7.5 min-w-[130px] max-w-[210px] flex-1 px-2.5 rounded-lg flex items-center justify-between text-xs font-medium cursor-pointer transition-all duration-150 ${
                isActive
                  ? "bg-white dark:bg-neutral-800 text-neutral-900 dark:text-neutral-100 shadow-sm border border-neutral-300/80 dark:border-neutral-700"
                  : "text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100/70 dark:hover:bg-neutral-800/40"
              }`}
            >
              {/* Tab Group Indicator Line / Dot */}
              {group && (
                <div
                  className="absolute left-1.5 top-2 w-1.5 h-3.5 rounded-full"
                  style={{ backgroundColor: group.color }}
                  title={`Tab Group: ${group.name}`}
                />
              )}

              {/* Favicon & Title */}
              <div className={`flex items-center gap-1.5 min-w-0 flex-1 ${group ? "pl-2" : ""}`}>
                <span className="text-xs shrink-0">{tab.favicon || "🌐"}</span>
                <span className="truncate text-xs font-medium">{tab.title || "Untitled Page"}</span>
              </div>

              {/* Right Side Icons: Audio, Pin, Close */}
              <div className="flex items-center gap-1 shrink-0 ml-1">
                {tab.isPlayingAudio && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleMuteTab(tab.id);
                    }}
                    title={tab.isMuted ? "Unmute Tab" : "Mute Tab"}
                    className="hover:scale-110 transition-transform"
                  >
                    {tab.isMuted ? (
                      <VolumeX className="w-3 h-3 text-rose-500" />
                    ) : (
                      <Volume2 className="w-3 h-3 text-blue-500 animate-pulse" />
                    )}
                  </button>
                )}

                {/* Close Button */}
                <button
                  id={`btn-close-tab-${tab.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    closeTab(tab.id);
                  }}
                  title="Close Tab (⌘W)"
                  className={`w-4 h-4 rounded-full flex items-center justify-center transition-all ${
                    isActive || hoveredTabId === tab.id
                      ? "opacity-100 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-300"
                      : "opacity-0"
                  }`}
                >
                  <X className="w-2.5 h-2.5 stroke-[2.5]" />
                </button>
              </div>

              {/* Loading Progress Bar at tab bottom */}
              {tab.loadingState === "loading" && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-neutral-200 dark:bg-neutral-700 overflow-hidden rounded-b-lg">
                  <div
                    className="h-full bg-blue-600 transition-all duration-300"
                    style={{ width: `${tab.progress}%` }}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* New Tab (+) Button */}
      <button
        id="btn-new-tab"
        onClick={() => createNewTab("macweb://newtab")}
        title="Open New Tab (⌘T)"
        className="w-7 h-7 rounded-lg flex items-center justify-center text-neutral-600 dark:text-neutral-400 hover:bg-white/80 dark:hover:bg-neutral-800 transition-colors"
      >
        <Plus className="w-4 h-4" />
      </button>

      {/* Tab Overview (Metal Grid) Button */}
      <button
        id="btn-tab-overview"
        onClick={() => setIsTabOverviewOpen(!isTabOverviewOpen)}
        title="Show Tab Overview (⌘⇧\)"
        className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
          isTabOverviewOpen
            ? "bg-blue-600 text-white"
            : "text-neutral-600 dark:text-neutral-400 hover:bg-white/80 dark:hover:bg-neutral-800"
        }`}
      >
        <Layers className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
