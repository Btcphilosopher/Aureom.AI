"use client";

import React, { useState } from "react";
import { useBrowser } from "@/context/BrowserContext";
import { NATIVE_SWIFT_PROJECT, NativeFile } from "@/lib/nativeCodebase";
import {
  Code,
  X,
  Copy,
  Check,
  Download,
  FileCode,
  Folder,
  Layers,
  Sparkles,
} from "lucide-react";

export function NativeCodeExplorerModal() {
  const { isNativeCodeModalOpen, setIsNativeCodeModalOpen } = useBrowser();
  const [selectedFile, setSelectedFile] = useState<NativeFile>(NATIVE_SWIFT_PROJECT[0]);
  const [copied, setCopied] = useState(false);

  if (!isNativeCodeModalOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportAll = () => {
    const fullProjectText = NATIVE_SWIFT_PROJECT.map(
      (f) => `// ==========================================\n// FILE: ${f.path}\n// CATEGORY: ${f.category}\n// ==========================================\n\n${f.code}\n\n`
    ).join("\n");

    const blob = new Blob([fullProjectText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "MACWEB_OS_Native_Xcode_Project.swift";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      id="native-code-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 select-none"
      onClick={() => setIsNativeCodeModalOpen(false)}
    >
      <div
        id="native-code-modal"
        className="w-full max-w-5xl h-[700px] bg-neutral-900 border border-neutral-700 text-neutral-100 rounded-3xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="h-14 px-6 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-orange-500/20 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold flex items-center gap-2">
                <span>Native macOS WebKit Architecture & Swift Codebase</span>
                <span className="text-[10px] bg-orange-500/20 text-orange-400 font-mono px-2 py-0.5 rounded-full">
                  Swift 6 & WebKit
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Production-grade AppKit window hierarchy, WKWebView navigation delegates, and SQLite 3 WAL schema.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportAll}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export All Files</span>
            </button>
            <button
              onClick={() => setIsNativeCodeModalOpen(false)}
              className="p-1.5 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Explorer Workspace (File Tree + Code Viewer) */}
        <div className="flex-1 flex overflow-hidden">
          {/* File Tree Sidebar */}
          <div className="w-72 bg-neutral-950/60 border-r border-neutral-800 p-3 overflow-y-auto space-y-1 text-xs">
            <div className="px-2 py-1 text-[10px] font-bold text-neutral-500 uppercase tracking-wider">
              Project Structure
            </div>

            {NATIVE_SWIFT_PROJECT.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-2.5 py-2 rounded-xl flex items-center gap-2 transition-colors ${
                    isSelected
                      ? "bg-blue-600 text-white font-semibold"
                      : "text-neutral-400 hover:bg-neutral-800 hover:text-neutral-200"
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 shrink-0" />
                  <div className="truncate min-w-0 flex-1">
                    <div className="truncate">{file.filename}</div>
                    <div className="text-[10px] opacity-70 truncate">{file.category}</div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Code Viewer */}
          <div className="flex-1 flex flex-col bg-neutral-900 overflow-hidden">
            {/* File Info Bar */}
            <div className="h-10 px-4 bg-neutral-950/80 border-b border-neutral-800 flex items-center justify-between text-xs font-mono">
              <div className="text-neutral-300 truncate font-semibold">
                {selectedFile.path}
              </div>

              <button
                onClick={handleCopy}
                className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg flex items-center gap-1.5 text-[11px] font-sans transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? "Copied" : "Copy File"}</span>
              </button>
            </div>

            {/* Code Body */}
            <div className="flex-1 p-4 overflow-auto font-mono text-xs text-neutral-200 bg-neutral-950/90 leading-relaxed select-text">
              <pre>
                <code>{selectedFile.code}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
