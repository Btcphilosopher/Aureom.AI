"use client";

import React, { useState } from "react";
import { useBrowser } from "@/context/BrowserContext";
import { X, Plus, Search, Layers, Volume2, Pin } from "lucide-react";

export function TabOverviewGrid() {
  const {
    isTabOverviewOpen,
    setIsTabOverviewOpen,
    tabs,
    activeTabId,
    setActiveTabId,
    createNewTab,
    closeTab,
    tabGroups,
  } = useBrowser();

  const [searchFilter, setSearchFilter] = useState("");
  const [selectedGroupFilter, setSelectedGroupFilter] = useState<string | null>(null);

  if (!isTabOverviewOpen) return null;

  const filteredTabs = tabs.filter((t) => {
    const matchesSearch =
      t.title.toLowerCase().includes(searchFilter.toLowerCase()) ||
      t.url.toLowerCase().includes(searchFilter.toLowerCase());
    const matchesGroup = selectedGroupFilter ? t.groupId === selectedGroupFilter : true;
    return matchesSearch && matchesGroup;
  });

  return (
    <div
      id="tab-overview-grid"
      className="fixed inset-0 z-50 bg-neutral-950/85 backdrop-blur-2xl p-8 flex flex-col select-none text-white overflow-y-auto"
    >
      {/* Top Header */}
      <div className="w-full max-w-6xl mx-auto flex items-center justify-between pb-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold">Tab Overview</h2>
            <p className="text-xs text-neutral-400">{tabs.length} Open Tabs across Window</p>
          </div>
        </div>

        {/* Tab Group Filter Chips */}
        <div className="hidden md:flex items-center gap-2">
          <button
            onClick={() => setSelectedGroupFilter(null)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
              selectedGroupFilter === null ? "bg-white text-neutral-900 font-bold" : "bg-white/10 hover:bg-white/20"
            }`}
          >
            All Tabs
          </button>
          {tabGroups.map((group) => (
            <button
              key={group.id}
              onClick={() => setSelectedGroupFilter(group.id)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors flex items-center gap-1.5 ${
                selectedGroupFilter === group.id ? "bg-white text-neutral-900 font-bold" : "bg-white/10 hover:bg-white/20"
              }`}
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: group.color }} />
              <span>{group.name}</span>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          {/* Search Tabs */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search open tabs..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-neutral-900 rounded-xl border border-white/15 text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <button
            onClick={() => {
              createNewTab("macweb://newtab");
              setIsTabOverviewOpen(false);
            }}
            className="p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl flex items-center gap-1 text-xs font-semibold"
          >
            <Plus className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsTabOverviewOpen(false)}
            className="p-2 bg-white/10 hover:bg-white/20 rounded-xl text-neutral-300 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid of Tab Cards */}
      <div className="w-full max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 pt-8">
        {filteredTabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          const group = tabGroups.find((g) => g.id === tab.groupId);

          return (
            <div
              key={tab.id}
              onClick={() => {
                setActiveTabId(tab.id);
                setIsTabOverviewOpen(false);
              }}
              className={`group relative h-48 rounded-2xl border transition-all duration-200 cursor-pointer overflow-hidden flex flex-col bg-neutral-900 ${
                isActive
                  ? "border-blue-500 ring-4 ring-blue-500/30 scale-102"
                  : "border-neutral-800 hover:border-neutral-600 hover:scale-102"
              }`}
            >
              {/* Card Top Title Bar */}
              <div className="p-3 bg-neutral-950/80 border-b border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2 truncate flex-1">
                  <span className="text-base shrink-0">{tab.favicon || "🌐"}</span>
                  <span className="text-xs font-semibold text-white truncate">{tab.title}</span>
                </div>

                <div className="flex items-center gap-1.5 ml-2">
                  {tab.isPinned && <Pin className="w-3 h-3 text-blue-400 fill-blue-400 rotate-45" />}
                  {tab.isPlayingAudio && <Volume2 className="w-3 h-3 text-emerald-400 animate-pulse" />}

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      closeTab(tab.id);
                    }}
                    className="p-1 hover:bg-neutral-800 rounded-full text-neutral-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Card Body Thumbnail Simulation */}
              <div className="flex-1 p-4 bg-gradient-to-b from-neutral-900 to-neutral-950 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <div className="text-[10px] font-mono text-neutral-400 truncate">{tab.url}</div>
                  <div className="h-2 w-3/4 bg-neutral-800 rounded-full" />
                  <div className="h-2 w-1/2 bg-neutral-800 rounded-full" />
                </div>

                {group && (
                  <div className="flex items-center gap-1.5 text-[10px] font-medium text-neutral-300">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: group.color }} />
                    <span>{group.name}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
