"use client";

import React from "react";
import { useBrowser } from "@/context/BrowserContext";
import { SEARCH_PROVIDERS } from "@/lib/curatedWebData";
import {
  Settings,
  X,
  Compass,
  Layers,
  Search,
  Shield,
  Download,
  Puzzle,
  Code,
  Info,
  Check,
  Cpu,
} from "lucide-react";

export function SettingsModal() {
  const {
    isSettingsOpen,
    setIsSettingsOpen,
    settingsActiveTab,
    setSettingsActiveTab,
    settings,
    updateSettings,
    extensions,
    toggleExtension,
  } = useBrowser();

  if (!isSettingsOpen) return null;

  const sidebarItems = [
    { id: "general", label: "General", icon: Compass },
    { id: "tabs", label: "Tabs", icon: Layers },
    { id: "search", label: "Search", icon: Search },
    { id: "privacy", label: "Privacy & Security", icon: Shield },
    { id: "extensions", label: "Extensions", icon: Puzzle },
    { id: "developer", label: "Developer & WebKit", icon: Code },
    { id: "about", label: "About", icon: Info },
  ];

  return (
    <div
      id="settings-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 select-none"
      onClick={() => setIsSettingsOpen(false)}
    >
      <div
        id="settings-modal"
        className="w-full max-w-3xl h-[600px] bg-neutral-900 border border-neutral-700 text-neutral-100 rounded-3xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="h-12 px-6 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-blue-500" />
            <span className="font-bold text-sm">MACWEB.OS Preferences</span>
          </div>
          <button
            onClick={() => setIsSettingsOpen(false)}
            className="p-1.5 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Container (Sidebar + Content) */}
        <div className="flex-1 flex overflow-hidden">
          {/* Settings Sidebar */}
          <div className="w-56 p-3 bg-neutral-950/60 border-r border-neutral-800 space-y-1">
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              const isActive = settingsActiveTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setSettingsActiveTab(item.id)}
                  className={`w-full text-left px-3 py-2 rounded-xl flex items-center gap-2.5 text-xs font-semibold transition-colors ${
                    isActive
                      ? "bg-blue-600 text-white shadow-sm"
                      : "text-neutral-400 hover:bg-neutral-800 hover:text-neutral-200"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Settings Tab Content */}
          <div className="flex-1 p-6 overflow-y-auto space-y-6 text-xs">
            {/* GENERAL TAB */}
            {settingsActiveTab === "general" && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-white">General Settings</h3>
                  <p className="text-neutral-400">Configure startup behavior and default paths.</p>
                </div>

                <div className="space-y-4">
                  <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
                    <label className="font-semibold text-neutral-200 block">On Startup Open:</label>
                    <div className="flex gap-4">
                      {[
                        { id: "restore", label: "Restore Previous Session" },
                        { id: "homepage", label: "Open Start Page" },
                      ].map((opt) => (
                        <label key={opt.id} className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="radio"
                            name="startup"
                            checked={settings.openTabsOnStartup === opt.id}
                            onChange={() => updateSettings({ openTabsOnStartup: opt.id as any })}
                            className="text-blue-600 focus:ring-0"
                          />
                          <span>{opt.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2">
                    <label className="font-semibold text-neutral-200 block">Default Download Location:</label>
                    <input
                      type="text"
                      value={settings.defaultDownloadLocation}
                      onChange={(e) => updateSettings({ defaultDownloadLocation: e.target.value })}
                      className="w-full px-3 py-2 bg-neutral-900 rounded-xl border border-neutral-700 text-neutral-200 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* SEARCH TAB */}
            {settingsActiveTab === "search" && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-white">Search Engine Preferences</h3>
                  <p className="text-neutral-400">Select default search engine used in address bar omnibox.</p>
                </div>

                <div className="space-y-2">
                  {SEARCH_PROVIDERS.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => updateSettings({ defaultSearchEngineId: p.id })}
                      className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                        settings.defaultSearchEngineId === p.id
                          ? "bg-blue-600/20 border-blue-500 text-white"
                          : "bg-neutral-950 border-neutral-800 hover:border-neutral-700 text-neutral-300"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{p.icon}</span>
                        <div>
                          <div className="font-bold text-sm">{p.name}</div>
                          <div className="text-[11px] text-neutral-400 font-mono">{p.searchUrlTemplate}</div>
                        </div>
                      </div>
                      {settings.defaultSearchEngineId === p.id && (
                        <Check className="w-5 h-5 text-blue-400" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* PRIVACY TAB */}
            {settingsActiveTab === "privacy" && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-white">Privacy & Content Filtering</h3>
                  <p className="text-neutral-400">Apple WebKit declarative content blocking and anti-tracking.</p>
                </div>

                <div className="space-y-3">
                  {[
                    { id: "contentBlockingEnabled", label: "Declarative Content Blocking", desc: "Block third-party advertising scripts before download" },
                    { id: "blockTrackers", label: "Intelligent Tracking Prevention (ITP)", desc: "Enforce 24-hour cookie limits on cross-site domains" },
                    { id: "blockCryptominers", label: "Block Cryptomining & Fingerprinting", desc: "Disable suspicious canvas readouts and WebAssembly miners" },
                    { id: "doNotTrack", label: "Send 'Do Not Track' Header", desc: "Broadcast DNT: 1 on all outbound WebKit HTTP requests" },
                  ].map((item) => (
                    <div
                      key={item.id}
                      className="p-3.5 bg-neutral-950 rounded-2xl border border-neutral-800 flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-neutral-200">{item.label}</div>
                        <div className="text-[11px] text-neutral-400">{item.desc}</div>
                      </div>
                      <button
                        onClick={() => updateSettings({ [item.id]: !(settings as any)[item.id] })}
                        className={`w-10 h-6 rounded-full p-0.5 transition-colors ${
                          (settings as any)[item.id] ? "bg-emerald-600" : "bg-neutral-800"
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full bg-white transition-transform ${
                            (settings as any)[item.id] ? "translate-x-4" : "translate-x-0"
                          }`}
                        />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* EXTENSIONS TAB */}
            {settingsActiveTab === "extensions" && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-white">Installed Extensions</h3>
                  <p className="text-neutral-400">WebExtensions running with WebKit content scripts.</p>
                </div>

                <div className="space-y-3">
                  {extensions.map((ext) => (
                    <div
                      key={ext.id}
                      className="p-3.5 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{ext.icon}</span>
                          <div>
                            <div className="font-bold text-white">{ext.name}</div>
                            <div className="text-[10px] text-neutral-400">v{ext.version} • {ext.author}</div>
                          </div>
                        </div>
                        <button
                          onClick={() => toggleExtension(ext.id)}
                          className={`w-10 h-6 rounded-full p-0.5 transition-colors ${
                            ext.enabled ? "bg-blue-600" : "bg-neutral-800"
                          }`}
                        >
                          <div
                            className={`w-5 h-5 rounded-full bg-white transition-transform ${
                              ext.enabled ? "translate-x-4" : "translate-x-0"
                            }`}
                          />
                        </button>
                      </div>
                      <p className="text-xs text-neutral-400">{ext.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* DEVELOPER TAB */}
            {settingsActiveTab === "developer" && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-white">Developer & Engine Settings</h3>
                  <p className="text-neutral-400">WebKit Web Inspector, process models, and diagnostics.</p>
                </div>

                <div className="p-4 bg-neutral-950 rounded-2xl border border-neutral-800 space-y-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-white">Developer Mode</div>
                      <div className="text-[11px] text-neutral-400">Enables Develop menu and Web Inspector inspection</div>
                    </div>
                    <button
                      onClick={() => updateSettings({ developerModeEnabled: !settings.developerModeEnabled })}
                      className={`w-10 h-6 rounded-full p-0.5 transition-colors ${
                        settings.developerModeEnabled ? "bg-blue-600" : "bg-neutral-800"
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full bg-white transition-transform ${
                          settings.developerModeEnabled ? "translate-x-4" : "translate-x-0"
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ABOUT TAB */}
            {settingsActiveTab === "about" && (
              <div className="space-y-6 text-center py-6">
                <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-blue-600 to-indigo-500 mx-auto flex items-center justify-center text-3xl shadow-xl">
                  🧭
                </div>

                <div className="space-y-1">
                  <h3 className="text-xl font-bold text-white">MACWEB.OS</h3>
                  <div className="text-xs text-neutral-400 font-mono">Version 3.7 (Build 2026.09.08)</div>
                </div>

                <div className="max-w-md mx-auto p-4 bg-neutral-950 rounded-2xl border border-neutral-800 text-left space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Rendering Engine:</span>
                    <span className="font-semibold text-neutral-200">WebKit Public Engine</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Target Architecture:</span>
                    <span className="font-semibold text-emerald-400 font-mono">Apple Silicon (arm64)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Graphics Pipeline:</span>
                    <span className="font-semibold text-neutral-200">Metal 3 Low Overhead</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">AI Assistant:</span>
                    <span className="font-semibold text-blue-400">Gemini 3.8 Flash</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
