"use client";

import React, { useState } from "react";
import { useBrowser } from "@/context/BrowserContext";
import { CURATED_PAGES } from "@/lib/curatedWebData";
import {
  X,
  Type,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Clock,
  Share2,
  Bookmark,
  Sparkles,
} from "lucide-react";

export function ReaderModeView() {
  const {
    activeTab,
    toggleReaderMode,
    readerConfig,
    setReaderConfig,
    addToReadingList,
    setIsAIDrawerOpen,
  } = useBrowser();

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [showTypographyPopover, setShowTypographyPopover] = useState(false);

  if (!activeTab || !activeTab.readerModeActive) return null;

  const page = CURATED_PAGES[activeTab.url];
  const title = page ? page.title : activeTab.title;
  const rawHtml = page ? page.readerHtml : "<p>Article text rendering...</p>";
  const textContent = rawHtml.replace(/<[^>]*>?/gm, " ");
  const readingTime = 4;

  const handleSpeak = () => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(textContent);
      utterance.rate = 1.0;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    }
  };

  const getThemeClasses = () => {
    switch (readerConfig.theme) {
      case "sepia":
        return "bg-[#fbf0d9] text-[#5f4b32]";
      case "dark":
        return "bg-[#181818] text-[#d4d4d4]";
      case "slate":
        return "bg-[#1e293b] text-[#cbd5e1]";
      default:
        return "bg-[#fdfdfd] text-[#222222]";
    }
  };

  const getFontFamily = () => {
    switch (readerConfig.fontFamily) {
      case "sans":
        return "font-sans";
      case "mono":
        return "font-mono";
      default:
        return "font-serif";
    }
  };

  const getMaxWidth = () => {
    switch (readerConfig.columnWidth) {
      case "narrow":
        return "max-w-xl";
      case "wide":
        return "max-w-4xl";
      default:
        return "max-w-2xl";
    }
  };

  return (
    <div
      id="browser-reader-mode"
      className={`w-full h-full overflow-y-auto ${getThemeClasses()} flex flex-col items-center select-text transition-colors duration-200 z-30`}
    >
      {/* Floating Reader Toolbar */}
      <div className="sticky top-4 z-40 px-3 py-1.5 rounded-2xl bg-neutral-900/85 backdrop-blur-xl border border-white/15 text-white flex items-center gap-3 shadow-2xl mb-8">
        {/* Typography Controls */}
        <div className="relative">
          <button
            onClick={() => setShowTypographyPopover(!showTypographyPopover)}
            className="p-1.5 rounded-lg hover:bg-white/10 flex items-center gap-1 text-xs font-semibold"
          >
            <Type className="w-4 h-4" />
            <span>Format</span>
          </button>

          {showTypographyPopover && (
            <div className="absolute left-0 top-10 w-64 p-3 bg-neutral-900 border border-white/20 rounded-2xl shadow-2xl space-y-3 text-xs text-white z-50">
              {/* Theme Colors */}
              <div className="space-y-1">
                <div className="text-[10px] text-neutral-400 font-semibold uppercase">Background</div>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { id: "light", label: "Light", color: "#fdfdfd" },
                    { id: "sepia", label: "Sepia", color: "#fbf0d9" },
                    { id: "slate", label: "Slate", color: "#1e293b" },
                    { id: "dark", label: "Dark", color: "#181818" },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setReaderConfig((prev) => ({ ...prev, theme: t.id as any }))}
                      className={`h-7 rounded-lg border flex items-center justify-center text-[10px] font-bold ${
                        readerConfig.theme === t.id ? "ring-2 ring-blue-500 border-transparent" : "border-white/20"
                      }`}
                      style={{ backgroundColor: t.color, color: t.id === "light" || t.id === "sepia" ? "#000" : "#fff" }}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Font Stepper */}
              <div className="space-y-1">
                <div className="text-[10px] text-neutral-400 font-semibold uppercase">Font Size</div>
                <div className="flex items-center justify-between bg-white/10 p-1 rounded-xl">
                  <button
                    onClick={() => setReaderConfig((prev) => ({ ...prev, fontSize: Math.max(14, prev.fontSize - 2) }))}
                    className="px-3 py-1 font-bold hover:bg-white/10 rounded-lg text-sm"
                  >
                    A-
                  </button>
                  <span className="font-mono">{readerConfig.fontSize}px</span>
                  <button
                    onClick={() => setReaderConfig((prev) => ({ ...prev, fontSize: Math.min(28, prev.fontSize + 2) }))}
                    className="px-3 py-1 font-bold hover:bg-white/10 rounded-lg text-lg"
                  >
                    A+
                  </button>
                </div>
              </div>

              {/* Font Family */}
              <div className="space-y-1">
                <div className="text-[10px] text-neutral-400 font-semibold uppercase">Typography</div>
                <div className="grid grid-cols-3 gap-1">
                  {[
                    { id: "serif", label: "Georgia" },
                    { id: "sans", label: "SF Pro" },
                    { id: "mono", label: "Menlo" },
                  ].map((f) => (
                    <button
                      key={f.id}
                      onClick={() => setReaderConfig((prev) => ({ ...prev, fontFamily: f.id as any }))}
                      className={`py-1 rounded-lg border text-center ${
                        readerConfig.fontFamily === f.id ? "bg-blue-600 border-transparent font-bold" : "border-white/20 hover:bg-white/10"
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="h-4 w-px bg-white/20" />

        {/* WebKit Speech Synthesis */}
        <button
          onClick={handleSpeak}
          title={isSpeaking ? "Pause Narration" : "Read Aloud (WebKit Speech)"}
          className={`p-1.5 rounded-lg flex items-center gap-1.5 text-xs font-semibold ${
            isSpeaking ? "bg-blue-600 text-white animate-pulse" : "hover:bg-white/10"
          }`}
        >
          {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          <span className="hidden sm:inline">{isSpeaking ? "Speaking" : "Listen"}</span>
        </button>

        {/* AI Summarize in Reader Mode */}
        <button
          onClick={() => setIsAIDrawerOpen(true)}
          title="AI Page Analysis"
          className="p-1.5 rounded-lg hover:bg-white/10 flex items-center gap-1 text-xs text-blue-400 font-semibold"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Summarize</span>
        </button>

        {/* Save to Reading List */}
        <button
          onClick={() => addToReadingList(activeTab.url, title, textContent.slice(0, 120))}
          title="Add to Reading List"
          className="p-1.5 rounded-lg hover:bg-white/10"
        >
          <Bookmark className="w-3.5 h-3.5" />
        </button>

        <div className="h-4 w-px bg-white/20" />

        {/* Close Reader Mode */}
        <button
          onClick={toggleReaderMode}
          title="Exit Reader Mode (⌘⇧R)"
          className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Reader Article Body */}
      <article className={`w-full ${getMaxWidth()} px-6 pb-20 space-y-6 ${getFontFamily()}`}>
        <header className="space-y-3 pb-6 border-b border-neutral-300 dark:border-neutral-800">
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight">
            {title}
          </h1>

          <div className="flex items-center gap-4 text-xs opacity-75 font-sans">
            <span className="font-semibold">{page?.author || "WebKit Engineering"}</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {readingTime} min read
            </span>
            <span>•</span>
            <span className="font-mono">{page?.publishedDate || "September 2026"}</span>
          </div>
        </header>

        <div
          className="leading-relaxed space-y-4"
          style={{ fontSize: `${readerConfig.fontSize}px` }}
          dangerouslySetInnerHTML={{ __html: rawHtml }}
        />
      </article>
    </div>
  );
}
