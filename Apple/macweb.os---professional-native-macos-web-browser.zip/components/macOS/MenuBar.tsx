"use client";

import React, { useState, useEffect, useRef } from "react";
import { useBrowser } from "@/context/BrowserContext";
import {
  Wifi,
  Battery,
  Search,
  Sliders,
  Sparkles,
  Shield,
  Code,
  LayoutGrid,
} from "lucide-react";

export function MenuBar() {
  const {
    activeWindow,
    createNewTab,
    createNewWindow,
    closeTab,
    closeWindow,
    reopenClosedTab,
    activeTabId,
    activeTab,
    goBack,
    goForward,
    reload,
    stop,
    toggleReaderMode,
    setZoomLevel,
    isSidebarOpen,
    setIsSidebarOpen,
    setSidebarTab,
    isWebInspectorOpen,
    setIsWebInspectorOpen,
    setInspectorActiveTab,
    isPrivacyDashboardOpen,
    setIsPrivacyDashboardOpen,
    isSettingsOpen,
    setIsSettingsOpen,
    setSettingsActiveTab,
    isTabOverviewOpen,
    setIsTabOverviewOpen,
    isNativeCodeModalOpen,
    setIsNativeCodeModalOpen,
    isFindBarOpen,
    setIsFindBarOpen,
    addBookmark,
    clearHistory,
    setIsAIDrawerOpen,
  } = useBrowser();

  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [timeStr, setTimeStr] = useState("");
  const menuBarRef = useRef<HTMLDivElement>(null);

  // Update clock every 10s
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const formatted = now.toLocaleTimeString([], {
        weekday: "short",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
      setTimeStr(formatted);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuBarRef.current && !menuBarRef.current.contains(e.target as Node)) {
        setActiveMenu(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleMenuClick = (menuName: string) => {
    setActiveMenu(activeMenu === menuName ? null : menuName);
  };

  const handleMenuHover = (menuName: string) => {
    if (activeMenu !== null) {
      setActiveMenu(menuName);
    }
  };

  const closeMenus = () => setActiveMenu(null);

  return (
    <div
      id="macos-system-menubar"
      ref={menuBarRef}
      className="h-7 w-full bg-neutral-900/80 dark:bg-black/70 backdrop-blur-xl text-neutral-200 text-xs flex items-center justify-between px-3 select-none border-b border-white/10 z-50 relative font-sans"
    >
      {/* Left System Menus */}
      <div className="flex items-center gap-1">
        {/* Apple Logo */}
        <div className="relative">
          <button
            id="btn-menu-apple"
            onClick={() => handleMenuClick("apple")}
            onMouseEnter={() => handleMenuHover("apple")}
            className={`px-2 py-0.5 rounded transition-colors flex items-center justify-center font-bold text-sm ${
              activeMenu === "apple" ? "bg-white/20 text-white" : "hover:bg-white/10"
            }`}
          >
            
          </button>
          {activeMenu === "apple" && (
            <div className="absolute left-0 top-6.5 w-56 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  setIsSettingsOpen(true);
                  setSettingsActiveTab("about");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>About MACWEB.OS</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  setIsSettingsOpen(true);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>System Preferences...</span>
                <span className="text-neutral-400">⌘,</span>
              </button>
              <button
                onClick={() => {
                  setIsNativeCodeModalOpen(true);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>WebKit Native Codebase</span>
                <span className="text-neutral-400">⌘⇧X</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  window.location.reload();
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded"
              >
                Restart Session...
              </button>
            </div>
          )}
        </div>

        {/* App Menu: MACWEB.OS */}
        <div className="relative">
          <button
            id="btn-menu-app"
            onClick={() => handleMenuClick("macweb")}
            onMouseEnter={() => handleMenuHover("macweb")}
            className={`px-2 py-0.5 rounded font-semibold text-white transition-colors ${
              activeMenu === "macweb" ? "bg-white/20" : "hover:bg-white/10"
            }`}
          >
            MACWEB.OS
          </button>
          {activeMenu === "macweb" && (
            <div className="absolute left-0 top-6.5 w-60 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  setIsSettingsOpen(true);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Preferences...</span>
                <span className="text-neutral-400">⌘,</span>
              </button>
              <button
                onClick={() => {
                  setIsPrivacyDashboardOpen(true);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Privacy Report...</span>
                <span className="text-neutral-400">🛡️</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  setIsAIDrawerOpen(true);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>AI Browser Copilot</span>
                <span className="text-neutral-400">⌘J</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  if (activeWindow) closeWindow(activeWindow.id);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Quit MACWEB.OS</span>
                <span className="text-neutral-400">⌘Q</span>
              </button>
            </div>
          )}
        </div>

        {/* File Menu */}
        <div className="relative">
          <button
            id="btn-menu-file"
            onClick={() => handleMenuClick("file")}
            onMouseEnter={() => handleMenuHover("file")}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeMenu === "file" ? "bg-white/20 text-white" : "hover:bg-white/10"
            }`}
          >
            File
          </button>
          {activeMenu === "file" && (
            <div className="absolute left-0 top-6.5 w-60 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  createNewTab("macweb://newtab");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>New Tab</span>
                <span className="text-neutral-400">⌘T</span>
              </button>
              <button
                onClick={() => {
                  createNewWindow("normal");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>New Window</span>
                <span className="text-neutral-400">⌘N</span>
              </button>
              <button
                onClick={() => {
                  createNewWindow("private");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>New Private Window</span>
                <span className="text-neutral-400">⌘⇧N</span>
              </button>
              <button
                onClick={() => {
                  reopenClosedTab();
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Reopen Closed Tab</span>
                <span className="text-neutral-400">⌘⇧T</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  if (activeTabId) closeTab(activeTabId);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Close Tab</span>
                <span className="text-neutral-400">⌘W</span>
              </button>
              <button
                onClick={() => {
                  if (activeWindow) closeWindow(activeWindow.id);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Close Window</span>
                <span className="text-neutral-400">⌘⇧W</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  setIsNativeCodeModalOpen(true);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Export Swift Xcode Project...</span>
                <span className="text-neutral-400">⌘E</span>
              </button>
            </div>
          )}
        </div>

        {/* Edit Menu */}
        <div className="relative">
          <button
            id="btn-menu-edit"
            onClick={() => handleMenuClick("edit")}
            onMouseEnter={() => handleMenuHover("edit")}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeMenu === "edit" ? "bg-white/20 text-white" : "hover:bg-white/10"
            }`}
          >
            Edit
          </button>
          {activeMenu === "edit" && (
            <div className="absolute left-0 top-6.5 w-56 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  setIsFindBarOpen(true);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Find in Page...</span>
                <span className="text-neutral-400">⌘F</span>
              </button>
              <button
                onClick={() => {
                  if (activeTab) {
                    navigator.clipboard.writeText(activeTab.url);
                  }
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Copy Current URL</span>
                <span className="text-neutral-400">⌘C</span>
              </button>
            </div>
          )}
        </div>

        {/* View Menu */}
        <div className="relative">
          <button
            id="btn-menu-view"
            onClick={() => handleMenuClick("view")}
            onMouseEnter={() => handleMenuHover("view")}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeMenu === "view" ? "bg-white/20 text-white" : "hover:bg-white/10"
            }`}
          >
            View
          </button>
          {activeMenu === "view" && (
            <div className="absolute left-0 top-6.5 w-60 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  setIsSidebarOpen(!isSidebarOpen);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>{isSidebarOpen ? "Hide Sidebar" : "Show Sidebar"}</span>
                <span className="text-neutral-400">⌘⌃S</span>
              </button>
              <button
                onClick={() => {
                  toggleReaderMode();
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>{activeTab?.readerModeActive ? "Exit Reader Mode" : "Show Reader Mode"}</span>
                <span className="text-neutral-400">⌘⇧R</span>
              </button>
              <button
                onClick={() => {
                  setIsTabOverviewOpen(!isTabOverviewOpen);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Tab Overview (Metal Grid)</span>
                <span className="text-neutral-400">⌘⇧\</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  reload();
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Reload Page</span>
                <span className="text-neutral-400">⌘R</span>
              </button>
              <button
                onClick={() => {
                  stop();
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Stop Loading</span>
                <span className="text-neutral-400">⌘.</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  if (activeTab) setZoomLevel(activeTab.zoomLevel + 10);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Zoom In</span>
                <span className="text-neutral-400">⌘+</span>
              </button>
              <button
                onClick={() => {
                  if (activeTab) setZoomLevel(activeTab.zoomLevel - 10);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Zoom Out</span>
                <span className="text-neutral-400">⌘-</span>
              </button>
              <button
                onClick={() => {
                  setZoomLevel(100);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Actual Size</span>
                <span className="text-neutral-400">⌘0</span>
              </button>
            </div>
          )}
        </div>

        {/* History Menu */}
        <div className="relative">
          <button
            id="btn-menu-history"
            onClick={() => handleMenuClick("history")}
            onMouseEnter={() => handleMenuHover("history")}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeMenu === "history" ? "bg-white/20 text-white" : "hover:bg-white/10"
            }`}
          >
            History
          </button>
          {activeMenu === "history" && (
            <div className="absolute left-0 top-6.5 w-60 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  goBack();
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Back</span>
                <span className="text-neutral-400">⌘[</span>
              </button>
              <button
                onClick={() => {
                  goForward();
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Forward</span>
                <span className="text-neutral-400">⌘]</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  setIsSidebarOpen(true);
                  setSidebarTab("history");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Show All History</span>
                <span className="text-neutral-400">⌘Y</span>
              </button>
              <button
                onClick={() => {
                  clearHistory("today");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded text-rose-400"
              >
                Clear Today&apos;s History...
              </button>
              <button
                onClick={() => {
                  clearHistory("all");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded text-rose-400"
              >
                Clear All History...
              </button>
            </div>
          )}
        </div>

        {/* Bookmarks Menu */}
        <div className="relative">
          <button
            id="btn-menu-bookmarks"
            onClick={() => handleMenuClick("bookmarks")}
            onMouseEnter={() => handleMenuHover("bookmarks")}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeMenu === "bookmarks" ? "bg-white/20 text-white" : "hover:bg-white/10"
            }`}
          >
            Bookmarks
          </button>
          {activeMenu === "bookmarks" && (
            <div className="absolute left-0 top-6.5 w-60 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  if (activeTab) addBookmark(activeTab.title, activeTab.url);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Add Bookmark...</span>
                <span className="text-neutral-400">⌘D</span>
              </button>
              <button
                onClick={() => {
                  setIsSidebarOpen(true);
                  setSidebarTab("bookmarks");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Show Bookmarks Sidebar</span>
                <span className="text-neutral-400">⌘⌥B</span>
              </button>
            </div>
          )}
        </div>

        {/* Develop Menu */}
        <div className="relative">
          <button
            id="btn-menu-develop"
            onClick={() => handleMenuClick("develop")}
            onMouseEnter={() => handleMenuHover("develop")}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeMenu === "develop" ? "bg-white/20 text-white" : "hover:bg-white/10"
            }`}
          >
            Develop
          </button>
          {activeMenu === "develop" && (
            <div className="absolute left-0 top-6.5 w-64 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  setIsWebInspectorOpen(!isWebInspectorOpen);
                  setInspectorActiveTab("elements");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Show Web Inspector</span>
                <span className="text-neutral-400">⌘⌥I</span>
              </button>
              <button
                onClick={() => {
                  setIsWebInspectorOpen(true);
                  setInspectorActiveTab("console");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Show JavaScript Console</span>
                <span className="text-neutral-400">⌘⌥C</span>
              </button>
              <button
                onClick={() => {
                  setIsWebInspectorOpen(true);
                  setInspectorActiveTab("network");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Show Network Diagnostics</span>
                <span className="text-neutral-400">⌘⌥N</span>
              </button>
              <button
                onClick={() => {
                  setIsWebInspectorOpen(true);
                  setInspectorActiveTab("performance");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Performance & RAM Monitor</span>
                <span className="text-neutral-400">⌘⌥P</span>
              </button>
              <div className="h-px bg-white/10 my-1"></div>
              <button
                onClick={() => {
                  setIsNativeCodeModalOpen(true);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Browse Native Swift Architecture</span>
                <span className="text-neutral-400">⌘⌥S</span>
              </button>
            </div>
          )}
        </div>

        {/* Window Menu */}
        <div className="relative">
          <button
            id="btn-menu-window"
            onClick={() => handleMenuClick("window")}
            onMouseEnter={() => handleMenuHover("window")}
            className={`px-2 py-0.5 rounded transition-colors ${
              activeMenu === "window" ? "bg-white/20 text-white" : "hover:bg-white/10"
            }`}
          >
            Window
          </button>
          {activeMenu === "window" && (
            <div className="absolute left-0 top-6.5 w-56 bg-neutral-900/95 backdrop-blur-2xl border border-white/15 rounded-lg shadow-2xl p-1 text-xs text-neutral-200 z-50">
              <button
                onClick={() => {
                  setIsTabOverviewOpen(!isTabOverviewOpen);
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>Tab Overview</span>
                <span className="text-neutral-400">⌘⇧\</span>
              </button>
              <button
                onClick={() => {
                  createNewWindow("normal");
                  closeMenus();
                }}
                className="w-full text-left px-3 py-1.5 hover:bg-blue-600 hover:text-white rounded flex justify-between"
              >
                <span>New Window</span>
                <span className="text-neutral-400">⌘N</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Right Status Items */}
      <div className="flex items-center gap-3 text-neutral-300">
        <button
          onClick={() => setIsPrivacyDashboardOpen(true)}
          title="Privacy Shield Report"
          className="hover:text-white flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded hover:bg-white/10 transition-colors"
        >
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span className="hidden sm:inline font-mono">Protected</span>
        </button>

        <button
          onClick={() => setIsAIDrawerOpen(true)}
          title="AI Browser Assistant (Gemini 3.8 Flash)"
          className="hover:text-white flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 hover:bg-blue-500/30 transition-colors"
        >
          <Sparkles className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-semibold">Copilot</span>
        </button>

        <button
          onClick={() => setIsNativeCodeModalOpen(true)}
          title="Native macOS Swift Architecture & Code"
          className="hover:text-white p-1 rounded hover:bg-white/10"
        >
          <Code className="w-3.5 h-3.5" />
        </button>

        <Wifi className="w-3.5 h-3.5" />
        <Battery className="w-3.5 h-3.5" />
        <span className="font-medium text-[11px] tracking-tight text-neutral-200">
          {timeStr || "Tue Sep 8 3:45 AM"}
        </span>
      </div>
    </div>
  );
}
