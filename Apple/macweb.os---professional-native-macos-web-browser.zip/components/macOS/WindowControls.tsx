"use client";

import React, { useState } from "react";
import { X, Minus, Maximize2 } from "lucide-react";

interface WindowControlsProps {
  onClose: () => void;
  onMinimize: () => void;
  onMaximize: () => void;
  isMaximized?: boolean;
}

export function WindowControls({
  onClose,
  onMinimize,
  onMaximize,
  isMaximized = false,
}: WindowControlsProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      id="macos-traffic-lights"
      className="flex items-center gap-2 pl-3 pr-2 py-2 select-none group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Red Close */}
      <button
        id="btn-traffic-close"
        onClick={onClose}
        title="Close Window (⌘W)"
        className="w-3 h-3 rounded-full bg-[#ff5f56] border border-[#e0443e] flex items-center justify-center transition-all duration-150 active:brightness-75 focus:outline-none"
      >
        {isHovered && <X className="w-2 h-2 text-[#4c0000] stroke-[2.5]" />}
      </button>

      {/* Yellow Minimize */}
      <button
        id="btn-traffic-minimize"
        onClick={onMinimize}
        title="Minimize Window (⌘M)"
        className="w-3 h-3 rounded-full bg-[#ffbd2e] border border-[#dea123] flex items-center justify-center transition-all duration-150 active:brightness-75 focus:outline-none"
      >
        {isHovered && <Minus className="w-2 h-2 text-[#5c3c00] stroke-[2.5]" />}
      </button>

      {/* Green Zoom / Maximize */}
      <button
        id="btn-traffic-maximize"
        onClick={onMaximize}
        title={isMaximized ? "Exit Full Screen" : "Enter Full Screen"}
        className="w-3 h-3 rounded-full bg-[#27c93f] border border-[#1aab29] flex items-center justify-center transition-all duration-150 active:brightness-75 focus:outline-none"
      >
        {isHovered && <Maximize2 className="w-1.5 h-1.5 text-[#004d00] stroke-[2.5]" />}
      </button>
    </div>
  );
}
