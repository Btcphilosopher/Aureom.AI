"use client";

import React from "react";
import { useBrowser } from "@/context/BrowserContext";
import { BrowserWindow as BrowserWindowType } from "@/types/browser";
import { WindowControls } from "@/components/macOS/WindowControls";
import { TabBar } from "@/components/browser/TabBar";
import { AddressBar } from "@/components/browser/AddressBar";
import { Sidebar } from "@/components/browser/Sidebar";
import { WebView } from "@/components/browser/WebView";
import { AIAssistantDrawer } from "@/components/browser/AIAssistantDrawer";
import { WebInspector } from "@/components/browser/WebInspector";
import { FindBar } from "@/components/browser/FindBar";
import { PrivacyDashboardModal } from "@/components/browser/PrivacyDashboardModal";
import { CertificateModal } from "@/components/browser/CertificateModal";
import { DownloadManagerPopover } from "@/components/browser/DownloadManagerPopover";
import { ExtensionsPopover } from "@/components/browser/ExtensionsPopover";
import { SettingsModal } from "@/components/browser/SettingsModal";
import { TabOverviewGrid } from "@/components/browser/TabOverviewGrid";
import { NativeCodeExplorerModal } from "@/components/browser/NativeCodeExplorerModal";

interface BrowserWindowProps {
  browserWindow: BrowserWindowType;
}

export function BrowserWindow({ browserWindow }: BrowserWindowProps) {
  const {
    activeWindowId,
    activateWindow,
    closeWindow,
    toggleMinimizeWindow,
    toggleMaximizeWindow,
    activeTab,
  } = useBrowser();

  const isActive = activeWindowId === browserWindow.id;
  const isPrivate = browserWindow.type === "private";

  if (browserWindow.isMinimized) {
    return null;
  }

  return (
    <div
      id={`browser-window-${browserWindow.id}`}
      onClick={() => activateWindow(browserWindow.id)}
      className={`w-full h-full flex flex-col overflow-hidden bg-neutral-100 dark:bg-neutral-900 border ${
        isActive
          ? "border-neutral-300 dark:border-neutral-700 shadow-2xl"
          : "border-neutral-200 dark:border-neutral-800 opacity-90 shadow-lg"
      } ${
        browserWindow.isMaximized ? "rounded-none" : "rounded-2xl"
      } select-none transition-all relative`}
      style={{ zIndex: browserWindow.zIndex }}
    >
      {/* Window Title & Unified Header */}
      <div className={`w-full flex items-center border-b border-neutral-300/80 dark:border-neutral-800 ${
        isPrivate ? "bg-neutral-900 text-purple-300" : "bg-neutral-200/90 dark:bg-neutral-950/90"
      }`}>
        <WindowControls
          onClose={() => closeWindow(browserWindow.id)}
          onMinimize={() => toggleMinimizeWindow(browserWindow.id)}
          onMaximize={() => toggleMaximizeWindow(browserWindow.id)}
          isMaximized={browserWindow.isMaximized}
        />

        {/* Private Window Indicator Badge if applicable */}
        {isPrivate && (
          <div className="px-2 py-0.5 bg-purple-500/20 text-purple-300 text-[10px] font-bold rounded-full font-mono mr-2">
            PRIVATE BROWSING
          </div>
        )}

        {/* Embedded Safari Tab Bar */}
        <div className="flex-1 min-w-0">
          <TabBar />
        </div>
      </div>

      {/* Address Bar Toolbar */}
      <AddressBar />

      {/* Main Viewport Workspace: Sidebar + WebView + AI Drawer */}
      <div className="flex-1 flex overflow-hidden relative">
        <Sidebar />

        <main id="browser-main-content" className="flex-1 flex flex-col relative overflow-hidden bg-white dark:bg-neutral-900">
          <WebView />
          <FindBar />
        </main>

        <AIAssistantDrawer />
      </div>

      {/* Developer Web Inspector Dock */}
      <WebInspector />

      {/* Modals & Popovers */}
      <PrivacyDashboardModal />
      <CertificateModal />
      <DownloadManagerPopover />
      <ExtensionsPopover />
      <SettingsModal />
      <TabOverviewGrid />
      <NativeCodeExplorerModal />
    </div>
  );
}
