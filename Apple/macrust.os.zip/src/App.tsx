import React, { useState, useEffect } from 'react';
import { Header, TabType } from './components/Header';
import { LayerArchitectureView } from './components/LayerArchitectureView';
import { MacRustCli } from './components/MacRustCli';
import { Arm64ResearchVm } from './components/Arm64ResearchVm';
import { MemoryMmuView } from './components/MemoryMmuView';
import { MachOInspector } from './components/MachOInspector';
import { DriverKitExtensionsView } from './components/DriverKitExtensionsView';
import { ObservabilityDigitalTwin } from './components/ObservabilityDigitalTwin';
import { BenchmarksFaultsLab } from './components/BenchmarksFaultsLab';
import { RustCodebaseLab } from './components/RustCodebaseLab';
import { AiAssistantModal } from './components/AiAssistantModal';
import { CrashDumpInfo } from './types/macrust';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [cpuLoad, setCpuLoad] = useState<number>(18);
  const [memoryUsedMb, setMemoryUsedMb] = useState<number>(22937); // ~22.4 GB out of 36 GB
  const [memoryTotalMb] = useState<number>(36864); // 36 GB Unified Memory
  const [isVmRunning, setIsVmRunning] = useState<boolean>(true);
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);
  const [activeCrashDump, setActiveCrashDump] = useState<CrashDumpInfo | null>(null);

  // Background telemetry heartbeat
  useEffect(() => {
    const timer = setInterval(() => {
      setCpuLoad((prev) => {
        const delta = (Math.random() - 0.5) * 6;
        return Math.max(8, Math.min(88, Math.round(prev + delta)));
      });
      setMemoryUsedMb((prev) => {
        const delta = (Math.random() - 0.5) * 128;
        return Math.max(16384, Math.min(32768, Math.round(prev + delta)));
      });
    }, 2000);

    return () => clearInterval(timer);
  }, []);

  const handleDiagnoseDump = (dump: CrashDumpInfo) => {
    setActiveCrashDump(dump);
    setIsAiModalOpen(true);
  };

  const handleOpenAiAssistant = () => {
    setIsAiModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Application Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cpuLoad={cpuLoad}
        memoryUsedMb={memoryUsedMb}
        memoryTotalMb={memoryTotalMb}
        isVmRunning={isVmRunning}
        onOpenAiAssistant={handleOpenAiAssistant}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {activeTab === 'overview' && <LayerArchitectureView />}
        {activeTab === 'terminal' && <MacRustCli />}
        {activeTab === 'research-vm' && <Arm64ResearchVm />}
        {activeTab === 'memory' && <MemoryMmuView />}
        {activeTab === 'macho' && <MachOInspector />}
        {activeTab === 'driverkit' && <DriverKitExtensionsView />}
        {activeTab === 'observability' && <ObservabilityDigitalTwin />}
        {activeTab === 'benchmarks' && (
          <BenchmarksFaultsLab onDiagnoseWithAi={handleDiagnoseDump} />
        )}
        {activeTab === 'code' && <RustCodebaseLab />}
      </main>

      {/* Footer System Status Bar */}
      <footer className="border-t border-zinc-900 bg-zinc-950/80 py-3 text-xs font-mono text-zinc-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>MACRUST.OS RUST KERNEL LABORATORY FOR MACOS</span>
            <span className="text-zinc-700">|</span>
            <span className="text-zinc-400">Target: aarch64-apple-darwin</span>
          </div>
          <div className="flex items-center space-x-4">
            <span>SIP: ENABLED</span>
            <span>SECURE ENCLAVE: ACTIVE</span>
            <span>NO-STD VERIFIED: 100%</span>
          </div>
        </div>
      </footer>

      {/* AI Kernel Assistant Dialog */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        initialDump={activeCrashDump}
      />
    </div>
  );
}
