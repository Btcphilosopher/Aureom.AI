import React, { useState } from 'react';
import {
  Code2,
  Folder,
  FileCode,
  Copy,
  Check,
  Shield,
  Layers,
  Sparkles,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { RUST_SOURCE_FILES } from '../data/rustCodebase';
import { RustSourceFile } from '../types/macrust';

export const RustCodebaseLab: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<RustSourceFile>(RUST_SOURCE_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Group files by crate
  const filesByCrate = RUST_SOURCE_FILES.reduce<Record<string, RustSourceFile[]>>((acc, file) => {
    if (!acc[file.crateName]) acc[file.crateName] = [];
    acc[file.crateName].push(file);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/80 backdrop-blur flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-zinc-100 font-mono flex items-center gap-2">
            <Code2 className="w-5 h-5 text-emerald-400" />
            Rust Operating-System Source Code Laboratory
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5 font-mono">
            Modular multi-crate workspace implementing ARM64 kernel routines, Mach IPC, DriverKit FFI, and zero-allocation VFS with formal safety invariant proofs.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopy}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-mono text-xs border border-zinc-700 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'COPIED SOURCE' : 'COPY CODE'}</span>
          </button>
        </div>
      </div>

      {/* Grid: Left Crate Tree, Right Syntax Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Crate Explorer */}
        <div className="lg:col-span-4 space-y-3 font-mono text-xs">
          <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-3">
            <div className="text-xs font-bold text-zinc-300 uppercase tracking-wider border-b border-zinc-800 pb-2">
              Workspace Crates ({Object.keys(filesByCrate).length})
            </div>

            <div className="space-y-4 overflow-y-auto max-h-[600px] pr-1">
              {Object.entries(filesByCrate).map(([crateName, files]) => (
                <div key={crateName} className="space-y-1">
                  <div className="flex items-center space-x-1.5 text-emerald-400 font-bold text-[11px]">
                    <Folder className="w-3.5 h-3.5" />
                    <span>{crateName}</span>
                  </div>

                  <div className="pl-3 space-y-1 border-l border-zinc-800">
                    {files.map((f) => {
                      const isSelected = selectedFile.path === f.path;
                      return (
                        <button
                          key={f.path}
                          onClick={() => setSelectedFile(f)}
                          className={`w-full text-left p-2 rounded flex items-center justify-between text-xs transition-all ${
                            isSelected
                              ? 'bg-zinc-800 text-emerald-300 font-bold border border-zinc-700'
                              : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200'
                          }`}
                        >
                          <div className="flex items-center space-x-2 truncate">
                            <FileCode className="w-3.5 h-3.5 shrink-0" />
                            <span className="truncate">{f.fileName}</span>
                          </div>
                          {f.isNoStd && (
                            <span className="text-[9px] px-1 py-0.2 rounded bg-amber-950 text-amber-400 shrink-0">
                              no_std
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Code Viewer & Invariants */}
        <div className="lg:col-span-8 space-y-4 font-mono text-xs">
          {/* File Header Details */}
          <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/80 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-zinc-500 text-[10px]">{selectedFile.crateName}</span>
                <h3 className="text-sm font-bold text-zinc-100">{selectedFile.path}</h3>
              </div>
              <div className="flex items-center space-x-2">
                {selectedFile.isNoStd && (
                  <span className="px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800/40 text-[10px] font-bold">
                    #![no_std] Freestanding
                  </span>
                )}
                {selectedFile.hasUnsafe && (
                  <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800/40 text-[10px] font-bold">
                    Contains Unsafe Blocks (Audited)
                  </span>
                )}
              </div>
            </div>
            <p className="text-zinc-400 text-[11px] leading-relaxed">
              {selectedFile.description}
            </p>
          </div>

          {/* Code Viewer Window */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-950 overflow-hidden shadow-2xl">
            <div className="bg-zinc-900 px-4 py-2 border-b border-zinc-800 flex items-center justify-between text-[11px] text-zinc-400">
              <span>{selectedFile.fileName} — Rust 2024 Edition</span>
              <span>{selectedFile.content.split('\n').length} lines</span>
            </div>

            <div className="p-4 overflow-x-auto max-h-[500px] text-zinc-300 leading-relaxed">
              <pre className="font-mono text-xs">
                {selectedFile.content.split('\n').map((line, idx) => (
                  <div key={idx} className="table-row hover:bg-zinc-900/60">
                    <span className="table-cell pr-4 text-zinc-600 select-none text-right w-8 text-[11px]">
                      {idx + 1}
                    </span>
                    <span
                      className={`table-cell whitespace-pre ${
                        line.includes('SAFETY:') || line.includes('INVARIANT:')
                          ? 'text-emerald-400 font-bold bg-emerald-950/20'
                          : line.includes('unsafe')
                          ? 'text-amber-300 font-bold'
                          : line.startsWith('//')
                          ? 'text-zinc-500 italic'
                          : line.startsWith('pub') || line.startsWith('fn') || line.startsWith('struct') || line.startsWith('impl')
                          ? 'text-cyan-300 font-semibold'
                          : 'text-zinc-200'
                      }`}
                    >
                      {line}
                    </span>
                  </div>
                ))}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
