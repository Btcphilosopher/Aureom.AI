import React, { useState, useEffect } from 'react';
import {
  Cpu,
  Play,
  Pause,
  RotateCcw,
  FastForward,
  Activity,
  AlertTriangle,
  Flame,
  CheckCircle2,
  Clock,
  Layers,
  Zap,
} from 'lucide-react';
import {
  INITIAL_ARM64_REGISTERS,
  INITIAL_CPU_CORES,
  INITIAL_THREADS,
  BOOT_STEPS,
} from '../data/mockSystemData';
import { Arm64RegisterState, CpuCoreInfo, SchedulerAlgorithm } from '../types/macrust';

export const Arm64ResearchVm: React.FC = () => {
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [cycleCount, setCycleCount] = useState<number>(4829104);
  const [currentBootStepIdx, setCurrentBootStepIdx] = useState<number>(BOOT_STEPS.length - 1);
  const [registers, setRegisters] = useState<Arm64RegisterState>(INITIAL_ARM64_REGISTERS);
  const [cores, setCores] = useState<CpuCoreInfo[]>(INITIAL_CPU_CORES);
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<SchedulerAlgorithm>('MultiLevelFeedbackQueue');
  const [lastInterrupt, setLastInterrupt] = useState<string | null>(null);

  // Simulation tick loop
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setCycleCount((c) => c + 1400);

      // Mutate registers slightly to simulate execution
      setRegisters((prev) => {
        const nextPcInt = parseInt(prev.pc, 16) + 4;
        const nextPcHex = '0x' + (nextPcInt > 0x80004000 ? 0x80000000 : nextPcInt).toString(16).padStart(16, '0');
        const nextCntpct = '0x' + (parseInt(prev.cntpctEl0, 16) + 24).toString(16).padStart(16, '0');

        return {
          ...prev,
          pc: nextPcHex,
          cntpctEl0: nextCntpct,
          x0: '0x' + Math.floor(Math.random() * 0xffffff).toString(16).padStart(16, '0'),
          x1: '0x' + Math.floor(Math.random() * 0x1000).toString(16).padStart(16, '0'),
        };
      });

      // Fluctuate CPU utilization
      setCores((prev) =>
        prev.map((core) => {
          const delta = (Math.random() - 0.5) * 6;
          const newUtil = Math.max(10, Math.min(98, Math.round(core.utilization + delta)));
          return {
            ...core,
            utilization: newUtil,
          };
        })
      );
    }, 400);

    return () => clearInterval(interval);
  }, [isRunning]);

  const handleStepInstruction = () => {
    setCycleCount((c) => c + 1);
    setRegisters((prev) => ({
      ...prev,
      pc: '0x' + (parseInt(prev.pc, 16) + 4).toString(16).padStart(16, '0'),
    }));
  };

  const handleResetVm = () => {
    setIsRunning(false);
    setCycleCount(0);
    setCurrentBootStepIdx(0);
    setRegisters(INITIAL_ARM64_REGISTERS);
    setLastInterrupt('VM Hardware Reset Triggered');
  };

  const handleTriggerSyscall = () => {
    setRegisters((prev) => ({
      ...prev,
      x8: '0x0000000000000040', // sys_write syscall number
      x0: '0x0000000000000001', // stdout fd
      x1: '0x0000000080002100', // buffer addr
      x2: '0x0000000000000018', // len
      esrEl1: '0x0000000056000000', // SVC exception class
    }));
    setLastInterrupt('SVC #0 Syscall Triggered (Vector 0x80001000: Synchronous EL1 Entry)');
  };

  const handleTriggerTimerInterrupt = () => {
    setLastInterrupt('ARM64 Generic Timer (CNTV_CTL_EL0) IRQ #27 Triggered -> Context Switch');
  };

  return (
    <div className="space-y-6">
      {/* Top Controller Bar */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/80 backdrop-blur flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span
              className={`w-3 h-3 rounded-full ${
                isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
              }`}
            />
            <h2 className="text-lg font-bold text-zinc-100 font-mono flex items-center gap-2">
              <Cpu className="w-5 h-5 text-emerald-400" />
              ARM64 Research VM Execution Controller
            </h2>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5 font-mono">
            Target: <span className="text-zinc-200">aarch64-unknown-none</span> | Hypervisor:{' '}
            <span className="text-emerald-400">Apple Virtualization.framework</span> | Cycles:{' '}
            <span className="text-zinc-200 font-bold">{cycleCount.toLocaleString()}</span>
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded text-xs font-mono font-bold transition-all ${
              isRunning
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-emerald-500 text-zinc-950 hover:bg-emerald-400 shadow-md shadow-emerald-950/40'
            }`}
          >
            {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isRunning ? 'PAUSE VM' : 'RUN VM'}</span>
          </button>

          <button
            onClick={handleStepInstruction}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-mono border border-zinc-700"
          >
            <FastForward className="w-4 h-4" />
            <span>STEP (1 INS)</span>
          </button>

          <button
            onClick={handleResetVm}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-zinc-800 hover:bg-red-950/40 hover:text-red-300 text-zinc-300 text-xs font-mono border border-zinc-700"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RESET</span>
          </button>

          <button
            onClick={handleTriggerSyscall}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-purple-950/60 hover:bg-purple-900/60 text-purple-200 text-xs font-mono border border-purple-700/50"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>TRIGGER SVC</span>
          </button>
        </div>
      </div>

      {lastInterrupt && (
        <div className="p-3 bg-zinc-900 border border-emerald-500/40 rounded-lg flex items-center justify-between text-xs font-mono text-emerald-300">
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>{lastInterrupt}</span>
          </div>
          <button
            onClick={() => setLastInterrupt(null)}
            className="text-zinc-500 hover:text-zinc-300"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Bootloader Sequence Progression Bar */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/60 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-mono uppercase tracking-wider text-zinc-400 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Freestanding ARM64 Bootloader Pipeline (Step-by-Step Sequence)
          </h3>
          <span className="text-xs font-mono text-emerald-400 font-bold">
            STAGE {currentBootStepIdx + 1} OF {BOOT_STEPS.length} COMPLETED
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
          {BOOT_STEPS.map((step, idx) => {
            const isDone = idx <= currentBootStepIdx;
            const isCurrent = idx === currentBootStepIdx;
            return (
              <div
                key={step.stepNumber}
                onClick={() => setCurrentBootStepIdx(idx)}
                className={`p-2.5 rounded border cursor-pointer transition-all ${
                  isCurrent
                    ? 'border-emerald-500 bg-emerald-950/30 text-emerald-300'
                    : isDone
                    ? 'border-zinc-700 bg-zinc-800/60 text-zinc-300'
                    : 'border-zinc-800 bg-zinc-950/40 text-zinc-600'
                }`}
              >
                <div className="text-[10px] font-mono text-zinc-500">STAGE #{step.stepNumber}</div>
                <div className="font-bold text-xs mt-0.5">{step.title}</div>
                <div className="text-[10px] text-zinc-400 mt-1 line-clamp-1">{step.description}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid: Left ARM64 Registers, Right CPU Core Topology & Scheduler */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* ARM64 General & System Registers */}
        <div className="lg:col-span-6 p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
            <h3 className="text-sm font-bold font-mono text-zinc-100 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-emerald-400" />
              ARM64 Architecture Registers (EL1 Exception Level)
            </h3>
            <span className="text-[10px] font-mono bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded">
              64-bit Hex
            </span>
          </div>

          {/* System Control & Special Registers */}
          <div>
            <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider block mb-2 font-semibold">
              Control & Translation Registers
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="p-2 rounded bg-zinc-950/80 border border-zinc-800 flex justify-between">
                <span className="text-zinc-500">PC:</span>
                <span className="text-amber-300 font-bold">{registers.pc}</span>
              </div>
              <div className="p-2 rounded bg-zinc-950/80 border border-zinc-800 flex justify-between">
                <span className="text-zinc-500">SP_EL1:</span>
                <span className="text-cyan-300 font-bold">{registers.spEl1}</span>
              </div>
              <div className="p-2 rounded bg-zinc-950/80 border border-zinc-800 flex justify-between">
                <span className="text-zinc-500">TTBR0_EL1:</span>
                <span className="text-purple-300">{registers.ttbr0El1}</span>
              </div>
              <div className="p-2 rounded bg-zinc-950/80 border border-zinc-800 flex justify-between">
                <span className="text-zinc-500">TTBR1_EL1:</span>
                <span className="text-purple-300">{registers.ttbr1El1}</span>
              </div>
              <div className="p-2 rounded bg-zinc-950/80 border border-zinc-800 flex justify-between">
                <span className="text-zinc-500">ESR_EL1:</span>
                <span className="text-red-400">{registers.esrEl1}</span>
              </div>
              <div className="p-2 rounded bg-zinc-950/80 border border-zinc-800 flex justify-between">
                <span className="text-zinc-500">CNTPCT:</span>
                <span className="text-emerald-400">{registers.cntpctEl0}</span>
              </div>
            </div>
          </div>

          {/* General Purpose Registers X0 - X30 */}
          <div>
            <span className="text-[11px] font-mono text-zinc-400 uppercase tracking-wider block mb-2 font-semibold">
              General Purpose Registers (X0 - X15 Sample)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 text-xs font-mono">
              {Object.entries(registers)
                .filter(([k]) => k.startsWith('x') && !k.includes('El'))
                .slice(0, 15)
                .map(([reg, val]) => (
                  <div
                    key={reg}
                    className="p-1.5 rounded bg-zinc-950/40 border border-zinc-800/80 flex items-center justify-between text-[11px]"
                  >
                    <span className="text-zinc-500 font-bold uppercase">{reg}:</span>
                    <span className="text-zinc-300 truncate ml-1">{typeof val === 'string' ? `${val.slice(0, 10)}..` : '0x00000000..'}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>

        {/* CPU Topology & Scheduler Lab */}
        <div className="lg:col-span-6 space-y-6">
          {/* Apple Silicon Core Topology */}
          <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="text-sm font-bold font-mono text-zinc-100 flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                Apple Silicon Heterogeneous Core Topology
              </h3>
              <span className="text-[10px] font-mono text-zinc-400">
                12 Cores (6P + 6E)
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {cores.map((c) => {
                const isPerf = c.type === 'Performance';
                return (
                  <div
                    key={c.id}
                    className={`p-3 rounded-lg border ${
                      isPerf
                        ? 'border-amber-900/40 bg-amber-950/10'
                        : 'border-cyan-900/40 bg-cyan-950/10'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="font-bold text-zinc-200">CORE #{c.id}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                          isPerf
                            ? 'bg-amber-900/60 text-amber-300'
                            : 'bg-cyan-900/60 text-cyan-300'
                        }`}
                      >
                        {isPerf ? 'P-CORE' : 'E-CORE'}
                      </span>
                    </div>

                    <div className="mt-2 space-y-1 text-[11px] font-mono">
                      <div className="flex justify-between text-zinc-400">
                        <span>Load:</span>
                        <strong className="text-zinc-200">{c.utilization}%</strong>
                      </div>
                      <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${
                            c.utilization > 80
                              ? 'bg-red-500'
                              : isPerf
                              ? 'bg-amber-400'
                              : 'bg-cyan-400'
                          }`}
                          style={{ width: `${c.utilization}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-zinc-500 text-[10px] pt-1">
                        <span>{c.frequencyGhz} GHz</span>
                        <span>{c.tempCelsius}°C</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Scheduler Invariant & Algorithm Selector */}
          <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div>
                <h3 className="text-sm font-bold font-mono text-zinc-100 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-emerald-400" />
                  Kernel Scheduler Policy
                </h3>
              </div>
              <select
                value={selectedAlgorithm}
                onChange={(e) => setSelectedAlgorithm(e.target.value as SchedulerAlgorithm)}
                className="bg-zinc-800 border border-zinc-700 rounded px-2.5 py-1 text-xs font-mono text-zinc-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="MultiLevelFeedbackQueue">Multi-Level Feedback Queue (MLFQ)</option>
                <option value="CompletelyFairScheduler">Completely Fair Scheduler (CFS)</option>
                <option value="PriorityRoundRobin">Priority Round-Robin</option>
                <option value="WorkStealingScheduler">Work-Stealing Multi-Core</option>
                <option value="RoundRobin">Simple Round Robin</option>
              </select>
            </div>

            <div className="p-3 bg-zinc-950/60 rounded-lg border border-zinc-800 text-xs font-mono text-zinc-300 space-y-1.5">
              <div className="text-emerald-400 font-semibold">
                Active Policy: {selectedAlgorithm}
              </div>
              <div className="text-zinc-400 text-[11px] leading-relaxed">
                Allocates time-quanta based on task interactive priority, preventing starvation via
                priority aging while dynamically pinning cache-sensitive tasks to P-Cores vs E-Cores.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
