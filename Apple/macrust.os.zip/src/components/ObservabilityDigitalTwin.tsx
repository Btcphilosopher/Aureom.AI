import React, { useState, useEffect } from 'react';
import {
  Activity,
  History,
  Clock,
  Radio,
  Sliders,
  Cpu,
  HardDrive,
  Network,
  Zap,
  Flame,
  Search,
  CheckCircle2,
} from 'lucide-react';
import { SYSTEM_EVENTS } from '../data/mockSystemData';
import { SystemEvent } from '../types/macrust';

export const ObservabilityDigitalTwin: React.FC = () => {
  const [events, setEvents] = useState<SystemEvent[]>(SYSTEM_EVENTS);
  const [eventCategoryFilter, setEventCategoryFilter] = useState<string>('ALL');
  const [timeOffsetSeconds, setTimeOffsetSeconds] = useState<number>(0);
  const [cpuUsage, setCpuUsage] = useState<number>(24);
  const [memPressure, setMemPressure] = useState<number>(38);
  const [diskThroughput, setDiskThroughput] = useState<number>(340);
  const [netThroughput, setNetThroughput] = useState<number>(12.4);

  // Live telemetry pulse
  useEffect(() => {
    const timer = setInterval(() => {
      setCpuUsage((prev) => Math.max(12, Math.min(85, Math.round(prev + (Math.random() - 0.5) * 8))));
      setDiskThroughput((prev) => Math.max(80, Math.min(850, Math.round(prev + (Math.random() - 0.5) * 40))));
      setNetThroughput((prev) => +(Math.max(1.0, Math.min(50.0, prev + (Math.random() - 0.5) * 2))).toFixed(1));

      // Occasionally push a new telemetry event
      if (Math.random() > 0.6) {
        const newEvt: SystemEvent = {
          id: `evt-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString(),
          category: Math.random() > 0.5 ? 'Memory' : 'Scheduler',
          severity: 'INFO',
          source: 'macrust-kernel::telemetry',
          message: `Periodic checkpoint: Context switches 142k/sec, 0 lock contentions.`,
        };
        setEvents((prev) => [newEvt, ...prev.slice(0, 30)]);
      }
    }, 1500);

    return () => clearInterval(timer);
  }, []);

  const filteredEvents = events.filter((e) => {
    if (eventCategoryFilter === 'ALL') return true;
    return e.category === eventCategoryFilter;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Time Machine Scrubber */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/80 backdrop-blur space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-zinc-100 font-mono flex items-center gap-2">
              <Activity className="w-5 h-5 text-emerald-400" />
              Observability & OS Digital Twin Dashboard
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5 font-mono">
              High-frequency real-time kernel telemetry, event stream, and retroactive state time-travel.
            </p>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono">
            <span className="text-emerald-400 animate-pulse font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              REAL-TIME (0 ms lag)
            </span>
          </div>
        </div>

        {/* Time Travel Scrubber */}
        <div className="p-3 bg-zinc-950/80 rounded-lg border border-zinc-800 font-mono text-xs space-y-2">
          <div className="flex justify-between items-center text-zinc-400">
            <span className="flex items-center gap-1.5 font-bold text-zinc-200">
              <History className="w-4 h-4 text-purple-400" />
              OS Time Machine Snapshot Replay:
            </span>
            <span className="text-purple-300 font-bold">
              {timeOffsetSeconds === 0 ? 'NOW (LIVE STREAM)' : `T - ${timeOffsetSeconds} SECONDS AGO`}
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-[10px] text-zinc-600">-60s</span>
            <input
              type="range"
              min="0"
              max="60"
              value={timeOffsetSeconds}
              onChange={(e) => setTimeOffsetSeconds(Number(e.target.value))}
              className="flex-1 accent-purple-500 bg-zinc-800"
            />
            <span className="text-[10px] text-emerald-400 font-bold">NOW</span>
          </div>
        </div>
      </div>

      {/* Telemetry Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
        <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-2">
          <div className="flex justify-between text-zinc-400 text-xs">
            <span>CPU UTILIZATION</span>
            <Cpu className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{cpuUsage}%</div>
          <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-400 h-full transition-all duration-500" style={{ width: `${cpuUsage}%` }} />
          </div>
        </div>

        <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-2">
          <div className="flex justify-between text-zinc-400 text-xs">
            <span>UNIFIED MEM PRESSURE</span>
            <HardDrive className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{memPressure}%</div>
          <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
            <div className="bg-cyan-400 h-full transition-all duration-500" style={{ width: `${memPressure}%` }} />
          </div>
        </div>

        <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-2">
          <div className="flex justify-between text-zinc-400 text-xs">
            <span>DISK I/O BANDWIDTH</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{diskThroughput} <span className="text-xs font-normal text-zinc-400">MB/s</span></div>
          <div className="text-[10px] text-zinc-500">APFS / MacRustFS Read/Write</div>
        </div>

        <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-2">
          <div className="flex justify-between text-zinc-400 text-xs">
            <span>NETWORK THROUGHPUT</span>
            <Network className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-zinc-100">{netThroughput} <span className="text-xs font-normal text-zinc-400">MB/s</span></div>
          <div className="text-[10px] text-zinc-500">Virtual Bridge en0</div>
        </div>
      </div>

      {/* System Event Bus Live Stream */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800 pb-3">
          <div className="flex items-center space-x-2">
            <Radio className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-zinc-100">System Event Bus & Kernel Tracing Pipeline</h3>
          </div>

          {/* Filter dropdown */}
          <div className="flex items-center space-x-2">
            <span className="text-zinc-500">Filter Subsystem:</span>
            <select
              value={eventCategoryFilter}
              onChange={(e) => setEventCategoryFilter(e.target.value)}
              className="bg-zinc-800 border border-zinc-700 rounded px-2.5 py-1 text-zinc-200 text-xs focus:outline-none focus:border-emerald-500"
            >
              <option value="ALL">All Categories</option>
              <option value="Process">Process</option>
              <option value="Memory">Memory</option>
              <option value="Security">Security</option>
              <option value="Driver">Driver</option>
              <option value="Boot">Boot</option>
              <option value="Scheduler">Scheduler</option>
            </select>
          </div>
        </div>

        {/* Events Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-500 text-[11px]">
                <th className="py-2 px-2">TIME</th>
                <th className="py-2 px-2">CATEGORY</th>
                <th className="py-2 px-2">SEVERITY</th>
                <th className="py-2 px-2">SOURCE MODULE</th>
                <th className="py-2 px-2">EVENT MESSAGE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
              {filteredEvents.map((evt) => (
                <tr key={evt.id} className="hover:bg-zinc-800/40">
                  <td className="py-2 px-2 text-zinc-500">{evt.timestamp}</td>
                  <td className="py-2 px-2 text-cyan-300 font-bold">{evt.category}</td>
                  <td className="py-2 px-2">
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                        evt.severity === 'ERROR'
                          ? 'bg-red-950 text-red-300'
                          : evt.severity === 'WARN'
                          ? 'bg-amber-950 text-amber-300'
                          : 'bg-emerald-950 text-emerald-300'
                      }`}
                    >
                      {evt.severity}
                    </span>
                  </td>
                  <td className="py-2 px-2 text-purple-300 text-[11px]">{evt.source}</td>
                  <td className="py-2 px-2 text-zinc-100">{evt.message}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
