import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TermIcon, Play, CornerDownLeft, Sparkles, RefreshCw, Copy, Check } from 'lucide-react';
import {
  INITIAL_CPU_CORES,
  INITIAL_PROCESSES,
  INITIAL_THREADS,
  INITIAL_DEVICES,
  SAMPLE_MACHO_BINARIES,
  ALLOCATOR_BENCHMARKS,
  IPC_BENCHMARKS,
} from '../data/mockSystemData';

interface CommandOutput {
  id: string;
  command: string;
  output: string | React.ReactNode;
  timestamp: string;
  isError?: boolean;
}

export const MacRustCli: React.FC = () => {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState<number>(-1);
  const [isRshMode, setIsRshMode] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const initialWelcome = (
    <div className="space-y-2 font-mono text-xs">
      <div className="text-emerald-400 font-bold tracking-wider">
        MACRUST.OS [Version 1.0.0-alpha.arm64] — macOS Systems & Research Kernel Terminal
      </div>
      <div className="text-zinc-400">
        Type <span className="text-emerald-300 font-semibold">help</span> or click any quick command below to begin.
      </div>
      <div className="text-zinc-500 text-[11px]">
        Modes: <span className="text-blue-300">macrust (Host CLI)</span> | <span className="text-amber-300">rsh (Guest Research Shell)</span>
      </div>
    </div>
  );

  const [logs, setLogs] = useState<CommandOutput[]>([
    {
      id: 'init-0',
      command: 'system info --welcome',
      output: initialWelcome,
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const quickCommands = [
    'macrust system',
    'macrust cpu',
    'macrust memory',
    'macrust process',
    'macrust devices',
    'macrust security',
    'macrust drivers',
    'macrust benchmark',
    'macrust kernel boot',
    'rsh',
  ];

  const handleCommand = (rawCmd: string) => {
    const cmd = rawCmd.trim();
    if (!cmd) return;

    setHistory((prev) => [...prev, cmd]);
    setHistoryIdx(-1);

    const now = new Date().toLocaleTimeString();
    const id = `cmd-${Date.now()}-${Math.random()}`;

    // Handling 'clear'
    if (cmd === 'clear') {
      setLogs([]);
      setInput('');
      return;
    }

    // Handling 'exit' from rsh mode
    if (isRshMode && cmd === 'exit') {
      setIsRshMode(false);
      setLogs((prev) => [
        ...prev,
        {
          id,
          command: cmd,
          output: <span className="text-amber-400 font-mono text-xs">Exited Research Shell (rsh). Returned to macOS host CLI.</span>,
          timestamp: now,
        },
      ]);
      setInput('');
      return;
    }

    // If inside rsh (Guest Research Shell)
    if (isRshMode) {
      handleRshCommand(cmd, id, now);
      setInput('');
      return;
    }

    // Host CLI commands
    handleHostCommand(cmd, id, now);
    setInput('');
  };

  const handleRshCommand = (cmd: string, id: string, now: string) => {
    const parts = cmd.split(' ');
    const main = parts[0];

    let output: React.ReactNode = '';

    switch (main) {
      case 'help':
        output = (
          <div className="font-mono text-xs space-y-1 text-zinc-300">
            <div className="text-amber-400 font-bold">rsh (MACRUST Research Shell #![no_std]):</div>
            <div><strong className="text-amber-200">ls [-l]</strong>: List files in in-memory MacRustFS</div>
            <div><strong className="text-amber-200">ps</strong>: List threads and processes in research kernel</div>
            <div><strong className="text-amber-200">cat &lt;file&gt;</strong>: Read virtual file content</div>
            <div><strong className="text-amber-200">echo &lt;text&gt;</strong>: Echo string to UART console</div>
            <div><strong className="text-amber-200">mount</strong>: Show virtual filesystem mount table</div>
            <div><strong className="text-amber-200">panic [reason]</strong>: Trigger research kernel panic diagnostic</div>
            <div><strong className="text-amber-200">exit</strong>: Return to host macrust CLI</div>
          </div>
        );
        break;

      case 'ls':
        output = (
          <div className="font-mono text-xs space-y-1">
            <div className="text-zinc-500">total 5 entries (MacRustFS journaled mount /)</div>
            <div className="grid grid-cols-4 gap-2 text-zinc-300">
              <span className="text-blue-400">drwxr-xr-x bin/</span>
              <span className="text-blue-400">drwxr-xr-x dev/</span>
              <span className="text-blue-400">drwxr-xr-x etc/</span>
              <span className="text-blue-400">drwxr-xr-x proc/</span>
              <span className="text-emerald-400">-rw-r--r-- banner.txt</span>
            </div>
          </div>
        );
        break;

      case 'ps':
        output = (
          <div className="font-mono text-xs space-y-1">
            <div className="text-amber-400 font-semibold border-b border-zinc-800 pb-1">
              PID &nbsp; PPID &nbsp; STATE &nbsp;&nbsp;&nbsp; PRI &nbsp; CPU% &nbsp; MEM(MB) &nbsp; COMMAND
            </div>
            {INITIAL_PROCESSES.filter((p) => p.domain === 'ResearchKernel').map((p) => (
              <div key={p.pid} className="flex gap-4 text-zinc-300">
                <span className="w-8">{p.pid}</span>
                <span className="w-8">{p.ppid}</span>
                <span className="w-16 text-emerald-400">{p.state}</span>
                <span className="w-8">{p.priority}</span>
                <span className="w-12">{p.cpuPercent}%</span>
                <span className="w-16">{p.memoryMb}</span>
                <span className="text-zinc-100">{p.command}</span>
              </div>
            ))}
          </div>
        );
        break;

      case 'cat':
        const file = parts[1] || 'banner.txt';
        if (file.includes('banner')) {
          output = (
            <pre className="font-mono text-xs text-amber-300 whitespace-pre-wrap">
              {`========================================
MACRUST.OS RESEARCH KERNEL 0.1.0-alpha
Architecture: aarch64 (#![no_std])
Target: Bare-Metal Virtual Machine
Invariants: Verified 0 Page Table Aliases
========================================`}
            </pre>
          );
        } else {
          output = <span className="text-zinc-400 font-mono text-xs">File &apos;{file}&apos; read (0 bytes).</span>;
        }
        break;

      case 'echo':
        output = <div className="font-mono text-xs text-zinc-200">{parts.slice(1).join(' ')}</div>;
        break;

      case 'mount':
        output = (
          <div className="font-mono text-xs space-y-1 text-zinc-300">
            <div>/dev/ram0 on / type macrustfs (rw,journaled,relatime)</div>
            <div>procfs on /proc type procfs (ro)</div>
            <div>devtmpfs on /dev type devtmpfs (rw)</div>
          </div>
        );
        break;

      case 'panic':
        output = (
          <div className="p-3 bg-red-950/40 border border-red-800/60 rounded font-mono text-xs text-red-300 space-y-1">
            <div className="font-bold text-red-400">[KERNEL PANIC] Explicit kernel panic requested from rsh</div>
            <div>CPU: #0 | PC: 0x80002A40 | LR: 0x80001000 | ESR_EL1: 0x0000000056000000</div>
            <div>Backtrace: macrust_kernel::arch::panic_handler() -&gt; kernel_main()</div>
            <div className="text-zinc-400">Dump written to /var/crash/mcrash-892102.mcrash</div>
          </div>
        );
        break;

      default:
        output = <span className="text-red-400 font-mono text-xs">rsh: command not found: {cmd}. Type &apos;help&apos; for list.</span>;
    }

    setLogs((prev) => [...prev, { id, command: `rsh# ${cmd}`, output, timestamp: now }]);
  };

  const handleHostCommand = (cmd: string, id: string, now: string) => {
    const parts = cmd.split(' ');
    const main = parts[0];
    const sub = parts[1];

    let output: React.ReactNode = '';

    if (cmd === 'rsh') {
      setIsRshMode(true);
      output = (
        <div className="font-mono text-xs text-amber-300 p-2.5 rounded bg-amber-950/30 border border-amber-800/50 space-y-1">
          <div className="font-bold">Entering MACRUST.OS Freestanding Research Shell (rsh)</div>
          <div className="text-zinc-400 text-[11px]">Running inside aarch64 virtual machine environment. Type &apos;exit&apos; to return to host macOS CLI.</div>
        </div>
      );
      setLogs((prev) => [...prev, { id, command: cmd, output, timestamp: now }]);
      return;
    }

    if (main === 'help') {
      output = (
        <div className="font-mono text-xs space-y-2 text-zinc-300">
          <div className="text-emerald-400 font-bold">MACRUST.OS CLI Commands:</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1 text-[11px]">
            <div><strong className="text-zinc-100">macrust system</strong>: System architecture & platform overview</div>
            <div><strong className="text-zinc-100">macrust cpu</strong>: Apple Silicon topology & ARM64 core stats</div>
            <div><strong className="text-zinc-100">macrust memory</strong>: Unified memory, page stats & allocators</div>
            <div><strong className="text-zinc-100">macrust process</strong>: Real & research process hierarchy</div>
            <div><strong className="text-zinc-100">macrust threads</strong>: Thread state & CPU affinity breakdown</div>
            <div><strong className="text-zinc-100">macrust devices</strong>: IOKit, USB, PCI & DriverKit tree</div>
            <div><strong className="text-zinc-100">macrust security</strong>: SIP status, code signing & entitlements</div>
            <div><strong className="text-zinc-100">macrust drivers</strong>: DriverKit user-space extension status</div>
            <div><strong className="text-zinc-100">macrust extensions</strong>: Endpoint Security & NetworkExtension</div>
            <div><strong className="text-zinc-100">macrust benchmark</strong>: Run allocator & IPC benchmark suite</div>
            <div><strong className="text-zinc-100">macrust trace</strong>: System event recorder & telemetry bus</div>
            <div><strong className="text-zinc-100">macrust kernel [boot|test]</strong>: ARM64 Research kernel manager</div>
            <div><strong className="text-zinc-100">macrust macho &lt;file&gt;</strong>: Inspect Mach-O & ELF binary headers</div>
            <div><strong className="text-zinc-100">rsh</strong>: Drop into freestanding research shell</div>
            <div><strong className="text-zinc-100">clear</strong>: Clear terminal screen</div>
          </div>
        </div>
      );
    } else if (cmd === 'macrust system' || cmd === 'macrust') {
      output = (
        <pre className="font-mono text-xs text-zinc-200 whitespace-pre-wrap leading-relaxed">
{`MACRUST.OS
─────────────────────────────────────────────
Platform          macOS (Darwin 23.4.0)
Architecture      arm64 (Apple Silicon M3 Pro)
CPU Model         6 Performance Cores + 6 Efficiency Cores
Rust Toolchain    rustc 1.85.0-nightly (aarch64-apple-darwin)
Host Kernel       XNU (Darwin Kernel - Verified Real)
Research Kernel   Available (macrust-kernel #![no_std])
DriverKit         Available (User-space Driver Extensions)
System Ext.       Available (Endpoint Security / NetworkExt)
Hypervisor        Available (Apple Virtualization.framework)
Domain Status     NATIVE | EXTENSION | RESEARCH`}
        </pre>
      );
    } else if (cmd === 'macrust cpu') {
      output = (
        <div className="font-mono text-xs space-y-2">
          <div className="text-emerald-400 font-bold border-b border-zinc-800 pb-1">
            CORE ID &nbsp; TYPE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; FREQ &nbsp;&nbsp;&nbsp; LOAD &nbsp; IPC &nbsp;&nbsp; TEMP &nbsp; ACTIVE THREAD
          </div>
          {INITIAL_CPU_CORES.map((core) => (
            <div key={core.id} className="flex gap-4 text-zinc-300">
              <span className="w-8 font-bold">#{core.id}</span>
              <span className={`w-24 ${core.type === 'Performance' ? 'text-amber-300' : 'text-cyan-300'}`}>
                {core.type}
              </span>
              <span className="w-16">{core.frequencyGhz} GHz</span>
              <span className="w-12 font-semibold text-emerald-400">{core.utilization}%</span>
              <span className="w-10">{core.instructionsPerCycle}</span>
              <span className="w-12">{core.tempCelsius}°C</span>
              <span className="text-zinc-400 truncate">{core.activeProcessName || 'idle'}</span>
            </div>
          ))}
        </div>
      );
    } else if (cmd === 'macrust memory') {
      output = (
        <pre className="font-mono text-xs text-zinc-200 whitespace-pre-wrap">
{`MACRUST.OS UNIFIED MEMORY SUBSYSTEM
─────────────────────────────────────────────
Total Unified RAM:     36.00 GB (LPDDR5-6400)
Host In-Use:           22.40 GB (62.2%)
Host Free / Inactive:  13.60 GB
Page Granule:          16 KB (ARM64 Native)
Page Translation:      4-Level Translation (L0-L3)
Swap Usage:            0.00 MB / 4.00 GB

RESEARCH KERNEL HEAP ALLOCATORS (512 MB Pool):
• BumpAllocator:       185M ops/sec (0% fragmentation)
• SlabAllocator:       84M ops/sec  (4% fragmentation)
• BuddyAllocator:      42M ops/sec  (12% fragmentation)
• LinkedListAllocator: 18M ops/sec  (28% fragmentation)`}
        </pre>
      );
    } else if (cmd === 'macrust process') {
      output = (
        <div className="font-mono text-xs space-y-1">
          <div className="text-emerald-400 font-bold border-b border-zinc-800 pb-1">
            PID &nbsp; PPID &nbsp; DOMAIN &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; STATE &nbsp;&nbsp;&nbsp; CPU% &nbsp; MEM &nbsp;&nbsp; COMMAND
          </div>
          {INITIAL_PROCESSES.map((p) => (
            <div key={p.pid} className="flex gap-3 text-zinc-300">
              <span className="w-8 font-bold">{p.pid}</span>
              <span className="w-8 text-zinc-500">{p.ppid}</span>
              <span className="w-32 text-purple-300 text-[11px] truncate">{p.domain}</span>
              <span className="w-16 text-emerald-400">{p.state}</span>
              <span className="w-12">{p.cpuPercent}%</span>
              <span className="w-12">{p.memoryMb}M</span>
              <span className="text-zinc-100 truncate">{p.command}</span>
            </div>
          ))}
        </div>
      );
    } else if (cmd === 'macrust threads') {
      output = (
        <div className="font-mono text-xs space-y-1">
          <div className="text-emerald-400 font-bold border-b border-zinc-800 pb-1">
            TID &nbsp;&nbsp; PID &nbsp; PROCESS &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CORE &nbsp; STATE &nbsp;&nbsp;&nbsp; RUNTIME(ms) &nbsp; PC REG
          </div>
          {INITIAL_THREADS.map((t) => (
            <div key={t.tid} className="flex gap-3 text-zinc-300">
              <span className="w-10 font-bold">#{t.tid}</span>
              <span className="w-8 text-zinc-500">{t.pid}</span>
              <span className="w-32 text-zinc-200 truncate">{t.processName}</span>
              <span className="w-10 text-cyan-300 font-bold">Core {t.cpuCoreId}</span>
              <span className="w-14 text-emerald-400">{t.state}</span>
              <span className="w-20">{t.runtimeMs} ms</span>
              <span className="text-amber-300 font-mono text-[11px]">{t.registers.pc}</span>
            </div>
          ))}
        </div>
      );
    } else if (cmd === 'macrust devices') {
      output = (
        <div className="font-mono text-xs space-y-2">
          <div className="text-emerald-400 font-bold border-b border-zinc-800 pb-1">
            DEVICE ID &nbsp;&nbsp;&nbsp;&nbsp; CATEGORY &nbsp; PROVIDER &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; STATUS &nbsp; VENDOR:PRODUCT &nbsp; NAME
          </div>
          {INITIAL_DEVICES.map((d) => (
            <div key={d.id} className="flex gap-3 text-zinc-300">
              <span className="w-24 font-bold text-zinc-400">{d.id}</span>
              <span className="w-16 text-cyan-300">{d.category}</span>
              <span className="w-24 text-purple-300">{d.provider}</span>
              <span className="w-14 text-emerald-400">{d.status}</span>
              <span className="w-24 text-zinc-400">{d.vendorId}:{d.productId}</span>
              <span className="text-zinc-100 truncate">{d.name}</span>
            </div>
          ))}
        </div>
      );
    } else if (cmd === 'macrust security') {
      output = (
        <pre className="font-mono text-xs text-zinc-200 whitespace-pre-wrap">
{`MACRUST.OS SECURITY & ISOLATION ARCHITECTURE
─────────────────────────────────────────────
System Integrity Protection (SIP): ENABLED (Config: 0x00000000)
Secure Boot Policy:                Full Security (Apple Silicon Secure Enclave)
Code Signing Enforcement:          Hardened Runtime + Gatekeeper Active
ARM64 Pointer Authentication:      PAC (Pointer Authentication Code) Enabled
Memory Tagging Extension (MTE):    Modelled / Invariant Verified
Endpoint Security Entitlements:    com.apple.developer.endpoint-security.client [Active]
DriverKit Entitlements:            com.apple.developer.driverkit [Active]

SAFETY INVARIANT: No attempts to circumvent SIP, Secure Boot, or macOS entitlements.`}
        </pre>
      );
    } else if (cmd === 'macrust drivers' || cmd === 'macrust extensions') {
      output = (
        <pre className="font-mono text-xs text-zinc-200 whitespace-pre-wrap">
{`DRIVERKIT & SYSTEM EXTENSIONS REGISTRY (User-Space)
─────────────────────────────────────────────
1. DriverKit USB Extension:
   • Bundle ID:   com.apple.DriverKit.USBHost
   • Target:      Apple Magic Keyboard / USB HID Devices
   • Rust FFI:    IOUSBHostDevice -> macrust_driverkit::usb::DriverKitUsbDevice
   • State:       ACTIVE (User-Space Mach Service)

2. Endpoint Security Extension:
   • Bundle ID:   com.macrust.systemextension.es
   • Target:      Process execution & file integrity audit pipeline
   • Rust FFI:    es_client_t -> macrust_system_extension::es::AuditEngine
   • State:       ACTIVE (Subscribed to AUTH_EXEC, OPEN, UNLINK)`}
        </pre>
      );
    } else if (cmd === 'macrust benchmark') {
      output = (
        <div className="font-mono text-xs space-y-3">
          <div className="text-emerald-400 font-bold border-b border-zinc-800 pb-1">
            MACRUST.OS BENCHMARK RESULTS (AArch64 Apple Silicon)
          </div>
          <div>
            <div className="text-amber-300 font-semibold mb-1">Heap Allocator Performance (Operations / Second):</div>
            <div className="space-y-1">
              {ALLOCATOR_BENCHMARKS.map((a) => (
                <div key={a.allocatorName} className="flex justify-between border-b border-zinc-800/40 pb-0.5">
                  <span className="text-zinc-200 font-bold">{a.allocatorName}</span>
                  <span className="text-emerald-400 font-mono">{a.allocationSpeedOpsPerSec.toLocaleString()} alloc/s</span>
                  <span className="text-cyan-400 font-mono">avg {a.avgLatencyNs} ns</span>
                  <span className="text-zinc-400">frag: {a.fragmentationPercentage}%</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="text-blue-300 font-semibold mb-1">IPC Mechanism Latency & Throughput:</div>
            <div className="space-y-1">
              {IPC_BENCHMARKS.map((i) => (
                <div key={i.mechanism} className="flex justify-between border-b border-zinc-800/40 pb-0.5">
                  <span className="text-zinc-200 font-bold">{i.mechanism}</span>
                  <span className="text-emerald-400 font-mono">{i.throughputMbps.toLocaleString()} MB/s</span>
                  <span className="text-amber-300 font-mono">{i.latencyNs} ns latency</span>
                  <span className="text-zinc-400">{i.contextSwitchesPerSec} csw/s</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
    } else if (cmd.startsWith('macrust macho')) {
      const binary = parts[2] || 'macrust-cli';
      const info = SAMPLE_MACHO_BINARIES[binary] || SAMPLE_MACHO_BINARIES['macrust-cli'];
      output = (
        <pre className="font-mono text-xs text-zinc-200 whitespace-pre-wrap">
{`MACH-O PARSER INSPECTION: ${info.fileName}
─────────────────────────────────────────────
Magic:         ${info.header.magic}
Architecture:  ${info.header.cputype} (${info.header.cpusubtype})
File Type:     ${info.header.filetype}
Commands:      ${info.header.ncmds} load commands (${info.header.sizeofcmds} bytes)
Segments:      ${info.segments.map((s) => s.name).join(', ')}
Code Signer:   ${info.codeSignature.signer}
Team ID:       ${info.codeSignature.teamId}
Hardened RT:   ${info.codeSignature.hardenedRuntime ? 'YES' : 'NO'}`}
        </pre>
      );
    } else if (cmd.startsWith('macrust kernel')) {
      output = (
        <div className="font-mono text-xs text-emerald-300 space-y-1 p-2.5 rounded bg-emerald-950/20 border border-emerald-800/40">
          <div className="font-bold">MACRUST Freestanding Research Kernel (#![no_std])</div>
          <div>Target: aarch64-unknown-none | Status: BUILT & READY</div>
          <div>Translation Tables: TTBR0=0x80100000 | TTBR1=0x80000000 (16KB Granule)</div>
          <div>Scheduler: MultiLevelFeedbackQueue active across 8 vCPUs</div>
          <div className="text-zinc-400 text-[11px]">To run shell inside guest kernel, type: <span className="text-amber-300 font-bold">rsh</span></div>
        </div>
      );
    } else {
      output = (
        <span className="text-red-400 font-mono text-xs">
          macrust: unknown command &apos;{cmd}&apos;. Type &apos;help&apos; for list of valid commands.
        </span>
      );
    }

    setLogs((prev) => [...prev, { id, command: cmd, output, timestamp: now }]);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleCommand(input);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length > 0) {
        const nextIdx = historyIdx === -1 ? history.length - 1 : Math.max(0, historyIdx - 1);
        setHistoryIdx(nextIdx);
        setInput(history[nextIdx]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIdx !== -1) {
        const nextIdx = historyIdx + 1;
        if (nextIdx >= history.length) {
          setHistoryIdx(-1);
          setInput('');
        } else {
          setHistoryIdx(nextIdx);
          setInput(history[nextIdx]);
        }
      }
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="space-y-4">
      {/* Quick Command Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        <span className="text-xs font-mono text-zinc-500 flex items-center gap-1 shrink-0">
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          Quick Exec:
        </span>
        {quickCommands.map((q) => (
          <button
            key={q}
            onClick={() => handleCommand(q)}
            className="px-2.5 py-1 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-emerald-300 text-xs font-mono border border-zinc-800 transition-all shrink-0"
          >
            {q}
          </button>
        ))}
      </div>

      {/* Terminal Main Window */}
      <div
        className="rounded-xl border border-zinc-800 bg-zinc-950 shadow-2xl overflow-hidden flex flex-col h-[600px]"
        onClick={() => inputRef.current?.focus()}
      >
        {/* Terminal Header */}
        <div className="bg-zinc-900/90 px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-yellow-500/80 inline-block" />
            <span className="w-3 h-3 rounded-full bg-green-500/80 inline-block" />
            <span className="ml-2 text-xs font-mono text-zinc-400 flex items-center gap-1.5">
              <TermIcon className="w-3.5 h-3.5 text-emerald-400" />
              {isRshMode ? (
                <span className="text-amber-400 font-semibold">guest-vm# /bin/rsh (Research Kernel)</span>
              ) : (
                <span className="text-zinc-300">host@macbook-arm64 ~ macrust-cli</span>
              )}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setLogs([]);
              }}
              className="text-[11px] font-mono text-zinc-500 hover:text-zinc-300 px-2 py-0.5 rounded hover:bg-zinc-800"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Terminal Output Area */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 font-mono text-xs text-zinc-200">
          {logs.map((log) => (
            <div key={log.id} className="space-y-1.5 group">
              <div className="flex items-center justify-between text-zinc-500 text-[11px]">
                <div className="flex items-center space-x-2">
                  <span className={isRshMode ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
                    {log.command.startsWith('rsh#') ? '' : '> '}
                  </span>
                  <span className="text-zinc-300 font-semibold">{log.command}</span>
                </div>
                <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span>{log.timestamp}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      copyToClipboard(typeof log.output === 'string' ? log.output : log.command, log.id);
                    }}
                    className="p-1 hover:text-zinc-300"
                  >
                    {copiedId === log.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
              </div>
              <div className="pl-3 border-l-2 border-zinc-800 text-zinc-300 leading-relaxed">
                {log.output}
              </div>
            </div>
          ))}
          <div ref={terminalEndRef} />
        </div>

        {/* Terminal Input Bar */}
        <div className="p-3 bg-zinc-900/80 border-t border-zinc-800 flex items-center space-x-2 font-mono text-xs">
          <span className={isRshMode ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'}>
            {isRshMode ? 'rsh# ' : 'macrust$ '}
          </span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={isRshMode ? "Type 'ls', 'ps', 'cat banner.txt', or 'exit'..." : "Type 'macrust cpu', 'macrust memory', 'rsh'..."}
            className="flex-1 bg-transparent text-zinc-100 focus:outline-none placeholder-zinc-600 font-mono text-xs"
            autoFocus
          />
          <button
            onClick={() => handleCommand(input)}
            className="p-1.5 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 transition-colors"
          >
            <CornerDownLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
