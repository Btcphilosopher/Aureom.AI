import React, { useState } from 'react';
import {
  Cpu as Microchip,
  Shield,
  Usb,
  Radio,
  Send,
  Zap,
  Activity,
  Layers,
  CheckCircle,
  FileCode,
  HardDrive,
  RefreshCw,
} from 'lucide-react';
import { INITIAL_DEVICES, SYSTEM_EXTENSIONS } from '../data/mockSystemData';
import { DeviceInfo, SystemExtensionInfo } from '../types/macrust';

export const DriverKitExtensionsView: React.FC = () => {
  const [devices, setDevices] = useState<DeviceInfo[]>(INITIAL_DEVICES);
  const [extensions] = useState<SystemExtensionInfo[]>(SYSTEM_EXTENSIONS);
  const [selectedDevice, setSelectedDevice] = useState<DeviceInfo>(INITIAL_DEVICES[0]);
  const [ioLog, setIoLog] = useState<string[]>([
    '[DriverKit] IOUSBHostDevice initialized for vendor:0x05ac product:0x0256',
    '[EndpointSecurity] Client attached to es_client_t, listening to NOTIFY_EXEC, AUTH_OPEN',
    '[DriverKit] DMA Mapping 0x80004000 (16KB) granted to USB host ring buffer',
  ]);

  const handleSimulateAttach = () => {
    const newDev: DeviceInfo = {
      id: `usb-dev-${Math.floor(10 + Math.random() * 90)}`,
      name: 'MacRust Research Serial / Debug Dongle',
      category: 'Serial',
      provider: 'IOUSBHostDevice',
      status: 'Active',
      vendorId: '0x16c0',
      productId: '0x05dc',
      dmaMapped: true,
    };
    setDevices((prev) => [newDev, ...prev]);
    setSelectedDevice(newDev);
    setIoLog((prev) => [
      `[DriverKit] New Device Attached: ${newDev.name} (${newDev.vendorId}:${newDev.productId})`,
      `[DriverKit] Driver matching successful -> com.macrust.driverkit.serial`,
      ...prev,
    ]);
  };

  const handleSendIo = () => {
    setIoLog((prev) => [
      `[DriverKit IO] Dispatched URB Read Request to ${selectedDevice.name} (Endpoint 0x81 IN)`,
      `[DriverKit DMA] Received 64 bytes over mapped ring buffer (Status: 0x00 SUCCESS)`,
      ...prev,
    ]);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/80 backdrop-blur flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-zinc-100 font-mono flex items-center gap-2">
            <Microchip className="w-5 h-5 text-indigo-400" />
            Apple DriverKit & System Extensions Subsystem
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5 font-mono">
            Modern macOS user-space driver architecture running in isolated Mach service sandboxes — zero kernel-space panics.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleSimulateAttach}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold transition-all shadow-md shadow-indigo-950/40"
          >
            <Usb className="w-3.5 h-3.5" />
            <span>+ ATTACH HARDWARE DEVICE</span>
          </button>
        </div>
      </div>

      {/* Grid: Left DriverKit Devices Tree, Right Extension Pipeline & Sandbox I/O */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Device & DriverKit Registry */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                <Usb className="w-4 h-4 text-cyan-400" />
                DriverKit Device Registry & DMA Mappings
              </h3>
              <span className="text-zinc-500 text-[10px]">{devices.length} Devices</span>
            </div>

            <div className="space-y-2">
              {devices.map((d) => {
                const isSelected = selectedDevice.id === d.id;
                return (
                  <div
                    key={d.id}
                    onClick={() => setSelectedDevice(d)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-indigo-500 bg-indigo-950/30'
                        : 'border-zinc-800 bg-zinc-950/60 hover:bg-zinc-800/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-zinc-200">{d.name}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 text-emerald-400 font-bold">
                        {d.status}
                      </span>
                    </div>

                    <div className="flex items-center space-x-4 mt-2 text-[11px] text-zinc-400">
                      <span>Cat: <strong className="text-zinc-300">{d.category}</strong></span>
                      <span>Provider: <strong className="text-purple-300">{d.provider}</strong></span>
                      <span>VID:PID: <strong className="text-zinc-300">{d.vendorId}:{d.productId}</strong></span>
                    </div>

                    <div className="mt-2 pt-1.5 border-t border-zinc-800/60 flex items-center justify-between text-[10px]">
                      <span className="text-zinc-500">ID: {d.id}</span>
                      {d.dmaMapped && (
                        <span className="text-indigo-400 font-semibold">[DMA Mapped Ring Buffer]</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* System Extensions Audit Engine (EndpointSecurity & NetworkExtension) */}
          <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                <Shield className="w-4 h-4 text-purple-400" />
                Apple System Extensions (Endpoint Security / NetworkExt)
              </h3>
            </div>

            <div className="space-y-3">
              {extensions.map((ext) => (
                <div key={ext.identifier} className="p-3 rounded-lg bg-zinc-950/60 border border-zinc-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-purple-300">{ext.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold">
                      {ext.state}
                    </span>
                  </div>
                  <div className="text-zinc-400 text-[11px]">{ext.identifier}</div>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {ext.subscribedEvents.map((evt) => (
                      <span key={evt} className="px-1.5 py-0.5 rounded bg-zinc-800 text-cyan-300 text-[10px]">
                        {evt}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Virtual Device Sandbox & Live I/O Stream */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <div>
                <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  Driver Sandbox Hardware Digital Twin
                </h3>
                <span className="text-zinc-400 text-[11px]">Selected: {selectedDevice.name}</span>
              </div>

              <button
                onClick={handleSendIo}
                className="flex items-center space-x-1.5 px-3 py-1 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30 transition-all font-bold"
              >
                <Send className="w-3.5 h-3.5" />
                <span>DISPATCH I/O</span>
              </button>
            </div>

            {/* FFI Invariant Specs */}
            <div className="p-3 rounded-lg bg-indigo-950/20 border border-indigo-800/40 text-zinc-300 space-y-1.5 leading-relaxed text-[11px]">
              <div className="font-bold text-indigo-300">Rust &lt;-&gt; DriverKit C++ FFI Trampoline:</div>
              <div>• Trait: <code>macrust_driverkit::traits::DriverKitDevice</code></div>
              <div>• Memory: Zero-copy DMA I/O via <code>IOBufferMemoryDescriptor</code></div>
              <div>• Isolation: Crash in user-space driver does not panic macOS Darwin kernel.</div>
            </div>

            {/* Live DriverKit I/O Event Stream */}
            <div className="space-y-2">
              <div className="text-[11px] text-zinc-500 font-semibold flex items-center justify-between">
                <span>REAL-TIME DRIVERKIT EVENT LOG:</span>
                <span className="text-emerald-400 animate-pulse font-bold">● LIVE STREAM</span>
              </div>
              <div className="h-64 overflow-y-auto p-3 rounded-lg bg-zinc-950 border border-zinc-800 font-mono text-[11px] space-y-1.5 text-zinc-300">
                {ioLog.map((log, idx) => (
                  <div key={idx} className="leading-tight">
                    <span className="text-zinc-600 mr-2">[{idx + 1}]</span>
                    <span className={log.includes('IO') ? 'text-emerald-400' : log.includes('DMA') ? 'text-indigo-300' : 'text-zinc-300'}>
                      {log}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
