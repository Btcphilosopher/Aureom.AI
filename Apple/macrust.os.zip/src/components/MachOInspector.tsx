import React, { useState } from 'react';
import {
  Code2,
  FileCode,
  Shield,
  Layers,
  Search,
  CheckCircle,
  Tag,
  Binary,
  Cpu,
  Lock,
} from 'lucide-react';
import { SAMPLE_MACHO_BINARIES } from '../data/mockSystemData';
import { MachOBinaryInfo } from '../types/macrust';

export const MachOInspector: React.FC = () => {
  const [selectedKey, setSelectedKey] = useState<string>('macrust-cli');
  const [activeTab, setActiveTab] = useState<'segments' | 'symbols' | 'signature' | 'raw'>('segments');
  const [symbolSearch, setSymbolSearch] = useState<string>('');

  const currentBinary: MachOBinaryInfo = SAMPLE_MACHO_BINARIES[selectedKey] || SAMPLE_MACHO_BINARIES['macrust-cli'];

  const filteredSymbols = currentBinary.symbols.filter(
    (s) =>
      s.name.toLowerCase().includes(symbolSearch.toLowerCase()) ||
      s.demangled.toLowerCase().includes(symbolSearch.toLowerCase()) ||
      s.section.toLowerCase().includes(symbolSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Header & Binary Selector */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/80 backdrop-blur flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-zinc-100 font-mono flex items-center gap-2">
            <Code2 className="w-5 h-5 text-emerald-400" />
            Mach-O & Freestanding ELF Binary Inspector
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5 font-mono">
            Analyzes 64-bit Mach-O executable segments, dyld load commands, symbol demangling, and code signing entitlements.
          </p>
        </div>

        {/* Binary Picker */}
        <div className="flex items-center space-x-2 font-mono text-xs">
          <span className="text-zinc-500">Binary Image:</span>
          <select
            value={selectedKey}
            onChange={(e) => setSelectedKey(e.target.value)}
            className="bg-zinc-800 border border-zinc-700 rounded px-2.5 py-1.5 text-emerald-300 font-bold focus:outline-none focus:border-emerald-500"
          >
            <option value="macrust-cli">macrust-cli (Native Mach-O Executable)</option>
            <option value="macrust-kernel">macrust-kernel (Freestanding #![no_std] ELF)</option>
            <option value="macrust-driverkit">IOUSBHostDevice.dext (DriverKit Extension)</option>
            <option value="macrust-systemext">com.macrust.es.systemextension</option>
          </select>
        </div>
      </div>

      {/* Mach-O Header Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800 font-mono text-xs">
          <div className="text-[10px] text-zinc-500">MAGIC IDENTIFIER</div>
          <div className="text-sm font-bold text-emerald-400 mt-0.5">{currentBinary.header.magic}</div>
          <div className="text-[10px] text-zinc-400">MH_MAGIC_64</div>
        </div>

        <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800 font-mono text-xs">
          <div className="text-[10px] text-zinc-500">CPU ARCHITECTURE</div>
          <div className="text-sm font-bold text-cyan-300 mt-0.5">{currentBinary.header.cputype}</div>
          <div className="text-[10px] text-zinc-400">{currentBinary.header.cpusubtype}</div>
        </div>

        <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800 font-mono text-xs">
          <div className="text-[10px] text-zinc-500">FILE TYPE</div>
          <div className="text-sm font-bold text-amber-300 mt-0.5">{currentBinary.header.filetype}</div>
          <div className="text-[10px] text-zinc-400">Executable Image</div>
        </div>

        <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800 font-mono text-xs">
          <div className="text-[10px] text-zinc-500">LOAD COMMANDS</div>
          <div className="text-sm font-bold text-purple-300 mt-0.5">{currentBinary.header.ncmds} cmds</div>
          <div className="text-[10px] text-zinc-400">{currentBinary.header.sizeofcmds} bytes total</div>
        </div>

        <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800 font-mono text-xs">
          <div className="text-[10px] text-zinc-500">ENTRY POINT</div>
          <div className="text-sm font-bold text-zinc-200 mt-0.5">{currentBinary.entryPoint}</div>
          <div className="text-[10px] text-zinc-400">LC_MAIN</div>
        </div>

        <div className="p-3 rounded-lg bg-zinc-900/60 border border-zinc-800 font-mono text-xs">
          <div className="text-[10px] text-zinc-500">FILE SIZE</div>
          <div className="text-sm font-bold text-zinc-200 mt-0.5">{(currentBinary.fileSizeBytes / 1024).toFixed(1)} KB</div>
          <div className="text-[10px] text-zinc-400">{currentBinary.fileSizeBytes} bytes</div>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex border-b border-zinc-800 gap-4 text-xs font-mono">
        <button
          onClick={() => setActiveTab('segments')}
          className={`pb-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'segments'
              ? 'text-emerald-400 font-bold border-b-2 border-emerald-400'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          Segments & Sections ({currentBinary.segments.length})
        </button>

        <button
          onClick={() => setActiveTab('symbols')}
          className={`pb-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'symbols'
              ? 'text-cyan-400 font-bold border-b-2 border-cyan-400'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Binary className="w-3.5 h-3.5" />
          Symbol Table ({currentBinary.symbols.length})
        </button>

        <button
          onClick={() => setActiveTab('signature')}
          className={`pb-2 transition-all flex items-center gap-1.5 ${
            activeTab === 'signature'
              ? 'text-amber-400 font-bold border-b-2 border-amber-400'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Shield className="w-3.5 h-3.5" />
          Code Signing & Entitlements
        </button>
      </div>

      {/* Tab 1: Segments & Sections */}
      {activeTab === 'segments' && (
        <div className="space-y-4">
          {currentBinary.segments.map((seg) => (
            <div
              key={seg.name}
              className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-3 font-mono text-xs"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-800 pb-2">
                <div className="flex items-center space-x-3">
                  <span className="font-bold text-sm text-emerald-400">{seg.name}</span>
                  <span className="text-zinc-400 text-[11px]">{seg.vmaddr} - {seg.vmsize}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 rounded bg-zinc-800 text-amber-300 font-bold text-[10px]">
                    PROT: {seg.protection}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 text-[10px]">
                    FILE SIZE: {seg.filesize}
                  </span>
                </div>
              </div>

              {/* Sections in this segment */}
              <div className="space-y-1.5">
                <div className="text-[11px] text-zinc-500 font-semibold">CONTAINED SECTIONS:</div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                  {seg.sections.map((sec) => (
                    <div
                      key={sec.name}
                      className="p-2.5 rounded bg-zinc-950/60 border border-zinc-800/80 space-y-1"
                    >
                      <div className="flex justify-between text-zinc-200 font-semibold">
                        <span className="text-cyan-300">{sec.name}</span>
                        <span className="text-zinc-500 text-[10px]">align: {sec.alignment}</span>
                      </div>
                      <div className="flex justify-between text-zinc-400 text-[10px]">
                        <span>Addr: {sec.addr}</span>
                        <span>Size: {sec.size}</span>
                      </div>
                      <div className="text-[10px] text-zinc-500">Flags: {sec.flags}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Symbols Table */}
      {activeTab === 'symbols' && (
        <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800 pb-3">
            <div className="flex items-center space-x-2">
              <Binary className="w-4 h-4 text-cyan-400" />
              <h3 className="font-bold text-zinc-100">Parsed Symbol Table (LC_SYMTAB)</h3>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={symbolSearch}
                onChange={(e) => setSymbolSearch(e.target.value)}
                placeholder="Filter symbols (e.g. main, alloc)..."
                className="bg-zinc-950 border border-zinc-700 rounded pl-8 pr-3 py-1 text-zinc-200 text-xs focus:outline-none focus:border-cyan-400 w-64"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-500 text-[11px]">
                  <th className="py-2 px-2">ADDRESS</th>
                  <th className="py-2 px-2">SECTION</th>
                  <th className="py-2 px-2">TYPE</th>
                  <th className="py-2 px-2">RAW MANGLING</th>
                  <th className="py-2 px-2">DEMANGLED RUST SYMBOL</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
                {filteredSymbols.map((s, idx) => (
                  <tr key={idx} className="hover:bg-zinc-800/40">
                    <td className="py-2 px-2 text-cyan-300 font-bold">{s.address}</td>
                    <td className="py-2 px-2 text-purple-300">{s.section}</td>
                    <td className="py-2 px-2">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                        s.isExported ? 'bg-emerald-950 text-emerald-300' : 'bg-zinc-800 text-zinc-400'
                      }`}>
                        {s.isExported ? 'GLOBAL' : 'LOCAL'}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-zinc-400 text-[11px] truncate max-w-xs">{s.name}</td>
                    <td className="py-2 px-2 text-zinc-100 font-semibold">{s.demangled}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: Code Signing & Entitlements */}
      {activeTab === 'signature' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                Apple Code Signature Metadata (LC_CODE_SIGNATURE)
              </h3>
            </div>

            <div className="space-y-2.5">
              <div className="flex justify-between p-2 rounded bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500">Signer Identity:</span>
                <span className="text-emerald-400 font-bold">{currentBinary.codeSignature.signer}</span>
              </div>
              <div className="flex justify-between p-2 rounded bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500">Developer Team ID:</span>
                <span className="text-cyan-300">{currentBinary.codeSignature.teamId}</span>
              </div>
              <div className="flex justify-between p-2 rounded bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500">Hardened Runtime:</span>
                <span className="text-emerald-400 font-bold">
                  {currentBinary.codeSignature.hardenedRuntime ? 'ENABLED' : 'DISABLED'}
                </span>
              </div>
              <div className="flex justify-between p-2 rounded bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500">CS Flags (Flags Hex):</span>
                <span className="text-zinc-300">{currentBinary.codeSignature.flags}</span>
              </div>
              <div className="flex justify-between p-2 rounded bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500">Code Directory Hash (CDHash):</span>
                <span className="text-amber-300 font-mono text-[11px]">{currentBinary.codeSignature.cdHash}</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6 p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-400" />
                Embedded XML Entitlements
              </h3>
            </div>

            <div className="space-y-2">
              {currentBinary.codeSignature.entitlements.map((ent) => (
                <div
                  key={ent}
                  className="p-2.5 rounded bg-zinc-950 border border-zinc-800/80 flex items-center space-x-2 text-zinc-200"
                >
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="text-emerald-300 font-semibold">{ent}</span>
                </div>
              ))}
            </div>

            <div className="p-3 bg-zinc-950/80 rounded-lg border border-zinc-800 text-[11px] text-zinc-400 leading-relaxed">
              Enforced by Darwin XNU kernel and Gatekeeper at launch time before mapping pages into the user address space.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
