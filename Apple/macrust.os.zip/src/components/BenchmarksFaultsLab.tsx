import React, { useState } from 'react';
import {
  Zap,
  AlertTriangle,
  Flame,
  Shield,
  Activity,
  Sparkles,
  Layers,
  ArrowRight,
  HardDrive,
  Cpu,
  RotateCcw,
} from 'lucide-react';
import { ALLOCATOR_BENCHMARKS, IPC_BENCHMARKS } from '../data/mockSystemData';
import { CrashDumpInfo } from '../types/macrust';

interface BenchmarksFaultsLabProps {
  onDiagnoseWithAi: (dump: CrashDumpInfo) => void;
}

export const BenchmarksFaultsLab: React.FC<BenchmarksFaultsLabProps> = ({ onDiagnoseWithAi }) => {
  const [activeTab, setActiveTab] = useState<'benchmarks' | 'faults' | 'dump'>('benchmarks');
  const [lastDump, setLastDump] = useState<CrashDumpInfo | null>(null);
  const [isInjecting, setIsInjecting] = useState<boolean>(false);

  const handleInjectFault = async (faultType: 'PAGE_FAULT' | 'OOM_PANIC' | 'STACK_OVERFLOW' | 'DEADLOCK_DETECTED') => {
    setIsInjecting(true);
    try {
      const res = await fetch('/api/fault/inject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ faultType }),
      });
      const data = await res.json();
      if (data.crashDump) {
        setLastDump(data.crashDump);
        setActiveTab('dump');
      }
    } catch {
      // Fallback local dump generation
      const mockDump: CrashDumpInfo = {
        dumpId: `mcrash-${Math.floor(100000 + Math.random() * 900000)}`,
        timestamp: new Date().toISOString(),
        kernelVersion: 'MACRUST-RESEARCH-0.1.0-aarch64',
        panicReason: `Kernel Panic: Injected ${faultType}`,
        cpuId: 0,
        faultAddress: '0x0000000000000008',
        esrEl1: '0x0000000096000004',
        registers: {} as any,
        stackBacktrace: [
          '0x0000000100001000: macrust_kernel::memory::virtual_mem::handle_page_fault',
          '0x00000001000024A0: macrust_kernel::arch::aarch64::exception_vector_el1_sync',
          '0x0000000100004810: macrust_kernel::process::spawn_task',
          '0x0000000100000100: kernel_main',
        ],
        activeProcess: 'research-init (PID 303)',
        activeThreadTid: 1001,
        memoryMapState: 'TTBR0: 0x80100000 | TTBR1: 0x80000000 | Free Pages: 0 / 32768',
      };
      setLastDump(mockDump);
      setActiveTab('dump');
    } finally {
      setIsInjecting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/80 backdrop-blur flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-zinc-100 font-mono flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            System Benchmarking & Kernel Fault Injection Lab
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5 font-mono">
            Execute stress benchmarks and safely simulate kernel exceptions, panics, and .mcrash dump diagnostics.
          </p>
        </div>

        {/* Sub-tabs */}
        <div className="flex bg-zinc-950 p-1 rounded-lg border border-zinc-800 font-mono text-xs">
          <button
            onClick={() => setActiveTab('benchmarks')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'benchmarks'
                ? 'bg-zinc-800 text-amber-300 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Performance Benchmarks
          </button>
          <button
            onClick={() => setActiveTab('faults')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'faults'
                ? 'bg-zinc-800 text-red-400 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Fault Injector
          </button>
          <button
            onClick={() => setActiveTab('dump')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'dump'
                ? 'bg-zinc-800 text-purple-300 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Crash Dump (.mcrash) {lastDump && <span className="ml-1 text-emerald-400">●</span>}
          </button>
        </div>
      </div>

      {/* Tab 1: Benchmarks */}
      {activeTab === 'benchmarks' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Allocator Benchmarks */}
          <div className="lg:col-span-6 p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-emerald-400" />
                Heap Allocator Throughput (Ops / Sec)
              </h3>
            </div>

            <div className="space-y-3">
              {ALLOCATOR_BENCHMARKS.map((a) => (
                <div key={a.allocatorName} className="p-3 rounded-lg bg-zinc-950/60 border border-zinc-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-zinc-200">{a.allocatorName}</span>
                    <span className="text-emerald-400 font-bold">
                      {a.allocationSpeedOpsPerSec.toLocaleString()} ops/sec
                    </span>
                  </div>
                  <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-400 h-full"
                      style={{ width: `${(a.allocationSpeedOpsPerSec / 185000000) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-zinc-400">
                    <span>Latency: {a.avgLatencyNs} ns</span>
                    <span>Frag: {a.fragmentationPercentage}%</span>
                    <span className="text-purple-300">{a.timeComplexity}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* IPC Latency & Throughput */}
          <div className="lg:col-span-6 p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                IPC Mechanism Latency & Throughput
              </h3>
            </div>

            <div className="space-y-3">
              {IPC_BENCHMARKS.map((i) => (
                <div key={i.mechanism} className="p-3 rounded-lg bg-zinc-950/60 border border-zinc-800 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-zinc-200">{i.mechanism}</span>
                    <span className="text-cyan-400 font-bold">
                      {i.throughputMbps.toLocaleString()} MB/s
                    </span>
                  </div>
                  <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-cyan-400 h-full"
                      style={{ width: `${(i.throughputMbps / 14800) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-zinc-400">
                    <span>Latency: <strong className="text-amber-300">{i.latencyNs} ns</strong></span>
                    <span>Context Switches: {i.contextSwitchesPerSec.toLocaleString()} /s</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Fault Injector */}
      {activeTab === 'faults' && (
        <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
          <div className="border-b border-zinc-800 pb-3">
            <h3 className="font-bold text-red-400 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Kernel Fault Injection & Panic Simulation Engine
            </h3>
            <p className="text-zinc-400 text-[11px] mt-0.5">
              Inject hardware exceptions and memory violations into the isolated ARM64 research virtual machine to test panic handlers and dump generation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div className="font-bold text-zinc-200 text-sm">1. Null Pointer Dereference (Page Fault)</div>
              <p className="text-zinc-400 text-[11px] leading-relaxed">
                Attempts to read from address 0x0000000000000008, triggering ARM64 Data Abort at EL1 with ESR_EL1=0x96000004.
              </p>
              <button
                disabled={isInjecting}
                onClick={() => handleInjectFault('PAGE_FAULT')}
                className="w-full py-2 rounded bg-red-950 hover:bg-red-900 text-red-200 font-bold border border-red-800/60 transition-colors"
              >
                INJECT PAGE FAULT
              </button>
            </div>

            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div className="font-bold text-zinc-200 text-sm">2. Physical Frame Exhaustion (OOM Panic)</div>
              <p className="text-zinc-400 text-[11px] leading-relaxed">
                Simulates PMM bitmap exhaustion when allocating critical interrupt vector table frames.
              </p>
              <button
                disabled={isInjecting}
                onClick={() => handleInjectFault('OOM_PANIC')}
                className="w-full py-2 rounded bg-amber-950 hover:bg-amber-900 text-amber-200 font-bold border border-amber-800/60 transition-colors"
              >
                INJECT OOM PANIC
              </button>
            </div>

            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div className="font-bold text-zinc-200 text-sm">3. Kernel Stack Guard Page Overflow</div>
              <p className="text-zinc-400 text-[11px] leading-relaxed">
                Recursive stack growth hits the non-present 16KB guard page located immediately below the thread kernel stack.
              </p>
              <button
                disabled={isInjecting}
                onClick={() => handleInjectFault('STACK_OVERFLOW')}
                className="w-full py-2 rounded bg-purple-950 hover:bg-purple-900 text-purple-200 font-bold border border-purple-800/60 transition-colors"
              >
                INJECT STACK OVERFLOW
              </button>
            </div>

            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3">
              <div className="font-bold text-zinc-200 text-sm">4. Multi-Core Deadlock Cycle Detection</div>
              <p className="text-zinc-400 text-[11px] leading-relaxed">
                Triggers circular dependency between SpinLock #12 (VFS) and SpinLock #4 (Scheduler RunQueue).
              </p>
              <button
                disabled={isInjecting}
                onClick={() => handleInjectFault('DEADLOCK_DETECTED')}
                className="w-full py-2 rounded bg-indigo-950 hover:bg-indigo-900 text-indigo-200 font-bold border border-indigo-800/60 transition-colors"
              >
                INJECT DEADLOCK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Crash Dump (.mcrash) Viewer */}
      {activeTab === 'dump' && (
        <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800 pb-3">
            <div>
              <h3 className="font-bold text-red-400 flex items-center gap-2">
                <Flame className="w-4 h-4" />
                Kernel Crash Dump Inspector ({lastDump ? lastDump.dumpId : 'No dump loaded'})
              </h3>
              <p className="text-zinc-400 text-[11px] mt-0.5">
                Parsed MACRUST .mcrash kernel crash artifact with backtrace symbolication and register frame.
              </p>
            </div>

            {lastDump && (
              <button
                onClick={() => onDiagnoseWithAi(lastDump)}
                className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold transition-all shadow-md shadow-emerald-950/40"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI KERNEL DIAGNOSIS</span>
              </button>
            )}
          </div>

          {lastDump ? (
            <div className="space-y-4">
              <div className="p-3 rounded-lg bg-red-950/30 border border-red-800/50 space-y-1">
                <div className="text-red-300 font-bold">{lastDump.panicReason}</div>
                <div className="text-zinc-400 text-[11px]">
                  Fault Address: <strong className="text-amber-300">{lastDump.faultAddress}</strong> | ESR_EL1: <strong className="text-cyan-300">{lastDump.esrEl1}</strong> | CPU: #{lastDump.cpuId}
                </div>
              </div>

              {/* Stack Backtrace */}
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 space-y-2">
                <div className="text-zinc-500 font-bold text-[11px]">STACK BACKTRACE (FRAME POINTER SYMBOLIC WALK):</div>
                <div className="space-y-1">
                  {lastDump.stackBacktrace.map((frame, idx) => (
                    <div key={idx} className="text-zinc-300 flex space-x-2">
                      <span className="text-zinc-600">#{idx}</span>
                      <span className="text-emerald-400">{frame}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Memory Map & Thread Context */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 space-y-1">
                  <div className="text-zinc-500 text-[11px]">ACTIVE PROCESS & THREAD</div>
                  <div className="text-zinc-200 font-bold">{lastDump.activeProcess} (TID {lastDump.activeThreadTid})</div>
                </div>
                <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 space-y-1">
                  <div className="text-zinc-500 text-[11px]">MEMORY STATE AT CRASH</div>
                  <div className="text-purple-300 font-bold">{lastDump.memoryMapState}</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-zinc-500 space-y-2">
              <AlertTriangle className="w-8 h-8 mx-auto text-zinc-600" />
              <div>No crash dump generated yet.</div>
              <button
                onClick={() => handleInjectFault('PAGE_FAULT')}
                className="px-3 py-1 rounded bg-zinc-800 text-zinc-300 hover:text-white mt-2"
              >
                Inject Sample Page Fault
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
