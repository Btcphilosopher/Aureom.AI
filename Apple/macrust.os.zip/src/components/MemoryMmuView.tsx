import React, { useState } from 'react';
import {
  HardDrive,
  Layers,
  Zap,
  Shield,
  ArrowRight,
  Database,
  Cpu,
  RefreshCw,
  Sliders,
  CheckCircle2,
} from 'lucide-react';
import {
  SAMPLE_PAGE_TABLE_DESCRIPTORS,
  ALLOCATOR_BENCHMARKS,
} from '../data/mockSystemData';
import { PageTableDescriptor } from '../types/macrust';

export const MemoryMmuView: React.FC = () => {
  const [sampleVa, setSampleVa] = useState<string>('0x0000000100042000');
  const [descriptors] = useState<PageTableDescriptor[]>(SAMPLE_PAGE_TABLE_DESCRIPTORS);
  const [selectedAllocator, setSelectedAllocator] = useState<string>('SlabAllocator');
  const [activeTab, setActiveTab] = useState<'mmu' | 'pmm' | 'allocators' | 'vmmap'>('mmu');

  // Simulated PMM frame allocation bitmap (32x8 = 256 sample frames visualized)
  const [frameStates, setFrameStates] = useState<boolean[]>(() => {
    const initial = new Array(128).fill(false);
    // Mark kernel reserved frames as allocated
    for (let i = 0; i < 42; i++) initial[i] = true;
    return initial;
  });

  const handleAllocateFrame = () => {
    const nextFreeIdx = frameStates.findIndex((f) => !f);
    if (nextFreeIdx !== -1) {
      setFrameStates((prev) => {
        const next = [...prev];
        next[nextFreeIdx] = true;
        return next;
      });
    }
  };

  const handleFreeFrame = () => {
    // Free the highest allocated user frame (> 42)
    for (let i = frameStates.length - 1; i >= 42; i--) {
      if (frameStates[i]) {
        setFrameStates((prev) => {
          const next = [...prev];
          next[i] = false;
          return next;
        });
        break;
      }
    }
  };

  // Decode virtual address into 4-level translation components (16KB granule)
  const parseVa = (vaHex: string) => {
    try {
      const cleanHex = vaHex.replace('0x', '');
      const num = BigInt('0x' + cleanHex);
      const offset = Number(num & BigInt(0x3fff)); // 14-bit offset (16KB)
      const l3 = Number((num >> BigInt(14)) & BigInt(0x7ff)); // 11 bits
      const l2 = Number((num >> BigInt(25)) & BigInt(0x7ff)); // 11 bits
      const l1 = Number((num >> BigInt(36)) & BigInt(0x7ff)); // 11 bits
      const l0 = Number((num >> BigInt(47)) & BigInt(0x1)); // 1 bit
      return { offset, l3, l2, l1, l0, isValid: true };
    } catch {
      return { offset: 0, l3: 0, l2: 0, l1: 0, l0: 0, isValid: false };
    }
  };

  const vaParsed = parseVa(sampleVa);
  const calculatedPa = `0x0000000080${vaParsed.l3.toString(16).padStart(4, '0')}${vaParsed.offset.toString(16).padStart(4, '0')}`;

  return (
    <div className="space-y-6">
      {/* Top Header & Sub-Navigation */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/80 backdrop-blur flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-zinc-100 font-mono flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-cyan-400" />
            ARM64 Memory Subsystem & MMU Page Translation
          </h2>
          <p className="text-xs text-zinc-400 mt-0.5 font-mono">
            Granule: <span className="text-cyan-300 font-bold">16 KB</span> | Translation:{' '}
            <span className="text-emerald-400 font-bold">4-Level (L0-L3)</span> | Physical Range:{' '}
            <span className="text-zinc-200">0x80000000 - 0x90000000 (512 MB Pool)</span>
          </p>
        </div>

        {/* Sub-tabs */}
        <div className="flex bg-zinc-950 p-1 rounded-lg border border-zinc-800 font-mono text-xs">
          <button
            onClick={() => setActiveTab('mmu')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'mmu'
                ? 'bg-zinc-800 text-cyan-300 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            MMU Translation Table
          </button>
          <button
            onClick={() => setActiveTab('pmm')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'pmm'
                ? 'bg-zinc-800 text-emerald-300 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            PMM Frame Bitmap
          </button>
          <button
            onClick={() => setActiveTab('allocators')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'allocators'
                ? 'bg-zinc-800 text-amber-300 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Heap Allocator Benchmark
          </button>
          <button
            onClick={() => setActiveTab('vmmap')}
            className={`px-3 py-1.5 rounded transition-all ${
              activeTab === 'vmmap'
                ? 'bg-zinc-800 text-purple-300 font-semibold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Address Space Layout
          </button>
        </div>
      </div>

      {/* Tab 1: MMU 4-Level Page Table Translation Visualizer */}
      {activeTab === 'mmu' && (
        <div className="space-y-6">
          {/* Virtual Address Input & Translation Pipeline */}
          <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800 pb-3">
              <span className="font-bold text-zinc-100 uppercase tracking-wider flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                Virtual Address (VA) Translation Pipeline
              </span>
              <div className="flex items-center gap-2">
                <span className="text-zinc-500">Input VA:</span>
                <input
                  type="text"
                  value={sampleVa}
                  onChange={(e) => setSampleVa(e.target.value)}
                  className="bg-zinc-950 border border-zinc-700 rounded px-2.5 py-1 text-cyan-300 font-bold focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            {/* 4-Level Box Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">LEVEL 0 (1-bit)</div>
                <div className="text-base font-bold text-purple-400 mt-1">L0: {vaParsed.l0}</div>
                <div className="text-[10px] text-zinc-400 mt-1">TTBR0_EL1 Base Descriptor</div>
              </div>

              <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">LEVEL 1 (11-bit)</div>
                <div className="text-base font-bold text-blue-400 mt-1">L1 Index: {vaParsed.l1}</div>
                <div className="text-[10px] text-zinc-400 mt-1">1GB Table Descriptor</div>
              </div>

              <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">LEVEL 2 (11-bit)</div>
                <div className="text-base font-bold text-emerald-400 mt-1">L2 Index: {vaParsed.l2}</div>
                <div className="text-[10px] text-zinc-400 mt-1">32MB Table Descriptor</div>
              </div>

              <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">LEVEL 3 (11-bit)</div>
                <div className="text-base font-bold text-amber-400 mt-1">L3 Index: {vaParsed.l3}</div>
                <div className="text-[10px] text-zinc-400 mt-1">16KB Page Descriptor</div>
              </div>

              <div className="p-3 rounded-lg bg-zinc-950/80 border border-zinc-800">
                <div className="text-[10px] text-zinc-500">OFFSET (14-bit)</div>
                <div className="text-base font-bold text-cyan-400 mt-1">Offset: 0x{vaParsed.offset.toString(16)}</div>
                <div className="text-[10px] text-zinc-400 mt-1">Byte Index into 16KB Page</div>
              </div>
            </div>

            {/* Translation Result Banner */}
            <div className="p-3 bg-emerald-950/20 border border-emerald-800/40 rounded-lg flex items-center justify-between text-xs">
              <div className="flex items-center space-x-3">
                <span className="text-zinc-400">Translated Physical Address (PA):</span>
                <span className="text-emerald-400 font-bold font-mono text-sm">{calculatedPa}</span>
              </div>
              <span className="text-zinc-500 text-[11px]">Attributes: Normal Memory, Inner/Outer WB-WA, UXN=1</span>
            </div>
          </div>

          {/* Descriptors Table */}
          <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-3 font-mono text-xs">
            <h3 className="font-bold text-zinc-200">Active Translation Table Descriptors (TTBR0/1)</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-500 text-[11px]">
                    <th className="py-2 px-2">VIRTUAL ADDRESS</th>
                    <th className="py-2 px-2">PHYSICAL ADDRESS</th>
                    <th className="py-2 px-2">SIZE</th>
                    <th className="py-2 px-2">LEVEL</th>
                    <th className="py-2 px-2">PERMISSIONS</th>
                    <th className="py-2 px-2">FLAGS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
                  {descriptors.map((d) => (
                    <tr key={d.virtualAddress} className="hover:bg-zinc-800/40">
                      <td className="py-2 px-2 text-cyan-300 font-bold">{d.virtualAddress}</td>
                      <td className="py-2 px-2 text-emerald-400">{d.physicalAddress}</td>
                      <td className="py-2 px-2">{d.sizeKb} KB</td>
                      <td className="py-2 px-2 text-purple-300">Level {d.level}</td>
                      <td className="py-2 px-2 font-bold text-amber-300">{d.permissions}</td>
                      <td className="py-2 px-2 text-zinc-400 text-[11px]">
                        {d.isCoW && <span className="mr-1.5 text-blue-400">[CoW]</span>}
                        {d.isGuardPage && <span className="mr-1.5 text-red-400">[GUARD]</span>}
                        {d.isAllocated ? 'PRESENT' : 'UNMAPPED'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: PMM Physical Memory Manager Frame Bitmap */}
      {activeTab === 'pmm' && (
        <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-zinc-800 pb-3">
            <div>
              <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-400" />
                Physical Memory Manager (PMM) 16KB Frame Bitmap
              </h3>
              <p className="text-zinc-400 text-[11px] mt-0.5">
                Total Frames: 32,768 (512 MB Pool) | Allocated: {frameStates.filter(Boolean).length} | Free: {frameStates.filter((f) => !f).length}
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleAllocateFrame}
                className="px-3 py-1.5 rounded bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs"
              >
                + ALLOC 1 FRAME (16KB)
              </button>
              <button
                onClick={handleFreeFrame}
                className="px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs border border-zinc-700"
              >
                - FREE FRAME
              </button>
            </div>
          </div>

          {/* Visual Grid of 128 Sample Frames */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] text-zinc-500">
              <span>Frame Sample Grid (128 Frames x 16 KB = 2 MB Sample Window):</span>
              <div className="flex items-center space-x-3">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 bg-emerald-500 rounded-sm" /> Kernel / User Allocated
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 bg-zinc-800 rounded-sm" /> Free Frame
                </span>
              </div>
            </div>

            <div className="grid grid-cols-16 sm:grid-cols-32 gap-1 p-3 bg-zinc-950 rounded-lg border border-zinc-800">
              {frameStates.map((isAllocated, idx) => (
                <div
                  key={idx}
                  title={`Frame #${idx} (PA: 0x8000${(idx * 4).toString(16).padStart(4, '0')}000) - ${isAllocated ? 'ALLOCATED' : 'FREE'}`}
                  className={`h-4 rounded-sm transition-all cursor-pointer ${
                    isAllocated
                      ? idx < 42
                        ? 'bg-purple-600 hover:bg-purple-500'
                        : 'bg-emerald-500 hover:bg-emerald-400'
                      : 'bg-zinc-800 hover:bg-zinc-700'
                  }`}
                />
              ))}
            </div>
            <div className="text-[11px] text-zinc-500 text-right">
              Purple: Kernel Reserved Boot Frames | Green: Dynamic User Frames
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Heap Allocators Benchmark */}
      {activeTab === 'allocators' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-12 p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
            <div className="border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-zinc-100 flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                Rust Kernel Heap Allocator Performance Comparison
              </h3>
              <p className="text-zinc-400 text-[11px] mt-0.5">
                Benchmarked under 100,000 multi-threaded malloc/free cycles on Apple Silicon ARM64.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {ALLOCATOR_BENCHMARKS.map((a) => {
                const isSelected = selectedAllocator === a.allocatorName;
                return (
                  <div
                    key={a.allocatorName}
                    onClick={() => setSelectedAllocator(a.allocatorName)}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'border-amber-500/80 bg-amber-950/20 shadow-lg'
                        : 'border-zinc-800 bg-zinc-950/60 hover:bg-zinc-800/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-zinc-100">{a.allocatorName}</span>
                      <span className="text-[10px] text-amber-400 font-bold">
                        {a.fragmentationPercentage}% frag
                      </span>
                    </div>

                    <div className="mt-3 space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Throughput:</span>
                        <strong className="text-emerald-400">
                          {a.allocationSpeedOpsPerSec.toLocaleString()} ops/s
                        </strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Avg Latency:</span>
                        <strong className="text-cyan-400">{a.avgLatencyNs} ns</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Complexity:</span>
                        <span className="text-purple-300 font-bold">{a.timeComplexity}</span>
                      </div>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-zinc-800/80 text-[11px] text-zinc-400">
                      Best for: {a.bestFor}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Virtual Address Space Layout */}
      {activeTab === 'vmmap' && (
        <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/70 space-y-4 font-mono text-xs">
          <div className="border-b border-zinc-800 pb-3">
            <h3 className="font-bold text-zinc-100 flex items-center gap-2">
              <Shield className="w-4 h-4 text-purple-400" />
              64-bit Address Space Canonical Layout (TTBR0 vs TTBR1)
            </h3>
            <p className="text-zinc-400 text-[11px] mt-0.5">
              Strict isolation: Kernel addresses reside in high memory (TTBR1_EL1), user tasks in low memory (TTBR0_EL1).
            </p>
          </div>

          <div className="space-y-3">
            <div className="p-3 rounded-lg bg-red-950/20 border border-red-800/40 flex justify-between items-center">
              <div>
                <span className="text-red-400 font-bold">0xFFFFFFFFFFFFFFFF - 0xFFFF800000000000</span>
                <div className="text-[11px] text-zinc-400">Kernel High Virtual Memory (TTBR1_EL1) - Exception Vectors, MMIO, Heap</div>
              </div>
              <span className="px-2 py-0.5 rounded bg-red-900/40 text-red-300 font-bold text-[10px]">KERNEL (EL1)</span>
            </div>

            <div className="p-2 text-center text-zinc-600 text-[11px]">
              ──────────────── Unmapped Non-Canonical Guard Gap (2^48 - 256TB) ────────────────
            </div>

            <div className="p-3 rounded-lg bg-blue-950/20 border border-blue-800/40 flex justify-between items-center">
              <div>
                <span className="text-blue-400 font-bold">0x00007FFFFFFFFFFF - 0x0000000000000000</span>
                <div className="text-[11px] text-zinc-400">User Space Task Memory (TTBR0_EL1) - Stack, Heap, Mach-O Image, Dyld Cache</div>
              </div>
              <span className="px-2 py-0.5 rounded bg-blue-900/40 text-blue-300 font-bold text-[10px]">USER (EL0)</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
