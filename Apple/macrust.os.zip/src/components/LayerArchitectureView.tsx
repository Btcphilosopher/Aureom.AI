import React, { useState } from 'react';
import { SYSTEM_LAYERS } from '../data/mockSystemData';
import { ImplementationDomain, SystemLayer } from '../types/macrust';
import { Shield, Layers, ChevronRight, Cpu, HardDrive, Terminal, Lock, Network, Share2 } from 'lucide-react';

export const LayerArchitectureView: React.FC = () => {
  const [selectedLayer, setSelectedLayer] = useState<SystemLayer>(SYSTEM_LAYERS[0]);
  const [selectedDomainFilter, setSelectedDomainFilter] = useState<ImplementationDomain | 'ALL'>('ALL');

  const filteredLayers = SYSTEM_LAYERS.filter((layer) => {
    if (selectedDomainFilter === 'ALL') return true;
    return layer.domains.includes(selectedDomainFilter);
  });

  const getDomainBadge = (domain: ImplementationDomain) => {
    switch (domain) {
      case 'NativeMacOS':
        return (
          <span
            key={domain}
            className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-950/80 text-blue-300 border border-blue-800/60"
          >
            NATIVE (XNU/Darwin)
          </span>
        );
      case 'AppleSystemExtension':
        return (
          <span
            key={domain}
            className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-950/80 text-purple-300 border border-purple-800/60"
          >
            EXTENSION (SystemExt)
          </span>
        );
      case 'DriverKit':
        return (
          <span
            key={domain}
            className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-950/80 text-indigo-300 border border-indigo-800/60"
          >
            DRIVERKIT (User-Space)
          </span>
        );
      case 'ResearchKernel':
        return (
          <span
            key={domain}
            className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/80 text-amber-300 border border-amber-800/60"
          >
            RESEARCH (Rust #![no_std])
          </span>
        );
      case 'VirtualMachine':
        return (
          <span
            key={domain}
            className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-800/60"
          >
            VM (Apple Virtualization)
          </span>
        );
      default:
        return (
          <span
            key={domain}
            className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-zinc-800 text-zinc-300"
          >
            {domain}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Architectural Axiom */}
      <div className="p-5 rounded-xl border border-zinc-800 bg-zinc-900/60 backdrop-blur">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-zinc-100 flex items-center gap-2.5">
              <Layers className="w-5 h-5 text-emerald-400" />
              13-Layer Computing Platform Hierarchy (Layer 0 – 12)
            </h2>
            <p className="text-sm text-zinc-400 mt-1 max-w-3xl">
              MACRUST.OS maps the full stack of modern Apple Silicon & macOS
              computing — strictly separating native XNU runtime, Apple user-space
              System Extensions & DriverKit, and the standalone Rust research
              kernel running in a sandboxed ARM64 VM.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-zinc-500">Filter Domain:</span>
            <select
              value={selectedDomainFilter}
              onChange={(e) =>
                setSelectedDomainFilter(e.target.value as ImplementationDomain | 'ALL')
              }
              className="bg-zinc-800 border border-zinc-700 rounded px-2.5 py-1 text-zinc-200 focus:outline-none focus:border-emerald-500"
            >
              <option value="ALL">All Domains</option>
              <option value="NativeMacOS">Native macOS (XNU/Darwin)</option>
              <option value="AppleSystemExtension">Apple System Extensions</option>
              <option value="DriverKit">Apple DriverKit</option>
              <option value="ResearchKernel">Rust Research Kernel</option>
              <option value="VirtualMachine">Virtual Machine</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid: Left side layer stack, Right side layer details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Layer Stack Column */}
        <div className="lg:col-span-6 space-y-2.5">
          {filteredLayers.map((layer) => {
            const isSelected = selectedLayer.id === layer.id;
            return (
              <div
                key={layer.id}
                onClick={() => setSelectedLayer(layer)}
                className={`p-3.5 rounded-lg border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-emerald-500/80 bg-zinc-800/90 shadow-lg shadow-emerald-950/20'
                    : 'border-zinc-800/80 bg-zinc-900/40 hover:bg-zinc-800/50 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span
                      className={`w-7 h-7 rounded flex items-center justify-center font-mono font-bold text-xs ${
                        isSelected
                          ? 'bg-emerald-500 text-zinc-950'
                          : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      L{layer.id}
                    </span>
                    <div>
                      <h4
                        className={`text-sm font-semibold ${
                          isSelected ? 'text-emerald-300' : 'text-zinc-200'
                        }`}
                      >
                        {layer.name}
                      </h4>
                      <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">
                        {layer.description}
                      </p>
                    </div>
                  </div>
                  <ChevronRight
                    className={`w-4 h-4 transition-transform ${
                      isSelected
                        ? 'text-emerald-400 translate-x-1'
                        : 'text-zinc-600'
                    }`}
                  />
                </div>

                <div className="flex flex-wrap gap-1.5 mt-2.5 pt-2 border-t border-zinc-800/60">
                  {layer.domains.map(getDomainBadge)}
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Layer Deep-Dive Column */}
        <div className="lg:col-span-6">
          <div className="p-6 rounded-xl border border-zinc-800 bg-zinc-900/80 sticky top-24 space-y-5">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <div>
                <span className="text-xs font-mono text-emerald-400 uppercase tracking-wider">
                  Subsystem Specification
                </span>
                <h3 className="text-lg font-bold text-zinc-100 mt-0.5">
                  {selectedLayer.name}
                </h3>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-mono bg-zinc-800 text-zinc-300 border border-zinc-700">
                Layer {selectedLayer.id} / 12
              </span>
            </div>

            <div>
              <h5 className="text-xs font-mono uppercase tracking-wider text-zinc-400 mb-1.5">
                Functional Scope & Objective
              </h5>
              <p className="text-sm text-zinc-300 leading-relaxed bg-zinc-950/60 p-3 rounded-lg border border-zinc-800/80">
                {selectedLayer.description}
              </p>
            </div>

            <div>
              <h5 className="text-xs font-mono uppercase tracking-wider text-zinc-400 mb-2">
                Implemented Subsystems & Rust Modules
              </h5>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {selectedLayer.subsystems.map((sub) => (
                  <div
                    key={sub}
                    className="flex items-center space-x-2 p-2.5 rounded bg-zinc-950/40 border border-zinc-800 text-xs font-mono text-zinc-200"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>{sub}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h5 className="text-xs font-mono uppercase tracking-wider text-zinc-400 mb-2">
                Architectural Domains Bound to Layer
              </h5>
              <div className="flex flex-wrap gap-2">
                {selectedLayer.domains.map(getDomainBadge)}
              </div>
            </div>

            <div className="pt-4 border-t border-zinc-800/80">
              <div className="p-3.5 rounded-lg bg-emerald-950/20 border border-emerald-800/30 text-xs text-emerald-200/90 leading-relaxed font-mono">
                <strong>CRITICAL INVARIANT:</strong> Code executing in Layer{' '}
                {selectedLayer.id} adheres to strict capability isolation. Native
                host interactions leverage official Apple C APIs / DriverKit FFI
                trampolines, while the research kernel operates under{' '}
                <code>#![no_std]</code> memory safety invariants.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
