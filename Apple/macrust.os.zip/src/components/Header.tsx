import React from 'react';
import { Cpu, Shield, Terminal, HardDrive, Cpu as Microchip, Activity, Layers, Code2, Zap } from 'lucide-react';

export type TabType =
  | 'overview'
  | 'terminal'
  | 'research-vm'
  | 'memory'
  | 'macho'
  | 'driverkit'
  | 'observability'
  | 'benchmarks'
  | 'code';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  cpuLoad: number;
  memoryUsedMb: number;
  memoryTotalMb: number;
  isVmRunning: boolean;
  onOpenAiAssistant: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  cpuLoad,
  memoryUsedMb,
  memoryTotalMb,
  isVmRunning,
  onOpenAiAssistant,
}) => {
  const tabs: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Layer Architecture', icon: <Layers className="w-4 h-4" /> },
    { id: 'terminal', label: 'macrust CLI', icon: <Terminal className="w-4 h-4" /> },
    { id: 'research-vm', label: 'ARM64 Research VM', icon: <Cpu className="w-4 h-4" /> },
    { id: 'memory', label: 'MMU & Allocators', icon: <HardDrive className="w-4 h-4" /> },
    { id: 'macho', label: 'Mach-O Inspector', icon: <Code2 className="w-4 h-4" /> },
    { id: 'driverkit', label: 'DriverKit & Extensions', icon: <Microchip className="w-4 h-4" /> },
    { id: 'observability', label: 'Digital Twin', icon: <Activity className="w-4 h-4" /> },
    { id: 'benchmarks', label: 'Faults & Benchmarks', icon: <Zap className="w-4 h-4" /> },
    { id: 'code', label: 'Rust Source Lab', icon: <Code2 className="w-4 h-4" /> },
  ];

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/90 backdrop-blur sticky top-0 z-40">
      {/* Top Status Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <h1 className="font-mono font-bold text-sm tracking-wider text-zinc-100">
              MACRUST<span className="text-emerald-400">.OS</span>
            </h1>
          </div>
          <span className="text-zinc-600">|</span>
          <div className="flex items-center space-x-1.5 font-mono text-zinc-400">
            <span className="px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 font-semibold text-[10px]">
              NATIVE
            </span>
            <span className="px-1.5 py-0.5 rounded bg-purple-950/60 text-purple-300 border border-purple-800/40 text-[10px]">
              EXTENSION
            </span>
            <span className="px-1.5 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-800/40 text-[10px]">
              RESEARCH
            </span>
          </div>
        </div>

        {/* Real-time System Metrics Indicator */}
        <div className="flex items-center space-x-4 font-mono text-zinc-400">
          <div className="flex items-center space-x-1.5">
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              CPU: <strong className="text-zinc-200">{cpuLoad}%</strong>
            </span>
          </div>
          <div className="flex items-center space-x-1.5">
            <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
            <span>
              MEM:{' '}
              <strong className="text-zinc-200">
                {(memoryUsedMb / 1024).toFixed(1)} GB
              </strong>{' '}
              / {(memoryTotalMb / 1024).toFixed(0)} GB
            </span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span
              className={`w-2 h-2 rounded-full ${
                isVmRunning ? 'bg-emerald-400 animate-ping' : 'bg-zinc-600'
              }`}
            />
            <span>
              GUEST VM:{' '}
              <strong
                className={isVmRunning ? 'text-emerald-400' : 'text-zinc-500'}
              >
                {isVmRunning ? 'RUNNING (aarch64)' : 'HALTED'}
              </strong>
            </span>
          </div>

          <button
            onClick={onOpenAiAssistant}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 transition-colors"
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="font-semibold">AI Kernel Engineer</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 overflow-x-auto no-scrollbar">
        <nav className="flex space-x-1 border-t border-zinc-900 pt-1 pb-1 text-xs font-mono">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-zinc-800 text-emerald-400 font-semibold border border-zinc-700 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
