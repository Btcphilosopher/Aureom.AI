import { RustSourceFile } from '../types/macrust';

export interface RustFile {
  path: string;
  crate: string;
  domain: 'NativeMacOS' | 'AppleSystemExtension' | 'DriverKit' | 'ResearchKernel';
  description: string;
  code: string;
}

export const RUST_SOURCE_FILES: RustSourceFile[] = [
  {
    path: 'research-kernel/kernel/src/lib.rs',
    fileName: 'lib.rs',
    crateName: 'macrust-kernel',
    domain: 'ResearchKernel',
    description: 'Freestanding Rust Kernel Core Entry Point with #![no_std] bootstrap sequence and interrupt vector installation.',
    isNoStd: true,
    hasUnsafe: true,
    content: `//! MACRUST.OS Research Kernel Core
//!
//! Target: aarch64-unknown-none
//! Domain: ResearchKernel
//!
//! SAFETY: All hardware control register accesses and MMU table mutations
//! strictly adhere to ARM Architecture Reference Manual (ARMv8-A/v9-A).

#![no_std]
#![no_main]
#![feature(alloc_error_handler)]

extern crate alloc;

pub mod arch;
pub mod memory;
pub mod scheduler;
pub mod process;
pub mod ipc;
pub mod filesystem;
pub mod drivers;
pub mod security;

use memory::PhysicalMemoryManager;
use scheduler::Scheduler;
use process::ProcessManager;

pub struct Kernel {
    pub pmm: PhysicalMemoryManager,
    pub scheduler: Scheduler,
    pub process_mgr: ProcessManager,
    pub is_initialized: bool,
}

impl Kernel {
    pub const fn uninit() -> Self {
        Self {
            pmm: PhysicalMemoryManager::new(),
            scheduler: Scheduler::new(),
            process_mgr: ProcessManager::new(),
            is_initialized: false,
        }
    }

    /// Primary Kernel Bootstrap Sequence
    ///
    /// # Safety
    /// Must be called once on boot CPU with MMU translation enabled.
    pub unsafe fn bootstrap(&mut self) -> Result<(), &'static str> {
        // Step 1: Install Exception Vector Table to VBAR_EL1
        arch::aarch64::exceptions::install_vector_table();

        // Step 2: Initialize Physical Memory Manager Bitmap
        self.pmm.init_from_dtb()?;

        // Step 3: Initialize Kernel Heap & Slab Allocators
        memory::heap::init_kernel_heap(&mut self.pmm)?;

        // Step 4: Configure Scheduler and Spawn PID 1 init task
        self.scheduler.init();
        self.process_mgr.spawn_init_task()?;

        self.is_initialized = true;
        Ok(())
    }
}`,
  },
  {
    path: 'research-kernel/kernel/src/arch/aarch64/mmu.rs',
    fileName: 'mmu.rs',
    crateName: 'macrust-kernel',
    domain: 'ResearchKernel',
    description: 'ARM64 4-Level Page Table translation (L0-L3) with 16KB native page granule management.',
    isNoStd: true,
    hasUnsafe: true,
    content: `//! ARM64 Translation Table Configuration & MMU Control
//!
//! Granule: 16KB Page Size
//! Virtual Address Range: 48-bit (256 TB per TTBR0/TTBR1)

use core::arch::asm;

pub const PAGE_SIZE: usize = 16 * 1024; // 16KB Granule
pub const ENTRY_COUNT: usize = 2048;    // 16KB / 8 bytes per descriptor

#[repr(transparent)]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct PageTableEntry(pub u64);

impl PageTableEntry {
    pub const VALID: u64 = 1 << 0;
    pub const TABLE: u64 = 1 << 1;
    pub const USER_ACCESSIBLE: u64 = 1 << 6;
    pub const READ_ONLY: u64 = 1 << 7;
    pub const NON_EXECUTABLE: u64 = 1 << 54;
    pub const PRIVILEGED_NON_EXEC: u64 = 1 << 53;

    pub const fn empty() -> Self {
        Self(0)
    }

    pub fn is_valid(&self) -> bool {
        (self.0 & Self::VALID) != 0
    }

    pub fn set_table(&mut self, next_table_phys_addr: usize) {
        // INVARIANT: Address must be 16KB aligned
        debug_assert!(next_table_phys_addr % PAGE_SIZE == 0);
        self.0 = (next_table_phys_addr as u64 & 0x0000_FFFF_FFFF_C000) | Self::VALID | Self::TABLE;
    }
}

/// Invalidate TLB Entries for current VMID
#[inline(always)]
pub unsafe fn invalidate_tlb_all() {
    asm!(
        "dsb ishst",
        "tlbi vmalle1is",
        "dsb ish",
        "isb",
        options(nostack, preserves_flags)
    );
}`,
  },
  {
    path: 'crates/macrust-mach/src/port.rs',
    fileName: 'port.rs',
    crateName: 'macrust-mach',
    domain: 'NativeMacOS',
    description: 'Zero-copy Mach Port handle wrapper with RAII deallocation semantics and rights transfer.',
    isNoStd: false,
    hasUnsafe: true,
    content: `//! Safe RAII Mach Port Wrapper
//!
//! Domain: NativeMacOS
//! Bridged to macOS Darwin Kernel Mach Subsystem

use std::fmt;

pub type MachPortName = u32;

pub const MACH_PORT_NULL: MachPortName = 0;
pub const MACH_PORT_DEAD: MachPortName = !0;

pub enum PortRight {
    Receive,
    Send,
    SendOnce,
    PortSet,
    DeadName,
}

#[derive(Debug)]
pub struct MachPort {
    name: MachPortName,
    right: PortRight,
}

impl MachPort {
    pub fn allocate(right: PortRight) -> Result<Self, i32> {
        let mut port_name: MachPortName = MACH_PORT_NULL;
        // SAFETY: Invokes mach_port_allocate on task self
        let kr = unsafe {
            libc::mach_port_allocate(
                libc::mach_task_self(),
                match right {
                    PortRight::Receive => 1, // MACH_PORT_RIGHT_RECEIVE
                    PortRight::PortSet => 3, // MACH_PORT_RIGHT_PORT_SET
                    _ => 1,
                },
                &mut port_name,
            )
        };

        if kr == 0 {
            Ok(Self { name: port_name, right })
        } else {
            Err(kr)
        }
    }

    pub fn raw_name(&self) -> MachPortName {
        self.name
    }
}

impl Drop for MachPort {
    fn drop(&mut self) {
        if self.name != MACH_PORT_NULL && self.name != MACH_PORT_DEAD {
            unsafe {
                libc::mach_port_deallocate(libc::mach_task_self(), self.name);
            }
        }
    }
}`,
  },
  {
    path: 'crates/macrust-driverkit/src/device.rs',
    fileName: 'device.rs',
    crateName: 'macrust-driverkit',
    domain: 'DriverKit',
    description: 'DriverKit User-Space Device Driver Provider trait and safe DMA memory mapping abstractions.',
    isNoStd: false,
    hasUnsafe: true,
    content: `//! DriverKit User-Space Hardware Abstraction
//!
//! Domain: DriverKit / AppleSystemExtension
//! Executes in isolated user-space sandbox outside Darwin kernel address space.

pub trait DriverProvider: Send + Sync {
    fn driver_name(&self) -> &'static str;
    fn probe(&mut self, vendor_id: u16, product_id: u16) -> bool;
    fn start(&mut self) -> Result<(), &'static str>;
    fn stop(&mut self) -> Result<(), &'static str>;
    fn handle_interrupt(&mut self) -> Result<(), &'static str>;
}

pub struct UsbHidDriver {
    device_name: &'static str,
    vendor_id: u16,
    product_id: u16,
    is_active: bool,
}

impl UsbHidDriver {
    pub fn new(vendor_id: u16, product_id: u16) -> Self {
        Self {
            device_name: "MacRust USB HID DriverKit Extension",
            vendor_id,
            product_id,
            is_active: false,
        }
    }
}

impl DriverProvider for UsbHidDriver {
    fn driver_name(&self) -> &'static str {
        self.device_name
    }

    fn probe(&mut self, vendor_id: u16, product_id: u16) -> bool {
        self.vendor_id == vendor_id && self.product_id == product_id
    }

    fn start(&mut self) -> Result<(), &'static str> {
        self.is_active = true;
        Ok(())
    }

    fn stop(&mut self) -> Result<(), &'static str> {
        self.is_active = false;
        Ok(())
    }

    fn handle_interrupt(&mut self) -> Result<(), &'static str> {
        // Dispatches input reports to IOUSBHostHIDDevice interface
        Ok(())
    }
}`,
  },
];

export const RUST_CODEBASE: RustFile[] = RUST_SOURCE_FILES.map((f) => ({
  path: f.path,
  crate: f.crateName,
  domain: f.domain as any,
  description: f.description,
  code: f.content,
}));
