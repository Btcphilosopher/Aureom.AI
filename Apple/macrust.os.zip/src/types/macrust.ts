export type ImplementationDomain =
  | 'NativeMacOS'
  | 'AppleSystemExtension'
  | 'DriverKit'
  | 'ResearchKernel'
  | 'VirtualMachine'
  | 'Simulation';

export type SystemLayerId = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12;

export interface SystemLayer {
  id: SystemLayerId;
  name: string;
  description: string;
  subsystems: string[];
  domains: ImplementationDomain[];
  color: string;
}

export interface CpuCore {
  id: number;
  type: 'Performance' | 'Efficiency';
  frequencyGhz: number;
  utilization: number;
  activeThreadId: number | null;
  activeProcessName: string | null;
  tempCelsius: number;
  instructionsPerCycle: number;
}
export type CpuCoreInfo = CpuCore;

export interface Arm64Registers {
  x0_x7: [string, string, string, string, string, string, string, string];
  x8_x15: [string, string, string, string, string, string, string, string];
  x16_x23: [string, string, string, string, string, string, string, string];
  x24_x30: [string, string, string, string, string, string, string];
  sp: string;
  pc: string;
  spsr_el1: string;
  ttbr0_el1: string;
  ttbr1_el1: string;
  esr_el1: string;
  cntpct_el0: string;
  // Dynamic register keys for simulation convenience
  [key: string]: any;
}
export type Arm64RegisterState = Arm64Registers;

export type SchedulerAlgorithm =
  | 'RoundRobin'
  | 'PriorityRoundRobin'
  | 'MultiLevelFeedbackQueue'
  | 'CompletelyFairScheduler'
  | 'WorkStealingScheduler';

export interface PageTableDescriptor {
  level: number;
  virtualAddressRange?: string;
  virtualAddress?: string;
  physicalAddressRange?: string;
  physicalAddress?: string;
  descriptorType?: 'Table' | 'Block' | 'Page' | 'Invalid';
  accessPermissions?: string;
  permissions?: string;
  executable?: boolean;
  userExecutable?: boolean;
  memoryAttribute?: string;
  valid?: boolean;
  sizeKb?: number;
  isCoW?: boolean;
  isGuardPage?: boolean;
  isAllocated?: boolean;
}

export interface KernelProcess {
  pid: number;
  ppid: number;
  name: string;
  domain: ImplementationDomain;
  state: 'READY' | 'RUNNING' | 'BLOCKED' | 'SLEEPING' | 'TERMINATED';
  priority: number;
  cpuAffinity: number;
  memoryMb: number;
  threadsCount: number;
  cpuPercent: number;
  command: string;
  capabilities: string[];
}

export interface KernelThread {
  tid: number;
  pid: number;
  processName: string;
  state: 'READY' | 'RUNNING' | 'BLOCKED' | 'SLEEPING' | 'TERMINATED';
  priority: number;
  cpuCoreId: number | null;
  runtimeMs: number;
  registers: Partial<Arm64Registers>;
}

export interface AllocatorBenchmarkResult {
  allocatorName: 'BumpAllocator' | 'LinkedListAllocator' | 'SlabAllocator' | 'BuddyAllocator';
  allocationSpeedOpsPerSec: number;
  deallocationSpeedOpsPerSec?: number;
  fragmentationPercentage: number;
  memoryEfficiencyScore?: number;
  avgLatencyNs: number;
  timeComplexity?: string;
  bestFor?: string;
}

export interface IpcBenchmarkResult {
  mechanism: 'Pipes' | 'Mach Messages' | 'Shared Memory' | 'Unix Sockets' | 'Lock-Free Queue';
  latencyNs: number;
  throughputMbps: number;
  contextSwitchesPerSec: number;
  memoryOverheadBytes: number;
}

export interface MachOHeader {
  magic: string;
  cputype: string;
  cpusubtype: string;
  filetype: string;
  ncmds: number;
  sizeofcmds: number;
  flags: string[];
  reserved?: number;
}

export interface MachOSegment {
  name: string;
  vmaddr: string;
  vmsize: string;
  fileoff?: string;
  filesize: string;
  maxprot?: string;
  initprot?: string;
  protection?: string;
  nsects?: number;
  flags?: string;
  sections: MachOSection[];
}

export interface MachOSection {
  name?: string;
  sectname?: string;
  segname?: string;
  addr: string;
  size: string;
  offset?: string;
  align?: number;
  alignment?: number;
  flags: string;
}

export interface MachOSymbol {
  name: string;
  demangled?: string;
  type?: string;
  section: string;
  value?: string;
  address?: string;
  isGlobal?: boolean;
  isExported?: boolean;
  isExternal?: boolean;
}

export interface MachOAnalysis {
  fileName: string;
  fileSizeBytes: number;
  isUniversal?: boolean;
  architectures?: string[];
  entryPoint?: string;
  header: MachOHeader;
  segments: MachOSegment[];
  symbols: MachOSymbol[];
  codeSignature: {
    signer: string;
    teamId: string;
    entitlements: string[];
    hardenedRuntime: boolean;
    valid?: boolean;
    flags?: string;
    cdHash?: string;
  };
}
export type MachOBinaryInfo = MachOAnalysis;

export interface DeviceInfo {
  id: string;
  name: string;
  category: 'USB' | 'PCI' | 'HID' | 'Network' | 'Storage' | 'Audio' | 'Display' | 'Serial';
  provider: 'DriverKit' | 'SystemExtension' | 'NativeMacOS' | 'ResearchDriver' | 'IOUSBHostDevice';
  status: 'DISCOVERED' | 'PROBED' | 'INITIALISING' | 'ACTIVE' | 'SUSPENDED' | 'FAILED' | 'Active';
  vendorId: string;
  productId: string;
  address?: string;
  description?: string;
  dmaMapped?: boolean;
}

export interface SystemExtensionInfo {
  name: string;
  identifier: string;
  category: 'EndpointSecurity' | 'NetworkExtension';
  state: 'ACTIVE' | 'INACTIVE';
  subscribedEvents: string[];
}

export interface SystemEvent {
  id: string;
  timestampMs?: number;
  timestamp?: string;
  category?: string;
  severity?: 'INFO' | 'WARN' | 'ERROR';
  source?: string;
  message?: string;
  type?:
    | 'ProcessCreated'
    | 'ProcessExited'
    | 'MemoryMapped'
    | 'MemoryFreed'
    | 'DeviceAttached'
    | 'DeviceRemoved'
    | 'NetworkConnected'
    | 'SecurityEvent'
    | 'ThermalChange'
    | 'KernelPanic';
  domain?: ImplementationDomain;
  summary?: string;
  details?: Record<string, unknown>;
}

export interface SystemTelemetry {
  timestampMs: number;
  cpuLoadPercent: number;
  pCoreLoadPercent: number;
  eCoreLoadPercent: number;
  memoryUsedMb: number;
  memoryTotalMb: number;
  virtualMemoryUsedMb: number;
  activeProcessesCount: number;
  activeThreadsCount: number;
  networkRxBytesPerSec: number;
  networkTxBytesPerSec: number;
  diskReadBytesPerSec: number;
  diskWriteBytesPerSec: number;
  cpuTempCelsius: number;
  thermalPressure: 'NOMINAL' | 'MODERATE' | 'HEAVY' | 'TRAPPING';
  powerWattsEstimated: number;
}

export interface CrashDump {
  dumpId: string;
  timestamp: string;
  kernelVersion: string;
  panicReason: string;
  cpuId: number;
  faultAddress: string;
  esrEl1: string;
  registers: Arm64Registers;
  stackBacktrace: string[];
  activeProcess: string;
  activeThreadTid: number;
  memoryMapState: string;
}
export type CrashDumpInfo = CrashDump;

export interface BootStep {
  stepNumber: number;
  title: string;
  description: string;
  targetLevel: string;
}

export interface RustSourceFile {
  path: string;
  fileName: string;
  crateName: string;
  domain: ImplementationDomain;
  description: string;
  isNoStd: boolean;
  hasUnsafe: boolean;
  content: string;
}
