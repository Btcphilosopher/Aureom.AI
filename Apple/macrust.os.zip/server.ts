import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import {
  INITIAL_CPU_CORES,
  INITIAL_ARM64_REGISTERS,
  SAMPLE_PAGE_TABLE_DESCRIPTORS,
  INITIAL_PROCESSES,
  SAMPLE_MACHO_BINARIES,
  ALLOCATOR_BENCHMARKS,
  IPC_BENCHMARKS,
} from './src/data/mockSystemData.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', project: 'MACRUST.OS', version: '1.0.0-alpha' });
  });

  // API Route: Real/Simulated System Info
  app.get('/api/system-info', (_req, res) => {
    res.json({
      platform: 'macOS',
      architecture: 'arm64',
      chipName: 'Apple Silicon (M3 Pro)',
      pCoresCount: 6,
      eCoresCount: 6,
      xnuKernelVersion: 'Darwin Kernel Version 23.4.0 (x86_64/arm64)',
      rustToolchain: 'rustc 1.85.0-nightly (aarch64-apple-darwin)',
      domainCapabilities: {
        NativeMacOS: 'Available (System sysctl, Mach ports, BSD APIs)',
        AppleSystemExtension: 'Available (Endpoint Security, Network Extension)',
        DriverKit: 'Available (IOUSBHostDevice, PCIDriverKit)',
        ResearchKernel: 'Active (Freestanding #![no_std] ARM64 OS)',
        VirtualMachine: 'Active (Apple Virtualization.framework / QEMU)',
      },
    });
  });

  // API Route: Mach-O Binary Parser
  app.post('/api/macho/parse', (req, res) => {
    const { binaryName } = req.body || {};
    const key = binaryName in SAMPLE_MACHO_BINARIES ? binaryName : 'macrust-cli';
    res.json({
      success: true,
      analysis: SAMPLE_MACHO_BINARIES[key],
    });
  });

  // API Route: System Benchmarks
  app.get('/api/benchmarks/run', (_req, res) => {
    res.json({
      timestamp: Date.now(),
      allocators: ALLOCATOR_BENCHMARKS,
      ipc: IPC_BENCHMARKS,
      schedulerContextSwitchCostNs: 124,
    });
  });

  // API Route: Fault Injector & Crash Dump Generator (.mcrash)
  app.post('/api/fault/inject', (req, res) => {
    const { faultType } = req.body || { faultType: 'PAGE_FAULT' };
    const dumpId = `mcrash-${Math.floor(100000 + Math.random() * 900000)}`;

    let panicReason = 'Unchecked kernel memory access violation';
    let faultAddress = '0x0000000000000008';

    if (faultType === 'OOM_PANIC') {
      panicReason = 'Kernel Allocator: Out of Physical Memory Frames (PMM Exhaustion)';
      faultAddress = '0x0000000080000000';
    } else if (faultType === 'STACK_OVERFLOW') {
      panicReason = 'Kernel Panic: Guard Page Hit in Thread Stack Guard Region';
      faultAddress = '0x00000001001FBFFF';
    } else if (faultType === 'DEADLOCK_DETECTED') {
      panicReason = 'Kernel Panic: Circular Lock Dependency Detected (Lock #12 -> Lock #4 -> Lock #12)';
      faultAddress = '0x0000000000000000';
    }

    const crashDump = {
      dumpId,
      timestamp: new Date().toISOString(),
      kernelVersion: 'MACRUST-RESEARCH-0.1.0-aarch64',
      panicReason,
      cpuId: 0,
      faultAddress,
      esrEl1: '0x0000000096000004', // Data Abort EL1
      registers: INITIAL_ARM64_REGISTERS,
      stackBacktrace: [
        '0x0000000100001000: macrust_kernel::memory::virtual_mem::handle_page_fault',
        '0x00000001000024A0: macrust_kernel::arch::aarch64::exception_vector_el1_sync',
        '0x0000000100004810: macrust_kernel::process::spawn_task',
        '0x0000000100000100: kernel_main',
      ],
      activeProcess: 'research-init (PID 303)',
      activeThreadTid: 1001,
      memoryMapState: 'TTBR0: 0x80100000 | TTBR1: 0x80000000 | Free Pages: 0 / 32768',
    };

    res.json({ success: true, crashDump });
  });

  // API Route: AI Systems Engineer Assistant (Gemini)
  app.post('/api/ai/kernel-diagnose', async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: 'GEMINI_API_KEY environment variable is missing. Please set it in AI Studio secrets.',
        });
      }

      const { prompt, crashDump } = req.body || {};
      const ai = new GoogleGenAI({ apiKey });

      const systemInstruction = `You are the Principal Systems Engineer for MACRUST.OS (a Rust-native macOS kernel & OS architecture project). Provide deep, concise, technical, low-level analysis covering ARM64 registers, MMU page translation, DriverKit boundaries, or Rust safety guarantees.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt || `Diagnose this kernel crash dump: ${JSON.stringify(crashDump)}`,
        config: {
          systemInstruction,
        },
      });

      res.json({ analysis: response.text });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to query AI assistant';
      res.status(500).json({ error: message });
    }
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MACRUST.OS Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
