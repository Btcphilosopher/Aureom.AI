import { pt, qt, pchisq, qchisq, pf, qf, pnorm, qnorm } from './math-utils';
import { computeDescriptiveStats } from './descriptive';
import { HypothesisTestResult, StatisticalAssumption } from './types';

function getSignificance(p: number): '***' | '**' | '*' | '.' | 'ns' {
  if (p < 0.001) return '***';
  if (p < 0.01) return '**';
  if (p < 0.05) return '*';
  if (p < 0.1) return '.';
  return 'ns';
}

function getMagnitude(d: number): 'negligible' | 'small' | 'medium' | 'large' {
  const absD = Math.abs(d);
  if (absD < 0.2) return 'negligible';
  if (absD < 0.5) return 'small';
  if (absD < 0.8) return 'medium';
  return 'large';
}

// 1. One-Sample t-test
export function runOneSampleTTest(
  values: number[],
  mu0 = 0,
  varName = 'Value',
  alternative: 'two.sided' | 'less' | 'greater' = 'two.sided'
): HypothesisTestResult {
  const stats = computeDescriptiveStats(values, varName, true);
  const n = stats.validCount;
  const mean = stats.mean ?? 0;
  const sd = stats.sd ?? 1;
  const se = stats.se ?? 1;
  const df = n - 1;

  const t = (mean - mu0) / (se || 1e-9);
  let pValue = 0;

  if (alternative === 'two.sided') {
    pValue = 2 * (1 - pt(Math.abs(t), df));
  } else if (alternative === 'less') {
    pValue = pt(t, df);
  } else {
    pValue = 1 - pt(t, df);
  }
  pValue = Math.max(0, Math.min(1, pValue));

  const tCrit = qt(0.975, df);
  const ci: [number, number] = [mean - tCrit * se, mean + tCrit * se];

  const cohensD = (mean - mu0) / (sd || 1e-9);

  const assumptions: StatisticalAssumption[] = [
    {
      name: 'Normality',
      description: 'The sampled population should be approximately normally distributed.',
      status: Math.abs(stats.skewness ?? 0) < 1.0 && Math.abs(stats.kurtosis ?? 0) < 1.5 ? 'passed' : 'warning',
      details: `Skewness = ${(stats.skewness ?? 0).toFixed(2)}, Kurtosis = ${(stats.kurtosis ?? 0).toFixed(2)}. ${n >= 30 ? 'Sample size (n >= 30) gives robustness via CLT.' : 'Examine Q-Q plot for smaller samples.'}`,
    },
    {
      name: 'Independence of Observations',
      description: 'Data points must be sampled independently.',
      status: 'passed',
      details: 'Assumed by random sampling design.',
    },
    {
      name: 'Continuous Measurement',
      description: 'The variable should be measured on an interval or ratio scale.',
      status: 'passed',
      details: `${varName} is numeric continuous.`,
    },
  ];

  const plainExplanation = pValue < 0.05
    ? `The sample mean of ${mean.toFixed(2)} is statistically significantly different from the hypothesized value of ${mu0} (t = ${t.toFixed(3)}, p = ${pValue < 0.0001 ? '< 0.0001' : pValue.toFixed(4)}). Effect size is ${getMagnitude(cohensD)} (Cohen's d = ${cohensD.toFixed(2)}).`
    : `There is insufficient evidence to conclude the sample mean (${mean.toFixed(2)}) differs from ${mu0} (t = ${t.toFixed(3)}, p = ${pValue.toFixed(4)}).`;

  const rCode = `# One-sample t-test in R
t.test(dataset$${varName}, mu = ${mu0}, alternative = "${alternative}")`;

  return {
    testName: 'One-Sample t-test',
    rFunction: 't.test(x, mu, alternative)',
    statisticName: 't',
    statisticValue: t,
    df,
    pValue,
    significance: getSignificance(pValue),
    alternative,
    ci,
    ciConfidence: 0.95,
    effectSize: {
      name: "Cohen's d",
      value: cohensD,
      magnitude: getMagnitude(cohensD),
    },
    groupStats: [{ group: varName, n, mean, sd, se }],
    assumptions,
    plainExplanation,
    rCode,
    methodDescription: 'Tests whether the population mean of a single numeric variable differs significantly from a specified hypothetical value.',
  };
}

// 2. Two-Sample Welch / Student t-test
export function runTwoSampleTTest(
  group1Values: number[],
  group2Values: number[],
  group1Name = 'Group A',
  group2Name = 'Group B',
  equalVar = false,
  alternative: 'two.sided' | 'less' | 'greater' = 'two.sided'
): HypothesisTestResult {
  const s1 = computeDescriptiveStats(group1Values, group1Name, true);
  const s2 = computeDescriptiveStats(group2Values, group2Name, true);

  const n1 = s1.validCount;
  const n2 = s2.validCount;
  const m1 = s1.mean ?? 0;
  const m2 = s2.mean ?? 0;
  const v1 = s1.variance ?? 1;
  const v2 = s2.variance ?? 1;
  const sd1 = s1.sd ?? 1;
  const sd2 = s2.sd ?? 1;

  const diff = m1 - m2;
  let df = 0;
  let seDiff = 0;
  let t = 0;
  let testName = 'Welch Two-Sample t-test';

  if (equalVar) {
    testName = "Student's Two-Sample t-test (Equal Variances)";
    const pooledVar = ((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2);
    seDiff = Math.sqrt(pooledVar * (1 / n1 + 1 / n2));
    df = n1 + n2 - 2;
    t = diff / (seDiff || 1e-9);
  } else {
    // Welch-Satterthwaite
    const w1 = v1 / n1;
    const w2 = v2 / n2;
    seDiff = Math.sqrt(w1 + w2);
    df = Math.pow(w1 + w2, 2) / (Math.pow(w1, 2) / (n1 - 1) + Math.pow(w2, 2) / (n2 - 1));
    t = diff / (seDiff || 1e-9);
  }

  let pValue = 0;
  if (alternative === 'two.sided') {
    pValue = 2 * (1 - pt(Math.abs(t), df));
  } else if (alternative === 'less') {
    pValue = pt(t, df);
  } else {
    pValue = 1 - pt(t, df);
  }
  pValue = Math.max(0, Math.min(1, pValue));

  const tCrit = qt(0.975, df);
  const ci: [number, number] = [diff - tCrit * seDiff, diff + tCrit * seDiff];

  // Cohen's d (pooled SD)
  const pooledSD = Math.sqrt(((n1 - 1) * v1 + (n2 - 1) * v2) / (n1 + n2 - 2));
  const cohensD = diff / (pooledSD || 1e-9);

  // Variance Ratio Test (F-test for equal variance)
  const fVar = v1 >= v2 ? v1 / v2 : v2 / v1;
  const varDiffRatio = Math.max(sd1, sd2) / Math.min(sd1, sd2);

  const assumptions: StatisticalAssumption[] = [
    {
      name: 'Normality within Groups',
      description: 'Both groups should follow an approximately normal distribution.',
      status: Math.abs(s1.skewness ?? 0) < 1.2 && Math.abs(s2.skewness ?? 0) < 1.2 ? 'passed' : 'warning',
      details: `${group1Name} skew: ${(s1.skewness ?? 0).toFixed(2)}, ${group2Name} skew: ${(s2.skewness ?? 0).toFixed(2)}.`,
    },
    {
      name: 'Homogeneity of Variances (Equal Variance)',
      description: 'Variances between both groups should be roughly comparable.',
      status: equalVar ? (varDiffRatio < 2.0 ? 'passed' : 'warning') : 'passed',
      details: equalVar
        ? `SD ratio is ${varDiffRatio.toFixed(2)}x.`
        : 'Welch t-test automatically adjusts degrees of freedom without requiring equal variances.',
    },
    {
      name: 'Independence between Groups',
      description: 'Observations in each group must be independent of observations in the other group.',
      status: 'passed',
      details: 'Unpaired two-group design.',
    },
  ];

  const plainExplanation = pValue < 0.05
    ? `The observed difference between ${group1Name} (mean = ${m1.toFixed(2)}) and ${group2Name} (mean = ${m2.toFixed(2)}) is statistically significant (mean diff = ${diff.toFixed(2)}, 95% CI [${ci[0].toFixed(2)}, ${ci[1].toFixed(2)}], t = ${t.toFixed(3)}, p = ${pValue < 0.0001 ? '< 0.0001' : pValue.toFixed(4)}). Effect size is ${getMagnitude(cohensD)} (Cohen's d = ${cohensD.toFixed(2)}).`
    : `No statistically significant difference was detected between ${group1Name} and ${group2Name} (mean diff = ${diff.toFixed(2)}, t = ${t.toFixed(3)}, p = ${pValue.toFixed(4)}).`;

  const rCode = `# ${testName} in R
t.test(
  group1,
  group2,
  var.equal = ${equalVar ? 'TRUE' : 'FALSE'},
  alternative = "${alternative}"
)`;

  return {
    testName,
    rFunction: `t.test(x, y, var.equal = ${equalVar ? 'TRUE' : 'FALSE'})`,
    statisticName: 't',
    statisticValue: t,
    df,
    pValue,
    significance: getSignificance(pValue),
    alternative,
    ci,
    ciConfidence: 0.95,
    effectSize: {
      name: "Cohen's d",
      value: cohensD,
      magnitude: getMagnitude(cohensD),
    },
    groupStats: [
      { group: group1Name, n: n1, mean: m1, sd: sd1, se: s1.se ?? 0 },
      { group: group2Name, n: n2, mean: m2, sd: sd2, se: s2.se ?? 0 },
    ],
    assumptions,
    plainExplanation,
    rCode,
    methodDescription: 'Compares the means of two independent groups to determine if the population means differ significantly.',
  };
}

// 3. Paired Samples t-test
export function runPairedTTest(
  preValues: number[],
  postValues: number[],
  preName = 'Before',
  postName = 'After',
  alternative: 'two.sided' | 'less' | 'greater' = 'two.sided'
): HypothesisTestResult {
  const n = Math.min(preValues.length, postValues.length);
  const diffs: number[] = [];
  for (let i = 0; i < n; i++) {
    diffs.push(preValues[i] - postValues[i]);
  }

  const baseResult = runOneSampleTTest(diffs, 0, 'Difference', alternative);
  const sPre = computeDescriptiveStats(preValues.slice(0, n), preName, true);
  const sPost = computeDescriptiveStats(postValues.slice(0, n), postName, true);

  return {
    ...baseResult,
    testName: 'Paired Samples t-test',
    rFunction: 't.test(x, y, paired = TRUE)',
    groupStats: [
      { group: preName, n, mean: sPre.mean ?? 0, sd: sPre.sd ?? 1, se: sPre.se ?? 0 },
      { group: postName, n, mean: sPost.mean ?? 0, sd: sPost.sd ?? 1, se: sPost.se ?? 0 },
    ],
    rCode: `# Paired t-test in R
t.test(dataset$${preName}, dataset$${postName}, paired = TRUE, alternative = "${alternative}")`,
    methodDescription: 'Compares repeated measurements on the exact same subjects (e.g. before/after treatment) by testing if the mean difference equals zero.',
  };
}

// 4. One-Way ANOVA with Tukey's HSD
export function runOneWayAnova(
  groups: { name: string; values: number[] }[],
  depVarName = 'Value'
): {
  testResult: HypothesisTestResult;
  table: { term: string; df: number; sumSq: number; meanSq: number; fValue: number; pValue: number; etaSq: number }[];
  tukeyPostHoc: { comparison: string; diff: number; ciLower: number; ciUpper: number; pAdj: number }[];
} {
  const k = groups.length;
  let totalN = 0;
  let grandSum = 0;

  const groupStats = groups.map(g => {
    const s = computeDescriptiveStats(g.values, g.name, true);
    totalN += s.validCount;
    grandSum += s.sum ?? 0;
    return { name: g.name, values: g.values, stats: s };
  });

  const grandMean = grandSum / totalN;

  // Between-group sum of squares (SSB)
  let ssBetween = 0;
  for (const g of groupStats) {
    const ni = g.stats.validCount;
    const mi = g.stats.mean ?? 0;
    ssBetween += ni * Math.pow(mi - grandMean, 2);
  }

  // Within-group sum of squares (SSW)
  let ssWithin = 0;
  for (const g of groupStats) {
    const mi = g.stats.mean ?? 0;
    for (const val of g.values) {
      ssWithin += Math.pow(val - mi, 2);
    }
  }

  const ssTotal = ssBetween + ssWithin;
  const dfBetween = k - 1;
  const dfWithin = totalN - k;

  const msBetween = ssBetween / dfBetween;
  const msWithin = ssWithin / dfWithin;

  const fValue = msBetween / (msWithin || 1e-9);
  const pValue = Math.max(0, Math.min(1, 1 - pf(fValue, dfBetween, dfWithin)));
  const etaSq = ssBetween / (ssTotal || 1e-9);

  // Tukey Post-Hoc Comparisons
  const tukeyPostHoc: { comparison: string; diff: number; ciLower: number; ciUpper: number; pAdj: number }[] = [];
  for (let i = 0; i < k; i++) {
    for (let j = i + 1; j < k; j++) {
      const g1 = groupStats[i];
      const g2 = groupStats[j];
      const diff = (g1.stats.mean ?? 0) - (g2.stats.mean ?? 0);
      const seTukey = Math.sqrt((msWithin / 2) * (1 / g1.stats.validCount + 1 / g2.stats.validCount));

      // Approximation of studentized range distribution critical value
      const qCrit = qt(1 - 0.05 / (k * (k - 1) / 2), dfWithin) * Math.SQRT2;
      const margin = qCrit * seTukey;
      const qObs = Math.abs(diff) / seTukey;
      const pAdj = Math.max(0, Math.min(1, (1 - pt(qObs / Math.SQRT2, dfWithin)) * (k * (k - 1) / 2)));

      tukeyPostHoc.push({
        comparison: `${g1.name} vs ${g2.name}`,
        diff,
        ciLower: diff - margin,
        ciUpper: diff + margin,
        pAdj,
      });
    }
  }

  const table = [
    { term: 'Between Groups (Treatment)', df: dfBetween, sumSq: ssBetween, meanSq: msBetween, fValue, pValue, etaSq },
    { term: 'Within Groups (Residuals)', df: dfWithin, sumSq: ssWithin, meanSq: msWithin, fValue: 0, pValue: 1, etaSq: 1 - etaSq },
  ];

  const assumptions: StatisticalAssumption[] = [
    {
      name: 'Normality of Residuals',
      description: 'Observations within each group should be normally distributed.',
      status: 'passed',
      details: 'Residual variation roughly follows bell shape.',
    },
    {
      name: 'Homogeneity of Variances',
      description: 'Variances across all factor levels should be homogeneous.',
      status: 'passed',
      details: 'ANOVA is robust to moderate variance differences with balanced group sizes.',
    },
    {
      name: 'Independence',
      description: 'Subjects are assigned independently to each category level.',
      status: 'passed',
      details: 'Independent multi-group factor.',
    },
  ];

  const plainExplanation = pValue < 0.05
    ? `Statistically significant differences exist across group means (F(${dfBetween}, ${dfWithin}) = ${fValue.toFixed(3)}, p = ${pValue < 0.0001 ? '< 0.0001' : pValue.toFixed(4)}). The factor explains ${(etaSq * 100).toFixed(1)}% of total variance (η² = ${etaSq.toFixed(3)}). Inspect the Tukey post-hoc table to identify which specific pairs differ.`
    : `No statistically significant differences between group means were observed (F(${dfBetween}, ${dfWithin}) = ${fValue.toFixed(3)}, p = ${pValue.toFixed(4)}).`;

  const rCode = `# One-way ANOVA in R
model <- aov(${depVarName} ~ Group, data = dataset)
summary(model)
TukeyHSD(model)`;

  const testResult: HypothesisTestResult = {
    testName: 'One-Way Analysis of Variance (ANOVA)',
    rFunction: 'aov(formula, data)',
    statisticName: 'F',
    statisticValue: fValue,
    df: [dfBetween, dfWithin],
    pValue,
    significance: getSignificance(pValue),
    alternative: 'two.sided',
    effectSize: {
      name: 'Eta Squared (η²)',
      value: etaSq,
      magnitude: etaSq < 0.01 ? 'negligible' : etaSq < 0.06 ? 'small' : etaSq < 0.14 ? 'medium' : 'large',
    },
    groupStats: groupStats.map(g => ({
      group: g.name,
      n: g.stats.validCount,
      mean: g.stats.mean ?? 0,
      sd: g.stats.sd ?? 0,
      se: g.stats.se ?? 0,
    })),
    assumptions,
    plainExplanation,
    rCode,
    methodDescription: 'Tests whether the population means of three or more groups are all equal against the alternative that at least one group mean differs.',
  };

  return { testResult, table, tukeyPostHoc };
}

// 5. Chi-Square Test of Independence (Contingency Table)
export function runChiSquareTest(
  matrix: number[][],
  rowNames: string[],
  colNames: string[]
): HypothesisTestResult {
  const r = matrix.length;
  const c = matrix[0].length;

  const rowTotals = Array(r).fill(0);
  const colTotals = Array(c).fill(0);
  let grandTotal = 0;

  for (let i = 0; i < r; i++) {
    for (let j = 0; j < c; j++) {
      const val = matrix[i][j];
      rowTotals[i] += val;
      colTotals[j] += val;
      grandTotal += val;
    }
  }

  let chiSq = 0;
  let minExpected = Infinity;

  for (let i = 0; i < r; i++) {
    for (let j = 0; j < c; j++) {
      const expected = (rowTotals[i] * colTotals[j]) / grandTotal;
      if (expected < minExpected) minExpected = expected;
      const diff = matrix[i][j] - expected;
      chiSq += (diff * diff) / (expected || 1e-9);
    }
  }

  const df = (r - 1) * (c - 1);
  const pValue = Math.max(0, Math.min(1, 1 - pchisq(chiSq, df)));

  // Cramér's V
  const minDim = Math.min(r - 1, c - 1);
  const cramersV = Math.sqrt(chiSq / (grandTotal * Math.max(1, minDim)));

  const assumptions: StatisticalAssumption[] = [
    {
      name: 'Expected Cell Frequencies',
      description: 'All expected cell frequencies should be at least 5 in 80%+ of cells.',
      status: minExpected >= 5 ? 'passed' : 'warning',
      details: `Minimum expected frequency = ${minExpected.toFixed(1)}. ${minExpected < 5 ? "Consider Fisher's Exact Test for small sample contingency tables." : 'Cochran criteria satisfied.'}`,
    },
    {
      name: 'Independence',
      description: 'Each observation must contribute to exactly one cell.',
      status: 'passed',
      details: 'Mutually exclusive categories.',
    },
  ];

  const plainExplanation = pValue < 0.05
    ? `There is a statistically significant association between the two categorical variables (χ²(${df}) = ${chiSq.toFixed(3)}, p = ${pValue < 0.0001 ? '< 0.0001' : pValue.toFixed(4)}). Association strength: Cramér's V = ${cramersV.toFixed(3)}.`
    : `No statistically significant association was found between the categorical variables (χ²(${df}) = ${chiSq.toFixed(3)}, p = ${pValue.toFixed(4)}).`;

  const rCode = `# Pearson's Chi-squared Test in R
chisq.test(table(dataset$VarA, dataset$VarB))`;

  return {
    testName: "Pearson's Chi-Square Test of Independence",
    rFunction: 'chisq.test(x, y)',
    statisticName: 'χ²',
    statisticValue: chiSq,
    df,
    pValue,
    significance: getSignificance(pValue),
    alternative: 'two.sided',
    effectSize: {
      name: "Cramér's V",
      value: cramersV,
      magnitude: cramersV < 0.1 ? 'negligible' : cramersV < 0.3 ? 'small' : cramersV < 0.5 ? 'medium' : 'large',
    },
    assumptions,
    plainExplanation,
    rCode,
    methodDescription: 'Evaluates whether there is a statistically significant relationship between two categorical variables in a contingency table.',
  };
}

// 6. Nonparametric Mann-Whitney U / Wilcoxon Rank Sum Test
export function runMannWhitneyTest(
  group1: number[],
  group2: number[],
  name1 = 'Group 1',
  name2 = 'Group 2'
): HypothesisTestResult {
  const n1 = group1.length;
  const n2 = group2.length;

  const combined = [
    ...group1.map(v => ({ v, g: 1 })),
    ...group2.map(v => ({ v, g: 2 })),
  ].sort((a, b) => a.v - b.v);

  // Assign ranks with average ties
  const ranks = Array(combined.length).fill(0);
  let i = 0;
  while (i < combined.length) {
    let j = i;
    while (j < combined.length && combined[j].v === combined[i].v) {
      j++;
    }
    const avgRank = (i + 1 + j) / 2;
    for (let k = i; k < j; k++) {
      ranks[k] = avgRank;
    }
    i = j;
  }

  let rankSum1 = 0;
  for (let k = 0; k < combined.length; k++) {
    if (combined[k].g === 1) rankSum1 += ranks[k];
  }

  const u1 = rankSum1 - (n1 * (n1 + 1)) / 2;
  const u2 = n1 * n2 - u1;
  const u = Math.min(u1, u2);

  // Normal approximation with continuity correction
  const meanU = (n1 * n2) / 2;
  const sdU = Math.sqrt((n1 * n2 * (n1 + n2 + 1)) / 12);
  const z = (u - meanU + 0.5) / sdU;
  const pValue = 2 * (1 - pnorm(Math.abs(z)));

  // Rank biserial correlation effect size r = 1 - 2U / (n1 * n2)
  const rEffect = 1 - (2 * u) / (n1 * n2);

  const assumptions: StatisticalAssumption[] = [
    {
      name: 'Continuous or Ordinal Data',
      description: 'Data can be meaningfully ranked.',
      status: 'passed',
      details: 'Numeric/ordinal values successfully ranked.',
    },
    {
      name: 'Independent Groups',
      description: 'Non-parametric distribution-free alternative to independent t-test.',
      status: 'passed',
      details: 'Requires no assumption of normality.',
    },
  ];

  const plainExplanation = pValue < 0.05
    ? `The rank distributions differ significantly between ${name1} and ${name2} (Mann-Whitney U = ${u.toFixed(1)}, W = ${rankSum1.toFixed(1)}, z = ${z.toFixed(2)}, p = ${pValue < 0.0001 ? '< 0.0001' : pValue.toFixed(4)}). Effect size: rank-biserial r = ${rEffect.toFixed(2)}.`
    : `No statistically significant shift in rank distributions was found between ${name1} and ${name2} (W = ${rankSum1.toFixed(1)}, p = ${pValue.toFixed(4)}).`;

  const rCode = `# Wilcoxon Rank-Sum / Mann-Whitney Test in R
wilcox.test(group1, group2, exact = FALSE)`;

  return {
    testName: 'Wilcoxon Rank-Sum / Mann-Whitney U Test',
    rFunction: 'wilcox.test(x, y)',
    statisticName: 'W',
    statisticValue: rankSum1,
    pValue,
    significance: getSignificance(pValue),
    alternative: 'two.sided',
    effectSize: {
      name: 'Rank-Biserial r',
      value: rEffect,
      magnitude: Math.abs(rEffect) < 0.1 ? 'negligible' : Math.abs(rEffect) < 0.3 ? 'small' : Math.abs(rEffect) < 0.5 ? 'medium' : 'large',
    },
    assumptions,
    plainExplanation,
    rCode,
    methodDescription: 'Non-parametric test comparing whether two independent samples come from populations with the same distribution without assuming normality.',
  };
}
