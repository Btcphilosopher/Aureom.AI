/**
 * High-precision mathematical and statistical distribution functions matching R implementation standards
 */

// Error Function erf(x) using Chebyshev approximation
export function erf(x: number): number {
  const sign = x >= 0 ? 1 : -1;
  const absX = Math.abs(x);

  // constants
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const t = 1.0 / (1.0 + p * absX);
  const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-absX * absX);

  return sign * y;
}

export function erfc(x: number): number {
  return 1 - erf(x);
}

// Log-Gamma function via Lanczos approximation (g=7, n=9)
const LANCZOS_P = [
  0.99999999999980993,
  676.5203681218851,
  -1259.1392167224028,
  771.32342877765313,
  -176.61502916214059,
  12.507343278686905,
  -0.138571095857209,
  9.9843695780195716e-6,
  1.5056327351493116e-7,
];

export function logGamma(z: number): number {
  if (z < 0.5) {
    // Reflection formula: Gamma(1-z)*Gamma(z) = pi / sin(pi*z)
    return Math.log(Math.PI / Math.sin(Math.PI * z)) - logGamma(1 - z);
  }
  z -= 1;
  let x = LANCZOS_P[0];
  for (let i = 1; i < 9; i++) {
    x += LANCZOS_P[i] / (z + i);
  }
  const t = z + 7 + 0.5;
  return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
}

export function gamma(z: number): number {
  return Math.exp(logGamma(z));
}

// Regularized incomplete lower gamma function P(a, x) = gamma(a, x) / Gamma(a)
export function lowerIncompleteGamma(a: number, x: number): number {
  if (x < 0 || a <= 0) return 0;
  if (x === 0) return 0;

  if (x < a + 1) {
    // Series expansion
    let sum = 1 / a;
    let term = 1 / a;
    for (let n = 1; n < 100; n++) {
      term *= x / (a + n);
      sum += term;
      if (Math.abs(term) < Math.abs(sum) * 1e-12) break;
    }
    return sum * Math.exp(-x + a * Math.log(x) - logGamma(a));
  } else {
    // Continued fraction for upper incomplete gamma Q(a, x), then 1 - Q
    let b = x + 1 - a;
    let c = 1 / 1e-30;
    let d = 1 / b;
    let h = d;
    for (let i = 1; i < 100; i++) {
      const an = -i * (i - a);
      b += 2;
      d = an * d + b;
      if (Math.abs(d) < 1e-30) d = 1e-30;
      c = b + an / c;
      if (Math.abs(c) < 1e-30) c = 1e-30;
      d = 1 / d;
      const del = d * c;
      h *= del;
      if (Math.abs(del - 1) < 1e-12) break;
    }
    const q = Math.exp(-x + a * Math.log(x) - logGamma(a)) * h;
    return 1 - q;
  }
}

// Incomplete beta function I_x(a, b) via continued fraction
export function incompleteBeta(x: number, a: number, b: number): number {
  if (x <= 0) return 0;
  if (x >= 1) return 1;

  // Use symmetry transformation if needed
  if (x > (a + 1) / (a + b + 2)) {
    return 1 - incompleteBeta(1 - x, b, a);
  }

  const factor = Math.exp(
    a * Math.log(x) + b * Math.log(1 - x) - logGamma(a) - logGamma(b) + logGamma(a + b)
  ) / a;

  // Lentz's method for continued fraction
  let c = 1;
  let d = 1 - (a + b) * x / (a + 1);
  if (Math.abs(d) < 1e-30) d = 1e-30;
  d = 1 / d;
  let h = d;

  for (let m = 1; m <= 200; m++) {
    // even step
    let num = (m * (b - m) * x) / ((a + 2 * m - 1) * (a + 2 * m));
    d = 1 + num * d;
    if (Math.abs(d) < 1e-30) d = 1e-30;
    c = 1 + num / c;
    if (Math.abs(c) < 1e-30) c = 1e-30;
    d = 1 / d;
    h *= d * c;

    // odd step
    num = -((a + m) * (a + b + m) * x) / ((a + 2 * m) * (a + 2 * m + 1));
    d = 1 + num * d;
    if (Math.abs(d) < 1e-30) d = 1e-30;
    c = 1 + num / c;
    if (Math.abs(c) < 1e-30) c = 1e-30;
    d = 1 / d;
    const delta = d * c;
    h *= delta;

    if (Math.abs(delta - 1) < 1e-12) break;
  }

  return factor * h;
}

// Standard Normal Distribution
export function dnorm(x: number, mean = 0, sd = 1): number {
  if (sd <= 0) return NaN;
  const z = (x - mean) / sd;
  return (1 / (sd * Math.sqrt(2 * Math.PI))) * Math.exp(-0.5 * z * z);
}

export function pnorm(x: number, mean = 0, sd = 1): number {
  if (sd <= 0) return NaN;
  const z = (x - mean) / sd;
  return 0.5 * (1 + erf(z / Math.SQRT2));
}

// Inverse standard normal (probit) using rational approximation (Acklam's algorithm)
export function qnorm(p: number, mean = 0, sd = 1): number {
  if (p <= 0 || p >= 1) return p <= 0 ? -Infinity : Infinity;

  // Coefficients in rational approximations
  const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.383577518672690e2, -3.066479806614716e1, 2.506628277459239e0];
  const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
  const c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838e0, -2.549732539343734e0, 4.374664141464968e0, 2.938163982698783e0];
  const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996e0, 3.754408661907416e0];

  const pLow = 0.02425;
  const pHigh = 1 - pLow;
  let q: number;

  if (p < pLow) {
    const qSqrt = Math.sqrt(-2 * Math.log(p));
    q = (((((c[0] * qSqrt + c[1]) * qSqrt + c[2]) * qSqrt + c[3]) * qSqrt + c[4]) * qSqrt + c[5]) /
      ((((d[0] * qSqrt + d[1]) * qSqrt + d[2]) * qSqrt + d[3]) * qSqrt + 1);
  } else if (p <= pHigh) {
    const r = p - 0.5;
    const r2 = r * r;
    q = (((((a[0] * r2 + a[1]) * r2 + a[2]) * r2 + a[3]) * r2 + a[4]) * r2 + a[5]) * r /
      (((((b[0] * r2 + b[1]) * r2 + b[2]) * r2 + b[3]) * r2 + b[4]) * r2 + 1);
  } else {
    const qSqrt = Math.sqrt(-2 * Math.log(1 - p));
    q = -(((((c[0] * qSqrt + c[1]) * qSqrt + c[2]) * qSqrt + c[3]) * qSqrt + c[4]) * qSqrt + c[5]) /
      ((((d[0] * qSqrt + d[1]) * qSqrt + d[2]) * qSqrt + d[3]) * qSqrt + 1);
  }

  // Refinement step with Halley's rational method
  const e = 0.5 * erfc(-q / Math.SQRT2) - p;
  const u = e * Math.SQRT2 * Math.sqrt(Math.PI) * Math.exp((q * q) / 2);
  q = q - u / (1 + (q * u) / 2);

  return mean + q * sd;
}

// Student-t CDF: pt(t, df)
export function pt(t: number, df: number): number {
  if (df <= 0) return NaN;
  const x = df / (df + t * t);
  const ib = incompleteBeta(x, df / 2, 0.5);
  if (t > 0) {
    return 1 - 0.5 * ib;
  } else {
    return 0.5 * ib;
  }
}

// Student-t Quantile: qt(p, df) using Newton-Raphson
export function qt(p: number, df: number): number {
  if (p <= 0 || p >= 1 || df <= 0) return NaN;
  if (df === 1) return Math.tan(Math.PI * (p - 0.5)); // Cauchy
  if (df === 2) return (2 * p - 1) / Math.sqrt(2 * p * (1 - p));

  // Initial estimate from normal
  let x = qnorm(p);
  // Hill's Cornish-Fisher expansion for t
  const a = 1 / (df - 0.5);
  const b = 48 / (a * a);
  const c = ((20700 * a / b - 98) * a - 16) * a + 96;
  const d = ((94.5 / (b + c) - 3) / b + 1) * Math.sqrt(a * Math.PI / 2) * df;
  x = x + (Math.pow(x, 3) + x) / (4 * df);

  // Newton refinement
  for (let i = 0; i < 15; i++) {
    const error = pt(x, df) - p;
    if (Math.abs(error) < 1e-9) break;
    // PDF of t-distribution
    const dt = (gamma((df + 1) / 2) / (Math.sqrt(df * Math.PI) * gamma(df / 2))) * Math.pow(1 + (x * x) / df, -(df + 1) / 2);
    x -= error / dt;
  }
  return x;
}

// Chi-Square CDF: pchisq(x, df)
export function pchisq(x: number, df: number): number {
  if (x <= 0 || df <= 0) return 0;
  return lowerIncompleteGamma(df / 2, x / 2);
}

// Chi-Square Quantile: qchisq(p, df)
export function qchisq(p: number, df: number): number {
  if (p <= 0 || p >= 1 || df <= 0) return NaN;
  // Wilson-Hilferty transformation as initial guess
  const z = qnorm(p);
  const term = 1 - 2 / (9 * df) + z * Math.sqrt(2 / (9 * df));
  let x = Math.max(0.001, df * Math.pow(term, 3));

  for (let i = 0; i < 20; i++) {
    const err = pchisq(x, df) - p;
    if (Math.abs(err) < 1e-9) break;
    // Chi-sq PDF
    const pdf = (1 / (Math.pow(2, df / 2) * gamma(df / 2))) * Math.pow(x, df / 2 - 1) * Math.exp(-x / 2);
    x -= err / Math.max(pdf, 1e-12);
    if (x <= 0) x = 0.001;
  }
  return x;
}

// F-Distribution CDF: pf(f, df1, df2)
export function pf(f: number, df1: number, df2: number): number {
  if (f <= 0 || df1 <= 0 || df2 <= 0) return 0;
  const x = (df1 * f) / (df1 * f + df2);
  return incompleteBeta(x, df1 / 2, df2 / 2);
}

// F-Distribution Quantile: qf(p, df1, df2)
export function qf(p: number, df1: number, df2: number): number {
  if (p <= 0 || p >= 1 || df1 <= 0 || df2 <= 0) return NaN;
  let f = 1.0;
  // Newton-Raphson solver
  for (let i = 0; i < 25; i++) {
    const err = pf(f, df1, df2) - p;
    if (Math.abs(err) < 1e-9) break;
    // F-distribution PDF
    const num = Math.pow(df1 * f, df1) * Math.pow(df2, df2);
    const den = Math.pow(df1 * f + df2, df1 + df2);
    const pdf = (1 / f) * (1 / (gamma(df1 / 2) * gamma(df2 / 2) / gamma((df1 + df2) / 2))) * Math.sqrt(num / den);
    f -= err / Math.max(pdf, 1e-12);
    if (f <= 0) f = 0.01;
  }
  return f;
}

// Matrix Operations for Multiple Regression, OLS, and PCA
export function transpose(A: number[][]): number[][] {
  const rows = A.length;
  const cols = A[0].length;
  const T: number[][] = Array.from({ length: cols }, () => Array(rows).fill(0));
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      T[j][i] = A[i][j];
    }
  }
  return T;
}

export function matMul(A: number[][], B: number[][]): number[][] {
  const rA = A.length;
  const cA = A[0].length;
  const cB = B[0].length;
  const C: number[][] = Array.from({ length: rA }, () => Array(cB).fill(0));
  for (let i = 0; i < rA; i++) {
    for (let k = 0; k < cA; k++) {
      for (let j = 0; j < cB; j++) {
        C[i][j] += A[i][k] * B[k][j];
      }
    }
  }
  return C;
}

// Gauss-Jordan matrix inversion with partial pivoting
export function invertMatrix(M: number[][]): number[][] | null {
  const n = M.length;
  const A = M.map(row => [...row]);
  const I: number[][] = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (__, j) => (i === j ? 1 : 0))
  );

  for (let i = 0; i < n; i++) {
    // Find pivot
    let maxRow = i;
    for (let k = i + 1; k < n; k++) {
      if (Math.abs(A[k][i]) > Math.abs(A[maxRow][i])) {
        maxRow = k;
      }
    }

    if (Math.abs(A[maxRow][i]) < 1e-12) return null; // Singular matrix

    // Swap rows
    [A[i], A[maxRow]] = [A[maxRow], A[i]];
    [I[i], I[maxRow]] = [I[maxRow], I[i]];

    // Normalize pivot row
    const pivot = A[i][i];
    for (let j = 0; j < n; j++) {
      A[i][j] /= pivot;
      I[i][j] /= pivot;
    }

    // Eliminate other rows
    for (let k = 0; k < n; k++) {
      if (k !== i) {
        const factor = A[k][i];
        for (let j = 0; j < n; j++) {
          A[k][j] -= factor * A[i][j];
          I[k][j] -= factor * I[i][j];
        }
      }
    }
  }

  return I;
}

// LOESS (Locally Estimated Scatterplot Smoothing) algorithm (Cleveland 1979)
export function loessSmoother(x: number[], y: number[], span = 0.66, iterations = 2): { x: number; y: number }[] {
  const n = x.length;
  if (n < 4) return x.map((xi, i) => ({ x: xi, y: y[i] }));

  // Sort by x
  const indices = Array.from({ length: n }, (_, i) => i).sort((a, b) => x[a] - x[b]);
  const xs = indices.map(i => x[i]);
  const ys = indices.map(i => y[i]);

  const k = Math.max(3, Math.floor(span * n));
  let smoothed = [...ys];
  let robustnessWeights = Array(n).fill(1.0);

  for (let iter = 0; iter < iterations; iter++) {
    const nextSmoothed = Array(n).fill(0);

    for (let i = 0; i < n; i++) {
      const xi = xs[i];
      // Compute distances
      const dists = xs.map((xj, j) => ({ j, d: Math.abs(xi - xj) })).sort((a, b) => a.d - b.d);
      const h = Math.max(1e-5, dists[k - 1].d);

      let sumW = 0;
      let sumWX = 0;
      let sumWY = 0;
      let sumWXX = 0;
      let sumWXY = 0;

      for (let m = 0; m < k; m++) {
        const j = dists[m].j;
        const u = dists[m].d / h;
        // Tricube kernel: (1 - u^3)^3 for 0 <= u < 1
        const tricube = u < 1 ? Math.pow(1 - Math.pow(u, 3), 3) : 0;
        const w = tricube * robustnessWeights[j];

        const xj = xs[j];
        const yj = ys[j];

        sumW += w;
        sumWX += w * xj;
        sumWY += w * yj;
        sumWXX += w * xj * xj;
        sumWXY += w * xj * yj;
      }

      const denom = sumW * sumWXX - sumWX * sumWX;
      if (Math.abs(denom) > 1e-12) {
        const beta1 = (sumW * sumWXY - sumWX * sumWY) / denom;
        const beta0 = (sumWY - beta1 * sumWX) / sumW;
        nextSmoothed[i] = beta0 + beta1 * xi;
      } else {
        nextSmoothed[i] = sumW > 0 ? sumWY / sumW : ys[i];
      }
    }

    smoothed = nextSmoothed;

    // Robustness weights via bisquare of residuals
    if (iter < iterations - 1) {
      const residuals = ys.map((yVal, idx) => Math.abs(yVal - smoothed[idx]));
      const s = residuals.slice().sort((a, b) => a - b)[Math.floor(n / 2)] || 1e-5;
      const h6 = 6 * s;
      robustnessWeights = residuals.map(r => {
        const u = r / h6;
        return u < 1 ? Math.pow(1 - u * u, 2) : 0;
      });
    }
  }

  return xs.map((xi, idx) => ({ x: xi, y: smoothed[idx] }));
}

// Eigenvalues and Eigenvectors for Symmetric Covariance Matrix (Jacobi algorithm for PCA)
export function jacobiEigen(A: number[][], maxIter = 100): { eigenvalues: number[]; eigenvectors: number[][] } {
  const n = A.length;
  const V: number[][] = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (__, j) => (i === j ? 1 : 0))
  );
  const D = A.map(row => [...row]);

  for (let iter = 0; iter < maxIter; iter++) {
    // Find largest off-diagonal element
    let p = 0;
    let q = 1;
    let maxVal = 0;

    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        if (Math.abs(D[i][j]) > maxVal) {
          maxVal = Math.abs(D[i][j]);
          p = i;
          q = j;
        }
      }
    }

    if (maxVal < 1e-12) break; // Converged

    const diff = D[q][q] - D[p][p];
    let t: number;
    if (Math.abs(D[p][q]) < Math.abs(diff) * 1e-15) {
      t = D[p][q] / diff;
    } else {
      const phi = diff / (2 * D[p][q]);
      t = 1 / (Math.abs(phi) + Math.sqrt(phi * phi + 1));
      if (phi < 0) t = -t;
    }

    const c = 1 / Math.sqrt(t * t + 1);
    const s = t * c;
    const tau = s / (1 + c);

    const tempDpq = D[p][q];
    D[p][q] = 0;
    D[p][p] -= t * tempDpq;
    D[q][q] += t * tempDpq;

    for (let r = 0; r < p; r++) {
      const Dpr = D[r][p];
      const Dqr = D[r][q];
      D[r][p] = Dpr - s * (Dqr + tau * Dpr);
      D[r][q] = Dqr + s * (Dpr - tau * Dqr);
    }
    for (let r = p + 1; r < q; r++) {
      const Dpr = D[p][r];
      const Dqr = D[r][q];
      D[p][r] = Dpr - s * (Dqr + tau * Dpr);
      D[r][q] = Dqr + s * (Dpr - tau * Dqr);
    }
    for (let r = q + 1; r < n; r++) {
      const Dpr = D[p][r];
      const Dqr = D[q][r];
      D[p][r] = Dpr - s * (Dqr + tau * Dpr);
      D[q][r] = Dqr + s * (Dpr - tau * Dqr);
    }

    for (let r = 0; r < n; r++) {
      const Vrp = V[r][p];
      const Vrq = V[r][q];
      V[r][p] = Vrp - s * (Vrq + tau * Vrp);
      V[r][q] = Vrq + s * (Vrp - tau * Vrq);
    }
  }

  const eigenvalues = Array.from({ length: n }, (_, i) => D[i][i]);
  // Sort descending
  const order = Array.from({ length: n }, (_, i) => i).sort((a, b) => eigenvalues[b] - eigenvalues[a]);
  const sortedEigenvalues = order.map(i => Math.max(0, eigenvalues[i]));
  const sortedEigenvectors = Array.from({ length: n }, (_, r) => order.map(c => V[r][c]));

  return { eigenvalues: sortedEigenvalues, eigenvectors: sortedEigenvectors };
}

// Sample Quantile (Type 7 default R standard)
export function computeQuantile(sortedArr: number[], q: number): number {
  if (sortedArr.length === 0) return NaN;
  if (sortedArr.length === 1) return sortedArr[0];
  if (q <= 0) return sortedArr[0];
  if (q >= 1) return sortedArr[sortedArr.length - 1];

  const pos = (sortedArr.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;

  if (sortedArr[base + 1] !== undefined) {
    return sortedArr[base] + rest * (sortedArr[base + 1] - sortedArr[base]);
  }
  return sortedArr[base];
}

// Numerical Formatter respecting chosen user precision
export function formatStat(value: number | undefined | null, precision: 2 | 3 | 4 | 'scientific' | 'full' = 3): string {
  if (value === undefined || value === null || isNaN(value)) return '—';
  if (!isFinite(value)) return value > 0 ? '+Inf' : '-Inf';

  if (precision === 'scientific') {
    return value.toExponential(3);
  }
  if (precision === 'full') {
    return String(value);
  }

  const absVal = Math.abs(value);
  if (absVal > 0 && absVal < 0.0001) {
    return value.toExponential(precision);
  }

  return value.toLocaleString('en-US', {
    minimumFractionDigits: precision,
    maximumFractionDigits: precision,
  });
}
