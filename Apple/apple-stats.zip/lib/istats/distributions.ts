import {
  dnorm,
  pnorm,
  qnorm,
  pt,
  qt,
  pchisq,
  qchisq,
  pf,
  qf,
  lowerIncompleteGamma,
  incompleteBeta,
  logGamma,
  gamma,
} from './math-utils';
import { DistributionType } from './types';

export interface DistributionInfo {
  type: DistributionType;
  name: string;
  category: 'continuous' | 'discrete';
  description: string;
  parameters: {
    name: string;
    label: string;
    defaultValue: number;
    min?: number;
    max?: number;
    step?: number;
    description: string;
  }[];
  rFunction: {
    density: string;
    cdf: string;
    quantile: string;
    random: string;
  };
}

export const DISTRIBUTIONS_REGISTRY: Record<DistributionType, DistributionInfo> = {
  normal: {
    type: 'normal',
    name: 'Normal (Gaussian)',
    category: 'continuous',
    description: 'Symmetric bell curve defined by mean (μ) and standard deviation (σ). Fundamental to the Central Limit Theorem.',
    parameters: [
      { name: 'mean', label: 'Mean (μ)', defaultValue: 0, description: 'Location parameter', step: 0.1 },
      { name: 'sd', label: 'Std Dev (σ)', defaultValue: 1, min: 0.001, description: 'Scale parameter', step: 0.1 },
    ],
    rFunction: { density: 'dnorm(x, mean, sd)', cdf: 'pnorm(q, mean, sd)', quantile: 'qnorm(p, mean, sd)', random: 'rnorm(n, mean, sd)' },
  },
  uniform: {
    type: 'uniform',
    name: 'Uniform',
    category: 'continuous',
    description: 'Constant probability density over a finite interval [min, max].',
    parameters: [
      { name: 'min', label: 'Minimum (a)', defaultValue: 0, description: 'Lower bound', step: 0.5 },
      { name: 'max', label: 'Maximum (b)', defaultValue: 10, description: 'Upper bound', step: 0.5 },
    ],
    rFunction: { density: 'dunif(x, min, max)', cdf: 'punif(q, min, max)', quantile: 'qunif(p, min, max)', random: 'runif(n, min, max)' },
  },
  t: {
    type: 't',
    name: 'Student-t',
    category: 'continuous',
    description: 'Heavier-tailed bell curve used for sample inference when population variance is unknown.',
    parameters: [
      { name: 'df', label: 'Degrees of Freedom (ν)', defaultValue: 5, min: 1, step: 1, description: 'Degrees of freedom' },
    ],
    rFunction: { density: 'dt(x, df)', cdf: 'pt(q, df)', quantile: 'qt(p, df)', random: 'rt(n, df)' },
  },
  chisquare: {
    type: 'chisquare',
    name: 'Chi-Square (χ²)',
    category: 'continuous',
    description: 'Distribution of the sum of squared independent standard normal variables.',
    parameters: [
      { name: 'df', label: 'Degrees of Freedom (k)', defaultValue: 4, min: 1, step: 1, description: 'Degrees of freedom' },
    ],
    rFunction: { density: 'dchisq(x, df)', cdf: 'pchisq(q, df)', quantile: 'qchisq(p, df)', random: 'rchisq(n, df)' },
  },
  f: {
    type: 'f',
    name: 'F-Distribution (Fisher-Snedecor)',
    category: 'continuous',
    description: 'Ratio of two independent scaled chi-square variables. Used in ANOVA and regression F-tests.',
    parameters: [
      { name: 'df1', label: 'Numerator df (d₁)', defaultValue: 3, min: 1, step: 1, description: 'Numerator df' },
      { name: 'df2', label: 'Denominator df (d₂)', defaultValue: 20, min: 1, step: 1, description: 'Denominator df' },
    ],
    rFunction: { density: 'df(x, df1, df2)', cdf: 'pf(q, df1, df2)', quantile: 'qf(p, df1, df2)', random: 'rf(n, df1, df2)' },
  },
  exponential: {
    type: 'exponential',
    name: 'Exponential',
    category: 'continuous',
    description: 'Time between events in a Poisson point process with constant rate λ. Memoryless property.',
    parameters: [
      { name: 'rate', label: 'Rate (λ)', defaultValue: 1.0, min: 0.001, step: 0.1, description: 'Rate of event occurrence' },
    ],
    rFunction: { density: 'dexp(x, rate)', cdf: 'pexp(q, rate)', quantile: 'qexp(p, rate)', random: 'rexp(n, rate)' },
  },
  gamma: {
    type: 'gamma',
    name: 'Gamma',
    category: 'continuous',
    description: 'Flexible two-parameter family for positive skewed variables (waiting times, insurance claims).',
    parameters: [
      { name: 'shape', label: 'Shape (k / α)', defaultValue: 2.0, min: 0.01, step: 0.1, description: 'Shape parameter' },
      { name: 'rate', label: 'Rate (β)', defaultValue: 1.0, min: 0.01, step: 0.1, description: 'Rate parameter' },
    ],
    rFunction: { density: 'dgamma(x, shape, rate)', cdf: 'pgamma(q, shape, rate)', quantile: 'qgamma(p, shape, rate)', random: 'rgamma(n, shape, rate)' },
  },
  beta: {
    type: 'beta',
    name: 'Beta',
    category: 'continuous',
    description: 'Defined on the interval [0, 1]. Conjugate prior for binomial proportions in Bayesian inference.',
    parameters: [
      { name: 'shape1', label: 'Shape 1 (α)', defaultValue: 2.0, min: 0.01, step: 0.2, description: 'First shape parameter' },
      { name: 'shape2', label: 'Shape 2 (β)', defaultValue: 5.0, min: 0.01, step: 0.2, description: 'Second shape parameter' },
    ],
    rFunction: { density: 'dbeta(x, shape1, shape2)', cdf: 'pbeta(q, shape1, shape2)', quantile: 'qbeta(p, shape1, shape2)', random: 'rbeta(n, shape1, shape2)' },
  },
  weibull: {
    type: 'weibull',
    name: 'Weibull',
    category: 'continuous',
    description: 'Extensively used in survival analysis, reliability engineering, and failure rate analysis.',
    parameters: [
      { name: 'shape', label: 'Shape (k)', defaultValue: 1.5, min: 0.01, step: 0.1, description: 'Shape parameter' },
      { name: 'scale', label: 'Scale (λ)', defaultValue: 1.0, min: 0.01, step: 0.1, description: 'Scale parameter' },
    ],
    rFunction: { density: 'dweibull(x, shape, scale)', cdf: 'pweibull(q, shape, scale)', quantile: 'qweibull(p, shape, scale)', random: 'rweibull(n, shape, scale)' },
  },
  lognormal: {
    type: 'lognormal',
    name: 'Log-Normal',
    category: 'continuous',
    description: 'Distribution of a variable whose logarithm is normally distributed (incomes, biological lengths).',
    parameters: [
      { name: 'meanlog', label: 'Meanlog (μ)', defaultValue: 0, description: 'Mean of log', step: 0.1 },
      { name: 'sdlog', label: 'Sdlog (σ)', defaultValue: 0.5, min: 0.001, description: 'SD of log', step: 0.05 },
    ],
    rFunction: { density: 'dlnorm(x, meanlog, sdlog)', cdf: 'plnorm(q, meanlog, sdlog)', quantile: 'qlnorm(p, meanlog, sdlog)', random: 'rlnorm(n, meanlog, sdlog)' },
  },
  binomial: {
    type: 'binomial',
    name: 'Binomial',
    category: 'discrete',
    description: 'Number of successes in n independent Bernoulli trials with success probability p.',
    parameters: [
      { name: 'size', label: 'Trials (n)', defaultValue: 20, min: 1, step: 1, description: 'Number of trials' },
      { name: 'prob', label: 'Prob (p)', defaultValue: 0.5, min: 0, max: 1, step: 0.05, description: 'Success probability' },
    ],
    rFunction: { density: 'dbinom(x, size, prob)', cdf: 'pbinom(q, size, prob)', quantile: 'qbinom(p, size, prob)', random: 'rbinom(n, size, prob)' },
  },
  poisson: {
    type: 'poisson',
    name: 'Poisson',
    category: 'discrete',
    description: 'Counts of rare independent events occurring in a fixed interval with average rate λ.',
    parameters: [
      { name: 'lambda', label: 'Mean (λ)', defaultValue: 4, min: 0.01, step: 0.5, description: 'Expected rate/count' },
    ],
    rFunction: { density: 'dpois(x, lambda)', cdf: 'ppois(q, lambda)', quantile: 'qpois(p, lambda)', random: 'rpois(n, lambda)' },
  },
  geometric: {
    type: 'geometric',
    name: 'Geometric',
    category: 'discrete',
    description: 'Number of failures before the first success in Bernoulli trials with probability p.',
    parameters: [
      { name: 'prob', label: 'Prob (p)', defaultValue: 0.3, min: 0.01, max: 1, step: 0.05, description: 'Success probability' },
    ],
    rFunction: { density: 'dgeom(x, prob)', cdf: 'pgeom(q, prob)', quantile: 'qgeom(p, prob)', random: 'rgeom(n, prob)' },
  },
  negbinomial: {
    type: 'negbinomial',
    name: 'Negative Binomial',
    category: 'discrete',
    description: 'Number of failures before target number of successes r is reached. Models overdispersed counts.',
    parameters: [
      { name: 'size', label: 'Target Successes (r)', defaultValue: 5, min: 1, step: 1, description: 'Target successes' },
      { name: 'prob', label: 'Prob (p)', defaultValue: 0.5, min: 0.01, max: 1, step: 0.05, description: 'Success probability' },
    ],
    rFunction: { density: 'dnbinom(x, size, prob)', cdf: 'pnbinom(q, size, prob)', quantile: 'qnbinom(p, size, prob)', random: 'rnbinom(n, size, prob)' },
  },
  hypergeometric: {
    type: 'hypergeometric',
    name: 'Hypergeometric',
    category: 'discrete',
    description: 'Sampling without replacement: number of successes drawn from a finite population.',
    parameters: [
      { name: 'm', label: 'White balls (m)', defaultValue: 10, min: 1, step: 1, description: 'Total successes in urn' },
      { name: 'n', label: 'Black balls (n)', defaultValue: 15, min: 1, step: 1, description: 'Total failures in urn' },
      { name: 'k', label: 'Drawn (k)', defaultValue: 7, min: 1, step: 1, description: 'Sample drawn without replacement' },
    ],
    rFunction: { density: 'dhyper(x, m, n, k)', cdf: 'phyper(q, m, n, k)', quantile: 'qhyper(p, m, n, k)', random: 'rhyper(nn, m, n, k)' },
  },
};

// Factorial helper
function factorial(n: number): number {
  if (n < 0) return NaN;
  if (n <= 1) return 1;
  let res = 1;
  for (let i = 2; i <= n; i++) res *= i;
  return res;
}

// Log combinations ln(n choose k)
function logChoose(n: number, k: number): number {
  if (k < 0 || k > n) return -Infinity;
  return logGamma(n + 1) - logGamma(k + 1) - logGamma(n - k + 1);
}

// Unified Density/Mass function
export function computePDF(type: DistributionType, x: number, params: Record<string, number>): number {
  switch (type) {
    case 'normal':
      return dnorm(x, params.mean ?? 0, params.sd ?? 1);
    case 'uniform': {
      const min = params.min ?? 0;
      const max = params.max ?? 1;
      return x >= min && x <= max ? 1 / (max - min) : 0;
    }
    case 't': {
      const df = params.df ?? 5;
      return (gamma((df + 1) / 2) / (Math.sqrt(df * Math.PI) * gamma(df / 2))) * Math.pow(1 + (x * x) / df, -(df + 1) / 2);
    }
    case 'chisquare': {
      const df = params.df ?? 4;
      if (x <= 0) return 0;
      return (1 / (Math.pow(2, df / 2) * gamma(df / 2))) * Math.pow(x, df / 2 - 1) * Math.exp(-x / 2);
    }
    case 'f': {
      const df1 = params.df1 ?? 3;
      const df2 = params.df2 ?? 20;
      if (x <= 0) return 0;
      const num = Math.pow(df1 * x, df1) * Math.pow(df2, df2);
      const den = Math.pow(df1 * x + df2, df1 + df2);
      return (1 / x) * (1 / (gamma(df1 / 2) * gamma(df2 / 2) / gamma((df1 + df2) / 2))) * Math.sqrt(num / den);
    }
    case 'exponential': {
      const rate = params.rate ?? 1;
      return x >= 0 ? rate * Math.exp(-rate * x) : 0;
    }
    case 'gamma': {
      const shape = params.shape ?? 2;
      const rate = params.rate ?? 1;
      if (x <= 0) return 0;
      return (Math.pow(rate, shape) / gamma(shape)) * Math.pow(x, shape - 1) * Math.exp(-rate * x);
    }
    case 'beta': {
      const a = params.shape1 ?? 2;
      const b = params.shape2 ?? 5;
      if (x <= 0 || x >= 1) return 0;
      return (1 / Math.exp(logGamma(a) + logGamma(b) - logGamma(a + b))) * Math.pow(x, a - 1) * Math.pow(1 - x, b - 1);
    }
    case 'weibull': {
      const k = params.shape ?? 1.5;
      const lambda = params.scale ?? 1;
      if (x < 0) return 0;
      return (k / lambda) * Math.pow(x / lambda, k - 1) * Math.exp(-Math.pow(x / lambda, k));
    }
    case 'lognormal': {
      const meanlog = params.meanlog ?? 0;
      const sdlog = params.sdlog ?? 0.5;
      if (x <= 0) return 0;
      return (1 / (x * sdlog * Math.sqrt(2 * Math.PI))) * Math.exp(-Math.pow(Math.log(x) - meanlog, 2) / (2 * sdlog * sdlog));
    }
    case 'binomial': {
      const n = Math.round(params.size ?? 20);
      const p = params.prob ?? 0.5;
      const k = Math.round(x);
      if (k < 0 || k > n || Math.abs(x - k) > 1e-6) return 0;
      return Math.exp(logChoose(n, k) + k * Math.log(p) + (n - k) * Math.log(1 - p));
    }
    case 'poisson': {
      const lambda = params.lambda ?? 4;
      const k = Math.round(x);
      if (k < 0 || Math.abs(x - k) > 1e-6) return 0;
      return Math.exp(k * Math.log(lambda) - lambda - logGamma(k + 1));
    }
    case 'geometric': {
      const p = params.prob ?? 0.3;
      const k = Math.round(x);
      if (k < 0 || Math.abs(x - k) > 1e-6) return 0;
      return Math.pow(1 - p, k) * p;
    }
    case 'negbinomial': {
      const r = Math.round(params.size ?? 5);
      const p = params.prob ?? 0.5;
      const k = Math.round(x);
      if (k < 0 || Math.abs(x - k) > 1e-6) return 0;
      return Math.exp(logChoose(k + r - 1, k) + r * Math.log(p) + k * Math.log(1 - p));
    }
    case 'hypergeometric': {
      const m = Math.round(params.m ?? 10);
      const n = Math.round(params.n ?? 15);
      const k = Math.round(params.k ?? 7);
      const xInt = Math.round(x);
      if (xInt < Math.max(0, k - n) || xInt > Math.min(k, m)) return 0;
      return Math.exp(logChoose(m, xInt) + logChoose(n, k - xInt) - logChoose(m + n, k));
    }
    default:
      return 0;
  }
}

// Unified CDF function P(X <= q)
export function computeCDF(type: DistributionType, q: number, params: Record<string, number>): number {
  switch (type) {
    case 'normal':
      return pnorm(q, params.mean ?? 0, params.sd ?? 1);
    case 'uniform': {
      const min = params.min ?? 0;
      const max = params.max ?? 1;
      if (q < min) return 0;
      if (q > max) return 1;
      return (q - min) / (max - min);
    }
    case 't':
      return pt(q, params.df ?? 5);
    case 'chisquare':
      return pchisq(q, params.df ?? 4);
    case 'f':
      return pf(q, params.df1 ?? 3, params.df2 ?? 20);
    case 'exponential': {
      const rate = params.rate ?? 1;
      return q >= 0 ? 1 - Math.exp(-rate * q) : 0;
    }
    case 'gamma': {
      const shape = params.shape ?? 2;
      const rate = params.rate ?? 1;
      if (q <= 0) return 0;
      return lowerIncompleteGamma(shape, rate * q);
    }
    case 'beta': {
      const a = params.shape1 ?? 2;
      const b = params.shape2 ?? 5;
      if (q <= 0) return 0;
      if (q >= 1) return 1;
      return incompleteBeta(q, a, b);
    }
    case 'weibull': {
      const k = params.shape ?? 1.5;
      const lambda = params.scale ?? 1;
      if (q <= 0) return 0;
      return 1 - Math.exp(-Math.pow(q / lambda, k));
    }
    case 'lognormal': {
      const meanlog = params.meanlog ?? 0;
      const sdlog = params.sdlog ?? 0.5;
      if (q <= 0) return 0;
      return pnorm(Math.log(q), meanlog, sdlog);
    }
    case 'binomial': {
      const n = Math.round(params.size ?? 20);
      const p = params.prob ?? 0.5;
      if (q < 0) return 0;
      if (q >= n) return 1;
      let sum = 0;
      for (let k = 0; k <= Math.floor(q); k++) {
        sum += computePDF('binomial', k, params);
      }
      return Math.min(1, Math.max(0, sum));
    }
    case 'poisson': {
      const lambda = params.lambda ?? 4;
      if (q < 0) return 0;
      let sum = 0;
      for (let k = 0; k <= Math.floor(q); k++) {
        sum += computePDF('poisson', k, params);
      }
      return Math.min(1, Math.max(0, sum));
    }
    default:
      return 0.5;
  }
}

// Generate points for curve rendering in distribution calculator
export function generateDistributionCurve(
  type: DistributionType,
  params: Record<string, number>,
  numPoints = 200
): { x: number; pdf: number; cdf: number }[] {
  let minX = -4;
  let maxX = 4;

  switch (type) {
    case 'normal': {
      const mu = params.mean ?? 0;
      const s = params.sd ?? 1;
      minX = mu - 4 * s;
      maxX = mu + 4 * s;
      break;
    }
    case 'uniform': {
      const a = params.min ?? 0;
      const b = params.max ?? 10;
      minX = a - (b - a) * 0.1;
      maxX = b + (b - a) * 0.1;
      break;
    }
    case 't': {
      minX = -5;
      maxX = 5;
      break;
    }
    case 'chisquare': {
      const df = params.df ?? 4;
      minX = 0;
      maxX = Math.max(10, df + 4 * Math.sqrt(2 * df));
      break;
    }
    case 'f': {
      minX = 0;
      maxX = 6;
      break;
    }
    case 'exponential': {
      const rate = params.rate ?? 1;
      minX = 0;
      maxX = 5 / rate;
      break;
    }
    case 'gamma': {
      const k = params.shape ?? 2;
      const b = params.rate ?? 1;
      minX = 0;
      maxX = (k / b) + 4 * Math.sqrt(k / (b * b));
      break;
    }
    case 'beta': {
      minX = 0;
      maxX = 1;
      break;
    }
    case 'binomial': {
      const n = params.size ?? 20;
      minX = 0;
      maxX = n;
      const discretePoints: { x: number; pdf: number; cdf: number }[] = [];
      let accum = 0;
      for (let k = 0; k <= n; k++) {
        const pdf = computePDF('binomial', k, params);
        accum += pdf;
        discretePoints.push({ x: k, pdf, cdf: accum });
      }
      return discretePoints;
    }
    case 'poisson': {
      const lambda = params.lambda ?? 4;
      minX = 0;
      maxX = Math.max(10, Math.ceil(lambda + 4 * Math.sqrt(lambda)));
      const discretePoints: { x: number; pdf: number; cdf: number }[] = [];
      let accum = 0;
      for (let k = 0; k <= maxX; k++) {
        const pdf = computePDF('poisson', k, params);
        accum += pdf;
        discretePoints.push({ x: k, pdf, cdf: accum });
      }
      return discretePoints;
    }
    default:
      minX = -4;
      maxX = 4;
  }

  const step = (maxX - minX) / (numPoints - 1);
  const points: { x: number; pdf: number; cdf: number }[] = [];

  for (let i = 0; i < numPoints; i++) {
    const x = minX + i * step;
    points.push({
      x,
      pdf: computePDF(type, x, params),
      cdf: computeCDF(type, x, params),
    });
  }

  return points;
}
