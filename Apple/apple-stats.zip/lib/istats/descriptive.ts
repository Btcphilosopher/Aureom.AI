import { DescriptiveStats } from './types';

/**
 * Computes quantile using R Type 7 default definition: Q[i](p) = (1-gamma)*x[j] + gamma*x[j+1]
 */
export function computeQuantile(sortedValues: number[], p: number): number {
  const n = sortedValues.length;
  if (n === 0) return NaN;
  if (n === 1) return sortedValues[0];
  if (p <= 0) return sortedValues[0];
  if (p >= 1) return sortedValues[n - 1];

  const index = (n - 1) * p;
  const lo = Math.floor(index);
  const hi = Math.ceil(index);
  const h = index - lo;

  return (1 - h) * sortedValues[lo] + h * sortedValues[hi];
}

export function computeDescriptiveStats(
  values: any[],
  variableName: string,
  isNumeric = true
): DescriptiveStats {
  const totalCount = values.length;

  if (!isNumeric) {
    // Categorical frequency analysis
    const counts: Record<string, number> = {};
    let validCount = 0;
    let missingCount = 0;

    for (const val of values) {
      if (val === null || val === undefined || val === '') {
        missingCount++;
      } else {
        validCount++;
        const strVal = String(val);
        counts[strVal] = (counts[strVal] || 0) + 1;
      }
    }

    const frequencies: Record<string, { count: number; percentage: number }> = {};
    let maxFreq = -1;
    let modes: string[] = [];

    for (const [key, cnt] of Object.entries(counts)) {
      frequencies[key] = {
        count: cnt,
        percentage: validCount > 0 ? (cnt / validCount) * 100 : 0,
      };
      if (cnt > maxFreq) {
        maxFreq = cnt;
        modes = [key];
      } else if (cnt === maxFreq) {
        modes.push(key);
      }
    }

    return {
      variable: variableName,
      count: totalCount,
      validCount,
      missingCount,
      mode: modes,
      frequencies,
    };
  }

  // Numeric analysis
  const numericValues: number[] = [];
  let missingCount = 0;

  for (const v of values) {
    if (v === null || v === undefined || v === '' || isNaN(Number(v))) {
      missingCount++;
    } else {
      numericValues.push(Number(v));
    }
  }

  const n = numericValues.length;
  if (n === 0) {
    return {
      variable: variableName,
      count: totalCount,
      validCount: 0,
      missingCount,
    };
  }

  numericValues.sort((a, b) => a - b);

  let sum = 0;
  for (let i = 0; i < n; i++) sum += numericValues[i];
  const mean = sum / n;

  const min = numericValues[0];
  const max = numericValues[n - 1];
  const range = max - min;

  // Median
  const median = computeQuantile(numericValues, 0.5);

  // Variance & SD (Sample, Bessel's correction n - 1)
  let sumSqDiff = 0;
  for (let i = 0; i < n; i++) {
    const diff = numericValues[i] - mean;
    sumSqDiff += diff * diff;
  }
  const variance = n > 1 ? sumSqDiff / (n - 1) : 0;
  const sd = Math.sqrt(variance);
  const se = n > 0 ? sd / Math.sqrt(n) : 0;
  const cv = mean !== 0 ? (sd / Math.abs(mean)) * 100 : 0;

  // Quartiles
  const q1 = computeQuantile(numericValues, 0.25);
  const q3 = computeQuantile(numericValues, 0.75);
  const iqr = q3 - q1;

  // Median Absolute Deviation (MAD) with standard normal consistency constant 1.4826
  const absDevs = numericValues.map(v => Math.abs(v - median)).sort((a, b) => a - b);
  const rawMad = computeQuantile(absDevs, 0.5);
  const mad = rawMad * 1.4826;

  // Skewness (Fisher-Pearson adjusted sample skewness)
  let skewness = 0;
  if (n > 2 && sd > 0) {
    let m3 = 0;
    for (let i = 0; i < n; i++) {
      m3 += Math.pow((numericValues[i] - mean) / sd, 3);
    }
    skewness = (n / ((n - 1) * (n - 2))) * m3;
  }

  // Excess Kurtosis (Sample adjusted)
  let kurtosis = 0;
  if (n > 3 && sd > 0) {
    let m4 = 0;
    for (let i = 0; i < n; i++) {
      m4 += Math.pow((numericValues[i] - mean) / sd, 4);
    }
    const factor1 = (n * (n + 1)) / ((n - 1) * (n - 2) * (n - 3));
    const factor2 = (3 * Math.pow(n - 1, 2)) / ((n - 2) * (n - 3));
    kurtosis = factor1 * m4 - factor2;
  }

  // Geometric Mean (only positive numbers)
  let geometricMean: number | undefined;
  const allPositive = numericValues.every(v => v > 0);
  if (allPositive && n > 0) {
    let logSum = 0;
    for (let i = 0; i < n; i++) logSum += Math.log(numericValues[i]);
    geometricMean = Math.exp(logSum / n);
  }

  // Harmonic Mean (only positive numbers)
  let harmonicMean: number | undefined;
  if (allPositive && n > 0) {
    let invSum = 0;
    for (let i = 0; i < n; i++) invSum += 1 / numericValues[i];
    harmonicMean = n / invSum;
  }

  // Trimmed Mean (10% trim default)
  const trimK = Math.floor(n * 0.1);
  let trimmedMean: number | undefined;
  if (n > 2 * trimK && trimK > 0) {
    const trimmedSlice = numericValues.slice(trimK, n - trimK);
    const trimmedSum = trimmedSlice.reduce((a, b) => a + b, 0);
    trimmedMean = trimmedSum / trimmedSlice.length;
  } else {
    trimmedMean = mean;
  }

  // Mode
  const freqMap: Record<number, number> = {};
  let maxCount = 0;
  for (const num of numericValues) {
    freqMap[num] = (freqMap[num] || 0) + 1;
    if (freqMap[num] > maxCount) maxCount = freqMap[num];
  }
  const modes: number[] = [];
  if (maxCount > 1) {
    for (const [k, count] of Object.entries(freqMap)) {
      if (count === maxCount) modes.push(Number(k));
    }
  }

  // Percentiles map
  const percentiles: Record<number, number> = {
    5: computeQuantile(numericValues, 0.05),
    10: computeQuantile(numericValues, 0.1),
    25: q1,
    50: median,
    75: q3,
    90: computeQuantile(numericValues, 0.9),
    95: computeQuantile(numericValues, 0.95),
    99: computeQuantile(numericValues, 0.99),
  };

  return {
    variable: variableName,
    count: totalCount,
    validCount: n,
    missingCount,
    sum,
    mean,
    median,
    mode: modes.length > 0 ? modes : undefined,
    min,
    max,
    range,
    variance,
    sd,
    se,
    cv,
    q1,
    q3,
    iqr,
    mad,
    skewness,
    kurtosis,
    geometricMean,
    harmonicMean,
    trimmedMean,
    percentiles,
  };
}
