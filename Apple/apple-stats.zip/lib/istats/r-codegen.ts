export function generateFullRScript(
  datasetName: string,
  analysisType: string,
  variables: string[],
  settings: Record<string, any> = {}
): string {
  const varsFormatted = variables.map(v => `"${v}"`).join(', ');

  switch (analysisType) {
    case 'descriptive':
      return `### ==============================================================================
### Apple Stats (iStats Engine) — Descriptive Statistical Report
### Dataset: ${datasetName}
### Variables: ${variables.join(', ')}
### ==============================================================================

# 1. Load Required Statistical Packages
library(readr)
library(dplyr)
library(ggplot2)
library(broom)

# 2. Inspect Structure and Summary
glimpse(dataset[, c(${varsFormatted})])
summary(dataset[, c(${varsFormatted})])

# 3. Comprehensive Summary Statistics (Moments & Quantiles)
descriptive_summary <- dataset %>%
  summarise(across(
    c(${varsFormatted}),
    list(
      N = ~sum(!is.na(.)),
      Mean = ~mean(., na.rm = TRUE),
      SD = ~sd(., na.rm = TRUE),
      Median = ~median(., na.rm = TRUE),
      IQR = ~IQR(., na.rm = TRUE),
      Min = ~min(., na.rm = TRUE),
      Max = ~max(., na.rm = TRUE)
    )
  ))

print(descriptive_summary)

# 4. Publication-Quality Distribution Plot (ggplot2)
${
  variables.length > 0
    ? `ggplot(dataset, aes(x = ${variables[0]})) +
  geom_histogram(aes(y = after_stat(density)), bins = 30, fill = "#3B82F6", alpha = 0.6, color = "white") +
  geom_density(color = "#1D4ED8", linewidth = 1.2) +
  theme_minimal(base_size = 14) +
  labs(
    title = "Empirical Distribution of ${variables[0]}",
    subtitle = "Histogram with overlaid Kernel Density Estimation (KDE)",
    x = "${variables[0]}",
    y = "Density"
  )`
    : ''
}`;

    case 'correlation':
      return `### ==============================================================================
### Apple Stats (iStats Engine) — Correlation Analysis & Heatmap
### Dataset: ${datasetName}
### ==============================================================================

library(dplyr)
library(ggplot2)
library(corrplot)

num_data <- dataset[, c(${varsFormatted})]

# 1. Pearson Correlation Matrix
cor_matrix <- cor(num_data, use = "pairwise.complete.obs", method = "pearson")
print(round(cor_matrix, 3))

# 2. Significance Test (p-values)
cor_tests <- psych::corr.test(num_data, method = "pearson", adjust = "holm")
print(cor_tests$p)

# 3. Interactive / Static Heatmap Visualisation
corrplot(
  cor_matrix,
  method = "color",
  type = "upper",
  addCoef.col = "black",
  tl.col = "black",
  tl.srt = 45,
  diag = FALSE,
  title = "Correlation Heatmap"
)`;

    case 'regression': {
      const dep = settings.dependentVar || variables[0] || 'Y';
      const indeps = settings.independentVars || variables.slice(1);
      const formula = `${dep} ~ ${indeps.join(' + ')}`;
      return `### ==============================================================================
### Apple Stats (iStats Engine) — Multiple Linear Regression Model
### Model Formula: ${formula}
### ==============================================================================

library(readr)
library(dplyr)
library(ggplot2)
library(car)      # For VIF and diagnostic tests
library(broom)    # Tidy model representations

# 1. Fit Ordinary Least Squares (OLS) Linear Model
model <- lm(${formula}, data = dataset)

# 2. Comprehensive Model Summary
summary(model)

# 3. Model Coefficients with 95% Confidence Intervals
tidy_coefs <- tidy(model, conf.int = TRUE, conf.level = 0.95)
print(tidy_coefs)

# 4. Multicollinearity Diagnostics (Variance Inflation Factor)
${indeps.length > 1 ? `print(vif(model))` : '# Single predictor: VIF not required'}

# 5. ANOVA Decomposition Table
anova(model)

# 6. Four-Panel Diagnostic Plots (Residuals, Q-Q, Scale-Location, Cook\\'s D)
par(mfrow = c(2, 2))
plot(model)
par(mfrow = c(1, 1))`;
    }

    case 'hypothesis': {
      const g1 = variables[0] || 'Var1';
      const g2 = variables[1] || 'Var2';
      return `### ==============================================================================
### Apple Stats (iStats Engine) — Inferential Hypothesis Test
### Variables: ${g1}, ${g2}
### ==============================================================================

library(dplyr)
library(rstatix)
library(ggplot2)

# Welch Two-Sample t-test (Does not assume equal variances)
welch_res <- t.test(dataset$${g1}, dataset$${g2}, var.equal = FALSE)
print(welch_res)

# Standardized Effect Size (Cohen's d)
cohen_res <- cohens_d(dataset, ${g1} ~ 1) # or paired formula
print(cohen_res)

# Visual Comparison Boxplot + Jitter Points
ggplot(dataset, aes(x = Group, y = Value, fill = Group)) +
  geom_boxplot(alpha = 0.7, outlier.shape = NA) +
  geom_jitter(width = 0.2, alpha = 0.5, size = 2) +
  theme_minimal(base_size = 14) +
  labs(
    title = "Two-Group Comparison with 95% Confidence Intervals",
    subtitle = paste("Welch t =", round(welch_res$statistic, 3), ", p =", format.pval(welch_res$p.value, digits = 3))
  )`;
    }

    default:
      return `# Apple Stats (iStats) R Script
library(dplyr)
library(ggplot2)
summary(dataset)`;
  }
}

import { Dataset } from './types';

export function generateCompleteRScript(dataset: Dataset): string {
  const numericVars = dataset.variables.filter(v => v.type === 'continuous' || v.type === 'discrete').map(v => v.name);
  const categoricalVars = dataset.variables.filter(v => v.type === 'nominal' || v.type === 'ordinal' || v.type === 'binary').map(v => v.name);

  return `### ==============================================================================
### Apple Stats (iStats Computational Foundation Engine)
### Dataset: ${dataset.name} (${dataset.rows.length} rows, ${dataset.variables.length} variables)
### Generated: ${new Date().toISOString().split('T')[0]}
### ==============================================================================

# 1. Load Essential Statistical Libraries
suppressPackageStartupMessages({
  library(tidyverse)   # Data manipulation & ggplot2 graphics
  library(car)         # Regression diagnostics & VIF
  library(forecast)    # Time series forecasting
  library(psych)       # Factor analysis & correlation matrices
  library(survival)    # Kaplan-Meier survival curves
  library(boot)        # Nonparametric bootstrap estimation
})

# 2. Dataset Initialization & Schema Audit
${dataset.rCitation || `# data <- read.csv("${dataset.name.toLowerCase().replace(/\\s+/g, '_')}.csv")`}
# data <- tibble::as_tibble(data)

# 3. Exploratory Data Analysis & Variable Summaries
glimpse(data)
summary(data)

${numericVars.length > 0 ? `# 4. Univariate Descriptive Statistics for ${numericVars[0]}
stat_summary <- data %>%
  summarise(
    n = n(),
    mean = mean(${numericVars[0]}, na.rm = TRUE),
    sd = sd(${numericVars[0]}, na.rm = TRUE),
    median = median(${numericVars[0]}, na.rm = TRUE),
    iqr = IQR(${numericVars[0]}, na.rm = TRUE),
    skewness = psych::skew(${numericVars[0]}),
    kurtosis = psych::kurtosi(${numericVars[0]})
  )
print(stat_summary)

# 5. Density & Normality Q-Q Plot
p1 <- ggplot(data, aes(x = ${numericVars[0]})) +
  geom_histogram(aes(y = after_stat(density)), bins = 30, fill = "#3B82F6", alpha = 0.6, color = "white") +
  geom_density(color = "#1D4ED8", linewidth = 1.2) +
  theme_minimal(base_size = 14) +
  labs(title = "Distribution of ${numericVars[0]}", subtitle = "Kernel Density & Histogram")

p2 <- ggplot(data, aes(sample = ${numericVars[0]})) +
  stat_qq() + stat_qq_line(color = "red") +
  theme_minimal(base_size = 14) +
  labs(title = "Normal Q-Q Plot", subtitle = "Theoretical vs Sample Quantiles")

gridExtra::grid.arrange(p1, p2, ncol = 2)
` : ''}

${numericVars.length >= 2 ? `# 6. Multiple Linear Regression Model
model <- lm(${numericVars[0]} ~ ${numericVars.slice(1, 4).join(' + ')}, data = data)
summary(model)
confint(model)
car::vif(model)

# 7. Four-Panel Residual Diagnostics
par(mfrow = c(2, 2))
plot(model)
par(mfrow = c(1, 1))
` : ''}

${numericVars.length >= 2 && categoricalVars.length >= 1 ? `# 8. Hypothesis Testing: Welch Two-Sample t-test / ANOVA
t_test_res <- t.test(${numericVars[0]} ~ ${categoricalVars[0]}, data = data)
print(t_test_res)

aov_res <- aov(${numericVars[0]} ~ ${categoricalVars[0]}, data = data)
summary(aov_res)
TukeyHSD(aov_res)
` : ''}

# End of reproducible iStats R script
`;
}
