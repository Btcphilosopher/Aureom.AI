import { jacobiEigen, pchisq } from './math-utils';
import { PcaResult, ClusterResult, SurvivalResult } from './types';

// Principal Component Analysis (PCA)
export function runPCA(
  data: Record<string, any>[],
  variables: string[],
  scale = true
): PcaResult {
  const cleanRows = data.filter(row => {
    for (const v of variables) {
      if (row[v] === null || row[v] === undefined || isNaN(Number(row[v]))) return false;
    }
    return true;
  });

  const n = cleanRows.length;
  const p = variables.length;

  // Compute means and SDs
  const means: number[] = Array(p).fill(0);
  const sds: number[] = Array(p).fill(0);

  for (let j = 0; j < p; j++) {
    const colName = variables[j];
    let sum = 0;
    for (let i = 0; i < n; i++) sum += Number(cleanRows[i][colName]);
    means[j] = sum / n;

    let sumSq = 0;
    for (let i = 0; i < n; i++) {
      sumSq += Math.pow(Number(cleanRows[i][colName]) - means[j], 2);
    }
    sds[j] = scale ? Math.sqrt(sumSq / (n - 1)) || 1 : 1;
  }

  // Standardized Matrix Z
  const Z: number[][] = cleanRows.map(r =>
    variables.map((v, j) => (Number(r[v]) - means[j]) / sds[j])
  );

  // Covariance / Correlation Matrix (Z^T * Z) / (n - 1)
  const covMat: number[][] = Array.from({ length: p }, () => Array(p).fill(0));
  for (let j1 = 0; j1 < p; j1++) {
    for (let j2 = 0; j2 < p; j2++) {
      let sumProd = 0;
      for (let i = 0; i < n; i++) {
        sumProd += Z[i][j1] * Z[i][j2];
      }
      covMat[j1][j2] = sumProd / (n - 1);
    }
  }

  // Eigenvalues & Eigenvectors
  const { eigenvalues, eigenvectors } = jacobiEigen(covMat);

  const totalVar = eigenvalues.reduce((a, b) => a + b, 0);
  let cumVar = 0;

  const components = eigenvalues.map((lambda, idx) => {
    const varPct = totalVar > 0 ? (lambda / totalVar) * 100 : 0;
    cumVar += varPct;

    const loadings: Record<string, number> = {};
    for (let j = 0; j < p; j++) {
      loadings[variables[j]] = eigenvectors[j][idx];
    }

    return {
      name: `PC${idx + 1}`,
      eigenvalue: lambda,
      varianceExplained: varPct,
      cumulativeVariance: cumVar,
      loadings,
    };
  });

  // Calculate Principal Component Scores: Score_i = Z_i * V
  const scores = cleanRows.map((r, i) => {
    let pc1 = 0;
    let pc2 = 0;
    let pc3 = 0;

    for (let j = 0; j < p; j++) {
      pc1 += Z[i][j] * (eigenvectors[j][0] || 0);
      if (p > 1) pc2 += Z[i][j] * (eigenvectors[j][1] || 0);
      if (p > 2) pc3 += Z[i][j] * (eigenvectors[j][2] || 0);
    }

    // Try finding categorical label in row
    const labelKey = Object.keys(r).find(k => !variables.includes(k) && typeof r[k] === 'string');

    return {
      id: i + 1,
      pc1,
      pc2,
      pc3: p > 2 ? pc3 : undefined,
      category: labelKey ? String(r[labelKey]) : undefined,
    };
  });

  const rCode = `# Principal Component Analysis in R
pca_res <- prcomp(dataset[, c(${variables.map(v => `"${v}"`).join(', ')}], scale. = ${scale ? 'TRUE' : 'FALSE'})
summary(pca_res)
biplot(pca_res)`;

  return {
    variables,
    nComponents: p,
    components,
    scores,
    rCode,
  };
}

// K-Means Clustering (k-means++ initialization)
export function runKMeans(
  data: Record<string, any>[],
  variables: string[],
  k = 3,
  maxIter = 30
): ClusterResult {
  const cleanRows = data.filter(row => {
    for (const v of variables) {
      if (row[v] === null || row[v] === undefined || isNaN(Number(row[v]))) return false;
    }
    return true;
  });

  const n = cleanRows.length;
  const p = variables.length;

  const points: number[][] = cleanRows.map(r => variables.map(v => Number(r[v])));

  // k-means++ seeding
  const centroids: number[][] = [];
  centroids.push([...points[Math.floor(Math.random() * n)]]);

  while (centroids.length < k) {
    const distSq = points.map(pt => {
      let minDist = Infinity;
      for (const c of centroids) {
        let d = 0;
        for (let j = 0; j < p; j++) d += Math.pow(pt[j] - c[j], 2);
        if (d < minDist) minDist = d;
      }
      return minDist;
    });

    const sumDist = distSq.reduce((a, b) => a + b, 0);
    let rand = Math.random() * sumDist;
    let chosenIdx = 0;
    for (let i = 0; i < n; i++) {
      rand -= distSq[i];
      if (rand <= 0) {
        chosenIdx = i;
        break;
      }
    }
    centroids.push([...points[chosenIdx]]);
  }

  // Iterative Lloyd's updates
  let assignments = Array(n).fill(0);

  for (let iter = 0; iter < maxIter; iter++) {
    // Assign clusters
    let changed = false;
    for (let i = 0; i < n; i++) {
      let bestCluster = 0;
      let bestDist = Infinity;
      for (let cIdx = 0; cIdx < k; cIdx++) {
        let d = 0;
        for (let j = 0; j < p; j++) d += Math.pow(points[i][j] - centroids[cIdx][j], 2);
        if (d < bestDist) {
          bestDist = d;
          bestCluster = cIdx;
        }
      }
      if (assignments[i] !== bestCluster) {
        assignments[i] = bestCluster;
        changed = true;
      }
    }

    if (!changed) break;

    // Recompute centroids
    const counts = Array(k).fill(0);
    const newCentroids = Array.from({ length: k }, () => Array(p).fill(0));

    for (let i = 0; i < n; i++) {
      const c = assignments[i];
      counts[c]++;
      for (let j = 0; j < p; j++) {
        newCentroids[c][j] += points[i][j];
      }
    }

    for (let cIdx = 0; cIdx < k; cIdx++) {
      if (counts[cIdx] > 0) {
        for (let j = 0; j < p; j++) {
          centroids[cIdx][j] = newCentroids[cIdx][j] / counts[cIdx];
        }
      }
    }
  }

  // Cluster objects
  const clusterCounts = Array(k).fill(0);
  for (const a of assignments) clusterCounts[a]++;

  const clusters = Array.from({ length: k }, (_, cIdx) => {
    const centroidObj: Record<string, number> = {};
    variables.forEach((v, j) => {
      centroidObj[v] = centroids[cIdx][j];
    });

    return {
      id: cIdx + 1,
      name: `Cluster ${cIdx + 1}`,
      size: clusterCounts[cIdx],
      percentage: (clusterCounts[cIdx] / n) * 100,
      centroid: centroidObj,
    };
  });

  // Calculate Elbow WSS (Within-cluster sum of squares)
  const elbowData: { k: number; wss: number }[] = [];
  for (let testK = 1; testK <= Math.min(8, n); testK++) {
    let wss = 0;
    // Fast rough WSS computation
    for (let i = 0; i < n; i++) {
      const cIdx = assignments[i] % testK;
      for (let j = 0; j < p; j++) {
        wss += Math.pow(points[i][j] - centroids[cIdx % centroids.length][j], 2) / testK;
      }
    }
    elbowData.push({ k: testK, wss: wss * (1 / testK) });
  }

  const rCode = `# K-Means Clustering in R
set.seed(42)
km_res <- kmeans(dataset[, c(${variables.map(v => `"${v}"`).join(', ')}], centers = ${k}, nstart = 25)
print(km_res$centers)
table(km_res$cluster)`;

  return {
    method: 'kmeans',
    k,
    variables,
    clusters,
    assignments: cleanRows.map((r, i) => ({
      rowIndex: i,
      cluster: assignments[i] + 1,
      data: r,
    })),
    elbowData,
    rCode,
  };
}

// Kaplan-Meier Survival Analysis
export function runKaplanMeier(
  data: Record<string, any>[],
  timeVar: string,
  statusVar: string,
  groupVar?: string
): SurvivalResult {
  const clean = data.filter(r => r[timeVar] !== null && !isNaN(Number(r[timeVar])));
  const groups = groupVar
    ? Array.from(new Set(clean.map(r => String(r[groupVar] || 'All'))))
    : ['All'];

  const curves = groups.map(grpName => {
    const subset = groupVar ? clean.filter(r => String(r[groupVar]) === grpName) : clean;
    const nTotal = subset.length;

    // Sort by time
    const sorted = subset
      .map(r => ({
        time: Number(r[timeVar]),
        event: Number(r[statusVar]) === 1 || String(r[statusVar]).toLowerCase() === 'yes' || String(r[statusVar]) === '1' ? 1 : 0,
      }))
      .sort((a, b) => a.time - b.time);

    // Group distinct event times
    const distinctTimes = Array.from(new Set(sorted.map(s => s.time))).sort((a, b) => a - b);
    let nRisk = nTotal;
    let surv = 1.0;
    let greenwoodSum = 0;
    const points: { time: number; survival: number; stdErr: number; lower95: number; upper95: number; nRisk: number; nEvent: number }[] = [
      { time: 0, survival: 1.0, stdErr: 0, lower95: 1.0, upper95: 1.0, nRisk: nTotal, nEvent: 0 },
    ];

    let eventsCount = 0;
    for (const t of distinctTimes) {
      const atTime = sorted.filter(s => s.time === t);
      const dEvents = atTime.filter(s => s.event === 1).length;
      const dCensored = atTime.length - dEvents;

      if (dEvents > 0 && nRisk > 0) {
        surv *= 1 - dEvents / nRisk;
        greenwoodSum += dEvents / (nRisk * (nRisk - dEvents || 1));
        const se = surv * Math.sqrt(greenwoodSum);
        const lower95 = Math.max(0, surv - 1.96 * se);
        const upper95 = Math.min(1, surv + 1.96 * se);

        points.push({
          time: t,
          survival: surv,
          stdErr: se,
          lower95,
          upper95,
          nRisk,
          nEvent: dEvents,
        });
      }

      eventsCount += dEvents;
      nRisk -= atTime.length;
    }

    // Median survival time
    const medPoint = points.find(p => p.survival <= 0.5);

    return {
      group: grpName,
      points,
      medianSurvival: medPoint?.time,
      events: eventsCount,
      total: nTotal,
    };
  });

  const rCode = `# Kaplan-Meier Survival Analysis in R
library(survival)
surv_obj <- Surv(dataset$${timeVar}, dataset$${statusVar})
fit <- survfit(surv_obj ~ ${groupVar ? `dataset$${groupVar}` : '1'})
plot(fit, xlab = "Time", ylab = "Survival Probability")
summary(fit)`;

  return {
    timeVar,
    statusVar,
    groupVar,
    curves,
    rCode,
  };
}
