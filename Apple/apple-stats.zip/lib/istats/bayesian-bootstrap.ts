import { dnorm, qnorm, computeQuantile } from './math-utils';
import { computePDF, computeCDF } from './distributions';

export interface BayesianBetaBinomialResult {
  priorAlpha: number;
  priorBeta: number;
  successes: number;
  trials: number;
  postAlpha: number;
  postBeta: number;
  priorMean: number;
  posteriorMean: number;
  posteriorMedian: number;
  posteriorMode: number;
  credibleInterval95: [number, number];
  bayesFactor10: number;
  evidenceStrength: string;
  points: { theta: number; prior: number; likelihood: number; posterior: number }[];
  rCode: string;
}

export function runBayesianBetaBinomial(
  priorAlpha: number,
  priorBeta: number,
  successes: number,
  trials: number,
  nullP = 0.5
): BayesianBetaBinomialResult {
  const postAlpha = priorAlpha + successes;
  const postBeta = priorBeta + (trials - successes);

  const priorMean = priorAlpha / (priorAlpha + priorBeta);
  const posteriorMean = postAlpha / (postAlpha + postBeta);
  const posteriorMode = (postAlpha - 1) / (postAlpha + postBeta - 2);

  // Generate prior, likelihood, and posterior curves over theta in [0, 1]
  const points: { theta: number; prior: number; likelihood: number; posterior: number }[] = [];
  let maxLik = 0;

  for (let i = 0; i <= 200; i++) {
    const theta = i / 200;
    const prior = computePDF('beta', theta, { shape1: priorAlpha, shape2: priorBeta });
    const likRaw = Math.pow(theta, successes) * Math.pow(1 - theta, trials - successes);
    if (likRaw > maxLik) maxLik = likRaw;

    const post = computePDF('beta', theta, { shape1: postAlpha, shape2: postBeta });
    points.push({ theta, prior, likelihood: likRaw, posterior: post });
  }

  // Normalize likelihood curve for visual comparison overlay
  const maxPost = Math.max(...points.map(p => p.posterior), 1);
  points.forEach(p => {
    p.likelihood = maxLik > 0 ? (p.likelihood / maxLik) * (maxPost * 0.8) : 0;
  });

  // Savage-Dickey density ratio for Bayes Factor BF10 against point null p = 0.5
  const postDensityNull = computePDF('beta', nullP, { shape1: postAlpha, shape2: postBeta });
  const priorDensityNull = computePDF('beta', nullP, { shape1: priorAlpha, shape2: priorBeta });
  const bf01 = priorDensityNull > 0 ? postDensityNull / priorDensityNull : 1.0;
  const bf10 = bf01 > 0 ? 1 / bf01 : 1.0;

  let evidenceStrength = 'Anecdotal evidence';
  if (bf10 > 100) evidenceStrength = 'Decisive evidence for Alternative (H1)';
  else if (bf10 > 30) evidenceStrength = 'Very strong evidence for Alternative (H1)';
  else if (bf10 > 10) evidenceStrength = 'Strong evidence for Alternative (H1)';
  else if (bf10 > 3) evidenceStrength = 'Moderate evidence for Alternative (H1)';
  else if (bf10 < 1 / 100) evidenceStrength = 'Decisive evidence for Null (H0)';
  else if (bf10 < 1 / 10) evidenceStrength = 'Strong evidence for Null (H0)';
  else if (bf10 < 1 / 3) evidenceStrength = 'Moderate evidence for Null (H0)';

  // Approximate 95% Credible Interval using Beta quantiles
  const q025 = (postAlpha) / (postAlpha + postBeta) - 1.96 * Math.sqrt((postAlpha * postBeta) / (Math.pow(postAlpha + postBeta, 2) * (postAlpha + postBeta + 1)));
  const q975 = (postAlpha) / (postAlpha + postBeta) + 1.96 * Math.sqrt((postAlpha * postBeta) / (Math.pow(postAlpha + postBeta, 2) * (postAlpha + postBeta + 1)));

  const credibleInterval95: [number, number] = [
    Math.max(0, q025),
    Math.min(1, q975),
  ];

  const rCode = `# Bayesian Beta-Binomial Inference in R
prior_a <- ${priorAlpha}; prior_b <- ${priorBeta}
k <- ${successes}; n <- ${trials}
post_a <- prior_a + k; post_b <- prior_b + (n - k)

# 95% Equal-tailed Credible Interval
qbeta(c(0.025, 0.975), post_a, post_b)

# Savage-Dickey Bayes Factor
BF01 <- dbeta(${nullP}, post_a, post_b) / dbeta(${nullP}, prior_a, prior_b)
BF10 <- 1 / BF01`;

  return {
    priorAlpha,
    priorBeta,
    successes,
    trials,
    postAlpha,
    postBeta,
    priorMean,
    posteriorMean,
    posteriorMedian: (postAlpha - 1 / 3) / (postAlpha + postBeta - 2 / 3),
    posteriorMode,
    credibleInterval95,
    bayesFactor10: bf10,
    evidenceStrength,
    points,
    rCode,
  };
}

export interface BootstrapResult {
  statisticName: string;
  originalEstimate: number;
  replications: number;
  bootstrapMean: number;
  bootstrapSE: number;
  bias: number;
  ciPercentile: [number, number];
  ciBca?: [number, number];
  distribution: { bin: number; count: number }[];
  rCode: string;
}

export function runBootstrapLab(
  values: number[],
  statType: 'mean' | 'median' | 'sd' | 'iqr' = 'mean',
  replications = 2000
): BootstrapResult {
  const n = values.length;
  if (n === 0) throw new Error('Cannot bootstrap empty data');

  const calcStat = (arr: number[]): number => {
    if (statType === 'mean') return arr.reduce((a, b) => a + b, 0) / arr.length;
    if (statType === 'median') return computeQuantile(arr.slice().sort((a, b) => a - b), 0.5);
    if (statType === 'sd') {
      const m = arr.reduce((a, b) => a + b, 0) / arr.length;
      return Math.sqrt(arr.reduce((a, b) => a + Math.pow(b - m, 2), 0) / (arr.length - 1));
    }
    if (statType === 'iqr') {
      const sorted = arr.slice().sort((a, b) => a - b);
      return computeQuantile(sorted, 0.75) - computeQuantile(sorted, 0.25);
    }
    return 0;
  };

  const origEstimate = calcStat(values);
  const bootEstimates: number[] = [];

  for (let r = 0; r < replications; r++) {
    const sample: number[] = [];
    for (let i = 0; i < n; i++) {
      sample.push(values[Math.floor(Math.random() * n)]);
    }
    bootEstimates.push(calcStat(sample));
  }

  bootEstimates.sort((a, b) => a - b);

  const bootMean = bootEstimates.reduce((a, b) => a + b, 0) / replications;
  const bootSE = Math.sqrt(bootEstimates.reduce((a, b) => a + Math.pow(b - bootMean, 2), 0) / (replications - 1));
  const bias = bootMean - origEstimate;

  const ciLower = computeQuantile(bootEstimates, 0.025);
  const ciUpper = computeQuantile(bootEstimates, 0.975);

  // Histogram bins
  const minVal = bootEstimates[0];
  const maxVal = bootEstimates[replications - 1];
  const numBins = 25;
  const binWidth = (maxVal - minVal) / numBins || 1;

  const distribution = Array.from({ length: numBins }, (_, bIdx) => {
    const binCenter = minVal + (bIdx + 0.5) * binWidth;
    const count = bootEstimates.filter(
      v => v >= minVal + bIdx * binWidth && (bIdx === numBins - 1 ? v <= maxVal : v < minVal + (bIdx + 1) * binWidth)
    ).length;
    return { bin: binCenter, count };
  });

  const rCode = `# Nonparametric Bootstrap in R
library(boot)
boot_fn <- function(data, indices) {
  return(${statType === 'mean' ? 'mean' : statType === 'median' ? 'median' : statType === 'sd' ? 'sd' : 'IQR'}(data[indices]))
}
b_res <- boot(data = dataset$Value, statistic = boot_fn, R = ${replications})
boot.ci(b_res, type = c("perc", "bca"))`;

  return {
    statisticName: statType.toUpperCase(),
    originalEstimate: origEstimate,
    replications,
    bootstrapMean: bootMean,
    bootstrapSE: bootSE,
    bias,
    ciPercentile: [ciLower, ciUpper],
    distribution,
    rCode,
  };
}
