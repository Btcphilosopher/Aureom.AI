export type VariableType = 'numeric' | 'integer' | 'categorical' | 'ordinal' | 'binary' | 'date' | 'time' | 'datetime' | 'text' | 'continuous' | 'discrete' | 'nominal';

export type MeasurementScale = 'nominal' | 'ordinal' | 'interval' | 'ratio';

export type AnalysisTab =
  | 'data'
  | 'descriptive'
  | 'inference'
  | 'regression'
  | 'distributions'
  | 'timeseries'
  | 'multivariate'
  | 'bayesian';

export interface Variable {
  name: string;
  label?: string;
  type: VariableType;
  role?: 'input' | 'target' | 'weight' | 'strata' | 'cluster';
  missingCount?: number;
  levels?: string[];
  unit?: string;
  description?: string;
}

export type VariableMeta = Variable;

export interface Dataset {
  id: string;
  name: string;
  category?: string;
  description?: string;
  source?: string;
  rCitation?: string;
  createdAt?: string;
  updatedAt?: string;
  variables: Variable[];
  rows: Record<string, any>[];
  data?: Record<string, any>[];
  rowCount?: number;
  colCount?: number;
}

export interface DescriptiveStats {
  variable: string;
  count: number;
  validCount: number;
  missingCount: number;
  sum?: number;
  mean?: number;
  median?: number;
  mode?: any[];
  min?: number;
  max?: number;
  range?: number;
  variance?: number;
  sd?: number;
  se?: number;
  cv?: number; // coefficient of variation
  q1?: number;
  q3?: number;
  iqr?: number;
  mad?: number; // median absolute deviation
  skewness?: number;
  kurtosis?: number;
  geometricMean?: number;
  harmonicMean?: number;
  trimmedMean?: number;
  weightedMean?: number;
  percentiles?: Record<number, number>; // 5, 10, 25, 50, 75, 90, 95, 99
  frequencies?: Record<string, { count: number; percentage: number }>;
}

export type DistributionType =
  | 'normal'
  | 'uniform'
  | 'binomial'
  | 'poisson'
  | 'exponential'
  | 'gamma'
  | 'beta'
  | 'weibull'
  | 'lognormal'
  | 't'
  | 'chisquare'
  | 'f'
  | 'geometric'
  | 'negbinomial'
  | 'hypergeometric';

export interface DistributionParams {
  [key: string]: number;
}

export interface StatisticalAssumption {
  name: string;
  description: string;
  status: 'passed' | 'warning' | 'failed' | 'info';
  details: string;
  pValue?: number;
}

export interface HypothesisTestResult {
  testName: string;
  rFunction: string;
  statisticName: string;
  statisticValue: number;
  df?: number | [number, number];
  pValue: number;
  significance: '***' | '**' | '*' | '.' | 'ns';
  alternative: 'two.sided' | 'less' | 'greater';
  ci?: [number, number];
  ciConfidence?: number;
  effectSize?: {
    name: string;
    value: number;
    magnitude: 'negligible' | 'small' | 'medium' | 'large';
    ci?: [number, number];
  };
  groupStats?: {
    group: string;
    n: number;
    mean: number;
    sd: number;
    se: number;
    median?: number;
  }[];
  assumptions: StatisticalAssumption[];
  plainExplanation: string;
  rCode: string;
  methodDescription: string;
  additionalData?: any;
}

export interface RegressionResult {
  modelType: 'linear' | 'multiple' | 'logistic' | 'polynomial';
  formula: string;
  rCode: string;
  dependentVar: string;
  independentVars: string[];
  n: number;
  rSquared?: number;
  adjRSquared?: number;
  fStatistic?: number;
  fPValue?: number;
  residualStandardError?: number;
  degreesOfFreedom?: number;
  aic?: number;
  bic?: number;
  logLikelihood?: number;
  coefficients: {
    term: string;
    estimate: number;
    stdError: number;
    statistic: number; // t or z
    pValue: number;
    ciLower: number;
    ciUpper: number;
    vif?: number; // multicollinearity
    standardizedBeta?: number;
    oddsRatio?: number;
    oddsRatioCI?: [number, number];
  }[];
  anovaTable?: {
    source: string;
    df: number;
    sumSq: number;
    meanSq: number;
    fValue?: number;
    pValue?: number;
  }[];
  diagnostics: {
    durbinWatson?: number;
    breuschPaganP?: number;
    shapiroWilkResidualsP?: number;
    maxCooksD?: number;
    influentialPoints?: number[];
  };
  assumptions: StatisticalAssumption[];
  plainExplanation: string;
  predictions?: {
    actual: number;
    predicted: number;
    residual: number;
    leverage?: number;
    cooksD?: number;
    stdResidual?: number;
  }[];
  rocCurve?: { fpr: number; tpr: number; threshold: number }[];
  auc?: number;
}

export interface AnovaResult {
  type: 'one-way' | 'two-way' | 'repeated-measures';
  dependentVar: string;
  factors: string[];
  table: {
    term: string;
    df: number;
    sumSq: number;
    meanSq: number;
    fValue: number;
    pValue: number;
    etaSq: number;
    partialEtaSq: number;
  }[];
  groupMeans: {
    group: string;
    n: number;
    mean: number;
    sd: number;
    ci: [number, number];
  }[];
  postHocTukey?: {
    comparison: string;
    diff: number;
    ciLower: number;
    ciUpper: number;
    pAdj: number;
  }[];
  assumptions: StatisticalAssumption[];
  plainExplanation: string;
  rCode: string;
}

export interface TimeSeriesResult {
  dateVar: string;
  valueVar: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  historical: { date: string; value: number; trend?: number; seasonal?: number; remainder?: number }[];
  forecast: { date: string; forecast: number; lower80: number; upper80: number; lower95: number; upper95: number }[];
  method: 'ARIMA' | 'ETS' | 'Holt-Winters' | 'Auto-Selected';
  modelDetails: string;
  metrics: {
    mae: number;
    rmse: number;
    mape: number;
    aic?: number;
  };
  acf: { lag: number; acf: number; ci: number }[];
  pacf: { lag: number; pacf: number; ci: number }[];
  anomalies: { index: number; date: string; value: number; zScore: number; reason: string }[];
  rCode: string;
}

export interface PcaResult {
  variables: string[];
  nComponents: number;
  components: {
    name: string;
    eigenvalue: number;
    varianceExplained: number;
    cumulativeVariance: number;
    loadings: Record<string, number>;
  }[];
  scores: {
    id: number;
    pc1: number;
    pc2: number;
    pc3?: number;
    label?: string;
    category?: string;
  }[];
  rCode: string;
}

export interface ClusterResult {
  method: 'kmeans' | 'hierarchical' | 'dbscan';
  k: number;
  variables: string[];
  clusters: {
    id: number;
    name: string;
    size: number;
    percentage: number;
    centroid: Record<string, number>;
  }[];
  assignments: {
    rowIndex: number;
    cluster: number;
    data: Record<string, any>;
  }[];
  elbowData?: { k: number; wss: number }[];
  dendrogramNodes?: any;
  rCode: string;
}

export interface SurvivalResult {
  timeVar: string;
  statusVar: string;
  groupVar?: string;
  curves: {
    group: string;
    points: { time: number; survival: number; stdErr: number; lower95: number; upper95: number; nRisk: number; nEvent: number }[];
    medianSurvival?: number;
    events: number;
    total: number;
  }[];
  logRankTest?: {
    chiSq: number;
    df: number;
    pValue: number;
  };
  rCode: string;
}

export interface AnalysisCard {
  id: string;
  title: string;
  type: 'descriptive' | 'graph' | 'hypothesis' | 'regression' | 'anova' | 'correlation' | 'timeseries' | 'pca' | 'cluster' | 'bayesian' | 'sampling' | 'distribution';
  variables: string[];
  datasetId: string;
  settings: Record<string, any>;
  results?: any;
  rCode: string;
  notes?: string;
  createdAt: string;
}

export interface IStatsProject {
  version: string;
  name: string;
  description: string;
  activeDatasetId: string;
  datasets: Dataset[];
  analyses: AnalysisCard[];
  history: {
    timestamp: string;
    action: string;
    target: string;
  }[];
  settings: {
    precision: 2 | 3 | 4 | 'scientific' | 'full';
    theme: 'light' | 'dark' | 'system';
    mode: 'beginner' | 'advanced';
    learnMode: boolean;
  };
}
