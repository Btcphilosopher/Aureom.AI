'use client';

import React, { useState, useMemo } from 'react';
import { SAMPLE_DATASETS } from '@/lib/istats/sample-datasets';
import { Dataset, AnalysisTab } from '@/lib/istats/types';
import { Header } from '@/components/istats/Header';
import { SpreadsheetView } from '@/components/istats/SpreadsheetView';
import { DescriptiveView } from '@/components/istats/DescriptiveView';
import { HypothesisView } from '@/components/istats/HypothesisView';
import { RegressionView } from '@/components/istats/RegressionView';
import { DistributionView } from '@/components/istats/DistributionView';
import { TimeSeriesView } from '@/components/istats/TimeSeriesView';
import { MultivariateView } from '@/components/istats/MultivariateView';
import { BayesianBootstrapView } from '@/components/istats/BayesianBootstrapView';
import { RTerminalModal } from '@/components/istats/RTerminalModal';
import { CSVImportModal } from '@/components/istats/CSVImportModal';

export default function AppleStatsPage() {
  const [datasets, setDatasets] = useState<Dataset[]>(SAMPLE_DATASETS);
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>(SAMPLE_DATASETS[0].id);
  const [activeTab, setActiveTab] = useState<AnalysisTab>('data');
  const [isRTerminalOpen, setIsRTerminalOpen] = useState<boolean>(false);
  const [isCSVImportOpen, setIsCSVImportOpen] = useState<boolean>(false);

  const currentDataset = useMemo(() => {
    return datasets.find((d) => d.id === selectedDatasetId) || datasets[0];
  }, [datasets, selectedDatasetId]);

  const handleUpdateDataset = (updated: Dataset) => {
    setDatasets((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
  };

  const handleImportDataset = (newDataset: Dataset) => {
    setDatasets((prev) => [newDataset, ...prev]);
    setSelectedDatasetId(newDataset.id);
    setActiveTab('data');
  };

  return (
    <main className="min-h-screen flex flex-col bg-slate-950 text-slate-100 font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Application Bar with Navigation */}
      <Header
        datasets={datasets}
        currentDataset={currentDataset}
        onSelectDataset={(ds) => setSelectedDatasetId(ds.id)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenImport={() => setIsCSVImportOpen(true)}
        onOpenExport={() => setIsRTerminalOpen(true)}
        onOpenRConsole={() => setIsRTerminalOpen(true)}
      />

      {/* Main Analysis Stage */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'data' && (
          <SpreadsheetView
            dataset={currentDataset}
            onUpdateDataset={handleUpdateDataset}
          />
        )}

        {activeTab === 'descriptive' && (
          <DescriptiveView dataset={currentDataset} />
        )}

        {activeTab === 'inference' && (
          <HypothesisView dataset={currentDataset} />
        )}

        {activeTab === 'regression' && (
          <RegressionView dataset={currentDataset} />
        )}

        {activeTab === 'distributions' && (
          <DistributionView />
        )}

        {activeTab === 'timeseries' && (
          <TimeSeriesView dataset={currentDataset} />
        )}

        {activeTab === 'multivariate' && (
          <MultivariateView dataset={currentDataset} />
        )}

        {activeTab === 'bayesian' && (
          <BayesianBootstrapView dataset={currentDataset} />
        )}
      </div>

      {/* Pure R Interactive Terminal & Script Exporter Modal */}
      <RTerminalModal
        dataset={currentDataset}
        isOpen={isRTerminalOpen}
        onClose={() => setIsRTerminalOpen(false)}
      />

      {/* CSV Dataset Import Modal */}
      <CSVImportModal
        isOpen={isCSVImportOpen}
        onClose={() => setIsCSVImportOpen(false)}
        onImport={handleImportDataset}
      />
    </main>
  );
}
