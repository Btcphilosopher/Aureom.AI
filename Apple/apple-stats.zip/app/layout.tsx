import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Apple Stats — Statistical Software (iStats)',
  description: 'Consumer-grade statistical analysis software with spreadsheet simplicity, pure R statistical ecosystem, visual analysis, 60+ graph types, and instant reporting.',
  openGraph: {
    title: 'Apple Stats — Statistical Software (iStats)',
    description: 'Consumer-grade statistical analysis software with spreadsheet simplicity, pure R statistical ecosystem, visual analysis, 60+ graph types, and instant reporting.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Apple Stats — Statistical Software (iStats)',
    description: 'Consumer-grade statistical analysis software with spreadsheet simplicity, pure R statistical ecosystem, visual analysis, 60+ graph types, and instant reporting.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
