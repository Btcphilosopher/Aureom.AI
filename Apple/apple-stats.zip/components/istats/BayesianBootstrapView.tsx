'use client';

import React, { useState, useMemo } from 'react';
import { Dataset } from '@/lib/istats/types';
import { runBayesianBetaBinomial, runBootstrapLab } from '@/lib/istats/bayesian-bootstrap';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  Sparkles,
  RefreshCw,
  Code2,
  Sliders,
  Copy,
  Check,
  Zap,
} from 'lucide-react';

interface BayesianBootstrapViewProps {
  dataset: Dataset;
}

export function BayesianBootstrapView({ dataset }: BayesianBootstrapViewProps) {
  const numericVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'continuous' || v.type === 'discrete').map((v) => v.name),
    [dataset]
  );

  const [activeTab, setActiveTab] = useState<'bayesian' | 'bootstrap'>('bayesian');

  // Bayesian inputs
  const [priorAlpha, setPriorAlpha] = useState<number>(2);
  const [priorBeta, setPriorBeta] = useState<number>(2);
  const [successes, setSuccesses] = useState<number>(14);
  const [trials, setTrials] = useState<number>(20);

  // Bootstrap inputs
  const [bootVar, setBootVar] = useState<string>(numericVars[0] || '');
  const [bootStat, setBootStat] = useState<'mean' | 'median' | 'sd' | 'iqr'>('mean');
  const [bootReps, setBootReps] = useState<number>(2000);
  const [bootTrigger, setBootTrigger] = useState<number>(0);

  // Run Bayesian calculation
  const bayesResult = useMemo(() => {
    return runBayesianBetaBinomial(priorAlpha, priorBeta, successes, trials);
  }, [priorAlpha, priorBeta, successes, trials]);

  // Run Bootstrap calculation
  const bootResult = useMemo(() => {
    if (!bootVar) return null;
    // Consume trigger to re-run simulation on click
    void bootTrigger;
    const vals = dataset.rows.map((r) => Number(r[bootVar])).filter((v) => !isNaN(v));
    if (vals.length === 0) return null;
    return runBootstrapLab(vals, bootStat, bootReps);
  }, [dataset, bootVar, bootStat, bootReps, bootTrigger]);

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Configuration Sidebar */}
      <div className="w-full lg:w-80 bg-slate-900 border-r border-slate-800 p-4 space-y-4 overflow-y-auto">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            Bayesian & Resampling Lab
          </h3>

          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800 mb-3 text-xs">
            <button
              onClick={() => setActiveTab('bayesian')}
              className={`py-1.5 rounded font-semibold ${activeTab === 'bayesian' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Bayesian Updater
            </button>
            <button
              onClick={() => setActiveTab('bootstrap')}
              className={`py-1.5 rounded font-semibold ${activeTab === 'bootstrap' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Bootstrap Lab
            </button>
          </div>

          {activeTab === 'bayesian' ? (
            <div className="space-y-3">
              <span className="text-xs text-slate-400 font-semibold block uppercase tracking-wider">
                Prior Beta(α, β) Parameters
              </span>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Prior Alpha (α)</span>
                  <span className="font-mono text-blue-400 font-bold">{priorAlpha}</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="20"
                  step="0.5"
                  value={priorAlpha}
                  onChange={(e) => setPriorAlpha(Number(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Prior Beta (β)</span>
                  <span className="font-mono text-blue-400 font-bold">{priorBeta}</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="20"
                  step="0.5"
                  value={priorBeta}
                  onChange={(e) => setPriorBeta(Number(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>

              <span className="text-xs text-slate-400 font-semibold block uppercase tracking-wider pt-2 border-t border-slate-800">
                Observed Data Likelihood
              </span>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Successes (k)</span>
                  <span className="font-mono text-emerald-400 font-bold">{successes}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={trials}
                  value={successes}
                  onChange={(e) => setSuccesses(Number(e.target.value))}
                  className="w-full accent-emerald-500"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Total Trials (n)</span>
                  <span className="font-mono text-slate-200 font-bold">{trials}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="100"
                  value={trials}
                  onChange={(e) => setTrials(Number(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1">Resampling Variable</label>
                <select
                  value={bootVar}
                  onChange={(e) => setBootVar(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-slate-200"
                >
                  {numericVars.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1">Target Statistic</label>
                <select
                  value={bootStat}
                  onChange={(e) => setBootStat(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-slate-200"
                >
                  <option value="mean">Sample Mean</option>
                  <option value="median">Sample Median</option>
                  <option value="sd">Standard Deviation</option>
                  <option value="iqr">Interquartile Range (IQR)</option>
                </select>
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-300">Bootstrap Replications (R)</span>
                  <span className="font-mono text-blue-400 font-bold">{bootReps}</span>
                </div>
                <input
                  type="range"
                  min="500"
                  max="5000"
                  step="500"
                  value={bootReps}
                  onChange={(e) => setBootReps(Number(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>

              <button
                onClick={() => setBootTrigger((prev) => prev + 1)}
                className="w-full flex items-center justify-center gap-2 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-md transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Rerun Resampling Simulation
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Lab Display */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {activeTab === 'bayesian' && (
          <div className="space-y-5">
            {/* Top Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[11px] block">Prior Mean</span>
                <span className="font-mono text-lg font-bold text-slate-300">
                  {bayesResult.priorMean.toFixed(3)}
                </span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[11px] block">Posterior Mean</span>
                <span className="font-mono text-lg font-bold text-blue-400">
                  {bayesResult.posteriorMean.toFixed(3)}
                </span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[11px] block">95% Credible Interval</span>
                <span className="font-mono text-xs font-bold text-emerald-400">
                  [{bayesResult.credibleInterval95[0].toFixed(3)}, {bayesResult.credibleInterval95[1].toFixed(3)}]
                </span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[11px] block">Bayes Factor (BF₁₀)</span>
                <span className="font-mono text-lg font-bold text-amber-400">
                  {bayesResult.bayesFactor10.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Tri-Plot: Prior, Likelihood, Posterior */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-semibold text-white">
                    Bayesian Belief Updating: Prior vs Likelihood vs Posterior
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Posterior Beta({bayesResult.postAlpha}, {bayesResult.postBeta}) represents updated probability distribution of parameter θ.
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs font-mono">
                  <span className="flex items-center gap-1 text-slate-400">
                    <span className="w-3 h-0.5 bg-slate-500 inline-block" /> Prior
                  </span>
                  <span className="flex items-center gap-1 text-amber-400">
                    <span className="w-3 h-0.5 bg-amber-400 inline-block" /> Likelihood
                  </span>
                  <span className="flex items-center gap-1 text-blue-400">
                    <span className="w-3 h-0.5 bg-blue-500 inline-block" /> Posterior
                  </span>
                </div>
              </div>

              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={bayesResult.points} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="theta" stroke="#94a3b8" fontSize={11} label={{ value: 'Parameter θ (Success Probability)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'Probability Density', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                    <Line type="monotone" dataKey="prior" stroke="#64748b" strokeWidth={1.5} strokeDasharray="3 3" dot={false} name="Prior Density" />
                    <Line type="monotone" dataKey="likelihood" stroke="#f59e0b" strokeWidth={2} dot={false} name="Scaled Likelihood" />
                    <Area type="monotone" dataKey="posterior" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.25} strokeWidth={2.5} name="Posterior Density" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Evidence Card & R Code */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider block">
                  Jeffreys Bayes Factor Evidence Scale
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  BF₁₀ = {bayesResult.bayesFactor10.toFixed(2)} indicates <strong className="text-amber-400">{bayesResult.evidenceStrength}</strong> compared to point null θ = 0.5.
                </p>
              </div>

              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-semibold text-emerald-400 font-mono flex items-center gap-1.5">
                  <Code2 className="w-3.5 h-3.5 text-emerald-400" />
                  R Script
                </span>
                <pre className="text-[10px] font-mono text-emerald-400 overflow-x-auto p-2 bg-slate-950 rounded border border-slate-800">
                  {bayesResult.rCode}
                </pre>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'bootstrap' && bootResult && (
          <div className="space-y-5">
            {/* Top Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[11px] block">Sample Estimate</span>
                <span className="font-mono text-lg font-bold text-white">
                  {bootResult.originalEstimate.toFixed(3)}
                </span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[11px] block">Bootstrap Mean</span>
                <span className="font-mono text-lg font-bold text-blue-400">
                  {bootResult.bootstrapMean.toFixed(3)}
                </span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[11px] block">Bootstrap SE</span>
                <span className="font-mono text-lg font-bold text-slate-300">
                  {bootResult.bootstrapSE.toFixed(4)}
                </span>
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <span className="text-slate-400 text-[11px] block">95% Percentile CI</span>
                <span className="font-mono text-xs font-bold text-emerald-400">
                  [{bootResult.ciPercentile[0].toFixed(3)}, {bootResult.ciPercentile[1].toFixed(3)}]
                </span>
              </div>
            </div>

            {/* Bootstrap Sampling Distribution Histogram */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <h2 className="text-base font-semibold text-white flex items-center justify-between">
                <span>Bootstrap Resampling Distribution ({bootResult.replications.toLocaleString()} Replications)</span>
                <span className="text-xs font-mono text-slate-400">Statistic: {bootResult.statisticName}</span>
              </h2>

              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bootResult.distribution} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="bin" stroke="#94a3b8" fontSize={11} />
                    <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'Replication Count', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                    <Bar dataKey="count" fill="#3b82f6" radius={[3, 3, 0, 0]} name="Replications" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* R Code */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-2">
              <span className="text-xs font-semibold text-emerald-400 font-mono flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5 text-emerald-400" />
                R boot Package Script
              </span>
              <pre className="p-3 bg-slate-950 rounded-lg font-mono text-xs text-emerald-400 overflow-x-auto border border-slate-800/80">
                {bootResult.rCode}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
