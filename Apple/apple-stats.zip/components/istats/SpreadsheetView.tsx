'use client';

import React, { useState, useMemo } from 'react';
import {
  Dataset,
  VariableMeta,
  VariableType,
} from '@/lib/istats/types';
import { computeDescriptiveStats } from '@/lib/istats/descriptive';
import {
  Search,
  Plus,
  Trash2,
  ArrowUpDown,
  Filter,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  BarChart2,
  Info,
  Code2,
} from 'lucide-react';

interface SpreadsheetViewProps {
  dataset: Dataset;
  onUpdateDataset: (updated: Dataset) => void;
}

export function SpreadsheetView({ dataset, onUpdateDataset }: SpreadsheetViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedColumn, setSelectedColumn] = useState<string>(
    dataset.variables[0]?.name || ''
  );
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' } | null>(
    null
  );

  // Quick stats summary per column
  const columnSummaries = useMemo(() => {
    const map: Record<string, any> = {};
    for (const v of dataset.variables) {
      const vals = dataset.rows.map((r) => r[v.name]);
      map[v.name] = computeDescriptiveStats(vals, v.name, v.type === 'continuous' || v.type === 'discrete');
    }
    return map;
  }, [dataset]);

  // Filter & Sort rows
  const displayedRows = useMemo(() => {
    let list = [...dataset.rows];

    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      list = list.filter((row) =>
        Object.values(row).some((val) =>
          String(val ?? '').toLowerCase().includes(term)
        )
      );
    }

    if (sortConfig) {
      list.sort((a, b) => {
        const valA = a[sortConfig.key];
        const valB = b[sortConfig.key];

        if (valA === valB) return 0;
        if (valA === null || valA === undefined || valA === '') return 1;
        if (valB === null || valB === undefined || valB === '') return -1;

        const numA = Number(valA);
        const numB = Number(valB);

        if (!isNaN(numA) && !isNaN(numB)) {
          return sortConfig.direction === 'asc' ? numA - numB : numB - numA;
        }

        return sortConfig.direction === 'asc'
          ? String(valA).localeCompare(String(valB))
          : String(valB).localeCompare(String(valA));
      });
    }

    return list;
  }, [dataset.rows, searchTerm, sortConfig]);

  // Update cell value
  const handleCellChange = (rowIndex: number, colName: string, value: string) => {
    const updatedRows = [...dataset.rows];
    const isNum = dataset.variables.find((v) => v.name === colName)?.type === 'continuous' ||
      dataset.variables.find((v) => v.name === colName)?.type === 'discrete';

    const parsedVal = isNum && value.trim() !== '' && !isNaN(Number(value))
      ? Number(value)
      : value;

    updatedRows[rowIndex] = {
      ...updatedRows[rowIndex],
      [colName]: parsedVal,
    };

    onUpdateDataset({
      ...dataset,
      rows: updatedRows,
    });
  };

  // Change variable type
  const handleTypeChange = (varName: string, newType: VariableType) => {
    const updatedVars = dataset.variables.map((v) =>
      v.name === varName ? { ...v, type: newType } : v
    );
    onUpdateDataset({
      ...dataset,
      variables: updatedVars,
    });
  };

  // Add new row
  const handleAddRow = () => {
    const newRow: Record<string, any> = {};
    dataset.variables.forEach((v) => {
      newRow[v.name] = v.type === 'continuous' || v.type === 'discrete' ? 0 : '';
    });
    onUpdateDataset({
      ...dataset,
      rows: [...dataset.rows, newRow],
    });
  };

  // Delete row
  const handleDeleteRow = (index: number) => {
    const updatedRows = dataset.rows.filter((_, i) => i !== index);
    onUpdateDataset({
      ...dataset,
      rows: updatedRows,
    });
  };

  const handleSort = (key: string) => {
    if (sortConfig && sortConfig.key === key) {
      if (sortConfig.direction === 'asc') {
        setSortConfig({ key, direction: 'desc' });
      } else {
        setSortConfig(null);
      }
    } else {
      setSortConfig({ key, direction: 'asc' });
    }
  };

  const selectedColMeta = dataset.variables.find((v) => v.name === selectedColumn);
  const selectedColStats = selectedColumn ? columnSummaries[selectedColumn] : null;

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Left: Interactive Statistical Grid */}
      <div className="flex-1 flex flex-col min-w-0 border-r border-slate-800">
        {/* Table Toolbar */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Filter dataset rows..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1 bg-slate-950 border border-slate-700 rounded-md text-xs text-slate-200 focus:outline-none focus:border-blue-500 w-48 lg:w-64"
              />
            </div>
            <span className="text-xs text-slate-400 font-mono">
              Showing {displayedRows.length} of {dataset.rows.length} observations
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleAddRow}
              className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-md text-xs font-medium transition"
            >
              <Plus className="w-3.5 h-3.5 text-blue-400" />
              Add Observation
            </button>
          </div>
        </div>

        {/* Data Grid with Variable Headers and Summary Ribbons */}
        <div className="flex-1 overflow-auto scrollbar-thin">
          <table className="w-full border-collapse text-left text-xs">
            <thead className="sticky top-0 z-20 bg-slate-900 shadow-sm border-b border-slate-800">
              {/* Row 1: Variable Name & Type Picker */}
              <tr>
                <th className="w-12 px-3 py-2 bg-slate-950 text-slate-500 text-center font-mono border-r border-slate-800">
                  #
                </th>
                {dataset.variables.map((v) => {
                  const isSelected = selectedColumn === v.name;
                  return (
                    <th
                      key={v.name}
                      onClick={() => setSelectedColumn(v.name)}
                      className={`min-w-[160px] px-3 py-2 border-r border-slate-800 cursor-pointer transition ${
                        isSelected ? 'bg-blue-950/40 text-blue-300' : 'hover:bg-slate-800/80 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-xs tracking-tight truncate">
                          {v.name}
                        </span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSort(v.name);
                          }}
                          className="text-slate-400 hover:text-white"
                        >
                          <ArrowUpDown className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Type Pill Dropdown */}
                      <select
                        value={v.type}
                        onChange={(e) => handleTypeChange(v.name, e.target.value as VariableType)}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full bg-slate-950/80 border border-slate-700/80 rounded px-1.5 py-0.5 text-[10px] font-mono text-slate-300 focus:outline-none focus:border-blue-400 cursor-pointer"
                      >
                        <option value="continuous">Numeric Continuous</option>
                        <option value="discrete">Numeric Discrete</option>
                        <option value="nominal">Nominal (Categorical)</option>
                        <option value="ordinal">Ordinal</option>
                        <option value="binary">Binary (0/1)</option>
                        <option value="date">Date / Time</option>
                      </select>
                    </th>
                  );
                })}
                <th className="w-10 px-2 py-2 bg-slate-950 text-center border-b border-slate-800"></th>
              </tr>

              {/* Row 2: Live Column Summary Ribbon */}
              <tr className="bg-slate-950/90 text-[10px] font-mono border-b border-slate-800 text-slate-400">
                <td className="px-2 py-1 text-center border-r border-slate-800">Stats</td>
                {dataset.variables.map((v) => {
                  const s = columnSummaries[v.name];
                  return (
                    <td key={v.name} className="px-3 py-1 border-r border-slate-800">
                      {s ? (
                        v.type === 'continuous' || v.type === 'discrete' ? (
                          <div className="flex items-center justify-between text-slate-300">
                            <span>μ={s.mean !== undefined ? s.mean.toFixed(2) : '-'}</span>
                            <span className="text-slate-400">σ={s.sd !== undefined ? s.sd.toFixed(2) : '-'}</span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between text-slate-400">
                            <span>{s.validCount} valid</span>
                            <span>{s.missingCount > 0 ? `${s.missingCount} NA` : '0 NA'}</span>
                          </div>
                        )
                      ) : (
                        '-'
                      )}
                    </td>
                  );
                })}
                <td></td>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {displayedRows.map((row, rIdx) => (
                <tr key={rIdx} className="hover:bg-slate-900/60 transition group">
                  <td className="px-3 py-1.5 text-center text-slate-500 bg-slate-950/40 border-r border-slate-800/80 select-none">
                    {rIdx + 1}
                  </td>
                  {dataset.variables.map((v) => {
                    const cellVal = row[v.name];
                    const isNA = cellVal === null || cellVal === undefined || cellVal === '';
                    const isSelectedCol = selectedColumn === v.name;

                    return (
                      <td
                        key={v.name}
                        className={`px-3 py-1 border-r border-slate-800/60 ${
                          isSelectedCol ? 'bg-blue-950/15' : ''
                        }`}
                      >
                        <input
                          type="text"
                          value={cellVal ?? ''}
                          placeholder={isNA ? 'NA' : ''}
                          onChange={(e) => handleCellChange(rIdx, v.name, e.target.value)}
                          className={`w-full bg-transparent px-1 py-0.5 rounded focus:bg-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-500 text-xs ${
                            isNA ? 'text-amber-400/80 italic' : 'text-slate-200'
                          }`}
                        />
                      </td>
                    );
                  })}
                  <td className="px-2 py-1 text-center">
                    <button
                      onClick={() => handleDeleteRow(rIdx)}
                      className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-rose-400 transition"
                      title="Delete row"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Right: Selected Variable Statistical Inspector Panel */}
      <div className="w-full lg:w-80 bg-slate-900/90 flex flex-col overflow-y-auto border-t lg:border-t-0 lg:border-l border-slate-800 p-4">
        {selectedColMeta && selectedColStats ? (
          <div className="space-y-4">
            {/* Variable Title Header */}
            <div className="border-b border-slate-800 pb-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-sm text-white flex items-center gap-1.5">
                  <BarChart2 className="w-4 h-4 text-blue-400" />
                  {selectedColMeta.name}
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-blue-400 border border-slate-700">
                  {selectedColMeta.type}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {selectedColMeta.description || 'No custom variable description provided.'}
              </p>
            </div>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-400 text-[11px] block">Observations (N)</span>
                <span className="font-mono text-sm font-semibold text-white">
                  {selectedColStats.validCount}
                </span>
              </div>
              <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800">
                <span className="text-slate-400 text-[11px] block">Missing (NA)</span>
                <span className={`font-mono text-sm font-semibold ${selectedColStats.missingCount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
                  {selectedColStats.missingCount}
                </span>
              </div>

              {selectedColStats.mean !== undefined && (
                <>
                  <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Sample Mean (μ)</span>
                    <span className="font-mono text-sm font-semibold text-blue-400">
                      {selectedColStats.mean.toFixed(3)}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Sample SD (s)</span>
                    <span className="font-mono text-sm font-semibold text-slate-200">
                      {selectedColStats.sd?.toFixed(3)}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Median (Q2)</span>
                    <span className="font-mono text-sm font-semibold text-slate-200">
                      {selectedColStats.median?.toFixed(3)}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">IQR (Q3 - Q1)</span>
                    <span className="font-mono text-sm font-semibold text-slate-200">
                      {selectedColStats.iqr?.toFixed(3)}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Skewness (g₁)</span>
                    <span className="font-mono text-sm font-semibold text-slate-200">
                      {selectedColStats.skewness?.toFixed(3)}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Kurtosis (g₂)</span>
                    <span className="font-mono text-sm font-semibold text-slate-200">
                      {selectedColStats.kurtosis?.toFixed(3)}
                    </span>
                  </div>
                </>
              )}
            </div>

            {/* Categorical Frequencies */}
            {selectedColStats.frequencies && (
              <div className="space-y-1.5">
                <span className="text-xs font-semibold text-slate-300 block">Frequency Table</span>
                <div className="max-h-48 overflow-y-auto rounded-lg border border-slate-800 bg-slate-950/70 p-2 space-y-1.5 font-mono text-xs">
                  {Object.entries(selectedColStats.frequencies).map(([cat, freq]: [string, any]) => (
                    <div key={cat} className="flex items-center justify-between text-[11px]">
                      <span className="truncate max-w-[120px] text-slate-300">{cat}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400">{freq.count}</span>
                        <span className="text-blue-400 font-semibold">{freq.percentage.toFixed(1)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* R Code Snippet for Variable */}
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span className="flex items-center gap-1 font-mono">
                  <Code2 className="w-3 h-3 text-emerald-400" />
                  R Equivalent
                </span>
              </div>
              <pre className="text-[10px] font-mono text-emerald-400 overflow-x-auto p-1.5 bg-slate-900 rounded">
                {`summary(dataset$${selectedColMeta.name})
sd(dataset$${selectedColMeta.name}, na.rm = TRUE)`}
              </pre>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-64 text-slate-500 text-xs">
            <Info className="w-6 h-6 mb-2 text-slate-600" />
            Click any column header to view detailed statistical properties.
          </div>
        )}
      </div>
    </div>
  );
}
