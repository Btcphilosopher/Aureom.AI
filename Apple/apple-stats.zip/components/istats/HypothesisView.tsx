'use client';

import React, { useState, useMemo } from 'react';
import { Dataset, HypothesisTestResult } from '@/lib/istats/types';
import {
  runOneSampleTTest,
  runTwoSampleTTest,
  runPairedTTest,
  runOneWayAnova,
  runChiSquareTest,
  runMannWhitneyTest,
} from '@/lib/istats/inference';
import {
  Sigma,
  CheckCircle2,
  AlertTriangle,
  Code2,
  HelpCircle,
  Sparkles,
  Layers,
  ArrowRight,
  Copy,
  Check,
} from 'lucide-react';

interface HypothesisViewProps {
  dataset: Dataset;
}

export function HypothesisView({ dataset }: HypothesisViewProps) {
  const numericVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'continuous' || v.type === 'discrete').map((v) => v.name),
    [dataset]
  );
  const categoricalVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'nominal' || v.type === 'ordinal' || v.type === 'binary').map((v) => v.name),
    [dataset]
  );

  const [testType, setTestType] = useState<
    'two-sample' | 'one-sample' | 'paired' | 'anova' | 'chisquare' | 'mann-whitney'
  >('two-sample');

  // Test Inputs
  const [varY, setVarY] = useState<string>(numericVars[0] || '');
  const [varX2, setVarX2] = useState<string>(numericVars[1] || numericVars[0] || '');
  const [groupFactor, setGroupFactor] = useState<string>(categoricalVars[0] || '');
  const [mu0, setMu0] = useState<number>(0);
  const [equalVar, setEqualVar] = useState<boolean>(false);
  const [alternative, setAlternative] = useState<'two.sided' | 'less' | 'greater'>('two.sided');
  const [copied, setCopied] = useState<boolean>(false);

  // Run computation dynamically
  const resultData = useMemo(() => {
    try {
      if (testType === 'one-sample') {
        const vals = dataset.rows.map((r) => Number(r[varY])).filter((v) => !isNaN(v));
        return {
          result: runOneSampleTTest(vals, mu0, varY, alternative),
        };
      }

      if (testType === 'two-sample') {
        if (!groupFactor) {
          // Fallback to two numeric columns
          const v1 = dataset.rows.map((r) => Number(r[varY])).filter((v) => !isNaN(v));
          const v2 = dataset.rows.map((r) => Number(r[varX2])).filter((v) => !isNaN(v));
          return {
            result: runTwoSampleTTest(v1, v2, varY, varX2, equalVar, alternative),
          };
        }
        // Split by first 2 levels of factor
        const uniqueGroups = Array.from(new Set(dataset.rows.map((r) => String(r[groupFactor]))));
        const g1Name = uniqueGroups[0] || 'Group 1';
        const g2Name = uniqueGroups[1] || 'Group 2';

        const g1 = dataset.rows.filter((r) => String(r[groupFactor]) === g1Name).map((r) => Number(r[varY])).filter((v) => !isNaN(v));
        const g2 = dataset.rows.filter((r) => String(r[groupFactor]) === g2Name).map((r) => Number(r[varY])).filter((v) => !isNaN(v));

        return {
          result: runTwoSampleTTest(g1, g2, `${varY} (${g1Name})`, `${varY} (${g2Name})`, equalVar, alternative),
        };
      }

      if (testType === 'paired') {
        const v1 = dataset.rows.map((r) => Number(r[varY])).filter((v) => !isNaN(v));
        const v2 = dataset.rows.map((r) => Number(r[varX2])).filter((v) => !isNaN(v));
        return {
          result: runPairedTTest(v1, v2, varY, varX2, alternative),
        };
      }

      if (testType === 'anova') {
        const uniqueGroups = Array.from(new Set(dataset.rows.map((r) => String(r[groupFactor] || ''))));
        const groups = uniqueGroups.map((grp) => ({
          name: grp,
          values: dataset.rows.filter((r) => String(r[groupFactor]) === grp).map((r) => Number(r[varY])).filter((v) => !isNaN(v)),
        })).filter(g => g.values.length > 0);

        const anova = runOneWayAnova(groups, varY);
        return {
          result: anova.testResult,
          anovaTable: anova.table,
          tukeyTable: anova.tukeyPostHoc,
        };
      }

      if (testType === 'chisquare') {
        const rowVar = categoricalVars[0] || 'Var1';
        const colVar = categoricalVars[1] || categoricalVars[0] || 'Var2';

        const rLevels = Array.from(new Set(dataset.rows.map((r) => String(r[rowVar]))));
        const cLevels = Array.from(new Set(dataset.rows.map((r) => String(r[colVar]))));

        const mat: number[][] = Array.from({ length: rLevels.length }, () => Array(cLevels.length).fill(0));

        dataset.rows.forEach((r) => {
          const rIdx = rLevels.indexOf(String(r[rowVar]));
          const cIdx = cLevels.indexOf(String(r[colVar]));
          if (rIdx >= 0 && cIdx >= 0) mat[rIdx][cIdx]++;
        });

        return {
          result: runChiSquareTest(mat, rLevels, cLevels),
          contingency: { rLevels, cLevels, mat, rowVar, colVar },
        };
      }

      if (testType === 'mann-whitney') {
        const uniqueGroups = Array.from(new Set(dataset.rows.map((r) => String(r[groupFactor]))));
        const g1Name = uniqueGroups[0] || 'Group 1';
        const g2Name = uniqueGroups[1] || 'Group 2';

        const g1 = dataset.rows.filter((r) => String(r[groupFactor]) === g1Name).map((r) => Number(r[varY])).filter((v) => !isNaN(v));
        const g2 = dataset.rows.filter((r) => String(r[groupFactor]) === g2Name).map((r) => Number(r[varY])).filter((v) => !isNaN(v));

        return {
          result: runMannWhitneyTest(g1, g2, g1Name, g2Name),
        };
      }

      return null;
    } catch (e: any) {
      return { error: e.message };
    }
  }, [dataset, testType, varY, varX2, groupFactor, mu0, equalVar, alternative, categoricalVars]);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const res: HypothesisTestResult | undefined = (resultData as any)?.result;

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Test Selection & Configuration Sidebar */}
      <div className="w-full lg:w-80 bg-slate-900 border-r border-slate-800 p-4 space-y-4 overflow-y-auto">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <Sigma className="w-3.5 h-3.5 text-blue-400" />
            Hypothesis Testing Lab
          </h3>

          {/* Test Selector */}
          <div className="space-y-1">
            {[
              { id: 'two-sample', label: 'Two-Sample t-test (Welch / Student)' },
              { id: 'one-sample', label: 'One-Sample t-test' },
              { id: 'paired', label: 'Paired Samples t-test' },
              { id: 'anova', label: 'One-Way ANOVA (with Tukey HSD)' },
              { id: 'chisquare', label: "Chi-Square Test of Independence" },
              { id: 'mann-whitney', label: 'Mann-Whitney U (Nonparametric)' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTestType(t.id as any)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition ${
                  testType === t.id
                    ? 'bg-blue-600 text-white font-semibold shadow-sm'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Parameters Form */}
        <div className="pt-3 border-t border-slate-800 space-y-3">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">
            Parameters
          </span>

          {testType !== 'chisquare' && (
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">
                {testType === 'paired' ? 'First Measurement (Before)' : 'Outcome Variable (Y)'}
              </label>
              <select
                value={varY}
                onChange={(e) => setVarY(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                {numericVars.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
          )}

          {testType === 'paired' && (
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">
                Second Measurement (After)
              </label>
              <select
                value={varX2}
                onChange={(e) => setVarX2(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                {numericVars.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
          )}

          {(testType === 'two-sample' || testType === 'anova' || testType === 'mann-whitney') && (
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">
                Grouping Factor (X)
              </label>
              <select
                value={groupFactor}
                onChange={(e) => setGroupFactor(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                {categoricalVars.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
          )}

          {testType === 'one-sample' && (
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">
                Hypothesized Mean (μ₀)
              </label>
              <input
                type="number"
                step="any"
                value={mu0}
                onChange={(e) => setMu0(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>
          )}

          {testType === 'two-sample' && (
            <div className="flex items-center space-x-2 pt-1">
              <input
                type="checkbox"
                id="equalVarCheck"
                checked={equalVar}
                onChange={(e) => setEqualVar(e.target.checked)}
                className="rounded accent-blue-500 cursor-pointer"
              />
              <label htmlFor="equalVarCheck" className="text-xs text-slate-300 cursor-pointer">
                Assume Equal Variances (Student t)
              </label>
            </div>
          )}

          {testType !== 'anova' && testType !== 'chisquare' && (
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">
                Alternative Hypothesis
              </label>
              <select
                value={alternative}
                onChange={(e) => setAlternative(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
              >
                <option value="two.sided">Two-Sided (≠)</option>
                <option value="greater">Greater ({'>'})</option>
                <option value="less">Less ({'<' })</option>
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Main Results Display */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {res ? (
          <>
            {/* Main Result Card */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-5 shadow-lg space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <h2 className="text-base font-semibold text-white flex items-center gap-2">
                    <Sigma className="w-5 h-5 text-blue-400" />
                    {res.testName}
                  </h2>
                  <span className="text-xs font-mono text-emerald-400">
                    R Function: {res.rFunction}
                  </span>
                </div>

                {/* Significance Badge */}
                <div className="flex items-center gap-2">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold font-mono ${
                      res.pValue < 0.05
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {res.pValue < 0.05 ? `Statistically Significant (${res.significance})` : 'Not Significant (p ≥ 0.05)'}
                  </span>
                </div>
              </div>

              {/* Primary Statistical Metrics Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-950/70 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[11px] block">{res.statisticName} Statistic</span>
                  <span className="font-mono text-lg font-bold text-white">
                    {res.statisticValue.toFixed(3)}
                  </span>
                </div>

                <div className="p-3 bg-slate-950/70 rounded-lg border border-slate-800">
                  <span className="text-slate-400 text-[11px] block">p-value</span>
                  <span
                    className={`font-mono text-lg font-bold ${
                      res.pValue < 0.05 ? 'text-emerald-400' : 'text-slate-200'
                    }`}
                  >
                    {res.pValue < 0.0001 ? '< 0.0001' : res.pValue.toFixed(4)}
                  </span>
                </div>

                {res.df !== undefined && (
                  <div className="p-3 bg-slate-950/70 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Degrees of Freedom</span>
                    <span className="font-mono text-lg font-bold text-slate-200">
                      {Array.isArray(res.df) ? `${res.df[0]}, ${res.df[1]}` : typeof res.df === 'number' ? res.df.toFixed(1) : res.df}
                    </span>
                  </div>
                )}

                {res.effectSize && (
                  <div className="p-3 bg-slate-950/70 rounded-lg border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">{res.effectSize.name}</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="font-mono text-lg font-bold text-blue-400">
                        {res.effectSize.value.toFixed(3)}
                      </span>
                      <span className="text-[10px] uppercase font-semibold text-slate-400">
                        ({res.effectSize.magnitude})
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Confidence Interval (if applicable) */}
              {res.ci && (
                <div className="p-3 bg-blue-950/20 border border-blue-900/40 rounded-lg flex items-center justify-between text-xs font-mono">
                  <span className="text-blue-300 font-semibold">
                    {((res.ciConfidence ?? 0.95) * 100).toFixed(0)}% Confidence Interval:
                  </span>
                  <span className="text-slate-200 font-bold">
                    [{res.ci[0].toFixed(3)}, {res.ci[1].toFixed(3)}]
                  </span>
                </div>
              )}

              {/* Plain-Language Executive Explanation */}
              <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                <span className="text-xs font-semibold text-blue-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  Plain-Language Finding
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {res.plainExplanation}
                </p>
              </div>
            </div>

            {/* ANOVA Table (if applicable) */}
            {(resultData as any)?.anovaTable && (
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3">
                <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                  ANOVA Summary Decomposition Table
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400">
                        <th className="py-2 px-3">Source of Variation</th>
                        <th className="py-2 px-3">df</th>
                        <th className="py-2 px-3">Sum of Sq (SS)</th>
                        <th className="py-2 px-3">Mean Sq (MS)</th>
                        <th className="py-2 px-3">F-Value</th>
                        <th className="py-2 px-3">p-value</th>
                        <th className="py-2 px-3">η²</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {(resultData as any).anovaTable.map((row: any) => (
                        <tr key={row.term || row.source} className="hover:bg-slate-800/50">
                          <td className="py-2 px-3 font-semibold text-slate-200">{row.term || row.source}</td>
                          <td className="py-2 px-3">{row.df}</td>
                          <td className="py-2 px-3">{row.sumSq.toFixed(2)}</td>
                          <td className="py-2 px-3">{row.meanSq.toFixed(2)}</td>
                          <td className="py-2 px-3 text-blue-400 font-bold">{row.fValue > 0 ? row.fValue.toFixed(3) : '-'}</td>
                          <td className="py-2 px-3 text-emerald-400">{row.pValue < 1 ? (row.pValue < 0.0001 ? '< 0.0001' : row.pValue.toFixed(4)) : '-'}</td>
                          <td className="py-2 px-3">{row.etaSq !== undefined ? row.etaSq.toFixed(3) : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tukey Post-Hoc Table (if applicable) */}
            {(resultData as any)?.tukeyTable && (resultData as any).tukeyTable.length > 0 && (
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3">
                <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                  Tukey Honestly Significant Difference (HSD) Post-Hoc Pairwise Comparisons
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400">
                        <th className="py-2 px-3">Comparison Pair</th>
                        <th className="py-2 px-3">Mean Difference</th>
                        <th className="py-2 px-3">95% CI Lower</th>
                        <th className="py-2 px-3">95% CI Upper</th>
                        <th className="py-2 px-3">Adjusted p-value</th>
                        <th className="py-2 px-3">Conclusion</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {(resultData as any).tukeyTable.map((t: any) => (
                        <tr key={t.comparison} className="hover:bg-slate-800/50">
                          <td className="py-2 px-3 font-semibold text-blue-400">{t.comparison}</td>
                          <td className="py-2 px-3">{t.diff.toFixed(3)}</td>
                          <td className="py-2 px-3">{t.ciLower.toFixed(3)}</td>
                          <td className="py-2 px-3">{t.ciUpper.toFixed(3)}</td>
                          <td className="py-2 px-3 font-bold text-emerald-400">{t.pAdj < 0.0001 ? '< 0.0001' : t.pAdj.toFixed(4)}</td>
                          <td className="py-2 px-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                t.pAdj < 0.05
                                  ? 'bg-emerald-500/20 text-emerald-300'
                                  : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              {t.pAdj < 0.05 ? 'Significant' : 'Not Significant'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Assumptions & Diagnostics Strip */}
            {res.assumptions && res.assumptions.length > 0 && (
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3">
                <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Statistical Assumption Auditing
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {res.assumptions.map((ass) => (
                    <div
                      key={ass.name}
                      className="p-3 bg-slate-950/70 rounded-lg border border-slate-800 space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-200">{ass.name}</span>
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            ass.status === 'passed'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : ass.status === 'warning'
                              ? 'bg-amber-500/20 text-amber-300'
                              : 'bg-rose-500/20 text-rose-300'
                          }`}
                        >
                          {ass.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px]">{ass.details}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Reproducible R Code Box */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-emerald-400 font-mono flex items-center gap-1.5">
                  <Code2 className="w-4 h-4 text-emerald-400" />
                  Exact Reproducible R Script
                </span>
                <button
                  onClick={() => handleCopyCode(res.rCode)}
                  className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded text-xs text-slate-200 transition"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'Copied' : 'Copy R Code'}
                </button>
              </div>
              <pre className="p-3 bg-slate-950 rounded-lg font-mono text-xs text-emerald-400 overflow-x-auto border border-slate-800/80">
                {res.rCode}
              </pre>
            </div>
          </>
        ) : (
          <div className="text-center py-20 text-slate-500">
            Select variables from the sidebar to execute statistical inference.
          </div>
        )}
      </div>
    </div>
  );
}
