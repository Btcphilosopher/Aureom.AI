'use client';

import React, { useState } from 'react';
import { Dataset, Variable } from '@/lib/istats/types';
import { Upload, FileText, Check, X, AlertCircle } from 'lucide-react';

interface CSVImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (newDataset: Dataset) => void;
}

export function CSVImportModal({ isOpen, onClose, onImport }: CSVImportModalProps) {
  const [pastedCSV, setPastedCSV] = useState<string>('');
  const [datasetName, setDatasetName] = useState<string>('Imported Dataset');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setDatasetName(file.name.replace(/\.[^/.]+$/, ''));
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setPastedCSV(text);
    };
    reader.readAsText(file);
  };

  const parseCSVToDataset = () => {
    setError(null);
    if (!pastedCSV.trim()) {
      setError('Please paste CSV text or upload a CSV file.');
      return;
    }

    try {
      const lines = pastedCSV
        .split(/\r?\n/)
        .map((l) => l.trim())
        .filter((l) => l.length > 0);

      if (lines.length < 2) {
        setError('CSV must contain at least a header line and one data row.');
        return;
      }

      // Detect delimiter (comma, semicolon, tab)
      const firstLine = lines[0];
      let delimiter = ',';
      if (firstLine.includes('\t')) delimiter = '\t';
      else if (firstLine.includes(';') && !firstLine.includes(',')) delimiter = ';';

      const headers = firstLine.split(delimiter).map((h) => h.replace(/^["']|["']$/g, '').trim());

      const rows: Record<string, any>[] = [];
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(delimiter).map((p) => p.replace(/^["']|["']$/g, '').trim());
        if (parts.length === headers.length) {
          const rowObj: Record<string, any> = {};
          headers.forEach((h, idx) => {
            const val = parts[idx];
            // Try numeric conversion
            const numVal = Number(val);
            rowObj[h] = !isNaN(numVal) && val !== '' ? numVal : val;
          });
          rows.push(rowObj);
        }
      }

      if (rows.length === 0) {
        setError('No valid data rows found in CSV.');
        return;
      }

      // Auto-detect variable types
      const variables: Variable[] = headers.map((h) => {
        const sampleVals = rows.map((r) => r[h]).filter((v) => v !== undefined && v !== '');
        const numericCount = sampleVals.filter((v) => typeof v === 'number').length;
        const isNumeric = numericCount / sampleVals.length > 0.8;

        if (isNumeric) {
          const isAllInteger = sampleVals.every((v) => Number.isInteger(Number(v)));
          return {
            name: h,
            label: h,
            type: isAllInteger ? 'discrete' : 'continuous',
            role: 'input',
            missingCount: rows.length - sampleVals.length,
          };
        }

        const uniqueVals = Array.from(new Set(sampleVals));
        if (uniqueVals.length === 2) {
          return {
            name: h,
            label: h,
            type: 'binary',
            role: 'input',
            missingCount: rows.length - sampleVals.length,
          };
        }

        return {
          name: h,
          label: h,
          type: 'nominal',
          role: 'input',
          missingCount: rows.length - sampleVals.length,
        };
      });

      const newDataset: Dataset = {
        id: `custom_${Date.now()}`,
        name: datasetName,
        category: 'Imported',
        description: `User-imported CSV dataset with ${rows.length} observations.`,
        source: 'User CSV Upload',
        rCitation: `data <- read.csv("${datasetName}.csv")`,
        variables,
        rows,
      };

      onImport(newDataset);
      onClose();
    } catch (e: any) {
      setError(`Failed to parse CSV: ${e.message}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl flex flex-col shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-white">Import CSV Dataset</h2>
              <p className="text-[11px] text-slate-400">
                Upload a .csv file or paste raw tabular data
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div>
            <label className="text-xs text-slate-300 font-medium block mb-1">Dataset Name</label>
            <input
              type="text"
              value={datasetName}
              onChange={(e) => setDatasetName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-medium"
            />
          </div>

          <div>
            <label className="text-xs text-slate-300 font-medium block mb-1">Upload File</label>
            <input
              type="file"
              accept=".csv,.tsv,.txt"
              onChange={handleFileUpload}
              className="w-full text-xs text-slate-400 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-500 cursor-pointer bg-slate-950 border border-slate-700 p-1.5 rounded-lg"
            />
          </div>

          <div>
            <label className="text-xs text-slate-300 font-medium block mb-1">
              Or Paste CSV / Tabular Text
            </label>
            <textarea
              value={pastedCSV}
              onChange={(e) => setPastedCSV(e.target.value)}
              placeholder="id,age,income,treatment,response&#10;1,25,54000,Drug,1&#10;2,42,88000,Placebo,0"
              className="w-full h-36 bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-blue-500 resize-none leading-relaxed"
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-950/40 border border-rose-900/60 rounded-lg flex items-center gap-2 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-medium text-slate-300 transition"
            >
              Cancel
            </button>
            <button
              onClick={parseCSVToDataset}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 rounded-lg text-xs font-semibold text-white transition flex items-center gap-1.5 shadow-md"
            >
              <Check className="w-4 h-4" />
              Import & Analyze
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
