'use client';

import React, { useState, useMemo } from 'react';
import { Dataset, RegressionResult } from '@/lib/istats/types';
import { runMultipleLinearRegression, runLogisticRegression } from '@/lib/istats/regression';
import { qnorm } from '@/lib/istats/math-utils';
import {
  ResponsiveContainer,
  ComposedChart,
  Scatter,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
} from 'recharts';
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  Code2,
  TrendingUp,
  Sliders,
  Copy,
  Check,
  Layers,
} from 'lucide-react';

interface RegressionViewProps {
  dataset: Dataset;
}

export function RegressionView({ dataset }: RegressionViewProps) {
  const numericVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'continuous' || v.type === 'discrete').map((v) => v.name),
    [dataset]
  );
  const binaryOrCategoricalVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'binary' || v.type === 'nominal').map((v) => v.name),
    [dataset]
  );

  const [modelType, setModelType] = useState<'linear' | 'logistic'>('linear');
  const [dependentVar, setDependentVar] = useState<string>(
    modelType === 'linear' ? numericVars[0] || '' : binaryOrCategoricalVars[0] || numericVars[0] || ''
  );
  const [selectedPredictors, setSelectedPredictors] = useState<string[]>(
    numericVars.slice(1, 4)
  );
  const [diagnosticTab, setDiagnosticTab] = useState<'residuals' | 'qq' | 'cooks' | 'roc'>('residuals');
  const [copied, setCopied] = useState<boolean>(false);

  const togglePredictor = (v: string) => {
    if (selectedPredictors.includes(v)) {
      if (selectedPredictors.length > 1) {
        setSelectedPredictors(selectedPredictors.filter((p) => p !== v));
      }
    } else {
      setSelectedPredictors([...selectedPredictors, v]);
    }
  };

  const regressionResult: RegressionResult | null = useMemo(() => {
    if (!dependentVar || selectedPredictors.length === 0) return null;
    try {
      if (modelType === 'linear') {
        return runMultipleLinearRegression(dataset.rows, dependentVar, selectedPredictors);
      } else {
        return runLogisticRegression(dataset.rows, dependentVar, selectedPredictors);
      }
    } catch (e: any) {
      console.error(e);
      return null;
    }
  }, [dataset, modelType, dependentVar, selectedPredictors]);

  // Diagnostic 1: Residuals vs Fitted data
  const resVsFittedData = useMemo(() => {
    if (!regressionResult?.predictions) return [];
    return regressionResult.predictions.map((p, idx) => ({
      fitted: Number(p.predicted.toFixed(3)),
      residual: Number(p.residual.toFixed(3)),
      zeroLine: 0,
      id: idx + 1,
    }));
  }, [regressionResult]);

  // Diagnostic 2: Normal Q-Q of residuals
  const qqData = useMemo(() => {
    if (!regressionResult?.predictions) return [];
    const resids = regressionResult.predictions.map((p) => p.residual).sort((a, b) => a - b);
    const n = resids.length;
    const mean = resids.reduce((a, b) => a + b, 0) / n;
    const sd = Math.sqrt(resids.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / (n - 1)) || 1;

    return resids.map((r, idx) => {
      const p = (idx + 0.5) / n;
      const thZ = qnorm(p, 0, 1);
      const stdRes = (r - mean) / sd;
      return {
        theoretical: Number(thZ.toFixed(3)),
        stdResidual: Number(stdRes.toFixed(3)),
        refLine: Number(thZ.toFixed(3)),
      };
    });
  }, [regressionResult]);

  // Diagnostic 3: Cook's Distance
  const cooksData = useMemo(() => {
    if (!regressionResult?.predictions) return [];
    return regressionResult.predictions.map((p, idx) => ({
      id: idx + 1,
      cooksD: Number((p.cooksD || 0).toFixed(4)),
      threshold: Number((4 / regressionResult.n).toFixed(4)),
    }));
  }, [regressionResult]);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Configuration Sidebar */}
      <div className="w-full lg:w-80 bg-slate-900 border-r border-slate-800 p-4 space-y-4 overflow-y-auto">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-blue-400" />
            Regression & Predictive Engine
          </h3>

          {/* Model Family Picker */}
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800 mb-3">
            <button
              onClick={() => {
                setModelType('linear');
                setDependentVar(numericVars[0] || '');
              }}
              className={`py-1.5 text-xs font-semibold rounded-md transition ${
                modelType === 'linear' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Multiple Linear
            </button>
            <button
              onClick={() => {
                setModelType('logistic');
                setDependentVar(binaryOrCategoricalVars[0] || numericVars[0] || '');
              }}
              className={`py-1.5 text-xs font-semibold rounded-md transition ${
                modelType === 'logistic' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Logistic (Binary)
            </button>
          </div>

          {/* Dependent Variable */}
          <div className="space-y-3">
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">
                Dependent Outcome Variable (Y)
              </label>
              <select
                value={dependentVar}
                onChange={(e) => setDependentVar(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                {(modelType === 'linear' ? numericVars : dataset.variables.map((v) => v.name)).map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>

            {/* Independent Predictors Multi-Select */}
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1.5">
                Predictor Variables (X₁, X₂, ...)
              </label>
              <div className="max-h-48 overflow-y-auto space-y-1.5 bg-slate-950 p-2 rounded-lg border border-slate-800">
                {numericVars
                  .filter((v) => v !== dependentVar)
                  .map((v) => (
                    <label
                      key={v}
                      className="flex items-center space-x-2 text-xs text-slate-300 hover:bg-slate-900 px-2 py-1 rounded cursor-pointer transition"
                    >
                      <input
                        type="checkbox"
                        checked={selectedPredictors.includes(v)}
                        onChange={() => togglePredictor(v)}
                        className="rounded accent-blue-500"
                      />
                      <span className="font-mono text-xs">{v}</span>
                    </label>
                  ))}
              </div>
            </div>
          </div>
        </div>

        {/* Model Formula Banner */}
        {regressionResult && (
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1 text-xs">
            <span className="text-slate-400 font-mono text-[11px] block">Estimated Model Formula:</span>
            <span className="font-mono text-xs text-blue-400 font-semibold block break-all">
              {regressionResult.formula}
            </span>
          </div>
        )}
      </div>

      {/* Main Results Container */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {regressionResult ? (
          <>
            {/* Top Metrics Row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {modelType === 'linear' ? (
                <>
                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">R² (Coeff of Determ.)</span>
                    <span className="font-mono text-xl font-bold text-blue-400">
                      {regressionResult.rSquared?.toFixed(4)}
                    </span>
                  </div>
                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Adjusted R²</span>
                    <span className="font-mono text-xl font-bold text-slate-200">
                      {regressionResult.adjRSquared?.toFixed(4)}
                    </span>
                  </div>
                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">F-Statistic (Model Sig)</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="font-mono text-xl font-bold text-emerald-400">
                        {regressionResult.fStatistic?.toFixed(2)}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        (p {regressionResult.fPValue! < 0.0001 ? '< 0.0001' : `= ${regressionResult.fPValue?.toFixed(4)}`})
                      </span>
                    </div>
                  </div>
                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Residual Std Error</span>
                    <span className="font-mono text-xl font-bold text-slate-200">
                      {regressionResult.residualStandardError?.toFixed(3)}
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">ROC AUC (Discriminative)</span>
                    <span className="font-mono text-xl font-bold text-emerald-400">
                      {regressionResult.auc?.toFixed(3)}
                    </span>
                  </div>
                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">AIC Information Criterion</span>
                    <span className="font-mono text-xl font-bold text-blue-400">
                      {regressionResult.aic?.toFixed(1)}
                    </span>
                  </div>
                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Log-Likelihood</span>
                    <span className="font-mono text-xl font-bold text-slate-200">
                      {regressionResult.logLikelihood?.toFixed(1)}
                    </span>
                  </div>
                  <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[11px] block">Total Sample (N)</span>
                    <span className="font-mono text-xl font-bold text-slate-200">
                      {regressionResult.n}
                    </span>
                  </div>
                </>
              )}
            </div>

            {/* Coefficients Summary Table */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3 shadow-md">
              <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center justify-between">
                <span>Model Coefficients & Inferential Significance</span>
                <span className="text-[10px] font-mono text-slate-400">
                  *** p&lt;0.001, ** p&lt;0.01, * p&lt;0.05
                </span>
              </h3>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400">
                      <th className="py-2 px-3">Predictor (Term)</th>
                      <th className="py-2 px-3">Estimate (β)</th>
                      <th className="py-2 px-3">Std. Error</th>
                      <th className="py-2 px-3">{modelType === 'linear' ? 't-value' : 'z-value'}</th>
                      <th className="py-2 px-3">p-value</th>
                      <th className="py-2 px-3">95% CI Lower</th>
                      <th className="py-2 px-3">95% CI Upper</th>
                      {modelType === 'linear' ? (
                        <th className="py-2 px-3">VIF</th>
                      ) : (
                        <th className="py-2 px-3">Odds Ratio (OR)</th>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {regressionResult.coefficients.map((c) => (
                      <tr key={c.term} className="hover:bg-slate-800/50">
                        <td className="py-2 px-3 font-semibold text-blue-400">{c.term}</td>
                        <td className="py-2 px-3 text-white font-bold">{c.estimate.toFixed(4)}</td>
                        <td className="py-2 px-3">{c.stdError.toFixed(4)}</td>
                        <td className="py-2 px-3 text-slate-200">{c.statistic.toFixed(3)}</td>
                        <td className="py-2 px-3 font-bold text-emerald-400">
                          {c.pValue < 0.0001 ? '< 0.0001 ***' : c.pValue < 0.01 ? `${c.pValue.toFixed(4)} **` : c.pValue < 0.05 ? `${c.pValue.toFixed(4)} *` : c.pValue.toFixed(4)}
                        </td>
                        <td className="py-2 px-3 text-slate-400">{c.ciLower?.toFixed(3)}</td>
                        <td className="py-2 px-3 text-slate-400">{c.ciUpper?.toFixed(3)}</td>
                        {modelType === 'linear' ? (
                          <td className="py-2 px-3">
                            {c.vif !== undefined ? (
                              <span
                                className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  c.vif < 5
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : c.vif < 10
                                    ? 'bg-amber-500/20 text-amber-300'
                                    : 'bg-rose-500/20 text-rose-300'
                                }`}
                              >
                                {c.vif.toFixed(2)}
                              </span>
                            ) : (
                              '-'
                            )}
                          </td>
                        ) : (
                          <td className="py-2 px-3 text-amber-400 font-bold">
                            {c.oddsRatio ? c.oddsRatio.toFixed(3) : '-'}
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Diagnostic Plots Tabs */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-4 shadow-md">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
                <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                  Model Diagnostic Visualizations
                </h3>
                <div className="flex items-center space-x-1">
                  {[
                    { id: 'residuals', label: 'Residuals vs Fitted' },
                    { id: 'qq', label: 'Normal Q-Q' },
                    { id: 'cooks', label: "Cook's Distance" },
                    ...(modelType === 'logistic' ? [{ id: 'roc', label: 'ROC Curve' }] : []),
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setDiagnosticTab(tab.id as any)}
                      className={`px-3 py-1 rounded-md text-xs font-medium transition ${
                        diagnosticTab === tab.id
                          ? 'bg-blue-600 text-white font-semibold'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="h-72 w-full">
                {diagnosticTab === 'residuals' && (
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={resVsFittedData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                      <XAxis dataKey="fitted" stroke="#94a3b8" fontSize={11} label={{ value: 'Fitted Values (ŷ)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                      <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'Residuals (y - ŷ)', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                      <Scatter dataKey="residual" fill="#38bdf8" name="Residual" />
                      <Line dataKey="zeroLine" stroke="#ef4444" strokeDasharray="4 4" dot={false} name="Zero Error Reference" />
                    </ComposedChart>
                  </ResponsiveContainer>
                )}

                {diagnosticTab === 'qq' && (
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={qqData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                      <XAxis dataKey="theoretical" stroke="#94a3b8" fontSize={11} label={{ value: 'Theoretical Normal Quantiles', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                      <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'Standardized Residuals', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                      <Scatter dataKey="stdResidual" fill="#3b82f6" name="Standardized Residuals" />
                      <Line dataKey="refLine" stroke="#ef4444" strokeDasharray="4 4" dot={false} name="45° Normality Line" />
                    </ComposedChart>
                  </ResponsiveContainer>
                )}

                {diagnosticTab === 'cooks' && (
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={cooksData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                      <XAxis dataKey="id" stroke="#94a3b8" fontSize={11} label={{ value: 'Observation Row #', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                      <YAxis stroke="#94a3b8" fontSize={11} label={{ value: "Cook's Distance", angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                      <Bar dataKey="cooksD" fill="#f59e0b" radius={[2, 2, 0, 0]} name="Cook's D" />
                      <Line dataKey="threshold" stroke="#ef4444" strokeDasharray="4 4" dot={false} name="4/n Benchmark" />
                    </ComposedChart>
                  </ResponsiveContainer>
                )}

                {diagnosticTab === 'roc' && regressionResult.rocCurve && (
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={regressionResult.rocCurve} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                      <XAxis dataKey="fpr" stroke="#94a3b8" fontSize={11} label={{ value: 'False Positive Rate (1 - Specificity)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                      <YAxis dataKey="tpr" stroke="#94a3b8" fontSize={11} label={{ value: 'True Positive Rate (Sensitivity)', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                      <Line type="monotone" dataKey="tpr" stroke="#10b981" strokeWidth={2.5} dot={false} name="ROC Curve" />
                    </ComposedChart>
                  </ResponsiveContainer>
                )}
              </div>
            </div>

            {/* Plain-English Summary & R Code */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider block">
                  Model Interpretation & Conclusions
                </span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {regressionResult.plainExplanation}
                </p>
              </div>

              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-emerald-400 font-mono flex items-center gap-1.5">
                    <Code2 className="w-3.5 h-3.5 text-emerald-400" />
                    R Code Snippet
                  </span>
                  <button
                    onClick={() => handleCopyCode(regressionResult.rCode)}
                    className="flex items-center gap-1 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 rounded text-[11px] text-slate-300 transition"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre className="text-[10px] font-mono text-emerald-400 overflow-x-auto p-2 bg-slate-950 rounded border border-slate-800">
                  {regressionResult.rCode}
                </pre>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-20 text-slate-500">
            Select an outcome variable and at least one predictor variable to build the regression model.
          </div>
        )}
      </div>
    </div>
  );
}
