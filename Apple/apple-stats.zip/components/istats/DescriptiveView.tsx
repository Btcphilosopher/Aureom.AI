'use client';

import React, { useState, useMemo } from 'react';
import { Dataset } from '@/lib/istats/types';
import { computeDescriptiveStats, computeQuantile } from '@/lib/istats/descriptive';
import { dnorm, qnorm, loessSmoother } from '@/lib/istats/math-utils';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ScatterChart,
  Scatter,
  ZAxis,
  Cell,
} from 'recharts';
import {
  BarChart2,
  TrendingUp,
  Sliders,
  Code2,
  Activity,
  Layers,
  Sparkles,
  HelpCircle,
} from 'lucide-react';

interface DescriptiveViewProps {
  dataset: Dataset;
}

export function DescriptiveView({ dataset }: DescriptiveViewProps) {
  const numericVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'continuous' || v.type === 'discrete').map((v) => v.name),
    [dataset]
  );
  const categoricalVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'nominal' || v.type === 'ordinal' || v.type === 'binary').map((v) => v.name),
    [dataset]
  );

  const [selectedVarX, setSelectedVarX] = useState<string>(numericVars[0] || '');
  const [selectedVarY, setSelectedVarY] = useState<string>(numericVars[1] || numericVars[0] || '');
  const [groupVar, setGroupVar] = useState<string>('none');
  const [chartType, setChartType] = useState<
    'histogram' | 'boxplot' | 'qqplot' | 'scatter' | 'correlation'
  >('histogram');
  const [binCount, setBinCount] = useState<number>(20);

  // Compute stats for selected variable X
  const statsX = useMemo(() => {
    if (!selectedVarX) return null;
    const vals = dataset.rows.map((r) => r[selectedVarX]);
    return computeDescriptiveStats(vals, selectedVarX, true);
  }, [dataset, selectedVarX]);

  // Histogram + KDE Data
  const histogramData = useMemo(() => {
    if (!selectedVarX || !statsX || statsX.validCount === 0) return [];
    const values = dataset.rows
      .map((r) => Number(r[selectedVarX]))
      .filter((v) => !isNaN(v))
      .sort((a, b) => a - b);

    const min = statsX.min ?? 0;
    const max = statsX.max ?? 1;
    const n = values.length;
    const binWidth = (max - min) / binCount || 1;
    const mean = statsX.mean ?? 0;
    const sd = statsX.sd ?? 1;

    const bins = Array.from({ length: binCount }, (_, idx) => {
      const x0 = min + idx * binWidth;
      const x1 = x0 + binWidth;
      const mid = (x0 + x1) / 2;
      const count = values.filter((v) => (idx === binCount - 1 ? v >= x0 && v <= x1 : v >= x0 && v < x1)).length;
      const density = n > 0 && binWidth > 0 ? count / (n * binWidth) : 0;
      const normalFit = dnorm(mid, mean, sd);

      return {
        bin: mid.toFixed(2),
        mid,
        count,
        density: Number(density.toFixed(4)),
        normalFit: Number(normalFit.toFixed(4)),
      };
    });

    return bins;
  }, [dataset, selectedVarX, statsX, binCount]);

  // Q-Q Plot Data (Sample Quantiles vs Theoretical Standard Normal Quantiles)
  const qqPlotData = useMemo(() => {
    if (!selectedVarX || !statsX || statsX.validCount === 0) return [];
    const values = dataset.rows
      .map((r) => Number(r[selectedVarX]))
      .filter((v) => !isNaN(v))
      .sort((a, b) => a - b);

    const n = values.length;
    const mean = statsX.mean ?? 0;
    const sd = statsX.sd ?? 1;

    return values.map((val, idx) => {
      const p = (idx + 0.5) / n;
      const theoreticalZ = qnorm(p, 0, 1);
      const standardizedSample = sd > 0 ? (val - mean) / sd : 0;
      return {
        theoretical: Number(theoreticalZ.toFixed(3)),
        sample: Number(standardizedSample.toFixed(3)),
        refLine: Number(theoreticalZ.toFixed(3)),
        actualValue: val,
      };
    });
  }, [dataset, selectedVarX, statsX]);

  // Scatter Plot Data with LOESS curve
  const scatterData = useMemo(() => {
    if (!selectedVarX || !selectedVarY) return [];
    const validPairs = dataset.rows
      .filter((r) => !isNaN(Number(r[selectedVarX])) && !isNaN(Number(r[selectedVarY])))
      .map((r) => ({
        x: Number(r[selectedVarX]),
        y: Number(r[selectedVarY]),
        group: groupVar !== 'none' ? String(r[groupVar] || 'Default') : 'Sample',
      }))
      .sort((a, b) => a.x - b.x);

    const xs = validPairs.map((p) => p.x);
    const ys = validPairs.map((p) => p.y);
    const loessSmooth = loessSmoother(xs, ys, 0.6);

    return validPairs.map((pt, idx) => ({
      ...pt,
      loess: loessSmooth[idx],
    }));
  }, [dataset, selectedVarX, selectedVarY, groupVar]);

  // Pearson Correlation Matrix
  const correlationMatrix = useMemo(() => {
    const mat: { var1: string; var2: string; r: number }[] = [];
    for (const v1 of numericVars) {
      for (const v2 of numericVars) {
        const pairs = dataset.rows.filter(
          (r) => !isNaN(Number(r[v1])) && !isNaN(Number(r[v2]))
        );
        const n = pairs.length;
        if (n > 1) {
          const mean1 = pairs.reduce((a, b) => a + Number(b[v1]), 0) / n;
          const mean2 = pairs.reduce((a, b) => a + Number(b[v2]), 0) / n;

          let num = 0;
          let den1 = 0;
          let den2 = 0;

          for (const p of pairs) {
            const d1 = Number(p[v1]) - mean1;
            const d2 = Number(p[v2]) - mean2;
            num += d1 * d2;
            den1 += d1 * d1;
            den2 += d2 * d2;
          }

          const r = Math.sqrt(den1 * den2) > 0 ? num / Math.sqrt(den1 * den2) : 0;
          mat.push({ var1: v1, var2: v2, r: Number(r.toFixed(3)) });
        }
      }
    }
    return mat;
  }, [dataset, numericVars]);

  // Group breakdown stats
  const groupedStats = useMemo(() => {
    if (groupVar === 'none' || !selectedVarX) return null;
    const groups = Array.from(new Set(dataset.rows.map((r) => String(r[groupVar] || 'Unknown'))));
    return groups.map((g) => {
      const subset = dataset.rows.filter((r) => String(r[groupVar]) === g).map((r) => r[selectedVarX]);
      return {
        groupName: g,
        stats: computeDescriptiveStats(subset, `${selectedVarX} (${g})`, true),
      };
    });
  }, [dataset, selectedVarX, groupVar]);

  const getColorForCorrelation = (r: number) => {
    if (r > 0.7) return 'bg-blue-600 text-white font-bold';
    if (r > 0.4) return 'bg-blue-800 text-blue-100';
    if (r > 0.1) return 'bg-slate-800 text-slate-200';
    if (r > -0.1) return 'bg-slate-900 text-slate-400';
    if (r > -0.4) return 'bg-slate-800 text-slate-200';
    if (r > -0.7) return 'bg-rose-900 text-rose-100';
    return 'bg-rose-600 text-white font-bold';
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Controls Sidebar */}
      <div className="w-full lg:w-72 bg-slate-900 border-r border-slate-800 p-4 space-y-4 overflow-y-auto">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-blue-400" />
            Visual Statistics Controls
          </h3>

          <div className="space-y-3">
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">Primary Variable (X)</label>
              <select
                value={selectedVarX}
                onChange={(e) => setSelectedVarX(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                {numericVars.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>

            {chartType === 'scatter' && (
              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1">Response Variable (Y)</label>
                <select
                  value={selectedVarY}
                  onChange={(e) => setSelectedVarY(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  {numericVars.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">Group / Factor (Optional)</label>
              <select
                value={groupVar}
                onChange={(e) => setGroupVar(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="none">None (Entire Dataset)</option>
                {categoricalVars.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>

            {chartType === 'histogram' && (
              <div>
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                  <span>Histogram Bins</span>
                  <span className="font-mono text-blue-400">{binCount}</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="50"
                  value={binCount}
                  onChange={(e) => setBinCount(Number(e.target.value))}
                  className="w-full accent-blue-500"
                />
              </div>
            )}
          </div>
        </div>

        {/* Chart View Mode Switcher */}
        <div className="pt-3 border-t border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 font-medium block mb-2">Graph Archetype</span>
          {[
            { id: 'histogram', label: 'Histogram & KDE Density' },
            { id: 'qqplot', label: 'Normal Q-Q Probability Plot' },
            { id: 'scatter', label: 'Scatter with LOESS Smoother' },
            { id: 'correlation', label: 'Correlation Matrix Heatmap' },
          ].map((mode) => (
            <button
              key={mode.id}
              onClick={() => setChartType(mode.id as any)}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition ${
                chartType === mode.id
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        {/* Quick R Code Box */}
        <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1 text-xs">
          <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1">
            <Code2 className="w-3.5 h-3.5 text-emerald-400" />
            iStats R Formula
          </span>
          <pre className="text-[10px] font-mono text-emerald-400 overflow-x-auto p-1 bg-slate-900 rounded">
            {chartType === 'histogram'
              ? `ggplot(dataset, aes(x=${selectedVarX})) +
  geom_histogram(aes(y=..density..), bins=${binCount}) +
  geom_density(col="blue")`
              : chartType === 'qqplot'
              ? `qqnorm(dataset$${selectedVarX})
qqline(dataset$${selectedVarX}, col="red")`
              : chartType === 'scatter'
              ? `ggplot(dataset, aes(x=${selectedVarX}, y=${selectedVarY})) +
  geom_point() + geom_smooth(method="loess")`
              : `cor(dataset[, sapply(dataset, is.numeric)])`}
          </pre>
        </div>
      </div>

      {/* Main Visual & Statistical Dashboard */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6">
        {/* Top Visual Chart Box */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-white flex items-center gap-2">
                <BarChart2 className="w-4 h-4 text-blue-400" />
                {chartType === 'histogram' && `Empirical Distribution & Kernel Density: ${selectedVarX}`}
                {chartType === 'qqplot' && `Normal Q-Q (Quantile-Quantile) Plot: ${selectedVarX}`}
                {chartType === 'scatter' && `Bivariate Relationship: ${selectedVarX} vs ${selectedVarY}`}
                {chartType === 'correlation' && 'Full Pearson Correlation Matrix'}
              </h2>
              <p className="text-xs text-slate-400">
                {chartType === 'histogram' && 'Histogram frequencies with overlaid theoretical Gaussian density curve'}
                {chartType === 'qqplot' && 'Checks if observations deviate systematically from theoretical normal distribution'}
                {chartType === 'scatter' && 'Scatter points with non-parametric LOESS local polynomial regression'}
                {chartType === 'correlation' && 'Pairwise linear correlation coefficients across all continuous variables'}
              </p>
            </div>
          </div>

          <div className="h-80 w-full">
            {chartType === 'histogram' && (
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={histogramData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="bin" stroke="#94a3b8" fontSize={11} />
                  <YAxis yAxisId="left" stroke="#3b82f6" fontSize={11} label={{ value: 'Count', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#10b981" fontSize={11} label={{ value: 'Density', angle: 90, position: 'insideRight', fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                  <Bar yAxisId="left" dataKey="count" fill="#3b82f6" opacity={0.65} radius={[4, 4, 0, 0]} name="Frequency Count" />
                  <Line yAxisId="right" type="monotone" dataKey="normalFit" stroke="#10b981" strokeWidth={2} dot={false} name="Normal PDF Fit" />
                </ComposedChart>
              </ResponsiveContainer>
            )}

            {chartType === 'qqplot' && (
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={qqPlotData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="theoretical" stroke="#94a3b8" fontSize={11} label={{ value: 'Theoretical Standard Normal Quantiles (Z)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                  <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'Sample Standardized Quantiles', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                  <Scatter dataKey="sample" fill="#3b82f6" name="Sample Quantiles" />
                  <Line dataKey="refLine" stroke="#ef4444" strokeWidth={1.5} strokeDasharray="4 4" dot={false} name="45° Normality Line" />
                </ComposedChart>
              </ResponsiveContainer>
            )}

            {chartType === 'scatter' && (
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={scatterData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="x" stroke="#94a3b8" fontSize={11} label={{ value: selectedVarX, position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                  <YAxis dataKey="y" stroke="#94a3b8" fontSize={11} label={{ value: selectedVarY, angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                  <Scatter dataKey="y" fill="#38bdf8" opacity={0.7} name="Observation" />
                  <Line dataKey="loess" stroke="#f59e0b" strokeWidth={2.5} dot={false} name="LOESS Smoother" />
                </ComposedChart>
              </ResponsiveContainer>
            )}

            {chartType === 'correlation' && (
              <div className="overflow-auto max-h-72">
                <table className="w-full text-center border-collapse text-xs font-mono">
                  <thead>
                    <tr>
                      <th className="p-2 border border-slate-800 bg-slate-950 text-slate-400">Var</th>
                      {numericVars.map((v) => (
                        <th key={v} className="p-2 border border-slate-800 bg-slate-950 text-slate-300 font-semibold">
                          {v}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {numericVars.map((v1) => (
                      <tr key={v1}>
                        <td className="p-2 border border-slate-800 bg-slate-950 text-slate-300 font-semibold text-left">
                          {v1}
                        </td>
                        {numericVars.map((v2) => {
                          const item = correlationMatrix.find((c) => c.var1 === v1 && c.var2 === v2);
                          const r = item ? item.r : 0;
                          return (
                            <td
                              key={v2}
                              className={`p-2 border border-slate-800 font-mono transition ${getColorForCorrelation(
                                r
                              )}`}
                            >
                              {r.toFixed(2)}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Comprehensive Moments & Quantiles Card */}
        {statsX && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Column 1: Central Tendency & Scale */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
                <Activity className="w-3.5 h-3.5 text-blue-400" />
                Moments & Dispersion
              </h3>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Mean (μ)</span>
                  <span className="text-blue-400 font-semibold">{statsX.mean?.toFixed(4)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Standard Deviation (s)</span>
                  <span className="text-slate-200">{statsX.sd?.toFixed(4)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Sample Variance (s²)</span>
                  <span className="text-slate-200">{statsX.variance?.toFixed(4)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Standard Error (SE)</span>
                  <span className="text-slate-200">{statsX.se?.toFixed(4)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Coeff. of Variation (CV)</span>
                  <span className="text-slate-200">{statsX.cv?.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">MAD (Median Abs Dev)</span>
                  <span className="text-slate-200">{statsX.mad?.toFixed(4)}</span>
                </div>
              </div>
            </div>

            {/* Column 2: Quantiles & Percentiles */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
                <Layers className="w-3.5 h-3.5 text-emerald-400" />
                Quantiles (Type 7 Standard)
              </h3>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Minimum</span>
                  <span className="text-slate-200">{statsX.min?.toFixed(3)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Q1 (25th Percentile)</span>
                  <span className="text-slate-200">{statsX.q1?.toFixed(3)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Median (50th Percentile)</span>
                  <span className="text-emerald-400 font-semibold">{statsX.median?.toFixed(3)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Q3 (75th Percentile)</span>
                  <span className="text-slate-200">{statsX.q3?.toFixed(3)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">IQR (Q3 - Q1)</span>
                  <span className="text-slate-200">{statsX.iqr?.toFixed(3)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Maximum</span>
                  <span className="text-slate-200">{statsX.max?.toFixed(3)}</span>
                </div>
              </div>
            </div>

            {/* Column 3: Shape & Robust Estimators */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Shape & Robust Means
              </h3>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Skewness (g₁)</span>
                  <span className={`${Math.abs(statsX.skewness ?? 0) > 1 ? 'text-amber-400' : 'text-slate-200'}`}>
                    {statsX.skewness?.toFixed(3)}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Excess Kurtosis (g₂)</span>
                  <span className={`${Math.abs(statsX.kurtosis ?? 0) > 1.5 ? 'text-amber-400' : 'text-slate-200'}`}>
                    {statsX.kurtosis?.toFixed(3)}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">10% Trimmed Mean</span>
                  <span className="text-slate-200">{statsX.trimmedMean?.toFixed(3)}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Geometric Mean</span>
                  <span className="text-slate-200">
                    {statsX.geometricMean !== undefined ? statsX.geometricMean.toFixed(3) : 'N/A (≤0 values)'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/60">
                  <span className="text-slate-400">Harmonic Mean</span>
                  <span className="text-slate-200">
                    {statsX.harmonicMean !== undefined ? statsX.harmonicMean.toFixed(3) : 'N/A'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Group Breakdown Table (if grouping variable selected) */}
        {groupedStats && groupedStats.length > 0 && (
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
            <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
              Factor Group Comparison: {selectedVarX} across levels of {groupVar}
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2 px-3">Factor Level</th>
                    <th className="py-2 px-3">N</th>
                    <th className="py-2 px-3">Mean</th>
                    <th className="py-2 px-3">SD</th>
                    <th className="py-2 px-3">Median</th>
                    <th className="py-2 px-3">IQR</th>
                    <th className="py-2 px-3">Min</th>
                    <th className="py-2 px-3">Max</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {groupedStats.map((g) => (
                    <tr key={g.groupName} className="hover:bg-slate-800/50">
                      <td className="py-2 px-3 font-semibold text-blue-400">{g.groupName}</td>
                      <td className="py-2 px-3">{g.stats.validCount}</td>
                      <td className="py-2 px-3 text-white">{g.stats.mean?.toFixed(3)}</td>
                      <td className="py-2 px-3">{g.stats.sd?.toFixed(3)}</td>
                      <td className="py-2 px-3">{g.stats.median?.toFixed(3)}</td>
                      <td className="py-2 px-3">{g.stats.iqr?.toFixed(3)}</td>
                      <td className="py-2 px-3">{g.stats.min?.toFixed(3)}</td>
                      <td className="py-2 px-3">{g.stats.max?.toFixed(3)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
