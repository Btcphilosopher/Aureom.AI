'use client';

import React, { useState, useMemo } from 'react';
import { Dataset, TimeSeriesResult } from '@/lib/istats/types';
import { runTimeSeriesForecast } from '@/lib/istats/timeseries';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  Activity,
  Calendar,
  AlertTriangle,
  Code2,
  TrendingUp,
  Sliders,
  Copy,
  Check,
  Zap,
} from 'lucide-react';

interface TimeSeriesViewProps {
  dataset: Dataset;
}

export function TimeSeriesView({ dataset }: TimeSeriesViewProps) {
  const numericVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'continuous' || v.type === 'discrete').map((v) => v.name),
    [dataset]
  );
  const dateOrTextVars = useMemo(
    () => dataset.variables.map((v) => v.name),
    [dataset]
  );

  const [dateVar, setDateVar] = useState<string>(
    dataset.variables.find((v) => v.type === 'date')?.name || dateOrTextVars[0] || ''
  );
  const [valueVar, setValueVar] = useState<string>(numericVars[0] || '');
  const [horizon, setHorizon] = useState<number>(12);
  const [activeSubTab, setActiveSubTab] = useState<'forecast' | 'decomp' | 'acf' | 'anomalies'>('forecast');
  const [copied, setCopied] = useState<boolean>(false);

  const tsResult: TimeSeriesResult | null = useMemo(() => {
    if (!dateVar || !valueVar) return null;
    try {
      return runTimeSeriesForecast(dataset.rows, dateVar, valueVar, horizon);
    } catch (e: any) {
      console.error(e);
      return null;
    }
  }, [dataset, dateVar, valueVar, horizon]);

  // Merge historical + forecast into single continuous time series chart
  const combinedForecastChartData = useMemo(() => {
    if (!tsResult) return [];
    const hist = tsResult.historical.map((h) => ({
      date: h.date,
      historical: h.value,
      trend: h.trend,
      forecast: undefined,
      lower80: undefined,
      upper80: undefined,
      lower95: undefined,
      upper95: undefined,
    }));

    const lastHist = hist[hist.length - 1];
    const fc = tsResult.forecast.map((f) => ({
      date: f.date,
      historical: undefined,
      trend: undefined,
      forecast: Number(f.forecast.toFixed(2)),
      lower80: Number(f.lower80.toFixed(2)),
      upper80: Number(f.upper80.toFixed(2)),
      lower95: Number(f.lower95.toFixed(2)),
      upper95: Number(f.upper95.toFixed(2)),
    }));

    return [...hist, ...fc];
  }, [tsResult]);

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Configuration Sidebar */}
      <div className="w-full lg:w-80 bg-slate-900 border-r border-slate-800 p-4 space-y-4 overflow-y-auto">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-blue-400" />
            Time Series & Forecasting
          </h3>

          <div className="space-y-3">
            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">Time / Date Index</label>
              <select
                value={dateVar}
                onChange={(e) => setDateVar(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                {dateOrTextVars.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs text-slate-300 font-medium block mb-1">Series Value (Y)</label>
              <select
                value={valueVar}
                onChange={(e) => setValueVar(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                {numericVars.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                <span>Forecast Horizon</span>
                <span className="font-mono text-blue-400 font-semibold">+{horizon} steps</span>
              </div>
              <input
                type="range"
                min="3"
                max="24"
                value={horizon}
                onChange={(e) => setHorizon(Number(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>
          </div>
        </div>

        {/* View Mode Tabs */}
        <div className="pt-3 border-t border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 font-medium block mb-2">Analysis View</span>
          {[
            { id: 'forecast', label: 'Multi-Step Forecast & Prediction Bands' },
            { id: 'decomp', label: 'STL Classical Decomposition (Trend/Season)' },
            { id: 'acf', label: 'Autocorrelation (ACF & PACF)' },
            { id: 'anomalies', label: 'Residual Anomaly Spikes' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition ${
                activeSubTab === tab.id
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Accuracy Metrics */}
        {tsResult && (
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2 text-xs">
            <span className="text-slate-400 font-semibold block uppercase tracking-wider text-[10px]">
              Model Fit Accuracy
            </span>
            <div className="grid grid-cols-3 gap-2 text-center font-mono">
              <div className="p-1.5 bg-slate-900 rounded border border-slate-800">
                <span className="text-[10px] text-slate-400 block">RMSE</span>
                <span className="text-blue-400 font-bold">{tsResult.metrics.rmse.toFixed(2)}</span>
              </div>
              <div className="p-1.5 bg-slate-900 rounded border border-slate-800">
                <span className="text-[10px] text-slate-400 block">MAE</span>
                <span className="text-slate-200 font-bold">{tsResult.metrics.mae.toFixed(2)}</span>
              </div>
              <div className="p-1.5 bg-slate-900 rounded border border-slate-800">
                <span className="text-[10px] text-slate-400 block">MAPE</span>
                <span className="text-emerald-400 font-bold">{tsResult.metrics.mape.toFixed(1)}%</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main Results Display */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {tsResult ? (
          <>
            {/* Forecast View */}
            {activeSubTab === 'forecast' && (
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-semibold text-white flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-blue-400" />
                      {tsResult.method} Model Forecast: {valueVar}
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5">{tsResult.modelDetails}</p>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono">
                    <span className="flex items-center gap-1 text-slate-300">
                      <span className="w-3 h-0.5 bg-blue-400 inline-block" /> Historical
                    </span>
                    <span className="flex items-center gap-1 text-emerald-400">
                      <span className="w-3 h-0.5 bg-emerald-400 inline-block" /> Forecast
                    </span>
                  </div>
                </div>

                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={combinedForecastChartData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                      <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                      <YAxis stroke="#94a3b8" fontSize={11} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                      <Line type="monotone" dataKey="historical" stroke="#38bdf8" strokeWidth={2} dot={false} name="Observed Series" />
                      <Line type="monotone" dataKey="forecast" stroke="#10b981" strokeWidth={2.5} dot={{ r: 3 }} name="Point Forecast" />
                      <Area type="monotone" dataKey="upper95" stroke="#10b981" strokeWidth={0} fill="#10b981" fillOpacity={0.15} name="95% Upper CI" />
                      <Area type="monotone" dataKey="lower95" stroke="#10b981" strokeWidth={0} fill="#0f172a" fillOpacity={0} name="95% Lower CI" />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* STL Decomposition View */}
            {activeSubTab === 'decomp' && (
              <div className="space-y-4">
                <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-2">
                  <h3 className="text-xs font-semibold text-white uppercase tracking-wider">Trend Component</h3>
                  <div className="h-44 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={tsResult.historical} margin={{ top: 5, right: 20, bottom: 10, left: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                        <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '10px' }} />
                        <Line type="monotone" dataKey="trend" stroke="#f59e0b" strokeWidth={2} dot={false} name="Trend" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-2">
                  <h3 className="text-xs font-semibold text-white uppercase tracking-wider">Seasonal Component</h3>
                  <div className="h-44 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={tsResult.historical} margin={{ top: 5, right: 20, bottom: 10, left: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                        <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '10px' }} />
                        <Line type="monotone" dataKey="seasonal" stroke="#3b82f6" strokeWidth={1.5} dot={false} name="Seasonality" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-2">
                  <h3 className="text-xs font-semibold text-white uppercase tracking-wider">Remainder / Residuals</h3>
                  <div className="h-44 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={tsResult.historical} margin={{ top: 5, right: 20, bottom: 10, left: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                        <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} />
                        <YAxis stroke="#94a3b8" fontSize={10} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '10px' }} />
                        <Line type="monotone" dataKey="remainder" stroke="#ef4444" strokeWidth={1.5} dot={false} name="Residual" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )}

            {/* Autocorrelation (ACF & PACF) View */}
            {activeSubTab === 'acf' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-2">
                  <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                    Autocorrelation Function (ACF)
                  </h3>
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={tsResult.acf} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                        <XAxis dataKey="lag" stroke="#94a3b8" fontSize={11} label={{ value: 'Lag (k)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                        <YAxis domain={[-1, 1]} stroke="#94a3b8" fontSize={11} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                        <Bar dataKey="acf" fill="#3b82f6" name="ACF" />
                        <Line dataKey="ci" stroke="#ef4444" strokeDasharray="3 3" dot={false} name="+95% CI" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-2">
                  <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                    Partial Autocorrelation Function (PACF)
                  </h3>
                  <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={tsResult.pacf} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                        <XAxis dataKey="lag" stroke="#94a3b8" fontSize={11} label={{ value: 'Lag (k)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                        <YAxis domain={[-1, 1]} stroke="#94a3b8" fontSize={11} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                        <Bar dataKey="pacf" fill="#10b981" name="PACF" />
                        <Line dataKey="ci" stroke="#ef4444" strokeDasharray="3 3" dot={false} name="+95% CI" />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )}

            {/* Anomalies Table View */}
            {activeSubTab === 'anomalies' && (
              <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-3 shadow-md">
                <h3 className="text-xs font-semibold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  Residual Anomaly & Outlier Inspector
                </h3>

                {tsResult.anomalies.length > 0 ? (
                  <table className="w-full text-left text-xs font-mono border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400">
                        <th className="py-2 px-3">Date Index</th>
                        <th className="py-2 px-3">Observed Value</th>
                        <th className="py-2 px-3">Z-Score Deviation</th>
                        <th className="py-2 px-3">Classification</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {tsResult.anomalies.map((a) => (
                        <tr key={a.index} className="hover:bg-slate-800/50">
                          <td className="py-2 px-3 font-semibold text-blue-400">{a.date}</td>
                          <td className="py-2 px-3 text-white font-bold">{a.value.toFixed(2)}</td>
                          <td className="py-2 px-3 text-amber-400 font-bold">{a.zScore.toFixed(2)}σ</td>
                          <td className="py-2 px-3 text-slate-300">{a.reason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="py-10 text-center text-slate-400 text-xs">
                    No severe anomalies detected (all residuals within ±2.5σ).
                  </div>
                )}
              </div>
            )}

            {/* R Code Box */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 space-y-2">
              <span className="text-xs font-semibold text-emerald-400 font-mono flex items-center gap-1.5">
                <Code2 className="w-4 h-4 text-emerald-400" />
                Pure R Script with forecast & stl
              </span>
              <pre className="p-3 bg-slate-950 rounded-lg font-mono text-xs text-emerald-400 overflow-x-auto border border-slate-800/80">
                {tsResult.rCode}
              </pre>
            </div>
          </>
        ) : (
          <div className="text-center py-20 text-slate-500">
            Select a time date index and numeric series value to perform forecasting.
          </div>
        )}
      </div>
    </div>
  );
}
