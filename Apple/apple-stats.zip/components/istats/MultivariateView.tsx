'use client';

import React, { useState, useMemo } from 'react';
import { Dataset, PcaResult, ClusterResult, SurvivalResult } from '@/lib/istats/types';
import { runPCA, runKMeans, runKaplanMeier } from '@/lib/istats/multivariate';
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from 'recharts';
import {
  Layers,
  Sparkles,
  Code2,
  Sliders,
  Copy,
  Check,
  Activity,
} from 'lucide-react';

interface MultivariateViewProps {
  dataset: Dataset;
}

export function MultivariateView({ dataset }: MultivariateViewProps) {
  const numericVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'continuous' || v.type === 'discrete').map((v) => v.name),
    [dataset]
  );
  const categoricalVars = useMemo(
    () => dataset.variables.filter((v) => v.type === 'nominal' || v.type === 'ordinal' || v.type === 'binary').map((v) => v.name),
    [dataset]
  );

  const [activeModule, setActiveModule] = useState<'pca' | 'kmeans' | 'survival'>('pca');
  const [selectedVars, setSelectedVars] = useState<string[]>(numericVars.slice(0, 4));
  const [kClusters, setKClusters] = useState<number>(3);
  const [scalePCA, setScalePCA] = useState<boolean>(true);

  // Survival variables
  const [timeVar, setTimeVar] = useState<string>(numericVars[0] || '');
  const [statusVar, setStatusVar] = useState<string>(categoricalVars[0] || numericVars[1] || '');
  const [survivalGroup, setSurvivalGroup] = useState<string>('none');

  const toggleVariable = (v: string) => {
    if (selectedVars.includes(v)) {
      if (selectedVars.length > 2) {
        setSelectedVars(selectedVars.filter((item) => item !== v));
      }
    } else {
      setSelectedVars([...selectedVars, v]);
    }
  };

  // PCA execution
  const pcaResult: PcaResult | null = useMemo(() => {
    if (selectedVars.length < 2) return null;
    try {
      return runPCA(dataset.rows, selectedVars, scalePCA);
    } catch (e) {
      console.error(e);
      return null;
    }
  }, [dataset, selectedVars, scalePCA]);

  // K-Means execution
  const kmeansResult: ClusterResult | null = useMemo(() => {
    if (selectedVars.length < 2) return null;
    try {
      return runKMeans(dataset.rows, selectedVars, kClusters);
    } catch (e) {
      console.error(e);
      return null;
    }
  }, [dataset, selectedVars, kClusters]);

  // Kaplan-Meier execution
  const survivalResult: SurvivalResult | null = useMemo(() => {
    if (!timeVar || !statusVar) return null;
    try {
      return runKaplanMeier(
        dataset.rows,
        timeVar,
        statusVar,
        survivalGroup !== 'none' ? survivalGroup : undefined
      );
    } catch (e) {
      console.error(e);
      return null;
    }
  }, [dataset, timeVar, statusVar, survivalGroup]);

  const clusterColors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4'];

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Configuration Sidebar */}
      <div className="w-full lg:w-80 bg-slate-900 border-r border-slate-800 p-4 space-y-4 overflow-y-auto">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-blue-400" />
            Multivariate & Unsupervised
          </h3>

          <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800 mb-3 text-xs">
            <button
              onClick={() => setActiveModule('pca')}
              className={`py-1.5 rounded font-semibold ${activeModule === 'pca' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              PCA
            </button>
            <button
              onClick={() => setActiveModule('kmeans')}
              className={`py-1.5 rounded font-semibold ${activeModule === 'kmeans' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              K-Means
            </button>
            <button
              onClick={() => setActiveModule('survival')}
              className={`py-1.5 rounded font-semibold ${activeModule === 'survival' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Survival
            </button>
          </div>

          {activeModule !== 'survival' ? (
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1.5">
                  Select Variables for Dimensional Reduction
                </label>
                <div className="max-h-48 overflow-y-auto space-y-1.5 bg-slate-950 p-2 rounded-lg border border-slate-800">
                  {numericVars.map((v) => (
                    <label
                      key={v}
                      className="flex items-center space-x-2 text-xs text-slate-300 hover:bg-slate-900 px-2 py-1 rounded cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedVars.includes(v)}
                        onChange={() => toggleVariable(v)}
                        className="rounded accent-blue-500"
                      />
                      <span className="font-mono text-xs">{v}</span>
                    </label>
                  ))}
                </div>
              </div>

              {activeModule === 'kmeans' && (
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-300">Number of Clusters (k)</span>
                    <span className="font-mono text-blue-400 font-bold">k = {kClusters}</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="6"
                    value={kClusters}
                    onChange={(e) => setKClusters(Number(e.target.value))}
                    className="w-full accent-blue-500"
                  />
                </div>
              )}

              {activeModule === 'pca' && (
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="scaleCheck"
                    checked={scalePCA}
                    onChange={(e) => setScalePCA(e.target.checked)}
                    className="rounded accent-blue-500"
                  />
                  <label htmlFor="scaleCheck" className="text-xs text-slate-300 cursor-pointer">
                    Scale to Unit Variance (Correlation Matrix)
                  </label>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1">Duration / Time (t)</label>
                <select
                  value={timeVar}
                  onChange={(e) => setTimeVar(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-slate-200"
                >
                  {numericVars.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1">Event / Censoring (0/1)</label>
                <select
                  value={statusVar}
                  onChange={(e) => setStatusVar(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-slate-200"
                >
                  {dataset.variables.map((v) => (
                    <option key={v.name} value={v.name}>
                      {v.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1">Strata Factor (Optional)</label>
                <select
                  value={survivalGroup}
                  onChange={(e) => setSurvivalGroup(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded px-2 py-1.5 text-xs text-slate-200"
                >
                  <option value="none">None (Single Cohort)</option>
                  {categoricalVars.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Analysis Visualizations */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {/* PCA Module */}
        {activeModule === 'pca' && pcaResult && (
          <div className="space-y-5">
            {/* Scree Plot */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <h2 className="text-sm font-semibold text-white flex items-center justify-between">
                <span>PCA Scree Plot & Cumulative Variance Explained</span>
                <span className="text-xs font-mono text-blue-400">
                  Total Explained by PC1+PC2: {(
                    ((pcaResult.components[0]?.varianceExplained || 0) +
                      (pcaResult.components[1]?.varianceExplained || 0))
                  ).toFixed(1)}%
                </span>
              </h2>

              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={pcaResult.components} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} />
                    <YAxis yAxisId="left" stroke="#3b82f6" fontSize={11} label={{ value: '% Variance', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis yAxisId="right" orientation="right" stroke="#10b981" fontSize={11} domain={[0, 100]} label={{ value: 'Cum %', angle: 90, position: 'insideRight', fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                    <Bar yAxisId="left" dataKey="varianceExplained" fill="#3b82f6" radius={[4, 4, 0, 0]} name="% Variance" />
                    <Line yAxisId="right" type="monotone" dataKey="cumulativeVariance" stroke="#10b981" strokeWidth={2} dot={{ r: 4 }} name="Cumulative %" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* PC1 vs PC2 Biplot Scores */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                Principal Component Biplot: PC1 vs PC2 Scores
              </h3>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="pc1" stroke="#94a3b8" fontSize={11} label={{ value: `PC1 (${pcaResult.components[0]?.varianceExplained.toFixed(1)}%)`, position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis dataKey="pc2" stroke="#94a3b8" fontSize={11} label={{ value: `PC2 (${pcaResult.components[1]?.varianceExplained.toFixed(1)}%)`, angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                    <Scatter data={pcaResult.scores} fill="#38bdf8" name="Observation" />
                  </ScatterChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Loadings Matrix */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                Eigenvector Loadings Matrix
              </h3>
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2 px-3">Variable</th>
                    {pcaResult.components.map((c) => (
                      <th key={c.name} className="py-2 px-3">{c.name}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {selectedVars.map((v) => (
                    <tr key={v} className="hover:bg-slate-800/50">
                      <td className="py-2 px-3 font-semibold text-blue-400">{v}</td>
                      {pcaResult.components.map((c) => (
                        <td key={c.name} className="py-2 px-3 text-slate-200">
                          {c.loadings[v]?.toFixed(3)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* K-Means Module */}
        {activeModule === 'kmeans' && kmeansResult && (
          <div className="space-y-5">
            {/* Cluster Centroids Table */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <h2 className="text-sm font-semibold text-white flex items-center justify-between">
                <span>K-Means Cluster Profiling (k = {kClusters})</span>
              </h2>

              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2 px-3">Cluster</th>
                    <th className="py-2 px-3">Size (N)</th>
                    <th className="py-2 px-3">% Total</th>
                    {selectedVars.map((v) => (
                      <th key={v} className="py-2 px-3">{v} Centroid</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {kmeansResult.clusters.map((c, idx) => (
                    <tr key={c.id} className="hover:bg-slate-800/50">
                      <td className="py-2 px-3 font-semibold flex items-center gap-1.5" style={{ color: clusterColors[idx % clusterColors.length] }}>
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: clusterColors[idx % clusterColors.length] }} />
                        {c.name}
                      </td>
                      <td className="py-2 px-3">{c.size}</td>
                      <td className="py-2 px-3">{c.percentage.toFixed(1)}%</td>
                      {selectedVars.map((v) => (
                        <td key={v} className="py-2 px-3 text-slate-200 font-bold">
                          {c.centroid[v]?.toFixed(2)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* WSS Elbow Curve */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                Elbow Criterion: Within-Cluster Sum of Squares (WSS) vs Number of Clusters k
              </h3>
              <div className="h-60 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={kmeansResult.elbowData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="k" stroke="#94a3b8" fontSize={11} label={{ value: 'Number of Clusters (k)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'Total WSS', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                    <Line type="monotone" dataKey="wss" stroke="#f59e0b" strokeWidth={2.5} dot={{ r: 4 }} name="WSS" />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* Kaplan-Meier Survival Module */}
        {activeModule === 'survival' && survivalResult && (
          <div className="space-y-5">
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <h2 className="text-sm font-semibold text-white flex items-center justify-between">
                <span>Kaplan-Meier Survival Probability Curves S(t)</span>
              </h2>

              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                    <XAxis dataKey="time" type="number" stroke="#94a3b8" fontSize={11} label={{ value: 'Time (t)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                    <YAxis domain={[0, 1]} stroke="#94a3b8" fontSize={11} label={{ value: 'Survival S(t)', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px' }} />
                    {survivalResult.curves.map((curve, idx) => (
                      <Line
                        key={curve.group}
                        data={curve.points}
                        type="stepAfter"
                        dataKey="survival"
                        stroke={clusterColors[idx % clusterColors.length]}
                        strokeWidth={2.5}
                        dot={false}
                        name={curve.group}
                      />
                    ))}
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Survival Cohorts Summary Table */}
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-3">
              <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                Survival Summary & Median Event Times
              </h3>
              <table className="w-full text-left text-xs font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2 px-3">Strata Group</th>
                    <th className="py-2 px-3">Total (N)</th>
                    <th className="py-2 px-3">Events Observed</th>
                    <th className="py-2 px-3">Censored</th>
                    <th className="py-2 px-3">Median Survival Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {survivalResult.curves.map((c) => (
                    <tr key={c.group} className="hover:bg-slate-800/50">
                      <td className="py-2 px-3 font-semibold text-blue-400">{c.group}</td>
                      <td className="py-2 px-3">{c.total}</td>
                      <td className="py-2 px-3 text-rose-400 font-bold">{c.events}</td>
                      <td className="py-2 px-3 text-slate-400">{c.total - c.events}</td>
                      <td className="py-2 px-3 text-emerald-400 font-bold">
                        {c.medianSurvival !== undefined ? c.medianSurvival.toFixed(1) : 'Not reached (>50%)'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
