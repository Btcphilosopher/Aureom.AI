'use client';

import React from 'react';
import {
  Database,
  Upload,
  Sparkles,
  Download,
  Terminal,
  BarChart3,
  Table as TableIcon,
  Sigma,
  Activity,
  GitBranch,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { Dataset } from '@/lib/istats/types';
import { SAMPLE_DATASETS } from '@/lib/istats/sample-datasets';

interface HeaderProps {
  datasets: Dataset[];
  currentDataset: Dataset;
  onSelectDataset: (dataset: Dataset) => void;
  activeTab: string;
  setActiveTab: (tab: any) => void;
  onOpenImport: () => void;
  onOpenExport: () => void;
  onOpenRConsole: () => void;
}

export function Header({
  datasets,
  currentDataset,
  onSelectDataset,
  activeTab,
  setActiveTab,
  onOpenImport,
  onOpenExport,
  onOpenRConsole,
}: HeaderProps) {
  const tabs = [
    { id: 'data', label: 'Data Hub', icon: TableIcon },
    { id: 'descriptive', label: 'Visual Stats', icon: BarChart3 },
    { id: 'inference', label: 'Hypothesis Tests', icon: Sigma },
    { id: 'regression', label: 'Regression', icon: Activity },
    { id: 'distributions', label: 'Distributions', icon: GitBranch },
    { id: 'timeseries', label: 'Time Series', icon: Activity },
    { id: 'multivariate', label: 'Multivariate', icon: Layers },
    { id: 'bayesian', label: 'Bayes & Bootstrap', icon: Sparkles },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 select-none sticky top-0 z-30 shadow-md">
      {/* Top Window Bar with macOS Traffic Lights & Identity */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800/80 bg-slate-950/70">
        <div className="flex items-center space-x-3">
          {/* Traffic Lights */}
          <div className="flex items-center space-x-2 mr-2">
            <div className="w-3 h-3 rounded-full bg-rose-500/90 border border-rose-600 shadow-sm" />
            <div className="w-3 h-3 rounded-full bg-amber-500/90 border border-amber-600 shadow-sm" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/90 border border-emerald-600 shadow-sm" />
          </div>

          <div className="flex items-center space-x-2">
            <span className="font-semibold text-sm tracking-tight text-white flex items-center gap-1.5">
              <span className="text-blue-400 font-bold"></span> Apple Stats
            </span>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-400 border border-blue-500/30">
              iStats Engine
            </span>
          </div>
        </div>

        {/* Dataset Selector Pill */}
        <div className="flex items-center space-x-2">
          <div className="flex items-center bg-slate-800/90 rounded-lg px-2.5 py-1 border border-slate-700 text-xs shadow-inner">
            <Database className="w-3.5 h-3.5 text-blue-400 mr-2" />
            <span className="text-slate-400 mr-1.5">Dataset:</span>
            <select
              value={currentDataset.id}
              onChange={(e) => {
                const found = datasets.find((d) => d.id === e.target.value);
                if (found) onSelectDataset(found);
              }}
              className="bg-transparent text-slate-100 font-medium focus:outline-none cursor-pointer text-xs"
            >
              {datasets.map((ds) => (
                <option key={ds.id} value={ds.id} className="bg-slate-900 text-slate-100">
                  {ds.name} ({ds.rows.length} rows, {ds.variables.length} vars)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Tools */}
        <div className="flex items-center space-x-1.5">
          <button
            onClick={onOpenImport}
            className="flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            title="Import CSV, Excel, or JSON"
          >
            <Upload className="w-3.5 h-3.5 text-blue-400" />
            Import CSV
          </button>

          <button
            onClick={onOpenRConsole}
            className="flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            title="Open iStats R Console & Script Inspector"
          >
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            R Console & Script
          </button>
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      <div className="flex items-center space-x-1 px-4 py-1.5 overflow-x-auto scrollbar-none bg-slate-900">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm font-semibold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              {tab.label}
            </button>
          );
        })}
      </div>
    </header>
  );
}
