'use client';

import React, { useState, useMemo } from 'react';
import { DistributionType } from '@/lib/istats/types';
import {
  DISTRIBUTIONS_REGISTRY,
  computePDF,
  computeCDF,
  generateDistributionCurve,
} from '@/lib/istats/distributions';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
} from 'recharts';
import {
  GitBranch,
  Sliders,
  Code2,
  Sparkles,
  Calculator,
  HelpCircle,
} from 'lucide-react';

export function DistributionView() {
  const [selectedDist, setSelectedDist] = useState<DistributionType>('normal');
  const distInfo = DISTRIBUTIONS_REGISTRY[selectedDist];

  // Distribution parameters state
  const [params, setParams] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    distInfo.parameters.forEach((p) => {
      initial[p.name] = p.defaultValue;
    });
    return initial;
  });

  // Tail probability calculator state
  const [calcMode, setCalcMode] = useState<'left' | 'right' | 'between' | 'two-tail'>('left');
  const [xVal, setXVal] = useState<number>(1.96);
  const [xVal2, setXVal2] = useState<number>(-1.96);

  // Switch distribution handler
  const handleSelectDist = (type: DistributionType) => {
    setSelectedDist(type);
    const newInfo = DISTRIBUTIONS_REGISTRY[type];
    const newParams: Record<string, number> = {};
    newInfo.parameters.forEach((p) => {
      newParams[p.name] = p.defaultValue;
    });
    setParams(newParams);
  };

  const handleParamChange = (name: string, val: number) => {
    setParams((prev) => ({ ...prev, [name]: val }));
  };

  // Curve data
  const curvePoints = useMemo(() => {
    return generateDistributionCurve(selectedDist, params, 200);
  }, [selectedDist, params]);

  // Compute tail probability
  const probabilityResult = useMemo(() => {
    try {
      if (calcMode === 'left') {
        const prob = computeCDF(selectedDist, xVal, params);
        return {
          label: `P(X ≤ ${xVal})`,
          prob,
          rExpr: `${distInfo.rFunction.cdf.replace('q', String(xVal))}`,
        };
      }
      if (calcMode === 'right') {
        const cdfVal = computeCDF(selectedDist, xVal, params);
        const prob = 1 - cdfVal;
        return {
          label: `P(X ≥ ${xVal})`,
          prob,
          rExpr: `1 - ${distInfo.rFunction.cdf.replace('q', String(xVal))}`,
        };
      }
      if (calcMode === 'between') {
        const lo = Math.min(xVal, xVal2);
        const hi = Math.max(xVal, xVal2);
        const prob = computeCDF(selectedDist, hi, params) - computeCDF(selectedDist, lo, params);
        return {
          label: `P(${lo} ≤ X ≤ ${hi})`,
          prob,
          rExpr: `${distInfo.rFunction.cdf.replace('q', String(hi))} - ${distInfo.rFunction.cdf.replace('q', String(lo))}`,
        };
      }
      if (calcMode === 'two-tail') {
        const absX = Math.abs(xVal);
        const prob = computeCDF(selectedDist, -absX, params) + (1 - computeCDF(selectedDist, absX, params));
        return {
          label: `P(|X| ≥ ${absX})`,
          prob,
          rExpr: `2 * (1 - ${distInfo.rFunction.cdf.replace('q', String(absX))})`,
        };
      }
      return { label: '', prob: 0, rExpr: '' };
    } catch {
      return { label: 'Error', prob: 0, rExpr: '' };
    }
  }, [selectedDist, params, calcMode, xVal, xVal2, distInfo]);

  // Highlight shaded region in curve data
  const chartData = useMemo(() => {
    return curvePoints.map((pt) => {
      let isShaded = false;
      if (calcMode === 'left') isShaded = pt.x <= xVal;
      else if (calcMode === 'right') isShaded = pt.x >= xVal;
      else if (calcMode === 'between') {
        const lo = Math.min(xVal, xVal2);
        const hi = Math.max(xVal, xVal2);
        isShaded = pt.x >= lo && pt.x <= hi;
      } else if (calcMode === 'two-tail') {
        const absX = Math.abs(xVal);
        isShaded = pt.x <= -absX || pt.x >= absX;
      }

      return {
        x: Number(pt.x.toFixed(3)),
        pdf: Number(pt.pdf.toFixed(5)),
        shadedPdf: isShaded ? Number(pt.pdf.toFixed(5)) : 0,
      };
    });
  }, [curvePoints, calcMode, xVal, xVal2]);

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-slate-950 text-slate-100">
      {/* Sidebar: Distribution Picker & Parameter Sliders */}
      <div className="w-full lg:w-80 bg-slate-900 border-r border-slate-800 p-4 space-y-4 overflow-y-auto">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
            <GitBranch className="w-3.5 h-3.5 text-blue-400" />
            Distribution Family (15+)
          </h3>
          <select
            value={selectedDist}
            onChange={(e) => handleSelectDist(e.target.value as DistributionType)}
            className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-semibold"
          >
            <optgroup label="Continuous Distributions">
              <option value="normal">Normal (Gaussian)</option>
              <option value="t">Student-t</option>
              <option value="chisquare">Chi-Square (χ²)</option>
              <option value="f">F-Distribution</option>
              <option value="exponential">Exponential</option>
              <option value="gamma">Gamma</option>
              <option value="beta">Beta</option>
              <option value="weibull">Weibull</option>
              <option value="lognormal">Log-Normal</option>
              <option value="uniform">Uniform</option>
            </optgroup>
            <optgroup label="Discrete Distributions">
              <option value="binomial">Binomial</option>
              <option value="poisson">Poisson</option>
              <option value="geometric">Geometric</option>
              <option value="negbinomial">Negative Binomial</option>
              <option value="hypergeometric">Hypergeometric</option>
            </optgroup>
          </select>
        </div>

        {/* Parameters Controls */}
        <div className="pt-3 border-t border-slate-800 space-y-3">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">
            Parameters
          </span>
          {distInfo.parameters.map((p) => (
            <div key={p.name} className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">{p.label}</span>
                <span className="font-mono text-blue-400 font-semibold">
                  {params[p.name]}
                </span>
              </div>
              <input
                type="range"
                min={p.min ?? -10}
                max={p.max ?? 30}
                step={p.step ?? 0.1}
                value={params[p.name] ?? p.defaultValue}
                onChange={(e) => handleParamChange(p.name, Number(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>
          ))}
        </div>

        {/* Tail Probability Calculator Form */}
        <div className="pt-3 border-t border-slate-800 space-y-3">
          <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1">
            <Calculator className="w-3.5 h-3.5 text-emerald-400" />
            Tail Probability Calculator
          </span>

          <div className="grid grid-cols-2 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setCalcMode('left')}
              className={`py-1 rounded font-medium ${calcMode === 'left' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
              P(X ≤ x)
            </button>
            <button
              onClick={() => setCalcMode('right')}
              className={`py-1 rounded font-medium ${calcMode === 'right' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
              P(X ≥ x)
            </button>
            <button
              onClick={() => setCalcMode('between')}
              className={`py-1 rounded font-medium ${calcMode === 'between' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
              P(a ≤ X ≤ b)
            </button>
            <button
              onClick={() => setCalcMode('two-tail')}
              className={`py-1 rounded font-medium ${calcMode === 'two-tail' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}
            >
              P(|X| ≥ x)
            </button>
          </div>

          <div className="space-y-2">
            <div>
              <label className="text-xs text-slate-400 block mb-1">
                {calcMode === 'between' ? 'Bound a (Lower)' : 'Critical Value (x)'}
              </label>
              <input
                type="number"
                step="any"
                value={xVal}
                onChange={(e) => setXVal(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1 text-xs text-slate-200 font-mono focus:outline-none focus:border-blue-500"
              />
            </div>

            {calcMode === 'between' && (
              <div>
                <label className="text-xs text-slate-400 block mb-1">Bound b (Upper)</label>
                <input
                  type="number"
                  step="any"
                  value={xVal2}
                  onChange={(e) => setXVal2(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-md px-2.5 py-1 text-xs text-slate-200 font-mono focus:outline-none focus:border-blue-500"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Graph & Formulas */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {/* Top Header Card */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-white flex items-center gap-2">
              <GitBranch className="w-4 h-4 text-blue-400" />
              {distInfo.name} Distribution
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">{distInfo.description}</p>
          </div>

          {/* Calculated Probability Display */}
          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-right">
            <span className="text-[11px] font-mono text-slate-400 block">{probabilityResult.label}</span>
            <span className="font-mono text-xl font-bold text-emerald-400">
              {probabilityResult.prob.toFixed(5)}
            </span>
            <span className="text-[10px] font-mono text-slate-500 block">
              {(probabilityResult.prob * 100).toFixed(2)}% Area
            </span>
          </div>
        </div>

        {/* Probability Density / Mass Curve */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-4 shadow-md space-y-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Probability Density Curve & Shaded Integration Area
            </span>
          </div>

          <div className="h-80 w-full">
            {distInfo.category === 'discrete' ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="x" stroke="#94a3b8" fontSize={11} label={{ value: 'k (Outcome)', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                  <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'P(X = k)', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                  <Bar dataKey="pdf" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Probability Mass" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis dataKey="x" stroke="#94a3b8" fontSize={11} label={{ value: 'x', position: 'insideBottom', offset: -10, fill: '#94a3b8', fontSize: 10 }} />
                  <YAxis stroke="#94a3b8" fontSize={11} label={{ value: 'Density f(x)', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', fontSize: '11px', borderRadius: '8px' }} />
                  <Area type="monotone" dataKey="pdf" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.15} strokeWidth={2} name="Total PDF" />
                  <Area type="monotone" dataKey="shadedPdf" stroke="#10b981" fill="#10b981" fillOpacity={0.4} strokeWidth={0} name="Shaded Tail" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Complete R Statistical Ecosystem Reference for this Distribution */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[11px] font-semibold text-slate-400 block">Density / Mass: d*()</span>
            <code className="text-xs font-mono text-blue-400 block bg-slate-950 p-1.5 rounded">
              {distInfo.rFunction.density}
            </code>
          </div>
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[11px] font-semibold text-slate-400 block">Cumulative CDF: p*()</span>
            <code className="text-xs font-mono text-emerald-400 block bg-slate-950 p-1.5 rounded">
              {distInfo.rFunction.cdf}
            </code>
          </div>
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[11px] font-semibold text-slate-400 block">Quantile / Inverse: q*()</span>
            <code className="text-xs font-mono text-amber-400 block bg-slate-950 p-1.5 rounded">
              {distInfo.rFunction.quantile}
            </code>
          </div>
          <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
            <span className="text-[11px] font-semibold text-slate-400 block">Random RNG: r*()</span>
            <code className="text-xs font-mono text-purple-400 block bg-slate-950 p-1.5 rounded">
              {distInfo.rFunction.random}
            </code>
          </div>
        </div>
      </div>
    </div>
  );
}
