/**
 * iBase 2026 Database Templates Gallery
 * Includes Sheffield Investment Database master demo + 15 specialized templates.
 */

import { Database, FieldType, RelationshipType, ViewType, RollupFunction, AuditEventType } from '../types/database';

export function createSheffieldInvestmentDatabase(): Database {
  const dbId = 'db_sheffield_investments';
  const now = new Date().toISOString();

  // 1. Table Definitions
  const tCompaniesId = 'tbl_companies';
  const tProjectsId = 'tbl_projects';
  const tInvestmentsId = 'tbl_investments';
  const tTransactionsId = 'tbl_transactions';
  const tLocationsId = 'tbl_locations';
  const tEmployeesId = 'tbl_employees';

  // Field IDs
  // Companies
  const fCompId = 'f_c_id';
  const fCompName = 'f_c_name';
  const fCompSector = 'f_c_sector';
  const fCompCountry = 'f_c_country';
  const fCompValuation = 'f_c_valuation';
  const fCompStatus = 'f_c_status';
  const fCompFounded = 'f_c_founded';
  const fCompEmail = 'f_c_email';
  const fCompTotalInvestments = 'f_c_total_inv';
  const fCompTotalRevenue = 'f_c_total_rev';

  // Projects
  const fProjId = 'f_p_id';
  const fProjCompFk = 'f_p_comp_fk';
  const fProjTitle = 'f_p_title';
  const fProjBudget = 'f_p_budget';
  const fProjStage = 'f_p_stage';
  const fProjROI = 'f_p_roi';
  const fProjStartDate = 'f_p_start';

  // Investments
  const fInvId = 'f_i_id';
  const fInvCompFk = 'f_i_comp_fk';
  const fInvProjFk = 'f_i_proj_fk';
  const fInvFund = 'f_i_fund';
  const fInvAmount = 'f_i_amount';
  const fInvEquity = 'f_i_equity';
  const fInvDate = 'f_i_date';
  const fInvRound = 'f_i_round';

  // Transactions
  const fTxId = 'f_t_id';
  const fTxInvFk = 'f_t_inv_fk';
  const fTxType = 'f_t_type';
  const fTxAmount = 'f_t_amount';
  const fTxFee = 'f_t_fee';
  const fTxTimestamp = 'f_t_time';
  const fTxStatus = 'f_t_status';

  // Locations
  const fLocId = 'f_l_id';
  const fLocCity = 'f_l_city';
  const fLocCountry = 'f_l_country';
  const fLocRegion = 'f_l_region';
  const fLocEmployeesCount = 'f_l_emp_cnt';

  // Employees
  const fEmpId = 'f_e_id';
  const fEmpCompFk = 'f_e_comp_fk';
  const fEmpLocFk = 'f_e_loc_fk';
  const fEmpName = 'f_e_name';
  const fEmpRole = 'f_e_role';
  const fEmpEmail = 'f_e_email';
  const fEmpSalary = 'f_e_salary';

  const fields: Record<string, any> = {
    // Companies fields
    [fCompId]: { id: fCompId, tableId: tCompaniesId, name: 'Company ID', type: FieldType.TEXT, isPrimaryKey: true },
    [fCompName]: { id: fCompName, tableId: tCompaniesId, name: 'Company Name', type: FieldType.TEXT, options: { required: true } },
    [fCompSector]: { id: fCompSector, tableId: tCompaniesId, name: 'Sector', type: FieldType.ENUM, options: { enumChoices: ['Fintech', 'CleanTech', 'HealthTech', 'AI & Robotics', 'BioTech', 'Advanced Manufacturing', 'Renewables', 'Cybersecurity'] } },
    [fCompCountry]: { id: fCompCountry, tableId: tCompaniesId, name: 'Country', type: FieldType.TEXT },
    [fCompValuation]: { id: fCompValuation, tableId: tCompaniesId, name: 'Valuation', type: FieldType.CURRENCY, options: { currencySymbol: '£', decimalPlaces: 0 } },
    [fCompStatus]: { id: fCompStatus, tableId: tCompaniesId, name: 'Status', type: FieldType.ENUM, options: { enumChoices: ['Active Portfolio', 'Evaluating', 'Exited', 'Underperforming'] } },
    [fCompFounded]: { id: fCompFounded, tableId: tCompaniesId, name: 'Founded Date', type: FieldType.DATE },
    [fCompEmail]: { id: fCompEmail, tableId: tCompaniesId, name: 'Contact Email', type: FieldType.EMAIL },
    [fCompTotalInvestments]: {
      id: fCompTotalInvestments,
      tableId: tCompaniesId,
      name: 'Total Raised (£)',
      type: FieldType.ROLLUP,
      options: { rollupTargetRelationFieldId: fInvCompFk, rollupTargetFieldId: fInvAmount, rollupFunction: RollupFunction.SUM, currencySymbol: '£' }
    },

    // Projects fields
    [fProjId]: { id: fProjId, tableId: tProjectsId, name: 'Project ID', type: FieldType.TEXT, isPrimaryKey: true },
    [fProjCompFk]: { id: fProjCompFk, tableId: tProjectsId, name: 'Company', type: FieldType.RELATION, isForeignKey: true, foreignKeyTargetTableId: tCompaniesId, foreignKeyTargetFieldId: fCompId },
    [fProjTitle]: { id: fProjTitle, tableId: tProjectsId, name: 'Project Title', type: FieldType.TEXT },
    [fProjBudget]: { id: fProjBudget, tableId: tProjectsId, name: 'Budget', type: FieldType.CURRENCY, options: { currencySymbol: '£' } },
    [fProjStage]: { id: fProjStage, tableId: tProjectsId, name: 'Stage', type: FieldType.ENUM, options: { enumChoices: ['Discovery', 'Prototype', 'Scaling', 'Production', 'Completed'] } },
    [fProjROI]: { id: fProjROI, tableId: tProjectsId, name: 'Target ROI (%)', type: FieldType.PERCENTAGE },
    [fProjStartDate]: { id: fProjStartDate, tableId: tProjectsId, name: 'Start Date', type: FieldType.DATE },

    // Investments fields
    [fInvId]: { id: fInvId, tableId: tInvestmentsId, name: 'Investment ID', type: FieldType.TEXT, isPrimaryKey: true },
    [fInvCompFk]: { id: fInvCompFk, tableId: tInvestmentsId, name: 'Company', type: FieldType.RELATION, isForeignKey: true, foreignKeyTargetTableId: tCompaniesId, foreignKeyTargetFieldId: fCompId },
    [fInvProjFk]: { id: fInvProjFk, tableId: tInvestmentsId, name: 'Project', type: FieldType.RELATION, isForeignKey: true, foreignKeyTargetTableId: tProjectsId, foreignKeyTargetFieldId: fProjId },
    [fInvFund]: { id: fInvFund, tableId: tInvestmentsId, name: 'Fund Name', type: FieldType.ENUM, options: { enumChoices: ['Northern Growth Fund I', 'Sheffield Technology Seed Fund', 'Yorkshire Venture Capital II', 'Global Innovation Trust'] } },
    [fInvAmount]: { id: fInvAmount, tableId: tInvestmentsId, name: 'Amount (£)', type: FieldType.CURRENCY, options: { currencySymbol: '£' } },
    [fInvEquity]: { id: fInvEquity, tableId: tInvestmentsId, name: 'Equity Stake (%)', type: FieldType.PERCENTAGE },
    [fInvDate]: { id: fInvDate, tableId: tInvestmentsId, name: 'Investment Date', type: FieldType.DATE },
    [fInvRound]: { id: fInvRound, tableId: tInvestmentsId, name: 'Funding Round', type: FieldType.ENUM, options: { enumChoices: ['Pre-Seed', 'Seed', 'Series A', 'Series B', 'Growth'] } },

    // Transactions fields
    [fTxId]: { id: fTxId, tableId: tTransactionsId, name: 'Transaction ID', type: FieldType.TEXT, isPrimaryKey: true },
    [fTxInvFk]: { id: fTxInvFk, tableId: tTransactionsId, name: 'Investment', type: FieldType.RELATION, isForeignKey: true, foreignKeyTargetTableId: tInvestmentsId, foreignKeyTargetFieldId: fInvId },
    [fTxType]: { id: fTxType, tableId: tTransactionsId, name: 'Type', type: FieldType.ENUM, options: { enumChoices: ['Wire Transfer', 'Escrow Release', 'Equity Dividend', 'Management Fee', 'Capital Return'] } },
    [fTxAmount]: { id: fTxAmount, tableId: tTransactionsId, name: 'Gross Amount (£)', type: FieldType.CURRENCY, options: { currencySymbol: '£' } },
    [fTxFee]: { id: fTxFee, tableId: tTransactionsId, name: 'Processing Fee (£)', type: FieldType.CURRENCY, options: { currencySymbol: '£' } },
    [fTxTimestamp]: { id: fTxTimestamp, tableId: tTransactionsId, name: 'Timestamp', type: FieldType.DATETIME },
    [fTxStatus]: { id: fTxStatus, tableId: tTransactionsId, name: 'Status', type: FieldType.ENUM, options: { enumChoices: ['Settled', 'Pending', 'Processing', 'Audited'] } },

    // Locations
    [fLocId]: { id: fLocId, tableId: tLocationsId, name: 'Location ID', type: FieldType.TEXT, isPrimaryKey: true },
    [fLocCity]: { id: fLocCity, tableId: tLocationsId, name: 'City', type: FieldType.TEXT },
    [fLocCountry]: { id: fLocCountry, tableId: tLocationsId, name: 'Country', type: FieldType.TEXT },
    [fLocRegion]: { id: fLocRegion, tableId: tLocationsId, name: 'Region', type: FieldType.TEXT },
    [fLocEmployeesCount]: { id: fLocEmployeesCount, tableId: tLocationsId, name: 'Headcount', type: FieldType.INTEGER },

    // Employees
    [fEmpId]: { id: fEmpId, tableId: tEmployeesId, name: 'Employee ID', type: FieldType.TEXT, isPrimaryKey: true },
    [fEmpCompFk]: { id: fEmpCompFk, tableId: tEmployeesId, name: 'Company', type: FieldType.RELATION, isForeignKey: true, foreignKeyTargetTableId: tCompaniesId, foreignKeyTargetFieldId: fCompId },
    [fEmpLocFk]: { id: fEmpLocFk, tableId: tEmployeesId, name: 'Office Location', type: FieldType.RELATION, isForeignKey: true, foreignKeyTargetTableId: tLocationsId, foreignKeyTargetFieldId: fLocId },
    [fEmpName]: { id: fEmpName, tableId: tEmployeesId, name: 'Full Name', type: FieldType.TEXT },
    [fEmpRole]: { id: fEmpRole, tableId: tEmployeesId, name: 'Role Title', type: FieldType.TEXT },
    [fEmpEmail]: { id: fEmpEmail, tableId: tEmployeesId, name: 'Work Email', type: FieldType.EMAIL },
    [fEmpSalary]: { id: fEmpSalary, tableId: tEmployeesId, name: 'Annual Compensation (£)', type: FieldType.CURRENCY, options: { currencySymbol: '£' } },
  };

  const tables: Record<string, any> = {
    [tCompaniesId]: {
      id: tCompaniesId,
      databaseId: dbId,
      name: 'Companies',
      description: 'Portfolio companies and investment targets',
      icon: 'Building2',
      color: '#0284c7',
      fieldIds: [fCompId, fCompName, fCompSector, fCompCountry, fCompValuation, fCompStatus, fCompFounded, fCompEmail, fCompTotalInvestments],
      primaryKeyFieldId: fCompId,
      createdAt: now,
      updatedAt: now,
    },
    [tProjectsId]: {
      id: tProjectsId,
      databaseId: dbId,
      name: 'Projects',
      description: 'R&D and expansion projects per company',
      icon: 'FolderKanban',
      color: '#059669',
      fieldIds: [fProjId, fProjCompFk, fProjTitle, fProjBudget, fProjStage, fProjROI, fProjStartDate],
      primaryKeyFieldId: fProjId,
      createdAt: now,
      updatedAt: now,
    },
    [tInvestmentsId]: {
      id: tInvestmentsId,
      databaseId: dbId,
      name: 'Investments',
      description: 'Capital deployments, funding rounds, and equity stakes',
      icon: 'TrendingUp',
      color: '#7c3aed',
      fieldIds: [fInvId, fInvCompFk, fInvProjFk, fInvFund, fInvAmount, fInvEquity, fInvDate, fInvRound],
      primaryKeyFieldId: fInvId,
      createdAt: now,
      updatedAt: now,
    },
    [tTransactionsId]: {
      id: tTransactionsId,
      databaseId: dbId,
      name: 'Transactions',
      description: 'Audited financial ledger transactions',
      icon: 'Receipt',
      color: '#d97706',
      fieldIds: [fTxId, fTxInvFk, fTxType, fTxAmount, fTxFee, fTxTimestamp, fTxStatus],
      primaryKeyFieldId: fTxId,
      createdAt: now,
      updatedAt: now,
    },
    [tLocationsId]: {
      id: tLocationsId,
      databaseId: dbId,
      name: 'Locations',
      description: 'Regional headquarters and innovation hubs',
      icon: 'MapPin',
      color: '#e11d48',
      fieldIds: [fLocId, fLocCity, fLocCountry, fLocRegion, fLocEmployeesCount],
      primaryKeyFieldId: fLocId,
      createdAt: now,
      updatedAt: now,
    },
    [tEmployeesId]: {
      id: tEmployeesId,
      databaseId: dbId,
      name: 'Employees',
      description: 'Executive officers and team leads across portfolio',
      icon: 'Users',
      color: '#2563eb',
      fieldIds: [fEmpId, fEmpCompFk, fEmpLocFk, fEmpName, fEmpRole, fEmpEmail, fEmpSalary],
      primaryKeyFieldId: fEmpId,
      createdAt: now,
      updatedAt: now,
    },
  };

  // 2. Generate Realistic Sample Data (hundreds of relational items)
  const sectors = ['Fintech', 'CleanTech', 'HealthTech', 'AI & Robotics', 'BioTech', 'Advanced Manufacturing', 'Renewables', 'Cybersecurity'];
  const cities = [
    { city: 'Sheffield', country: 'United Kingdom', region: 'South Yorkshire' },
    { city: 'London', country: 'United Kingdom', region: 'Greater London' },
    { city: 'Manchester', country: 'United Kingdom', region: 'North West' },
    { city: 'Edinburgh', country: 'United Kingdom', region: 'Scotland' },
    { city: 'Cambridge', country: 'United Kingdom', region: 'East of England' },
  ];

  const companyNames = [
    'Sheffield Cybernetics', 'Yorkshire CleanEnergy', 'Peak AI Diagnostics', 'Steel City Bio', 'Hallam Advanced Robotics',
    'Doncaster Quantum', 'Rotheham Power Grid', 'Pennine Fintech', 'Derbyshire Medical', 'Northern Lithium Tech',
    'Apex Automation', 'Hyperion Aerospace', 'Summit Hydrogen', 'Vanguard Data Systems', 'Nexus Fusion Labs'
  ];

  const records: Record<string, any[]> = {
    [tCompaniesId]: [],
    [tProjectsId]: [],
    [tInvestmentsId]: [],
    [tTransactionsId]: [],
    [tLocationsId]: [],
    [tEmployeesId]: [],
  };

  // Populate Locations
  cities.forEach((loc, idx) => {
    const locId = `loc_${idx + 1}`;
    records[tLocationsId].push({
      id: locId,
      tableId: tLocationsId,
      values: {
        [fLocId]: locId,
        [fLocCity]: loc.city,
        [fLocCountry]: loc.country,
        [fLocRegion]: loc.region,
        [fLocEmployeesCount]: 120 + idx * 85,
      },
      createdAt: now,
      updatedAt: now,
    });
  });

  // Populate Companies, Projects, Investments, Transactions, Employees
  companyNames.forEach((cName, cIdx) => {
    const cId = `comp_${cIdx + 1}`;
    const sector = sectors[cIdx % sectors.length];
    const valuation = 5000000 + cIdx * 4500000;
    const status = cIdx % 5 === 0 ? 'Exited' : cIdx % 4 === 0 ? 'Evaluating' : 'Active Portfolio';

    records[tCompaniesId].push({
      id: cId,
      tableId: tCompaniesId,
      values: {
        [fCompId]: cId,
        [fCompName]: cName,
        [fCompSector]: sector,
        [fCompCountry]: 'United Kingdom',
        [fCompValuation]: valuation,
        [fCompStatus]: status,
        [fCompFounded]: `201${(cIdx % 9) + 1}-0${(cIdx % 8) + 1}-15`,
        [fCompEmail]: `contact@${cName.toLowerCase().replace(/[^a-z0-9]/g, '')}.co.uk`,
      },
      createdAt: now,
      updatedAt: now,
    });

    // 2 Projects per company
    for (let p = 1; p <= 2; p++) {
      const pId = `proj_${cIdx + 1}_${p}`;
      const stages = ['Discovery', 'Prototype', 'Scaling', 'Production', 'Completed'];
      records[tProjectsId].push({
        id: pId,
        tableId: tProjectsId,
        values: {
          [fProjId]: pId,
          [fProjCompFk]: cId,
          [fProjTitle]: `${cName.split(' ')[0]} ${p === 1 ? 'NextGen Platform' : 'Global Scaling initiative'}`,
          [fProjBudget]: 750000 + p * 500000,
          [fProjStage]: stages[(cIdx + p) % stages.length],
          [fProjROI]: 18.5 + (cIdx * 2.3) % 40,
          [fProjStartDate]: `2024-0${(p % 9) + 1}-01`,
        },
        createdAt: now,
        updatedAt: now,
      });

      // 2 Investments per project
      for (let inv = 1; inv <= 2; inv++) {
        const invId = `inv_${cIdx + 1}_${p}_${inv}`;
        const amount = 1200000 + (cIdx + inv) * 350000;
        const funds = ['Northern Growth Fund I', 'Sheffield Technology Seed Fund', 'Yorkshire Venture Capital II', 'Global Innovation Trust'];
        const rounds = ['Pre-Seed', 'Seed', 'Series A', 'Series B', 'Growth'];

        records[tInvestmentsId].push({
          id: invId,
          tableId: tInvestmentsId,
          values: {
            [fInvId]: invId,
            [fInvCompFk]: cId,
            [fInvProjFk]: pId,
            [fInvFund]: funds[(cIdx + inv) % funds.length],
            [fInvAmount]: amount,
            [fInvEquity]: 8.5 + (inv * 4.2),
            [fInvDate]: `2024-0${(cIdx % 8) + 1}-10`,
            [fInvRound]: rounds[(cIdx + inv) % rounds.length],
          },
          createdAt: now,
          updatedAt: now,
        });

        // 2 Transactions per Investment
        for (let tx = 1; tx <= 2; tx++) {
          const txId = `tx_${cIdx + 1}_${p}_${inv}_${tx}`;
          records[tTransactionsId].push({
            id: txId,
            tableId: tTransactionsId,
            values: {
              [fTxId]: txId,
              [fTxInvFk]: invId,
              [fTxType]: tx === 1 ? 'Wire Transfer' : 'Escrow Release',
              [fTxAmount]: amount / 2,
              [fTxFee]: 2500,
              [fTxTimestamp]: `2024-05-1${tx}T10:30:00Z`,
              [fTxStatus]: 'Settled',
            },
            createdAt: now,
            updatedAt: now,
          });
        }
      }
    }

    // Employees per company
    const firstNames = ['Oliver', 'Charlotte', 'George', 'Amelia', 'Harry', 'Isla', 'Noah', 'Ava', 'Jack', 'Mia'];
    const lastNames = ['Smith', 'Jones', 'Taylor', 'Brown', 'Williams', 'Wilson', 'Johnson', 'Davies', 'Patel', 'Wright'];

    for (let e = 1; e <= 3; e++) {
      const eId = `emp_${cIdx + 1}_${e}`;
      const name = `${firstNames[(cIdx + e) % firstNames.length]} ${lastNames[(cIdx + e * 2) % lastNames.length]}`;
      const roles = ['Chief Executive Officer', 'Head of R&D', 'Chief Technology Officer', 'Lead Systems Architect', 'VP of Engineering'];

      records[tEmployeesId].push({
        id: eId,
        tableId: tEmployeesId,
        values: {
          [fEmpId]: eId,
          [fEmpCompFk]: cId,
          [fEmpLocFk]: `loc_${(e % 5) + 1}`,
          [fEmpName]: name,
          [fEmpRole]: roles[(cIdx + e) % roles.length],
          [fEmpEmail]: `${name.toLowerCase().replace(/\s+/g, '.')}@${cName.toLowerCase().replace(/[^a-z0-9]/g, '')}.co.uk`,
          [fEmpSalary]: 85000 + e * 25000,
        },
        createdAt: now,
        updatedAt: now,
      });
    }
  });

  // Relationships
  const relationships: Record<string, any> = {
    rel_comp_proj: {
      id: 'rel_comp_proj',
      databaseId: dbId,
      name: 'Company to Projects',
      type: RelationshipType.ONE_TO_MANY,
      sourceTableId: tCompaniesId,
      sourceFieldId: fCompId,
      targetTableId: tProjectsId,
      targetFieldId: fProjCompFk,
      onDelete: 'CASCADE',
    },
    rel_comp_inv: {
      id: 'rel_comp_inv',
      databaseId: dbId,
      name: 'Company to Investments',
      type: RelationshipType.ONE_TO_MANY,
      sourceTableId: tCompaniesId,
      sourceFieldId: fCompId,
      targetTableId: tInvestmentsId,
      targetFieldId: fInvCompFk,
      onDelete: 'CASCADE',
    },
    rel_inv_tx: {
      id: 'rel_inv_tx',
      databaseId: dbId,
      name: 'Investment to Transactions',
      type: RelationshipType.ONE_TO_MANY,
      sourceTableId: tInvestmentsId,
      sourceFieldId: fInvId,
      targetTableId: tTransactionsId,
      targetFieldId: fTxInvFk,
      onDelete: 'CASCADE',
    },
  };

  // Views
  const views: Record<string, any[]> = {
    [tCompaniesId]: [
      { id: 'v_c_grid', tableId: tCompaniesId, name: 'All Companies Table', type: ViewType.TABLE, isDefault: true },
      { id: 'v_c_kanban', tableId: tCompaniesId, name: 'By Portfolio Status', type: ViewType.KANBAN, kanbanStatusFieldId: fCompStatus },
      { id: 'v_c_card', tableId: tCompaniesId, name: 'Company Cards', type: ViewType.CARD },
    ],
    [tProjectsId]: [
      { id: 'v_p_grid', tableId: tProjectsId, name: 'All Projects Table', type: ViewType.TABLE, isDefault: true },
      { id: 'v_p_kanban', tableId: tProjectsId, name: 'Project Stage Kanban', type: ViewType.KANBAN, kanbanStatusFieldId: fProjStage },
      { id: 'v_p_calendar', tableId: tProjectsId, name: 'Project Timeline', type: ViewType.TIMELINE, timelineStartFieldId: fProjStartDate },
    ],
    [tInvestmentsId]: [
      { id: 'v_i_grid', tableId: tInvestmentsId, name: 'All Investments Table', type: ViewType.TABLE, isDefault: true },
    ],
    [tTransactionsId]: [
      { id: 'v_t_grid', tableId: tTransactionsId, name: 'Audited Transactions', type: ViewType.TABLE, isDefault: true },
    ],
    [tLocationsId]: [
      { id: 'v_l_grid', tableId: tLocationsId, name: 'Regional Hubs', type: ViewType.TABLE, isDefault: true },
    ],
    [tEmployeesId]: [
      { id: 'v_e_grid', tableId: tEmployeesId, name: 'Directory Table', type: ViewType.TABLE, isDefault: true },
      { id: 'v_e_cards', tableId: tEmployeesId, name: 'Employee Directory', type: ViewType.CARD },
    ],
  };

  return {
    id: dbId,
    name: 'Sheffield Investment Database',
    description: 'Master enterprise portfolio, capital investments, transaction ledgers, and employee directory.',
    icon: 'Landmark',
    color: '#0284c7',
    isFavourite: true,
    isShared: true,
    createdAt: now,
    updatedAt: now,
    tables,
    fields,
    records,
    relationships,
    views,
    forms: {},
    savedQueries: [
      {
        id: 'sq_1',
        databaseId: dbId,
        name: 'High Valuation Tech Companies (> £20M)',
        type: 'SQL',
        sqlText: "SELECT * FROM Companies WHERE Valuation > 20000000 ORDER BY Valuation DESC",
        createdAt: now,
      },
      {
        id: 'sq_2',
        databaseId: dbId,
        name: 'Active Projects with Target ROI > 25%',
        type: 'SQL',
        sqlText: "SELECT * FROM Projects WHERE ROI > 25 ORDER BY ROI DESC",
        createdAt: now,
      },
    ],
    auditLogs: [
      {
        id: 'evt_init',
        databaseId: dbId,
        eventType: AuditEventType.DATABASE_CREATED,
        entityType: 'DATABASE',
        entityId: dbId,
        summary: 'Database "Sheffield Investment Database" initialized with 6 core relational tables and master records',
        user: 'System Admin',
        timestamp: now,
      },
    ],
  };
}

export const TEMPLATES_LIST = [
  {
    id: 'sheffield_investment',
    name: 'Sheffield Investment Database',
    description: 'Master portfolio, capital funding rounds, R&D projects & audited financial transactions',
    category: 'Finance & Enterprise',
    icon: 'Landmark',
    color: '#0284c7',
    buildDatabase: createSheffieldInvestmentDatabase,
  },
  {
    id: 'crm_sales',
    name: 'CRM & Sales Pipeline',
    description: 'Track lead accounts, key contacts, deal stages, and revenue forecasts',
    category: 'Sales & Marketing',
    icon: 'Users',
    color: '#2563eb',
    buildDatabase: () => createSimpleTemplate('db_crm', 'CRM & Sales Pipeline', 'Accounts, contacts & deals', [
      { name: 'Accounts', fields: ['Account Name', 'Industry', 'Annual Revenue', 'Account Owner'] },
      { name: 'Contacts', fields: ['Full Name', 'Email', 'Phone', 'Role'] },
      { name: 'Deals', fields: ['Deal Name', 'Value', 'Stage', 'Close Date'] },
    ]),
  },
  {
    id: 'software_projects',
    name: 'Projects & Tasks Tracker',
    description: 'Manage sprints, backlog issues, assignees, and release timelines',
    category: 'Engineering & Operations',
    icon: 'FolderKanban',
    color: '#059669',
    buildDatabase: () => createSimpleTemplate('db_proj', 'Projects & Tasks Tracker', 'Sprint planning & task tracking', [
      { name: 'Projects', fields: ['Project Title', 'Owner', 'Deadline', 'Status'] },
      { name: 'Tasks', fields: ['Task Summary', 'Assignee', 'Priority', 'Estimate (Hours)'] },
    ]),
  },
  {
    id: 'inventory_assets',
    name: 'Inventory & Asset Register',
    description: 'Track stock counts, warehouse locations, SKU prices, and reorder levels',
    category: 'Logistics',
    icon: 'Boxes',
    color: '#d97706',
    buildDatabase: () => createSimpleTemplate('db_inv', 'Inventory & Asset Register', 'Stock counts & warehouses', [
      { name: 'Products', fields: ['SKU Code', 'Product Name', 'Unit Price', 'Stock On Hand'] },
      { name: 'Warehouses', fields: ['Warehouse Name', 'City', 'Capacity'] },
    ]),
  },
  {
    id: 'contacts_network',
    name: 'Personal & Professional Network',
    description: 'Rolodex of contacts, company affiliations, and interaction history',
    category: 'Personal',
    icon: 'Contact',
    color: '#7c3aed',
    buildDatabase: () => createSimpleTemplate('db_contacts', 'Contacts & Network', 'Rolodex & interactions', [
      { name: 'People', fields: ['Name', 'Company', 'Email', 'Phone', 'Tags'] },
      { name: 'Interactions', fields: ['Contact', 'Interaction Date', 'Notes', 'Follow Up Required'] },
    ]),
  },
  {
    id: 'hr_employees',
    name: 'Human Resources & Directory',
    description: 'Employee profiles, department org structures, salaries, and performance reviews',
    category: 'Human Resources',
    icon: 'UserCheck',
    color: '#e11d48',
    buildDatabase: () => createSimpleTemplate('db_hr', 'Human Resources & Directory', 'Employee profiles & reviews', [
      { name: 'Employees', fields: ['Employee Name', 'Department', 'Role Title', 'Work Email', 'Salary'] },
      { name: 'Reviews', fields: ['Employee', 'Review Period', 'Rating', 'Feedback'] },
    ]),
  },
  {
    id: 'suppliers_procurement',
    name: 'Suppliers & Purchase Orders',
    description: 'Vendor management, purchase contracts, itemized line items, and invoices',
    category: 'Finance & Enterprise',
    icon: 'Truck',
    color: '#0d9488',
    buildDatabase: () => createSimpleTemplate('db_suppliers', 'Suppliers & Purchase Orders', 'Vendors & invoices', [
      { name: 'Vendors', fields: ['Vendor Name', 'Tax ID', 'Payment Terms', 'Rating'] },
      { name: 'Purchase Orders', fields: ['PO Number', 'Vendor', 'Order Date', 'Total Amount'] },
    ]),
  },
  {
    id: 'real_estate',
    name: 'Real Estate & Property Manager',
    description: 'Properties, residential units, lease contracts, tenants, and maintenance tickets',
    category: 'Property',
    icon: 'Building',
    color: '#4f46e5',
    buildDatabase: () => createSimpleTemplate('db_property', 'Real Estate & Property Manager', 'Properties & leases', [
      { name: 'Properties', fields: ['Property Address', 'Property Type', 'Valuation', 'Total Units'] },
      { name: 'Tenants', fields: ['Tenant Name', 'Lease Unit', 'Monthly Rent', 'Lease Expiry'] },
    ]),
  },
];

function createSimpleTemplate(dbId: string, name: string, description: string, tablesConfig: { name: string; fields: string[] }[]): Database {
  const now = new Date().toISOString();
  const dbTables: Record<string, any> = {};
  const dbFields: Record<string, any> = {};
  const dbRecords: Record<string, any[]> = {};
  const dbViews: Record<string, any[]> = {};

  tablesConfig.forEach((tc, tIdx) => {
    const tableId = `tbl_${tIdx + 1}`;
    const fieldIds: string[] = [];

    tc.fields.forEach((fName, fIdx) => {
      const fieldId = `f_${tIdx + 1}_${fIdx + 1}`;
      fieldIds.push(fieldId);

      let type = FieldType.TEXT;
      if (fName.toLowerCase().includes('price') || fName.toLowerCase().includes('revenue') || fName.toLowerCase().includes('salary') || fName.toLowerCase().includes('value') || fName.toLowerCase().includes('rent')) {
        type = FieldType.CURRENCY;
      } else if (fName.toLowerCase().includes('email')) {
        type = FieldType.EMAIL;
      } else if (fName.toLowerCase().includes('date')) {
        type = FieldType.DATE;
      } else if (fName.toLowerCase().includes('status') || fName.toLowerCase().includes('stage')) {
        type = FieldType.ENUM;
      }

      dbFields[fieldId] = {
        id: fieldId,
        tableId,
        name: fName,
        type,
        isPrimaryKey: fIdx === 0,
      };
    });

    dbTables[tableId] = {
      id: tableId,
      databaseId: dbId,
      name: tc.name,
      description: `Collection of ${tc.name.toLowerCase()}`,
      fieldIds,
      primaryKeyFieldId: fieldIds[0],
      createdAt: now,
      updatedAt: now,
    };

    // Create 3 sample records
    dbRecords[tableId] = [1, 2, 3].map((idx) => {
      const rId = `rec_${tableId}_${idx}`;
      const values: Record<string, any> = {};
      fieldIds.forEach((fid, fidx) => {
        const field = dbFields[fid];
        if (fidx === 0) values[fid] = `${tc.name.slice(0, -1)} #${idx}`;
        else if (field.type === FieldType.CURRENCY) values[fid] = idx * 1500;
        else if (field.type === FieldType.EMAIL) values[fid] = `user${idx}@example.com`;
        else if (field.type === FieldType.DATE) values[fid] = `2024-0${idx}-15`;
        else values[fid] = `Sample ${field.name} ${idx}`;
      });
      return { id: rId, tableId, values, createdAt: now, updatedAt: now };
    });

    dbViews[tableId] = [
      { id: `v_${tableId}_default`, tableId, name: 'Default Table', type: ViewType.TABLE, isDefault: true },
    ];
  });

  return {
    id: dbId,
    name,
    description,
    createdAt: now,
    updatedAt: now,
    tables: dbTables,
    fields: dbFields,
    records: dbRecords,
    relationships: {},
    views: dbViews,
    forms: {},
    savedQueries: [],
    auditLogs: [
      {
        id: 'evt_init',
        databaseId: dbId,
        eventType: AuditEventType.DATABASE_CREATED,
        entityType: 'DATABASE',
        entityId: dbId,
        summary: `Database "${name}" created from template`,
        user: 'Current User',
        timestamp: now,
      },
    ],
  };
}
