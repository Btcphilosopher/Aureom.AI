/**
 * iBase 2026 Import / Export Center
 * File dropzone for CSV, TSV, XLSX, JSON with column type auto-detection and SQL/CSV exporter.
 */

import React, { useState } from 'react';
import { X, Upload, Download, FileText, CheckCircle2, AlertCircle, FileSpreadsheet, Code2 } from 'lucide-react';
import { Database, Table } from '../types/database';
import { ImportExportEngine, ParseResult } from '../engine/importExportEngine';

interface ImportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentDb: Database | null;
  activeTableId: string | null;
  onImportTable: (parseResult: ParseResult) => void;
}

export const ImportExportModal: React.FC<ImportExportModalProps> = ({
  isOpen,
  onClose,
  currentDb,
  activeTableId,
  onImportTable,
}) => {
  const [mode, setMode] = useState<'import' | 'export'>('import');
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const [exportFormat, setExportFormat] = useState<'csv' | 'json' | 'sql'>('csv');
  const [exportedText, setExportedText] = useState<string>('');

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = file.name;
    const ext = fileName.split('.').pop()?.toLowerCase();

    if (ext === 'xlsx' || ext === 'xls') {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const buffer = evt.target?.result as ArrayBuffer;
        const res = ImportExportEngine.parseXLSX(buffer, fileName);
        setParseResult(res);
      };
      reader.readAsArrayBuffer(file);
    } else {
      const reader = new FileReader();
      reader.onload = (evt) => {
        const content = evt.target?.result as string;
        if (ext === 'json' || ext === 'jsonl') {
          const res = ImportExportEngine.parseJSON(content, fileName);
          setParseResult(res);
        } else {
          const res = ImportExportEngine.parseCSV(content, fileName);
          setParseResult(res);
        }
      };
      reader.readAsText(file);
    }
  };

  const handleConfirmImport = () => {
    if (!parseResult) return;
    onImportTable(parseResult);
    setParseResult(null);
    onClose();
  };

  const handleGenerateExport = () => {
    if (!currentDb || !activeTableId) return;
    const table = currentDb.tables[activeTableId];
    const fields = table.fieldIds.map((id) => currentDb.fields[id]).filter(Boolean);
    const records = currentDb.records[activeTableId] || [];

    if (exportFormat === 'csv') {
      const csv = ImportExportEngine.exportToCSV(table, fields, records);
      setExportedText(csv);
    } else if (exportFormat === 'json') {
      const json = JSON.stringify(records.map((r) => r.values), null, 2);
      setExportedText(json);
    } else if (exportFormat === 'sql') {
      const sql = ImportExportEngine.exportToSQL(table, fields, records);
      setExportedText(sql);
    }
  };

  const downloadExportedFile = () => {
    if (!exportedText || !currentDb || !activeTableId) return;
    const table = currentDb.tables[activeTableId];
    const blob = new Blob([exportedText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${table.name.toLowerCase().replace(/\s+/g, '_')}_export.${exportFormat}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none">
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative flex flex-col max-h-[85vh]">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-zinc-400"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Mode Switcher */}
        <div className="flex space-x-4 border-b border-zinc-200 dark:border-zinc-800 pb-3 mb-5 font-bold text-sm">
          <button
            onClick={() => setMode('import')}
            className={`pb-1 ${mode === 'import' ? 'text-sky-600 border-b-2 border-sky-500' : 'text-zinc-400'}`}
          >
            Import Data (CSV, XLSX, JSON)
          </button>
          <button
            onClick={() => {
              setMode('export');
              handleGenerateExport();
            }}
            className={`pb-1 ${mode === 'export' ? 'text-sky-600 border-b-2 border-sky-500' : 'text-zinc-400'}`}
          >
            Export Table (CSV, JSON, SQL)
          </button>
        </div>

        {mode === 'import' ? (
          <div className="space-y-4 overflow-y-auto flex-1">
            {!parseResult ? (
              <div className="border-2 border-dashed border-zinc-300 dark:border-zinc-700 rounded-2xl p-10 text-center hover:bg-zinc-50 dark:hover:bg-zinc-800/40 transition cursor-pointer relative">
                <input
                  type="file"
                  accept=".csv,.tsv,.xlsx,.xls,.json,.jsonl"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
                <Upload className="w-10 h-10 text-sky-500 mx-auto mb-3" />
                <h3 className="font-bold text-sm mb-1">Drop CSV, Excel, or JSON file here</h3>
                <p className="text-xs text-zinc-400">Automatic column detection and field type inference pipeline</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3 bg-sky-500/10 border border-sky-500/30 rounded-xl text-xs flex justify-between items-center">
                  <div>
                    <span className="font-bold text-sky-700 dark:text-sky-300">
                      Detected Table: "{parseResult.tableName}"
                    </span>
                    <span className="text-zinc-400 block font-mono">
                      {parseResult.columns.length} columns • {parseResult.rows.length} rows parsed
                    </span>
                  </div>
                </div>

                <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl max-h-56 overflow-auto">
                  <table className="w-full text-left border-collapse text-xs font-mono">
                    <thead className="bg-zinc-100 dark:bg-zinc-800">
                      <tr>
                        {parseResult.columns.map((c) => (
                          <th key={c.name} className="p-2 border-r border-zinc-200 dark:border-zinc-700">
                            <div>{c.name}</div>
                            <span className="text-[9px] text-sky-500 font-sans uppercase font-bold">{c.inferredType}</span>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {parseResult.rows.slice(0, 5).map((r, idx) => (
                        <tr key={idx} className="border-b border-zinc-200/50 dark:border-zinc-800/50">
                          {parseResult.columns.map((c) => (
                            <td key={c.name} className="p-2 border-r border-zinc-200/50 dark:border-zinc-800/50 truncate max-w-[150px]">
                              {String(r[c.name] ?? '')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    onClick={() => setParseResult(null)}
                    className="px-4 py-2 text-xs font-semibold text-zinc-500 hover:bg-zinc-100 rounded-lg"
                  >
                    Back
                  </button>
                  <button
                    onClick={handleConfirmImport}
                    className="px-4 py-2 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-lg"
                  >
                    Commit & Import Table
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4 flex-1 flex flex-col">
            <div className="flex space-x-2">
              <button
                onClick={() => setExportFormat('csv')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  exportFormat === 'csv' ? 'bg-sky-500 text-white' : 'bg-zinc-100 dark:bg-zinc-800'
                }`}
              >
                CSV
              </button>
              <button
                onClick={() => setExportFormat('json')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  exportFormat === 'json' ? 'bg-sky-500 text-white' : 'bg-zinc-100 dark:bg-zinc-800'
                }`}
              >
                JSON
              </button>
              <button
                onClick={() => setExportFormat('sql')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold ${
                  exportFormat === 'sql' ? 'bg-sky-500 text-white' : 'bg-zinc-100 dark:bg-zinc-800'
                }`}
              >
                SQL DDL + DML
              </button>
            </div>

            <textarea
              readOnly
              value={exportedText}
              className="w-full flex-1 p-3 bg-zinc-900 text-emerald-400 font-mono text-xs rounded-xl focus:outline-none"
            />

            <div className="flex justify-end pt-2">
              <button
                onClick={downloadExportedFile}
                className="flex items-center space-x-2 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold"
              >
                <Download className="w-4 h-4" />
                <span>Download {exportFormat.toUpperCase()} File</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
