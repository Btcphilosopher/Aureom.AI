/**
 * iBase 2026 Global Command Palette (Cmd+K)
 * Lightning-fast multi-entity database search and quick actions launcher.
 */

import React, { useState, useEffect } from 'react';
import {
  Search,
  Command,
  Plus,
  Table as TableIcon,
  Layers,
  Code2,
  FileSpreadsheet,
  Download,
  Upload,
  Eye,
  ArrowRight,
  Database as DatabaseIcon,
} from 'lucide-react';
import { Database } from '../types/database';
import { SearchEngine, SearchMatch } from '../engine/searchEngine';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  currentDb: Database | null;
  onSelectTable: (tableId: string) => void;
  onSelectRecord: (tableId: string, recordId: string) => void;
  onExecuteAction: (actionType: string) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  currentDb,
  onSelectTable,
  onSelectRecord,
  onExecuteAction,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const searchResults: SearchMatch[] = currentDb ? SearchEngine.search(currentDb, query) : [];

  const quickActions = [
    { id: 'act_new_db', label: 'Create New Database', icon: DatabaseIcon, action: 'new_db' },
    { id: 'act_new_table', label: 'Create New Table', icon: Plus, action: 'new_table' },
    { id: 'act_add_record', label: 'Add New Record', icon: Plus, action: 'add_record' },
    { id: 'act_schema', label: 'Open ERD Schema Designer', icon: Layers, action: 'schema' },
    { id: 'act_sql', label: 'Open SQL Studio Editor', icon: Code2, action: 'sql' },
    { id: 'act_import', label: 'Import CSV / XLSX / JSON Data', icon: Upload, action: 'import' },
    { id: 'act_export', label: 'Export Database to SQL / CSV', icon: Download, action: 'export' },
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-start justify-center pt-20 z-50 p-4 select-none">
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Search Input Header */}
        <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center space-x-3">
          <Search className="w-5 h-5 text-zinc-400" />
          <input
            type="text"
            autoFocus
            placeholder="Type a command or search tables, fields & records..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm text-zinc-900 dark:text-zinc-100 focus:outline-none"
          />
          <kbd className="px-2 py-0.5 text-[10px] font-mono text-zinc-400 bg-zinc-100 dark:bg-zinc-800 rounded border border-zinc-200 dark:border-zinc-700">
            ESC
          </kbd>
        </div>

        {/* Results Stream */}
        <div className="max-h-96 overflow-y-auto p-2 space-y-1 text-xs">
          {query.trim().length >= 2 ? (
            searchResults.length === 0 ? (
              <div className="p-8 text-center text-zinc-400">
                No database records or commands match "{query}"
              </div>
            ) : (
              searchResults.map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    if (m.type === 'TABLE' && m.tableId) onSelectTable(m.tableId);
                    if (m.type === 'RECORD' && m.tableId && m.recordId) onSelectRecord(m.tableId, m.recordId);
                    onClose();
                  }}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-sky-500/10 text-left transition group"
                >
                  <div className="flex items-center space-x-3 truncate">
                    <TableIcon className="w-4 h-4 text-sky-500 shrink-0" />
                    <div className="truncate">
                      <div className="font-bold text-zinc-900 dark:text-zinc-100 group-hover:text-sky-500 truncate">
                        {m.title}
                      </div>
                      <div className="text-[10px] text-zinc-400 truncate">{m.subtitle}</div>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-zinc-400 group-hover:text-sky-500" />
                </button>
              ))
            )
          ) : (
            <div>
              <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                Global Commands
              </div>
              {quickActions.map((qa) => {
                const Icon = qa.icon;
                return (
                  <button
                    key={qa.id}
                    onClick={() => {
                      onExecuteAction(qa.action);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-zinc-100 dark:hover:bg-zinc-800 text-left transition group"
                  >
                    <div className="flex items-center space-x-3 text-zinc-700 dark:text-zinc-300">
                      <Icon className="w-4 h-4 text-sky-500" />
                      <span className="font-semibold">{qa.label}</span>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-zinc-400 group-hover:text-sky-500" />
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
