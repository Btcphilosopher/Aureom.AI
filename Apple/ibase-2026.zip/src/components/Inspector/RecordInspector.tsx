/**
 * iBase 2026 Record Inspector
 * Slide-over inspector panel displaying record fields & automatically expanding related items across relational tables.
 */

import React from 'react';
import {
  X,
  Eye,
  Link,
  Table as TableIcon,
  Save,
  Trash2,
  Calendar,
  Hash,
  DollarSign,
  Type,
  ArrowUpRight,
} from 'lucide-react';
import { Database, Table, RecordData, Field, FieldType } from '../../types/database';
import { RelationalEngine } from '../../engine/relationalEngine';

interface RecordInspectorProps {
  currentDb: Database;
  activeTableId: string;
  recordId: string | null;
  onClose: () => void;
  onUpdateRecord: (tableId: string, recordId: string, fieldId: string, value: any) => void;
  onSelectRecord: (tableId: string, recordId: string) => void;
  relationalEngine: RelationalEngine;
}

export const RecordInspector: React.FC<RecordInspectorProps> = ({
  currentDb,
  activeTableId,
  recordId,
  onClose,
  onUpdateRecord,
  onSelectRecord,
  relationalEngine,
}) => {
  if (!recordId) return null;

  const table = currentDb.tables[activeTableId];
  const record = (currentDb.records[activeTableId] || []).find((r) => r.id === recordId);

  if (!table || !record) return null;

  const fields = table.fieldIds.map((id) => currentDb.fields[id]).filter(Boolean);
  const computedValues = relationalEngine.computeRecordDynamicValues(activeTableId, record);

  // Find all related records in OTHER tables that reference this record via Foreign Key
  const relatedTablesInfo: { targetTable: Table; relatedRecords: RecordData[]; fkField: Field }[] = [];

  for (const otherTable of Object.values(currentDb.tables)) {
    if (otherTable.id === activeTableId) continue;

    const fkField = otherTable.fieldIds
      .map((fid) => currentDb.fields[fid])
      .find((f) => f?.isForeignKey && f.foreignKeyTargetTableId === activeTableId);

    if (fkField) {
      const rels = relationalEngine.getRelatedRecords(activeTableId, record.id, otherTable.id, fkField.id);
      if (rels.length > 0) {
        relatedTablesInfo.push({
          targetTable: otherTable,
          relatedRecords: rels,
          fkField,
        });
      }
    }
  }

  const primaryVal = computedValues[table.primaryKeyFieldId] || record.id;

  return (
    <aside className="w-96 bg-white dark:bg-[#14161d] border-l border-zinc-200 dark:border-zinc-800 h-full flex flex-col justify-between shadow-2xl z-30 select-none animate-in slide-in-from-right duration-200">
      {/* Inspector Header */}
      <div className="p-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50/50 dark:bg-[#181a22]">
        <div className="flex items-center space-x-2 truncate">
          <Eye className="w-4 h-4 text-sky-500 shrink-0" />
          <div className="truncate">
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
              Inspector • {table.name}
            </span>
            <h3 className="font-bold text-sm text-zinc-900 dark:text-zinc-100 truncate">
              {String(primaryVal)}
            </h3>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Fields & Related Items Scroll Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 text-xs">
        {/* Record Fields Section */}
        <div>
          <h4 className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 mb-3">
            Record Properties
          </h4>

          <div className="space-y-3">
            {fields.map((f) => {
              const val = computedValues[f.id] ?? '';
              const isReadOnly = f.type === FieldType.FORMULA || f.type === FieldType.ROLLUP || f.type === FieldType.LOOKUP;

              return (
                <div key={f.id} className="space-y-1">
                  <label className="block text-[11px] font-semibold text-zinc-600 dark:text-zinc-400">
                    {f.name} {f.isPrimaryKey && '(Primary Key)'}
                  </label>

                  {isReadOnly ? (
                    <div className="px-3 py-1.5 bg-zinc-100 dark:bg-zinc-900 rounded-lg text-zinc-500 dark:text-zinc-400 italic font-mono text-xs">
                      {String(val)}
                    </div>
                  ) : (
                    <input
                      type="text"
                      value={String(val)}
                      onChange={(e) => onUpdateRecord(activeTableId, record.id, f.id, e.target.value)}
                      className="w-full px-3 py-1.5 bg-zinc-50 dark:bg-zinc-900/80 border border-zinc-200 dark:border-zinc-700/80 rounded-lg text-xs font-mono text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Automatic Relational Expansion Section */}
        {relatedTablesInfo.length > 0 && (
          <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800">
            <h4 className="text-[10px] font-bold uppercase tracking-wider text-indigo-500 mb-3 flex items-center space-x-1">
              <Link className="w-3 h-3" />
              <span>Linked Relational Items</span>
            </h4>

            <div className="space-y-4">
              {relatedTablesInfo.map((relInfo) => (
                <div
                  key={relInfo.targetTable.id}
                  className="bg-zinc-50 dark:bg-[#191b24] p-3 rounded-xl border border-zinc-200 dark:border-zinc-800"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-xs text-zinc-800 dark:text-zinc-200">
                      {relInfo.targetTable.name} ({relInfo.relatedRecords.length})
                    </span>
                  </div>

                  <div className="space-y-1">
                    {relInfo.relatedRecords.map((rRec) => {
                      const rPrimaryVal = Object.values(rRec.values)[0] || rRec.id;
                      return (
                        <button
                          key={rRec.id}
                          onClick={() => onSelectRecord(relInfo.targetTable.id, rRec.id)}
                          className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-white dark:bg-zinc-800 hover:bg-sky-500/10 text-left transition group border border-zinc-200/60 dark:border-zinc-700/40"
                        >
                          <span className="truncate font-mono text-[11px] text-zinc-700 dark:text-zinc-300 group-hover:text-sky-600 dark:group-hover:text-sky-400">
                            {String(rPrimaryVal)}
                          </span>
                          <ArrowUpRight className="w-3 h-3 text-zinc-400 group-hover:text-sky-500" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-[#12141a] text-[10px] text-zinc-400 font-mono">
        Created: {new Date(record.createdAt).toLocaleDateString()} • ID: {record.id}
      </div>
    </aside>
  );
};
