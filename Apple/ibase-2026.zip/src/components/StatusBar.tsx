/**
 * iBase 2026 Bottom Status Bar
 */

import React from 'react';
import { Database, Table } from '../types/database';
import { Undo2, Redo2, CheckCircle2, ShieldCheck, Cpu } from 'lucide-react';

interface StatusBarProps {
  currentDb: Database | null;
  activeTableId: string | null;
  selectedRecordIds: string[];
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  queryTimeMs?: number;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  currentDb,
  activeTableId,
  selectedRecordIds,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  queryTimeMs = 0.4,
}) => {
  if (!currentDb) return null;

  const currentTable: Table | undefined = activeTableId ? currentDb.tables[activeTableId] : undefined;
  const totalRecords = activeTableId && currentDb.records[activeTableId] ? currentDb.records[activeTableId].length : 0;
  const totalTables = Object.keys(currentDb.tables).length;

  return (
    <footer className="h-7 bg-zinc-100 dark:bg-[#0c0e12] border-t border-zinc-200 dark:border-zinc-800/80 px-4 flex items-center justify-between text-[11px] font-mono text-zinc-500 dark:text-zinc-400 select-none z-10">
      {/* Left side: Record count & selection */}
      <div className="flex items-center space-x-4">
        {currentTable ? (
          <div className="flex items-center space-x-2">
            <span className="font-medium text-zinc-700 dark:text-zinc-300">{currentTable.name}</span>
            <span>•</span>
            <span>
              {totalRecords.toLocaleString()} {totalRecords === 1 ? 'record' : 'records'}
            </span>
            {selectedRecordIds.length > 0 && (
              <span className="bg-sky-500/10 text-sky-600 dark:text-sky-400 px-1.5 py-0.2 rounded font-semibold">
                {selectedRecordIds.length} selected
              </span>
            )}
          </div>
        ) : (
          <span>{totalTables} tables loaded</span>
        )}

        {/* Undo / Redo */}
        <div className="flex items-center space-x-1 pl-2 border-l border-zinc-200 dark:border-zinc-800">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            className={`p-1 rounded transition ${
              canUndo ? 'hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-200' : 'opacity-40 cursor-not-allowed'
            }`}
            title="Undo operation (Cmd+Z)"
          >
            <Undo2 className="w-3 h-3" />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            className={`p-1 rounded transition ${
              canRedo ? 'hover:bg-zinc-200 dark:hover:bg-zinc-800 text-zinc-700 dark:text-zinc-200' : 'opacity-40 cursor-not-allowed'
            }`}
            title="Redo operation (Cmd+Shift+Z)"
          >
            <Redo2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Right side: Engine status, Latency, Local-first */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-1">
          <Cpu className="w-3 h-3 text-sky-500" />
          <span>Query latency: {queryTimeMs}ms</span>
        </div>

        <div className="flex items-center space-x-1 text-emerald-600 dark:text-emerald-400">
          <CheckCircle2 className="w-3 h-3" />
          <span>Local-First Sync</span>
        </div>

        <div className="flex items-center space-x-1">
          <ShieldCheck className="w-3 h-3 text-indigo-500" />
          <span>Referential Integrity Active</span>
        </div>
      </div>
    </footer>
  );
};
