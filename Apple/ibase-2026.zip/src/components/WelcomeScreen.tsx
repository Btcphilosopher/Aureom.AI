/**
 * iBase 2026 Primary Welcome & Database Creation Center
 * "Simple on the surface, powerful underneath."
 */

import React, { useState } from 'react';
import {
  Database as DatabaseIcon,
  Plus,
  Upload,
  Sparkles,
  Star,
  FolderOpen,
  ArrowRight,
  Search,
  Check,
  Building2,
  Landmark,
  Users,
  FolderKanban,
  Boxes,
  Contact,
  UserCheck,
  Truck,
  Building,
  Table as TableIcon,
} from 'lucide-react';
import { Database } from '../types/database';
import { TEMPLATES_LIST, createSheffieldInvestmentDatabase } from '../data/templates';

interface WelcomeScreenProps {
  recentDatabases: Database[];
  onSelectDatabase: (db: Database) => void;
  onCreateBlankDatabase: (name: string) => void;
  onSelectTemplate: (templateId: string) => void;
  onOpenImport: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  recentDatabases,
  onSelectDatabase,
  onCreateBlankDatabase,
  onSelectTemplate,
  onOpenImport,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'recents' | 'templates'>('all');
  const [blankName, setBlankName] = useState('');
  const [showBlankModal, setShowBlankModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const templatesFiltered = TEMPLATES_LIST.filter(
    (t) => t.name.toLowerCase().includes(searchQuery.toLowerCase()) || t.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateBlankSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!blankName.trim()) return;
    onCreateBlankDatabase(blankName.trim());
    setBlankName('');
    setShowBlankModal(false);
  };

  const getTemplateIcon = (iconName: string) => {
    switch (iconName) {
      case 'Landmark': return <Landmark className="w-5 h-5 text-sky-500" />;
      case 'Users': return <Users className="w-5 h-5 text-blue-500" />;
      case 'FolderKanban': return <FolderKanban className="w-5 h-5 text-emerald-500" />;
      case 'Boxes': return <Boxes className="w-5 h-5 text-amber-500" />;
      case 'Contact': return <Contact className="w-5 h-5 text-purple-500" />;
      case 'UserCheck': return <UserCheck className="w-5 h-5 text-rose-500" />;
      case 'Truck': return <Truck className="w-5 h-5 text-teal-500" />;
      case 'Building': return <Building className="w-5 h-5 text-indigo-500" />;
      default: return <DatabaseIcon className="w-5 h-5 text-sky-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f8f9fa] dark:bg-[#0e0f12] text-zinc-900 dark:text-zinc-100 flex flex-col justify-between select-none">
      {/* Top Header Banner */}
      <div className="max-w-6xl w-full mx-auto px-6 pt-10 pb-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500 text-white flex items-center justify-center font-bold text-xl shadow-md">
              iB
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">iBASE 2026</h1>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 font-medium">
                Information, Structured. • Professional Lightweight Database
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={onOpenImport}
              className="flex items-center space-x-2 px-3.5 py-2 bg-white dark:bg-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-700/80 border border-zinc-200 dark:border-zinc-700 rounded-lg text-xs font-semibold text-zinc-700 dark:text-zinc-200 shadow-xs transition"
            >
              <Upload className="w-4 h-4 text-sky-500" />
              <span>Import CSV / Excel</span>
            </button>

            <button
              onClick={() => setShowBlankModal(true)}
              className="flex items-center space-x-2 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold shadow-xs transition active:scale-[0.98]"
            >
              <Plus className="w-4 h-4" />
              <span>New Database</span>
            </button>
          </div>
        </div>

        {/* Master Demo Quick Launcher Banner */}
        <div className="relative overflow-hidden bg-gradient-to-r from-sky-950 via-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-xl border border-sky-500/20 mb-10">
          <div className="relative z-10 max-w-2xl">
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-sky-500/20 border border-sky-400/30 text-sky-300 text-[11px] font-semibold mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Master Engineering Demo</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight mb-2">Sheffield Investment Database</h2>
            <p className="text-xs text-sky-100/80 leading-relaxed mb-5">
              Experience iBase with real relational tables (Companies, Projects, Capital Investments, Audited Transactions, Regional Hubs, Employees), formula rollups, visual schema canvas, and SQL engine.
            </p>
            <button
              onClick={() => onSelectTemplate('sheffield_investment')}
              className="flex items-center space-x-2 px-4 py-2.5 bg-sky-500 hover:bg-sky-400 text-white rounded-lg font-semibold text-xs shadow-md transition active:scale-[0.98]"
            >
              <span>Launch Sheffield Investment Database</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-zinc-200 dark:border-zinc-800 pb-3 mb-6">
          <div className="flex space-x-6 text-sm font-semibold">
            <button
              onClick={() => setActiveTab('all')}
              className={`pb-3 relative transition ${
                activeTab === 'all'
                  ? 'text-sky-600 dark:text-sky-400'
                  : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300'
              }`}
            >
              All Templates ({TEMPLATES_LIST.length})
              {activeTab === 'all' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-sky-500 rounded-full" />}
            </button>

            <button
              onClick={() => setActiveTab('recents')}
              className={`pb-3 relative transition ${
                activeTab === 'recents'
                  ? 'text-sky-600 dark:text-sky-400'
                  : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-300'
              }`}
            >
              Recent Databases ({recentDatabases.length})
              {activeTab === 'recents' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-sky-500 rounded-full" />}
            </button>
          </div>

          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Filter templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-white dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-lg text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-sky-500/50"
            />
          </div>
        </div>

        {/* Recents Section */}
        {activeTab === 'recents' && (
          <div className="mb-10">
            {recentDatabases.length === 0 ? (
              <div className="p-12 text-center border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-xl">
                <FolderOpen className="w-8 h-8 text-zinc-400 mx-auto mb-3" />
                <h3 className="text-sm font-semibold text-zinc-700 dark:text-zinc-300">No recent databases</h3>
                <p className="text-xs text-zinc-400 mt-1">Create a new blank database or select a template below.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {recentDatabases.map((db) => {
                  const tableCount = Object.keys(db.tables).length;
                  const recordCount = Object.values(db.records).reduce((acc, curr) => acc + curr.length, 0);

                  return (
                    <button
                      key={db.id}
                      onClick={() => onSelectDatabase(db)}
                      className="p-4 bg-white dark:bg-[#14161c] hover:bg-zinc-50 dark:hover:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-800 rounded-xl text-left transition shadow-xs group"
                    >
                      <div className="flex items-center space-x-3 mb-2">
                        <div className="p-2 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400">
                          <DatabaseIcon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-sm group-hover:text-sky-600 dark:group-hover:text-sky-400 transition">
                            {db.name}
                          </h3>
                          <p className="text-[11px] text-zinc-400 font-mono">
                            {tableCount} tables • {recordCount.toLocaleString()} records
                          </p>
                        </div>
                      </div>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2">{db.description}</p>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Templates Gallery Grid */}
        {(activeTab === 'all' || activeTab === 'templates') && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
            {templatesFiltered.map((tmpl) => (
              <div
                key={tmpl.id}
                onClick={() => onSelectTemplate(tmpl.id)}
                className="p-5 bg-white dark:bg-[#14161c] hover:bg-sky-500/5 dark:hover:bg-sky-500/10 border border-zinc-200 dark:border-zinc-800/80 hover:border-sky-500/40 dark:hover:border-sky-500/40 rounded-xl cursor-pointer transition shadow-xs group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2 rounded-lg bg-zinc-100 dark:bg-zinc-800 group-hover:bg-white dark:group-hover:bg-zinc-700 transition">
                      {getTemplateIcon(tmpl.icon)}
                    </div>
                    <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded">
                      {tmpl.category}
                    </span>
                  </div>

                  <h3 className="font-semibold text-sm text-zinc-900 dark:text-zinc-100 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition mb-1">
                    {tmpl.name}
                  </h3>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2 leading-relaxed mb-4">
                    {tmpl.description}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs font-semibold text-sky-600 dark:text-sky-400 pt-3 border-t border-zinc-100 dark:border-zinc-800/60">
                  <span>Create Database</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Blank Database Modal */}
      {showBlankModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <h2 className="text-lg font-bold mb-1">Create Blank Database</h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-5">
              Start with a clean slate and build custom relational tables.
            </p>

            <form onSubmit={handleCreateBlankSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                  Database Name
                </label>
                <input
                  type="text"
                  required
                  autoFocus
                  placeholder="e.g. My Custom Database"
                  value={blankName}
                  onChange={(e) => setBlankName(e.target.value)}
                  className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg text-sm text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBlankModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-lg transition"
                >
                  Create Database
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Footer Branding */}
      <footer className="py-6 border-t border-zinc-200 dark:border-zinc-800 text-center text-xs text-zinc-400 font-mono">
        iBase 2026 • Local-First Relational Engine • Designed for Desktop, Web & Tablet
      </footer>
    </div>
  );
};
