/**
 * iBase 2026 Auto Form Builder & Data Entry
 * Dynamically builds entry forms with sections, field validations, and direct table record insertion.
 */

import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Plus,
  CheckCircle2,
  Save,
  Send,
  Calendar,
  Hash,
  DollarSign,
  Type,
  ToggleLeft,
} from 'lucide-react';
import { Database, Table, Field, FieldType } from '../../types/database';

interface FormBuilderProps {
  currentDb: Database;
  activeTableId: string;
  onAddRecordWithValues: (tableId: string, values: Record<string, any>) => void;
}

export const FormBuilder: React.FC<FormBuilderProps> = ({ currentDb, activeTableId, onAddRecordWithValues }) => {
  const table = currentDb.tables[activeTableId];
  const fields = table ? table.fieldIds.map((id) => currentDb.fields[id]).filter((f) => f && f.type !== FieldType.FORMULA && f.type !== FieldType.ROLLUP && f.type !== FieldType.LOOKUP) : [];

  const [formValues, setFormValues] = useState<Record<string, any>>({});
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);

  const handleInputChange = (fieldId: string, value: any) => {
    setFormValues((prev) => ({ ...prev, [fieldId]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!table) return;

    onAddRecordWithValues(activeTableId, formValues);
    setSubmittedMessage(`Successfully added new record into table "${table.name}"!`);
    setFormValues({});
    setTimeout(() => setSubmittedMessage(null), 4000);
  };

  if (!table) return null;

  return (
    <div className="flex-1 bg-white dark:bg-[#121419] flex flex-col overflow-hidden select-none">
      {/* Header */}
      <div className="h-11 px-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50/50 dark:bg-[#15171e]">
        <div className="flex items-center space-x-2 font-bold text-xs text-zinc-800 dark:text-zinc-200">
          <FileSpreadsheet className="w-4 h-4 text-purple-500" />
          <span>Form Builder • {table.name}</span>
        </div>
      </div>

      {/* Form Content Workspace */}
      <div className="flex-1 p-6 overflow-y-auto max-w-2xl mx-auto w-full">
        {submittedMessage && (
          <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 rounded-xl text-xs font-semibold flex items-center space-x-2 animate-in fade-in">
            <CheckCircle2 className="w-5 h-5" />
            <span>{submittedMessage}</span>
          </div>
        )}

        <div className="bg-zinc-50 dark:bg-[#161820] p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-sm">
          <div className="mb-6 border-b border-zinc-200 dark:border-zinc-800 pb-3">
            <h2 className="text-lg font-bold text-zinc-900 dark:text-zinc-100">{table.name} Entry Form</h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Complete the fields below to create a validated record.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {fields.map((f) => (
              <div key={f.id} className="space-y-1">
                <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                  {f.name} {f.options?.required && <span className="text-rose-500">*</span>}
                </label>

                {f.type === FieldType.ENUM && f.options?.enumChoices ? (
                  <select
                    value={formValues[f.id] || ''}
                    onChange={(e) => handleInputChange(f.id, e.target.value)}
                    required={f.options?.required}
                    className="w-full px-3 py-2 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg text-xs"
                  >
                    <option value="">Select option...</option>
                    {f.options.enumChoices.map((choice) => (
                      <option key={choice} value={choice}>
                        {choice}
                      </option>
                    ))}
                  </select>
                ) : f.type === FieldType.BOOLEAN ? (
                  <label className="flex items-center space-x-2 cursor-pointer pt-1">
                    <input
                      type="checkbox"
                      checked={Boolean(formValues[f.id])}
                      onChange={(e) => handleInputChange(f.id, e.target.checked)}
                      className="rounded text-sky-600 focus:ring-sky-500"
                    />
                    <span className="text-xs font-medium text-zinc-600 dark:text-zinc-400">Active / Yes</span>
                  </label>
                ) : f.type === FieldType.DATE ? (
                  <input
                    type="date"
                    value={formValues[f.id] || ''}
                    onChange={(e) => handleInputChange(f.id, e.target.value)}
                    required={f.options?.required}
                    className="w-full px-3 py-2 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg text-xs"
                  />
                ) : (
                  <input
                    type="text"
                    value={formValues[f.id] || ''}
                    onChange={(e) => handleInputChange(f.id, e.target.value)}
                    placeholder={`Enter ${f.name}...`}
                    required={f.options?.required}
                    className="w-full px-3 py-2 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                )}
              </div>
            ))}

            <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 flex justify-end">
              <button
                type="submit"
                className="flex items-center space-x-2 px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-semibold text-xs shadow-md transition active:scale-[0.98]"
              >
                <Send className="w-4 h-4" />
                <span>Submit Record</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
