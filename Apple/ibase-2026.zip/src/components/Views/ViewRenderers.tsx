/**
 * iBase 2026 Alternative Views (Kanban, Card Grid, Calendar, Map)
 */

import React from 'react';
import { Kanban, LayoutGrid, Calendar, MapPin, Eye, Plus, ChevronRight } from 'lucide-react';
import { Database, Table, View, ViewType, RecordData } from '../../types/database';
import { RelationalEngine } from '../../engine/relationalEngine';

interface ViewRendererProps {
  currentDb: Database;
  activeTableId: string;
  view: View;
  onSelectRecord: (recordId: string) => void;
  relationalEngine: RelationalEngine;
  onUpdateRecord: (tableId: string, recordId: string, fieldId: string, value: any) => void;
}

export const ViewRenderer: React.FC<ViewRendererProps> = ({
  currentDb,
  activeTableId,
  view,
  onSelectRecord,
  relationalEngine,
  onUpdateRecord,
}) => {
  const table = currentDb.tables[activeTableId];
  const records = currentDb.records[activeTableId] || [];
  const fields = table ? table.fieldIds.map((id) => currentDb.fields[id]).filter(Boolean) : [];

  if (!table) return null;

  // 1. KANBAN BOARD VIEW
  if (view.type === ViewType.KANBAN) {
    const statusField = fields.find((f) => f.id === view.kanbanStatusFieldId || f.name.toLowerCase().includes('status') || f.name.toLowerCase().includes('stage')) || fields.find((f) => f.type === 'ENUM');

    const columns: string[] = statusField?.options?.enumChoices || ['Backlog', 'In Progress', 'Done', 'Review'];

    return (
      <div className="flex-1 p-4 bg-zinc-100 dark:bg-[#111317] overflow-x-auto flex space-x-4 select-none">
        {columns.map((colName) => {
          const columnRecords = records.filter((r) => {
            const val = r.values[statusField?.id || ''];
            return String(val).toLowerCase() === colName.toLowerCase();
          });

          return (
            <div
              key={colName}
              className="w-72 shrink-0 bg-white/80 dark:bg-[#161820] rounded-xl border border-zinc-200 dark:border-zinc-800 p-3 flex flex-col max-h-full"
            >
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-200 dark:border-zinc-800 font-semibold text-xs text-zinc-700 dark:text-zinc-300">
                <span>{colName}</span>
                <span className="bg-zinc-200 dark:bg-zinc-800 text-zinc-500 px-2 py-0.5 rounded-full text-[10px] font-mono">
                  {columnRecords.length}
                </span>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2">
                {columnRecords.map((rec) => {
                  const computedValues = relationalEngine.computeRecordDynamicValues(activeTableId, rec);
                  const primaryVal = computedValues[table.primaryKeyFieldId] || rec.id;

                  return (
                    <div
                      key={rec.id}
                      onClick={() => onSelectRecord(rec.id)}
                      className="p-3 bg-white dark:bg-zinc-900 rounded-lg border border-zinc-200 dark:border-zinc-800 hover:border-sky-500/50 cursor-pointer shadow-xs transition group"
                    >
                      <h4 className="font-bold text-xs text-zinc-900 dark:text-zinc-100 group-hover:text-sky-500 mb-1">
                        {String(primaryVal)}
                      </h4>
                      <p className="text-[10px] text-zinc-400 font-mono">ID: {rec.id}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  // 2. CARD GRID / GALLERY VIEW
  if (view.type === ViewType.CARD || view.type === ViewType.GALLERY) {
    return (
      <div className="flex-1 p-6 bg-zinc-100 dark:bg-[#111317] overflow-y-auto select-none">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {records.map((rec) => {
            const computedValues = relationalEngine.computeRecordDynamicValues(activeTableId, rec);
            const primaryVal = computedValues[table.primaryKeyFieldId] || rec.id;

            return (
              <div
                key={rec.id}
                onClick={() => onSelectRecord(rec.id)}
                className="p-4 bg-white dark:bg-[#161820] rounded-xl border border-zinc-200 dark:border-zinc-800 hover:border-sky-500/50 cursor-pointer shadow-xs transition group space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-zinc-900 dark:text-zinc-100 group-hover:text-sky-500 truncate">
                    {String(primaryVal)}
                  </h4>
                  <Eye className="w-4 h-4 text-zinc-400 group-hover:text-sky-500" />
                </div>

                <div className="space-y-1 text-xs">
                  {fields.slice(1, 4).map((f) => (
                    <div key={f.id} className="flex justify-between text-[11px]">
                      <span className="text-zinc-400">{f.name}:</span>
                      <span className="font-mono text-zinc-700 dark:text-zinc-300 font-medium truncate max-w-[120px]">
                        {String(computedValues[f.id] ?? '-')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // Fallback / Calendar / Map view
  return (
    <div className="flex-1 p-8 text-center text-zinc-400 flex flex-col items-center justify-center">
      <Calendar className="w-12 h-12 mb-3 text-sky-500 opacity-80" />
      <h3 className="text-base font-bold text-zinc-700 dark:text-zinc-300">View Active: {view.name}</h3>
      <p className="text-xs text-zinc-400 mt-1">Rendering {records.length} records dynamically.</p>
    </div>
  );
};
