/**
 * iBase 2026 Visual Database Schema Designer (ERD Canvas)
 * Interactive canvas displaying tables, fields, PKs, FKs, and vector SVG relationship connectors (1:1, 1:N, N:M).
 */

import React, { useState, useRef } from 'react';
import {
  Layers,
  Plus,
  Trash2,
  Key,
  Link,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Move,
  Grid,
  Sparkles,
  ArrowRight,
  Database,
  Hash,
  Type,
  Calendar,
  DollarSign,
} from 'lucide-react';
import { Database as DatabaseType, Table, Field, Relationship, RelationshipType } from '../../types/database';

interface SchemaCanvasProps {
  currentDb: DatabaseType;
  onCreateTable: () => void;
  onDeleteTable: (tableId: string) => void;
  onAddRelationship: (sourceTableId: string, targetTableId: string, type: RelationshipType) => void;
  onSelectTable: (tableId: string) => void;
}

interface NodePosition {
  x: number;
  y: number;
}

export const SchemaCanvas: React.FC<SchemaCanvasProps> = ({
  currentDb,
  onCreateTable,
  onDeleteTable,
  onAddRelationship,
  onSelectTable,
}) => {
  // Pre-calculate positions for tables in a grid layout
  const initialPositions = useRef<Record<string, NodePosition>>({});

  const tables = Object.values(currentDb.tables);

  // Initialize positions if not present
  tables.forEach((t, i) => {
    if (!initialPositions.current[t.id]) {
      const col = i % 3;
      const row = Math.floor(i / 3);
      initialPositions.current[t.id] = {
        x: 80 + col * 320,
        y: 80 + row * 260,
      };
    }
  });

  const [positions, setPositions] = useState<Record<string, NodePosition>>(initialPositions.current);
  const [draggingTableId, setDraggingTableId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);

  // Relational link creation state
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [sourceTableId, setSourceTableId] = useState<string>(tables[0]?.id || '');
  const [targetTableId, setTargetTableId] = useState<string>(tables[1]?.id || '');
  const [relType, setRelType] = useState<RelationshipType>(RelationshipType.ONE_TO_MANY);

  // Mouse Drag handlers
  const handleMouseDown = (tableId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDraggingTableId(tableId);
    const pos = positions[tableId] || { x: 0, y: 0 };
    setDragOffset({
      x: e.clientX - pos.x,
      y: e.clientY - pos.y,
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggingTableId) return;
    const newX = Math.max(20, e.clientX - dragOffset.x);
    const newY = Math.max(20, e.clientY - dragOffset.y);
    setPositions((prev) => ({
      ...prev,
      [draggingTableId]: { x: newX, y: newY },
    }));
  };

  const handleMouseUp = () => {
    setDraggingTableId(null);
  };

  const handleConnectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (sourceTableId && targetTableId && sourceTableId !== targetTableId) {
      onAddRelationship(sourceTableId, targetTableId, relType);
      setShowConnectModal(false);
    }
  };

  const relationships = Object.values(currentDb.relationships || {});

  return (
    <div
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      className="flex-1 bg-[#f1f3f5] dark:bg-[#0b0c0f] relative overflow-hidden select-none flex flex-col"
    >
      {/* Canvas Top Controls */}
      <div className="h-11 px-4 border-b border-zinc-200 dark:border-zinc-800 bg-white/80 dark:bg-[#14161c]/80 backdrop-blur-xs flex items-center justify-between z-20">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 text-xs font-bold text-zinc-800 dark:text-zinc-200">
            <Layers className="w-4 h-4 text-sky-500" />
            <span>Visual ERD Designer</span>
          </div>

          <div className="h-4 w-px bg-zinc-200 dark:border-zinc-800" />

          <button
            onClick={onCreateTable}
            className="flex items-center space-x-1 px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded-md text-xs font-semibold shadow-xs transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Table</span>
          </button>

          <button
            onClick={() => setShowConnectModal(true)}
            className="flex items-center space-x-1 px-2.5 py-1 bg-white dark:bg-zinc-800 hover:bg-zinc-100 text-zinc-700 dark:text-zinc-300 rounded-md text-xs font-semibold border border-zinc-200 dark:border-zinc-700 shadow-xs transition"
          >
            <Link className="w-3.5 h-3.5 text-indigo-500" />
            <span>Connect Relationship</span>
          </button>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center space-x-2 text-xs text-zinc-500 font-mono">
          <button
            onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}
            className="p-1 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span>{Math.round(zoom * 100)}%</span>
          <button
            onClick={() => setZoom(Math.min(1.8, zoom + 0.1))}
            className="p-1 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div
        className="flex-1 relative overflow-auto"
        style={{
          backgroundImage: 'radial-gradient(circle, rgba(140, 140, 140, 0.15) 1px, transparent 1px)',
          backgroundSize: '24px 24px',
          transform: `scale(${zoom})`,
          transformOrigin: 'top left',
        }}
      >
        {/* SVG Connector Lines for Relationships */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
          <defs>
            <marker id="arrow" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#6366f1" />
            </marker>
          </defs>

          {/* Render lines for foreign keys or relationships */}
          {relationships.map((rel) => {
            const srcPos = positions[rel.sourceTableId] || { x: 100, y: 100 };
            const tgtPos = positions[rel.targetTableId] || { x: 400, y: 100 };

            const x1 = srcPos.x + 240;
            const y1 = srcPos.y + 60;
            const x2 = tgtPos.x;
            const y2 = tgtPos.y + 60;

            const midX = (x1 + x2) / 2;

            return (
              <g key={rel.id}>
                <path
                  d={`M ${x1} ${y1} C ${midX} ${y1}, ${midX} ${y2}, ${x2} ${y2}`}
                  fill="none"
                  stroke="#6366f1"
                  strokeWidth="2.5"
                  strokeDasharray={rel.type === RelationshipType.MANY_TO_MANY ? '5,5' : 'none'}
                  markerEnd="url(#arrow)"
                />
                <rect x={midX - 18} y={(y1 + y2) / 2 - 10} width="36" height="20" rx="4" fill="#6366f1" />
                <text
                  x={midX}
                  y={(y1 + y2) / 2 + 4}
                  fill="#ffffff"
                  fontSize="10"
                  fontWeight="bold"
                  textAnchor="middle"
                >
                  {rel.type === RelationshipType.ONE_TO_MANY ? '1:N' : rel.type === RelationshipType.MANY_TO_MANY ? 'N:M' : '1:1'}
                </text>
              </g>
            );
          })}
        </svg>

        {/* Table Nodes */}
        {tables.map((table) => {
          const pos = positions[table.id] || { x: 100, y: 100 };
          const tableFields = table.fieldIds.map((id) => currentDb.fields[id]).filter(Boolean);

          return (
            <div
              key={table.id}
              style={{ left: pos.x, top: pos.y }}
              onMouseDown={(e) => handleMouseDown(table.id, e)}
              className="absolute w-64 bg-white dark:bg-[#16181f] border border-zinc-300 dark:border-zinc-700/80 rounded-xl shadow-lg z-10 cursor-grab active:cursor-grabbing hover:shadow-xl transition-shadow"
            >
              {/* Card Header */}
              <div
                className="px-3 py-2.5 rounded-t-xl border-b border-zinc-200 dark:border-zinc-700/80 flex items-center justify-between"
                style={{ backgroundColor: (table.color || '#0284c7') + '15' }}
              >
                <div className="flex items-center space-x-2 truncate">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: table.color || '#0284c7' }}
                  />
                  <h4 className="font-bold text-xs text-zinc-900 dark:text-zinc-100 truncate">
                    {table.name}
                  </h4>
                </div>
                <div className="flex items-center space-x-1">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectTable(table.id);
                    }}
                    className="p-1 hover:bg-zinc-200 dark:hover:bg-zinc-700 rounded text-zinc-400 hover:text-sky-500"
                    title="Open Table Grid"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteTable(table.id);
                    }}
                    className="p-1 hover:bg-zinc-200 dark:hover:bg-zinc-700 rounded text-zinc-400 hover:text-rose-500"
                    title="Delete Table"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Fields List */}
              <div className="p-2 space-y-1 text-xs font-mono">
                {tableFields.map((f) => (
                  <div
                    key={f.id}
                    className="flex items-center justify-between px-2 py-1 rounded bg-zinc-50 dark:bg-zinc-900/60 text-zinc-700 dark:text-zinc-300 text-[11px]"
                  >
                    <div className="flex items-center space-x-1.5 truncate">
                      {f.isPrimaryKey && <Key className="w-3 h-3 text-amber-500 shrink-0" />}
                      {f.isForeignKey && <Link className="w-3 h-3 text-indigo-500 shrink-0" />}
                      <span className="truncate">{f.name}</span>
                    </div>
                    <span className="text-[9px] text-zinc-400 uppercase font-sans">{f.type}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Connect Relationship Modal */}
      {showConnectModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <h3 className="text-base font-bold mb-1">Create Relational Constraint</h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-4">
              Connect primary & foreign key constraints between tables.
            </p>

            <form onSubmit={handleConnectSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Source Table (Parent / Primary Key)</label>
                <select
                  value={sourceTableId}
                  onChange={(e) => setSourceTableId(e.target.value)}
                  className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg"
                >
                  {tables.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Target Table (Child / Foreign Key)</label>
                <select
                  value={targetTableId}
                  onChange={(e) => setTargetTableId(e.target.value)}
                  className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg"
                >
                  {tables.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Cardinality Type</label>
                <select
                  value={relType}
                  onChange={(e) => setRelType(e.target.value as RelationshipType)}
                  className="w-full px-3 py-2 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg"
                >
                  <option value={RelationshipType.ONE_TO_MANY}>ONE_TO_MANY (1 : N)</option>
                  <option value={RelationshipType.ONE_TO_ONE}>ONE_TO_ONE (1 : 1)</option>
                  <option value={RelationshipType.MANY_TO_MANY}>MANY_TO_MANY (N : M)</option>
                </select>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowConnectModal(false)}
                  className="px-4 py-2 font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg"
                >
                  Establish Link
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
