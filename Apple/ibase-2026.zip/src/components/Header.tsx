/**
 * iBase 2026 Header Toolbar
 * Top bar with Database selector, search, command palette trigger, view tabs, and system status badges.
 */

import React from 'react';
import {
  Database as DatabaseIcon,
  Search,
  Command,
  Plus,
  Moon,
  Sun,
  Download,
  Upload,
  Layers,
  Code2,
  FileSpreadsheet,
  History,
  Grid,
  Share2,
  Table as TableIcon,
  Sparkles,
} from 'lucide-react';
import { Database, Table } from '../types/database';

interface HeaderProps {
  currentDb: Database | null;
  activeTableId: string | null;
  activeTab: 'data' | 'schema' | 'query' | 'sql' | 'forms' | 'audit';
  setActiveTab: (tab: 'data' | 'schema' | 'query' | 'sql' | 'forms' | 'audit') => void;
  onOpenCommandPalette: () => void;
  onOpenImportExport: () => void;
  onOpenAuditLog: () => void;
  onSelectDatabaseClick: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onNewRecordClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentDb,
  activeTableId,
  activeTab,
  setActiveTab,
  onOpenCommandPalette,
  onOpenImportExport,
  onOpenAuditLog,
  onSelectDatabaseClick,
  isDarkMode,
  onToggleDarkMode,
  onNewRecordClick,
}) => {
  const currentTable: Table | undefined = currentDb && activeTableId ? currentDb.tables[activeTableId] : undefined;

  return (
    <header className="h-13 bg-white dark:bg-[#14161b] border-b border-zinc-200 dark:border-zinc-800/80 px-4 flex items-center justify-between select-none z-20 transition-colors duration-150">
      {/* Left: App Brand & Database Switcher */}
      <div className="flex items-center space-x-3">
        <button
          onClick={onSelectDatabaseClick}
          className="flex items-center space-x-2 px-2.5 py-1.5 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800/60 transition text-left group"
          title="Switch Database or return Home"
        >
          <div className="w-7 h-7 rounded-md bg-sky-500/10 dark:bg-sky-400/15 text-sky-600 dark:text-sky-400 flex items-center justify-center font-bold text-sm tracking-tight border border-sky-500/20">
            iB
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-semibold text-sm tracking-tight text-zinc-900 dark:text-zinc-100 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition">
                {currentDb ? currentDb.name : 'iBase 2026'}
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-500 dark:text-zinc-400">
                PRO
              </span>
            </div>
          </div>
        </button>

        <div className="h-4 w-px bg-zinc-200 dark:bg-zinc-800" />

        {/* View Mode Tabs */}
        {currentDb && (
          <nav className="flex items-center space-x-1 text-xs font-medium text-zinc-600 dark:text-zinc-400">
            <button
              onClick={() => setActiveTab('data')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition ${
                activeTab === 'data'
                  ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                  : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/40'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>Data Grid</span>
            </button>

            <button
              onClick={() => setActiveTab('schema')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition ${
                activeTab === 'schema'
                  ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                  : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/40'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-sky-500" />
              <span>Schema Designer</span>
            </button>

            <button
              onClick={() => setActiveTab('query')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition ${
                activeTab === 'query'
                  ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                  : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/40'
              }`}
            >
              <Grid className="w-3.5 h-3.5 text-emerald-500" />
              <span>Visual Query</span>
            </button>

            <button
              onClick={() => setActiveTab('sql')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition ${
                activeTab === 'sql'
                  ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                  : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/40'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 text-amber-500" />
              <span>SQL Studio</span>
            </button>

            <button
              onClick={() => setActiveTab('forms')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition ${
                activeTab === 'forms'
                  ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold shadow-xs'
                  : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/40'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-purple-500" />
              <span>Form Builder</span>
            </button>
          </nav>
        )}
      </div>

      {/* Right Controls */}
      <div className="flex items-center space-x-2">
        {/* Quick Add Record Button */}
        {currentDb && currentTable && activeTab === 'data' && (
          <button
            onClick={onNewRecordClick}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-md font-medium text-xs shadow-xs transition active:scale-[0.98]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Record</span>
          </button>
        )}

        {/* Global Search / Command Palette Trigger */}
        <button
          onClick={onOpenCommandPalette}
          className="flex items-center space-x-2 px-3 py-1.5 bg-zinc-100 dark:bg-zinc-800/80 hover:bg-zinc-200 dark:hover:bg-zinc-700/80 text-zinc-600 dark:text-zinc-300 rounded-md text-xs border border-zinc-200 dark:border-zinc-700/60 transition"
          title="Search or execute command (Cmd+K)"
        >
          <Search className="w-3.5 h-3.5 text-zinc-400" />
          <span className="hidden sm:inline">Search database...</span>
          <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-mono font-medium text-zinc-400 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded shadow-xs">
            <Command className="w-2.5 h-2.5" />K
          </kbd>
        </button>

        {/* Import/Export */}
        {currentDb && (
          <button
            onClick={onOpenImportExport}
            className="p-1.5 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-md transition"
            title="Import or Export Data (CSV, XLSX, SQL, JSON)"
          >
            <Download className="w-4 h-4" />
          </button>
        )}

        {/* Audit Log */}
        {currentDb && (
          <button
            onClick={onOpenAuditLog}
            className="p-1.5 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-md transition"
            title="View Audit Log & Operations Stream"
          >
            <History className="w-4 h-4" />
          </button>
        )}

        {/* Theme Toggle */}
        <button
          onClick={onToggleDarkMode}
          className="p-1.5 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-md transition"
          title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-zinc-600" />}
        </button>
      </div>
    </header>
  );
};
