/**
 * iBase 2026 Advanced SQL Editor Studio
 * Execute typed SQL queries (SELECT, JOIN, WHERE, GROUP BY, ORDER BY, INSERT, UPDATE, DELETE) against local database.
 */

import React, { useState } from 'react';
import {
  Code2,
  Play,
  History,
  CheckCircle2,
  AlertCircle,
  Database as DatabaseIcon,
  ShieldAlert,
  Save,
} from 'lucide-react';
import { Database } from '../../types/database';
import { SQLEngine, SQLQueryResult } from '../../engine/sqlEngine';

interface SQLEditorProps {
  currentDb: Database;
  onUpdateDatabase: (updatedDb: Database, auditEvent?: any) => void;
}

export const SQLEditor: React.FC<SQLEditorProps> = ({ currentDb, onUpdateDatabase }) => {
  const [sqlText, setSqlText] = useState<string>(
    `-- iBase 2026 Typed SQL Studio\nSELECT * FROM Companies WHERE Valuation > 10000000 ORDER BY Valuation DESC LIMIT 20;`
  );

  const [queryResult, setQueryResult] = useState<SQLQueryResult | null>(null);
  const [history, setHistory] = useState<string[]>([
    "SELECT * FROM Companies WHERE Valuation > 10000000 ORDER BY Valuation DESC LIMIT 20;",
    "SELECT * FROM Projects WHERE ROI > 20 ORDER BY ROI DESC;",
  ]);

  const handleRunSQL = () => {
    if (!sqlText.trim()) return;
    const engine = new SQLEngine(currentDb);
    const result = engine.executeQuery(sqlText, (updatedDb, auditEvent) => {
      onUpdateDatabase(updatedDb, auditEvent);
    });

    setQueryResult(result);
    if (!history.includes(sqlText.trim())) {
      setHistory((prev) => [sqlText.trim(), ...prev.slice(0, 19)]);
    }
  };

  const isWriteQuery = /^(INSERT|UPDATE|DELETE|DROP|ALTER)/i.test(sqlText.trim());

  return (
    <div className="flex-1 bg-white dark:bg-[#111318] flex flex-col overflow-hidden select-none">
      {/* Top SQL Toolbar */}
      <div className="h-11 px-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50/50 dark:bg-[#15171e]">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2 font-bold text-xs text-zinc-800 dark:text-zinc-200">
            <Code2 className="w-4 h-4 text-amber-500" />
            <span>SQL Studio Editor</span>
          </div>

          <div className="h-4 w-px bg-zinc-200 dark:border-zinc-800" />

          {/* Read vs Write Badge */}
          {isWriteQuery ? (
            <span className="flex items-center space-x-1 px-2 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 font-mono text-[10px] font-bold border border-amber-500/20">
              <ShieldAlert className="w-3 h-3" />
              <span>WRITE TRANSACTION</span>
            </span>
          ) : (
            <span className="flex items-center space-x-1 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/20">
              <CheckCircle2 className="w-3 h-3" />
              <span>READ ONLY</span>
            </span>
          )}
        </div>

        <button
          onClick={handleRunSQL}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs rounded-lg shadow-xs transition active:scale-[0.98]"
        >
          <Play className="w-3.5 h-3.5" />
          <span>Execute SQL</span>
        </button>
      </div>

      {/* Main Workspace Split: Left Editor + History, Right Output */}
      <div className="flex-1 flex overflow-hidden">
        {/* Editor & History Column */}
        <div className="w-1/2 border-r border-zinc-200 dark:border-zinc-800 flex flex-col">
          {/* SQL Input Area */}
          <div className="flex-1 p-3 flex flex-col">
            <label className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 mb-1">
              SQL Statement
            </label>
            <textarea
              value={sqlText}
              onChange={(e) => setSqlText(e.target.value)}
              className="w-full flex-1 p-3 bg-zinc-900 text-amber-300 font-mono text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/50 resize-none leading-relaxed"
              spellCheck={false}
            />
          </div>

          {/* History Pane */}
          <div className="h-44 p-3 border-t border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-[#14161d] overflow-y-auto">
            <h4 className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 mb-2 flex items-center space-x-1">
              <History className="w-3 h-3" />
              <span>Query History</span>
            </h4>
            <div className="space-y-1">
              {history.map((h, idx) => (
                <button
                  key={idx}
                  onClick={() => setSqlText(h)}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg bg-white dark:bg-zinc-800/80 hover:bg-amber-500/10 font-mono text-[11px] text-zinc-700 dark:text-zinc-300 truncate transition border border-zinc-200/60 dark:border-zinc-700/40"
                >
                  {h}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Output Results Column */}
        <div className="w-1/2 p-4 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between mb-3 text-xs font-mono">
            <span className="font-semibold text-zinc-700 dark:text-zinc-300">Execution Output</span>
            {queryResult && (
              <span className="text-emerald-500 font-semibold">
                {queryResult.executionTimeMs}ms • {queryResult.affectedRows} rows
              </span>
            )}
          </div>

          {queryResult?.error ? (
            <div className="p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-600 dark:text-rose-400 text-xs font-mono space-y-1">
              <div className="flex items-center space-x-1.5 font-bold">
                <AlertCircle className="w-4 h-4" />
                <span>SQL Execution Error</span>
              </div>
              <p>{queryResult.error}</p>
            </div>
          ) : queryResult ? (
            <div className="flex-1 border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-auto">
              <table className="w-full text-left border-collapse font-mono text-xs">
                <thead className="bg-zinc-100 dark:bg-zinc-800 border-b border-zinc-200 dark:border-zinc-700 sticky top-0">
                  <tr>
                    {queryResult.columns.map((col) => (
                      <th key={col} className="px-3 py-2 border-r border-zinc-200 dark:border-zinc-700 font-semibold">
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {queryResult.rows.map((row, rIdx) => (
                    <tr key={rIdx} className="border-b border-zinc-200/60 dark:border-zinc-800/60 hover:bg-zinc-50 dark:hover:bg-zinc-800/40">
                      {queryResult.columns.map((col) => (
                        <td key={col} className="px-3 py-1.5 border-r border-zinc-200/60 dark:border-zinc-800/60 truncate max-w-[200px]">
                          {String(row[col] ?? '')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-zinc-400 border border-dashed border-zinc-200 dark:border-zinc-800 rounded-xl text-xs">
              <Code2 className="w-8 h-8 mb-2 opacity-50 text-amber-500" />
              <span>Click "Execute SQL" to run query</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
