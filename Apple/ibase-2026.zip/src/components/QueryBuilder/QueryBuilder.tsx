/**
 * iBase 2026 Visual Query Builder
 * Generates typed AST query representations and executes filter/join pipelines safely.
 */

import React, { useState } from 'react';
import {
  Grid,
  Plus,
  Trash2,
  Play,
  Code2,
  Layers,
  CheckCircle2,
  Table as TableIcon,
} from 'lucide-react';
import { Database, Table, Field, FilterRule } from '../../types/database';
import { SQLEngine, SQLQueryResult } from '../../engine/sqlEngine';

interface QueryBuilderProps {
  currentDb: Database;
  activeTableId: string;
}

export const QueryBuilder: React.FC<QueryBuilderProps> = ({ currentDb, activeTableId }) => {
  const table = currentDb.tables[activeTableId];
  const fields = table ? table.fieldIds.map((id) => currentDb.fields[id]).filter(Boolean) : [];

  const [rules, setRules] = useState<FilterRule[]>([
    {
      id: 'rule_1',
      fieldId: fields[0]?.id || '',
      operator: 'greater_than',
      value: '100000',
    },
  ]);

  const [conjunction, setConjunction] = useState<'AND' | 'OR'>('AND');
  const [queryResult, setQueryResult] = useState<SQLQueryResult | null>(null);

  const addRule = () => {
    setRules((prev) => [
      ...prev,
      {
        id: 'rule_' + Date.now(),
        fieldId: fields[0]?.id || '',
        operator: 'equals',
        value: '',
      },
    ]);
  };

  const removeRule = (id: string) => {
    setRules((prev) => prev.filter((r) => r.id !== id));
  };

  const updateRule = (id: string, updates: Partial<FilterRule>) => {
    setRules((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
  };

  const handleRunQuery = () => {
    if (!table) return;

    // Build equivalent safe SQL statement
    const whereParts = rules
      .map((r) => {
        const field = fields.find((f) => f.id === r.fieldId);
        if (!field) return null;

        const val = typeof r.value === 'number' ? r.value : `'${r.value}'`;
        let op = '=';
        if (r.operator === 'greater_than') op = '>';
        if (r.operator === 'less_than') op = '<';
        if (r.operator === 'not_equals') op = '!=';
        if (r.operator === 'contains') op = 'LIKE';

        if (op === 'LIKE') return `"${field.name}" LIKE '%${r.value}%'`;
        return `"${field.name}" ${op} ${val}`;
      })
      .filter(Boolean);

    const whereClause = whereParts.length > 0 ? `WHERE ${whereParts.join(` ${conjunction} `)}` : '';
    const sqlText = `SELECT * FROM "${table.name}" ${whereClause} LIMIT 100`;

    const engine = new SQLEngine(currentDb);
    const res = engine.executeQuery(sqlText);
    setQueryResult(res);
  };

  if (!table) return null;

  return (
    <div className="flex-1 bg-white dark:bg-[#121419] flex flex-col overflow-hidden select-none">
      {/* Builder Header */}
      <div className="h-11 px-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50/50 dark:bg-[#15171e]">
        <div className="flex items-center space-x-2 font-bold text-xs text-zinc-800 dark:text-zinc-200">
          <Grid className="w-4 h-4 text-emerald-500" />
          <span>Visual Query Builder</span>
          <span className="text-zinc-400 font-normal">• Table: "{table.name}"</span>
        </div>

        <button
          onClick={handleRunQuery}
          className="flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-lg shadow-xs transition"
        >
          <Play className="w-3.5 h-3.5" />
          <span>Execute Query</span>
        </button>
      </div>

      {/* Rules Builder Workspace */}
      <div className="p-6 space-y-6 overflow-y-auto max-w-4xl">
        <div className="bg-zinc-50 dark:bg-[#161820] p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-xs font-semibold">
              <span>Match</span>
              <select
                value={conjunction}
                onChange={(e) => setConjunction(e.target.value as 'AND' | 'OR')}
                className="px-2 py-1 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-md"
              >
                <option value="AND">ALL (AND)</option>
                <option value="OR">ANY (OR)</option>
              </select>
              <span>of the following conditions:</span>
            </div>

            <button
              onClick={addRule}
              className="flex items-center space-x-1 px-2.5 py-1 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-md text-xs font-medium"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Condition</span>
            </button>
          </div>

          <div className="space-y-2">
            {rules.map((rule) => (
              <div key={rule.id} className="flex items-center space-x-3 text-xs">
                {/* Field Select */}
                <select
                  value={rule.fieldId}
                  onChange={(e) => updateRule(rule.id, { fieldId: e.target.value })}
                  className="px-3 py-1.5 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg flex-1"
                >
                  {fields.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.name} ({f.type})
                    </option>
                  ))}
                </select>

                {/* Operator */}
                <select
                  value={rule.operator}
                  onChange={(e) => updateRule(rule.id, { operator: e.target.value as any })}
                  className="px-3 py-1.5 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg w-40"
                >
                  <option value="equals">equals (=)</option>
                  <option value="not_equals">does not equal (!=)</option>
                  <option value="greater_than">greater than (&gt;)</option>
                  <option value="less_than">less than (&lt;)</option>
                  <option value="contains">contains (LIKE)</option>
                </select>

                {/* Value input */}
                <input
                  type="text"
                  placeholder="Comparison value..."
                  value={rule.value}
                  onChange={(e) => updateRule(rule.id, { value: e.target.value })}
                  className="px-3 py-1.5 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-lg flex-1"
                />

                <button
                  onClick={() => removeRule(rule.id)}
                  className="p-1.5 text-zinc-400 hover:text-rose-500 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Results Output Section */}
        {queryResult && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-semibold text-zinc-700 dark:text-zinc-300">
                Query Result ({queryResult.rows.length} rows)
              </span>
              <span className="text-emerald-500 font-semibold">
                Execution Time: {queryResult.executionTimeMs}ms
              </span>
            </div>

            <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-x-auto max-h-80">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead className="bg-zinc-100 dark:bg-zinc-800 border-b border-zinc-200 dark:border-zinc-700">
                  <tr>
                    {queryResult.columns.map((c) => (
                      <th key={c} className="px-3 py-2 border-r border-zinc-200 dark:border-zinc-700 font-semibold">
                        {c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {queryResult.rows.map((row, rIdx) => (
                    <tr key={rIdx} className="border-b border-zinc-200/60 dark:border-zinc-800/60">
                      {queryResult.columns.map((c) => (
                        <td key={c} className="px-3 py-1.5 border-r border-zinc-200/60 dark:border-zinc-800/60">
                          {String(row[c] ?? '')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
