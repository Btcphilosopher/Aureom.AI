/**
 * iBase 2026 Audit Log & Revision Stream
 */

import React from 'react';
import { X, History, ShieldCheck, Clock, User, CheckCircle2 } from 'lucide-react';
import { Database, AuditEvent } from '../types/database';

interface AuditLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentDb: Database | null;
}

export const AuditLogModal: React.FC<AuditLogModalProps> = ({ isOpen, onClose, currentDb }) => {
  if (!isOpen || !currentDb) return null;

  const logs: AuditEvent[] = currentDb.auditLogs || [];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none">
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl relative flex flex-col max-h-[85vh]">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-zinc-400"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center space-x-2 border-b border-zinc-200 dark:border-zinc-800 pb-3 mb-4">
          <History className="w-5 h-5 text-sky-500" />
          <h2 className="font-bold text-base text-zinc-900 dark:text-zinc-100">
            Immutable Database Audit Log
          </h2>
        </div>

        <div className="flex-1 overflow-y-auto space-y-3 font-mono text-xs">
          {logs.length === 0 ? (
            <div className="p-8 text-center text-zinc-400">No audit events recorded yet</div>
          ) : (
            logs.map((evt) => (
              <div
                key={evt.id}
                className="p-3 bg-zinc-50 dark:bg-[#161820] border border-zinc-200 dark:border-zinc-800 rounded-xl space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sky-600 dark:text-sky-400 text-[11px] uppercase">
                    {evt.eventType}
                  </span>
                  <div className="flex items-center space-x-2 text-[10px] text-zinc-400">
                    <User className="w-3 h-3" />
                    <span>{evt.user}</span>
                    <span>•</span>
                    <Clock className="w-3 h-3" />
                    <span>{new Date(evt.timestamp).toLocaleTimeString()}</span>
                  </div>
                </div>
                <p className="text-zinc-700 dark:text-zinc-300 font-sans text-xs">{evt.summary}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
