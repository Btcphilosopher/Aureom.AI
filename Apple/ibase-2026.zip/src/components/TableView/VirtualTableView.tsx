/**
 * iBase 2026 High-Performance Virtualized Data Grid Table View
 * Supports 26 Field Types, Inline Cell Editing, Sorting, Filtering, Keyboard Navigation, and Bulk Actions.
 */

import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Table as TableIcon,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Filter,
  Plus,
  Trash2,
  Copy,
  Edit,
  Check,
  ChevronRight,
  ChevronDown,
  MoreHorizontal,
  Search,
  Hash,
  Type,
  Calendar,
  DollarSign,
  Percent,
  ToggleLeft,
  Mail,
  Phone,
  Globe,
  ListFilter,
  Calculator,
  Link,
  Eye,
  Sigma,
} from 'lucide-react';
import { Database, Table, Field, RecordData, FieldType, SortRule, FilterGroup } from '../../types/database';
import { RelationalEngine } from '../../engine/relationalEngine';

interface VirtualTableViewProps {
  currentDb: Database;
  activeTableId: string;
  onUpdateRecord: (tableId: string, recordId: string, fieldId: string, value: any) => void;
  onAddRecord: (tableId: string) => void;
  onDeleteRecords: (tableId: string, recordIds: string[]) => void;
  onDuplicateRecord: (tableId: string, recordId: string) => void;
  onSelectRecordForInspector: (recordId: string) => void;
  relationalEngine: RelationalEngine;
  onAddFieldClick: () => void;
}

export const VirtualTableView: React.FC<VirtualTableViewProps> = ({
  currentDb,
  activeTableId,
  onUpdateRecord,
  onAddRecord,
  onDeleteRecords,
  onDuplicateRecord,
  onSelectRecordForInspector,
  relationalEngine,
  onAddFieldClick,
}) => {
  const table = currentDb.tables[activeTableId];
  const fields = useMemo(() => {
    if (!table) return [];
    return table.fieldIds.map((id) => currentDb.fields[id]).filter(Boolean);
  }, [table, currentDb.fields]);

  const rawRecords = useMemo(() => {
    return currentDb.records[activeTableId] || [];
  }, [currentDb.records, activeTableId]);

  // State for sorting, filtering, selection & cell editing
  const [sortRule, setSortRule] = useState<SortRule | null>(null);
  const [searchFilter, setSearchFilter] = useState('');
  const [selectedRecordIds, setSelectedRecordIds] = useState<string[]>([]);
  const [editingCell, setEditingCell] = useState<{ recordId: string; fieldId: string } | null>(null);
  const [editingValue, setEditingValue] = useState<any>('');

  // Column width state
  const [columnWidths, setColumnWidths] = useState<Record<string, number>>({});

  // Virtualization scroll state
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const ROW_HEIGHT = 36;
  const VISIBLE_COUNT = 30; // buffer rows

  // Filtered & Sorted records
  const processedRecords = useMemo(() => {
    let list = [...rawRecords];

    // Search filter
    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase().trim();
      list = list.filter((rec) => {
        return fields.some((f) => {
          const val = rec.values[f.id];
          return val !== null && val !== undefined && String(val).toLowerCase().includes(q);
        });
      });
    }

    // Sort rule
    if (sortRule) {
      const field = fields.find((f) => f.id === sortRule.fieldId);
      if (field) {
        list.sort((a, b) => {
          const valA = a.values[field.id] ?? '';
          const valB = b.values[field.id] ?? '';

          if (typeof valA === 'number' && typeof valB === 'number') {
            return sortRule.direction === 'asc' ? valA - valB : valB - valA;
          }

          return sortRule.direction === 'asc'
            ? String(valA).localeCompare(String(valB))
            : String(valB).localeCompare(String(valA));
        });
      }
    }

    return list;
  }, [rawRecords, searchFilter, sortRule, fields]);

  // Handle Scroll for virtualization
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
  };

  const startIndex = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - 5);
  const endIndex = Math.min(processedRecords.length, startIndex + VISIBLE_COUNT);
  const visibleRecords = processedRecords.slice(startIndex, endIndex);

  const topPadding = startIndex * ROW_HEIGHT;
  const bottomPadding = (processedRecords.length - endIndex) * ROW_HEIGHT;

  // Header click for sorting
  const handleHeaderSort = (fieldId: string) => {
    if (sortRule?.fieldId === fieldId) {
      if (sortRule.direction === 'asc') {
        setSortRule({ fieldId, direction: 'desc' });
      } else {
        setSortRule(null);
      }
    } else {
      setSortRule({ fieldId, direction: 'asc' });
    }
  };

  // Checkbox Selection
  const toggleSelectAll = () => {
    if (selectedRecordIds.length === processedRecords.length) {
      setSelectedRecordIds([]);
    } else {
      setSelectedRecordIds(processedRecords.map((r) => r.id));
    }
  };

  const toggleSelectRecord = (id: string) => {
    if (selectedRecordIds.includes(id)) {
      setSelectedRecordIds(selectedRecordIds.filter((rId) => rId !== id));
    } else {
      setSelectedRecordIds([...selectedRecordIds, id]);
    }
  };

  // Inline Editing Save
  const saveEditingCell = () => {
    if (!editingCell) return;
    onUpdateRecord(activeTableId, editingCell.recordId, editingCell.fieldId, editingValue);
    setEditingCell(null);
  };

  const getFieldIcon = (type: FieldType) => {
    switch (type) {
      case FieldType.INTEGER:
      case FieldType.BIG_INTEGER:
      case FieldType.DECIMAL: return <Hash className="w-3.5 h-3.5 text-blue-500" />;
      case FieldType.CURRENCY: return <DollarSign className="w-3.5 h-3.5 text-emerald-500" />;
      case FieldType.PERCENTAGE: return <Percent className="w-3.5 h-3.5 text-emerald-500" />;
      case FieldType.BOOLEAN: return <ToggleLeft className="w-3.5 h-3.5 text-purple-500" />;
      case FieldType.DATE:
      case FieldType.DATETIME: return <Calendar className="w-3.5 h-3.5 text-amber-500" />;
      case FieldType.EMAIL: return <Mail className="w-3.5 h-3.5 text-sky-500" />;
      case FieldType.PHONE: return <Phone className="w-3.5 h-3.5 text-indigo-500" />;
      case FieldType.URL: return <Globe className="w-3.5 h-3.5 text-teal-500" />;
      case FieldType.ENUM: return <ListFilter className="w-3.5 h-3.5 text-rose-500" />;
      case FieldType.FORMULA: return <Calculator className="w-3.5 h-3.5 text-violet-500" />;
      case FieldType.RELATION: return <Link className="w-3.5 h-3.5 text-amber-600" />;
      case FieldType.LOOKUP: return <Eye className="w-3.5 h-3.5 text-indigo-400" />;
      case FieldType.ROLLUP: return <Sigma className="w-3.5 h-3.5 text-emerald-600" />;
      default: return <Type className="w-3.5 h-3.5 text-zinc-400" />;
    }
  };

  if (!table) return null;

  return (
    <div className="flex-1 flex flex-col bg-white dark:bg-[#121419] overflow-hidden select-none">
      {/* Table Toolbar */}
      <div className="h-11 px-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between text-xs bg-zinc-50/50 dark:bg-[#15171e]">
        <div className="flex items-center space-x-3">
          {/* Quick Search inside Table */}
          <div className="relative w-48">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Filter records..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full pl-8 pr-2 py-1 bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>

          <button
            onClick={onAddRecord}
            className="flex items-center space-x-1 px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white font-medium rounded-md shadow-xs transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Row</span>
          </button>

          <button
            onClick={onAddFieldClick}
            className="flex items-center space-x-1 px-2.5 py-1 bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-medium rounded-md border border-zinc-200 dark:border-zinc-700 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Field</span>
          </button>
        </div>

        {/* Bulk Action Controls when rows selected */}
        {selectedRecordIds.length > 0 && (
          <div className="flex items-center space-x-2 bg-sky-500/10 dark:bg-sky-500/20 px-3 py-1 rounded-md border border-sky-500/30 text-sky-700 dark:text-sky-300">
            <span className="font-semibold">{selectedRecordIds.length} selected</span>
            <button
              onClick={() => {
                selectedRecordIds.forEach((id) => onDuplicateRecord(activeTableId, id));
                setSelectedRecordIds([]);
              }}
              className="px-2 py-0.5 hover:bg-sky-500/20 rounded flex items-center space-x-1"
              title="Duplicate selected records"
            >
              <Copy className="w-3 h-3" />
              <span>Duplicate</span>
            </button>
            <button
              onClick={() => {
                onDeleteRecords(activeTableId, selectedRecordIds);
                setSelectedRecordIds([]);
              }}
              className="px-2 py-0.5 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 rounded flex items-center space-x-1 font-semibold"
              title="Delete selected records"
            >
              <Trash2 className="w-3 h-3" />
              <span>Delete</span>
            </button>
          </div>
        )}
      </div>

      {/* Grid Container */}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-auto relative"
      >
        <table className="w-full text-left border-collapse font-sans text-xs">
          {/* Header */}
          <thead className="sticky top-0 z-10 bg-zinc-100 dark:bg-[#181a20] border-b border-zinc-200 dark:border-zinc-800 shadow-xs">
            <tr>
              {/* Checkbox Column */}
              <th className="w-10 px-3 py-2 border-r border-zinc-200 dark:border-zinc-800 text-center">
                <input
                  type="checkbox"
                  checked={selectedRecordIds.length > 0 && selectedRecordIds.length === processedRecords.length}
                  onChange={toggleSelectAll}
                  className="rounded text-sky-600 focus:ring-sky-500"
                />
              </th>

              {/* Inspector Column */}
              <th className="w-10 px-2 py-2 border-r border-zinc-200 dark:border-zinc-800 text-center text-zinc-400">
                <Eye className="w-3.5 h-3.5 mx-auto" />
              </th>

              {/* Field Headers */}
              {fields.map((f) => {
                const isSorted = sortRule?.fieldId === f.id;
                return (
                  <th
                    key={f.id}
                    onClick={() => handleHeaderSort(f.id)}
                    className="px-3 py-2 border-r border-zinc-200 dark:border-zinc-800 font-semibold text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200/60 dark:hover:bg-zinc-800/60 cursor-pointer select-none whitespace-nowrap min-w-[140px]"
                  >
                    <div className="flex items-center justify-between space-x-2">
                      <div className="flex items-center space-x-1.5 truncate">
                        {getFieldIcon(f.type)}
                        <span className="truncate">{f.name}</span>
                        {f.isPrimaryKey && (
                          <span className="text-[9px] bg-amber-500/20 text-amber-600 dark:text-amber-400 px-1 py-0.2 rounded uppercase font-bold">
                            PK
                          </span>
                        )}
                        {f.isForeignKey && (
                          <span className="text-[9px] bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 px-1 py-0.2 rounded uppercase font-bold">
                            FK
                          </span>
                        )}
                      </div>
                      <div className="text-zinc-400">
                        {isSorted ? (
                          sortRule.direction === 'asc' ? (
                            <ArrowUp className="w-3.5 h-3.5 text-sky-500" />
                          ) : (
                            <ArrowDown className="w-3.5 h-3.5 text-sky-500" />
                          )
                        ) : (
                          <ArrowUpDown className="w-3 h-3 opacity-0 group-hover:opacity-100 transition" />
                        )}
                      </div>
                    </div>
                  </th>
                );
              })}

              {/* Add Column Button */}
              <th className="w-12 px-3 py-2 text-center">
                <button
                  onClick={onAddFieldClick}
                  className="p-1 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200"
                  title="Add Field"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </th>
            </tr>
          </thead>

          {/* Virtual Body */}
          <tbody>
            {topPadding > 0 && <tr style={{ height: topPadding }} />}

            {visibleRecords.map((rec) => {
              const isSelected = selectedRecordIds.includes(rec.id);
              const computedValues = relationalEngine.computeRecordDynamicValues(activeTableId, rec);

              return (
                <tr
                  key={rec.id}
                  className={`border-b border-zinc-200/70 dark:border-zinc-800/60 transition-colors ${
                    isSelected
                      ? 'bg-sky-500/10 dark:bg-sky-500/15'
                      : 'hover:bg-zinc-50 dark:hover:bg-zinc-800/40'
                  }`}
                  style={{ height: ROW_HEIGHT }}
                >
                  {/* Select Checkbox */}
                  <td className="px-3 py-1 border-r border-zinc-200/70 dark:border-zinc-800/60 text-center">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleSelectRecord(rec.id)}
                      className="rounded text-sky-600 focus:ring-sky-500"
                    />
                  </td>

                  {/* Open Inspector Button */}
                  <td className="px-2 py-1 border-r border-zinc-200/70 dark:border-zinc-800/60 text-center">
                    <button
                      onClick={() => onSelectRecordForInspector(rec.id)}
                      className="p-1 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded text-zinc-400 hover:text-sky-500 transition"
                      title="Inspect record & related items"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </td>

                  {/* Field Values */}
                  {fields.map((f) => {
                    const isEditing = editingCell?.recordId === rec.id && editingCell?.fieldId === f.id;
                    const val = computedValues[f.id];
                    const isReadOnly = f.type === FieldType.FORMULA || f.type === FieldType.ROLLUP || f.type === FieldType.LOOKUP;

                    return (
                      <td
                        key={f.id}
                        onDoubleClick={() => {
                          if (!isReadOnly) {
                            setEditingCell({ recordId: rec.id, fieldId: f.id });
                            setEditingValue(rec.values[f.id] ?? '');
                          }
                        }}
                        className={`px-3 py-1 border-r border-zinc-200/70 dark:border-zinc-800/60 truncate max-w-[220px] font-mono text-[11px] ${
                          isReadOnly ? 'bg-zinc-50/60 dark:bg-zinc-900/40 italic text-zinc-500 dark:text-zinc-400' : ''
                        }`}
                      >
                        {isEditing ? (
                          <input
                            type="text"
                            autoFocus
                            value={editingValue}
                            onChange={(e) => setEditingValue(e.target.value)}
                            onBlur={saveEditingCell}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') saveEditingCell();
                              if (e.key === 'Escape') setEditingCell(null);
                            }}
                            className="w-full px-1.5 py-0.5 bg-white dark:bg-zinc-900 border border-sky-500 rounded text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none"
                          />
                        ) : (
                          <CellRenderer field={f} value={val} currentDb={currentDb} />
                        )}
                      </td>
                    );
                  })}

                  <td className="px-3 py-1" />
                </tr>
              );
            })}

            {bottomPadding > 0 && <tr style={{ height: bottomPadding }} />}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Helper Component for Formatted Cell Display
const CellRenderer: React.FC<{ field: Field; value: any; currentDb: Database }> = ({ field, value, currentDb }) => {
  if (value === null || value === undefined || value === '') {
    return <span className="text-zinc-400 italic font-sans text-[10px]">null</span>;
  }

  if (field.type === FieldType.CURRENCY) {
    const symbol = field.options?.currencySymbol || '£';
    const num = Number(value) || 0;
    return (
      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
        {symbol}{num.toLocaleString('en-GB', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
      </span>
    );
  }

  if (field.type === FieldType.PERCENTAGE) {
    return <span className="text-teal-600 dark:text-teal-400 font-semibold">{value}%</span>;
  }

  if (field.type === FieldType.BOOLEAN) {
    return (
      <span className={`inline-block w-2.5 h-2.5 rounded-full ${value ? 'bg-emerald-500' : 'bg-zinc-300 dark:bg-zinc-700'}`} />
    );
  }

  if (field.type === FieldType.ENUM) {
    return (
      <span className="px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-700 dark:text-sky-300 text-[10px] font-sans font-medium border border-sky-500/20">
        {String(value)}
      </span>
    );
  }

  if (field.type === FieldType.RELATION && field.foreignKeyTargetTableId) {
    const targetTable = currentDb.tables[field.foreignKeyTargetTableId];
    const targetRecord = (currentDb.records[field.foreignKeyTargetTableId] || []).find((r) => r.id === String(value));
    const targetTitle = targetRecord ? Object.values(targetRecord.values)[0] || targetRecord.id : String(value);

    return (
      <span className="px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-sans font-medium text-[10px]">
        {targetTable ? `${targetTable.name}: ` : ''}{String(targetTitle)}
      </span>
    );
  }

  if (field.type === FieldType.ROLLUP) {
    return (
      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
        {String(value)}
      </span>
    );
  }

  return <span className="text-zinc-800 dark:text-zinc-200">{String(value)}</span>;
};
