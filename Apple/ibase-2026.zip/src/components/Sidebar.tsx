/**
 * iBase 2026 Left Navigation Sidebar
 */

import React, { useState } from 'react';
import {
  Table as TableIcon,
  Plus,
  Layers,
  Code2,
  FileSpreadsheet,
  Kanban,
  LayoutGrid,
  Calendar,
  MapPin,
  ChevronRight,
  ChevronDown,
  Trash2,
  Edit2,
  Database,
  Search,
} from 'lucide-react';
import { Database as DatabaseType, ViewType, View } from '../types/database';

interface SidebarProps {
  currentDb: DatabaseType;
  activeTableId: string | null;
  onSelectTable: (tableId: string) => void;
  activeViewId: string | null;
  onSelectView: (viewId: string) => void;
  onCreateTableClick: () => void;
  onDeleteTableClick: (tableId: string) => void;
  activeTab: 'data' | 'schema' | 'query' | 'sql' | 'forms' | 'audit';
  setActiveTab: (tab: 'data' | 'schema' | 'query' | 'sql' | 'forms' | 'audit') => void;
  onCreateViewClick: (type: ViewType) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentDb,
  activeTableId,
  onSelectTable,
  activeViewId,
  onSelectView,
  onCreateTableClick,
  onDeleteTableClick,
  activeTab,
  setActiveTab,
  onCreateViewClick,
}) => {
  const [tablesExpanded, setTablesExpanded] = useState(true);
  const [queriesExpanded, setQueriesExpanded] = useState(true);
  const [showAddViewMenu, setShowAddViewMenu] = useState(false);

  const tables = Object.values(currentDb.tables);
  const activeTable = activeTableId ? currentDb.tables[activeTableId] : undefined;
  const currentViews = activeTableId ? currentDb.views[activeTableId] || [] : [];

  const getViewIcon = (type: ViewType) => {
    switch (type) {
      case ViewType.TABLE: return <TableIcon className="w-3.5 h-3.5" />;
      case ViewType.KANBAN: return <Kanban className="w-3.5 h-3.5" />;
      case ViewType.CARD: return <LayoutGrid className="w-3.5 h-3.5" />;
      case ViewType.CALENDAR: return <Calendar className="w-3.5 h-3.5" />;
      case ViewType.MAP: return <MapPin className="w-3.5 h-3.5" />;
      default: return <TableIcon className="w-3.5 h-3.5" />;
    }
  };

  return (
    <aside className="w-60 bg-zinc-50 dark:bg-[#101216] border-r border-zinc-200 dark:border-zinc-800/80 flex flex-col justify-between shrink-0 select-none">
      <div className="flex-1 overflow-y-auto p-3 space-y-5 text-xs">
        {/* Tables Section */}
        <div>
          <div className="flex items-center justify-between px-2 mb-1 text-zinc-400 font-semibold tracking-wider uppercase text-[10px]">
            <button
              onClick={() => setTablesExpanded(!tablesExpanded)}
              className="flex items-center space-x-1 hover:text-zinc-600 dark:hover:text-zinc-200 transition"
            >
              {tablesExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              <span>Tables ({tables.length})</span>
            </button>
            <button
              onClick={onCreateTableClick}
              className="p-1 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded text-zinc-600 dark:text-zinc-300 transition"
              title="Add New Table"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {tablesExpanded && (
            <div className="space-y-0.5">
              {tables.map((table) => {
                const isSelected = activeTableId === table.id && activeTab === 'data';
                const recCount = (currentDb.records[table.id] || []).length;

                return (
                  <div key={table.id} className="group relative flex items-center">
                    <button
                      onClick={() => {
                        onSelectTable(table.id);
                        setActiveTab('data');
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-left font-medium transition ${
                        isSelected
                          ? 'bg-sky-500/10 dark:bg-sky-500/20 text-sky-700 dark:text-sky-300 font-semibold'
                          : 'text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200/60 dark:hover:bg-zinc-800/50'
                      }`}
                    >
                      <div className="flex items-center space-x-2 truncate">
                        <TableIcon className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                        <span className="truncate">{table.name}</span>
                      </div>
                      <span className="text-[10px] text-zinc-400 bg-zinc-200/50 dark:bg-zinc-800 px-1.5 py-0.2 rounded font-mono">
                        {recCount}
                      </span>
                    </button>

                    {/* Delete Table Action on Hover */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteTableClick(table.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:text-rose-600 dark:hover:text-rose-400 transition absolute right-7"
                      title="Delete Table"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Views Section for Active Table */}
        {activeTable && activeTab === 'data' && (
          <div>
            <div className="flex items-center justify-between px-2 mb-1 text-zinc-400 font-semibold tracking-wider uppercase text-[10px]">
              <span>Table Views</span>
              <div className="relative">
                <button
                  onClick={() => setShowAddViewMenu(!showAddViewMenu)}
                  className="p-1 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded text-zinc-600 dark:text-zinc-300 transition"
                  title="Create New View"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>

                {/* Dropdown Menu to pick View Type */}
                {showAddViewMenu && (
                  <div className="absolute right-0 mt-1 w-36 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-lg shadow-lg z-30 py-1 text-xs">
                    <button
                      onClick={() => {
                        onCreateViewClick(ViewType.TABLE);
                        setShowAddViewMenu(false);
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center space-x-2"
                    >
                      <TableIcon className="w-3.5 h-3.5" />
                      <span>Grid View</span>
                    </button>
                    <button
                      onClick={() => {
                        onCreateViewClick(ViewType.KANBAN);
                        setShowAddViewMenu(false);
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center space-x-2"
                    >
                      <Kanban className="w-3.5 h-3.5 text-amber-500" />
                      <span>Kanban Board</span>
                    </button>
                    <button
                      onClick={() => {
                        onCreateViewClick(ViewType.CARD);
                        setShowAddViewMenu(false);
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center space-x-2"
                    >
                      <LayoutGrid className="w-3.5 h-3.5 text-sky-500" />
                      <span>Card Grid</span>
                    </button>
                    <button
                      onClick={() => {
                        onCreateViewClick(ViewType.CALENDAR);
                        setShowAddViewMenu(false);
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 flex items-center space-x-2"
                    >
                      <Calendar className="w-3.5 h-3.5 text-purple-500" />
                      <span>Calendar</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-0.5">
              {currentViews.map((v) => {
                const isSelected = activeViewId === v.id;
                return (
                  <button
                    key={v.id}
                    onClick={() => onSelectView(v.id)}
                    className={`w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-md text-left font-medium transition ${
                      isSelected
                        ? 'bg-zinc-200/80 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold'
                        : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200/40 dark:hover:bg-zinc-800/40'
                    }`}
                  >
                    <span className="text-zinc-400">{getViewIcon(v.type)}</span>
                    <span className="truncate">{v.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Saved Queries */}
        <div>
          <div className="flex items-center justify-between px-2 mb-1 text-zinc-400 font-semibold tracking-wider uppercase text-[10px]">
            <button
              onClick={() => setQueriesExpanded(!queriesExpanded)}
              className="flex items-center space-x-1 hover:text-zinc-600 dark:hover:text-zinc-200 transition"
            >
              {queriesExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              <span>Saved Queries ({currentDb.savedQueries?.length || 0})</span>
            </button>
          </div>

          {queriesExpanded && (
            <div className="space-y-0.5">
              {(currentDb.savedQueries || []).map((sq) => (
                <button
                  key={sq.id}
                  onClick={() => setActiveTab('sql')}
                  className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-md text-left font-medium text-zinc-600 dark:text-zinc-400 hover:bg-zinc-200/40 dark:hover:bg-zinc-800/40 transition truncate"
                >
                  <Code2 className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                  <span className="truncate">{sq.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Footer System Info */}
      <div className="p-3 border-t border-zinc-200 dark:border-zinc-800/80 bg-zinc-100/50 dark:bg-[#0c0d10] text-[11px] text-zinc-500 dark:text-zinc-400 space-y-1">
        <div className="flex items-center justify-between font-mono">
          <span>Engine:</span>
          <span className="text-emerald-600 dark:text-emerald-400 font-semibold">Local SQLite Engine</span>
        </div>
        <div className="flex items-center justify-between font-mono">
          <span>Storage:</span>
          <span className="text-sky-600 dark:text-sky-400 font-semibold">IndexedDB Sync</span>
        </div>
      </div>
    </aside>
  );
};
