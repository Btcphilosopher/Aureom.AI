/**
 * iBase 2026 Safe Formula Engine
 * Lexer -> Parser -> AST -> Evaluator
 * Supports field references [FieldName], math operators, logic, text and date functions.
 */

export type TokenType =
  | 'NUMBER'
  | 'STRING'
  | 'IDENTIFIER' // [Field Name]
  | 'OPERATOR'   // +, -, *, /, %, ==, !=, >, <, >=, <=, &&, ||
  | 'KEYWORD'    // IF, AND, OR, NOT
  | 'FUNCTION'   // CONCAT, UPPER, LOWER, ROUND, IF, DATE_DIFF, ABS, LEN, FORMAT_CURRENCY
  | 'LPAREN'     // (
  | 'RPAREN'     // )
  | 'COMMA'      // ,
  | 'EOF';

export interface Token {
  type: TokenType;
  value: string | number;
}

export function lexFormula(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  while (i < input.length) {
    const char = input[i];

    // Whitespace
    if (/\s/.test(char)) {
      i++;
      continue;
    }

    // Bracketed field identifier e.g. [Quantity]
    if (char === '[') {
      let fieldName = '';
      i++;
      while (i < input.length && input[i] !== ']') {
        fieldName += input[i];
        i++;
      }
      if (input[i] === ']') i++;
      tokens.push({ type: 'IDENTIFIER', value: fieldName.trim() });
      continue;
    }

    // Numbers
    if (/\d/.test(char) || (char === '.' && /\d/.test(input[i + 1] || ''))) {
      let numStr = '';
      while (i < input.length && (/\d/.test(input[i]) || input[i] === '.')) {
        numStr += input[i];
        i++;
      }
      tokens.push({ type: 'NUMBER', value: parseFloat(numStr) });
      continue;
    }

    // Strings (quoted)
    if (char === '"' || char === "'") {
      const quote = char;
      let strVal = '';
      i++;
      while (i < input.length && input[i] !== quote) {
        strVal += input[i];
        i++;
      }
      if (input[i] === quote) i++;
      tokens.push({ type: 'STRING', value: strVal });
      continue;
    }

    // Parentheses & comma
    if (char === '(') {
      tokens.push({ type: 'LPAREN', value: '(' });
      i++;
      continue;
    }
    if (char === ')') {
      tokens.push({ type: 'RPAREN', value: ')' });
      i++;
      continue;
    }
    if (char === ',') {
      tokens.push({ type: 'COMMA', value: ',' });
      i++;
      continue;
    }

    // Multi-char operators e.g. ==, !=, >=, <=, &&, ||
    const twoChars = input.slice(i, i + 2);
    if (['==', '!=', '>=', '<=', '&&', '||'].includes(twoChars)) {
      tokens.push({ type: 'OPERATOR', value: twoChars });
      i += 2;
      continue;
    }

    // Single-char operators
    if (['+', '-', '*', '/', '%', '>', '<', '='].includes(char)) {
      const op = char === '=' ? '==' : char;
      tokens.push({ type: 'OPERATOR', value: op });
      i++;
      continue;
    }

    // Function or Keyword identifiers (e.g. IF, CONCAT, UPPER, LOWER, ROUND, ABS, YEAR, NOW)
    if (/[a-zA-Z_]/.test(char)) {
      let word = '';
      while (i < input.length && /[a-zA-Z0-9_]/.test(input[i])) {
        word += input[i];
        i++;
      }
      const upperWord = word.toUpperCase();
      if (['IF', 'AND', 'OR', 'NOT'].includes(upperWord)) {
        tokens.push({ type: 'KEYWORD', value: upperWord });
      } else if (['CONCAT', 'UPPER', 'LOWER', 'ROUND', 'ABS', 'LEN', 'LENGTH', 'FORMAT_CURRENCY', 'DATE_DIFF', 'NOW', 'YEAR', 'MIN', 'MAX', 'COALESCE'].includes(upperWord)) {
        tokens.push({ type: 'FUNCTION', value: upperWord });
      } else {
        tokens.push({ type: 'IDENTIFIER', value: word });
      }
      continue;
    }

    i++;
  }

  tokens.push({ type: 'EOF', value: '' });
  return tokens;
}

export type ASTNode =
  | { type: 'Literal'; value: any }
  | { type: 'FieldRef'; name: string }
  | { type: 'BinaryExpr'; operator: string; left: ASTNode; right: ASTNode }
  | { type: 'UnaryExpr'; operator: string; argument: ASTNode }
  | { type: 'FunctionCall'; name: string; args: ASTNode[] };

class FormulaParser {
  private tokens: Token[];
  private current = 0;

  constructor(tokens: Token[]) {
    this.tokens = tokens;
  }

  private peek(): Token {
    return this.tokens[this.current] || { type: 'EOF', value: '' };
  }

  private advance(): Token {
    const token = this.peek();
    this.current++;
    return token;
  }

  private match(type: TokenType, value?: string): boolean {
    const t = this.peek();
    if (t.type === type && (value === undefined || t.value === value)) {
      this.advance();
      return true;
    }
    return false;
  }

  public parse(): ASTNode {
    const node = this.parseExpression();
    return node;
  }

  private parseExpression(): ASTNode {
    return this.parseLogicalOr();
  }

  private parseLogicalOr(): ASTNode {
    let left = this.parseLogicalAnd();
    while (this.match('OPERATOR', '||') || this.match('KEYWORD', 'OR')) {
      const right = this.parseLogicalAnd();
      left = { type: 'BinaryExpr', operator: '||', left, right };
    }
    return left;
  }

  private parseLogicalAnd(): ASTNode {
    let left = this.parseEquality();
    while (this.match('OPERATOR', '&&') || this.match('KEYWORD', 'AND')) {
      const right = this.parseEquality();
      left = { type: 'BinaryExpr', operator: '&&', left, right };
    }
    return left;
  }

  private parseEquality(): ASTNode {
    let left = this.parseRelational();
    while (this.peek().type === 'OPERATOR' && ['==', '!='].includes(String(this.peek().value))) {
      const op = String(this.advance().value);
      const right = this.parseRelational();
      left = { type: 'BinaryExpr', operator: op, left, right };
    }
    return left;
  }

  private parseRelational(): ASTNode {
    let left = this.parseAdditive();
    while (this.peek().type === 'OPERATOR' && ['>', '<', '>=', '<='].includes(String(this.peek().value))) {
      const op = String(this.advance().value);
      const right = this.parseAdditive();
      left = { type: 'BinaryExpr', operator: op, left, right };
    }
    return left;
  }

  private parseAdditive(): ASTNode {
    let left = this.parseMultiplicative();
    while (this.peek().type === 'OPERATOR' && ['+', '-'].includes(String(this.peek().value))) {
      const op = String(this.advance().value);
      const right = this.parseMultiplicative();
      left = { type: 'BinaryExpr', operator: op, left, right };
    }
    return left;
  }

  private parseMultiplicative(): ASTNode {
    let left = this.parsePrimary();
    while (this.peek().type === 'OPERATOR' && ['*', '/', '%'].includes(String(this.peek().value))) {
      const op = String(this.advance().value);
      const right = this.parsePrimary();
      left = { type: 'BinaryExpr', operator: op, left, right };
    }
    return left;
  }

  private parsePrimary(): ASTNode {
    const token = this.peek();

    if (token.type === 'NUMBER' || token.type === 'STRING') {
      this.advance();
      return { type: 'Literal', value: token.value };
    }

    if (token.type === 'IDENTIFIER') {
      this.advance();
      return { type: 'FieldRef', name: String(token.value) };
    }

    if (token.type === 'FUNCTION' || (token.type === 'KEYWORD' && token.value === 'IF')) {
      const funcName = String(this.advance().value).toUpperCase();
      this.match('LPAREN');
      const args: ASTNode[] = [];
      if (this.peek().type !== 'RPAREN' && this.peek().type !== 'EOF') {
        do {
          args.push(this.parseExpression());
        } while (this.match('COMMA'));
      }
      this.match('RPAREN');
      return { type: 'FunctionCall', name: funcName, args };
    }

    if (token.type === 'LPAREN') {
      this.advance();
      const expr = this.parseExpression();
      this.match('RPAREN');
      return expr;
    }

    // Fallback
    this.advance();
    return { type: 'Literal', value: null };
  }
}

export function evaluateAST(node: ASTNode, recordValuesByName: Record<string, any>): any {
  if (!node) return null;

  switch (node.type) {
    case 'Literal':
      return node.value;

    case 'FieldRef': {
      const val = recordValuesByName[node.name] ?? recordValuesByName[node.name.toLowerCase()];
      return val ?? null;
    }

    case 'BinaryExpr': {
      const l = evaluateAST(node.left, recordValuesByName);
      const r = evaluateAST(node.right, recordValuesByName);

      switch (node.operator) {
        case '+':
          if (typeof l === 'string' || typeof r === 'string') {
            return String(l ?? '') + String(r ?? '');
          }
          return (Number(l) || 0) + (Number(r) || 0);
        case '-': return (Number(l) || 0) - (Number(r) || 0);
        case '*': return (Number(l) || 0) * (Number(r) || 0);
        case '/': return Number(r) === 0 ? 0 : (Number(l) || 0) / Number(r);
        case '%': return Number(r) === 0 ? 0 : (Number(l) || 0) % Number(r);
        case '==': return l == r;
        case '!=': return l != r;
        case '>': return Number(l) > Number(r);
        case '<': return Number(l) < Number(r);
        case '>=': return Number(l) >= Number(r);
        case '<=': return Number(l) <= Number(r);
        case '&&': return Boolean(l) && Boolean(r);
        case '||': return Boolean(l) || Boolean(r);
        default: return null;
      }
    }

    case 'FunctionCall': {
      const argVals = node.args.map((arg) => evaluateAST(arg, recordValuesByName));
      switch (node.name) {
        case 'IF': {
          const condition = argVals[0];
          return condition ? argVals[1] : argVals[2];
        }
        case 'CONCAT':
          return argVals.map((v) => (v === null || v === undefined ? '' : String(v))).join('');
        case 'UPPER':
          return String(argVals[0] ?? '').toUpperCase();
        case 'LOWER':
          return String(argVals[0] ?? '').toLowerCase();
        case 'ROUND': {
          const num = Number(argVals[0]) || 0;
          const decimals = Number(argVals[1]) || 0;
          return Number(num.toFixed(decimals));
        }
        case 'ABS':
          return Math.abs(Number(argVals[0]) || 0);
        case 'LEN':
        case 'LENGTH':
          return String(argVals[0] ?? '').length;
        case 'FORMAT_CURRENCY': {
          const amount = Number(argVals[0]) || 0;
          const symbol = argVals[1] ? String(argVals[1]) : '£';
          return `${symbol}${amount.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        }
        case 'DATE_DIFF': {
          const d1 = new Date(argVals[0]);
          const d2 = new Date(argVals[1]);
          const diffMs = Math.abs(d1.getTime() - d2.getTime());
          return Math.floor(diffMs / (1000 * 60 * 60 * 24)); // returns days
        }
        case 'NOW':
          return new Date().toISOString();
        case 'YEAR': {
          const d = new Date(argVals[0]);
          return isNaN(d.getTime()) ? null : d.getFullYear();
        }
        case 'MIN':
          return Math.min(...argVals.map((v) => Number(v) || 0));
        case 'MAX':
          return Math.max(...argVals.map((v) => Number(v) || 0));
        case 'COALESCE':
          return argVals.find((v) => v !== null && v !== undefined && v !== '') ?? null;
        default:
          return null;
      }
    }

    default:
      return null;
  }
}

export function evaluateFormula(expression: string, recordValuesByName: Record<string, any>): any {
  if (!expression || !expression.trim()) return null;
  try {
    const tokens = lexFormula(expression);
    const parser = new FormulaParser(tokens);
    const ast = parser.parse();
    return evaluateAST(ast, recordValuesByName);
  } catch (err) {
    console.error('Formula evaluation error:', err);
    return '#ERROR!';
  }
}
