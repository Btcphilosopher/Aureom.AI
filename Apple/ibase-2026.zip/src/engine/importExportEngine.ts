/**
 * iBase 2026 Import / Export Engine
 * High-performance file parsing, column auto-detection, type inference, and multi-format export.
 */

import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { Database, Table, Field, FieldType, RecordData } from '../types/database';

export interface ColumnInference {
  name: string;
  inferredType: FieldType;
  sampleValues: any[];
}

export interface ParseResult {
  tableName: string;
  columns: ColumnInference[];
  rows: Record<string, any>[];
}

export class ImportExportEngine {
  /**
   * Infer FieldType from array of sample string/value representations
   */
  public static inferFieldType(values: any[]): FieldType {
    const validValues = values.filter((v) => v !== null && v !== undefined && String(v).trim() !== '');
    if (validValues.length === 0) return FieldType.TEXT;

    let isBoolean = true;
    let isInteger = true;
    let isDecimal = true;
    let isCurrency = true;
    let isDate = true;
    let isEmail = true;
    let isUrl = true;

    for (const val of validValues) {
      const str = String(val).trim();

      // Boolean check
      if (!['true', 'false', '1', '0', 'yes', 'no'].includes(str.toLowerCase())) {
        isBoolean = false;
      }

      // Currency check (e.g., $100, £50.00, €99)
      if (!/^[$£€¥]\s*[\d,]+(\.\d+)?$/.test(str)) {
        isCurrency = false;
      }

      // Integer check
      if (!/^-?\d+$/.test(str)) {
        isInteger = false;
      }

      // Decimal check
      if (!/^-?\d+(\.\d+)?$/.test(str)) {
        isDecimal = false;
      }

      // Email check
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str)) {
        isEmail = false;
      }

      // URL check
      if (!/^https?:\/\/[^\s]+$/.test(str)) {
        isUrl = false;
      }

      // Date check
      const timestamp = Date.parse(str);
      if (isNaN(timestamp) || str.length < 6) {
        isDate = false;
      }
    }

    if (isBoolean) return FieldType.BOOLEAN;
    if (isCurrency) return FieldType.CURRENCY;
    if (isInteger) return FieldType.INTEGER;
    if (isDecimal) return FieldType.DECIMAL;
    if (isEmail) return FieldType.EMAIL;
    if (isUrl) return FieldType.URL;
    if (isDate) return FieldType.DATE;

    return FieldType.TEXT;
  }

  /**
   * Parse raw text file (CSV or TSV)
   */
  public static parseCSV(content: string, fileName: string): ParseResult {
    const parsed = Papa.parse<Record<string, any>>(content, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
    });

    const rows = parsed.data || [];
    const rawCols = parsed.meta.fields || [];

    const columns: ColumnInference[] = rawCols.map((colName) => {
      const sampleVals = rows.slice(0, 50).map((r) => r[colName]);
      return {
        name: colName,
        inferredType: this.inferFieldType(sampleVals),
        sampleValues: sampleVals.slice(0, 3),
      };
    });

    const cleanTableName = fileName.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9_]/g, ' ') || 'Imported Table';

    return {
      tableName: cleanTableName,
      columns,
      rows,
    };
  }

  /**
   * Parse JSON file content
   */
  public static parseJSON(content: string, fileName: string): ParseResult {
    let rows: Record<string, any>[] = [];
    try {
      const data = JSON.parse(content);
      rows = Array.isArray(data) ? data : [data];
    } catch (e) {
      // Try JSONL
      rows = content
        .split('\n')
        .filter((line) => line.trim())
        .map((line) => JSON.parse(line));
    }

    if (rows.length === 0) throw new Error('JSON file is empty');

    const colNames = Array.from(new Set(rows.flatMap((r) => Object.keys(r))));
    const columns: ColumnInference[] = colNames.map((colName) => {
      const sampleVals = rows.slice(0, 50).map((r) => r[colName]);
      return {
        name: colName,
        inferredType: this.inferFieldType(sampleVals),
        sampleValues: sampleVals.slice(0, 3),
      };
    });

    const cleanTableName = fileName.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9_]/g, ' ') || 'Imported Table';

    return {
      tableName: cleanTableName,
      columns,
      rows,
    };
  }

  /**
   * Parse XLSX binary file buffer
   */
  public static parseXLSX(buffer: ArrayBuffer, fileName: string): ParseResult {
    const workbook = XLSX.read(buffer, { type: 'array' });
    const firstSheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[firstSheetName];
    const rows = XLSX.utils.sheet_to_json<Record<string, any>>(sheet);

    if (rows.length === 0) throw new Error('Excel sheet is empty');

    const colNames = Array.from(new Set(rows.flatMap((r) => Object.keys(r))));
    const columns: ColumnInference[] = colNames.map((colName) => {
      const sampleVals = rows.slice(0, 50).map((r) => r[colName]);
      return {
        name: colName,
        inferredType: this.inferFieldType(sampleVals),
        sampleValues: sampleVals.slice(0, 3),
      };
    });

    const cleanTableName = firstSheetName || fileName.replace(/\.[^/.]+$/, '') || 'Imported Table';

    return {
      tableName: cleanTableName,
      columns,
      rows,
    };
  }

  /**
   * Export table to CSV string
   */
  public static exportToCSV(table: Table, fields: Field[], records: RecordData[]): string {
    const headers = fields.map((f) => f.name);
    const dataRows = records.map((rec) => {
      const row: Record<string, any> = {};
      for (const f of fields) {
        let val = rec.values[f.id];
        if (Array.isArray(val)) val = val.join('; ');
        row[f.name] = val ?? '';
      }
      return row;
    });

    return Papa.unparse({ fields: headers, data: dataRows });
  }

  /**
   * Export table to SQL DDL + DML script
   */
  public static exportToSQL(table: Table, fields: Field[], records: RecordData[]): string {
    let sql = `-- iBase 2026 SQL Export for Table: ${table.name}\n`;
    sql += `-- Generated at ${new Date().toISOString()}\n\n`;

    // CREATE TABLE DDL
    sql += `CREATE TABLE IF NOT EXISTS "${table.name}" (\n`;
    const colDefs = fields.map((f) => {
      let sqlType = 'TEXT';
      if (f.type === FieldType.INTEGER) sqlType = 'INTEGER';
      if (f.type === FieldType.BIG_INTEGER || f.type === FieldType.DECIMAL || f.type === FieldType.CURRENCY) sqlType = 'NUMERIC';
      if (f.type === FieldType.BOOLEAN) sqlType = 'BOOLEAN';
      if (f.type === FieldType.DATE || f.type === FieldType.DATETIME) sqlType = 'TIMESTAMP';

      let constraint = f.isPrimaryKey ? ' PRIMARY KEY' : '';
      if (f.options?.required) constraint += ' NOT NULL';
      return `  "${f.name}" ${sqlType}${constraint}`;
    });
    sql += colDefs.join(',\n');
    sql += `\n);\n\n`;

    // INSERT INTO DML
    if (records.length > 0) {
      sql += `-- INSERT ${records.length} RECORDS\n`;
      for (const rec of records) {
        const colNames = fields.map((f) => `"${f.name}"`).join(', ');
        const valList = fields.map((f) => {
          const v = rec.values[f.id];
          if (v === null || v === undefined) return 'NULL';
          if (typeof v === 'number' || typeof v === 'boolean') return String(v);
          return `'${String(v).replace(/'/g, "''")}'`;
        }).join(', ');

        sql += `INSERT INTO "${table.name}" (${colNames}) VALUES (${valList});\n`;
      }
    }

    return sql;
  }
}
