/**
 * iBase 2026 Global Database Search Engine
 */

import { Database } from '../types/database';

export interface SearchMatch {
  id: string;
  type: 'TABLE' | 'FIELD' | 'RECORD' | 'QUERY' | 'VIEW';
  title: string;
  subtitle: string;
  matchContext: string;
  tableId?: string;
  recordId?: string;
  fieldId?: string;
  viewId?: string;
}

export class SearchEngine {
  public static search(db: Database, query: string): SearchMatch[] {
    if (!query || query.trim().length < 2) return [];

    const q = query.toLowerCase().trim();
    const results: SearchMatch[] = [];

    // 1. Search Tables
    for (const table of Object.values(db.tables)) {
      if (table.name.toLowerCase().includes(q) || table.description?.toLowerCase().includes(q)) {
        results.push({
          id: `tbl_${table.id}`,
          type: 'TABLE',
          title: table.name,
          subtitle: `Table • ${table.fieldIds.length} fields`,
          matchContext: table.description || `Table "${table.name}"`,
          tableId: table.id,
        });
      }
    }

    // 2. Search Fields
    for (const field of Object.values(db.fields)) {
      if (field.name.toLowerCase().includes(q) || field.type.toLowerCase().includes(q)) {
        const table = db.tables[field.tableId];
        results.push({
          id: `fld_${field.id}`,
          type: 'FIELD',
          title: `${field.name} (${field.type})`,
          subtitle: `Field in table "${table?.name || 'Unknown'}"`,
          matchContext: field.description || `Type: ${field.type}`,
          tableId: field.tableId,
          fieldId: field.id,
        });
      }
    }

    // 3. Search Saved Queries
    for (const sq of db.savedQueries || []) {
      if (sq.name.toLowerCase().includes(q) || (sq.sqlText && sq.sqlText.toLowerCase().includes(q))) {
        results.push({
          id: `qry_${sq.id}`,
          type: 'QUERY',
          title: sq.name,
          subtitle: `Saved Query (${sq.type})`,
          matchContext: sq.sqlText || sq.name,
        });
      }
    }

    // 4. Search Records across all tables
    for (const table of Object.values(db.tables)) {
      const records = db.records[table.id] || [];
      const tableFields = table.fieldIds.map((id) => db.fields[id]).filter(Boolean);

      for (const rec of records) {
        let matchedFieldName = '';
        let matchedValue = '';
        let found = false;

        for (const f of tableFields) {
          const val = rec.values[f.id];
          if (val !== null && val !== undefined) {
            const strVal = String(val);
            if (strVal.toLowerCase().includes(q)) {
              matchedFieldName = f.name;
              matchedValue = strVal;
              found = true;
              break;
            }
          }
        }

        if (found) {
          // Find primary display value for title
          const primaryFieldId = table.primaryKeyFieldId || table.fieldIds[0];
          const primaryVal = rec.values[primaryFieldId] ? String(rec.values[primaryFieldId]) : rec.id;

          results.push({
            id: `rec_${rec.id}`,
            type: 'RECORD',
            title: primaryVal,
            subtitle: `Record in "${table.name}"`,
            matchContext: `${matchedFieldName}: "${matchedValue}"`,
            tableId: table.id,
            recordId: rec.id,
          });

          if (results.length >= 100) break; // Limit search results max 100
        }
      }
    }

    return results;
  }
}
