/**
 * iBase 2026 Relational Engine
 * Handles Indexing, FK integrity, Rollups, Lookups, and Relationships.
 */

import { Database, RecordData, Field, FieldType, RollupFunction } from '../types/database';
import { evaluateFormula } from './formulaEngine';

export interface IndexMap {
  [tableId: string]: {
    byPrimaryKey: Map<string, RecordData>;
    byForeignKey: Map<string, RecordData[]>; // key = `${foreignKeyFieldId}:${targetId}`
  };
}

export class RelationalEngine {
  private db: Database;
  private indexMaps: IndexMap = {};

  constructor(db: Database) {
    this.db = db;
    this.buildIndexes();
  }

  public updateDatabase(db: Database) {
    this.db = db;
    this.buildIndexes();
  }

  public buildIndexes() {
    this.indexMaps = {};

    for (const tableId of Object.keys(this.db.tables)) {
      const records = this.db.records[tableId] || [];
      const pkMap = new Map<string, RecordData>();
      const fkMap = new Map<string, RecordData[]>();

      for (const rec of records) {
        pkMap.set(rec.id, rec);

        // Index foreign keys
        for (const [fieldId, val] of Object.entries(rec.values)) {
          if (val !== null && val !== undefined) {
            const key = `${fieldId}:${val}`;
            if (!fkMap.has(key)) {
              fkMap.set(key, []);
            }
            fkMap.get(key)!.push(rec);
          }
        }
      }

      this.indexMaps[tableId] = {
        byPrimaryKey: pkMap,
        byForeignKey: fkMap,
      };
    }
  }

  public getRecordById(tableId: string, recordId: string): RecordData | undefined {
    return this.indexMaps[tableId]?.byPrimaryKey.get(recordId);
  }

  public getRelatedRecords(sourceTableId: string, sourceRecordId: string, targetTableId: string, fkFieldId: string): RecordData[] {
    const key = `${fkFieldId}:${sourceRecordId}`;
    return this.indexMaps[targetTableId]?.byForeignKey.get(key) || [];
  }

  /**
   * Compute dynamic calculated fields (FORMULA, LOOKUP, ROLLUP) for a record
   */
  public computeRecordDynamicValues(tableId: string, record: RecordData): Record<string, any> {
    const table = this.db.tables[tableId];
    if (!table) return record.values;

    const computedValues: Record<string, any> = { ...record.values };
    const fieldNamesToValues: Record<string, any> = {};

    // 1. Build map of field names to values for formula evaluation
    for (const fieldId of table.fieldIds) {
      const field = this.db.fields[fieldId];
      if (field) {
        fieldNamesToValues[field.name] = record.values[fieldId] ?? null;
      }
    }

    // 2. Compute Formulas, Lookups, Rollups
    for (const fieldId of table.fieldIds) {
      const field = this.db.fields[fieldId];
      if (!field) continue;

      if (field.type === FieldType.FORMULA && field.options?.formulaExpression) {
        const val = evaluateFormula(field.options.formulaExpression, fieldNamesToValues);
        computedValues[fieldId] = val;
        fieldNamesToValues[field.name] = val;
      } else if (field.type === FieldType.LOOKUP && field.options) {
        // Lookup target field from relation
        const relationFieldId = field.options.relationTargetTableId; // OR stored in options
        const lookupFieldId = field.options.lookupTargetFieldId;

        if (field.options.relationTargetTableId && lookupFieldId) {
          const fkVal = record.values[field.options.relationTargetTableId];
          if (fkVal) {
            // Find target record
            const targetTableId = this.db.fields[field.options.relationTargetTableId]?.foreignKeyTargetTableId;
            if (targetTableId) {
              const targetRecord = this.getRecordById(targetTableId, String(fkVal));
              if (targetRecord) {
                computedValues[fieldId] = targetRecord.values[lookupFieldId] ?? null;
              }
            }
          }
        }
      } else if (field.type === FieldType.ROLLUP && field.options) {
        // Rollup calculation
        const { rollupTargetRelationFieldId, rollupTargetFieldId, rollupFunction } = field.options;

        if (rollupTargetRelationFieldId && rollupTargetFieldId) {
          const relField = this.db.fields[rollupTargetRelationFieldId];
          if (relField && relField.foreignKeyTargetTableId) {
            const targetTableId = relField.foreignKeyTargetTableId;
            // Find related records in target table where foreign key points to this record
            // OR where this record's FK points to target table
            let related: RecordData[] = [];

            // Check if relField is FK on target table pointing to this record
            const targetTableFKFieldId = relField.id;
            related = this.getRelatedRecords(tableId, record.id, targetTableId, targetTableFKFieldId);

            if (related.length === 0) {
              // Check inverse FK relation
              const fkVal = record.values[relField.id];
              if (fkVal) {
                const targetRec = this.getRecordById(targetTableId, String(fkVal));
                if (targetRec) related = [targetRec];
              }
            }

            const rawValues = related.map((r) => r.values[rollupTargetFieldId]).filter((v) => v !== null && v !== undefined);

            let rollupResult: any = null;
            const numValues = rawValues.map(Number).filter((n) => !isNaN(n));

            switch (rollupFunction) {
              case RollupFunction.COUNT:
                rollupResult = related.length;
                break;
              case RollupFunction.SUM:
                rollupResult = numValues.reduce((acc, curr) => acc + curr, 0);
                break;
              case RollupFunction.AVG:
                rollupResult = numValues.length ? numValues.reduce((acc, curr) => acc + curr, 0) / numValues.length : 0;
                break;
              case RollupFunction.MIN:
                rollupResult = numValues.length ? Math.min(...numValues) : 0;
                break;
              case RollupFunction.MAX:
                rollupResult = numValues.length ? Math.max(...numValues) : 0;
                break;
              case RollupFunction.ARRAY_AGG:
                rollupResult = rawValues.join(', ');
                break;
              default:
                rollupResult = related.length;
            }

            computedValues[fieldId] = rollupResult;
          }
        }
      }
    }

    return computedValues;
  }

  /**
   * Validate referential integrity before deleting a record
   */
  public canDeleteRecord(tableId: string, recordId: string): { allowed: boolean; reason?: string } {
    // Check if any foreign key in other tables references this record
    for (const targetTableId of Object.keys(this.db.tables)) {
      if (targetTableId === tableId) continue;

      const records = this.db.records[targetTableId] || [];
      const tableFields = this.db.tables[targetTableId].fieldIds.map((id) => this.db.fields[id]);

      for (const field of tableFields) {
        if (field?.isForeignKey && field.foreignKeyTargetTableId === tableId) {
          const referencingCount = records.filter((r) => r.values[field.id] === recordId).length;
          if (referencingCount > 0) {
            return {
              allowed: false,
              reason: `Cannot delete record: ${referencingCount} record(s) in table "${this.db.tables[targetTableId].name}" reference this item (Foreign Key Constraint).`,
            };
          }
        }
      }
    }

    return { allowed: true };
  }
}
