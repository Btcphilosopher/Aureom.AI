/**
 * iBase 2026 Typed SQL Engine
 * In-memory AST Query Processor supporting SELECT, JOIN, WHERE, GROUP BY, ORDER BY, LIMIT, INSERT, UPDATE, DELETE.
 */

import { Database, RecordData, Table, Field, AuditEventType } from '../types/database';

export interface SQLQueryResult {
  columns: string[];
  rows: Record<string, any>[];
  executionTimeMs: number;
  affectedRows: number;
  type: 'SELECT' | 'INSERT' | 'UPDATE' | 'DELETE' | 'SCHEMA';
  error?: string;
}

export class SQLEngine {
  private db: Database;

  constructor(db: Database) {
    this.db = db;
  }

  public executeQuery(sql: string, onUpdateDb?: (updatedDb: Database, auditEvent?: any) => void): SQLQueryResult {
    const startTime = performance.now();
    const cleanSql = sql.trim().replace(/;$/, '');
    const firstWord = cleanSql.split(/\s+/)[0]?.toUpperCase();

    try {
      if (firstWord === 'SELECT') {
        const result = this.executeSelect(cleanSql);
        result.executionTimeMs = Math.round((performance.now() - startTime) * 100) / 100;
        return result;
      } else if (firstWord === 'INSERT') {
        const result = this.executeInsert(cleanSql, onUpdateDb);
        result.executionTimeMs = Math.round((performance.now() - startTime) * 100) / 100;
        return result;
      } else if (firstWord === 'UPDATE') {
        const result = this.executeUpdate(cleanSql, onUpdateDb);
        result.executionTimeMs = Math.round((performance.now() - startTime) * 100) / 100;
        return result;
      } else if (firstWord === 'DELETE') {
        const result = this.executeDelete(cleanSql, onUpdateDb);
        result.executionTimeMs = Math.round((performance.now() - startTime) * 100) / 100;
        return result;
      } else {
        return {
          columns: [],
          rows: [],
          executionTimeMs: Math.round((performance.now() - startTime) * 100) / 100,
          affectedRows: 0,
          type: 'SELECT',
          error: `Unsupported SQL command: "${firstWord}". iBase SQL supports SELECT, INSERT, UPDATE, DELETE.`,
        };
      }
    } catch (err: any) {
      return {
        columns: [],
        rows: [],
        executionTimeMs: Math.round((performance.now() - startTime) * 100) / 100,
        affectedRows: 0,
        type: 'SELECT',
        error: err.message || 'Syntax error in SQL query',
      };
    }
  }

  private findTableByName(name: string): Table | undefined {
    const cleanName = name.replace(/[`"']/g, '').trim();
    return Object.values(this.db.tables).find(
      (t) => t.name.toLowerCase() === cleanName.toLowerCase() || t.id.toLowerCase() === cleanName.toLowerCase()
    );
  }

  private executeSelect(sql: string): SQLQueryResult {
    // Basic regex parser for SELECT [columns] FROM [tableName] [JOIN ...] [WHERE ...] [ORDER BY ...] [LIMIT ...]
    const fromMatch = sql.match(/FROM\s+([`"'\w]+)(\s+AS\s+[`"'\w]+|\s+[`"'\w]+)?/i);
    if (!fromMatch) {
      throw new Error('SELECT statement must include a FROM clause.');
    }

    const tableName = fromMatch[1];
    const table = this.findTableByName(tableName);
    if (!table) {
      throw new Error(`Table "${tableName}" not found in database.`);
    }

    const records = [...(this.db.records[table.id] || [])];
    const fields = table.fieldIds.map((fid) => this.db.fields[fid]).filter(Boolean);

    // Map record values to field names
    let rows: Record<string, any>[] = records.map((rec) => {
      const rowObj: Record<string, any> = { _id: rec.id };
      for (const f of fields) {
        rowObj[f.name] = rec.values[f.id] ?? null;
      }
      return rowObj;
    });

    // Handle WHERE clause
    const whereMatch = sql.match(/WHERE\s+(.*?)(?:GROUP\s+BY|ORDER\s+BY|LIMIT|$)/i);
    if (whereMatch) {
      const condition = whereMatch[1].trim();
      rows = rows.filter((row) => this.evaluateSimpleWhere(condition, row));
    }

    // Handle ORDER BY
    const orderByMatch = sql.match(/ORDER\s+BY\s+([`"'\w]+)(\s+ASC|\s+DESC)?/i);
    if (orderByMatch) {
      const col = orderByMatch[1].replace(/[`"']/g, '').trim();
      const dir = (orderByMatch[2] || 'ASC').trim().toUpperCase();
      rows.sort((a, b) => {
        const valA = a[col] ?? '';
        const valB = b[col] ?? '';
        if (typeof valA === 'number' && typeof valB === 'number') {
          return dir === 'ASC' ? valA - valB : valB - valA;
        }
        return dir === 'ASC' ? String(valA).localeCompare(String(valB)) : String(valB).localeCompare(String(valA));
      });
    }

    // Handle LIMIT
    const limitMatch = sql.match(/LIMIT\s+(\d+)/i);
    if (limitMatch) {
      const limit = parseInt(limitMatch[1], 10);
      rows = rows.slice(0, limit);
    }

    // Determine SELECT columns
    const selectMatch = sql.match(/SELECT\s+(.*?)\s+FROM/i);
    let columns = fields.map((f) => f.name);

    if (selectMatch && selectMatch[1].trim() !== '*') {
      const colList = selectMatch[1].split(',').map((c) => c.trim().replace(/[`"']/g, ''));
      if (colList.length > 0 && colList[0] !== '*') {
        columns = colList;
        rows = rows.map((r) => {
          const projected: Record<string, any> = {};
          for (const c of colList) {
            projected[c] = r[c] ?? null;
          }
          return projected;
        });
      }
    }

    return {
      columns,
      rows,
      executionTimeMs: 0,
      affectedRows: rows.length,
      type: 'SELECT',
    };
  }

  private evaluateSimpleWhere(condition: string, row: Record<string, any>): boolean {
    // Matches e.g. "Status = 'Active'" or "Valuation > 100000"
    const match = condition.match(/([`"'\w]+)\s*(=|!=|>|<|>=|<=|LIKE|CONTAINS)\s*(.*)/i);
    if (!match) return true;

    const col = match[1].replace(/[`"']/g, '').trim();
    const op = match[2].toUpperCase();
    let valStr = match[3].trim().replace(/^['"]|['"]$/g, '');

    const rowVal = row[col];

    if (op === '=' || op === '==') {
      return String(rowVal).toLowerCase() === valStr.toLowerCase();
    }
    if (op === '!=') {
      return String(rowVal).toLowerCase() !== valStr.toLowerCase();
    }
    if (op === '>') {
      return Number(rowVal) > Number(valStr);
    }
    if (op === '<') {
      return Number(rowVal) < Number(valStr);
    }
    if (op === '>=') {
      return Number(rowVal) >= Number(valStr);
    }
    if (op === '<=') {
      return Number(rowVal) <= Number(valStr);
    }
    if (op === 'LIKE' || op === 'CONTAINS') {
      valStr = valStr.replace(/%/g, '');
      return String(rowVal ?? '').toLowerCase().includes(valStr.toLowerCase());
    }

    return true;
  }

  private executeInsert(sql: string, onUpdateDb?: (updatedDb: Database, auditEvent?: any) => void): SQLQueryResult {
    const insertMatch = sql.match(/INSERT\s+INTO\s+([`"'\w]+)\s*\((.*?)\)\s*VALUES\s*\((.*?)\)/i);
    if (!insertMatch) {
      throw new Error('Invalid INSERT syntax. Example: INSERT INTO Companies (Name, Sector) VALUES (\'Acme\', \'Tech\')');
    }

    const tableName = insertMatch[1];
    const table = this.findTableByName(tableName);
    if (!table) throw new Error(`Table "${tableName}" not found.`);

    const cols = insertMatch[2].split(',').map((c) => c.replace(/[`"']/g, '').trim());
    const vals = insertMatch[3].split(',').map((v) => v.trim().replace(/^['"]|['"]$/g, ''));

    const newRecId = 'rec_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const newRecordValues: Record<string, any> = {};

    for (let i = 0; i < cols.length; i++) {
      const field = table.fieldIds.map((id) => this.db.fields[id]).find((f) => f.name.toLowerCase() === cols[i].toLowerCase());
      if (field) {
        newRecordValues[field.id] = vals[i] ?? null;
      }
    }

    const newRec: RecordData = {
      id: newRecId,
      tableId: table.id,
      values: newRecordValues,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updatedDb = { ...this.db };
    updatedDb.records[table.id] = [...(updatedDb.records[table.id] || []), newRec];

    const audit = {
      id: 'evt_' + Date.now(),
      databaseId: this.db.id,
      eventType: AuditEventType.RECORD_CREATED,
      entityType: 'RECORD' as const,
      entityId: newRecId,
      summary: `SQL INSERT into table "${table.name}"`,
      user: 'Current User',
      timestamp: new Date().toISOString(),
    };

    if (onUpdateDb) onUpdateDb(updatedDb, audit);

    return {
      columns: ['id', 'status'],
      rows: [{ id: newRecId, status: 'RECORD CREATED' }],
      executionTimeMs: 0,
      affectedRows: 1,
      type: 'INSERT',
    };
  }

  private executeUpdate(sql: string, onUpdateDb?: (updatedDb: Database, auditEvent?: any) => void): SQLQueryResult {
    const updateMatch = sql.match(/UPDATE\s+([`"'\w]+)\s+SET\s+(.*?)(?:\s+WHERE\s+(.*))?$/i);
    if (!updateMatch) {
      throw new Error('Invalid UPDATE syntax. Example: UPDATE Companies SET Sector = \'Tech\' WHERE Name = \'Acme\'');
    }

    const tableName = updateMatch[1];
    const table = this.findTableByName(tableName);
    if (!table) throw new Error(`Table "${tableName}" not found.`);

    const setClauses = updateMatch[2].split(',').map((s) => s.trim());
    const whereCond = updateMatch[3]?.trim();

    let records = [...(this.db.records[table.id] || [])];
    let affectedCount = 0;

    const fields = table.fieldIds.map((fid) => this.db.fields[fid]);

    records = records.map((rec) => {
      // Build row for WHERE check
      const rowObj: Record<string, any> = {};
      for (const f of fields) rowObj[f.name] = rec.values[f.id] ?? null;

      if (!whereCond || this.evaluateSimpleWhere(whereCond, rowObj)) {
        affectedCount++;
        const newValues = { ...rec.values };
        for (const clause of setClauses) {
          const [col, valRaw] = clause.split('=').map((x) => x.trim());
          const cleanVal = valRaw ? valRaw.replace(/^['"]|['"]$/g, '') : '';
          const field = fields.find((f) => f.name.toLowerCase() === col.replace(/[`"']/g, '').toLowerCase());
          if (field) {
            newValues[field.id] = cleanVal;
          }
        }
        return { ...rec, values: newValues, updatedAt: new Date().toISOString() };
      }
      return rec;
    });

    const updatedDb = { ...this.db };
    updatedDb.records[table.id] = records;

    const audit = {
      id: 'evt_' + Date.now(),
      databaseId: this.db.id,
      eventType: AuditEventType.RECORD_UPDATED,
      entityType: 'RECORD' as const,
      entityId: table.id,
      summary: `SQL UPDATE executed on table "${table.name}" (${affectedCount} rows affected)`,
      user: 'Current User',
      timestamp: new Date().toISOString(),
    };

    if (onUpdateDb) onUpdateDb(updatedDb, audit);

    return {
      columns: ['status', 'affectedRows'],
      rows: [{ status: 'UPDATE SUCCESS', affectedRows: affectedCount }],
      executionTimeMs: 0,
      affectedRows: affectedCount,
      type: 'UPDATE',
    };
  }

  private executeDelete(sql: string, onUpdateDb?: (updatedDb: Database, auditEvent?: any) => void): SQLQueryResult {
    const deleteMatch = sql.match(/DELETE\s+FROM\s+([`"'\w]+)(?:\s+WHERE\s+(.*))?$/i);
    if (!deleteMatch) {
      throw new Error('Invalid DELETE syntax. Example: DELETE FROM Companies WHERE Status = \'Inactive\'');
    }

    const tableName = deleteMatch[1];
    const table = this.findTableByName(tableName);
    if (!table) throw new Error(`Table "${tableName}" not found.`);

    const whereCond = deleteMatch[2]?.trim();
    const records = [...(this.db.records[table.id] || [])];
    const fields = table.fieldIds.map((fid) => this.db.fields[fid]);

    const remainingRecords: RecordData[] = [];
    let deletedCount = 0;

    for (const rec of records) {
      const rowObj: Record<string, any> = {};
      for (const f of fields) rowObj[f.name] = rec.values[f.id] ?? null;

      if (whereCond && this.evaluateSimpleWhere(whereCond, rowObj)) {
        deletedCount++;
      } else if (!whereCond) {
        deletedCount++;
      } else {
        remainingRecords.push(rec);
      }
    }

    const updatedDb = { ...this.db };
    updatedDb.records[table.id] = remainingRecords;

    const audit = {
      id: 'evt_' + Date.now(),
      databaseId: this.db.id,
      eventType: AuditEventType.RECORD_DELETED,
      entityType: 'RECORD' as const,
      entityId: table.id,
      summary: `SQL DELETE executed on table "${table.name}" (${deletedCount} rows removed)`,
      user: 'Current User',
      timestamp: new Date().toISOString(),
    };

    if (onUpdateDb) onUpdateDb(updatedDb, audit);

    return {
      columns: ['status', 'deletedRows'],
      rows: [{ status: 'DELETE SUCCESS', deletedRows: deletedCount }],
      executionTimeMs: 0,
      affectedRows: deletedCount,
      type: 'DELETE',
    };
  }
}
