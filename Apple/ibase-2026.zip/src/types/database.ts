/**
 * iBase 2026 Canonical Data Model
 */

export enum FieldType {
  TEXT = 'TEXT',
  LONG_TEXT = 'LONG_TEXT',
  INTEGER = 'INTEGER',
  BIG_INTEGER = 'BIG_INTEGER',
  DECIMAL = 'DECIMAL',
  CURRENCY = 'CURRENCY',
  PERCENTAGE = 'PERCENTAGE',
  BOOLEAN = 'BOOLEAN',
  DATE = 'DATE',
  TIME = 'TIME',
  DATETIME = 'DATETIME',
  DURATION = 'DURATION',
  EMAIL = 'EMAIL',
  PHONE = 'PHONE',
  URL = 'URL',
  ENUM = 'ENUM',
  MULTI_ENUM = 'MULTI_ENUM',
  JSON = 'JSON',
  IMAGE = 'IMAGE',
  FILE = 'FILE',
  LOCATION = 'LOCATION',
  FORMULA = 'FORMULA',
  RELATION = 'RELATION',
  LOOKUP = 'LOOKUP',
  ROLLUP = 'ROLLUP',
}

export enum RelationshipType {
  ONE_TO_ONE = 'ONE_TO_ONE',
  ONE_TO_MANY = 'ONE_TO_MANY',
  MANY_TO_MANY = 'MANY_TO_MANY',
}

export enum ViewType {
  TABLE = 'TABLE',
  LIST = 'LIST',
  CARD = 'CARD',
  KANBAN = 'KANBAN',
  CALENDAR = 'CALENDAR',
  TIMELINE = 'TIMELINE',
  GALLERY = 'GALLERY',
  MAP = 'MAP',
}

export enum ConstraintType {
  PRIMARY_KEY = 'PRIMARY_KEY',
  FOREIGN_KEY = 'FOREIGN_KEY',
  UNIQUE = 'UNIQUE',
  NOT_NULL = 'NOT_NULL',
  CHECK = 'CHECK',
  INDEX = 'INDEX',
}

export enum RollupFunction {
  COUNT = 'COUNT',
  SUM = 'SUM',
  AVG = 'AVG',
  MIN = 'MIN',
  MAX = 'MAX',
  ARRAY_AGG = 'ARRAY_AGG',
}

export interface FieldOptions {
  enumChoices?: string[];
  currencySymbol?: string; // e.g., '£', '$', '€'
  decimalPlaces?: number;
  formulaExpression?: string; // e.g. "[Quantity] * [Price]"
  relationTargetTableId?: string;
  relationType?: RelationshipType;
  lookupTargetFieldId?: string;
  rollupTargetRelationFieldId?: string;
  rollupTargetFieldId?: string;
  rollupFunction?: RollupFunction;
  defaultValue?: any;
  required?: boolean;
  unique?: boolean;
}

export interface Field {
  id: string;
  tableId: string;
  name: string;
  type: FieldType;
  options?: FieldOptions;
  description?: string;
  isPrimaryKey?: boolean;
  isForeignKey?: boolean;
  foreignKeyTargetTableId?: string;
  foreignKeyTargetFieldId?: string;
}

export type RecordValue = string | number | boolean | null | string[] | Record<string, any>;

export interface RecordData {
  id: string; // Unique record identifier
  tableId: string;
  values: Record<string, RecordValue>; // fieldId -> value
  createdAt: string; // ISO string
  updatedAt: string; // ISO string
}

export interface Table {
  id: string;
  databaseId: string;
  name: string;
  description?: string;
  color?: string;
  icon?: string;
  fieldIds: string[];
  primaryKeyFieldId: string;
  createdAt: string;
  updatedAt: string;
}

export interface Relationship {
  id: string;
  databaseId: string;
  name: string;
  type: RelationshipType;
  sourceTableId: string;
  sourceFieldId: string;
  targetTableId: string;
  targetFieldId: string;
  onDelete?: 'CASCADE' | 'SET_NULL' | 'RESTRICT';
}

export interface FilterRule {
  id: string;
  fieldId: string;
  operator: 'equals' | 'not_equals' | 'contains' | 'not_contains' | 'greater_than' | 'less_than' | 'is_empty' | 'is_not_empty' | 'in';
  value: any;
}

export interface FilterGroup {
  conjunction: 'AND' | 'OR';
  rules: (FilterRule | FilterGroup)[];
}

export interface SortRule {
  fieldId: string;
  direction: 'asc' | 'desc';
}

export interface View {
  id: string;
  tableId: string;
  name: string;
  type: ViewType;
  filterGroup?: FilterGroup;
  sortRules?: SortRule[];
  groupByFieldId?: string;
  visibleFieldIds?: string[];
  kanbanStatusFieldId?: string;
  calendarDateFieldId?: string;
  timelineStartFieldId?: string;
  timelineEndFieldId?: string;
  imageFieldId?: string;
  locationFieldId?: string;
  isDefault?: boolean;
}

export interface FormFieldConfig {
  fieldId: string;
  label: string;
  placeholder?: string;
  helpText?: string;
  required?: boolean;
  hidden?: boolean;
}

export interface FormSection {
  id: string;
  title: string;
  description?: string;
  fieldConfigs: FormFieldConfig[];
}

export interface Form {
  id: string;
  tableId: string;
  name: string;
  description?: string;
  sections: FormSection[];
  createdAt: string;
}

export interface SavedQuery {
  id: string;
  databaseId: string;
  name: string;
  type: 'VISUAL' | 'SQL';
  sqlText?: string;
  ast?: any;
  createdAt: string;
}

export enum AuditEventType {
  DATABASE_CREATED = 'DATABASE_CREATED',
  TABLE_CREATED = 'TABLE_CREATED',
  FIELD_CREATED = 'FIELD_CREATED',
  FIELD_CHANGED = 'FIELD_CHANGED',
  RECORD_CREATED = 'RECORD_CREATED',
  RECORD_UPDATED = 'RECORD_UPDATED',
  RECORD_DELETED = 'RECORD_DELETED',
  QUERY_EXECUTED = 'QUERY_EXECUTED',
  EXPORT_CREATED = 'EXPORT_CREATED',
  PERMISSION_CHANGED = 'PERMISSION_CHANGED',
  SCHEMA_CHANGED = 'SCHEMA_CHANGED',
  IMPORT_COMPLETED = 'IMPORT_COMPLETED',
  TRANSACTION_COMMITTED = 'TRANSACTION_COMMITTED',
  TRANSACTION_ROLLED_BACK = 'TRANSACTION_ROLLED_BACK',
}

export interface AuditEvent {
  id: string;
  databaseId: string;
  eventType: AuditEventType;
  entityType: 'DATABASE' | 'TABLE' | 'FIELD' | 'RECORD' | 'QUERY' | 'IMPORT' | 'EXPORT';
  entityId: string;
  summary: string;
  details?: Record<string, any>;
  user: string;
  timestamp: string;
}

export interface Database {
  id: string;
  name: string;
  description: string;
  icon?: string;
  color?: string;
  isFavourite?: boolean;
  isShared?: boolean;
  createdAt: string;
  updatedAt: string;
  tables: Record<string, Table>;
  fields: Record<string, Field>;
  records: Record<string, RecordData[]>; // tableId -> records list
  relationships: Record<string, Relationship>;
  views: Record<string, View[]>; // tableId -> views
  forms: Record<string, Form[]>; // tableId -> forms
  savedQueries: SavedQuery[];
  auditLogs: AuditEvent[];
}

export interface DatabaseTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  color: string;
  buildDatabase: () => Database;
}
