/**
 * iBase 2026 Master Application Root
 * "Simple on the surface, powerful underneath."
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { StatusBar } from './components/StatusBar';
import { WelcomeScreen } from './components/WelcomeScreen';
import { VirtualTableView } from './components/TableView/VirtualTableView';
import { SchemaCanvas } from './components/SchemaCanvas/SchemaCanvas';
import { RecordInspector } from './components/Inspector/RecordInspector';
import { QueryBuilder } from './components/QueryBuilder/QueryBuilder';
import { SQLEditor } from './components/SQLEditor/SQLEditor';
import { FormBuilder } from './components/FormBuilder/FormBuilder';
import { ViewRenderer } from './components/Views/ViewRenderers';
import { CommandPalette } from './components/CommandPalette';
import { ImportExportModal } from './components/ImportExportModal';
import { AuditLogModal } from './components/AuditLogModal';

import { Database, ViewType, FieldType, AuditEventType, Table, RecordData, RelationshipType } from './types/database';
import { RelationalEngine } from './engine/relationalEngine';
import { ParseResult } from './engine/importExportEngine';
import { createSheffieldInvestmentDatabase, TEMPLATES_LIST } from './data/templates';

export default function App() {
  // Initialize default database with Sheffield Investment Database master demo
  const [currentDb, setCurrentDb] = useState<Database | null>(() => createSheffieldInvestmentDatabase());
  const [recentDatabases, setRecentDatabases] = useState<Database[]>(() => [createSheffieldInvestmentDatabase()]);

  // Active view states
  const [activeTableId, setActiveTableId] = useState<string | null>(() => {
    const defaultDb = createSheffieldInvestmentDatabase();
    return Object.keys(defaultDb.tables)[0] || null;
  });

  const [activeViewId, setActiveViewId] = useState<string | null>('v_c_grid');
  const [activeTab, setActiveTab] = useState<'data' | 'schema' | 'query' | 'sql' | 'forms' | 'audit'>('data');

  // Inspector & Modals
  const [inspectedRecordId, setInspectedRecordId] = useState<string | null>(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isImportExportOpen, setIsImportExportOpen] = useState(false);
  const [isAuditLogOpen, setIsAuditLogOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // Undo / Redo History Stack
  const [undoStack, setUndoStack] = useState<Database[]>([]);
  const [redoStack, setRedoStack] = useState<Database[]>([]);

  // Dark mode effect
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Relational Engine Memo
  const relationalEngine = useMemo(() => {
    if (!currentDb) return new RelationalEngine(createSheffieldInvestmentDatabase());
    return new RelationalEngine(currentDb);
  }, [currentDb]);

  // Helper to push database state to undo stack
  const commitDbState = (newDb: Database, auditSummary?: string, eventType?: AuditEventType) => {
    if (!currentDb) return;
    setUndoStack((prev) => [...prev, currentDb]);
    setRedoStack([]);

    if (auditSummary && eventType) {
      const auditEvt = {
        id: 'evt_' + Date.now(),
        databaseId: newDb.id,
        eventType,
        entityType: 'DATABASE' as const,
        entityId: newDb.id,
        summary: auditSummary,
        user: 'Current User',
        timestamp: new Date().toISOString(),
      };
      newDb.auditLogs = [auditEvt, ...(newDb.auditLogs || [])];
    }

    setCurrentDb(newDb);
  };

  // Record CRUD handlers
  const handleUpdateRecord = (tableId: string, recordId: string, fieldId: string, value: any) => {
    if (!currentDb) return;
    const tableRecords = [...(currentDb.records[tableId] || [])];
    const recIndex = tableRecords.findIndex((r) => r.id === recordId);
    if (recIndex === -1) return;

    const oldRec = tableRecords[recIndex];
    const updatedRec: RecordData = {
      ...oldRec,
      values: { ...oldRec.values, [fieldId]: value },
      updatedAt: new Date().toISOString(),
    };

    tableRecords[recIndex] = updatedRec;
    const newDb = {
      ...currentDb,
      records: { ...currentDb.records, [tableId]: tableRecords },
    };

    commitDbState(newDb, `Updated record "${recordId}" in table "${currentDb.tables[tableId]?.name}"`, AuditEventType.RECORD_UPDATED);
  };

  const handleAddRecord = (tableId: string) => {
    if (!currentDb) return;
    const table = currentDb.tables[tableId];
    if (!table) return;

    const newRecId = 'rec_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5);
    const initialValues: Record<string, any> = {};

    // Populate primary key
    initialValues[table.primaryKeyFieldId] = `${table.name.slice(0, 4).toUpperCase()}_${Date.now().toString().slice(-4)}`;

    const newRecord: RecordData = {
      id: newRecId,
      tableId,
      values: initialValues,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const newDb = {
      ...currentDb,
      records: {
        ...currentDb.records,
        [tableId]: [newRecord, ...(currentDb.records[tableId] || [])],
      },
    };

    commitDbState(newDb, `Added new record to table "${table.name}"`, AuditEventType.RECORD_CREATED);
  };

  const handleAddRecordWithValues = (tableId: string, values: Record<string, any>) => {
    if (!currentDb) return;
    const table = currentDb.tables[tableId];
    if (!table) return;

    const newRecId = 'rec_' + Date.now().toString(36);
    const newRecord: RecordData = {
      id: newRecId,
      tableId,
      values,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const newDb = {
      ...currentDb,
      records: {
        ...currentDb.records,
        [tableId]: [newRecord, ...(currentDb.records[tableId] || [])],
      },
    };

    commitDbState(newDb, `Form submitted new record to table "${table.name}"`, AuditEventType.RECORD_CREATED);
  };

  const handleDeleteRecords = (tableId: string, recordIds: string[]) => {
    if (!currentDb) return;
    const currentRecords = currentDb.records[tableId] || [];
    const remaining = currentRecords.filter((r) => !recordIds.includes(r.id));

    const newDb = {
      ...currentDb,
      records: { ...currentDb.records, [tableId]: remaining },
    };

    commitDbState(newDb, `Deleted ${recordIds.length} record(s) from table "${currentDb.tables[tableId]?.name}"`, AuditEventType.RECORD_DELETED);
  };

  const handleDuplicateRecord = (tableId: string, recordId: string) => {
    if (!currentDb) return;
    const rec = (currentDb.records[tableId] || []).find((r) => r.id === recordId);
    if (!rec) return;

    const newRecId = 'rec_' + Date.now().toString(36);
    const dupRec: RecordData = {
      ...rec,
      id: newRecId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const newDb = {
      ...currentDb,
      records: {
        ...currentDb.records,
        [tableId]: [dupRec, ...(currentDb.records[tableId] || [])],
      },
    };

    commitDbState(newDb, `Duplicated record in table "${currentDb.tables[tableId]?.name}"`, AuditEventType.RECORD_CREATED);
  };

  // Schema Table & Field Handlers
  const handleCreateTable = () => {
    if (!currentDb) return;
    const count = Object.keys(currentDb.tables).length + 1;
    const tableId = `tbl_custom_${Date.now().toString(36)}`;
    const pkFieldId = `f_${tableId}_pk`;
    const nameFieldId = `f_${tableId}_name`;

    const newTable: Table = {
      id: tableId,
      databaseId: currentDb.id,
      name: `Table ${count}`,
      description: 'Custom table',
      color: '#0284c7',
      fieldIds: [pkFieldId, nameFieldId],
      primaryKeyFieldId: pkFieldId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const newFields = {
      ...currentDb.fields,
      [pkFieldId]: { id: pkFieldId, tableId, name: 'ID', type: FieldType.TEXT, isPrimaryKey: true },
      [nameFieldId]: { id: nameFieldId, tableId, name: 'Item Name', type: FieldType.TEXT },
    };

    const newDb = {
      ...currentDb,
      tables: { ...currentDb.tables, [tableId]: newTable },
      fields: newFields,
      records: { ...currentDb.records, [tableId]: [] },
      views: {
        ...currentDb.views,
        [tableId]: [{ id: `v_${tableId}_grid`, tableId, name: 'Grid View', type: ViewType.TABLE, isDefault: true }],
      },
    };

    setActiveTableId(tableId);
    setActiveViewId(`v_${tableId}_grid`);
    commitDbState(newDb, `Created new table "${newTable.name}"`, AuditEventType.TABLE_CREATED);
  };

  const handleAddField = () => {
    if (!currentDb || !activeTableId) return;
    const table = currentDb.tables[activeTableId];
    if (!table) return;

    const fieldId = `f_${activeTableId}_${Date.now().toString(36)}`;
    const count = table.fieldIds.length + 1;
    const fieldName = `New Field ${count}`;

    const newField = {
      id: fieldId,
      tableId: activeTableId,
      name: fieldName,
      type: FieldType.TEXT,
    };

    const updatedTable = {
      ...table,
      fieldIds: [...table.fieldIds, fieldId],
    };

    const newDb = {
      ...currentDb,
      tables: { ...currentDb.tables, [activeTableId]: updatedTable },
      fields: { ...currentDb.fields, [fieldId]: newField },
    };

    commitDbState(newDb, `Added field "${fieldName}" to table "${table.name}"`, AuditEventType.FIELD_CREATED);
  };

  const handleDeleteTable = (tableId: string) => {
    if (!currentDb) return;
    const { [tableId]: deletedTable, ...remainingTables } = currentDb.tables;

    const newDb = {
      ...currentDb,
      tables: remainingTables,
    };

    const firstRemaining = Object.keys(remainingTables)[0] || null;
    setActiveTableId(firstRemaining);
    commitDbState(newDb, `Deleted table "${deletedTable?.name}"`, AuditEventType.SCHEMA_CHANGED);
  };

  const handleAddRelationship = (sourceTableId: string, targetTableId: string, type: RelationshipType) => {
    if (!currentDb) return;
    const relId = `rel_${Date.now()}`;
    const newRel = {
      id: relId,
      databaseId: currentDb.id,
      name: `Link`,
      type,
      sourceTableId,
      sourceFieldId: currentDb.tables[sourceTableId]?.primaryKeyFieldId || '',
      targetTableId,
      targetFieldId: currentDb.tables[targetTableId]?.primaryKeyFieldId || '',
    };

    const newDb = {
      ...currentDb,
      relationships: { ...currentDb.relationships, [relId]: newRel },
    };

    commitDbState(newDb, `Established ${type} relationship`, AuditEventType.SCHEMA_CHANGED);
  };

  // Import handler
  const handleImportTable = (parseResult: ParseResult) => {
    if (!currentDb) return;

    const tableId = `tbl_imp_${Date.now().toString(36)}`;
    const pkFieldId = `f_${tableId}_pk`;

    const fieldIds: string[] = [pkFieldId];
    const newFields: Record<string, any> = {
      [pkFieldId]: { id: pkFieldId, tableId, name: 'Import ID', type: FieldType.TEXT, isPrimaryKey: true },
    };

    parseResult.columns.forEach((col, idx) => {
      const fid = `f_${tableId}_${idx + 1}`;
      fieldIds.push(fid);
      newFields[fid] = {
        id: fid,
        tableId,
        name: col.name,
        type: col.inferredType,
      };
    });

    const newTable: Table = {
      id: tableId,
      databaseId: currentDb.id,
      name: parseResult.tableName,
      fieldIds,
      primaryKeyFieldId: pkFieldId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const importedRecords: RecordData[] = parseResult.rows.map((row, idx) => {
      const rId = `rec_imp_${idx + 1}`;
      const values: Record<string, any> = { [pkFieldId]: rId };
      parseResult.columns.forEach((col, cIdx) => {
        const fid = fieldIds[cIdx + 1];
        values[fid] = row[col.name];
      });
      return { id: rId, tableId, values, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    });

    const newDb = {
      ...currentDb,
      tables: { ...currentDb.tables, [tableId]: newTable },
      fields: { ...currentDb.fields, ...newFields },
      records: { ...currentDb.records, [tableId]: importedRecords },
      views: {
        ...currentDb.views,
        [tableId]: [{ id: `v_${tableId}_grid`, tableId, name: 'Grid View', type: ViewType.TABLE, isDefault: true }],
      },
    };

    setActiveTableId(tableId);
    setActiveViewId(`v_${tableId}_grid`);
    commitDbState(newDb, `Imported table "${parseResult.tableName}" with ${importedRecords.length} records`, AuditEventType.IMPORT_COMPLETED);
  };

  // Template & Blank creation
  const handleSelectTemplate = (templateId: string) => {
    const tmpl = TEMPLATES_LIST.find((t) => t.id === templateId) || TEMPLATES_LIST[0];
    const newDb = tmpl.buildDatabase();

    setCurrentDb(newDb);
    setRecentDatabases((prev) => [newDb, ...prev.filter((d) => d.id !== newDb.id)]);
    const firstTableId = Object.keys(newDb.tables)[0] || null;
    setActiveTableId(firstTableId);
    if (firstTableId && newDb.views[firstTableId]?.[0]) {
      setActiveViewId(newDb.views[firstTableId][0].id);
    }
  };

  const handleCreateBlankDatabase = (name: string) => {
    const dbId = `db_${Date.now()}`;
    const now = new Date().toISOString();
    const newDb: Database = {
      id: dbId,
      name,
      description: 'Custom relational database',
      createdAt: now,
      updatedAt: now,
      tables: {},
      fields: {},
      records: {},
      relationships: {},
      views: {},
      forms: {},
      savedQueries: [],
      auditLogs: [],
    };

    setCurrentDb(newDb);
    setRecentDatabases((prev) => [newDb, ...prev]);
    setActiveTableId(null);
  };

  // Undo / Redo
  const handleUndo = () => {
    if (undoStack.length === 0 || !currentDb) return;
    const previous = undoStack[undoStack.length - 1];
    setRedoStack((prev) => [currentDb, ...prev]);
    setUndoStack((prev) => prev.slice(0, -1));
    setCurrentDb(previous);
  };

  const handleRedo = () => {
    if (redoStack.length === 0 || !currentDb) return;
    const next = redoStack[0];
    setUndoStack((prev) => [...prev, currentDb]);
    setRedoStack((prev) => prev.slice(1));
    setCurrentDb(next);
  };

  // Active view object
  const activeView = activeTableId && activeViewId ? (currentDb?.views[activeTableId] || []).find((v) => v.id === activeViewId) : null;

  if (!currentDb) {
    return (
      <WelcomeScreen
        recentDatabases={recentDatabases}
        onSelectDatabase={setCurrentDb}
        onCreateBlankDatabase={handleCreateBlankDatabase}
        onSelectTemplate={handleSelectTemplate}
        onOpenImport={() => setIsImportExportOpen(true)}
      />
    );
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-[#f8f9fa] dark:bg-[#0e0f12] text-zinc-900 dark:text-zinc-100 overflow-hidden font-sans antialiased">
      {/* Top Header */}
      <Header
        currentDb={currentDb}
        activeTableId={activeTableId}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        onOpenImportExport={() => setIsImportExportOpen(true)}
        onOpenAuditLog={() => setIsAuditLogOpen(true)}
        onSelectDatabaseClick={() => setCurrentDb(null)}
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        onNewRecordClick={() => activeTableId && handleAddRecord(activeTableId)}
      />

      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <Sidebar
          currentDb={currentDb}
          activeTableId={activeTableId}
          onSelectTable={(tId) => {
            setActiveTableId(tId);
            const defaultV = currentDb.views[tId]?.[0]?.id || null;
            setActiveViewId(defaultV);
          }}
          activeViewId={activeViewId}
          onSelectView={setActiveViewId}
          onCreateTableClick={handleCreateTable}
          onDeleteTableClick={handleDeleteTable}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onCreateViewClick={(type) => {
            if (!activeTableId) return;
            const viewId = `v_${activeTableId}_${Date.now()}`;
            const newView = { id: viewId, tableId: activeTableId, name: `${type} View`, type };
            const updatedViews = [...(currentDb.views[activeTableId] || []), newView];
            setCurrentDb({ ...currentDb, views: { ...currentDb.views, [activeTableId]: updatedViews } });
            setActiveViewId(viewId);
          }}
        />

        {/* Center Workspace Area */}
        <main className="flex-1 flex flex-col relative overflow-hidden bg-white dark:bg-[#111317]">
          {activeTab === 'data' && activeTableId && (
            activeView && activeView.type !== ViewType.TABLE ? (
              <ViewRenderer
                currentDb={currentDb}
                activeTableId={activeTableId}
                view={activeView}
                onSelectRecord={setInspectedRecordId}
                relationalEngine={relationalEngine}
                onUpdateRecord={handleUpdateRecord}
              />
            ) : (
              <VirtualTableView
                currentDb={currentDb}
                activeTableId={activeTableId}
                onUpdateRecord={handleUpdateRecord}
                onAddRecord={() => handleAddRecord(activeTableId)}
                onDeleteRecords={handleDeleteRecords}
                onDuplicateRecord={handleDuplicateRecord}
                onSelectRecordForInspector={setInspectedRecordId}
                relationalEngine={relationalEngine}
                onAddFieldClick={handleAddField}
              />
            )
          )}

          {activeTab === 'schema' && (
            <SchemaCanvas
              currentDb={currentDb}
              onCreateTable={handleCreateTable}
              onDeleteTable={handleDeleteTable}
              onAddRelationship={handleAddRelationship}
              onSelectTable={(tId) => {
                setActiveTableId(tId);
                setActiveTab('data');
              }}
            />
          )}

          {activeTab === 'query' && activeTableId && (
            <QueryBuilder currentDb={currentDb} activeTableId={activeTableId} />
          )}

          {activeTab === 'sql' && (
            <SQLEditor
              currentDb={currentDb}
              onUpdateDatabase={(newDb, audit) => {
                commitDbState(newDb, audit?.summary, audit?.eventType);
              }}
            />
          )}

          {activeTab === 'forms' && activeTableId && (
            <FormBuilder
              currentDb={currentDb}
              activeTableId={activeTableId}
              onAddRecordWithValues={handleAddRecordWithValues}
            />
          )}
        </main>

        {/* Right Slide-over Inspector */}
        {inspectedRecordId && activeTableId && (
          <RecordInspector
            currentDb={currentDb}
            activeTableId={activeTableId}
            recordId={inspectedRecordId}
            onClose={() => setInspectedRecordId(null)}
            onUpdateRecord={handleUpdateRecord}
            onSelectRecord={(tId, rId) => {
              setActiveTableId(tId);
              setInspectedRecordId(rId);
            }}
            relationalEngine={relationalEngine}
          />
        )}
      </div>

      {/* Bottom Status Bar */}
      <StatusBar
        currentDb={currentDb}
        activeTableId={activeTableId}
        selectedRecordIds={[]}
        canUndo={undoStack.length > 0}
        canRedo={redoStack.length > 0}
        onUndo={handleUndo}
        onRedo={handleRedo}
      />

      {/* Global Modals */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        currentDb={currentDb}
        onSelectTable={(tId) => {
          setActiveTableId(tId);
          setActiveTab('data');
        }}
        onSelectRecord={(tId, rId) => {
          setActiveTableId(tId);
          setActiveTab('data');
          setInspectedRecordId(rId);
        }}
        onExecuteAction={(act) => {
          if (act === 'new_db') setCurrentDb(null);
          if (act === 'new_table') handleCreateTable();
          if (act === 'add_record' && activeTableId) handleAddRecord(activeTableId);
          if (act === 'schema') setActiveTab('schema');
          if (act === 'sql') setActiveTab('sql');
          if (act === 'import') setIsImportExportOpen(true);
          if (act === 'export') setIsImportExportOpen(true);
        }}
      />

      <ImportExportModal
        isOpen={isImportExportOpen}
        onClose={() => setIsImportExportOpen(false)}
        currentDb={currentDb}
        activeTableId={activeTableId}
        onImportTable={handleImportTable}
      />

      <AuditLogModal
        isOpen={isAuditLogOpen}
        onClose={() => setIsAuditLogOpen(false)}
        currentDb={currentDb}
      />
    </div>
  );
}
