import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../services/document.service';
import { DocumentModel } from '../../models/document.model';

interface PresetTemplate {
  name: string;
  icon: string;
  description: string;
  builder: () => DocumentModel;
}

@Component({
  selector: 'app-sidebar-left',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-64 bg-[#ECECEE] border-r border-[#C6C6C8] flex flex-col h-full text-[#1D1D1F] select-none shrink-0">
      <!-- Sidebar Navigation Tabs -->
      <div class="flex items-center border-b border-[#C6C6C8] bg-[#E5E5E7] p-1 gap-1 text-xs shrink-0">
        <button
          type="button"
          (click)="activeTab.set('pages')"
          class="flex-1 py-1 rounded transition-colors cursor-pointer flex items-center justify-center gap-1 font-medium"
          [class.bg-white]="activeTab() === 'pages'"
          [class.text-[#1D1D1F]]="activeTab() === 'pages'"
          [class.border]="activeTab() === 'pages'"
          [class.border-[#C6C6C8]]="activeTab() === 'pages'"
          [class.shadow-2xs]="activeTab() === 'pages'"
          [class.text-[#4D4D4F]]="activeTab() !== 'pages'">
          <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5">content_copy</mat-icon>
          <span>Pages ({{ docService.document().pages.length }})</span>
        </button>

        <button
          type="button"
          (click)="activeTab.set('templates')"
          class="flex-1 py-1 rounded transition-colors cursor-pointer flex items-center justify-center gap-1 font-medium"
          [class.bg-white]="activeTab() === 'templates'"
          [class.text-[#1D1D1F]]="activeTab() === 'templates'"
          [class.border]="activeTab() === 'templates'"
          [class.border-[#C6C6C8]]="activeTab() === 'templates'"
          [class.shadow-2xs]="activeTab() === 'templates'"
          [class.text-[#4D4D4F]]="activeTab() !== 'templates'">
          <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5 text-amber-600">dashboard</mat-icon>
          <span>Templates</span>
        </button>

        <button
          type="button"
          (click)="activeTab.set('dataset')"
          class="flex-1 py-1 rounded transition-colors cursor-pointer flex items-center justify-center gap-1 font-medium"
          [class.bg-white]="activeTab() === 'dataset'"
          [class.text-[#1D1D1F]]="activeTab() === 'dataset'"
          [class.border]="activeTab() === 'dataset'"
          [class.border-[#C6C6C8]]="activeTab() === 'dataset'"
          [class.shadow-2xs]="activeTab() === 'dataset'"
          [class.text-[#4D4D4F]]="activeTab() !== 'dataset'">
          <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5 text-emerald-600">data_object</mat-icon>
          <span>Batch Data</span>
        </button>
      </div>

      <!-- Tab Content Area -->
      <div class="flex-1 overflow-y-auto p-3 custom-scrollbar">
        <!-- TAB 1: PAGES THUMBNAILS -->
        @if (activeTab() === 'pages') {
          <div class="space-y-3">
            <div class="px-1 text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Document Pages</div>
            @for (page of docService.document().pages; track page.id; let idx = $index) {
              <div
                tabindex="0"
                role="button"
                (click)="docService.activePageIndex.set(idx)"
                (keyup.enter)="docService.activePageIndex.set(idx)"
                class="group relative rounded-lg border p-2 transition-all cursor-pointer bg-white shadow-2xs"
                [class.border-[#007AFF]]="docService.activePageIndex() === idx"
                [class.ring-2]="docService.activePageIndex() === idx"
                [class.ring-[#007AFF]/20]="docService.activePageIndex() === idx"
                [class.border-[#C6C6C8]]="docService.activePageIndex() !== idx"
                [class.hover:border-[#007AFF]]="docService.activePageIndex() !== idx">

                <div class="flex items-center justify-between mb-1.5 px-1">
                  <span class="text-[11px] font-semibold text-[#1D1D1F]">Page {{ idx + 1 }}</span>
                  <div class="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      (click)="$event.stopPropagation(); docService.duplicatePage(idx)"
                      class="p-0.5 hover:text-[#007AFF] text-[#8E8E93]" title="Duplicate Page">
                      <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5">control_point_duplicate</mat-icon>
                    </button>
                    @if (docService.document().pages.length > 1) {
                      <button
                        type="button"
                        (click)="$event.stopPropagation(); docService.deletePage(idx)"
                        class="p-0.5 hover:text-red-600 text-[#8E8E93]" title="Delete Page">
                        <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5">delete</mat-icon>
                      </button>
                    }
                  </div>
                </div>

                <!-- Page Thumbnail Visual Box -->
                <div class="w-full aspect-[1/1.3] bg-[#F5F5F7] rounded shadow-inner border border-[#C6C6C8] overflow-hidden relative flex flex-col p-2 text-[#1D1D1F] select-none">
                  <div class="text-[7px] font-bold text-[#1D1D1F] border-b border-[#C6C6C8] pb-0.5 truncate">
                    {{ page.elements[0]?.text || 'Page ' + (idx + 1) }}
                  </div>
                  <div class="flex-1 space-y-1 mt-1">
                    @for (el of page.elements.slice(1, 4); track el.id) {
                      <div class="h-1 bg-[#C6C6C8] rounded w-full"></div>
                    }
                  </div>
                  <div class="text-[6px] text-[#8E8E93] text-right">A4 PDF</div>
                </div>
              </div>
            }

            <button
              type="button"
              (click)="docService.addPage()"
              class="w-full py-2 border-2 border-dashed border-[#C6C6C8] hover:border-[#007AFF] rounded-lg text-xs font-medium text-[#4D4D4F] hover:text-[#007AFF] flex items-center justify-center gap-1.5 transition-colors cursor-pointer bg-white/50">
              <mat-icon class="text-sm w-4 h-4 leading-4 text-[#007AFF]">add_circle</mat-icon>
              <span>Add Page</span>
            </button>
          </div>
        }

        <!-- TAB 2: TEMPLATES -->
        @if (activeTab() === 'templates') {
          <div class="space-y-3">
            <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider mb-2">Preset Layouts</div>
            @for (tmpl of presetTemplates; track tmpl.name) {
              <div
                tabindex="0"
                role="button"
                (click)="loadPreset(tmpl)"
                (keyup.enter)="loadPreset(tmpl)"
                class="p-2.5 bg-white hover:bg-gray-50 rounded-lg border border-[#C6C6C8] hover:border-[#007AFF] transition-all cursor-pointer shadow-2xs group">
                <div class="flex items-center gap-2 mb-1">
                  <mat-icon class="text-[#007AFF] text-sm w-4 h-4 leading-4">{{ tmpl.icon }}</mat-icon>
                  <span class="text-xs font-semibold text-[#1D1D1F] group-hover:text-[#007AFF]">{{ tmpl.name }}</span>
                </div>
                <p class="text-[10px] text-[#4D4D4F] leading-tight">{{ tmpl.description }}</p>
              </div>
            }
          </div>
        }

        <!-- TAB 3: BATCH DATASET -->
        @if (activeTab() === 'dataset') {
          <div class="space-y-3">
            <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">CSV Data Automation</div>
            <p class="text-[11px] text-[#4D4D4F] leading-relaxed">
              Upload CSV or JSON dataset to populate template variables like <code class="text-[#007AFF] bg-white border border-[#C6C6C8] px-1 py-0.5 rounded font-mono">{{ '{{customer_name}}' }}</code>.
            </p>

            <button
              type="button"
              (click)="docService.showBatchStudio.set(true)"
              class="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs">
              <mat-icon class="text-sm w-4 h-4 leading-4">upload_file</mat-icon>
              <span>Launch Batch Studio</span>
            </button>
          </div>
        }
      </div>
    </div>
  `
})
export class SidebarLeftComponent {
  docService = inject(DocumentService);
  activeTab = signal<'pages' | 'templates' | 'dataset'>('pages');

  presetTemplates: PresetTemplate[] = [
    {
      name: 'Executive Business Invoice',
      icon: 'receipt_long',
      description: 'Professional invoice with line items, tax calculations, and header logo.',
      builder: () => this.buildInvoiceTemplate()
    },
    {
      name: 'Annual Financial Report',
      icon: 'assessment',
      description: 'Comprehensive report layout with bar charts, executive summary, and data tables.',
      builder: () => this.buildReportTemplate()
    },
    {
      name: 'Product Catalog Sheet',
      icon: 'shopping_bag',
      description: 'Clean product catalog layout with spec grids and vector image boxes.',
      builder: () => this.buildCatalogTemplate()
    },
    {
      name: 'Certificate of Achievement',
      icon: 'military_tech',
      description: 'Formal certificate with decorative borders and signature lines.',
      builder: () => this.buildCertificateTemplate()
    }
  ];

  loadPreset(tmpl: PresetTemplate) {
    const doc = tmpl.builder();
    this.docService.loadDocumentTemplate(doc);
  }

  private buildInvoiceTemplate(): DocumentModel {
    return {
      id: 'doc_inv_' + Date.now(),
      name: 'Executive_Invoice.macpdf',
      pageSize: 'A4',
      orientation: 'portrait',
      width: 595.28,
      height: 841.89,
      header: 'INVOICE • ACME CORPORATION',
      footer: 'Page {{page}} of {{total}} • Confidential',
      watermark: '',
      metadata: {
        title: 'Commercial Invoice',
        author: 'Finance Team',
        subject: 'Billing Statement',
        keywords: 'Invoice, Finance',
        creator: 'MACPDF.PRO',
        producer: 'Python Engine'
      },
      pages: [
        {
          id: 'p_inv_1',
          pageNumber: 1,
          width: 595.28,
          height: 841.89,
          elements: [
            {
              id: 'el_inv_hdr',
              type: 'text',
              text: 'COMMERCIAL INVOICE',
              x: 54, y: 50, width: 300, height: 35,
              fontSize: 24, fontWeight: 'bold', color: '#0F172A'
            },
            {
              id: 'el_inv_meta',
              type: 'text',
              text: 'Invoice #: {{invoice_number}}\nDate: {{date}}\nDue Date: Net 30',
              x: 380, y: 50, width: 160, height: 45,
              fontSize: 10, alignment: 'right', color: '#475569'
            },
            {
              id: 'el_inv_bill',
              type: 'rectangle',
              x: 54, y: 105, width: 487, height: 75,
              fill: '#F8FAFC', stroke: '#E2E8F0', strokeWidth: 1, borderRadius: 6
            },
            {
              id: 'el_inv_bill_txt',
              type: 'text',
              text: 'Billed To: {{customer_name}}\nCompany: Acme Global Corp\nEmail: {{customer_email}}',
              x: 70, y: 120, width: 450, height: 50,
              fontSize: 11, color: '#334155', lineHeight: 1.4
            },
            {
              id: 'el_inv_tbl',
              type: 'table',
              x: 54, y: 200, width: 487, height: 160,
              headers: ['DESCRIPTION', 'QTY', 'UNIT PRICE', 'AMOUNT'],
              rows: [
                ['Enterprise Cloud PDF Engine', '1', '$1,200.00', '$1,200.00'],
                ['Custom Python Layout Services', '8 hrs', '$150.00', '$1,200.00'],
                ['System SLA & Maintenance', '12 mos', '$100.00', '$1,200.00']
              ],
              headerBackground: '#0F172A', headerTextColor: '#FFFFFF', borderColor: '#CBD5E1'
            },
            {
              id: 'el_inv_tot',
              type: 'text',
              text: 'SUBTOTAL: $3,600.00\nTAX (8%): $288.00\nTOTAL DUE: {{total}}',
              x: 350, y: 380, width: 190, height: 60,
              fontSize: 12, fontWeight: 'bold', alignment: 'right', color: '#0F172A'
            }
          ]
        }
      ]
    };
  }

  private buildReportTemplate(): DocumentModel {
    return {
      id: 'doc_rep_' + Date.now(),
      name: 'Quarterly_Report.macpdf',
      pageSize: 'A4',
      orientation: 'portrait',
      width: 595.28,
      height: 841.89,
      header: 'ANNUAL PERFORMANCE REPORT',
      footer: 'Page {{page}} of {{total}}',
      watermark: '',
      metadata: {
        title: 'Quarterly Business Report',
        author: 'Executive Office',
        subject: 'Performance Review',
        keywords: 'Report, Analytics',
        creator: 'MACPDF.PRO',
        producer: 'Python Engine'
      },
      pages: [
        {
          id: 'p_rep_1',
          pageNumber: 1,
          width: 595.28,
          height: 841.89,
          elements: [
            { id: 't1', type: 'text', text: 'ANNUAL PERFORMANCE REPORT', x: 54, y: 50, width: 487, height: 35, fontSize: 22, fontWeight: 'bold', color: '#0F172A' },
            { id: 'r1', type: 'rectangle', x: 54, y: 90, width: 487, height: 2, fill: '#2563EB', stroke: '#2563EB', strokeWidth: 1 },
            { id: 'c1', type: 'chart', chartType: 'bar', title: 'Revenue Growth ($M)', x: 54, y: 110, width: 487, height: 220, labels: ['2022', '2023', '2024', '2025', '2026'], data: [12, 24, 45, 78, 120] },
            { id: 'tbl1', type: 'table', x: 54, y: 350, width: 487, height: 140, headers: ['REGION', 'TARGET', 'ACTUAL', 'VARIANCE'], rows: [['North America', '$50M', '$58M', '+16%'], ['Europe', '$35M', '$42M', '+20%'], ['Asia Pacific', '$25M', '$30M', '+20%']], headerBackground: '#1E293B', headerTextColor: '#FFFFFF', borderColor: '#E2E8F0' }
          ]
        }
      ]
    };
  }

  private buildCatalogTemplate(): DocumentModel {
    return {
      id: 'doc_cat_' + Date.now(),
      name: 'Product_Catalog.macpdf',
      pageSize: 'A4',
      orientation: 'portrait',
      width: 595.28,
      height: 841.89,
      pages: [
        {
          id: 'p_cat_1',
          pageNumber: 1,
          width: 595.28,
          height: 841.89,
          elements: [
            { id: 'ct1', type: 'text', text: 'PRODUCT SPECIFICATION SHEET', x: 54, y: 50, width: 487, height: 35, fontSize: 22, fontWeight: 'bold', color: '#0F172A' },
            { id: 'img1', type: 'image', x: 54, y: 95, width: 230, height: 180, src: 'https://picsum.photos/seed/product/500/400' },
            { id: 'txt1', type: 'text', text: 'Model X-200 PDF Workstation\n• High-density vector graphics\n• Instant local IPC processing\n• Multi-page batch streaming', x: 300, y: 95, width: 240, height: 100, fontSize: 11, lineHeight: 1.5, color: '#334155' }
          ]
        }
      ],
      metadata: { title: 'Catalog', author: 'Catalog Engine', subject: 'Products', keywords: '', creator: 'MACPDF', producer: 'Python' }
    };
  }

  private buildCertificateTemplate(): DocumentModel {
    return {
      id: 'doc_cert_' + Date.now(),
      name: 'Certificate_of_Excellence.macpdf',
      pageSize: 'A4',
      orientation: 'landscape',
      width: 841.89,
      height: 595.28,
      pages: [
        {
          id: 'p_cert_1',
          pageNumber: 1,
          width: 841.89,
          height: 595.28,
          elements: [
            { id: 'border_out', type: 'rectangle', x: 20, y: 20, width: 801.89, height: 555.28, fill: 'transparent', stroke: '#0F172A', strokeWidth: 4 },
            { id: 'border_in', type: 'rectangle', x: 28, y: 28, width: 785.89, height: 539.28, fill: 'transparent', stroke: '#D97706', strokeWidth: 1 },
            { id: 'cert_hdr', type: 'text', text: 'CERTIFICATE OF ACHIEVEMENT', x: 100, y: 80, width: 641, height: 40, fontSize: 28, fontWeight: 'bold', alignment: 'center', color: '#0F172A' },
            { id: 'cert_sub', type: 'text', text: 'PROUDLY PRESENTED TO', x: 100, y: 140, width: 641, height: 20, fontSize: 12, alignment: 'center', color: '#64748B' },
            { id: 'cert_name', type: 'text', text: '{{customer_name}}', x: 100, y: 175, width: 641, height: 40, fontSize: 32, fontWeight: 'bold', alignment: 'center', color: '#2563EB' },
            { id: 'cert_body', type: 'text', text: 'For outstanding excellence in professional document engineering and PDF automation.', x: 150, y: 230, width: 541, height: 40, fontSize: 13, alignment: 'center', color: '#334155' }
          ]
        }
      ],
      metadata: { title: 'Certificate', author: 'Certification Board', subject: 'Award', keywords: '', creator: 'MACPDF', producer: 'Python' }
    };
  }
}
