import { Component, ChangeDetectionStrategy, inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../services/document.service';
import { ElementModel } from '../../models/document.model';

@Component({
  selector: 'app-canvas',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 bg-[#D1D1D3] flex flex-col h-full relative overflow-hidden select-none">
      <!-- Horizontal Ruler Bar -->
      <div class="h-6 bg-[#E5E5E7] border-b border-[#C6C6C8] flex items-center px-6 relative text-[9px] font-mono text-[#8E8E93] overflow-hidden shrink-0">
        <div class="absolute left-6 right-0 h-full flex items-end">
          @for (tick of horizontalTicks; track tick) {
            <div class="absolute flex flex-col items-start border-l border-[#C6C6C8] h-2 bottom-0" [style.left.px]="tick * (docService.zoom() / 100)">
              <span class="pl-0.5 -mt-3.5">{{ tick }}pt</span>
            </div>
          }
        </div>
      </div>

      <div class="flex-1 flex relative overflow-auto custom-scrollbar items-center justify-center p-12">
        <!-- Vertical Ruler Bar -->
        <div class="absolute left-0 top-0 bottom-0 w-6 bg-[#E5E5E7] border-r border-[#C6C6C8] flex flex-col items-end py-6 text-[9px] font-mono text-[#8E8E93] overflow-hidden z-10">
          @for (tick of verticalTicks; track tick) {
            <div class="absolute border-t border-[#C6C6C8] w-2 right-0" [style.top.px]="tick * (docService.zoom() / 100)">
              <span class="pr-0.5 -mt-2">{{ tick }}</span>
            </div>
          }
        </div>

        <!-- CANVAS MAIN STAGE -->
        @if (docService.isPreviewMode()) {
          <!-- LIVE PDF PREVIEW VIEW -->
          <div class="w-full h-full flex flex-col items-center justify-center">
            @if (docService.latestRenderResult(); as res) {
              @if (res.status === 'success' && res.dataUrl) {
                <div class="w-full h-full flex flex-col items-center justify-center p-4">
                  <iframe
                    [src]="getSafeUrl(res.dataUrl)"
                    title="PDF Document Preview"
                    class="w-full max-w-4xl h-full rounded shadow-2xl border border-[#C6C6C8] bg-white">
                  </iframe>
                </div>
              } @else if (res.error) {
                <div class="bg-red-50 border border-red-300 p-6 rounded-lg max-w-md text-red-800 text-xs shadow-md">
                  <div class="font-bold mb-2 flex items-center gap-2 text-red-900">
                    <mat-icon class="text-base w-4 h-4 leading-4">error</mat-icon>
                    <span>Python Engine Render Error</span>
                  </div>
                  <p class="font-mono text-[11px] leading-tight break-all">{{ res.error }}</p>
                </div>
              }
            } @else {
              <div class="flex flex-col items-center gap-3 text-[#4D4D4F]">
                <mat-icon class="text-4xl w-10 h-10 leading-10 animate-spin text-[#007AFF]">autorenew</mat-icon>
                <p class="text-xs font-medium">Rendering PDF Page Stream...</p>
              </div>
            }
          </div>
        } @else {
          <!-- INTERACTIVE PAGE EDITOR CANVAS -->
          <div
            #pageCanvas
            tabindex="0"
            role="region"
            aria-label="Interactive Page Canvas"
            (click)="onCanvasClick($event)"
            (keyup.escape)="onCanvasClick($event)"
            class="relative shadow-2xl transition-transform origin-top border border-[#C6C6C8] rounded-xs outline-none bg-white"
            [style.width.px]="docService.activePage().width"
            [style.height.px]="docService.activePage().height"
            [style.backgroundColor]="docService.activePage().background || '#FFFFFF'"
            [style.transform]="'scale(' + (docService.zoom() / 100) + ')'">

            <!-- Grid Overlay Lines -->
            @if (docService.showGrid()) {
              <div class="absolute inset-0 pointer-events-none bg-[radial-gradient(#C6C6C8_1px,transparent_1px)] [background-size:20px_20px] opacity-60"></div>
            }

            <!-- Margins Guideline -->
            <div class="absolute inset-9 border border-[#007AFF]/30 pointer-events-none border-dashed"></div>

            <!-- Page Watermark Overlay -->
            @if (docService.document().watermark || docService.activePage().watermark; as wtm) {
              @if (wtm) {
                <div class="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
                  <span class="text-6xl font-extrabold text-slate-200/40 -rotate-45 select-none font-sans uppercase tracking-widest">
                    {{ wtm }}
                  </span>
                </div>
              }
            }

            <!-- Running Header Overlay -->
            @if (docService.document().header || docService.activePage().header; as hdr) {
              @if (hdr) {
                <div class="absolute top-6 left-9 right-9 border-b border-slate-200 pb-1 text-[10px] text-slate-400 flex justify-between pointer-events-none font-sans">
                  <span>{{ hdr }}</span>
                  <span>MACPDF.PRO</span>
                </div>
              }
            }

            <!-- Running Footer Overlay -->
            @if (docService.document().footer || docService.activePage().footer; as ftr) {
              @if (ftr) {
                <div class="absolute bottom-6 left-9 right-9 border-t border-slate-200 pt-1 text-[10px] text-slate-400 flex justify-between pointer-events-none font-sans">
                  <span>{{ ftr.replace('{{page}}', '' + (docService.activePageIndex() + 1)).replace('{{total}}', '' + docService.document().pages.length) }}</span>
                  <span>CONFIDENTIAL</span>
                </div>
              }
            }

            <!-- ELEMENTS ON CANVAS -->
            @for (el of docService.activePage().elements; track el.id) {
              <div
                tabindex="0"
                role="button"
                [attr.aria-label]="'Canvas Element ' + el.type"
                (mousedown)="onElementMouseDown($event, el)"
                (keyup.enter)="docService.selectElement(el.id, false)"
                class="absolute cursor-move select-none group transition-shadow outline-none"
                [class.ring-2]="isSelected(el.id)"
                [class.ring-blue-600]="isSelected(el.id)"
                [class.ring-offset-1]="isSelected(el.id)"
                [style.left.px]="el.x"
                [style.top.px]="el.y"
                [style.width.px]="el.width"
                [style.height.px]="el.height"
                [style.transform]="'rotate(' + (el.rotation || 0) + 'deg)'">

                <!-- 1. TEXT ELEMENT -->
                @if (el.type === 'text') {
                  <div
                    class="w-full h-full p-1 overflow-hidden font-sans leading-normal break-words"
                    [style.fontSize.px]="el.fontSize || 12"
                    [style.fontWeight]="el.fontWeight || 'normal'"
                    [style.color]="el.color || '#1E293B'"
                    [style.textAlign]="el.alignment || 'left'">
                    {{ el.text }}
                  </div>
                }

                <!-- 2. RECTANGLE SHAPE -->
                @if (el.type === 'rectangle') {
                  <div
                    class="w-full h-full rounded"
                    [style.backgroundColor]="el.fill || '#F1F5F9'"
                    [style.borderColor]="el.stroke || '#94A3B8'"
                    [style.borderWidth.px]="el.strokeWidth || 1">
                  </div>
                }

                <!-- 3. CIRCLE SHAPE -->
                @if (el.type === 'circle') {
                  <div
                    class="w-full h-full rounded-full"
                    [style.backgroundColor]="el.fill || '#3B82F6'"
                    [style.borderColor]="el.stroke || '#1D4ED8'"
                    [style.borderWidth.px]="el.strokeWidth || 2">
                  </div>
                }

                <!-- 4. LINE SHAPE -->
                @if (el.type === 'line') {
                  <div
                    class="w-full my-auto"
                    [style.backgroundColor]="el.stroke || '#0F172A'"
                    [style.height.px]="el.strokeWidth || 2">
                  </div>
                }

                <!-- 5. TABLE ELEMENT -->
                @if (el.type === 'table') {
                  <div class="w-full h-full border border-slate-300 rounded overflow-hidden text-[10px] bg-white flex flex-col font-sans shadow-sm">
                    <div class="flex text-white font-bold" [style.backgroundColor]="el.headerBackground || '#0F172A'">
                      @for (hdr of el.headers || []; track $index) {
                        <div class="flex-1 p-1.5 border-r border-slate-700 truncate">{{ hdr }}</div>
                      }
                    </div>
                    <div class="flex-1 flex flex-col divide-y divide-slate-200">
                      @for (row of el.rows || []; track $index) {
                        <div class="flex divide-x divide-slate-200 text-slate-800">
                          @for (cell of row; track $index) {
                            <div class="flex-1 p-1.5 truncate">{{ cell }}</div>
                          }
                        </div>
                      }
                    </div>
                  </div>
                }

                <!-- 6. CHART ELEMENT -->
                @if (el.type === 'chart') {
                  <div class="w-full h-full bg-slate-50 border border-slate-200 rounded p-2 flex flex-col font-sans text-slate-800 shadow-sm">
                    <div class="text-[11px] font-bold text-slate-900 border-b pb-1 mb-1">{{ el.title }}</div>
                    <div class="flex-1 flex items-end justify-between gap-2 px-2 pt-2 pb-1 border-l border-b border-slate-400">
                      @for (val of el.data || [40,65,25,80,55]; track $index) {
                        <div class="flex-1 bg-blue-600 rounded-t flex items-end justify-center text-[8px] text-white font-mono" [style.height.%]="(val / 100) * 100">
                          {{ val }}
                        </div>
                      }
                    </div>
                  </div>
                }

                <!-- 7. IMAGE ELEMENT -->
                @if (el.type === 'image') {
                  <img
                    [src]="el.src"
                    alt="Asset"
                    class="w-full h-full object-cover rounded shadow-sm"
                    referrerpolicy="no-referrer">
                }

                <!-- 8. FORM FIELD ELEMENT -->
                @if (el.type === 'form_field') {
                  <div class="w-full h-full border border-blue-400 bg-blue-50/50 rounded px-2 flex items-center text-xs text-slate-700 font-mono">
                    <span class="text-blue-600 font-bold mr-1">[Field]</span>
                    <span>{{ el.placeholder || 'Text Input' }}</span>
                  </div>
                }

                <!-- SELECTION HANDLE CORNERS -->
                @if (isSelected(el.id)) {
                  <div
                    tabindex="0"
                    role="button"
                    aria-label="Resize element handle"
                    (mousedown)="onResizeHandleMouseDown($event, el)"
                    class="absolute -bottom-1.5 -right-1.5 w-3 h-3 bg-blue-600 border border-white rounded-full cursor-se-resize z-20">
                  </div>
                }
              </div>
            }
          </div>
        }
      </div>
    </div>
  `
})
export class CanvasComponent {
  docService = inject(DocumentService);
  sanitizer = inject(DomSanitizer);

  horizontalTicks = Array.from({ length: 20 }, (_, i) => i * 100);
  verticalTicks = Array.from({ length: 30 }, (_, i) => i * 100);

  private isDragging = false;
  private isResizing = false;
  private dragStartPos = { x: 0, y: 0 };
  private elementStartPos = { x: 0, y: 0, w: 0, h: 0 };
  private activeElement: ElementModel | null = null;

  getSafeUrl(url: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  isSelected(id: string): boolean {
    return this.docService.selectedElementIds().includes(id);
  }

  onCanvasClick(event: Event) {
    if (event.target === event.currentTarget) {
      this.docService.clearSelection();
    }
  }

  onElementMouseDown(event: MouseEvent, el: ElementModel) {
    event.stopPropagation();
    this.docService.selectElement(el.id, event.shiftKey);

    this.isDragging = true;
    this.activeElement = el;
    this.dragStartPos = { x: event.clientX, y: event.clientY };
    this.elementStartPos = { x: el.x, y: el.y, w: el.width, h: el.height };
  }

  onResizeHandleMouseDown(event: MouseEvent, el: ElementModel) {
    event.stopPropagation();
    this.isResizing = true;
    this.activeElement = el;
    this.dragStartPos = { x: event.clientX, y: event.clientY };
    this.elementStartPos = { x: el.x, y: el.y, w: el.width, h: el.height };
  }

  @HostListener('window:mousemove', ['$event'])
  onMouseMove(event: MouseEvent) {
    if (!this.activeElement) return;

    const zoomFactor = this.docService.zoom() / 100;
    const dx = (event.clientX - this.dragStartPos.x) / zoomFactor;
    const dy = (event.clientY - this.dragStartPos.y) / zoomFactor;

    if (this.isDragging) {
      let newX = Math.round(this.elementStartPos.x + dx);
      let newY = Math.round(this.elementStartPos.y + dy);

      // Snap to 10pt grid
      if (this.docService.snapToGrid()) {
        newX = Math.round(newX / 10) * 10;
        newY = Math.round(newY / 10) * 10;
      }

      this.docService.updateElement(this.activeElement.id, { x: newX, y: newY });
    } else if (this.isResizing) {
      let newW = Math.max(20, Math.round(this.elementStartPos.w + dx));
      let newH = Math.max(10, Math.round(this.elementStartPos.h + dy));

      if (this.docService.snapToGrid()) {
        newW = Math.round(newW / 10) * 10;
        newH = Math.round(newH / 10) * 10;
      }

      this.docService.updateElement(this.activeElement.id, { width: newW, height: newH });
    }
  }

  @HostListener('window:mouseup')
  onMouseUp() {
    if (this.isDragging || this.isResizing) {
      this.isDragging = false;
      this.isResizing = false;
      this.activeElement = null;
      this.docService.triggerLiveRender();
    }
  }

  @HostListener('window:keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    // Shortcuts: Cmd/Ctrl + Z, Cmd/Ctrl + Shift + Z, Delete
    const isCmd = event.metaKey || event.ctrlKey;

    if (isCmd && event.key.toLowerCase() === 'z') {
      event.preventDefault();
      if (event.shiftKey) {
        this.docService.redo();
      } else {
        this.docService.undo();
      }
    } else if (isCmd && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.docService.showCommandPalette.set(true);
    } else if (event.key === 'Delete' || event.key === 'Backspace') {
      const activeTag = (event.target as HTMLElement)?.tagName?.toLowerCase();
      if (activeTag !== 'input' && activeTag !== 'textarea') {
        this.docService.deleteSelectedElements();
      }
    }
  }
}
