import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../services/document.service';
import { ElementModel, PageSizeName, Orientation } from '../../models/document.model';

@Component({
  selector: 'app-inspector-right',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-72 bg-[#ECECEE] border-l border-[#C6C6C8] flex flex-col h-full text-[#1D1D1F] select-none shrink-0">
      <!-- Header Tabs: Element vs Document Properties -->
      <div class="flex items-center border-b border-[#C6C6C8] bg-[#E5E5E7] p-1 gap-1 text-xs shrink-0">
        <button
          type="button"
          (click)="inspectorTab.set('element')"
          class="flex-1 py-1 rounded transition-colors cursor-pointer flex items-center justify-center gap-1 font-medium"
          [class.bg-white]="inspectorTab() === 'element'"
          [class.text-[#1D1D1F]]="inspectorTab() === 'element'"
          [class.border]="inspectorTab() === 'element'"
          [class.border-[#C6C6C8]]="inspectorTab() === 'element'"
          [class.shadow-2xs]="inspectorTab() === 'element'"
          [class.text-[#4D4D4F]]="inspectorTab() !== 'element'">
          <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5">tune</mat-icon>
          <span>Element</span>
        </button>

        <button
          type="button"
          (click)="inspectorTab.set('document')"
          class="flex-1 py-1 rounded transition-colors cursor-pointer flex items-center justify-center gap-1 font-medium"
          [class.bg-white]="inspectorTab() === 'document'"
          [class.text-[#1D1D1F]]="inspectorTab() === 'document'"
          [class.border]="inspectorTab() === 'document'"
          [class.border-[#C6C6C8]]="inspectorTab() === 'document'"
          [class.shadow-2xs]="inspectorTab() === 'document'"
          [class.text-[#4D4D4F]]="inspectorTab() !== 'document'">
          <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5">description</mat-icon>
          <span>Doc Setup</span>
        </button>
      </div>

      <!-- Content Inspector Area -->
      <div class="flex-1 overflow-y-auto p-3 custom-scrollbar space-y-4">
        @if (inspectorTab() === 'element') {
          @if (docService.singleSelectedElement(); as el) {
            <!-- 1. TYPE & HEADER -->
            <div class="flex items-center justify-between bg-white p-2 rounded border border-[#C6C6C8] shadow-2xs">
              <div class="flex items-center gap-2">
                <span class="px-1.5 py-0.5 bg-[#007AFF]/10 text-[#007AFF] rounded text-[10px] font-mono font-bold uppercase border border-[#007AFF]/20">
                  {{ el.type }}
                </span>
                <span class="text-xs font-semibold text-[#1D1D1F] font-mono">{{ el.id }}</span>
              </div>
              <button
                type="button"
                (click)="docService.deleteSelectedElements()"
                class="text-[#8E8E93] hover:text-red-600 p-1 cursor-pointer" title="Delete Element">
                <mat-icon class="text-sm w-4 h-4 leading-4">delete</mat-icon>
              </button>
            </div>

            <!-- 2. POSITION & GEOMETRY -->
            <div class="space-y-2">
              <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Position & Geometry (pt)</div>
              <div class="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">X Position</span>
                  <input
                    type="number"
                    [ngModel]="el.x"
                    (ngModelChange)="updateProp(el.id, 'x', +$event)"
                    class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs font-mono shadow-2xs focus:border-[#007AFF] focus:outline-none">
                </div>
                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Y Position</span>
                  <input
                    type="number"
                    [ngModel]="el.y"
                    (ngModelChange)="updateProp(el.id, 'y', +$event)"
                    class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs font-mono shadow-2xs focus:border-[#007AFF] focus:outline-none">
                </div>
                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Width</span>
                  <input
                    type="number"
                    [ngModel]="el.width"
                    (ngModelChange)="updateProp(el.id, 'width', +$event)"
                    class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs font-mono shadow-2xs focus:border-[#007AFF] focus:outline-none">
                </div>
                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Height</span>
                  <input
                    type="number"
                    [ngModel]="el.height"
                    (ngModelChange)="updateProp(el.id, 'height', +$event)"
                    class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs font-mono shadow-2xs focus:border-[#007AFF] focus:outline-none">
                </div>
              </div>
            </div>

            <!-- 3. TYPE-SPECIFIC EDITORS -->

            <!-- TEXT ENGINE PROPERTIES -->
            @if (el.type === 'text') {
              <div class="space-y-2 border-t border-[#D1D1D3] pt-3">
                <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Typography</div>

                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Text Content</span>
                  <textarea
                    rows="3"
                    [ngModel]="el.text"
                    (ngModelChange)="updateProp(el.id, 'text', $event)"
                    class="w-full bg-white border border-[#C6C6C8] rounded p-2 text-[#1D1D1F] text-xs font-sans focus:border-[#007AFF] focus:outline-none custom-scrollbar shadow-2xs">
                  </textarea>
                </div>

                <div class="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Font Size</span>
                    <input
                      type="number"
                      [ngModel]="el.fontSize || 12"
                      (ngModelChange)="updateProp(el.id, 'fontSize', +$event)"
                      class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs font-mono shadow-2xs focus:border-[#007AFF] focus:outline-none">
                  </div>
                  <div>
                    <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Font Weight</span>
                    <select
                      [ngModel]="el.fontWeight || 'normal'"
                      (ngModelChange)="updateProp(el.id, 'fontWeight', $event)"
                      class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
                      <option value="normal">Normal</option>
                      <option value="medium">Medium</option>
                      <option value="bold">Bold</option>
                    </select>
                  </div>
                </div>

                <div class="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Text Color</span>
                    <div class="flex items-center gap-2">
                      <input
                        type="color"
                        [ngModel]="el.color || '#1E293B'"
                        (ngModelChange)="updateProp(el.id, 'color', $event)"
                        class="w-6 h-6 rounded border border-[#C6C6C8] bg-transparent cursor-pointer">
                      <span class="text-xs font-mono text-[#1D1D1F]">{{ el.color }}</span>
                    </div>
                  </div>

                  <div>
                    <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Alignment</span>
                    <div class="flex items-center bg-white rounded border border-[#C6C6C8] p-0.5 shadow-2xs">
                      <button type="button" (click)="updateProp(el.id, 'alignment', 'left')" class="flex-1 py-0.5 font-bold hover:text-[#007AFF]" [class.text-[#007AFF]]="el.alignment === 'left'">L</button>
                      <button type="button" (click)="updateProp(el.id, 'alignment', 'center')" class="flex-1 py-0.5 font-bold hover:text-[#007AFF]" [class.text-[#007AFF]]="el.alignment === 'center'">C</button>
                      <button type="button" (click)="updateProp(el.id, 'alignment', 'right')" class="flex-1 py-0.5 font-bold hover:text-[#007AFF]" [class.text-[#007AFF]]="el.alignment === 'right'">R</button>
                    </div>
                  </div>
                </div>
              </div>
            }

            <!-- SHAPE PROPERTIES -->
            @if (el.type === 'rectangle' || el.type === 'circle' || el.type === 'line') {
              <div class="space-y-2 border-t border-[#D1D1D3] pt-3">
                <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Vector Styling</div>

                <div class="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Fill Color</span>
                    <input
                      type="color"
                      [ngModel]="el.fill || '#F1F5F9'"
                      (ngModelChange)="updateProp(el.id, 'fill', $event)"
                      class="w-6 h-6 rounded border border-[#C6C6C8] bg-transparent cursor-pointer">
                  </div>
                  <div>
                    <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Stroke Color</span>
                    <input
                      type="color"
                      [ngModel]="el.stroke || '#94A3B8'"
                      (ngModelChange)="updateProp(el.id, 'stroke', $event)"
                      class="w-6 h-6 rounded border border-[#C6C6C8] bg-transparent cursor-pointer">
                  </div>
                </div>

                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Stroke Width (pt)</span>
                  <input
                    type="number"
                    [ngModel]="el.strokeWidth || 1"
                    (ngModelChange)="updateProp(el.id, 'strokeWidth', +$event)"
                    class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs font-mono shadow-2xs focus:border-[#007AFF] focus:outline-none">
                </div>
              </div>
            }

            <!-- TABLE PROPERTIES -->
            @if (el.type === 'table') {
              <div class="space-y-2 border-t border-[#D1D1D3] pt-3">
                <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Table Engine</div>

                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Header Background</span>
                  <input
                    type="color"
                    [ngModel]="el.headerBackground || '#0F172A'"
                    (ngModelChange)="updateProp(el.id, 'headerBackground', $event)"
                    class="w-6 h-6 rounded border border-[#C6C6C8] bg-transparent cursor-pointer">
                </div>

                <p class="text-[10px] text-[#8E8E93]">
                  Rows: {{ el.rows?.length || 0 }} • Cols: {{ el.headers?.length || 0 }}
                </p>
              </div>
            }

            <!-- CHART PROPERTIES -->
            @if (el.type === 'chart') {
              <div class="space-y-2 border-t border-[#D1D1D3] pt-3">
                <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Chart Engine</div>

                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Chart Type</span>
                  <select
                    [ngModel]="el.chartType || 'bar'"
                    (ngModelChange)="updateProp(el.id, 'chartType', $event)"
                    class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
                    <option value="bar">Bar Chart</option>
                    <option value="line">Line Chart</option>
                    <option value="area">Area Chart</option>
                  </select>
                </div>

                <div>
                  <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Title</span>
                  <input
                    type="text"
                    [ngModel]="el.title || ''"
                    (ngModelChange)="updateProp(el.id, 'title', $event)"
                    class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
                </div>
              </div>
            }

            <!-- DATA BINDING & TEMPLATES -->
            <div class="space-y-2 border-t border-[#D1D1D3] pt-3">
              <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Template Variable</div>
              <input
                type="text"
                placeholder="variable_name"
                [ngModel]="el.dataVariable || ''"
                (ngModelChange)="updateProp(el.id, 'dataVariable', $event)"
                class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#007AFF] font-mono text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
            </div>

          } @else {
            <div class="text-center py-10 text-[#8E8E93] space-y-2">
              <mat-icon class="text-3xl w-8 h-8 leading-8 text-[#8E8E93]">mouse</mat-icon>
              <p class="text-xs">Select any canvas element to adjust layout, typography, vectors, or tables.</p>
            </div>
          }
        }

        @if (inspectorTab() === 'document') {
          <div class="space-y-3">
            <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Page Specification</div>

            <div>
              <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Page Size</span>
              <select
                [ngModel]="docService.document().pageSize"
                (ngModelChange)="onPageSizeChange($event)"
                class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
                <option value="A0">A0 (2384 x 3370 pt)</option>
                <option value="A1">A1 (1684 x 2384 pt)</option>
                <option value="A2">A2 (1191 x 1684 pt)</option>
                <option value="A3">A3 (842 x 1191 pt)</option>
                <option value="A4">A4 (595 x 842 pt)</option>
                <option value="A5">A5 (420 x 595 pt)</option>
                <option value="LETTER">US Letter (612 x 792 pt)</option>
                <option value="LEGAL">US Legal (612 x 1008 pt)</option>
                <option value="TABLOID">Tabloid (792 x 1224 pt)</option>
              </select>
            </div>

            <div>
              <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Orientation</span>
              <select
                [ngModel]="docService.document().orientation"
                (ngModelChange)="onOrientationChange($event)"
                class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
                <option value="portrait">Portrait</option>
                <option value="landscape">Landscape</option>
              </select>
            </div>

            <div class="space-y-2 border-t border-[#D1D1D3] pt-3">
              <div class="text-[10px] font-bold text-[#8E8E93] uppercase tracking-wider">Headers & Footers</div>

              <div>
                <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Running Header</span>
                <input
                  type="text"
                  [ngModel]="docService.document().header"
                  (ngModelChange)="docService.setDocumentHeaderFooterWatermark($event, undefined, undefined)"
                  class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
              </div>

              <div>
                <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Running Footer</span>
                <input
                  type="text"
                  [ngModel]="docService.document().footer"
                  (ngModelChange)="docService.setDocumentHeaderFooterWatermark(undefined, $event, undefined)"
                  class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-[#1D1D1F] text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
              </div>

              <div>
                <span class="block text-[10px] text-[#4D4D4F] mb-0.5 font-medium">Diagonal Watermark Text</span>
                <input
                  type="text"
                  placeholder="e.g. CONFIDENTIAL / DRAFT"
                  [ngModel]="docService.document().watermark"
                  (ngModelChange)="docService.setDocumentHeaderFooterWatermark(undefined, undefined, $event)"
                  class="w-full bg-white border border-[#C6C6C8] rounded px-2 py-1 text-amber-700 font-medium text-xs shadow-2xs focus:border-[#007AFF] focus:outline-none">
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class InspectorRightComponent {
  docService = inject(DocumentService);
  inspectorTab = signal<'element' | 'document'>('element');

  updateProp(id: string, prop: keyof ElementModel, val: unknown) {
    this.docService.updateElementAndSaveHistory(id, { [prop]: val });
  }

  onPageSizeChange(size: PageSizeName) {
    this.docService.setPageSize(size, this.docService.document().orientation);
  }

  onOrientationChange(ori: Orientation) {
    this.docService.setPageSize(this.docService.document().pageSize, ori);
  }
}
