import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../services/document.service';

@Component({
  selector: 'app-status-bar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-7 bg-[#E5E5E7] border-t border-[#C6C6C8] flex items-center justify-between px-3 text-[11px] font-mono text-[#4D4D4F] select-none shrink-0">
      <!-- Left: Page Info & Page Size -->
      <div class="flex items-center gap-4">
        <span class="text-[#1D1D1F] font-semibold">
          Page {{ docService.activePageIndex() + 1 }} / {{ docService.document().pages.length }}
        </span>

        <span class="text-[#8E8E93]">•</span>

        <span>{{ docService.document().pageSize }} ({{ docService.document().orientation }})</span>

        <span class="text-[#8E8E93]">•</span>

        <span>Zoom: {{ docService.zoom() }}%</span>
      </div>

      <!-- Center: SHA-256 Integrity Hash & Size -->
      <div class="flex items-center gap-3">
        @if (docService.latestRenderResult(); as res) {
          @if (res.status === 'success') {
            <span class="text-emerald-700 font-medium flex items-center gap-1">
              <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5 text-emerald-600">verified</mat-icon>
              <span>SHA-256: {{ res.sha256?.substring(0, 16) }}...</span>
            </span>

            <span class="text-[#8E8E93]">•</span>

            <span class="text-[#007AFF] font-medium">
              {{ (res.sizeBytes || 0) / 1024 | number:'1.1-1' }} KB
            </span>

            <span class="text-[#8E8E93]">•</span>

            <span class="text-[#4D4D4F]">
              Latency: {{ res.renderTimeMs }}ms
            </span>
          }
        }
      </div>

      <!-- Right: Python Engine Status -->
      <div class="flex items-center gap-2">
        <button
          type="button"
          (click)="docService.showEngineHealthModal.set(true)"
          class="flex items-center gap-1.5 hover:text-[#1D1D1F] transition-colors cursor-pointer">
          <div class="w-2 h-2 rounded-full bg-[#28C840]"></div>
          <span class="text-[#1D1D1F] font-sans font-medium">Python PDF Engine Online</span>
        </button>
      </div>
    </div>
  `
})
export class StatusBarComponent {
  docService = inject(DocumentService);
}
