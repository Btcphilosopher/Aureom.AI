import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../services/document.service';

@Component({
  selector: 'app-toolbar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-11 bg-[#F5F5F7] border-b border-[#C6C6C8] flex items-center justify-between px-3 text-[#1D1D1F] select-none shrink-0">
      <!-- Left: Insert Tools -->
      <div class="flex items-center gap-1">
        <!-- Add Page -->
        <button
          type="button"
          (click)="docService.addPage()"
          class="flex items-center gap-1.5 px-2.5 py-1 bg-white hover:bg-gray-100 text-[#1D1D1F] rounded text-xs font-medium transition-colors border border-[#C6C6C8] shadow-2xs cursor-pointer"
          title="Add New Document Page">
          <mat-icon class="text-sm w-4 h-4 leading-4 text-[#007AFF]">note_add</mat-icon>
          <span>Add Page</span>
        </button>

        <div class="h-5 w-px bg-[#C6C6C8] mx-1"></div>

        <!-- Element Insertion Group -->
        <div class="flex items-center bg-[#E5E5E7] p-0.5 rounded border border-[#C6C6C8]">
          <button
            type="button"
            (click)="docService.addElement('text')"
            class="p-1 hover:bg-white rounded text-[#2C2C2E] transition-colors cursor-pointer"
            title="Insert Text Box">
            <mat-icon class="text-base w-4 h-4 leading-4">title</mat-icon>
          </button>
          <button
            type="button"
            (click)="docService.addElement('rectangle')"
            class="p-1 hover:bg-white rounded text-[#2C2C2E] transition-colors cursor-pointer"
            title="Insert Vector Rectangle">
            <mat-icon class="text-base w-4 h-4 leading-4">crop_square</mat-icon>
          </button>
          <button
            type="button"
            (click)="docService.addElement('circle')"
            class="p-1 hover:bg-white rounded text-[#2C2C2E] transition-colors cursor-pointer"
            title="Insert Vector Circle/Ellipse">
            <mat-icon class="text-base w-4 h-4 leading-4">radio_button_unchecked</mat-icon>
          </button>
          <button
            type="button"
            (click)="docService.addElement('line')"
            class="p-1 hover:bg-white rounded text-[#2C2C2E] transition-colors cursor-pointer"
            title="Insert Line / Connector">
            <mat-icon class="text-base w-4 h-4 leading-4">horizontal_rule</mat-icon>
          </button>
          <button
            type="button"
            (click)="docService.addElement('table')"
            class="p-1 hover:bg-white rounded text-amber-600 transition-colors cursor-pointer"
            title="Insert Data Table">
            <mat-icon class="text-base w-4 h-4 leading-4">table_chart</mat-icon>
          </button>
          <button
            type="button"
            (click)="docService.addElement('chart')"
            class="p-1 hover:bg-white rounded text-indigo-600 transition-colors cursor-pointer"
            title="Insert Vector Chart">
            <mat-icon class="text-base w-4 h-4 leading-4">bar_chart</mat-icon>
          </button>
          <button
            type="button"
            (click)="docService.addElement('image')"
            class="p-1 hover:bg-white rounded text-emerald-600 transition-colors cursor-pointer"
            title="Insert Image Asset">
            <mat-icon class="text-base w-4 h-4 leading-4">image</mat-icon>
          </button>
          <button
            type="button"
            (click)="docService.addElement('form_field')"
            class="p-1 hover:bg-white rounded text-sky-600 transition-colors cursor-pointer"
            title="Insert PDF Form Field">
            <mat-icon class="text-base w-4 h-4 leading-4">check_box</mat-icon>
          </button>
        </div>

        <div class="h-5 w-px bg-[#C6C6C8] mx-1"></div>

        <!-- History Undo / Redo -->
        <button
          type="button"
          (click)="docService.undo()"
          [disabled]="!docService.canUndo()"
          class="p-1.5 rounded hover:bg-white text-[#2C2C2E] disabled:opacity-30 disabled:hover:bg-transparent transition-colors cursor-pointer"
          title="Undo (⌘Z)">
          <mat-icon class="text-base w-4 h-4 leading-4">undo</mat-icon>
        </button>
        <button
          type="button"
          (click)="docService.redo()"
          [disabled]="!docService.canRedo()"
          class="p-1.5 rounded hover:bg-white text-[#2C2C2E] disabled:opacity-30 disabled:hover:bg-transparent transition-colors cursor-pointer"
          title="Redo (⌘⇧Z)">
          <mat-icon class="text-base w-4 h-4 leading-4">redo</mat-icon>
        </button>
      </div>

      <!-- Center: View Mode & Zoom -->
      <div class="flex items-center gap-2">
        <div class="flex items-center bg-[#E5E5E7] rounded border border-[#C6C6C8] text-xs p-0.5">
          <button
            type="button"
            (click)="docService.isPreviewMode.set(false)"
            class="px-2.5 py-1 rounded transition-all cursor-pointer font-medium"
            [class.bg-white]="!docService.isPreviewMode()"
            [class.shadow-2xs]="!docService.isPreviewMode()"
            [class.text-[#1D1D1F]]="!docService.isPreviewMode()"
            [class.text-[#4D4D4F]]="docService.isPreviewMode()">
            Interactive Editor
          </button>
          <button
            type="button"
            (click)="docService.isPreviewMode.set(true)"
            class="px-2.5 py-1 rounded transition-all cursor-pointer font-medium flex items-center gap-1"
            [class.bg-[#007AFF]]="docService.isPreviewMode()"
            [class.text-white]="docService.isPreviewMode()"
            [class.text-[#4D4D4F]]="!docService.isPreviewMode()">
            <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5">visibility</mat-icon>
            Live PDF Render
          </button>
        </div>

        <div class="h-5 w-px bg-[#C6C6C8] mx-1"></div>

        <!-- Zoom Controls -->
        <div class="flex items-center bg-white px-2 py-0.5 rounded border border-[#C6C6C8] text-xs gap-1.5 shadow-2xs">
          <button type="button" (click)="adjustZoom(-10)" class="text-[#4D4D4F] hover:text-[#1D1D1F] font-bold cursor-pointer" title="Zoom Out">-</button>
          <span class="font-mono w-10 text-center text-[11px] text-[#007AFF] font-semibold">{{ docService.zoom() }}%</span>
          <button type="button" (click)="adjustZoom(10)" class="text-[#4D4D4F] hover:text-[#1D1D1F] font-bold cursor-pointer" title="Zoom In">+</button>
        </div>
      </div>

      <!-- Right: Advanced Automation & Export -->
      <div class="flex items-center gap-2">
        <!-- AI Studio Button -->
        <button
          type="button"
          (click)="docService.showAiGeneratorModal.set(true)"
          class="flex items-center gap-1.5 px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded text-xs font-semibold border border-purple-200 transition-all cursor-pointer shadow-2xs">
          <mat-icon class="text-sm w-4 h-4 leading-4 text-purple-600">auto_awesome</mat-icon>
          <span>AI Layout</span>
        </button>

        <!-- Batch Studio -->
        <button
          type="button"
          (click)="docService.showBatchStudio.set(true)"
          class="flex items-center gap-1.5 px-3 py-1 bg-white hover:bg-gray-100 text-[#1D1D1F] border border-[#C6C6C8] rounded text-[11px] font-medium shadow-2xs active:bg-gray-100 cursor-pointer">
          <mat-icon class="text-sm w-4 h-4 leading-4 text-emerald-600">dynamic_feed</mat-icon>
          <span>Generate Batch</span>
        </button>

        <!-- Export PDF -->
        <button
          type="button"
          (click)="docService.showExportModal.set(true)"
          class="flex items-center gap-1.5 px-3 py-1 bg-[#007AFF] text-white rounded text-[11px] font-medium shadow-2xs active:bg-blue-600 transition-all cursor-pointer">
          <mat-icon class="text-sm w-4 h-4 leading-4">download</mat-icon>
          <span>Export PDF</span>
        </button>
      </div>
    </div>
  `
})
export class ToolbarComponent {
  docService = inject(DocumentService);

  adjustZoom(delta: number) {
    const current = this.docService.zoom();
    const next = Math.max(25, Math.min(500, current + delta));
    this.docService.zoom.set(next);
  }
}
