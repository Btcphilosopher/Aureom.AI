import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../services/document.service';
import { EngineService } from '../../services/engine.service';

interface CommandItem {
  label: string;
  icon: string;
  shortcut?: string;
  action: string;
}

interface ExportProfileOption {
  id: string;
  name: string;
  desc: string;
}

// --- 1. COMMAND PALETTE MODAL (⌘K) ---
@Component({
  selector: 'app-command-palette-modal',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (docService.showCommandPalette()) {
      <div class="fixed inset-0 bg-black/30 backdrop-blur-xs z-50 flex items-start justify-center pt-20 p-4">
        <button
          type="button"
          aria-label="Close modal overlay"
          class="fixed inset-0 cursor-default bg-transparent border-none p-0 outline-none"
          (click)="close()">
        </button>

        <div class="relative z-10 w-full max-w-xl bg-[#F5F5F7] border border-[#C6C6C8] rounded-xl shadow-2xl overflow-hidden flex flex-col text-[#1D1D1F]">
          <div class="p-3 border-b border-[#C6C6C8] bg-[#E5E5E7] flex items-center gap-2">
            <mat-icon class="text-[#007AFF] text-base w-4 h-4 leading-4">search</mat-icon>
            <input
              type="text"
              placeholder="Type a command or search tools... (e.g. 'Add Page', 'Table', 'Export', 'Batch')"
              [ngModel]="searchQuery()"
              (ngModelChange)="searchQuery.set($event)"
              class="w-full bg-transparent text-sm text-[#1D1D1F] focus:outline-none font-sans placeholder-[#8E8E93]">
            <span class="text-[10px] font-mono bg-white border border-[#C6C6C8] px-1.5 py-0.5 rounded text-[#4D4D4F] shadow-2xs">ESC</span>
          </div>

          <div class="max-h-80 overflow-y-auto p-2 space-y-1 custom-scrollbar">
            @for (cmd of filteredCommands(); track cmd.label) {
              <button
                type="button"
                (click)="execCmd(cmd)"
                class="w-full text-left px-3 py-2 rounded-lg hover:bg-[#007AFF] hover:text-white flex items-center justify-between text-xs cursor-pointer group transition-colors">
                <div class="flex items-center gap-2.5">
                  <mat-icon class="text-[#8E8E93] group-hover:text-white text-base w-4 h-4 leading-4">{{ cmd.icon }}</mat-icon>
                  <span class="font-medium">{{ cmd.label }}</span>
                </div>
                @if (cmd.shortcut) {
                  <span class="font-mono text-[10px] text-[#4D4D4F] group-hover:text-white bg-white group-hover:bg-[#0066CC] border border-[#C6C6C8] group-hover:border-transparent px-1.5 py-0.5 rounded shadow-2xs">
                    {{ cmd.shortcut }}
                  </span>
                }
              </button>
            }
          </div>
        </div>
      </div>
    }
  `
})
export class CommandPaletteModalComponent {
  docService = inject(DocumentService);
  searchQuery = signal<string>('');

  commands: CommandItem[] = [
    { label: 'New Blank Document', icon: 'note_add', shortcut: '⌘N', action: 'new' },
    { label: 'Add Document Page', icon: 'add_circle', action: 'add_page' },
    { label: 'Insert Text Block', icon: 'title', action: 'text' },
    { label: 'Insert Vector Rectangle', icon: 'crop_square', action: 'rect' },
    { label: 'Insert Data Table', icon: 'table_chart', action: 'table' },
    { label: 'Insert Vector Chart', icon: 'bar_chart', action: 'chart' },
    { label: 'Insert Image Asset', icon: 'image', action: 'image' },
    { label: 'Insert Form Field', icon: 'check_box', action: 'form' },
    { label: 'Export PDF Document', icon: 'download', shortcut: '⌘E', action: 'export' },
    { label: 'Launch Batch PDF Automation', icon: 'dynamic_feed', action: 'batch' },
    { label: 'Merge or Split PDFs', icon: 'call_merge', action: 'merge_split' },
    { label: 'Validate PDF SHA-256 Digest', icon: 'verified', action: 'validate' },
    { label: 'AI Document Studio (Gemini)', icon: 'auto_awesome', action: 'ai' },
    { label: 'Python Engine Diagnostics', icon: 'memory', action: 'health' }
  ];

  filteredCommands() {
    const q = this.searchQuery().toLowerCase().trim();
    if (!q) return this.commands;
    return this.commands.filter(c => c.label.toLowerCase().includes(q));
  }

  close() {
    this.docService.showCommandPalette.set(false);
  }

  execCmd(cmd: CommandItem) {
    this.close();
    switch (cmd.action) {
      case 'new': this.docService.document.set(this.docService.createDefaultDocument()); break;
      case 'add_page': this.docService.addPage(); break;
      case 'text': this.docService.addElement('text'); break;
      case 'rect': this.docService.addElement('rectangle'); break;
      case 'table': this.docService.addElement('table'); break;
      case 'chart': this.docService.addElement('chart'); break;
      case 'image': this.docService.addElement('image'); break;
      case 'form': this.docService.addElement('form_field'); break;
      case 'export': this.docService.showExportModal.set(true); break;
      case 'batch': this.docService.showBatchStudio.set(true); break;
      case 'merge_split': this.docService.showMergeSplitModal.set(true); break;
      case 'validate': this.docService.showValidationModal.set(true); break;
      case 'ai': this.docService.showAiGeneratorModal.set(true); break;
      case 'health': this.docService.showEngineHealthModal.set(true); break;
    }
  }
}

// --- 2. BATCH GENERATOR STUDIO MODAL ---
@Component({
  selector: 'app-batch-generator-modal',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (docService.showBatchStudio()) {
      <div class="fixed inset-0 bg-black/30 backdrop-blur-xs z-50 flex items-center justify-center p-4">
        <button
          type="button"
          aria-label="Close modal overlay"
          class="fixed inset-0 cursor-default bg-transparent border-none p-0 outline-none"
          (click)="close()">
        </button>

        <div class="relative z-10 w-full max-w-2xl bg-[#F5F5F7] border border-[#C6C6C8] rounded-xl shadow-2xl p-6 text-[#1D1D1F] space-y-4">
          <div class="flex items-center justify-between border-b border-[#C6C6C8] pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-600 text-xl w-6 h-6 leading-6">dynamic_feed</mat-icon>
              <div>
                <h3 class="text-base font-bold text-[#1D1D1F]">Batch Document Generator</h3>
                <p class="text-xs text-[#4D4D4F]">Data-driven automated PDF compilation from CSV/JSON datasets</p>
              </div>
            </div>
            <button type="button" (click)="close()" class="text-[#8E8E93] hover:text-[#1D1D1F] cursor-pointer font-bold text-lg">×</button>
          </div>

          <div class="space-y-3">
            <div class="bg-white p-4 rounded-lg border border-[#C6C6C8] shadow-2xs space-y-2">
              <span class="block text-xs font-semibold text-[#1D1D1F]">1. Paste CSV Data or Load Sample Dataset</span>
              <textarea
                rows="5"
                [ngModel]="csvData()"
                (ngModelChange)="csvData.set($event)"
                class="w-full bg-[#F5F5F7] border border-[#C6C6C8] rounded p-2 text-xs font-mono text-emerald-800 focus:outline-none focus:border-emerald-600 custom-scrollbar"
                placeholder="customer_name,invoice_number,date,total&#10;Acme Corp,INV-1001,2026-09-07,$12,400&#10;TechGlobal,INV-1002,2026-09-08,$8,950">
              </textarea>

              <div class="flex justify-between items-center text-[11px]">
                <button type="button" (click)="loadSampleCsv()" class="text-[#007AFF] hover:underline cursor-pointer font-medium">Load Sample CSV (5 records)</button>
                <span class="text-[#8E8E93] font-mono">Variables: {{ '{{customer_name}}' }}, {{ '{{invoice_number}}' }}, etc.</span>
              </div>
            </div>

            @if (isProcessing()) {
              <div class="bg-white p-4 rounded-lg border border-[#C6C6C8] space-y-2">
                <div class="flex justify-between text-xs font-mono">
                  <span class="text-emerald-700 font-bold">Compiling Batch PDFs...</span>
                  <span class="text-[#1D1D1F] font-bold">{{ currentProgress() }} / {{ totalRecords() }}</span>
                </div>
                <div class="w-full bg-[#E5E5E7] h-2.5 rounded-full overflow-hidden">
                  <div class="bg-emerald-600 h-full transition-all duration-200" [style.width.%]="(currentProgress() / max1(totalRecords())) * 100"></div>
                </div>
              </div>
            }

            @if (batchResults(); as res) {
              <div class="bg-emerald-50 border border-emerald-200 p-4 rounded-lg text-emerald-900 text-xs space-y-2">
                <div class="font-bold flex items-center gap-2">
                  <mat-icon class="text-base w-4 h-4 leading-4 text-emerald-600">check_circle</mat-icon>
                  <span>Batch Job Completed Successfully!</span>
                </div>
                <p>Processed {{ res.processed }} PDF document records deterministically.</p>
              </div>
            }
          </div>

          <div class="flex justify-end gap-2 pt-2 border-t border-[#C6C6C8]">
            <button type="button" (click)="close()" class="px-3 py-1.5 bg-[#E5E5E7] hover:bg-[#D1D1D3] text-[#1D1D1F] rounded text-xs cursor-pointer border border-[#C6C6C8]">Cancel</button>
            <button
              type="button"
              (click)="startBatchJob()"
              [disabled]="isProcessing()"
              class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded text-xs cursor-pointer shadow-xs flex items-center gap-1.5">
              <mat-icon class="text-sm w-4 h-4 leading-4">play_arrow</mat-icon>
              <span>Run Batch Compilation</span>
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class BatchGeneratorModalComponent {
  docService = inject(DocumentService);
  engineService = inject(EngineService);

  csvData = signal<string>(`customer_name,invoice_number,date,total
Acme Global,INV-8801,2026-09-01,$14,200.00
Nexus Systems,INV-8802,2026-09-02,$9,450.00
Aura AI Ltd,INV-8803,2026-09-03,$21,000.00
Zenith Corp,INV-8804,2026-09-04,$5,600.00`);

  isProcessing = signal<boolean>(false);
  currentProgress = signal<number>(0);
  totalRecords = signal<number>(0);
  batchResults = signal<{ status: string; processed?: number; error?: string } | null>(null);

  max1(n: number) { return Math.max(1, n); }

  loadSampleCsv() {
    this.csvData.set(`customer_name,invoice_number,date,total
Enterprise Tech,INV-9001,2026-09-07,$12,800.00
Omni Corp,INV-9002,2026-09-07,$34,500.00
Alpha Logistics,INV-9003,2026-09-07,$7,200.00
Beta Robotics,INV-9004,2026-09-07,$19,400.00
Gamma Labs,INV-9005,2026-09-07,$11,100.00`);
  }

  close() {
    this.docService.showBatchStudio.set(false);
  }

  async startBatchJob() {
    const rawCsv = this.csvData().trim();
    if (!rawCsv) return;

    const lines = rawCsv.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length < 2) return;

    const headers = lines[0].split(',').map(h => h.trim());
    const rows = lines.slice(1).map(line => {
      const parts = line.split(',');
      const rec: Record<string, string> = {};
      headers.forEach((h, idx) => rec[h] = parts[idx]?.trim() || '');
      return rec;
    });

    this.isProcessing.set(true);
    this.totalRecords.set(rows.length);
    this.currentProgress.set(0);

    for (let i = 1; i <= rows.length; i++) {
      this.currentProgress.set(i);
      await new Promise(r => setTimeout(r, 80));
    }

    const res = await this.engineService.batchProcess(this.docService.document(), rows);
    this.batchResults.set(res);
    this.isProcessing.set(false);
  }
}

// --- 3. MERGE & SPLIT MODAL ---
@Component({
  selector: 'app-merge-split-modal',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (docService.showMergeSplitModal()) {
      <div class="fixed inset-0 bg-black/30 backdrop-blur-xs z-50 flex items-center justify-center p-4">
        <button
          type="button"
          aria-label="Close modal overlay"
          class="fixed inset-0 cursor-default bg-transparent border-none p-0 outline-none"
          (click)="close()">
        </button>

        <div class="relative z-10 w-full max-w-xl bg-[#F5F5F7] border border-[#C6C6C8] rounded-xl shadow-2xl p-6 text-[#1D1D1F] space-y-4">
          <div class="flex items-center justify-between border-b border-[#C6C6C8] pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-[#007AFF] text-xl w-6 h-6 leading-6">call_merge</mat-icon>
              <div>
                <h3 class="text-base font-bold text-[#1D1D1F]">PDF Merge & Split Tool</h3>
                <p class="text-xs text-[#4D4D4F]">Combine multiple PDFs or extract specific page ranges</p>
              </div>
            </div>
            <button type="button" (click)="close()" class="text-[#8E8E93] hover:text-[#1D1D1F] cursor-pointer font-bold text-lg">×</button>
          </div>

          <div class="bg-white p-4 rounded-lg border border-[#C6C6C8] shadow-2xs space-y-3">
            <div class="flex items-center gap-3 border-b border-[#C6C6C8] pb-2">
              <button
                type="button"
                (click)="activeTab.set('merge')"
                class="px-3 py-1 rounded text-xs font-semibold cursor-pointer"
                [class.bg-[#007AFF]]="activeTab() === 'merge'"
                [class.text-white]="activeTab() === 'merge'"
                [class.text-[#4D4D4F]]="activeTab() !== 'merge'">
                Merge PDFs
              </button>
              <button
                type="button"
                (click)="activeTab.set('split')"
                class="px-3 py-1 rounded text-xs font-semibold cursor-pointer"
                [class.bg-[#007AFF]]="activeTab() === 'split'"
                [class.text-white]="activeTab() === 'split'"
                [class.text-[#4D4D4F]]="activeTab() !== 'split'">
                Split Current PDF
              </button>
            </div>

            @if (activeTab() === 'merge') {
              <div class="space-y-2 text-xs">
                <p class="text-[#4D4D4F]">Merges current active document with newly compiled page streams.</p>
                <button
                  type="button"
                  (click)="executeMerge()"
                  class="w-full py-2 bg-[#007AFF] hover:bg-[#0066CC] text-white font-semibold rounded cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-2xs">
                  <mat-icon class="text-sm w-4 h-4 leading-4">merge_type</mat-icon>
                  <span>Merge Document Streams</span>
                </button>
              </div>
            } @else {
              <div class="space-y-2 text-xs">
                <p class="text-[#4D4D4F]">Extracts pages into individual single-page PDF files.</p>
                <button
                  type="button"
                  (click)="executeSplit()"
                  class="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded cursor-pointer transition-colors flex items-center justify-center gap-1.5 shadow-2xs">
                  <mat-icon class="text-sm w-4 h-4 leading-4">call_split</mat-icon>
                  <span>Split All Pages into Separate PDFs</span>
                </button>
              </div>
            }

            @if (resultMsg()) {
              <div class="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded text-xs font-mono">
                {{ resultMsg() }}
              </div>
            }
          </div>
        </div>
      </div>
    }
  `
})
export class MergeSplitModalComponent {
  docService = inject(DocumentService);
  engineService = inject(EngineService);

  activeTab = signal<'merge' | 'split'>('merge');
  resultMsg = signal<string | null>(null);

  close() { this.docService.showMergeSplitModal.set(false); }

  async executeMerge() {
    const res = await this.engineService.renderDocument(this.docService.document());
    if (res.pdfBase64) {
      const merged = await this.engineService.mergePdfs([res.pdfBase64, res.pdfBase64]);
      this.resultMsg.set(`Merged 2 document copies into 1 PDF! Pages: ${merged.pages}, SHA-256: ${merged.sha256?.substring(0, 16)}...`);
    }
  }

  async executeSplit() {
    const res = await this.engineService.renderDocument(this.docService.document());
    if (res.pdfBase64) {
      const splitRes = await this.engineService.splitPdf(res.pdfBase64);
      this.resultMsg.set(`Split document into ${splitRes.splitPages?.length || 1} distinct PDF files!`);
    }
  }
}

// --- 4. VALIDATION MODAL ---
@Component({
  selector: 'app-validation-modal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (docService.showValidationModal()) {
      <div class="fixed inset-0 bg-black/30 backdrop-blur-xs z-50 flex items-center justify-center p-4">
        <button
          type="button"
          aria-label="Close modal overlay"
          class="fixed inset-0 cursor-default bg-transparent border-none p-0 outline-none"
          (click)="close()">
        </button>

        <div class="relative z-10 w-full max-w-lg bg-[#F5F5F7] border border-[#C6C6C8] rounded-xl shadow-2xl p-6 text-[#1D1D1F] space-y-4">
          <div class="flex items-center justify-between border-b border-[#C6C6C8] pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-600 text-xl w-6 h-6 leading-6">verified</mat-icon>
              <div>
                <h3 class="text-base font-bold text-[#1D1D1F]">PDF Validation & Integrity Pass</h3>
                <p class="text-xs text-[#4D4D4F]">Strict ISO 32000-1 specification validation pass</p>
              </div>
            </div>
            <button type="button" (click)="close()" class="text-[#8E8E93] hover:text-[#1D1D1F] cursor-pointer font-bold text-lg">×</button>
          </div>

          @if (valResult(); as val) {
            <div class="space-y-3 font-mono text-xs">
              <div class="p-3 bg-white rounded border border-[#C6C6C8] shadow-2xs space-y-1.5">
                <div class="flex justify-between"><span class="text-[#4D4D4F]">Status:</span><span class="text-emerald-700 font-bold">ISO VALIDATED</span></div>
                <div class="flex justify-between"><span class="text-[#4D4D4F]">Page Count:</span><span class="text-[#1D1D1F] font-bold">{{ val.pages }}</span></div>
                <div class="flex justify-between"><span class="text-[#4D4D4F]">File Size:</span><span class="text-[#1D1D1F] font-bold">{{ (val.sizeBytes || 0) / 1024 | number:'1.1-1' }} KB</span></div>
                <div class="flex justify-between"><span class="text-[#4D4D4F]">SHA-256 Hash:</span><span class="text-[#007AFF] break-all text-[10px]">{{ val.sha256 }}</span></div>
                <div class="flex justify-between"><span class="text-[#4D4D4F]">Object Integrity:</span><span class="text-emerald-700 font-bold">{{ val.objectIntegrity }}</span></div>
              </div>
            </div>
          } @else {
            <div class="text-center py-6">
              <button type="button" (click)="runValidation()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold cursor-pointer shadow-2xs">
                Run Validation Pass
              </button>
            </div>
          }
        </div>
      </div>
    }
  `
})
export class ValidationModalComponent {
  docService = inject(DocumentService);
  engineService = inject(EngineService);
  valResult = signal<{ pages?: number; sizeBytes?: number; sha256?: string; objectIntegrity?: string } | null>(null);

  close() { this.docService.showValidationModal.set(false); }

  async runValidation() {
    const res = await this.engineService.renderDocument(this.docService.document());
    if (res.pdfBase64) {
      const val = await this.engineService.validatePdf(res.pdfBase64);
      this.valResult.set(val);
    }
  }
}

// --- 5. EXPORT MODAL ---
@Component({
  selector: 'app-export-modal',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (docService.showExportModal()) {
      <div class="fixed inset-0 bg-black/30 backdrop-blur-xs z-50 flex items-center justify-center p-4">
        <button
          type="button"
          aria-label="Close modal overlay"
          class="fixed inset-0 cursor-default bg-transparent border-none p-0 outline-none"
          (click)="close()">
        </button>

        <div class="relative z-10 w-full max-w-lg bg-[#F5F5F7] border border-[#C6C6C8] rounded-xl shadow-2xl p-6 text-[#1D1D1F] space-y-4">
          <div class="flex items-center justify-between border-b border-[#C6C6C8] pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-[#007AFF] text-xl w-6 h-6 leading-6">download</mat-icon>
              <div>
                <h3 class="text-base font-bold text-[#1D1D1F]">Export Production PDF</h3>
                <p class="text-xs text-[#4D4D4F]">Select output profile and resolution specs</p>
              </div>
            </div>
            <button type="button" (click)="close()" class="text-[#8E8E93] hover:text-[#1D1D1F] cursor-pointer font-bold text-lg">×</button>
          </div>

          <div class="grid grid-cols-2 gap-2 text-xs">
            @for (prof of profiles; track prof.id) {
              <button
                type="button"
                (click)="selectedProfile.set(prof.id)"
                class="p-2.5 bg-white border rounded-lg cursor-pointer transition-all text-left shadow-2xs"
                [class.border-[#007AFF]]="selectedProfile() === prof.id"
                [class.bg-[#007AFF]/10]="selectedProfile() === prof.id"
                [class.border-[#C6C6C8]]="selectedProfile() !== prof.id">
                <div class="font-bold text-[#1D1D1F] mb-0.5">{{ prof.name }}</div>
                <div class="text-[10px] text-[#4D4D4F]">{{ prof.desc }}</div>
              </button>
            }
          </div>

          <button
            type="button"
            (click)="exportNow()"
            class="w-full py-2.5 bg-[#007AFF] hover:bg-[#0066CC] text-white font-bold rounded shadow-2xs text-xs cursor-pointer flex items-center justify-center gap-2">
            <mat-icon class="text-sm w-4 h-4 leading-4">file_download</mat-icon>
            <span>Download PDF File</span>
          </button>
        </div>
      </div>
    }
  `
})
export class ExportModalComponent {
  docService = inject(DocumentService);
  engineService = inject(EngineService);
  selectedProfile = signal<string>('print');

  profiles: ExportProfileOption[] = [
    { id: 'screen', name: 'Screen Standard (72 DPI)', desc: 'Optimized for fast web viewing.' },
    { id: 'print', name: 'Print Ready (300 DPI)', desc: 'High resolution vectors & embedded fonts.' },
    { id: 'press', name: 'Press Production', desc: 'Crop marks, bleed area, CMYK aware.' },
    { id: 'archive', name: 'Archive PDF/A', desc: 'Long term digital preservation compliant.' }
  ];

  close() { this.docService.showExportModal.set(false); }

  async exportNow() {
    const res = await this.engineService.renderDocument(this.docService.document());
    if (res.dataUrl) {
      const a = document.createElement('a');
      a.href = res.dataUrl;
      a.download = this.docService.document().name.replace('.macpdf', '.pdf');
      a.click();
      this.close();
    }
  }
}

// --- 6. AI LAYOUT GENERATOR MODAL (GEMINI) ---
@Component({
  selector: 'app-ai-generator-modal',
  imports: [CommonModule, FormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (docService.showAiGeneratorModal()) {
      <div class="fixed inset-0 bg-black/30 backdrop-blur-xs z-50 flex items-center justify-center p-4">
        <button
          type="button"
          aria-label="Close modal overlay"
          class="fixed inset-0 cursor-default bg-transparent border-none p-0 outline-none"
          (click)="close()">
        </button>

        <div class="relative z-10 w-full max-w-xl bg-[#F5F5F7] border border-[#C6C6C8] rounded-xl shadow-2xl p-6 text-[#1D1D1F] space-y-4">
          <div class="flex items-center justify-between border-b border-[#C6C6C8] pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-purple-600 text-xl w-6 h-6 leading-6">auto_awesome</mat-icon>
              <div>
                <h3 class="text-base font-bold text-[#1D1D1F]">AI Document Architect (Gemini)</h3>
                <p class="text-xs text-[#4D4D4F]">Describe any document to auto-generate vector layouts & tables</p>
              </div>
            </div>
            <button type="button" (click)="close()" class="text-[#8E8E93] hover:text-[#1D1D1F] cursor-pointer font-bold text-lg">×</button>
          </div>

          <div class="space-y-3 text-xs">
            <div>
              <span class="block font-semibold text-[#1D1D1F] mb-1">Document Specification Prompt</span>
              <textarea
                rows="4"
                [ngModel]="promptText()"
                (ngModelChange)="promptText.set($event)"
                placeholder="e.g. Create a 2-page SaaS Quarterly Financial Report with a revenue bar chart, executive summary, and project billing table for Acme Corp."
                class="w-full bg-white border border-[#C6C6C8] rounded p-2.5 text-[#1D1D1F] focus:outline-none focus:border-purple-600 custom-scrollbar shadow-2xs">
              </textarea>
            </div>

            @if (loading()) {
              <div class="p-4 bg-purple-50 border border-purple-200 rounded text-purple-900 flex items-center gap-3">
                <mat-icon class="text-xl w-5 h-5 leading-5 animate-spin text-purple-600">autorenew</mat-icon>
                <span>Synthesizing document architecture using Gemini AI...</span>
              </div>
            }
          </div>

          <div class="flex justify-end gap-2 pt-2 border-t border-[#C6C6C8]">
            <button type="button" (click)="close()" class="px-3 py-1.5 bg-[#E5E5E7] hover:bg-[#D1D1D3] text-[#1D1D1F] rounded text-xs cursor-pointer border border-[#C6C6C8]">Cancel</button>
            <button
              type="button"
              (click)="generateDocument()"
              [disabled]="loading()"
              class="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded text-xs cursor-pointer flex items-center gap-1.5 shadow-2xs">
              <mat-icon class="text-sm w-4 h-4 leading-4">auto_awesome</mat-icon>
              <span>Generate Document</span>
            </button>
          </div>
        </div>
      </div>
    }
  `
})
export class AiGeneratorModalComponent {
  docService = inject(DocumentService);
  engineService = inject(EngineService);

  promptText = signal<string>('Create a professional technical data sheet for an AI cloud server with spec table and performance chart.');
  loading = signal<boolean>(false);

  close() { this.docService.showAiGeneratorModal.set(false); }

  async generateDocument() {
    const p = this.promptText().trim();
    if (!p) return;

    this.loading.set(true);
    const res = await this.engineService.generateAiTemplate(p);
    this.loading.set(false);

    if (res.status === 'success' && res.document) {
      this.docService.loadDocumentTemplate(res.document);
      this.close();
    }
  }
}

// --- 7. ENGINE HEALTH MODAL ---
@Component({
  selector: 'app-engine-health-modal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (docService.showEngineHealthModal()) {
      <div class="fixed inset-0 bg-black/30 backdrop-blur-xs z-50 flex items-center justify-center p-4">
        <button
          type="button"
          aria-label="Close modal overlay"
          class="fixed inset-0 cursor-default bg-transparent border-none p-0 outline-none"
          (click)="close()">
        </button>

        <div class="relative z-10 w-full max-w-lg bg-[#F5F5F7] border border-[#C6C6C8] rounded-xl shadow-2xl p-6 text-[#1D1D1F] space-y-4">
          <div class="flex items-center justify-between border-b border-[#C6C6C8] pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-600 text-xl w-6 h-6 leading-6">memory</mat-icon>
              <div>
                <h3 class="text-base font-bold text-[#1D1D1F]">Python Engine Health & Diagnostics</h3>
                <p class="text-xs text-[#4D4D4F]">Local IPC process status & runtime telemetry</p>
              </div>
            </div>
            <button type="button" (click)="close()" class="text-[#8E8E93] hover:text-[#1D1D1F] cursor-pointer font-bold text-lg">×</button>
          </div>

          @if (docService.engineHealth(); as h) {
            <div class="font-mono text-xs space-y-2 bg-white p-4 rounded-lg border border-[#C6C6C8] shadow-2xs">
              <div class="flex justify-between"><span class="text-[#4D4D4F]">Status:</span><span class="text-emerald-700 font-bold">{{ h.status }}</span></div>
              <div class="flex justify-between"><span class="text-[#4D4D4F]">Python Version:</span><span class="text-[#1D1D1F] font-bold">{{ h.pythonVersion }}</span></div>
              <div class="flex justify-between"><span class="text-[#4D4D4F]">Renderer:</span><span class="text-[#1D1D1F] font-bold">{{ h.renderer }}</span></div>
              <div class="flex justify-between"><span class="text-[#4D4D4F]">Memory Usage:</span><span class="text-[#1D1D1F] font-bold">{{ h.memoryMb }} MB</span></div>
              <div class="flex justify-between"><span class="text-[#4D4D4F]">Total Rendered PDFs:</span><span class="text-[#1D1D1F] font-bold">{{ h.renderCount }}</span></div>
              <div class="flex justify-between"><span class="text-[#4D4D4F]">Average Render Latency:</span><span class="text-[#007AFF] font-bold">{{ h.avgRenderMs }} ms</span></div>
            </div>
          }
        </div>
      </div>
    }
  `
})
export class EngineHealthModalComponent {
  docService = inject(DocumentService);
  close() { this.docService.showEngineHealthModal.set(false); }
}
