import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../services/document.service';

@Component({
  selector: 'app-menu-bar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-7 bg-[#E5E5E7] border-b border-[#C6C6C8] flex items-center px-2 text-[12px] text-[#2C2C2E] select-none relative z-40 shrink-0">
      @for (menu of menus; track menu.name) {
        <div class="relative">
          <button
            type="button"
            (click)="toggleMenu(menu.name)"
            class="px-2.5 py-0.5 rounded hover:bg-[#D1D1D3] transition-colors cursor-pointer text-[#2C2C2E] font-medium"
            [class.bg-[#D1D1D3]]="openMenu() === menu.name">
            {{ menu.name }}
          </button>

          @if (openMenu() === menu.name) {
            <div class="absolute left-0 top-full mt-1 w-56 bg-white border border-[#C6C6C8] rounded-md shadow-xl py-1 text-[#1D1D1F] z-50">
              @for (item of menu.items; track item.label) {
                @if (item.divider) {
                  <div class="my-1 border-t border-[#E5E5E7]"></div>
                } @else {
                  <button
                    type="button"
                    (click)="execAction(item.action)"
                    class="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex items-center justify-between text-xs cursor-pointer group">
                    <span class="flex items-center gap-2">
                      @if (item.icon) {
                        <mat-icon class="text-xs w-3.5 h-3.5 leading-3.5 text-[#8E8E93] group-hover:text-white">{{ item.icon }}</mat-icon>
                      }
                      {{ item.label }}
                    </span>
                    @if (item.shortcut) {
                      <span class="text-[10px] text-[#8E8E93] group-hover:text-blue-100 font-mono">{{ item.shortcut }}</span>
                    }
                  </button>
                }
              }
            </div>
          }
        </div>
      }
    </div>

    @if (openMenu() !== null) {
      <button
        type="button"
        aria-label="Close overlay"
        class="fixed inset-0 z-30 cursor-default bg-transparent border-none p-0 outline-none"
        (click)="openMenu.set(null)">
      </button>
    }
  `
})
export class MenuBarComponent {
  docService = inject(DocumentService);
  openMenu = signal<string | null>(null);

  menus = [
    {
      name: 'File',
      items: [
        { label: 'New Document', shortcut: '⌘N', action: 'new_doc', icon: 'note_add' },
        { label: 'Open Template...', shortcut: '⌘O', action: 'open_template', icon: 'folder_open' },
        { label: 'Save Project (.macpdf)', shortcut: '⌘S', action: 'save_doc', icon: 'save' },
        { divider: true },
        { label: 'Export PDF...', shortcut: '⌘E', action: 'export_pdf', icon: 'picture_as_pdf' },
        { label: 'Export Profiles...', action: 'export_profiles', icon: 'tune' },
        { divider: true },
        { label: 'Document Settings...', action: 'doc_settings', icon: 'settings' }
      ]
    },
    {
      name: 'Edit',
      items: [
        { label: 'Undo', shortcut: '⌘Z', action: 'undo', icon: 'undo' },
        { label: 'Redo', shortcut: '⌘⇧Z', action: 'redo', icon: 'redo' },
        { divider: true },
        { label: 'Cut', shortcut: '⌘X', action: 'cut', icon: 'content_cut' },
        { label: 'Copy', shortcut: '⌘C', action: 'copy', icon: 'content_copy' },
        { label: 'Paste', shortcut: '⌘V', action: 'paste', icon: 'content_paste' },
        { label: 'Duplicate', shortcut: '⌘D', action: 'duplicate', icon: 'control_point_duplicate' },
        { label: 'Select All', shortcut: '⌘A', action: 'select_all', icon: 'select_all' },
        { label: 'Delete Selected', shortcut: 'Delete', action: 'delete', icon: 'delete' }
      ]
    },
    {
      name: 'Insert',
      items: [
        { label: 'Text Block', action: 'add_text', icon: 'title' },
        { label: 'Vector Rectangle', action: 'add_rect', icon: 'crop_square' },
        { label: 'Vector Ellipse / Circle', action: 'add_circle', icon: 'radio_button_unchecked' },
        { label: 'Line / Vector Path', action: 'add_line', icon: 'show_chart' },
        { divider: true },
        { label: 'Data Table', action: 'add_table', icon: 'table_chart' },
        { label: 'Vector Chart', action: 'add_chart', icon: 'bar_chart' },
        { label: 'Image Asset', action: 'add_image', icon: 'image' },
        { label: 'PDF Form Field', action: 'add_form', icon: 'check_box' }
      ]
    },
    {
      name: 'Format',
      items: [
        { label: 'Page Setup (A0 - A5, Custom)', action: 'page_setup', icon: 'aspect_ratio' },
        { label: 'Orientation (Portrait/Landscape)', action: 'toggle_orientation', icon: 'screen_rotation' },
        { label: 'Header & Footer Editor', action: 'edit_header_footer', icon: 'view_headline' },
        { label: 'Watermark Engine', action: 'edit_watermark', icon: 'subtitles' }
      ]
    },
    {
      name: 'Export',
      items: [
        { label: 'Production PDF Export', shortcut: '⌘E', action: 'export_pdf', icon: 'download' },
        { label: 'Validate PDF Integrity', action: 'validate_pdf', icon: 'verified' },
        { label: 'Export SHA-256 Digest', action: 'show_hash', icon: 'fingerprint' }
      ]
    },
    {
      name: 'Tools',
      items: [
        { label: 'Command Palette', shortcut: '⌘K', action: 'command_palette', icon: 'terminal' },
        { label: 'Batch PDF Generator...', action: 'batch_generator', icon: 'dynamic_feed' },
        { label: 'Merge & Split PDFs...', action: 'merge_split', icon: 'call_merge' },
        { label: 'AI Document Studio (Gemini)', action: 'ai_studio', icon: 'auto_awesome' },
        { divider: true },
        { label: 'Python Engine Health', action: 'engine_health', icon: 'monitor_heart' }
      ]
    }
  ];

  toggleMenu(name: string) {
    if (this.openMenu() === name) {
      this.openMenu.set(null);
    } else {
      this.openMenu.set(name);
    }
  }

  execAction(action?: string) {
    this.openMenu.set(null);
    if (!action) return;

    switch (action) {
      case 'new_doc':
        this.docService.document.set(this.docService.createDefaultDocument());
        break;
      case 'undo': this.docService.undo(); break;
      case 'redo': this.docService.redo(); break;
      case 'add_text': this.docService.addElement('text'); break;
      case 'add_rect': this.docService.addElement('rectangle'); break;
      case 'add_circle': this.docService.addElement('circle'); break;
      case 'add_line': this.docService.addElement('line'); break;
      case 'add_table': this.docService.addElement('table'); break;
      case 'add_chart': this.docService.addElement('chart'); break;
      case 'add_image': this.docService.addElement('image'); break;
      case 'add_form': this.docService.addElement('form_field'); break;
      case 'delete': this.docService.deleteSelectedElements(); break;
      case 'duplicate': this.docService.duplicateSelectedElements(); break;
      case 'select_all': this.docService.selectAll(); break;
      case 'command_palette': this.docService.showCommandPalette.set(true); break;
      case 'batch_generator': this.docService.showBatchStudio.set(true); break;
      case 'merge_split': this.docService.showMergeSplitModal.set(true); break;
      case 'validate_pdf': this.docService.showValidationModal.set(true); break;
      case 'export_pdf':
      case 'export_profiles': this.docService.showExportModal.set(true); break;
      case 'ai_studio': this.docService.showAiGeneratorModal.set(true); break;
      case 'engine_health': this.docService.showEngineHealthModal.set(true); break;
    }
  }
}
