import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DocumentService } from '../../services/document.service';

@Component({
  selector: 'app-window-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-10 bg-[#E5E5E7] border-b border-[#C6C6C8] flex items-center justify-between px-3 text-[#1D1D1F] select-none text-xs shrink-0">
      <!-- Left: macOS Traffic Lights & Title -->
      <div class="flex items-center gap-3">
        <div class="flex items-center gap-2 pr-2">
          <div class="w-3 h-3 rounded-full bg-[#FF5F57] hover:brightness-95 transition-all cursor-pointer flex items-center justify-center group" title="Close">
            <span class="opacity-0 group-hover:opacity-100 text-[9px] font-bold text-black/80">×</span>
          </div>
          <div class="w-3 h-3 rounded-full bg-[#FFBD2E] hover:brightness-95 transition-all cursor-pointer flex items-center justify-center group" title="Minimize">
            <span class="opacity-0 group-hover:opacity-100 text-[9px] font-bold text-black/80">-</span>
          </div>
          <div class="w-3 h-3 rounded-full bg-[#28C840] hover:brightness-95 transition-all cursor-pointer flex items-center justify-center group" title="Expand">
            <span class="opacity-0 group-hover:opacity-100 text-[9px] font-bold text-black/80">+</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <mat-icon class="text-[#007AFF] text-sm w-4 h-4 leading-4">picture_as_pdf</mat-icon>
          <span class="font-bold tracking-tight text-[#4D4D4F]">MACPDF.PRO</span>
          <span class="text-[#8E8E93]">•</span>
          <span class="text-[#1D1D1F] font-semibold truncate max-w-[200px]">{{ docService.document().name }}</span>
          <span class="px-1.5 py-0.5 text-[10px] bg-white text-[#007AFF] rounded font-mono border border-[#C6C6C8] shadow-2xs">.macpdf bundle</span>
        </div>
      </div>

      <!-- Center: Live Status Indicator -->
      <div class="flex items-center gap-2 bg-white px-3 py-1 rounded-full border border-[#C6C6C8] shadow-2xs text-[11px]">
        @if (docService.isRendering()) {
          <div class="w-2 h-2 rounded-full bg-[#007AFF] animate-ping"></div>
          <span class="text-[#007AFF] font-medium">Compiling PDF Engine...</span>
        } @else {
          <div class="w-2 h-2 rounded-full bg-[#28C840]"></div>
          <span class="text-[#28C840] font-semibold">Engine Synchronized</span>
        }
      </div>

      <!-- Right: System Diagnostics & Health -->
      <div class="flex items-center gap-2">
        <button
          type="button"
          (click)="docService.showEngineHealthModal.set(true)"
          class="flex items-center gap-1.5 px-2.5 py-1 bg-white hover:bg-gray-100 text-[#2C2C2E] rounded text-xs transition-colors cursor-pointer border border-[#C6C6C8] shadow-2xs">
          <mat-icon class="text-[#28C840] text-xs w-3.5 h-3.5 leading-3.5">memory</mat-icon>
          <span class="font-mono text-[10px]">Python 3.10</span>
          <span class="px-1 text-[9px] bg-emerald-50 text-emerald-700 rounded border border-emerald-200 font-semibold">ONLINE</span>
        </button>

        <button
          type="button"
          (click)="docService.showCommandPalette.set(true)"
          class="flex items-center gap-1 px-2.5 py-1 bg-[#007AFF]/10 hover:bg-[#007AFF]/20 text-[#007AFF] rounded transition-colors cursor-pointer border border-[#007AFF]/30">
          <span class="font-mono text-[11px] font-bold">⌘K</span>
          <span class="text-[10px] font-medium">Palette</span>
        </button>
      </div>
    </div>
  `
})
export class WindowHeaderComponent {
  docService = inject(DocumentService);
}
