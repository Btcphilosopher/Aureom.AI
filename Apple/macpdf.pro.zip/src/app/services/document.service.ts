import { Injectable, signal, computed, inject } from '@angular/core';
import {
  DocumentModel, PageModel, ElementModel, ElementType, PageSizeName,
  Orientation, RenderResult, EngineHealth
} from '../models/document.model';
import { EngineService } from './engine.service';

const PAGE_DIMENSIONS: Record<PageSizeName, { w: number; h: number }> = {
  A0: { w: 2383.94, h: 3370.39 },
  A1: { w: 1683.78, h: 2383.94 },
  A2: { w: 1190.55, h: 1683.78 },
  A3: { w: 841.89, h: 1190.55 },
  A4: { w: 595.28, h: 841.89 },
  A5: { w: 419.53, h: 595.28 },
  LETTER: { w: 612.00, h: 792.00 },
  LEGAL: { w: 612.00, h: 1008.00 },
  TABLOID: { w: 792.00, h: 1224.00 },
  EXECUTIVE: { w: 522.00, h: 756.00 },
  CUSTOM: { w: 600, h: 800 }
};

@Injectable({
  providedIn: 'root'
})
export class DocumentService {
  private engineService = inject(EngineService);

  // Signals for Reactive UI State
  document = signal<DocumentModel>(this.createDefaultDocument());
  activePageIndex = signal<number>(0);
  selectedElementIds = signal<string[]>([]);

  zoom = signal<number>(100); // percentage 25-500%
  pan = signal<{ x: number; y: number }>({ x: 0, y: 0 });
  snapToGrid = signal<boolean>(true);
  showGrid = signal<boolean>(true);
  showGuides = signal<boolean>(true);
  showRulers = signal<boolean>(true);
  isPreviewMode = signal<boolean>(false);

  // Live Render state
  latestRenderResult = signal<RenderResult | null>(null);
  isRendering = signal<boolean>(false);
  engineHealth = signal<EngineHealth | null>(null);

  // Command History for Undo/Redo
  private history: DocumentModel[] = [];
  private historyIndex = -1;
  canUndo = signal<boolean>(false);
  canRedo = signal<boolean>(false);

  // Modals / Overlays
  showCommandPalette = signal<boolean>(false);
  showBatchStudio = signal<boolean>(false);
  showMergeSplitModal = signal<boolean>(false);
  showValidationModal = signal<boolean>(false);
  showExportModal = signal<boolean>(false);
  showAiGeneratorModal = signal<boolean>(false);
  showEngineHealthModal = signal<boolean>(false);

  // Batch / Dataset State
  batchDataset = signal<{ headers: string[]; rows: Record<string, unknown>[] } | null>(null);

  // Computed signals
  activePage = computed<PageModel>(() => {
    const doc = this.document();
    const idx = this.activePageIndex();
    return doc.pages[idx] || doc.pages[0];
  });

  selectedElements = computed<ElementModel[]>(() => {
    const page = this.activePage();
    const ids = this.selectedElementIds();
    return page.elements.filter((e) => ids.includes(e.id));
  });

  singleSelectedElement = computed<ElementModel | null>(() => {
    const elems = this.selectedElements();
    return elems.length === 1 ? elems[0] : null;
  });

  private renderDebounceTimer: ReturnType<typeof setTimeout> | null = null;

  constructor() {
    this.saveHistoryState();
    this.refreshEngineHealth();
    this.triggerLiveRender();

    // Poll engine health every 15s
    setInterval(() => this.refreshEngineHealth(), 15000);
  }

  createDefaultDocument(): DocumentModel {
    const dim = PAGE_DIMENSIONS.A4;
    return {
      id: 'doc_' + Math.random().toString(36).substring(2, 9),
      name: 'Untitled PDF Project.macpdf',
      pageSize: 'A4',
      orientation: 'portrait',
      width: dim.w,
      height: dim.h,
      background: '#FFFFFF',
      header: 'MACPDF.PRO Studio Document',
      footer: 'Page {{page}} of {{total}}',
      watermark: '',
      metadata: {
        title: 'Executive Report',
        author: 'MACPDF.PRO User',
        subject: 'PDF Document Production',
        keywords: 'macOS, PDF, Report, Professional',
        creator: 'MACPDF.PRO macOS Studio',
        producer: 'Python ReportLab Engine'
      },
      pages: [
        {
          id: 'p_1',
          pageNumber: 1,
          width: dim.w,
          height: dim.h,
          elements: [
            {
              id: 'el_title',
              type: 'text',
              text: 'MACPDF.PRO Production Studio',
              x: 54,
              y: 50,
              width: 480,
              height: 40,
              fontSize: 26,
              fontWeight: 'bold',
              alignment: 'left',
              color: '#0F172A'
            },
            {
              id: 'el_subtitle',
              type: 'text',
              text: 'High-Performance macOS PDF Creation Engine • Python & Rust Architecture',
              x: 54,
              y: 95,
              width: 480,
              height: 20,
              fontSize: 12,
              fontWeight: 'medium',
              alignment: 'left',
              color: '#64748B'
            },
            {
              id: 'el_divider',
              type: 'rectangle',
              x: 54,
              y: 125,
              width: 487,
              height: 2,
              fill: '#2563EB',
              stroke: '#2563EB',
              strokeWidth: 1
            },
            {
              id: 'el_summary_box',
              type: 'rectangle',
              x: 54,
              y: 145,
              width: 487,
              height: 90,
              fill: '#F8FAFC',
              stroke: '#E2E8F0',
              strokeWidth: 1,
              borderRadius: 8
            },
            {
              id: 'el_summary_text',
              type: 'text',
              text: 'Welcome to MACPDF.PRO. This document is live-compiled using our native Python PDF engine. Supports vector graphics, high-density typography, dynamic tables, data-bound templates, and automated batch generation.',
              x: 70,
              y: 160,
              width: 455,
              height: 60,
              fontSize: 11,
              lineHeight: 1.4,
              color: '#334155'
            },
            {
              id: 'el_table_title',
              type: 'text',
              text: 'Financial Overview & Production Metrics',
              x: 54,
              y: 255,
              width: 480,
              height: 25,
              fontSize: 14,
              fontWeight: 'bold',
              color: '#1E293B'
            },
            {
              id: 'el_table_1',
              type: 'table',
              x: 54,
              y: 285,
              width: 487,
              height: 120,
              headers: ['PROJECT MODULE', 'STATUS', 'RENDERING', 'EST. TOTAL'],
              rows: [
                ['PDF Core Engine', 'PRODUCTION', 'ReportLab 3.10', '$12,400.00'],
                ['Batch Automation', 'ACTIVE', 'Data-Driven', '$8,950.00'],
                ['Vector Layout', 'PASS', '0.04s Latency', '$4,200.00']
              ],
              headerBackground: '#0F172A',
              headerTextColor: '#FFFFFF',
              borderColor: '#CBD5E1'
            },
            {
              id: 'el_chart_title',
              type: 'text',
              text: 'Quarterly Output Analytics',
              x: 54,
              y: 430,
              width: 480,
              height: 25,
              fontSize: 14,
              fontWeight: 'bold',
              color: '#1E293B'
            },
            {
              id: 'el_chart_1',
              type: 'chart',
              chartType: 'bar',
              title: 'Documents Generated (Thousands)',
              x: 54,
              y: 460,
              width: 487,
              height: 200,
              labels: ['Q1', 'Q2', 'Q3', 'Q4', 'Q5'],
              data: [42, 68, 85, 110, 145]
            }
          ]
        }
      ]
    };
  }

  // --- Document State Mutations & History ---
  private saveHistoryState() {
    const currentDoc = JSON.parse(JSON.stringify(this.document()));

    // Truncate future redos
    if (this.historyIndex < this.history.length - 1) {
      this.history = this.history.slice(0, this.historyIndex + 1);
    }

    this.history.push(currentDoc);
    this.historyIndex = this.history.length - 1;

    // Cap history length to 50
    if (this.history.length > 50) {
      this.history.shift();
      this.historyIndex--;
    }

    this.canUndo.set(this.historyIndex > 0);
    this.canRedo.set(this.historyIndex < this.history.length - 1);

    this.triggerLiveRender();
  }

  undo() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      this.document.set(JSON.parse(JSON.stringify(this.history[this.historyIndex])));
      this.canUndo.set(this.historyIndex > 0);
      this.canRedo.set(this.historyIndex < this.history.length - 1);
      this.triggerLiveRender();
    }
  }

  redo() {
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++;
      this.document.set(JSON.parse(JSON.stringify(this.history[this.historyIndex])));
      this.canUndo.set(this.historyIndex > 0);
      this.canRedo.set(this.historyIndex < this.history.length - 1);
      this.triggerLiveRender();
    }
  }

  // --- Live Debounced Render ---
  triggerLiveRender() {
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    this.isRendering.set(true);
    this.renderDebounceTimer = setTimeout(async () => {
      const res = await this.engineService.renderDocument(this.document());
      this.latestRenderResult.set(res);
      this.isRendering.set(false);
    }, 250);
  }

  async refreshEngineHealth() {
    const health = await this.engineService.getEngineHealth();
    this.engineHealth.set(health);
  }

  // --- Page Operations ---
  addPage() {
    const doc = this.document();
    const newPageNum = doc.pages.length + 1;
    const newPage: PageModel = {
      id: 'p_' + Math.random().toString(36).substring(2, 9),
      pageNumber: newPageNum,
      width: doc.width,
      height: doc.height,
      elements: [
        {
          id: 'el_p_title_' + newPageNum,
          type: 'text',
          text: `Section ${newPageNum}`,
          x: 54,
          y: 50,
          width: 480,
          height: 35,
          fontSize: 22,
          fontWeight: 'bold',
          color: '#0F172A'
        }
      ]
    };

    const updatedPages = [...doc.pages, newPage];
    this.document.set({ ...doc, pages: updatedPages });
    this.activePageIndex.set(updatedPages.length - 1);
    this.saveHistoryState();
  }

  duplicatePage(index: number) {
    const doc = this.document();
    if (index < 0 || index >= doc.pages.length) return;
    const target = doc.pages[index];
    const dupPage: PageModel = JSON.parse(JSON.stringify(target));
    dupPage.id = 'p_' + Math.random().toString(36).substring(2, 9);
    dupPage.pageNumber = doc.pages.length + 1;

    // re-id elements
    dupPage.elements.forEach((e) => {
      e.id = 'el_' + Math.random().toString(36).substring(2, 9);
    });

    const updatedPages = [...doc.pages];
    updatedPages.splice(index + 1, 0, dupPage);
    this.reindexPages(updatedPages);
    this.document.set({ ...doc, pages: updatedPages });
    this.activePageIndex.set(index + 1);
    this.saveHistoryState();
  }

  deletePage(index: number) {
    const doc = this.document();
    if (doc.pages.length <= 1) return; // Keep at least 1 page
    const updatedPages = doc.pages.filter((_, i) => i !== index);
    this.reindexPages(updatedPages);

    const nextIdx = Math.min(this.activePageIndex(), updatedPages.length - 1);
    this.document.set({ ...doc, pages: updatedPages });
    this.activePageIndex.set(nextIdx);
    this.saveHistoryState();
  }

  movePage(fromIndex: number, toIndex: number) {
    const doc = this.document();
    if (fromIndex < 0 || fromIndex >= doc.pages.length || toIndex < 0 || toIndex >= doc.pages.length) return;

    const updatedPages = [...doc.pages];
    const [moved] = updatedPages.splice(fromIndex, 1);
    updatedPages.splice(toIndex, 0, moved);

    this.reindexPages(updatedPages);
    this.document.set({ ...doc, pages: updatedPages });
    this.activePageIndex.set(toIndex);
    this.saveHistoryState();
  }

  private reindexPages(pages: PageModel[]) {
    pages.forEach((p, idx) => {
      p.pageNumber = idx + 1;
    });
  }

  // --- Element Operations ---
  addElement(type: ElementType) {
    const page = this.activePage();
    const newId = 'el_' + Math.random().toString(36).substring(2, 9);
    let newEl: ElementModel;

    switch (type) {
      case 'text':
        newEl = {
          id: newId,
          type: 'text',
          text: 'New Paragraph Text',
          x: 100,
          y: 100,
          width: 250,
          height: 30,
          fontSize: 14,
          fontWeight: 'normal',
          color: '#0F172A'
        };
        break;

      case 'rectangle':
        newEl = {
          id: newId,
          type: 'rectangle',
          x: 100,
          y: 100,
          width: 200,
          height: 100,
          fill: '#F1F5F9',
          stroke: '#94A3B8',
          strokeWidth: 1,
          borderRadius: 6
        };
        break;

      case 'circle':
        newEl = {
          id: newId,
          type: 'circle',
          x: 100,
          y: 100,
          width: 120,
          height: 120,
          fill: '#3B82F6',
          stroke: '#1D4ED8',
          strokeWidth: 2
        };
        break;

      case 'line':
        newEl = {
          id: newId,
          type: 'line',
          x: 100,
          y: 100,
          width: 200,
          height: 2,
          x2: 300,
          y2: 100,
          stroke: '#0F172A',
          strokeWidth: 2
        };
        break;

      case 'table':
        newEl = {
          id: newId,
          type: 'table',
          x: 80,
          y: 120,
          width: 420,
          height: 100,
          headers: ['Item Name', 'Quantity', 'Rate', 'Total'],
          rows: [
            ['Standard License', '1', '$299.00', '$299.00'],
            ['Support SLA', '12 mos', '$50.00', '$600.00']
          ],
          headerBackground: '#0F172A',
          headerTextColor: '#FFFFFF',
          borderColor: '#E2E8F0'
        };
        break;

      case 'chart':
        newEl = {
          id: newId,
          type: 'chart',
          chartType: 'bar',
          title: 'Monthly Progress',
          x: 80,
          y: 150,
          width: 420,
          height: 180,
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
          data: [25, 40, 60, 80, 95]
        };
        break;

      case 'image':
        newEl = {
          id: newId,
          type: 'image',
          x: 100,
          y: 100,
          width: 240,
          height: 160,
          src: 'https://picsum.photos/seed/macpdf/600/400',
          aspectRatio: 'fit'
        };
        break;

      case 'form_field':
        newEl = {
          id: newId,
          type: 'form_field',
          fieldType: 'text_input',
          placeholder: 'Full Legal Name',
          x: 100,
          y: 100,
          width: 260,
          height: 32,
          required: true
        };
        break;
    }

    this.updateActivePageElements([...page.elements, newEl]);
    this.selectedElementIds.set([newId]);
    this.saveHistoryState();
  }

  updateElement(id: string, updates: Partial<ElementModel>) {
    const page = this.activePage();
    const updated = page.elements.map((el) => (el.id === id ? { ...el, ...updates } : el));
    this.updateActivePageElements(updated);
  }

  updateElementAndSaveHistory(id: string, updates: Partial<ElementModel>) {
    this.updateElement(id, updates);
    this.saveHistoryState();
  }

  deleteSelectedElements() {
    const ids = this.selectedElementIds();
    if (ids.length === 0) return;
    const page = this.activePage();
    const remaining = page.elements.filter((e) => !ids.includes(e.id));
    this.updateActivePageElements(remaining);
    this.selectedElementIds.set([]);
    this.saveHistoryState();
  }

  duplicateSelectedElements() {
    const page = this.activePage();
    const selected = this.selectedElements();
    if (selected.length === 0) return;

    const duplicates = selected.map((e) => {
      const copy: ElementModel = JSON.parse(JSON.stringify(e));
      copy.id = 'el_' + Math.random().toString(36).substring(2, 9);
      copy.x += 20;
      copy.y += 20;
      return copy;
    });

    this.updateActivePageElements([...page.elements, ...duplicates]);
    this.selectedElementIds.set(duplicates.map((d) => d.id));
    this.saveHistoryState();
  }

  selectElement(id: string, multiSelect = false) {
    if (multiSelect) {
      const current = this.selectedElementIds();
      if (current.includes(id)) {
        this.selectedElementIds.set(current.filter((i) => i !== id));
      } else {
        this.selectedElementIds.set([...current, id]);
      }
    } else {
      this.selectedElementIds.set([id]);
    }
  }

  clearSelection() {
    this.selectedElementIds.set([]);
  }

  selectAll() {
    const page = this.activePage();
    this.selectedElementIds.set(page.elements.map((e) => e.id));
  }

  private updateActivePageElements(elements: ElementModel[]) {
    const doc = this.document();
    const idx = this.activePageIndex();
    const updatedPages = [...doc.pages];
    updatedPages[idx] = { ...updatedPages[idx], elements };
    this.document.set({ ...doc, pages: updatedPages });
  }

  // --- Document Properties ---
  setPageSize(pageSize: PageSizeName, orientation: Orientation = 'portrait') {
    const dim = PAGE_DIMENSIONS[pageSize] || PAGE_DIMENSIONS.A4;
    const w = orientation === 'landscape' ? dim.h : dim.w;
    const h = orientation === 'landscape' ? dim.w : dim.h;

    const doc = this.document();
    const updatedPages = doc.pages.map((p) => ({ ...p, width: w, height: h }));

    this.document.set({
      ...doc,
      pageSize,
      orientation,
      width: w,
      height: h,
      pages: updatedPages
    });
    this.saveHistoryState();
  }

  setDocumentHeaderFooterWatermark(hdr?: string, ftr?: string, wtm?: string) {
    const doc = this.document();
    this.document.set({
      ...doc,
      header: hdr !== undefined ? hdr : doc.header,
      footer: ftr !== undefined ? ftr : doc.footer,
      watermark: wtm !== undefined ? wtm : doc.watermark
    });
    this.saveHistoryState();
  }

  loadDocumentTemplate(doc: DocumentModel) {
    this.document.set(doc);
    this.activePageIndex.set(0);
    this.selectedElementIds.set([]);
    this.history = [];
    this.historyIndex = -1;
    this.saveHistoryState();
  }
}
