import { Injectable } from '@angular/core';
import { DocumentModel, RenderResult, EngineHealth, ValidationResult } from '../models/document.model';

@Injectable({
  providedIn: 'root'
})
export class EngineService {
  private apiBase = '/api';

  async getEngineHealth(): Promise<EngineHealth> {
    try {
      const res = await fetch(`${this.apiBase}/engine/health`);
      if (!res.ok) throw new Error('Health check failed');
      return await res.json();
    } catch {
      return {
        status: 'OFFLINE',
        engine: 'Disconnected',
        pythonVersion: 'Unknown',
        renderer: 'Offline',
        renderCount: 0,
        avgRenderMs: 0,
        lastRenderMs: 0,
        memoryMb: 0,
        timestamp: new Date().toISOString()
      };
    }
  }

  async renderDocument(doc: DocumentModel): Promise<RenderResult> {
    try {
      const res = await fetch(`${this.apiBase}/render`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(doc)
      });
      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `HTTP ${res.status} Render Failed`);
      }
      return await res.json();
    } catch (e) {
      const err = e as Error;
      return {
        status: 'error',
        error: err.message || 'Render request failed'
      };
    }
  }

  async validatePdf(pdfBase64: string): Promise<ValidationResult> {
    try {
      const res = await fetch(`${this.apiBase}/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pdfBase64 })
      });
      return await res.json();
    } catch (e) {
      const err = e as Error;
      return {
        valid: false,
        error: err.message || 'Validation endpoint error'
      };
    }
  }

  async mergePdfs(pdfsBase64: string[]): Promise<RenderResult> {
    try {
      const res = await fetch(`${this.apiBase}/merge`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pdfsBase64 })
      });
      return await res.json();
    } catch (e) {
      const err = e as Error;
      return { status: 'error', error: err.message };
    }
  }

  async splitPdf(pdfBase64: string, ranges?: number[]): Promise<{ status: string; splitPages?: string[]; error?: string }> {
    try {
      const res = await fetch(`${this.apiBase}/split`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pdfBase64, ranges })
      });
      return await res.json();
    } catch (e) {
      const err = e as Error;
      return { status: 'error', error: err.message };
    }
  }

  async batchProcess(templateData: DocumentModel, rows: Record<string, unknown>[]): Promise<{ status: string; processed?: number; error?: string }> {
    try {
      const res = await fetch(`${this.apiBase}/batch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ templateData, rows })
      });
      return await res.json();
    } catch (e) {
      const err = e as Error;
      return { status: 'error', error: err.message };
    }
  }

  async generateAiTemplate(prompt: string, pageSize = 'A4', style = 'modern'): Promise<{ status: string; document?: DocumentModel; error?: string }> {
    try {
      const res = await fetch(`${this.apiBase}/ai/generate-template`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, pageSize, style })
      });
      return await res.json();
    } catch (e) {
      const err = e as Error;
      return { status: 'error', error: err.message };
    }
  }
}
