import { ChangeDetectionStrategy, Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WindowHeaderComponent } from './components/window-header/window-header';
import { MenuBarComponent } from './components/menu-bar/menu-bar';
import { ToolbarComponent } from './components/toolbar/toolbar';
import { SidebarLeftComponent } from './components/sidebar-left/sidebar-left';
import { CanvasComponent } from './components/canvas/canvas';
import { InspectorRightComponent } from './components/inspector-right/inspector-right';
import { StatusBarComponent } from './components/status-bar/status-bar';

import {
  CommandPaletteModalComponent,
  BatchGeneratorModalComponent,
  MergeSplitModalComponent,
  ValidationModalComponent,
  ExportModalComponent,
  AiGeneratorModalComponent,
  EngineHealthModalComponent
} from './components/modals/modals';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    WindowHeaderComponent,
    MenuBarComponent,
    ToolbarComponent,
    SidebarLeftComponent,
    CanvasComponent,
    InspectorRightComponent,
    StatusBarComponent,
    CommandPaletteModalComponent,
    BatchGeneratorModalComponent,
    MergeSplitModalComponent,
    ValidationModalComponent,
    ExportModalComponent,
    AiGeneratorModalComponent,
    EngineHealthModalComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {}
