export type PageSizeName = 'A0' | 'A1' | 'A2' | 'A3' | 'A4' | 'A5' | 'LETTER' | 'LEGAL' | 'TABLOID' | 'EXECUTIVE' | 'CUSTOM';
export type Orientation = 'portrait' | 'landscape';
export type ElementType = 'text' | 'rectangle' | 'circle' | 'line' | 'table' | 'chart' | 'image' | 'form_field';
export type ChartType = 'bar' | 'line' | 'area' | 'pie' | 'donut' | 'scatter' | 'histogram';
export type FormFieldType = 'text_input' | 'checkbox' | 'radio' | 'dropdown' | 'signature';

export interface ElementModel {
  id: string;
  type: ElementType;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation?: number; // degrees
  opacity?: number;  // 0 to 1
  zIndex?: number;
  locked?: boolean;

  // Text properties
  text?: string;
  fontSize?: number;
  fontWeight?: 'normal' | 'medium' | 'bold' | '600' | '700';
  fontStyle?: 'normal' | 'italic';
  fontFamily?: string;
  alignment?: 'left' | 'center' | 'right' | 'justified';
  color?: string;
  lineHeight?: number;
  letterSpacing?: number;

  // Shape properties
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  borderRadius?: number;

  // Line properties
  x2?: number;
  y2?: number;

  // Table properties
  headers?: string[];
  rows?: string[][];
  headerBackground?: string;
  headerTextColor?: string;
  borderColor?: string;

  // Chart properties
  chartType?: ChartType;
  title?: string;
  labels?: string[];
  data?: number[];
  seriesName?: string;

  // Image properties
  src?: string;
  aspectRatio?: 'fit' | 'fill' | 'cover';

  // Form Field properties
  fieldType?: FormFieldType;
  placeholder?: string;
  required?: boolean;
  options?: string[];

  // Data binding
  dataVariable?: string;
}

export interface PageModel {
  id: string;
  pageNumber: number;
  width: number;
  height: number;
  background?: string;
  elements: ElementModel[];
  header?: string;
  footer?: string;
  watermark?: string;
}

export interface DocumentMetadata {
  title: string;
  author: string;
  subject: string;
  keywords: string;
  creator: string;
  producer: string;
  creationDate?: string;
}

export interface DocumentModel {
  id: string;
  name: string;
  pageSize: PageSizeName;
  orientation: Orientation;
  width: number;
  height: number;
  background?: string;
  header?: string;
  footer?: string;
  watermark?: string;
  metadata: DocumentMetadata;
  pages: PageModel[];
  margins?: { top: number; right: number; bottom: number; left: number };
  bleed?: number;
}

export interface RenderResult {
  status: 'success' | 'error';
  pages?: number;
  sizeBytes?: number;
  sha256?: string;
  renderTimeMs?: number;
  pdfBase64?: string;
  dataUrl?: string;
  error?: string;
}

export interface EngineHealth {
  status: 'ONLINE' | 'OFFLINE';
  engine: string;
  pythonVersion: string;
  renderer: string;
  renderCount: number;
  avgRenderMs: number;
  lastRenderMs: number;
  memoryMb: number;
  timestamp: string;
}

export interface ValidationResult {
  valid: boolean;
  sizeBytes?: number;
  pages?: number;
  sha256?: string;
  readable?: boolean;
  objectIntegrity?: string;
  title?: string;
  author?: string;
  producer?: string;
  error?: string;
}

export type ExportProfile = 'screen' | 'print' | 'press' | 'archive' | 'web' | 'email';
