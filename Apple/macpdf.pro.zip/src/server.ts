import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { exec, execSync } from 'node:child_process';
import { writeFileSync, readFileSync, existsSync, mkdirSync, unlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import crypto from 'node:crypto';
import { PDFDocument } from 'pdf-lib';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static assets from /browser
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

// Health / Diagnostics Stats
let renderCount = 0;
let totalRenderTimeMs = 0;
let lastRenderDurationMs = 0;

app.get('/api/engine/health', (req, res) => {
  let pythonVersion = '3.10';
  try {
    const versionOut = execSync('python3 --version').toString().trim();
    pythonVersion = versionOut.replace('Python ', '');
  } catch {
    // fallback if python binary not directly in sync path
  }

  const memUsage = process.memoryUsage();
  res.json({
    status: 'ONLINE',
    engine: 'Python 3.10+ / PDF-Lib Hybrid',
    pythonVersion,
    renderer: 'READY',
    renderCount,
    avgRenderMs: renderCount > 0 ? Math.round(totalRenderTimeMs / renderCount) : 0,
    lastRenderMs: lastRenderDurationMs,
    memoryMb: Math.round(memUsage.heapUsed / 1024 / 1024),
    timestamp: new Date().toISOString()
  });
});

// Render Document JSON to PDF
app.post('/api/render', async (req, res) => {
  const startTime = Date.now();
  try {
    const docData = req.body;
    if (!docData || typeof docData !== 'object') {
      res.status(400).json({ error: 'Invalid document JSON payload' });
      return;
    }

    const tmpDir = join(tmpdir(), 'macpdf_tmp');
    if (!existsSync(tmpDir)) {
      mkdirSync(tmpDir, { recursive: true });
    }

    const docId = crypto.randomUUID();
    const jsonPath = join(tmpDir, `doc_${docId}.json`);
    const pdfPath = join(tmpDir, `out_${docId}.pdf`);

    writeFileSync(jsonPath, JSON.stringify(docData), 'utf-8');

    // Execute Python PDF Engine
    const pythonScript = join(process.cwd(), 'python-engine', 'macpdf_engine.py');
    const cmd = `python3 "${pythonScript}" render "${jsonPath}" -o "${pdfPath}"`;

    exec(cmd, (error, stdout, stderr) => {
      try {
        if (existsSync(jsonPath)) unlinkSync(jsonPath);
      } catch {
        /* ignore cleanup error */
      }

      if (error || !existsSync(pdfPath)) {
        console.error('Python Engine error:', stderr || error?.message);
        res.status(500).json({
          status: 'error',
          error: stderr || error?.message || 'Failed to render PDF in Python engine'
        });
        return;
      }

      const pdfBuffer = readFileSync(pdfPath);
      try {
        if (existsSync(pdfPath)) unlinkSync(pdfPath);
      } catch {
        /* ignore cleanup error */
      }

      const sha256 = crypto.createHash('sha256').update(pdfBuffer).digest('hex');
      const base64Pdf = pdfBuffer.toString('base64');

      renderCount++;
      lastRenderDurationMs = Date.now() - startTime;
      totalRenderTimeMs += lastRenderDurationMs;

      res.json({
        status: 'success',
        pages: docData.pages ? docData.pages.length : 1,
        sizeBytes: pdfBuffer.length,
        sha256,
        renderTimeMs: lastRenderDurationMs,
        pdfBase64: base64Pdf,
        dataUrl: `data:application/pdf;base64,${base64Pdf}`
      });
    });

  } catch (err) {
    const error = err as Error;
    res.status(500).json({ error: error.message || 'Internal server render error' });
  }
});

// Validate PDF Buffer
app.post('/api/validate', async (req, res) => {
  try {
    const { pdfBase64 } = req.body;
    if (!pdfBase64) {
      res.status(400).json({ valid: false, error: 'No PDF base64 payload provided' });
      return;
    }

    const buffer = Buffer.from(pdfBase64, 'base64');
    const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');

    try {
      const pdfDoc = await PDFDocument.load(buffer, { ignoreEncryption: true });
      const pageCount = pdfDoc.getPageCount();

      res.json({
        valid: true,
        sizeBytes: buffer.length,
        pages: pageCount,
        sha256,
        readable: true,
        objectIntegrity: 'PASS',
        title: pdfDoc.getTitle() || 'Untitled Document',
        author: pdfDoc.getAuthor() || 'Unknown',
        producer: pdfDoc.getProducer() || 'MACPDF.PRO Engine'
      });
    } catch (e) {
      const error = e as Error;
      res.json({
        valid: false,
        sizeBytes: buffer.length,
        sha256,
        error: `PDF stream corrupt or unreadable: ${error.message}`
      });
    }
  } catch (err) {
    const error = err as Error;
    res.status(500).json({ error: error.message });
  }
});

// Merge Multiple PDFs
app.post('/api/merge', async (req, res) => {
  try {
    const { pdfsBase64 } = req.body; // Array of base64 PDF strings
    if (!Array.isArray(pdfsBase64) || pdfsBase64.length === 0) {
      res.status(400).json({ error: 'Array of base64 PDFs is required' });
      return;
    }

    const mergedPdf = await PDFDocument.create();

    for (const base64Str of pdfsBase64) {
      const pdfBytes = Buffer.from(base64Str, 'base64');
      const doc = await PDFDocument.load(pdfBytes);
      const copiedPages = await mergedPdf.copyPages(doc, doc.getPageIndices());
      copiedPages.forEach((page) => mergedPdf.addPage(page));
    }

    const mergedBytes = await mergedPdf.save();
    const mergedBase64 = Buffer.from(mergedBytes).toString('base64');
    const sha256 = crypto.createHash('sha256').update(mergedBytes).digest('hex');

    res.json({
      status: 'success',
      pages: mergedPdf.getPageCount(),
      sizeBytes: mergedBytes.length,
      sha256,
      dataUrl: `data:application/pdf;base64,${mergedBase64}`
    });
  } catch (err) {
    const error = err as Error;
    res.status(500).json({ error: `Merge failed: ${error.message}` });
  }
});

// Split PDF
app.post('/api/split', async (req, res) => {
  try {
    const { pdfBase64, ranges } = req.body; // ranges: e.g. "1,2,3-5" or array of page numbers 0-indexed
    if (!pdfBase64) {
      res.status(400).json({ error: 'PDF base64 is required' });
      return;
    }

    const sourceDoc = await PDFDocument.load(Buffer.from(pdfBase64, 'base64'));
    const totalPages = sourceDoc.getPageCount();

    const outputDocs: { pageNumber: number; dataUrl: string; sizeBytes: number }[] = [];

    // Extract pages
    let pageIndicesToExtract: number[] = [];
    if (Array.isArray(ranges)) {
      pageIndicesToExtract = ranges.map((p: number) => p - 1).filter((p) => p >= 0 && p < totalPages);
    } else {
      pageIndicesToExtract = Array.from({ length: totalPages }, (_, i) => i);
    }

    for (const pageIdx of pageIndicesToExtract) {
      const singleDoc = await PDFDocument.create();
      const [copiedPage] = await singleDoc.copyPages(sourceDoc, [pageIdx]);
      singleDoc.addPage(copiedPage);

      const singleBytes = await singleDoc.save();
      const b64 = Buffer.from(singleBytes).toString('base64');
      outputDocs.push({
        pageNumber: pageIdx + 1,
        dataUrl: `data:application/pdf;base64,${b64}`,
        sizeBytes: singleBytes.length
      });
    }

    res.json({
      status: 'success',
      totalPages,
      splitPages: outputDocs
    });
  } catch (err) {
    const error = err as Error;
    res.status(500).json({ error: `Split failed: ${error.message}` });
  }
});

// Batch Template Generation
app.post('/api/batch', async (req, res) => {
  try {
    const { templateData, rows } = req.body; // rows is array of records
    if (!templateData || !Array.isArray(rows) || rows.length === 0) {
      res.status(400).json({ error: 'Template JSON and non-empty data rows array required' });
      return;
    }

    const generatedResults = [];
    const templateStr = JSON.stringify(templateData);

    // Render up to max batch size in memory safely
    const processRows = rows.slice(0, 100);

    for (let i = 0; i < processRows.length; i++) {
      const row = processRows[i];
      let rowJsonStr = templateStr;

      Object.keys(row).forEach((k) => {
        rowJsonStr = rowJsonStr.split(`{{${k}}}`).join(row[k]);
      });

      const rowDoc = JSON.parse(rowJsonStr);
      generatedResults.push({
        index: i + 1,
        record: row,
        document: rowDoc
      });
    }

    res.json({
      status: 'success',
      totalRecords: rows.length,
      processed: generatedResults.length,
      items: generatedResults
    });
  } catch (err) {
    const error = err as Error;
    res.status(500).json({ error: `Batch processing error: ${error.message}` });
  }
});

// AI Template & Document Generation via Gemini API
let genAiInstance: GoogleGenAI | null = null;
function getGenAi(): GoogleGenAI {
  if (!genAiInstance) {
    const key = process.env['GEMINI_API_KEY'];
    if (!key) {
      throw new Error('GEMINI_API_KEY environment variable is required');
    }
    genAiInstance = new GoogleGenAI({ apiKey: key });
  }
  return genAiInstance;
}

app.post('/api/ai/generate-template', async (req, res) => {
  try {
    const { prompt, pageSize = 'A4', style = 'modern' } = req.body;
    if (!prompt) {
      res.status(400).json({ error: 'Prompt is required' });
      return;
    }

    const ai = getGenAi();
    const systemInstruction = `You are the MACPDF.PRO AI Document Layout Architect.
Your task is to generate a valid MACPDF.PRO Document JSON structure matching the requested document specification.

Output ONLY valid JSON matching this schema:
{
  "pageSize": "A4",
  "orientation": "portrait",
  "background": "#FFFFFF",
  "header": "Company Header",
  "footer": "Page {{page}} of {{total}}",
  "watermark": "",
  "metadata": {
    "title": "Document Title",
    "author": "Author Name",
    "subject": "Subject"
  },
  "pages": [
    {
      "pageNumber": 1,
      "width": 595.28,
      "height": 841.89,
      "elements": [
        {
          "type": "text",
          "text": "Heading Text",
          "x": 50,
          "y": 50,
          "width": 495,
          "height": 40,
          "fontSize": 24,
          "fontWeight": "bold",
          "alignment": "left",
          "color": "#1E293B"
        },
        {
          "type": "rectangle",
          "x": 50,
          "y": 100,
          "width": 495,
          "height": 2,
          "fill": "#3B82F6",
          "stroke": "#3B82F6",
          "strokeWidth": 1
        },
        {
          "type": "table",
          "x": 50,
          "y": 120,
          "width": 495,
          "height": 140,
          "headers": ["Item", "Qty", "Price", "Total"],
          "rows": [
            ["Consulting Services", "10 hrs", "$150.00", "$1,500.00"],
            ["PDF Production Design", "1", "$800.00", "$800.00"]
          ],
          "headerBackground": "#0F172A",
          "headerTextColor": "#FFFFFF"
        },
        {
          "type": "chart",
          "chartType": "bar",
          "title": "Quarterly Revenue",
          "x": 50,
          "y": 280,
          "width": 495,
          "height": 180,
          "labels": ["Q1", "Q2", "Q3", "Q4"],
          "data": [1200, 1800, 2400, 3100]
        }
      ]
    }
  ]
}

DO NOT wrap in markdown formatting backticks if possible, or provide raw JSON directly.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        { role: 'user', parts: [{ text: `Generate a MACPDF.PRO JSON document for: ${prompt}. Style: ${style}, Page Size: ${pageSize}` }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.2
      }
    });

    const rawText = response.text || '';
    const cleanJson = rawText.replace(/```json/g, '').replace(/```/g, '').trim();

    const parsedDoc = JSON.parse(cleanJson);
    res.json({
      status: 'success',
      document: parsedDoc
    });
  } catch (err) {
    const error = err as Error;
    res.status(500).json({ error: `AI Document Generation failed: ${error.message}` });
  }
});

// SSR Catch-all handler
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

// Start Node server
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000;
  app.listen(port, () => {
    console.log(`MACPDF.PRO Engine Server running on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
