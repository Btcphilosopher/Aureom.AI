package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siri.engine.SiriAssistantViewModel
import com.example.siri.ui.*
import com.example.ui.theme.SiriCanvas
import com.example.ui.theme.SiriCardBorder
import com.example.ui.theme.SiriCardSurface
import com.example.ui.theme.SiriElectricBlue
import com.example.ui.theme.SiriTextPrimary
import com.example.ui.theme.SiriTextSecondary
import com.example.ui.theme.SiriTheme

data class NavigationTabItem(
    val title: String,
    val icon: ImageVector,
    val tag: String
)

class MainActivity : ComponentActivity() {

    private val viewModel: SiriAssistantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SiriTheme {
                val uiState by viewModel.uiState.collectAsState()

                val tabs = listOf(
                    NavigationTabItem("Siri", Icons.Default.AutoAwesome, "tab_assistant"),
                    NavigationTabItem("Estate", Icons.Default.Devices, "tab_estate"),
                    NavigationTabItem("Graph", Icons.Default.Share, "tab_graph"),
                    NavigationTabItem("Modes", Icons.Default.Dashboard, "tab_modes"),
                    NavigationTabItem("Lab", Icons.Default.Science, "tab_evaluation"),
                    NavigationTabItem("Privacy", Icons.Default.Security, "tab_privacy")
                )

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = SiriCanvas,
                    bottomBar = {
                        NavigationBar(
                            containerColor = SiriCardSurface,
                            tonalElevation = 8.dp,
                            modifier = Modifier.testTag("bottom_navigation_bar")
                        ) {
                            tabs.forEachIndexed { index, tab ->
                                val isSelected = uiState.selectedTab == index
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { viewModel.selectTab(index) },
                                    icon = {
                                        Icon(
                                            imageVector = tab.icon,
                                            contentDescription = tab.title,
                                            tint = if (isSelected) SiriElectricBlue else SiriTextSecondary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.title,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 10.sp,
                                                color = if (isSelected) SiriElectricBlue else SiriTextSecondary
                                            )
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = Color(0x1A2997FF)
                                    ),
                                    modifier = Modifier.testTag(tab.tag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.selectedTab) {
                            0 -> AssistantScreen(viewModel = viewModel)
                            1 -> EstateScreen(viewModel = viewModel)
                            2 -> KnowledgeGraphScreen(viewModel = viewModel)
                            3 -> ModesScreen(viewModel = viewModel)
                            4 -> EvaluationScreen(viewModel = viewModel)
                            5 -> SettingsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
