package com.example.siri.model

enum class TrustDomain(val label: String, val trustLevel: Int) {
    SYSTEM_POLICY("System Policy (Authority)", 100),
    USER_INSTRUCTION("Direct User Instruction", 90),
    TOOL_RESULT("Structured Tool Result", 80),
    EXTERNAL_CONTENT("External Untrusted Web/Document", 20)
}

enum class DataClassification(val label: String, val requiresElevation: Boolean) {
    PUBLIC("Public Info", false),
    PERSONAL("Personal Activity", false),
    SENSITIVE("Private Messages / Documents", true),
    HIGHLY_SENSITIVE("Financial / Health / Authentication", true),
    LOCAL_ONLY("Strict On-Device Only", true)
}

enum class SourceType(val label: String) {
    PERSONAL_DATA("Personal Data"),
    LOCAL_DEVICE_DATA("Local Device State"),
    ON_SCREEN_VIEW("On-Screen View"),
    WEB_DATA("Verified Web Source"),
    MODEL_REASONING("Neural Synthesizer")
}

data class Provenance(
    val sourceType: SourceType,
    val sourceName: String,
    val entityId: String? = null,
    val retrievalTimeIso: String,
    val confidence: Float = 0.98f,
    val matchExplanation: String,
    val rawEvidence: String
)

data class ModelConfidence(
    val overallScore: Float,
    val intentConfidence: Float,
    val entityResolutionConfidence: Float,
    val uncertaintyReason: String? = null,
    val requiresClarification: Boolean = false
)

enum class InferenceLocation(val label: String) {
    ON_DEVICE_NPU("Apple Neural Engine (3nm On-Device)"),
    PRIVATE_CLOUD_COMPUTE("Apple Private Cloud Compute (Confidential VM)"),
    WEB_KNOWLEDGE_GATEWAY("Public Web Knowledge Gateway")
}
