package com.example.siri.model

import java.util.UUID

enum class DeviceType(val displayName: String, val iconName: String) {
    MAC("MacBook Pro 16\"", "laptop"),
    IPHONE("iPhone 16 Pro", "smartphone"),
    IPAD("iPad Pro 13\"", "tablet"),
    WATCH("Apple Watch Ultra 2", "watch"),
    AIRPODS("AirPods Pro 2", "headphones"),
    CARPLAY("CarPlay Automotive", "directions_car"),
    VISION_PRO("Apple Vision Pro", "visibility"),
    HOME("HomePod / Smart Hub", "home")
}

enum class SensorType {
    MICROPHONE, CAMERA, GPS, MOTION, HEART_RATE, SCREEN, NEURAL_ENGINE, AMBIENT_LIGHT
}

data class DeviceCapability(
    val type: DeviceType,
    val sensors: List<SensorType>,
    val computePowerTops: Int,
    val hasDisplay: Boolean,
    val batteryLevel: Float,
    val isCurrentDevice: Boolean = false
)

data class VisibleEntity(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val subtitle: String,
    val entityType: EntityType,
    val sourceApp: String,
    val rawContent: String,
    val boundingBox: String? = null
)

data class ScreenContext(
    val activeApp: String,
    val windowTitle: String,
    val visibleEntities: List<VisibleEntity>,
    val selectedText: String? = null,
    val rawScreenSummary: String
)

data class LocationContext(
    val placeName: String,
    val city: String,
    val latitude: Double,
    val longitude: Double,
    val semanticContext: String // e.g. "At Office", "In Transit", "At Home"
)

data class TemporalContext(
    val currentTimeIso: String,
    val timeOfDay: String, // "Morning", "Afternoon", "Evening"
    val dayOfWeek: String,
    val upcomingCalendarSummary: String,
    val temporalReferences: Map<String, String> // e.g. "yesterday" -> "2026-09-14", "next Thursday" -> "2026-09-24"
)

data class TaskContext(
    val activeProjectId: String? = null,
    val unfinishedTasks: List<String> = emptyList(),
    val currentWorkflowStep: String? = null
)

enum class PrivacyBoundary(val label: String) {
    LOCAL_ONLY("On-Device Isolated"),
    PRIVATE_CLOUD("Private Cloud Compute"),
    PUBLIC_WEB("Public Web Gateway")
}

data class PrivacyState(
    val boundary: PrivacyBoundary = PrivacyBoundary.LOCAL_ONLY,
    val activePermissions: Set<PermissionType> = setOf(PermissionType.READ, PermissionType.COMMUNICATE),
    val auditLoggingEnabled: Boolean = true,
    val strictInjectionDefense: Boolean = true
)

data class ContextSnapshot(
    val snapshotId: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val currentUserName: String = "Alex Mercer",
    val currentDevice: DeviceType = DeviceType.IPHONE,
    val screenContext: ScreenContext,
    val locationContext: LocationContext,
    val temporalContext: TemporalContext,
    val taskContext: TaskContext,
    val privacyState: PrivacyState,
    val networkState: String = "Wi-Fi 7 (Ultra Low Latency)"
)
