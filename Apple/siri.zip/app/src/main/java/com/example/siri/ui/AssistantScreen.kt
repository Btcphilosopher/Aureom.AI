package com.example.siri.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siri.engine.SiriAssistantViewModel
import com.example.siri.model.*
import com.example.ui.theme.*

@Composable
fun AssistantScreen(
    viewModel: SiriAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.turns.size) {
        if (uiState.turns.isNotEmpty()) {
            listState.animateScrollToItem(uiState.turns.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiriCanvas)
    ) {
        // Top Bar: Active State Indicator & Device Status
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(SiriElevatedSurface)
                    .border(1.dp, SiriCardBorder, RoundedCornerShape(20.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(
                            when (uiState.siriState) {
                                SiriState.IDLE -> SiriEmerald
                                SiriState.LISTENING -> SiriElectricBlue
                                SiriState.THINKING, SiriState.PLANNING -> SiriViolet
                                SiriState.WAITING_CONFIRMATION -> SiriAmber
                                else -> SiriCyan
                            }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = uiState.siriState.label,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = SiriTextPrimary,
                        fontSize = 12.sp
                    )
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SiriElevatedSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Privacy Sandbox",
                            tint = SiriEmerald,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Apple Neural Engine (3nm)",
                            style = MaterialTheme.typography.labelSmall.copy(color = SiriTextSecondary)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = { viewModel.clearConversation() },
                    modifier = Modifier.size(36.dp).testTag("clear_conversation_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Clear History",
                        tint = SiriTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Main Conversation Feed
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(uiState.turns, key = { it.id }) { turn ->
                ConversationTurnItem(
                    turn = turn,
                    onConfirm = { viewModel.confirmPendingAction(turn.id) },
                    onCancel = { viewModel.cancelPendingAction(turn.id) }
                )
            }
        }

        // Proactive Suggestion Chips
        if (uiState.suggestions.isNotEmpty()) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(uiState.suggestions) { suggestion ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = SiriCardSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                        modifier = Modifier
                            .clickable { viewModel.sendUserPrompt(suggestion.promptAction) }
                            .testTag("suggestion_${suggestion.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = SiriElectricBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = suggestion.title,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = SiriTextPrimary,
                                        fontSize = 12.sp
                                    )
                                )
                                Text(
                                    text = suggestion.category,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SiriTextSecondary,
                                        fontSize = 10.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Multimodal Input Bar with Siri Orb
        Surface(
            color = SiriCardSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Interactive Siri Orb / Mic trigger
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .clickable { viewModel.toggleMicrophone() }
                        .testTag("siri_orb_trigger"),
                    contentAlignment = Alignment.Center
                ) {
                    SiriOrbView(
                        siriState = uiState.siriState,
                        audioLevel = uiState.audioLevel,
                        orbSize = 50.dp
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Text Input
                TextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = {
                        Text(
                            text = "Ask, plan, or refer to what's on screen...",
                            style = MaterialTheme.typography.bodyMedium.copy(color = SiriTextTertiary)
                        )
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SiriElevatedSurface,
                        unfocusedContainerColor = SiriElevatedSurface,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = SiriTextPrimary,
                        unfocusedTextColor = SiriTextPrimary
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("prompt_input_field"),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Send Button
                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            viewModel.sendUserPrompt(textInput)
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (textInput.isNotBlank()) SiriElectricBlue else SiriPillSurface)
                        .testTag("send_prompt_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send Prompt",
                        tint = if (textInput.isNotBlank()) Color.White else SiriTextTertiary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ConversationTurnItem(
    turn: ConversationTurn,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    var isProvenanceExpanded by remember { mutableStateOf(false) }

    if (turn.role == MessageRole.USER) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Surface(
                shape = RoundedCornerShape(18.dp).copy(bottomEnd = androidx.compose.foundation.shape.CornerSize(4.dp)),
                color = SiriElectricBlue,
                modifier = Modifier.widthIn(max = 300.dp)
            ) {
                Text(
                    text = turn.text,
                    style = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
    } else if (turn.role == MessageRole.SYSTEM) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = SiriElevatedSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = null,
                    tint = SiriCyan,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = turn.text,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = SiriCyan,
                        fontSize = 12.sp
                    )
                )
            }
        }
    } else {
        // Siri Response Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(SiriCardSurface)
                .border(1.dp, SiriCardBorder, RoundedCornerShape(18.dp))
                .padding(14.dp)
        ) {
            // Header with Siri Identity
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(
                                androidx.compose.ui.graphics.Brush.linearGradient(
                                    listOf(SiriElectricBlue, SiriViolet)
                                )
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SIRI",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = SiriTextPrimary,
                            letterSpacing = 0.5.sp
                        )
                    )
                }

                if (turn.provenance != null) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SiriElevatedSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                        modifier = Modifier.clickable { isProvenanceExpanded = !isProvenanceExpanded }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isProvenanceExpanded) Icons.Default.ExpandLess else Icons.Default.Info,
                                contentDescription = "Inspect Provenance",
                                tint = SiriElectricBlue,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Evidence & Trace",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SiriElectricBlue,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Text Content
            Text(
                text = turn.text,
                style = MaterialTheme.typography.bodyLarge.copy(
                    lineHeight = 22.sp,
                    color = SiriTextPrimary
                )
            )

            // Detected Entities Tags
            if (turn.detectedEntities.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    turn.detectedEntities.take(3).forEach { entity ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SiriPillSurface
                        ) {
                            Text(
                                text = entity,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SiriTextSecondary,
                                    fontSize = 11.sp
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            // Structured Multi-Step Plan Tree (if present)
            if (turn.activePlan != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SiriElevatedSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccountTree,
                                contentDescription = null,
                                tint = SiriViolet,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Execution Plan: ${turn.activePlan.goal}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = SiriViolet,
                                    fontSize = 11.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        turn.activePlan.steps.forEach { step ->
                            Row(
                                modifier = Modifier.padding(vertical = 3.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = if (step.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                    contentDescription = null,
                                    tint = if (step.isCompleted) SiriEmerald else SiriTextTertiary,
                                    modifier = Modifier.size(13.dp).padding(top = 2.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "${step.stepIndex}. [${step.targetApp}] ${step.description}",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontSize = 11.sp,
                                            color = SiriTextPrimary
                                        )
                                    )
                                    if (step.executionResult != null) {
                                        Text(
                                            text = "→ ${step.executionResult}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 10.sp,
                                                color = SiriTextSecondary
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Confirmation Card (for High Risk Actions)
            if (turn.requiresConfirmation && !turn.isConfirmed) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SiriElevatedSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriAmber.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = SiriAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "High-Risk Action Confirmation",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SiriAmber,
                                    fontSize = 12.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = turn.activePlan?.confirmationPrompt ?: "Proceed with dispatching external communication?",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 12.sp,
                                color = SiriTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = onConfirm,
                                colors = ButtonDefaults.buttonColors(containerColor = SiriElectricBlue),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).testTag("confirm_action_button")
                            ) {
                                Text("Send Confirmation", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp, fontWeight = FontWeight.SemiBold))
                            }
                            OutlinedButton(
                                onClick = onCancel,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SiriCoral),
                                modifier = Modifier.testTag("cancel_action_button")
                            ) {
                                Text("Cancel", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp))
                            }
                        }
                    }
                }
            }

            // Expandable Provenance & Grounding Inspector
            AnimatedVisibility(visible = isProvenanceExpanded && turn.provenance != null) {
                val prov = turn.provenance!!
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SiriElevatedSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "PROVENANCE & AUDIT TRACE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SiriElectricBlue,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Source: ${prov.sourceName} (${prov.sourceType.label})",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp, color = SiriTextPrimary)
                        )
                        Text(
                            text = "Timestamp: ${prov.retrievalTimeIso}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp, color = SiriTextSecondary)
                        )
                        Text(
                            text = "Why Matched: ${prov.matchExplanation}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp, color = SiriTextPrimary)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Evidence: \"${prov.rawEvidence}\"",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = SiriCyan)
                        )
                    }
                }
            }
        }
    }
}
