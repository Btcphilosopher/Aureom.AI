package com.example.siri.model

import java.util.UUID

enum class EntityType(val label: String) {
    PERSON("Person"),
    PLACE("Place"),
    ORGANIZATION("Organization"),
    PROJECT("Project"),
    DOCUMENT("Document"),
    MESSAGE("Message"),
    EMAIL("Email"),
    PHOTO("Photo"),
    EVENT("Calendar Event"),
    TASK("Reminder / Task"),
    PRODUCT("Product"),
    TRIP("Trip"),
    SONG("Music"),
    NOTE("Note"),
    BOOKING("Reservation / Booking"),
    HOME_DEVICE("Home Device")
}

enum class RelationshipType(val label: String) {
    KNOWS("knows"),
    EMAILED("emailed"),
    MESSAGED("messaged"),
    MET("met with"),
    WORKS_ON("works on"),
    SENT("sent"),
    CREATED("created"),
    ATTENDED("attended"),
    RECOMMENDED("recommended"),
    LOCATED_AT("located at"),
    CONTAINS("contains"),
    PART_OF("part of"),
    DEPENDS_ON("depends on")
}

data class EntityNode(
    val id: String = UUID.randomUUID().toString(),
    val type: EntityType,
    val title: String,
    val subtitle: String,
    val properties: Map<String, String> = emptyMap(),
    val sourceApp: String,
    val timestamp: Long = System.currentTimeMillis(),
    val tags: List<String> = emptyList(),
    val isPrivate: Boolean = false
)

data class GraphEdge(
    val fromEntityId: String,
    val toEntityId: String,
    val relationship: RelationshipType,
    val contextNote: String? = null,
    val confidence: Float = 0.95f
)

data class PersonalKnowledgeGraph(
    val nodes: Map<String, EntityNode>,
    val edges: List<GraphEdge>
) {
    fun findNode(id: String): EntityNode? = nodes[id]

    fun search(query: String): List<EntityNode> {
        val q = query.trim().lowercase()
        return nodes.values.filter {
            it.title.lowercase().contains(q) ||
            it.subtitle.lowercase().contains(q) ||
            it.properties.values.any { p -> p.lowercase().contains(q) }
        }
    }

    fun getRelatedEntities(entityId: String): List<Pair<RelationshipType, EntityNode>> {
        val outgoing = edges.filter { it.fromEntityId == entityId }
            .mapNotNull { edge -> nodes[edge.toEntityId]?.let { edge.relationship to it } }
        val incoming = edges.filter { it.toEntityId == entityId }
            .mapNotNull { edge -> nodes[edge.fromEntityId]?.let { edge.relationship to it } }
        return outgoing + incoming
    }
}
