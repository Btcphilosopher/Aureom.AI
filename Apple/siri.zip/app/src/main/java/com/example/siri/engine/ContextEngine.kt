package com.example.siri.engine

import com.example.siri.data.SyntheticEstateData
import com.example.siri.model.*

class ContextEngine(
    private val graph: PersonalKnowledgeGraph = SyntheticEstateData.createInitialGraph()
) {
    var activeDevice: DeviceType = DeviceType.IPHONE
    var activeOnScreenApp: String = "Mail"
    var activeOnScreenTitle: String = "Booking: The Hoxton Shoreditch (LON-88492)"
    var activeVisibleEntities: List<VisibleEntity> = listOf(
        VisibleEntity(
            title = "The Hoxton, Shoreditch",
            subtitle = "Booking Ref: LON-88492 · Check-in: 15:00 BST",
            entityType = EntityType.BOOKING,
            sourceApp = "Mail",
            rawContent = "Booking Confirmation: The Hoxton Shoreditch. Check-in 15:00 BST on Thursday Sep 24. 81 Great Eastern St, London EC2A 3HX."
        )
    )

    fun buildContextSnapshot(): ContextSnapshot {
        val screenContext = ScreenContext(
            activeApp = activeOnScreenApp,
            windowTitle = activeOnScreenTitle,
            visibleEntities = activeVisibleEntities,
            rawScreenSummary = "Active display showing $activeOnScreenApp with document: \"$activeOnScreenTitle\"."
        )

        val locationContext = LocationContext(
            placeName = "Silicon Roundabout Workspace",
            city = "London",
            latitude = 51.5256,
            longitude = -0.0875,
            semanticContext = "At Office / Work Studio"
        )

        val temporalContext = TemporalContext(
            currentTimeIso = "2026-09-15T09:14:00+01:00",
            timeOfDay = "Morning",
            dayOfWeek = "Tuesday",
            upcomingCalendarSummary = "Next-Gen Summit in 9 days; Review with James tomorrow at 14:00.",
            temporalReferences = mapOf(
                "today" to "2026-09-15",
                "yesterday" to "2026-09-14",
                "tomorrow" to "2026-09-16",
                "next Thursday" to "2026-09-24",
                "last month" to "August 2026"
            )
        )

        val taskContext = TaskContext(
            activeProjectId = "project_atlas",
            unfinishedTasks = listOf("Send the proposal to James Taylor", "Confirm Shoreditch check-in time"),
            currentWorkflowStep = "Proposal Finalization"
        )

        return ContextSnapshot(
            currentUserName = "Alex Mercer",
            currentDevice = activeDevice,
            screenContext = screenContext,
            locationContext = locationContext,
            temporalContext = temporalContext,
            taskContext = taskContext,
            privacyState = PrivacyState()
        )
    }

    /**
     * Resolves references such as "this", "that", "the London one", "James", "the booking number"
     */
    fun resolveEntityReference(query: String, snapshot: ContextSnapshot): EntityResolutionResult {
        val lower = query.lowercase().trim()

        // 1. Check On-Screen entity if query refers to "this", "on screen", "looking at", "what's this"
        if (lower.contains("this") || lower.contains("on screen") || lower.contains("looking at") || lower.contains("check-in") || lower.contains("what is this") || lower.contains("what's this")) {
            val visible = snapshot.screenContext.visibleEntities.firstOrNull()
            if (visible != null) {
                return EntityResolutionResult(
                    resolvedEntity = EntityNode(
                        id = "onscreen_${visible.id}",
                        type = visible.entityType,
                        title = visible.title,
                        subtitle = visible.subtitle,
                        properties = mapOf("content" to visible.rawContent),
                        sourceApp = visible.sourceApp
                    ),
                    confidence = 0.99f,
                    provenanceSource = "On-Screen View Annotations (${snapshot.screenContext.activeApp})"
                )
            }
        }

        // 2. Reference to James
        if (lower.contains("james")) {
            val james = graph.findNode("person_james")
            if (james != null) {
                return EntityResolutionResult(
                    resolvedEntity = james,
                    confidence = 0.98f,
                    provenanceSource = "Contacts & Frequent Colleague Graph"
                )
            }
        }

        // 3. Reference to London Hotel / James recommended hotel
        if (lower.contains("hotel") || (lower.contains("london") && (lower.contains("booking") || lower.contains("stay")))) {
            val hoxton = graph.findNode("booking_hoxton")
            if (hoxton != null) {
                return EntityResolutionResult(
                    resolvedEntity = hoxton,
                    confidence = 0.97f,
                    provenanceSource = "Messages (Recommended by James) & Mail Confirmation"
                )
            }
        }

        // 4. Reference to Proposal / Document
        if (lower.contains("proposal") || lower.contains("document")) {
            val doc = graph.findNode("doc_proposal_v3")
            if (doc != null) {
                return EntityResolutionResult(
                    resolvedEntity = doc,
                    confidence = 0.96f,
                    provenanceSource = "Files (Modified yesterday by Alex Mercer)"
                )
            }
        }

        // 5. Reference to Peak District photos
        if (lower.contains("peak district") || lower.contains("photo") || lower.contains("trip")) {
            val photo = graph.findNode("photo_peak_district")
            if (photo != null) {
                return EntityResolutionResult(
                    resolvedEntity = photo,
                    confidence = 0.95f,
                    provenanceSource = "Photos Semantic Embedding Index"
                )
            }
        }

        // 6. Reference to Invoice
        if (lower.contains("invoice")) {
            val inv = graph.findNode("doc_invoice_last_month")
            if (inv != null) {
                return EntityResolutionResult(
                    resolvedEntity = inv,
                    confidence = 0.96f,
                    provenanceSource = "Files / Invoices (Hyve Cloud Aug 2026)"
                )
            }
        }

        // Fallback search
        val matches = graph.search(query)
        return if (matches.isNotEmpty()) {
            EntityResolutionResult(
                resolvedEntity = matches.first(),
                confidence = 0.90f,
                provenanceSource = "Personal Knowledge Graph"
            )
        } else {
            EntityResolutionResult(
                resolvedEntity = null,
                confidence = 0.30f,
                provenanceSource = "Unknown"
            )
        }
    }
}

data class EntityResolutionResult(
    val resolvedEntity: EntityNode?,
    val confidence: Float,
    val provenanceSource: String
)
