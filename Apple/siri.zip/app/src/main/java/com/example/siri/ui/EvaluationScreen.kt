package com.example.siri.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siri.engine.EvaluationLabEngine
import com.example.siri.engine.SiriAssistantViewModel
import com.example.siri.model.ActionJournalItem
import com.example.ui.theme.*

@Composable
fun EvaluationScreen(
    viewModel: SiriAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedSection by remember { mutableStateOf(0) } // 0: Master Demos, 1: Safety & Injection Benchmarks, 2: Action Journal

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiriCanvas)
            .padding(16.dp)
    ) {
        Text(
            text = "EVALUATION LAB & ACTION JOURNAL",
            style = MaterialTheme.typography.labelSmall.copy(
                color = SiriElectricBlue,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Architecture Verification Suite",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Section Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Master Demos (1-10)", "Safety Benchmarks", "Action Journal (${uiState.journalItems.size})").forEachIndexed { idx, title ->
                val isSelected = selectedSection == idx
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) SiriElectricBlue else SiriCardSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) SiriElectricBlue else SiriCardBorder),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { selectedSection = idx }
                        .testTag("eval_tab_$idx")
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = if (isSelected) Color.White else SiriTextSecondary,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            fontSize = 11.sp
                        ),
                        modifier = Modifier.padding(vertical = 8.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Active Section Content
        when (selectedSection) {
            0 -> {
                // Master Demos List
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(EvaluationLabEngine.masterDemos) { demo ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SiriCardSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = demo.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SiriElectricBlue,
                                            fontSize = 12.sp
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = SiriPillSurface
                                    ) {
                                        Text(
                                            text = demo.category,
                                            style = MaterialTheme.typography.labelSmall.copy(color = SiriCyan, fontSize = 10.sp),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Prompt: \"${demo.testPrompt}\"",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = SiriTextPrimary,
                                        fontSize = 12.sp
                                    )
                                )
                                Text(
                                    text = demo.description,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SiriTextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Expected: ${demo.expectedOutcome}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SiriEmerald,
                                        fontSize = 10.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        viewModel.runBenchmarkItem(demo)
                                        viewModel.selectTab(0) // Switch to Assistant to see execution
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SiriElevatedSurface),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriElectricBlue.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth().testTag("run_demo_${demo.id}")
                                ) {
                                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = SiriElectricBlue, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Execute Demonstration Turn", style = MaterialTheme.typography.bodyMedium.copy(color = SiriElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold))
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // Safety & Injection Benchmarks
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(EvaluationLabEngine.safetyBenchmarks) { test ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SiriCardSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = test.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SiriCoral,
                                            fontSize = 12.sp
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = SiriElevatedSurface
                                    ) {
                                        Text(
                                            text = "SECURITY KERNEL",
                                            style = MaterialTheme.typography.labelSmall.copy(color = SiriCoral, fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Attack Input: \"${test.testPrompt}\"",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = SiriTextPrimary,
                                        fontSize = 12.sp
                                    )
                                )
                                Text(
                                    text = test.description,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SiriTextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Protection Policy: ${test.expectedOutcome}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SiriCyan,
                                        fontSize = 10.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        viewModel.runBenchmarkItem(test)
                                        viewModel.selectTab(0)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SiriElevatedSurface),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriCoral.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth().testTag("run_safety_${test.id}")
                                ) {
                                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = SiriCoral, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Test Security Policy Interception", style = MaterialTheme.typography.bodyMedium.copy(color = SiriCoral, fontSize = 11.sp, fontWeight = FontWeight.SemiBold))
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                // Action Journal & Undo mechanism
                if (uiState.journalItems.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No structured actions executed yet.\nRun a demonstration or ask Siri to schedule / note an item.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = SiriTextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(uiState.journalItems, key = { it.id }) { item ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = SiriCardSurface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "${item.toolName} (${item.appTarget})",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = SiriElectricBlue,
                                                fontSize = 12.sp
                                            )
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (item.isUndone) SiriCoral.copy(alpha = 0.2f) else SiriEmerald.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = if (item.isUndone) "ROLLED BACK" else item.reversibility.label,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = if (item.isUndone) SiriCoral else SiriEmerald,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold
                                                ),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = item.intentDescription,
                                        style = MaterialTheme.typography.bodyMedium.copy(color = SiriTextPrimary, fontSize = 12.sp)
                                    )
                                    Text(
                                        text = item.resultSummary,
                                        style = MaterialTheme.typography.labelSmall.copy(color = SiriTextSecondary, fontSize = 11.sp)
                                    )

                                    if (item.undoAvailable && !item.isUndone) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        OutlinedButton(
                                            onClick = { viewModel.undoJournalAction(item) },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SiriAmber),
                                            modifier = Modifier.testTag("undo_action_${item.id}")
                                        ) {
                                            Icon(imageVector = Icons.Default.Undo, contentDescription = "Undo", modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Undo Action", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
