package com.example.siri.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siri.engine.SiriAssistantViewModel
import com.example.siri.model.PermissionType
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    viewModel: SiriAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var privateCloudComputeEnabled by remember { mutableStateOf(true) }
    var auditLoggingEnabled by remember { mutableStateOf(true) }
    var strictPromptDefenseEnabled by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiriCanvas)
            .padding(16.dp)
    ) {
        Text(
            text = "INTELLIGENCE & PRIVACY ARCHITECTURE",
            style = MaterialTheme.typography.labelSmall.copy(
                color = SiriElectricBlue,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Privacy & Security Kernel",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Section 1: Compute Routing Architecture
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SiriCardSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Memory, contentDescription = null, tint = SiriElectricBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Compute Routing Sandbox", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Private Cloud Compute", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = SiriTextPrimary))
                                Text("Cryptographically verifiable confidential VMs for complex plans with zero retention.", style = MaterialTheme.typography.labelSmall.copy(color = SiriTextSecondary))
                            }
                            Switch(
                                checked = privateCloudComputeEnabled,
                                onCheckedChange = { privateCloudComputeEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SiriElectricBlue)
                            )
                        }
                    }
                }
            }

            // Section 2: Security & Prompt Defense
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SiriCardSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = SiriEmerald, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Security Policies & Defenses", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Prompt Injection Kernel", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = SiriTextPrimary))
                                Text("Untrusted external web & document isolation.", style = MaterialTheme.typography.labelSmall.copy(color = SiriTextSecondary))
                            }
                            Switch(
                                checked = strictPromptDefenseEnabled,
                                onCheckedChange = { strictPromptDefenseEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SiriEmerald)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("On-Device Audit Logging", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold, color = SiriTextPrimary))
                                Text("Record tool invocation provenance to local Room DB.", style = MaterialTheme.typography.labelSmall.copy(color = SiriTextSecondary))
                            }
                            Switch(
                                checked = auditLoggingEnabled,
                                onCheckedChange = { auditLoggingEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = SiriElectricBlue)
                            )
                        }
                    }
                }
            }

            // Section 3: Permission Matrix
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SiriCardSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Checklist, contentDescription = null, tint = SiriViolet, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Authorized App Intents Matrix", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp))
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        PermissionType.values().forEach { perm ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Text(
                                    text = perm.label,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp, color = SiriTextPrimary)
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = SiriPillSurface
                                ) {
                                    Text(
                                        text = "AUTHORIZED",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = SiriEmerald,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
