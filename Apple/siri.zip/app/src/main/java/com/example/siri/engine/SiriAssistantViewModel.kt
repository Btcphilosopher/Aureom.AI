package com.example.siri.engine

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.siri.data.ConversationRecord
import com.example.siri.data.JournalRecord
import com.example.siri.data.MemoryRecord
import com.example.siri.data.SiriDatabase
import com.example.siri.data.SyntheticEstateData
import com.example.siri.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SiriUiState(
    val siriState: SiriState = SiriState.IDLE,
    val turns: List<ConversationTurn> = emptyList(),
    val activeSnapshot: ContextSnapshot,
    val activeDevice: DeviceType = DeviceType.IPHONE,
    val activeMode: OperatingMode = OperatingMode.STANDARD,
    val pendingConfirmationTurn: ConversationTurn? = null,
    val isMicActive: Boolean = false,
    val audioLevel: Float = 0.0f,
    val searchQuery: String = "",
    val searchResults: List<EntityNode> = emptyList(),
    val suggestions: List<ProactiveSuggestion> = emptyList(),
    val journalItems: List<ActionJournalItem> = emptyList(),
    val selectedTab: Int = 0, // 0: Assistant, 1: Estate & Screen, 2: Knowledge Graph, 3: Modes, 4: Evaluation Lab, 5: Privacy Settings
    val activeOnScreenContent: String = "Mail",
    val activeEvaluationLog: String? = null,
    val executionDomain: InferenceLocation = InferenceLocation.ON_DEVICE_NPU
)

class SiriAssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SiriDatabase.getDatabase(application)
    private val dao = db.siriDao()
    private val contextEngine = ContextEngine()
    private val actionOrchestrator = ActionOrchestrator(contextEngine)
    val personalGraph: PersonalKnowledgeGraph = SyntheticEstateData.createInitialGraph()

    private val _uiState = MutableStateFlow(
        SiriUiState(
            activeSnapshot = contextEngine.buildContextSnapshot(),
            suggestions = AnticipationEngine.generateProactiveSuggestions()
        )
    )
    val uiState: StateFlow<SiriUiState> = _uiState.asStateFlow()

    init {
        // Load initial greeting turn
        val initialTurn = ConversationTurn(
            role = MessageRole.SIRI,
            text = "Good morning, Alex. I'm ready with your personal context, active screen, and upcoming schedule.",
            confidence = 1.0f,
            provenance = Provenance(
                sourceType = SourceType.LOCAL_DEVICE_DATA,
                sourceName = "On-Device Context Engine",
                retrievalTimeIso = "2026-09-15T09:14:00+01:00",
                matchExplanation = "Context initialized for primary user Alex Mercer across 8 connected devices.",
                rawEvidence = "Estate: MacBook Pro, iPhone, iPad, Apple Watch, AirPods, Vision Pro."
            )
        )
        _uiState.update { it.copy(turns = listOf(initialTurn)) }
    }

    fun selectTab(index: Int) {
        _uiState.update { it.copy(selectedTab = index) }
    }

    fun setOperatingMode(mode: OperatingMode) {
        _uiState.update { it.copy(activeMode = mode) }
        when (mode) {
            OperatingMode.MORNING_BRIEF -> {
                sendUserPrompt("Show my Morning Brief")
            }
            OperatingMode.EVENING_REVIEW -> {
                sendUserPrompt("Show my Evening Review")
            }
            OperatingMode.TRAVEL -> {
                sendUserPrompt("I'm going to London next Thursday. Find the meeting in my calendar, check the train options, tell me what time I should leave, and put the itinerary in a note.")
            }
            OperatingMode.CARPLAY -> {
                switchDevice(DeviceType.CARPLAY)
            }
            OperatingMode.APPLE_WATCH -> {
                switchDevice(DeviceType.WATCH)
            }
            OperatingMode.VISION_PRO -> {
                switchDevice(DeviceType.VISION_PRO)
            }
            else -> {}
        }
    }

    fun switchDevice(device: DeviceType) {
        contextEngine.activeDevice = device
        val newSnapshot = contextEngine.buildContextSnapshot()
        _uiState.update {
            it.copy(
                activeDevice = device,
                activeSnapshot = newSnapshot
            )
        }
        // If continuing conversation across devices (Demo 6)
        val handoffTurn = ConversationTurn(
            role = MessageRole.SYSTEM,
            text = "Seamless Handoff: Context and state transferred to ${device.displayName} with zero data loss.",
            provenance = Provenance(
                sourceType = SourceType.LOCAL_DEVICE_DATA,
                sourceName = "Apple Continuity Engine",
                retrievalTimeIso = newSnapshot.temporalContext.currentTimeIso,
                matchExplanation = "Synchronized cryptographic context tokens across iCloud Keychain Enclave.",
                rawEvidence = "Device target: ${device.displayName}"
            )
        )
        _uiState.update { it.copy(turns = it.turns + handoffTurn) }
    }

    fun switchOnScreenApp(app: String) {
        when (app) {
            "Mail" -> {
                contextEngine.activeOnScreenApp = "Mail"
                contextEngine.activeOnScreenTitle = "Booking: The Hoxton Shoreditch (LON-88492)"
                contextEngine.activeVisibleEntities = listOf(
                    VisibleEntity(
                        title = "The Hoxton, Shoreditch",
                        subtitle = "Booking Ref: LON-88492 · Check-in: 15:00 BST",
                        entityType = EntityType.BOOKING,
                        sourceApp = "Mail",
                        rawContent = "Booking Confirmation: The Hoxton Shoreditch. Check-in 15:00 BST on Thursday Sep 24. 81 Great Eastern St, London EC2A 3HX."
                    )
                )
            }
            "Camera" -> {
                contextEngine.activeOnScreenApp = "Camera / Visual Intelligence"
                contextEngine.activeOnScreenTitle = "Live Optical Viewfinder (Restaurant Menu & Keynote Poster)"
                contextEngine.activeVisibleEntities = listOf(
                    VisibleEntity(
                        title = "Osteria Botanica - Evening Menu",
                        subtitle = "Wild Mushroom Agnolotti, Roman Artichokes, Broccolini Risotto",
                        entityType = EntityType.PHOTO,
                        sourceApp = "Camera",
                        rawContent = "Osteria Botanica Menu with vegetarian selections"
                    ),
                    VisibleEntity(
                        title = "AI Systems Keynote 2026 Poster",
                        subtitle = "Friday Oct 16, 2026 at 18:00 BST · Barbican Centre",
                        entityType = EntityType.PHOTO,
                        sourceApp = "Camera",
                        rawContent = "Tech Keynote Poster with date Oct 16, 2026 Barbican Centre"
                    )
                )
            }
            "Files" -> {
                contextEngine.activeOnScreenApp = "Files"
                contextEngine.activeOnScreenTitle = "Atlas_Architecture_v3.2_Draft.pdf"
                contextEngine.activeVisibleEntities = listOf(
                    VisibleEntity(
                        title = "Atlas_Architecture_v3.2_Draft.pdf",
                        subtitle = "Modified yesterday by Alex Mercer · 4.8 MB",
                        entityType = EntityType.DOCUMENT,
                        sourceApp = "Files",
                        rawContent = "Project Atlas architecture proposal detailing neural engine privacy sandbox."
                    )
                )
            }
            "Photos" -> {
                contextEngine.activeOnScreenApp = "Photos"
                contextEngine.activeOnScreenTitle = "Peak District Sunrise Vista (Stanage Edge)"
                contextEngine.activeVisibleEntities = listOf(
                    VisibleEntity(
                        title = "Peak District Sunrise Vista",
                        subtitle = "August 12, 2026 · Stanage Edge",
                        entityType = EntityType.PHOTO,
                        sourceApp = "Photos",
                        rawContent = "48MP ProRAW photo of mountain sunrise in Peak District"
                    )
                )
            }
        }
        _uiState.update {
            it.copy(
                activeOnScreenContent = app,
                activeSnapshot = contextEngine.buildContextSnapshot()
            )
        }
    }

    fun toggleMicrophone() {
        val current = _uiState.value.isMicActive
        if (!current) {
            _uiState.update {
                it.copy(
                    isMicActive = true,
                    siriState = SiriState.LISTENING,
                    audioLevel = 0.85f
                )
            }
            viewModelScope.launch {
                // Simulate voice waveform animation
                for (i in 1..4) {
                    delay(300)
                    _uiState.update { it.copy(audioLevel = (0.4f + (i % 3) * 0.25f)) }
                }
            }
        } else {
            _uiState.update {
                it.copy(
                    isMicActive = false,
                    audioLevel = 0.0f
                )
            }
        }
    }

    fun sendUserPrompt(promptText: String) {
        if (promptText.isBlank()) return

        val userTurn = ConversationTurn(
            role = MessageRole.USER,
            text = promptText
        )

        _uiState.update {
            it.copy(
                turns = it.turns + userTurn,
                siriState = SiriState.THINKING,
                isMicActive = false,
                audioLevel = 0.0f
            )
        }

        viewModelScope.launch {
            // Save turn to Room DB
            dao.insertConversationTurn(
                ConversationRecord(
                    role = "user",
                    text = promptText
                )
            )

            delay(400) // Fast neural reasoning
            _uiState.update { it.copy(siriState = SiriState.PLANNING) }
            delay(300)

            // Special handling for brief requests
            if (promptText.contains("morning brief", ignoreCase = true)) {
                val briefText = AnticipationEngine.generateMorningBrief()
                val briefTurn = ConversationTurn(
                    role = MessageRole.SIRI,
                    text = briefText,
                    provenance = Provenance(
                        sourceType = SourceType.PERSONAL_DATA,
                        sourceName = "Anticipation Engine (Calendar + Traffic + Tasks)",
                        retrievalTimeIso = "2026-09-15T09:14:00+01:00",
                        matchExplanation = "Synthesized active day plan with zero generic filler.",
                        rawEvidence = "Calendar, Weather, Unfinished proposal task."
                    )
                )
                _uiState.update { it.copy(turns = it.turns + briefTurn, siriState = SiriState.IDLE) }
                return@launch
            }

            if (promptText.contains("evening review", ignoreCase = true)) {
                val eveningText = AnticipationEngine.generateEveningReview()
                val eveningTurn = ConversationTurn(
                    role = MessageRole.SIRI,
                    text = eveningText,
                    provenance = Provenance(
                        sourceType = SourceType.PERSONAL_DATA,
                        sourceName = "Anticipation Engine (Completed & Pending Review)",
                        retrievalTimeIso = "2026-09-15T20:00:00+01:00",
                        matchExplanation = "Aggregated completed items and tomorrow's upcoming schedule.",
                        rawEvidence = "Journal records, Calendar schedule tomorrow."
                    )
                )
                _uiState.update { it.copy(turns = it.turns + eveningTurn, siriState = SiriState.IDLE) }
                return@launch
            }

            // Execute through ActionOrchestrator
            val result = actionOrchestrator.processUserIntent(promptText)

            val siriTurn = ConversationTurn(
                role = MessageRole.SIRI,
                text = result.siriResponseText,
                confidence = result.confidence,
                provenance = result.provenance,
                activePlan = result.plan,
                detectedEntities = result.detectedEntities,
                requiresConfirmation = result.requiresConfirmation,
                isConfirmed = false
            )

            // If a plan was executed, log to action journal
            if (result.plan != null && !result.requiresConfirmation) {
                val completedStep = result.plan.steps.firstOrNull { it.isCompleted }
                val journalItem = ActionJournalItem(
                    intentDescription = result.plan.goal,
                    appTarget = completedStep?.targetApp ?: "System",
                    toolName = completedStep?.tool?.name ?: "Action",
                    argumentsSummary = completedStep?.arguments?.toString() ?: "{}",
                    resultSummary = result.siriResponseText.take(120),
                    reversibility = result.plan.reversibility,
                    undoAvailable = result.plan.reversibility == Reversibility.REVERSIBLE
                )
                _uiState.update { it.copy(journalItems = listOf(journalItem) + it.journalItems) }

                dao.insertJournalRecord(
                    JournalRecord(
                        intentDescription = journalItem.intentDescription,
                        appTarget = journalItem.appTarget,
                        toolName = journalItem.toolName,
                        argumentsSummary = journalItem.argumentsSummary,
                        resultSummary = journalItem.resultSummary,
                        reversibility = journalItem.reversibility.name
                    )
                )
            }

            _uiState.update {
                it.copy(
                    turns = it.turns + siriTurn,
                    siriState = if (result.requiresConfirmation) SiriState.WAITING_CONFIRMATION else SiriState.SPEAKING,
                    pendingConfirmationTurn = if (result.requiresConfirmation) siriTurn else null
                )
            }

            // Transition to IDLE after speaking
            if (!result.requiresConfirmation) {
                delay(800)
                _uiState.update { it.copy(siriState = SiriState.IDLE) }
            }
        }
    }

    fun confirmPendingAction(turnId: String) {
        val pending = _uiState.value.pendingConfirmationTurn ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(siriState = SiriState.EXECUTING) }
            delay(400)

            val confirmedMsg = "Dispatched confirmation to **James Taylor** (+44 20 7946 0912): *\"Hey James! Here is my London hotel confirmation: The Hoxton Shoreditch (Ref: LON-88492), check-in Thursday Sep 24 at 15:00.\"*"

            val executionTurn = ConversationTurn(
                role = MessageRole.SIRI,
                text = confirmedMsg,
                confidence = 1.0f,
                provenance = Provenance(
                    sourceType = SourceType.PERSONAL_DATA,
                    sourceName = "Messages App Intent (Sent)",
                    retrievalTimeIso = "2026-09-15T09:15:00+01:00",
                    matchExplanation = "User confirmed high-risk outgoing communication action.",
                    rawEvidence = "Recipient: James Taylor. Status: Delivered via Apple iMessage."
                )
            )

            val journalItem = ActionJournalItem(
                intentDescription = "Send Hoxton Hotel booking confirmation to James Taylor",
                appTarget = "Messages",
                toolName = "SendMessage",
                argumentsSummary = "Recipient: James Taylor, Booking: LON-88492",
                resultSummary = "Delivered message to James Taylor",
                reversibility = Reversibility.IRREVERSIBLE,
                undoAvailable = false
            )

            _uiState.update {
                it.copy(
                    turns = it.turns.map { t -> if (t.id == turnId) t.copy(isConfirmed = true) else t } + executionTurn,
                    pendingConfirmationTurn = null,
                    siriState = SiriState.IDLE,
                    journalItems = listOf(journalItem) + it.journalItems
                )
            }
        }
    }

    fun cancelPendingAction(turnId: String) {
        val cancelTurn = ConversationTurn(
            role = MessageRole.SIRI,
            text = "Action cancelled. The message was not sent.",
            confidence = 1.0f
        )
        _uiState.update {
            it.copy(
                turns = it.turns + cancelTurn,
                pendingConfirmationTurn = null,
                siriState = SiriState.IDLE
            )
        }
    }

    fun undoJournalAction(item: ActionJournalItem) {
        viewModelScope.launch {
            val undoTurn = ConversationTurn(
                role = MessageRole.SYSTEM,
                text = "Undone action: ${item.intentDescription} (${item.appTarget}) has been rolled back.",
                confidence = 1.0f
            )
            _uiState.update {
                it.copy(
                    journalItems = it.journalItems.map { j -> if (j.id == item.id) j.copy(isUndone = true) else j },
                    turns = it.turns + undoTurn
                )
            }
        }
    }

    fun performUniversalSearch(query: String) {
        val results = if (query.isBlank()) emptyList() else personalGraph.search(query)
        _uiState.update {
            it.copy(
                searchQuery = query,
                searchResults = results
            )
        }
    }

    fun runBenchmarkItem(item: BenchmarkItem) {
        _uiState.update {
            it.copy(
                activeEvaluationLog = "Running ${item.title}...\nTarget: \"${item.testPrompt}\"\nExpected: ${item.expectedOutcome}"
            )
        }
        sendUserPrompt(item.testPrompt)
    }

    fun clearConversation() {
        viewModelScope.launch {
            dao.clearConversation()
            _uiState.update {
                it.copy(
                    turns = emptyList(),
                    pendingConfirmationTurn = null,
                    siriState = SiriState.IDLE
                )
            }
        }
    }
}
