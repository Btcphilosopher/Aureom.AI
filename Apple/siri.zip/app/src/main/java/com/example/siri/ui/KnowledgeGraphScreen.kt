package com.example.siri.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siri.engine.SiriAssistantViewModel
import com.example.siri.model.EntityNode
import com.example.siri.model.EntityType
import com.example.ui.theme.*

@Composable
fun KnowledgeGraphScreen(
    viewModel: SiriAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    var searchInput by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<EntityType?>(null) }
    var selectedEntity by remember { mutableStateOf<EntityNode?>(null) }

    val allNodes = remember { viewModel.personalGraph.nodes.values.toList() }

    val displayedNodes = remember(searchInput, selectedCategory) {
        var list = allNodes
        if (selectedCategory != null) {
            list = list.filter { it.type == selectedCategory }
        }
        if (searchInput.isNotBlank()) {
            val q = searchInput.lowercase().trim()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.subtitle.lowercase().contains(q) ||
                it.properties.values.any { p -> p.lowercase().contains(q) }
            }
        }
        list
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiriCanvas)
            .padding(16.dp)
    ) {
        Text(
            text = "PERSONAL KNOWLEDGE GRAPH & SPOTLIGHT",
            style = MaterialTheme.typography.labelSmall.copy(
                color = SiriElectricBlue,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Structured Personal Estate",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Universal Spotlight Search
        TextField(
            value = searchInput,
            onValueChange = {
                searchInput = it
                viewModel.performUniversalSearch(it)
            },
            placeholder = {
                Text(
                    text = "Spotlight Search (People, Hotels, Proposals, Trips...)",
                    style = MaterialTheme.typography.bodyMedium.copy(color = SiriTextTertiary)
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = SiriElectricBlue
                )
            },
            trailingIcon = {
                if (searchInput.isNotEmpty()) {
                    IconButton(onClick = { searchInput = "" }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = SiriTextSecondary)
                    }
                }
            },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = SiriCardSurface,
                unfocusedContainerColor = SiriCardSurface,
                focusedIndicatorColor = SiriElectricBlue,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = SiriTextPrimary,
                unfocusedTextColor = SiriTextPrimary
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().testTag("universal_search_field"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (selectedCategory == null) SiriElectricBlue else SiriCardSurface,
                    modifier = Modifier.clickable { selectedCategory = null }
                ) {
                    Text(
                        text = "All (${allNodes.size})",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = if (selectedCategory == null) Color.White else SiriTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
            items(EntityType.values()) { type ->
                val count = allNodes.count { it.type == type }
                if (count > 0) {
                    val isSelected = selectedCategory == type
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) SiriElectricBlue else SiriCardSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) SiriElectricBlue else SiriCardBorder),
                        modifier = Modifier.clickable { selectedCategory = if (isSelected) null else type }
                    ) {
                        Text(
                            text = "${type.label} ($count)",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (isSelected) Color.White else SiriTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Entities List & Graph Connections
        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(displayedNodes, key = { it.id }) { node ->
                val isExpanded = selectedEntity?.id == node.id
                val relatedEdges = if (isExpanded) viewModel.personalGraph.getRelatedEntities(node.id) else emptyList()

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SiriCardSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isExpanded) SiriElectricBlue else SiriCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedEntity = if (isExpanded) null else node }
                        .testTag("entity_node_${node.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (node.type) {
                                        EntityType.PERSON -> Icons.Default.Person
                                        EntityType.BOOKING -> Icons.Default.Hotel
                                        EntityType.EMAIL -> Icons.Default.Mail
                                        EntityType.MESSAGE -> Icons.Default.ChatBubble
                                        EntityType.EVENT -> Icons.Default.Event
                                        EntityType.DOCUMENT -> Icons.Default.Description
                                        EntityType.PHOTO -> Icons.Default.Photo
                                        EntityType.NOTE -> Icons.Default.Note
                                        EntityType.TASK -> Icons.Default.CheckCircle
                                        EntityType.HOME_DEVICE -> Icons.Default.Home
                                        else -> Icons.Default.Folder
                                    },
                                    contentDescription = null,
                                    tint = SiriElectricBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = node.title,
                                        style = MaterialTheme.typography.bodyLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SiriTextPrimary,
                                            fontSize = 13.sp
                                        )
                                    )
                                    Text(
                                        text = "${node.sourceApp} · ${node.type.label}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = SiriTextSecondary,
                                            fontSize = 10.sp
                                        )
                                    )
                                }
                            }
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = SiriTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = node.subtitle,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = SiriTextPrimary,
                                fontSize = 12.sp
                            )
                        )

                        if (isExpanded) {
                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = SiriCardBorder)
                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "PROPERTIES & METADATA",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SiriElectricBlue,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            node.properties.forEach { (k, v) ->
                                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                    Text(
                                        text = "$k: ",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = SiriTextSecondary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                    Text(
                                        text = v,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = SiriTextPrimary,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }

                            if (relatedEdges.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "GRAPH CONNECTIONS (${relatedEdges.size})",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SiriViolet,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                relatedEdges.forEach { (rel, target) ->
                                    Row(
                                        modifier = Modifier.padding(vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "—[${rel.label}]→ ",
                                            style = MaterialTheme.typography.labelSmall.copy(color = SiriViolet, fontSize = 11.sp)
                                        )
                                        Text(
                                            text = "${target.title} (${target.type.label})",
                                            style = MaterialTheme.typography.bodyMedium.copy(color = SiriTextPrimary, fontSize = 11.sp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
