package com.example.siri.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ConversationRecord::class,
        JournalRecord::class,
        MemoryRecord::class,
        AuditEventRecord::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SiriDatabase : RoomDatabase() {
    abstract fun siriDao(): SiriDao

    companion object {
        @Volatile
        private var INSTANCE: SiriDatabase? = null

        fun getDatabase(context: Context): SiriDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SiriDatabase::class.java,
                    "siri_nextgen_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
