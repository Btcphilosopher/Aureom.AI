package com.example.siri.engine

import com.example.siri.model.*
import java.util.UUID

object AppIntentsCatalog {

    val allTools: List<Tool> = listOf(
        // Messages
        Tool("tool_msg_send", "SendMessage", "Send an instant message to a contact", listOf(PermissionType.COMMUNICATE), RiskLevel.HIGH_RISK, Reversibility.IRREVERSIBLE, "Messages"),
        Tool("tool_msg_find", "FindMessage", "Find messages by sender, content, or entity", listOf(PermissionType.READ), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "Messages"),
        Tool("tool_msg_draft", "DraftMessage", "Create a message draft without sending", listOf(PermissionType.WRITE), RiskLevel.LOW_RISK, Reversibility.REVERSIBLE, "Messages"),

        // Mail
        Tool("tool_mail_find", "FindEmail", "Search emails by subject, sender, or date", listOf(PermissionType.READ), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "Mail"),
        Tool("tool_mail_send", "SendEmail", "Send an email to a recipient", listOf(PermissionType.COMMUNICATE), RiskLevel.HIGH_RISK, Reversibility.IRREVERSIBLE, "Mail"),
        Tool("tool_mail_draft", "DraftEmail", "Draft an email response", listOf(PermissionType.WRITE), RiskLevel.LOW_RISK, Reversibility.REVERSIBLE, "Mail"),

        // Calendar
        Tool("tool_cal_create", "CreateCalendarEvent", "Create a calendar event with time and attendees", listOf(PermissionType.WRITE), RiskLevel.MEDIUM_RISK, Reversibility.REVERSIBLE, "Calendar"),
        Tool("tool_cal_find", "FindCalendarEvents", "Look up schedule and conflicts", listOf(PermissionType.READ), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "Calendar"),

        // Notes
        Tool("tool_note_create", "CreateNote", "Create or append to a note", listOf(PermissionType.WRITE), RiskLevel.LOW_RISK, Reversibility.REVERSIBLE, "Notes"),
        Tool("tool_note_find", "FindNote", "Search notes archive", listOf(PermissionType.READ), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "Notes"),

        // Reminders
        Tool("tool_rem_create", "CreateReminder", "Create a timed or location-based reminder", listOf(PermissionType.WRITE), RiskLevel.LOW_RISK, Reversibility.REVERSIBLE, "Reminders"),
        Tool("tool_rem_complete", "CompleteReminder", "Mark a reminder as completed", listOf(PermissionType.WRITE), RiskLevel.LOW_RISK, Reversibility.REVERSIBLE, "Reminders"),

        // Photos
        Tool("tool_photo_search", "SearchPhotos", "Semantic search for photos by objects, places, or dates", listOf(PermissionType.READ), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "Photos"),
        Tool("tool_photo_edit", "EditPhoto", "Adjust brightness, crop, or filter photo", listOf(PermissionType.WRITE), RiskLevel.LOW_RISK, Reversibility.REVERSIBLE, "Photos"),
        Tool("tool_photo_share", "SharePhoto", "Share a photo with a contact", listOf(PermissionType.SHARE, PermissionType.COMMUNICATE), RiskLevel.HIGH_RISK, Reversibility.IRREVERSIBLE, "Photos"),

        // Maps
        Tool("tool_maps_route", "GetDirections", "Calculate transit time and navigation route", listOf(PermissionType.LOCATION), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "Maps"),
        Tool("tool_maps_search", "SearchPlaces", "Find nearby places, restaurants, or venues", listOf(PermissionType.LOCATION), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "Maps"),

        // Files
        Tool("tool_files_find", "FindFile", "Search filesystem for documents", listOf(PermissionType.READ), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "Files"),
        Tool("tool_files_delete", "DeleteFile", "Permanently delete a file", listOf(PermissionType.DELETE), RiskLevel.CRITICAL, Reversibility.IRREVERSIBLE, "Files"),

        // Home
        Tool("tool_home_lights", "ControlHomeLights", "Adjust brightness or toggle lights", listOf(PermissionType.HOME_CONTROL), RiskLevel.LOW_RISK, Reversibility.REVERSIBLE, "Home"),
        Tool("tool_home_lock", "ControlDoorLock", "Unlock or lock security doors", listOf(PermissionType.HOME_CONTROL), RiskLevel.CRITICAL, Reversibility.REVERSIBLE, "Home")
    )

    fun getTool(id: String): Tool = allTools.firstOrNull { it.id == id }
        ?: Tool(id, id, "System Tool", listOf(PermissionType.READ), RiskLevel.READ_ONLY, Reversibility.REVERSIBLE, "System")

    fun executeTool(tool: Tool, params: Map<String, String>): ToolResult {
        val invocationId = UUID.randomUUID().toString()
        return when (tool.name) {
            "SendMessage" -> {
                val recipient = params["recipient"] ?: "Recipient"
                val message = params["message"] ?: params["content"] ?: "Hello"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Dispatched iMessage to $recipient: \"$message\"",
                    rawData = mapOf("status" to "DELIVERED", "recipient" to recipient, "content" to message),
                    undoPayload = null // Irreversible
                )
            }
            "FindMessage" -> {
                val query = params["query"] ?: "hotel"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Found recommendation message from James Taylor regarding The Hoxton Shoreditch.",
                    rawData = mapOf("sender" to "James Taylor", "match" to "The Hoxton in Shoreditch")
                )
            }
            "FindEmail" -> {
                val query = params["query"] ?: "hotel"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Retrieved confirmation from reservations@thehoxton.com. Booking Ref: LON-88492. Check-in: 15:00 BST.",
                    rawData = mapOf("booking_ref" to "LON-88492", "check_in" to "15:00 BST", "hotel" to "The Hoxton Shoreditch")
                )
            }
            "CreateCalendarEvent" -> {
                val title = params["title"] ?: "New Event"
                val date = params["date"] ?: "2026-09-24"
                val time = params["time"] ?: "15:00"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Scheduled \"$title\" in iCloud Calendar on $date at $time.",
                    rawData = mapOf("event_id" to "evt_${UUID.randomUUID().toString().take(6)}", "title" to title),
                    undoPayload = mapOf("action" to "delete_event", "title" to title)
                )
            }
            "CreateNote" -> {
                val title = params["title"] ?: "Note"
                val body = params["body"] ?: params["content"] ?: ""
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Saved to Notes: \"$title\"",
                    rawData = mapOf("note_title" to title, "length" to "${body.length} chars"),
                    undoPayload = mapOf("action" to "delete_note", "title" to title)
                )
            }
            "CreateReminder" -> {
                val title = params["title"] ?: "Reminder"
                val whenStr = params["when"] ?: "Tomorrow afternoon"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Created Reminder: \"$title\" for $whenStr.",
                    rawData = mapOf("reminder_id" to "rem_${UUID.randomUUID().toString().take(6)}", "title" to title),
                    undoPayload = mapOf("action" to "delete_reminder", "title" to title)
                )
            }
            "SearchPhotos" -> {
                val query = params["query"] ?: "Peak District"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Found 1 matching 48MP ProRAW photo from Peak District (Stanage Edge sunrise).",
                    rawData = mapOf("photo_id" to "photo_peak_district", "title" to "Peak District Sunrise Vista")
                )
            }
            "GetDirections" -> {
                val dest = params["destination"] ?: "London"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Calculated route to $dest: 42 mins via Central Line & Northern Line.",
                    rawData = mapOf("eta" to "42 mins", "transport" to "Transit")
                )
            }
            "ControlHomeLights" -> {
                val state = params["state"] ?: "OFF"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Set Studio Lights state to $state.",
                    rawData = mapOf("device" to "home_living_lights", "state" to state),
                    undoPayload = mapOf("action" to "toggle_lights", "state" to "ON")
                )
            }
            "ControlDoorLock" -> {
                val state = params["state"] ?: "LOCKED"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Front Door Smart Lock state updated to $state.",
                    rawData = mapOf("device" to "home_door_lock", "state" to state),
                    undoPayload = mapOf("action" to "toggle_lock", "state" to "LOCKED")
                )
            }
            "DeleteFile" -> {
                val file = params["file"] ?: "selected_file"
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Permanently deleted $file from local volume.",
                    rawData = mapOf("deleted_file" to file),
                    undoPayload = null // Irreversible
                )
            }
            else -> {
                ToolResult(
                    invocationId = invocationId,
                    success = true,
                    outputSummary = "Executed ${tool.name} successfully with parameters: $params",
                    rawData = params
                )
            }
        }
    }
}
