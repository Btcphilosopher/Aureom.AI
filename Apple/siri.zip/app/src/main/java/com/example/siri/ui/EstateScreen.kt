package com.example.siri.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siri.data.SyntheticEstateData
import com.example.siri.engine.SiriAssistantViewModel
import com.example.siri.model.DeviceType
import com.example.ui.theme.*

@Composable
fun EstateScreen(
    viewModel: SiriAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val devices = remember { SyntheticEstateData.getDeviceCapabilities() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiriCanvas)
            .padding(16.dp)
    ) {
        Text(
            text = "MULTI-DEVICE ESTATE & PERCEPTION",
            style = MaterialTheme.typography.labelSmall.copy(
                color = SiriElectricBlue,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Active Estate: Alex Mercer",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Device Carousel
        Text(
            text = "CONNECTED DEVICES (${devices.size})",
            style = MaterialTheme.typography.labelSmall.copy(color = SiriTextSecondary)
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(devices) { dev ->
                val isSelected = dev.type == uiState.activeDevice
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) SiriElevatedSurface else SiriCardSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) SiriElectricBlue else SiriCardBorder
                    ),
                    modifier = Modifier
                        .width(160.dp)
                        .clickable { viewModel.switchDevice(dev.type) }
                        .testTag("device_card_${dev.type.name}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = when (dev.type) {
                                    DeviceType.MAC -> Icons.Default.Laptop
                                    DeviceType.IPHONE -> Icons.Default.Smartphone
                                    DeviceType.IPAD -> Icons.Default.Tablet
                                    DeviceType.WATCH -> Icons.Default.Watch
                                    DeviceType.AIRPODS -> Icons.Default.Headphones
                                    DeviceType.CARPLAY -> Icons.Default.DirectionsCar
                                    DeviceType.VISION_PRO -> Icons.Default.Visibility
                                    DeviceType.HOME -> Icons.Default.Home
                                },
                                contentDescription = dev.type.displayName,
                                tint = if (isSelected) SiriElectricBlue else SiriTextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(SiriEmerald)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = dev.type.displayName,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = SiriTextPrimary,
                                fontSize = 12.sp
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "${(dev.batteryLevel * 100).toInt()}% · ${dev.computePowerTops} TOPS NPU",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = SiriTextSecondary,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // On-Screen Active App & Perception Engine Simulator
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ON-SCREEN VIEW PERCEPTION",
                style = MaterialTheme.typography.labelSmall.copy(color = SiriTextSecondary)
            )
            Text(
                text = "Simulate active foreground app",
                style = MaterialTheme.typography.labelSmall.copy(color = SiriElectricBlue)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        // App Selector Pills
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            listOf("Mail", "Camera", "Files", "Photos").forEach { app ->
                val isSelected = uiState.activeOnScreenContent == app
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) SiriPillSurface else SiriCardSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) SiriElectricBlue else SiriCardBorder
                    ),
                    modifier = Modifier
                        .clickable { viewModel.switchOnScreenApp(app) }
                        .testTag("app_filter_$app")
                ) {
                    Text(
                        text = app,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = if (isSelected) SiriElectricBlue else SiriTextSecondary,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            fontSize = 12.sp
                        ),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Simulated Display Screen Card
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = SiriCardSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RemoveRedEye,
                            contentDescription = null,
                            tint = SiriCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Active Foreground: ${uiState.activeSnapshot.screenContext.activeApp}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SiriTextPrimary,
                                fontSize = 13.sp
                            )
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SiriElevatedSurface
                    ) {
                        Text(
                            text = "Optical / DOM Graph",
                            style = MaterialTheme.typography.labelSmall.copy(color = SiriCyan, fontSize = 10.sp),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = uiState.activeSnapshot.screenContext.windowTitle,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = SiriTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "EXTRACTED VIEW ENTITIES (${uiState.activeSnapshot.screenContext.visibleEntities.size})",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = SiriElectricBlue,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(uiState.activeSnapshot.screenContext.visibleEntities) { entity ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SiriElevatedSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SiriCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = entity.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = SiriTextPrimary,
                                            fontSize = 12.sp
                                        )
                                    )
                                    Text(
                                        text = entity.entityType.label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = SiriTextSecondary,
                                            fontSize = 10.sp
                                        )
                                    )
                                }
                                Text(
                                    text = entity.subtitle,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = SiriTextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = entity.rawContent,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = SiriTextPrimary,
                                        fontSize = 11.sp
                                    ),
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
