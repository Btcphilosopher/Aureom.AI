package com.example.siri.model

import java.util.UUID

enum class PermissionType(val label: String) {
    READ("Read Authorized Data"),
    WRITE("Write / Modify Data"),
    COMMUNICATE("Send Messages / Emails"),
    PURCHASE("Financial Transactions"),
    DELETE("Delete Entities / Files"),
    SHARE("Share External Data"),
    LOCATION("Precision Location"),
    HEALTH("Health & Biometrics"),
    HOME_CONTROL("Smart Home & Locks"),
    DEVICE_CONTROL("System Settings & Hardware")
}

enum class RiskLevel(val label: String, val requiresExplicitConfirmation: Boolean) {
    READ_ONLY("Read Only", false),
    LOW_RISK("Low Risk (Local Cache)", false),
    MEDIUM_RISK("Medium Risk (Drafting/Modifying)", false),
    HIGH_RISK("High Risk (External Communication/Transactions)", true),
    CRITICAL("Critical (Destructive Deletion/Security Locks)", true)
}

enum class Reversibility(val label: String) {
    REVERSIBLE("Fully Reversible"),
    PARTIALLY_REVERSIBLE("Partially Reversible"),
    IRREVERSIBLE("Irreversible")
}

data class Tool(
    val id: String,
    val name: String,
    val description: String,
    val requiredPermissions: List<PermissionType>,
    val riskLevel: RiskLevel,
    val reversibility: Reversibility,
    val targetApp: String
)

data class ToolInvocation(
    val invocationId: String = UUID.randomUUID().toString(),
    val tool: Tool,
    val inputParameters: Map<String, String>,
    val callerTrustDomain: TrustDomain = TrustDomain.USER_INSTRUCTION
)

data class ToolResult(
    val invocationId: String,
    val success: Boolean,
    val outputSummary: String,
    val rawData: Map<String, String> = emptyMap(),
    val undoPayload: Map<String, String>? = null,
    val errorMessage: String? = null
)

data class PlanStep(
    val stepIndex: Int,
    val description: String,
    val targetApp: String,
    val tool: Tool,
    val arguments: Map<String, String>,
    val riskLevel: RiskLevel,
    val isCompleted: Boolean = false,
    val executionResult: String? = null
)

data class Plan(
    val planId: String = UUID.randomUUID().toString(),
    val goal: String,
    val steps: List<PlanStep>,
    val requiresUserConfirmation: Boolean,
    val confirmationPrompt: String? = null,
    val reversibility: Reversibility = Reversibility.REVERSIBLE,
    val executionDomain: InferenceLocation = InferenceLocation.ON_DEVICE_NPU
)

data class ActionJournalItem(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val intentDescription: String,
    val appTarget: String,
    val toolName: String,
    val argumentsSummary: String,
    val resultSummary: String,
    val reversibility: Reversibility,
    val undoAvailable: Boolean = true,
    val isUndone: Boolean = false
)
