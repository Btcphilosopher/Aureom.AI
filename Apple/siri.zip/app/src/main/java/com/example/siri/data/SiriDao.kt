package com.example.siri.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SiriDao {
    @Query("SELECT * FROM conversation_turns ORDER BY timestamp ASC")
    fun getAllConversationTurns(): Flow<List<ConversationRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversationTurn(turn: ConversationRecord): Long

    @Query("DELETE FROM conversation_turns")
    suspend fun clearConversation()

    @Query("SELECT * FROM action_journal ORDER BY timestamp DESC")
    fun getAllJournalRecords(): Flow<List<JournalRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJournalRecord(record: JournalRecord): Long

    @Update
    suspend fun updateJournalRecord(record: JournalRecord)

    @Query("SELECT * FROM personal_memories ORDER BY timestamp DESC")
    fun getAllMemories(): Flow<List<MemoryRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryRecord): Long

    @Update
    suspend fun updateMemory(memory: MemoryRecord)

    @Query("DELETE FROM personal_memories WHERE id = :id")
    suspend fun deleteMemoryById(id: Long)

    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC")
    fun getAllAuditEvents(): Flow<List<AuditEventRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEvent(event: AuditEventRecord): Long
}
