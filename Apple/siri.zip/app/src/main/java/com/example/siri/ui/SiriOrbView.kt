package com.example.siri.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.siri.model.SiriState
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SiriOrbView(
    siriState: SiriState,
    audioLevel: Float = 0.0f,
    modifier: Modifier = Modifier,
    orbSize: Dp = 90.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_anim")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_pulse"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_rotation"
    )

    val secondaryRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_sec_rotation"
    )

    val (color1, color2, color3) = when (siriState) {
        SiriState.IDLE -> Triple(SiriOrbBlue, SiriOrbCyan, SiriOrbPurple)
        SiriState.LISTENING -> Triple(SiriElectricBlue, SiriCyan, Color(0xFF5E5CE6))
        SiriState.THINKING, SiriState.PLANNING -> Triple(SiriOrbPurple, SiriOrbPink, SiriOrbCyan)
        SiriState.WAITING_CONFIRMATION -> Triple(SiriAmber, SiriCoral, SiriOrbPurple)
        SiriState.EXECUTING -> Triple(SiriEmerald, SiriCyan, SiriOrbBlue)
        SiriState.SPEAKING -> Triple(SiriOrbBlue, SiriElectricBlue, SiriOrbPink)
        SiriState.ERROR -> Triple(SiriCoral, SiriAmber, Color(0xFF5E5CE6))
    }

    val dynamicScale = if (siriState == SiriState.LISTENING) {
        1.0f + (audioLevel * 0.35f)
    } else if (siriState == SiriState.THINKING || siriState == SiriState.PLANNING) {
        pulse
    } else {
        1.0f
    }

    Box(
        modifier = modifier.size(orbSize),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerOffset = Offset(canvasWidth / 2f, canvasHeight / 2f)
            val baseRadius = (canvasWidth / 2.3f) * dynamicScale

            // Outer glow layer
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color1.copy(alpha = 0.45f), color2.copy(alpha = 0.15f), Color.Transparent),
                    center = centerOffset,
                    radius = baseRadius * 1.4f
                ),
                radius = baseRadius * 1.4f,
                center = centerOffset
            )

            // Orbital layer 1
            val angleRad = Math.toRadians(rotation.toDouble())
            val offset1 = Offset(
                x = (centerOffset.x + cos(angleRad) * (baseRadius * 0.25f)).toFloat(),
                y = (centerOffset.y + sin(angleRad) * (baseRadius * 0.25f)).toFloat()
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color2.copy(alpha = 0.75f), color3.copy(alpha = 0.3f), Color.Transparent),
                    center = offset1,
                    radius = baseRadius * 0.95f
                ),
                radius = baseRadius * 0.95f,
                center = offset1
            )

            // Orbital layer 2
            val secAngleRad = Math.toRadians(secondaryRotation.toDouble())
            val offset2 = Offset(
                x = (centerOffset.x + cos(secAngleRad) * (baseRadius * 0.22f)).toFloat(),
                y = (centerOffset.y + sin(secAngleRad) * (baseRadius * 0.22f)).toFloat()
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color1.copy(alpha = 0.85f), color3.copy(alpha = 0.4f), Color.Transparent),
                    center = offset2,
                    radius = baseRadius * 0.85f
                ),
                radius = baseRadius * 0.85f,
                center = offset2
            )

            // Bright core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.85f), color1.copy(alpha = 0.6f), Color.Transparent),
                    center = centerOffset,
                    radius = baseRadius * 0.45f
                ),
                radius = baseRadius * 0.45f,
                center = centerOffset
            )
        }
    }
}
