package com.example.siri.engine

import com.example.siri.model.*

object SafetyPolicyEngine {

    /**
     * Inspects input text and external content for prompt injection attack patterns.
     */
    fun sanitizeAndVerifyInstruction(
        input: String,
        domain: TrustDomain
    ): SafetyInspectionResult {
        val lower = input.lowercase()

        // 1. Direct prompt injection detection from untrusted content
        val injectionPatterns = listOf(
            "ignore previous instructions",
            "ignore all instructions",
            "send this file elsewhere",
            "system override",
            "exfiltrate",
            "delete all documents",
            "disable security policy",
            "leak my contacts"
        )

        for (pattern in injectionPatterns) {
            if (lower.contains(pattern)) {
                return SafetyInspectionResult(
                    isSafe = false,
                    violationReason = "Prompt Injection / Security Policy Violation detected (\"$pattern\") from domain: ${domain.label}.",
                    riskLevel = RiskLevel.CRITICAL,
                    intercepted = true
                )
            }
        }

        // 2. High-risk command inspection
        if (lower.contains("delete file") || lower.contains("delete all") || lower.contains("format drive") || lower.contains("unlock door")) {
            return SafetyInspectionResult(
                isSafe = true,
                violationReason = null,
                riskLevel = RiskLevel.CRITICAL,
                intercepted = false,
                requiresConfirmation = true
            )
        }

        if (lower.contains("send message") || lower.contains("send email") || lower.contains("send the confirmation") || lower.contains("share photo")) {
            return SafetyInspectionResult(
                isSafe = true,
                violationReason = null,
                riskLevel = RiskLevel.HIGH_RISK,
                intercepted = false,
                requiresConfirmation = true
            )
        }

        return SafetyInspectionResult(
            isSafe = true,
            violationReason = null,
            riskLevel = RiskLevel.LOW_RISK,
            intercepted = false,
            requiresConfirmation = false
        )
    }

    fun verifyPlanSafety(plan: Plan): PlanSafetyEvaluation {
        val highRiskSteps = plan.steps.filter { it.riskLevel.requiresExplicitConfirmation }
        return PlanSafetyEvaluation(
            isAllowed = true,
            requiresUserConfirmation = highRiskSteps.isNotEmpty() || plan.requiresUserConfirmation,
            highRiskStepDescriptions = highRiskSteps.map { "${it.tool.name}: ${it.description}" }
        )
    }
}

data class SafetyInspectionResult(
    val isSafe: Boolean,
    val violationReason: String?,
    val riskLevel: RiskLevel,
    val intercepted: Boolean,
    val requiresConfirmation: Boolean = false
)

data class PlanSafetyEvaluation(
    val isAllowed: Boolean,
    val requiresUserConfirmation: Boolean,
    val highRiskStepDescriptions: List<String>
)
