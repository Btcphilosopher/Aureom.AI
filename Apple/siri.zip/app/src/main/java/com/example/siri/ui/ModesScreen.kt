package com.example.siri.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.siri.engine.SiriAssistantViewModel
import com.example.siri.model.OperatingMode
import com.example.ui.theme.*

@Composable
fun ModesScreen(
    viewModel: SiriAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SiriCanvas)
            .padding(16.dp)
    ) {
        Text(
            text = "OPERATING MODES & SPECIALIZED AGENTS",
            style = MaterialTheme.typography.labelSmall.copy(
                color = SiriElectricBlue,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Adaptive Modalities",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(OperatingMode.values()) { mode ->
                val isActive = uiState.activeMode == mode
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isActive) SiriElevatedSurface else SiriCardSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isActive) SiriElectricBlue else SiriCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.setOperatingMode(mode)
                            viewModel.selectTab(0) // Switch to Assistant feed to see action
                        }
                        .testTag("mode_card_${mode.name}")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isActive) SiriElectricBlue else SiriPillSurface,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = when (mode) {
                                            OperatingMode.STANDARD -> Icons.Default.AutoAwesome
                                            OperatingMode.MORNING_BRIEF -> Icons.Default.WbSunny
                                            OperatingMode.EVENING_REVIEW -> Icons.Default.Bedtime
                                            OperatingMode.TRAVEL -> Icons.Default.Flight
                                            OperatingMode.PROJECT -> Icons.Default.Folder
                                            OperatingMode.WORK -> Icons.Default.Work
                                            OperatingMode.CREATIVE -> Icons.Default.Palette
                                            OperatingMode.DEVELOPER -> Icons.Default.Code
                                            OperatingMode.CARPLAY -> Icons.Default.DirectionsCar
                                            OperatingMode.APPLE_WATCH -> Icons.Default.Watch
                                            OperatingMode.VISION_PRO -> Icons.Default.Visibility
                                        },
                                        contentDescription = null,
                                        tint = if (isActive) Color.White else SiriElectricBlue,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = mode.title,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = SiriTextPrimary,
                                        fontSize = 14.sp
                                    )
                                )
                                Text(
                                    text = mode.subtitle,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = SiriTextSecondary,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.setOperatingMode(mode)
                                viewModel.selectTab(0)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isActive) SiriEmerald else SiriPillSurface
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (isActive) "Active" else "Engage",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isActive) Color.White else SiriTextPrimary
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
