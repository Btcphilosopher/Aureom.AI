package com.example.siri.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversation_turns")
data class ConversationRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val sourceName: String? = null,
    val sourceExplanation: String? = null,
    val confidence: Float = 1.0f,
    val targetApp: String? = null
)

@Entity(tableName = "action_journal")
data class JournalRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val intentDescription: String,
    val appTarget: String,
    val toolName: String,
    val argumentsSummary: String,
    val resultSummary: String,
    val reversibility: String,
    val isUndone: Boolean = false
)

@Entity(tableName = "personal_memories")
data class MemoryRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val value: String,
    val sourceApp: String,
    val provenance: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isUserControlled: Boolean = true,
    val isEnabled: Boolean = true
)

@Entity(tableName = "audit_events")
data class AuditEventRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val callerDomain: String,
    val actionName: String,
    val securityVerification: String,
    val outcome: String
)
