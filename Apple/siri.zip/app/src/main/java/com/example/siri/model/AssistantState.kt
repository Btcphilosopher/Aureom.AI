package com.example.siri.model

import java.util.UUID

enum class SiriState(val label: String) {
    IDLE("Ready"),
    LISTENING("Listening..."),
    THINKING("Perceiving Context..."),
    PLANNING("Synthesizing Plan..."),
    WAITING_CONFIRMATION("Awaiting User Confirmation"),
    EXECUTING("Executing Structured Intent..."),
    SPEAKING("Responding"),
    ERROR("Policy / Execution Notice")
}

enum class MessageRole {
    USER, SIRI, SYSTEM
}

data class ConversationTurn(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val provenance: Provenance? = null,
    val activePlan: Plan? = null,
    val toolResult: ToolResult? = null,
    val detectedEntities: List<String> = emptyList(),
    val confidence: Float = 0.98f,
    val requiresConfirmation: Boolean = false,
    val isConfirmed: Boolean = false,
    val clarificationOptions: List<String> = emptyList()
)

data class ProactiveSuggestion(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val subtitle: String,
    val category: String,
    val promptAction: String,
    val relevanceScore: Float,
    val intrusionCost: Float, // only surface when relevance > intrusionCost
    val iconName: String
)

enum class OperatingMode(val title: String, val subtitle: String, val icon: String) {
    STANDARD("Universal Siri", "Context-aware computational agent", "auto_awesome"),
    MORNING_BRIEF("Morning Brief", "Actionable synthesis of calendar, traffic, tasks", "wb_sunny"),
    EVENING_REVIEW("Evening Review", "Unfinished tasks, tomorrow prep, unwind", "bedtime"),
    TRAVEL("Travel Companion", "Itinerary, boarding passes, localized context", "flight"),
    PROJECT("Project Atlas", "Cross-app workspace, files, notes, colleagues", "folder"),
    WORK("Executive Work", "Documents, calendar conflicts, meeting prep", "work"),
    CREATIVE("Creative Studio", "Media curation, smart photo grouping, playlists", "palette"),
    DEVELOPER("Developer Console", "Repo tracking, sandboxed builds, audit inspection", "code"),
    CARPLAY("CarPlay Automotive", "Distraction-free glanceable voice HUD", "directions_car"),
    APPLE_WATCH("Apple Watch HUD", "Haptic glanceable micro-actions", "watch"),
    VISION_PRO("Spatial Reality", "3D pinned spatial windows & eye-gaze anchor", "visibility")
}
