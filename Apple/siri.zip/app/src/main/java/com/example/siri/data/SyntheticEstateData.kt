package com.example.siri.data

import com.example.siri.model.*

object SyntheticEstateData {

    fun createInitialGraph(): PersonalKnowledgeGraph {
        val nodes = mutableMapOf<String, EntityNode>()
        val edges = mutableListOf<GraphEdge>()

        // 1. People
        val userNode = EntityNode(
            id = "person_user",
            type = EntityType.PERSON,
            title = "Alex Mercer",
            subtitle = "Principal Engineer & Systems Architect",
            properties = mapOf("email" to "alex.mercer@apple-ecosystem.local", "role" to "Primary User"),
            sourceApp = "Contacts",
            tags = listOf("me", "owner")
        )
        val jamesNode = EntityNode(
            id = "person_james",
            type = EntityType.PERSON,
            title = "James Taylor",
            subtitle = "Lead Product Architect",
            properties = mapOf(
                "email" to "james.taylor@hyve-systems.io",
                "phone" to "+44 20 7946 0912",
                "relationship" to "Close Colleague & Project Lead"
            ),
            sourceApp = "Contacts",
            tags = listOf("colleague", "london_team", "project_lead")
        )
        val sarahNode = EntityNode(
            id = "person_sarah",
            type = EntityType.PERSON,
            title = "Sarah Chen",
            subtitle = "Staff Security Engineer",
            properties = mapOf("email" to "sarah.chen@hyve-systems.io", "team" to "Security Kernel"),
            sourceApp = "Contacts",
            tags = listOf("colleague", "reviewer")
        )
        val tomNode = EntityNode(
            id = "person_tom",
            type = EntityType.PERSON,
            title = "Tom Watson",
            subtitle = "Design Director",
            properties = mapOf("email" to "tom.w@designworks.co.uk"),
            sourceApp = "Contacts",
            tags = listOf("creative", "photographer")
        )

        listOf(userNode, jamesNode, sarahNode, tomNode).forEach { nodes[it.id] = it }

        // 2. Places & Bookings
        val hoxtonHotelNode = EntityNode(
            id = "booking_hoxton",
            type = EntityType.BOOKING,
            title = "The Hoxton, Shoreditch",
            subtitle = "Booking #LON-88492 · Check-in: 15:00 BST",
            properties = mapOf(
                "hotel_name" to "The Hoxton Shoreditch",
                "booking_reference" to "LON-88492",
                "check_in_time" to "15:00 BST",
                "check_out_time" to "11:00 BST",
                "address" to "81 Great Eastern St, London EC2A 3HX, UK",
                "recommended_by" to "James Taylor",
                "room_type" to "Cosy Double · Breakfast Included",
                "dates" to "Thursday Sep 24 – Saturday Sep 26, 2026"
            ),
            sourceApp = "Mail",
            tags = listOf("hotel", "london", "trip", "accommodation")
        )

        val edinburghHotelNode = EntityNode(
            id = "booking_edinburgh",
            type = EntityType.BOOKING,
            title = "The Balmoral Hotel, Edinburgh",
            subtitle = "Booking #EDI-40291 · 1 Princes St",
            properties = mapOf(
                "hotel_name" to "The Balmoral Hotel",
                "booking_reference" to "EDI-40291",
                "check_in_time" to "14:00 BST",
                "address" to "1 Princes St, Edinburgh EH2 2EQ",
                "city" to "Edinburgh"
            ),
            sourceApp = "Mail",
            tags = listOf("hotel", "edinburgh", "trip")
        )

        listOf(hoxtonHotelNode, edinburghHotelNode).forEach { nodes[it.id] = it }

        // 3. Emails
        val emailHotelConf = EntityNode(
            id = "email_hotel_conf",
            type = EntityType.EMAIL,
            title = "Booking Confirmation: The Hoxton Shoreditch (LON-88492)",
            subtitle = "From: reservations@thehoxton.com · Received Tuesday",
            properties = mapOf(
                "sender" to "reservations@thehoxton.com",
                "subject" to "Your Hoxton Shoreditch Reservation LON-88492",
                "body" to "Dear Alex, we look forward to welcoming you to Shoreditch. Check-in starts at 15:00 BST on Thursday Sep 24. Address: 81 Great Eastern St, London EC2A 3HX.",
                "booking_number" to "LON-88492",
                "date" to "Tuesday 10:14"
            ),
            sourceApp = "Mail",
            tags = listOf("confirmation", "hotel", "travel")
        )

        val emailProposalDeadline = EntityNode(
            id = "email_proposal",
            type = EntityType.EMAIL,
            title = "Project Atlas Architecture Proposal - Final Review",
            subtitle = "From: James Taylor · Sent yesterday",
            properties = mapOf(
                "sender" to "james.taylor@hyve-systems.io",
                "subject" to "Project Atlas Architecture Proposal",
                "body" to "Alex, could you prepare the latest version of the proposal before the Thursday summit? Let me know once updated.",
                "attachment" to "Atlas_Architecture_v3.2_Draft.pdf"
            ),
            sourceApp = "Mail",
            tags = listOf("work", "proposal", "urgent")
        )

        listOf(emailHotelConf, emailProposalDeadline).forEach { nodes[it.id] = it }

        // 4. Messages
        val msgJamesRec = EntityNode(
            id = "msg_james_hotel",
            type = EntityType.MESSAGE,
            title = "Message from James Taylor",
            subtitle = "\"Stay at The Hoxton in Shoreditch, it's 5 mins from our meeting venue!\"",
            properties = mapOf(
                "sender" to "James Taylor",
                "timestamp_str" to "Last Monday, 16:42",
                "content" to "Hey Alex! For next week's London summit, definitely book The Hoxton in Shoreditch. Super close to the studio and great workspace."
            ),
            sourceApp = "Messages",
            tags = listOf("recommendation", "hotel", "london")
        )

        listOf(msgJamesRec).forEach { nodes[it.id] = it }

        // 5. Calendar Events
        val summitEvent = EntityNode(
            id = "event_london_summit",
            type = EntityType.EVENT,
            title = "Next-Gen Personal Computing Summit 2026",
            subtitle = "Thu, Sep 24, 10:00 - 16:30 BST · London HQ",
            properties = mapOf(
                "start_time" to "2026-09-24T10:00:00",
                "end_time" to "2026-09-24T16:30:00",
                "location" to "Whitechapel Studio, London E1 6PX",
                "attendees" to "James Taylor, Sarah Chen, Alex Mercer"
            ),
            sourceApp = "Calendar",
            tags = listOf("meeting", "work", "london", "summit")
        )

        val edinburghTripEvent = EntityNode(
            id = "event_edinburgh",
            type = EntityType.EVENT,
            title = "Travel to Edinburgh: LNER Express 11:00",
            subtitle = "Kings Cross -> Waverley Station",
            properties = mapOf(
                "start_time" to "2026-10-02T11:00:00",
                "transport" to "LNER Train Coach B Seat 42"
            ),
            sourceApp = "Calendar",
            tags = listOf("travel", "train", "edinburgh")
        )

        listOf(summitEvent, edinburghTripEvent).forEach { nodes[it.id] = it }

        // 6. Documents & Files
        val proposalDoc = EntityNode(
            id = "doc_proposal_v3",
            type = EntityType.DOCUMENT,
            title = "Atlas_Architecture_v3.2_Draft.pdf",
            subtitle = "Modified yesterday by Alex Mercer · 4.8 MB",
            properties = mapOf(
                "file_path" to "/Documents/Projects/Atlas/Atlas_Architecture_v3.2_Draft.pdf",
                "version" to "v3.2 Final Release",
                "status" to "Ready for dispatch",
                "summary" to "System architecture detailing Context Engine, Privacy Sandboxing, and Multi-Device Distributed Orchestrator."
            ),
            sourceApp = "Files",
            tags = listOf("proposal", "document", "work", "atlas")
        )

        val invoiceDoc = EntityNode(
            id = "doc_invoice_last_month",
            type = EntityType.DOCUMENT,
            title = "Invoice_August_2026_Hyve.pdf",
            subtitle = "Hyve Cloud Infrastructure · $1,240.00",
            properties = mapOf(
                "invoice_number" to "INV-2026-08-991",
                "amount" to "$1,240.00",
                "date" to "2026-08-31"
            ),
            sourceApp = "Files",
            tags = listOf("invoice", "finance", "receipt")
        )

        listOf(proposalDoc, invoiceDoc).forEach { nodes[it.id] = it }

        // 7. Photos
        val photoPeakDistrict = EntityNode(
            id = "photo_peak_district",
            type = EntityType.PHOTO,
            title = "Peak District Sunrise Vista",
            subtitle = "Taken at Stanage Edge · Peak District National Park",
            properties = mapOf(
                "location" to "Peak District, Derbyshire",
                "date_taken" to "August 12, 2026",
                "camera" to "iPhone 16 Pro 48MP Quad-Pixel",
                "resolution" to "8064x6048",
                "objects_detected" to "mountain, sunrise, rocky ledge, landscape"
            ),
            sourceApp = "Photos",
            tags = listOf("photo", "peak_district", "nature", "summer")
        )

        val photoTechPoster = EntityNode(
            id = "photo_poster",
            type = EntityType.PHOTO,
            title = "AI Systems Keynote 2026 Poster",
            subtitle = "Captured via Camera · OCR extracted event details",
            properties = mapOf(
                "event_name" to "AI Systems Keynote 2026",
                "extracted_date" to "Friday Oct 16, 2026 at 18:00 BST",
                "extracted_location" to "Barbican Centre, Silk St, London",
                "extracted_url" to "https://aisystems.tech/register"
            ),
            sourceApp = "Photos",
            tags = listOf("poster", "camera", "ocr", "event")
        )

        val photoRestaurantMenu = EntityNode(
            id = "photo_menu",
            type = EntityType.PHOTO,
            title = "Osteria Botanica - Evening Menu",
            subtitle = "Captured in Camera · Visual Intelligence analyzed dishes",
            properties = mapOf(
                "restaurant" to "Osteria Botanica",
                "vegetarian_items" to "1. Wild Mushroom & Truffle Agnolotti (GF available), 2. Wood-fired Roman Artichokes with Lemon Ricotta, 3. Charred Broccolini Risotto",
                "signature_dish" to "Wild Mushroom & Truffle Agnolotti"
            ),
            sourceApp = "Photos",
            tags = listOf("menu", "food", "vegetarian", "camera")
        )

        listOf(photoPeakDistrict, photoTechPoster, photoRestaurantMenu).forEach { nodes[it.id] = it }

        // 8. Notes & Reminders
        val noteLondonItinerary = EntityNode(
            id = "note_london",
            type = EntityType.NOTE,
            title = "London Summit Itinerary & Contacts",
            subtitle = "Notes App · Contains venue addresses and James' contact",
            properties = mapOf(
                "content" to "Meeting Thursday 10am @ Whitechapel Studio. Hotel: The Hoxton Shoreditch (LON-88492). James phone: +44 20 7946 0912."
            ),
            sourceApp = "Notes",
            tags = listOf("note", "london", "travel")
        )

        val reminderProposal = EntityNode(
            id = "reminder_proposal",
            type = EntityType.TASK,
            title = "Send the proposal to James Taylor",
            subtitle = "Due: Tomorrow afternoon (Unfinished)",
            properties = mapOf(
                "due_date" to "2026-09-16T14:00:00",
                "status" to "Incomplete",
                "target_person" to "James Taylor",
                "referenced_file" to "Atlas_Architecture_v3.2_Draft.pdf"
            ),
            sourceApp = "Reminders",
            tags = listOf("task", "unfinished", "proposal")
        )

        listOf(noteLondonItinerary, reminderProposal).forEach { nodes[it.id] = it }

        // 9. Home Devices
        val livingRoomLights = EntityNode(
            id = "home_living_lights",
            type = EntityType.HOME_DEVICE,
            title = "Studio Warm Ambient Lights",
            subtitle = "Living Area · Currently On (70% Brightness)",
            properties = mapOf("state" to "ON", "brightness" to "70%", "color_temp" to "2700K Warm"),
            sourceApp = "Home",
            tags = listOf("lights", "home", "studio")
        )

        val studioLock = EntityNode(
            id = "home_door_lock",
            type = EntityType.HOME_DEVICE,
            title = "Studio Front Door Smart Lock",
            subtitle = "Secure Enclave · Locked",
            properties = mapOf("state" to "LOCKED", "security_level" to "CRITICAL"),
            sourceApp = "Home",
            tags = listOf("lock", "security", "home")
        )

        listOf(livingRoomLights, studioLock).forEach { nodes[it.id] = it }

        // Construct Edges & Relationships
        edges.add(GraphEdge(fromEntityId = "person_james", toEntityId = "booking_hoxton", relationship = RelationshipType.RECOMMENDED, contextNote = "Recommended in Messages"))
        edges.add(GraphEdge(fromEntityId = "person_james", toEntityId = "msg_james_hotel", relationship = RelationshipType.SENT))
        edges.add(GraphEdge(fromEntityId = "email_hotel_conf", toEntityId = "booking_hoxton", relationship = RelationshipType.CONTAINS, contextNote = "Booking ref LON-88492"))
        edges.add(GraphEdge(fromEntityId = "person_user", toEntityId = "booking_hoxton", relationship = RelationshipType.CREATED))
        edges.add(GraphEdge(fromEntityId = "person_james", toEntityId = "doc_proposal_v3", relationship = RelationshipType.WORKS_ON))
        edges.add(GraphEdge(fromEntityId = "reminder_proposal", toEntityId = "doc_proposal_v3", relationship = RelationshipType.DEPENDS_ON))
        edges.add(GraphEdge(fromEntityId = "reminder_proposal", toEntityId = "person_james", relationship = RelationshipType.DEPENDS_ON))
        edges.add(GraphEdge(fromEntityId = "person_user", toEntityId = "event_london_summit", relationship = RelationshipType.ATTENDED))
        edges.add(GraphEdge(fromEntityId = "event_london_summit", toEntityId = "booking_hoxton", relationship = RelationshipType.LOCATED_AT, contextNote = "5 mins walk"))

        return PersonalKnowledgeGraph(nodes, edges)
    }

    fun getDeviceCapabilities(): List<DeviceCapability> = listOf(
        DeviceCapability(DeviceType.IPHONE, listOf(SensorType.MICROPHONE, SensorType.CAMERA, SensorType.GPS, SensorType.NEURAL_ENGINE, SensorType.SCREEN), 38, true, 0.88f, true),
        DeviceCapability(DeviceType.MAC, listOf(SensorType.MICROPHONE, SensorType.CAMERA, SensorType.NEURAL_ENGINE, SensorType.SCREEN), 120, true, 0.95f),
        DeviceCapability(DeviceType.IPAD, listOf(SensorType.MICROPHONE, SensorType.CAMERA, SensorType.SCREEN), 45, true, 0.76f),
        DeviceCapability(DeviceType.WATCH, listOf(SensorType.MICROPHONE, SensorType.MOTION, SensorType.HEART_RATE, SensorType.GPS, SensorType.SCREEN), 12, true, 0.65f),
        DeviceCapability(DeviceType.AIRPODS, listOf(SensorType.MICROPHONE, SensorType.MOTION), 4, false, 0.90f),
        DeviceCapability(DeviceType.CARPLAY, listOf(SensorType.MICROPHONE, SensorType.GPS, SensorType.SCREEN), 25, true, 1.0f),
        DeviceCapability(DeviceType.VISION_PRO, listOf(SensorType.MICROPHONE, SensorType.CAMERA, SensorType.SCREEN, SensorType.NEURAL_ENGINE), 80, true, 0.82f),
        DeviceCapability(DeviceType.HOME, listOf(SensorType.MICROPHONE, SensorType.AMBIENT_LIGHT), 18, false, 1.0f)
    )
}
