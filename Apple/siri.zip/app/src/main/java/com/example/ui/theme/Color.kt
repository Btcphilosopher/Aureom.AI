package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Super-modernist Apple Intelligence Palette (Graphite, Titanium, Silver, Deep Azure, Ambient Violet)
val SiriCanvas = Color(0xFF080B10)
val SiriCardSurface = Color(0xFF111622)
val SiriCardBorder = Color(0xFF1F293D)
val SiriElevatedSurface = Color(0xFF182030)
val SiriPillSurface = Color(0xFF222C40)

// System Accents
val SiriElectricBlue = Color(0xFF2997FF)
val SiriCyan = Color(0xFF64D2FF)
val SiriViolet = Color(0xFFAF52DE)
val SiriMagenta = Color(0xFFFF375F)
val SiriEmerald = Color(0xFF30D158)
val SiriAmber = Color(0xFFFF9F0A)
val SiriCoral = Color(0xFFFF453A)

// Typography & Neutrals
val SiriTextPrimary = Color(0xFFF5F5F7)
val SiriTextSecondary = Color(0xFF98989D)
val SiriTextTertiary = Color(0xFF636366)
val SiriDivider = Color(0x26FFFFFF)

// Siri Orb Core & Wave Gradients
val SiriOrbBlue = Color(0xFF0071E3)
val SiriOrbPurple = Color(0xFF7000FF)
val SiriOrbPink = Color(0xFFFF2D55)
val SiriOrbCyan = Color(0xFF00C7BE)
val SiriOrbGold = Color(0xFFFFD60A)
