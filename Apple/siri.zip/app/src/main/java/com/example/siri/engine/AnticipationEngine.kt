package com.example.siri.engine

import com.example.siri.model.ProactiveSuggestion

object AnticipationEngine {

    fun generateProactiveSuggestions(): List<ProactiveSuggestion> = listOf(
        ProactiveSuggestion(
            title = "Unfinished Proposal for James",
            subtitle = "Atlas_Architecture_v3.2_Draft.pdf modified yesterday. James requested update before Thursday.",
            category = "Task Continuity",
            promptAction = "Send the latest version of the proposal to James",
            relevanceScore = 0.94f,
            intrusionCost = 0.20f,
            iconName = "description"
        ),
        ProactiveSuggestion(
            title = "London Hotel Check-in Ready",
            subtitle = "The Hoxton Shoreditch (LON-88492) · Check-in 15:00 BST Sep 24",
            category = "Upcoming Travel",
            promptAction = "Put my London hotel booking in my calendar",
            relevanceScore = 0.88f,
            intrusionCost = 0.15f,
            iconName = "hotel"
        ),
        ProactiveSuggestion(
            title = "AI Systems Keynote Registration",
            subtitle = "Poster captured in Camera · Barbican Centre Oct 16",
            category = "Visual Intelligence",
            promptAction = "Turn this poster into a calendar event",
            relevanceScore = 0.82f,
            intrusionCost = 0.25f,
            iconName = "event"
        ),
        ProactiveSuggestion(
            title = "Trip to Edinburgh Transit Options",
            subtitle = "LNER Train departure in 17 days · Review schedule",
            category = "Travel Planner",
            promptAction = "I'm going to London next Thursday. Find the meeting in my calendar, check the train options, tell me what time I should leave, and put the itinerary in a note.",
            relevanceScore = 0.79f,
            intrusionCost = 0.30f,
            iconName = "flight"
        )
    )

    fun generateMorningBrief(): String {
        return """
            ☀️ **Morning Brief · Tuesday, Sep 15, 2026**
            
            • **Today's Focus**: Silicon Roundabout Studio (Office). 1 conflict-free meeting scheduled.
            • **Unfinished Task**: Proposal review with James Taylor due for summit prep.
            • **Upcoming Trip**: Next-Gen Personal Computing Summit in London on Thursday, Sep 24 (Hotel: The Hoxton Shoreditch).
            • **Smart Home**: Studio ambient temperature 21°C, all security perimeters locked.
            • **Commute**: Central line running with normal 3-minute headway.
        """.trimIndent()
    }

    fun generateEveningReview(): String {
        return """
            🌙 **Evening Review · Tuesday, Sep 15, 2026**
            
            • **Completed Today**: Synchronized 3 document changes, inspected London itinerary, verified reservation LON-88492.
            • **Pending for Tomorrow**: Finalize Atlas proposal with James Taylor at 14:00 BST.
            • **Schedule Tomorrow**: 2 meetings, first at 10:30 BST (Security Review with Sarah Chen).
        """.trimIndent()
    }
}
