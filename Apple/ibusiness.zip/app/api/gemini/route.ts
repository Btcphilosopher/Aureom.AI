import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

// Initialize Gemini API client on the server side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || process.env.NEXT_PUBLIC_GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { prompt, stateSummary } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required." }, { status: 400 });
    }

    const systemInstruction = `You are iBUSINESS Intelligence, the AI Chief Financial Officer and enterprise business analyst built into the iBUSINESS macOS Operating System.
Your job is to provide highly precise, evidence-backed financial analysis and answers.

You must ALWAYS respect the following safety and accuracy guidelines:
1. NEVER fabricate transactions, payments, or tax rules.
2. Never invent figures. Every single number you mention must correspond strictly to the provided data context.
3. Every financial answer must cite: Data sources, reporting Period, precise calculations, and any forecast assumptions.
4. If asked about future projections (like a 90-day cash forecast), state your model (e.g. Simple regression, historical averages, or current runway calculation) and label it clearly as an estimate, not a certainty.
5. High-impact financial actions require human confirmation. Never pretend you can send money or post entries autonomously.
6. Present your answers in structured, elegant, professional, clear macOS system text style. Use Markdown tables, bullet points, and highlight key indicators (e.g. Gross Margin %, Runway days).

Here is the current real-time state of the company (Northstar Digital Ltd):
${JSON.stringify(stateSummary, null, 2)}
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.2, // Low temperature for high precision and math accuracy
      }
    });

    const resultText = response.text || "No insights could be generated at this time.";

    return NextResponse.json({ text: resultText });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return NextResponse.json({ 
      error: "Unable to process AI analysis.", 
      details: error?.message || "Internal server error" 
    }, { status: 500 });
  }
}
