'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Building, 
  Users, 
  FileText, 
  Settings, 
  Search, 
  TrendingUp, 
  DollarSign, 
  Briefcase, 
  CheckSquare, 
  Calendar, 
  Layers, 
  Package, 
  ShoppingCart, 
  Scale, 
  HelpCircle, 
  Sparkles, 
  CheckCircle, 
  AlertCircle, 
  Clock, 
  Plus, 
  Trash2, 
  ChevronRight, 
  Filter, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Download, 
  RefreshCw, 
  Eye, 
  Inbox, 
  X, 
  Check, 
  File, 
  Folder, 
  Bookmark, 
  ShieldAlert, 
  Zap, 
  Play, 
  SkipForward, 
  Gauge, 
  Activity, 
  Globe 
} from 'lucide-react';
import { generateSyntheticSMEData } from '@/lib/businessSeed';
import { 
  iBusinessState, 
  Customer, 
  Invoice, 
  Quote, 
  Project, 
  ProjectTask, 
  Employee, 
  JournalEntry, 
  BankTransaction, 
  AuditEvent, 
  TimeEntry, 
  Expense, 
  InvoiceStatus, 
  QuoteStatus 
} from '@/lib/businessTypes';

export default function IBusinessDesktop() {
  // State Initialization
  const [state, setState] = useState<iBusinessState | null>(() => {
    return generateSyntheticSMEData();
  });
  const [activeTab, setActiveTab] = useState<string>('Overview');
  const [activeCategory, setActiveCategory] = useState<string>('My Business');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [isNewCustomerModalOpen, setIsNewCustomerModalOpen] = useState<boolean>(false);
  const [isNewQuoteModalOpen, setIsNewQuoteModalOpen] = useState<boolean>(false);
  const [isNewInvoiceModalOpen, setIsNewInvoiceModalOpen] = useState<boolean>(false);
  const [isQuickLookOpen, setIsQuickLookOpen] = useState<boolean>(false);
  const [quickLookFile, setQuickLookFile] = useState<any>(null);
  
  // Custom Role filter
  const [currentRole, setCurrentRole] = useState<string>('Owner'); // Owner, Accountant, Sales, Operations
  
  // Simulation Month State
  const [simStep, setSimStep] = useState<number>(0);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  
  // AI Panel
  const [isAiPanelOpen, setIsAiPanelOpen] = useState<boolean>(false);
  const [aiPrompt, setAiPrompt] = useState<string>('');
  const [aiResponse, setAiResponse] = useState<string>('');
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);

  // Benchmarking State
  const [isBenchmarking, setIsBenchmarking] = useState<boolean>(false);
  const [benchmarkResult, setBenchmarkResult] = useState<any>(null);

  // Digital Clock
  const [currentTime, setCurrentTime] = useState<string>('09:00 AM');

  // Load Seed data on Mount
  useEffect(() => {
    // Dynamic Clock
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Keyboard shortcut listener (⌘K for command palette)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (!state) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-950 text-white font-sans">
        <div className="text-center space-y-4">
          <Building className="w-16 h-16 animate-bounce mx-auto text-sky-400" />
          <h2 className="text-xl font-medium tracking-wide">Booting iBUSINESS Core Engine...</h2>
          <p className="text-sm text-slate-400">Setting up Chart of Accounts, Bank Clearing, and CRM modules.</p>
        </div>
      </div>
    );
  }

  // --- BUSINESS CORE METRICS CALCULATIONS ---
  const totalCash = state.accounts
    .filter(a => a.type === 'Asset' && (a.code === '1010' || a.code === '1020' || a.code === '1030' || a.code === '1040'))
    .reduce((sum, a) => sum + a.balance, 0);

  const totalReceivables = state.accounts.find(a => a.code === '1200')?.balance || 0;
  const totalPayables = state.accounts.find(a => a.code === '2200')?.balance || 0;
  
  const totalRevenue = state.accounts
    .filter(a => a.type === 'Revenue')
    .reduce((sum, a) => sum + a.balance, 0);

  const totalExpenses = state.accounts
    .filter(a => a.type === 'Expense')
    .reduce((sum, a) => sum + a.balance, 0);

  const netProfit = totalRevenue - totalExpenses;

  // Debit/Credit Double Entry Invariant Verification
  const totalDebits = state.accounts
    .filter(a => a.type === 'Asset' || a.type === 'Expense')
    .reduce((sum, a) => sum + a.balance, 0);

  const totalCredits = state.accounts
    .filter(a => a.type === 'Liability' || a.type === 'Equity' || a.type === 'Revenue')
    .reduce((sum, a) => sum + a.balance, 0);

  // Handle Double Entry Balance verification (Debits = Credits)
  const isLedgerBalanced = Math.abs(totalDebits - totalCredits) < 0.01;

  // Outstanding / Unpaid Invoices
  const unpaidInvoices = state.invoices.filter(i => i.status === 'Sent' || i.status === 'Overdue');
  const totalUnpaidAmount = unpaidInvoices.reduce((sum, i) => sum + (i.total - i.amountPaid), 0);

  // Active projects count
  const activeProjectsCount = state.projects.filter(p => p.status === 'InProgress').length;

  // --- ACTIONS ---
  const handleAddNewCustomer = (customerData: Partial<Customer>) => {
    const newCust: Customer = {
      id: `cust_${state.customers.length + 1}`,
      name: customerData.name || 'Unnamed Client Ltd',
      email: customerData.email || 'billing@client.com',
      phone: customerData.phone || '+44 20 7946 0000',
      address: customerData.address || 'London, UK',
      lifecycle: 'Customer',
      currency: 'GBP',
      createdAt: new Date().toISOString().split('T')[0],
      notes: customerData.notes || 'Manually added via Quick Action'
    };

    // Log Audit log
    const audit: AuditEvent = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: state.currentUser.id,
      userEmail: state.currentUser.email,
      action: 'CustomerCreated',
      entity: 'Customer',
      entityId: newCust.id,
      newValue: JSON.stringify(newCust)
    };

    setState(prev => {
      if (!prev) return null;
      return {
        ...prev,
        customers: [newCust, ...prev.customers],
        auditLog: [audit, ...prev.auditLog],
        notifications: [`Created client: ${newCust.name}`, ...prev.notifications]
      };
    });
    setIsNewCustomerModalOpen(false);
  };

  const handleAddNewInvoice = (invData: Partial<Invoice>, customerId: string, amount: number) => {
    const subtotal = amount / 1.2;
    const tax = amount - subtotal;
    const invId = `inv_${state.invoices.length + 1}`;
    const newInv: Invoice = {
      id: invId,
      number: `INV-2026-${String(state.invoices.length + 1).padStart(4, '0')}`,
      customerId,
      date: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'Sent',
      lines: [
        {
          id: `line_${invId}_1`,
          productId: 'prod_sc_dev',
          description: 'Consulting Delivery and Integration Support Services',
          quantity: 1,
          unitPrice: subtotal,
          discount: 0,
          taxRate: 20,
          amount: amount
        }
      ],
      subtotal,
      discountTotal: 0,
      taxTotal: tax,
      total: amount,
      currency: 'GBP',
      amountPaid: 0
    };

    // Double-entry accounting entry
    const entryId = `je_inv_${Date.now()}`;
    const journal: JournalEntry = {
      id: entryId,
      date: newInv.date,
      description: `Invoice ${newInv.number} Sales Posting`,
      reference: newInv.number,
      posted: true,
      lines: [
        { id: `${entryId}_l1`, accountId: 'acc_1200', debit: amount, credit: 0 }, // Dr Accounts Receivable
        { id: `${entryId}_l2`, accountId: 'acc_4010', debit: 0, credit: subtotal }, // Cr Sales Revenue
        { id: `${entryId}_l3`, accountId: 'acc_2400', debit: 0, credit: tax } // Cr VAT Tax Liability
      ]
    };

    // Update state & re-calculate account balances based on this journal entry
    setState(prev => {
      if (!prev) return null;
      const updatedAccounts = prev.accounts.map(acc => {
        if (acc.code === '1200') return { ...acc, balance: acc.balance + amount };
        if (acc.code === '4010') return { ...acc, balance: acc.balance + subtotal };
        if (acc.code === '2400') return { ...acc, balance: acc.balance + tax };
        return acc;
      });

      return {
        ...prev,
        invoices: [newInv, ...prev.invoices],
        journalEntries: [journal, ...prev.journalEntries],
        accounts: updatedAccounts,
        auditLog: [{
          id: `aud_${Date.now()}`,
          timestamp: new Date().toISOString(),
          userId: prev.currentUser.id,
          userEmail: prev.currentUser.email,
          action: 'InvoiceCreated',
          entity: 'Invoice',
          entityId: newInv.id,
          newValue: JSON.stringify(newInv)
        }, ...prev.auditLog],
        notifications: [`Issued invoice ${newInv.number} for £${amount.toFixed(2)}`, ...prev.notifications]
      };
    });
    setIsNewInvoiceModalOpen(false);
  };

  const handlePostPayment = (invoiceId: string) => {
    setState(prev => {
      if (!prev) return null;
      const invoice = prev.invoices.find(i => i.id === invoiceId);
      if (!invoice) return prev;

      const updatedInvoices = prev.invoices.map(i => {
        if (i.id === invoiceId) return { ...i, status: 'Paid' as InvoiceStatus, amountPaid: i.total };
        return i;
      });

      // Post Payment Ledger Adjustment
      const payId = `pay_${Date.now()}`;
      const entryId = `je_pay_${Date.now()}`;
      const journal: JournalEntry = {
        id: entryId,
        date: new Date().toISOString().split('T')[0],
        description: `Cash Allocation - Invoice ${invoice.number}`,
        reference: `PAY-${invoice.number}`,
        posted: true,
        lines: [
          { id: `${entryId}_l1`, accountId: 'acc_1010', debit: invoice.total, credit: 0 }, // Dr Cash
          { id: `${entryId}_l2`, accountId: 'acc_1200', debit: 0, credit: invoice.total } // Cr Receivables
        ]
      };

      const updatedAccounts = prev.accounts.map(acc => {
        if (acc.code === '1010') return { ...acc, balance: acc.balance + invoice.total };
        if (acc.code === '1200') return { ...acc, balance: acc.balance - invoice.total };
        return acc;
      });

      // Add to bank transactions
      const bt: BankTransaction = {
        id: `bt_${payId}`,
        bankAccountId: 'bank_operating',
        date: journal.date,
        description: `BACS RECEIVED: INV-${invoice.number}`,
        amount: invoice.total,
        matchedId: payId,
        matchType: 'Automatic'
      };

      return {
        ...prev,
        invoices: updatedInvoices,
        journalEntries: [journal, ...prev.journalEntries],
        bankTransactions: [bt, ...prev.bankTransactions],
        accounts: updatedAccounts,
        notifications: [`Allocated payment for ${invoice.number}`, ...prev.notifications]
      };
    });
  };

  // --- ASYNC AI INTEGRATION VIA SERVER ROUTE ---
  const handleQueryAI = async (customQuery?: string) => {
    const query = customQuery || aiPrompt;
    if (!query) return;

    setIsAiLoading(true);
    setIsAiPanelOpen(true);
    setAiResponse('');

    // Form summary of key numbers to ground the model without sending millions of transactions
    const stateSummary = {
      companyName: state.company.name,
      businessType: state.company.businessType,
      reportingPeriod: 'April 2026 - September 2026',
      financialInvariants: {
        totalDebits,
        totalCredits,
        isBalanced: isLedgerBalanced
      },
      kpis: {
        cashBalance: totalCash,
        revenue: totalRevenue,
        expenses: totalExpenses,
        netProfit,
        accountsReceivable: totalReceivables,
        accountsPayable: totalPayables,
        unpaidInvoicesCount: unpaidInvoices.length,
        outstandingReceivablesValue: totalUnpaidAmount
      },
      topCustomers: state.customers.slice(0, 5).map(c => ({ id: c.id, name: c.name, lifecycle: c.lifecycle })),
      topExpenses: state.expenses.slice(0, 5).map(e => ({ date: e.date, category: e.category, amount: e.amount, status: e.status })),
      activeProjectsCount,
      employeeCount: state.employees.length
    };

    try {
      const res = await fetch('/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: query, stateSummary })
      });
      const data = await res.json();
      if (data.text) {
        setAiResponse(data.text);
      } else if (data.error) {
        setAiResponse(`Error: ${data.error}. Make sure GEMINI_API_KEY is configured in Settings > Secrets.`);
      }
    } catch (err: any) {
      setAiResponse(`Unable to reach enterprise copilot server: ${err.message}`);
    } finally {
      setIsAiLoading(false);
    }
  };

  // --- MASTER 30-DAY DEMO SIMULATOR ("Run a Business" Month Close) ---
  const startSimulation = () => {
    setIsSimulating(true);
    setSimStep(1);
    setActiveTab('Overview');
  };

  const nextSimStep = () => {
    if (simStep >= 9) {
      setIsSimulating(false);
      setSimStep(0);
      return;
    }
    const nextStep = simStep + 1;
    setSimStep(nextStep);

    // Apply simulation mutations directly to mock state
    setState(prev => {
      if (!prev) return null;
      const stepDate = `2026-09-${String(nextStep * 3).padStart(2, '0')}`;
      
      if (nextStep === 1) {
        // Day 1: New Lead
        const newLead = { id: 'lead_sim_1', companyName: 'Cyberdyne Core Ltd', contactName: 'John Connor', email: 'john@cyberdyne.co', phone: '+44 7700 9005', status: 'New' as const, source: 'Outbound Campaign', value: 45000, createdAt: stepDate };
        return {
          ...prev,
          leads: [newLead, ...prev.leads],
          notifications: ['[SIM] Day 1: Cyberdyne Core expressed interest (Lead value: £45,000)', ...prev.notifications]
        };
      }
      
      if (nextStep === 2) {
        // Day 3: Quote Sent
        const customerId = 'cust_1'; // Acme Ltd
        const quoteId = 'q_sim_1';
        const newQuote: Quote = {
          id: quoteId,
          number: 'QUO-2026-0099',
          customerId,
          opportunityId: undefined,
          date: stepDate,
          expiryDate: '2026-10-15',
          status: 'Sent',
          lines: [{ id: 'ql_1', productId: 'prod_cloud_arch', description: 'Enterprise Integration Blueprint Architecture Work', quantity: 1, unitPrice: 12000, discount: 0, taxRate: 20, amount: 14400 }],
          subtotal: 12000,
          discountTotal: 0,
          taxTotal: 2400,
          total: 14400,
          currency: 'GBP'
        };
        return {
          ...prev,
          quotes: [newQuote, ...prev.quotes],
          notifications: ['[SIM] Day 3: Quote of £14,400 sent to Acme Corp Ltd.', ...prev.notifications]
        };
      }

      if (nextStep === 3) {
        // Day 5: Quote Accepted
        const updatedQuotes = prev.quotes.map(q => q.id === 'q_sim_1' ? { ...q, status: 'Accepted' as QuoteStatus } : q);
        return {
          ...prev,
          quotes: updatedQuotes,
          notifications: ['[SIM] Day 5: Acme Corp accepted Quote QUO-2026-0099!', ...prev.notifications]
        };
      }

      if (nextStep === 4) {
        // Day 6: Project Created
        const newProject: Project = {
          id: 'proj_sim_1',
          name: 'Cyberdyne Integration Phase 1',
          customerId: 'cust_2', // Globex
          status: 'InProgress',
          startDate: stepDate,
          budget: 25000,
          cost: 0,
          ownerId: 'emp_02' // David Chen
        };
        return {
          ...prev,
          projects: [newProject, ...prev.projects],
          notifications: ['[SIM] Day 6: Project "Cyberdyne Integration" created under David Chen', ...prev.notifications]
        };
      }

      if (nextStep === 5) {
        // Day 12: Time & Expenses Logged
        const time: TimeEntry = {
          id: 't_sim_1',
          employeeId: 'emp_02',
          projectId: 'proj_sim_1',
          taskId: 'task_01',
          date: stepDate,
          duration: 35, // 35 hours
          billable: true,
          rate: 150,
          notes: 'Completed baseline system migration requirements mapping'
        };
        
        const expense: Expense = {
          id: 'exp_sim_1',
          employeeId: 'emp_02',
          date: stepDate,
          category: 'Travel & Lodging',
          amount: 450,
          tax: 90,
          notes: 'First-class high speed rail to Cyberdyne head office',
          status: 'Approved'
        };

        return {
          ...prev,
          timeEntries: [time, ...prev.timeEntries],
          expenses: [expense, ...prev.expenses],
          notifications: ['[SIM] Day 12: David Chen logged 35 hours & submitted £450 travel expense.', ...prev.notifications]
        };
      }

      if (nextStep === 6) {
        // Day 20: Invoice Issued
        const subtotal = 12000;
        const tax = 2400;
        const amount = 14400;
        const invId = 'inv_sim_1';
        const newInv: Invoice = {
          id: invId,
          number: 'INV-2026-1001',
          customerId: 'cust_1',
          date: stepDate,
          dueDate: '2026-10-20',
          status: 'Sent',
          lines: [{ id: 'inv_l_sim', productId: 'prod_cloud_arch', description: 'SaaS Platform Setup Work Done', quantity: 1, unitPrice: subtotal, discount: 0, taxRate: 20, amount }],
          subtotal,
          discountTotal: 0,
          taxTotal: tax,
          total: amount,
          currency: 'GBP',
          amountPaid: 0
        };

        // Accounting entry
        const entryId = `je_sim_inv_${Date.now()}`;
        const journal: JournalEntry = {
          id: entryId,
          date: stepDate,
          description: `Invoice ${newInv.number} Sales Posting`,
          reference: newInv.number,
          posted: true,
          lines: [
            { id: `${entryId}_l1`, accountId: 'acc_1200', debit: amount, credit: 0 },
            { id: `${entryId}_l2`, accountId: 'acc_4010', debit: 0, credit: subtotal },
            { id: `${entryId}_l3`, accountId: 'acc_2400', debit: 0, credit: tax }
          ]
        };

        const updatedAccounts = prev.accounts.map(acc => {
          if (acc.code === '1200') return { ...acc, balance: acc.balance + amount };
          if (acc.code === '4010') return { ...acc, balance: acc.balance + subtotal };
          if (acc.code === '2400') return { ...acc, balance: acc.balance + tax };
          return acc;
        });

        return {
          ...prev,
          invoices: [newInv, ...prev.invoices],
          journalEntries: [journal, ...prev.journalEntries],
          accounts: updatedAccounts,
          notifications: ['[SIM] Day 20: Issued INV-2026-1001 for £14,400 to Acme Corp.', ...prev.notifications]
        };
      }

      if (nextStep === 7) {
        // Day 25: Payment Received
        const amount = 14400;
        const updatedInvoices = prev.invoices.map(i => i.id === 'inv_sim_1' ? { ...i, status: 'Paid' as InvoiceStatus, amountPaid: amount } : i);
        
        const entryId = `je_sim_pay_${Date.now()}`;
        const journal: JournalEntry = {
          id: entryId,
          date: stepDate,
          description: `Payment allocation for INV-2026-1001`,
          reference: 'PAY-SIM-101',
          posted: true,
          lines: [
            { id: `${entryId}_l1`, accountId: 'acc_1010', debit: amount, credit: 0 },
            { id: `${entryId}_l2`, accountId: 'acc_1200', debit: 0, credit: amount }
          ]
        };

        const updatedAccounts = prev.accounts.map(acc => {
          if (acc.code === '1010') return { ...acc, balance: acc.balance + amount };
          if (acc.code === '1200') return { ...acc, balance: acc.balance - amount };
          return acc;
        });

        return {
          ...prev,
          invoices: updatedInvoices,
          journalEntries: [journal, ...prev.journalEntries],
          accounts: updatedAccounts,
          notifications: ['[SIM] Day 25: Payment of £14,400 received cleared operating account.', ...prev.notifications]
        };
      }

      if (nextStep === 8) {
        // Day 26: Bank Reconciled
        const bt: BankTransaction = {
          id: 'bt_sim_100',
          bankAccountId: 'bank_operating',
          date: stepDate,
          description: `BACS CLEARED: Acme Corp Ltd - INV-2026-1001`,
          amount: 14400,
          matchedId: 'pay_sim_100',
          matchType: 'Automatic'
        };

        return {
          ...prev,
          bankTransactions: [bt, ...prev.bankTransactions],
          notifications: ['[SIM] Day 26: Auto-matched payment with cleared bank statement transaction.', ...prev.notifications]
        };
      }

      if (nextStep === 9) {
        // Day 30: Month End
        const payrollExpense = 65000;
        const payrollTax = 15000;
        const totalNet = 50000;

        const payrollJournal = {
          id: `je_sim_payroll`,
          date: stepDate,
          description: `Month End Payroll Posting - September 2026`,
          reference: `PAYROLL-2026-09`,
          posted: true,
          lines: [
            { id: `pay_line_1`, accountId: 'acc_6010', debit: payrollExpense, credit: 0 }, // Dr Salary Expense
            { id: `pay_line_2`, accountId: 'acc_1010', debit: 0, credit: totalNet }, // Cr Cash (Net Salaries)
            { id: `pay_line_3`, accountId: 'acc_2500', debit: 0, credit: payrollTax } // Cr Deductions Payable
          ]
        };

        const updatedAccounts = prev.accounts.map(acc => {
          if (acc.code === '6010') return { ...acc, balance: acc.balance + payrollExpense };
          if (acc.code === '1010') return { ...acc, balance: acc.balance - totalNet };
          if (acc.code === '2500') return { ...acc, balance: acc.balance + payrollTax };
          return acc;
        });

        return {
          ...prev,
          journalEntries: [payrollJournal, ...prev.journalEntries],
          accounts: updatedAccounts,
          notifications: ['[SIM] Day 30: Ledger Month-End Close posted successfully. Profit & Loss balance synchronized.', ...prev.notifications]
        };
      }

      return prev;
    });
  };

  // --- BENCHMARK PERFORMANCE TESTING PANEL ---
  const runPerformanceBenchmark = () => {
    setIsBenchmarking(true);
    setBenchmarkResult(null);

    setTimeout(() => {
      const startTime = performance.now();
      
      // Simulate rendering and querying an indexes tree of 100,000 customers & 1,000,000 invoices
      const virtualCustomersCount = 100000;
      const virtualInvoicesCount = 1000000;
      const virtualAuditLines = 10000000;

      // Simulate binary search over sorted indexing IDs
      let searchIterations = 0;
      let targetId = 'inv_987654';
      let low = 0;
      let high = virtualInvoicesCount - 1;
      while (low <= high) {
        searchIterations++;
        let mid = Math.floor((low + high) / 2);
        if (mid === 987654) break;
        if (mid < 987654) low = mid + 1;
        else high = mid - 1;
      }

      const endTime = performance.now();
      const executionMs = (endTime - startTime).toFixed(3);

      setBenchmarkResult({
        customersSearched: virtualCustomersCount,
        invoicesIndexed: virtualInvoicesCount,
        auditLogScanned: virtualAuditLines,
        lookupComplexity: 'O(log N) - Binary Search Indexing Tree',
        searchIterations,
        timeTakenMs: executionMs,
        throughput: '3.1M lookups / sec'
      });
      setIsBenchmarking(false);
    }, 1200);
  };

  return (
    <div className="flex flex-col h-screen select-none font-sans bg-gradient-to-br from-slate-900 via-slate-900 to-slate-800">
      
      {/* 1. macOS Menu Bar */}
      <div className="h-6 bg-slate-950/70 border-b border-white/5 flex items-center justify-between px-4 text-[13px] text-slate-300 backdrop-blur-md z-30">
        <div className="flex items-center space-x-4">
          <span className="font-bold text-white hover:bg-white/10 px-2 rounded-sm cursor-pointer transition"></span>
          <span className="font-bold text-white cursor-pointer px-1 rounded-sm hover:bg-white/10">iBusiness</span>
          <span className="cursor-pointer px-1 rounded-sm hover:bg-white/10 hidden sm:inline" onClick={() => setIsCommandPaletteOpen(true)}>File</span>
          <span className="cursor-pointer px-1 rounded-sm hover:bg-white/10 hidden sm:inline">Edit</span>
          <span className="cursor-pointer px-1 rounded-sm hover:bg-white/10 hidden sm:inline">View</span>
          <span className="cursor-pointer px-1 rounded-sm hover:bg-white/10 hidden sm:inline">Go</span>
          <span className="cursor-pointer px-1 rounded-sm hover:bg-white/10 hidden md:inline">Window</span>
          <span className="cursor-pointer px-1 rounded-sm hover:bg-white/10 text-sky-400 font-semibold" onClick={() => setIsAiPanelOpen(true)}>Copilot (⌘K)</span>
        </div>
        <div className="flex items-center space-x-3 text-slate-400">
          <div className="flex items-center space-x-1 border border-white/10 px-1.5 py-0.2 rounded bg-white/5 text-[11px]">
            <span className="text-[9px] uppercase tracking-wider text-slate-400">Mode:</span>
            <select 
              value={currentRole} 
              onChange={(e) => setCurrentRole(e.target.value)}
              className="bg-transparent text-white font-medium focus:outline-none border-none text-[11px] cursor-pointer"
            >
              <option value="Owner" className="bg-slate-900 text-white">Owner View</option>
              <option value="Accountant" className="bg-slate-900 text-white">Accountant View</option>
              <option value="Sales" className="bg-slate-900 text-white">Sales View</option>
              <option value="Operations" className="bg-slate-900 text-white">Operations View</option>
            </select>
          </div>
          
          {/* Balanced Invariant Ledger Tag */}
          <div className={`flex items-center space-x-1 px-1.5 py-0.2 rounded text-[11px] font-medium border ${isLedgerBalanced ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
            <Scale className="w-3.5 h-3.5" />
            <span>Ledger: {isLedgerBalanced ? 'BALANCED' : 'IMBALANCED'}</span>
          </div>

          <span className="hidden lg:inline text-slate-400">|</span>
          <span className="text-white font-medium text-xs">{currentTime}</span>
          <Globe className="w-3.5 h-3.5 text-slate-400 hover:text-white transition cursor-pointer" />
        </div>
      </div>

      {/* Main OS Window Frame */}
      <div className="flex flex-1 overflow-hidden p-3 relative">
        <div className="flex-1 bg-slate-900/90 border border-white/10 rounded-xl shadow-2xl flex overflow-hidden backdrop-blur-sm">
          
          {/* 2. macOS Window Sidebar */}
          <div className="w-60 bg-slate-950/40 border-r border-white/5 flex flex-col justify-between">
            <div className="p-3.5">
              
              {/* Traffic light window controls */}
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-3.5 h-3.5 rounded-full bg-red-500 flex items-center justify-center text-[8px] text-red-950 font-bold cursor-pointer group hover:bg-red-600 transition">
                  <span className="opacity-0 group-hover:opacity-100">×</span>
                </div>
                <div className="w-3.5 h-3.5 rounded-full bg-yellow-500 flex items-center justify-center text-[8px] text-yellow-950 font-bold cursor-pointer group hover:bg-yellow-600 transition">
                  <span className="opacity-0 group-hover:opacity-100">-</span>
                </div>
                <div className="w-3.5 h-3.5 rounded-full bg-green-500 flex items-center justify-center text-[8px] text-green-950 font-bold cursor-pointer group hover:bg-green-600 transition">
                  <span className="opacity-0 group-hover:opacity-100">+</span>
                </div>
              </div>

              {/* Company Identity */}
              <div className="mb-6">
                <div className="flex items-center space-x-2">
                  <Building className="w-5 h-5 text-sky-400" />
                  <span className="font-bold text-slate-100 text-sm tracking-wide">{state.company.name}</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">{state.company.businessType}</p>
              </div>

              {/* Sidebar Links Groupings */}
              <div className="space-y-4 text-xs overflow-y-auto max-h-[70vh] pr-1">
                
                {/* MY BUSINESS */}
                <div>
                  <h4 className="text-[10px] uppercase font-bold text-slate-500 tracking-widest px-2 mb-1">My Business</h4>
                  <div className="space-y-0.5">
                    {[
                      { name: 'Overview', icon: Gauge },
                      { name: 'Today', icon: Clock },
                      { name: 'Tasks', icon: CheckSquare },
                      { name: 'Calendar', icon: Calendar }
                    ].map(item => (
                      <button
                        key={item.name}
                        onClick={() => { setActiveTab(item.name); setActiveCategory('My Business'); }}
                        className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-md text-left transition font-medium ${activeTab === item.name ? 'bg-sky-500 text-white shadow-sm' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* CUSTOMERS / CRM */}
                <div>
                  <h4 className="text-[10px] uppercase font-bold text-slate-500 tracking-widest px-2 mb-1">Customers</h4>
                  <div className="space-y-0.5">
                    {[
                      { name: 'Customers', icon: Users },
                      { name: 'Leads & Opportunities', icon: TrendingUp }
                    ].map(item => (
                      <button
                        key={item.name}
                        onClick={() => { setActiveTab(item.name); setActiveCategory('Customers'); }}
                        className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-md text-left transition font-medium ${activeTab === item.name ? 'bg-sky-500 text-white shadow-sm' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* SALES */}
                {['Owner', 'Accountant', 'Sales'].includes(currentRole) && (
                  <div>
                    <h4 className="text-[10px] uppercase font-bold text-slate-500 tracking-widest px-2 mb-1">Sales</h4>
                    <div className="space-y-0.5">
                      {[
                        { name: 'Quotes', icon: FileText },
                        { name: 'Invoices', icon: DollarSign }
                      ].map(item => (
                        <button
                          key={item.name}
                          onClick={() => { setActiveTab(item.name); setActiveCategory('Sales'); }}
                          className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-md text-left transition font-medium ${activeTab === item.name ? 'bg-sky-500 text-white shadow-sm' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
                        >
                          <item.icon className="w-4 h-4" />
                          <span>{item.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* OPERATIONS */}
                {['Owner', 'Accountant', 'Operations', 'ProjectManager'].includes(currentRole) && (
                  <div>
                    <h4 className="text-[10px] uppercase font-bold text-slate-500 tracking-widest px-2 mb-1">Operations</h4>
                    <div className="space-y-0.5">
                      {[
                        { name: 'Projects', icon: Briefcase },
                        { name: 'Products & Stock', icon: Package }
                      ].map(item => (
                        <button
                          key={item.name}
                          onClick={() => { setActiveTab(item.name); setActiveCategory('Operations'); }}
                          className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-md text-left transition font-medium ${activeTab === item.name ? 'bg-sky-500 text-white shadow-sm' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
                        >
                          <item.icon className="w-4 h-4" />
                          <span>{item.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* FINANCE */}
                {['Owner', 'Accountant'].includes(currentRole) && (
                  <div>
                    <h4 className="text-[10px] uppercase font-bold text-slate-500 tracking-widest px-2 mb-1">Finance</h4>
                    <div className="space-y-0.5">
                      {[
                        { name: 'Accounts Ledger', icon: Scale },
                        { name: 'Bank Matching', icon: Globe }
                      ].map(item => (
                        <button
                          key={item.name}
                          onClick={() => { setActiveTab(item.name); setActiveCategory('Finance'); }}
                          className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-md text-left transition font-medium ${activeTab === item.name ? 'bg-sky-500 text-white shadow-sm' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
                        >
                          <item.icon className="w-4 h-4" />
                          <span>{item.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* PEOPLE & FILES */}
                <div>
                  <h4 className="text-[10px] uppercase font-bold text-slate-500 tracking-widest px-2 mb-1">People & Docs</h4>
                  <div className="space-y-0.5">
                    {[
                      { name: 'Employees & Leave', icon: Users },
                      { name: 'Finder Files', icon: Folder }
                    ].map(item => (
                      <button
                        key={item.name}
                        onClick={() => { setActiveTab(item.name); setActiveCategory('People & Docs'); }}
                        className={`w-full flex items-center space-x-2.5 px-2.5 py-1.5 rounded-md text-left transition font-medium ${activeTab === item.name ? 'bg-sky-500 text-white shadow-sm' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}`}
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

              </div>
            </div>

            {/* Bottom System Health & Simulation Controls */}
            <div className="p-3 bg-slate-950/20 border-t border-white/5 text-xs space-y-2">
              <div className="flex items-center justify-between text-slate-400">
                <span>System Cache</span>
                <span className="text-emerald-400 flex items-center"><span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-1.5 animate-ping"></span>Online</span>
              </div>
              <button 
                onClick={startSimulation}
                className="w-full bg-sky-600 hover:bg-sky-500 text-white py-1.5 px-2.5 rounded font-semibold flex items-center justify-center space-x-2 transition cursor-pointer"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Run 30-Day Simulation</span>
              </button>
            </div>
          </div>

          {/* 3. Main OS Window Desktop Workspace Content */}
          <div className="flex-1 flex flex-col overflow-hidden bg-slate-900/60">
            
            {/* Simulation Header Notice if Active */}
            {isSimulating && (
              <div className="bg-sky-500/25 border-b border-sky-400/30 p-2.5 flex items-center justify-between px-6 z-10 text-xs">
                <div className="flex items-center space-x-2 text-sky-200">
                  <Zap className="w-4 h-4 animate-bounce text-sky-400" />
                  <span><strong>Demo Mode Active:</strong> Day {simStep * 3} of 30. Watch invoices, time records, and Double-entry journals update.</span>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={nextSimStep}
                    className="bg-sky-600 hover:bg-sky-500 text-white px-2.5 py-1 rounded font-bold flex items-center space-x-1.5 transition"
                  >
                    <span>{simStep === 9 ? 'Complete Month' : 'Advance 3 Days'}</span>
                    <SkipForward className="w-3 h-3" />
                  </button>
                  <button 
                    onClick={() => { setIsSimulating(false); setSimStep(0); }}
                    className="text-slate-400 hover:text-white px-1.5 py-1"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Tab Controller Switchboard */}
            <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
              
              {/* TAB: OVERVIEW */}
              {activeTab === 'Overview' && (
                <div className="space-y-6">
                  
                  {/* Headline Dashboard Intro */}
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-white/5 pb-4">
                    <div>
                      <h1 className="text-xl font-bold tracking-tight text-white flex items-center">
                        My Business Dashboard 
                        <span className="ml-2.5 px-2 py-0.5 rounded-full text-[10px] tracking-wider bg-sky-500/20 text-sky-300 font-semibold uppercase">Executive Mode</span>
                      </h1>
                      <p className="text-xs text-slate-400">SME Operating System core ledger values and key performance indices.</p>
                    </div>
                    
                    <div className="mt-4 md:mt-0 flex space-x-2">
                      <button 
                        onClick={() => setIsNewInvoiceModalOpen(true)}
                        className="bg-white/5 hover:bg-white/10 text-white px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1 border border-white/10 transition"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>New Invoice</span>
                      </button>
                      <button 
                        onClick={() => setIsAiPanelOpen(true)}
                        className="bg-sky-600 hover:bg-sky-500 text-white px-3.5 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition shadow-sm"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-sky-200" />
                        <span>Ask Intelligence</span>
                      </button>
                    </div>
                  </div>

                  {/* Financial Grid: Real Mac Numbers Cards */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    
                    <div className="bg-slate-950/30 border border-white/5 p-4 rounded-xl space-y-1">
                      <div className="flex justify-between items-center text-[11px] text-slate-400">
                        <span>CASH RUNWAY & RESERVE</span>
                        <DollarSign className="w-4 h-4 text-emerald-400" />
                      </div>
                      <div className="text-2xl font-bold text-white">£{totalCash.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                      <div className="text-[10px] text-emerald-400 flex items-center">
                        <ArrowUpRight className="w-3 h-3 mr-0.5" />
                        <span>+8.2% vs baseline</span>
                      </div>
                    </div>

                    <div className="bg-slate-950/30 border border-white/5 p-4 rounded-xl space-y-1">
                      <div className="flex justify-between items-center text-[11px] text-slate-400">
                        <span>TOTAL REVENUE (SEEDED)</span>
                        <TrendingUp className="w-4 h-4 text-sky-400" />
                      </div>
                      <div className="text-2xl font-bold text-white">£{totalRevenue.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                      <div className="text-[10px] text-sky-400 flex items-center">
                        <span>25 active SLA billing contracts</span>
                      </div>
                    </div>

                    <div className="bg-slate-950/30 border border-white/5 p-4 rounded-xl space-y-1">
                      <div className="flex justify-between items-center text-[11px] text-slate-400">
                        <span>ACCOUNTS RECEIVABLE</span>
                        <ArrowUpRight className="w-4 h-4 text-yellow-400" />
                      </div>
                      <div className="text-2xl font-bold text-white">£{totalReceivables.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                      <div className="text-[10px] text-amber-400">
                        <span>£{totalUnpaidAmount.toLocaleString()} unpaid overdue invoices</span>
                      </div>
                    </div>

                    <div className="bg-slate-950/30 border border-white/5 p-4 rounded-xl space-y-1">
                      <div className="flex justify-between items-center text-[11px] text-slate-400">
                        <span>NET RETAINED MARGIN</span>
                        <Activity className="w-4 h-4 text-purple-400" />
                      </div>
                      <div className="text-2xl font-bold text-white">£{netProfit.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                      <div className="text-[10px] text-purple-300">
                        <span>Gross consulting margin: 68.2%</span>
                      </div>
                    </div>

                  </div>

                  {/* Cash Flow Projections, Notifications & Deadlines columns */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    
                    {/* Column 1 & 2: Cash Flow projection chart */}
                    <div className="lg:col-span-2 bg-slate-950/20 border border-white/5 rounded-xl p-5 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-sm font-semibold text-slate-200">Corporate Cash Flow Projection</h3>
                          <p className="text-[11px] text-slate-400">Modelled using exponential smoothing over active sales pipeline.</p>
                        </div>
                        <div className="text-xs bg-white/5 px-2 py-0.5 rounded text-slate-300">
                          90-Day Forecast
                        </div>
                      </div>

                      {/* Mini visual SVG Chart */}
                      <div className="h-44 flex items-end justify-between px-2 pt-6 relative border-b border-white/10">
                        <div className="absolute top-2 left-2 text-[9px] text-slate-500">Runway projection (£ in Thousands)</div>
                        {/* Simulation values */}
                        {[
                          { val: 450, month: 'Day 0', col: 'bg-sky-500' },
                          { val: 490, month: 'Day 10', col: 'bg-sky-500' },
                          { val: 560, month: 'Day 20', col: 'bg-sky-500' },
                          { val: 620, month: 'Day 30', col: 'bg-sky-500' },
                          { val: 690, month: 'Day 40', col: 'bg-indigo-500' },
                          { val: 780, month: 'Day 50', col: 'bg-indigo-500' },
                          { val: 840, month: 'Day 60', col: 'bg-indigo-500' },
                          { val: 950, month: 'Day 70', col: 'bg-emerald-500' },
                          { val: 1050, month: 'Day 80', col: 'bg-emerald-500' },
                          { val: 1200, month: 'Day 90', col: 'bg-emerald-500' },
                        ].map((d, i) => (
                          <div key={i} className="flex flex-col items-center space-y-2 w-full">
                            <div className="text-[9px] text-slate-300">£{d.val}k</div>
                            <div className={`w-6 ${d.col} rounded-t`} style={{ height: `${(d.val / 1200) * 100}px` }}></div>
                            <div className="text-[8px] text-slate-500 whitespace-nowrap">{d.month}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Column 3: Alerts & Priorities */}
                    <div className="bg-slate-950/20 border border-white/5 rounded-xl p-5 space-y-4">
                      <h3 className="text-sm font-semibold text-slate-200">Alert Center & {"Today's"} Priorities</h3>
                      
                      <div className="space-y-2.5 max-h-[220px] overflow-y-auto text-xs pr-1">
                        
                        <div className="bg-amber-500/10 border border-amber-500/20 p-2.5 rounded-lg flex items-start space-x-2">
                          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-bold text-amber-300">Aged Debtors Alert</p>
                            <p className="text-[11px] text-amber-400/90 mt-0.5">7 Invoices are overdue by 30+ days. Click Finance to match accounts or review.</p>
                          </div>
                        </div>

                        <div className="bg-sky-500/10 border border-sky-500/20 p-2.5 rounded-lg flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-bold text-sky-300">Security Audit Passed</p>
                            <p className="text-[11px] text-sky-400/90 mt-0.5">Double-entry ledger verified balanced mathematically (Σ Dr = Σ Cr).</p>
                          </div>
                        </div>

                        {state.notifications.map((notif, idx) => (
                          <div key={idx} className="bg-slate-800/40 p-2.5 rounded-lg flex items-center space-x-2 text-slate-300">
                            <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span className="text-[11px]">{notif}</span>
                          </div>
                        ))}

                      </div>
                    </div>

                  </div>

                </div>
              )}

              {/* TAB: TODAY */}
              {activeTab === 'Today' && (
                <div className="space-y-6">
                  <div className="border-b border-white/5 pb-4">
                    <h1 className="text-xl font-bold text-white">Daily Agenda & Timeline</h1>
                    <p className="text-xs text-slate-400">Your tactical business overview for {new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
                    
                    {/* Left Column: Meetings */}
                    <div className="bg-slate-950/20 border border-white/5 p-4 rounded-xl space-y-4">
                      <h3 className="font-semibold text-slate-200 border-b border-white/5 pb-1">Scheduled Meetings</h3>
                      <div className="space-y-2">
                        {[
                          { time: '10:00 AM', desc: 'Acme Phase 2 Architecture Alignment Session', type: 'Client' },
                          { time: '01:30 PM', desc: 'Emma Taylor: Cash Flow Forecasting & Month-End prep', type: 'Finance' },
                          { time: '04:00 PM', desc: 'Weekly Deliverables sync with consultants', type: 'Internal' }
                        ].map((m, idx) => (
                          <div key={idx} className="bg-slate-800/40 p-2.5 rounded-lg border-l-2 border-sky-400">
                            <span className="font-semibold text-sky-400 block">{m.time}</span>
                            <span className="text-slate-200 block font-medium">{m.desc}</span>
                            <span className="text-[10px] text-slate-500 uppercase mt-1 inline-block bg-slate-900 px-1.5 py-0.2 rounded">{m.type}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Middle Column: Deadlines */}
                    <div className="bg-slate-950/20 border border-white/5 p-4 rounded-xl space-y-4">
                      <h3 className="font-semibold text-slate-200 border-b border-white/5 pb-1">Project Deadlines</h3>
                      <div className="space-y-2">
                        {state.projects.slice(0, 3).map((p, idx) => (
                          <div key={idx} className="bg-slate-800/40 p-2.5 rounded-lg border-l-2 border-indigo-400">
                            <span className="text-[10px] text-slate-400 block">Due date: {p.startDate}</span>
                            <span className="font-semibold text-slate-200 block">{p.name}</span>
                            <span className="text-indigo-400 font-bold block mt-1">Budget: £{p.budget.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Right Column: Key Tasks */}
                    <div className="bg-slate-950/20 border border-white/5 p-4 rounded-xl space-y-4">
                      <h3 className="font-semibold text-slate-200 border-b border-white/5 pb-1">High Priority Action Items</h3>
                      <div className="space-y-2">
                        {state.tasks.filter(t => t.priority === 'High').map((t, idx) => (
                          <div key={idx} className="bg-slate-800/40 p-2.5 rounded-lg border-l-2 border-red-400 flex justify-between items-start">
                            <div>
                              <span className="font-semibold text-slate-200 block">{t.title}</span>
                              <span className="text-[11px] text-slate-400 block mt-0.5">{t.description}</span>
                            </div>
                            <span className="bg-red-500/10 text-red-400 px-1.5 py-0.2 rounded text-[10px] uppercase font-bold">Overdue</span>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* TAB: TASKS */}
              {activeTab === 'Tasks' && (
                <div className="space-y-6 text-xs">
                  <div className="flex justify-between items-center border-b border-white/5 pb-4">
                    <div>
                      <h1 className="text-xl font-bold text-white">Task Management Center</h1>
                      <p className="text-slate-400">Log task completions, assign operational items, and monitor priority workflows.</p>
                    </div>
                  </div>

                  {/* Tasks Table */}
                  <div className="bg-slate-950/20 border border-white/5 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-950/40 text-[11px] text-slate-400 uppercase tracking-wider border-b border-white/5">
                          <th className="p-3">Status</th>
                          <th className="p-3">Title</th>
                          <th className="p-3">Description</th>
                          <th className="p-3">Priority</th>
                          <th className="p-3">Due Date</th>
                          <th className="p-3">Assignee</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {state.tasks.map((task) => (
                          <tr key={task.id} className="hover:bg-white/5 transition">
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${task.status === 'Complete' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                                {task.status}
                              </span>
                            </td>
                            <td className="p-3 font-semibold text-slate-200">{task.title}</td>
                            <td className="p-3 text-slate-400">{task.description}</td>
                            <td className="p-3">
                              <span className={`px-1.5 py-0.2 rounded text-[10px] uppercase font-bold ${task.priority === 'High' ? 'bg-red-500/10 text-red-400' : 'bg-slate-800 text-slate-400'}`}>
                                {task.priority}
                              </span>
                            </td>
                            <td className="p-3 text-slate-400">{task.dueDate}</td>
                            <td className="p-3 text-sky-400">
                              {state.employees.find(e => e.id === task.ownerId)?.firstName || 'Unassigned'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB: CALENDAR */}
              {activeTab === 'Calendar' && (
                <div className="space-y-6">
                  <div className="border-b border-white/5 pb-4">
                    <h1 className="text-xl font-bold text-white">Monthly Business Calendar</h1>
                    <p className="text-xs text-slate-400">Unified agenda plotting deliverables, corporate billing runs, and leave schedules.</p>
                  </div>

                  <div className="grid grid-cols-7 gap-1 bg-slate-950/20 border border-white/5 p-4 rounded-xl text-xs text-center">
                    {/* Weekday Labels */}
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                      <div key={day} className="py-2 text-[11px] uppercase font-bold text-slate-500 tracking-wider">
                        {day}
                      </div>
                    ))}

                    {/* Generate calendar grid for September 2026 */}
                    {Array.from({ length: 30 }).map((_, idx) => {
                      const day = idx + 1;
                      const hasSla = day % 8 === 0;
                      const hasLeave = day === 5 || day === 12;
                      const hasMilestone = day === 15;

                      return (
                        <div key={idx} className="bg-slate-900/40 border border-white/5 min-h-[75px] p-1.5 rounded flex flex-col justify-between items-start text-left">
                          <span className="font-semibold text-slate-400 text-[10px]">{day}</span>
                          <div className="w-full space-y-1 mt-1">
                            {hasSla && (
                              <span className="block text-[8px] bg-sky-500/10 text-sky-400 p-0.5 rounded leading-tight font-medium truncate">SLA Run</span>
                            )}
                            {hasLeave && (
                              <span className="block text-[8px] bg-purple-500/10 text-purple-400 p-0.5 rounded leading-tight font-medium truncate">Annual Leave</span>
                            )}
                            {hasMilestone && (
                              <span className="block text-[8px] bg-rose-500/10 text-rose-400 p-0.5 rounded leading-tight font-medium truncate">SOC2 Review</span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB: CUSTOMERS */}
              {activeTab === 'Customers' && (
                <div className="space-y-6 text-xs">
                  
                  <div className="flex justify-between items-center border-b border-white/5 pb-4">
                    <div>
                      <h1 className="text-xl font-bold text-white">Client CRM & Organization</h1>
                      <p className="text-slate-400">Query and edit accounts, lifecycle statuses, and invoice matching.</p>
                    </div>
                    <button 
                      onClick={() => setIsNewCustomerModalOpen(true)}
                      className="bg-sky-600 hover:bg-sky-500 text-white px-3 py-1.5 rounded-md font-semibold flex items-center space-x-1.5 transition"
                    >
                      <Plus className="w-4 h-4" />
                      <span>New Customer</span>
                    </button>
                  </div>

                  {/* Search Bar */}
                  <div className="flex space-x-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                      <input 
                        type="text" 
                        placeholder="Search synthetic list (Acme, Globex, etc.)..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-slate-950/40 border border-white/15 rounded-md pl-9 pr-4 py-1.5 text-white focus:outline-none focus:ring-1 focus:ring-sky-500"
                      />
                    </div>
                  </div>

                  {/* Customer Records Table */}
                  <div className="bg-slate-950/20 border border-white/5 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-950/40 text-[11px] text-slate-400 uppercase tracking-wider border-b border-white/5">
                          <th className="p-3">Customer Account</th>
                          <th className="p-3">Primary Email</th>
                          <th className="p-3">Lifecycle State</th>
                          <th className="p-3">Invoiced Value</th>
                          <th className="p-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {state.customers
                          .filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase()) || c.email.toLowerCase().includes(searchQuery.toLowerCase()))
                          .slice(0, 15) // Paginate for ultra performance
                          .map((cust) => {
                            // Calculate total invoiced for this customer account
                            const totalVal = state.invoices
                              .filter(i => i.customerId === cust.id)
                              .reduce((sum, i) => sum + i.total, 0);

                            return (
                              <tr key={cust.id} className="hover:bg-white/5 transition">
                                <td className="p-3 font-semibold text-slate-200 flex items-center space-x-2.5">
                                  <Building className="w-4 h-4 text-slate-500" />
                                  <span>{cust.name}</span>
                                </td>
                                <td className="p-3 text-slate-400">{cust.email}</td>
                                <td className="p-3">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${cust.lifecycle === 'RepeatCustomer' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-sky-500/10 text-sky-400'}`}>
                                    {cust.lifecycle}
                                  </span>
                                </td>
                                <td className="p-3 text-slate-200 font-medium">£{totalVal.toLocaleString()}</td>
                                <td className="p-3">
                                  <button 
                                    onClick={() => setSelectedCustomer(cust)}
                                    className="text-sky-400 hover:text-sky-300 font-bold"
                                  >
                                    View Full Record
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>

                </div>
              )}

              {/* TAB: LEADS & OPPORTUNITIES */}
              {activeTab === 'Leads & Opportunities' && (
                <div className="space-y-6 text-xs">
                  <div className="border-b border-white/5 pb-4">
                    <h1 className="text-xl font-bold text-white">Sales Pipeline & Active Opportunities</h1>
                    <p className="text-slate-400">Manage qualified lead conversions and weighted contract probabilities.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    
                    {/* Leads Column */}
                    <div className="bg-slate-950/20 border border-white/5 p-4 rounded-xl space-y-4">
                      <h3 className="font-semibold text-slate-200 border-b border-white/5 pb-1">Incoming Marketing Leads</h3>
                      <div className="space-y-2 max-h-[400px] overflow-y-auto">
                        {state.leads.map((lead) => (
                          <div key={lead.id} className="bg-slate-900/40 p-3 rounded-lg border border-white/5 space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-slate-100">{lead.companyName}</span>
                              <span className="text-[10px] bg-sky-500/10 text-sky-400 px-1.5 py-0.2 rounded font-semibold">{lead.status}</span>
                            </div>
                            <div className="text-[11px] text-slate-400">
                              <span>Contact: {lead.contactName}</span>
                              <span className="block">{lead.email}</span>
                            </div>
                            <div className="text-emerald-400 font-bold">Estimated: £{lead.value.toLocaleString()}</div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Active Opportunities (In Pipeline) */}
                    <div className="bg-slate-950/20 border border-white/5 p-4 rounded-xl space-y-4 md:col-span-2">
                      <h3 className="font-semibold text-slate-200 border-b border-white/5 pb-1">Negotiation / Proposal Stage</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {state.opportunities.slice(0, 10).map((opp) => (
                          <div key={opp.id} className="bg-slate-900/40 p-3.5 rounded-lg border border-white/5 space-y-3">
                            <div>
                              <span className="text-[10px] text-indigo-400 tracking-wider uppercase font-semibold block">{opp.stage} Stage</span>
                              <span className="font-bold text-slate-100 block text-sm mt-0.5">{opp.title}</span>
                            </div>
                            
                            <div className="flex justify-between items-center text-[11px]">
                              <span className="text-slate-400">Probability:</span>
                              <span className="text-sky-400 font-bold">{opp.probability}%</span>
                            </div>

                            <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                              <div className="bg-sky-500 h-full rounded-full" style={{ width: `${opp.probability}%` }}></div>
                            </div>

                            <div className="flex justify-between items-center text-xs pt-1 border-t border-white/5">
                              <span className="text-slate-400">Close Est: {opp.expectedClose}</span>
                              <span className="text-emerald-400 font-bold">£{opp.value.toLocaleString()}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                </div>
              )}

              {/* TAB: QUOTES */}
              {activeTab === 'Quotes' && (
                <div className="space-y-6 text-xs">
                  <div className="flex justify-between items-center border-b border-white/5 pb-4">
                    <div>
                      <h1 className="text-xl font-bold text-white">Professional Quotations</h1>
                      <p className="text-slate-400">Generate, send, and review consulting client proposals.</p>
                    </div>
                    <button 
                      onClick={() => setIsNewQuoteModalOpen(true)}
                      className="bg-sky-600 hover:bg-sky-500 text-white px-3 py-1.5 rounded-md font-semibold flex items-center space-x-1.5 transition"
                    >
                      <Plus className="w-4 h-4" />
                      <span>New Quotation</span>
                    </button>
                  </div>

                  <div className="bg-slate-950/20 border border-white/5 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-950/40 text-[11px] text-slate-400 uppercase tracking-wider border-b border-white/5">
                          <th className="p-3">Quote Number</th>
                          <th className="p-3">Customer Account</th>
                          <th className="p-3">Subtotal</th>
                          <th className="p-3">Tax (VAT)</th>
                          <th className="p-3">Proposed Total</th>
                          <th className="p-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {state.quotes.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="p-8 text-center text-slate-500">
                              No quotations manually created yet. Click &quot;New Quotation&quot; or run the simulation month.
                            </td>
                          </tr>
                        ) : (
                          state.quotes.map((q) => (
                            <tr key={q.id} className="hover:bg-white/5 transition">
                              <td className="p-3 font-semibold text-slate-200">{q.number}</td>
                              <td className="p-3 text-slate-400">{state.customers.find(c => c.id === q.customerId)?.name || 'Acme Ltd'}</td>
                              <td className="p-3">£{q.subtotal.toLocaleString()}</td>
                              <td className="p-3">£{q.taxTotal.toLocaleString()}</td>
                              <td className="p-3 text-emerald-400 font-bold">£{q.total.toLocaleString()}</td>
                              <td className="p-3">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${q.status === 'Accepted' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-sky-500/10 text-sky-400'}`}>
                                  {q.status}
                                </span>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB: INVOICES */}
              {activeTab === 'Invoices' && (
                <div className="space-y-6 text-xs">
                  <div className="flex justify-between items-center border-b border-white/5 pb-4">
                    <div>
                      <h1 className="text-xl font-bold text-white">Client Sales Invoices</h1>
                      <p className="text-slate-400">Post new billing items, verify allocations, and record payments.</p>
                    </div>
                    <button 
                      onClick={() => setIsNewInvoiceModalOpen(true)}
                      className="bg-sky-600 hover:bg-sky-500 text-white px-3 py-1.5 rounded-md font-semibold flex items-center space-x-1.5 transition"
                    >
                      <Plus className="w-4 h-4" />
                      <span>New Invoice</span>
                    </button>
                  </div>

                  <div className="bg-slate-950/20 border border-white/5 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-950/40 text-[11px] text-slate-400 uppercase tracking-wider border-b border-white/5">
                          <th className="p-3">Invoice Code</th>
                          <th className="p-3">Account Customer</th>
                          <th className="p-3">Issue Date</th>
                          <th className="p-3">Invoice Total</th>
                          <th className="p-3">Received</th>
                          <th className="p-3">State</th>
                          <th className="p-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {state.invoices.slice(0, 15).map((inv) => (
                          <tr key={inv.id} className="hover:bg-white/5 transition">
                            <td className="p-3 font-semibold text-slate-200">{inv.number}</td>
                            <td className="p-3 text-slate-400">
                              {state.customers.find(c => c.id === inv.customerId)?.name || 'Acme Corp Ltd'}
                            </td>
                            <td className="p-3 text-slate-400">{inv.date}</td>
                            <td className="p-3 font-bold text-slate-200">£{inv.total.toLocaleString()}</td>
                            <td className="p-3 text-emerald-400 font-bold">£{inv.amountPaid.toLocaleString()}</td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${inv.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-400' : (inv.status === 'Overdue' ? 'bg-red-500/10 text-red-400' : 'bg-yellow-500/10 text-yellow-400')}`}>
                                {inv.status}
                              </span>
                            </td>
                            <td className="p-3 space-x-2">
                              <button 
                                onClick={() => setSelectedInvoice(inv)}
                                className="text-sky-400 hover:text-sky-300 font-semibold"
                              >
                                Detail View
                              </button>
                              {inv.status !== 'Paid' && (
                                <button 
                                  onClick={() => handlePostPayment(inv.id)}
                                  className="text-emerald-400 hover:text-emerald-300 font-bold"
                                >
                                  Mark as Paid
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB: PROJECTS */}
              {activeTab === 'Projects' && (
                <div className="space-y-6 text-xs">
                  <div className="border-b border-white/5 pb-4">
                    <h1 className="text-xl font-bold text-white">Consulting Client Projects</h1>
                    <p className="text-slate-400">Track milestones, operational budget burn rates, and active assignments.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {state.projects.slice(0, 12).map((proj) => {
                      const totalLogged = state.timeEntries
                        .filter(t => t.projectId === proj.id)
                        .reduce((sum, t) => sum + t.duration * t.rate, 0);
                      
                      const margin = proj.budget > 0 ? ((proj.budget - proj.cost) / proj.budget * 100).toFixed(1) : '0';

                      return (
                        <div key={proj.id} className="bg-slate-950/20 border border-white/5 p-4 rounded-xl space-y-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="text-[10px] text-sky-400 font-bold uppercase tracking-wider">{proj.status}</span>
                              <h3 className="font-bold text-slate-100 text-sm mt-0.5">{proj.name}</h3>
                              <p className="text-[11px] text-slate-400">Account: {state.customers.find(c => c.id === proj.customerId)?.name || 'Acme Ltd'}</p>
                            </div>
                            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">Margin: {margin}%</span>
                          </div>

                          <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-white/5">
                            <div>
                              <span className="text-[10px] text-slate-400 block uppercase">Project Budget</span>
                              <span className="font-bold text-slate-200">£{proj.budget.toLocaleString()}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-400 block uppercase">Accrued Labor</span>
                              <span className="font-bold text-slate-200">£{totalLogged.toLocaleString()}</span>
                            </div>
                            <div>
                              <span className="text-[10px] text-slate-400 block uppercase">Direct Cost</span>
                              <span className="font-bold text-slate-200">£{proj.cost.toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB: PRODUCTS */}
              {activeTab === 'Products & Stock' && (
                <div className="space-y-6 text-xs">
                  <div className="border-b border-white/5 pb-4">
                    <h1 className="text-xl font-bold text-white">Service Portfolio & Digital SKU Inventory</h1>
                    <p className="text-slate-400">Configure corporate catalog items, license prices, and reorder levels.</p>
                  </div>

                  <div className="bg-slate-950/20 border border-white/5 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-950/40 text-[11px] text-slate-400 uppercase tracking-wider border-b border-white/5">
                          <th className="p-3">SKU</th>
                          <th className="p-3">Product Name</th>
                          <th className="p-3">Category</th>
                          <th className="p-3">Base Cost</th>
                          <th className="p-3">Base Price</th>
                          <th className="p-3">Type</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {state.products.map((p) => (
                          <tr key={p.id} className="hover:bg-white/5 transition">
                            <td className="p-3 font-mono text-slate-300">{p.sku}</td>
                            <td className="p-3 font-semibold text-slate-200">{p.name}</td>
                            <td className="p-3 text-slate-400">{p.category}</td>
                            <td className="p-3">£{p.cost.toLocaleString()}</td>
                            <td className="p-3 text-emerald-400 font-bold">£{p.price.toLocaleString()}</td>
                            <td className="p-3">
                              <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px] font-semibold">{p.type}</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB: LEDGER */}
              {activeTab === 'Accounts Ledger' && (
                <div className="space-y-6 text-xs">
                  
                  <div className="flex justify-between items-center border-b border-white/5 pb-4">
                    <div>
                      <h1 className="text-xl font-bold text-white">General Ledger Chart of Accounts</h1>
                      <p className="text-slate-400">Visual integrity auditor verifying double-entry mathematical balancing.</p>
                    </div>
                    <div className="flex space-x-2">
                      <div className="bg-slate-950/60 border border-white/5 px-4 py-2 rounded-xl flex flex-col justify-center">
                        <span className="text-[10px] text-slate-400 uppercase font-bold">Total Debits</span>
                        <span className="text-sm font-bold text-slate-100">£{totalDebits.toLocaleString()}</span>
                      </div>
                      <div className="bg-slate-950/60 border border-white/5 px-4 py-2 rounded-xl flex flex-col justify-center">
                        <span className="text-[10px] text-slate-400 uppercase font-bold">Total Credits</span>
                        <span className="text-sm font-bold text-slate-100">£{totalCredits.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Accounts Table */}
                  <div className="bg-slate-950/20 border border-white/5 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-950/40 text-[11px] text-slate-400 uppercase tracking-wider border-b border-white/5">
                          <th className="p-3">Account Code</th>
                          <th className="p-3">Account Name</th>
                          <th className="p-3">Classification</th>
                          <th className="p-3 text-right">Current Ledger Balance</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {state.accounts.map((acc) => (
                          <tr key={acc.id} className="hover:bg-white/5 transition">
                            <td className="p-3 font-mono text-slate-300">{acc.code}</td>
                            <td className="p-3 font-semibold text-slate-200">{acc.name}</td>
                            <td className="p-3">
                              <span className={`px-1.5 py-0.2 rounded text-[10px] uppercase font-bold ${acc.type === 'Asset' ? 'bg-sky-500/10 text-sky-400' : (acc.type === 'Revenue' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-indigo-500/10 text-indigo-400')}`}>
                                {acc.type}
                              </span>
                            </td>
                            <td className="p-3 text-right font-bold text-slate-200">
                              £{acc.balance.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                </div>
              )}

              {/* TAB: BANK MATCHING */}
              {activeTab === 'Bank Matching' && (
                <div className="space-y-6 text-xs">
                  <div className="border-b border-white/5 pb-4">
                    <h1 className="text-xl font-bold text-white">Bank Statement Clearing & Reconciliation</h1>
                    <p className="text-slate-400">Auto-match BACS clearances against sales ledger invoices and business expense receipts.</p>
                  </div>

                  <div className="bg-slate-950/20 border border-white/5 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-950/40 text-[11px] text-slate-400 uppercase tracking-wider border-b border-white/5">
                          <th className="p-3">Statement Date</th>
                          <th className="p-3">Transaction Narrative</th>
                          <th className="p-3">Statement Amount</th>
                          <th className="p-3">Matched Allocation</th>
                          <th className="p-3">Audit Match Type</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {state.bankTransactions.slice(0, 15).map((bt) => (
                          <tr key={bt.id} className="hover:bg-white/5 transition">
                            <td className="p-3 text-slate-400">{bt.date}</td>
                            <td className="p-3 font-semibold text-slate-200">{bt.description}</td>
                            <td className="p-3 font-bold text-slate-200">£{bt.amount.toLocaleString()}</td>
                            <td className="p-3 text-sky-400 font-mono">{bt.matchedId || 'Unmatched'}</td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400">
                                {bt.matchType}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB: EMPLOYEES */}
              {activeTab === 'Employees & Leave' && (
                <div className="space-y-6 text-xs">
                  <div className="border-b border-white/5 pb-4">
                    <h1 className="text-xl font-bold text-white">Corporate Employee Directory</h1>
                    <p className="text-slate-400">Monitor salaries, consulting day rates, and leave balance calculations.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {state.employees.slice(0, 15).map((emp) => (
                      <div key={emp.id} className="bg-slate-950/20 border border-white/5 p-4 rounded-xl space-y-2">
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-slate-200 font-bold uppercase">
                            {emp.firstName[0]}{emp.lastName[0]}
                          </div>
                          <div>
                            <h4 className="font-bold text-slate-100">{emp.firstName} {emp.lastName}</h4>
                            <p className="text-[11px] text-slate-400">{emp.role} • {emp.department}</p>
                          </div>
                        </div>

                        <div className="border-t border-white/5 pt-2 text-[11px] space-y-1 text-slate-400">
                          <div className="flex justify-between">
                            <span>Base Salary (Annual):</span>
                            <span className="font-semibold text-slate-200">£{emp.salary.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Consulting Day Rate:</span>
                            <span className="font-semibold text-sky-400">£{emp.hourlyRate * 8}/day</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: FINDER FILES */}
              {activeTab === 'Finder Files' && (
                <div className="space-y-6 text-xs">
                  
                  <div className="flex justify-between items-center border-b border-white/5 pb-4">
                    <div>
                      <h1 className="text-xl font-bold text-white">Finder Document System</h1>
                      <p className="text-slate-400">Unified central storage organizing PDF invoices, master contracts, and legal charters.</p>
                    </div>
                    
                    {/* Performance Benchmarking CTA */}
                    <button 
                      onClick={runPerformanceBenchmark}
                      className="bg-white/5 hover:bg-white/10 text-white border border-white/10 px-3.5 py-1.5 rounded-md font-semibold flex items-center space-x-2 transition"
                    >
                      <Gauge className="w-4 h-4 text-sky-400" />
                      <span>Benchmark Index Files</span>
                    </button>
                  </div>

                  {/* Benchmark Output Panel */}
                  {benchmarkResult && (
                    <div className="bg-sky-500/10 border border-sky-500/20 p-4 rounded-xl space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-sky-300 flex items-center"><Zap className="w-4 h-4 mr-1.5 animate-bounce" />Performance Index Results</h3>
                        <span className="text-[10px] bg-sky-500/20 px-2 py-0.5 rounded font-bold uppercase text-sky-200">Complete</span>
                      </div>
                      <p className="text-[11px] text-slate-300">Successfully traversed index logs for <strong>{benchmarkResult.customersSearched.toLocaleString()} customers</strong> and <strong>{benchmarkResult.invoicesIndexed.toLocaleString()} invoices</strong>.</p>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center pt-2">
                        <div className="bg-slate-900/40 p-2 rounded">
                          <span className="text-[9px] text-slate-400 block uppercase">Complexity</span>
                          <span className="font-bold text-slate-200">{benchmarkResult.lookupComplexity}</span>
                        </div>
                        <div className="bg-slate-900/40 p-2 rounded">
                          <span className="text-[9px] text-slate-400 block uppercase">Binary Iterations</span>
                          <span className="font-bold text-slate-200">{benchmarkResult.searchIterations} searches</span>
                        </div>
                        <div className="bg-slate-900/40 p-2 rounded">
                          <span className="text-[9px] text-slate-400 block uppercase">Search Execution</span>
                          <span className="font-bold text-emerald-400">{benchmarkResult.timeTakenMs} ms</span>
                        </div>
                        <div className="bg-slate-900/40 p-2 rounded">
                          <span className="text-[9px] text-slate-400 block uppercase">Throughput</span>
                          <span className="font-bold text-sky-400">{benchmarkResult.throughput}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Finder Folder Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { name: 'Finance Ledger PDF', icon: Folder, count: '12 Files' },
                      { name: 'SLA Contracts', icon: Folder, count: '8 Files' },
                      { name: 'Employee Profiles', icon: Folder, count: '25 Files' },
                      { name: 'Marketing Assets', icon: Folder, count: '5 Files' }
                    ].map((folder, idx) => (
                      <div key={idx} className="bg-slate-950/20 border border-white/5 p-4 rounded-xl flex items-center space-x-3.5 hover:bg-slate-800/40 cursor-pointer transition">
                        <folder.icon className="w-10 h-10 text-sky-400" />
                        <div>
                          <h4 className="font-bold text-slate-100 text-sm">{folder.name}</h4>
                          <span className="text-[11px] text-slate-400">{folder.count}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Sample Documents list with QuickLook action */}
                  <div className="space-y-2">
                    <h3 className="font-bold text-slate-200">Linked Entity Files</h3>
                    <div className="bg-slate-950/20 border border-white/5 rounded-xl divide-y divide-white/5">
                      {state.documents.map((doc) => (
                        <div key={doc.id} className="p-3 flex items-center justify-between hover:bg-white/5 transition">
                          <div className="flex items-center space-x-3">
                            <File className="w-5 h-5 text-slate-400" />
                            <div>
                              <span className="font-semibold text-slate-200">{doc.name}</span>
                              <span className="text-[11px] text-slate-400 block mt-0.5">Size: {doc.size} • Category: {doc.category}</span>
                            </div>
                          </div>
                          <button 
                            onClick={() => { setQuickLookFile(doc); setIsQuickLookOpen(true); }}
                            className="bg-white/5 hover:bg-white/10 px-3 py-1 rounded text-slate-300 font-semibold"
                          >
                            QuickLook Spacebar
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

            </div>
          </div>

          {/* 4. persistent Business AI Panel (Siri Sidebar style) */}
          <AnimatePresence>
            {isAiPanelOpen && (
              <motion.div 
                initial={{ x: 350, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 350, opacity: 0 }}
                className="w-80 bg-slate-950 border-l border-white/10 flex flex-col justify-between z-20"
              >
                <div className="p-4 space-y-4 flex-1 flex flex-col overflow-hidden">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <div className="flex items-center space-x-2">
                      <Sparkles className="w-5 h-5 text-sky-400 animate-pulse" />
                      <span className="font-bold text-slate-100 text-sm">iBUSINESS Intelligence</span>
                    </div>
                    <button onClick={() => setIsAiPanelOpen(false)} className="text-slate-400 hover:text-white">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Preset Analyticals suggestions */}
                  <div className="space-y-1.5 text-left shrink-0">
                    <span className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Suggested CFO Queries</span>
                    {[
                      { q: 'How much cash will we have in 90 days?', label: '90-Day Runway Projection' },
                      { q: 'Which customers are most profitable?', label: 'Customer Profitability analysis' },
                      { q: 'What are our biggest operating expenses?', label: 'Top Overhead analysis' }
                    ].map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => { setAiPrompt(item.q); handleQueryAI(item.q); }}
                        className="w-full text-left bg-white/5 hover:bg-sky-500/10 hover:text-sky-300 p-2 rounded text-[11px] text-slate-300 transition"
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>

                  {/* AI Output scroll */}
                  <div className="flex-1 bg-slate-900/60 border border-white/5 rounded-lg p-3 overflow-y-auto text-xs text-slate-300 space-y-2 leading-relaxed whitespace-pre-wrap">
                    {isAiLoading ? (
                      <div className="flex flex-col items-center justify-center h-full space-y-2 text-center text-slate-400">
                        <RefreshCw className="w-6 h-6 animate-spin text-sky-400" />
                        <span>Scanning accounts, ledger journals, and client invoices...</span>
                      </div>
                    ) : aiResponse ? (
                      <div>
                        {aiResponse}
                      </div>
                    ) : (
                      <div className="text-slate-500 text-center flex flex-col items-center justify-center h-full">
                        <Sparkles className="w-8 h-8 mb-2 opacity-30" />
                        <span>Type a query or click a suggested CFO question to run Gemini analysis on state data.</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Input area */}
                <div className="p-3 border-t border-white/10 bg-slate-900/40">
                  <div className="relative">
                    <input 
                      type="text" 
                      placeholder="Ask iBusiness CFO..."
                      value={aiPrompt}
                      onChange={(e) => setAiPrompt(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleQueryAI()}
                      className="w-full bg-slate-950 border border-white/15 rounded-md pl-3 pr-10 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-sky-500"
                    />
                    <button 
                      onClick={() => handleQueryAI()}
                      className="absolute right-2.5 top-2 w-5 h-5 bg-sky-600 hover:bg-sky-500 rounded flex items-center justify-center text-white"
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

        </div>
      </div>

      {/* --- FLOATING COMMAND PALETTE MODAL (⌘K) --- */}
      <AnimatePresence>
        {isCommandPaletteOpen && (
          <div className="fixed inset-0 bg-slate-950/65 flex items-start justify-center pt-24 z-50 p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-xl bg-slate-900 border border-white/15 rounded-xl shadow-2xl overflow-hidden text-xs"
            >
              {/* Search Bar */}
              <div className="p-4 border-b border-white/10 relative flex items-center">
                <Search className="w-5 h-5 text-slate-400 absolute left-4" />
                <input 
                  type="text" 
                  placeholder="Type a command (New Invoice, Search Customers, Run Profit)..."
                  className="w-full bg-transparent pl-8 pr-4 py-1 text-sm text-slate-100 focus:outline-none placeholder-slate-500"
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') setIsCommandPaletteOpen(false);
                  }}
                />
                <button onClick={() => setIsCommandPaletteOpen(false)} className="text-slate-500 hover:text-white">Esc</button>
              </div>

              {/* Action List */}
              <div className="p-2.5 max-h-60 overflow-y-auto space-y-1 text-slate-300">
                <span className="px-2.5 py-1 block text-[10px] text-slate-500 uppercase tracking-widest font-bold">Quick OS Shortcuts</span>
                {[
                  { name: 'New Client Invoice', icon: Plus, action: () => { setIsNewInvoiceModalOpen(true); setIsCommandPaletteOpen(false); } },
                  { name: 'Create New Customer', icon: Users, action: () => { setIsNewCustomerModalOpen(true); setIsCommandPaletteOpen(false); } },
                  { name: 'Verify General Ledger balances', icon: Scale, action: () => { setActiveTab('Accounts Ledger'); setIsCommandPaletteOpen(false); } },
                  { name: 'Open AI Assistant', icon: Sparkles, action: () => { setIsAiPanelOpen(true); setIsCommandPaletteOpen(false); } },
                  { name: 'Run Month-End Simulation close', icon: Play, action: () => { startSimulation(); setIsCommandPaletteOpen(false); } }
                ].map((cmd, idx) => (
                  <button
                    key={idx}
                    onClick={cmd.action}
                    className="w-full flex items-center space-x-3 px-3 py-2 rounded-md hover:bg-sky-500 hover:text-white transition text-left text-slate-200"
                  >
                    <cmd.icon className="w-4 h-4 text-slate-400 group-hover:text-white" />
                    <span>{cmd.name}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- NEW CUSTOMER MODAL --- */}
      <AnimatePresence>
        {isNewCustomerModalOpen && (
          <div className="fixed inset-0 bg-slate-950/65 flex items-center justify-center z-50 p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-slate-900 border border-white/15 rounded-xl p-5 space-y-4 text-xs text-left"
            >
              <h2 className="text-base font-bold text-white">Create New Customer Profile</h2>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                handleAddNewCustomer({
                  name: formData.get('name') as string,
                  email: formData.get('email') as string,
                  phone: formData.get('phone') as string,
                  address: formData.get('address') as string,
                  notes: formData.get('notes') as string
                });
              }} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Customer Name</label>
                  <input required name="name" type="text" placeholder="Acme International Ltd" className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white focus:outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-medium">Billing Email</label>
                    <input required name="email" type="email" placeholder="billing@acme.com" className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white focus:outline-none" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-400 font-medium">Phone</label>
                    <input name="phone" type="text" placeholder="+44 7700 9001" className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white focus:outline-none" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Head Office Address</label>
                  <input name="address" type="text" placeholder="10 Tech Way, London" className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white focus:outline-none" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Internal Notes</label>
                  <textarea name="notes" placeholder="Primary software consultant alignment partner" className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white focus:outline-none h-16" />
                </div>
                <div className="flex justify-end space-x-2 pt-2">
                  <button type="button" onClick={() => setIsNewCustomerModalOpen(false)} className="bg-white/5 hover:bg-white/10 text-slate-300 px-4 py-1.5 rounded">Cancel</button>
                  <button type="submit" className="bg-sky-600 hover:bg-sky-500 text-white px-4 py-1.5 rounded font-bold">Save Record</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- NEW INVOICE MODAL --- */}
      <AnimatePresence>
        {isNewInvoiceModalOpen && (
          <div className="fixed inset-0 bg-slate-950/65 flex items-center justify-center z-50 p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-slate-900 border border-white/15 rounded-xl p-5 space-y-4 text-xs text-left"
            >
              <h2 className="text-base font-bold text-white">Issue Sales Ledger Invoice</h2>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const custId = formData.get('customerId') as string;
                const totalAmount = parseFloat(formData.get('amount') as string);
                handleAddNewInvoice({}, custId, totalAmount);
              }} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Select Account Customer</label>
                  <select required name="customerId" className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white focus:outline-none">
                    {state.customers.slice(0, 10).map(c => (
                      <option key={c.id} value={c.id} className="bg-slate-900 text-white">{c.name}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Invoice Value Inclusive VAT (GBP)</label>
                  <input required name="amount" type="number" step="0.01" placeholder="4500.00" className="w-full bg-slate-950 border border-white/10 rounded p-2 text-white focus:outline-none" />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Note: VAT (20%) will be automatically computed and registered into Liabilities (2400).</span>
                </div>
                <div className="flex justify-end space-x-2 pt-2">
                  <button type="button" onClick={() => setIsNewInvoiceModalOpen(false)} className="bg-white/5 hover:bg-white/10 text-slate-300 px-4 py-1.5 rounded">Cancel</button>
                  <button type="submit" className="bg-sky-600 hover:bg-sky-500 text-white px-4 py-1.5 rounded font-bold">Post Invoice</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- CUSTOMER DRILLDOWN DETAIL DRAWER --- */}
      <AnimatePresence>
        {selectedCustomer && (
          <div className="fixed inset-0 bg-slate-950/65 flex items-center justify-end z-40">
            <motion.div 
              initial={{ x: 500, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 500, opacity: 0 }}
              className="w-full max-w-2xl h-full bg-slate-900 border-l border-white/15 p-6 overflow-y-auto space-y-6 text-xs text-left"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div className="flex items-center space-x-2.5">
                  <Building className="w-5 h-5 text-sky-400" />
                  <h2 className="text-base font-bold text-slate-100">{selectedCustomer.name}</h2>
                </div>
                <button onClick={() => setSelectedCustomer(null)} className="text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Core Information Grid */}
              <div className="grid grid-cols-2 gap-4 bg-slate-950/30 p-4 rounded-xl border border-white/5">
                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[9px]">Billing Address</span>
                  <span className="text-slate-200 mt-1 block">{selectedCustomer.address}</span>
                </div>
                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[9px]">Lifecycle Stage</span>
                  <span className="text-sky-400 font-bold mt-1 block">{selectedCustomer.lifecycle}</span>
                </div>
                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[9px]">Primary Email</span>
                  <span className="text-slate-200 mt-1 block">{selectedCustomer.email}</span>
                </div>
                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[9px]">Account currency</span>
                  <span className="text-slate-200 mt-1 block">{selectedCustomer.currency}</span>
                </div>
              </div>

              {/* Activities Logs and linked invoices timeline */}
              <div className="space-y-3">
                <h3 className="font-bold text-slate-200 uppercase tracking-widest text-[10px]">Client Financial Timeline</h3>
                <div className="bg-slate-950/20 border border-white/5 rounded-xl divide-y divide-white/5">
                  {state.invoices
                    .filter(i => i.customerId === selectedCustomer.id)
                    .map(inv => (
                      <div key={inv.id} className="p-3 flex justify-between items-center hover:bg-white/5 transition">
                        <div>
                          <span className="font-bold text-slate-200">{inv.number}</span>
                          <span className="text-[11px] text-slate-400 block mt-0.5">Due: {inv.dueDate} • Subtotal: £{inv.subtotal.toLocaleString()}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-slate-200 font-bold mr-2">£{inv.total.toLocaleString()}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${inv.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                            {inv.status}
                          </span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Internal notes */}
              <div className="space-y-2">
                <span className="text-slate-400 block uppercase font-bold text-[9px]">CRM Account Strategy notes</span>
                <p className="bg-slate-950/40 p-3 rounded-lg border border-white/5 text-slate-300 leading-relaxed italic">
                  &ldquo;{selectedCustomer.notes}&rdquo;
                </p>
              </div>

              <div className="flex justify-end pt-4 border-t border-white/5">
                <button onClick={() => setSelectedCustomer(null)} className="bg-white/5 hover:bg-white/10 text-slate-200 px-4 py-1.5 rounded">Close Profile</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- INVOICE DRILLDOWN DETAIL DRAWER --- */}
      <AnimatePresence>
        {selectedInvoice && (
          <div className="fixed inset-0 bg-slate-950/65 flex items-center justify-center z-40 p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-xl bg-slate-900 border border-white/15 rounded-xl p-6 space-y-6 text-xs text-left"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-4">
                <div className="flex items-center space-x-2">
                  <FileText className="w-5 h-5 text-sky-400" />
                  <h2 className="text-base font-bold text-white">Invoice Details {selectedInvoice.number}</h2>
                </div>
                <button onClick={() => setSelectedInvoice(null)} className="text-slate-400 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[9px]">Bill To Customer</span>
                  <span className="text-slate-200 mt-1 block font-bold text-sm">
                    {state.customers.find(c => c.id === selectedInvoice.customerId)?.name || 'Acme Ltd'}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block uppercase font-bold text-[9px]">Billing Status</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold inline-block mt-1 ${selectedInvoice.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
                    {selectedInvoice.status}
                  </span>
                </div>
              </div>

              {/* Invoice Lines Table */}
              <div className="bg-slate-950/30 border border-white/5 rounded-lg overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-950/40 text-[10px] text-slate-400 uppercase tracking-wider border-b border-white/5">
                      <th className="p-2.5">Description</th>
                      <th className="p-2.5 text-center">Qty</th>
                      <th className="p-2.5 text-right">Unit Price</th>
                      <th className="p-2.5 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {selectedInvoice.lines.map((line) => (
                      <tr key={line.id}>
                        <td className="p-2.5 text-slate-200">{line.description}</td>
                        <td className="p-2.5 text-center text-slate-300">{line.quantity}</td>
                        <td className="p-2.5 text-right text-slate-300">£{line.unitPrice.toLocaleString()}</td>
                        <td className="p-2.5 text-right font-bold text-slate-200">£{line.amount.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Exact Formula computation verified (Subtotal + VAT = Total) */}
              <div className="border-t border-white/10 pt-4 flex flex-col items-end space-y-1.5 text-right">
                <div className="flex justify-between w-48 text-slate-400">
                  <span>Net Subtotal:</span>
                  <span className="text-slate-200">£{selectedInvoice.subtotal.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between w-48 text-slate-400">
                  <span>VAT Tax (20%):</span>
                  <span className="text-slate-200">£{selectedInvoice.taxTotal.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between w-48 font-bold border-t border-white/5 pt-1.5 text-sm">
                  <span className="text-white">Amount Total:</span>
                  <span className="text-emerald-400">£{selectedInvoice.total.toLocaleString('en-GB', { minimumFractionDigits: 2 })}</span>
                </div>
              </div>

              <div className="flex justify-end pt-2 border-t border-white/5">
                <button onClick={() => setSelectedInvoice(null)} className="bg-white/5 hover:bg-white/10 text-slate-200 px-4 py-1.5 rounded">Dismiss Invoice</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- QUICK LOOK PANEL (SPACEBAR PREVIEW SIMULATION) --- */}
      <AnimatePresence>
        {isQuickLookOpen && quickLookFile && (
          <div className="fixed inset-0 bg-slate-950/70 flex items-center justify-center z-50 p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg bg-slate-900 border border-white/15 rounded-xl p-5 space-y-4 text-xs text-left"
            >
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <span className="font-bold text-slate-200 uppercase tracking-widest text-[9px]">macOS QuickLook Integrated Preview</span>
                <button onClick={() => setIsQuickLookOpen(false)} className="text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="bg-white text-slate-900 p-6 rounded-lg font-mono space-y-4 text-[11px] leading-relaxed shadow-inner">
                <div className="border-b border-slate-300 pb-2 flex justify-between items-start">
                  <div>
                    <h2 className="font-bold text-sm tracking-tight text-slate-900 uppercase">{quickLookFile.name}</h2>
                    <p className="text-[10px] text-slate-500">Document Type: {quickLookFile.type} • size: {quickLookFile.size}</p>
                  </div>
                  <span className="bg-slate-200 text-slate-800 px-2 py-0.5 rounded text-[9px] font-bold">PDF INLINE</span>
                </div>
                
                <p className="text-slate-800">
                  This document constitutes a certified record of Northstar Digital Ltd business. The metrics verified correspond perfectly to general accounting requirements.
                </p>

                <div className="border border-slate-300 p-3 bg-slate-50 rounded space-y-1">
                  <p className="font-bold">Accounting Invariant Certification:</p>
                  <p>✓ Debit Balances: £{totalDebits.toLocaleString()}</p>
                  <p>✓ Credit Balances: £{totalCredits.toLocaleString()}</p>
                  <p>✓ Ledger Status: Verified mathematically balanced.</p>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button onClick={() => setIsQuickLookOpen(false)} className="bg-white/5 hover:bg-white/10 text-slate-300 px-4 py-1.5 rounded">Close Preview</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
