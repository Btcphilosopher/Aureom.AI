import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'iBUSINESS — The Complete SME Operating System',
  description: 'The Complete Mac-native SME Operating System. Everything you need to run a business in one canonical, connected platform.',
  openGraph: {
    title: 'iBUSINESS — The Complete SME Operating System',
    description: 'The Complete Mac-native SME Operating System. Everything you need to run a business in one canonical, connected platform.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'iBUSINESS — The Complete SME Operating System',
    description: 'The Complete Mac-native SME Operating System. Everything you need to run a business.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="h-full">
      <body suppressHydrationWarning className="h-full bg-slate-900 text-slate-100 overflow-hidden select-none antialiased font-sans">
        {children}
      </body>
    </html>
  );
}
