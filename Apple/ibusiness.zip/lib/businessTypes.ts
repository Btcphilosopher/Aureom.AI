// iBUSINESS Canonical Business Model Types

export type CurrencyCode = 'GBP' | 'USD' | 'EUR';

export interface Currency {
  code: CurrencyCode;
  symbol: string;
  name: string;
  exchangeRateToBase: number; // GBP is base
}

export type Role = 'Owner' | 'Administrator' | 'Finance' | 'Sales' | 'Operations' | 'HR' | 'ProjectManager' | 'Employee' | 'ReadOnly' | 'Accountant';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  permissions: string[];
  companyId: string;
}

export interface Company {
  id: string;
  name: string;
  country: string;
  baseCurrency: CurrencyCode;
  financialYearStart: string; // "MM-DD"
  businessType: string;
}

// CRM
export type LeadStatus = 'New' | 'Contacted' | 'Qualified' | 'Lost';
export type CustomerLifecycle = 'Lead' | 'Qualified' | 'Opportunity' | 'Customer' | 'RepeatCustomer' | 'Inactive';

export interface Lead {
  id: string;
  companyName: string;
  contactName: string;
  email: string;
  phone: string;
  status: LeadStatus;
  source: string;
  value: number;
  createdAt: string;
}

export interface Contact {
  id: string;
  customerId?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  role: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  lifecycle: CustomerLifecycle;
  currency: CurrencyCode;
  createdAt: string;
  notes: string;
}

export type OpportunityStage = 'Lead' | 'Qualified' | 'Discovery' | 'Proposal' | 'Negotiation' | 'Won' | 'Lost';

export interface Opportunity {
  id: string;
  customerId: string;
  title: string;
  value: number;
  stage: OpportunityStage;
  probability: number; // percentage
  expectedClose: string; // YYYY-MM-DD
  ownerId: string;
  createdAt: string;
}

// Sales
export type QuoteStatus = 'Draft' | 'Sent' | 'Approved' | 'Accepted' | 'Declined' | 'Expired';

export interface QuoteLine {
  id: string;
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  taxRate: number; // percentage (e.g. 20 for VAT)
  amount: number; // calculated: (qty * price - discount) * (1 + tax) ? Or exclusive of tax
}

export interface Quote {
  id: string;
  number: string;
  customerId: string;
  opportunityId?: string;
  date: string;
  expiryDate: string;
  status: QuoteStatus;
  lines: QuoteLine[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  total: number;
  currency: CurrencyCode;
}

export type OrderStatus = 'Draft' | 'Pending' | 'Approved' | 'Fulfilled' | 'Cancelled';

export interface SalesOrderLine {
  id: string;
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  taxRate: number;
  amount: number;
}

export interface SalesOrder {
  id: string;
  number: string;
  customerId: string;
  quoteId?: string;
  date: string;
  status: OrderStatus;
  lines: SalesOrderLine[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  total: number;
  currency: CurrencyCode;
}

export type InvoiceStatus = 'Draft' | 'Sent' | 'Viewed' | 'PartiallyPaid' | 'Paid' | 'Overdue' | 'Cancelled' | 'CreditNote';

export interface InvoiceLine {
  id: string;
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  taxRate: number;
  amount: number;
}

export interface Invoice {
  id: string;
  number: string;
  customerId: string;
  orderId?: string;
  date: string;
  dueDate: string;
  status: InvoiceStatus;
  lines: InvoiceLine[];
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  total: number;
  currency: CurrencyCode;
  amountPaid: number;
}

export interface PaymentAllocation {
  id: string;
  paymentId: string;
  invoiceId: string;
  amount: number;
}

export interface Payment {
  id: string;
  number: string;
  customerId: string;
  date: string;
  amount: number;
  currency: CurrencyCode;
  method: string;
  bankAccountId: string;
  reference: string;
  allocations: PaymentAllocation[];
}

// Products
export type ProductType = 'PhysicalProduct' | 'DigitalProduct' | 'Subscription' | 'Service' | 'Consultancy';

export interface Product {
  id: string;
  sku: string;
  name: string;
  description: string;
  category: string;
  type: ProductType;
  cost: number;
  price: number;
  taxCode: string;
  supplierId?: string;
  inventory: number;
  reorderPoint: number;
}

export interface PriceList {
  id: string;
  name: string; // Retail, Wholesale, etc.
  productPrices: { [productId: string]: number };
  effectiveFrom: string;
  effectiveTo?: string;
}

// Operations
export type ProjectStatus = 'Opportunity' | 'Planned' | 'InProgress' | 'Blocked' | 'Review' | 'Complete';

export interface Project {
  id: string;
  name: string;
  customerId: string;
  status: ProjectStatus;
  startDate: string;
  endDate?: string;
  budget: number;
  cost: number;
  ownerId: string;
}

export type TaskStatus = 'Inbox' | 'Planned' | 'InProgress' | 'Blocked' | 'Review' | 'Complete';

export interface ProjectTask {
  id: string;
  projectId?: string;
  customerId?: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: 'Low' | 'Medium' | 'High';
  dueDate: string;
  ownerId?: string;
  dependencies: string[]; // ids of other tasks
}

export interface TimeEntry {
  id: string;
  employeeId: string;
  projectId: string;
  taskId: string;
  date: string;
  duration: number; // hours
  billable: boolean;
  rate: number;
  notes: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactName: string;
  email: string;
  phone: string;
  currency: CurrencyCode;
}

export type PurchaseOrderStatus = 'Draft' | 'Sent' | 'Approved' | 'Received' | 'Billed' | 'Paid' | 'Cancelled';

export interface PurchaseOrderLine {
  id: string;
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  amount: number;
}

export interface PurchaseOrder {
  id: string;
  number: string;
  supplierId: string;
  date: string;
  status: PurchaseOrderStatus;
  lines: PurchaseOrderLine[];
  subtotal: number;
  taxTotal: number;
  total: number;
  currency: CurrencyCode;
}

export interface GoodsReceipt {
  id: string;
  purchaseOrderId: string;
  date: string;
  receivedBy: string;
  notes: string;
}

export type ExpenseStatus = 'Submitted' | 'Approved' | 'Posted' | 'Reimbursed' | 'Rejected';

export interface Expense {
  id: string;
  employeeId: string;
  date: string;
  category: string;
  amount: number;
  tax: number;
  projectId?: string;
  customerId?: string;
  notes: string;
  status: ExpenseStatus;
  receiptUrl?: string;
}

// People
export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  role: string;
  department: string;
  managerId?: string;
  email: string;
  phone: string;
  startDate: string;
  salary: number; // annual base salary
  hourlyRate: number;
}

export type LeaveStatus = 'Submitted' | 'Approved' | 'Rejected' | 'Cancelled';

export interface LeaveRequest {
  id: string;
  employeeId: string;
  type: 'AnnualLeave' | 'SickLeave' | 'UnpaidLeave';
  startDate: string;
  endDate: string;
  totalDays: number;
  notes: string;
  status: LeaveStatus;
}

export interface PayrollRun {
  id: string;
  period: string; // YYYY-MM
  date: string;
  status: 'Draft' | 'Posted' | 'Paid';
  totalGross: number;
  totalDeductions: number;
  totalTax: number;
  totalNet: number;
}

// Documents
export interface Document {
  id: string;
  name: string;
  type: 'PDF' | 'DOCX' | 'XLSX' | 'CSV' | 'Image' | 'Text';
  size: string;
  category: 'CRM' | 'Finance' | 'HR' | 'Contracts' | 'Projects' | 'Marketing' | 'Archive';
  linkedEntity?: { type: string; id: string };
  uploadedAt: string;
  url?: string;
}

export interface Contract {
  id: string;
  title: string;
  partyName: string;
  startDate: string;
  endDate: string;
  renewalDate?: string;
  value: number;
  status: 'Draft' | 'Active' | 'Expiring' | 'Expired' | 'Terminated';
  documentId?: string;
}

// Growth & Support
export interface Campaign {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  budget: number;
  sent: number;
  opened: number;
  clicked: number;
  converted: number;
  revenue: number;
}

export type TicketStatus = 'New' | 'Open' | 'Waiting' | 'Escalated' | 'Resolved' | 'Closed';

export interface Ticket {
  id: string;
  customerId: string;
  subject: string;
  priority: 'Low' | 'Medium' | 'High';
  status: TicketStatus;
  agentId?: string;
  createdAt: string;
  resolvedAt?: string;
}

// Finance & Banking
export interface BankAccount {
  id: string;
  name: string;
  accountNumber: string;
  routingNumber: string;
  type: 'Checking' | 'Savings' | 'CreditCard';
  balance: number;
  currency: CurrencyCode;
}

export interface BankTransaction {
  id: string;
  bankAccountId: string;
  date: string;
  description: string;
  amount: number; // positive = credit (deposit), negative = debit (payment)
  matchedId?: string; // id of matched invoice/expense/payment/journal
  matchType?: 'Automatic' | 'Suggested' | 'Manual' | 'Split' | 'Unmatched';
}

// Double Entry Accounting
export interface Account {
  id: string;
  code: string; // 1000, 2000, etc.
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  balance: number;
}

export interface JournalLine {
  id: string;
  accountId: string;
  debit: number;
  credit: number;
}

export interface JournalEntry {
  id: string;
  date: string;
  description: string;
  reference: string;
  posted: boolean;
  lines: JournalLine[];
}

export interface Budget {
  id: string;
  year: number;
  name: string;
  lines: { [accountCode: string]: number }; // budgeted amount for account code
}

export interface Forecast {
  id: string;
  period: string; // "30-day", "90-day", etc.
  dataPoints: { date: string; inflow: number; outflow: number; balance: number }[];
}

// Audit Log
export interface AuditEvent {
  id: string;
  timestamp: string;
  userId: string;
  userEmail: string;
  action: string;
  entity: string;
  entityId: string;
  oldValue?: string;
  newValue?: string;
  reason?: string;
}

// Automation Rule
export interface AutomationRule {
  id: string;
  trigger: string; // "invoice_overdue" | "quote_accepted" | "inventory_low"
  condition?: string;
  action: string;
}

// Application State
export interface iBusinessState {
  company: Company;
  users: User[];
  currentUser: User;
  leads: Lead[];
  contacts: Contact[];
  customers: Customer[];
  opportunities: Opportunity[];
  quotes: Quote[];
  orders: SalesOrder[];
  invoices: Invoice[];
  payments: Payment[];
  products: Product[];
  priceLists: PriceList[];
  projects: Project[];
  tasks: ProjectTask[];
  timeEntries: TimeEntry[];
  suppliers: Supplier[];
  purchaseOrders: PurchaseOrder[];
  goodsReceipts: GoodsReceipt[];
  expenses: Expense[];
  employees: Employee[];
  leaveRequests: LeaveRequest[];
  payrollRuns: PayrollRun[];
  documents: Document[];
  contracts: Contract[];
  campaigns: Campaign[];
  tickets: Ticket[];
  bankAccounts: BankAccount[];
  bankTransactions: BankTransaction[];
  accounts: Account[];
  journalEntries: JournalEntry[];
  budgets: Budget[];
  auditLog: AuditEvent[];
  automations: AutomationRule[];
  notifications: string[]; // brief notifications
}
