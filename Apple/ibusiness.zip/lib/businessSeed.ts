import {
  iBusinessState,
  Company,
  User,
  Employee,
  Customer,
  Supplier,
  Product,
  Project,
  ProjectTask,
  Invoice,
  InvoiceLine,
  InvoiceStatus,
  Payment,
  PaymentAllocation,
  BankAccount,
  BankTransaction,
  Account,
  JournalEntry,
  JournalLine,
  TimeEntry,
  Opportunity,
  Lead,
  Contact,
  Quote,
  QuoteLine,
  Expense,
  LeaveRequest,
  PayrollRun,
  Document,
  Contract,
  Campaign,
  Ticket,
  AutomationRule,
  AuditEvent
} from './businessTypes';

// Chart of Accounts Constants
export const DEFAULT_ACCOUNTS: Account[] = [
  // Assets
  { id: 'acc_1010', code: '1010', name: 'Operating Bank Account (GBP)', type: 'Asset', balance: 450000 },
  { id: 'acc_1020', code: '1020', name: 'US Dollar Account (USD)', type: 'Asset', balance: 185000 },
  { id: 'acc_1030', code: '1030', name: 'Euro Clearing Account (EUR)', type: 'Asset', balance: 95000 },
  { id: 'acc_1040', code: '1040', name: 'Savings & Reserve Account', type: 'Asset', balance: 250000 },
  { id: 'acc_1200', code: '1200', name: 'Accounts Receivable', type: 'Asset', balance: 120000 },
  { id: 'acc_1400', code: '1400', name: 'Inventory Asset', type: 'Asset', balance: 35000 },
  
  // Liabilities
  { id: 'acc_2200', code: '2200', name: 'Accounts Payable', type: 'Liability', balance: 45000 },
  { id: 'acc_2400', code: '2400', name: 'VAT / Tax Liability', type: 'Liability', balance: 38000 },
  { id: 'acc_2500', code: '2500', name: 'Payroll Deductions Payable', type: 'Liability', balance: 12000 },
  
  // Equity
  { id: 'acc_3000', code: '3000', name: 'Retained Earnings', type: 'Equity', balance: 835000 },
  { id: 'acc_3100', code: '3100', name: 'Share Capital', type: 'Equity', balance: 100000 },
  
  // Revenue
  { id: 'acc_4010', code: '4010', name: 'Consulting Services Revenue', type: 'Revenue', balance: 0 },
  { id: 'acc_4020', code: '4020', name: 'Software Licensing Revenue', type: 'Revenue', balance: 0 },
  
  // Cost of Sales
  { id: 'acc_5010', code: '5010', name: 'Subcontractor Cost', type: 'Expense', balance: 0 },
  
  // Operating Expenses
  { id: 'acc_6010', code: '6010', name: 'Employee Salaries Expense', type: 'Expense', balance: 0 },
  { id: 'acc_6020', code: '6020', name: 'Travel & Subsistence', type: 'Expense', balance: 0 },
  { id: 'acc_6030', code: '6030', name: 'Software & SaaS Tools', type: 'Expense', balance: 0 },
  { id: 'acc_6040', code: '6040', name: 'Rent & Office Overhead', type: 'Expense', balance: 0 },
  { id: 'acc_6050', code: '6050', name: 'Marketing Campaign Expense', type: 'Expense', balance: 0 }
];

export const SYNTHETIC_EMPLOYEES: Employee[] = [
  { id: 'emp_01', firstName: 'Sarah', lastName: 'Jenkins', role: 'Managing Director', department: 'Executive', email: 'sarah.jenkins@northstar.com', phone: '+44 20 7946 0192', startDate: '2022-01-10', salary: 145000, hourlyRate: 150 },
  { id: 'emp_02', firstName: 'David', lastName: 'Chen', role: 'Principal Tech Architect', department: 'Consulting', email: 'david.chen@northstar.com', phone: '+44 20 7946 0141', startDate: '2022-03-15', salary: 120000, hourlyRate: 120 },
  { id: 'emp_03', firstName: 'Emma', lastName: 'Taylor', role: 'Finance Director / Accountant', department: 'Finance', email: 'emma.taylor@northstar.com', phone: '+44 20 7946 0524', startDate: '2022-02-01', salary: 95000, hourlyRate: 90 },
  { id: 'emp_04', firstName: 'Marcus', lastName: 'Alvarez', role: 'Sales & Marketing Manager', department: 'Sales', email: 'marcus.alvarez@northstar.com', phone: '+44 20 7946 0331', startDate: '2023-01-15', salary: 85000, hourlyRate: 85 },
  { id: 'emp_05', firstName: 'Elena', lastName: 'Rostova', role: 'Senior Consultant', department: 'Consulting', email: 'elena.rostova@northstar.com', phone: '+44 20 7946 0451', startDate: '2023-04-01', salary: 90000, hourlyRate: 100 },
  { id: 'emp_06', firstName: 'James', lastName: 'Morgan', role: 'Senior Software Engineer', department: 'Consulting', email: 'james.morgan@northstar.com', phone: '+44 20 7946 0112', startDate: '2023-06-20', salary: 85000, hourlyRate: 90 },
  { id: 'emp_07', firstName: 'Aiko', lastName: 'Tanaka', role: 'UX/UI Design Lead', department: 'Consulting', email: 'aiko.tanaka@northstar.com', phone: '+44 20 7946 0229', startDate: '2023-02-10', salary: 82000, hourlyRate: 85 },
  { id: 'emp_08', firstName: 'Liam', lastName: 'O\'Connor', role: 'Agile Project Manager', department: 'Operations', email: 'liam.oconnor@northstar.com', phone: '+44 20 7946 0881', startDate: '2023-08-01', salary: 78000, hourlyRate: 80 },
  { id: 'emp_09', firstName: 'Chloe', lastName: 'Patel', role: 'Cloud DevOps Architect', department: 'Consulting', email: 'chloe.patel@northstar.com', phone: '+44 20 7946 0772', startDate: '2023-09-10', salary: 98000, hourlyRate: 110 },
  { id: 'emp_10', firstName: 'William', lastName: 'Schmidt', role: 'HR Manager', department: 'HR', email: 'will.schmidt@northstar.com', phone: '+44 20 7946 0612', startDate: '2023-11-01', salary: 68000, hourlyRate: 70 },
  { id: 'emp_11', firstName: 'Nadia', lastName: 'Bello', role: 'Business Analyst', department: 'Consulting', email: 'nadia.bello@northstar.com', phone: '+44 20 7946 0244', startDate: '2024-01-08', salary: 62000, hourlyRate: 65 },
  { id: 'emp_12', firstName: 'Alex', lastName: 'Kovac', role: 'Support Specialist', department: 'Operations', email: 'alex.kovac@northstar.com', phone: '+44 20 7946 0915', startDate: '2024-02-15', salary: 45000, hourlyRate: 45 },
  { id: 'emp_13', firstName: 'Sofia', lastName: 'Martinez', role: 'Senior Account Executive', department: 'Sales', email: 'sofia.martinez@northstar.com', phone: '+44 20 7946 0303', startDate: '2024-03-01', salary: 65000, hourlyRate: 65 },
  { id: 'emp_14', firstName: 'Tom', lastName: 'Hardy', role: 'Backend Developer', department: 'Consulting', email: 'tom.hardy@northstar.com', phone: '+44 20 7946 0155', startDate: '2024-04-10', salary: 55000, hourlyRate: 55 },
  { id: 'emp_15', firstName: 'Yuki', lastName: 'Sato', role: 'Frontend Engineer', department: 'Consulting', email: 'yuki.sato@northstar.com', phone: '+44 20 7946 0199', startDate: '2024-05-01', salary: 54000, hourlyRate: 55 },
  { id: 'emp_16', firstName: 'Robert', lastName: 'Baratheon', role: 'Security Consultant', department: 'Consulting', email: 'rob.b@northstar.com', phone: '+44 20 7946 0488', startDate: '2024-05-15', salary: 92000, hourlyRate: 100 },
  { id: 'emp_17', firstName: 'Danielle', lastName: 'Vance', role: 'Marketing Assistant', department: 'Sales', email: 'danielle.v@northstar.com', phone: '+44 20 7946 0399', startDate: '2024-06-01', salary: 42000, hourlyRate: 40 },
  { id: 'emp_18', firstName: 'Arthur', lastName: 'Pendragon', role: 'Delivery Lead', department: 'Operations', email: 'arthur.p@northstar.com', phone: '+44 20 7946 0811', startDate: '2024-06-15', salary: 85000, hourlyRate: 90 },
  { id: 'emp_19', firstName: 'Gwen', lastName: 'Stacy', role: 'Product Designer', department: 'Consulting', email: 'gwen.s@northstar.com', phone: '+44 20 7946 0221', startDate: '2024-07-01', salary: 58000, hourlyRate: 60 },
  { id: 'emp_20', firstName: 'Luke', lastName: 'Skywalker', role: 'Systems Engineer', department: 'Consulting', email: 'luke.s@northstar.com', phone: '+44 20 7946 0101', startDate: '2024-07-20', salary: 65000, hourlyRate: 70 },
  { id: 'emp_21', firstName: 'Leia', lastName: 'Organa', role: 'Compliance Officer', department: 'Executive', email: 'leia.o@northstar.com', phone: '+44 20 7946 0102', startDate: '2024-08-01', salary: 82000, hourlyRate: 85 },
  { id: 'emp_22', firstName: 'Bruce', lastName: 'Wayne', role: 'IT Support Engineer', department: 'Operations', email: 'bruce.w@northstar.com', phone: '+44 20 7946 0900', startDate: '2024-08-15', salary: 48000, hourlyRate: 50 },
  { id: 'emp_23', firstName: 'Clark', lastName: 'Kent', role: 'Technical Writer', department: 'Consulting', email: 'clark.k@northstar.com', phone: '+44 20 7946 0777', startDate: '2024-09-01', salary: 50000, hourlyRate: 50 },
  { id: 'emp_24', firstName: 'Diana', lastName: 'Prince', role: 'Solutions Architect', department: 'Consulting', email: 'diana.p@northstar.com', phone: '+44 20 7946 0444', startDate: '2024-09-10', salary: 110000, hourlyRate: 120 },
  { id: 'emp_25', firstName: 'Peter', lastName: 'Parker', role: 'Junior Consultant', department: 'Consulting', email: 'peter.p@northstar.com', phone: '+44 20 7946 0555', startDate: '2024-10-01', salary: 40000, hourlyRate: 40 }
];

export const SYNTHETIC_PRODUCTS: Product[] = [
  { id: 'prod_cloud_arch', sku: 'CONS-CLOUD-01', name: 'Cloud Architecture Workshop', description: 'Comprehensive design and strategy workshop for AWS/GCP cloud environments', category: 'Consulting', type: 'Consultancy', cost: 1500, price: 3500, taxCode: 'VAT-STANDARD', inventory: 0, reorderPoint: 0 },
  { id: 'prod_sc_dev', sku: 'DEV-ENGINE-02', name: 'Software Engineering Services', description: 'Expert development work in React, TypeScript, Go, or Python', category: 'Consulting', type: 'Consultancy', cost: 80, price: 160, taxCode: 'VAT-STANDARD', inventory: 0, reorderPoint: 0 },
  { id: 'prod_sec_audit', sku: 'CONS-SEC-03', name: 'Security & Penetration Audit', description: 'End-to-end security compliance audit, penetration testing, and risk register', category: 'Consulting', type: 'Consultancy', cost: 4000, price: 9500, taxCode: 'VAT-STANDARD', inventory: 0, reorderPoint: 0 },
  { id: 'prod_license_nscore', sku: 'LIC-NSCORE-04', name: 'Northstar Core Platform License', description: 'Enterprise SaaS license for the Northstar real-time monitoring dashboard', category: 'Software', type: 'Subscription', cost: 0, price: 1200, taxCode: 'VAT-STANDARD', inventory: 0, reorderPoint: 0 },
  { id: 'prod_support_premium', sku: 'SUP-PREM-05', name: '24/7 Premium Support SLA', description: 'Ad-hoc support desk with 1-hour response SLA', category: 'Support', type: 'Subscription', cost: 200, price: 600, taxCode: 'VAT-STANDARD', inventory: 0, reorderPoint: 0 }
];

// Helper to generate a company state
export function createNorthstarCompany(): Company {
  return {
    id: 'comp_northstar',
    name: 'Northstar Digital Ltd',
    country: 'United Kingdom',
    baseCurrency: 'GBP',
    financialYearStart: '04-01', // April 1st
    businessType: 'Professional Technology Consultancy'
  };
}

export function createDefaultUsers(): User[] {
  return [
    { id: 'usr_sarah', name: 'Sarah Jenkins', email: 'sarah.jenkins@northstar.com', role: 'Owner', permissions: ['*'], companyId: 'comp_northstar' },
    { id: 'usr_emma', name: 'Emma Taylor', email: 'emma.taylor@northstar.com', role: 'Accountant', permissions: ['finance_read', 'finance_write', 'accounting_post'], companyId: 'comp_northstar' },
    { id: 'usr_marcus', name: 'Marcus Alvarez', email: 'marcus.alvarez@northstar.com', role: 'Sales', permissions: ['crm_read', 'crm_write', 'sales_write'], companyId: 'comp_northstar' }
  ];
}

// Generate the high-volume dynamic data securely
export function generateSyntheticSMEData(): iBusinessState {
  const company = createNorthstarCompany();
  const users = createDefaultUsers();
  
  // 1. Generate 100 suppliers
  const suppliers: Supplier[] = [];
  const supplierNames = ['AWS Web Services', 'Google Cloud Corp', 'Slack Technologies', 'GitHub Inc', 'Vercel Inc', 'Postmark Email', 'Zoom Communications', 'JetBrains s.r.o.', 'Apple Developer Services', 'Canva Design', 'Figma Inc', 'HubSpot Europe', 'Hiscox Insurance', 'WeWork Spaces', 'Mailchimp Inc', 'Stripe Payments', 'Heroku Labs', 'Salesforce UK', 'Atlassian Jira', 'Dribbble Pro'];
  for (let i = 1; i <= 100; i++) {
    const brand = supplierNames[i % supplierNames.length] + ` (Supplier ${i})`;
    const isEuro = i % 10 === 0;
    const isUSD = i % 5 === 0;
    suppliers.push({
      id: `supp_${i}`,
      name: brand,
      contactName: `Supplier Contact ${i}`,
      email: `billing@${brand.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
      phone: `+44 20 7946 ${String(100 + i).padStart(4, '0')}`,
      currency: isEuro ? 'EUR' : isUSD ? 'USD' : 'GBP'
    });
  }

  // 2. Generate 150 Customers
  const customers: Customer[] = [];
  const baseCustomerNames = ['Acme Corp', 'Globex Industries', 'Initech LLC', 'Umbrella Corp', 'Hooli Inc', 'Vehement Capital', 'Stark Enterprises', 'Wayne Enterprises', 'Soylent Green Co', 'Tyrell Nexus', 'Massive Dynamic', 'Cyberdyne Systems', 'Aperture Science', 'Oscorp Tech', 'Wonka Chocolate', 'Gekko & Co', 'Sledgehammer Games', 'Sterling Cooper', 'Dunder Mifflin', 'Pied Piper'];
  for (let i = 1; i <= 150; i++) {
    const brandName = baseCustomerNames[i % baseCustomerNames.length] + ` Ltd #${i}`;
    const randDays = Math.floor(Math.random() * 300);
    const date = new Date(Date.now() - randDays * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const lifecycles: ('Customer' | 'RepeatCustomer' | 'Inactive')[] = ['Customer', 'RepeatCustomer', 'Inactive'];
    customers.push({
      id: `cust_${i}`,
      name: brandName,
      email: `contact@${brandName.toLowerCase().replace(/[^a-z0-9]/g, '')}.co.uk`,
      phone: `+44 7700 ${String(90000 + i).substring(0, 6)}`,
      address: `${10 + i} Innovation Way, London, EC2A 4NE, UK`,
      lifecycle: i <= 15 ? 'RepeatCustomer' : lifecycles[i % lifecycles.length],
      currency: i % 8 === 0 ? 'USD' : i % 12 === 0 ? 'EUR' : 'GBP',
      createdAt: date,
      notes: `Enterprise client generated synthetically on ${date}. Professional software development and architecture client.`
    });
  }

  // 3. Generate 60 Active Projects
  const projects: Project[] = [];
  const projectNames = ['Cloud Migration Blueprint', 'Core Product UI Redesign', 'SOC2 Compliance Audit Support', 'E-Commerce Platform Deployment', 'Kubernetes Orchestration Sync', 'Data Warehouse ETL Pipelines', 'Corporate Website Localization', 'Mobile Application MVP', 'Zero Trust Network Overhaul', 'Machine Learning Recommendation Engine'];
  for (let i = 1; i <= 60; i++) {
    const custId = `cust_${(i % 150) + 1}`;
    const pName = projectNames[i % projectNames.length] + ` (Phase ${Math.floor(i/10) + 1})`;
    const randomValue = 15000 + (i * 2500) % 85000;
    const statuses: ('InProgress' | 'Complete' | 'Planned' | 'Blocked')[] = ['InProgress', 'Complete', 'Planned', 'Blocked'];
    const stat = i <= 40 ? 'InProgress' : statuses[i % statuses.length];
    projects.push({
      id: `proj_${i}`,
      name: pName,
      customerId: custId,
      status: stat,
      startDate: new Date(Date.now() - (30 + i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      endDate: stat === 'Complete' ? new Date(Date.now() + (5 + i) * 24 * 60 * 60 * 1000).toISOString().split('T')[0] : undefined,
      budget: randomValue,
      cost: randomValue * 0.65,
      ownerId: `emp_${(i % 25) + 1}`
    });
  }

  // 4. Generate 500 Invoices & 500 Payments matching exact double entry balances
  const invoices: Invoice[] = [];
  const payments: Payment[] = [];
  const bankTransactions: BankTransaction[] = [];
  const journalEntries: JournalEntry[] = [];
  
  let invoiceCounter = 1;
  let paymentCounter = 1;
  let journalCounter = 1;

  // Let's seed initial bank account state
  const bankAccounts: BankAccount[] = [
    { id: 'bank_operating', name: 'Operating checking (GBP)', accountNumber: 'GB-NORTH-1010-9876', routingNumber: '09-01-29', type: 'Checking', balance: 524100, currency: 'GBP' },
    { id: 'bank_reserve', name: 'High-yield Reserve (GBP)', accountNumber: 'GB-NORTH-1040-5432', routingNumber: '09-01-29', type: 'Savings', balance: 250000, currency: 'GBP' },
    { id: 'bank_usd', name: 'Silicon Valley Clearing (USD)', accountNumber: 'US-NORTH-1020-0012', routingNumber: '121000248', type: 'Checking', balance: 185000, currency: 'USD' },
    { id: 'bank_euro', name: 'Deutsche Bank Clearing (EUR)', accountNumber: 'DE-NORTH-1030-9911', routingNumber: 'DEUTDEBBXXX', type: 'Checking', balance: 95000, currency: 'EUR' },
    { id: 'bank_card', name: 'Amex Business Gold (GBP)', accountNumber: 'AX-NORTH-3210-4499', routingNumber: '00-00-00', type: 'CreditCard', balance: -15200, currency: 'GBP' }
  ];

  // We will generate exactly 500 invoices distributed across customers and projects
  for (let i = 1; i <= 500; i++) {
    const custId = `cust_${(i % 150) + 1}`;
    const projId = i % 4 === 0 ? undefined : `proj_${(i % 60) + 1}`;
    const invoiceDate = new Date(Date.now() - (150 - Math.floor(i/3.5)) * 24 * 60 * 60 * 1000);
    const invoiceDateStr = invoiceDate.toISOString().split('T')[0];
    const dueDate = new Date(invoiceDate.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    // Setup some clean items
    const quantity = 10 + (i % 20);
    const rate = i % 2 === 0 ? 120 : 150;
    const subtotal = quantity * rate;
    const tax = subtotal * 0.20; // 20% standard VAT
    const total = subtotal + tax;
    
    const isPaid = i <= 430; // Paid up to 430 invoices, remaining are Overdue or Sent
    const status: InvoiceStatus = isPaid ? 'Paid' : (dueDate < '2026-09-15' ? 'Overdue' : 'Sent');
    
    const lines: InvoiceLine[] = [
      {
        id: `inv_line_${i}_1`,
        productId: i % 2 === 0 ? 'prod_sc_dev' : 'prod_cloud_arch',
        description: i % 2 === 0 ? `Expert Software Engineering Services - ${quantity} hours @ £${rate}/hr` : `Consulting Design & Security Delivery`,
        quantity,
        unitPrice: rate,
        discount: 0,
        taxRate: 20,
        amount: total
      }
    ];

    const invId = `inv_${i}`;
    const newInvoice: Invoice = {
      id: invId,
      number: `INV-2026-${String(invoiceCounter++).padStart(4, '0')}`,
      customerId: custId,
      orderId: undefined,
      date: invoiceDateStr,
      dueDate,
      status,
      lines,
      subtotal,
      discountTotal: 0,
      taxTotal: tax,
      total,
      currency: 'GBP',
      amountPaid: isPaid ? total : 0
    };

    invoices.push(newInvoice);

    // If Paid, let's create balanced Double-Entry journal entries AND matched bank transactions
    if (isPaid) {
      // Debit AccountsReceivable total, Credit Revenue subtotal, Credit TaxLiability tax
      const entryId = `je_${journalCounter++}`;
      const entry: JournalEntry = {
        id: entryId,
        date: invoiceDateStr,
        description: `Invoice ${newInvoice.number} Posting`,
        reference: newInvoice.number,
        posted: true,
        lines: [
          { id: `${entryId}_l1`, accountId: 'acc_1200', debit: total, credit: 0 }, // Receivables Dr
          { id: `${entryId}_l2`, accountId: 'acc_4010', debit: 0, credit: subtotal }, // Revenue Cr
          { id: `${entryId}_l3`, accountId: 'acc_2400', debit: 0, credit: tax } // VAT Cr
        ]
      };
      journalEntries.push(entry);

      // Now payment event: Debit Bank Account total, Credit AccountsReceivable total
      const payId = `pay_${paymentCounter++}`;
      const paymentDate = new Date(invoiceDate.getTime() + (Math.floor(Math.random() * 20)) * 24 * 60 * 60 * 1000);
      const paymentDateStr = paymentDate.toISOString().split('T')[0];

      const newPayment: Payment = {
        id: payId,
        number: `PAY-2026-${String(paymentCounter).padStart(4, '0')}`,
        customerId: custId,
        date: paymentDateStr,
        amount: total,
        currency: 'GBP',
        method: 'Bank Transfer',
        bankAccountId: 'bank_operating',
        reference: `RE-INV-${newInvoice.number}`,
        allocations: [{ id: `${payId}_alloc`, paymentId: payId, invoiceId: invId, amount: total }]
      };
      payments.push(newPayment);

      const payEntryId = `je_${journalCounter++}`;
      const payEntry: JournalEntry = {
        id: payEntryId,
        date: paymentDateStr,
        description: `Payment allocation for ${newInvoice.number}`,
        reference: newPayment.number,
        posted: true,
        lines: [
          { id: `${payEntryId}_l1`, accountId: 'acc_1010', debit: total, credit: 0 }, // Cash/Bank Dr
          { id: `${payEntryId}_l2`, accountId: 'acc_1200', debit: 0, credit: total } // Receivables Cr
        ]
      };
      journalEntries.push(payEntry);

      // Programmatic bank transactions matching
      bankTransactions.push({
        id: `bt_${payId}`,
        bankAccountId: 'bank_operating',
        date: paymentDateStr,
        description: `BACS: ${brandName(custId)} - Invoice ${newInvoice.number}`,
        amount: total,
        matchedId: payId,
        matchType: 'Automatic'
      });
    } else {
      // It is Draft or Unpaid. We still record Accounts Receivable debit/credit if posted
      const entryId = `je_${journalCounter++}`;
      const entry: JournalEntry = {
        id: entryId,
        date: invoiceDateStr,
        description: `Invoice ${newInvoice.number} Posted (Awaiting Payment)`,
        reference: newInvoice.number,
        posted: true,
        lines: [
          { id: `${entryId}_l1`, accountId: 'acc_1200', debit: total, credit: 0 }, // Receivables Dr
          { id: `${entryId}_l2`, accountId: 'acc_4010', debit: 0, credit: subtotal }, // Revenue Cr
          { id: `${entryId}_l3`, accountId: 'acc_2400', debit: 0, credit: tax } // VAT Cr
        ]
      };
      journalEntries.push(entry);
    }
  }

  // 5. Generate lightweight CRM: 30 Opportunities, 20 Leads, Contacts
  const leads: Lead[] = [];
  const opportunities: Opportunity[] = [];
  const contacts: Contact[] = [];

  for (let i = 1; i <= 30; i++) {
    const custId = `cust_${(i % 150) + 1}`;
    opportunities.push({
      id: `opp_${i}`,
      customerId: custId,
      title: `Enterprise Tech Consulting Phase ${i}`,
      value: 12000 + (i * 3500) % 55000,
      stage: i % 5 === 0 ? 'Won' : i % 4 === 0 ? 'Proposal' : 'Discovery',
      probability: i % 5 === 0 ? 100 : i % 4 === 0 ? 60 : 30,
      expectedClose: '2026-10-15',
      ownerId: 'emp_04',
      createdAt: '2026-08-01'
    });
  }

  for (let i = 1; i <= 20; i++) {
    leads.push({
      id: `lead_${i}`,
      companyName: `Global Enterprise Services UK #${i}`,
      contactName: `Lead Contact ${i}`,
      email: `lead.${i}@globalservices.com`,
      phone: `+44 7700 9109${i}`,
      status: i % 4 === 0 ? 'Qualified' : 'Contacted',
      source: i % 3 === 0 ? 'Inbound Referral' : 'Web Organic',
      value: 25000 + i * 500,
      createdAt: '2026-09-01'
    });
  }

  // Populate first contacts
  for (let i = 1; i <= 50; i++) {
    contacts.push({
      id: `cont_${i}`,
      customerId: `cust_${(i % 150) + 1}`,
      firstName: `ContactFirst_${i}`,
      lastName: `ContactLast_${i}`,
      email: `contact.${i}@customer.com`,
      phone: `+44 7700 811${i}`,
      role: i % 3 === 0 ? 'CTO' : i % 2 === 0 ? 'Director of IT' : 'Finance Manager'
    });
  }

  // 6. Seed default Automation Rules
  const automations: AutomationRule[] = [
    { id: 'auto_overdue', trigger: 'invoice_overdue', condition: 'days_overdue > 7', action: 'Create Task: "Follow Up Unpaid Invoice" + Send Email Reminder' },
    { id: 'auto_quote', trigger: 'quote_accepted', condition: 'total > 10000', action: 'Create Sales Order + Auto-Generate Project Template & Notify PM' },
    { id: 'auto_inventory', trigger: 'inventory_low', condition: 'inventory <= reorderPoint', action: 'Draft Purchase Order Suggestion for Supplier' }
  ];

  // Helper function to return customer name
  function brandName(id: string): string {
    const numeric = parseInt(id.replace('cust_', ''), 10);
    return baseCustomerNames[numeric % baseCustomerNames.length] + ` Ltd #${numeric}`;
  }

  // Calculate dynamic chart of account balances based on generated journal entries!
  const finalAccounts = [...DEFAULT_ACCOUNTS];
  // Reset all balances to zero, then apply journals to get exact correct ledger balances!
  finalAccounts.forEach(acc => {
    acc.balance = 0;
  });

  // Inject share capital and initial Retained earnings
  finalAccounts.find(a => a.code === '3100')!.balance = 100000;
  finalAccounts.find(a => a.code === '3000')!.balance = 835000;
  finalAccounts.find(a => a.code === '1010')!.balance = 450000;
  finalAccounts.find(a => a.code === '1040')!.balance = 250000;
  finalAccounts.find(a => a.code === '1020')!.balance = 185000;
  finalAccounts.find(a => a.code === '1030')!.balance = 95000;

  // Let's add all journal balances programmatically!
  journalEntries.forEach(entry => {
    entry.lines.forEach(line => {
      const acc = finalAccounts.find(a => a.id === line.accountId);
      if (acc) {
        if (acc.type === 'Asset' || acc.type === 'Expense') {
          acc.balance += (line.debit - line.credit);
        } else {
          // Liabilities, Equity, Revenue
          acc.balance += (line.credit - line.debit);
        }
      }
    });
  });

  return {
    company,
    users,
    currentUser: users[0],
    leads,
    contacts,
    customers,
    opportunities,
    quotes: [],
    orders: [],
    invoices,
    payments,
    products: SYNTHETIC_PRODUCTS,
    priceLists: [],
    projects,
    tasks: [
      { id: 'task_01', projectId: 'proj_1', title: 'Conduct Initial Cloud Mapping Session', description: 'Interactive workshop with leadership to map infrastructure.', status: 'InProgress', priority: 'High', dueDate: '2026-09-20', ownerId: 'emp_02', dependencies: [] },
      { id: 'task_02', projectId: 'proj_1', title: 'Prepare AWS/GCP Cost Efficiency Analysis', description: 'Deliver report outlining 15-20% runtime reduction vectors.', status: 'Planned', priority: 'Medium', dueDate: '2026-09-28', ownerId: 'emp_09', dependencies: ['task_01'] },
      { id: 'task_03', projectId: 'proj_2', title: 'Rewrite NextJS Dashboard Route Handlers', description: 'Optimize backend route streaming latency to < 50ms.', status: 'Complete', priority: 'High', dueDate: '2026-09-12', ownerId: 'emp_06', dependencies: [] }
    ],
    timeEntries: [],
    suppliers,
    purchaseOrders: [],
    goodsReceipts: [],
    expenses: [
      { id: 'exp_01', employeeId: 'emp_02', date: '2026-09-05', category: 'Travel & Lodging', amount: 350, tax: 70, notes: 'Client onsite workshop train & lunch', status: 'Posted' },
      { id: 'exp_02', employeeId: 'emp_05', date: '2026-09-10', category: 'Software Tools', amount: 85, tax: 17, notes: 'JetBrains IntelliJ Business License subscription', status: 'Approved' }
    ],
    employees: SYNTHETIC_EMPLOYEES,
    leaveRequests: [
      { id: 'lr_1', employeeId: 'emp_05', type: 'AnnualLeave', startDate: '2026-10-01', endDate: '2026-10-10', totalDays: 7, notes: 'Autumn holiday trip', status: 'Approved' }
    ],
    payrollRuns: [
      { id: 'pr_08', period: '2026-08', date: '2026-08-28', status: 'Paid', totalGross: 145000, totalDeductions: 18500, totalTax: 32000, totalNet: 94500 }
    ],
    documents: [
      { id: 'doc_01', name: 'Standard_Terms_Of_Service_2026.pdf', type: 'PDF', size: '1.2 MB', category: 'Contracts', uploadedAt: '2026-04-12' },
      { id: 'doc_02', name: 'Consulting_Rate_Card_V3.pdf', type: 'PDF', size: '420 KB', category: 'Finance', uploadedAt: '2026-06-01' }
    ],
    contracts: [
      { id: 'cont_01', title: 'Master Services Agreement - Acme Ltd', partyName: 'Acme Corp Ltd', startDate: '2025-01-01', endDate: '2026-12-31', value: 250000, status: 'Active', documentId: 'doc_01' }
    ],
    campaigns: [
      { id: 'camp_01', name: 'Q3 Enterprise Architecture Outbound', startDate: '2026-07-01', endDate: '2026-09-30', budget: 5000, sent: 2400, opened: 1250, clicked: 380, converted: 18, revenue: 84000 }
    ],
    tickets: [
      { id: 'tkt_01', customerId: 'cust_1', subject: 'Core platform monitoring sync latency issue', priority: 'High', status: 'Open', agentId: 'emp_12', createdAt: '2026-09-14' }
    ],
    bankAccounts,
    bankTransactions,
    accounts: finalAccounts,
    journalEntries,
    budgets: [],
    auditLog: [
      { id: 'aud_1', timestamp: '2026-09-15T09:00:00', userId: 'usr_sarah', userEmail: 'sarah.jenkins@northstar.com', action: 'Company Initialization', entity: 'Company', entityId: 'comp_northstar' }
    ],
    automations: [],
    notifications: ['Invoice INV-2026-0480 is overdue by 12 days', 'Cloud Migration Phase 2 started successfully']
  };
}
