#!/usr/bin/env python3
"""Run the BenchmarkSuite against a media file and print a performance report.

Usage:
    python scripts/run_benchmark.py /path/to/video.mov
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import orjson

from python_engine.jobs.benchmark import BenchmarkSuite


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 1

    media_path = sys.argv[1]
    if not Path(media_path).is_file():
        print(f"No such file: {media_path}", file=sys.stderr)
        return 1

    suite = BenchmarkSuite()
    report = suite.run(media_path)
    print(orjson.dumps(report.to_dict(), option=orjson.OPT_INDENT_2).decode())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
