#!/usr/bin/env python3
"""Recursively scan a folder and report media health for every file found.

Usage:
    python scripts/run_health_scan.py /path/to/library
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from python_engine.library.health import run_health_scan
from python_engine.media.scanner import scan_folder


async def _main(folder: str) -> int:
    scan_result = await scan_folder(folder)
    all_paths = [a.path for a in scan_result.assets] + [p for p, _ in scan_result.unreadable]

    if not all_paths:
        print("No media files found.")
        return 0

    reports = await run_health_scan(all_paths)

    healthy = sum(1 for r in reports if r.status.value == "healthy")
    warnings = sum(1 for r in reports if r.status.value == "warning")
    errors = sum(1 for r in reports if r.status.value == "error")

    for report in reports:
        if report.status.value != "healthy":
            issues = ", ".join(report.issues) if report.issues else report.detail or ""
            print(f"[{report.status.value.upper():7}] {report.path} -- {issues}")

    print(f"\n{len(reports)} files scanned: {healthy} healthy, {warnings} warnings, {errors} errors")
    return 1 if errors else 0


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 1
    return asyncio.run(_main(sys.argv[1]))


if __name__ == "__main__":
    raise SystemExit(main())
