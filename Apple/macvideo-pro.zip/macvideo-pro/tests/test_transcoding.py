"""Proxy creation, transcoding, and export validation."""

from __future__ import annotations

from pathlib import Path

import pytest

from python_engine.core.errors import EncodeError, ValidationError
from python_engine.proxies.engine import available_proxy_profiles, generate_proxy
from python_engine.transcoding.engine import FFmpegRunner
from python_engine.transcoding.export import ExportSettings, validate_export
from python_engine.transcoding.presets import get_preset
from tests.conftest import requires_ffmpeg


@requires_ffmpeg
def test_transcode_produces_correct_resolution_and_codec(sample_1080p, tmp_output_dir: Path) -> None:
    runner = FFmpegRunner()
    dest = runner.transcode(
        source=str(sample_1080p),
        destination=str(tmp_output_dir / "out.mp4"),
        video_codec="libx264",
        audio_codec="aac",
        width=640,
        height=360,
    )
    assert dest.exists()
    assert not (tmp_output_dir / "out.mp4.partial").exists()


@requires_ffmpeg
def test_transcode_rejects_command_injection_attempt(sample_1080p, tmp_output_dir: Path) -> None:
    runner = FFmpegRunner()
    with pytest.raises(ValidationError):
        runner.transcode(
            source=str(sample_1080p),
            destination=str(tmp_output_dir / "bad.mp4"),
            video_codec="libx264; rm -rf /",
        )


@requires_ffmpeg
def test_transcode_cancellation_leaves_no_partial_or_final_file(sample_1080p, tmp_output_dir: Path) -> None:
    runner = FFmpegRunner()
    progress_count = [0]

    def on_progress(_p):
        progress_count[0] += 1

    dest_path = tmp_output_dir / "cancelled.mp4"
    with pytest.raises(EncodeError):
        runner.transcode(
            source=str(sample_1080p),
            destination=str(dest_path),
            video_codec="libx264",
            on_progress=on_progress,
            cancel_check=lambda: progress_count[0] >= 1,
        )
    assert not dest_path.exists()
    assert not Path(str(dest_path) + ".partial").exists()


@requires_ffmpeg
def test_transcode_progress_is_real_not_fabricated(sample_1080p, tmp_output_dir: Path) -> None:
    runner = FFmpegRunner()
    events = []
    runner.transcode(
        source=str(sample_1080p),
        destination=str(tmp_output_dir / "progress.mp4"),
        video_codec="libx264",
        on_progress=lambda p: events.append(p),
    )
    assert len(events) > 0
    # At least one event should carry a real frame count from the encoder.
    assert any(e.frame is not None and e.frame > 0 for e in events)


@requires_ffmpeg
def test_generate_proxy_preserves_frame_rate_and_aspect(sample_1080p, tmp_output_dir: Path) -> None:
    profiles = available_proxy_profiles()
    profile = next(p for p in profiles if p.name == "720p H.264")
    dest = generate_proxy(str(sample_1080p), str(tmp_output_dir / "proxy.mov"), profile)
    assert dest.exists()

    from python_engine.media.inspector import inspect_media_asset

    asset = inspect_media_asset(str(dest))
    assert asset.width == 1280
    assert asset.height == 720
    assert asset.frame_rate == pytest.approx(30.0, abs=0.1)


@requires_ffmpeg
def test_validate_export_passes_for_reasonable_settings(sample_1080p, tmp_output_dir: Path) -> None:
    preset = get_preset("1080p H.264")
    settings = ExportSettings(
        source=str(sample_1080p), destination=str(tmp_output_dir / "export.mp4"), preset=preset
    )
    result = validate_export(settings)
    assert result.valid is True
    assert result.errors == []


@requires_ffmpeg
def test_validate_export_fails_for_missing_source(tmp_output_dir: Path) -> None:
    preset = get_preset("1080p H.264")
    settings = ExportSettings(
        source="/no/such/file.mp4", destination=str(tmp_output_dir / "export.mp4"), preset=preset
    )
    result = validate_export(settings)
    assert result.valid is False
    assert len(result.errors) > 0


@requires_ffmpeg
def test_validate_export_warns_on_upscale(sample_1080p, tmp_output_dir: Path) -> None:
    preset = get_preset("4K HEVC")
    settings = ExportSettings(
        source=str(sample_1080p), destination=str(tmp_output_dir / "export4k.mp4"), preset=preset
    )
    result = validate_export(settings)
    assert any("upscale" in w.lower() for w in result.warnings)


@requires_ffmpeg
def test_export_never_starts_with_validation_errors(tmp_output_dir: Path) -> None:
    """Spec section 84: if errors exist, DO NOT START EXPORT."""
    from python_engine.database.database import Database
    from python_engine.jobs.manager import JobManager
    from python_engine.transcoding.queue import ExportQueue

    db = Database(str(tmp_output_dir / "db.sqlite3"))
    db.init()
    mgr = JobManager(db)
    queue = ExportQueue(mgr)
    preset = get_preset("1080p H.264")

    with pytest.raises(ValueError):
        queue.queue_export("/no/such/file.mp4", str(tmp_output_dir / "x.mp4"), preset)
