"""Frame sampling, histogram, colour analysis, scene detection."""

from __future__ import annotations

import numpy as np
import pytest

from python_engine.video.colour import detect_highlight_clipping, detect_shadow_clipping, analyse_colour
from python_engine.video.frames import FrameReader, process_frame_tiles
from python_engine.video.histogram import calculate_histogram
from python_engine.video.scenes import detect_scenes
from python_engine.video.waveform import generate_waveform_data
from python_engine.video.vectorscope import generate_vectorscope
from tests.conftest import requires_ffmpeg


@requires_ffmpeg
def test_frame_reader_reads_by_timestamp_and_number(sample_1080p) -> None:
    with FrameReader(str(sample_1080p)) as reader:
        meta = reader.meta
        assert meta.width == 1920
        assert meta.height == 1080

        frame = reader.read_frame(0.5)
        assert frame.shape == (1080, 1920, 3)

        frame2 = reader.read_frame_number(5)
        assert frame2.shape == (1080, 1920, 3)


def test_frame_reader_raises_decode_error_on_corrupt_file(broken_media) -> None:
    with pytest.raises(Exception):
        FrameReader(str(broken_media))


@requires_ffmpeg
def test_frame_reader_streams_without_accumulating(sample_1080p) -> None:
    with FrameReader(str(sample_1080p)) as reader:
        count = sum(1 for _ in reader.iter_frames(stride=10))
    assert count > 0


def test_tiled_processing_covers_every_pixel_as_views() -> None:
    frame = np.zeros((1000, 1800, 3), dtype=np.uint8)
    tiles = list(process_frame_tiles(frame, tile_width=1024, tile_height=1024))
    total_pixels = sum(t.shape[0] * t.shape[1] for _, _, t in tiles)
    assert total_pixels == 1000 * 1800
    for _, _, tile in tiles:
        assert tile.base is not None  # a numpy view, not a copy


def test_histogram_accounts_for_every_pixel() -> None:
    frame = np.random.randint(0, 256, (100, 150, 3), dtype=np.uint8)
    hist = calculate_histogram(frame)
    assert hist.luminance.sum() == 100 * 150
    assert hist.r.sum() == 100 * 150


def test_clipping_detection_pure_white_and_black() -> None:
    white = np.full((10, 10, 3), 255, dtype=np.uint8)
    black = np.zeros((10, 10, 3), dtype=np.uint8)
    assert detect_highlight_clipping(white) == pytest.approx(100.0)
    assert detect_shadow_clipping(black) == pytest.approx(100.0)
    assert detect_shadow_clipping(white) == pytest.approx(0.0)
    assert detect_highlight_clipping(black) == pytest.approx(0.0)


def test_colour_analysis_reports_assumptions() -> None:
    frame = np.random.randint(0, 256, (50, 50, 3), dtype=np.uint8)
    analysis = analyse_colour(frame)
    assert analysis.assumed_bit_depth == 8
    assert "sRGB" in analysis.assumed_colour_space or "Rec.709" in analysis.assumed_colour_space


def test_waveform_data_accounts_for_every_pixel() -> None:
    frame = np.random.randint(0, 256, (200, 300, 3), dtype=np.uint8)
    wf = generate_waveform_data(frame, output_width=64, level_buckets=32)
    assert wf.columns.sum() == 200 * 300


def test_vectorscope_density_accounts_for_every_pixel() -> None:
    frame = np.random.randint(0, 256, (200, 300, 3), dtype=np.uint8)
    vs = generate_vectorscope(frame, grid_size=32)
    assert vs.density.sum() == 200 * 300


def test_vectorscope_sample_points_bounded() -> None:
    frame = np.random.randint(0, 256, (500, 500, 3), dtype=np.uint8)
    vs = generate_vectorscope(frame, include_sample_points=True, max_sample_points=100)
    assert len(vs.sample_points) <= 101  # +1 tolerance for stride rounding


@requires_ffmpeg
def test_scene_detection_finds_hard_cut(scene_cut_video) -> None:
    markers = detect_scenes(str(scene_cut_video), sample_interval_seconds=0.25, threshold=0.1)
    timestamps = [m.timestamp for m in markers]
    assert any(abs(t - 2.0) < 0.3 for t in timestamps), f"expected a cut near 2.0s, got {timestamps}"


@requires_ffmpeg
def test_scene_detection_confidence_is_bounded(scene_cut_video) -> None:
    markers = detect_scenes(str(scene_cut_video), sample_interval_seconds=0.25)
    for m in markers:
        assert 0.0 <= m.confidence <= 1.0
