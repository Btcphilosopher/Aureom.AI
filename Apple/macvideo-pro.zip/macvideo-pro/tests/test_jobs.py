"""Job queue: priority scheduling, cancellation, checkpointing, crash recovery."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from python_engine.database.database import Database
from python_engine.database.models import JobRow
from python_engine.jobs.manager import JobContext, JobManager, JobPriority, JobStatus
from python_engine.jobs.pool import JobWeight, ProcessingPool


@pytest.fixture()
def db(tmp_path: Path) -> Database:
    database = Database(str(tmp_path / "jobs.sqlite3"))
    database.init()
    return database


async def _drain(mgr: JobManager, *job_ids: str, timeout: float = 3.0) -> None:
    task = asyncio.create_task(mgr.run_forever())
    elapsed = 0.0
    step = 0.02
    while elapsed < timeout:
        statuses = [mgr.get_status(j)["status"] for j in job_ids]
        if all(s in ("COMPLETED", "FAILED", "CANCELLED") for s in statuses):
            break
        await asyncio.sleep(step)
        elapsed += step
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


async def test_priority_ordering_is_strict(db: Database) -> None:
    mgr = JobManager(db)
    order: list[str] = []

    async def handler(ctx: JobContext) -> None:
        order.append(ctx.payload["label"])
        await asyncio.sleep(0.01)

    mgr.register_handler("t", handler)
    mgr.set_concurrency_limit(1)

    ids = [
        mgr.submit("t", {"label": "normal"}, priority=JobPriority.NORMAL),
        mgr.submit("t", {"label": "background"}, priority=JobPriority.BACKGROUND),
        mgr.submit("t", {"label": "realtime"}, priority=JobPriority.REALTIME),
        mgr.submit("t", {"label": "high"}, priority=JobPriority.HIGH),
    ]

    await _drain(mgr, *ids)
    assert order == ["realtime", "high", "normal", "background"]


async def test_job_failure_does_not_crash_manager(db: Database) -> None:
    mgr = JobManager(db)

    async def failing(ctx: JobContext) -> None:
        raise ValueError("deliberate")

    mgr.register_handler("bad", failing)
    job_id = mgr.submit("bad", {})
    await _drain(mgr, job_id)

    status = mgr.get_status(job_id)
    assert status["status"] == "FAILED"
    assert "deliberate" in status["error"]


async def test_cancel_queued_job_never_runs(db: Database) -> None:
    mgr = JobManager(db)
    ran = []

    async def handler(ctx: JobContext) -> None:
        ran.append(ctx.job_id)

    mgr.register_handler("t", handler)
    mgr.set_concurrency_limit(1)

    blocker_ran = asyncio.Event()

    async def blocker(ctx: JobContext) -> None:
        await asyncio.sleep(0.3)
        blocker_ran.set()

    mgr.register_handler("blocker", blocker)
    blocker_id = mgr.submit("blocker", {})
    victim_id = mgr.submit("t", {})

    assert mgr.cancel(victim_id) is True

    await _drain(mgr, blocker_id, victim_id, timeout=1.0)
    assert victim_id not in ran
    assert mgr.get_status(victim_id)["status"] == "CANCELLED"


async def test_cooperative_cancellation_of_running_job(db: Database) -> None:
    mgr = JobManager(db)
    observed_cancel = asyncio.Event()

    async def handler(ctx: JobContext) -> None:
        for _ in range(50):
            if ctx.cancel_requested():
                observed_cancel.set()
                return
            await asyncio.sleep(0.01)

    mgr.register_handler("slow", handler)
    job_id = mgr.submit("slow", {})

    task = asyncio.create_task(mgr.run_forever())
    await asyncio.sleep(0.05)
    mgr.cancel(job_id)
    await asyncio.sleep(0.3)
    task.cancel()

    assert observed_cancel.is_set()
    assert mgr.get_status(job_id)["status"] == "CANCELLED"


async def test_progress_and_checkpoint_are_persisted(db: Database) -> None:
    mgr = JobManager(db)

    async def handler(ctx: JobContext) -> None:
        ctx.report_progress(0.5)
        ctx.checkpoint({"frame": 42})

    mgr.register_handler("t", handler)
    job_id = mgr.submit("t", {})
    await _drain(mgr, job_id)

    assert mgr.get_status(job_id)["progress"] == 1.0  # completed jobs report 1.0
    checkpoint = mgr.get_checkpoint(job_id)
    assert checkpoint == {"frame": 42}


def test_crash_recovery_marks_running_jobs_interrupted(db: Database) -> None:
    with db.session() as session:
        row = JobRow(kind="stale", status=JobStatus.RUNNING.value, priority="NORMAL", payload_json="{}")
        session.add(row)
        session.flush()
        stale_id = row.id

    mgr = JobManager(db)
    recovered = mgr.recover_interrupted_jobs()

    assert stale_id in recovered
    assert mgr.get_status(stale_id)["status"] == "INTERRUPTED"


def test_crash_recovery_does_not_touch_queued_jobs(db: Database) -> None:
    with db.session() as session:
        row = JobRow(kind="q", status=JobStatus.QUEUED.value, priority="NORMAL", payload_json="{}")
        session.add(row)
        session.flush()
        queued_id = row.id

    mgr = JobManager(db)
    recovered = mgr.recover_interrupted_jobs()

    assert queued_id not in recovered
    assert mgr.get_status(queued_id)["status"] == "QUEUED"


def test_processing_pool_never_returns_unbounded_workers() -> None:
    pool = ProcessingPool()
    for weight in JobWeight:
        alloc = pool.allocate(weight)
        assert alloc.worker_count >= 1
        assert alloc.worker_count < 1000  # sanity ceiling; never "unlimited"


def test_processing_pool_heavy_jobs_never_exceed_light_job_ceiling() -> None:
    pool = ProcessingPool()
    light = pool.allocate(JobWeight.LIGHT)
    heavy = pool.allocate(JobWeight.HEAVY)
    assert heavy.worker_count <= light.worker_count


def test_processing_pool_classifies_8k_as_heavy() -> None:
    pool = ProcessingPool()
    assert pool.classify_by_resolution(7680, 4320) == JobWeight.HEAVY
    assert pool.classify_by_resolution(1920, 1080) == JobWeight.LIGHT
