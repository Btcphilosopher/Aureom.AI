"""Metadata extraction, codec capability, and health scanning."""

from __future__ import annotations

import pytest

from python_engine.core.errors import InspectionError
from python_engine.media.codecs import get_codec_capability
from python_engine.media.inspector import inspect_media, inspect_media_asset
from python_engine.library.health import HealthStatus, check_media_health
from tests.conftest import requires_ffmpeg


@requires_ffmpeg
def test_inspect_media_spec_shape(sample_1080p) -> None:
    result = inspect_media(str(sample_1080p))
    assert result["filename"] == sample_1080p.name
    assert result["duration"] == pytest.approx(2.0, abs=0.15)
    assert result["video"]["width"] == 1920
    assert result["video"]["height"] == 1080
    assert result["video"]["codec"] == "h264"
    assert result["audio"]["codec"] == "aac"


@requires_ffmpeg
def test_inspect_media_asset_streams(sample_1080p) -> None:
    asset = inspect_media_asset(str(sample_1080p))
    assert asset.width == 1920
    assert asset.height == 1080
    assert len(asset.streams.video) == 1
    assert len(asset.streams.audio) == 1
    assert asset.streams.primary_video.pixel_format is not None


@requires_ffmpeg
def test_inspect_media_no_audio_stream(sample_360p_no_audio) -> None:
    asset = inspect_media_asset(str(sample_360p_no_audio))
    assert asset.streams.primary_audio is None
    assert asset.streams.primary_video is not None


@requires_ffmpeg
def test_inspect_media_raises_on_corrupt_file(broken_media) -> None:
    with pytest.raises(InspectionError):
        inspect_media(str(broken_media))


def test_inspect_media_raises_on_missing_file() -> None:
    with pytest.raises(Exception):
        inspect_media("/no/such/file/at/all.mov")


@requires_ffmpeg
def test_codec_capability_reflects_installed_backend() -> None:
    cap = get_codec_capability("h264")
    assert cap.decode_supported is True


def test_codec_capability_unknown_codec_reports_unsupported() -> None:
    cap = get_codec_capability("totally_made_up_codec_xyz")
    assert cap.decode_supported is False
    assert cap.encode_supported is False
    assert cap.hardware_possible is False


@requires_ffmpeg
async def test_health_check_healthy_file(sample_1080p) -> None:
    report = await check_media_health(str(sample_1080p))
    assert report.status == HealthStatus.HEALTHY
    assert report.issues == []


@requires_ffmpeg
async def test_health_check_corrupt_file(broken_media) -> None:
    report = await check_media_health(str(broken_media))
    assert report.status == HealthStatus.ERROR


async def test_health_check_missing_file() -> None:
    report = await check_media_health("/no/such/file.mov")
    assert report.status == HealthStatus.ERROR
