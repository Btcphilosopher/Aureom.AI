"""Thumbnail/contact-sheet/filmstrip generation and audio analysis."""

from __future__ import annotations

from pathlib import Path

import pytest
from PIL import Image

from python_engine.audio.analysis import analyse_audio
from python_engine.audio.waveform import generate_audio_waveform
from python_engine.core.errors import DecodeError
from python_engine.thumbnails.generator import (
    generate_contact_sheet,
    generate_filmstrip,
    generate_thumbnail,
)
from tests.conftest import requires_ffmpeg


@requires_ffmpeg
def test_generate_thumbnail_decodes_single_frame_only(sample_1080p, tmp_output_dir: Path) -> None:
    out = generate_thumbnail(str(sample_1080p), 1.0, tmp_output_dir / "thumb.jpg", max_size=(320, 180))
    assert out.exists()
    img = Image.open(out)
    assert img.width <= 320 and img.height <= 180


@requires_ffmpeg
def test_generate_contact_sheet(scene_cut_video, tmp_output_dir: Path) -> None:
    result = generate_contact_sheet(str(scene_cut_video), 6, tmp_output_dir / "contact.jpg", thumb_size=(120, 68))
    assert result.output.exists()
    assert result.frame_count == 6
    assert len(result.timestamps) == 6


@requires_ffmpeg
def test_generate_filmstrip(scene_cut_video, tmp_output_dir: Path) -> None:
    entries = generate_filmstrip(str(scene_cut_video), 0.5, tmp_output_dir / "filmstrip")
    assert len(entries) > 0
    for entry in entries:
        assert entry.thumbnail_path.exists()


@requires_ffmpeg
def test_audio_analysis_on_sine_wave(sample_1080p) -> None:
    result = analyse_audio(str(sample_1080p))
    assert result.channels >= 1
    assert result.duration_seconds == pytest.approx(2.0, abs=0.2)
    assert result.peak_level_dbfs > float("-inf")
    assert result.peak_level_dbfs <= 0.0  # dBFS never exceeds full scale


@requires_ffmpeg
def test_audio_analysis_raises_without_audio_stream(sample_360p_no_audio) -> None:
    with pytest.raises(DecodeError):
        analyse_audio(str(sample_360p_no_audio))


@requires_ffmpeg
def test_audio_waveform_bucket_count(sample_1080p) -> None:
    wf = generate_audio_waveform(str(sample_1080p), resolution=40)
    assert len(wf.peaks) == 40
    assert any(p != (0.0, 0.0) for p in wf.peaks)


@requires_ffmpeg
def test_audio_waveform_peaks_within_valid_range(sample_1080p) -> None:
    wf = generate_audio_waveform(str(sample_1080p), resolution=20)
    for lo, hi in wf.peaks:
        assert -1.0 <= lo <= hi <= 1.0
