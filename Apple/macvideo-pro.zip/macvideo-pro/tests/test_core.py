"""Core layer: config, memory budget, atomic temp files, error handling."""

from __future__ import annotations

from pathlib import Path

import pytest

from python_engine.core.config import MediaEngineConfig
from python_engine.core.errors import ConfigurationError, MediaError
from python_engine.core.tempfile import TemporaryMediaFile, sweep_orphaned
from python_engine.video.memory import MemoryBudget


def test_config_never_hardcodes_worker_count() -> None:
    config = MediaEngineConfig()
    workers = config.resolved_worker_count()
    assert workers >= 1


def test_config_explicit_worker_count_respected() -> None:
    config = MediaEngineConfig(worker_count=3)
    assert config.resolved_worker_count() == 3


def test_config_rejects_invalid_explicit_worker_count() -> None:
    config = MediaEngineConfig(worker_count=0)
    with pytest.raises(ConfigurationError):
        config.resolved_worker_count()


def test_config_memory_ceiling_never_exceeds_available() -> None:
    import psutil

    config = MediaEngineConfig(max_memory_percent=95)
    ceiling = config.memory_ceiling_bytes()
    available = psutil.virtual_memory().available
    assert ceiling <= available


def test_memory_budget_max_concurrent_frames_is_bounded() -> None:
    budget = MemoryBudget()
    frame_size = 7680 * 4320 * 4  # one 8K RGBA frame
    count = budget.max_concurrent_frames(frame_size)
    assert count >= 1
    assert count < 10_000  # sanity ceiling -- never "unlimited"


def test_media_error_includes_path_in_message() -> None:
    err = MediaError("boom", path="/x/y.mov")
    assert "/x/y.mov" in str(err)


def test_atomic_write_commits_on_success(tmp_path: Path) -> None:
    dest = tmp_path / "out.txt"
    tmf = TemporaryMediaFile(dest)
    with tmf as temp_path:
        temp_path.write_text("hello")
        tmf.commit()
    assert dest.exists()
    assert dest.read_text() == "hello"


def test_atomic_write_never_leaves_partial_on_success(tmp_path: Path) -> None:
    dest = tmp_path / "out2.txt"
    tmf = TemporaryMediaFile(dest)
    with tmf as temp_path:
        temp_path.write_text("data")
        tmf.commit()
    assert dest.exists()
    assert dest.read_text() == "data"
    assert not tmf.temp_path.exists()


def test_atomic_write_cleans_up_on_exception(tmp_path: Path) -> None:
    dest = tmp_path / "out3.txt"
    tmf = TemporaryMediaFile(dest)
    try:
        with tmf as temp_path:
            temp_path.write_text("partial data")
            raise RuntimeError("simulated failure")
    except RuntimeError:
        pass
    assert not dest.exists()
    assert not tmf.temp_path.exists()


def test_sweep_orphaned_removes_partial_files(tmp_path: Path) -> None:
    orphan = tmp_path / "leftover.mp4.partial"
    orphan.write_bytes(b"junk")
    normal = tmp_path / "real.mp4"
    normal.write_bytes(b"real data")

    removed = sweep_orphaned(tmp_path)
    assert orphan not in [p for p in tmp_path.iterdir()]
    assert normal.exists()
    assert len(removed) == 1
