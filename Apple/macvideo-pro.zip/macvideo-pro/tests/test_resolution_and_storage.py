"""8K resolution detection, storage, and bitrate calculation."""

from __future__ import annotations

import pytest

from python_engine.storage.estimator import (
    calculate_bitrate,
    estimate_storage,
    format_bytes_binary,
    format_bytes_decimal,
    raw_frame_size,
    raw_video_storage,
)
from python_engine.video.analysis import classify_resolution, is_ultra_high_definition, validate_8k


@pytest.mark.parametrize(
    "width,height,expected",
    [
        (720, 480, "SD"),
        (1280, 720, "HD"),
        (1920, 1080, "FHD"),
        (2048, 1080, "2K"),
        (3840, 2160, "4K"),
        (4096, 2160, "4K"),
        (5120, 2880, "5K"),
        (6144, 3456, "6K"),
        (7680, 4320, "8K"),
        (8192, 4320, "8K"),
        (100, 100, "SD"),
        (0, 0, "OTHER"),
    ],
)
def test_classify_resolution(width: int, height: int, expected: str) -> None:
    assert classify_resolution(width, height) == expected


def test_classify_resolution_is_orientation_independent() -> None:
    assert classify_resolution(3840, 2160) == classify_resolution(2160, 3840)


def test_validate_8k_exact_standards() -> None:
    assert validate_8k(7680, 4320) is True
    assert validate_8k(8192, 4320) is True


def test_validate_8k_nonstandard_but_plausible() -> None:
    # A slightly cropped 8K sensor readout should still validate as 8K.
    assert validate_8k(7680, 4318) is True


def test_validate_8k_rejects_lower_resolutions() -> None:
    assert validate_8k(1920, 1080) is False
    assert validate_8k(3840, 2160) is False


def test_validate_8k_rejects_invalid_dimensions() -> None:
    assert validate_8k(0, 0) is False
    assert validate_8k(-100, 4320) is False


def test_is_ultra_high_definition() -> None:
    assert is_ultra_high_definition(3840, 2160) is True
    assert is_ultra_high_definition(7680, 4320) is True
    assert is_ultra_high_definition(1920, 1080) is False


def test_raw_frame_size_matches_reference_figure() -> None:
    # Spec's own reference: 7680x4320 RGBA 8-bit ~= 132.7 MB.
    size = raw_frame_size(7680, 4320, bytes_per_pixel=4)
    assert size == 132_710_400
    assert format_bytes_decimal(size) == "132.71 MB"


def test_raw_frame_size_rejects_invalid_input() -> None:
    with pytest.raises(ValueError):
        raw_frame_size(0, 100, 4)
    with pytest.raises(ValueError):
        raw_frame_size(100, 100, 0)


def test_raw_video_storage_scales_with_duration_and_fps() -> None:
    one_second = raw_video_storage(7680, 4320, fps=60, duration_seconds=1.0, bytes_per_pixel=4)
    two_seconds = raw_video_storage(7680, 4320, fps=60, duration_seconds=2.0, bytes_per_pixel=4)
    assert two_seconds == pytest.approx(one_second * 2, rel=1e-9)


def test_calculate_bitrate_is_labelled_as_average() -> None:
    result = calculate_bitrate(file_size_bytes=125_000_000, duration_seconds=100)
    assert result.mbps == pytest.approx(10.0, rel=1e-6)
    assert result.is_average is True
    assert result.label == "average bitrate"


def test_calculate_bitrate_rejects_invalid_input() -> None:
    with pytest.raises(ValueError):
        calculate_bitrate(file_size_bytes=100, duration_seconds=0)
    with pytest.raises(ValueError):
        calculate_bitrate(file_size_bytes=-1, duration_seconds=10)


def test_estimate_storage_decimal_and_binary_units_differ() -> None:
    estimate = estimate_storage(duration_seconds=3600, video_bitrate_bps=100_000_000)
    # GB (decimal) and GiB (binary) must differ by the expected ~7.4% factor.
    assert estimate.gb_decimal != estimate.gib_binary
    assert estimate.gb_decimal > estimate.gib_binary


def test_estimate_storage_rejects_negative_input() -> None:
    with pytest.raises(ValueError):
        estimate_storage(duration_seconds=-1, video_bitrate_bps=1000)


def test_format_bytes_binary_and_decimal() -> None:
    assert format_bytes_decimal(1_000_000) == "1.00 MB"
    assert format_bytes_binary(1024 * 1024) == "1.00 MiB"
