"""AI/ML opt-in gating and IPC command routing."""

from __future__ import annotations

import asyncio
from pathlib import Path

import orjson
import pytest

from python_engine.ai.engine import MediaAIEngine
from python_engine.ai.scenes import analyse_scenes
from python_engine.ai.transcription import NoBackendConfigured, transcribe
from python_engine.api.ipc import IPCServer
from python_engine.core.config import MediaEngineConfig
from python_engine.core.errors import ConfigurationError
from python_engine.database.database import Database
from python_engine.jobs.manager import JobManager
from python_engine.transcoding.queue import ExportQueue
from tests.conftest import requires_ffmpeg


def test_ai_disabled_by_default() -> None:
    config = MediaEngineConfig()
    assert config.enable_ai is False


@requires_ffmpeg
def test_ai_refuses_when_disabled(scene_cut_video) -> None:
    engine = MediaAIEngine(MediaEngineConfig(enable_ai=False))
    with pytest.raises(ConfigurationError):
        analyse_scenes(engine, str(scene_cut_video))


@requires_ffmpeg
def test_ai_scene_analysis_works_when_enabled(scene_cut_video) -> None:
    engine = MediaAIEngine(MediaEngineConfig(enable_ai=True))
    result = analyse_scenes(engine, str(scene_cut_video), sample_interval_seconds=0.25)
    assert len(result.scenes) > 0
    assert result.status.backend.value == "local"


def test_transcription_without_backend_raises_honest_error(tmp_path: Path) -> None:
    engine = MediaAIEngine(MediaEngineConfig(enable_ai=True))
    dummy = tmp_path / "audio.wav"
    dummy.write_bytes(b"\x00" * 100)
    with pytest.raises(NoBackendConfigured):
        transcribe(engine, str(dummy), backend=None)


def test_remote_ai_requires_separate_opt_in(tmp_path: Path) -> None:
    engine = MediaAIEngine(MediaEngineConfig(enable_ai=True, ai_allow_remote=False))
    dummy = tmp_path / "audio.wav"
    dummy.write_bytes(b"\x00" * 100)
    with pytest.raises(ConfigurationError):
        transcribe(engine, str(dummy), backend=None, allow_remote=True)


@requires_ffmpeg
async def test_ipc_server_round_trip(sample_1080p, tmp_path: Path) -> None:
    db = Database(str(tmp_path / "ipc.sqlite3"))
    db.init()
    mgr = JobManager(db)
    queue = ExportQueue(mgr)
    server = IPCServer(str(tmp_path / "ipc.sock"), database=db, job_manager=mgr, export_queue=queue)
    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(tmp_path / "ipc.sock"))
        req = {"command": "inspect", "request_id": "1", "params": {"path": str(sample_1080p)}}
        writer.write(orjson.dumps(req) + b"\n")
        await writer.drain()
        line = await reader.readline()
        response = orjson.loads(line)
        assert response["ok"] is True
        assert response["result"]["video"]["width"] == 1920
        writer.close()
    finally:
        await server.stop()


async def test_ipc_server_handles_malformed_json_gracefully(tmp_path: Path) -> None:
    db = Database(str(tmp_path / "ipc2.sqlite3"))
    db.init()
    mgr = JobManager(db)
    queue = ExportQueue(mgr)
    server = IPCServer(str(tmp_path / "ipc2.sock"), database=db, job_manager=mgr, export_queue=queue)
    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(tmp_path / "ipc2.sock"))
        writer.write(b"not valid json\n")
        await writer.drain()
        line = await reader.readline()
        response = orjson.loads(line)
        assert response["ok"] is False
        assert response["error"]["code"] == "invalid_request"
        writer.close()
    finally:
        await server.stop()


async def test_ipc_socket_has_owner_only_permissions(tmp_path: Path) -> None:
    import stat

    db = Database(str(tmp_path / "ipc3.sqlite3"))
    db.init()
    mgr = JobManager(db)
    queue = ExportQueue(mgr)
    server = IPCServer(str(tmp_path / "ipc3.sock"), database=db, job_manager=mgr, export_queue=queue)
    await server.start()
    try:
        mode = stat.S_IMODE(server.socket_path.stat().st_mode)
        assert mode == 0o600
    finally:
        await server.stop()


@requires_ffmpeg
async def test_ipc_analyse_command(sample_1080p, tmp_path: Path) -> None:
    db = Database(str(tmp_path / "ipc4.sqlite3"))
    db.init()
    mgr = JobManager(db)
    queue = ExportQueue(mgr)
    server = IPCServer(str(tmp_path / "ipc4.sock"), database=db, job_manager=mgr, export_queue=queue)
    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(tmp_path / "ipc4.sock"))
        req = {
            "command": "analyse",
            "request_id": "1",
            "params": {"path": str(sample_1080p), "timestamp": 1.0},
        }
        writer.write(orjson.dumps(req) + b"\n")
        await writer.drain()
        line = await reader.readline()
        response = orjson.loads(line)
        assert response["ok"] is True
        assert response["result"]["resolution"] == [1920, 1080]
        assert 0.0 <= response["result"]["mean_luminance"] <= 1.0
        assert len(response["result"]["histogram"]["luminance"]) == 256
        writer.close()
    finally:
        await server.stop()


async def test_ipc_project_save_and_load_round_trip(tmp_path: Path) -> None:
    db = Database(str(tmp_path / "ipc5.sqlite3"))
    db.init()
    mgr = JobManager(db)
    queue = ExportQueue(mgr)
    server = IPCServer(str(tmp_path / "ipc5.sock"), database=db, job_manager=mgr, export_queue=queue)
    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(tmp_path / "ipc5.sock"))

        async def send(cmd, params):
            req = {"command": cmd, "request_id": "1", "params": params}
            writer.write(orjson.dumps(req) + b"\n")
            await writer.drain()
            line = await reader.readline()
            return orjson.loads(line)

        save_resp = await send(
            "project",
            {"action": "save", "name": "IPC Project", "frame_rate": 30.0, "resolution": [1920, 1080]},
        )
        assert save_resp["ok"] is True
        project_id = save_resp["result"]["project_id"]

        load_resp = await send("project", {"action": "load", "project_id": project_id})
        assert load_resp["ok"] is True
        assert load_resp["result"]["name"] == "IPC Project"
        writer.close()
    finally:
        await server.stop()


async def test_ipc_survives_handler_returning_unserializable_data(tmp_path: Path) -> None:
    """Regression test: a handler returning data with non-string dict keys
    *nested* inside an ``Any``-typed field (so pydantic's top-level
    ``dict[str, Any]`` validation doesn't catch it, exactly like the
    original `_cmd_analyse` percentiles bug) must still produce a clean
    error response over the socket, not kill the connection."""
    db = Database(str(tmp_path / "ipc6.sqlite3"))
    db.init()
    mgr = JobManager(db)
    queue = ExportQueue(mgr)
    server = IPCServer(str(tmp_path / "ipc6.sock"), database=db, job_manager=mgr, export_queue=queue)

    # Override a real, schema-valid command's handler to return data that
    # passes pydantic's dict[str, Any] check (int keys nested inside Any)
    # but fails orjson.dumps() -- reproducing the original bug exactly.
    async def bad_dashboard_handler(params):
        return {"colour_statistics": {"percentiles": {1: 0.0, 5: 1.0}}}

    server._handlers["dashboard"] = bad_dashboard_handler

    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(tmp_path / "ipc6.sock"))

        req = {"command": "dashboard", "request_id": "1", "params": {}}
        writer.write(orjson.dumps(req) + b"\n")
        await writer.drain()
        line = await reader.readline()
        response = orjson.loads(line)
        assert response["ok"] is False
        assert response["error"]["code"] == "serialization_error"

        # The connection must still be alive and responsive afterwards.
        req2 = {"command": "system_capabilities", "request_id": "2", "params": {}}
        writer.write(orjson.dumps(req2) + b"\n")
        await writer.drain()
        line2 = await reader.readline()
        assert orjson.loads(line2)["ok"] is True
        writer.close()
    finally:
        await server.stop()
