"""Shared pytest fixtures: synthetic test media generated with ffmpeg.

No fixed "real" media files are bundled (the repo shouldn't ship binary
video files) -- fixtures generate small synthetic clips on demand via
ffmpeg's `lavfi` sources, and are skipped automatically if ffmpeg isn't
available on the machine running the tests (spec section 90: "Tests
should skip unavailable external media gracefully").
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

FFMPEG_AVAILABLE = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None

requires_ffmpeg = pytest.mark.skipif(
    not FFMPEG_AVAILABLE, reason="ffmpeg/ffprobe not available on this machine"
)


def _make_video(
    path: Path,
    *,
    width: int,
    height: int,
    fps: float,
    duration: float,
    with_audio: bool = True,
    video_codec: str = "libx264",
    pix_fmt: str = "yuv420p",
    color: str | None = None,
) -> Path:
    if color is not None:
        source = f"color=c={color}:size={width}x{height}:rate={fps}:duration={duration}"
    else:
        source = f"testsrc=size={width}x{height}:rate={fps}:duration={duration}"

    argv = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", source]
    if with_audio:
        argv += ["-f", "lavfi", "-i", f"sine=frequency=440:duration={duration}"]
    argv += ["-c:v", video_codec, "-pix_fmt", pix_fmt]
    if with_audio:
        argv += ["-c:a", "aac"]
    argv += [str(path), "-y"]

    subprocess.run(argv, check=True, capture_output=True)
    return path


@pytest.fixture(scope="session")
def media_dir(tmp_path_factory: pytest.TempPathFactory) -> Path:
    return tmp_path_factory.mktemp("macvideo_test_media")


@pytest.fixture(scope="session")
def sample_1080p(media_dir: Path) -> Path:
    return _make_video(media_dir / "sample_1080p.mp4", width=1920, height=1080, fps=30, duration=2.0)


@pytest.fixture(scope="session")
def sample_360p_no_audio(media_dir: Path) -> Path:
    return _make_video(
        media_dir / "sample_360p.mp4", width=640, height=360, fps=24, duration=1.0, with_audio=False
    )


@pytest.fixture(scope="session")
def broken_media(media_dir: Path) -> Path:
    path = media_dir / "broken.mov"
    path.write_text("not a real video file")
    return path


@pytest.fixture(scope="session")
def scene_cut_video(media_dir: Path) -> Path:
    """A video with one hard cut at 2.0s (red -> blue), for scene detection tests."""
    red = media_dir / "_red.mp4"
    blue = media_dir / "_blue.mp4"
    _make_video(red, width=640, height=360, fps=25, duration=2.0, with_audio=False, color="red")
    _make_video(blue, width=640, height=360, fps=25, duration=2.0, with_audio=False, color="blue")

    concat_list = media_dir / "_concat.txt"
    concat_list.write_text(f"file '{red.name}'\nfile '{blue.name}'\n")

    out = media_dir / "scene_cut.mp4"
    subprocess.run(
        [
            "ffmpeg", "-hide_banner", "-loglevel", "error",
            "-f", "concat", "-safe", "0", "-i", str(concat_list),
            "-c", "copy", str(out), "-y",
        ],
        check=True, capture_output=True, cwd=media_dir,
    )
    return out


@pytest.fixture()
def tmp_output_dir(tmp_path: Path) -> Path:
    d = tmp_path / "outputs"
    d.mkdir()
    return d
