"""Database, search, and duplicate detection."""

from __future__ import annotations

import asyncio
from pathlib import Path


from python_engine.database.database import Database
from python_engine.database.models import MediaAssetRow
from python_engine.library.duplicates import find_duplicates
from python_engine.library.manager import LibraryManager, dashboard_data, library_statistics
from python_engine.library.search import MediaQuery, search_media
from python_engine.media.scanner import scan_folder
from tests.conftest import requires_ffmpeg


def test_database_init_creates_tables(tmp_path: Path) -> None:
    db = Database(str(tmp_path / "test.sqlite3"))
    db.init()
    with db.session() as session:
        session.add(MediaAssetRow(path="/x/a.mov", filename="a.mov", file_size=100))
    with db.session() as session:
        rows = session.query(MediaAssetRow).all()
        assert len(rows) == 1
        assert rows[0].path == "/x/a.mov"


def test_database_wal_mode_and_foreign_keys_enabled(tmp_path: Path) -> None:
    db = Database(str(tmp_path / "test2.sqlite3"))
    db.init()
    from sqlalchemy import text

    with db.engine.connect() as conn:
        journal_mode = conn.execute(text("PRAGMA journal_mode")).scalar()
        fk_enabled = conn.execute(text("PRAGMA foreign_keys")).scalar()
    assert journal_mode == "wal"
    assert fk_enabled == 1


def test_migrations_are_idempotent(tmp_path: Path) -> None:
    db = Database(str(tmp_path / "test3.sqlite3"))
    db.init()
    db.init()  # calling init twice must not error or duplicate schema


@requires_ffmpeg
def test_scan_and_search_pipeline(sample_1080p, sample_360p_no_audio, broken_media, tmp_path: Path) -> None:
    db = Database(str(tmp_path / "lib.sqlite3"))
    db.init()
    mgr = LibraryManager(db)

    async def _scan():
        return await scan_folder(str(sample_1080p.parent))

    result = asyncio.run(_scan())
    mgr.upsert_many(result.assets)

    assert any("broken.mov" in path for path, _ in result.unreadable)

    hits = search_media(db, MediaQuery(min_width=1000))
    assert any(h.filename == sample_1080p.name for h in hits)

    stats = library_statistics(db)
    assert stats.total_files >= 2

    dashboard = dashboard_data(db)
    assert dashboard["total_files"] >= 2


@requires_ffmpeg
def test_upsert_is_idempotent_by_path(sample_1080p, tmp_path: Path) -> None:
    from python_engine.media.inspector import inspect_media_asset

    db = Database(str(tmp_path / "lib2.sqlite3"))
    db.init()
    mgr = LibraryManager(db)

    asset = inspect_media_asset(str(sample_1080p))
    id1 = mgr.upsert_asset(asset)
    id2 = mgr.upsert_asset(asset)
    assert id1 == id2
    assert len(mgr.all_assets()) == 1


def test_find_duplicates_detects_byte_identical_files(tmp_path: Path) -> None:
    a = tmp_path / "a.bin"
    b = tmp_path / "b.bin"
    c = tmp_path / "c.bin"
    a.write_bytes(b"x" * 5000)
    b.write_bytes(b"x" * 5000)  # identical content, different name
    c.write_bytes(b"y" * 5000)  # different content, same size

    groups = find_duplicates([str(a), str(b), str(c)])
    assert len(groups) == 1
    assert set(groups[0].paths) == {str(a), str(b)}


def test_find_duplicates_no_false_positives_for_different_sizes(tmp_path: Path) -> None:
    a = tmp_path / "a.bin"
    b = tmp_path / "b.bin"
    a.write_bytes(b"x" * 100)
    b.write_bytes(b"x" * 200)
    groups = find_duplicates([str(a), str(b)])
    assert groups == []


def test_find_duplicates_never_uses_filename_as_signal(tmp_path: Path) -> None:
    same_name_different_content_1 = tmp_path / "sub1"
    same_name_different_content_2 = tmp_path / "sub2"
    same_name_different_content_1.mkdir()
    same_name_different_content_2.mkdir()
    f1 = same_name_different_content_1 / "video.mov"
    f2 = same_name_different_content_2 / "video.mov"
    f1.write_bytes(b"a" * 1000)
    f2.write_bytes(b"b" * 1000)

    groups = find_duplicates([str(f1), str(f2)])
    assert groups == []  # same name, different content -> not duplicates
