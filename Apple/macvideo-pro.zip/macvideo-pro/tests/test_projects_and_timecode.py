"""Project/timeline validation, non-destructive editing, and SMPTE timecode."""

from __future__ import annotations

from pathlib import Path

import pytest

from python_engine.database.database import Database
from python_engine.projects.clips import TimelineClip
from python_engine.projects.project import Project, load_project, save_project
from python_engine.projects.timecode import Timecode
from python_engine.projects.timeline import Timeline, validate_timeline


def test_timeline_flags_negative_duration_clip() -> None:
    clip = TimelineClip(source_asset="a", source_in=0, source_out=5, timeline_in=0, timeline_out=-5)
    timeline = Timeline(frame_rate=30, resolution=(1920, 1080), clips=[clip])
    result = validate_timeline(timeline)
    assert result.valid is False
    assert any("negative" in e.lower() or "invalid" in e.lower() for e in result.errors)


def test_timeline_flags_missing_media_reference() -> None:
    clip = TimelineClip(source_asset="ghost", source_in=0, source_out=5, timeline_in=0, timeline_out=5)
    timeline = Timeline(frame_rate=30, resolution=(1920, 1080), clips=[clip])
    result = validate_timeline(timeline, known_asset_ids={"real-asset"})
    assert result.valid is False
    assert any("missing" in e.lower() for e in result.errors)


def test_timeline_warns_on_overlap_but_does_not_reject() -> None:
    clip1 = TimelineClip(source_asset="a", source_in=0, source_out=10, timeline_in=0, timeline_out=10)
    clip2 = TimelineClip(source_asset="a", source_in=0, source_out=10, timeline_in=5, timeline_out=15)
    timeline = Timeline(frame_rate=30, resolution=(1920, 1080), clips=[clip1, clip2])
    result = validate_timeline(timeline, known_asset_ids={"a"})
    assert result.valid is True  # overlap is a warning, not an error
    assert any("overlap" in w.lower() for w in result.warnings)


def test_timeline_warns_on_unusual_frame_rate() -> None:
    timeline = Timeline(frame_rate=17.0, resolution=(1920, 1080))
    result = validate_timeline(timeline)
    assert any("not a common" in w for w in result.warnings)


def test_validate_timeline_never_mutates_input() -> None:
    clip = TimelineClip(source_asset="a", source_in=0, source_out=10, timeline_in=0, timeline_out=10)
    timeline = Timeline(frame_rate=30, resolution=(1920, 1080), clips=[clip])
    original_clip_count = len(timeline.clips)
    validate_timeline(timeline)
    assert len(timeline.clips) == original_clip_count
    assert timeline.clips[0].timeline_out == 10  # untouched


def test_project_round_trip_persistence(tmp_path: Path) -> None:
    db = Database(str(tmp_path / "proj.sqlite3"))
    db.init()

    clip = TimelineClip(source_asset="asset-1", source_in=1, source_out=6, timeline_in=0, timeline_out=5)
    timeline = Timeline(frame_rate=29.97, resolution=(3840, 2160), clips=[clip])
    project = Project(name="My Project", timeline=timeline)

    project_id = save_project(db, project)
    loaded = load_project(db, project_id)

    assert loaded is not None
    assert loaded.name == "My Project"
    assert loaded.timeline.frame_rate == pytest.approx(29.97)
    assert loaded.timeline.resolution == (3840, 2160)
    assert len(loaded.timeline.clips) == 1
    assert loaded.timeline.clips[0].source_asset == "asset-1"


@pytest.mark.parametrize(
    "frame_number,expected",
    [
        (0, "00:00:00;00"),
        (1800, "00:01:00;02"),
        (17982, "00:10:00;00"),
        (19782, "00:11:00;02"),
    ],
)
def test_drop_frame_timecode_known_checkpoints(frame_number: int, expected: str) -> None:
    tc = Timecode.from_frame_number(frame_number, 29.97)
    assert str(tc) == expected


@pytest.mark.parametrize("frame_number", [0, 1800, 17982, 19782, 100_000, 12345, 539999])
def test_drop_frame_timecode_round_trips(frame_number: int) -> None:
    tc = Timecode.from_frame_number(frame_number, 29.97)
    assert tc.to_frame_number(29.97) == frame_number


def test_non_drop_frame_timecode() -> None:
    tc = Timecode.from_frame_number(25 * 60 * 2 + 5, 25.0, drop_frame=False)
    assert str(tc) == "00:02:00:05"


def test_timecode_rejects_invalid_input() -> None:
    with pytest.raises(ValueError):
        Timecode.from_frame_number(-1, 30.0)
    with pytest.raises(ValueError):
        Timecode.from_frame_number(0, 0)
