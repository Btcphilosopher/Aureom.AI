# MACVIDEO.PRO -- Python Computational Engine

The Python backend/orchestration engine for MACVIDEO.PRO, a professional
macOS 8K video analysis and processing platform. Python is the analysis,
calculation, and orchestration layer; real-time playback, GPU rendering,
and UI belong to the native Swift/SwiftUI/AVFoundation/VideoToolbox/Metal
frontend (out of scope for this repo).

## Status

This is a working engine, not a scaffold: every module listed below has
been exercised against real media (synthetic clips generated with ffmpeg's
`lavfi` sources, up to 1080p test signals; genuine 8K test footage wasn't
available in the build environment, so 8K code paths -- resolution
classification, storage math, tiled processing, `ProcessingPool` weight
classification -- are verified with correct-by-construction unit tests and
synthetic dimensions rather than a real 8K decode). 122 tests pass.

### What's fully implemented and tested

- **Core**: config (dynamic RAM-aware, never hardcodes memory pools),
  structured JSON logging with secret redaction, a full exception
  hierarchy, macOS-aware path/volume handling, a single validated
  external-process abstraction (`core/external.py`) used by *everything*
  that shells out -- no raw `subprocess` calls elsewhere, always
  `shell=False`, argv lists only.
- **Media**: async recursive scanner, ffprobe-backed inspector (every
  field genuinely comes from ffprobe -- nothing invented), per-stream
  models, codec capability detection against the *installed* ffmpeg build
  (never assumes hardware acceleration).
- **Video analysis**: resolution classification and 8K validation (driven
  by actual dimensions, verified against the spec's own 132.7MB reference
  figure for a raw 8K RGBA frame), bounded-memory `FrameReader` (decodes
  one frame at a time, never the whole clip), zero-copy tiled processing,
  vectorised NumPy histogram/colour/waveform/vectorscope analysis, a
  streaming frame-difference scene detector (verified to find an exact
  hard cut in a synthetic test clip).
- **Audio**: streamed PCM decode (bounded chunks, never the whole file in
  memory), level analysis (peak/RMS/dynamic range in dBFS), intelligently
  downsampled waveform generation.
- **Thumbnails**: single-frame thumbnail, contact sheet, and filmstrip
  generation -- all decode only the frames they need.
- **Transcoding/proxies/export**: `FFmpegRunner` is the one validated
  abstraction for every encode (rejects command-injection attempts,
  writes atomically via a `.partial` + rename pattern, parses *real*
  encoder progress from ffmpeg's own `-progress` stream). Export
  validation checks codec/resolution/bitrate/frame-rate/audio/disk-space
  and refuses to let an export start with unresolved errors.
- **Jobs**: a priority-ordered async `JobManager` (REALTIME > HIGH >
  NORMAL > LOW > BACKGROUND, verified with strict ordering tests),
  cooperative cancellation (both queued and running jobs), checkpointing,
  and crash recovery (`RUNNING` jobs from a previous process become
  `INTERRUPTED`, never silently still-running). `ProcessingPool` sizes
  concurrent workers from real CPU/RAM state and never returns unbounded
  counts; 8K-class jobs get fewer concurrent workers than thumbnail jobs.
- **Storage/performance**: real disk throughput measurement,
  `SystemCapabilities` detection (no Apple Silicon assumptions -- reports
  what's actually present), `PerformanceAnalyzer` with bottleneck
  classification from measured phase timings, a `BenchmarkSuite` that
  reports only genuinely-measured numbers.
- **Library**: staged duplicate detection (size/mtime -> quick hash ->
  partial hash -> full hash, never uses filename as a signal), structured
  search, async health scanning that never crashes on a bad file.
- **Projects**: non-destructive timeline/clip model, timeline validation
  (overlaps, invalid ranges, missing media -- reports only, never
  mutates), and a from-scratch SMPTE drop-frame timecode implementation
  verified against known reference checkpoints with full round-trip
  correctness.
- **AI/ML**: disabled by default; a real `MediaAIEngine` gate enforces
  `enable_ai`, plus a *separate* `ai_allow_remote` flag before any
  remote-backed path is reachable. Scene analysis and metadata
  suggestions are real (derived from measured data), never auto-applied.
  Transcription ships no bundled speech model -- it raises an honest
  `NoBackendConfigured` error rather than fabricating a transcript; a real
  deployment plugs in a local ASR backend via the `TranscriptionBackend`
  protocol.
- **IPC**: a local-only (Unix domain socket, `0o600` permissions -- never
  a network service) JSON command API covering scan/inspect/thumbnail/
  analyse/proxy/transcode/export/search/project/health/job control/system
  capabilities/dashboard. Malformed requests, unknown commands, and even
  a handler bug that produces non-JSON-serialisable data are all handled
  without killing the connection (see `test_ipc_survives_handler_...` for
  the regression test that caught and fixed exactly this failure mode
  during development).

### Honest gaps

- **8K test footage**: no real 8K source file was available to decode in
  this environment. Everything that touches actual pixels was tested with
  synthetic clips up to 1080p; the 8K-specific code paths (classification
  thresholds, storage formulas, `ProcessingPool` weight tiers) are unit
  tested with correct dimensions/values rather than a live 8K decode.
- **AI transcription**: no local speech-to-text model ships with this
  engine (see above) -- the interface is real and tested, the model
  integration is a deployment-time choice.
- **AI semantic scene description**: `AIScene.semantic_description` stays
  `None` without a configured classifier backend, for the same reason.
- No Apple VideoToolbox hardware encoder was available to verify against
  (the codec-capability / hardware-encoder-detection *logic* is real and
  tested against whatever the installed ffmpeg build reports, but was
  never confirmed against real VideoToolbox output), and
  `StorageMonitor`'s internal/external/network volume classification was
  only exercised on a Linux filesystem, not against real `/Volumes`
  mounts.

## Running the tests

```bash
pip install -e ".[dev]"
pytest tests/ -v
```

Tests that need ffmpeg/ffprobe are marked and skip automatically if those
aren't on `PATH` (spec requirement: tests should skip unavailable external
media gracefully, not fail).

## Project layout

See `python_engine/` for the package tree (mirrors the architecture in the
spec: `core/`, `media/`, `video/`, `audio/`, `transcoding/`, `proxies/`,
`thumbnails/`, `storage/`, `library/`, `projects/`, `jobs/`, `ai/`,
`database/`, `api/`), plus a few modules added beyond the original spec
tree where the work genuinely needed its own file rather than being
crammed into an existing one:

- `core/external.py`, `core/capabilities.py`, `core/tempfile.py`
- `audio/pcm.py` (shared streamed decode used by both `analysis.py` and
  `waveform.py`)
- `jobs/pool.py`, `jobs/performance.py`, `jobs/benchmark.py`
- `projects/timecode.py` (`Timebase`/`Timecode` split out from
  `timeline.py` for size)
- `transcoding/export.py` (`ExportSettings`/`validate_export`/size
  estimation, split from the `TranscodeJob` data shape in `jobs.py`)

`scripts/run_benchmark.py` and `scripts/run_health_scan.py` are small CLI
wrappers for ad-hoc use.

## Architecture reminder

Python = analysis + calculation + orchestration. Swift/AVFoundation/
VideoToolbox = the real media pipeline and real-time playback. Metal =
real-time GPU rendering. Python never assumes it controls the GPU
pipeline or holds an entire frame's worth of 8K video in memory at once;
`enable_gpu_analysis` in `MediaEngineConfig` is a capability flag, not a
claim of direct GPU access.
