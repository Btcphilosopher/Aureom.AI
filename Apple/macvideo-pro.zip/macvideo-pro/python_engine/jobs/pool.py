"""Worker count sizing.

`ProcessingPool` answers one question: "how many of this kind of job
should run concurrently, right now, on this machine?" It never returns an
unbounded number, and it treats heavy (8K-class) jobs very differently
from light ones (thumbnails) -- both in CPU terms and in how many frame
buffers memory can hold at once.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from python_engine.core.config import MediaEngineConfig
from python_engine.video.memory import MemoryBudget


class JobWeight(str, Enum):
    """Relative resource cost of one unit of work of this job kind."""

    LIGHT = "light"  # thumbnails, metadata inspection, small-frame analysis
    MEDIUM = "medium"  # HD/4K analysis, proxy generation
    HEAVY = "heavy"  # 8K analysis, 8K transcode/export


# Baseline concurrency ceilings per weight class, before RAM-based
# reduction. 8K-class work is deliberately capped low: a handful of
# concurrent 8K encodes/analyses can each want multiple GB of working
# memory, and heavy CPU/GPU contention degrades per-job throughput faster
# than it grows aggregate throughput.
_BASE_CEILING = {
    JobWeight.LIGHT: 16,
    JobWeight.MEDIUM: 6,
    JobWeight.HEAVY: 2,
}

# Rough per-job memory cost used only to sanity-check the CPU-derived
# worker count against available RAM -- not a precise accounting of any
# specific job's actual usage.
_ESTIMATED_MEMORY_PER_WORKER_BYTES = {
    JobWeight.LIGHT: 128 * 1024 * 1024,  # 128 MiB
    JobWeight.MEDIUM: 768 * 1024 * 1024,  # 768 MiB
    JobWeight.HEAVY: 3 * 1024 * 1024 * 1024,  # 3 GiB
}


@dataclass(frozen=True, slots=True)
class WorkerAllocation:
    weight: JobWeight
    worker_count: int
    reason: str


class ProcessingPool:
    def __init__(
        self, config: MediaEngineConfig | None = None, memory_budget: MemoryBudget | None = None
    ) -> None:
        self.config = config or MediaEngineConfig()
        self.memory_budget = memory_budget or MemoryBudget(self.config)

    def classify_by_resolution(self, width: int | None, height: int | None) -> JobWeight:
        if not width or not height:
            return JobWeight.MEDIUM
        long_edge = max(width, height)
        if long_edge >= 7000:  # 8K-class
            return JobWeight.HEAVY
        if long_edge >= 3800:  # 4K-class and up
            return JobWeight.MEDIUM
        return JobWeight.LIGHT

    def allocate(self, weight: JobWeight) -> WorkerAllocation:
        """Determine how many workers of `weight` class may run concurrently.

        Starts from the CPU-derived worker count (never unlimited), applies
        the weight-class ceiling, then reduces further if available RAM
        can't comfortably support that many concurrent workers of this
        weight.
        """
        cpu_workers = self.config.resolved_worker_count()
        ceiling = _BASE_CEILING[weight]
        by_cpu = min(cpu_workers, ceiling)

        headroom = self.memory_budget.snapshot().headroom_bytes
        per_worker_cost = _ESTIMATED_MEMORY_PER_WORKER_BYTES[weight]
        by_memory = max(1, headroom // per_worker_cost) if per_worker_cost > 0 else by_cpu

        worker_count = max(1, min(by_cpu, int(by_memory)))

        reason = (
            f"cpu_workers={cpu_workers} weight_ceiling={ceiling} "
            f"memory_headroom_mb={headroom // (1024 * 1024)} "
            f"est_mb_per_worker={per_worker_cost // (1024 * 1024)}"
        )
        return WorkerAllocation(weight=weight, worker_count=worker_count, reason=reason)

    def allocate_for_resolution(self, width: int | None, height: int | None) -> WorkerAllocation:
        return self.allocate(self.classify_by_resolution(width, height))
