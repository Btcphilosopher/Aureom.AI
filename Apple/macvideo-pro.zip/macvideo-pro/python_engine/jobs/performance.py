"""Per-job performance measurement and bottleneck classification.

`PerformanceAnalyzer` is a simple stopwatch collector: callers mark phase
boundaries (decode/analysis/encode/io/queue-wait) as they actually occur,
and this module turns the *measured* durations into a bottleneck
classification. Nothing here estimates or predicts a duration that wasn't
observed.
"""

from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import StrEnum


class JobPhase(StrEnum):
    QUEUE_WAIT = "queue_wait"
    DECODE = "decode"
    ANALYSIS = "analysis"
    ENCODE = "encode"
    IO = "io"


class Bottleneck(StrEnum):
    CPU_BOUND = "CPU_BOUND"
    GPU_BOUND = "GPU_BOUND"
    IO_BOUND = "IO_BOUND"
    ENCODER_BOUND = "ENCODER_BOUND"
    DECODER_BOUND = "DECODER_BOUND"
    UNKNOWN = "UNKNOWN"


@dataclass(slots=True)
class PerformanceRecord:
    job_id: str
    phase_seconds: dict[JobPhase, float] = field(default_factory=dict)

    @property
    def total_seconds(self) -> float:
        return sum(self.phase_seconds.values())

    def classify_bottleneck(self) -> Bottleneck:
        """Diagnostic classification, not an absolute hardware truth (spec
        section 47) -- based purely on which measured phase dominated
        total wall time for *this* job."""
        if not self.phase_seconds:
            return Bottleneck.UNKNOWN

        dominant_phase, dominant_seconds = max(self.phase_seconds.items(), key=lambda kv: kv[1])
        if dominant_seconds <= 0:
            return Bottleneck.UNKNOWN

        mapping = {
            JobPhase.DECODE: Bottleneck.DECODER_BOUND,
            JobPhase.ENCODE: Bottleneck.ENCODER_BOUND,
            JobPhase.IO: Bottleneck.IO_BOUND,
            JobPhase.ANALYSIS: Bottleneck.CPU_BOUND,
            JobPhase.QUEUE_WAIT: Bottleneck.UNKNOWN,  # queueing isn't a hardware bottleneck
        }
        return mapping.get(dominant_phase, Bottleneck.UNKNOWN)

    def to_dict(self) -> dict[str, object]:
        return {
            "job_id": self.job_id,
            "phases": {phase.value: seconds for phase, seconds in self.phase_seconds.items()},
            "total_seconds": self.total_seconds,
            "bottleneck": self.classify_bottleneck().value,
        }


class PerformanceAnalyzer:
    """Collects `PerformanceRecord`s across jobs, keyed by job id."""

    def __init__(self) -> None:
        self._records: dict[str, PerformanceRecord] = {}

    def record_for(self, job_id: str) -> PerformanceRecord:
        return self._records.setdefault(job_id, PerformanceRecord(job_id=job_id))

    @contextmanager
    def measure(self, job_id: str, phase: JobPhase):
        start = time.perf_counter()
        try:
            yield
        finally:
            elapsed = time.perf_counter() - start
            record = self.record_for(job_id)
            record.phase_seconds[phase] = record.phase_seconds.get(phase, 0.0) + elapsed

    def report(self, job_id: str) -> dict[str, object] | None:
        record = self._records.get(job_id)
        return record.to_dict() if record else None

    def all_reports(self) -> list[dict[str, object]]:
        return [r.to_dict() for r in self._records.values()]
