"""Benchmark suite.

Every number returned here comes from an actual timed run of the real
engine code against a real (caller-supplied) media file -- there is no
lookup table of "expected" performance. If a stage can't run (e.g. no
audio stream for the audio benchmark), that stage is omitted from the
report rather than filled with a guess.
"""

from __future__ import annotations

import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

from python_engine.media.inspector import inspect_media_asset
from python_engine.video.analysis import classify_resolution
from python_engine.video.colour import analyse_colour
from python_engine.video.frames import FrameReader
from python_engine.video.histogram import calculate_histogram
from python_engine.video.scenes import detect_scenes
from python_engine.thumbnails.generator import generate_thumbnail


@dataclass(slots=True)
class BenchmarkStageResult:
    stage: str
    seconds: float
    units_processed: int  # e.g. frames, or 1 for a single whole-file op
    unit_label: str

    @property
    def rate_per_second(self) -> float:
        return self.units_processed / self.seconds if self.seconds > 0 else 0.0


@dataclass(slots=True)
class BenchmarkReport:
    media_path: str
    resolution: str
    stages: list[BenchmarkStageResult] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        return {
            "media_path": self.media_path,
            "resolution": self.resolution,
            "stages": [
                {
                    "stage": s.stage,
                    "seconds": s.seconds,
                    "units_processed": s.units_processed,
                    "unit_label": s.unit_label,
                    "rate_per_second": s.rate_per_second,
                }
                for s in self.stages
            ],
        }


class BenchmarkSuite:
    def __init__(self, *, sample_frame_count: int = 10) -> None:
        self.sample_frame_count = sample_frame_count

    def run(self, media_path: str) -> BenchmarkReport:
        stages: list[BenchmarkStageResult] = []

        # -- metadata extraction --
        start = time.perf_counter()
        asset = inspect_media_asset(media_path)
        stages.append(
            BenchmarkStageResult(
                stage="metadata_extraction", seconds=time.perf_counter() - start,
                units_processed=1, unit_label="file",
            )
        )

        resolution = (
            classify_resolution(asset.width, asset.height) if asset.width and asset.height else "OTHER"
        )

        # -- frame analysis + histogram (sampled frames) --
        frames_analysed = 0
        start = time.perf_counter()
        with FrameReader(media_path) as reader:
            meta = reader.meta
            if meta.fps > 0 and meta.frame_count > 0:
                duration = meta.frame_count / meta.fps
                interval = max(duration / self.sample_frame_count, 1.0 / meta.fps)
                t = 0.0
                while t < duration and frames_analysed < self.sample_frame_count:
                    try:
                        frame = reader.read_frame(t)
                    except Exception:
                        break
                    analyse_colour(frame)
                    calculate_histogram(frame)
                    frames_analysed += 1
                    t += interval
        elapsed = time.perf_counter() - start
        if frames_analysed:
            stages.append(
                BenchmarkStageResult(
                    stage="frame_analysis_and_histogram", seconds=elapsed,
                    units_processed=frames_analysed, unit_label="frames",
                )
            )

        # -- thumbnail generation --
        with tempfile.TemporaryDirectory() as tmp:
            thumb_count = 0
            start = time.perf_counter()
            with FrameReader(media_path) as reader:
                meta = reader.meta
                if meta.fps > 0 and meta.frame_count > 0:
                    duration = meta.frame_count / meta.fps
                    interval = max(duration / self.sample_frame_count, 1.0 / meta.fps)
                    t = 0.0
                    while t < duration and thumb_count < self.sample_frame_count:
                        try:
                            generate_thumbnail(media_path, t, Path(tmp) / f"t{thumb_count}.jpg")
                        except Exception:
                            break
                        thumb_count += 1
                        t += interval
            elapsed = time.perf_counter() - start
            if thumb_count:
                stages.append(
                    BenchmarkStageResult(
                        stage="thumbnail_generation", seconds=elapsed,
                        units_processed=thumb_count, unit_label="frames",
                    )
                )

        # -- scene detection --
        start = time.perf_counter()
        markers = detect_scenes(media_path, sample_interval_seconds=0.5)
        elapsed = time.perf_counter() - start
        if markers:
            stages.append(
                BenchmarkStageResult(
                    stage="scene_detection", seconds=elapsed,
                    units_processed=len(markers), unit_label="candidate_cuts",
                )
            )

        return BenchmarkReport(media_path=str(media_path), resolution=resolution, stages=stages)
