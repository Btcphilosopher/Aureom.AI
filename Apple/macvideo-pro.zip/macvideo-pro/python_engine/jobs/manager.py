"""JobManager: the central orchestrator for queued, long-running work.

Handles queueing (priority-ordered), bounded-concurrency workers (sized
per job kind via `ProcessingPool`), cancellation, checkpointing, and
crash recovery. Every state transition is persisted to the `jobs` table
immediately, so `recover_interrupted_jobs()` can tell a genuinely
interrupted job (was RUNNING when the process died) from one that's still
legitimately queued.
"""

from __future__ import annotations

import asyncio
import itertools
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import IntEnum, StrEnum

import orjson
from sqlalchemy import select

from python_engine.core.errors import JobCancelledError
from python_engine.core.logging import get_logger
from python_engine.database.database import Database
from python_engine.database.models import JobRow

_log = get_logger("jobs.manager")


class JobStatus(StrEnum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    INTERRUPTED = "INTERRUPTED"  # was RUNNING when the engine last shut down


class JobPriority(IntEnum):
    """Lower value = scheduled first. Playback-adjacent work outranks
    background library indexing (spec section 98)."""

    REALTIME = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3
    BACKGROUND = 4


JobHandler = Callable[["JobContext"], Awaitable[None]]


@dataclass(slots=True)
class JobContext:
    """Passed to a job handler. `cancel_requested()` / `checkpoint()` /
    `report_progress()` are how a handler cooperates with the manager."""

    job_id: str
    kind: str
    payload: dict[str, object]
    manager: "JobManager"

    def cancel_requested(self) -> bool:
        return self.manager._is_cancel_requested(self.job_id)

    def report_progress(self, progress: float) -> None:
        self.manager._update_progress(self.job_id, progress)

    def checkpoint(self, data: dict[str, object]) -> None:
        self.manager._save_checkpoint(self.job_id, data)


@dataclass(slots=True)
class _QueuedJob:
    priority: JobPriority
    sequence: int
    job_id: str
    kind: str
    payload: dict[str, object]

    def sort_key(self) -> tuple[int, int]:
        return (int(self.priority), self.sequence)


class JobManager:
    def __init__(self, database: Database) -> None:
        self.database = database
        self._handlers: dict[str, JobHandler] = {}
        self._weight_classifiers: dict[str, Callable[[dict[str, object]], int]] = {}
        self._queue: list[_QueuedJob] = []
        self._sequence_counter = itertools.count()
        self._cancel_flags: set[str] = set()
        self._running: dict[str, asyncio.Task] = {}
        self._concurrency_limit = 4
        self._lock = asyncio.Lock()
        self._wakeup = asyncio.Event()

    # -- registration -----------------------------------------------------

    def register_handler(self, kind: str, handler: JobHandler) -> None:
        self._handlers[kind] = handler

    def set_concurrency_limit(self, limit: int) -> None:
        self._concurrency_limit = max(1, limit)

    # -- submission ---------------------------------------------------------

    def submit(
        self,
        kind: str,
        payload: dict[str, object],
        *,
        priority: JobPriority = JobPriority.NORMAL,
    ) -> str:
        with self.database.session() as session:
            row = JobRow(
                kind=kind,
                status=JobStatus.QUEUED.value,
                priority=priority.name,
                payload_json=orjson.dumps(payload).decode(),
            )
            session.add(row)
            session.flush()
            job_id = row.id

        queued = _QueuedJob(
            priority=priority,
            sequence=next(self._sequence_counter),
            job_id=job_id,
            kind=kind,
            payload=payload,
        )
        self._queue.append(queued)
        self._queue.sort(key=lambda j: j.sort_key())
        self._wakeup.set()
        _log.info("job submitted", extra={"context": {"job_id": job_id, "kind": kind}})
        return job_id

    # -- status / control ---------------------------------------------------

    def get_status(self, job_id: str) -> dict[str, object] | None:
        with self.database.session() as session:
            row = session.scalar(select(JobRow).where(JobRow.id == job_id))
            if row is None:
                return None
            return {
                "job_id": row.id,
                "kind": row.kind,
                "status": row.status,
                "priority": row.priority,
                "progress": row.progress,
                "error": row.error,
            }

    def cancel(self, job_id: str) -> bool:
        self._cancel_flags.add(job_id)
        self._queue = [j for j in self._queue if j.job_id != job_id]
        with self.database.session() as session:
            row = session.scalar(select(JobRow).where(JobRow.id == job_id))
            if row is None:
                return False
            if row.status in (JobStatus.QUEUED.value, JobStatus.PAUSED.value):
                row.status = JobStatus.CANCELLED.value
                row.updated_at = _now_iso()
                return True
            # RUNNING: flag is checked cooperatively by the handler via
            # JobContext.cancel_requested(); status transitions to
            # CANCELLED once the handler unwinds (see _run_one).
            return row.status == JobStatus.RUNNING.value

    def pause(self, job_id: str) -> bool:
        """Pause a job. Only meaningful for jobs still in QUEUED (removes
        it from scheduling until resumed) -- a job already RUNNING cannot
        be paused without handler-level cooperation, since this manager
        does not assume control over an external process's execution
        state (see `transcoding.queue.ExportQueue` for a job kind that
        *does* support this, via OS-level process suspension)."""
        self._queue = [j for j in self._queue if j.job_id != job_id]
        with self.database.session() as session:
            row = session.scalar(select(JobRow).where(JobRow.id == job_id))
            if row is None or row.status != JobStatus.QUEUED.value:
                return False
            row.status = JobStatus.PAUSED.value
            row.updated_at = _now_iso()
            return True

    def resume(self, job_id: str) -> bool:
        with self.database.session() as session:
            row = session.scalar(select(JobRow).where(JobRow.id == job_id))
            if row is None or row.status != JobStatus.PAUSED.value:
                return False
            row.status = JobStatus.QUEUED.value
            row.updated_at = _now_iso()
            payload = orjson.loads(row.payload_json)
            priority = JobPriority[row.priority]
            kind = row.kind
            job_id_value = row.id

        queued = _QueuedJob(
            priority=priority,
            sequence=next(self._sequence_counter),
            job_id=job_id_value,
            kind=kind,
            payload=payload,
        )
        self._queue.append(queued)
        self._queue.sort(key=lambda j: j.sort_key())
        self._wakeup.set()
        return True

    # -- crash recovery -------------------------------------------------

    def recover_interrupted_jobs(self) -> list[str]:
        """Any job left RUNNING from before a restart becomes INTERRUPTED,
        never silently left claiming to still be running (spec section 88).
        """
        recovered: list[str] = []
        with self.database.session() as session:
            rows = list(session.scalars(select(JobRow).where(JobRow.status == JobStatus.RUNNING.value)))
            for row in rows:
                row.status = JobStatus.INTERRUPTED.value
                row.updated_at = _now_iso()
                recovered.append(row.id)
        if recovered:
            _log.warning(
                "recovered interrupted jobs from previous run",
                extra={"context": {"job_ids": recovered}},
            )
        return recovered

    # -- execution ------------------------------------------------------

    async def run_forever(self) -> None:
        """Main scheduler loop: pull jobs in priority order, run up to
        `_concurrency_limit` concurrently."""
        while True:
            async with self._lock:
                done = [jid for jid, t in self._running.items() if t.done()]
                for jid in done:
                    self._running.pop(jid, None)

                while self._queue and len(self._running) < self._concurrency_limit:
                    queued = self._queue.pop(0)
                    task = asyncio.create_task(self._run_one(queued))
                    self._running[queued.job_id] = task

            if not self._queue and not self._running:
                self._wakeup.clear()
                await self._wakeup.wait()
            else:
                await asyncio.sleep(0.02)

    async def _run_one(self, queued: _QueuedJob) -> None:
        handler = self._handlers.get(queued.kind)
        if handler is None:
            self._set_status(queued.job_id, JobStatus.FAILED, error=f"No handler registered for kind {queued.kind!r}")
            return

        self._set_status(queued.job_id, JobStatus.RUNNING)
        context = JobContext(job_id=queued.job_id, kind=queued.kind, payload=queued.payload, manager=self)
        try:
            await handler(context)
            if queued.job_id in self._cancel_flags:
                self._set_status(queued.job_id, JobStatus.CANCELLED)
            else:
                self._set_status(queued.job_id, JobStatus.COMPLETED, progress=1.0)
        except JobCancelledError:
            self._set_status(queued.job_id, JobStatus.CANCELLED)
        except Exception as exc:  # noqa: BLE001 - a failed job must not crash the service
            _log.error(
                "job failed", extra={"context": {"job_id": queued.job_id, "error": str(exc)}}
            )
            self._set_status(queued.job_id, JobStatus.FAILED, error=str(exc))
        finally:
            self._cancel_flags.discard(queued.job_id)

    # -- internal helpers used by JobContext -----------------------------

    def _is_cancel_requested(self, job_id: str) -> bool:
        return job_id in self._cancel_flags

    def _update_progress(self, job_id: str, progress: float) -> None:
        with self.database.session() as session:
            row = session.scalar(select(JobRow).where(JobRow.id == job_id))
            if row is not None:
                row.progress = max(0.0, min(1.0, progress))
                row.updated_at = _now_iso()

    def _save_checkpoint(self, job_id: str, data: dict[str, object]) -> None:
        with self.database.session() as session:
            row = session.scalar(select(JobRow).where(JobRow.id == job_id))
            if row is not None:
                row.checkpoint_json = orjson.dumps(data).decode()
                row.updated_at = _now_iso()

    def get_checkpoint(self, job_id: str) -> dict[str, object] | None:
        with self.database.session() as session:
            row = session.scalar(select(JobRow).where(JobRow.id == job_id))
            if row is None or row.checkpoint_json is None:
                return None
            return orjson.loads(row.checkpoint_json)

    def _set_status(
        self,
        job_id: str,
        status: JobStatus,
        *,
        error: str | None = None,
        progress: float | None = None,
    ) -> None:
        with self.database.session() as session:
            row = session.scalar(select(JobRow).where(JobRow.id == job_id))
            if row is None:
                return
            row.status = status.value
            row.updated_at = _now_iso()
            if error is not None:
                row.error = error
            if progress is not None:
                row.progress = progress


def _now_iso() -> str:
    from datetime import UTC, datetime

    return datetime.now(tz=UTC).isoformat()
