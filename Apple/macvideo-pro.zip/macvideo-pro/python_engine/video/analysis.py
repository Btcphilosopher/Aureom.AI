"""Resolution classification and 8K validation.

Classification is always driven by actual pixel dimensions -- never by
filename, container metadata hints, or codec name.
"""

from __future__ import annotations

# (label, min_width, min_height) thresholds, ordered from largest to
# smallest so the first match wins. These follow common broadcast/post
# terminology; the "min" values are picked so real-world variants (e.g.
# 3840x2160 vs 4096x2160 DCI) both classify as their tier.
_TIERS: list[tuple[str, int, int]] = [
    ("8K", 7000, 3900),
    ("6K", 5900, 3300),
    ("5K", 4900, 2700),
    ("4K", 3700, 1900),
    ("2K", 1900, 1000),
    ("FHD", 1900, 1000),  # overlaps 2K deliberately; refined below
    ("HD", 1200, 700),
    ("SD", 1, 1),
]

# Precise, well-known standards checked first for an exact/near-exact match
# before falling back to the threshold table above.
_KNOWN_RESOLUTIONS: dict[tuple[int, int], str] = {
    (720, 480): "SD",
    (720, 576): "SD",
    (1280, 720): "HD",
    (1920, 1080): "FHD",
    (2048, 1080): "2K",
    (2048, 1152): "2K",
    (3840, 2160): "4K",
    (4096, 2160): "4K",
    (5120, 2880): "5K",
    (6144, 3160): "6K",
    (6144, 3456): "6K",
    (7680, 4320): "8K",
    (8192, 4320): "8K",
}


def classify_resolution(width: int, height: int) -> str:
    """Classify a resolution into SD/HD/FHD/2K/4K/5K/6K/8K/OTHER.

    Driven entirely by `(width, height)`. Landscape and portrait
    orientations both classify the same way (the larger dimension is
    treated as the "long" edge).
    """
    if width <= 0 or height <= 0:
        return "OTHER"

    long_edge = max(width, height)
    short_edge = min(width, height)

    exact = _KNOWN_RESOLUTIONS.get((long_edge, short_edge))
    if exact:
        return exact

    if long_edge >= 7000 and short_edge >= 3800:
        return "8K"
    if long_edge >= 5700 and short_edge >= 3000:
        return "6K"
    if long_edge >= 4700 and short_edge >= 2500:
        return "5K"
    if long_edge >= 3600 and short_edge >= 1800:
        return "4K"
    if long_edge >= 1900 and short_edge >= 1000:
        # Distinguish DCI/cinema 2K (near-2048 width, ~1080 height, often
        # *not* 16:9) from broadcast Full HD (exactly-ish 16:9 1920x1080).
        aspect = long_edge / short_edge
        if 1900 <= long_edge <= 2100 and abs(aspect - (16 / 9)) > 0.03:
            return "2K"
        return "FHD"
    if long_edge >= 1200 and short_edge >= 700:
        return "HD"
    if long_edge >= 1 and short_edge >= 1:
        return "SD"
    return "OTHER"


# Dimensions that indicate genuine 8K-class media even when they don't
# exactly match the canonical 7680x4320 UHD-2 standard. Real-world
# professional sources include DCI 8K (8192-wide), and anamorphic /
# slightly-cropped sensor readouts.
_COMMON_8K_DIMENSIONS: set[tuple[int, int]] = {
    (7680, 4320),  # 8K UHD-2
    (8192, 4320),  # 8K DCI (full container)
    (8192, 4096),  # 8K DCI (flat)
    (7680, 4800),  # 8K 16:10 variants seen on some sensors
}


def validate_8k(width: int, height: int) -> bool:
    """Return True if `(width, height)` is plausibly 8K-class media.

    Recognises common 8K standards exactly, but does not reject
    non-standard professional resolutions just because they aren't a bit-
    for-bit match: any frame at or above roughly 7000x3800 (matching the
    8K classification threshold) qualifies, since real capture/crop/export
    pipelines routinely produce slightly different dimensions (e.g.
    7680x4318 from a cropped 8K sensor).
    """
    if width <= 0 or height <= 0:
        return False

    if (width, height) in _COMMON_8K_DIMENSIONS or (height, width) in _COMMON_8K_DIMENSIONS:
        return True

    return classify_resolution(width, height) == "8K"


def is_ultra_high_definition(width: int, height: int) -> bool:
    """True for 4K and above (UHD tiers this engine expects to handle)."""
    return classify_resolution(width, height) in {"4K", "5K", "6K", "8K"}
