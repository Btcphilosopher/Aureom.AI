"""Vectorscope data generation.

A vectorscope plots each pixel's chroma (U/V, aka Cb/Cr) as a point in a
2D plane; more pixels at a given chroma value means a brighter point.
Python computes that density grid -- the actual scope graticule/rendering
belongs to the Metal frontend.

For an 8K frame (33M+ pixels), returning one point per pixel would be both
enormous and pointless to transmit over IPC, so this returns a bounded
density grid (a 2D histogram over U/V) by default. A capped, downsampled
raw point cloud is available for callers that want a scatter-style render
instead of (or alongside) the density grid.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

_DEFAULT_GRID_SIZE = 256  # U/V axis resolution
_MAX_SCATTER_POINTS = 20_000  # hard cap so an 8K frame can't balloon the payload


@dataclass(frozen=True, slots=True)
class VectorscopeData:
    grid_size: int
    # shape: (grid_size, grid_size), U on one axis, V on the other. Counts,
    # not normalised.
    density: np.ndarray
    # Bounded, optionally-empty scatter sample: list of (u, v) in [-0.5, 0.5].
    sample_points: list[tuple[float, float]]

    def to_dict(self) -> dict[str, object]:
        return {
            "grid_size": self.grid_size,
            "density": self.density.tolist(),
            "sample_points": self.sample_points,
        }


def _rgb_to_uv(frame_rgb: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """BT.709 RGB -> U/V (Cb/Cr-equivalent), each in [-0.5, 0.5]."""
    rgb = frame_rgb[..., :3].astype(np.float64) / 255.0
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]

    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    u = (b - y) / 1.8556  # Kb-normalised
    v = (r - y) / 1.5748  # Kr-normalised
    return u, v


def generate_vectorscope(
    frame: np.ndarray,
    *,
    grid_size: int = _DEFAULT_GRID_SIZE,
    include_sample_points: bool = False,
    max_sample_points: int = _MAX_SCATTER_POINTS,
) -> VectorscopeData:
    if frame.ndim != 3 or frame.shape[2] < 3:
        raise ValueError(f"Expected HxWx3(+) frame, got shape {frame.shape}")
    if grid_size <= 0:
        raise ValueError("grid_size must be > 0")

    u, v = _rgb_to_uv(frame)

    edges = np.linspace(-0.5, 0.5, grid_size + 1)
    density, _, _ = np.histogram2d(u.ravel(), v.ravel(), bins=[edges, edges])

    sample_points: list[tuple[float, float]] = []
    if include_sample_points:
        flat_u, flat_v = u.ravel(), v.ravel()
        total = flat_u.size
        if total > max_sample_points:
            stride = max(1, total // max_sample_points)
            flat_u = flat_u[::stride]
            flat_v = flat_v[::stride]
        sample_points = list(zip(flat_u.tolist(), flat_v.tolist(), strict=True))

    return VectorscopeData(
        grid_size=grid_size,
        density=density.astype(np.int64),
        sample_points=sample_points,
    )
