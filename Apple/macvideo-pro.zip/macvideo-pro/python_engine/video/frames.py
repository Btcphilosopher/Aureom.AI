"""Bounded-memory frame access.

Everything here decodes and holds at most a handful of frames at a time --
never the whole clip. `FrameReader` wraps OpenCV's `VideoCapture`, which
itself decodes via the system media backend and only materialises the
specific frame(s) requested; seeking asks the decoder to get as close as
practical and decode forward from there, it never rewinds to frame zero.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import cv2
import numpy as np

from python_engine.core.errors import DecodeError
from python_engine.core.logging import get_logger

_log = get_logger("video.frames")


@dataclass(frozen=True, slots=True)
class FrameMeta:
    width: int
    height: int
    fps: float
    frame_count: int


class FrameReader:
    """Frame-accurate-as-practical reader over a single media file.

    Holds an open `cv2.VideoCapture`; only ever returns one decoded frame
    (as a numpy array) per call. Use as a context manager to guarantee the
    underlying decoder is released.
    """

    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = Path(path)
        if not self.path.is_file():
            raise DecodeError("File does not exist", path=str(self.path))

        self._cap = cv2.VideoCapture(str(self.path))
        if not self._cap.isOpened():
            raise DecodeError(
                "Could not open media for frame decoding (unsupported codec/container "
                "for this backend, or corrupt file)",
                path=str(self.path),
            )

    @property
    def meta(self) -> FrameMeta:
        return FrameMeta(
            width=int(self._cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
            height=int(self._cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
            fps=float(self._cap.get(cv2.CAP_PROP_FPS)) or 0.0,
            frame_count=int(self._cap.get(cv2.CAP_PROP_FRAME_COUNT)),
        )

    def read_frame(self, timestamp: float) -> np.ndarray:
        """Decode the frame at (or nearest to) `timestamp` seconds.

        Seeks the underlying decoder as close as practical to the
        timestamp, then decodes forward as required -- this does not
        rewind/scan from the start of the file.
        """
        if timestamp < 0:
            raise ValueError("timestamp must be >= 0")

        ok = self._cap.set(cv2.CAP_PROP_POS_MSEC, timestamp * 1000.0)
        if not ok:
            _log.warning(
                "seek by timestamp not confirmed by backend; attempting read anyway",
                extra={"context": {"path": str(self.path), "timestamp": timestamp}},
            )
        success, frame_bgr = self._cap.read()
        if not success or frame_bgr is None:
            raise DecodeError(
                f"Failed to decode frame at timestamp={timestamp:.3f}s",
                path=str(self.path),
            )
        return cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)

    def read_frame_number(self, frame_number: int) -> np.ndarray:
        if frame_number < 0:
            raise ValueError("frame_number must be >= 0")

        ok = self._cap.set(cv2.CAP_PROP_POS_FRAMES, float(frame_number))
        if not ok:
            _log.warning(
                "seek by frame number not confirmed by backend; attempting read anyway",
                extra={"context": {"path": str(self.path), "frame_number": frame_number}},
            )
        success, frame_bgr = self._cap.read()
        if not success or frame_bgr is None:
            raise DecodeError(
                f"Failed to decode frame_number={frame_number}", path=str(self.path)
            )
        return cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)

    def iter_frames(
        self, *, start_frame: int = 0, stride: int = 1
    ) -> Iterator[tuple[int, np.ndarray]]:
        """Stream frames sequentially from `start_frame`, one at a time.

        This never accumulates frames -- it's a generator. Callers that
        need a bounded window (e.g. scene-cut diffing needs only the
        previous frame) should keep only what they need themselves.
        """
        if stride < 1:
            raise ValueError("stride must be >= 1")

        self._cap.set(cv2.CAP_PROP_POS_FRAMES, float(start_frame))
        index = start_frame
        while True:
            success, frame_bgr = self._cap.read()
            if not success or frame_bgr is None:
                return
            if (index - start_frame) % stride == 0:
                yield index, cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            index += 1

    def close(self) -> None:
        self._cap.release()

    def __enter__(self) -> FrameReader:
        return self

    def __exit__(self, *exc_info: object) -> None:
        self.close()


class FrameProcessor(ABC):
    """Base class for streaming, one-frame-at-a-time processing.

    Subclasses hold only whatever bounded state they need between frames
    (e.g. "previous frame" for diffing) -- never a growing list of frames.
    """

    @abstractmethod
    def process(self, frame: np.ndarray) -> object:
        """Process a single frame and return a per-frame result."""


class _SupportsProcess(Protocol):
    def process(self, frame: np.ndarray) -> object: ...


def process_stream(
    frames: Iterator[np.ndarray] | Iterator[tuple[int, np.ndarray]],
    processor: _SupportsProcess,
) -> Iterator[object]:
    """Apply `processor` to a frame stream, yielding results one at a time.

    Consumes and discards each frame immediately after processing --
    memory use is bounded by whatever the processor itself retains, not by
    stream length.
    """
    for item in frames:
        frame = item[1] if isinstance(item, tuple) else item
        yield processor.process(frame)


def process_frame_tiles(
    frame: np.ndarray,
    tile_width: int = 1024,
    tile_height: int = 1024,
) -> Iterator[tuple[int, int, np.ndarray]]:
    """Yield `(x_offset, y_offset, tile)` views over `frame`.

    Tiles are numpy *views* (no copy) into the source frame, so tiling an
    8K frame does not double memory use. Edge tiles are smaller than
    `tile_width`/`tile_height` when the frame doesn't divide evenly --
    callers should not assume uniform tile size.
    """
    if tile_width <= 0 or tile_height <= 0:
        raise ValueError("tile dimensions must be > 0")

    height, width = frame.shape[0], frame.shape[1]
    for y in range(0, height, tile_height):
        for x in range(0, width, tile_width):
            tile = frame[y : min(y + tile_height, height), x : min(x + tile_width, width)]
            yield x, y, tile
