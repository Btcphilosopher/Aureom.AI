"""Histogram calculation. Fully vectorised NumPy -- no per-pixel Python loops."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

_BINS_8BIT = 256


@dataclass(frozen=True, slots=True)
class Histogram:
    luminance: np.ndarray
    r: np.ndarray
    g: np.ndarray
    b: np.ndarray
    bins: int


def luminance(frame_rgb: np.ndarray) -> np.ndarray:
    """Rec. 709 luma from an RGB frame, vectorised."""
    r = frame_rgb[..., 0].astype(np.float64)
    g = frame_rgb[..., 1].astype(np.float64)
    b = frame_rgb[..., 2].astype(np.float64)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def calculate_histogram(frame: np.ndarray, bins: int = _BINS_8BIT) -> Histogram:
    """Compute luminance + per-channel RGB histograms for `frame`.

    `frame` must be an HxWx3 (or HxWx4, alpha ignored) array. Assumes
    8-bit-range values (0-255); callers with higher bit-depth source
    material should normalise to that range first (see `colour.py`).
    """
    if frame.ndim != 3 or frame.shape[2] < 3:
        raise ValueError(f"Expected HxWx3(+) frame, got shape {frame.shape}")

    rgb = frame[..., :3]
    luma = luminance(rgb)

    hist_range = (0, 256)
    luminance_hist, _ = np.histogram(luma, bins=bins, range=hist_range)
    r_hist, _ = np.histogram(rgb[..., 0], bins=bins, range=hist_range)
    g_hist, _ = np.histogram(rgb[..., 1], bins=bins, range=hist_range)
    b_hist, _ = np.histogram(rgb[..., 2], bins=bins, range=hist_range)

    return Histogram(
        luminance=luminance_hist,
        r=r_hist,
        g=g_hist,
        b=b_hist,
        bins=bins,
    )


def histogram_to_dict(hist: Histogram) -> dict[str, list[int]]:
    return {
        "luminance": hist.luminance.tolist(),
        "r": hist.r.tolist(),
        "g": hist.g.tolist(),
        "b": hist.b.tolist(),
    }
