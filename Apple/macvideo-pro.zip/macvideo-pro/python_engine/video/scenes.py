"""Scene / cut detection.

    VIDEO -> SAMPLED FRAMES -> FRAME DIFFERENCE -> CHANGE SCORE
          -> CANDIDATE CUTS -> SCENE MARKERS

Frames are sampled and diffed one pair at a time (only two frames held in
memory at once, regardless of clip length or resolution). Confidence is an
algorithmic estimate derived from how far a candidate's change score sits
above the local threshold -- it is explicitly labelled as such, never
presented as certainty.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from python_engine.video.frames import FrameReader
from python_engine.video.histogram import luminance

_DOWNSCALE_MAX_DIM = 256  # analyse at reduced resolution; cuts don't need full-res diffing


@dataclass(frozen=True, slots=True)
class SceneMarker:
    timestamp: float
    confidence: float  # ALGORITHMIC ESTIMATE, not ground truth

    def to_dict(self) -> dict[str, float]:
        return {"timestamp": self.timestamp, "confidence": self.confidence}


def _downscale_luma(frame: np.ndarray) -> np.ndarray:
    """Cheap area-based downscale to bound the cost of per-frame diffing.

    Uses strided sampling rather than a full resize routine -- sufficient
    for change detection, and avoids pulling in an extra dependency path
    for something this approximate.
    """
    luma = luminance(frame[..., :3])
    height, width = luma.shape
    stride_y = max(1, height // _DOWNSCALE_MAX_DIM)
    stride_x = max(1, width // _DOWNSCALE_MAX_DIM)
    return luma[::stride_y, ::stride_x]


def _change_score(prev: np.ndarray, curr: np.ndarray) -> float:
    """Mean absolute luma difference, normalised to roughly [0, 1]."""
    diff = np.abs(curr.astype(np.float64) - prev.astype(np.float64))
    return float(diff.mean() / 255.0)


class SceneDetector:
    """Streaming scene-cut detector.

    Call `feed(timestamp, frame)` in timestamp order; holds only the
    previous frame's downscaled luma between calls. Call `finish()` to get
    the final list of `SceneMarker`s once all frames have been fed.
    """

    def __init__(
        self,
        *,
        threshold: float = 0.12,
        min_gap_seconds: float = 0.5,
    ) -> None:
        self.threshold = threshold
        self.min_gap_seconds = min_gap_seconds
        self._prev_luma: np.ndarray | None = None
        self._last_cut_time: float | None = None
        self._markers: list[SceneMarker] = []
        # First frame is always an implicit scene start.
        self._seen_first = False

    def feed(self, timestamp: float, frame: np.ndarray) -> SceneMarker | None:
        luma = _downscale_luma(frame)

        if not self._seen_first:
            self._seen_first = True
            self._prev_luma = luma
            marker = SceneMarker(timestamp=timestamp, confidence=1.0)
            self._markers.append(marker)
            self._last_cut_time = timestamp
            return marker

        assert self._prev_luma is not None
        score = _change_score(self._prev_luma, luma)
        self._prev_luma = luma

        if score < self.threshold:
            return None
        if self._last_cut_time is not None and (
            timestamp - self._last_cut_time
        ) < self.min_gap_seconds:
            return None

        # Confidence: how far above threshold, scaled into (0, 1]. This is
        # explicitly an algorithmic estimate of cut likelihood, not a
        # calibrated probability.
        confidence = float(min(1.0, (score - self.threshold) / max(self.threshold, 1e-6) + 0.5))
        marker = SceneMarker(timestamp=timestamp, confidence=confidence)
        self._markers.append(marker)
        self._last_cut_time = timestamp
        return marker

    def finish(self) -> list[SceneMarker]:
        return list(self._markers)


def detect_scenes(
    path: str,
    *,
    sample_interval_seconds: float = 0.5,
    threshold: float = 0.12,
    min_gap_seconds: float = 0.5,
) -> list[SceneMarker]:
    """Convenience wrapper: sample a file at a fixed interval and detect cuts."""
    detector = SceneDetector(threshold=threshold, min_gap_seconds=min_gap_seconds)

    with FrameReader(path) as reader:
        meta = reader.meta
        if meta.fps <= 0 or meta.frame_count <= 0:
            return []
        duration = meta.frame_count / meta.fps
        timestamp = 0.0
        while timestamp < duration:
            try:
                frame = reader.read_frame(timestamp)
            except Exception:
                break
            detector.feed(timestamp, frame)
            timestamp += sample_interval_seconds

    return detector.finish()
