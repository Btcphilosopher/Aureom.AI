"""Waveform data generation.

Python's job stops at *data*: a downsampled luminance distribution per
horizontal column, suitable for a Metal/Swift renderer to draw. No pixels
are drawn here.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from python_engine.video.histogram import luminance

_DEFAULT_LEVEL_BUCKETS = 256  # vertical resolution (luma levels 0-255)


@dataclass(frozen=True, slots=True)
class WaveformData:
    """A column-major luminance distribution: for each of `width` output
    columns, a histogram over `level_buckets` luma levels of how many
    source pixels in that column fall at each level. This is exactly the
    data a traditional video waveform monitor plots -- rendering (drawing
    the actual scope) is left to the native Metal frontend.
    """

    width: int
    level_buckets: int
    # shape: (width, level_buckets) -- counts, not normalised, so the
    # renderer can choose its own intensity/log scaling.
    columns: np.ndarray

    def to_list(self) -> list[list[int]]:
        return self.columns.tolist()


def generate_waveform_data(
    frame: np.ndarray,
    *,
    output_width: int = 256,
    level_buckets: int = _DEFAULT_LEVEL_BUCKETS,
) -> WaveformData:
    """Downsample `frame` into a waveform-monitor-style luminance distribution.

    The source frame's columns are grouped into `output_width` buckets
    (each covering `source_width / output_width` source columns); for each
    output column we histogram the luma values of every pixel in that
    source-column group across `level_buckets` levels.
    """
    if frame.ndim != 3 or frame.shape[2] < 3:
        raise ValueError(f"Expected HxWx3(+) frame, got shape {frame.shape}")
    if output_width <= 0 or level_buckets <= 0:
        raise ValueError("output_width and level_buckets must be > 0")

    luma = luminance(frame[..., :3])
    src_height, src_width = luma.shape

    output_width = min(output_width, src_width)
    # Split source columns into `output_width` (near-)equal groups.
    col_edges = np.linspace(0, src_width, output_width + 1, dtype=int)

    columns = np.zeros((output_width, level_buckets), dtype=np.int64)
    bin_edges = np.linspace(0, 256, level_buckets + 1)

    for i in range(output_width):
        lo, hi = col_edges[i], col_edges[i + 1]
        if hi <= lo:
            continue
        segment = luma[:, lo:hi].ravel()
        hist, _ = np.histogram(segment, bins=bin_edges)
        columns[i] = hist

    return WaveformData(width=output_width, level_buckets=level_buckets, columns=columns)
