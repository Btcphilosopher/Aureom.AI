"""Memory budgeting for frame-based processing.

`MemoryBudget` is the thing every frame-touching module consults before
deciding how many frames/tiles/workers it's allowed to hold concurrently.
It reads *actual* system state (via psutil) on every call rather than
caching a number computed once at startup, since available RAM changes
continuously as other processes (including the encoder itself) run.
"""

from __future__ import annotations

from dataclasses import dataclass

import psutil

from python_engine.core.config import MediaEngineConfig


@dataclass(frozen=True, slots=True)
class MemorySnapshot:
    system_total_bytes: int
    system_available_bytes: int
    process_rss_bytes: int
    configured_ceiling_bytes: int

    @property
    def headroom_bytes(self) -> int:
        """Bytes still available under the configured ceiling right now."""
        used_by_this_process = self.process_rss_bytes
        return max(0, self.configured_ceiling_bytes - used_by_this_process)


class MemoryBudget:
    def __init__(self, config: MediaEngineConfig | None = None) -> None:
        self.config = config or MediaEngineConfig()
        self._process = psutil.Process()

    def snapshot(self) -> MemorySnapshot:
        vm = psutil.virtual_memory()
        return MemorySnapshot(
            system_total_bytes=vm.total,
            system_available_bytes=vm.available,
            process_rss_bytes=self._process.memory_info().rss,
            configured_ceiling_bytes=self.config.memory_ceiling_bytes(),
        )

    def max_concurrent_frames(self, frame_size_bytes: int, *, safety_factor: float = 0.5) -> int:
        """How many frames of `frame_size_bytes` can be held concurrently.

        `safety_factor` reserves headroom for the *other* buffers a real
        pipeline needs per frame (colour conversion, tiling scratch space,
        etc) beyond the raw frame itself -- a single frame in flight
        commonly needs 2-3x its raw size in working memory.
        """
        if frame_size_bytes <= 0:
            raise ValueError("frame_size_bytes must be > 0")

        headroom = self.snapshot().headroom_bytes
        effective_frame_cost = frame_size_bytes / max(safety_factor, 0.01)
        return max(1, int(headroom // effective_frame_cost))

    def fits(self, requested_bytes: int) -> bool:
        return requested_bytes <= self.snapshot().headroom_bytes

    def under_pressure(self, *, threshold_percent: float = 85.0) -> bool:
        """True when system-wide memory pressure is high.

        Used by callers (ProcessingPool, caches) to react -- reduce
        workers, flush caches -- rather than crash. See spec section 97.
        """
        vm = psutil.virtual_memory()
        return vm.percent >= threshold_percent
