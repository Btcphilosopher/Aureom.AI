"""Colour analysis: statistics and highlight/shadow clipping detection.

**Assumptions, stated explicitly (per spec section 25):**
  - Input frames are assumed to be full-range 8-bit-per-channel RGB
    (0-255), already decoded/converted by the frame source (`FrameReader`
    converts BGR->RGB but does not reinterpret bit depth or colour space).
  - Clipping thresholds (`HIGHLIGHT_THRESHOLD` / `SHADOW_THRESHOLD`) are
    defined in that same 0-255 8-bit range. For 10/12-bit or log/HDR source
    material, the caller is responsible for normalising to this range (or
    supplying different thresholds) before calling these functions --
    this module does not attempt to infer the original colour space or
    transfer function from pixel values alone.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from python_engine.video.histogram import luminance as compute_luminance

HIGHLIGHT_THRESHOLD = 254  # >= this 8-bit value counts as clipped highlight
SHADOW_THRESHOLD = 1  # <= this 8-bit value counts as clipped shadow

_PERCENTILES = (1, 5, 25, 50, 75, 95, 99)


@dataclass(frozen=True, slots=True)
class ColourAnalysis:
    mean_luminance: float
    min_luminance: float
    max_luminance: float
    percentiles: dict[int, float]
    mean_r: float
    mean_g: float
    mean_b: float
    highlight_clipping_percent: float
    shadow_clipping_percent: float
    assumed_bit_depth: int = 8
    assumed_colour_space: str = "sRGB/Rec.709 (full range)"


def analyse_colour(frame: np.ndarray) -> ColourAnalysis:
    if frame.ndim != 3 or frame.shape[2] < 3:
        raise ValueError(f"Expected HxWx3(+) frame, got shape {frame.shape}")

    rgb = frame[..., :3].astype(np.float64)
    luma = compute_luminance(rgb)

    percentiles = {p: float(np.percentile(luma, p)) for p in _PERCENTILES}

    highlight_pct = detect_highlight_clipping(frame)
    shadow_pct = detect_shadow_clipping(frame)

    return ColourAnalysis(
        mean_luminance=float(luma.mean()),
        min_luminance=float(luma.min()),
        max_luminance=float(luma.max()),
        percentiles=percentiles,
        mean_r=float(rgb[..., 0].mean()),
        mean_g=float(rgb[..., 1].mean()),
        mean_b=float(rgb[..., 2].mean()),
        highlight_clipping_percent=highlight_pct,
        shadow_clipping_percent=shadow_pct,
    )


def detect_highlight_clipping(frame: np.ndarray) -> float:
    """Percentage of pixels with any channel at/above `HIGHLIGHT_THRESHOLD`."""
    rgb = frame[..., :3]
    clipped = np.any(rgb >= HIGHLIGHT_THRESHOLD, axis=-1)
    return float(100.0 * clipped.sum() / clipped.size)


def detect_shadow_clipping(frame: np.ndarray) -> float:
    """Percentage of pixels with all channels at/below `SHADOW_THRESHOLD`."""
    rgb = frame[..., :3]
    clipped = np.all(rgb <= SHADOW_THRESHOLD, axis=-1)
    return float(100.0 * clipped.sum() / clipped.size)
