"""Shared audio level math.

Small, pure helpers for converting between linear PCM amplitude and dBFS,
kept separate from `analysis.py` so both `analysis.py` (whole-file summary)
and any future real-time meter can share the same definitions.
"""

from __future__ import annotations

import numpy as np

_EPSILON = 1e-12


def linear_to_dbfs(value: float, full_scale: float) -> float:
    """Convert a linear amplitude (0..full_scale) to dBFS.

    Returns `-inf` for silence (0 amplitude) rather than raising, since
    "silent" is a legitimate and common measurement result.
    """
    if full_scale <= 0:
        raise ValueError("full_scale must be > 0")
    if value <= 0:
        return float("-inf")
    return 20.0 * np.log10(value / full_scale)


def peak_dbfs(samples: np.ndarray, full_scale: float) -> float:
    if samples.size == 0:
        return float("-inf")
    peak = float(np.abs(samples).max())
    return linear_to_dbfs(peak, full_scale)


def rms_dbfs(samples: np.ndarray, full_scale: float) -> float:
    if samples.size == 0:
        return float("-inf")
    samples_f = samples.astype(np.float64)
    rms = float(np.sqrt(np.mean(samples_f * samples_f)))
    return linear_to_dbfs(max(rms, _EPSILON), full_scale)


def dynamic_range_db(peak_db: float, rms_db: float) -> float:
    """Coarse crest-factor estimate: peak minus RMS, in dB."""
    if peak_db == float("-inf") or rms_db == float("-inf"):
        return 0.0
    return peak_db - rms_db
