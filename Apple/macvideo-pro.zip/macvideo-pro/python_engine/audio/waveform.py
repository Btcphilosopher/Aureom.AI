"""Audio waveform generation: intelligently downsampled min/max peak envelope.

Streams PCM in bounded chunks and folds each chunk into the output buckets
as it arrives -- a multi-hour uncompressed recording is never resident in
memory at once; only the current decode chunk plus the small
`resolution`-sized bucket array.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from python_engine.audio.pcm import PCM_SAMPLE_RATE, pcm_stream
from python_engine.core.paths import require_existing_file
from python_engine.media.inspector import inspect_media_asset


@dataclass(frozen=True, slots=True)
class AudioWaveform:
    resolution: int
    # Per-bucket (min, max) peak envelope in [-1.0, 1.0].
    peaks: list[tuple[float, float]]

    def to_list(self) -> list[list[float]]:
        return [list(p) for p in self.peaks]


def generate_audio_waveform(
    path: str,
    resolution: int,
    *,
    ffmpeg_path: str = "ffmpeg",
    ffprobe_path: str = "ffprobe",
) -> AudioWaveform:
    if resolution <= 0:
        raise ValueError("resolution must be > 0")

    resolved = require_existing_file(path)
    asset = inspect_media_asset(resolved, ffprobe_path)
    duration = asset.duration_seconds or 0.0
    if duration <= 0:
        return AudioWaveform(resolution=resolution, peaks=[(0.0, 0.0)] * resolution)

    total_samples_estimate = int(duration * PCM_SAMPLE_RATE)
    samples_per_bucket = max(1, total_samples_estimate // resolution)

    full_scale = float(np.iinfo(np.int16).max)
    bucket_min = np.zeros(resolution, dtype=np.float64)
    bucket_max = np.zeros(resolution, dtype=np.float64)
    bucket_touched = np.zeros(resolution, dtype=bool)

    sample_cursor = 0
    for chunk in pcm_stream(str(resolved), ffmpeg_path=ffmpeg_path):
        if chunk.size == 0:
            continue
        chunk_f = chunk.astype(np.float64) / full_scale

        start_bucket = min(resolution - 1, sample_cursor // samples_per_bucket)
        end_bucket = min(resolution - 1, (sample_cursor + chunk.size - 1) // samples_per_bucket)

        if start_bucket == end_bucket:
            b = start_bucket
            seg_min, seg_max = float(chunk_f.min()), float(chunk_f.max())
            bucket_min[b] = min(bucket_min[b], seg_min) if bucket_touched[b] else seg_min
            bucket_max[b] = max(bucket_max[b], seg_max) if bucket_touched[b] else seg_max
            bucket_touched[b] = True
        else:
            for b in range(start_bucket, end_bucket + 1):
                bucket_start_sample = b * samples_per_bucket - sample_cursor
                bucket_end_sample = (b + 1) * samples_per_bucket - sample_cursor
                segment = chunk_f[max(0, bucket_start_sample) : max(0, bucket_end_sample)]
                if segment.size == 0:
                    continue
                seg_min, seg_max = float(segment.min()), float(segment.max())
                bucket_min[b] = min(bucket_min[b], seg_min) if bucket_touched[b] else seg_min
                bucket_max[b] = max(bucket_max[b], seg_max) if bucket_touched[b] else seg_max
                bucket_touched[b] = True

        sample_cursor += chunk.size

    peaks = list(zip(bucket_min.tolist(), bucket_max.tolist(), strict=True))
    return AudioWaveform(resolution=resolution, peaks=peaks)
