"""Whole-file audio analysis: level statistics from actual decoded PCM.

Streams through the file once via `audio.pcm.pcm_stream` (bounded chunks,
never the whole decode in memory) accumulating only peak/sum-of-squares
running state.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from python_engine.audio.levels import dynamic_range_db, linear_to_dbfs
from python_engine.audio.pcm import PCM_DTYPE, PCM_SAMPLE_RATE, pcm_stream
from python_engine.core.errors import DecodeError
from python_engine.core.paths import require_existing_file
from python_engine.media.inspector import inspect_media_asset


@dataclass(frozen=True, slots=True)
class AudioAnalysis:
    sample_rate: int
    channels: int
    duration_seconds: float
    peak_level_dbfs: float
    rms_dbfs: float
    dynamic_range_db: float  # coarse crest-factor estimate: peak - RMS


def analyse_audio(
    path: str, *, ffmpeg_path: str = "ffmpeg", ffprobe_path: str = "ffprobe"
) -> AudioAnalysis:
    resolved = require_existing_file(path)
    asset = inspect_media_asset(resolved, ffprobe_path)
    audio_stream = asset.streams.primary_audio
    if audio_stream is None:
        raise DecodeError("File has no audio stream", path=str(resolved))

    peak_abs = 0
    sum_squares = 0.0
    total_samples = 0

    for chunk in pcm_stream(str(resolved), ffmpeg_path=ffmpeg_path):
        if chunk.size == 0:
            continue
        chunk_f = chunk.astype(np.float64)
        peak_abs = max(peak_abs, int(np.abs(chunk).max()))
        sum_squares += float(np.sum(chunk_f * chunk_f))
        total_samples += chunk.size

    full_scale = float(np.iinfo(PCM_DTYPE).max)

    if total_samples == 0 or peak_abs == 0:
        peak_dbfs = float("-inf")
        rms_dbfs_value = float("-inf")
        dyn_range = 0.0
    else:
        peak_dbfs = linear_to_dbfs(peak_abs, full_scale)
        rms_linear = (sum_squares / total_samples) ** 0.5
        rms_dbfs_value = linear_to_dbfs(max(rms_linear, 1e-9), full_scale)
        dyn_range = dynamic_range_db(peak_dbfs, rms_dbfs_value)

    return AudioAnalysis(
        sample_rate=audio_stream.sample_rate or PCM_SAMPLE_RATE,
        channels=audio_stream.channels or 1,
        duration_seconds=asset.duration_seconds or 0.0,
        peak_level_dbfs=float(peak_dbfs),
        rms_dbfs=float(rms_dbfs_value),
        dynamic_range_db=dyn_range,
    )
