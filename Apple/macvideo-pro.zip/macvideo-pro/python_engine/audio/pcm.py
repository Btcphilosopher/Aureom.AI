"""Shared streamed-PCM decode via ffmpeg.

The one place audio decode happens. Both `analysis.py` (level stats) and
`waveform.py` (peak envelope) consume this generator instead of each
shelling out to ffmpeg separately -- streamed in bounded chunks so a
multi-hour uncompressed recording is never fully materialised in memory.
"""

from __future__ import annotations

import subprocess
from collections.abc import Iterator

import numpy as np

from python_engine.core.errors import ExternalToolError
from python_engine.core.external import resolve_executable

PCM_SAMPLE_RATE = 48_000
PCM_DTYPE = np.int16
READ_CHUNK_FRAMES = 1_000_000  # ~1M sample-frames per chunk (~2MB mono s16)


def pcm_stream(
    path: str,
    *,
    ffmpeg_path: str = "ffmpeg",
    sample_rate: int = PCM_SAMPLE_RATE,
) -> Iterator[np.ndarray]:
    """Yield successive int16 numpy chunks of mono-mixed PCM via ffmpeg.

    Mono mixdown (`-ac 1`) is used because this stream feeds level/peak
    analysis on the full mix; original channel *count* is read separately
    from ffprobe metadata elsewhere, never inferred from this stream.
    """
    ffmpeg = resolve_executable(ffmpeg_path)
    argv = [
        ffmpeg,
        "-v",
        "error",
        "-i",
        path,
        "-vn",
        "-ac",
        "1",
        "-ar",
        str(sample_rate),
        "-f",
        "s16le",
        "-",
    ]
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert proc.stdout is not None
    bytes_per_frame = 2  # int16 mono
    chunk_bytes = READ_CHUNK_FRAMES * bytes_per_frame

    try:
        while True:
            raw = proc.stdout.read(chunk_bytes)
            if not raw:
                break
            usable_len = (len(raw) // bytes_per_frame) * bytes_per_frame
            if usable_len == 0:
                continue
            yield np.frombuffer(raw[:usable_len], dtype=PCM_DTYPE)
    finally:
        proc.stdout.close()
        stderr = proc.stderr.read() if proc.stderr else b""
        returncode = proc.wait()
        if returncode != 0:
            raise ExternalToolError(
                f"ffmpeg PCM decode failed (exit {returncode})",
                command=argv,
                returncode=returncode,
                stderr=stderr.decode("utf-8", errors="replace"),
            )
