"""Media inspection via ffprobe.

Every value in the returned structures originates from ffprobe's own
metadata extraction -- nothing here is invented, guessed from a filename, or
filled with a plausible-looking default when ffprobe doesn't report it.
Missing fields stay `None`.
"""

from __future__ import annotations

import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import orjson

from python_engine.core.errors import InspectionError
from python_engine.core.external import run_external, run_external_async
from python_engine.core.logging import get_logger
from python_engine.core.paths import require_existing_file
from python_engine.media.metadata import MediaAsset
from python_engine.media.streams import (
    AudioStreamInfo,
    MetadataStreamInfo,
    StreamCollection,
    SubtitleStreamInfo,
    VideoStreamInfo,
)

_log = get_logger("media.inspector")

_HDR_TRANSFERS = {"smpte2084", "arib-std-b67"}  # PQ / HLG
_HDR_PRIMARIES = {"bt2020"}

_FFPROBE_ARGS = [
    "-v",
    "quiet",
    "-print_format",
    "json",
    "-show_format",
    "-show_streams",
]


def _run_ffprobe(path: Path, ffprobe_path: str) -> dict[str, Any]:
    result = run_external(
        [ffprobe_path, *_FFPROBE_ARGS, str(path)],
        check=False,
    )
    if result.returncode != 0:
        raise InspectionError(
            f"ffprobe failed to inspect media (exit {result.returncode}): "
            f"{result.stderr.strip()[:500]}",
            path=str(path),
        )
    try:
        return orjson.loads(result.stdout)
    except orjson.JSONDecodeError as exc:
        raise InspectionError(f"ffprobe returned unparsable JSON: {exc}", path=str(path)) from exc


async def _run_ffprobe_async(path: Path, ffprobe_path: str) -> dict[str, Any]:
    result = await run_external_async(
        [ffprobe_path, *_FFPROBE_ARGS, str(path)],
        check=False,
    )
    if result.returncode != 0:
        raise InspectionError(
            f"ffprobe failed to inspect media (exit {result.returncode}): "
            f"{result.stderr.strip()[:500]}",
            path=str(path),
        )
    try:
        return orjson.loads(result.stdout)
    except orjson.JSONDecodeError as exc:
        raise InspectionError(f"ffprobe returned unparsable JSON: {exc}", path=str(path)) from exc


def _parse_fraction(value: str | None) -> float | None:
    if not value:
        return None
    if "/" in value:
        num, _, den = value.partition("/")
        try:
            num_f, den_f = float(num), float(den)
        except ValueError:
            return None
        if den_f == 0:
            return None
        return num_f / den_f
    try:
        return float(value)
    except ValueError:
        return None


def _detect_hdr(stream: dict[str, Any]) -> bool:
    transfer = (stream.get("color_transfer") or "").lower()
    primaries = (stream.get("color_primaries") or "").lower()
    return transfer in _HDR_TRANSFERS or primaries in _HDR_PRIMARIES


def _bit_depth_from_pix_fmt(pix_fmt: str | None) -> int | None:
    if not pix_fmt:
        return None
    # e.g. yuv420p10le -> 10, yuv420p -> 8 (implicit), yuv444p12le -> 12
    for token in ("10", "12", "16"):
        if token in pix_fmt:
            return int(token)
    if pix_fmt.endswith("p") or pix_fmt.endswith("le") or pix_fmt.endswith("be"):
        return 8
    return None


def _rotation_from_stream(stream: dict[str, Any]) -> int:
    side_data_list = stream.get("side_data_list") or []
    for entry in side_data_list:
        if "rotation" in entry:
            try:
                return int(entry["rotation"])
            except (TypeError, ValueError):
                continue
    tags = stream.get("tags") or {}
    rotate = tags.get("rotate")
    if rotate is not None:
        try:
            return int(rotate)
        except (TypeError, ValueError):
            pass
    return 0


def _build_stream_collection(probe: dict[str, Any]) -> StreamCollection:
    collection = StreamCollection()
    for stream in probe.get("streams", []):
        codec_type = stream.get("codec_type")
        index = int(stream.get("index", 0))

        if codec_type == "video":
            avg_fps = _parse_fraction(stream.get("avg_frame_rate"))
            r_fps = _parse_fraction(stream.get("r_frame_rate"))
            is_vfr = bool(
                avg_fps and r_fps and abs(avg_fps - r_fps) > max(0.01, r_fps * 0.005)
            )
            pix_fmt = stream.get("pix_fmt")
            collection.video.append(
                VideoStreamInfo(
                    index=index,
                    codec=stream.get("codec_name"),
                    codec_long_name=stream.get("codec_long_name"),
                    width=stream.get("width"),
                    height=stream.get("height"),
                    fps=avg_fps,
                    avg_fps=avg_fps,
                    bit_depth=_bit_depth_from_pix_fmt(pix_fmt),
                    pixel_format=pix_fmt,
                    colour_space=stream.get("color_space"),
                    colour_primaries=stream.get("color_primaries"),
                    colour_transfer=stream.get("color_transfer"),
                    hdr=_detect_hdr(stream),
                    bitrate=int(stream["bit_rate"]) if stream.get("bit_rate") else None,
                    rotation=_rotation_from_stream(stream),
                    is_variable_frame_rate=is_vfr,
                )
            )
        elif codec_type == "audio":
            tags = stream.get("tags") or {}
            collection.audio.append(
                AudioStreamInfo(
                    index=index,
                    codec=stream.get("codec_name"),
                    codec_long_name=stream.get("codec_long_name"),
                    sample_rate=int(stream["sample_rate"])
                    if stream.get("sample_rate")
                    else None,
                    channels=stream.get("channels"),
                    channel_layout=stream.get("channel_layout"),
                    bitrate=int(stream["bit_rate"]) if stream.get("bit_rate") else None,
                    language=tags.get("language"),
                )
            )
        elif codec_type == "subtitle":
            tags = stream.get("tags") or {}
            collection.subtitle.append(
                SubtitleStreamInfo(
                    index=index,
                    codec=stream.get("codec_name"),
                    language=tags.get("language"),
                )
            )
        elif codec_type == "data":
            tags = stream.get("tags") or {}
            collection.data.append(
                MetadataStreamInfo(
                    index=index,
                    codec=stream.get("codec_name"),
                    handler=tags.get("handler_name"),
                )
            )
    return collection


def _asset_from_probe(path: Path, probe: dict[str, Any]) -> MediaAsset:
    fmt = probe.get("format", {})
    streams = _build_stream_collection(probe)
    video = streams.primary_video
    audio = streams.primary_audio

    stat = path.stat()
    created_at = datetime.fromtimestamp(stat.st_ctime, tz=UTC).isoformat()
    modified_at = datetime.fromtimestamp(stat.st_mtime, tz=UTC).isoformat()

    duration = None
    if fmt.get("duration") is not None:
        try:
            duration = float(fmt["duration"])
        except (TypeError, ValueError):
            duration = None

    bitrate = None
    if fmt.get("bit_rate") is not None:
        try:
            bitrate = int(fmt["bit_rate"])
        except (TypeError, ValueError):
            bitrate = None

    return MediaAsset(
        path=str(path),
        filename=path.name,
        duration_seconds=duration,
        width=video.width if video else None,
        height=video.height if video else None,
        frame_rate=video.fps if video else None,
        video_codec=video.codec if video else None,
        audio_codec=audio.codec if audio else None,
        bitrate=bitrate,
        file_size=stat.st_size,
        colour_space=video.colour_space if video else None,
        bit_depth=video.bit_depth if video else None,
        hdr=video.hdr if video else False,
        created_at=created_at,
        modified_at=modified_at,
        streams=streams,
        container=fmt.get("format_name"),
        is_variable_frame_rate=video.is_variable_frame_rate if video else False,
    )


def inspect_media(path: str | os.PathLike[str], ffprobe_path: str = "ffprobe") -> dict[str, Any]:
    """Return the spec-shaped structured JSON dict for a media file.

    Matches the shape from the spec:
    `{"filename", "duration", "video": {...}, "audio": {...}}`.
    """
    resolved = require_existing_file(path)
    probe = _run_ffprobe(resolved, ffprobe_path)
    asset = _asset_from_probe(resolved, probe)
    return _asset_to_spec_shape(asset)


async def inspect_media_async(
    path: str | os.PathLike[str], ffprobe_path: str = "ffprobe"
) -> dict[str, Any]:
    resolved = require_existing_file(path)
    probe = await _run_ffprobe_async(resolved, ffprobe_path)
    asset = _asset_from_probe(resolved, probe)
    return _asset_to_spec_shape(asset)


def inspect_media_asset(
    path: str | os.PathLike[str], ffprobe_path: str = "ffprobe"
) -> MediaAsset:
    """Return the full `MediaAsset` (with per-stream detail) for a media file."""
    resolved = require_existing_file(path)
    probe = _run_ffprobe(resolved, ffprobe_path)
    return _asset_from_probe(resolved, probe)


async def inspect_media_asset_async(
    path: str | os.PathLike[str], ffprobe_path: str = "ffprobe"
) -> MediaAsset:
    resolved = require_existing_file(path)
    probe = await _run_ffprobe_async(resolved, ffprobe_path)
    return _asset_from_probe(resolved, probe)


def _asset_to_spec_shape(asset: MediaAsset) -> dict[str, Any]:
    video = asset.streams.primary_video
    audio = asset.streams.primary_audio
    return {
        "filename": asset.filename,
        "duration": asset.duration_seconds,
        "video": {
            "width": video.width if video else None,
            "height": video.height if video else None,
            "fps": video.fps if video else None,
            "codec": video.codec if video else None,
            "bit_depth": video.bit_depth if video else None,
        }
        if video
        else None,
        "audio": {
            "codec": audio.codec if audio else None,
            "sample_rate": audio.sample_rate if audio else None,
            "channels": audio.channels if audio else None,
        }
        if audio
        else None,
    }
