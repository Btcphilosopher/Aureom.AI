"""Per-stream representations.

A media file can contain multiple video/audio/subtitle/metadata streams
(multicam masters, alternate audio languages, embedded captions, GoPro
telemetry tracks, etc). Each is represented separately rather than
collapsing to "the" video/audio track, so nothing about a file is silently
discarded.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class VideoStreamInfo(BaseModel):
    index: int
    codec: str | None = None
    codec_long_name: str | None = None
    width: int | None = None
    height: int | None = None
    fps: float | None = None
    avg_fps: float | None = None
    bit_depth: int | None = None
    pixel_format: str | None = None
    colour_space: str | None = None
    colour_primaries: str | None = None
    colour_transfer: str | None = None
    hdr: bool = False
    bitrate: int | None = None
    rotation: int = 0
    is_variable_frame_rate: bool = False


class AudioStreamInfo(BaseModel):
    index: int
    codec: str | None = None
    codec_long_name: str | None = None
    sample_rate: int | None = None
    channels: int | None = None
    channel_layout: str | None = None
    bitrate: int | None = None
    language: str | None = None


class SubtitleStreamInfo(BaseModel):
    index: int
    codec: str | None = None
    language: str | None = None


class MetadataStreamInfo(BaseModel):
    """Non-audiovisual data streams: timecode tracks, telemetry, closed captions."""

    index: int
    codec: str | None = None
    handler: str | None = None


class StreamCollection(BaseModel):
    video: list[VideoStreamInfo] = Field(default_factory=list)
    audio: list[AudioStreamInfo] = Field(default_factory=list)
    subtitle: list[SubtitleStreamInfo] = Field(default_factory=list)
    data: list[MetadataStreamInfo] = Field(default_factory=list)

    @property
    def primary_video(self) -> VideoStreamInfo | None:
        return self.video[0] if self.video else None

    @property
    def primary_audio(self) -> AudioStreamInfo | None:
        return self.audio[0] if self.audio else None
