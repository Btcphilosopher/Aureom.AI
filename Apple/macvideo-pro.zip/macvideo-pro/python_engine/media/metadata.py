"""The MediaAsset domain model.

This is the in-memory / API-facing representation of a scanned media file.
The SQLAlchemy ORM row in `database.models.MediaAssetRow` mirrors this shape
for persistence; `MediaAsset` itself has no database dependency.
"""

from __future__ import annotations

import uuid

from pydantic import BaseModel, Field

from python_engine.media.streams import StreamCollection


class MediaAsset(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    path: str
    filename: str

    duration_seconds: float | None = None

    width: int | None = None
    height: int | None = None

    frame_rate: float | None = None
    video_codec: str | None = None
    audio_codec: str | None = None

    bitrate: int | None = None
    file_size: int = 0

    colour_space: str | None = None
    bit_depth: int | None = None
    hdr: bool = False

    created_at: str | None = None
    modified_at: str | None = None

    # Not in the minimal spec shape, but populated by the inspector so
    # downstream consumers (scanner, library, health checks) don't need to
    # re-run ffprobe to see individual streams.
    streams: StreamCollection = Field(default_factory=StreamCollection)

    container: str | None = None
    is_variable_frame_rate: bool = False

    model_config = {"extra": "forbid"}
