"""Asynchronous recursive media scanner.

Walks a folder, finds files with plausible media extensions, and inspects
each with ffprobe -- concurrently, but bounded, so scanning a library with
thousands of files doesn't spawn thousands of ffprobe processes at once.
Files that ffprobe can't actually decode are reported, not silently
skipped or assumed-good from their extension alone.
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass, field
from pathlib import Path

from python_engine.core.errors import InspectionError
from python_engine.core.logging import get_logger
from python_engine.media.inspector import inspect_media_asset_async
from python_engine.media.metadata import MediaAsset

_log = get_logger("media.scanner")

# Extensions we *attempt* to scan. Whether a given file actually decodes is
# determined by handing it to ffprobe/ffmpeg, not by this list alone --
# the installed media backend is the source of truth for what's supported.
CANDIDATE_EXTENSIONS: frozenset[str] = frozenset(
    {".mov", ".mp4", ".m4v", ".avi", ".mkv", ".webm"}
)


@dataclass(slots=True)
class ScanResult:
    assets: list[MediaAsset] = field(default_factory=list)
    unreadable: list[tuple[str, str]] = field(default_factory=list)  # (path, reason)
    skipped_extension: list[str] = field(default_factory=list)
    files_examined: int = 0


async def scan_folder(
    folder: str | os.PathLike[str],
    *,
    ffprobe_path: str = "ffprobe",
    max_concurrency: int = 8,
    extensions: frozenset[str] = CANDIDATE_EXTENSIONS,
    recursive: bool = True,
) -> ScanResult:
    """Recursively scan `folder` for media and return inspected `MediaAsset`s.

    Concurrency is bounded by `max_concurrency` (a semaphore), independent
    of how many files are found -- scanning does not itself spawn unbounded
    workers regardless of library size.
    """
    root = Path(folder)
    if not root.is_dir():
        raise InspectionError(f"Not a directory: {root}", path=str(root))

    candidates = list(_walk(root, extensions, recursive))
    result = ScanResult()

    semaphore = asyncio.Semaphore(max(1, max_concurrency))

    async def _inspect_one(path: Path) -> None:
        async with semaphore:
            result.files_examined += 1
            try:
                asset = await inspect_media_asset_async(path, ffprobe_path)
            except InspectionError as exc:
                _log.warning(
                    "unreadable media during scan",
                    extra={"context": {"path": str(path), "error": str(exc)}},
                )
                result.unreadable.append((str(path), str(exc)))
                return
            result.assets.append(asset)

    await asyncio.gather(*(_inspect_one(path) for path in candidates))
    return result


def _walk(root: Path, extensions: frozenset[str], recursive: bool):
    iterator = root.rglob("*") if recursive else root.glob("*")
    for entry in iterator:
        if not entry.is_file():
            continue
        if entry.suffix.lower() in extensions:
            yield entry
