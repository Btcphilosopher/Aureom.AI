"""Codec capability detection against the *installed* ffmpeg backend.

Nothing here assumes a codec is supported, or that support is hardware
accelerated, just because a codec name is recognised. It's derived from
`ffmpeg -codecs` / `ffmpeg -encoders` / `ffmpeg -hwaccels` output on the
running machine, cached for the process lifetime.
"""

from __future__ import annotations

import functools
import re
from dataclasses import dataclass, field

from python_engine.core.errors import ExternalToolError
from python_engine.core.external import run_external
from python_engine.core.logging import get_logger

_log = get_logger("media.codecs")

# Encoder name substrings that indicate hardware acceleration on macOS
# (VideoToolbox) or common desktop platforms. This is a *hint* used only to
# decide which installed encoders to probe for hardware_possible -- it is
# never used, by itself, to claim hardware support without confirming the
# encoder is actually present in `ffmpeg -encoders`.
_HWACCEL_ENCODER_HINTS = ("videotoolbox", "nvenc", "qsv", "vaapi", "amf")


@dataclass(frozen=True, slots=True)
class CodecCapability:
    codec: str
    decode_supported: bool
    encode_supported: bool
    hardware_possible: bool
    pixel_formats: tuple[str, ...] = field(default_factory=tuple)
    hardware_encoders: tuple[str, ...] = field(default_factory=tuple)


@functools.lru_cache(maxsize=1)
def _raw_codecs_listing(ffmpeg_path: str = "ffmpeg") -> str:
    result = run_external([ffmpeg_path, "-hide_banner", "-codecs"], check=True)
    return result.stdout.decode("utf-8", errors="replace")


@functools.lru_cache(maxsize=1)
def _raw_encoders_listing(ffmpeg_path: str = "ffmpeg") -> str:
    result = run_external([ffmpeg_path, "-hide_banner", "-encoders"], check=True)
    return result.stdout.decode("utf-8", errors="replace")


@functools.lru_cache(maxsize=1)
def _raw_pix_fmts_listing(ffmpeg_path: str = "ffmpeg") -> str:
    result = run_external([ffmpeg_path, "-hide_banner", "-pix_fmts"], check=True)
    return result.stdout.decode("utf-8", errors="replace")


def list_available_codecs(ffmpeg_path: str = "ffmpeg") -> dict[str, CodecCapability]:
    """Enumerate every codec ffmpeg's `-codecs` table reports, with real flags.

    The `-codecs` table format is: `DEVILS name  description`, where the six
    flag letters mean: D=decoding, E=encoding, V/A/S=video/audio/subtitle,
    I=intra-frame-only, L=lossy, S=lossless (position 6). We only read the
    D/E/type flags here; we do not infer anything not present in the table.
    """
    try:
        listing = _raw_codecs_listing(ffmpeg_path)
    except ExternalToolError:
        _log.warning("ffmpeg -codecs unavailable; codec capability list is empty")
        return {}

    encoder_names = _encoder_names(ffmpeg_path)

    codecs: dict[str, CodecCapability] = {}
    pattern = re.compile(r"^\s*([D\.])([E\.])([VASD\.])([I\.])([L\.])([S\.])\s+(\S+)")
    for line in listing.splitlines():
        match = pattern.match(line)
        if not match:
            continue
        decode_flag, encode_flag, _kind, _intra, _lossy, _lossless, name = match.groups()
        decode_supported = decode_flag == "D"
        encode_supported = encode_flag == "E"

        hw_encoders = tuple(
            enc for enc in encoder_names if name in enc and _looks_hardware(enc)
        )
        codecs[name] = CodecCapability(
            codec=name,
            decode_supported=decode_supported,
            encode_supported=encode_supported,
            hardware_possible=bool(hw_encoders),
            pixel_formats=_pixel_formats_for(name, ffmpeg_path),
            hardware_encoders=hw_encoders,
        )
    return codecs


def get_codec_capability(codec: str, ffmpeg_path: str = "ffmpeg") -> CodecCapability:
    codecs = list_available_codecs(ffmpeg_path)
    if codec in codecs:
        return codecs[codec]
    # Unknown to this ffmpeg build: report honestly rather than guessing.
    return CodecCapability(
        codec=codec,
        decode_supported=False,
        encode_supported=False,
        hardware_possible=False,
    )


def _encoder_names(ffmpeg_path: str) -> tuple[str, ...]:
    try:
        listing = _raw_encoders_listing(ffmpeg_path)
    except ExternalToolError:
        return ()
    names = []
    pattern = re.compile(r"^\s*[VAS\.][F\.][S\.][X\.][B\.][D\.]\s+(\S+)")
    for line in listing.splitlines():
        match = pattern.match(line)
        if match:
            names.append(match.group(1))
    return tuple(names)


def _looks_hardware(encoder_name: str) -> bool:
    lowered = encoder_name.lower()
    return any(hint in lowered for hint in _HWACCEL_ENCODER_HINTS)


def _pixel_formats_for(codec: str, ffmpeg_path: str) -> tuple[str, ...]:
    # ffmpeg does not map codec -> supported pixel formats directly via CLI
    # without invoking the encoder; we return the global pixel-format table
    # only as a reference set (not codec-specific) to avoid inventing data.
    try:
        listing = _raw_pix_fmts_listing(ffmpeg_path)
    except ExternalToolError:
        return ()
    formats = []
    for line in listing.splitlines():
        if " = " in line or "NB_COMPONENTS" in line or not line[:5].strip():
            continue
        match = re.match(r"^[IOHPB\.]{5}\s+(\S+)", line)
        if match:
            formats.append(match.group(1))
    return tuple(formats)
