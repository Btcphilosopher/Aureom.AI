"""Thumbnail, contact-sheet, and filmstrip generation.

Every function here decodes only the specific frame(s) it needs via
`FrameReader` -- never the whole source video, regardless of source
resolution. Resizing happens on the single decoded frame, never on the
full clip.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image

from python_engine.core.errors import MediaError
from python_engine.core.paths import require_writable_directory
from python_engine.video.frames import FrameReader


def _resize_keep_aspect(frame: np.ndarray, max_size: tuple[int, int]) -> Image.Image:
    image = Image.fromarray(frame)
    image.thumbnail(max_size, Image.Resampling.LANCZOS)
    return image


def generate_thumbnail(
    video: str | os.PathLike[str],
    timestamp: float,
    output: str | os.PathLike[str],
    max_size: tuple[int, int] = (640, 360),
) -> Path:
    """Decode a single frame at `timestamp` and write a resized thumbnail.

    For an 8K source, this decodes exactly one frame -- the source video is
    never resized as a whole; only the single already-decoded frame is
    scaled down.
    """
    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with FrameReader(video) as reader:
        frame = reader.read_frame(timestamp)

    image = _resize_keep_aspect(frame, max_size)
    image.save(output_path)
    return output_path


@dataclass(frozen=True, slots=True)
class ContactSheetResult:
    output: Path
    frame_count: int
    timestamps: list[float]


def generate_contact_sheet(
    video: str | os.PathLike[str],
    frame_count: int,
    output: str | os.PathLike[str],
    *,
    thumb_size: tuple[int, int] = (320, 180),
    columns: int | None = None,
) -> ContactSheetResult:
    """Sample `frame_count` evenly-spaced frames and tile them into one image.

    Frames are processed sequentially (bounded concurrency: one at a time)
    -- at most one decoded full-res frame and one thumbnail-sized tile are
    held in memory simultaneously, never the whole set of `frame_count`
    full-resolution frames.
    """
    if frame_count < 1:
        raise ValueError("frame_count must be >= 1")

    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with FrameReader(video) as reader:
        meta = reader.meta
        if meta.fps <= 0 or meta.frame_count <= 0:
            raise MediaError("Cannot determine duration for contact sheet", path=str(video))
        duration = meta.frame_count / meta.fps

        # Evenly spaced, inset slightly from the very first/last instant.
        timestamps = [
            duration * (i + 0.5) / frame_count for i in range(frame_count)
        ]

        cols = columns or max(1, int(round(frame_count**0.5)))
        rows = (frame_count + cols - 1) // cols

        sheet = Image.new("RGB", (cols * thumb_size[0], rows * thumb_size[1]), color=(0, 0, 0))

        for i, ts in enumerate(timestamps):
            frame = reader.read_frame(ts)
            tile = _resize_keep_aspect(frame, thumb_size)
            # Centre the (aspect-preserved) tile within its cell.
            x = (i % cols) * thumb_size[0] + (thumb_size[0] - tile.width) // 2
            y = (i // cols) * thumb_size[1] + (thumb_size[1] - tile.height) // 2
            sheet.paste(tile, (x, y))

    sheet.save(output_path)
    return ContactSheetResult(output=output_path, frame_count=frame_count, timestamps=timestamps)


@dataclass(frozen=True, slots=True)
class FilmstripEntry:
    timestamp: float
    thumbnail_path: Path


def generate_filmstrip(
    video: str | os.PathLike[str],
    frame_interval: float,
    output_dir: str | os.PathLike[str],
    *,
    thumb_size: tuple[int, int] = (160, 90),
) -> list[FilmstripEntry]:
    """Generate one small thumbnail every `frame_interval` seconds.

    Returns thumbnails and their timestamps (spec section 22) -- writes
    each as a small file under `output_dir` rather than holding all of
    them as in-memory images at once.
    """
    if frame_interval <= 0:
        raise ValueError("frame_interval must be > 0")

    out_dir = require_writable_directory(output_dir)
    entries: list[FilmstripEntry] = []

    with FrameReader(video) as reader:
        meta = reader.meta
        if meta.fps <= 0 or meta.frame_count <= 0:
            raise MediaError("Cannot determine duration for filmstrip", path=str(video))
        duration = meta.frame_count / meta.fps

        timestamp = 0.0
        index = 0
        while timestamp < duration:
            frame = reader.read_frame(timestamp)
            tile = _resize_keep_aspect(frame, thumb_size)
            path = out_dir / f"frame_{index:06d}.jpg"
            tile.save(path, quality=85)
            entries.append(FilmstripEntry(timestamp=timestamp, thumbnail_path=path))
            timestamp += frame_interval
            index += 1

    return entries
