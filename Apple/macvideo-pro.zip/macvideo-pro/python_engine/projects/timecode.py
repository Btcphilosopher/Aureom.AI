"""Timebase and Timecode.

Timecode arithmetic is not "frame_number / fps" for drop-frame rates
(29.97, 59.94): those use the standard SMPTE drop-frame algorithm, which
skips frame *numbers* 0 and 1 at the start of every minute except every
10th, to keep displayed timecode approximately in sync with wall-clock
time despite the non-integer frame rate. Non-drop-frame rates use plain
integer division.
"""

from __future__ import annotations

from dataclasses import dataclass

# Frame rates conventionally represented as drop-frame when the caller
# doesn't specify explicitly (29.97 and 59.94 "NTSC" rates). This is a
# convention, not a rule -- `Timecode` always takes an explicit
# `drop_frame` flag rather than inferring it silently.
_CONVENTIONALLY_DROP_FRAME_RATES = (29.97, 59.94)


@dataclass(frozen=True, slots=True)
class Timebase:
    """Represents a media timebase where the source metadata makes one
    available: `timescale` (ticks per second) and `frame_duration` (ticks
    per frame). Presentation timestamps, when supplied, are in timescale
    ticks -- not seconds -- until converted."""

    timescale: int
    frame_duration: int

    @property
    def nominal_fps(self) -> float:
        if self.frame_duration == 0:
            return 0.0
        return self.timescale / self.frame_duration

    def ticks_to_seconds(self, ticks: int) -> float:
        if self.timescale == 0:
            return 0.0
        return ticks / self.timescale

    def seconds_to_ticks(self, seconds: float) -> int:
        return round(seconds * self.timescale)


@dataclass(frozen=True, slots=True)
class Timecode:
    hours: int
    minutes: int
    seconds: int
    frames: int
    fps_nominal: int  # rounded nominal rate, e.g. 30 for 29.97, 60 for 59.94
    drop_frame: bool

    def __str__(self) -> str:
        sep = ";" if self.drop_frame else ":"
        return (
            f"{self.hours:02d}:{self.minutes:02d}:{self.seconds:02d}"
            f"{sep}{self.frames:02d}"
        )

    @classmethod
    def from_frame_number(
        cls, frame_number: int, fps: float, *, drop_frame: bool | None = None
    ) -> "Timecode":
        """Build a `Timecode` from an absolute frame count.

        `drop_frame` defaults to the SMPTE convention for 29.97/59.94 if
        not specified, but is never silently assumed for other rates --
        pass it explicitly for anything non-standard.
        """
        if fps <= 0:
            raise ValueError("fps must be > 0")
        if frame_number < 0:
            raise ValueError("frame_number must be >= 0")

        if drop_frame is None:
            drop_frame = any(abs(fps - r) < 0.01 for r in _CONVENTIONALLY_DROP_FRAME_RATES)

        fps_nominal = round(fps)

        if not drop_frame:
            frames_per_hour = fps_nominal * 3600
            frame_number = frame_number % (frames_per_hour * 24)
            frames = frame_number % fps_nominal
            total_seconds = frame_number // fps_nominal
            seconds = total_seconds % 60
            minutes = (total_seconds // 60) % 60
            hours = (total_seconds // 60) // 60
            return cls(hours, minutes, seconds, frames, fps_nominal, drop_frame=False)

        # Standard SMPTE drop-frame algorithm.
        drop_frames = round(fps_nominal * 0.066666)  # 2 for 30-based, 4 for 60-based
        frames_per_10min = round(fps * 60 * 10)
        frames_per_minute_dropped = fps_nominal * 60 - drop_frames
        frames_per_24h = round(fps_nominal * 3600 * 24)

        frame_number = frame_number % frames_per_24h

        d, m = divmod(frame_number, frames_per_10min)
        if m > drop_frames:
            adjusted = frame_number + (drop_frames * 9 * d) + drop_frames * (
                (m - drop_frames) // frames_per_minute_dropped
            )
        else:
            adjusted = frame_number + drop_frames * 9 * d

        frames = adjusted % fps_nominal
        total_seconds = adjusted // fps_nominal
        seconds = total_seconds % 60
        minutes = (total_seconds // 60) % 60
        hours = ((total_seconds // 60) // 60) % 24

        return cls(hours, minutes, seconds, frames, fps_nominal, drop_frame=True)

    def to_frame_number(self, fps: float) -> int:
        """Inverse of `from_frame_number` -- exact for the same fps/drop_frame."""
        fps_nominal = round(fps)
        total_minutes = self.hours * 60 + self.minutes

        if not self.drop_frame:
            total_seconds = self.hours * 3600 + self.minutes * 60 + self.seconds
            return total_seconds * fps_nominal + self.frames

        drop_frames = round(fps_nominal * 0.066666)
        raw = (
            fps_nominal * 3600 * self.hours
            + fps_nominal * 60 * self.minutes
            + fps_nominal * self.seconds
            + self.frames
        )
        minutes_to_drop = total_minutes - (total_minutes // 10)
        return raw - (drop_frames * minutes_to_drop)
