"""Timeline model and validation.

`validate_timeline` only ever returns warnings/errors -- it never mutates
the timeline to "fix" a problem (spec section 56: "Return warnings instead
of silently modifying projects").
"""

from __future__ import annotations

from dataclasses import dataclass, field

from python_engine.projects.clips import TimelineClip

# Broadcast/delivery frame rates recognised without warning (spec section
# 57). Arbitrary other valid (positive, sane) rates are still accepted --
# just flagged as unusual, never rejected outright.
_COMMON_FRAME_RATES = (
    23.976, 24, 25, 29.97, 30, 50, 59.94, 60, 120,
)


@dataclass(slots=True)
class Marker:
    timestamp: float
    label: str | None = None
    kind: str = "generic"
    confidence: float | None = None  # set only for algorithmically-derived markers


@dataclass(slots=True)
class Timeline:
    frame_rate: float
    resolution: tuple[int, int]
    tracks: int = 1
    clips: list[TimelineClip] = field(default_factory=list)
    markers: list[Marker] = field(default_factory=list)
    is_variable_frame_rate: bool = False

    @property
    def duration(self) -> float:
        if not self.clips:
            return 0.0
        return max(c.timeline_out for c in self.clips)

    def clips_on_track(self, track: int) -> list[TimelineClip]:
        return sorted((c for c in self.clips if c.track == track), key=lambda c: c.timeline_in)


@dataclass(slots=True)
class TimelineValidationResult:
    valid: bool = True
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def add_error(self, message: str) -> None:
        self.errors.append(message)
        self.valid = False

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)


def validate_timeline(
    timeline: Timeline,
    *,
    known_asset_ids: set[str] | None = None,
    asset_resolutions: dict[str, tuple[int, int]] | None = None,
) -> TimelineValidationResult:
    """Check a timeline for overlaps, invalid ranges, missing media,
    invalid frame rates, and resolution mismatches. Never mutates
    `timeline` -- only reports.
    """
    result = TimelineValidationResult()
    known_asset_ids = known_asset_ids or set()
    asset_resolutions = asset_resolutions or {}

    if timeline.frame_rate <= 0:
        result.add_error(f"Invalid timeline frame rate: {timeline.frame_rate}")
    elif not any(abs(timeline.frame_rate - r) < 0.01 for r in _COMMON_FRAME_RATES):
        result.add_warning(
            f"Timeline frame rate {timeline.frame_rate:g} is not a common broadcast/delivery rate"
        )

    if timeline.resolution[0] <= 0 or timeline.resolution[1] <= 0:
        result.add_error(f"Invalid timeline resolution: {timeline.resolution}")

    for clip in timeline.clips:
        _validate_single_clip(clip, result)

        if known_asset_ids and clip.source_asset not in known_asset_ids:
            result.add_error(
                f"Clip {clip.id} references missing media asset {clip.source_asset!r}"
            )

        asset_res = asset_resolutions.get(clip.source_asset)
        if asset_res and asset_res != timeline.resolution:
            result.add_warning(
                f"Clip {clip.id} source resolution {asset_res} differs from "
                f"timeline resolution {timeline.resolution}"
            )

    _validate_overlaps(timeline, result)

    return result


def _validate_single_clip(clip: TimelineClip, result: TimelineValidationResult) -> None:
    if clip.source_out <= clip.source_in:
        result.add_error(
            f"Clip {clip.id} has invalid source range: in={clip.source_in} out={clip.source_out}"
        )
    if clip.timeline_out <= clip.timeline_in:
        result.add_error(
            f"Clip {clip.id} has invalid/negative timeline duration: "
            f"in={clip.timeline_in} out={clip.timeline_out}"
        )
    if clip.timeline_in < 0 or clip.source_in < 0:
        result.add_error(f"Clip {clip.id} has a negative start point")


def _validate_overlaps(timeline: Timeline, result: TimelineValidationResult) -> None:
    by_track: dict[int, list[TimelineClip]] = {}
    for clip in timeline.clips:
        by_track.setdefault(clip.track, []).append(clip)

    for track, clips in by_track.items():
        ordered = sorted(clips, key=lambda c: c.timeline_in)
        for prev, curr in zip(ordered, ordered[1:], strict=False):
            if curr.timeline_in < prev.timeline_out:
                result.add_warning(
                    f"Overlapping clips on track {track}: {prev.id} and {curr.id} "
                    f"overlap by {prev.timeline_out - curr.timeline_in:.3f}s"
                )
