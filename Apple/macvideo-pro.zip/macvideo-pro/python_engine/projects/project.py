"""The `Project` model.

Non-destructive by construction: a `Project` stores only edit decisions
(via `Timeline`/`TimelineClip` -- in/out points, transforms, effects) that
reference source `MediaAsset`s by id. Nothing in this module ever opens a
source media file for writing; trimming, cropping, grading, or reordering
a clip only ever changes numbers in the timeline data structure.
"""

from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime

import orjson
from sqlalchemy import select

from python_engine.database.database import Database
from python_engine.database.models import ProjectRow
from python_engine.projects.clips import Effect, TimelineClip, Transform
from python_engine.projects.timeline import Marker, Timeline


def _now_iso() -> str:
    return datetime.now(tz=UTC).isoformat()


@dataclass(slots=True)
class Project:
    name: str
    timeline: Timeline
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: str = field(default_factory=_now_iso)
    modified_at: str = field(default_factory=_now_iso)
    media_references: set[str] = field(default_factory=set)  # MediaAsset ids used
    export_settings: dict[str, object] = field(default_factory=dict)

    def touch(self) -> None:
        self.modified_at = _now_iso()

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "name": self.name,
            "created_at": self.created_at,
            "modified_at": self.modified_at,
            "media_references": sorted(self.media_references),
            "export_settings": self.export_settings,
            "timeline": _timeline_to_dict(self.timeline),
        }

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> "Project":
        return cls(
            id=str(data["id"]),
            name=str(data["name"]),
            created_at=str(data["created_at"]),
            modified_at=str(data["modified_at"]),
            media_references=set(data.get("media_references", [])),  # type: ignore[arg-type]
            export_settings=dict(data.get("export_settings", {})),  # type: ignore[arg-type]
            timeline=_timeline_from_dict(data["timeline"]),  # type: ignore[arg-type]
        )


def _timeline_to_dict(timeline: Timeline) -> dict[str, object]:
    return {
        "frame_rate": timeline.frame_rate,
        "resolution": list(timeline.resolution),
        "tracks": timeline.tracks,
        "is_variable_frame_rate": timeline.is_variable_frame_rate,
        "clips": [_clip_to_dict(c) for c in timeline.clips],
        "markers": [asdict(m) for m in timeline.markers],
    }


def _timeline_from_dict(data: dict[str, object]) -> Timeline:
    return Timeline(
        frame_rate=float(data["frame_rate"]),  # type: ignore[arg-type]
        resolution=tuple(data["resolution"]),  # type: ignore[arg-type]
        tracks=int(data.get("tracks", 1)),  # type: ignore[arg-type]
        is_variable_frame_rate=bool(data.get("is_variable_frame_rate", False)),
        clips=[_clip_from_dict(c) for c in data.get("clips", [])],  # type: ignore[arg-type]
        markers=[Marker(**m) for m in data.get("markers", [])],  # type: ignore[arg-type]
    )


def _clip_to_dict(clip: TimelineClip) -> dict[str, object]:
    d = asdict(clip)
    return d


def _clip_from_dict(data: dict[str, object]) -> TimelineClip:
    transform_data = data.get("transform", {})
    effects_data = data.get("effects", [])
    return TimelineClip(
        id=str(data.get("id") or uuid.uuid4()),
        source_asset=str(data["source_asset"]),
        source_in=float(data["source_in"]),  # type: ignore[arg-type]
        source_out=float(data["source_out"]),  # type: ignore[arg-type]
        timeline_in=float(data["timeline_in"]),  # type: ignore[arg-type]
        timeline_out=float(data["timeline_out"]),  # type: ignore[arg-type]
        track=int(data.get("track", 0)),  # type: ignore[arg-type]
        transform=Transform(**transform_data),  # type: ignore[arg-type]
        effects=[Effect(**e) for e in effects_data],  # type: ignore[arg-type]
        audio_gain=float(data.get("audio_gain", 0.0)),  # type: ignore[arg-type]
    )


def save_project(database: Database, project: Project) -> str:
    """Persist a project. Only ever writes the project/timeline/edit-decision
    data -- never touches any file referenced by `media_references`."""
    project.touch()
    payload = orjson.dumps(_timeline_to_dict(project.timeline)).decode()
    export_payload = orjson.dumps(project.export_settings).decode()

    with database.session() as session:
        row = session.scalar(select(ProjectRow).where(ProjectRow.id == project.id))
        if row is None:
            row = ProjectRow(id=project.id, name=project.name, created_at=project.created_at)
            session.add(row)
        row.name = project.name
        row.modified_at = project.modified_at
        row.timeline_json = payload
        row.export_settings_json = export_payload
        session.flush()
        return row.id


def load_project(database: Database, project_id: str) -> Project | None:
    with database.session() as session:
        row = session.scalar(select(ProjectRow).where(ProjectRow.id == project_id))
        if row is None:
            return None
        timeline = _timeline_from_dict(orjson.loads(row.timeline_json)) if row.timeline_json else Timeline(
            frame_rate=30.0, resolution=(1920, 1080)
        )
        export_settings = orjson.loads(row.export_settings_json) if row.export_settings_json else {}
        return Project(
            id=row.id,
            name=row.name,
            created_at=row.created_at,
            modified_at=row.modified_at,
            timeline=timeline,
            export_settings=export_settings,
            media_references={c.source_asset for c in timeline.clips},
        )
