"""The `TimelineClip` model (spec section 54).

A clip is purely an edit decision -- in/out points, placement, transform,
effects -- referencing a source asset by id. Nothing here ever touches the
source media file itself (see spec section 55, non-destructive editing).
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field


@dataclass(slots=True)
class Transform:
    scale_x: float = 1.0
    scale_y: float = 1.0
    position_x: float = 0.0
    position_y: float = 0.0
    rotation_degrees: float = 0.0
    crop_left: float = 0.0
    crop_right: float = 0.0
    crop_top: float = 0.0
    crop_bottom: float = 0.0


@dataclass(slots=True)
class Effect:
    kind: str  # e.g. "lut", "colour_correction", "blur" -- opaque to the engine
    parameters: dict[str, object] = field(default_factory=dict)
    enabled: bool = True


@dataclass(slots=True)
class TimelineClip:
    source_asset: str  # MediaAsset.id -- a reference, never a copy of the media
    source_in: float
    source_out: float
    timeline_in: float
    timeline_out: float
    track: int = 0
    transform: Transform = field(default_factory=Transform)
    effects: list[Effect] = field(default_factory=list)
    audio_gain: float = 0.0  # dB
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    @property
    def source_duration(self) -> float:
        return self.source_out - self.source_in

    @property
    def timeline_duration(self) -> float:
        return self.timeline_out - self.timeline_in

    @property
    def speed_ratio(self) -> float:
        """>1.0 means the clip plays faster than its source (time-remapped)."""
        if self.timeline_duration <= 0:
            return 1.0
        return self.source_duration / self.timeline_duration
