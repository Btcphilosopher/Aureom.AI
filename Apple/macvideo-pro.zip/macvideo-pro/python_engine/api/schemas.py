"""Request/response schemas for the Swift <-> Python command API.

Every command request/response is a pydantic model, so malformed input
from the native layer is rejected with a clear validation error instead
of causing an obscure downstream failure.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

CommandName = Literal[
    "scan",
    "inspect",
    "thumbnail",
    "analyse",
    "proxy",
    "transcode",
    "export",
    "search",
    "project",
    "health",
    "job_status",
    "job_cancel",
    "job_pause",
    "job_resume",
    "system_capabilities",
    "dashboard",
]


class CommandRequest(BaseModel):
    command: CommandName
    request_id: str | None = None
    params: dict[str, Any] = Field(default_factory=dict)


class CommandError(BaseModel):
    code: str
    message: str


class CommandResponse(BaseModel):
    request_id: str | None = None
    ok: bool
    result: dict[str, Any] | list[Any] | None = None
    error: CommandError | None = None


class ScanParams(BaseModel):
    folder: str
    recursive: bool = True
    max_concurrency: int = 8


class InspectParams(BaseModel):
    path: str


class ThumbnailParams(BaseModel):
    path: str
    timestamp: float
    output: str
    max_width: int = 640
    max_height: int = 360


class ProxyParams(BaseModel):
    source: str
    destination: str
    profile_name: str = "1080p H.264"
    priority: Literal["REALTIME", "HIGH", "NORMAL", "LOW", "BACKGROUND"] = "NORMAL"


class TranscodeParams(BaseModel):
    source: str
    destination: str
    preset_name: str
    priority: Literal["REALTIME", "HIGH", "NORMAL", "LOW", "BACKGROUND"] = "NORMAL"


class SearchParams(BaseModel):
    text: str | None = None
    resolution: str | None = None
    codec: str | None = None
    min_duration: float | None = None
    max_duration: float | None = None
    hdr: bool | None = None
    limit: int = 500


class HealthParams(BaseModel):
    paths: list[str]


class JobIdParams(BaseModel):
    job_id: str
