"""Local IPC server: newline-delimited JSON commands over a Unix domain socket.

This is deliberately **not** a network service -- `asyncio.start_unix_server`
binds to a filesystem path, not a TCP port, so there is nothing here for a
remote host to connect to regardless of firewall configuration. The socket
file is created with owner-only permissions.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import Any, Awaitable, Callable

import orjson
from pydantic import ValidationError as PydanticValidationError

from python_engine.api.schemas import CommandError, CommandRequest, CommandResponse
from python_engine.core.errors import MacVideoError
from python_engine.core.logging import get_logger
from python_engine.database.database import Database
from python_engine.jobs.manager import JobManager, JobPriority
from python_engine.library.health import run_health_scan
from python_engine.library.manager import LibraryManager, dashboard_data
from python_engine.library.search import MediaQuery, search_media
from python_engine.media.inspector import inspect_media
from python_engine.media.scanner import scan_folder
from python_engine.core.capabilities import detect_system_capabilities
from python_engine.thumbnails.generator import generate_thumbnail
from python_engine.transcoding.presets import get_preset
from python_engine.transcoding.queue import ExportQueue
from python_engine.projects.project import Project, load_project, save_project
from python_engine.projects.timeline import Timeline
from python_engine.video.colour import analyse_colour
from python_engine.video.frames import FrameReader
from python_engine.video.histogram import calculate_histogram, histogram_to_dict

_log = get_logger("api.ipc")

Handler = Callable[[dict[str, Any]], Awaitable[dict[str, Any] | list[Any]]]


class IPCServer:
    def __init__(
        self,
        socket_path: str,
        *,
        database: Database,
        job_manager: JobManager,
        export_queue: ExportQueue,
    ) -> None:
        self.socket_path = Path(socket_path)
        self.database = database
        self.job_manager = job_manager
        self.export_queue = export_queue
        self.library_manager = LibraryManager(database)
        self._server: asyncio.base_events.Server | None = None
        self._handlers: dict[str, Handler] = {
            "scan": self._cmd_scan,
            "inspect": self._cmd_inspect,
            "thumbnail": self._cmd_thumbnail,
            "analyse": self._cmd_analyse,
            "proxy": self._cmd_proxy,
            "transcode": self._cmd_transcode,
            "export": self._cmd_transcode,
            "search": self._cmd_search,
            "project": self._cmd_project,
            "health": self._cmd_health,
            "job_status": self._cmd_job_status,
            "job_cancel": self._cmd_job_cancel,
            "job_pause": self._cmd_job_pause,
            "job_resume": self._cmd_job_resume,
            "system_capabilities": self._cmd_system_capabilities,
            "dashboard": self._cmd_dashboard,
        }

    async def start(self) -> None:
        if self.socket_path.exists():
            self.socket_path.unlink()
        self.socket_path.parent.mkdir(parents=True, exist_ok=True)

        self._server = await asyncio.start_unix_server(self._handle_client, path=str(self.socket_path))
        # Owner-only permissions: this is a local trust boundary, not a
        # network-facing service.
        os.chmod(self.socket_path, 0o600)
        _log.info("IPC server listening", extra={"context": {"socket": str(self.socket_path)}})

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
        if self.socket_path.exists():
            self.socket_path.unlink()

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                response = await self._process_line(line)
                try:
                    payload = orjson.dumps(response.model_dump()) + b"\n"
                except TypeError as exc:
                    # A handler returned something not JSON-serialisable
                    # (e.g. non-string dict keys). This is a bug in that
                    # handler, but it must not kill the connection or the
                    # server -- report it as an internal error instead.
                    _log.error(
                        "response serialisation failed",
                        extra={"context": {"error": str(exc)}},
                    )
                    fallback = CommandResponse(
                        request_id=response.request_id,
                        ok=False,
                        error=CommandError(code="serialization_error", message=str(exc)),
                    )
                    payload = orjson.dumps(fallback.model_dump()) + b"\n"
                writer.write(payload)
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError):
            pass
        finally:
            writer.close()

    async def _process_line(self, line: bytes) -> CommandResponse:
        request_id = None
        try:
            raw = orjson.loads(line)
            request = CommandRequest.model_validate(raw)
            request_id = request.request_id
        except (orjson.JSONDecodeError, PydanticValidationError) as exc:
            return CommandResponse(
                request_id=request_id,
                ok=False,
                error=CommandError(code="invalid_request", message=str(exc)),
            )

        handler = self._handlers.get(request.command)
        if handler is None:
            return CommandResponse(
                request_id=request.request_id,
                ok=False,
                error=CommandError(code="unknown_command", message=f"Unknown command: {request.command}"),
            )

        try:
            result = await handler(request.params)
            return CommandResponse(request_id=request.request_id, ok=True, result=result)
        except MacVideoError as exc:
            return CommandResponse(
                request_id=request.request_id,
                ok=False,
                error=CommandError(code=type(exc).__name__, message=str(exc)),
            )
        except Exception as exc:  # noqa: BLE001 - a bad request must not crash the IPC server
            _log.error("unhandled IPC command error", extra={"context": {"error": str(exc)}})
            return CommandResponse(
                request_id=request.request_id,
                ok=False,
                error=CommandError(code="internal_error", message=str(exc)),
            )

    # -- command handlers -------------------------------------------------

    async def _cmd_scan(self, params: dict[str, Any]) -> dict[str, Any]:
        result = await scan_folder(
            params["folder"],
            max_concurrency=int(params.get("max_concurrency", 8)),
            recursive=bool(params.get("recursive", True)),
        )
        self.library_manager.upsert_many(result.assets)
        return {
            "files_examined": result.files_examined,
            "assets_found": len(result.assets),
            "unreadable": result.unreadable,
        }

    async def _cmd_inspect(self, params: dict[str, Any]) -> dict[str, Any]:
        return inspect_media(params["path"])

    async def _cmd_thumbnail(self, params: dict[str, Any]) -> dict[str, Any]:
        output = generate_thumbnail(
            params["path"],
            float(params["timestamp"]),
            params["output"],
            max_size=(int(params.get("max_width", 640)), int(params.get("max_height", 360))),
        )
        return {"output": str(output)}

    async def _cmd_analyse(self, params: dict[str, Any]) -> dict[str, Any]:
        """Spec section 61: 8K frame analysis API.

        Decodes exactly one frame (via `FrameReader`) regardless of source
        resolution, then runs the real colour/histogram analysis over it.
        """
        with FrameReader(params["path"]) as reader:
            frame = reader.read_frame(float(params["timestamp"]))

        colour = analyse_colour(frame)
        histogram = histogram_to_dict(calculate_histogram(frame))

        return {
            "resolution": [frame.shape[1], frame.shape[0]],
            "mean_luminance": colour.mean_luminance / 255.0,
            "highlight_clipping": colour.highlight_clipping_percent / 100.0,
            "shadow_clipping": colour.shadow_clipping_percent / 100.0,
            "histogram": histogram,
            "colour_statistics": {
                "mean_r": colour.mean_r,
                "mean_g": colour.mean_g,
                "mean_b": colour.mean_b,
                "min_luminance": colour.min_luminance,
                "max_luminance": colour.max_luminance,
                "percentiles": {str(k): v for k, v in colour.percentiles.items()},
            },
        }

    async def _cmd_proxy(self, params: dict[str, Any]) -> dict[str, Any]:
        priority = JobPriority[params.get("priority", "NORMAL")]
        job_id = self.job_manager.submit(
            "proxy",
            {
                "source": params["source"],
                "destination": params["destination"],
                "profile_name": params.get("profile_name", "1080p H.264"),
                "video_codec": "h264",
                "container": "mov",
                "max_width": 1920,
                "max_height": 1080,
                "video_bitrate": "8M",
            },
            priority=priority,
        )
        return {"job_id": job_id, "status": "queued"}

    async def _cmd_transcode(self, params: dict[str, Any]) -> dict[str, Any]:
        preset = get_preset(params["preset_name"])
        if preset is None:
            raise MacVideoError(f"Unknown preset: {params['preset_name']!r}")
        priority = JobPriority[params.get("priority", "NORMAL")]
        job_id = self.export_queue.queue_export(
            params["source"], params["destination"], preset, priority=priority
        )
        return {"job_id": job_id, "status": "queued"}

    async def _cmd_search(self, params: dict[str, Any]) -> list[dict[str, Any]]:
        query = MediaQuery(
            text=params.get("text"),
            resolution=params.get("resolution"),
            codec=params.get("codec"),
            min_duration=params.get("min_duration"),
            max_duration=params.get("max_duration"),
            hdr=params.get("hdr"),
            limit=int(params.get("limit", 500)),
        )
        rows = search_media(self.database, query)
        return [{"id": r.id, "path": r.path, "filename": r.filename, "resolution_class": r.resolution_class} for r in rows]

    async def _cmd_project(self, params: dict[str, Any]) -> dict[str, Any]:
        action = params.get("action", "load")
        if action == "save":
            timeline = Timeline(
                frame_rate=float(params["frame_rate"]),
                resolution=tuple(params["resolution"]),
            )
            project_kwargs: dict[str, Any] = {"name": params["name"], "timeline": timeline}
            if params.get("project_id"):
                project_kwargs["id"] = params["project_id"]
            project = Project(**project_kwargs)
            project_id = save_project(self.database, project)
            return {"project_id": project_id}
        elif action == "load":
            project = load_project(self.database, params["project_id"])
            if project is None:
                raise MacVideoError(f"No such project: {params['project_id']}")
            return project.to_dict()
        else:
            raise MacVideoError(f"Unknown project action: {action!r}")

    async def _cmd_health(self, params: dict[str, Any]) -> list[dict[str, Any]]:
        reports = await run_health_scan(params["paths"])
        return [
            {"path": r.path, "status": r.status.value, "issues": [i.value for i in r.issues], "detail": r.detail}
            for r in reports
        ]

    async def _cmd_job_status(self, params: dict[str, Any]) -> dict[str, Any]:
        status = self.job_manager.get_status(params["job_id"])
        if status is None:
            raise MacVideoError(f"No such job: {params['job_id']}")
        return status

    async def _cmd_job_cancel(self, params: dict[str, Any]) -> dict[str, Any]:
        ok = self.job_manager.cancel(params["job_id"])
        return {"cancelled": ok}

    async def _cmd_job_pause(self, params: dict[str, Any]) -> dict[str, Any]:
        ok = self.job_manager.pause(params["job_id"])
        return {"paused": ok}

    async def _cmd_job_resume(self, params: dict[str, Any]) -> dict[str, Any]:
        ok = self.job_manager.resume(params["job_id"])
        return {"resumed": ok}

    async def _cmd_system_capabilities(self, params: dict[str, Any]) -> dict[str, Any]:
        from dataclasses import asdict

        caps = detect_system_capabilities()
        return {
            "cpu": asdict(caps.cpu),
            "memory": asdict(caps.memory),
            "gpu": asdict(caps.gpu),
            "os_name": caps.os_name,
            "os_version": caps.os_version,
            "python_version": caps.python_version,
            "ffmpeg_version": caps.ffmpeg_version,
            "ffprobe_version": caps.ffprobe_version,
        }

    async def _cmd_dashboard(self, params: dict[str, Any]) -> dict[str, Any]:
        return dashboard_data(self.database)
