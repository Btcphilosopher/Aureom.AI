"""AI metadata suggestions.

Returns *suggestions* only (spec section 69) -- nothing here writes back
into `MediaAsset` or the library database. Suggestions are derived from
real measured properties of the asset (resolution, codec, HDR flag, scene
markers) rather than a generative model (none is bundled -- see
`ai.transcription` for the same honesty principle applied to ASR). This
keeps the module genuinely useful without pretending to have language
generation it doesn't have.
"""

from __future__ import annotations

from dataclasses import dataclass

from python_engine.ai.engine import MediaAIEngine, ProcessingBackend, ProcessingStatus
from python_engine.media.metadata import MediaAsset
from python_engine.video.analysis import classify_resolution
from python_engine.video.scenes import SceneMarker


@dataclass(frozen=True, slots=True)
class ChapterSuggestion:
    timestamp: float
    label: str


@dataclass(frozen=True, slots=True)
class MetadataSuggestions:
    title: str | None
    description: str | None
    keywords: list[str]
    chapters: list[ChapterSuggestion]
    status: ProcessingStatus

    def to_dict(self) -> dict[str, object]:
        return {
            "title": self.title,
            "description": self.description,
            "keywords": self.keywords,
            "chapters": [{"timestamp": c.timestamp, "label": c.label} for c in self.chapters],
        }


def suggest_metadata(
    engine: MediaAIEngine,
    asset: MediaAsset,
    *,
    scene_markers: list[SceneMarker] | None = None,
) -> MetadataSuggestions:
    """Derive metadata suggestions from real, already-measured asset properties.

    Never invents facts not present in `asset`/`scene_markers` -- e.g. it
    will not guess subject matter it has no data for.
    """
    engine.require_enabled()

    keywords: list[str] = []
    if asset.width and asset.height:
        keywords.append(classify_resolution(asset.width, asset.height))
    if asset.video_codec:
        keywords.append(asset.video_codec.upper())
    if asset.hdr:
        keywords.append("HDR")
    if asset.streams.primary_video and asset.streams.primary_video.is_variable_frame_rate:
        keywords.append("VFR")
    if asset.frame_rate:
        keywords.append(f"{asset.frame_rate:g}fps")

    title = asset.filename.rsplit(".", 1)[0].replace("_", " ").replace("-", " ").strip() or None

    description_parts = []
    if asset.duration_seconds:
        minutes = int(asset.duration_seconds // 60)
        seconds = int(asset.duration_seconds % 60)
        description_parts.append(f"{minutes}m {seconds}s")
    if asset.width and asset.height:
        description_parts.append(f"{asset.width}x{asset.height}")
    if asset.video_codec:
        description_parts.append(asset.video_codec.upper())
    description = ", ".join(description_parts) or None

    chapters = [
        ChapterSuggestion(timestamp=m.timestamp, label=f"Scene at {m.timestamp:.1f}s")
        for m in (scene_markers or [])
    ]

    status = ProcessingStatus(backend=ProcessingBackend.LOCAL, model_name="metadata-heuristics-v1")
    return MetadataSuggestions(
        title=title,
        description=description,
        keywords=keywords,
        chapters=chapters,
        status=status,
    )
