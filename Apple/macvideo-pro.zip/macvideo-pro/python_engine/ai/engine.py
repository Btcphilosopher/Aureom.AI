"""MediaAIEngine: the optional AI/ML layer.

**Privacy model (spec section 71), enforced structurally, not just by
convention:**
  - `MediaAIEngine` refuses to run any analysis unless
    `MediaEngineConfig.enable_ai` is explicitly `True`.
  - Nothing is uploaded anywhere by default. A *separate* explicit flag,
    `MediaEngineConfig.ai_allow_remote`, must also be `True` before any
    remote-backed module is even reachable -- local processing is the
    only path available otherwise.
  - Every module reports a `visible processing status` (which backend ran,
    local or remote) alongside its results, so nothing happens silently.
  - AI outputs are always framed as suggestions (spec section 69) --
    nothing in this package writes back into `MediaAsset`/library metadata
    on its own; callers decide whether to accept a suggestion.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from python_engine.core.config import MediaEngineConfig
from python_engine.core.errors import ConfigurationError


class ProcessingBackend(StrEnum):
    LOCAL = "local"
    REMOTE = "remote"


@dataclass(frozen=True, slots=True)
class ProcessingStatus:
    backend: ProcessingBackend
    model_name: str
    remote_service: str | None = None  # populated only when backend == REMOTE


class MediaAIEngine:
    """Gate + registry for AI/ML modules. Modules themselves live in
    `ai.scenes`, `ai.transcription`, `ai.metadata` and are only ever
    reachable through an instance of this class, which enforces the
    enable_ai / ai_allow_remote gates before dispatching to them."""

    def __init__(self, config: MediaEngineConfig) -> None:
        self.config = config

    def require_enabled(self) -> None:
        if not self.config.enable_ai:
            raise ConfigurationError(
                "AI/ML features are disabled (MediaEngineConfig.enable_ai is False). "
                "AI is opt-in and must be explicitly enabled before any AI module runs."
            )

    def require_remote_allowed(self) -> None:
        self.require_enabled()
        if not self.config.ai_allow_remote:
            raise ConfigurationError(
                "Remote AI processing is not permitted (ai_allow_remote is False). "
                "MACVIDEO.PRO defaults to fully local AI processing; remote services "
                "require explicit, separate opt-in."
            )
