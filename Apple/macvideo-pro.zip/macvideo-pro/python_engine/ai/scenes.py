"""AI-assisted scene analysis.

The boundary detection itself reuses the real, deterministic
`video.scenes.detect_scenes` (frame-difference based) -- this module adds
duration/statistics on top and clearly labels everything as an
algorithmic estimate. No semantic description is fabricated: a
`semantic_description` field exists in the result shape (spec section 70)
but is only ever populated by a real pluggable classifier backend: with
none configured, it stays `None` rather than inventing plausible-sounding
text.
"""

from __future__ import annotations

from dataclasses import dataclass

from python_engine.ai.engine import MediaAIEngine, ProcessingBackend, ProcessingStatus
from python_engine.video.scenes import SceneMarker, detect_scenes


@dataclass(frozen=True, slots=True)
class AIScene:
    start: float
    end: float
    duration: float
    confidence: float  # ALGORITHMIC ESTIMATE
    semantic_description: str | None = None  # only set by a real configured classifier

    def to_dict(self) -> dict[str, object]:
        return {
            "start": self.start,
            "end": self.end,
            "duration": self.duration,
            "confidence": self.confidence,
            "semantic_description": self.semantic_description,
        }


@dataclass(frozen=True, slots=True)
class AISceneAnalysisResult:
    scenes: list[AIScene]
    status: ProcessingStatus


def analyse_scenes(
    engine: MediaAIEngine,
    video: str,
    *,
    sample_interval_seconds: float = 0.5,
    threshold: float = 0.12,
) -> AISceneAnalysisResult:
    """Return scene boundaries/durations/confidence (spec section 70).

    Requires `engine.config.enable_ai` -- raises `ConfigurationError`
    otherwise (this call is gated even though the underlying detector is
    the same deterministic algorithm used elsewhere, to keep one
    consistent AI on/off switch for anything under the `ai/` package).
    """
    engine.require_enabled()

    markers: list[SceneMarker] = detect_scenes(
        video, sample_interval_seconds=sample_interval_seconds, threshold=threshold
    )

    scenes: list[AIScene] = []
    for i, marker in enumerate(markers):
        end = markers[i + 1].timestamp if i + 1 < len(markers) else marker.timestamp
        scenes.append(
            AIScene(
                start=marker.timestamp,
                end=end,
                duration=max(0.0, end - marker.timestamp),
                confidence=marker.confidence,
            )
        )

    status = ProcessingStatus(backend=ProcessingBackend.LOCAL, model_name="frame-diff-heuristic-v1")
    return AISceneAnalysisResult(scenes=scenes, status=status)
