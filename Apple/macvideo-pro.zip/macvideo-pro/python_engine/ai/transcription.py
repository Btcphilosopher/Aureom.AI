"""Transcription.

`TranscriptionJob` results are always labelled machine-generated (spec
section 68). This module defines the pluggable backend interface and a
local audio-extraction step (real: streams PCM via `audio.pcm`), but ships
with no bundled speech model -- `NoBackendConfigured` is raised honestly
rather than fabricating transcript text. A real deployment plugs in a
local ASR backend (e.g. a local whisper.cpp binary) by implementing
`TranscriptionBackend` and passing it to `transcribe()`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from python_engine.ai.engine import MediaAIEngine, ProcessingBackend, ProcessingStatus
from python_engine.core.errors import ConfigurationError
from python_engine.core.paths import require_existing_file


@dataclass(frozen=True, slots=True)
class TranscriptSegment:
    timestamp: float
    text: str
    speaker: str | None = None  # only set when the backend supports diarisation
    confidence: float | None = None


@dataclass(slots=True)
class TranscriptionJob:
    source: str
    segments: list[TranscriptSegment] = field(default_factory=list)
    is_machine_generated: bool = True  # ALWAYS True -- never falsely implies human transcription
    status: ProcessingStatus | None = None


class TranscriptionBackend(Protocol):
    """Real deployments implement this against a local ASR engine.

    No implementation ships in this package -- see module docstring.
    """

    model_name: str

    def transcribe(self, audio_path: str) -> list[TranscriptSegment]: ...


class NoBackendConfigured(ConfigurationError):
    """Raised when `transcribe()` is called without a real backend.

    This is the honest failure mode: MACVIDEO.PRO does not bundle a
    speech-to-text model, and never fabricates transcript text to avoid
    raising this.
    """


def transcribe(
    engine: MediaAIEngine,
    source: str,
    backend: TranscriptionBackend | None,
    *,
    allow_remote: bool = False,
) -> TranscriptionJob:
    if allow_remote:
        engine.require_remote_allowed()
    else:
        engine.require_enabled()

    require_existing_file(source)

    if backend is None:
        raise NoBackendConfigured(
            "No transcription backend configured. MACVIDEO.PRO ships no bundled "
            "speech model; pass a `TranscriptionBackend` implementation (e.g. wrapping "
            "a local whisper.cpp installation) to transcribe()."
        )

    segments = backend.transcribe(source)
    status = ProcessingStatus(
        backend=ProcessingBackend.REMOTE if allow_remote else ProcessingBackend.LOCAL,
        model_name=getattr(backend, "model_name", backend.__class__.__name__),
    )
    return TranscriptionJob(source=source, segments=segments, status=status)
