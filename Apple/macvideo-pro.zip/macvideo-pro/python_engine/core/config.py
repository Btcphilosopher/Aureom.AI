"""Engine-wide configuration.

`MediaEngineConfig` never hard-codes memory pools. `worker_count` and any
memory ceiling are resolved lazily against the machine the engine is
actually running on (see `resolved_worker_count` / `MemoryBudget` in
`video.frames`), so the same config works on a 8GB Mac mini and a 128GB
Mac Studio without editing constants.
"""

from __future__ import annotations

import os
from pathlib import Path

import psutil
from pydantic import BaseModel, Field, field_validator

from python_engine.core.errors import ConfigurationError

DEFAULT_MAX_RESOLUTION = (7680, 4320)  # 8K UHD ceiling this engine plans around.
DEFAULT_THUMBNAIL_SIZE = (640, 360)
DEFAULT_PROXY_RESOLUTION = (1920, 1080)


class MediaEngineConfig(BaseModel):
    """Runtime configuration for the whole Python engine.

    Any field left as `None` is resolved dynamically at first use rather
    than defaulted to a fixed constant (see `resolved_*` helpers below).
    """

    max_resolution: tuple[int, int] = Field(default=DEFAULT_MAX_RESOLUTION)
    thumbnail_size: tuple[int, int] = Field(default=DEFAULT_THUMBNAIL_SIZE)

    # Ceiling on how much of *system* RAM the engine is allowed to target
    # across all concurrent jobs. This is a percentage, not a byte count,
    # because it must scale with whatever machine it runs on.
    max_memory_percent: float = Field(default=70.0, gt=0, le=95)

    # None => resolved dynamically from CPU/RAM at call time (see
    # `resolved_worker_count`). Never spawn unlimited workers.
    worker_count: int | None = None

    cache_directory: Path | None = None
    proxy_resolution: tuple[int, int] = Field(default=DEFAULT_PROXY_RESOLUTION)

    # AI is opt-in and defaults to fully local processing. See ai/ package.
    enable_ai: bool = False
    ai_allow_remote: bool = False  # Explicit, separate opt-in for any cloud AI.

    enable_gpu_analysis: bool = True

    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"

    database_path: Path | None = None

    @field_validator("max_resolution", "proxy_resolution", "thumbnail_size")
    @classmethod
    def _positive_dims(cls, value: tuple[int, int]) -> tuple[int, int]:
        w, h = value
        if w <= 0 or h <= 0:
            raise ValueError(f"Resolution dimensions must be positive, got {value}")
        return value

    def resolved_cache_directory(self) -> Path:
        if self.cache_directory is not None:
            path = self.cache_directory
        else:
            path = Path(
                os.environ.get(
                    "MACVIDEO_CACHE_DIR",
                    str(Path.home() / "Library" / "Caches" / "MacVideoPro"),
                )
            )
        path.mkdir(parents=True, exist_ok=True)
        return path

    def resolved_database_path(self) -> Path:
        if self.database_path is not None:
            return self.database_path
        return self.resolved_cache_directory() / "macvideo.sqlite3"

    def resolved_worker_count(self, *, reserve_for_system: int = 1) -> int:
        """Determine a worker count from *this* machine's CPU count.

        Never returns fewer than 1, never blindly returns `os.cpu_count()`
        unmodified for heavy jobs (callers like ProcessingPool further
        scale this down for 8K-class work).
        """
        if self.worker_count is not None:
            if self.worker_count < 1:
                raise ConfigurationError("worker_count must be >= 1 if set")
            return self.worker_count

        cpu_count = os.cpu_count() or 1
        return max(1, cpu_count - reserve_for_system)

    def available_memory_bytes(self) -> int:
        """Currently available (not just total) system RAM, in bytes."""
        return psutil.virtual_memory().available

    def memory_ceiling_bytes(self) -> int:
        """Bytes the engine should treat as its working ceiling right now.

        Based on *available* memory (not total), scaled by
        `max_memory_percent`. Re-evaluated on every call since available RAM
        changes constantly as other apps (and the encoder) run.
        """
        total = psutil.virtual_memory().total
        by_percent_of_total = int(total * (self.max_memory_percent / 100.0))
        available_now = psutil.virtual_memory().available
        # Never claim more than what is actually free right now.
        return max(0, min(by_percent_of_total, available_now))

    model_config = {"frozen": False, "arbitrary_types_allowed": True}
