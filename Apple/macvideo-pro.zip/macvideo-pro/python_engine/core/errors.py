"""Custom exception hierarchy for the MACVIDEO.PRO Python engine.

A failed or malformed media file must never be allowed to crash the whole
service. Every module that touches external media, external processes, or
project/database state should raise one of these instead of letting a bare
exception (or, worse, a `subprocess` non-zero exit) propagate unhandled.
"""

from __future__ import annotations


class MacVideoError(Exception):
    """Base class for every error raised by the MACVIDEO.PRO engine."""


class MediaError(MacVideoError):
    """Generic error tied to a specific media asset/path."""

    def __init__(self, message: str, *, path: str | None = None) -> None:
        self.path = path
        if path:
            message = f"{message} (path={path!r})"
        super().__init__(message)


class DecodeError(MediaError):
    """Raised when a frame, stream, or file could not be decoded."""


class EncodeError(MediaError):
    """Raised when transcoding/proxy/export encoding fails."""


class InspectionError(MediaError):
    """Raised when ffprobe / media inspection fails or returns unusable data."""


class UnsupportedMediaError(MediaError):
    """Raised when a container/codec is not supported by the installed backend."""


class StorageError(MacVideoError):
    """Raised for filesystem, disk-space, or volume-related failures."""


class ProjectError(MacVideoError):
    """Raised for project/timeline/clip consistency failures."""


class ValidationError(MacVideoError):
    """Raised when validation fails and the caller must not proceed.

    Distinct from `pydantic.ValidationError` (schema shape); this is for
    domain-level validation such as export settings or timeline integrity.
    """

    def __init__(self, message: str, *, errors: list[str] | None = None) -> None:
        self.errors = errors or [message]
        super().__init__(message)


class JobError(MacVideoError):
    """Raised for job-queue/orchestration failures."""


class JobCancelledError(JobError):
    """Raised internally to unwind a job cleanly when cancellation is requested."""


class ExternalToolError(MacVideoError):
    """Raised when an external executable (ffmpeg/ffprobe) is missing or fails.

    Carries the command, return code, and captured stderr so callers/logs get
    a real diagnostic instead of a bare non-zero exit.
    """

    def __init__(
        self,
        message: str,
        *,
        command: list[str] | None = None,
        returncode: int | None = None,
        stderr: str | None = None,
    ) -> None:
        self.command = command or []
        self.returncode = returncode
        self.stderr = stderr
        super().__init__(message)


class ConfigurationError(MacVideoError):
    """Raised when engine configuration is invalid or inconsistent."""
