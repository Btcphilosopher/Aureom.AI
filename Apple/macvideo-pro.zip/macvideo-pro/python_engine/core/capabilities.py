"""System capability detection.

Reports what's actually present on the running machine -- CPU, RAM, GPU
info where accessible, storage, OS, Python, and media backend versions.
Never assumes Apple Silicon (or any particular platform); fields that
can't be determined on the current platform/backend are `None` rather
than guessed.
"""

from __future__ import annotations

import platform
import sys
from dataclasses import dataclass

import psutil

from python_engine.core.errors import ExternalToolError
from python_engine.core.external import run_external


@dataclass(frozen=True, slots=True)
class CpuInfo:
    physical_cores: int | None
    logical_cores: int | None
    architecture: str
    processor: str


@dataclass(frozen=True, slots=True)
class MemoryInfo:
    total_bytes: int
    available_bytes: int


@dataclass(frozen=True, slots=True)
class GpuInfo:
    """Best-effort GPU description. Python does not control the GPU
    pipeline (see spec section 94) -- this is informational only, used to
    decide whether to advertise `enable_gpu_analysis` as meaningful, never
    to claim direct GPU access."""

    description: str | None
    apple_silicon_unified_memory: bool


@dataclass(frozen=True, slots=True)
class SystemCapabilities:
    cpu: CpuInfo
    memory: MemoryInfo
    gpu: GpuInfo
    os_name: str
    os_version: str
    python_version: str
    ffmpeg_version: str | None
    ffprobe_version: str | None


def _detect_gpu() -> GpuInfo:
    machine = platform.machine().lower()
    is_apple_silicon = platform.system() == "Darwin" and machine in {"arm64", "aarch64"}

    description = None
    if platform.system() == "Darwin":
        try:
            result = run_external(
                ["system_profiler", "SPDisplaysDataType", "-json"], timeout=5, check=False
            )
            if result.returncode == 0:
                description = "Detected via system_profiler (see raw output for detail)"
        except ExternalToolError:
            description = None

    return GpuInfo(description=description, apple_silicon_unified_memory=is_apple_silicon)


def _tool_version(executable: str, *version_flag: str) -> str | None:
    try:
        result = run_external([executable, *version_flag], timeout=5, check=False)
    except ExternalToolError:
        return None
    if result.returncode != 0:
        return None
    first_line = result.stdout.decode("utf-8", errors="replace").splitlines()
    return first_line[0].strip() if first_line else None


def detect_system_capabilities(
    ffmpeg_path: str = "ffmpeg", ffprobe_path: str = "ffprobe"
) -> SystemCapabilities:
    vm = psutil.virtual_memory()

    cpu = CpuInfo(
        physical_cores=psutil.cpu_count(logical=False),
        logical_cores=psutil.cpu_count(logical=True),
        architecture=platform.machine(),
        processor=platform.processor() or platform.machine(),
    )
    memory = MemoryInfo(total_bytes=vm.total, available_bytes=vm.available)
    gpu = _detect_gpu()

    return SystemCapabilities(
        cpu=cpu,
        memory=memory,
        gpu=gpu,
        os_name=platform.system(),
        os_version=platform.release(),
        python_version=sys.version.split()[0],
        ffmpeg_version=_tool_version(ffmpeg_path, "-version"),
        ffprobe_version=_tool_version(ffprobe_path, "-version"),
    )
