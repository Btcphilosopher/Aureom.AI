"""Safe temporary-file handling for long-running writes (encodes, exports).

`TemporaryMediaFile` writes to a `.partial`-suffixed sibling of the real
destination and only `os.replace`s it into place on success -- an atomic
rename on the same filesystem, so a reader can never observe a half-written
file at the final path. On failure/cancellation, the partial file is
removed rather than left behind. On engine restart, `sweep_orphaned` finds
and removes `.partial` files left by a previous crash (nothing currently
writing to them, since nothing is running yet at startup).
"""

from __future__ import annotations

import os
from pathlib import Path
from types import TracebackType

PARTIAL_SUFFIX = ".partial"


class TemporaryMediaFile:
    """Context manager: yields a temp path to write to. The caller must
    call `commit()` explicitly (inside the `with` block, once writing has
    finished successfully) to atomically rename the temp file into place;
    on any exit without a prior `commit()` -- including a raised exception
    or simply forgetting to call it -- the partial file is removed rather
    than left behind."""

    def __init__(self, destination: str | os.PathLike[str]) -> None:
        self.destination = Path(destination)
        self.temp_path = self.destination.with_name(self.destination.name + PARTIAL_SUFFIX)
        self._committed = False

    def __enter__(self) -> Path:
        self.destination.parent.mkdir(parents=True, exist_ok=True)
        if self.temp_path.exists():
            self.temp_path.unlink()
        return self.temp_path

    def commit(self) -> Path:
        """Atomically move the completed temp file into place."""
        if not self.temp_path.exists():
            raise FileNotFoundError(f"Nothing written to {self.temp_path}")
        os.replace(self.temp_path, self.destination)
        self._committed = True
        return self.destination

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        if not self._committed and self.temp_path.exists():
            self.temp_path.unlink(missing_ok=True)


def sweep_orphaned(directory: str | os.PathLike[str]) -> list[Path]:
    """Remove `.partial` files left behind by a previous crash.

    Intended to run once at engine startup (alongside
    `jobs.manager.JobManager.recover_interrupted_jobs`) -- at that point
    nothing is actively writing, so any `.partial` file found is
    unambiguously orphaned.
    """
    root = Path(directory)
    if not root.is_dir():
        return []

    removed: list[Path] = []
    for path in root.rglob(f"*{PARTIAL_SUFFIX}"):
        if path.is_file():
            path.unlink()
            removed.append(path)
    return removed
