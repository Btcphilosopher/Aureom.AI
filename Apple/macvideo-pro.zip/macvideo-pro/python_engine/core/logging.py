"""Structured logging for the MACVIDEO.PRO engine.

Emits single-line JSON records (via orjson) so the native Swift layer, or any
log aggregator, can parse them without regex scraping. Never logs secrets:
`SENSITIVE_KEYS` is scrubbed from every `extra=` payload before it's written.
"""

from __future__ import annotations

import logging
import sys
import time
from typing import Any

import orjson

SENSITIVE_KEYS = {
    "password",
    "token",
    "auth_token",
    "authorization",
    "api_key",
    "apikey",
    "secret",
    "credential",
    "credentials",
    "access_token",
    "refresh_token",
}


def _scrub(payload: dict[str, Any]) -> dict[str, Any]:
    scrubbed: dict[str, Any] = {}
    for key, value in payload.items():
        if key.lower() in SENSITIVE_KEYS:
            scrubbed[key] = "***REDACTED***"
        elif isinstance(value, dict):
            scrubbed[key] = _scrub(value)
        else:
            scrubbed[key] = value
    return scrubbed


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": round(time.time(), 6),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)

        extra = getattr(record, "context", None)
        if isinstance(extra, dict):
            payload.update(_scrub(extra))

        try:
            return orjson.dumps(payload).decode("utf-8")
        except TypeError:
            # Fallback for non-JSON-serialisable context values.
            return orjson.dumps(payload, default=str).decode("utf-8")


def configure_logging(
    level: int = logging.INFO,
    *,
    stream: Any = None,
) -> logging.Logger:
    """Configure and return the root `macvideo` logger.

    Idempotent: calling this repeatedly reconfigures the same logger instead
    of stacking duplicate handlers.
    """
    logger = logging.getLogger("macvideo")
    logger.setLevel(level)
    logger.handlers.clear()

    handler = logging.StreamHandler(stream or sys.stderr)
    handler.setFormatter(JsonFormatter())
    logger.addHandler(handler)
    logger.propagate = False
    return logger


def get_logger(name: str) -> logging.Logger:
    """Return a child of the `macvideo` logger namespace."""
    return logging.getLogger(f"macvideo.{name}")


def log_with_context(
    logger: logging.Logger, level: int, message: str, **context: Any
) -> None:
    logger.log(level, message, extra={"context": context})
