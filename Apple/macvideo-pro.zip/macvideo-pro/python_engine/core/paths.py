"""macOS-aware path handling.

Everything routes through `pathlib.Path`. This module centralises the rules
around resolving, validating, and classifying paths (including external /
network volumes) so the rest of the engine never has to touch raw strings.
"""

from __future__ import annotations

import os
import unicodedata
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from python_engine.core.errors import StorageError

# macOS mounts most volumes under /Volumes. The boot volume is `/`.
_VOLUMES_ROOT = Path("/Volumes")


class VolumeKind(str, Enum):
    INTERNAL = "internal"
    EXTERNAL = "external"
    NETWORK = "network"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class VolumeInfo:
    kind: VolumeKind
    mount_point: Path
    filesystem: str | None = None


def normalize_path(raw: str | os.PathLike[str]) -> Path:
    """Resolve a user-supplied path, normalising Unicode composition.

    macOS filenames are commonly NFD-composed on disk; comparisons and
    hashing should be done against a stable normal form (NFC) so that
    visually-identical Unicode filenames compare equal.
    """
    path = Path(os.fspath(raw))
    normalized_name = unicodedata.normalize("NFC", path.name)
    if normalized_name != path.name:
        path = path.with_name(normalized_name)
    return path


def expand_and_resolve(raw: str | os.PathLike[str]) -> Path:
    """Expand `~`, resolve `..`/symlinks, without requiring existence."""
    path = normalize_path(raw)
    return Path(os.path.expanduser(str(path))).resolve()


def require_existing_file(raw: str | os.PathLike[str]) -> Path:
    path = expand_and_resolve(raw)
    if not path.exists():
        raise StorageError(f"Path does not exist: {path}")
    if not path.is_file():
        raise StorageError(f"Path is not a file: {path}")
    return path


def require_writable_directory(raw: str | os.PathLike[str]) -> Path:
    path = expand_and_resolve(raw)
    path.mkdir(parents=True, exist_ok=True)
    if not os.access(path, os.W_OK):
        raise StorageError(f"Directory is not writable: {path}")
    return path


def classify_volume(path: str | os.PathLike[str]) -> VolumeInfo:
    """Best-effort classification of the volume a path lives on.

    This never assumes every volume performs the same; it inspects mount
    points to distinguish internal, external, and network storage so callers
    (e.g. StorageMonitor) can reason about throughput expectations.
    """
    resolved = expand_and_resolve(path)

    try:
        candidates = [m for m in _iter_mounts() if _is_relative_to(resolved, m)]
    except OSError:
        return VolumeInfo(kind=VolumeKind.UNKNOWN, mount_point=Path("/"))

    if not candidates:
        return VolumeInfo(kind=VolumeKind.INTERNAL, mount_point=Path("/"))

    mount_point = max(candidates, key=lambda p: len(p.parts))

    if _is_relative_to(mount_point, _VOLUMES_ROOT) and mount_point != _VOLUMES_ROOT:
        fs = _filesystem_for(mount_point)
        if fs and fs.lower() in {"nfs", "smbfs", "afpfs", "webdav"}:
            return VolumeInfo(VolumeKind.NETWORK, mount_point, fs)
        return VolumeInfo(VolumeKind.EXTERNAL, mount_point, fs)

    return VolumeInfo(VolumeKind.INTERNAL, mount_point, _filesystem_for(mount_point))


def _is_relative_to(path: Path, base: Path) -> bool:
    try:
        path.relative_to(base)
        return True
    except ValueError:
        return False


def _iter_mounts() -> list[Path]:
    mounts = [Path("/")]
    if _VOLUMES_ROOT.is_dir():
        try:
            mounts.extend(p for p in _VOLUMES_ROOT.iterdir() if p.is_dir())
        except OSError:
            pass
    return mounts


def _filesystem_for(mount_point: Path) -> str | None:
    try:
        import psutil

        for part in psutil.disk_partitions(all=True):
            if Path(part.mountpoint) == mount_point:
                return part.fstype
    except Exception:
        return None
    return None
