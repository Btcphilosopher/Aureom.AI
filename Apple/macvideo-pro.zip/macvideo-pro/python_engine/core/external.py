"""The one place in the engine that shells out to an external executable.

Every ffmpeg/ffprobe invocation in the codebase should go through
`run_external`. It never uses `shell=True`, always passes an argv list, and
centralises timeout/error handling so failures come back as
`ExternalToolError` with the captured command + stderr instead of a raw
`CalledProcessError` (or a crash) surfacing somewhere deep in a job worker.
"""

from __future__ import annotations

import asyncio
import shutil
import subprocess
from dataclasses import dataclass

from python_engine.core.errors import ExternalToolError
from python_engine.core.logging import get_logger

_log = get_logger("core.external")


@dataclass(frozen=True, slots=True)
class ExternalResult:
    command: list[str]
    returncode: int
    stdout: bytes
    stderr: str


def resolve_executable(name_or_path: str) -> str:
    """Resolve an executable to an absolute path, or raise.

    Rejects blanks and refuses to silently fall back to a shell-searched
    binary the caller didn't ask for.
    """
    if not name_or_path or not name_or_path.strip():
        raise ExternalToolError("Executable path/name must not be empty")

    resolved = shutil.which(name_or_path)
    if resolved is None:
        raise ExternalToolError(
            f"Required external tool not found on PATH: {name_or_path!r}. "
            "MACVIDEO.PRO relies on an external media backend (ffmpeg/ffprobe) "
            "for decoding/encoding and does not attempt to replace it."
        )
    return resolved


def run_external(
    argv: list[str],
    *,
    timeout: float | None = None,
    check: bool = True,
) -> ExternalResult:
    """Run an external command synchronously. Never uses a shell.

    `argv[0]` is resolved via `resolve_executable` first so a bad/missing
    binary fails fast with a clear error rather than a vague OSError.
    """
    if not argv:
        raise ExternalToolError("Empty command")

    full_argv = [resolve_executable(argv[0]), *argv[1:]]
    _log.debug("running external command", extra={"context": {"argv": full_argv}})

    try:
        proc = subprocess.run(
            full_argv,
            shell=False,
            capture_output=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired as exc:
        raise ExternalToolError(
            f"Command timed out after {timeout}s",
            command=full_argv,
        ) from exc
    except OSError as exc:
        raise ExternalToolError(
            f"Failed to execute command: {exc}", command=full_argv
        ) from exc

    stderr_text = proc.stderr.decode("utf-8", errors="replace")
    result = ExternalResult(
        command=full_argv,
        returncode=proc.returncode,
        stdout=proc.stdout,
        stderr=stderr_text,
    )

    if check and proc.returncode != 0:
        raise ExternalToolError(
            f"Command exited with status {proc.returncode}: {' '.join(full_argv[:2])}",
            command=full_argv,
            returncode=proc.returncode,
            stderr=stderr_text,
        )

    return result


async def run_external_async(
    argv: list[str],
    *,
    timeout: float | None = None,
    check: bool = True,
) -> ExternalResult:
    """Async variant of `run_external`, for scanning/inspecting many files concurrently."""
    if not argv:
        raise ExternalToolError("Empty command")

    full_argv = [resolve_executable(argv[0]), *argv[1:]]
    _log.debug(
        "running external command (async)", extra={"context": {"argv": full_argv}}
    )

    try:
        proc = await asyncio.create_subprocess_exec(
            *full_argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except TimeoutError as exc:
        raise ExternalToolError(
            f"Command timed out after {timeout}s", command=full_argv
        ) from exc
    except OSError as exc:
        raise ExternalToolError(
            f"Failed to execute command: {exc}", command=full_argv
        ) from exc

    stderr_text = stderr.decode("utf-8", errors="replace")
    result = ExternalResult(
        command=full_argv,
        returncode=proc.returncode or 0,
        stdout=stdout,
        stderr=stderr_text,
    )

    if check and result.returncode != 0:
        raise ExternalToolError(
            f"Command exited with status {result.returncode}: {' '.join(full_argv[:2])}",
            command=full_argv,
            returncode=result.returncode,
            stderr=stderr_text,
        )

    return result
