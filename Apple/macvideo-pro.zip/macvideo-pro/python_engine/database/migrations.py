"""Minimal, dependency-free schema versioning for the sqlite database.

`Base.metadata.create_all()` (called before this runs) already handles the
common case of "table doesn't exist yet". This module exists for the other
case: incremental changes to tables that *do* already exist on a user's
machine from a previous engine version. Each migration is idempotent (safe
to run against a database that already has it applied).
"""

from __future__ import annotations

from collections.abc import Callable

from sqlalchemy import text
from sqlalchemy.engine import Engine

from python_engine.core.logging import get_logger

_log = get_logger("database.migrations")

Migration = Callable[[Engine], None]


def _ensure_schema_version_table(engine: Engine) -> None:
    with engine.begin() as conn:
        conn.execute(
            text(
                "CREATE TABLE IF NOT EXISTS schema_version ("
                "id INTEGER PRIMARY KEY CHECK (id = 1), "
                "version INTEGER NOT NULL"
                ")"
            )
        )
        conn.execute(
            text(
                "INSERT OR IGNORE INTO schema_version (id, version) VALUES (1, 0)"
            )
        )


def _current_version(engine: Engine) -> int:
    with engine.connect() as conn:
        row = conn.execute(text("SELECT version FROM schema_version WHERE id = 1")).fetchone()
        return int(row[0]) if row else 0


def _set_version(engine: Engine, version: int) -> None:
    with engine.begin() as conn:
        conn.execute(text("UPDATE schema_version SET version = :v WHERE id = 1"), {"v": version})


# Ordered list of migrations. Index in the list + 1 == target version.
# Migration 1 is a no-op: `create_all` already establishes the baseline
# schema for a fresh database; this registry exists for *future* additive
# changes (new columns/tables) against already-deployed databases.
_MIGRATIONS: list[Migration] = [
    lambda engine: None,  # v1: baseline (handled by create_all)
]


def run_migrations(engine: Engine) -> int:
    _ensure_schema_version_table(engine)
    current = _current_version(engine)

    for index in range(current, len(_MIGRATIONS)):
        migration = _MIGRATIONS[index]
        target_version = index + 1
        _log.info(
            "applying migration", extra={"context": {"target_version": target_version}}
        )
        migration(engine)
        _set_version(engine, target_version)
        current = target_version

    return current
