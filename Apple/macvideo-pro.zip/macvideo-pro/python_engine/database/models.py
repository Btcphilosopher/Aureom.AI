"""SQLAlchemy ORM models for the MACVIDEO.PRO library/project database."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import (
    Boolean,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def _uuid() -> str:
    return str(uuid.uuid4())


def _now_iso() -> str:
    return datetime.now(tz=UTC).isoformat()


class Base(DeclarativeBase):
    pass


class MediaAssetRow(Base):
    __tablename__ = "media_assets"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    path: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    filename: Mapped[str] = mapped_column(String, nullable=False)
    file_size: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    duration: Mapped[float | None] = mapped_column(Float, nullable=True)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)
    frame_rate: Mapped[float | None] = mapped_column(Float, nullable=True)
    video_codec: Mapped[str | None] = mapped_column(String, nullable=True)
    audio_codec: Mapped[str | None] = mapped_column(String, nullable=True)
    bitrate: Mapped[int | None] = mapped_column(Integer, nullable=True)
    colour_space: Mapped[str | None] = mapped_column(String, nullable=True)
    bit_depth: Mapped[int | None] = mapped_column(Integer, nullable=True)
    hdr: Mapped[bool] = mapped_column(Boolean, default=False)
    container: Mapped[str | None] = mapped_column(String, nullable=True)
    is_variable_frame_rate: Mapped[bool] = mapped_column(Boolean, default=False)
    resolution_class: Mapped[str | None] = mapped_column(String, nullable=True)

    content_hash: Mapped[str | None] = mapped_column(String, nullable=True)
    quick_hash: Mapped[str | None] = mapped_column(String, nullable=True)

    created_at: Mapped[str] = mapped_column(String, default=_now_iso)
    modified_at: Mapped[str] = mapped_column(String, default=_now_iso)
    scanned_at: Mapped[str] = mapped_column(String, default=_now_iso)

    video_streams: Mapped[list["VideoStreamRow"]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )
    audio_streams: Mapped[list["AudioStreamRow"]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )
    analysis_results: Mapped[list["AnalysisResultRow"]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )
    proxies: Mapped[list["ProxyRow"]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("ix_media_assets_resolution_class", "resolution_class"),
        Index("ix_media_assets_video_codec", "video_codec"),
        Index("ix_media_assets_duration", "duration"),
        Index("ix_media_assets_content_hash", "content_hash"),
    )


class VideoStreamRow(Base):
    __tablename__ = "video_streams"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    asset_id: Mapped[str] = mapped_column(ForeignKey("media_assets.id"), nullable=False)
    stream_index: Mapped[int] = mapped_column(Integer, nullable=False)
    codec: Mapped[str | None] = mapped_column(String, nullable=True)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)
    fps: Mapped[float | None] = mapped_column(Float, nullable=True)
    bit_depth: Mapped[int | None] = mapped_column(Integer, nullable=True)
    pixel_format: Mapped[str | None] = mapped_column(String, nullable=True)
    hdr: Mapped[bool] = mapped_column(Boolean, default=False)

    asset: Mapped[MediaAssetRow] = relationship(back_populates="video_streams")

    __table_args__ = (Index("ix_video_streams_asset_id", "asset_id"),)


class AudioStreamRow(Base):
    __tablename__ = "audio_streams"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    asset_id: Mapped[str] = mapped_column(ForeignKey("media_assets.id"), nullable=False)
    stream_index: Mapped[int] = mapped_column(Integer, nullable=False)
    codec: Mapped[str | None] = mapped_column(String, nullable=True)
    sample_rate: Mapped[int | None] = mapped_column(Integer, nullable=True)
    channels: Mapped[int | None] = mapped_column(Integer, nullable=True)
    language: Mapped[str | None] = mapped_column(String, nullable=True)

    asset: Mapped[MediaAssetRow] = relationship(back_populates="audio_streams")

    __table_args__ = (Index("ix_audio_streams_asset_id", "asset_id"),)


class AnalysisResultRow(Base):
    """Cached results of any analysis kind (histogram/scene/health/etc)."""

    __tablename__ = "analysis_results"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    asset_id: Mapped[str] = mapped_column(ForeignKey("media_assets.id"), nullable=False)
    kind: Mapped[str] = mapped_column(String, nullable=False)
    cache_key: Mapped[str] = mapped_column(String, nullable=False)
    payload_json: Mapped[str] = mapped_column(String, nullable=False)
    created_at: Mapped[str] = mapped_column(String, default=_now_iso)

    asset: Mapped[MediaAssetRow] = relationship(back_populates="analysis_results")

    __table_args__ = (
        UniqueConstraint("asset_id", "kind", "cache_key", name="uq_analysis_result"),
        Index("ix_analysis_results_kind", "kind"),
    )


class ProxyRow(Base):
    __tablename__ = "proxies"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    asset_id: Mapped[str] = mapped_column(ForeignKey("media_assets.id"), nullable=False)
    profile_name: Mapped[str] = mapped_column(String, nullable=False)
    path: Mapped[str] = mapped_column(String, nullable=False)
    width: Mapped[int | None] = mapped_column(Integer, nullable=True)
    height: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[str] = mapped_column(String, default=_now_iso)

    asset: Mapped[MediaAssetRow] = relationship(back_populates="proxies")

    __table_args__ = (Index("ix_proxies_asset_id", "asset_id"),)


class ProjectRow(Base):
    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    name: Mapped[str] = mapped_column(String, nullable=False)
    created_at: Mapped[str] = mapped_column(String, default=_now_iso)
    modified_at: Mapped[str] = mapped_column(String, default=_now_iso)
    timeline_json: Mapped[str | None] = mapped_column(String, nullable=True)
    export_settings_json: Mapped[str | None] = mapped_column(String, nullable=True)

    timeline_clips: Mapped[list["TimelineClipRow"]] = relationship(
        back_populates="project", cascade="all, delete-orphan"
    )
    markers: Mapped[list["MarkerRow"]] = relationship(
        back_populates="project", cascade="all, delete-orphan"
    )
    exports: Mapped[list["ExportRow"]] = relationship(
        back_populates="project", cascade="all, delete-orphan"
    )


class TimelineClipRow(Base):
    __tablename__ = "timeline_clips"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False)
    source_asset_id: Mapped[str] = mapped_column(String, nullable=False)
    source_in: Mapped[float] = mapped_column(Float, nullable=False)
    source_out: Mapped[float] = mapped_column(Float, nullable=False)
    timeline_in: Mapped[float] = mapped_column(Float, nullable=False)
    timeline_out: Mapped[float] = mapped_column(Float, nullable=False)
    track: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    transform_json: Mapped[str | None] = mapped_column(String, nullable=True)
    effects_json: Mapped[str | None] = mapped_column(String, nullable=True)
    audio_gain_db: Mapped[float] = mapped_column(Float, default=0.0)

    project: Mapped[ProjectRow] = relationship(back_populates="timeline_clips")

    __table_args__ = (Index("ix_timeline_clips_project_id", "project_id"),)


class MarkerRow(Base):
    __tablename__ = "markers"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    project_id: Mapped[str] = mapped_column(ForeignKey("projects.id"), nullable=False)
    timestamp: Mapped[float] = mapped_column(Float, nullable=False)
    label: Mapped[str | None] = mapped_column(String, nullable=True)
    kind: Mapped[str] = mapped_column(String, default="generic")
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)

    project: Mapped[ProjectRow] = relationship(back_populates="markers")

    __table_args__ = (Index("ix_markers_project_id", "project_id"),)


class ExportRow(Base):
    __tablename__ = "exports"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    project_id: Mapped[str | None] = mapped_column(
        ForeignKey("projects.id"), nullable=True
    )
    destination: Mapped[str] = mapped_column(String, nullable=False)
    preset_name: Mapped[str | None] = mapped_column(String, nullable=True)
    status: Mapped[str] = mapped_column(String, default="QUEUED")
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[str] = mapped_column(String, default=_now_iso)
    updated_at: Mapped[str] = mapped_column(String, default=_now_iso)

    project: Mapped[ProjectRow | None] = relationship(back_populates="exports")


class JobRow(Base):
    """Persisted job-queue state, so a restart can distinguish RUNNING from
    genuinely-interrupted work (see `jobs.manager.recover_interrupted_jobs`).
    """

    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    kind: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, default="QUEUED")
    priority: Mapped[str] = mapped_column(String, default="NORMAL")
    payload_json: Mapped[str] = mapped_column(String, default="{}")
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    error: Mapped[str | None] = mapped_column(String, nullable=True)
    checkpoint_json: Mapped[str | None] = mapped_column(String, nullable=True)
    created_at: Mapped[str] = mapped_column(String, default=_now_iso)
    updated_at: Mapped[str] = mapped_column(String, default=_now_iso)

    __table_args__ = (Index("ix_jobs_status", "status"),)
