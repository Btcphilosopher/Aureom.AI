"""SQLite engine/session management.

One `Database` wraps a SQLAlchemy engine + sessionmaker for a single sqlite
file (per `MediaEngineConfig.resolved_database_path()`). Foreign keys and
WAL mode are enabled explicitly -- SQLite does not turn these on by default.
"""

from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from python_engine.core.errors import StorageError
from python_engine.core.logging import get_logger
from python_engine.database.migrations import run_migrations
from python_engine.database.models import Base

_log = get_logger("database")


@event.listens_for(Engine, "connect")
def _set_sqlite_pragmas(dbapi_connection, connection_record) -> None:  # noqa: ANN001
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=NORMAL")
    cursor.close()


class Database:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise StorageError(f"Cannot create database directory: {exc}") from exc

        self.engine = create_engine(f"sqlite:///{self.path}", future=True)
        self._session_factory = sessionmaker(bind=self.engine, expire_on_commit=False)
        self._initialised = False

    def init(self) -> None:
        """Create tables (idempotent) and run any pending migrations."""
        Base.metadata.create_all(self.engine)
        run_migrations(self.engine)
        self._initialised = True
        _log.info("database initialised", extra={"context": {"path": str(self.path)}})

    @contextmanager
    def session(self) -> Iterator[Session]:
        if not self._initialised:
            self.init()
        session = self._session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def dispose(self) -> None:
        self.engine.dispose()
