"""Library manager: persists scanned `MediaAsset`s and reports statistics.

All numbers reported by `library_statistics` / `dashboard_data` are computed
directly from the database at call time -- nothing here is a cached or
invented figure.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from sqlalchemy import func, select

from python_engine.database.database import Database
from python_engine.database.models import MediaAssetRow
from python_engine.media.metadata import MediaAsset
from python_engine.video.analysis import classify_resolution


def _upsert_fields(row: MediaAssetRow, asset: MediaAsset) -> None:
    row.path = asset.path
    row.filename = asset.filename
    row.file_size = asset.file_size
    row.duration = asset.duration_seconds
    row.width = asset.width
    row.height = asset.height
    row.frame_rate = asset.frame_rate
    row.video_codec = asset.video_codec
    row.audio_codec = asset.audio_codec
    row.bitrate = asset.bitrate
    row.colour_space = asset.colour_space
    row.bit_depth = asset.bit_depth
    row.hdr = asset.hdr
    row.container = asset.container
    row.is_variable_frame_rate = asset.is_variable_frame_rate
    row.resolution_class = (
        classify_resolution(asset.width, asset.height)
        if asset.width and asset.height
        else None
    )
    row.modified_at = asset.modified_at or row.modified_at


class LibraryManager:
    def __init__(self, database: Database) -> None:
        self.database = database

    def upsert_asset(self, asset: MediaAsset) -> str:
        """Insert or update a media asset by path. Returns the row id."""
        with self.database.session() as session:
            existing = session.scalar(
                select(MediaAssetRow).where(MediaAssetRow.path == asset.path)
            )
            if existing is not None:
                _upsert_fields(existing, asset)
                session.flush()
                return existing.id

            row = MediaAssetRow(id=asset.id)
            _upsert_fields(row, asset)
            session.add(row)
            session.flush()
            return row.id

    def upsert_many(self, assets: list[MediaAsset]) -> list[str]:
        return [self.upsert_asset(asset) for asset in assets]

    def get_by_path(self, path: str) -> MediaAssetRow | None:
        with self.database.session() as session:
            row = session.scalar(select(MediaAssetRow).where(MediaAssetRow.path == path))
            if row is not None:
                session.expunge(row)
            return row

    def delete_by_path(self, path: str) -> bool:
        with self.database.session() as session:
            row = session.scalar(select(MediaAssetRow).where(MediaAssetRow.path == path))
            if row is None:
                return False
            session.delete(row)
            return True

    def all_assets(self) -> list[MediaAssetRow]:
        with self.database.session() as session:
            rows = list(session.scalars(select(MediaAssetRow)))
            for row in rows:
                session.expunge(row)
            return rows


@dataclass(slots=True)
class LibraryStatistics:
    total_files: int = 0
    total_duration_seconds: float = 0.0
    total_storage_bytes: int = 0
    resolution_distribution: dict[str, int] = field(default_factory=dict)
    codec_distribution: dict[str, int] = field(default_factory=dict)
    frame_rate_distribution: dict[str, int] = field(default_factory=dict)


def library_statistics(database: Database) -> LibraryStatistics:
    with database.session() as session:
        total_files = session.scalar(select(func.count(MediaAssetRow.id))) or 0
        total_duration = session.scalar(select(func.coalesce(func.sum(MediaAssetRow.duration), 0.0))) or 0.0
        total_storage = session.scalar(select(func.coalesce(func.sum(MediaAssetRow.file_size), 0))) or 0

        resolution_rows = session.execute(
            select(MediaAssetRow.resolution_class, func.count(MediaAssetRow.id)).group_by(
                MediaAssetRow.resolution_class
            )
        ).all()
        codec_rows = session.execute(
            select(MediaAssetRow.video_codec, func.count(MediaAssetRow.id)).group_by(
                MediaAssetRow.video_codec
            )
        ).all()
        fps_rows = session.execute(
            select(MediaAssetRow.frame_rate, func.count(MediaAssetRow.id)).group_by(
                MediaAssetRow.frame_rate
            )
        ).all()

    return LibraryStatistics(
        total_files=int(total_files),
        total_duration_seconds=float(total_duration),
        total_storage_bytes=int(total_storage),
        resolution_distribution={(r or "UNKNOWN"): c for r, c in resolution_rows},
        codec_distribution={(c or "UNKNOWN"): n for c, n in codec_rows},
        frame_rate_distribution={
            (f"{f:g}" if f is not None else "UNKNOWN"): n for f, n in fps_rows
        },
    )


def dashboard_data(database: Database) -> dict[str, object]:
    """Spec-shaped dashboard summary (section 82)."""
    stats = library_statistics(database)
    eight_k = stats.resolution_distribution.get("8K", 0)
    four_k = stats.resolution_distribution.get("4K", 0)
    hd = stats.resolution_distribution.get("HD", 0) + stats.resolution_distribution.get(
        "FHD", 0
    )
    return {
        "total_files": stats.total_files,
        "total_storage_tb": round(stats.total_storage_bytes / (1000**4), 4),
        "eight_k_files": eight_k,
        "four_k_files": four_k,
        "hd_files": hd,
    }
