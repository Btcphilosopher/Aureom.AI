"""Staged duplicate detection.

Hashing an entire library of large (potentially multi-GB, 8K) files with
full SHA-256 up front would be prohibitively slow and I/O-heavy. Detection
is staged so expensive work only happens on files that already look like
plausible duplicates:

    1. size + mtime          (free -- from stat())
    2. quick hash            (small chunks: head + middle + tail)
    3. partial hash          (first N MiB, full SHA-256 over that slice)
    4. full hash             (SHA-256 of the entire file -- only for the
                               remaining candidates after stage 3)

Two files are only ever reported as "exact duplicates" once their full
SHA-256 matches. Filename is never used as a signal -- two same-named files
with different content are not duplicates, and two differently-named files
with identical content are.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path

_QUICK_CHUNK_SIZE = 64 * 1024  # 64 KiB samples for the quick hash stage
_PARTIAL_HASH_BYTES = 4 * 1024 * 1024  # first 4 MiB for the partial stage
_FULL_HASH_READ_CHUNK = 8 * 1024 * 1024  # streamed in 8 MiB chunks


@dataclass(frozen=True, slots=True)
class FileFingerprint:
    path: str
    size: int
    mtime: float


def quick_hash(path: Path) -> str:
    """Cheap fingerprint: head + middle + tail samples, not the whole file.

    Two files with the same quick hash are *candidates* for duplication,
    not confirmed duplicates -- collisions here are expected and cheap to
    produce (that's the point: fast triage, not proof).
    """
    size = path.stat().st_size
    hasher = hashlib.sha256()
    with path.open("rb") as fh:
        # Head
        hasher.update(fh.read(_QUICK_CHUNK_SIZE))
        # Middle
        if size > _QUICK_CHUNK_SIZE * 2:
            fh.seek(size // 2)
            hasher.update(fh.read(_QUICK_CHUNK_SIZE))
        # Tail
        if size > _QUICK_CHUNK_SIZE:
            fh.seek(max(0, size - _QUICK_CHUNK_SIZE))
            hasher.update(fh.read(_QUICK_CHUNK_SIZE))
    hasher.update(str(size).encode())
    return hasher.hexdigest()


def partial_hash(path: Path, max_bytes: int = _PARTIAL_HASH_BYTES) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as fh:
        hasher.update(fh.read(max_bytes))
    return hasher.hexdigest()


def full_hash(path: Path) -> str:
    """SHA-256 of the entire file, streamed in bounded chunks.

    Never reads the whole file into memory at once -- important for
    multi-GB/TB 8K masters.
    """
    hasher = hashlib.sha256()
    with path.open("rb") as fh:
        while chunk := fh.read(_FULL_HASH_READ_CHUNK):
            hasher.update(chunk)
    return hasher.hexdigest()


@dataclass(slots=True)
class DuplicateGroup:
    full_hash: str
    paths: list[str] = field(default_factory=list)


def find_duplicates(paths: list[str | Path]) -> list[DuplicateGroup]:
    """Staged duplicate detection across `paths`.

    Only files that survive every earlier stage as a *group* of 2+
    candidates proceed to the next, more expensive stage.
    """
    resolved = [Path(p) for p in paths]
    existing = [p for p in resolved if p.is_file()]

    # Stage 1: size + mtime grouping (free).
    by_size: dict[int, list[Path]] = {}
    for p in existing:
        by_size.setdefault(p.stat().st_size, []).append(p)
    size_candidates = [group for group in by_size.values() if len(group) > 1]

    # Stage 2: quick hash.
    quick_groups: dict[str, list[Path]] = {}
    for group in size_candidates:
        for p in group:
            quick_groups.setdefault(quick_hash(p), []).append(p)
    quick_candidates = [group for group in quick_groups.values() if len(group) > 1]

    # Stage 3: partial hash.
    partial_groups: dict[str, list[Path]] = {}
    for group in quick_candidates:
        for p in group:
            partial_groups.setdefault(partial_hash(p), []).append(p)
    partial_candidates = [group for group in partial_groups.values() if len(group) > 1]

    # Stage 4: full hash -- the only stage that confirms a true duplicate.
    full_groups: dict[str, list[Path]] = {}
    for group in partial_candidates:
        for p in group:
            full_groups.setdefault(full_hash(p), []).append(p)

    return [
        DuplicateGroup(full_hash=h, paths=[str(p) for p in group])
        for h, group in full_groups.items()
        if len(group) > 1
    ]
