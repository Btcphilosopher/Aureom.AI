"""Media health scanning.

Runs (async, bounded-concurrency) checks over a set of paths/assets and
reports per-asset health without ever crashing the scan because one file is
bad -- that's the entire point of this module.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from python_engine.core.errors import ExternalToolError, InspectionError
from python_engine.core.logging import get_logger
from python_engine.media.inspector import inspect_media_asset_async

_log = get_logger("library.health")


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    WARNING = "warning"
    ERROR = "error"


class HealthIssue(str, Enum):
    MISSING_FILE = "missing_file"
    UNREADABLE_FILE = "unreadable_file"
    UNSUPPORTED_CODEC = "unsupported_codec"
    INVALID_METADATA = "invalid_metadata"
    ZERO_DURATION = "zero_duration"
    INVALID_STREAM = "invalid_stream"
    TRUNCATED_FILE = "truncated_file"


@dataclass(slots=True)
class MediaHealthReport:
    path: str
    status: HealthStatus
    issues: list[HealthIssue] = field(default_factory=list)
    detail: str | None = None


async def check_media_health(
    path: str, *, ffprobe_path: str = "ffprobe", ffmpeg_path: str = "ffmpeg"
) -> MediaHealthReport:
    p = Path(path)
    issues: list[HealthIssue] = []

    if not p.exists():
        return MediaHealthReport(path=path, status=HealthStatus.ERROR, issues=[HealthIssue.MISSING_FILE])

    if p.stat().st_size == 0:
        return MediaHealthReport(
            path=path,
            status=HealthStatus.ERROR,
            issues=[HealthIssue.TRUNCATED_FILE],
            detail="File exists but is zero bytes",
        )

    try:
        asset = await inspect_media_asset_async(p, ffprobe_path)
    except InspectionError as exc:
        return MediaHealthReport(
            path=path,
            status=HealthStatus.ERROR,
            issues=[HealthIssue.UNREADABLE_FILE],
            detail=str(exc),
        )
    except ExternalToolError as exc:
        return MediaHealthReport(
            path=path,
            status=HealthStatus.ERROR,
            issues=[HealthIssue.UNSUPPORTED_CODEC],
            detail=str(exc),
        )

    if not asset.streams.video and not asset.streams.audio:
        issues.append(HealthIssue.INVALID_STREAM)

    if asset.duration_seconds is None:
        issues.append(HealthIssue.INVALID_METADATA)
    elif asset.duration_seconds <= 0:
        issues.append(HealthIssue.ZERO_DURATION)

    if asset.streams.primary_video and (
        not asset.streams.primary_video.width or not asset.streams.primary_video.height
    ):
        issues.append(HealthIssue.INVALID_METADATA)

    # A truncated/corrupt file often still returns *some* ffprobe metadata
    # but fails to decode near the end; a lightweight integrity check tries
    # to decode the last second without writing output.
    if asset.duration_seconds and asset.duration_seconds > 0:
        truncated = await _probe_decodes_to_end(p, asset.duration_seconds, ffmpeg_path)
        if not truncated:
            issues.append(HealthIssue.TRUNCATED_FILE)

    if not issues:
        return MediaHealthReport(path=path, status=HealthStatus.HEALTHY)

    status = (
        HealthStatus.ERROR
        if any(
            i in issues
            for i in (
                HealthIssue.TRUNCATED_FILE,
                HealthIssue.INVALID_STREAM,
                HealthIssue.ZERO_DURATION,
            )
        )
        else HealthStatus.WARNING
    )
    return MediaHealthReport(path=path, status=status, issues=issues)


async def _probe_decodes_to_end(path: Path, duration: float, ffmpeg_path: str) -> bool:
    """Best-effort check that the file decodes near its reported end.

    Seeks close to the end and attempts to decode a tiny window to null
    output. Returns True if it succeeds (or the check itself is
    inconclusive, to avoid false "truncated" reports), False only on a
    clear decode failure right at the reported end of the file.
    """
    from python_engine.core.external import run_external_async

    seek_to = max(0.0, duration - 0.5)
    try:
        result = await run_external_async(
            [
                ffmpeg_path,
                "-v",
                "error",
                "-ss",
                f"{seek_to:.3f}",
                "-i",
                str(path),
                "-frames:v",
                "1",
                "-f",
                "null",
                "-",
            ],
            check=False,
            timeout=30,
        )
    except ExternalToolError:
        return True  # Inconclusive -- don't falsely flag as truncated.

    if result.returncode != 0 and result.stderr.strip():
        return False
    return True


async def run_health_scan(
    paths: list[str], *, max_concurrency: int = 4
) -> list[MediaHealthReport]:
    """Run health checks across many assets with bounded concurrency."""
    semaphore = asyncio.Semaphore(max(1, max_concurrency))

    async def _one(path: str) -> MediaHealthReport:
        async with semaphore:
            return await check_media_health(path)

    return list(await asyncio.gather(*(_one(p) for p in paths)))
