"""Structured search over the media library.

`search_media(...)` builds a real SQL query from structured filters -- it
does not scan every row in Python. Free-text `search_media(query="...")`
matches filename/path via SQL `LIKE`.
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import select

from python_engine.database.database import Database
from python_engine.database.models import MediaAssetRow


@dataclass(slots=True)
class MediaQuery:
    text: str | None = None  # matched against filename/path
    resolution: str | None = None  # e.g. "8K", "4K"
    codec: str | None = None
    min_duration: float | None = None
    max_duration: float | None = None
    min_width: int | None = None
    min_height: int | None = None
    hdr: bool | None = None
    variable_frame_rate: bool | None = None
    folder: str | None = None  # path prefix
    limit: int = 500
    offset: int = 0


def search_media(database: Database, query: MediaQuery | None = None, **kwargs: object) -> list[MediaAssetRow]:
    """Search the library. Either pass a `MediaQuery`, or keyword filters
    matching its fields directly, e.g.:

        search_media(db, resolution="8K", codec="HEVC", min_duration=1800)
    """
    q = query or MediaQuery(**kwargs)  # type: ignore[arg-type]

    stmt = select(MediaAssetRow)

    if q.text:
        like = f"%{q.text}%"
        stmt = stmt.where(
            (MediaAssetRow.filename.like(like)) | (MediaAssetRow.path.like(like))
        )
    if q.resolution:
        stmt = stmt.where(MediaAssetRow.resolution_class == q.resolution)
    if q.codec:
        stmt = stmt.where(MediaAssetRow.video_codec == q.codec)
    if q.min_duration is not None:
        stmt = stmt.where(MediaAssetRow.duration >= q.min_duration)
    if q.max_duration is not None:
        stmt = stmt.where(MediaAssetRow.duration <= q.max_duration)
    if q.min_width is not None:
        stmt = stmt.where(MediaAssetRow.width >= q.min_width)
    if q.min_height is not None:
        stmt = stmt.where(MediaAssetRow.height >= q.min_height)
    if q.hdr is not None:
        stmt = stmt.where(MediaAssetRow.hdr == q.hdr)
    if q.variable_frame_rate is not None:
        stmt = stmt.where(MediaAssetRow.is_variable_frame_rate == q.variable_frame_rate)
    if q.folder:
        stmt = stmt.where(MediaAssetRow.path.like(f"{q.folder}%"))

    stmt = stmt.limit(max(1, q.limit)).offset(max(0, q.offset))

    with database.session() as session:
        rows = list(session.scalars(stmt))
        for row in rows:
            session.expunge(row)
        return rows
