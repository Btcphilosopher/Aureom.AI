"""Proxy generation.

A proxy is generated entirely through `FFmpegRunner` -- this module never
decodes/re-encodes frames manually in Python. `ProxyProfile` mirrors a
`transcoding.presets.ExportPreset` but is named/scoped for the proxy use
case specifically (spec section 33), and adds the aspect-ratio/frame-rate/
timecode preservation behaviour proxies need.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from python_engine.core.errors import ValidationError
from python_engine.core.paths import require_existing_file
from python_engine.media.inspector import inspect_media_asset
from python_engine.transcoding.engine import FFmpegRunner
from python_engine.transcoding.presets import ExportPreset, available_proxy_presets


@dataclass(frozen=True, slots=True)
class ProxyProfile:
    name: str
    video_codec: str
    container: str
    max_width: int | None = None
    max_height: int | None = None
    video_bitrate: str | None = None
    pixel_format: str | None = None
    preserve_timecode: bool = True

    @classmethod
    def from_preset(cls, preset: ExportPreset) -> "ProxyProfile":
        return cls(
            name=preset.name,
            video_codec=preset.video_codec,
            container=preset.container,
            max_width=preset.width,
            max_height=preset.height,
            video_bitrate=preset.video_bitrate,
            pixel_format=preset.pixel_format,
        )


def available_proxy_profiles(ffmpeg_path: str = "ffmpeg") -> tuple[ProxyProfile, ...]:
    return tuple(ProxyProfile.from_preset(p) for p in available_proxy_presets(ffmpeg_path))


def _scaled_dimensions(
    source_width: int, source_height: int, max_width: int | None, max_height: int | None
) -> tuple[int, int]:
    """Scale to fit within (max_width, max_height), preserving aspect ratio.

    Output dimensions are always rounded to even numbers, since most
    4:2:0 codecs (H.264/HEVC/ProRes) require even width/height.
    """
    if not max_width or not max_height:
        return source_width, source_height

    scale = min(max_width / source_width, max_height / source_height, 1.0)
    width = max(2, int(source_width * scale) // 2 * 2)
    height = max(2, int(source_height * scale) // 2 * 2)
    return width, height


def generate_proxy(
    source: str,
    destination: str,
    profile: ProxyProfile,
    *,
    ffmpeg_path: str = "ffmpeg",
    ffprobe_path: str = "ffprobe",
    on_progress=None,
    cancel_check=None,
) -> Path:
    """Generate a proxy from `source` using `profile`, via ffmpeg.

    Preserves aspect ratio and source frame rate (proxies must match their
    master's cut points 1:1, so the frame rate is never silently changed)
    where the container/codec permit.
    """
    resolved_source = require_existing_file(source)
    asset = inspect_media_asset(resolved_source, ffprobe_path)
    video = asset.streams.primary_video
    if video is None or not video.width or not video.height:
        raise ValidationError(f"Source has no video stream to proxy: {source}")

    width, height = _scaled_dimensions(video.width, video.height, profile.max_width, profile.max_height)

    runner = FFmpegRunner(ffmpeg_path, ffprobe_path)
    return runner.transcode(
        source=str(resolved_source),
        destination=destination,
        video_codec=profile.video_codec,
        audio_codec="pcm_s16le" if profile.video_codec == "prores" else "aac",
        width=width,
        height=height,
        frame_rate=video.fps,  # never silently altered
        video_bitrate=profile.video_bitrate,
        pixel_format=profile.pixel_format,
        container=profile.container,
        on_progress=on_progress,
        cancel_check=cancel_check,
    )
