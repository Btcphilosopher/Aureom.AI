"""Transcode/export presets.

Presets describe *intent* (8K HEVC High Quality, ProRes Proxy, etc). Which
presets are actually usable on this machine is determined by checking each
preset's codec against `media.codecs.get_codec_capability` -- a preset is
never exposed as available just because it's in this list.
"""

from __future__ import annotations

from dataclasses import dataclass

from python_engine.media.codecs import get_codec_capability


@dataclass(frozen=True, slots=True)
class ExportPreset:
    name: str
    video_codec: str
    container: str
    width: int | None = None
    height: int | None = None
    video_bitrate: str | None = None
    audio_codec: str | None = "aac"
    audio_bitrate: str | None = "384k"
    pixel_format: str | None = None
    prefer_hardware: bool = True
    description: str = ""


# Reference catalogue (spec section 38/39). Availability is checked
# per-machine via `available_presets`, never assumed from this list alone.
_CATALOGUE: tuple[ExportPreset, ...] = (
    ExportPreset(
        name="8K HEVC High Quality",
        video_codec="hevc",
        container="mov",
        width=7680,
        height=4320,
        video_bitrate="180M",
        pixel_format="yuv420p10le",
        description="Maximum-quality 8K HEVC 10-bit master-grade export.",
    ),
    ExportPreset(
        name="8K HEVC Efficient",
        video_codec="hevc",
        container="mp4",
        width=7680,
        height=4320,
        video_bitrate="90M",
        pixel_format="yuv420p",
        description="Smaller 8K HEVC delivery, still full UHD-2 resolution.",
    ),
    ExportPreset(
        name="4K HEVC",
        video_codec="hevc",
        container="mp4",
        width=3840,
        height=2160,
        video_bitrate="45M",
        pixel_format="yuv420p",
        description="Standard 4K HEVC delivery.",
    ),
    ExportPreset(
        name="4K H.264",
        video_codec="h264",
        container="mp4",
        width=3840,
        height=2160,
        video_bitrate="50M",
        pixel_format="yuv420p",
        description="Maximum-compatibility 4K H.264 delivery.",
    ),
    ExportPreset(
        name="1080p H.264",
        video_codec="h264",
        container="mp4",
        width=1920,
        height=1080,
        video_bitrate="16M",
        pixel_format="yuv420p",
        description="Standard 1080p web/delivery export.",
    ),
    ExportPreset(
        name="ProRes Master",
        video_codec="prores",
        container="mov",
        video_bitrate=None,
        pixel_format="yuv422p10le",
        audio_codec="pcm_s16le",
        audio_bitrate=None,
        prefer_hardware=False,
        description="Mezzanine/archival master using ProRes (bitrate is codec-managed via quality profile, not a fixed target).",
    ),
    ExportPreset(
        name="Archive",
        video_codec="ffv1",
        container="mkv",
        video_bitrate=None,
        pixel_format=None,
        audio_codec="flac",
        audio_bitrate=None,
        prefer_hardware=False,
        description="Lossless archival encode.",
    ),
    ExportPreset(
        name="Web",
        video_codec="h264",
        container="mp4",
        width=1920,
        height=1080,
        video_bitrate="8M",
        pixel_format="yuv420p",
        description="Compact web-delivery export.",
    ),
)


# Proxy-specific presets (spec section 33).
_PROXY_CATALOGUE: tuple[ExportPreset, ...] = (
    ExportPreset(
        name="1080p H.264",
        video_codec="h264",
        container="mov",
        width=1920,
        height=1080,
        video_bitrate="8M",
        description="Fast, broadly compatible 1080p editorial proxy.",
    ),
    ExportPreset(
        name="720p H.264",
        video_codec="h264",
        container="mov",
        width=1280,
        height=720,
        video_bitrate="4M",
        description="Lightweight 720p editorial proxy for slower storage/network.",
    ),
    ExportPreset(
        name="1080p ProRes Proxy",
        video_codec="prores",
        container="mov",
        width=1920,
        height=1080,
        video_bitrate=None,
        pixel_format="yuv422p",
        audio_codec="pcm_s16le",
        audio_bitrate=None,
        prefer_hardware=False,
        description="ProRes 422 Proxy for editorial workflows that require it.",
    ),
)


def all_export_presets() -> tuple[ExportPreset, ...]:
    return _CATALOGUE


def all_proxy_presets() -> tuple[ExportPreset, ...]:
    return _PROXY_CATALOGUE


def is_preset_available(preset: ExportPreset, ffmpeg_path: str = "ffmpeg") -> bool:
    capability = get_codec_capability(preset.video_codec, ffmpeg_path)
    return capability.encode_supported


def available_export_presets(ffmpeg_path: str = "ffmpeg") -> tuple[ExportPreset, ...]:
    """Only presets whose codec the *installed* ffmpeg build can actually encode."""
    return tuple(p for p in _CATALOGUE if is_preset_available(p, ffmpeg_path))


def available_proxy_presets(ffmpeg_path: str = "ffmpeg") -> tuple[ExportPreset, ...]:
    return tuple(p for p in _PROXY_CATALOGUE if is_preset_available(p, ffmpeg_path))


def get_preset(name: str, *, proxy: bool = False) -> ExportPreset | None:
    catalogue = _PROXY_CATALOGUE if proxy else _CATALOGUE
    for preset in catalogue:
        if preset.name == name:
            return preset
    return None
