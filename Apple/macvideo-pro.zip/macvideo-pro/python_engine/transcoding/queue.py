"""Export/transcode queue: wires `TranscodeJob`s into `JobManager`.

Registers job handlers for `"transcode"`, `"proxy"`, and `"export"` kinds
that call `FFmpegRunner`/`generate_proxy` and translate real encoder
progress (frame/fps/speed/out_time -- never fabricated) into
`JobContext.report_progress`. Also implements batch queuing with
resolution-aware bounded concurrency for 8K-class sources (spec section
44), and export validation gating (section 84: a job whose settings fail
`validate_export` is marked FAILED before any encode is attempted).
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass

from python_engine.core.errors import JobCancelledError
from python_engine.jobs.manager import JobContext, JobManager, JobPriority
from python_engine.jobs.pool import ProcessingPool
from python_engine.media.inspector import inspect_media_asset
from python_engine.proxies.engine import ProxyProfile, generate_proxy
from python_engine.transcoding.engine import EncodeProgress, FFmpegRunner
from python_engine.transcoding.export import ExportSettings, validate_export
from python_engine.transcoding.presets import ExportPreset


@dataclass(slots=True)
class BatchResult:
    job_ids: list[str]
    skipped: list[tuple[str, str]]  # (source, reason) for sources that failed validation


class ExportQueue:
    def __init__(self, job_manager: JobManager, processing_pool: ProcessingPool | None = None) -> None:
        self.job_manager = job_manager
        self.processing_pool = processing_pool or ProcessingPool()
        self._register_handlers()

    def _register_handlers(self) -> None:
        self.job_manager.register_handler("transcode", self._handle_transcode)
        self.job_manager.register_handler("proxy", self._handle_proxy)
        self.job_manager.register_handler("export", self._handle_transcode)

    async def _handle_transcode(self, ctx: JobContext) -> None:
        payload = ctx.payload
        runner = FFmpegRunner(
            payload.get("ffmpeg_path", "ffmpeg"),  # type: ignore[arg-type]
            payload.get("ffprobe_path", "ffprobe"),  # type: ignore[arg-type]
        )

        source = str(payload["source"])
        destination = str(payload["destination"])

        # Determine total duration up front so raw encoder progress
        # (out_time_seconds) can be turned into a 0-1 fraction.
        try:
            asset = inspect_media_asset(source, payload.get("ffprobe_path", "ffprobe"))  # type: ignore[arg-type]
            total_duration = asset.duration_seconds or None
        except Exception:  # noqa: BLE001
            total_duration = None

        loop = asyncio.get_running_loop()
        cancel_event = asyncio.Event()

        def on_progress(p: EncodeProgress) -> None:
            fraction = None
            if total_duration and p.out_time_seconds is not None:
                fraction = min(1.0, p.out_time_seconds / total_duration)
            if fraction is not None:
                loop.call_soon_threadsafe(ctx.report_progress, fraction)
            loop.call_soon_threadsafe(
                ctx.checkpoint,
                {
                    "frame": p.frame,
                    "fps": p.fps,
                    "speed": p.speed,
                    "out_time_seconds": p.out_time_seconds,
                },
            )

        def cancel_check() -> bool:
            return ctx.cancel_requested()

        def run_blocking() -> None:
            runner.transcode(
                source=source,
                destination=destination,
                video_codec=payload.get("video_codec"),  # type: ignore[arg-type]
                audio_codec=payload.get("audio_codec"),  # type: ignore[arg-type]
                width=payload.get("width"),  # type: ignore[arg-type]
                height=payload.get("height"),  # type: ignore[arg-type]
                frame_rate=payload.get("frame_rate"),  # type: ignore[arg-type]
                video_bitrate=payload.get("video_bitrate"),  # type: ignore[arg-type]
                audio_bitrate=payload.get("audio_bitrate"),  # type: ignore[arg-type]
                container=payload.get("container"),  # type: ignore[arg-type]
                pixel_format=payload.get("pixel_format"),  # type: ignore[arg-type]
                on_progress=on_progress,
                cancel_check=cancel_check,
            )

        try:
            await loop.run_in_executor(None, run_blocking)
        except Exception as exc:  # noqa: BLE001
            if ctx.cancel_requested():
                raise JobCancelledError(str(exc)) from exc
            raise

    async def _handle_proxy(self, ctx: JobContext) -> None:
        payload = ctx.payload
        profile = ProxyProfile(
            name=str(payload.get("profile_name", "proxy")),
            video_codec=str(payload["video_codec"]),
            container=str(payload["container"]),
            max_width=payload.get("max_width"),  # type: ignore[arg-type]
            max_height=payload.get("max_height"),  # type: ignore[arg-type]
            video_bitrate=payload.get("video_bitrate"),  # type: ignore[arg-type]
            pixel_format=payload.get("pixel_format"),  # type: ignore[arg-type]
        )

        loop = asyncio.get_running_loop()

        def on_progress(p: EncodeProgress) -> None:
            loop.call_soon_threadsafe(
                ctx.checkpoint,
                {"frame": p.frame, "fps": p.fps, "speed": p.speed},
            )

        def run_blocking() -> None:
            generate_proxy(
                str(payload["source"]),
                str(payload["destination"]),
                profile,
                on_progress=on_progress,
                cancel_check=ctx.cancel_requested,
            )

        try:
            await loop.run_in_executor(None, run_blocking)
        except Exception as exc:  # noqa: BLE001
            if ctx.cancel_requested():
                raise JobCancelledError(str(exc)) from exc
            raise

    # -- submission helpers ---------------------------------------------

    def queue_export(
        self,
        source: str,
        destination: str,
        preset: ExportPreset,
        *,
        priority: JobPriority = JobPriority.NORMAL,
        skip_validation: bool = False,
    ) -> str:
        """Validate then queue a single export. Raises if validation fails
        and `skip_validation` is False -- an export is never started with
        known errors (spec section 84)."""
        if not skip_validation:
            result = validate_export(ExportSettings(source=source, destination=destination, preset=preset))
            if not result.valid:
                raise ValueError(f"Export validation failed: {'; '.join(result.errors)}")

        return self.job_manager.submit(
            "export",
            {
                "source": source,
                "destination": destination,
                "video_codec": preset.video_codec,
                "audio_codec": preset.audio_codec,
                "width": preset.width,
                "height": preset.height,
                "video_bitrate": preset.video_bitrate,
                "audio_bitrate": preset.audio_bitrate,
                "container": preset.container,
                "pixel_format": preset.pixel_format,
            },
            priority=priority,
        )

    def queue_batch(
        self,
        files: list[str],
        preset: ExportPreset,
        destination_dir: str,
        *,
        priority: JobPriority = JobPriority.NORMAL,
    ) -> BatchResult:
        """Queue many files against one preset, skipping (not crashing on)
        sources that fail validation. Concurrency across the batch is
        governed entirely by `JobManager`'s concurrency limit -- callers
        with 8K sources should size that limit via
        `ProcessingPool.allocate_for_resolution` before calling this."""
        import os

        job_ids: list[str] = []
        skipped: list[tuple[str, str]] = []

        for source in files:
            destination = os.path.join(destination_dir, os.path.splitext(os.path.basename(source))[0] + f".{preset.container}")
            settings = ExportSettings(source=source, destination=destination, preset=preset)
            result = validate_export(settings)
            if not result.valid:
                skipped.append((source, "; ".join(result.errors)))
                continue
            job_id = self.queue_export(source, destination, preset, priority=priority, skip_validation=True)
            job_ids.append(job_id)

        return BatchResult(job_ids=job_ids, skipped=skipped)
