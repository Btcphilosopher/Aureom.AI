"""Export validation and size estimation.

`validate_export` runs every check the spec calls for and never allows an
export to start if `errors` is non-empty (see spec section 84: "If errors
exist: DO NOT START EXPORT" -- enforced by `queue.py` checking
`ValidationResult.valid` before transitioning a job out of QUEUED).
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from pathlib import Path

from python_engine.core.paths import expand_and_resolve
from python_engine.media.codecs import get_codec_capability
from python_engine.media.inspector import inspect_media_asset
from python_engine.storage.estimator import StorageEstimate, estimate_storage
from python_engine.transcoding.presets import ExportPreset

_VALID_FRAME_RATES = {
    23.976, 24, 25, 29.97, 30, 47.952, 48, 50, 59.94, 60, 100, 119.88, 120,
}


@dataclass(slots=True)
class ExportSettings:
    source: str
    destination: str
    preset: ExportPreset
    frame_rate: float | None = None  # None => keep source frame rate
    audio_channels: int | None = None


@dataclass(slots=True)
class ValidationResult:
    valid: bool
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def add_error(self, message: str) -> None:
        self.errors.append(message)
        self.valid = False

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)


def validate_export(
    settings: ExportSettings,
    *,
    ffmpeg_path: str = "ffmpeg",
    ffprobe_path: str = "ffprobe",
    min_free_bytes_margin: float = 1.05,
) -> ValidationResult:
    """Validate export settings against the source, backend, and disk.

    Checks: resolution, codec, bitrate, frame rate, audio configuration,
    disk space, and source compatibility (spec section 40). Never starts
    an export itself -- purely a check.
    """
    result = ValidationResult(valid=True)

    source_path = Path(settings.source)
    if not source_path.is_file():
        result.add_error(f"Source does not exist: {settings.source}")
        return result

    try:
        asset = inspect_media_asset(source_path, ffprobe_path)
    except Exception as exc:  # noqa: BLE001 - report as a validation error, don't crash
        result.add_error(f"Source is not readable by the media backend: {exc}")
        return result

    video = asset.streams.primary_video
    if video is None:
        result.add_error("Source has no video stream")

    preset = settings.preset

    # --- Codec ---
    capability = get_codec_capability(preset.video_codec, ffmpeg_path)
    if not capability.encode_supported:
        result.add_error(
            f"Video codec {preset.video_codec!r} is not supported for encoding by "
            "the installed media backend"
        )
    elif preset.prefer_hardware and not capability.hardware_possible:
        result.add_warning(
            f"No hardware encoder detected for {preset.video_codec!r}; "
            "export will use software encoding (may be significantly slower for 8K)"
        )

    if preset.audio_codec:
        audio_capability = get_codec_capability(preset.audio_codec, ffmpeg_path)
        if not audio_capability.encode_supported:
            result.add_error(
                f"Audio codec {preset.audio_codec!r} is not supported for encoding"
            )

    # --- Resolution ---
    if preset.width is not None and preset.height is not None:
        if preset.width <= 0 or preset.height <= 0:
            result.add_error(f"Invalid target resolution: {preset.width}x{preset.height}")
        elif preset.width > 16384 or preset.height > 16384:
            result.add_error(
                f"Target resolution {preset.width}x{preset.height} exceeds what the "
                "backend can reasonably encode"
            )
        if video and video.width and video.height:
            if preset.width > video.width or preset.height > video.height:
                result.add_warning(
                    "Target resolution is larger than the source; this will upscale, not add detail"
                )

    # --- Frame rate ---
    target_fps = settings.frame_rate or (video.fps if video else None)
    if target_fps is not None:
        if target_fps <= 0 or target_fps > 1000:
            result.add_error(f"Invalid frame rate: {target_fps}")
        elif not any(abs(target_fps - valid) < 0.01 for valid in _VALID_FRAME_RATES):
            result.add_warning(
                f"Frame rate {target_fps:g} is not a common broadcast/delivery rate"
            )

    if video and video.is_variable_frame_rate:
        result.add_warning(
            "Source is variable frame rate; exported timing may not match a naive "
            "frame_number/fps calculation"
        )

    # --- Audio configuration ---
    if asset.streams.audio and not preset.audio_codec:
        result.add_warning("Source has audio but the preset specifies no audio codec")
    if not asset.streams.audio and preset.audio_codec:
        result.add_warning("Preset expects audio but source has no audio stream")

    # --- Disk space ---
    dest_path = expand_and_resolve(settings.destination)
    dest_dir = dest_path.parent
    if not dest_dir.exists():
        try:
            dest_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            result.add_error(f"Destination directory is not writable: {exc}")
            dest_dir = None  # type: ignore[assignment]

    if dest_dir is not None:
        try:
            usage = shutil.disk_usage(dest_dir)
        except OSError as exc:
            result.add_error(f"Cannot determine free disk space: {exc}")
        else:
            estimate = estimate_export_size_for_settings(settings, asset.duration_seconds or 0.0)
            required = estimate.bytes_decimal * min_free_bytes_margin
            if usage.free < required:
                result.add_error(
                    f"Insufficient disk space: need ~{estimate.gb_decimal:.2f} GB, "
                    f"{usage.free / 1e9:.2f} GB free"
                )
            elif usage.free < required * 1.5:
                result.add_warning("Disk space is sufficient but limited headroom remains")

    return result


def estimate_export_size_for_settings(
    settings: ExportSettings, duration_seconds: float
) -> StorageEstimate:
    video_bitrate_bps = _parse_bitrate_string(settings.preset.video_bitrate)
    audio_bitrate_bps = _parse_bitrate_string(settings.preset.audio_bitrate)
    return estimate_storage(duration_seconds, video_bitrate_bps, audio_bitrate_bps)


def _parse_bitrate_string(value: str | None) -> float:
    """Parse ffmpeg-style bitrate strings ('80M', '384k') to bits/second.

    Codecs without a fixed target bitrate (ProRes/FFV1/etc, where `None`)
    contribute 0 here -- their real output size cannot be estimated this
    way; callers should treat such estimates as a lower bound only.
    """
    if not value:
        return 0.0
    value = value.strip()
    multiplier = 1.0
    if value.lower().endswith("k"):
        multiplier = 1_000.0
        value = value[:-1]
    elif value.lower().endswith("m"):
        multiplier = 1_000_000.0
        value = value[:-1]
    try:
        return float(value) * multiplier
    except ValueError:
        return 0.0


@dataclass(frozen=True, slots=True)
class ExportSizeEstimate:
    estimated_bytes: float
    estimated_gb: float
    estimated_tb: float
    is_estimate: bool = True  # ALWAYS True: never presented as an exact figure


def estimate_export_size(
    duration_seconds: float, video_bitrate: float, audio_bitrate: float = 0.0
) -> ExportSizeEstimate:
    storage = estimate_storage(duration_seconds, video_bitrate, audio_bitrate)
    return ExportSizeEstimate(
        estimated_bytes=storage.bytes_decimal,
        estimated_gb=storage.gb_decimal,
        estimated_tb=storage.tb_decimal,
    )
