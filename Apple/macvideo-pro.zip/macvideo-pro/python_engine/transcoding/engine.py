"""FFmpegRunner: the one validated abstraction for every transcode/proxy/export.

Every external ffmpeg invocation for encoding work in the engine goes
through this class -- no raw `subprocess` calls scattered through
`transcoding/`, `proxies/`, or `library/`. Commands are always built as
argv lists (never string-concatenated shell commands), and every
parameter is validated before being placed on the command line.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from python_engine.core.errors import EncodeError, ValidationError
from python_engine.core.external import resolve_executable
from python_engine.core.logging import get_logger
from python_engine.core.paths import expand_and_resolve, require_existing_file

_log = get_logger("transcoding.ffmpeg_runner")

# Conservative allow-list: codec names must look like real codec
# identifiers (letters, digits, underscore, dot, hyphen) -- this exists to
# stop a codec string containing shell metacharacters or path separators
# from ever reaching the command line, even though we already use
# shell=False everywhere (defence in depth, not the only guard).
_SAFE_TOKEN = re.compile(r"^[A-Za-z0-9_.\-]+$")


def _validate_token(name: str, value: str) -> str:
    if not value or not _SAFE_TOKEN.match(value):
        raise ValidationError(f"Invalid {name}: {value!r}")
    return value


def _validate_dimension(name: str, value: int) -> int:
    if value <= 0 or value > 16384:
        raise ValidationError(f"Invalid {name}: {value} (must be 1-16384)")
    return value


@dataclass(frozen=True, slots=True)
class EncodeProgress:
    frame: int | None = None
    fps: float | None = None
    out_time_seconds: float | None = None
    speed: str | None = None
    progress: float | None = None  # 0.0-1.0, only if total duration is known


@dataclass(frozen=True, slots=True)
class TranscodeRequest:
    source: Path
    destination: Path
    video_codec: str | None = None
    audio_codec: str | None = None
    width: int | None = None
    height: int | None = None
    frame_rate: float | None = None
    video_bitrate: str | None = None  # e.g. "80M"
    audio_bitrate: str | None = None  # e.g. "384k"
    container: str | None = None  # forced output format, if the extension is ambiguous
    pixel_format: str | None = None
    extra_args: tuple[str, ...] = field(default_factory=tuple)
    overwrite: bool = True
    hardware_encoder: str | None = None  # e.g. "hevc_videotoolbox"


def _progress_line_to_dict(buffer: dict[str, str]) -> EncodeProgress:
    def _f(key: str) -> float | None:
        raw = buffer.get(key)
        if raw is None or raw in {"N/A", ""}:
            return None
        try:
            return float(raw)
        except ValueError:
            return None

    def _i(key: str) -> int | None:
        val = _f(key)
        return int(val) if val is not None else None

    out_time_us = buffer.get("out_time_us") or buffer.get("out_time_ms")
    out_time_seconds = None
    if out_time_us not in (None, "N/A"):
        try:
            out_time_seconds = float(out_time_us) / 1_000_000.0
        except ValueError:
            out_time_seconds = None

    return EncodeProgress(
        frame=_i("frame"),
        fps=_f("fps"),
        out_time_seconds=out_time_seconds,
        speed=(buffer.get("speed") or "").strip() or None,
    )


class FFmpegRunner:
    def __init__(self, ffmpeg_path: str = "ffmpeg", ffprobe_path: str = "ffprobe") -> None:
        self.ffmpeg_path = resolve_executable(ffmpeg_path)
        self.ffprobe_path = ffprobe_path

    def build_transcode_argv(self, request: TranscodeRequest) -> list[str]:
        argv: list[str] = [self.ffmpeg_path, "-hide_banner", "-y" if request.overwrite else "-n"]
        argv += ["-i", str(request.source)]

        filters: list[str] = []
        if request.width and request.height:
            w = _validate_dimension("width", request.width)
            h = _validate_dimension("height", request.height)
            filters.append(f"scale={w}:{h}")
        if filters:
            argv += ["-vf", ",".join(filters)]

        if request.hardware_encoder:
            argv += ["-c:v", _validate_token("hardware_encoder", request.hardware_encoder)]
        elif request.video_codec:
            argv += ["-c:v", _validate_token("video_codec", request.video_codec)]

        if request.pixel_format:
            argv += ["-pix_fmt", _validate_token("pixel_format", request.pixel_format)]
        if request.frame_rate:
            if request.frame_rate <= 0 or request.frame_rate > 1000:
                raise ValidationError(f"Invalid frame_rate: {request.frame_rate}")
            argv += ["-r", f"{request.frame_rate:.6g}"]
        if request.video_bitrate:
            argv += ["-b:v", _validate_token("video_bitrate", request.video_bitrate)]

        if request.audio_codec:
            argv += ["-c:a", _validate_token("audio_codec", request.audio_codec)]
        if request.audio_bitrate:
            argv += ["-b:a", _validate_token("audio_bitrate", request.audio_bitrate)]

        if request.container:
            argv += ["-f", _validate_token("container", request.container)]

        argv += list(request.extra_args)
        argv += ["-progress", "pipe:1", "-nostats", str(request.destination)]
        return argv

    def transcode(
        self,
        *,
        source: str,
        destination: str,
        video_codec: str | None = None,
        audio_codec: str | None = None,
        width: int | None = None,
        height: int | None = None,
        frame_rate: float | None = None,
        video_bitrate: str | None = None,
        audio_bitrate: str | None = None,
        container: str | None = None,
        pixel_format: str | None = None,
        hardware_encoder: str | None = None,
        extra_args: tuple[str, ...] = (),
        on_progress: Callable[[EncodeProgress], None] | None = None,
        cancel_check: Callable[[], bool] | None = None,
    ) -> Path:
        """Run a transcode to completion, optionally reporting real progress.

        `on_progress` is called with parsed encoder progress (frame/fps/
        speed/out_time) read directly from ffmpeg's `-progress` stream --
        never fabricated. Writes go to a `.partial` sibling of the real
        destination (`core.tempfile.TemporaryMediaFile`) and are only
        atomically renamed into place on a clean, successful exit -- a
        reader can never observe a half-written file at `destination`. If
        `cancel_check` returns True mid-encode, or the encoder exits
        non-zero, the partial file is removed and nothing is renamed.
        """
        final_destination = expand_and_resolve(destination)
        # ffmpeg infers container format from the output extension; since
        # we write to a `<name>.partial` path (no recognisable media
        # extension), the container must always be explicit on the
        # command line -- inferred from the real destination's suffix if
        # the caller didn't specify one.
        effective_container = container or final_destination.suffix.lstrip(".") or None

        from python_engine.core.tempfile import TemporaryMediaFile

        temp_file = TemporaryMediaFile(final_destination)

        request = TranscodeRequest(
            source=require_existing_file(source),
            destination=final_destination,  # retained for error messages only
            video_codec=video_codec,
            audio_codec=audio_codec,
            width=width,
            height=height,
            frame_rate=frame_rate,
            video_bitrate=video_bitrate,
            audio_bitrate=audio_bitrate,
            container=effective_container,
            pixel_format=pixel_format,
            hardware_encoder=hardware_encoder,
            extra_args=extra_args,
        )

        with temp_file as temp_path:
            from dataclasses import replace

            write_request = replace(request, destination=temp_path)
            argv = self.build_transcode_argv(write_request)
            _log.info("starting transcode", extra={"context": {"argv": argv}})

            import subprocess

            proc = subprocess.Popen(
                argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
            assert proc.stdout is not None

            buffer: dict[str, str] = {}
            cancelled = False
            try:
                for line in proc.stdout:
                    line = line.strip()
                    if not line:
                        continue
                    if "=" not in line:
                        continue
                    key, _, value = line.partition("=")
                    buffer[key] = value

                    if key == "progress":
                        if on_progress is not None:
                            on_progress(_progress_line_to_dict(buffer))
                        buffer = {}

                    if cancel_check is not None and cancel_check():
                        proc.terminate()
                        proc.wait(timeout=10)
                        cancelled = True
                        break
            finally:
                proc.stdout.close()

            if cancelled:
                raise EncodeError("Transcode cancelled", path=str(final_destination))

            stderr_output = proc.stderr.read() if proc.stderr else ""
            returncode = proc.wait()

            if returncode != 0:
                raise EncodeError(
                    f"ffmpeg exited with status {returncode}: {stderr_output.strip()[-1000:]}",
                    path=str(final_destination),
                )

            return temp_file.commit()

    def probe_supported_hwaccels(self) -> tuple[str, ...]:
        from python_engine.core.external import run_external

        result = run_external([self.ffmpeg_path, "-hide_banner", "-hwaccels"], check=False)
        if result.returncode != 0:
            return ()
        lines = result.stdout.decode("utf-8", errors="replace").splitlines()
        return tuple(line.strip() for line in lines[1:] if line.strip())
