"""The `TranscodeJob` description (spec section 35).

A plain, serialisable description of one transcode operation. Execution
lives in `transcoding.engine.FFmpegRunner`; queueing/state lives in
`transcoding.queue`. This module is intentionally just the data shape.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field


@dataclass(slots=True)
class TranscodeJob:
    source: str
    destination: str
    video_codec: str | None = None
    audio_codec: str | None = None
    resolution: tuple[int, int] | None = None
    frame_rate: float | None = None
    bitrate: str | None = None
    quality: str | None = None  # codec-specific quality hint (e.g. CRF value as string)
    container: str | None = None
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "source": self.source,
            "destination": self.destination,
            "video_codec": self.video_codec,
            "audio_codec": self.audio_codec,
            "resolution": list(self.resolution) if self.resolution else None,
            "frame_rate": self.frame_rate,
            "bitrate": self.bitrate,
            "quality": self.quality,
            "container": self.container,
        }

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> "TranscodeJob":
        resolution = data.get("resolution")
        return cls(
            id=str(data.get("id") or uuid.uuid4()),
            source=str(data["source"]),
            destination=str(data["destination"]),
            video_codec=data.get("video_codec"),  # type: ignore[arg-type]
            audio_codec=data.get("audio_codec"),  # type: ignore[arg-type]
            resolution=tuple(resolution) if resolution else None,  # type: ignore[arg-type]
            frame_rate=data.get("frame_rate"),  # type: ignore[arg-type]
            bitrate=data.get("bitrate"),  # type: ignore[arg-type]
            quality=data.get("quality"),  # type: ignore[arg-type]
            container=data.get("container"),  # type: ignore[arg-type]
        )
