"""Bitrate and storage calculation.

Two distinct concerns kept clearly separate here, per the spec:

1. `estimate_storage` / `calculate_bitrate` -- real-world *compressed*
   media, where bitrate is inherently an *average* for VBR content.
2. `raw_frame_size` / `raw_video_storage` -- theoretical *uncompressed*
   storage, useful only for engineering estimation (e.g. "how big would an
   uncompressed 8K ProRes-free intermediate be"), never to be confused with
   actual compressed file sizes.
"""

from __future__ import annotations

from dataclasses import dataclass

_DECIMAL_KILO = 1000.0
_BINARY_KILO = 1024.0


@dataclass(frozen=True, slots=True)
class BitrateResult:
    bits_per_second: float
    mbps: float
    gbps: float
    is_average: bool = True
    label: str = "average bitrate"


def calculate_bitrate(file_size_bytes: int, duration_seconds: float) -> BitrateResult:
    """Compute bitrate from file size and duration.

    Any bitrate derived this way (rather than read directly from an
    encoder's CBR setting) is definitionally an *average* -- this is always
    labelled as such, since real-world media is overwhelmingly VBR.
    """
    if duration_seconds <= 0:
        raise ValueError("duration_seconds must be > 0")
    if file_size_bytes < 0:
        raise ValueError("file_size_bytes must be >= 0")

    bits_per_second = (file_size_bytes * 8) / duration_seconds
    mbps = bits_per_second / (_DECIMAL_KILO**2)
    gbps = bits_per_second / (_DECIMAL_KILO**3)
    return BitrateResult(bits_per_second=bits_per_second, mbps=mbps, gbps=gbps)


@dataclass(frozen=True, slots=True)
class StorageEstimate:
    total_bits: float
    bytes_decimal: float  # informational: raw byte count
    mb_decimal: float  # MB = 1000^2 bytes
    gb_decimal: float  # GB = 1000^3 bytes
    tb_decimal: float  # TB = 1000^4 bytes
    mib_binary: float  # MiB = 1024^2 bytes
    gib_binary: float  # GiB = 1024^3 bytes
    tib_binary: float  # TiB = 1024^4 bytes


def estimate_storage(
    duration_seconds: float,
    video_bitrate_bps: float,
    audio_bitrate_bps: float = 0,
) -> StorageEstimate:
    """Estimate storage required for given duration + bitrate(s).

    Bitrates are expected in bits per second. Returns both decimal
    (MB/GB/TB, base 1000) and binary (MiB/GiB/TiB, base 1024) units
    explicitly, since the two are routinely confused and differ by ~7% at
    the GB/GiB scale.
    """
    if duration_seconds < 0:
        raise ValueError("duration_seconds must be >= 0")
    if video_bitrate_bps < 0 or audio_bitrate_bps < 0:
        raise ValueError("bitrates must be >= 0")

    total_bits = (video_bitrate_bps + audio_bitrate_bps) * duration_seconds
    total_bytes = total_bits / 8

    return StorageEstimate(
        total_bits=total_bits,
        bytes_decimal=total_bytes,
        mb_decimal=total_bytes / _DECIMAL_KILO**2,
        gb_decimal=total_bytes / _DECIMAL_KILO**3,
        tb_decimal=total_bytes / _DECIMAL_KILO**4,
        mib_binary=total_bytes / _BINARY_KILO**2,
        gib_binary=total_bytes / _BINARY_KILO**3,
        tib_binary=total_bytes / _BINARY_KILO**4,
    )


def raw_frame_size(width: int, height: int, bytes_per_pixel: float) -> int:
    """Raw uncompressed size of a single frame, in bytes.

    ENGINEERING ESTIMATE ONLY. e.g. for 7680x4320 RGBA 8-bit
    (`bytes_per_pixel=4`): ~132.7 MB, matching the spec's own reference
    figure.
    """
    if width <= 0 or height <= 0:
        raise ValueError("width/height must be > 0")
    if bytes_per_pixel <= 0:
        raise ValueError("bytes_per_pixel must be > 0")
    return int(round(width * height * bytes_per_pixel))


def raw_video_storage(
    width: int,
    height: int,
    fps: float,
    duration_seconds: float,
    bytes_per_pixel: float,
) -> int:
    """Raw uncompressed storage for an entire clip, in bytes.

    ENGINEERING ESTIMATE ONLY -- this is *not* a prediction of compressed
    file size; real encoders (H.264/HEVC/ProRes/etc.) achieve large
    reductions versus this number. Useful for sizing scratch-disk or
    intermediate-codec capacity planning.
    """
    if fps <= 0:
        raise ValueError("fps must be > 0")
    if duration_seconds < 0:
        raise ValueError("duration_seconds must be >= 0")

    frame_size = raw_frame_size(width, height, bytes_per_pixel)
    frame_count = fps * duration_seconds
    return int(round(frame_size * frame_count))


def format_bytes_decimal(num_bytes: float) -> str:
    """Human-readable decimal (1000-based) size string, e.g. '4.20 GB'."""
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if abs(num_bytes) < _DECIMAL_KILO or unit == "PB":
            return f"{num_bytes:.2f} {unit}"
        num_bytes /= _DECIMAL_KILO
    return f"{num_bytes:.2f} PB"


def format_bytes_binary(num_bytes: float) -> str:
    """Human-readable binary (1024-based) size string, e.g. '3.91 GiB'."""
    for unit in ("B", "KiB", "MiB", "GiB", "TiB", "PiB"):
        if abs(num_bytes) < _BINARY_KILO or unit == "PiB":
            return f"{num_bytes:.2f} {unit}"
        num_bytes /= _BINARY_KILO
    return f"{num_bytes:.2f} PiB"
