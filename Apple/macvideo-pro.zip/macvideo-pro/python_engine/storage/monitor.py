"""Storage throughput monitoring.

Measures real read/write speed against the actual filesystem (small,
bounded-size probe files -- never large enough to be a meaningful I/O
burden itself) and reports available space. Never assumes every volume
performs the same; results are always tied to the specific path/volume
tested.
"""

from __future__ import annotations

import os
import shutil
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from python_engine.core.errors import StorageError
from python_engine.core.paths import VolumeInfo, classify_volume, expand_and_resolve

_PROBE_SIZE_BYTES = 32 * 1024 * 1024  # 32 MiB -- big enough to move past OS cache noise floor


@dataclass(frozen=True, slots=True)
class ThroughputMeasurement:
    path: str
    volume: VolumeInfo
    write_mb_per_sec: float | None
    read_mb_per_sec: float | None
    free_bytes: int
    total_bytes: int


class StorageMonitor:
    def measure(self, path: str, *, probe_size_bytes: int = _PROBE_SIZE_BYTES) -> ThroughputMeasurement:
        target_dir = expand_and_resolve(path)
        if target_dir.is_file():
            target_dir = target_dir.parent
        if not target_dir.is_dir():
            raise StorageError(f"Not a directory: {target_dir}")

        volume = classify_volume(target_dir)
        usage = shutil.disk_usage(target_dir)

        write_speed = self._measure_write(target_dir, probe_size_bytes)
        read_speed = self._measure_read(target_dir, probe_size_bytes) if write_speed is not None else None

        return ThroughputMeasurement(
            path=str(target_dir),
            volume=volume,
            write_mb_per_sec=write_speed,
            read_mb_per_sec=read_speed,
            free_bytes=usage.free,
            total_bytes=usage.total,
        )

    def _measure_write(self, directory: Path, size_bytes: int) -> float | None:
        payload = os.urandom(min(size_bytes, 4 * 1024 * 1024))
        repeats = max(1, size_bytes // len(payload))
        tmp_path: Path | None = None

        try:
            with tempfile.NamedTemporaryFile(dir=directory, delete=False) as fh:
                tmp_path = Path(fh.name)
                start = time.perf_counter()
                for _ in range(repeats):
                    fh.write(payload)
                fh.flush()
                os.fsync(fh.fileno())
                elapsed = time.perf_counter() - start
        except OSError:
            return None
        finally:
            if tmp_path is not None:
                tmp_path.unlink(missing_ok=True)

        if elapsed <= 0:
            return None
        written_mb = (repeats * len(payload)) / (1024 * 1024)
        return written_mb / elapsed

    def _measure_read(self, directory: Path, size_bytes: int) -> float | None:
        payload = os.urandom(min(size_bytes, 4 * 1024 * 1024))
        repeats = max(1, size_bytes // len(payload))
        tmp_path: Path | None = None

        try:
            with tempfile.NamedTemporaryFile(dir=directory, delete=False) as fh:
                tmp_path = Path(fh.name)
                for _ in range(repeats):
                    fh.write(payload)
                fh.flush()
                os.fsync(fh.fileno())

            start = time.perf_counter()
            with open(tmp_path, "rb") as fh:
                while fh.read(4 * 1024 * 1024):
                    pass
            elapsed = time.perf_counter() - start
        except OSError:
            return None
        finally:
            if tmp_path is not None:
                tmp_path.unlink(missing_ok=True)

        if elapsed <= 0:
            return None
        read_mb = (repeats * len(payload)) / (1024 * 1024)
        return read_mb / elapsed
