import { ICloudItem, Workspace, ComputeJob, TaskRecipe, ActivityEvent } from './types';

// High-fidelity SVG-based data URIs for sample images so they can be rendered and drawn to Canvas without cross-origin issues
const sampleLandscapeSvg = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800">
  <defs>
    <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="%231a365d"/>
      <stop offset="50%" stop-color="%234299e1"/>
      <stop offset="85%" stop-color="%23ed8936"/>
      <stop offset="100%" stop-color="%23ecc94b"/>
    </linearGradient>
    <linearGradient id="mountains" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="%232d3748"/>
      <stop offset="100%" stop-color="%231a202c"/>
    </linearGradient>
    <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="%232b6cb0"/>
      <stop offset="100%" stop-color="%231a365d"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="800" fill="url(%23sky)"/>
  <circle cx="950" cy="420" r="85" fill="%23fffaf0" opacity="0.9"/>
  <polygon points="0,520 280,360 520,520" fill="url(%23mountains)" opacity="0.75"/>
  <polygon points="340,540 680,310 980,540" fill="url(%23mountains)" opacity="0.85"/>
  <polygon points="760,530 1020,380 1200,510" fill="url(%23mountains)" opacity="0.9"/>
  <rect y="520" width="1200" height="280" fill="url(%23sea)"/>
  <ellipse cx="600" cy="530" rx="400" ry="8" fill="%23ecc94b" opacity="0.4"/>
  <text x="60" y="90" font-family="-apple-system, sans-serif" font-size="28" font-weight="600" fill="%23ffffff" letter-spacing="1">Big Sur Pacific Coastline · RAW Capture</text>
  <text x="60" y="125" font-family="-apple-system, sans-serif" font-size="16" fill="%23e2e8f0">Exposure: 1/250s · f/8.0 · ISO 100 · 35mm</text>
</svg>`;

const sampleArchitectureSvg = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="%2318181b"/>
      <stop offset="100%" stop-color="%2327272a"/>
    </linearGradient>
    <linearGradient id="beam" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="%230ea5e9"/>
      <stop offset="100%" stop-color="%2338bdf8"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="800" fill="url(%23bg)"/>
  <g stroke="%233f3f46" stroke-width="1.5" stroke-dasharray="6 6">
    <line x1="100" y1="100" x2="1100" y2="100"/>
    <line x1="100" y1="300" x2="1100" y2="300"/>
    <line x1="100" y1="500" x2="1100" y2="500"/>
    <line x1="100" y1="700" x2="1100" y2="700"/>
    <line x1="200" y1="50" x2="200" y2="750"/>
    <line x1="600" y1="50" x2="600" y2="750"/>
    <line x1="1000" y1="50" x2="1000" y2="750"/>
  </g>
  <rect x="240" y="240" width="720" height="340" rx="16" fill="%2309090b" stroke="%230ea5e9" stroke-width="2"/>
  <text x="290" y="320" font-family="-apple-system, sans-serif" font-size="32" font-weight="700" fill="%23ffffff">Apple Silicon M-Series Node Architecture</text>
  <text x="290" y="365" font-family="-apple-system, sans-serif" font-size="18" fill="%2394a3b8">Unified Memory Architecture (UMA) · 128 GB/s Bandwidth</text>
  <rect x="290" y="410" width="200" height="110" rx="8" fill="%2318181b" stroke="%2338bdf8" stroke-width="1"/>
  <text x="310" y="450" font-family="-apple-system, sans-serif" font-size="16" font-weight="600" fill="%2338bdf8">Neural Engine</text>
  <text x="310" y="480" font-family="-apple-system, sans-serif" font-size="13" fill="%23a1a1aa">16-Core Matrix Units</text>
  <rect x="520" y="410" width="200" height="110" rx="8" fill="%2318181b" stroke="%23a855f7" stroke-width="1"/>
  <text x="540" y="450" font-family="-apple-system, sans-serif" font-size="16" font-weight="600" fill="%23c084fc">Performance Cores</text>
  <text x="540" y="480" font-family="-apple-system, sans-serif" font-size="13" fill="%23a1a1aa">12-Core Low Latency</text>
  <rect x="750" y="410" width="180" height="110" rx="8" fill="%2318181b" stroke="%2310b981" stroke-width="1"/>
  <text x="770" y="450" font-family="-apple-system, sans-serif" font-size="16" font-weight="600" fill="%2334d399">Storage Fabric</text>
  <text x="770" y="480" font-family="-apple-system, sans-serif" font-size="13" fill="%23a1a1aa">NVMe APFS Direct</text>
</svg>`;

export const sampleTelemetryCsv = `Region,Datacenter,Nodes,CpuUtilPercent,MemoryGB,NetworkIO_GB,LatencyMs,CostUSD
us-west-1,SJC-01,24,68.4,192,412.5,12.8,1420.50
us-west-2,PDX-04,36,74.2,288,680.1,16.4,2130.00
us-east-1,IAD-09,48,88.1,384,1150.2,22.1,3280.75
us-east-2,CMH-02,20,59.3,160,320.0,18.7,1190.20
eu-west-1,DUB-03,32,71.0,256,540.8,28.5,1980.00
eu-central-1,FRA-05,28,64.8,224,495.2,31.2,1850.40
ap-northeast-1,HND-01,22,62.5,176,380.6,94.2,1540.00
ap-southeast-1,SIN-02,18,55.2,144,290.4,110.6,1280.00`;

export const sampleMarkdownDoc = `# iCloud Personal Compute Architecture

## Executive Summary
This document outlines the hybrid personal cloud model combining **Apple Silicon local execution** with **remote FastAPI containerised workers**.

### Core Guarantees
- **Local Sandbox Priority**: Tasks with small input sizes or privacy tags run in the macOS App Sandbox using native Swift concurrency.
- **Remote Worker Scalability**: Heavy batch jobs automatically delegate to verified FastAPI endpoints with streaming telemetry.
- **Durable Storage**: Files are confirmed via SHA-256 digests prior to marking synchronisation as complete.
- **Zero-Trust Token Store**: Credentials are held exclusively in the macOS Keychain and never logged or serialized to disk.

### Supported File Formats
1. **Visual**: PNG, JPEG, WebP, TIFF, SVG, HEIC
2. **Datasets**: CSV, TSV, Parquet, JSON
3. **Documents**: Markdown, TXT, PDF, Rich Text
4. **Archives**: ZIP, TAR.GZ

### Security Invariants
- Path traversal protection on all archive extractions.
- Bounded memory limits (4GB per worker process).
- Automatic temporary directory purge on process exit.
`;

export const initialFiles: ICloudItem[] = [
  // Folders
  {
    id: 'folder-design',
    name: 'Design Assets',
    kind: 'folder',
    size: 4820000,
    modifiedAt: '2026-11-07T14:22:00Z',
    parentId: null,
    tags: ['blue'],
    isFavorite: true,
    status: 'local',
    mimeType: 'inode/directory',
    versionHistory: [{ version: 1, timestamp: '2026-11-01T10:00:00Z', size: 0, checksum: 'dir_hash_01', note: 'Created folder' }],
    hasLocalCache: true,
    isPinned: true,
  },
  {
    id: 'folder-telemetry',
    name: 'Telemetry Datasets',
    kind: 'folder',
    size: 2150000,
    modifiedAt: '2026-11-06T09:15:00Z',
    parentId: null,
    tags: ['purple', 'green'],
    isFavorite: true,
    status: 'local',
    mimeType: 'inode/directory',
    versionHistory: [{ version: 1, timestamp: '2026-11-02T11:00:00Z', size: 0, checksum: 'dir_hash_02', note: 'Created folder' }],
    hasLocalCache: true,
    isPinned: true,
  },
  {
    id: 'folder-docs',
    name: 'Engineering Documents',
    kind: 'folder',
    size: 890000,
    modifiedAt: '2026-11-05T16:40:00Z',
    parentId: null,
    tags: ['orange'],
    isFavorite: false,
    status: 'cloud',
    mimeType: 'inode/directory',
    versionHistory: [{ version: 1, timestamp: '2026-11-01T08:00:00Z', size: 0, checksum: 'dir_hash_03', note: 'Created folder' }],
    hasLocalCache: false,
  },
  {
    id: 'folder-backups',
    name: 'Archive Backups',
    kind: 'folder',
    size: 15400000,
    modifiedAt: '2026-11-04T18:00:00Z',
    parentId: null,
    tags: ['gray'],
    isFavorite: false,
    status: 'local',
    mimeType: 'inode/directory',
    versionHistory: [{ version: 1, timestamp: '2026-11-01T08:00:00Z', size: 0, checksum: 'dir_hash_04', note: 'Created folder' }],
    hasLocalCache: true,
  },

  // Files in Root
  {
    id: 'file-landscape-01',
    name: 'Big_Sur_Coastline_Sunset.jpg',
    kind: 'image',
    size: 2450000,
    modifiedAt: '2026-11-08T01:10:00Z',
    parentId: 'folder-design',
    tags: ['blue', 'yellow'],
    isFavorite: true,
    status: 'local',
    checksum: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    content: sampleLandscapeSvg,
    mimeType: 'image/jpeg',
    versionHistory: [
      { version: 2, timestamp: '2026-11-08T01:10:00Z', size: 2450000, checksum: 'e3b0c442...', note: 'Color grading applied' },
      { version: 1, timestamp: '2026-11-07T12:00:00Z', size: 3100000, checksum: '9a4f210b...', note: 'RAW import' },
    ],
    hasLocalCache: true,
    isPinned: true,
  },
  {
    id: 'file-arch-01',
    name: 'Apple_Silicon_UMA_Diagram.png',
    kind: 'image',
    size: 1820000,
    modifiedAt: '2026-11-07T18:30:00Z',
    parentId: 'folder-design',
    tags: ['blue'],
    isFavorite: false,
    status: 'local',
    checksum: '6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b',
    content: sampleArchitectureSvg,
    mimeType: 'image/png',
    versionHistory: [{ version: 1, timestamp: '2026-11-07T18:30:00Z', size: 1820000, checksum: '6b86b273...', note: 'Exported diagram' }],
    hasLocalCache: true,
  },
  {
    id: 'file-telemetry-01',
    name: 'Quarterly_Cloud_Telemetry.csv',
    kind: 'dataset',
    size: 42800,
    modifiedAt: '2026-11-08T02:45:00Z',
    parentId: 'folder-telemetry',
    tags: ['green'],
    isFavorite: true,
    status: 'local',
    checksum: 'd4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35',
    content: sampleTelemetryCsv,
    mimeType: 'text/csv',
    versionHistory: [
      { version: 3, timestamp: '2026-11-08T02:45:00Z', size: 42800, checksum: 'd4735e3a...', note: 'Appended AP-Northeast region' },
      { version: 2, timestamp: '2026-11-07T15:20:00Z', size: 38200, checksum: '7b2a9914...', note: 'Added CostUSD column' },
      { version: 1, timestamp: '2026-11-06T10:00:00Z', size: 31000, checksum: '1c4320ee...', note: 'Initial telemetry dump' },
    ],
    hasLocalCache: true,
    isPinned: true,
    workspaceId: 'ws-infra',
  },
  {
    id: 'file-markdown-01',
    name: 'Architecture_Specification.md',
    kind: 'document',
    size: 18500,
    modifiedAt: '2026-11-07T21:10:00Z',
    parentId: 'folder-docs',
    tags: ['orange'],
    isFavorite: true,
    status: 'local',
    checksum: '4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce',
    content: sampleMarkdownDoc,
    mimeType: 'text/markdown',
    versionHistory: [{ version: 1, timestamp: '2026-11-07T21:10:00Z', size: 18500, checksum: '4e074085...', note: 'Initial draft' }],
    hasLocalCache: true,
    workspaceId: 'ws-infra',
    isShared: true,
    shareRole: 'view',
  },
  {
    id: 'file-backup-01',
    name: 'Developer_Signing_Keys_Archive.zip',
    kind: 'archive',
    size: 5400000,
    modifiedAt: '2026-11-03T11:20:00Z',
    parentId: 'folder-backups',
    tags: ['red'],
    isFavorite: false,
    status: 'cloud',
    checksum: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
    mimeType: 'application/zip',
    versionHistory: [{ version: 1, timestamp: '2026-11-03T11:20:00Z', size: 5400000, checksum: '4b227777...', note: 'Automated encrypted backup' }],
    hasLocalCache: false,
  },
  {
    id: 'file-conflict-sample',
    name: 'Production_Cluster_Configs.json',
    kind: 'code',
    size: 24500,
    modifiedAt: '2026-11-07T23:50:00Z',
    parentId: null,
    tags: ['red'],
    isFavorite: false,
    status: 'conflict',
    checksum: 'ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d',
    content: `{\n  "cluster": "prod-m3max-01",\n  "replicas": 8,\n  "memory_limit": "32Gi",\n  "fastapi_worker": "remote://10.0.12.8:8000",\n  "concurrency": 16\n}`,
    mimeType: 'application/json',
    versionHistory: [{ version: 1, timestamp: '2026-11-07T23:50:00Z', size: 24500, checksum: 'ef2d127d...', note: 'Conflict: local vs remote replica count' }],
    hasLocalCache: true,
  }
];

export const initialWorkspaces: Workspace[] = [
  {
    id: 'ws-infra',
    name: 'Cloud Telemetry & Ingestion',
    description: 'Quarterly regional compute telemetry, latency monitoring, and automated chart extraction.',
    color: '#0071e3', // Apple Blue
    icon: 'Cpu',
    itemIds: ['file-telemetry-01', 'file-markdown-01'],
    notes: 'Primary metrics pipeline. Target latency < 35ms across US and EU nodes. Run statistical summaries every morning.',
    linkedWorker: 'local',
    createdAt: '2026-11-01T08:00:00Z',
    activeRecipeId: 'recipe-csv-stats',
  },
  {
    id: 'ws-creative',
    name: 'Q4 Brand & Photography Pack',
    description: 'High-res RAW photo assets, format conversion pipelines, and WebP compression.',
    color: '#8e44ad',
    icon: 'Image',
    itemIds: ['file-landscape-01', 'file-arch-01'],
    notes: 'Resize all assets to max 1920px width and convert to WebP at 85% quality for web delivery.',
    linkedWorker: 'remote',
    createdAt: '2026-11-02T10:30:00Z',
    activeRecipeId: 'recipe-photo-pipeline',
  },
  {
    id: 'ws-security',
    name: 'Cryptographic Audits & Checksums',
    description: 'SHA-256 verification, tamper detection, and signed release archives.',
    color: '#27ae60',
    icon: 'ShieldCheck',
    itemIds: ['file-backup-01', 'file-conflict-sample'],
    notes: 'Verify hash manifests before publishing release binaries to production workers.',
    linkedWorker: 'local',
    createdAt: '2026-11-03T14:15:00Z',
  }
];

export const initialRecipes: TaskRecipe[] = [
  {
    id: 'recipe-photo-pipeline',
    name: 'Photographs → Resize → WebP → Hash',
    description: 'Batch process raw photos: downscale to web dimensions, transcode to WebP, and compute SHA-256 integrity hash.',
    icon: 'Camera',
    steps: [
      {
        stepId: 'step-1',
        taskType: 'image_resize_convert',
        name: 'Resize & Convert to WebP',
        params: { maxWidth: 1200, maxHeight: 800, format: 'webp', quality: 0.85, grayscale: false }
      },
      {
        stepId: 'step-2',
        taskType: 'checksum_verify',
        name: 'Generate SHA-256 Digest',
        params: { algorithm: 'SHA-256' }
      }
    ]
  },
  {
    id: 'recipe-csv-stats',
    name: 'CSV → Statistical Analysis → Chart',
    description: 'Validate columns, calculate means & distributions, and render visual SVG telemetry chart.',
    icon: 'BarChart2',
    steps: [
      {
        stepId: 'step-1',
        taskType: 'csv_summary_stats',
        name: 'Calculate Column Statistics',
        params: { computeCorrelation: true }
      },
      {
        stepId: 'step-2',
        taskType: 'dataset_chart',
        name: 'Render Regional Latency Chart',
        params: { chartType: 'bar', xColumn: 'Region', yColumn: 'LatencyMs' }
      }
    ]
  },
  {
    id: 'recipe-doc-bundle',
    name: 'Documents → Text Extraction → Secure ZIP',
    description: 'Extract plain text, compute word count and reading metrics, and bundle safely into a zip archive.',
    icon: 'FileText',
    steps: [
      {
        stepId: 'step-1',
        taskType: 'document_text_extract',
        name: 'Extract Text & Readability Metrics',
        params: { includeHeaders: true }
      },
      {
        stepId: 'step-2',
        taskType: 'archive_pack',
        name: 'Create Verified ZIP Bundle',
        params: { archiveName: 'Ingested_Documentation_Bundle.zip' }
      }
    ]
  }
];

export const initialJobs: ComputeJob[] = [
  {
    id: 'job-mc8f2a19',
    taskType: 'csv_summary_stats',
    taskTitle: 'Quarterly Telemetry Statistical Summary',
    status: 'completed',
    workerType: 'local',
    workerName: 'This Mac (M3 Max Local Sandbox)',
    inputItemIds: ['file-telemetry-01'],
    inputNames: ['Quarterly_Cloud_Telemetry.csv'],
    parameters: { computeCorrelation: true },
    outputItemIds: [],
    outputSummary: 'Processed 8 datacenter regions. Mean CPU: 67.9%, Mean Latency: 41.7ms. Standard deviation: 36.8ms.',
    progress: 100,
    currentStep: 'Execution complete',
    logs: [
      { timestamp: '03:15:10', level: 'info', message: 'Job queued into local thread pool.' },
      { timestamp: '03:15:11', level: 'info', message: 'Loaded Quarterly_Cloud_Telemetry.csv (42.8 KB).' },
      { timestamp: '03:15:12', level: 'info', message: 'Computed distribution over 8 regions.' },
      { timestamp: '03:15:12', level: 'success', message: 'Calculated descriptive stats for 5 numeric columns.' }
    ],
    metrics: {
      cpuPercent: 18.4,
      memoryMb: 42,
      wallClockMs: 820,
      ioBytes: 43820
    },
    submittedAt: '2026-11-08T03:15:10Z',
    completedAt: '2026-11-08T03:15:12Z'
  },
  {
    id: 'job-df991c04',
    taskType: 'image_resize_convert',
    taskTitle: 'Batch Transcode Coastline RAW to WebP',
    status: 'completed',
    workerType: 'local',
    workerName: 'This Mac (M3 Max Local Sandbox)',
    inputItemIds: ['file-landscape-01'],
    inputNames: ['Big_Sur_Coastline_Sunset.jpg'],
    parameters: { maxWidth: 1200, maxHeight: 800, format: 'webp', quality: 0.85 },
    outputItemIds: [],
    outputSummary: 'Successfully converted 1200x800 image to WebP. Compressed from 2.45 MB to 418 KB (-83%).',
    progress: 100,
    currentStep: 'Saved to iCloud',
    logs: [
      { timestamp: '03:18:00', level: 'info', message: 'Spawned image worker on Apple Silicon GPU/NE.' },
      { timestamp: '03:18:01', level: 'info', message: 'Rescaling canvas to 1200x800 px.' },
      { timestamp: '03:18:01', level: 'success', message: 'Transcoded WebP payload. Checksum calculated.' }
    ],
    metrics: {
      cpuPercent: 32.1,
      memoryMb: 88,
      wallClockMs: 1450,
      ioBytes: 2868000
    },
    submittedAt: '2026-11-08T03:18:00Z',
    completedAt: '2026-11-08T03:18:02Z'
  }
];

export const initialActivities: ActivityEvent[] = [
  {
    id: 'act-01',
    timestamp: '2026-11-08T03:18:02Z',
    type: 'compute_job',
    title: 'Completed WebP Transcode',
    detail: 'Big_Sur_Coastline_Sunset.jpg processed in 1.45s on This Mac.',
    status: 'success'
  },
  {
    id: 'act-02',
    timestamp: '2026-11-08T03:15:12Z',
    type: 'compute_job',
    title: 'CSV Telemetry Summarised',
    detail: 'Calculated 5 column distributions for Quarterly_Cloud_Telemetry.csv.',
    status: 'success'
  },
  {
    id: 'act-03',
    timestamp: '2026-11-07T23:50:00Z',
    type: 'conflict',
    title: 'Synchronisation Conflict Detected',
    detail: 'Production_Cluster_Configs.json modified simultaneously on Mac Studio and Remote Worker.',
    status: 'warning'
  },
  {
    id: 'act-04',
    timestamp: '2026-11-07T21:10:00Z',
    type: 'share',
    title: 'Shared Link Generated',
    detail: 'Architecture_Specification.md shared with view-only permissions.',
    status: 'info'
  },
  {
    id: 'act-05',
    timestamp: '2026-11-07T14:22:00Z',
    type: 'upload',
    title: 'Folder Synchronised',
    detail: 'Design Assets folder confirmed durable on iCloud.',
    status: 'success'
  }
];
