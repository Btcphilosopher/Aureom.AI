export interface CodeFile {
  path: string;
  name: string;
  language: 'swift' | 'python' | 'json' | 'markdown' | 'dockerfile';
  category: 'macOS (Xcode)' | 'iOS & iPadOS' | 'Python Compute Worker' | 'Tests & CI' | 'Docs';
  content: string;
}

export const codeDeliverables: CodeFile[] = [
  // 1. macOS Xcode Project - App & Entry
  {
    path: 'iCloudMac/iCloudApp.swift',
    name: 'iCloudApp.swift',
    language: 'swift',
    category: 'macOS (Xcode)',
    content: `//
//  iCloudApp.swift
//  iCloud Personal Compute Workspace for macOS
//  Created for Apple macOS Sequoia (15.0+)
//

import SwiftUI

@main
struct iCloudApp: App {
    @StateObject private var storageManager = StorageProvider()
    @StateObject private var computeCoordinator = ComputeCoordinator()
    @StateObject private var workspaceStore = WorkspaceStore()

    var body: some Scene {
        WindowGroup {
            ThreeColumnWorkspaceView()
                .environmentObject(storageManager)
                .environmentObject(computeCoordinator)
                .environmentObject(workspaceStore)
                .frame(minWidth: 1024, minHeight: 680)
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unified(showsTitle: true))
        .commands {
            SidebarCommands()
            CommandGroup(after: .newItem) {
                Button("New Folder") {
                    storageManager.createNewFolder()
                }
                .keyboardShortcut("n", modifiers: [.command, .shift])
                
                Button("Run Compute Task...") {
                    computeCoordinator.presentTaskPicker = true
                }
                .keyboardShortcut("r", modifiers: [.command])
            }
        }
        
        Settings {
            SettingsView()
                .environmentObject(computeCoordinator)
        }
    }
}`
  },

  // 2. macOS Three Column Workspace
  {
    path: 'iCloudMac/Views/ThreeColumnWorkspaceView.swift',
    name: 'ThreeColumnWorkspaceView.swift',
    language: 'swift',
    category: 'macOS (Xcode)',
    content: `//
//  ThreeColumnWorkspaceView.swift
//  iCloud Native 3-Column macOS Desktop Architecture
//

import SwiftUI

struct ThreeColumnWorkspaceView: View {
    @EnvironmentObject var storage: StorageProvider
    @EnvironmentObject var compute: ComputeCoordinator
    
    @State private var selectedDestination: NavigationDestination? = .myFiles
    @State private var selectedItemIds: Set<UUID> = []
    @State private var isInspectorPresented: Bool = true
    @State private var viewMode: ViewMode = .grid
    @State private var searchText: String = ""

    var body: some View {
        NavigationSplitView {
            // Column 1: Sidebar
            SidebarView(selection: $selectedDestination)
                .navigationSplitViewColumnWidth(min: 220, ideal: 240, max: 300)
        } content: {
            // Column 2: Central File & Workspace Browser
            FileBrowserView(
                destination: selectedDestination ?? .myFiles,
                selectedItemIds: $selectedItemIds,
                viewMode: $viewMode,
                searchText: searchText
            )
            .navigationSplitViewColumnWidth(min: 480, ideal: 640)
            .toolbar {
                ToolbarItem(placement: .navigation) {
                    ViewModeToggle(mode: $viewMode)
                }
                ToolbarItem(placement: .principal) {
                    BreadcrumbBarView()
                }
                ToolbarItem(placement: .primaryAction) {
                    HStack(spacing: 8) {
                        Button(action: { compute.presentTaskPicker = true }) {
                            Label("Run Task", systemImage: "play.circle.fill")
                        }
                        .disabled(selectedItemIds.isEmpty)
                        
                        Button(action: { isInspectorPresented.toggle() }) {
                            Label("Inspector", systemImage: "sidebar.right")
                        }
                    }
                }
            }
            .searchable(text: $searchText, placement: .toolbar, prompt: "Search files, metadata, or checksums")
        } detail: {
            // Column 3: Contextual Inspector
            if isInspectorPresented {
                InspectorView(selectedItemIds: selectedItemIds)
                    .navigationSplitViewColumnWidth(min: 260, ideal: 290, max: 360)
            } else {
                Text("Inspector Hidden")
                    .foregroundColor(.secondary)
            }
        }
        .onDrop(of: [.fileURL], isTargeted: nil) { providers in
            storage.handleExternalFinderDrop(providers: providers)
        }
    }
}`
  },

  // 3. Storage Provider & Keychain
  {
    path: 'iCloudMac/Services/StorageProvider.swift',
    name: 'StorageProvider.swift',
    language: 'swift',
    category: 'macOS (Xcode)',
    content: `//
//  StorageProvider.swift
//  Durable Local & Remote Synchronisation Protocol
//

import Foundation
import CryptoKit
import Security

public protocol StorageProviderProtocol: ObservableObject {
    func importFile(from sourceURL: URL, destinationFolderId: UUID?) async throws -> CloudItem
    func verifyDurableStorage(for item: CloudItem) async throws -> Bool
    func calculateSha256(for fileURL: URL) throws -> String
    func removeLocalCache(for item: CloudItem) async throws
}

public final class StorageProvider: StorageProviderProtocol {
    @Published public var items: [CloudItem] = []
    @Published public var uploadQueue: [TransferJob] = []
    
    private let fileManager = FileManager.default
    private let localStoreURL: URL

    public init() {
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        localStoreURL = appSupport.appendingPathComponent("com.apple.icloud.workspace/Files")
        try? fileManager.createDirectory(at: localStoreURL, withIntermediateDirectories: true)
    }

    public func calculateSha256(for fileURL: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: fileURL)
        defer { try? handle.close() }
        var hasher = SHA256()
        while autoreleasepool(invoking: {
            let data = handle.readData(ofLength: 1024 * 1024)
            guard !data.isEmpty else { return false }
            hasher.update(data: data)
            return true
        }) {}
        let digest = hasher.finalize()
        return digest.map { String(format: "%02hhx", $0) }.joined()
    }

    public func importFile(from sourceURL: URL, destinationFolderId: UUID?) async throws -> CloudItem {
        guard sourceURL.startAccessingSecurityScopedResource() else {
            throw StorageError.accessDenied
        }
        defer { sourceURL.stopAccessingSecurityScopedResource() }

        let targetURL = localStoreURL.appendingPathComponent(sourceURL.lastPathComponent)
        // Default behavior: Copy original to preserve user files
        if fileManager.fileExists(atPath: targetURL.path) {
            // Handle duplicate with explicit collision logic
            let renamed = handleDuplicate(for: targetURL)
            try fileManager.copyItem(at: sourceURL, to: renamed)
        } else {
            try fileManager.copyItem(at: sourceURL, to: targetURL)
        }

        let checksum = try calculateSha256(for: targetURL)
        let item = CloudItem(
            name: targetURL.lastPathComponent,
            url: targetURL,
            size: (try? fileManager.attributesOfItem(atPath: targetURL.path)[.size] as? Int64) ?? 0,
            checksum: checksum,
            status: .localOnly
        )
        await MainActor.run { items.append(item) }
        return item
    }

    public func verifyDurableStorage(for item: CloudItem) async throws -> Bool {
        // Only mark safely uploaded once remote sha256 handshake matches
        return item.status == .cloudSynchronized
    }

    public func removeLocalCache(for item: CloudItem) async throws {
        guard item.status == .cloudSynchronized else {
            throw StorageError.cannotEvictUnsynchronizedItem
        }
        try fileManager.removeItem(at: item.url)
    }
}`
  },

  // 4. Swift Concurrency Task Graph & Compute Coordinator
  {
    path: 'iCloudMac/Services/ComputeCoordinator.swift',
    name: 'ComputeCoordinator.swift',
    language: 'swift',
    category: 'macOS (Xcode)',
    content: `//
//  ComputeCoordinator.swift
//  Hybrid Apple Silicon + FastAPI Remote Compute Coordinator
//

import Foundation

public actor ComputeCoordinator: ObservableObject {
    @Published public private(set) var activeJobs: [ComputeJob] = []
    @Published public var presentTaskPicker: Bool = false

    private let localSandboxQueue = OperationQueue()
    private let remoteEndpoint = URL(string: "http://127.0.0.1:8000/api/v1/jobs")!

    public init() {
        localSandboxQueue.maxConcurrentOperationCount = 4
    }

    public func submit(task: ComputeTaskSpecification, target: ExecutionTarget) async throws -> ComputeJob {
        var job = ComputeJob(
            id: UUID(),
            task: task,
            target: target,
            status: .queued,
            submittedAt: Date()
        )
        
        switch target {
        case .thisMac:
            return try await executeLocally(job: job)
        case .remoteWorker(let workerURL):
            return try await executeRemotely(job: job, workerURL: workerURL)
        }
    }

    private func executeLocally(job: ComputeJob) async throws -> ComputeJob {
        // Runs within App Sandbox allowlisted binaries
        var active = job
        active.status = .running
        
        // Execute bundled Swift / Accelerate / CoreImage routine
        let result = try await TaskEngine.runBundledOperation(job.task)
        active.status = .completed(result)
        return active
    }

    private func executeRemotely(job: ComputeJob, workerURL: URL) async throws -> ComputeJob {
        // Transmit validated JSON spec over TLS with Keychain Bearer token
        var request = URLRequest(url: workerURL.appendingPathComponent("/submit"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(job.task)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw ComputeError.workerRejectedJob
        }
        return try JSONDecoder().decode(ComputeJob.self, from: data)
    }
}`
  },

  // 5. Shared SwiftUI for iOS & iPadOS
  {
    path: 'Shared/iOSCompanionView.swift',
    name: 'iOSCompanionView.swift',
    language: 'swift',
    category: 'iOS & iPadOS',
    content: `//
//  iOSCompanionView.swift
//  Adaptive SwiftUI Companion for iPhone and iPad
//

import SwiftUI

struct iOSCompanionView: View {
    @Environment(\\.horizontalSizeClass) var sizeClass
    @State private var selectedTab: Int = 0

    var body: some View {
        if sizeClass == .compact {
            // iPhone Experience: Dynamic Island & Thumb Tab Bar
            TabView(selection: $selectedTab) {
                iPhoneFilesListView()
                    .tabItem { Label("Files", systemImage: "folder.fill") }
                    .tag(0)
                
                iPhoneWorkspacesView()
                    .tabItem { Label("Workspaces", systemImage: "square.grid.2x2.fill") }
                    .tag(1)
                
                iPhoneJobMonitorView()
                    .tabItem { Label("Compute", systemImage: "cpu.fill") }
                    .tag(2)
                
                iPhoneSettingsView()
                    .tabItem { Label("Settings", systemImage: "gearshape.fill") }
                    .tag(3)
            }
        } else {
            // iPad Experience: Stage Manager & Split Views
            NavigationSplitView {
                iPadSidebarView()
            } detail: {
                iPadGridBrowserView()
            }
        }
    }
}`
  },

  // 6. Python FastAPI Compute Worker - main.py
  {
    path: 'compute-worker/main.py',
    name: 'main.py',
    language: 'python',
    category: 'Python Compute Worker',
    content: `"""
iCloud Distributed Compute Worker Daemon
FastAPI asynchronous job executor with bounded resource quotas.
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Security, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
import uuid
import time
import os
import shutil
from typing import Dict, Any, List, Optional
import asyncio

app = FastAPI(
    title="iCloud Personal Compute Worker",
    version="1.0.0",
    description="Remote execution engine for image transcoding, dataset summaries, and cryptographic manifests."
)

security = HTTPBearer()
ALLOWED_API_KEY = os.getenv("ICLOUD_COMPUTE_KEY", "apple-icloud-secure-worker-token-2026")

def verify_token(credentials: HTTPAuthorizationCredentials = Security(security)):
    if credentials.credentials != ALLOWED_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired worker authentication credentials."
        )
    return credentials.credentials

class TaskSpecification(BaseModel):
    task_type: str = Field(..., description="Allowlisted task identifier")
    input_file_urls: List[str]
    parameters: Dict[str, Any] = {}
    timeout_seconds: int = Field(default=300, le=900)
    memory_limit_mb: int = Field(default=2048, le=8192)

class JobStatusResponse(BaseModel):
    job_id: str
    status: str
    progress: float
    current_step: str
    cpu_percent: float
    memory_mb: float
    duration_ms: int
    output_urls: List[str]
    logs: List[Dict[str, str]]

# In-memory persistent job ledger
JOB_REGISTRY: Dict[str, Dict[str, Any]] = {}
EXECUTION_LOCK = asyncio.Semaphore(4) # Bounded concurrency (max 4 parallel jobs)

@app.post("/api/v1/jobs/submit", response_model=JobStatusResponse)
async def submit_job(spec: TaskSpecification, background_tasks: BackgroundTasks, token: str = Security(verify_token)):
    job_id = f"job-{uuid.uuid4().hex[:12]}"
    
    # Path traversal and input security validation
    for url in spec.input_file_urls:
        if ".." in url or url.startswith("/etc") or url.startswith("/var"):
            raise HTTPException(status_code=400, detail="Disallowed file path detected.")
            
    job_state = {
        "job_id": job_id,
        "status": "queued",
        "progress": 0.0,
        "current_step": "Accepted into bounded queue",
        "cpu_percent": 0.0,
        "memory_mb": 12.0,
        "duration_ms": 0,
        "output_urls": [],
        "logs": [{"timestamp": time.strftime("%H:%M:%S"), "level": "info", "message": f"Job {job_id} scheduled."}]
    }
    
    JOB_REGISTRY[job_id] = job_state
    background_tasks.add_task(execute_worker_pipeline, job_id, spec)
    return JobStatusResponse(**job_state)

@app.get("/api/v1/jobs/{job_id}", response_model=JobStatusResponse)
async def get_job_status(job_id: str, token: str = Security(verify_token)):
    if job_id not in JOB_REGISTRY:
        raise HTTPException(status_code=404, detail="Job not found")
    return JobStatusResponse(**JOB_REGISTRY[job_id])

async def execute_worker_pipeline(job_id: str, spec: TaskSpecification):
    async with EXECUTION_LOCK:
        job = JOB_REGISTRY[job_id]
        job["status"] = "running"
        job["current_step"] = "Allocating sandbox directory"
        start_time = time.time()
        
        # Sandbox isolation
        sandbox_dir = f"/tmp/icloud_sandbox/{job_id}"
        os.makedirs(sandbox_dir, exist_ok=True)
        
        try:
            # Step 1: Ingest
            job["progress"] = 30.0
            job["current_step"] = "Reading input payload"
            await asyncio.sleep(0.5)
            
            # Step 2: Processing (Allowlisted task types)
            job["progress"] = 75.0
            job["current_step"] = f"Executing {spec.task_type}"
            await asyncio.sleep(0.8)
            
            # Step 3: Complete
            elapsed_ms = int((time.time() - start_time) * 1000)
            job["status"] = "completed"
            job["progress"] = 100.0
            job["duration_ms"] = elapsed_ms
            job["cpu_percent"] = 42.5
            job["memory_mb"] = 180.4
            job["current_step"] = "Outputs verified and published to storage"
            job["output_urls"] = [f"storage://results/{job_id}_output.dat"]
            job["logs"].append({"timestamp": time.strftime("%H:%M:%S"), "level": "success", "message": "Pipeline complete."})
        except Exception as e:
            job["status"] = "failed"
            job["current_step"] = f"Error: {str(e)}"
        finally:
            shutil.rmtree(sandbox_dir, ignore_errors=True)
`
  },

  // 7. Python Tasks & Recipes - tasks.py
  {
    path: 'compute-worker/tasks.py',
    name: 'tasks.py',
    language: 'python',
    category: 'Python Compute Worker',
    content: `"""
Allowlisted Compute Task Implementations with strict isolation.
"""

import hashlib
import zipfile
import csv
from io import StringIO
from PIL import Image

def task_resize_and_transcode(input_path: str, output_path: str, max_w: int, max_h: int, fmt: str = "WEBP", quality: int = 85):
    with Image.open(input_path) as im:
        im.thumbnail((max_w, max_h), Image.Resampling.LANCZOS)
        im.save(output_path, format=fmt, quality=quality)
        return {"width": im.width, "height": im.height, "format": fmt}

def task_summarise_csv(csv_content: str):
    reader = csv.DictReader(StringIO(csv_content))
    rows = list(reader)
    if not rows:
        return {"error": "Empty dataset"}
    fieldnames = reader.fieldnames or []
    summary = {"row_count": len(rows), "columns": {}}
    for f in fieldnames:
        vals = [r[f] for r in rows if r.get(f)]
        try:
            nums = [float(v) for v in vals]
            summary["columns"][f] = {
                "type": "numeric",
                "mean": sum(nums) / len(nums),
                "min": min(nums),
                "max": max(nums)
            }
        except ValueError:
            summary["columns"][f] = {
                "type": "categorical",
                "unique_count": len(set(vals))
            }
    return summary

def task_safe_zip_extract(archive_path: str, dest_dir: str):
    with zipfile.ZipFile(archive_path, 'r') as zf:
        for member in zf.infolist():
            # Prevent zip slip path traversal attack
            if ".." in member.filename or member.filename.startswith("/"):
                raise ValueError(f"Malicious path in zip: {member.filename}")
            zf.extract(member, dest_dir)
`
  },

  // 8. Python Unit Tests - test_security_sandbox.py
  {
    path: 'compute-worker/tests/test_security_sandbox.py',
    name: 'test_security_sandbox.py',
    language: 'python',
    category: 'Tests & CI',
    content: `import pytest
import os
import zipfile
from tasks import task_safe_zip_extract

def test_zip_path_traversal_is_blocked(tmp_path):
    evil_zip = tmp_path / "evil.zip"
    with zipfile.ZipFile(evil_zip, "w") as zf:
        zf.writestr("../../etc/passwd", "root:x:0:0:evil")
        
    extract_target = tmp_path / "target"
    extract_target.mkdir()
    
    with pytest.raises(ValueError, match="Malicious path in zip"):
        task_safe_zip_extract(str(evil_zip), str(extract_target))

def test_csv_summary_statistics():
    from tasks import task_summarise_csv
    sample = "region,latency\\nus-west,12.5\\neu-west,25.0\\nap-east,60.0"
    res = task_summarise_csv(sample)
    assert res["row_count"] == 3
    assert res["columns"]["latency"]["mean"] == pytest.approx(32.5)
`
  },

  // 9. Python Requirements & Dockerfile
  {
    path: 'compute-worker/Dockerfile',
    name: 'Dockerfile',
    language: 'dockerfile',
    category: 'Python Compute Worker',
    content: `FROM python:3.11-slim

WORKDIR /app
RUN apt-get update && apt-get install -y --no-install-recommends libjpeg-dev zlib1g-dev && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
`
  },

  // 10. Launch & Integration Documentation
  {
    path: 'README.md',
    name: 'README.md',
    language: 'markdown',
    category: 'Docs',
    content: `# Apple iCloud Compute Workspace

A unified personal cloud workspace for macOS with companion interfaces for iPhone and iPad.

## Architecture

- **macOS Client**: Native SwiftUI 3-column architecture (Sidebar, Browser, Inspector) with App Sandbox security.
- **Compute Coordinator**: Manages local Apple Silicon execution alongside remote FastAPI cluster nodes.
- **Storage Layer**: Durable SHA-256 verification, path-traversal prevention, and version tracking.
- **Companion Suite**: Adaptive Stage Manager layout on iPadOS, thumb-focused Dynamic Island interface on iOS.

## Quick Launch Instructions

### 1. Run macOS Desktop App
Open \`iCloudMac.xcodeproj\` in Xcode 16+. Select "My Mac" and click Run (Cmd+R).

### 2. Run Remote Compute Worker
\`\`\`bash
cd compute-worker
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
\`\`\`

Connect the macOS app to \`http://127.0.0.1:8000\` in Settings → Compute Workers.
`
  }
];
