export type FileKind = 'folder' | 'image' | 'document' | 'dataset' | 'archive' | 'audio' | 'code';

export type FileStatus = 'local' | 'cloud' | 'uploading' | 'syncing' | 'conflict' | 'failed';

export type TagColor = 'red' | 'orange' | 'yellow' | 'green' | 'blue' | 'purple' | 'gray';

export interface FileVersion {
  version: number;
  timestamp: string;
  size: number;
  checksum: string;
  note: string;
}

export interface ICloudItem {
  id: string;
  name: string;
  kind: FileKind;
  size: number; // bytes
  modifiedAt: string;
  parentId: string | null; // null = root
  tags: TagColor[];
  isFavorite: boolean;
  status: FileStatus;
  uploadProgress?: number; // 0-100
  checksum?: string;
  content?: string; // Data URL for images, raw text for docs/csv, or simulated payload
  mimeType: string;
  versionHistory: FileVersion[];
  inTrash?: boolean;
  deletedAt?: string;
  workspaceId?: string;
  isShared?: boolean;
  shareRole?: 'view' | 'edit';
  shareExpiry?: string;
  hasLocalCache?: boolean;
  isPinned?: boolean;
}

export type ViewMode = 'grid' | 'list';
export type SortField = 'name' | 'modifiedAt' | 'size' | 'kind';
export type SortOrder = 'asc' | 'desc';

export type NavigationDestination = 
  | 'home' 
  | 'my-files' 
  | 'workspaces' 
  | 'compute' 
  | 'shared' 
  | 'activity' 
  | 'trash' 
  | 'settings';

export type DeviceMode = 'mac' | 'ipad' | 'iphone';

export interface Workspace {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  itemIds: string[];
  notes: string;
  linkedWorker: 'local' | 'remote';
  createdAt: string;
  activeRecipeId?: string;
}

export type ComputeTaskType = 
  | 'image_resize_convert'
  | 'csv_summary_stats'
  | 'dataset_chart'
  | 'document_text_extract'
  | 'archive_pack'
  | 'checksum_verify'
  | 'media_transcode';

export type JobStatus = 'queued' | 'preparing' | 'running' | 'completed' | 'failed' | 'cancelled';

export interface JobLog {
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'success';
  message: string;
}

export interface JobMetrics {
  cpuPercent: number;
  memoryMb: number;
  wallClockMs: number;
  ioBytes: number;
}

export interface ComputeJob {
  id: string;
  taskType: ComputeTaskType;
  taskTitle: string;
  status: JobStatus;
  workerType: 'local' | 'remote';
  workerName: string;
  inputItemIds: string[];
  inputNames: string[];
  parameters: Record<string, any>;
  outputItemIds: string[];
  outputSummary?: string;
  outputDetails?: any;
  progress: number;
  currentStep: string;
  logs: JobLog[];
  metrics: JobMetrics;
  submittedAt: string;
  completedAt?: string;
}

export interface TaskRecipe {
  id: string;
  name: string;
  description: string;
  icon: string;
  steps: {
    stepId: string;
    taskType: ComputeTaskType;
    name: string;
    params: Record<string, any>;
  }[];
}

export interface ActivityEvent {
  id: string;
  timestamp: string;
  type: 'upload' | 'download' | 'create' | 'compute_job' | 'trash' | 'share' | 'conflict';
  title: string;
  detail: string;
  status: 'success' | 'warning' | 'info' | 'error';
}

export interface DuplicateResolution {
  action: 'replace' | 'keep_both' | 'skip';
  item: ICloudItem;
}
