'use client';

import React, { useState } from 'react';
import { 
  X, 
  Code2, 
  Copy, 
  Check, 
  Download, 
  FileCode, 
  FileText, 
  Folder, 
  Terminal,
  ExternalLink
} from 'lucide-react';
import { codeDeliverables, CodeFile } from '@/lib/codeDeliverables';

interface CodeDeliverablesModalProps {
  onClose: () => void;
}

export const CodeDeliverablesModal: React.FC<CodeDeliverablesModalProps> = ({
  onClose,
}) => {
  const [selectedFile, setSelectedFile] = useState<CodeFile>(codeDeliverables[0]);
  const [copied, setCopied] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'macOS (Xcode)', 'iOS & iPadOS', 'Python Compute Worker', 'Tests & CI', 'Docs'];

  const filteredFiles = activeCategory === 'All' 
    ? codeDeliverables 
    : codeDeliverables.filter(f => f.category === activeCategory);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-md select-none">
      <div className="w-full max-w-5xl h-[85vh] flex flex-col bg-[#1e1e24] text-neutral-200 rounded-2xl shadow-2xl border border-neutral-700/80 overflow-hidden font-sans">
        {/* Xcode-style Header */}
        <div className="h-12 bg-[#25252d] border-b border-neutral-800 flex items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-[#ff5f57] inline-block" />
              <span className="w-3 h-3 rounded-full bg-[#febc2e] inline-block" />
              <span className="w-3 h-3 rounded-full bg-[#28c840] inline-block" />
            </div>
            <div className="flex items-center gap-2 ml-2">
              <Code2 className="w-4 h-4 text-[#38bdf8]" />
              <span className="text-xs font-semibold text-white">
                Xcode Project & Python Worker Deliverables
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadFile}
              className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-200 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download {selectedFile.name}</span>
            </button>
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#0071e3] hover:bg-[#0077ed] text-white text-xs font-medium transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Source'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1 rounded-md text-neutral-400 hover:text-white ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="px-4 py-2 bg-[#202027] border-b border-neutral-800/80 flex items-center gap-1.5 overflow-x-auto text-xs">
          {categories.map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`px-2.5 py-1 rounded-md whitespace-nowrap transition-colors ${
                activeCategory === cat
                  ? 'bg-neutral-700 text-white font-semibold'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Split View: File Tree + Editor */}
        <div className="flex-1 flex overflow-hidden">
          {/* File Tree Navigator */}
          <div className="w-72 border-r border-neutral-800 bg-[#18181d] p-3 overflow-y-auto space-y-1 text-xs">
            <p className="text-[10px] uppercase font-bold tracking-wider text-neutral-500 px-2 py-1">Project Files ({filteredFiles.length})</p>
            {filteredFiles.map(file => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedFile(file)}
                  className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left transition-colors truncate ${
                    isSelected
                      ? 'bg-[#0071e3]/20 text-[#38bdf8] font-semibold'
                      : 'text-neutral-400 hover:bg-neutral-800/50 hover:text-neutral-200'
                  }`}
                >
                  <FileCode className={`w-3.5 h-3.5 shrink-0 ${file.language === 'swift' ? 'text-orange-400' : file.language === 'python' ? 'text-blue-400' : 'text-neutral-400'}`} />
                  <div className="truncate">
                    <p className="truncate text-xs">{file.name}</p>
                    <p className="text-[9px] text-neutral-500 truncate">{file.path}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Code Viewer */}
          <div className="flex-1 flex flex-col bg-[#141418] overflow-hidden">
            {/* Editor tab bar */}
            <div className="h-8 bg-[#1a1a20] border-b border-neutral-800/80 px-4 flex items-center justify-between text-xs text-neutral-400 font-mono">
              <span className="text-[#38bdf8] font-semibold">{selectedFile.path}</span>
              <span className="text-[11px] uppercase text-neutral-500">{selectedFile.language}</span>
            </div>

            {/* Code Body */}
            <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-neutral-300">
              <pre className="whitespace-pre">{selectedFile.content}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
