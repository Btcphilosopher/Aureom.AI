'use client';

import React, { useState } from 'react';
import { 
  Folder, 
  Layers, 
  Cpu, 
  Settings, 
  Play, 
  Eye, 
  FileText, 
  UploadCloud, 
  CheckCircle2, 
  Star,
  ChevronRight,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { ICloudItem, ComputeJob, Workspace } from '@/lib/types';

interface IphoneCompanionProps {
  items: ICloudItem[];
  jobs: ComputeJob[];
  workspaces: Workspace[];
  onOpenQuickLook: (item: ICloudItem) => void;
  onRunTask: (item: ICloudItem) => void;
  onExitCompanion: () => void;
}

export const IphoneCompanion: React.FC<IphoneCompanionProps> = ({
  items,
  jobs,
  workspaces,
  onOpenQuickLook,
  onRunTask,
  onExitCompanion,
}) => {
  const [activeTab, setActiveTab] = useState<'files' | 'workspaces' | 'jobs' | 'settings'>('files');

  return (
    <div className="flex-1 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-md select-none overflow-hidden">
      {/* iPhone 16 Pro Hardware Chassis */}
      <div className="w-[380px] h-[740px] bg-black rounded-[52px] p-3 shadow-2xl border-4 border-neutral-800 flex flex-col relative overflow-hidden">
        {/* Dynamic Island */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-7 bg-black rounded-full z-50 flex items-center justify-between px-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-blue-500/80 animate-pulse" />
          <span className="text-[9px] font-semibold text-neutral-300">iCloud Sync</span>
          <div className="w-2.5 h-2.5 rounded-full bg-neutral-900 border border-neutral-700" />
        </div>

        {/* iPhone Screen Container */}
        <div className="flex-1 rounded-[42px] bg-[#f5f5f7] dark:bg-[#18191c] overflow-hidden flex flex-col relative pt-10">
          {/* iOS Top Bar */}
          <div className="px-5 py-2 flex items-center justify-between">
            <span className="text-xs font-bold text-neutral-900 dark:text-white">
              {activeTab === 'files' ? 'iCloud Files' : activeTab === 'workspaces' ? 'Workspaces' : activeTab === 'jobs' ? 'Compute' : 'Settings'}
            </span>
            <button
              type="button"
              onClick={onExitCompanion}
              className="px-2 py-0.5 rounded-full bg-black/[0.06] dark:bg-white/[0.1] text-neutral-700 dark:text-neutral-300 text-[10px] font-semibold"
            >
              Exit
            </button>
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto px-4 py-2 space-y-3">
            {activeTab === 'files' && (
              <div className="space-y-2">
                {items.filter(i => !i.inTrash).map(item => (
                  <div
                    key={item.id}
                    onClick={() => onOpenQuickLook(item)}
                    className="p-3 bg-white dark:bg-[#202126] rounded-2xl border border-black/[0.04] dark:border-white/[0.06] flex items-center justify-between shadow-2xs cursor-pointer active:scale-98 transition-all"
                  >
                    <div className="flex items-center gap-3 truncate">
                      <FileText className="w-5 h-5 text-[#0071e3] shrink-0" />
                      <div className="truncate">
                        <p className="text-xs font-semibold text-neutral-800 dark:text-neutral-100 truncate">{item.name}</p>
                        <p className="text-[10px] text-neutral-400 font-mono">{(item.size / 1024).toFixed(1)} KB · {item.kind}</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-neutral-400 shrink-0" />
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'workspaces' && (
              <div className="space-y-2">
                {workspaces.map(ws => (
                  <div
                    key={ws.id}
                    className="p-3.5 bg-white dark:bg-[#202126] rounded-2xl border border-black/[0.04] space-y-1"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: ws.color }} />
                      <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-100">{ws.name}</h4>
                    </div>
                    <p className="text-[11px] text-neutral-400">{ws.description}</p>
                    <span className="inline-block mt-1 text-[10px] font-mono text-[#0071e3]">{ws.itemIds.length} files attached</span>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'jobs' && (
              <div className="space-y-2">
                {jobs.map(j => (
                  <div
                    key={j.id}
                    className="p-3 bg-white dark:bg-[#202126] rounded-2xl border border-black/[0.04] space-y-2 text-xs"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-neutral-800 dark:text-neutral-200 truncate">{j.taskTitle}</span>
                      <span className="text-[10px] text-emerald-500 font-bold uppercase">{j.status}</span>
                    </div>
                    <div className="w-full h-1 bg-black/[0.06] dark:bg-white/[0.08] rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${j.progress}%` }} />
                    </div>
                    <div className="flex justify-between text-[10px] text-neutral-400">
                      <span>{j.workerName.split(' ')[0]}</span>
                      <span>{j.metrics?.wallClockMs}ms</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="p-4 bg-white dark:bg-[#202126] rounded-2xl border border-black/[0.04] space-y-3 text-xs">
                <h4 className="font-bold text-neutral-800 dark:text-neutral-200">iCloud Storage</h4>
                <div className="flex justify-between text-[11px] text-neutral-500">
                  <span>Usage</span>
                  <span className="font-mono">18.4 / 50 GB (36%)</span>
                </div>
                <div className="w-full h-1.5 bg-black/[0.06] rounded-full overflow-hidden">
                  <div className="h-full bg-[#0071e3] rounded-full" style={{ width: '36%' }} />
                </div>
                <p className="text-[10px] text-neutral-400 pt-1">
                  Personal Compute jobs automatically offload heavy tasks to connected macOS or FastAPI workers.
                </p>
              </div>
            )}
          </div>

          {/* iPhone Bottom Thumb Tab Bar */}
          <div className="h-14 border-t border-black/[0.06] dark:border-white/[0.06] bg-white/80 dark:bg-[#202126]/80 backdrop-blur-lg flex items-center justify-around px-2 text-[10px]">
            <button
              type="button"
              onClick={() => setActiveTab('files')}
              className={`flex flex-col items-center gap-1 ${activeTab === 'files' ? 'text-[#0071e3] font-semibold' : 'text-neutral-400'}`}
            >
              <Folder className="w-4 h-4" />
              <span>Files</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('workspaces')}
              className={`flex flex-col items-center gap-1 ${activeTab === 'workspaces' ? 'text-[#0071e3] font-semibold' : 'text-neutral-400'}`}
            >
              <Layers className="w-4 h-4" />
              <span>Projects</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('jobs')}
              className={`flex flex-col items-center gap-1 ${activeTab === 'jobs' ? 'text-[#0071e3] font-semibold' : 'text-neutral-400'}`}
            >
              <Cpu className="w-4 h-4" />
              <span>Compute</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('settings')}
              className={`flex flex-col items-center gap-1 ${activeTab === 'settings' ? 'text-[#0071e3] font-semibold' : 'text-neutral-400'}`}
            >
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </button>
          </div>

          {/* iPhone Home Indicator */}
          <div className="h-3 flex items-center justify-center bg-transparent">
            <div className="w-28 h-1 rounded-full bg-neutral-400/60 dark:bg-neutral-600/60" />
          </div>
        </div>
      </div>
    </div>
  );
};
