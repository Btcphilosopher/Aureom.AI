'use client';

import React, { useState } from 'react';
import { 
  Folder, 
  FileText, 
  Cpu, 
  HardDrive, 
  Play, 
  Eye, 
  Search, 
  Plus, 
  Layers, 
  Share2, 
  CheckCircle2,
  Table,
  UploadCloud,
  ChevronRight,
  Maximize2
} from 'lucide-react';
import { ICloudItem, ComputeJob, Workspace } from '@/lib/types';

interface IpadCompanionProps {
  items: ICloudItem[];
  jobs: ComputeJob[];
  workspaces: Workspace[];
  onOpenQuickLook: (item: ICloudItem) => void;
  onRunTask: (item: ICloudItem) => void;
  onExitCompanion: () => void;
}

export const IpadCompanion: React.FC<IpadCompanionProps> = ({
  items,
  jobs,
  workspaces,
  onOpenQuickLook,
  onRunTask,
  onExitCompanion,
}) => {
  const [activeTab, setActiveTab] = useState<'files' | 'workspaces' | 'jobs'>('files');
  const [selectedFileId, setSelectedFileId] = useState<string | null>(items[0]?.id || null);

  const selectedFile = items.find(i => i.id === selectedFileId) || items[0];

  return (
    <div className="flex-1 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-md select-none overflow-hidden">
      {/* iPad Hardware Bezel */}
      <div className="w-full max-w-5xl h-[82vh] bg-black rounded-[36px] p-4 shadow-2xl border-4 border-neutral-800 flex flex-col relative overflow-hidden">
        {/* Front Camera Dot */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-neutral-950 border border-neutral-800 z-40" />

        {/* iPad Screen */}
        <div className="flex-1 rounded-[26px] bg-[#f5f5f7] dark:bg-[#1c1d21] overflow-hidden flex flex-col relative">
          {/* iPadOS Status Bar */}
          <div className="h-7 px-6 flex items-center justify-between text-[11px] font-semibold text-neutral-800 dark:text-neutral-200 bg-white/40 dark:bg-black/20">
            <span>9:41 AM</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-neutral-400">iPad Pro · Stage Manager</span>
              <button
                type="button"
                onClick={onExitCompanion}
                className="px-2 py-0.5 rounded-full bg-[#0071e3] text-white text-[10px]"
              >
                Return to Mac
              </button>
            </div>
          </div>

          {/* iPad App Layout: Split View Navigation */}
          <div className="flex-1 flex overflow-hidden">
            {/* iPad Sidebar */}
            <div className="w-64 border-r border-black/[0.06] dark:border-white/[0.06] bg-white/60 dark:bg-[#18191c]/70 p-3 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="px-2">
                  <h2 className="text-sm font-bold text-neutral-900 dark:text-white">iCloud</h2>
                  <p className="text-[10px] text-neutral-400">Personal Cloud Companion</p>
                </div>

                <div className="space-y-1">
                  <button
                    type="button"
                    onClick={() => setActiveTab('files')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                      activeTab === 'files' ? 'bg-[#0071e3] text-white' : 'hover:bg-black/[0.04] text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    <Folder className="w-4 h-4" />
                    <span>iCloud Drive</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('workspaces')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                      activeTab === 'workspaces' ? 'bg-[#0071e3] text-white' : 'hover:bg-black/[0.04] text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    <Layers className="w-4 h-4" />
                    <span>Workspaces</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('jobs')}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                      activeTab === 'jobs' ? 'bg-[#0071e3] text-white' : 'hover:bg-black/[0.04] text-neutral-700 dark:text-neutral-300'
                    }`}
                  >
                    <Cpu className="w-4 h-4" />
                    <span>Compute Monitor</span>
                  </button>
                </div>
              </div>

              {/* iPad Quota footer */}
              <div className="p-3 bg-black/[0.03] dark:bg-white/[0.04] rounded-xl text-[11px] space-y-1 text-neutral-500">
                <div className="flex justify-between font-medium">
                  <span>iPad Storage</span>
                  <span>18.4 / 50 GB</span>
                </div>
                <div className="w-full h-1 bg-black/[0.08] dark:bg-white/[0.1] rounded-full overflow-hidden">
                  <div className="h-full bg-[#0071e3] rounded-full" style={{ width: '36%' }} />
                </div>
              </div>
            </div>

            {/* iPad Main Column & Detail Pane */}
            <div className="flex-1 flex overflow-hidden">
              {/* Middle List */}
              <div className="w-72 border-r border-black/[0.06] dark:border-white/[0.06] p-3 overflow-y-auto space-y-2">
                <p className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider px-1">
                  {activeTab === 'files' ? 'Files' : activeTab === 'workspaces' ? 'Workspaces' : 'Recent Jobs'}
                </p>

                {activeTab === 'files' && (
                  items.filter(i => !i.inTrash).map(item => (
                    <div
                      key={item.id}
                      onClick={() => setSelectedFileId(item.id)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-2.5 ${
                        selectedFileId === item.id
                          ? 'bg-[#0071e3]/10 border-[#0071e3]'
                          : 'border-transparent hover:bg-black/[0.03] dark:hover:bg-white/[0.04]'
                      }`}
                    >
                      <FileText className="w-4 h-4 text-[#0071e3] shrink-0" />
                      <div className="truncate">
                        <p className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 truncate">{item.name}</p>
                        <p className="text-[10px] text-neutral-400">{(item.size / 1024).toFixed(1)} KB</p>
                      </div>
                    </div>
                  ))
                )}

                {activeTab === 'workspaces' && (
                  workspaces.map(ws => (
                    <div
                      key={ws.id}
                      className="p-3 rounded-xl bg-white dark:bg-[#202126] border border-black/[0.04] space-y-1"
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: ws.color }} />
                        <h4 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">{ws.name}</h4>
                      </div>
                      <p className="text-[10px] text-neutral-400">{ws.itemIds.length} associated files</p>
                    </div>
                  ))
                )}

                {activeTab === 'jobs' && (
                  jobs.map(j => (
                    <div
                      key={j.id}
                      className="p-3 rounded-xl bg-white dark:bg-[#202126] border border-black/[0.04] space-y-1 text-xs"
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-semibold text-neutral-800 dark:text-neutral-200 truncate">{j.taskTitle}</span>
                        <span className="text-emerald-500 text-[10px] font-semibold uppercase">{j.status}</span>
                      </div>
                      <p className="text-[10px] text-neutral-400">{j.workerName}</p>
                    </div>
                  ))
                )}
              </div>

              {/* Detail Preview Column */}
              <div className="flex-1 p-5 overflow-y-auto space-y-4">
                {selectedFile ? (
                  <div className="space-y-4">
                    <div className="p-4 bg-white/70 dark:bg-[#202126]/70 rounded-2xl border border-black/[0.06] dark:border-white/[0.08] flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-bold text-neutral-900 dark:text-white">{selectedFile.name}</h3>
                        <p className="text-xs text-neutral-400">{(selectedFile.size / 1024).toFixed(1)} KB · SHA-256 Verified</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onOpenQuickLook(selectedFile)}
                          className="px-3 py-1.5 rounded-lg bg-black/[0.04] dark:bg-white/[0.06] text-xs font-medium hover:bg-black/[0.08]"
                        >
                          Quick Look
                        </button>
                        <button
                          type="button"
                          onClick={() => onRunTask(selectedFile)}
                          className="px-3 py-1.5 rounded-lg bg-[#0071e3] text-white text-xs font-medium hover:bg-[#0077ed]"
                        >
                          Run Task
                        </button>
                      </div>
                    </div>

                    {/* Preview render */}
                    {selectedFile.kind === 'image' && selectedFile.content && (
                      <div className="w-full h-64 bg-black/5 dark:bg-black/30 rounded-2xl overflow-hidden flex items-center justify-center p-4">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={selectedFile.content}
                          alt={selectedFile.name}
                          className="max-h-full max-w-full object-contain rounded-lg shadow-sm"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    )}

                    {selectedFile.kind === 'dataset' && (
                      <div className="p-4 bg-white/70 dark:bg-[#202126]/70 rounded-2xl border border-black/[0.06] space-y-2">
                        <p className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">CSV Telemetry Ingestion</p>
                        <p className="text-xs text-neutral-500">
                          {selectedFile.content?.split('\n').slice(0, 5).join('\n')}
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-20 text-neutral-400 text-xs">Select a file to preview</div>
                )}
              </div>
            </div>
          </div>

          {/* iPad Home Indicator Bar */}
          <div className="h-4 flex items-center justify-center bg-transparent">
            <div className="w-32 h-1 rounded-full bg-neutral-400/60 dark:bg-neutral-600/60" />
          </div>
        </div>
      </div>
    </div>
  );
};
