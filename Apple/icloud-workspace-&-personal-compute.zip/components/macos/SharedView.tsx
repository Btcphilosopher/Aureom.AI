'use client';

import React, { useState } from 'react';
import { 
  Users, 
  Share2, 
  FileText, 
  Copy, 
  Check, 
  Clock, 
  ShieldAlert, 
  ExternalLink,
  Eye,
  Edit3
} from 'lucide-react';
import { ICloudItem } from '@/lib/types';

interface SharedViewProps {
  sharedItems: ICloudItem[];
  onRevokeShare: (id: string) => void;
  onOpenItem: (item: ICloudItem) => void;
}

export const SharedView: React.FC<SharedViewProps> = ({
  sharedItems,
  onRevokeShare,
  onOpenItem,
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopyLink = (item: ICloudItem) => {
    const link = `https://icloud.apple.com/share/${item.id}`;
    navigator.clipboard.writeText(link);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-white/50 dark:bg-[#1a1b1e]/50 select-none p-6 space-y-4">
      <div className="flex items-center justify-between pb-3 border-b border-black/[0.08] dark:border-white/[0.08]">
        <div>
          <h1 className="text-base font-bold text-neutral-900 dark:text-white">
            Shared with Collaborators
          </h1>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Files and folders shared through authenticated iCloud links with explicit role permissions.
          </p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-3">
        {sharedItems.length === 0 ? (
          <div className="text-center py-16 text-neutral-400 text-xs">
            <Users className="w-12 h-12 stroke-[1.2] mx-auto mb-2 text-neutral-400" />
            <p className="font-semibold text-neutral-700 dark:text-neutral-300">No Shared Items</p>
            <p className="text-[11px] text-neutral-400 mt-1">
              Select any file in iCloud Drive and click &quot;Share&quot; to generate an access link with custom permissions.
            </p>
          </div>
        ) : (
          sharedItems.map(item => (
            <div
              key={item.id}
              className="p-4 bg-white/70 dark:bg-[#202126]/70 rounded-xl border border-black/[0.06] dark:border-white/[0.08] flex items-center justify-between hover:border-[#0071e3]/40 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-[#0071e3]/10 text-[#0071e3]">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 
                    onClick={() => onOpenItem(item)}
                    className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 cursor-pointer hover:text-[#0071e3]"
                  >
                    {item.name}
                  </h3>
                  <div className="flex items-center gap-3 text-[11px] text-neutral-400 mt-0.5">
                    <span className="flex items-center gap-1">
                      {item.shareRole === 'edit' ? <Edit3 className="w-3 h-3 text-purple-500" /> : <Eye className="w-3 h-3 text-[#0071e3]" />}
                      <span className="capitalize">{item.shareRole || 'view'} Only</span>
                    </span>
                    <span>·</span>
                    <span className="flex items-center gap-1 font-mono">
                      <Clock className="w-3 h-3" />
                      <span>Expires in 30 days</span>
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopyLink(item)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/[0.04] dark:bg-white/[0.06] text-xs font-medium text-neutral-700 dark:text-neutral-200 hover:bg-black/[0.08] transition-colors"
                >
                  {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedId === item.id ? 'Copied' : 'Copy Link'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => onRevokeShare(item.id)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-red-600 dark:text-red-400 hover:bg-red-500/10 transition-colors"
                >
                  Revoke
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
