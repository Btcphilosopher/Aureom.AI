'use client';

import React from 'react';
import { 
  Home, 
  Folder, 
  Layers, 
  Cpu, 
  Users, 
  Activity, 
  Trash2, 
  Settings, 
  Pin,
  HardDrive,
  Zap,
  Server
} from 'lucide-react';
import { NavigationDestination, ICloudItem, Workspace, ComputeJob } from '@/lib/types';

interface SidebarProps {
  destination: NavigationDestination;
  onSelectDestination: (dest: NavigationDestination) => void;
  workspaces: Workspace[];
  jobs: ComputeJob[];
  pinnedItems: ICloudItem[];
  onSelectFolder: (folderId: string) => void;
  storageUsedBytes: number;
  storageMaxBytes: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  destination,
  onSelectDestination,
  workspaces,
  jobs,
  pinnedItems,
  onSelectFolder,
  storageUsedBytes,
  storageMaxBytes,
}) => {
  const activeJobsCount = jobs.filter(j => j.status === 'running' || j.status === 'preparing' || j.status === 'queued').length;
  const storageUsedGB = (storageUsedBytes / (1024 * 1024 * 1024)).toFixed(1);
  const storageMaxGB = (storageMaxBytes / (1024 * 1024 * 1024)).toFixed(0);
  const storagePercent = Math.min(Math.round((storageUsedBytes / storageMaxBytes) * 100), 100);

  const navItems: { id: NavigationDestination; label: string; icon: React.ReactNode; badge?: number | string }[] = [
    { id: 'home', label: 'Home', icon: <Home className="w-4 h-4 text-[#0071e3]" /> },
    { id: 'my-files', label: 'iCloud Drive', icon: <Folder className="w-4 h-4 text-[#0071e3]" /> },
    { id: 'workspaces', label: 'Workspaces', icon: <Layers className="w-4 h-4 text-[#8e44ad]" />, badge: workspaces.length },
    { id: 'compute', label: 'Compute & Workers', icon: <Cpu className="w-4 h-4 text-[#27ae60]" />, badge: activeJobsCount > 0 ? activeJobsCount : undefined },
    { id: 'shared', label: 'Shared', icon: <Users className="w-4 h-4 text-[#2980b9]" /> },
    { id: 'activity', label: 'Activity Log', icon: <Activity className="w-4 h-4 text-[#e67e22]" /> },
    { id: 'trash', label: 'Trash', icon: <Trash2 className="w-4 h-4 text-[#7f8c8d]" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4 text-[#95a5a6]" /> },
  ];

  return (
    <aside className="w-60 shrink-0 select-none flex flex-col justify-between h-full bg-[#f5f5f7]/85 dark:bg-[#18191c]/85 border-r border-black/[0.08] dark:border-white/[0.08] backdrop-blur-2xl p-2.5 text-xs text-neutral-700 dark:text-neutral-300">
      <div className="flex-1 overflow-y-auto space-y-4">
        {/* Apple iCloud Section Header */}
        <div>
          <div className="px-2 py-1 text-[11px] font-semibold tracking-wider text-neutral-400 dark:text-neutral-500 uppercase">
            iCloud
          </div>
          <nav className="space-y-0.5">
            {navItems.map((item) => {
              const isActive = destination === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectDestination(item.id)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md font-medium transition-colors ${
                    isActive
                      ? 'bg-[#0071e3] text-white shadow-xs'
                      : 'hover:bg-black/[0.04] dark:hover:bg-white/[0.06] text-neutral-700 dark:text-neutral-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <span className={isActive ? 'text-white' : ''}>{item.icon}</span>
                    <span className="truncate">{item.label}</span>
                  </div>
                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-full ${
                        isActive
                          ? 'bg-white/25 text-white'
                          : 'bg-black/[0.06] dark:bg-white/[0.1] text-neutral-600 dark:text-neutral-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Pinned Folders */}
        {pinnedItems.length > 0 && (
          <div>
            <div className="flex items-center justify-between px-2 py-1 text-[11px] font-semibold tracking-wider text-neutral-400 dark:text-neutral-500 uppercase">
              <span>Pinned Folders</span>
              <Pin className="w-3 h-3 text-neutral-400" />
            </div>
            <div className="space-y-0.5">
              {pinnedItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    onSelectDestination('my-files');
                    onSelectFolder(item.id);
                  }}
                  className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-md hover:bg-black/[0.04] dark:hover:bg-white/[0.06] transition-colors text-left"
                >
                  <Folder className="w-3.5 h-3.5 text-[#0071e3] shrink-0" />
                  <span className="truncate font-medium">{item.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Workspaces Shortcut List */}
        <div>
          <div className="px-2 py-1 text-[11px] font-semibold tracking-wider text-neutral-400 dark:text-neutral-500 uppercase">
            Active Projects
          </div>
          <div className="space-y-0.5">
            {workspaces.map((ws) => (
              <button
                key={ws.id}
                type="button"
                onClick={() => onSelectDestination('workspaces')}
                className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-md hover:bg-black/[0.04] dark:hover:bg-white/[0.06] transition-colors text-left group"
              >
                <div className="flex items-center gap-2 truncate">
                  <div
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: ws.color }}
                  />
                  <span className="truncate font-medium">{ws.name}</span>
                </div>
                <span className="text-[10px] text-neutral-400 group-hover:text-neutral-600 dark:group-hover:text-neutral-300">
                  {ws.itemIds.length}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Visibly Separate Storage & Compute Quota Meters */}
      <div className="pt-3 border-t border-black/[0.08] dark:border-white/[0.08] space-y-3">
        {/* Storage Meter */}
        <div className="bg-white/60 dark:bg-black/20 p-2.5 rounded-lg border border-black/[0.04] dark:border-white/[0.05]">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-neutral-500" />
              <span className="font-semibold text-[11px] text-neutral-800 dark:text-neutral-200">iCloud Storage</span>
            </div>
            <span className="text-[11px] text-neutral-500 font-mono tabular-nums">
              {storageUsedGB} / {storageMaxGB} GB
            </span>
          </div>
          <div className="w-full h-1.5 bg-black/[0.08] dark:bg-white/[0.1] rounded-full overflow-hidden">
            <div
              className="h-full bg-[#0071e3] rounded-full transition-all duration-300"
              style={{ width: `${storagePercent}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[10px] text-neutral-400 mt-1">
            <span>50 GB Plan</span>
            <span>{storagePercent}% used</span>
          </div>
        </div>

        {/* Compute Quota Meter */}
        <div className="bg-white/60 dark:bg-black/20 p-2.5 rounded-lg border border-black/[0.04] dark:border-white/[0.05]">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-[#27ae60]" />
              <span className="font-semibold text-[11px] text-neutral-800 dark:text-neutral-200">Personal Compute</span>
            </div>
            <span className="text-[11px] text-neutral-500 font-mono tabular-nums">
              3.2 / 20 hrs
            </span>
          </div>
          <div className="w-full h-1.5 bg-black/[0.08] dark:bg-white/[0.1] rounded-full overflow-hidden">
            <div
              className="h-full bg-[#27ae60] rounded-full transition-all duration-300"
              style={{ width: '16%' }}
            />
          </div>
          <div className="flex items-center justify-between text-[10px] text-neutral-500 dark:text-neutral-400 mt-1.5">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
              This Mac Sandbox
            </span>
            <span className="flex items-center gap-1">
              <Server className="w-3 h-3 text-neutral-400" />
              FastAPI Ready
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
};
