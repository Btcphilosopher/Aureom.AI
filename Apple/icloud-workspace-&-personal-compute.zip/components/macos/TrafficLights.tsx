'use client';

import React from 'react';

interface TrafficLightsProps {
  onClose?: () => void;
  onMinimize?: () => void;
  onZoom?: () => void;
  className?: string;
}

export const TrafficLights: React.FC<TrafficLightsProps> = ({
  onClose,
  onMinimize,
  onZoom,
  className = '',
}) => {
  return (
    <div className={`flex items-center gap-2 group ${className}`} aria-label="Window controls">
      <button
        type="button"
        onClick={onClose}
        className="w-3 h-3 rounded-full bg-[#ff5f57] border border-[#e0443e] flex items-center justify-center text-[8px] text-[#4d0000] opacity-90 hover:opacity-100 transition-opacity focus:outline-none"
        title="Close Window"
      >
        <span className="opacity-0 group-hover:opacity-100 font-bold leading-none">×</span>
      </button>
      <button
        type="button"
        onClick={onMinimize}
        className="w-3 h-3 rounded-full bg-[#febc2e] border border-[#d89e24] flex items-center justify-center text-[8px] text-[#5c3c00] opacity-90 hover:opacity-100 transition-opacity focus:outline-none"
        title="Minimize"
      >
        <span className="opacity-0 group-hover:opacity-100 font-bold leading-none">−</span>
      </button>
      <button
        type="button"
        onClick={onZoom}
        className="w-3 h-3 rounded-full bg-[#28c840] border border-[#1aab29] flex items-center justify-center text-[8px] text-[#004d11] opacity-90 hover:opacity-100 transition-opacity focus:outline-none"
        title="Zoom / Fullscreen"
      >
        <span className="opacity-0 group-hover:opacity-100 font-bold leading-none">+</span>
      </button>
    </div>
  );
};
