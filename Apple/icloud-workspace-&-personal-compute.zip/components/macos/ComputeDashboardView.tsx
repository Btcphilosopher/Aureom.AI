'use client';

import React, { useState } from 'react';
import { 
  Cpu, 
  Server, 
  Terminal, 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Play, 
  AlertTriangle, 
  Activity, 
  Layers, 
  HardDrive,
  RefreshCw
} from 'lucide-react';
import { ComputeJob } from '@/lib/types';

interface ComputeDashboardViewProps {
  jobs: ComputeJob[];
  onOpenTaskModal: () => void;
  onClearCompletedJobs: () => void;
}

export const ComputeDashboardView: React.FC<ComputeDashboardViewProps> = ({
  jobs,
  onOpenTaskModal,
  onClearCompletedJobs,
}) => {
  const [selectedJobId, setSelectedJobId] = useState<string>(jobs[0]?.id || '');

  const activeJob = jobs.find(j => j.id === selectedJobId) || jobs[0];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Completed</span>
          </span>
        );
      case 'running':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#0071e3]">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Running</span>
          </span>
        );
      case 'queued':
      case 'preparing':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-500">
            <Clock className="w-3.5 h-3.5" />
            <span>{status}</span>
          </span>
        );
      case 'failed':
      case 'cancelled':
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-500">
            <XCircle className="w-3.5 h-3.5" />
            <span>{status}</span>
          </span>
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-white/50 dark:bg-[#1a1b1e]/50 select-none">
      {/* Top Banner: Worker Health & Telemetry Summary */}
      <div className="p-4 border-b border-black/[0.08] dark:border-white/[0.08] bg-white/70 dark:bg-[#202126]/70">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-sm font-bold text-neutral-900 dark:text-white">
              Personal Compute Coordinator
            </h1>
            <p className="text-xs text-neutral-500 dark:text-neutral-400">
              Coordinating sandboxed Apple Silicon execution & remote FastAPI worker clusters
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClearCompletedJobs}
              className="px-3 py-1.5 rounded-lg border border-black/[0.08] dark:border-white/[0.08] text-xs font-medium text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.04]"
            >
              Clear Completed
            </button>
            <button
              type="button"
              onClick={onOpenTaskModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0071e3] text-white text-xs font-medium hover:bg-[#0077ed] shadow-xs"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>Launch New Job</span>
            </button>
          </div>
        </div>

        {/* Worker Node Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Node 1: Local Mac */}
          <div className="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/[0.06] dark:border-white/[0.08] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-600">
                <Cpu className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">This Mac</p>
                <p className="text-[10px] text-neutral-400">Apple Silicon Sandbox (4 Cores)</p>
              </div>
            </div>
            <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">Active</span>
          </div>

          {/* Node 2: Remote Worker */}
          <div className="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/[0.06] dark:border-white/[0.08] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-blue-500/10 text-[#0071e3]">
                <Server className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">FastAPI Cluster</p>
                <p className="text-[10px] text-neutral-400">fastapi-worker-01 (TLS Verified)</p>
              </div>
            </div>
            <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">Ready</span>
          </div>

          {/* Metric 3: Active Jobs */}
          <div className="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/[0.06] dark:border-white/[0.08]">
            <p className="text-[10px] text-neutral-400 uppercase tracking-wider font-semibold">Queue Concurrency</p>
            <p className="text-lg font-bold text-neutral-800 dark:text-neutral-200 mt-0.5">
              {jobs.filter(j => j.status === 'running').length} <span className="text-xs font-normal text-neutral-400">/ 4 max</span>
            </p>
          </div>

          {/* Metric 4: Compute Time Used */}
          <div className="p-3 rounded-xl bg-black/[0.02] dark:bg-white/[0.03] border border-black/[0.06] dark:border-white/[0.08]">
            <p className="text-[10px] text-neutral-400 uppercase tracking-wider font-semibold">Monthly Quota</p>
            <p className="text-lg font-bold text-neutral-800 dark:text-neutral-200 mt-0.5 font-mono tabular-nums">
              3.2 <span className="text-xs font-normal text-neutral-400">/ 20.0 hrs</span>
            </p>
          </div>
        </div>
      </div>

      {/* Main Body: Jobs List on Left, Active Job Details on Right */}
      <div className="flex-1 flex overflow-hidden">
        {/* Jobs Queue Table */}
        <div className="w-1/2 border-r border-black/[0.08] dark:border-white/[0.08] overflow-y-auto p-4 space-y-2">
          <p className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider px-1">Job Execution Queue ({jobs.length})</p>
          {jobs.length === 0 ? (
            <div className="text-center py-12 text-neutral-400 text-xs">
              No jobs in queue. Select files and click &quot;Run Task&quot; to launch.
            </div>
          ) : (
            jobs.map(job => {
              const isSelected = job.id === selectedJobId;
              return (
                <div
                  key={job.id}
                  onClick={() => setSelectedJobId(job.id)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#0071e3]/10 border-[#0071e3] shadow-xs'
                      : 'bg-white/70 dark:bg-[#202126]/70 border-black/[0.06] dark:border-white/[0.08] hover:bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-xs text-neutral-800 dark:text-neutral-200 truncate">
                      {job.taskTitle}
                    </span>
                    {getStatusBadge(job.status)}
                  </div>
                  <p className="text-[10px] text-neutral-400 truncate">
                    Inputs: {job.inputNames.join(', ')}
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-neutral-400 mt-2 font-mono tabular-nums">
                    <span>{job.workerName.split(' ')[0]} {job.workerName.split(' ')[1]}</span>
                    <span>{job.metrics?.wallClockMs}ms · {job.metrics?.cpuPercent}% CPU</span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Active Job Inspector & Live Terminal Logs */}
        <div className="w-1/2 overflow-y-auto p-5 space-y-4">
          {activeJob ? (
            <>
              {/* Header */}
              <div className="p-4 bg-white/70 dark:bg-[#202126]/70 rounded-xl border border-black/[0.06] dark:border-white/[0.08] space-y-2">
                <div className="flex items-center justify-between">
                  <h2 className="text-xs font-bold text-neutral-900 dark:text-white">{activeJob.taskTitle}</h2>
                  {getStatusBadge(activeJob.status)}
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-neutral-600 dark:text-neutral-300 font-mono">
                  <div>
                    <span className="text-neutral-400">Job ID: </span>
                    <span>{activeJob.id}</span>
                  </div>
                  <div>
                    <span className="text-neutral-400">Worker: </span>
                    <span>{activeJob.workerName}</span>
                  </div>
                  <div>
                    <span className="text-neutral-400">Duration: </span>
                    <span>{activeJob.metrics?.wallClockMs} ms</span>
                  </div>
                  <div>
                    <span className="text-neutral-400">Memory Peak: </span>
                    <span>{activeJob.metrics?.memoryMb} MB</span>
                  </div>
                </div>
              </div>

              {/* Output Summary */}
              {activeJob.outputSummary && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 space-y-1">
                  <p className="font-semibold text-[11px] uppercase tracking-wider">Result Summary</p>
                  <p>{activeJob.outputSummary}</p>
                </div>
              )}

              {/* Execution Logs Terminal */}
              <div className="p-3 bg-neutral-900 rounded-xl text-neutral-300 font-mono text-[11px] space-y-2 border border-neutral-800">
                <div className="flex items-center gap-2 text-neutral-400 pb-1 border-b border-neutral-800">
                  <Terminal className="w-3.5 h-3.5 text-[#38bdf8]" />
                  <span className="text-[10px] uppercase font-semibold">Worker Telemetry Stream</span>
                </div>
                <div className="space-y-1 max-h-56 overflow-y-auto text-[10px]">
                  {activeJob.logs.map((log, i) => (
                    <div key={i} className="flex gap-2">
                      <span className="text-neutral-500">[{log.timestamp}]</span>
                      <span className={log.level === 'error' ? 'text-red-400' : log.level === 'success' ? 'text-emerald-400' : 'text-neutral-300'}>
                        {log.message}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-12 text-neutral-400 text-xs">Select a job to inspect telemetry logs</div>
          )}
        </div>
      </div>
    </div>
  );
};
