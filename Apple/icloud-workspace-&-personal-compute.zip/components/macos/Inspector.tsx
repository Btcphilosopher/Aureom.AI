'use client';

import React, { useState } from 'react';
import { 
  X, 
  Folder, 
  FileText, 
  Image as ImageIcon, 
  Table, 
  Archive, 
  Code, 
  Copy, 
  Check, 
  Download, 
  HardDrive, 
  Cloud, 
  CloudOff, 
  History, 
  Play, 
  Share2, 
  Star,
  ShieldCheck,
  Tag
} from 'lucide-react';
import { ICloudItem, TagColor } from '@/lib/types';
import { formatDeterministicFullDate, formatDeterministicShortDate } from '@/lib/utils';

interface InspectorProps {
  selectedItems: ICloudItem[];
  onClose: () => void;
  onRunTask: (item: ICloudItem) => void;
  onToggleFavorite: (id: string) => void;
  onToggleOffline: (id: string) => void;
  onAddTag: (id: string, tag: TagColor) => void;
  onRemoveTag: (id: string, tag: TagColor) => void;
  onShare: (item: ICloudItem) => void;
  onRename: (id: string, newName: string) => void;
}

export const Inspector: React.FC<InspectorProps> = ({
  selectedItems,
  onClose,
  onRunTask,
  onToggleFavorite,
  onToggleOffline,
  onAddTag,
  onRemoveTag,
  onShare,
  onRename,
}) => {
  const [copiedHash, setCopiedHash] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState('');

  const singleItem = selectedItems.length === 1 ? selectedItems[0] : null;

  const handleCopyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  const handleStartRename = () => {
    if (singleItem) {
      setNameInput(singleItem.name);
      setIsEditingName(true);
    }
  };

  const handleSaveRename = () => {
    if (singleItem && nameInput.trim() && nameInput !== singleItem.name) {
      onRename(singleItem.id, nameInput.trim());
    }
    setIsEditingName(false);
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    if (bytes < 1024) return `${bytes} Bytes`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB (${bytes} bytes)`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB (${bytes} bytes)`;
  };

  const allTagColors: TagColor[] = ['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'gray'];

  const getTagBg = (tag: TagColor) => {
    switch (tag) {
      case 'red': return 'bg-red-500';
      case 'orange': return 'bg-amber-500';
      case 'yellow': return 'bg-yellow-400';
      case 'green': return 'bg-emerald-500';
      case 'blue': return 'bg-[#0071e3]';
      case 'purple': return 'bg-purple-500';
      case 'gray': return 'bg-neutral-400';
      default: return 'bg-neutral-400';
    }
  };

  return (
    <aside className="w-72 shrink-0 select-none flex flex-col h-full bg-[#fbfbfd]/90 dark:bg-[#18191c]/90 border-l border-black/[0.08] dark:border-white/[0.08] backdrop-blur-2xl p-3.5 text-xs text-neutral-700 dark:text-neutral-300 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-black/[0.06] dark:border-white/[0.06] mb-3">
        <span className="font-semibold text-neutral-900 dark:text-white text-xs tracking-tight">Inspector</span>
        <button
          type="button"
          onClick={onClose}
          className="p-1 rounded text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 hover:bg-black/[0.05] dark:hover:bg-white/[0.08]"
          title="Close Inspector (⌘I)"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {!singleItem && selectedItems.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center text-neutral-400 px-4">
          <FileText className="w-12 h-12 stroke-[1.2] text-neutral-300 dark:text-neutral-600 mb-2" />
          <p className="font-medium text-xs text-neutral-600 dark:text-neutral-400">No Item Selected</p>
          <p className="text-[11px] text-neutral-400 mt-1">Select a file or folder to view metadata, cryptographic checksums, and version history.</p>
        </div>
      ) : !singleItem && selectedItems.length > 1 ? (
        <div className="space-y-4">
          <div className="p-4 bg-black/[0.03] dark:bg-white/[0.04] rounded-xl text-center">
            <span className="text-2xl font-bold text-neutral-800 dark:text-neutral-200">
              {selectedItems.length}
            </span>
            <p className="text-xs font-semibold text-neutral-600 dark:text-neutral-400 mt-0.5">Items Selected</p>
            <p className="text-[11px] text-neutral-500 mt-1">
              Combined size: {formatSize(selectedItems.reduce((acc, i) => acc + i.size, 0))}
            </p>
          </div>

          <div className="space-y-2">
            <p className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">Batch Operations</p>
            <button
              type="button"
              onClick={() => onRunTask(selectedItems[0])}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-[#0071e3] text-white font-medium rounded-lg hover:bg-[#0077ed] transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Run Task on Selected</span>
            </button>
          </div>
        </div>
      ) : singleItem ? (
        <div className="space-y-4">
          {/* Preview Box */}
          <div className="flex flex-col items-center justify-center p-4 bg-black/[0.03] dark:bg-white/[0.04] rounded-xl border border-black/[0.04] dark:border-white/[0.06]">
            {singleItem.kind === 'image' && singleItem.content ? (
              <div className="w-full h-32 rounded-lg overflow-hidden flex items-center justify-center bg-black/5 dark:bg-white/5 mb-2">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={singleItem.content}
                  alt={singleItem.name}
                  className="max-h-full max-w-full object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
            ) : singleItem.kind === 'folder' ? (
              <Folder className="w-16 h-16 text-[#0071e3] fill-[#0071e3]/20 mb-2" />
            ) : singleItem.kind === 'dataset' ? (
              <Table className="w-14 h-14 text-emerald-600 mb-2" />
            ) : singleItem.kind === 'archive' ? (
              <Archive className="w-14 h-14 text-amber-600 mb-2" />
            ) : singleItem.kind === 'code' ? (
              <Code className="w-14 h-14 text-blue-500 mb-2" />
            ) : (
              <FileText className="w-14 h-14 text-neutral-500 mb-2" />
            )}

            {/* Editable Name */}
            {isEditingName ? (
              <div className="w-full mt-1 flex items-center gap-1">
                <input
                  type="text"
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveRename();
                    if (e.key === 'Escape') setIsEditingName(false);
                  }}
                  autoFocus
                  className="w-full text-xs font-semibold px-2 py-1 bg-white dark:bg-[#25262b] border border-[#0071e3] rounded text-neutral-800 dark:text-neutral-100"
                />
                <button
                  onClick={handleSaveRename}
                  className="p-1 bg-[#0071e3] text-white rounded text-[10px]"
                >
                  Save
                </button>
              </div>
            ) : (
              <div 
                onClick={handleStartRename}
                className="w-full text-center font-semibold text-xs text-neutral-800 dark:text-neutral-200 truncate cursor-text hover:text-[#0071e3] transition-colors"
                title="Click to rename"
              >
                {singleItem.name}
              </div>
            )}

            <div className="flex items-center gap-2 mt-2">
              <button
                type="button"
                onClick={() => onToggleFavorite(singleItem.id)}
                className={`p-1 rounded-md text-xs transition-colors ${
                  singleItem.isFavorite ? 'text-amber-500' : 'text-neutral-400 hover:text-neutral-600'
                }`}
                title={singleItem.isFavorite ? 'Unfavorite' : 'Mark as Favorite'}
              >
                <Star className={`w-3.5 h-3.5 ${singleItem.isFavorite ? 'fill-current' : ''}`} />
              </button>
              <button
                type="button"
                onClick={() => onShare(singleItem)}
                className="p-1 rounded-md text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
                title="Share..."
              >
                <Share2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Quick Task Action */}
          {singleItem.kind !== 'folder' && (
            <button
              type="button"
              onClick={() => onRunTask(singleItem)}
              className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-[#0071e3] text-white font-medium rounded-lg hover:bg-[#0077ed] shadow-xs transition-all cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Run Task on File...</span>
            </button>
          )}

          {/* General Metadata */}
          <div className="space-y-2 border-t border-black/[0.06] dark:border-white/[0.06] pt-3">
            <p className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">Information</p>
            <div className="space-y-1.5 text-[11px]">
              <div className="flex justify-between">
                <span className="text-neutral-500">Kind:</span>
                <span className="font-medium capitalize text-neutral-800 dark:text-neutral-200">{singleItem.kind}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Size:</span>
                <span className="font-medium text-neutral-800 dark:text-neutral-200 font-mono">{formatSize(singleItem.size)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Modified:</span>
                <span className="font-medium text-neutral-800 dark:text-neutral-200" suppressHydrationWarning>
                  {formatDeterministicFullDate(singleItem.modifiedAt)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Storage State:</span>
                <span className="font-medium capitalize text-neutral-800 dark:text-neutral-200 flex items-center gap-1">
                  {singleItem.status === 'local' ? (
                    <>
                      <HardDrive className="w-3 h-3 text-emerald-500" />
                      <span>This Mac & iCloud</span>
                    </>
                  ) : (
                    <>
                      <Cloud className="w-3 h-3 text-[#0071e3]" />
                      <span>iCloud Only</span>
                    </>
                  )}
                </span>
              </div>
            </div>
          </div>

          {/* Cryptographic SHA-256 Checksum */}
          {singleItem.checksum && (
            <div className="space-y-1.5 border-t border-black/[0.06] dark:border-white/[0.06] pt-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span>SHA-256 Checksum</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopyHash(singleItem.checksum || '')}
                  className="flex items-center gap-1 text-[10px] text-[#0071e3] hover:underline"
                >
                  {copiedHash ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedHash ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <div className="p-2 bg-black/[0.04] dark:bg-white/[0.05] rounded text-[10px] font-mono break-all text-neutral-600 dark:text-neutral-400">
                {singleItem.checksum}
              </div>
            </div>
          )}

          {/* Tags */}
          <div className="space-y-1.5 border-t border-black/[0.06] dark:border-white/[0.06] pt-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">Tags</span>
              <Tag className="w-3 h-3 text-neutral-400" />
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {allTagColors.map(color => {
                const isSelected = singleItem.tags.includes(color);
                return (
                  <button
                    key={color}
                    type="button"
                    onClick={() => {
                      if (isSelected) onRemoveTag(singleItem.id, color);
                      else onAddTag(singleItem.id, color);
                    }}
                    className={`w-4 h-4 rounded-full ${getTagBg(color)} transition-transform ${
                      isSelected ? 'ring-2 ring-offset-2 ring-neutral-400 scale-110' : 'opacity-60 hover:opacity-100'
                    }`}
                    title={isSelected ? `Remove ${color} tag` : `Add ${color} tag`}
                  />
                );
              })}
            </div>
          </div>

          {/* Offline Cache Controls */}
          <div className="space-y-2 border-t border-black/[0.06] dark:border-white/[0.06] pt-3">
            <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">Offline Cache</span>
            <button
              type="button"
              onClick={() => onToggleOffline(singleItem.id)}
              className="w-full flex items-center justify-between p-2 rounded-lg bg-black/[0.03] dark:bg-white/[0.04] hover:bg-black/[0.06] dark:hover:bg-white/[0.08] transition-colors text-left"
            >
              <div className="flex items-center gap-2">
                {singleItem.status === 'local' ? (
                  <CloudOff className="w-4 h-4 text-neutral-500" />
                ) : (
                  <Download className="w-4 h-4 text-[#0071e3]" />
                )}
                <div>
                  <span className="font-semibold text-xs text-neutral-800 dark:text-neutral-200 block">
                    {singleItem.status === 'local' ? 'Remove Local Download' : 'Keep Downloaded'}
                  </span>
                  <span className="text-[10px] text-neutral-400 block mt-0.5">
                    {singleItem.status === 'local' ? 'Free up disk space on This Mac' : 'Make available without internet'}
                  </span>
                </div>
              </div>
            </button>
          </div>

          {/* Version History */}
          <div className="space-y-2 border-t border-black/[0.06] dark:border-white/[0.06] pt-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">Version History</span>
              <History className="w-3.5 h-3.5 text-neutral-400" />
            </div>
            <div className="space-y-2">
              {singleItem.versionHistory.map(v => (
                <div key={v.version} className="p-2 bg-black/[0.02] dark:bg-white/[0.03] rounded border border-black/[0.04] dark:border-white/[0.05] text-[11px]">
                  <div className="flex justify-between items-center font-medium">
                    <span className="text-neutral-800 dark:text-neutral-200">Version {v.version}</span>
                    <span className="text-neutral-400 text-[10px]" suppressHydrationWarning>
                      {formatDeterministicShortDate(v.timestamp)}
                    </span>
                  </div>
                  <p className="text-[10px] text-neutral-500 mt-0.5">{v.note}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </aside>
  );
};
