'use client';

import React from 'react';
import { AlertTriangle, HardDrive, Server, X } from 'lucide-react';
import { ICloudItem } from '@/lib/types';
import { formatDeterministicDate } from '@/lib/utils';

interface ConflictModalProps {
  item: ICloudItem | null;
  onClose: () => void;
  onResolve: (action: 'keep_both' | 'replace' | 'skip') => void;
}

export const ConflictModal: React.FC<ConflictModalProps> = ({
  item,
  onClose,
  onResolve,
}) => {
  if (!item) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm select-none">
      <div className="w-full max-w-md p-5 bg-[#f5f5f7] dark:bg-[#202126] rounded-2xl shadow-2xl border border-amber-500/30 space-y-4">
        {/* Header */}
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-500 shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-bold text-neutral-900 dark:text-white">
              Synchronisation Conflict Detected
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
              An item named <span className="font-semibold text-neutral-800 dark:text-neutral-200">&quot;{item.name}&quot;</span> was modified on This Mac and remotely on the worker cluster.
            </p>
          </div>
        </div>

        {/* Versions Comparison Box */}
        <div className="grid grid-cols-2 gap-2 p-3 bg-black/[0.03] dark:bg-white/[0.04] rounded-xl text-xs">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-neutral-800 dark:text-neutral-200">
              <HardDrive className="w-3.5 h-3.5 text-emerald-500" />
              <span>Local Mac Version</span>
            </div>
            <p className="text-[10px] text-neutral-400" suppressHydrationWarning>Modified: {formatDeterministicDate(item.modifiedAt)}</p>
            <p className="text-[10px] text-neutral-400 font-mono">Size: {(item.size / 1024).toFixed(1)} KB</p>
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-neutral-800 dark:text-neutral-200">
              <Server className="w-3.5 h-3.5 text-[#0071e3]" />
              <span>Remote Cluster</span>
            </div>
            <p className="text-[10px] text-neutral-400">Modified: Just now</p>
            <p className="text-[10px] text-neutral-400 font-mono">Size: {(item.size / 1024).toFixed(1)} KB</p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="space-y-2 pt-1">
          <button
            type="button"
            onClick={() => onResolve('keep_both')}
            className="w-full py-2 px-3 bg-[#0071e3] text-white rounded-lg text-xs font-semibold hover:bg-[#0077ed] transition-colors"
          >
            Keep Both (Recommended)
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => onResolve('replace')}
              className="py-1.5 px-3 bg-black/[0.05] dark:bg-white/[0.08] text-neutral-700 dark:text-neutral-300 rounded-lg text-xs font-medium hover:bg-black/[0.08] transition-colors"
            >
              Replace with Remote
            </button>
            <button
              type="button"
              onClick={() => onResolve('skip')}
              className="py-1.5 px-3 bg-black/[0.05] dark:bg-white/[0.08] text-neutral-700 dark:text-neutral-300 rounded-lg text-xs font-medium hover:bg-black/[0.08] transition-colors"
            >
              Skip
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
