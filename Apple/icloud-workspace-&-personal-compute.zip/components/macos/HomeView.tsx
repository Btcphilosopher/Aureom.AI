'use client';

import React from 'react';
import { 
  Clock, 
  Folder, 
  HardDrive, 
  Cpu, 
  Play, 
  Eye, 
  UploadCloud, 
  Sparkles, 
  ArrowRight,
  ShieldCheck,
  Zap,
  Activity
} from 'lucide-react';
import { ICloudItem, ComputeJob, Workspace } from '@/lib/types';
import { formatDeterministicShortDate } from '@/lib/utils';

interface HomeViewProps {
  recentFiles: ICloudItem[];
  pinnedFolders: ICloudItem[];
  jobs: ComputeJob[];
  workspaces: Workspace[];
  storageUsedBytes: number;
  storageMaxBytes: number;
  onOpenQuickLook: (item: ICloudItem) => void;
  onRunTask: (item: ICloudItem) => void;
  onNavigateToFolder: (folderId: string | null) => void;
  onOpenTaskModal: () => void;
  onSelectDestination: (dest: any) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  recentFiles,
  pinnedFolders,
  jobs,
  workspaces,
  storageUsedBytes,
  storageMaxBytes,
  onOpenQuickLook,
  onRunTask,
  onNavigateToFolder,
  onOpenTaskModal,
  onSelectDestination,
}) => {
  const activeJobs = jobs.filter(j => j.status === 'running' || j.status === 'preparing');

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-white/50 dark:bg-[#1a1b1e]/50 select-none p-6 space-y-6">
      {/* Welcome Hero / Quick Drop Action */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0071e3]/10 via-[#8e44ad]/10 to-transparent border border-black/[0.06] dark:border-white/[0.08] shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-[#0071e3] uppercase tracking-wider">macOS Sequoia Workspace</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#0071e3]/10 text-[#0071e3] font-medium">Native iCloud</span>
          </div>
          <h1 className="text-xl font-bold text-neutral-900 dark:text-white">
            Welcome to iCloud Studio
          </h1>
          <p className="text-xs text-neutral-600 dark:text-neutral-400 max-w-xl">
            Drop files from Finder, run distributed batch tasks on Apple Silicon or FastAPI workers, and monitor synchronised outputs in real time.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenTaskModal}
          className="flex items-center gap-2 px-4 py-2 bg-[#0071e3] text-white rounded-xl text-xs font-semibold hover:bg-[#0077ed] transition-all shadow-xs shrink-0 cursor-pointer"
        >
          <Zap className="w-4 h-4 fill-current" />
          <span>Launch Compute Task</span>
        </button>
      </div>

      {/* 2-Column Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 spans): Recent Files & Active Transfers */}
        <div className="lg:col-span-2 space-y-6">
          {/* Recent Work */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                <Clock className="w-4 h-4 text-[#0071e3]" />
                <span>Recent Files</span>
              </div>
              <button
                type="button"
                onClick={() => onSelectDestination('my-files')}
                className="text-xs text-[#0071e3] hover:underline flex items-center gap-1 font-medium"
              >
                <span>View All Files</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {recentFiles.slice(0, 4).map(file => (
                <div
                  key={file.id}
                  onClick={() => onOpenQuickLook(file)}
                  className="p-3.5 bg-white/70 dark:bg-[#202126]/70 rounded-xl border border-black/[0.06] dark:border-white/[0.08] hover:border-[#0071e3] transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3 truncate">
                    <div className="w-9 h-9 rounded-lg bg-black/[0.03] dark:bg-white/[0.05] flex items-center justify-center shrink-0">
                      {file.kind === 'image' && file.content ? (
                        /* eslint-disable-next-line @next/next/no-img-element */
                        <img
                          src={file.content}
                          alt={file.name}
                          className="w-full h-full object-cover rounded-lg"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <Folder className="w-5 h-5 text-[#0071e3]" />
                      )}
                    </div>
                    <div className="truncate">
                      <p className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 truncate">{file.name}</p>
                      <p className="text-[10px] text-neutral-400 font-mono" suppressHydrationWarning>
                        {(file.size / 1024).toFixed(1)} KB · {formatDeterministicShortDate(file.modifiedAt)}
                      </p>
                    </div>
                  </div>

                  <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 transition-opacity">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenQuickLook(file);
                      }}
                      className="p-1 text-neutral-500 hover:text-[#0071e3]"
                      title="Quick Look (Spacebar)"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                    {file.kind !== 'folder' && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRunTask(file);
                        }}
                        className="p-1 text-neutral-500 hover:text-[#0071e3]"
                        title="Run Task"
                      >
                        <Play className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pinned Folders */}
          <div className="space-y-3">
            <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
              Pinned Directories
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {pinnedFolders.map(folder => (
                <button
                  key={folder.id}
                  type="button"
                  onClick={() => {
                    onSelectDestination('my-files');
                    onNavigateToFolder(folder.id);
                  }}
                  className="p-3 bg-white/70 dark:bg-[#202126]/70 rounded-xl border border-black/[0.06] dark:border-white/[0.08] hover:border-[#0071e3] transition-all text-left flex items-center gap-3"
                >
                  <Folder className="w-6 h-6 text-[#0071e3] fill-[#0071e3]/20 shrink-0" />
                  <div className="truncate">
                    <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 truncate block">{folder.name}</span>
                    <span className="text-[10px] text-neutral-400 block mt-0.5">Available locally</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Running Jobs & Health Overview */}
        <div className="space-y-6">
          {/* Active Jobs Widget */}
          <div className="p-4 rounded-xl bg-white/70 dark:bg-[#202126]/70 border border-black/[0.06] dark:border-white/[0.08] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-500" />
                <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                  Compute Status
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onSelectDestination('compute')}
                className="text-xs text-[#0071e3] hover:underline"
              >
                Queue
              </button>
            </div>

            {activeJobs.length === 0 ? (
              <p className="text-xs text-neutral-400 py-3 text-center">
                All compute tasks finished. Workers idle.
              </p>
            ) : (
              <div className="space-y-2">
                {activeJobs.map(j => (
                  <div key={j.id} className="p-2.5 bg-black/[0.02] dark:bg-white/[0.03] rounded-lg space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold text-neutral-800 dark:text-neutral-200 truncate">{j.taskTitle}</span>
                      <span className="text-emerald-500 font-mono text-[10px]">{j.progress}%</span>
                    </div>
                    <div className="w-full h-1 bg-black/[0.06] dark:bg-white/[0.08] rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${j.progress}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-2 border-t border-black/[0.04] dark:border-white/[0.04] flex items-center justify-between text-[11px] text-neutral-500">
              <span>This Mac Sandbox</span>
              <span className="text-emerald-600 font-medium">4 Threads Ready</span>
            </div>
          </div>

          {/* Workspaces Shortcut Card */}
          <div className="p-4 rounded-xl bg-white/70 dark:bg-[#202126]/70 border border-black/[0.06] dark:border-white/[0.08] space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                Active Projects
              </h2>
              <button
                type="button"
                onClick={() => onSelectDestination('workspaces')}
                className="text-xs text-[#0071e3] hover:underline"
              >
                All
              </button>
            </div>
            <div className="space-y-2">
              {workspaces.map(ws => (
                <div
                  key={ws.id}
                  onClick={() => onSelectDestination('workspaces')}
                  className="flex items-center justify-between p-2 rounded-lg hover:bg-black/[0.03] dark:hover:bg-white/[0.04] transition-colors cursor-pointer text-xs"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: ws.color }} />
                    <span className="font-medium text-neutral-800 dark:text-neutral-200 truncate">{ws.name}</span>
                  </div>
                  <span className="text-[10px] text-neutral-400 font-mono">{ws.itemIds.length} files</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
