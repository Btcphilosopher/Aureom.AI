'use client';

import React, { useRef } from 'react';
import { 
  PanelLeft, 
  ChevronLeft, 
  ChevronRight, 
  LayoutGrid, 
  List, 
  Search, 
  Play, 
  Eye, 
  UploadCloud, 
  FolderPlus, 
  Sidebar as SidebarIcon,
  Sun,
  Moon,
  Code2,
  Monitor,
  Tablet,
  Smartphone,
  Cloud
} from 'lucide-react';
import { ViewMode, DeviceMode, NavigationDestination } from '@/lib/types';
import { TrafficLights } from './TrafficLights';

interface ToolbarProps {
  destination: NavigationDestination;
  currentFolderName?: string;
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  isInspectorOpen: boolean;
  onToggleInspector: () => void;
  viewMode: ViewMode;
  onChangeViewMode: (mode: ViewMode) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onRunTask: () => void;
  onQuickLook: () => void;
  onNewFolder: () => void;
  onUploadFiles: (files: FileList) => void;
  deviceMode: DeviceMode;
  onChangeDeviceMode: (mode: DeviceMode) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenCodeHub: () => void;
  hasSelection: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  onGoBack: () => void;
  onGoForward: () => void;
}

export const Toolbar: React.FC<ToolbarProps> = ({
  destination,
  currentFolderName,
  isSidebarOpen,
  onToggleSidebar,
  isInspectorOpen,
  onToggleInspector,
  viewMode,
  onChangeViewMode,
  searchQuery,
  onSearchChange,
  onRunTask,
  onQuickLook,
  onNewFolder,
  onUploadFiles,
  deviceMode,
  onChangeDeviceMode,
  isDarkMode,
  onToggleDarkMode,
  onOpenCodeHub,
  hasSelection,
  canGoBack,
  canGoForward,
  onGoBack,
  onGoForward,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getTitle = () => {
    if (currentFolderName) return currentFolderName;
    switch (destination) {
      case 'home': return 'Home';
      case 'my-files': return 'iCloud Drive';
      case 'workspaces': return 'Workspaces';
      case 'compute': return 'Compute & Workers';
      case 'shared': return 'Shared';
      case 'activity': return 'Activity Stream';
      case 'trash': return 'Trash';
      case 'settings': return 'iCloud Settings';
      default: return 'iCloud';
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onUploadFiles(e.target.files);
      e.target.value = '';
    }
  };

  return (
    <header className="h-13 select-none flex items-center justify-between px-3.5 border-b border-black/[0.08] dark:border-white/[0.08] bg-white/70 dark:bg-[#1f2024]/80 backdrop-blur-xl z-20 shrink-0">
      {/* Left zone: Traffic lights, Sidebar toggle, History buttons */}
      <div className="flex items-center gap-3">
        <TrafficLights className="mr-1" />

        <button
          type="button"
          onClick={onToggleSidebar}
          className={`p-1.5 rounded-md text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08] transition-colors ${
            !isSidebarOpen ? 'text-neutral-400' : ''
          }`}
          title="Toggle Sidebar (⌘S)"
        >
          <PanelLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-0.5">
          <button
            type="button"
            onClick={onGoBack}
            disabled={!canGoBack}
            className="p-1.5 rounded-md text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08] disabled:opacity-30 disabled:pointer-events-none transition-colors"
            title="Back (⌘[)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onGoForward}
            disabled={!canGoForward}
            className="p-1.5 rounded-md text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08] disabled:opacity-30 disabled:pointer-events-none transition-colors"
            title="Forward (⌘])"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Proxy Icon & Title */}
        <div className="flex items-center gap-1.5 ml-1">
          <Cloud className="w-4 h-4 text-[#0071e3]" />
          <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 tracking-tight">
            {getTitle()}
          </span>
        </div>
      </div>

      {/* Middle zone: View mode toggle & Search */}
      <div className="flex items-center gap-2 max-w-md w-full justify-center">
        {/* View mode segmented switch */}
        <div className="flex items-center p-0.5 bg-black/[0.06] dark:bg-white/[0.08] rounded-md">
          <button
            type="button"
            onClick={() => onChangeViewMode('grid')}
            className={`p-1 rounded text-xs transition-all ${
              viewMode === 'grid'
                ? 'bg-white dark:bg-[#2b2c32] text-neutral-900 dark:text-white shadow-xs font-medium'
                : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
            title="Icon Grid View"
          >
            <LayoutGrid className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onChangeViewMode('list')}
            className={`p-1 rounded text-xs transition-all ${
              viewMode === 'list'
                ? 'bg-white dark:bg-[#2b2c32] text-neutral-900 dark:text-white shadow-xs font-medium'
                : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
            title="List Table View"
          >
            <List className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Search input */}
        <div className="relative w-48 sm:w-60">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search files or checksums"
            className="w-full text-xs pl-8 pr-2.5 py-1.5 bg-black/[0.05] dark:bg-white/[0.07] border border-transparent focus:border-[#0071e3]/40 rounded-md text-neutral-800 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:bg-white dark:focus:bg-[#1a1b1e] transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
            >
              ×
            </button>
          )}
        </div>
      </div>

      {/* Right zone: Actions, Device switcher, Dark Mode, Architecture */}
      <div className="flex items-center gap-1.5">
        {/* Run Compute Task */}
        <button
          type="button"
          onClick={onRunTask}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
            hasSelection
              ? 'bg-[#0071e3] text-white hover:bg-[#0077ed] shadow-xs cursor-pointer'
              : 'bg-black/[0.05] dark:bg-white/[0.07] text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.08] dark:hover:bg-white/[0.12]'
          }`}
          title="Run Compute Task on Selected Files (⌘R)"
        >
          <Play className="w-3 h-3 fill-current" />
          <span className="hidden lg:inline">Run Task</span>
        </button>

        {/* Quick Look button */}
        <button
          type="button"
          onClick={onQuickLook}
          disabled={!hasSelection}
          className="p-1.5 rounded-md text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08] disabled:opacity-30 disabled:pointer-events-none transition-colors"
          title="Quick Look Preview (Spacebar)"
        >
          <Eye className="w-4 h-4" />
        </button>

        {/* Upload File */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileChange}
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-1.5 rounded-md text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08] transition-colors"
          title="Upload Files from Computer (⌘U)"
        >
          <UploadCloud className="w-4 h-4" />
        </button>

        {/* New Folder */}
        <button
          type="button"
          onClick={onNewFolder}
          className="p-1.5 rounded-md text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08] transition-colors"
          title="New Folder (⇧⌘N)"
        >
          <FolderPlus className="w-4 h-4" />
        </button>

        {/* Toggle Inspector */}
        <button
          type="button"
          onClick={onToggleInspector}
          className={`p-1.5 rounded-md transition-colors ${
            isInspectorOpen
              ? 'bg-[#0071e3]/15 text-[#0071e3] dark:bg-[#0071e3]/30'
              : 'text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08]'
          }`}
          title="Toggle Inspector (⌘I)"
        >
          <SidebarIcon className="w-4 h-4" />
        </button>

        <div className="h-4 w-px bg-black/[0.1] dark:bg-white/[0.1] mx-1" />

        {/* Device Companion Switcher (macOS / iPadOS / iOS) */}
        <div className="flex items-center p-0.5 bg-black/[0.06] dark:bg-white/[0.08] rounded-md">
          <button
            type="button"
            onClick={() => onChangeDeviceMode('mac')}
            className={`p-1 rounded text-xs transition-all ${
              deviceMode === 'mac'
                ? 'bg-white dark:bg-[#2b2c32] text-neutral-900 dark:text-white shadow-xs'
                : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
            title="macOS Desktop Studio"
          >
            <Monitor className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onChangeDeviceMode('ipad')}
            className={`p-1 rounded text-xs transition-all ${
              deviceMode === 'ipad'
                ? 'bg-white dark:bg-[#2b2c32] text-neutral-900 dark:text-white shadow-xs'
                : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
            title="iPadOS Companion (Stage Manager)"
          >
            <Tablet className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onChangeDeviceMode('iphone')}
            className={`p-1 rounded text-xs transition-all ${
              deviceMode === 'iphone'
                ? 'bg-white dark:bg-[#2b2c32] text-neutral-900 dark:text-white shadow-xs'
                : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
            }`}
            title="iOS iPhone Companion"
          >
            <Smartphone className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Dark Mode Toggle */}
        <button
          type="button"
          onClick={onToggleDarkMode}
          className="p-1.5 rounded-md text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08] transition-colors"
          title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        >
          {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Code & Architecture Deliverables */}
        <button
          type="button"
          onClick={onOpenCodeHub}
          className="flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 hover:opacity-90 transition-opacity ml-1"
          title="Inspect Native Swift Xcode & Python Worker Code"
        >
          <Code2 className="w-3.5 h-3.5" />
          <span className="hidden xl:inline text-[11px]">Xcode & Architecture</span>
        </button>
      </div>
    </header>
  );
};
