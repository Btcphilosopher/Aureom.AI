'use client';

import React, { useState } from 'react';
import { 
  Settings, 
  HardDrive, 
  Cpu, 
  Server, 
  ShieldCheck, 
  Key, 
  CheckCircle2, 
  RefreshCw,
  Sliders
} from 'lucide-react';

interface SettingsViewProps {
  storageUsedBytes: number;
  storageMaxBytes: number;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  storageUsedBytes,
  storageMaxBytes,
}) => {
  const [workerUrl, setWorkerUrl] = useState('http://127.0.0.1:8000');
  const [workerToken, setWorkerToken] = useState('••••••••••••••••••••••••••••••••');
  const [isPinging, setIsPinging] = useState(false);
  const [pingStatus, setPingStatus] = useState<string | null>(null);
  const [maxConcurrency, setMaxConcurrency] = useState(4);
  const [maxMemoryMb, setMaxMemoryMb] = useState(2048);
  const [plan, setPlan] = useState<'50gb' | '200gb' | '2tb'>('50gb');

  const storageUsedGB = (storageUsedBytes / (1024 * 1024 * 1024)).toFixed(1);
  const storageMaxGB = (storageMaxBytes / (1024 * 1024 * 1024)).toFixed(0);

  const handlePingWorker = async () => {
    setIsPinging(true);
    setPingStatus(null);
    await new Promise(r => setTimeout(r, 600));
    setPingStatus('Verified: FastAPI Daemon v1.0.0 responding with 12ms latency');
    setIsPinging(false);
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-white/50 dark:bg-[#1a1b1e]/50 select-none p-6 space-y-6">
      <div className="pb-3 border-b border-black/[0.08] dark:border-white/[0.08]">
        <h1 className="text-base font-bold text-neutral-900 dark:text-white">
          iCloud Settings & Preferences
        </h1>
        <p className="text-xs text-neutral-500 dark:text-neutral-400">
          Configure storage limits, personal compute endpoints, Keychain encryption, and sandbox policies.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-4xl">
        {/* Section 1: Storage Tier & Usage */}
        <div className="p-4 rounded-xl bg-white/70 dark:bg-[#202126]/70 border border-black/[0.06] dark:border-white/[0.08] space-y-3">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-[#0071e3]" />
            <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">iCloud Storage Tier</h2>
          </div>

          <div className="p-3 bg-black/[0.02] dark:bg-white/[0.03] rounded-lg space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-neutral-500">Storage Consumption</span>
              <span className="font-mono font-semibold text-neutral-800 dark:text-neutral-200">{storageUsedGB} GB of {storageMaxGB} GB</span>
            </div>
            <div className="w-full h-2 bg-black/[0.08] dark:bg-white/[0.1] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#0071e3] rounded-full"
                style={{ width: `${(storageUsedBytes / storageMaxBytes) * 100}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-xs">
            {(['50gb', '200gb', '2tb'] as const).map(p => (
              <button
                key={p}
                type="button"
                onClick={() => setPlan(p)}
                className={`p-2 rounded-lg border text-center transition-all ${
                  plan === p
                    ? 'border-[#0071e3] bg-[#0071e3]/10 font-bold text-[#0071e3]'
                    : 'border-black/[0.06] dark:border-white/[0.06] text-neutral-600 dark:text-neutral-300'
                }`}
              >
                <span className="uppercase block font-semibold">{p}</span>
                <span className="text-[10px] text-neutral-400 font-normal block mt-0.5">
                  {p === '50gb' ? '$0.99/mo' : p === '200gb' ? '$2.99/mo' : '$9.99/mo'}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Section 2: Personal Compute Quota */}
        <div className="p-4 rounded-xl bg-white/70 dark:bg-[#202126]/70 border border-black/[0.06] dark:border-white/[0.08] space-y-3">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-500" />
            <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">Compute Quotas</h2>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-neutral-500">Apple Silicon Local Sandbox:</span>
              <span className="font-semibold text-emerald-600">Unlimited (Local GPU)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Remote FastAPI Allowance:</span>
              <span className="font-mono font-semibold text-neutral-800 dark:text-neutral-200">3.2 / 20.0 Hours</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Concurrent Workers Cap:</span>
              <span className="font-mono text-neutral-800 dark:text-neutral-200">Max {maxConcurrency} tasks</span>
            </div>
          </div>

          <div className="pt-2 border-t border-black/[0.04] dark:border-white/[0.04]">
            <label className="text-[11px] text-neutral-500 block mb-1">Worker Concurrency Limit</label>
            <input
              type="range"
              min={1}
              max={8}
              value={maxConcurrency}
              onChange={e => setMaxConcurrency(parseInt(e.target.value))}
              className="w-full accent-[#0071e3]"
            />
            <div className="flex justify-between text-[10px] text-neutral-400 mt-1">
              <span>1 Worker</span>
              <span>{maxConcurrency} Parallel Jobs</span>
              <span>8 Workers</span>
            </div>
          </div>
        </div>

        {/* Section 3: Remote FastAPI Worker Node */}
        <div className="p-4 rounded-xl bg-white/70 dark:bg-[#202126]/70 border border-black/[0.06] dark:border-white/[0.08] space-y-3 md:col-span-2">
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 text-purple-500" />
            <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">Remote Compute Daemon (FastAPI)</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-neutral-500 block mb-1">Daemon Endpoint URL</label>
              <input
                type="text"
                value={workerUrl}
                onChange={e => setWorkerUrl(e.target.value)}
                className="w-full px-3 py-1.5 bg-black/[0.04] dark:bg-white/[0.06] rounded-lg border border-transparent focus:border-[#0071e3] font-mono text-xs"
              />
            </div>
            <div>
              <label className="text-neutral-500 block mb-1">Keychain Bearer Credential</label>
              <input
                type="text"
                value={workerToken}
                onChange={e => setWorkerToken(e.target.value)}
                className="w-full px-3 py-1.5 bg-black/[0.04] dark:bg-white/[0.06] rounded-lg border border-transparent focus:border-[#0071e3] font-mono text-xs"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePingWorker}
              disabled={isPinging}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-black/[0.04] dark:bg-white/[0.06] hover:bg-black/[0.08] rounded-lg text-xs font-medium text-neutral-800 dark:text-neutral-200 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isPinging ? 'animate-spin' : ''}`} />
              <span>{isPinging ? 'Pinging Worker...' : 'Test Connection'}</span>
            </button>

            {pingStatus && (
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                {pingStatus}
              </span>
            )}
          </div>
        </div>

        {/* Section 4: Privacy & Keychain */}
        <div className="p-4 rounded-xl bg-white/70 dark:bg-[#202126]/70 border border-black/[0.06] dark:border-white/[0.08] space-y-2 md:col-span-2 text-xs">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">Privacy & Security Policies</h2>
          </div>
          <p className="text-neutral-500 dark:text-neutral-400 leading-relaxed text-[11px]">
            - All compute requests strictly observe App Sandbox file read restrictions.<br />
            - Tokens are preserved in macOS Keychain and never recorded in persistent logs.<br />
            - Archive extraction blocks path traversal (Zip Slip protection).<br />
            - Plaintext files transmitted to remote workers are purged immediately on job completion.
          </p>
        </div>
      </div>
    </div>
  );
};
