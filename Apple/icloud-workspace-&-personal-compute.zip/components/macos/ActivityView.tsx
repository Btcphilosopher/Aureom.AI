'use client';

import React, { useState } from 'react';
import { 
  Activity, 
  UploadCloud, 
  DownloadCloud, 
  Cpu, 
  AlertTriangle, 
  Share2, 
  Trash2, 
  CheckCircle2,
  Clock
} from 'lucide-react';
import { ActivityEvent } from '@/lib/types';
import { formatDeterministicDate } from '@/lib/utils';

interface ActivityViewProps {
  activities: ActivityEvent[];
  onClearActivities: () => void;
}

export const ActivityView: React.FC<ActivityViewProps> = ({
  activities,
  onClearActivities,
}) => {
  const [filterType, setFilterType] = useState<string>('all');

  const filtered = activities.filter(a => {
    if (filterType === 'all') return true;
    return a.type === filterType;
  });

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'compute_job':
        return <Cpu className="w-4 h-4 text-[#8e44ad]" />;
      case 'upload':
        return <UploadCloud className="w-4 h-4 text-[#0071e3]" />;
      case 'download':
        return <DownloadCloud className="w-4 h-4 text-emerald-500" />;
      case 'conflict':
        return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'share':
        return <Share2 className="w-4 h-4 text-blue-400" />;
      case 'trash':
        return <Trash2 className="w-4 h-4 text-red-500" />;
      default:
        return <Activity className="w-4 h-4 text-neutral-400" />;
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-white/50 dark:bg-[#1a1b1e]/50 select-none p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-black/[0.08] dark:border-white/[0.08]">
        <div>
          <h1 className="text-base font-bold text-neutral-900 dark:text-white">
            Activity Stream & Audit Log
          </h1>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Real-time timeline of uploads, background compute jobs, permissions, and conflict handshakes.
          </p>
        </div>
        <button
          type="button"
          onClick={onClearActivities}
          className="px-3 py-1.5 rounded-lg border border-black/[0.08] dark:border-white/[0.08] text-xs font-medium text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.04]"
        >
          Clear Log
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-black/[0.04] dark:bg-white/[0.06] rounded-lg w-fit text-xs font-medium">
        {(['all', 'compute_job', 'upload', 'conflict', 'share'] as const).map(f => (
          <button
            key={f}
            type="button"
            onClick={() => setFilterType(f)}
            className={`px-3 py-1 rounded-md capitalize transition-all ${
              filterType === f
                ? 'bg-white dark:bg-[#2b2c32] text-neutral-900 dark:text-white shadow-xs font-semibold'
                : 'text-neutral-500 hover:text-neutral-800'
            }`}
          >
            {f === 'all' ? 'All Events' : f === 'compute_job' ? 'Compute' : f}
          </button>
        ))}
      </div>

      {/* Timeline List */}
      <div className="flex-1 overflow-y-auto space-y-2">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-neutral-400 text-xs">No activity recorded for this filter.</div>
        ) : (
          filtered.map(act => (
            <div
              key={act.id}
              className="p-3.5 bg-white/70 dark:bg-[#202126]/70 rounded-xl border border-black/[0.06] dark:border-white/[0.08] flex items-start gap-3 hover:border-black/[0.12] transition-colors"
            >
              <div className="p-2 rounded-lg bg-black/[0.03] dark:bg-white/[0.05] shrink-0 mt-0.5">
                {getEventIcon(act.type)}
              </div>
              <div className="flex-1 space-y-0.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">{act.title}</h3>
                  <span className="text-[10px] text-neutral-400 font-mono" suppressHydrationWarning>
                    {formatDeterministicDate(act.timestamp)}
                  </span>
                </div>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-normal">
                  {act.detail}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
