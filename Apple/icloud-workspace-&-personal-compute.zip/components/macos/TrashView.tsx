'use client';

import React from 'react';
import { Trash2, RotateCcw, AlertTriangle, FileText } from 'lucide-react';
import { ICloudItem } from '@/lib/types';
import { formatDeterministicShortDate } from '@/lib/utils';

interface TrashViewProps {
  trashItems: ICloudItem[];
  onRestoreItem: (id: string) => void;
  onEmptyTrash: () => void;
}

export const TrashView: React.FC<TrashViewProps> = ({
  trashItems,
  onRestoreItem,
  onEmptyTrash,
}) => {
  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-white/50 dark:bg-[#1a1b1e]/50 select-none p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-black/[0.08] dark:border-white/[0.08]">
        <div>
          <h1 className="text-base font-bold text-neutral-900 dark:text-white">
            Trash ({trashItems.length})
          </h1>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Items in Trash are preserved for 30 days and can be restored back to their original locations.
          </p>
        </div>
        {trashItems.length > 0 && (
          <button
            type="button"
            onClick={onEmptyTrash}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-medium hover:bg-red-600 transition-colors shadow-xs"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Empty Trash</span>
          </button>
        )}
      </div>

      {/* Trash Items List */}
      <div className="flex-1 overflow-y-auto space-y-2">
        {trashItems.length === 0 ? (
          <div className="text-center py-20 text-neutral-400 text-xs">
            <Trash2 className="w-12 h-12 stroke-[1.2] mx-auto mb-2 text-neutral-400" />
            <p className="font-semibold text-neutral-700 dark:text-neutral-300">Trash is Empty</p>
            <p className="text-[11px] text-neutral-400 mt-1">Deleted items will appear here before permanent purging.</p>
          </div>
        ) : (
          trashItems.map(item => (
            <div
              key={item.id}
              className="p-3 bg-white/70 dark:bg-[#202126]/70 rounded-xl border border-black/[0.06] dark:border-white/[0.08] flex items-center justify-between hover:bg-white transition-colors"
            >
              <div className="flex items-center gap-3">
                <FileText className="w-4 h-4 text-neutral-400" />
                <div>
                  <p className="text-xs font-semibold text-neutral-800 dark:text-neutral-200">{item.name}</p>
                  <p className="text-[10px] text-neutral-400 font-mono" suppressHydrationWarning>
                    Deleted on {item.deletedAt ? formatDeterministicShortDate(item.deletedAt) : 'Recently'} · {(item.size / 1024).toFixed(1)} KB
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onRestoreItem(item.id)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black/[0.08] dark:border-white/[0.08] text-xs font-medium text-[#0071e3] hover:bg-[#0071e3]/10 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Put Back</span>
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
