'use client';

import React, { useEffect } from 'react';
import { X, Play, Download, ShieldCheck, FileText, Table, Archive, Code } from 'lucide-react';
import { ICloudItem } from '@/lib/types';

interface QuickLookModalProps {
  item: ICloudItem | null;
  onClose: () => void;
  onRunTask: (item: ICloudItem) => void;
}

export const QuickLookModal: React.FC<QuickLookModalProps> = ({
  item,
  onClose,
  onRunTask,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === ' ') {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!item) return null;

  const handleDownload = () => {
    if (!item.content) return;
    const link = document.createElement('a');
    link.href = item.content;
    link.download = item.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderContent = () => {
    if (item.kind === 'image' && item.content) {
      return (
        <div className="w-full h-full flex items-center justify-center p-4 bg-neutral-900/10 dark:bg-black/40 overflow-hidden">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={item.content}
            alt={item.name}
            className="max-h-[60vh] max-w-full object-contain rounded-lg shadow-md"
            referrerPolicy="no-referrer"
          />
        </div>
      );
    }

    if (item.kind === 'dataset' && item.content) {
      const lines = item.content.split(/\r?\n/).filter(l => l.trim().length > 0);
      const headers = lines[0]?.split(',') || [];
      const rows = lines.slice(1, 15).map(l => l.split(','));

      return (
        <div className="w-full h-full p-4 overflow-auto">
          <div className="border border-black/[0.08] dark:border-white/[0.1] rounded-lg overflow-hidden bg-white/80 dark:bg-[#1a1b1e]/80">
            <table className="w-full text-xs">
              <thead className="bg-neutral-100 dark:bg-neutral-800 border-b border-black/[0.08] dark:border-white/[0.08] text-neutral-600 dark:text-neutral-300 font-semibold">
                <tr>
                  {headers.map((h, i) => (
                    <th key={i} className="py-2 px-3 text-left">{h.trim()}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-black/[0.04] dark:divide-white/[0.04]">
                {rows.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-black/[0.02] dark:hover:bg-white/[0.02]">
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} className="py-1.5 px-3 font-mono text-[11px] text-neutral-700 dark:text-neutral-300">
                        {cell.trim()}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {lines.length > 15 && (
            <p className="text-[11px] text-neutral-400 text-center mt-2">
              Showing first 14 of {lines.length - 1} rows
            </p>
          )}
        </div>
      );
    }

    if (item.kind === 'document' && item.content) {
      return (
        <div className="w-full h-full p-6 overflow-auto bg-white/70 dark:bg-[#1c1d21]/70 font-sans text-xs text-neutral-800 dark:text-neutral-200 leading-relaxed whitespace-pre-wrap">
          {item.content}
        </div>
      );
    }

    if (item.kind === 'code' && item.content) {
      return (
        <div className="w-full h-full p-4 overflow-auto bg-[#18191c] text-[#38bdf8] font-mono text-xs leading-relaxed">
          <pre>{item.content}</pre>
        </div>
      );
    }

    return (
      <div className="w-full h-full flex flex-col items-center justify-center p-8 text-neutral-400">
        <FileText className="w-16 h-16 stroke-[1.2] mb-3 text-neutral-500" />
        <p className="text-xs font-semibold text-neutral-700 dark:text-neutral-300">{item.name}</p>
        <p className="text-[11px] text-neutral-400 mt-1">Binary file preview not available</p>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-md animate-fade-in">
      <div 
        className="w-full max-w-3xl max-h-[82vh] flex flex-col bg-[#f5f5f7]/95 dark:bg-[#1e1f23]/95 border border-black/[0.12] dark:border-white/[0.15] rounded-2xl shadow-2xl overflow-hidden backdrop-blur-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Quick Look Header */}
        <div className="h-11 flex items-center justify-between px-4 border-b border-black/[0.08] dark:border-white/[0.08] bg-white/50 dark:bg-white/[0.03]">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="w-3.5 h-3.5 rounded-full bg-[#ff5f57] border border-[#e0443e] flex items-center justify-center text-[8px] text-[#4d0000] opacity-90 hover:opacity-100"
              title="Close Quick Look (Space or Esc)"
            >
              ×
            </button>
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 ml-1 truncate max-w-sm">
              {item.name}
            </span>
            <span className="text-[11px] text-neutral-400">
              · {(item.size / 1024).toFixed(1)} KB
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md bg-black/[0.05] dark:bg-white/[0.08] hover:bg-black/[0.08] text-neutral-700 dark:text-neutral-200 transition-colors"
              title="Export File to Finder"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export</span>
            </button>

            {item.kind !== 'folder' && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onRunTask(item);
                }}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md bg-[#0071e3] text-white hover:bg-[#0077ed] transition-colors shadow-xs"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>Run Task</span>
              </button>
            )}
          </div>
        </div>

        {/* Content Viewer */}
        <div className="flex-1 min-h-[380px] max-h-[60vh] overflow-hidden">
          {renderContent()}
        </div>

        {/* Quick Look Footer */}
        <div className="h-9 px-4 border-t border-black/[0.08] dark:border-white/[0.08] flex items-center justify-between text-[11px] text-neutral-400 bg-white/40 dark:bg-black/20">
          <div className="flex items-center gap-1.5 truncate max-w-md">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
            <span className="font-mono truncate">{item.checksum || 'Verified SHA-256 Digest'}</span>
          </div>
          <span className="text-[10px]">Press Space or Esc to dismiss</span>
        </div>
      </div>
    </div>
  );
};
