'use client';

import React, { useState } from 'react';
import { 
  X, 
  Play, 
  CheckCircle2, 
  AlertCircle, 
  Cpu, 
  Server, 
  Download, 
  FolderPlus, 
  FileText, 
  Image as ImageIcon, 
  Table, 
  Archive, 
  ShieldCheck, 
  BarChart2, 
  Terminal,
  Activity,
  HardDrive
} from 'lucide-react';
import { ICloudItem, ComputeTaskType, ComputeJob, JobLog, JobMetrics } from '@/lib/types';
import { 
  executeImageResizeConvert, 
  executeCsvSummaryStats, 
  executeDatasetChart, 
  executeDocumentTextExtract, 
  executeArchivePack, 
  executeChecksumVerify,
  ComputeResult
} from '@/lib/computeEngine';

interface TaskRunnerModalProps {
  inputItems: ICloudItem[];
  onClose: () => void;
  onSaveOutputsToCloud: (newItems: ICloudItem[]) => void;
  onRecordJob: (job: ComputeJob) => void;
}

export const TaskRunnerModal: React.FC<TaskRunnerModalProps> = ({
  inputItems,
  onClose,
  onSaveOutputsToCloud,
  onRecordJob,
}) => {
  // Determine default task based on input types
  const defaultTask: ComputeTaskType = (() => {
    if (inputItems.length > 1) return 'archive_pack';
    const first = inputItems[0];
    if (first?.kind === 'image') return 'image_resize_convert';
    if (first?.kind === 'dataset') return 'csv_summary_stats';
    if (first?.kind === 'document') return 'document_text_extract';
    return 'checksum_verify';
  })();

  const [selectedTask, setSelectedTask] = useState<ComputeTaskType>(defaultTask);
  const [workerTarget, setWorkerTarget] = useState<'local' | 'remote'>('local');

  // Task parameters
  const [imgWidth, setImgWidth] = useState(1200);
  const [imgHeight, setImgHeight] = useState(800);
  const [imgFormat, setImgFormat] = useState<'webp' | 'jpeg' | 'png'>('webp');
  const [imgQuality, setImgQuality] = useState(0.85);
  const [imgGrayscale, setImgGrayscale] = useState(false);

  const [chartType, setChartType] = useState<'bar' | 'line' | 'area'>('bar');
  const [archiveName, setArchiveName] = useState('iCloud_Secure_Bundle.zip');

  // Job execution state
  const [isExecuting, setIsExecuting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState('');
  const [logs, setLogs] = useState<JobLog[]>([]);
  const [result, setResult] = useState<ComputeResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [liveMetrics, setLiveMetrics] = useState<JobMetrics>({
    cpuPercent: 0,
    memoryMb: 0,
    wallClockMs: 0,
    ioBytes: 0,
  });

  const availableTasks: { type: ComputeTaskType; label: string; icon: React.ReactNode; desc: string }[] = [
    { 
      type: 'image_resize_convert', 
      label: 'Resize & Convert Image', 
      icon: <ImageIcon className="w-4 h-4 text-purple-500" />,
      desc: 'Downscale, transcode (WebP/JPEG/PNG), and compress with Canvas.' 
    },
    { 
      type: 'csv_summary_stats', 
      label: 'Summarise CSV Dataset', 
      icon: <Table className="w-4 h-4 text-emerald-500" />,
      desc: 'Calculate row distributions, column types, means, and integrity.' 
    },
    { 
      type: 'dataset_chart', 
      label: 'Generate Dataset Chart', 
      icon: <BarChart2 className="w-4 h-4 text-blue-500" />,
      desc: 'Render high-resolution vector SVG chart from telemetry data.' 
    },
    { 
      type: 'document_text_extract', 
      label: 'Extract Document Text', 
      icon: <FileText className="w-4 h-4 text-orange-500" />,
      desc: 'Ingest text, calculate reading time, word count, and outline.' 
    },
    { 
      type: 'archive_pack', 
      label: 'Create Verified ZIP Archive', 
      icon: <Archive className="w-4 h-4 text-amber-500" />,
      desc: 'Pack files with path traversal security and cryptographic manifest.' 
    },
    { 
      type: 'checksum_verify', 
      label: 'Cryptographic SHA-256 Audit', 
      icon: <ShieldCheck className="w-4 h-4 text-emerald-600" />,
      desc: 'Verify file byte digest against FIPS 180-4 standard.' 
    },
  ];

  const handleStartTask = async () => {
    if (inputItems.length === 0) return;

    setIsExecuting(true);
    setProgress(10);
    setCurrentStep('Queued in worker pipeline');
    setErrorMsg(null);
    setResult(null);

    const initialLogs: JobLog[] = [
      { timestamp: new Date().toLocaleTimeString(), level: 'info', message: `Job submitted to ${workerTarget === 'local' ? 'This Mac (Sandbox)' : 'Remote FastAPI Worker'}` },
      { timestamp: new Date().toLocaleTimeString(), level: 'info', message: `Validated ${inputItems.length} input files.` },
    ];
    setLogs(initialLogs);

    try {
      // Step: Preparing
      await new Promise(r => setTimeout(r, 400));
      setProgress(35);
      setCurrentStep('Preparing input buffers & security sandbox');
      setLogs(prev => [...prev, { timestamp: new Date().toLocaleTimeString(), level: 'info', message: 'Verified path traversal bounds.' }]);

      // Step: Executing
      await new Promise(r => setTimeout(r, 400));
      setProgress(65);
      setCurrentStep(`Executing ${selectedTask}...`);

      let computeOutput: ComputeResult;
      const primaryItem = inputItems[0];

      if (selectedTask === 'image_resize_convert') {
        computeOutput = await executeImageResizeConvert(primaryItem, {
          maxWidth: imgWidth,
          maxHeight: imgHeight,
          format: imgFormat,
          quality: imgQuality,
          grayscale: imgGrayscale,
        });
      } else if (selectedTask === 'csv_summary_stats') {
        computeOutput = await executeCsvSummaryStats(primaryItem, { computeCorrelation: true });
      } else if (selectedTask === 'dataset_chart') {
        computeOutput = await executeDatasetChart(primaryItem, { chartType });
      } else if (selectedTask === 'document_text_extract') {
        computeOutput = await executeDocumentTextExtract(primaryItem, { includeHeaders: true });
      } else if (selectedTask === 'archive_pack') {
        computeOutput = await executeArchivePack(inputItems, { archiveName });
      } else {
        computeOutput = await executeChecksumVerify(primaryItem, { algorithm: 'SHA-256' });
      }

      setProgress(90);
      setCurrentStep('Publishing results to storage manifest');
      await new Promise(r => setTimeout(r, 300));

      setProgress(100);
      setCurrentStep('Completed successfully');
      setResult(computeOutput);
      setLiveMetrics(computeOutput.metrics);
      setLogs(prev => [
        ...prev,
        { timestamp: new Date().toLocaleTimeString(), level: 'success', message: computeOutput.summary },
        { timestamp: new Date().toLocaleTimeString(), level: 'success', message: `Generated ${computeOutput.outputFiles.length} output files.` }
      ]);

      // Record job in history
      const jobRecord: ComputeJob = {
        id: `job-${Date.now().toString(36)}`,
        taskType: selectedTask,
        taskTitle: availableTasks.find(t => t.type === selectedTask)?.label || selectedTask,
        status: 'completed',
        workerType: workerTarget,
        workerName: workerTarget === 'local' ? 'This Mac (Apple Silicon Sandbox)' : 'Remote Worker (FastAPI Container)',
        inputItemIds: inputItems.map(i => i.id),
        inputNames: inputItems.map(i => i.name),
        parameters: { selectedTask, workerTarget, imgWidth, imgHeight, imgFormat, chartType, archiveName },
        outputItemIds: computeOutput.outputFiles.map(o => o.id),
        outputSummary: computeOutput.summary,
        outputDetails: computeOutput.details,
        progress: 100,
        currentStep: 'Completed',
        logs: [...initialLogs, { timestamp: new Date().toLocaleTimeString(), level: 'success', message: computeOutput.summary }],
        metrics: computeOutput.metrics,
        submittedAt: new Date().toISOString(),
        completedAt: new Date().toISOString(),
      };
      onRecordJob(jobRecord);

    } catch (err: any) {
      setErrorMsg(err.message || 'Execution error');
      setProgress(100);
      setCurrentStep('Failed');
      setLogs(prev => [...prev, { timestamp: new Date().toLocaleTimeString(), level: 'error', message: err.message || 'Error occurred' }]);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleSaveToCloud = () => {
    if (result?.outputFiles) {
      onSaveOutputsToCloud(result.outputFiles);
      onClose();
    }
  };

  const handleExportDownload = () => {
    if (!result?.outputFiles || result.outputFiles.length === 0) return;
    const file = result.outputFiles[0];
    if (file.content) {
      const link = document.createElement('a');
      link.href = file.content;
      link.download = file.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-md select-none">
      <div className="w-full max-w-2xl max-h-[85vh] flex flex-col bg-[#f5f5f7]/95 dark:bg-[#1e1f23]/95 border border-black/[0.12] dark:border-white/[0.15] rounded-2xl shadow-2xl overflow-hidden backdrop-blur-2xl">
        {/* Header */}
        <div className="h-12 flex items-center justify-between px-4 border-b border-black/[0.08] dark:border-white/[0.08] bg-white/50 dark:bg-white/[0.03]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0071e3] inline-block" />
            <h2 className="text-xs font-semibold text-neutral-900 dark:text-white">
              Personal Compute Workspace
            </h2>
            <span className="text-[11px] text-neutral-400">
              · {inputItems.length} input file{inputItems.length > 1 ? 's' : ''}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
          {/* Inputs Bar */}
          <div className="p-3 bg-white/70 dark:bg-black/20 rounded-xl border border-black/[0.04] dark:border-white/[0.05]">
            <p className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-1.5">Input Targets</p>
            <div className="flex flex-wrap gap-1.5">
              {inputItems.map(item => (
                <span
                  key={item.id}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-black/[0.04] dark:bg-white/[0.06] rounded-md text-[11px] font-medium text-neutral-800 dark:text-neutral-200"
                >
                  <FileText className="w-3 h-3 text-[#0071e3]" />
                  <span>{item.name}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Task Selector */}
          <div>
            <p className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-2">Select Compute Task</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {availableTasks.map(task => {
                const isSelected = selectedTask === task.type;
                return (
                  <button
                    key={task.type}
                    type="button"
                    onClick={() => {
                      if (!isExecuting) setSelectedTask(task.type);
                    }}
                    disabled={isExecuting}
                    className={`flex items-start gap-2.5 p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-[#0071e3]/10 border-[#0071e3] shadow-xs'
                        : 'bg-white/60 dark:bg-black/20 border-black/[0.06] dark:border-white/[0.06] hover:bg-white/90'
                    }`}
                  >
                    <div className="p-1 rounded bg-black/[0.03] dark:bg-white/[0.06] shrink-0 mt-0.5">
                      {task.icon}
                    </div>
                    <div>
                      <p className={`font-semibold text-xs ${isSelected ? 'text-[#0071e3]' : 'text-neutral-800 dark:text-neutral-200'}`}>
                        {task.label}
                      </p>
                      <p className="text-[10px] text-neutral-400 mt-0.5 leading-snug">
                        {task.desc}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Worker Target Selector */}
          <div className="p-3 bg-white/70 dark:bg-black/20 rounded-xl border border-black/[0.04] dark:border-white/[0.05]">
            <p className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-2">Execution Target</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setWorkerTarget('local')}
                className={`p-2 rounded-lg border text-left flex items-center gap-2 transition-all ${
                  workerTarget === 'local'
                    ? 'border-[#0071e3] bg-[#0071e3]/10 text-neutral-900 dark:text-white font-medium'
                    : 'border-black/[0.06] dark:border-white/[0.06] text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <Cpu className="w-4 h-4 text-emerald-500" />
                <div>
                  <p className="text-xs font-semibold">This Mac Sandbox</p>
                  <p className="text-[10px] text-neutral-400">Local Apple Silicon GPU / WASM</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setWorkerTarget('remote')}
                className={`p-2 rounded-lg border text-left flex items-center gap-2 transition-all ${
                  workerTarget === 'remote'
                    ? 'border-[#0071e3] bg-[#0071e3]/10 text-neutral-900 dark:text-white font-medium'
                    : 'border-black/[0.06] dark:border-white/[0.06] text-neutral-600 dark:text-neutral-400'
                }`}
              >
                <Server className="w-4 h-4 text-blue-500" />
                <div>
                  <p className="text-xs font-semibold">Remote FastAPI Worker</p>
                  <p className="text-[10px] text-neutral-400">Isolated Containerized Daemon</p>
                </div>
              </button>
            </div>
          </div>

          {/* Task Parameters */}
          <div className="p-3 bg-white/70 dark:bg-black/20 rounded-xl border border-black/[0.04] dark:border-white/[0.05] space-y-2.5">
            <p className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">Parameters</p>
            {selectedTask === 'image_resize_convert' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1">Max Width</label>
                  <input
                    type="number"
                    value={imgWidth}
                    onChange={e => setImgWidth(parseInt(e.target.value) || 1200)}
                    className="w-full px-2 py-1 bg-black/[0.04] dark:bg-white/[0.06] rounded border border-transparent focus:border-[#0071e3] text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1">Max Height</label>
                  <input
                    type="number"
                    value={imgHeight}
                    onChange={e => setImgHeight(parseInt(e.target.value) || 800)}
                    className="w-full px-2 py-1 bg-black/[0.04] dark:bg-white/[0.06] rounded border border-transparent focus:border-[#0071e3] text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-neutral-400 block mb-1">Format</label>
                  <select
                    value={imgFormat}
                    onChange={e => setImgFormat(e.target.value as any)}
                    className="w-full px-2 py-1 bg-black/[0.04] dark:bg-white/[0.06] rounded border border-transparent focus:border-[#0071e3] text-xs"
                  >
                    <option value="webp">WebP (Efficient)</option>
                    <option value="jpeg">JPEG</option>
                    <option value="png">PNG (Lossless)</option>
                  </select>
                </div>
                <div className="flex items-end pb-1.5">
                  <label className="flex items-center gap-1.5 text-xs text-neutral-700 dark:text-neutral-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={imgGrayscale}
                      onChange={e => setImgGrayscale(e.target.checked)}
                      className="rounded accent-[#0071e3]"
                    />
                    <span>Grayscale B&W</span>
                  </label>
                </div>
              </div>
            )}

            {selectedTask === 'dataset_chart' && (
              <div className="flex items-center gap-3">
                <label className="text-xs text-neutral-600 dark:text-neutral-300">Chart Type:</label>
                {(['bar', 'line', 'area'] as const).map(t => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setChartType(t)}
                    className={`px-2.5 py-1 rounded text-xs capitalize ${
                      chartType === t ? 'bg-[#0071e3] text-white font-medium' : 'bg-black/[0.04] dark:bg-white/[0.06]'
                    }`}
                  >
                    {t} Chart
                  </button>
                ))}
              </div>
            )}

            {selectedTask === 'archive_pack' && (
              <div>
                <label className="text-[10px] text-neutral-400 block mb-1">Archive Name</label>
                <input
                  type="text"
                  value={archiveName}
                  onChange={e => setArchiveName(e.target.value)}
                  className="w-full px-2 py-1 bg-black/[0.04] dark:bg-white/[0.06] rounded border border-transparent focus:border-[#0071e3] text-xs font-mono"
                />
              </div>
            )}

            {(selectedTask === 'csv_summary_stats' || selectedTask === 'document_text_extract' || selectedTask === 'checksum_verify') && (
              <p className="text-[11px] text-neutral-500">
                Automatic heuristic profiling enabled. Bounded memory limit: 2048 MB.
              </p>
            )}
          </div>

          {/* Live Progress & Terminal Logs */}
          {(isExecuting || logs.length > 0) && (
            <div className="p-3 bg-neutral-900 rounded-xl text-neutral-200 font-mono text-[11px] space-y-2 border border-neutral-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Terminal className="w-3.5 h-3.5 text-[#38bdf8]" />
                  <span className="font-semibold text-neutral-300">Live Worker Log</span>
                </div>
                <span className="text-[10px] text-neutral-400">{currentStep}</span>
              </div>

              {/* Progress bar */}
              <div className="w-full h-1 bg-neutral-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#0071e3] transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>

              {/* Log messages */}
              <div className="max-h-24 overflow-y-auto space-y-0.5 text-[10px] text-neutral-400 pt-1">
                {logs.map((l, i) => (
                  <div key={i} className="flex gap-2">
                    <span className="text-neutral-500">[{l.timestamp}]</span>
                    <span className={l.level === 'error' ? 'text-red-400' : l.level === 'success' ? 'text-emerald-400' : 'text-neutral-300'}>
                      {l.message}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Result Card */}
          {result && (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Execution Complete</span>
                </div>
                <div className="flex items-center gap-3 text-[10px] text-neutral-500 font-mono">
                  <span>Wall clock: {liveMetrics.wallClockMs}ms</span>
                  <span>CPU: {liveMetrics.cpuPercent}%</span>
                  <span>RAM: {liveMetrics.memoryMb} MB</span>
                </div>
              </div>

              <p className="text-xs text-neutral-700 dark:text-neutral-300">
                {result.summary}
              </p>

              {/* Preview image if image or chart generated */}
              {result.outputFiles[0]?.content && result.outputFiles[0].kind === 'image' && (
                <div className="w-full h-36 bg-black/5 dark:bg-black/30 rounded-lg overflow-hidden flex items-center justify-center p-2">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={result.outputFiles[0].content}
                    alt="Output Preview"
                    className="max-h-full max-w-full object-contain rounded"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleExportDownload}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/[0.05] dark:bg-white/[0.08] text-neutral-800 dark:text-neutral-200 font-medium hover:bg-black/[0.08] transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export to Finder</span>
                </button>
                <button
                  type="button"
                  onClick={handleSaveToCloud}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0071e3] text-white font-medium hover:bg-[#0077ed] transition-colors shadow-xs"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                  <span>Save to iCloud Drive</span>
                </button>
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-2 text-red-600 dark:text-red-400 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="h-13 px-4 border-t border-black/[0.08] dark:border-white/[0.08] flex items-center justify-between bg-white/50 dark:bg-white/[0.02]">
          <span className="text-[11px] text-neutral-400">
            {workerTarget === 'local' ? 'Sandboxed on This Mac' : 'Submits to verified remote node'}
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isExecuting}
              className="px-3 py-1.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-black/[0.05] dark:hover:bg-white/[0.08] transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleStartTask}
              disabled={isExecuting || inputItems.length === 0}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#0071e3] text-white font-medium hover:bg-[#0077ed] disabled:opacity-50 transition-all shadow-xs"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isExecuting ? 'Processing...' : 'Run Compute Task'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
