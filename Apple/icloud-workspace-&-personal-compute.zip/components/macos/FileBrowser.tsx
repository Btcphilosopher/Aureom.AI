'use client';

import React, { useState } from 'react';
import { 
  Folder, 
  FileText, 
  Image as ImageIcon, 
  Table, 
  Archive, 
  Code, 
  FileCheck, 
  AlertTriangle, 
  Cloud, 
  CloudOff, 
  HardDrive, 
  Star, 
  MoreHorizontal,
  ChevronRight,
  ArrowUpDown,
  UploadCloud,
  Play,
  Eye,
  Trash2,
  RefreshCw
} from 'lucide-react';
import { ICloudItem, ViewMode, SortField, SortOrder, FileKind, TagColor } from '@/lib/types';
import { formatDeterministicDate } from '@/lib/utils';

interface FileBrowserProps {
  items: ICloudItem[];
  currentFolderId: string | null;
  folderPath: { id: string | null; name: string }[];
  onNavigateToFolder: (folderId: string | null) => void;
  selectedIds: string[];
  onToggleSelect: (id: string, isMulti: boolean) => void;
  onSelectAll: () => void;
  onClearSelection: () => void;
  viewMode: ViewMode;
  onOpenQuickLook: (item: ICloudItem) => void;
  onRunTaskOnItem: (item: ICloudItem) => void;
  onToggleFavorite: (id: string) => void;
  onToggleOffline: (id: string) => void;
  onDeleteToTrash: (id: string) => void;
  onDropFilesOnFolder: (files: FileList | ICloudItem[], targetFolderId: string) => void;
  onDropFilesOnBrowser: (files: FileList) => void;
  onResolveConflict: (item: ICloudItem) => void;
}

export const FileBrowser: React.FC<FileBrowserProps> = ({
  items,
  currentFolderId,
  folderPath,
  onNavigateToFolder,
  selectedIds,
  onToggleSelect,
  viewMode,
  onOpenQuickLook,
  onRunTaskOnItem,
  onToggleFavorite,
  onToggleOffline,
  onDeleteToTrash,
  onDropFilesOnFolder,
  onDropFilesOnBrowser,
  onResolveConflict,
}) => {
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [kindFilter, setKindFilter] = useState<FileKind | 'all'>('all');
  const [isDragOverBrowser, setIsDragOverBrowser] = useState(false);
  const [dragOverFolderId, setDragOverFolderId] = useState<string | null>(null);

  // Filter items in current directory
  const currentItems = items.filter(i => !i.inTrash && i.parentId === currentFolderId);

  // Apply kind filter
  const filteredItems = currentItems.filter(i => {
    if (kindFilter === 'all') return true;
    return i.kind === kindFilter;
  });

  // Apply sorting (Folders first by default)
  const sortedItems = [...filteredItems].sort((a, b) => {
    if (a.kind === 'folder' && b.kind !== 'folder') return -1;
    if (a.kind !== 'folder' && b.kind === 'folder') return 1;

    let comp = 0;
    if (sortField === 'name') comp = a.name.localeCompare(b.name);
    else if (sortField === 'size') comp = a.size - b.size;
    else if (sortField === 'modifiedAt') comp = new Date(a.modifiedAt).getTime() - new Date(b.modifiedAt).getTime();
    else if (sortField === 'kind') comp = a.kind.localeCompare(b.kind);

    return sortOrder === 'asc' ? comp : -comp;
  });

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '—';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatDate = (iso: string) => {
    return formatDeterministicDate(iso);
  };

  const getTagColorClass = (tag: TagColor) => {
    switch (tag) {
      case 'red': return 'bg-red-500';
      case 'orange': return 'bg-amber-500';
      case 'yellow': return 'bg-yellow-400';
      case 'green': return 'bg-emerald-500';
      case 'blue': return 'bg-[#0071e3]';
      case 'purple': return 'bg-purple-500';
      case 'gray': return 'bg-neutral-400';
      default: return 'bg-neutral-400';
    }
  };

  const renderIcon = (item: ICloudItem, size = 'md') => {
    const isLg = size === 'lg';
    const iconClass = isLg ? 'w-10 h-10' : 'w-5 h-5';

    if (item.kind === 'folder') {
      return (
        <div className={`relative flex items-center justify-center ${isLg ? 'w-14 h-14' : 'w-7 h-7'}`}>
          <Folder className={`${iconClass} text-[#0071e3] fill-[#0071e3]/20`} />
        </div>
      );
    }

    if (item.kind === 'image' && item.content) {
      return (
        <div className={`overflow-hidden rounded-md border border-black/[0.08] dark:border-white/[0.1] bg-black/5 dark:bg-white/5 flex items-center justify-center ${isLg ? 'w-14 h-14' : 'w-7 h-7'}`}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={item.content}
            alt={item.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      );
    }

    switch (item.kind) {
      case 'image':
        return <ImageIcon className={`${iconClass} text-purple-500`} />;
      case 'dataset':
        return <Table className={`${iconClass} text-emerald-600`} />;
      case 'archive':
        return <Archive className={`${iconClass} text-amber-600`} />;
      case 'code':
        return <Code className={`${iconClass} text-blue-500`} />;
      case 'document':
      default:
        return <FileText className={`${iconClass} text-neutral-600 dark:text-neutral-300`} />;
    }
  };

  const renderStatusBadge = (item: ICloudItem) => {
    switch (item.status) {
      case 'local':
        return (
          <span title="Downloaded on This Mac" className="flex items-center text-emerald-600 dark:text-emerald-400">
            <HardDrive className="w-3.5 h-3.5" />
          </span>
        );
      case 'cloud':
        return (
          <span title="Stored safely on iCloud (click to download)" className="flex items-center text-neutral-400">
            <Cloud className="w-3.5 h-3.5" />
          </span>
        );
      case 'uploading':
      case 'syncing':
        return (
          <span title="Synchronising with iCloud" className="flex items-center text-[#0071e3] animate-spin">
            <RefreshCw className="w-3 h-3" />
          </span>
        );
      case 'conflict':
        return (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onResolveConflict(item);
            }}
            title="Synchronisation conflict! Click to resolve."
            className="flex items-center gap-1 text-amber-600 dark:text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded text-[10px] font-semibold hover:bg-amber-500/20"
          >
            <AlertTriangle className="w-3 h-3" />
            <span>Conflict</span>
          </button>
        );
      default:
        return null;
    }
  };

  // Browser Drag and Drop Handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOverBrowser(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOverBrowser(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOverBrowser(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onDropFilesOnBrowser(e.dataTransfer.files);
    }
  };

  return (
    <div 
      className={`flex-1 flex flex-col h-full overflow-hidden bg-white/50 dark:bg-[#1a1b1e]/50 select-none relative ${
        isDragOverBrowser ? 'ring-2 ring-[#0071e3] ring-inset bg-[#0071e3]/5' : ''
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Drop overlay message */}
      {isDragOverBrowser && (
        <div className="absolute inset-0 bg-[#0071e3]/10 backdrop-blur-xs z-30 flex flex-col items-center justify-center pointer-events-none">
          <UploadCloud className="w-12 h-12 text-[#0071e3] animate-bounce mb-2" />
          <p className="text-sm font-semibold text-[#0071e3]">Drop files to store in {folderPath[folderPath.length - 1]?.name || 'iCloud Drive'}</p>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">Copies originals securely with SHA-256 verification</p>
        </div>
      )}

      {/* Subheader: Breadcrumb Path & Kind Filter Pills */}
      <div className="px-4 py-2 border-b border-black/[0.06] dark:border-white/[0.06] flex items-center justify-between gap-4 text-xs bg-white/30 dark:bg-white/[0.02]">
        {/* Breadcrumb Path */}
        <div className="flex items-center gap-1.5 overflow-x-auto whitespace-nowrap text-neutral-600 dark:text-neutral-400">
          {folderPath.map((crumb, idx) => {
            const isLast = idx === folderPath.length - 1;
            return (
              <React.Fragment key={crumb.id || 'root'}>
                <button
                  type="button"
                  onClick={() => onNavigateToFolder(crumb.id)}
                  className={`hover:text-[#0071e3] transition-colors font-medium ${
                    isLast ? 'text-neutral-900 dark:text-white font-semibold' : ''
                  }`}
                >
                  {crumb.name}
                </button>
                {!isLast && <ChevronRight className="w-3.5 h-3.5 text-neutral-400 shrink-0" />}
              </React.Fragment>
            );
          })}
        </div>

        {/* Kind Filters */}
        <div className="flex items-center gap-1 p-0.5 bg-black/[0.04] dark:bg-white/[0.06] rounded-md shrink-0">
          {(['all', 'folder', 'image', 'document', 'dataset', 'archive'] as const).map(k => (
            <button
              key={k}
              type="button"
              onClick={() => setKindFilter(k)}
              className={`px-2 py-0.5 text-[11px] rounded capitalize transition-all ${
                kindFilter === k
                  ? 'bg-white dark:bg-[#2b2c32] text-neutral-900 dark:text-white shadow-xs font-semibold'
                  : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200'
              }`}
            >
              {k === 'all' ? 'All Items' : `${k}s`}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Area: Grid or List */}
      <div className="flex-1 overflow-y-auto p-4">
        {sortedItems.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8 text-neutral-400">
            <Folder className="w-16 h-16 text-neutral-300 dark:text-neutral-600 stroke-[1.2] mb-3" />
            <h3 className="text-sm font-semibold text-neutral-700 dark:text-neutral-300 mb-1">
              {kindFilter === 'all' ? 'This Folder is Empty' : `No ${kindFilter}s Found`}
            </h3>
            <p className="text-xs text-neutral-500 max-w-xs mb-4">
              Drag and drop files from Finder, click the upload button in the toolbar, or create a new folder.
            </p>
          </div>
        ) : viewMode === 'grid' ? (
          /* Grid View */
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
            {sortedItems.map(item => {
              const isSelected = selectedIds.includes(item.id);
              const isDragTarget = dragOverFolderId === item.id;

              return (
                <div
                  key={item.id}
                  onClick={(e) => onToggleSelect(item.id, e.metaKey || e.shiftKey || e.ctrlKey)}
                  onDoubleClick={() => {
                    if (item.kind === 'folder') {
                      onNavigateToFolder(item.id);
                    } else {
                      onOpenQuickLook(item);
                    }
                  }}
                  onDragOver={(e) => {
                    if (item.kind === 'folder') {
                      e.preventDefault();
                      e.stopPropagation();
                      setDragOverFolderId(item.id);
                    }
                  }}
                  onDragLeave={() => setDragOverFolderId(null)}
                  onDrop={(e) => {
                    if (item.kind === 'folder') {
                      e.preventDefault();
                      e.stopPropagation();
                      setDragOverFolderId(null);
                      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                        onDropFilesOnFolder(e.dataTransfer.files, item.id);
                      }
                    }
                  }}
                  className={`group relative flex flex-col items-center p-3 rounded-xl border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#0071e3]/10 border-[#0071e3] shadow-xs'
                      : isDragTarget
                      ? 'bg-[#0071e3]/20 border-[#0071e3] scale-105'
                      : 'border-transparent hover:bg-black/[0.03] dark:hover:bg-white/[0.04]'
                  }`}
                >
                  {/* Status badge in top right */}
                  <div className="absolute top-2 right-2 flex items-center gap-1 z-10">
                    {renderStatusBadge(item)}
                    {item.isFavorite && <Star className="w-3 h-3 text-amber-500 fill-amber-500" />}
                  </div>

                  {/* Icon or Thumbnail */}
                  <div className="mb-2 transition-transform group-hover:scale-105">
                    {renderIcon(item, 'lg')}
                  </div>

                  {/* Name */}
                  <span 
                    className="w-full text-xs font-medium text-neutral-800 dark:text-neutral-200 truncate px-1"
                    title={item.name}
                  >
                    {item.name}
                  </span>

                  {/* Subtitle / Size */}
                  <div className="flex items-center gap-1 text-[10px] text-neutral-400 mt-0.5">
                    <span>{item.kind === 'folder' ? 'Folder' : formatSize(item.size)}</span>
                  </div>

                  {/* Tag dots */}
                  {item.tags.length > 0 && (
                    <div className="flex items-center gap-1 mt-1.5">
                      {item.tags.map(tag => (
                        <span key={tag} className={`w-1.5 h-1.5 rounded-full ${getTagColorClass(tag)}`} />
                      ))}
                    </div>
                  )}

                  {/* Hover Quick Actions */}
                  <div className="absolute bottom-1 right-1 opacity-0 group-hover:opacity-100 flex items-center gap-1 bg-white/90 dark:bg-[#25262b]/95 rounded-md p-0.5 shadow-xs transition-opacity z-10">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenQuickLook(item);
                      }}
                      className="p-1 text-neutral-600 dark:text-neutral-300 hover:text-[#0071e3]"
                      title="Quick Look (Spacebar)"
                    >
                      <Eye className="w-3 h-3" />
                    </button>
                    {item.kind !== 'folder' && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRunTaskOnItem(item);
                        }}
                        className="p-1 text-neutral-600 dark:text-neutral-300 hover:text-[#0071e3]"
                        title="Run Compute Task..."
                      >
                        <Play className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* List Table View */
          <div className="border border-black/[0.08] dark:border-white/[0.08] rounded-lg overflow-hidden bg-white/70 dark:bg-[#1e1f23]/70">
            <table className="w-full text-left text-xs">
              <thead className="bg-black/[0.03] dark:bg-white/[0.04] border-b border-black/[0.06] dark:border-white/[0.06] text-neutral-500 font-semibold">
                <tr>
                  <th 
                    onClick={() => handleSort('name')}
                    className="py-2 px-3 cursor-pointer hover:text-neutral-900 dark:hover:text-white select-none"
                  >
                    <div className="flex items-center gap-1">
                      <span>Name</span>
                      {sortField === 'name' && <ArrowUpDown className="w-3 h-3" />}
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('modifiedAt')}
                    className="py-2 px-3 cursor-pointer hover:text-neutral-900 dark:hover:text-white select-none w-36"
                  >
                    <div className="flex items-center gap-1">
                      <span>Date Modified</span>
                      {sortField === 'modifiedAt' && <ArrowUpDown className="w-3 h-3" />}
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('size')}
                    className="py-2 px-3 cursor-pointer hover:text-neutral-900 dark:hover:text-white select-none w-24 text-right"
                  >
                    <div className="flex items-center justify-end gap-1">
                      <span>Size</span>
                      {sortField === 'size' && <ArrowUpDown className="w-3 h-3" />}
                    </div>
                  </th>
                  <th 
                    onClick={() => handleSort('kind')}
                    className="py-2 px-3 cursor-pointer hover:text-neutral-900 dark:hover:text-white select-none w-24"
                  >
                    <div className="flex items-center gap-1">
                      <span>Kind</span>
                      {sortField === 'kind' && <ArrowUpDown className="w-3 h-3" />}
                    </div>
                  </th>
                  <th className="py-2 px-3 w-28 text-center">Status</th>
                  <th className="py-2 px-3 w-16 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-black/[0.04] dark:divide-white/[0.04]">
                {sortedItems.map(item => {
                  const isSelected = selectedIds.includes(item.id);
                  return (
                    <tr
                      key={item.id}
                      onClick={(e) => onToggleSelect(item.id, e.metaKey || e.shiftKey || e.ctrlKey)}
                      onDoubleClick={() => {
                        if (item.kind === 'folder') onNavigateToFolder(item.id);
                        else onOpenQuickLook(item);
                      }}
                      className={`group transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-[#0071e3]/15 text-[#0071e3]'
                          : 'hover:bg-black/[0.02] dark:hover:bg-white/[0.03]'
                      }`}
                    >
                      <td className="py-2 px-3">
                        <div className="flex items-center gap-2.5">
                          {renderIcon(item, 'sm')}
                          <span className="font-medium text-neutral-800 dark:text-neutral-200 truncate max-w-xs md:max-w-md">
                            {item.name}
                          </span>
                          {item.tags.length > 0 && (
                            <div className="flex items-center gap-1 ml-1">
                              {item.tags.map(tag => (
                                <span key={tag} className={`w-1.5 h-1.5 rounded-full ${getTagColorClass(tag)}`} />
                              ))}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="py-2 px-3 text-neutral-500 tabular-nums">
                        {formatDate(item.modifiedAt)}
                      </td>
                      <td className="py-2 px-3 text-right text-neutral-500 font-mono tabular-nums">
                        {formatSize(item.size)}
                      </td>
                      <td className="py-2 px-3 text-neutral-500 capitalize">
                        {item.kind}
                      </td>
                      <td className="py-2 px-3 text-center">
                        <div className="flex items-center justify-center">
                          {renderStatusBadge(item)}
                        </div>
                      </td>
                      <td className="py-2 px-3 text-right">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onOpenQuickLook(item);
                            }}
                            className="p-1 hover:text-[#0071e3]"
                            title="Quick Look"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {item.kind !== 'folder' && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onRunTaskOnItem(item);
                              }}
                              className="p-1 hover:text-[#0071e3]"
                              title="Run Task"
                            >
                              <Play className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteToTrash(item.id);
                            }}
                            className="p-1 hover:text-red-500"
                            title="Move to Trash"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Footer Status Bar: Item Count & Selection Summary */}
      <div className="px-4 py-1.5 border-t border-black/[0.06] dark:border-white/[0.06] flex items-center justify-between text-[11px] text-neutral-500 dark:text-neutral-400 bg-white/40 dark:bg-black/20">
        <span>{sortedItems.length} items</span>
        {selectedIds.length > 0 && (
          <span className="font-medium text-[#0071e3]">
            {selectedIds.length} item{selectedIds.length > 1 ? 's' : ''} selected
          </span>
        )}
      </div>
    </div>
  );
};
