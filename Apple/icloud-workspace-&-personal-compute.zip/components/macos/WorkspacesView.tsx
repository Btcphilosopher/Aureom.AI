'use client';

import React, { useState } from 'react';
import { 
  Layers, 
  Plus, 
  Play, 
  FileText, 
  Cpu, 
  Server, 
  Folder, 
  ArrowRight, 
  CheckCircle2,
  Workflow,
  Sparkles
} from 'lucide-react';
import { Workspace, ICloudItem, TaskRecipe } from '@/lib/types';

interface WorkspacesViewProps {
  workspaces: Workspace[];
  recipes: TaskRecipe[];
  allItems: ICloudItem[];
  onCreateWorkspace: (name: string, description: string, color: string) => void;
  onRunRecipe: (recipe: TaskRecipe, workspace: Workspace) => void;
  onOpenItem: (item: ICloudItem) => void;
}

export const WorkspacesView: React.FC<WorkspacesViewProps> = ({
  workspaces,
  recipes,
  allItems,
  onCreateWorkspace,
  onRunRecipe,
  onOpenItem,
}) => {
  const [selectedWsId, setSelectedWsId] = useState<string>(workspaces[0]?.id || '');
  const [isCreatingWs, setIsCreatingWs] = useState(false);
  const [newWsName, setNewWsName] = useState('');
  const [newWsDesc, setNewWsDesc] = useState('');
  const [newWsColor, setNewWsColor] = useState('#0071e3');

  const activeWorkspace = workspaces.find(w => w.id === selectedWsId) || workspaces[0];

  const handleCreate = () => {
    if (newWsName.trim()) {
      onCreateWorkspace(newWsName.trim(), newWsDesc.trim(), newWsColor);
      setNewWsName('');
      setNewWsDesc('');
      setIsCreatingWs(false);
    }
  };

  const wsItems = allItems.filter(i => activeWorkspace?.itemIds.includes(i.id));

  return (
    <div className="flex-1 flex h-full overflow-hidden bg-white/50 dark:bg-[#1a1b1e]/50 select-none">
      {/* Workspace Sub-sidebar */}
      <div className="w-64 border-r border-black/[0.08] dark:border-white/[0.08] p-3 flex flex-col justify-between bg-black/[0.02] dark:bg-white/[0.02]">
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">Project Workspaces</span>
            <button
              type="button"
              onClick={() => setIsCreatingWs(true)}
              className="p-1 rounded text-[#0071e3] hover:bg-[#0071e3]/10"
              title="Create Workspace"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-1">
            {workspaces.map(ws => {
              const isSelected = ws.id === selectedWsId;
              return (
                <button
                  key={ws.id}
                  type="button"
                  onClick={() => setSelectedWsId(ws.id)}
                  className={`w-full flex items-center justify-between p-2 rounded-xl text-left transition-all ${
                    isSelected
                      ? 'bg-white dark:bg-[#28292e] shadow-xs border border-black/[0.06] dark:border-white/[0.08]'
                      : 'hover:bg-black/[0.03] dark:hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: ws.color }} />
                    <div className="truncate">
                      <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 truncate block">{ws.name}</span>
                      <span className="text-[10px] text-neutral-400 truncate block">{ws.itemIds.length} files</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Recipe Quick Launch */}
        <div className="p-3 bg-white/70 dark:bg-black/20 rounded-xl border border-black/[0.04] dark:border-white/[0.06] space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-300">
            <Workflow className="w-3.5 h-3.5 text-[#8e44ad]" />
            <span>Task Recipes</span>
          </div>
          <p className="text-[10px] text-neutral-400">Reusable multi-step task graphs for automated processing.</p>
        </div>
      </div>

      {/* Main Workspace Details View */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {activeWorkspace ? (
          <>
            {/* Header Banner */}
            <div className="p-5 rounded-2xl bg-white/80 dark:bg-[#202126]/80 border border-black/[0.06] dark:border-white/[0.08] shadow-xs flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2.5">
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: activeWorkspace.color }} />
                  <h1 className="text-lg font-bold text-neutral-900 dark:text-white">
                    {activeWorkspace.name}
                  </h1>
                </div>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xl">
                  {activeWorkspace.description}
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/[0.04] dark:bg-white/[0.06] text-neutral-600 dark:text-neutral-300">
                  {activeWorkspace.linkedWorker === 'local' ? (
                    <>
                      <Cpu className="w-3 h-3 text-emerald-500" />
                      <span>This Mac</span>
                    </>
                  ) : (
                    <>
                      <Server className="w-3 h-3 text-blue-500" />
                      <span>Remote Worker</span>
                    </>
                  )}
                </span>
              </div>
            </div>

            {/* Reusable Recipes Grid */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                  Associated Task Recipes
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {recipes.map(recipe => (
                  <div
                    key={recipe.id}
                    className="p-4 rounded-xl bg-white/70 dark:bg-[#202126]/70 border border-black/[0.06] dark:border-white/[0.08] flex flex-col justify-between space-y-3 hover:border-[#0071e3]/40 transition-all"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <Workflow className="w-4 h-4 text-[#0071e3]" />
                        <h3 className="text-xs font-semibold text-neutral-800 dark:text-neutral-100">{recipe.name}</h3>
                      </div>
                      <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1">
                        {recipe.description}
                      </p>
                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                        {recipe.steps.map((st, i) => (
                          <React.Fragment key={st.stepId}>
                            <span className="px-2 py-0.5 rounded bg-black/[0.04] dark:bg-white/[0.06] text-[10px] text-neutral-600 dark:text-neutral-300 font-medium">
                              {st.name}
                            </span>
                            {i < recipe.steps.length - 1 && (
                              <ArrowRight className="w-3 h-3 text-neutral-400" />
                            )}
                          </React.Fragment>
                        ))}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onRunRecipe(recipe, activeWorkspace)}
                      className="flex items-center justify-center gap-1.5 py-1.5 px-3 bg-[#0071e3] text-white rounded-lg text-xs font-medium hover:bg-[#0077ed] transition-colors"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Run Recipe Pipeline</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Associated Workspace Files */}
            <div className="space-y-3">
              <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                Source Files & Outputs ({wsItems.length})
              </h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {wsItems.map(item => (
                  <div
                    key={item.id}
                    onClick={() => onOpenItem(item)}
                    className="p-3 bg-white/70 dark:bg-[#202126]/70 rounded-xl border border-black/[0.06] dark:border-white/[0.08] hover:border-[#0071e3] transition-all cursor-pointer flex flex-col items-center text-center"
                  >
                    <FileText className="w-8 h-8 text-[#0071e3] mb-2" />
                    <span className="text-xs font-medium text-neutral-800 dark:text-neutral-200 truncate w-full">{item.name}</span>
                    <span className="text-[10px] text-neutral-400 mt-0.5">{(item.size / 1024).toFixed(1)} KB</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Notes Section */}
            <div className="p-4 rounded-xl bg-white/70 dark:bg-[#202126]/70 border border-black/[0.06] dark:border-white/[0.08] space-y-2">
              <h2 className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
                Project Notes & Invariants
              </h2>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed font-sans">
                {activeWorkspace.notes}
              </p>
            </div>
          </>
        ) : (
          <div className="text-center py-12 text-neutral-400">No workspace selected</div>
        )}
      </div>

      {/* Create Workspace Modal */}
      {isCreatingWs && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
          <div className="w-full max-w-md p-5 bg-[#f5f5f7] dark:bg-[#202126] rounded-2xl shadow-xl border border-black/[0.1] dark:border-white/[0.1] space-y-4">
            <h3 className="text-sm font-bold text-neutral-900 dark:text-white">Create Project Workspace</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="text-neutral-500 block mb-1">Workspace Name</label>
                <input
                  type="text"
                  value={newWsName}
                  onChange={e => setNewWsName(e.target.value)}
                  placeholder="e.g. Q4 Data Pipeline"
                  className="w-full px-3 py-1.5 rounded-lg border border-black/[0.1] dark:border-white/[0.1] bg-white dark:bg-black/30"
                />
              </div>
              <div>
                <label className="text-neutral-500 block mb-1">Description</label>
                <textarea
                  value={newWsDesc}
                  onChange={e => setNewWsDesc(e.target.value)}
                  placeholder="Goals, target datasets, and outputs..."
                  rows={3}
                  className="w-full px-3 py-1.5 rounded-lg border border-black/[0.1] dark:border-white/[0.1] bg-white dark:bg-black/30"
                />
              </div>
              <div>
                <label className="text-neutral-500 block mb-1">Color Marker</label>
                <div className="flex gap-2">
                  {['#0071e3', '#8e44ad', '#27ae60', '#e67e22', '#e74c3c'].map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewWsColor(c)}
                      className={`w-6 h-6 rounded-full transition-transform ${newWsColor === c ? 'ring-2 ring-offset-2 ring-neutral-400 scale-110' : ''}`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsCreatingWs(false)}
                className="px-3 py-1.5 text-xs text-neutral-600 dark:text-neutral-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleCreate}
                disabled={!newWsName.trim()}
                className="px-4 py-1.5 text-xs font-semibold bg-[#0071e3] text-white rounded-lg disabled:opacity-50"
              >
                Create Workspace
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
