'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  ICloudItem, 
  Workspace, 
  ComputeJob, 
  TaskRecipe, 
  ActivityEvent, 
  NavigationDestination, 
  ViewMode, 
  DeviceMode,
  TagColor 
} from '@/lib/types';
import { 
  initialFiles, 
  initialWorkspaces, 
  initialRecipes, 
  initialJobs, 
  initialActivities 
} from '@/lib/sampleData';
import { Toolbar } from '@/components/macos/Toolbar';
import { Sidebar } from '@/components/macos/Sidebar';
import { FileBrowser } from '@/components/macos/FileBrowser';
import { Inspector } from '@/components/macos/Inspector';
import { QuickLookModal } from '@/components/macos/QuickLookModal';
import { TaskRunnerModal } from '@/components/macos/TaskRunnerModal';
import { ConflictModal } from '@/components/macos/ConflictModal';
import { HomeView } from '@/components/macos/HomeView';
import { WorkspacesView } from '@/components/macos/WorkspacesView';
import { ComputeDashboardView } from '@/components/macos/ComputeDashboardView';
import { ActivityView } from '@/components/macos/ActivityView';
import { SharedView } from '@/components/macos/SharedView';
import { TrashView } from '@/components/macos/TrashView';
import { SettingsView } from '@/components/macos/SettingsView';
import { IpadCompanion } from '@/components/companions/IpadCompanion';
import { IphoneCompanion } from '@/components/companions/IphoneCompanion';
import { CodeDeliverablesModal } from '@/components/code/CodeDeliverablesModal';
import { calculateSha256 } from '@/lib/computeEngine';

export default function ICloudApp() {
  // Primary collections state
  const [files, setFiles] = useState<ICloudItem[]>(initialFiles);
  const [workspaces, setWorkspaces] = useState<Workspace[]>(initialWorkspaces);
  const [recipes] = useState<TaskRecipe[]>(initialRecipes);
  const [jobs, setJobs] = useState<ComputeJob[]>(initialJobs);
  const [activities, setActivities] = useState<ActivityEvent[]>(initialActivities);

  // Navigation & View state
  const [destination, setDestination] = useState<NavigationDestination>('home');
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [folderHistory, setFolderHistory] = useState<(string | null)[]>([null]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('mac');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);
  const [isInspectorOpen, setIsInspectorOpen] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals state
  const [quickLookItem, setQuickLookItem] = useState<ICloudItem | null>(null);
  const [taskModalItems, setTaskModalItems] = useState<ICloudItem[] | null>(null);
  const [conflictModalItem, setConflictModalItem] = useState<ICloudItem | null>(null);
  const [codeModalOpen, setCodeModalOpen] = useState<boolean>(false);

  // Synchronise dark mode with <html> tag
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Folder Breadcrumb calculation
  const folderPath = useMemo(() => {
    const crumbs: { id: string | null; name: string }[] = [{ id: null, name: 'iCloud Drive' }];
    if (!currentFolderId) return crumbs;

    const findFolderParents = (fId: string) => {
      const folder = files.find(f => f.id === fId);
      if (!folder) return;
      if (folder.parentId) findFolderParents(folder.parentId);
      crumbs.push({ id: folder.id, name: folder.name });
    };

    findFolderParents(currentFolderId);
    return crumbs;
  }, [currentFolderId, files]);

  // Navigate folder with history tracking
  const handleNavigateToFolder = useCallback((folderId: string | null) => {
    setCurrentFolderId(folderId);
    setSelectedIds([]);
    setFolderHistory(prev => {
      const updated = prev.slice(0, historyIndex + 1);
      return [...updated, folderId];
    });
    setHistoryIndex(prev => prev + 1);
  }, [historyIndex]);

  const handleGoBack = useCallback(() => {
    if (historyIndex > 0) {
      const newIdx = historyIndex - 1;
      setHistoryIndex(newIdx);
      setCurrentFolderId(folderHistory[newIdx]);
      setSelectedIds([]);
    }
  }, [historyIndex, folderHistory]);

  const handleGoForward = useCallback(() => {
    if (historyIndex < folderHistory.length - 1) {
      const newIdx = historyIndex + 1;
      setHistoryIndex(newIdx);
      setCurrentFolderId(folderHistory[newIdx]);
      setSelectedIds([]);
    }
  }, [historyIndex, folderHistory]);

  // Storage calculations
  const storageUsedBytes = useMemo(() => {
    return files.filter(f => !f.inTrash).reduce((sum, item) => sum + item.size, 0) + 18400000000;
  }, [files]);
  const storageMaxBytes = 50 * 1024 * 1024 * 1024; // 50 GB

  // Selected items objects
  const selectedItems = useMemo(() => {
    return files.filter(f => selectedIds.includes(f.id));
  }, [files, selectedIds]);

  const handleBatchDeleteToTrash = useCallback((ids: string[]) => {
    setFiles(prev => prev.map(f => ids.includes(f.id) ? { ...f, inTrash: true, deletedAt: new Date().toISOString() } : f));
    setSelectedIds([]);
  }, []);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      // Spacebar: Quick Look
      if (e.key === ' ' && selectedIds.length > 0) {
        e.preventDefault();
        const itemToPreview = files.find(f => f.id === selectedIds[0]);
        if (itemToPreview) setQuickLookItem(itemToPreview);
      }

      // Cmd+A: Select All
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        const currentVisible = files.filter(f => !f.inTrash && f.parentId === currentFolderId);
        setSelectedIds(currentVisible.map(f => f.id));
      }

      // Cmd+I: Toggle Inspector
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'i') {
        e.preventDefault();
        setIsInspectorOpen(prev => !prev);
      }

      // Cmd+S: Toggle Sidebar
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        setIsSidebarOpen(prev => !prev);
      }

      // Cmd+R: Run Task
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'r' && selectedIds.length > 0) {
        e.preventDefault();
        const items = files.filter(f => selectedIds.includes(f.id));
        setTaskModalItems(items);
      }

      // Delete / Cmd+Backspace: Move to Trash
      if (e.key === 'Backspace' && (e.metaKey || e.ctrlKey) && selectedIds.length > 0) {
        e.preventDefault();
        handleBatchDeleteToTrash(selectedIds);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedIds, files, currentFolderId, handleBatchDeleteToTrash]);

  // Selection toggle
  const handleToggleSelect = (id: string, isMulti: boolean) => {
    if (isMulti) {
      setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    } else {
      setSelectedIds([id]);
    }
  };

  // Create new folder
  const handleNewFolder = () => {
    const folderCount = files.filter(f => f.parentId === currentFolderId && f.kind === 'folder').length;
    const name = folderCount === 0 ? 'Untitled Folder' : `Untitled Folder ${folderCount + 1}`;

    const newFolder: ICloudItem = {
      id: `folder-${Date.now()}`,
      name,
      kind: 'folder',
      size: 0,
      modifiedAt: new Date().toISOString(),
      parentId: currentFolderId,
      tags: ['blue'],
      isFavorite: false,
      status: 'local',
      mimeType: 'inode/directory',
      versionHistory: [{ version: 1, timestamp: new Date().toISOString(), size: 0, checksum: 'dir_hash', note: 'Created folder' }],
      hasLocalCache: true,
    };

    setFiles(prev => [newFolder, ...prev]);
    setSelectedIds([newFolder.id]);

    // Record activity
    setActivities(prev => [
      {
        id: `act-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'create',
        title: 'Created New Folder',
        detail: `Created "${name}" in ${folderPath[folderPath.length - 1]?.name || 'iCloud Drive'}.`,
        status: 'success'
      },
      ...prev
    ]);
  };

  // Uploading real files from computer
  const handleUploadFiles = async (fileList: FileList, targetParentId: string | null = currentFolderId) => {
    const newItems: ICloudItem[] = [];

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      let content = '';

      if (file.type.startsWith('image/')) {
        content = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
      } else if (file.type.includes('text') || file.name.endsWith('.csv') || file.name.endsWith('.md') || file.name.endsWith('.json')) {
        content = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsText(file);
        });
      }

      const checksum = await calculateSha256(content || file.name);
      const kind = file.type.startsWith('image/')
        ? 'image'
        : file.name.endsWith('.csv')
        ? 'dataset'
        : file.name.endsWith('.zip')
        ? 'archive'
        : 'document';

      newItems.push({
        id: `file-up-${Date.now()}-${i}`,
        name: file.name,
        kind,
        size: file.size,
        modifiedAt: new Date().toISOString(),
        parentId: targetParentId,
        tags: ['blue'],
        isFavorite: false,
        status: 'local',
        checksum,
        content,
        mimeType: file.type || 'application/octet-stream',
        versionHistory: [
          {
            version: 1,
            timestamp: new Date().toISOString(),
            size: file.size,
            checksum,
            note: 'Imported from computer with SHA-256 validation'
          }
        ],
        hasLocalCache: true
      });
    }

    setFiles(prev => [...newItems, ...prev]);

    setActivities(prev => [
      {
        id: `act-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'upload',
        title: `Imported ${newItems.length} File${newItems.length > 1 ? 's' : ''}`,
        detail: `Durable SHA-256 handshake confirmed for ${newItems.map(f => f.name).join(', ')}.`,
        status: 'success'
      },
      ...prev
    ]);
  };

  // Move / Copy items into specific folder
  const handleDropFilesOnFolder = (dropped: FileList | ICloudItem[], targetFolderId: string) => {
    if (dropped instanceof FileList) {
      handleUploadFiles(dropped, targetFolderId);
    } else {
      // Moving internal items
      const idsToMove = dropped.map(d => d.id);
      setFiles(prev => prev.map(f => {
        if (idsToMove.includes(f.id) && f.id !== targetFolderId) {
          return { ...f, parentId: targetFolderId, modifiedAt: new Date().toISOString() };
        }
        return f;
      }));
    }
  };

  // File mutations
  const handleRename = (id: string, newName: string) => {
    setFiles(prev => prev.map(f => f.id === id ? { ...f, name: newName, modifiedAt: new Date().toISOString() } : f));
  };

  const handleToggleFavorite = (id: string) => {
    setFiles(prev => prev.map(f => f.id === id ? { ...f, isFavorite: !f.isFavorite } : f));
  };

  const handleToggleOffline = (id: string) => {
    setFiles(prev => prev.map(f => {
      if (f.id === id) {
        const nextStatus = f.status === 'local' ? 'cloud' : 'local';
        return { ...f, status: nextStatus, hasLocalCache: nextStatus === 'local' };
      }
      return f;
    }));
  };

  const handleAddTag = (id: string, tag: TagColor) => {
    setFiles(prev => prev.map(f => f.id === id && !f.tags.includes(tag) ? { ...f, tags: [...f.tags, tag] } : f));
  };

  const handleRemoveTag = (id: string, tag: TagColor) => {
    setFiles(prev => prev.map(f => f.id === id ? { ...f, tags: f.tags.filter(t => t !== tag) } : f));
  };

  const handleDeleteToTrash = (id: string) => {
    setFiles(prev => prev.map(f => f.id === id ? { ...f, inTrash: true, deletedAt: new Date().toISOString() } : f));
    setSelectedIds(prev => prev.filter(x => x !== id));
  };

  const handleRestoreFromTrash = (id: string) => {
    setFiles(prev => prev.map(f => f.id === id ? { ...f, inTrash: false, deletedAt: undefined } : f));
  };

  const handleEmptyTrash = () => {
    setFiles(prev => prev.filter(f => !f.inTrash));
  };

  const handleShare = (item: ICloudItem) => {
    setFiles(prev => prev.map(f => f.id === item.id ? { ...f, isShared: true, shareRole: 'view' } : f));
    setActivities(prev => [
      {
        id: `act-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'share',
        title: 'Created Shared Link',
        detail: `Generated read-only link for ${item.name}.`,
        status: 'info'
      },
      ...prev
    ]);
  };

  const handleRevokeShare = (id: string) => {
    setFiles(prev => prev.map(f => f.id === id ? { ...f, isShared: false } : f));
  };

  // Save compute outputs to cloud
  const handleSaveOutputsToCloud = (outputFiles: ICloudItem[]) => {
    setFiles(prev => [...outputFiles, ...prev]);
    setActivities(prev => [
      {
        id: `act-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'compute_job',
        title: 'Task Output Saved',
        detail: `Saved ${outputFiles.map(o => o.name).join(', ')} to iCloud Drive.`,
        status: 'success'
      },
      ...prev
    ]);
  };

  // Add recorded job
  const handleRecordJob = (job: ComputeJob) => {
    setJobs(prev => [job, ...prev]);
  };

  // Create Workspace
  const handleCreateWorkspace = (name: string, description: string, color: string) => {
    const newWs: Workspace = {
      id: `ws-${Date.now()}`,
      name,
      description,
      color,
      icon: 'Layers',
      itemIds: selectedIds.length > 0 ? selectedIds : [],
      notes: 'Initial workspace notes. Created on ' + new Date().toISOString().slice(0, 10),
      linkedWorker: 'local',
      createdAt: new Date().toISOString(),
    };
    setWorkspaces(prev => [newWs, ...prev]);
  };

  // Run Recipe Pipeline
  const handleRunRecipe = (recipe: TaskRecipe, workspace: Workspace) => {
    const wsFiles = files.filter(f => workspace.itemIds.includes(f.id));
    if (wsFiles.length > 0) {
      setTaskModalItems(wsFiles);
    } else {
      // Use first available file
      setTaskModalItems([files[0]]);
    }
  };

  // Conflict Resolution
  const handleResolveConflict = (action: 'keep_both' | 'replace' | 'skip') => {
    if (!conflictModalItem) return;

    if (action === 'keep_both') {
      const copy: ICloudItem = {
        ...conflictModalItem,
        id: `file-conflict-copy-${Date.now()}`,
        name: `${conflictModalItem.name.replace(/\.[^/.]+$/, '')} (Remote Version).json`,
        status: 'local',
      };
      setFiles(prev => [
        ...prev.map(f => f.id === conflictModalItem.id ? { ...f, status: 'local' as const } : f),
        copy
      ]);
    } else if (action === 'replace') {
      setFiles(prev => prev.map(f => f.id === conflictModalItem.id ? { ...f, status: 'local' as const } : f));
    }
    setConflictModalItem(null);
  };

  // Search filtering
  const searchFilteredFiles = useMemo(() => {
    if (!searchQuery.trim()) return files;
    const q = searchQuery.toLowerCase();
    return files.filter(f => 
      !f.inTrash && (
        f.name.toLowerCase().includes(q) ||
        f.checksum?.toLowerCase().includes(q) ||
        f.kind.toLowerCase().includes(q)
      )
    );
  }, [files, searchQuery]);

  // Current folder name
  const currentFolderName = useMemo(() => {
    if (destination !== 'my-files') return undefined;
    if (!currentFolderId) return 'iCloud Drive';
    const folder = files.find(f => f.id === currentFolderId);
    return folder?.name;
  }, [destination, currentFolderId, files]);

  return (
    <div suppressHydrationWarning className="h-screen w-screen overflow-hidden flex flex-col bg-[#e5e5ea] dark:bg-[#09090b] text-neutral-900 dark:text-neutral-100 font-sans antialiased">
      {/* Companion View Toggles */}
      {deviceMode === 'ipad' ? (
        <IpadCompanion
          items={files}
          jobs={jobs}
          workspaces={workspaces}
          onOpenQuickLook={(item) => setQuickLookItem(item)}
          onRunTask={(item) => setTaskModalItems([item])}
          onExitCompanion={() => setDeviceMode('mac')}
        />
      ) : deviceMode === 'iphone' ? (
        <IphoneCompanion
          items={files}
          jobs={jobs}
          workspaces={workspaces}
          onOpenQuickLook={(item) => setQuickLookItem(item)}
          onRunTask={(item) => setTaskModalItems([item])}
          onExitCompanion={() => setDeviceMode('mac')}
        />
      ) : (
        /* macOS Desktop Studio Window Frame */
        <div className="flex-1 flex flex-col h-full overflow-hidden mac-glass">
          {/* Top Unified Toolbar */}
          <Toolbar
            destination={destination}
            currentFolderName={currentFolderName}
            isSidebarOpen={isSidebarOpen}
            onToggleSidebar={() => setIsSidebarOpen(prev => !prev)}
            isInspectorOpen={isInspectorOpen}
            onToggleInspector={() => setIsInspectorOpen(prev => !prev)}
            viewMode={viewMode}
            onChangeViewMode={setViewMode}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onRunTask={() => {
              if (selectedItems.length > 0) setTaskModalItems(selectedItems);
              else setTaskModalItems([files[0]]);
            }}
            onQuickLook={() => {
              if (selectedItems.length > 0) setQuickLookItem(selectedItems[0]);
            }}
            onNewFolder={handleNewFolder}
            onUploadFiles={handleUploadFiles}
            deviceMode={deviceMode}
            onChangeDeviceMode={setDeviceMode}
            isDarkMode={isDarkMode}
            onToggleDarkMode={() => setIsDarkMode(prev => !prev)}
            onOpenCodeHub={() => setCodeModalOpen(true)}
            hasSelection={selectedIds.length > 0}
            canGoBack={historyIndex > 0}
            canGoForward={historyIndex < folderHistory.length - 1}
            onGoBack={handleGoBack}
            onGoForward={handleGoForward}
          />

          {/* Three-Column Desktop Layout */}
          <div className="flex-1 flex overflow-hidden">
            {/* Column 1: Sidebar */}
            {isSidebarOpen && (
              <Sidebar
                destination={destination}
                onSelectDestination={(dest) => {
                  setDestination(dest);
                  if (dest === 'my-files') {
                    setCurrentFolderId(null);
                  }
                  setSelectedIds([]);
                }}
                workspaces={workspaces}
                jobs={jobs}
                pinnedItems={files.filter(f => f.isPinned && !f.inTrash)}
                onSelectFolder={(folderId) => {
                  setDestination('my-files');
                  handleNavigateToFolder(folderId);
                }}
                storageUsedBytes={storageUsedBytes}
                storageMaxBytes={storageMaxBytes}
              />
            )}

            {/* Column 2: Central Viewport */}
            <main className="flex-1 flex flex-col h-full overflow-hidden">
              {destination === 'home' && (
                <HomeView
                  recentFiles={files.filter(f => !f.inTrash && f.kind !== 'folder')}
                  pinnedFolders={files.filter(f => f.kind === 'folder' && f.isPinned && !f.inTrash)}
                  jobs={jobs}
                  workspaces={workspaces}
                  storageUsedBytes={storageUsedBytes}
                  storageMaxBytes={storageMaxBytes}
                  onOpenQuickLook={(item) => setQuickLookItem(item)}
                  onRunTask={(item) => setTaskModalItems([item])}
                  onNavigateToFolder={handleNavigateToFolder}
                  onOpenTaskModal={() => setTaskModalItems(selectedItems.length > 0 ? selectedItems : [files[0]])}
                  onSelectDestination={setDestination}
                />
              )}

              {destination === 'my-files' && (
                <FileBrowser
                  items={searchQuery ? searchFilteredFiles : files}
                  currentFolderId={searchQuery ? null : currentFolderId}
                  folderPath={folderPath}
                  onNavigateToFolder={handleNavigateToFolder}
                  selectedIds={selectedIds}
                  onToggleSelect={handleToggleSelect}
                  onSelectAll={() => setSelectedIds(files.filter(f => !f.inTrash && f.parentId === currentFolderId).map(f => f.id))}
                  onClearSelection={() => setSelectedIds([])}
                  viewMode={viewMode}
                  onOpenQuickLook={(item) => setQuickLookItem(item)}
                  onRunTaskOnItem={(item) => setTaskModalItems([item])}
                  onToggleFavorite={handleToggleFavorite}
                  onToggleOffline={handleToggleOffline}
                  onDeleteToTrash={handleDeleteToTrash}
                  onDropFilesOnFolder={handleDropFilesOnFolder}
                  onDropFilesOnBrowser={(fileList) => handleUploadFiles(fileList, currentFolderId)}
                  onResolveConflict={(item) => setConflictModalItem(item)}
                />
              )}

              {destination === 'workspaces' && (
                <WorkspacesView
                  workspaces={workspaces}
                  recipes={recipes}
                  allItems={files.filter(f => !f.inTrash)}
                  onCreateWorkspace={handleCreateWorkspace}
                  onRunRecipe={handleRunRecipe}
                  onOpenItem={(item) => setQuickLookItem(item)}
                />
              )}

              {destination === 'compute' && (
                <ComputeDashboardView
                  jobs={jobs}
                  onOpenTaskModal={() => setTaskModalItems(selectedItems.length > 0 ? selectedItems : [files[0]])}
                  onClearCompletedJobs={() => setJobs(prev => prev.filter(j => j.status === 'running' || j.status === 'preparing' || j.status === 'queued'))}
                />
              )}

              {destination === 'shared' && (
                <SharedView
                  sharedItems={files.filter(f => f.isShared && !f.inTrash)}
                  onRevokeShare={handleRevokeShare}
                  onOpenItem={(item) => setQuickLookItem(item)}
                />
              )}

              {destination === 'activity' && (
                <ActivityView
                  activities={activities}
                  onClearActivities={() => setActivities([])}
                />
              )}

              {destination === 'trash' && (
                <TrashView
                  trashItems={files.filter(f => f.inTrash)}
                  onRestoreItem={handleRestoreFromTrash}
                  onEmptyTrash={handleEmptyTrash}
                />
              )}

              {destination === 'settings' && (
                <SettingsView
                  storageUsedBytes={storageUsedBytes}
                  storageMaxBytes={storageMaxBytes}
                />
              )}
            </main>

            {/* Column 3: Contextual Inspector */}
            {isInspectorOpen && destination === 'my-files' && (
              <Inspector
                selectedItems={selectedItems}
                onClose={() => setIsInspectorOpen(false)}
                onRunTask={(item) => setTaskModalItems([item])}
                onToggleFavorite={handleToggleFavorite}
                onToggleOffline={handleToggleOffline}
                onAddTag={handleAddTag}
                onRemoveTag={handleRemoveTag}
                onShare={handleShare}
                onRename={handleRename}
              />
            )}
          </div>
        </div>
      )}

      {/* Modals & Overlays */}
      {quickLookItem && (
        <QuickLookModal
          item={quickLookItem}
          onClose={() => setQuickLookItem(null)}
          onRunTask={(item) => {
            setQuickLookItem(null);
            setTaskModalItems([item]);
          }}
        />
      )}

      {taskModalItems && (
        <TaskRunnerModal
          inputItems={taskModalItems}
          onClose={() => setTaskModalItems(null)}
          onSaveOutputsToCloud={handleSaveOutputsToCloud}
          onRecordJob={handleRecordJob}
        />
      )}

      {conflictModalItem && (
        <ConflictModal
          item={conflictModalItem}
          onClose={() => setConflictModalItem(null)}
          onResolve={handleResolveConflict}
        />
      )}

      {codeModalOpen && (
        <CodeDeliverablesModal
          onClose={() => setCodeModalOpen(false)}
        />
      )}
    </div>
  );
}
