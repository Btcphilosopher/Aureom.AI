import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'iCloud Workspace & Personal Compute',
  description: 'A native Apple-inspired personal cloud workspace for macOS, iPad, and iPhone. File storage, drag-and-drop organisation, distributed compute tasks, and project recipes.',
  openGraph: {
    title: 'iCloud Workspace & Personal Compute',
    description: 'A native Apple-inspired personal cloud workspace for macOS, iPad, and iPhone. File storage, drag-and-drop organisation, distributed compute tasks, and project recipes.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'iCloud Workspace & Personal Compute',
    description: 'A native Apple-inspired personal cloud workspace for macOS, iPad, and iPhone. File storage, drag-and-drop organisation, distributed compute tasks, and project recipes.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
