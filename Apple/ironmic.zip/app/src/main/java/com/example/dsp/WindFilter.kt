package com.example.dsp

import kotlin.math.abs
import kotlin.math.max

enum class WindSeverity {
    NONE,
    LOW,
    MEDIUM,
    HIGH
}

/**
 * Intelligent Wind & Turbulence Filter.
 * Detects chaotic low-frequency energy (20-80 Hz) vs mid-band energy and applies
 * dynamic adaptive attenuation + high-pass notch.
 */
class WindFilter(private var sampleRate: Float = 48000f) {
    private var isEnabled = false
    private var sensitivity = 1.0f

    // 2-pole Low-pass filter for detecting sub-bass rumble
    private var subLpf = BiquadFilter.lowPass(48000f, 80f, 0.707f)
    // 2-pole Bandpass filter for mid energy baseline
    private var midBpf = BiquadFilter.bandPass(48000f, 1000f, 1.0f)
    // Adaptive dynamic notch/HPF filter
    private var adaptiveHpf = BiquadFilter.highPass(48000f, 120f, 1.0f)

    private var subEnergySmoothed = 0.0f
    private var midEnergySmoothed = 0.0f

    @Volatile
    var detectedSeverity = WindSeverity.NONE
        private set

    @Volatile
    var windEnergyRatio = 0.0f
        private set

    init {
        configure(false, 1.0f, 48000f)
    }

    fun configure(enabled: Boolean, sens: Float, sr: Float) {
        isEnabled = enabled
        sensitivity = sens.coerceIn(0.2f, 3.0f)
        sampleRate = sr
        subLpf = BiquadFilter.lowPass(sampleRate, 80f, 0.707f)
        midBpf = BiquadFilter.bandPass(sampleRate, 1000f, 1.0f)
        adaptiveHpf = BiquadFilter.highPass(sampleRate, 130f, 1.0f)
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        if (!isEnabled) {
            detectedSeverity = WindSeverity.NONE
            windEnergyRatio = 0.0f
            return
        }

        var blockSubSum = 0.0f
        var blockMidSum = 0.0f

        for (i in offset until (offset + count)) {
            val sample = buffer[i]
            val subVal = subLpf.processSample(sample)
            val midVal = midBpf.processSample(sample)

            blockSubSum += subVal * subVal
            blockMidSum += midVal * midVal
        }

        val blockSubRms = kotlin.math.sqrt(blockSubSum / count.coerceAtLeast(1))
        val blockMidRms = kotlin.math.sqrt(blockMidSum / count.coerceAtLeast(1))

        subEnergySmoothed = 0.9f * subEnergySmoothed + 0.1f * blockSubRms
        midEnergySmoothed = 0.9f * midEnergySmoothed + 0.1f * blockMidRms

        val ratio = (subEnergySmoothed / (midEnergySmoothed + 0.0001f)) * sensitivity
        windEnergyRatio = ratio

        detectedSeverity = when {
            ratio > 4.5f -> WindSeverity.HIGH
            ratio > 2.5f -> WindSeverity.MEDIUM
            ratio > 1.2f -> WindSeverity.LOW
            else -> WindSeverity.NONE
        }

        if (detectedSeverity != WindSeverity.NONE) {
            // Apply adaptive notch attenuation on sub rumble
            adaptiveHpf.processBlock(buffer, offset, count)
        }
    }

    fun reset() {
        subLpf.reset()
        midBpf.reset()
        adaptiveHpf.reset()
        subEnergySmoothed = 0.0f
        midEnergySmoothed = 0.0f
        detectedSeverity = WindSeverity.NONE
    }
}
