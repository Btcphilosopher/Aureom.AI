package com.example.audio

import android.media.AudioFormat
import android.media.MediaRecorder

enum class BitDepth(val bits: Int, val label: String, val encodingFormat: Int) {
    PCM_16(16, "16-bit PCM", AudioFormat.ENCODING_PCM_16BIT),
    PCM_24(24, "24-bit PCM", AudioFormat.ENCODING_PCM_24BIT_PACKED),
    FLOAT_32(32, "32-bit Float", AudioFormat.ENCODING_PCM_FLOAT)
}

enum class ChannelConfig(val count: Int, val label: String, val channelMask: Int) {
    MONO(1, "Mono", AudioFormat.CHANNEL_IN_MONO),
    STEREO(2, "Stereo", AudioFormat.CHANNEL_IN_STEREO)
}

data class CaptureConfig(
    val sampleRate: Int = 48000,
    val bitDepth: BitDepth = BitDepth.FLOAT_32,
    val channelConfig: ChannelConfig = ChannelConfig.MONO,
    val audioSource: Int = MediaRecorder.AudioSource.UNPROCESSED,
    val preferredDeviceId: Int? = null,
    val isLowLatencyPerformanceMode: Boolean = true
) {
    val isRawSource: Boolean
        get() = (audioSource == MediaRecorder.AudioSource.UNPROCESSED)
}
