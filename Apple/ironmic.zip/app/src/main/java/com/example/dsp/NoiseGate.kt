package com.example.dsp

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow

class NoiseGate(private var sampleRate: Float = 48000f) {
    private var isEnabled = false
    private var thresholdLinear = 0.0056f // -45dB
    private var hysteresisLinear = 0.0089f // -41dB (close threshold is lower than open threshold)
    private var expanderRatio = 2.0f
    private var attackCoeff = 0.0f
    private var releaseCoeff = 0.0f

    private var envelope = 0.0f
    private var currentGain = 1.0f
    @Volatile
    var isOpen = true
        private set

    init {
        configure(false, -45f, 4f, 2.0f, 48000f)
    }

    fun configure(
        enabled: Boolean,
        threshDb: Float,
        hysteresisDb: Float,
        ratio: Float,
        sr: Float
    ) {
        isEnabled = enabled
        sampleRate = sr
        val openThresh = threshDb
        val closeThresh = threshDb - hysteresisDb
        thresholdLinear = 10.0f.pow(closeThresh / 20.0f)
        hysteresisLinear = 10.0f.pow(openThresh / 20.0f)
        expanderRatio = ratio.coerceAtLeast(1.0f)

        val attackTimeSec = 0.002f // 2ms fast attack
        val releaseTimeSec = 0.120f // 120ms release
        attackCoeff = exp(-1.0f / (attackTimeSec * sampleRate))
        releaseCoeff = exp(-1.0f / (releaseTimeSec * sampleRate))
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        if (!isEnabled) {
            isOpen = true
            return
        }

        for (i in offset until (offset + count)) {
            val absSample = abs(buffer[i])
            envelope = 0.95f * envelope + 0.05f * absSample

            if (isOpen) {
                if (envelope < thresholdLinear) {
                    isOpen = false
                }
            } else {
                if (envelope > hysteresisLinear) {
                    isOpen = true
                }
            }

            val targetGain = if (isOpen) {
                1.0f
            } else {
                // Downward expander below threshold
                val ratioFactor = if (thresholdLinear > 1e-6f && envelope > 1e-6f) {
                    (envelope / thresholdLinear).pow(expanderRatio - 1.0f).coerceIn(0.01f, 1.0f)
                } else {
                    0.02f
                }
                ratioFactor
            }

            if (targetGain > currentGain) {
                currentGain = attackCoeff * currentGain + (1.0f - attackCoeff) * targetGain
            } else {
                currentGain = releaseCoeff * currentGain + (1.0f - releaseCoeff) * targetGain
            }

            buffer[i] *= currentGain
        }
    }

    fun reset() {
        envelope = 0f
        currentGain = 1.0f
        isOpen = true
    }
}
