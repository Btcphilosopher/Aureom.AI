package com.example.dsp

import kotlin.math.pow
import kotlin.math.tanh

/**
 * Analog-modeled Soft Saturation and Warmth stage.
 * Uses tanh curve with anti-harsh knee and dry/wet blending.
 */
class Saturation {
    private var isEnabled = false
    private var driveLinear = 1.412f // +3dB
    private var blend = 0.85f // dry/wet

    fun configure(enabled: Boolean, driveDb: Float, wetMix: Float = 0.85f) {
        isEnabled = enabled
        driveLinear = 10.0f.pow(driveDb.coerceIn(0f, 18f) / 20.0f)
        blend = wetMix.coerceIn(0f, 1f)
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        if (!isEnabled) return

        val normFactor = 1.0f / tanh(driveLinear)

        for (i in offset until (offset + count)) {
            val dry = buffer[i]
            val driven = dry * driveLinear
            val saturated = tanh(driven) * normFactor
            buffer[i] = dry * (1.0f - blend) + saturated * blend
        }
    }
}
