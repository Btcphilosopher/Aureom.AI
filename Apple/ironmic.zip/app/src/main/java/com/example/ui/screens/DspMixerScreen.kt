package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dsp.EqPreset
import com.example.dsp.ProcessingMode
import com.example.dsp.WindSeverity
import com.example.ui.IronMicViewModel
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelBorderActive
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun DspMixerScreen(
    viewModel: IronMicViewModel,
    modifier: Modifier = Modifier
) {
    val dspSettings by viewModel.dspSettingsState.collectAsState()
    val telemetry by viewModel.dspTelemetry.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("dsp_mixer_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section: Processing Mode & Presets
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ACTIVE DSP PROFILE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ProcessingMode.values().forEach { mode ->
                        val isSel = (mode == dspSettings.mode)
                        Box(
                            modifier = Modifier
                                .background(
                                    color = if (isSel) SignalAmber.copy(alpha = 0.2f) else Color(0xFF161A20),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .border(1.dp, if (isSel) SignalAmber else PanelBorder, RoundedCornerShape(4.dp))
                                .clickable { viewModel.setProcessingMode(mode) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = mode.name,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) SignalAmber else TextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Section: 6-Band Parametric EQ
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
                .testTag("eq_module")
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "6-BAND PARAMETRIC EQ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = SignalCyan,
                        letterSpacing = 1.sp
                    )

                    Switch(
                        checked = dspSettings.eqEnabled,
                        onCheckedChange = {
                            viewModel.updateDspSettings(dspSettings.copy(eqEnabled = it))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SignalCyan,
                            checkedTrackColor = SignalCyan.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CarbonDark
                        )
                    )
                }

                // EQ Presets Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    EqPreset.values().forEach { preset ->
                        OutlinedButton(
                            onClick = { viewModel.applyEqPreset(preset) },
                            modifier = Modifier.height(26.dp),
                            shape = RoundedCornerShape(4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color.Transparent,
                                contentColor = SignalCyan
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = SolidColor(PanelBorder)
                            )
                        ) {
                            Text(preset.name, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }

                // Individual Band Sliders
                dspSettings.eqBands.forEachIndexed { idx, band ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${band.name} (${band.frequency.toInt()}Hz)",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary,
                            modifier = Modifier.weight(1.2f)
                        )

                        Slider(
                            value = band.gainDb,
                            onValueChange = { newGain ->
                                val updated = dspSettings.eqBands.toMutableList()
                                updated[idx] = band.copy(gainDb = newGain)
                                viewModel.updateDspSettings(dspSettings.copy(eqBands = updated))
                            },
                            valueRange = -12f..12f,
                            enabled = dspSettings.eqEnabled,
                            colors = SliderDefaults.colors(
                                thumbColor = SignalCyan,
                                activeTrackColor = SignalCyan,
                                inactiveTrackColor = PanelBorder
                            ),
                            modifier = Modifier.weight(2.0f)
                        )

                        Text(
                            text = String.format(Locale.US, "%+.1fdB", band.gainDb),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (band.gainDb != 0f) SignalCyan else TextMuted,
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                }
            }
        }

        // Section: Studio Broadcast Compressor
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
                .testTag("compressor_module")
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "BROADCAST COMPRESSOR",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SignalAmber,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "GR: -${String.format(Locale.US, "%.1f", telemetry.compGainReductionDb)} dB",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (telemetry.compGainReductionDb > 0.5f) SignalAmber else TextMuted
                        )
                    }

                    Switch(
                        checked = dspSettings.compressorEnabled,
                        onCheckedChange = {
                            viewModel.updateDspSettings(dspSettings.copy(compressorEnabled = it))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SignalAmber,
                            checkedTrackColor = SignalAmber.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CarbonDark
                        )
                    )
                }

                // Threshold Slider
                Text(
                    text = "THRESHOLD: ${String.format(Locale.US, "%.1f dBFS", dspSettings.compThresholdDb)}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary
                )
                Slider(
                    value = dspSettings.compThresholdDb,
                    onValueChange = { viewModel.updateDspSettings(dspSettings.copy(compThresholdDb = it)) },
                    valueRange = -40f..0f,
                    enabled = dspSettings.compressorEnabled,
                    colors = SliderDefaults.colors(thumbColor = SignalAmber, activeTrackColor = SignalAmber, inactiveTrackColor = PanelBorder)
                )

                // Ratio Slider
                Text(
                    text = "RATIO: ${String.format(Locale.US, "%.1f : 1", dspSettings.compRatio)}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary
                )
                Slider(
                    value = dspSettings.compRatio,
                    onValueChange = { viewModel.updateDspSettings(dspSettings.copy(compRatio = it)) },
                    valueRange = 1f..10f,
                    enabled = dspSettings.compressorEnabled,
                    colors = SliderDefaults.colors(thumbColor = SignalAmber, activeTrackColor = SignalAmber, inactiveTrackColor = PanelBorder)
                )
            }
        }

        // Section: Safety True-Peak Limiter
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "TRUE-PEAK SAFETY LIMITER",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SignalRed,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "CEILING: ${String.format(Locale.US, "%.1f dBTP", dspSettings.limiterCeilingDbtp)} | GR: -${String.format(Locale.US, "%.1f dB", telemetry.limiterGainReductionDb)}",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary
                        )
                    }

                    Switch(
                        checked = dspSettings.limiterEnabled,
                        onCheckedChange = {
                            viewModel.updateDspSettings(dspSettings.copy(limiterEnabled = it))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SignalRed,
                            checkedTrackColor = SignalRed.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CarbonDark
                        )
                    )
                }

                Slider(
                    value = dspSettings.limiterCeilingDbtp,
                    onValueChange = { viewModel.updateDspSettings(dspSettings.copy(limiterCeilingDbtp = it)) },
                    valueRange = -6f..0f,
                    enabled = dspSettings.limiterEnabled,
                    colors = SliderDefaults.colors(thumbColor = SignalRed, activeTrackColor = SignalRed, inactiveTrackColor = PanelBorder)
                )
            }
        }

        // Section: Intelligent Wind & De-Esser
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ACOUSTIC CORRECTION (WIND & SIBILANCE)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalGreen,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "DYNAMIC VOICE DE-ESSER",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextPrimary
                        )
                        Text(
                            text = "CENTER: 6,500 Hz | RED: -${String.format(Locale.US, "%.1f dB", telemetry.deEsserReductionDb)}",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextMuted
                        )
                    }

                    Switch(
                        checked = dspSettings.deEsserEnabled,
                        onCheckedChange = {
                            viewModel.updateDspSettings(dspSettings.copy(deEsserEnabled = it))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SignalGreen,
                            checkedTrackColor = SignalGreen.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CarbonDark
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "INTELLIGENT WIND / RUMBLE FILTER",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextPrimary
                        )
                        Text(
                            text = "STATE: ${telemetry.windSeverity.name} (RATIO ${String.format(Locale.US, "%.1f", telemetry.windRatio)})",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = if (telemetry.windSeverity != WindSeverity.NONE) SignalRed else SignalGreen
                        )
                    }

                    Switch(
                        checked = dspSettings.windFilterEnabled,
                        onCheckedChange = {
                            viewModel.updateDspSettings(dspSettings.copy(windFilterEnabled = it))
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SignalGreen,
                            checkedTrackColor = SignalGreen.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CarbonDark
                        )
                    )
                }
            }
        }
    }
}
