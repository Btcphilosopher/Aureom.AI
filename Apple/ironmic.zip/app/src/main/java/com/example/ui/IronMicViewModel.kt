package com.example.ui

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.IronMicApplication
import com.example.audio.AudioDeviceManager
import com.example.audio.AudioDeviceModel
import com.example.audio.AudioEngine
import com.example.audio.AudioRecordingService
import com.example.audio.BitDepth
import com.example.audio.CaptureConfig
import com.example.audio.ChannelConfig
import com.example.audio.EngineDiagnostics
import com.example.audio.HardwareCapabilityMatrix
import com.example.audio.ProximityStatus
import com.example.audio.ProximityTarget
import com.example.audio.RecordState
import com.example.audio.RecordingSessionInfo
import com.example.calibration.MicrophoneQualityDashboard
import com.example.calibration.SilenceTestResult
import com.example.calibration.ToneTestResult
import com.example.data.TakeEntity
import com.example.data.TakeRepository
import com.example.dsp.DspSettings
import com.example.dsp.DspTelemetry
import com.example.dsp.EqPreset
import com.example.dsp.MeterReading
import com.example.dsp.ProcessingMode
import com.example.dsp.SyntheticSignalType
import com.example.monitoring.MonitorEngine
import com.example.monitoring.MonitorState
import com.example.recording.PlaybackState
import com.example.recording.TakePlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

enum class AppTab(val title: String, val iconLabel: String) {
    CONSOLE("Console", "CON"),
    DSP_MIXER("DSP & Chain", "DSP"),
    INSTRUMENTS("Instruments", "MTR"),
    DEVICE_LAB("Hardware Lab", "LAB"),
    TAKES("Takes Library", "REC"),
    SYNTH_LAB("Signal Gen", "GEN")
}

class IronMicViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as IronMicApplication
    val repository: TakeRepository = app.takeRepository

    val deviceManager = AudioDeviceManager(application)
    val monitorEngine = MonitorEngine(application)
    val audioEngine = AudioEngine(application, deviceManager, monitorEngine)
    val takePlayer = TakePlayer()

    private val _activeTab = MutableStateFlow(AppTab.CONSOLE)
    val activeTab: StateFlow<AppTab> = _activeTab.asStateFlow()

    val meterReading: StateFlow<MeterReading> = audioEngine.meterReading
    val engineDiagnostics: StateFlow<EngineDiagnostics> = audioEngine.engineDiagnostics
    val dspTelemetry: StateFlow<DspTelemetry> = audioEngine.dspTelemetry
    val recordingSession: StateFlow<RecordingSessionInfo> = audioEngine.recordingSession
    val spectrumMagnitudes: StateFlow<FloatArray> = audioEngine.spectrumMagnitudes
    val scopeWaveform: StateFlow<FloatArray> = audioEngine.scopeWaveform
    val proximityStatus: StateFlow<ProximityStatus> = audioEngine.proximityStatus
    val monitorState: StateFlow<MonitorState> = monitorEngine.monitorState
    val availableDevices: StateFlow<List<AudioDeviceModel>> = deviceManager.availableDevices
    val capabilityMatrix: StateFlow<HardwareCapabilityMatrix> = deviceManager.capabilityMatrix
    val playbackState: StateFlow<PlaybackState> = takePlayer.playbackState

    val silenceTestResult: StateFlow<SilenceTestResult?> = audioEngine.silenceTestResult
    val toneTestResult: StateFlow<ToneTestResult?> = audioEngine.toneTestResult

    private val _micQualityDashboard = MutableStateFlow(MicrophoneQualityDashboard())
    val micQualityDashboard: StateFlow<MicrophoneQualityDashboard> = _micQualityDashboard.asStateFlow()

    private val _dspSettingsState = MutableStateFlow(DspSettings())
    val dspSettingsState: StateFlow<DspSettings> = _dspSettingsState.asStateFlow()

    private val _captureConfigState = MutableStateFlow(CaptureConfig())
    val captureConfigState: StateFlow<CaptureConfig> = _captureConfigState.asStateFlow()

    private val _activeSyntheticType = MutableStateFlow(SyntheticSignalType.OFF)
    val activeSyntheticType: StateFlow<SyntheticSignalType> = _activeSyntheticType.asStateFlow()

    val allTakes: StateFlow<List<TakeEntity>> = repository.allTakes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val recordingsDir: File by lazy {
        File(getApplication<Application>().filesDir, "recordings").apply {
            if (!exists()) mkdirs()
        }
    }

    init {
        audioEngine.start()
        observeCalibrationResults()
    }

    private fun observeCalibrationResults() {
        viewModelScope.launch {
            audioEngine.silenceTestResult.collect { result ->
                if (result != null) {
                    _micQualityDashboard.value = _micQualityDashboard.value.copy(
                        noiseFloorDbfs = result.noiseFloorDbfs,
                        peakHeadroomDb = 0f - result.peakNoiseDbfs,
                        dynamicRangeDb = result.dynamicRangeDb,
                        lowFrequencyStatus = if (result.subBassRumblePresent) "Sub Rumble Detected" else "Stable Baseline",
                        speechBandStatus = if (result.highFreqHissPresent) "Hiss Elevation" else "Clean Intelligibility",
                        isCalibrated = true
                    )
                }
            }
        }
    }

    fun selectTab(tab: AppTab) {
        _activeTab.value = tab
    }

    fun setProcessingMode(mode: ProcessingMode) {
        val updated = _dspSettingsState.value.copy(mode = mode)
        _dspSettingsState.value = updated
        audioEngine.updateDspSettings(updated)
    }

    fun setDigitalGainDb(gainDb: Float) {
        if (_dspSettingsState.value.gainLocked) return
        val updated = _dspSettingsState.value.copy(digitalGainDb = gainDb)
        _dspSettingsState.value = updated
        audioEngine.setDigitalGainDb(gainDb)
    }

    fun toggleGainLock() {
        val newLock = !_dspSettingsState.value.gainLocked
        val updated = _dspSettingsState.value.copy(gainLocked = newLock)
        _dspSettingsState.value = updated
        audioEngine.setGainLock(newLock)
    }

    fun updateDspSettings(settings: DspSettings) {
        _dspSettingsState.value = settings
        audioEngine.updateDspSettings(settings)
    }

    fun applyEqPreset(preset: EqPreset) {
        val newBands = DspSettings.presetBands(preset)
        val updated = _dspSettingsState.value.copy(eqBands = newBands)
        _dspSettingsState.value = updated
        audioEngine.updateDspSettings(updated)
    }

    fun setProximityTarget(target: ProximityTarget) {
        audioEngine.activeProximityTarget = target
    }

    fun selectCaptureConfig(
        sampleRate: Int = _captureConfigState.value.sampleRate,
        bitDepth: BitDepth = _captureConfigState.value.bitDepth,
        channelConfig: ChannelConfig = _captureConfigState.value.channelConfig,
        preferredDeviceId: Int? = _captureConfigState.value.preferredDeviceId
    ) {
        val newConfig = _captureConfigState.value.copy(
            sampleRate = sampleRate,
            bitDepth = bitDepth,
            channelConfig = channelConfig,
            preferredDeviceId = preferredDeviceId
        )
        _captureConfigState.value = newConfig
        audioEngine.updateConfig(newConfig)
    }

    fun selectDevice(deviceId: Int) {
        deviceManager.selectDevice(deviceId)
        selectCaptureConfig(preferredDeviceId = deviceId)
    }

    fun toggleMonitoring(enabled: Boolean) {
        monitorEngine.toggleMonitoring(enabled)
    }

    fun setMonitorVolume(gainDb: Float) {
        monitorEngine.setVolumeGain(gainDb)
    }

    fun setMonitorBlend(blend: Float) {
        monitorEngine.setDirectBlend(blend)
    }

    fun emergencyMute() {
        monitorEngine.emergencyMute()
    }

    fun startSilenceCalibration() {
        audioEngine.startSilenceCalibration()
    }

    fun startToneCalibration() {
        audioEngine.startToneCalibration()
    }

    fun setSyntheticSignal(type: SyntheticSignalType) {
        _activeSyntheticType.value = type
        audioEngine.syntheticType = type
    }

    fun toggleRecording() {
        val current = recordingSession.value.state
        if (current == RecordState.RECORDING) {
            pauseRecording()
        } else if (current == RecordState.PAUSED) {
            resumeRecording()
        } else {
            startRecording()
        }
    }

    fun startRecording() {
        val file = audioEngine.startRecording(recordingsDir)
        if (file != null) {
            startRecordingForegroundService(file.name)
        }
    }

    fun pauseRecording() {
        audioEngine.pauseRecording()
    }

    fun resumeRecording() {
        audioEngine.resumeRecording()
    }

    fun addTakeMarker(label: String = "Marker") {
        audioEngine.addRecordingMarker(label)
    }

    fun stopRecording() {
        val writer = audioEngine.stopRecording()
        stopRecordingForegroundService()

        if (writer != null) {
            viewModelScope.launch {
                val reading = meterReading.value
                val session = recordingSession.value
                val take = TakeEntity(
                    filename = writer.file.name,
                    filePath = writer.file.absolutePath,
                    durationMs = session.durationMs,
                    sampleRate = writer.sampleRate,
                    bitDepth = writer.bitDepth,
                    channels = writer.channelCount,
                    fileSize = writer.file.length(),
                    peakDbfs = reading.peakDbfs,
                    integratedLufs = reading.lufsIntegrated,
                    truePeakDbtp = reading.truePeakDbtp,
                    notes = "",
                    processingMode = _dspSettingsState.value.mode.title,
                    markersJson = "[]"
                )
                repository.insert(take)
            }
        }
    }

    private fun startRecordingForegroundService(takeName: String) {
        try {
            val intent = Intent(getApplication(), AudioRecordingService::class.java).apply {
                putExtra(AudioRecordingService.EXTRA_TAKE_NAME, takeName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                getApplication<Application>().startForegroundService(intent)
            } else {
                getApplication<Application>().startService(intent)
            }
        } catch (_: Exception) {}
    }

    private fun stopRecordingForegroundService() {
        try {
            val intent = Intent(getApplication(), AudioRecordingService::class.java).apply {
                action = AudioRecordingService.ACTION_STOP_SERVICE
            }
            getApplication<Application>().startService(intent)
        } catch (_: Exception) {}
    }

    fun playTake(take: TakeEntity) {
        takePlayer.playTake(take.id, take.filePath)
    }

    fun togglePlayback() {
        takePlayer.togglePlayPause()
    }

    fun seekPlayback(posMs: Long) {
        takePlayer.seekTo(posMs)
    }

    fun stopPlayback() {
        takePlayer.stop()
    }

    fun updateTakeNote(take: TakeEntity, newNote: String) {
        viewModelScope.launch {
            repository.update(take.copy(notes = newNote))
        }
    }

    fun deleteTake(take: TakeEntity) {
        viewModelScope.launch {
            if (playbackState.value.currentTakeId == take.id) {
                takePlayer.stop()
            }
            repository.delete(take)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
        takePlayer.stop()
        stopRecordingForegroundService()
    }
}
