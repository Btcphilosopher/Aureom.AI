package com.example.data

import kotlinx.coroutines.flow.Flow
import java.io.File

class TakeRepository(private val takeDao: TakeDao) {
    val allTakes: Flow<List<TakeEntity>> = takeDao.getAllTakes()

    suspend fun insert(take: TakeEntity): Long = takeDao.insertTake(take)

    suspend fun update(take: TakeEntity) = takeDao.updateTake(take)

    suspend fun delete(take: TakeEntity) {
        takeDao.deleteTake(take)
        try {
            val file = File(take.filePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {}
    }

    suspend fun deleteById(id: Long) {
        val take = takeDao.getTakeById(id)
        if (take != null) {
            delete(take)
        }
    }

    suspend fun getById(id: Long): TakeEntity? = takeDao.getTakeById(id)
}
