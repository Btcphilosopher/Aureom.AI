package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [TakeEntity::class], version = 1, exportSchema = false)
abstract class IronMicDatabase : RoomDatabase() {
    abstract fun takeDao(): TakeDao

    companion object {
        @Volatile
        private var INSTANCE: IronMicDatabase? = null

        fun getDatabase(context: Context): IronMicDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    IronMicDatabase::class.java,
                    "ironmic_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
