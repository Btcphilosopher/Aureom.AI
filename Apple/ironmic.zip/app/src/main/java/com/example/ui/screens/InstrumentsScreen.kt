package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dsp.MeterReading
import com.example.ui.IronMicViewModel
import com.example.ui.components.RealTimeOscilloscopeView
import com.example.ui.components.RealTimeSpectrumView
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun InstrumentsScreen(
    viewModel: IronMicViewModel,
    modifier: Modifier = Modifier
) {
    val meterReading by viewModel.meterReading.collectAsState()
    val spectrumMagnitudes by viewModel.spectrumMagnitudes.collectAsState()
    val scopeWaveform by viewModel.scopeWaveform.collectAsState()
    val diagnostics by viewModel.engineDiagnostics.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("instruments_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Section: EBU R128 Broadcast Loudness Meter
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
                .testTag("loudness_meter_card")
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "EBU R128 / ITU-R BS.1770 LOUDNESS METER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    LoudnessMetricCell(
                        title = "MOMENTARY (M)",
                        value = String.format(Locale.US, "%.1f", meterReading.lufsMomentary),
                        unit = "LUFS",
                        color = SignalAmber
                    )
                    LoudnessMetricCell(
                        title = "SHORT-TERM (S)",
                        value = String.format(Locale.US, "%.1f", meterReading.lufsShortTerm),
                        unit = "LUFS",
                        color = SignalCyan
                    )
                    LoudnessMetricCell(
                        title = "INTEGRATED (I)",
                        value = String.format(Locale.US, "%.1f", meterReading.lufsIntegrated),
                        unit = "LUFS",
                        color = SignalGreen
                    )
                }
            }
        }

        // Section: Acoustic Precision Telemetry (True Peak, Crest Factor, DC Offset, Noise Floor)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ACOUSTIC PRECISION TELEMETRY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalCyan,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    LoudnessMetricCell(
                        title = "TRUE PEAK",
                        value = String.format(Locale.US, "%+.1f", meterReading.truePeakDbtp),
                        unit = "dBTP",
                        color = if (meterReading.truePeakDbtp >= -0.5f) SignalRed else SignalAmber
                    )
                    LoudnessMetricCell(
                        title = "CREST FACTOR",
                        value = String.format(Locale.US, "%.1f", meterReading.crestFactorDb),
                        unit = "dB",
                        color = SignalGreen
                    )
                    LoudnessMetricCell(
                        title = "DC OFFSET",
                        value = String.format(Locale.US, "%+.3f", meterReading.dcOffset),
                        unit = "NULL",
                        color = TextSecondary
                    )
                    LoudnessMetricCell(
                        title = "NOISE FLOOR",
                        value = String.format(Locale.US, "%.1f", meterReading.noiseFloorDbfs),
                        unit = "dBFS",
                        color = TextMuted
                    )
                }
            }
        }

        // Section: Live FFT Spectrum Analyzer
        RealTimeSpectrumView(
            magnitudes = spectrumMagnitudes,
            fftSize = 2048
        )

        // Section: Time-domain Oscilloscope
        RealTimeOscilloscopeView(
            waveform = scopeWaveform,
            timebaseMs = 10f
        )

        // Section: Real-time Audio Performance Watchdog
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "REAL-TIME AUDIO THREAD WATCHDOG",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalGreen,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "BUFFER: ${diagnostics.bufferFrames} FRAMES (${String.format(Locale.US, "%.2f", diagnostics.bufferDurationMs)} ms) | SAMPLE RATE: ${diagnostics.sampleRate} Hz",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextPrimary
                )

                Text(
                    text = "DSP EXEC TIME: ${diagnostics.dspProcessingUs} μs | DSP BUDGET LOAD: ${String.format(Locale.US, "%.1f", diagnostics.dspLoadPercent)}%",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = SignalCyan
                )

                Text(
                    text = "XRUNS (DROPOUTS): ${diagnostics.xRuns} | SOURCE: ${diagnostics.audioSourceUsed}",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (diagnostics.xRuns > 0) SignalRed else SignalGreen
                )
            }
        }
    }
}

@Composable
fun LoudnessMetricCell(
    title: String,
    value: String,
    unit: String,
    color: androidx.compose.ui.graphics.Color
) {
    Box(
        modifier = Modifier
            .background(CarbonDark, RoundedCornerShape(4.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                color = TextMuted
            )
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = value,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = color
                )
                Text(
                    text = unit,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary
                )
            }
        }
    }
}
