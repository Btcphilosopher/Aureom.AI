package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dsp.DspSettings
import com.example.dsp.DspTelemetry
import com.example.dsp.ProcessingMode
import com.example.dsp.WindSeverity
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun SignalChainDiagram(
    dspSettings: DspSettings,
    telemetry: DspTelemetry,
    audioSource: String,
    modifier: Modifier = Modifier
) {
    val isRaw = (dspSettings.mode == ProcessingMode.RAW)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("signal_chain_diagram")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TRANSPARENT SIGNAL CHAIN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "DSP: ${telemetry.processingTimeUs} μs (${String.format(Locale.US, "%.1f", telemetry.dspLoadPercent)}% CPU)",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = SignalCyan
                )
            }

            // Flow Nodes
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ChainNode(label = "MIC IN", sub = audioSource.take(8), isActive = true, color = SignalCyan)
                ChainConnector()

                ChainNode(label = "GAIN", sub = String.format(Locale.US, "%+.1fdB", dspSettings.digitalGainDb), isActive = dspSettings.digitalGainDb != 0f, color = SignalAmber)
                ChainConnector()

                ChainNode(label = "HPF", sub = if (isRaw) "OFF" else "80Hz", isActive = !isRaw, color = SignalGreen)
                ChainConnector()

                ChainNode(label = "WIND", sub = if (telemetry.windSeverity != WindSeverity.NONE) telemetry.windSeverity.name else "OFF", isActive = telemetry.windSeverity != WindSeverity.NONE, color = SignalRed)
                ChainConnector()

                ChainNode(label = "GATE", sub = if (telemetry.noiseGateOpen) "OPEN" else "CLOSED", isActive = !isRaw, color = if (telemetry.noiseGateOpen) SignalGreen else SignalAmber)
                ChainConnector()

                ChainNode(label = "EQ", sub = if (isRaw) "FLAT" else "6-BAND", isActive = !isRaw, color = SignalCyan)
                ChainConnector()

                val compGr = telemetry.compGainReductionDb
                ChainNode(label = "COMP", sub = if (compGr > 0.5f) String.format(Locale.US, "-%.1fdB", compGr) else "0dB", isActive = compGr > 0.5f, color = SignalAmber)
                ChainConnector()

                val deEssGr = telemetry.deEsserReductionDb
                ChainNode(label = "DE-ESS", sub = if (deEssGr > 0.5f) String.format(Locale.US, "-%.1fdB", deEssGr) else "OFF", isActive = deEssGr > 0.5f, color = SignalCyan)
                ChainConnector()

                val limGr = telemetry.limiterGainReductionDb
                ChainNode(label = "LIMIT", sub = if (limGr > 0.2f) String.format(Locale.US, "-%.1fdB", limGr) else "ARMED", isActive = limGr > 0.2f, color = SignalRed)
                ChainConnector()

                ChainNode(label = "OUT/WAV", sub = "32-BIT", isActive = true, color = SignalGreen)
            }
        }
    }
}

@Composable
fun ChainNode(label: String, sub: String, isActive: Boolean, color: Color) {
    Box(
        modifier = Modifier
            .background(
                color = if (isActive) color.copy(alpha = 0.15f) else Color(0xFF14171C),
                shape = RoundedCornerShape(4.dp)
            )
            .border(
                width = 1.dp,
                color = if (isActive) color else PanelBorder,
                shape = RoundedCornerShape(4.dp)
            )
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = if (isActive) color else TextMuted
            )
            Text(
                text = sub,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                color = if (isActive) TextPrimary else TextMuted
            )
        }
    }
}

@Composable
fun ChainConnector() {
    Text(
        text = "→",
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace,
        color = PanelBorder
    )
}
