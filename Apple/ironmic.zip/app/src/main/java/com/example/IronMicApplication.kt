package com.example

import android.app.Application
import com.example.data.IronMicDatabase
import com.example.data.TakeRepository

class IronMicApplication : Application() {

    val database: IronMicDatabase by lazy {
        IronMicDatabase.getDatabase(this)
    }

    val takeRepository: TakeRepository by lazy {
        TakeRepository(database.takeDao())
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    companion object {
        lateinit var instance: IronMicApplication
            private set
    }
}
