package com.example.dsp

/**
 * High-Pass Filter with configurable slope (6, 12, 18, 24 dB/oct).
 * Implemented using cascaded 2nd order Butterworth biquad sections.
 */
class HighPassFilter(private var sampleRate: Float = 48000f) {
    private var stage1 = BiquadFilter.highPass(48000f, 80f, 0.707f)
    private var stage2 = BiquadFilter.highPass(48000f, 80f, 0.707f)

    private var currentCutoff = 80f
    private var currentSlope = 18
    private var enabled = true

    fun configure(cutoffHz: Float, slopeDbPerOct: Int, sr: Float, isEnabled: Boolean) {
        sampleRate = sr
        currentCutoff = cutoffHz.coerceIn(10f, 400f)
        currentSlope = slopeDbPerOct
        enabled = isEnabled

        if (!enabled) return

        when (slopeDbPerOct) {
            6 -> {
                stage1 = BiquadFilter.highPass(sampleRate, currentCutoff, 0.5f)
            }
            12 -> {
                stage1 = BiquadFilter.highPass(sampleRate, currentCutoff, 0.7071f)
            }
            18 -> {
                stage1 = BiquadFilter.highPass(sampleRate, currentCutoff, 0.54f)
                stage2 = BiquadFilter.highPass(sampleRate, currentCutoff, 1.3f)
            }
            24 -> {
                stage1 = BiquadFilter.highPass(sampleRate, currentCutoff, 0.5412f)
                stage2 = BiquadFilter.highPass(sampleRate, currentCutoff, 1.3065f)
            }
            else -> {
                stage1 = BiquadFilter.highPass(sampleRate, currentCutoff, 0.7071f)
            }
        }
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        if (!enabled) return

        if (currentSlope <= 12) {
            stage1.processBlock(buffer, offset, count)
        } else {
            stage1.processBlock(buffer, offset, count)
            stage2.processBlock(buffer, offset, count)
        }
    }

    fun reset() {
        stage1.reset()
        stage2.reset()
    }
}
