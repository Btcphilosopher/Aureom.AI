package com.example.dsp

import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow

/**
 * Fast True-Peak oriented Safety Limiter.
 * Uses lookahead circular buffer, peak hold, and smooth release to prevent clipping.
 */
class Limiter(private var sampleRate: Float = 48000f) {
    private var isEnabled = true
    private var ceilingLinear = 0.89125f // -1.0 dBTP default
    private var releaseCoeff = 0.0f

    // Lookahead buffer (e.g. 64 samples ~ 1.33ms at 48kHz)
    private val lookaheadSize = 64
    private val delayBuffer = FloatArray(lookaheadSize)
    private var writeIndex = 0

    private var currentGain = 1.0f
    val clipCounter = AtomicInteger(0)

    @Volatile
    var gainReductionDb = 0.0f
        private set

    init {
        configure(true, -1.0f, 50.0f, 48000f)
    }

    fun configure(enabled: Boolean, ceilingDbtp: Float, releaseMs: Float, sr: Float) {
        isEnabled = enabled
        sampleRate = sr
        ceilingLinear = 10.0f.pow(ceilingDbtp.coerceIn(-12f, 0f) / 20.0f)
        val releaseTimeSec = (releaseMs.coerceAtLeast(1.0f)) / 1000f
        releaseCoeff = exp(-1.0f / (releaseTimeSec * sampleRate))
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        if (!isEnabled) {
            gainReductionDb = 0.0f
            // Check for clips in raw stream
            for (i in offset until (offset + count)) {
                if (abs(buffer[i]) >= 1.0f) {
                    clipCounter.incrementAndGet()
                }
            }
            return
        }

        var maxGr = 0.0f

        for (i in offset until (offset + count)) {
            val inputSample = buffer[i]

            // Lookahead ring buffer retrieval
            val delayedSample = delayBuffer[writeIndex]
            delayBuffer[writeIndex] = inputSample
            writeIndex = (writeIndex + 1) % lookaheadSize

            val absInput = abs(inputSample)
            val targetGain = if (absInput > ceilingLinear && absInput > 1e-6f) {
                ceilingLinear / absInput
            } else {
                1.0f
            }

            // Fast attack, smooth release
            if (targetGain < currentGain) {
                currentGain = targetGain
            } else {
                currentGain = releaseCoeff * currentGain + (1.0f - releaseCoeff) * targetGain
            }

            var outputSample = delayedSample * currentGain

            // Overshoot safety hard clamp at ceiling
            if (outputSample > ceilingLinear) {
                outputSample = ceilingLinear
                clipCounter.incrementAndGet()
            } else if (outputSample < -ceilingLinear) {
                outputSample = -ceilingLinear
                clipCounter.incrementAndGet()
            }

            val gr = if (currentGain < 1.0f) {
                -20.0f * kotlin.math.log10(currentGain.coerceAtLeast(1e-6f))
            } else {
                0.0f
            }
            if (gr > maxGr) maxGr = gr

            buffer[i] = outputSample
        }

        gainReductionDb = maxGr
    }

    fun reset() {
        delayBuffer.fill(0f)
        writeIndex = 0
        currentGain = 1.0f
        gainReductionDb = 0.0f
    }
}
