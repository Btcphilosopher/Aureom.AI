package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dsp.ProcessingMode
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelBorderActive
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ModeSelectorBar(
    currentMode: ProcessingMode,
    onModeSelected: (ProcessingMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("mode_selector_bar")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PROCESSING MODE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber,
                    letterSpacing = 1.sp
                )
                Text(
                    text = currentMode.title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = when (currentMode) {
                        ProcessingMode.RAW -> SignalRed
                        ProcessingMode.POWER -> SignalAmber
                        ProcessingMode.MEASUREMENT -> SignalCyan
                        else -> SignalGreen
                    }
                )
            }

            // Horizontal scrolling mode pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ProcessingMode.values().forEach { mode ->
                    val isSelected = (mode == currentMode)
                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isSelected) SignalAmber.copy(alpha = 0.2f) else Color(0xFF161A20),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) SignalAmber else PanelBorder,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable { onModeSelected(mode) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("mode_pill_${mode.name.lowercase()}")
                    ) {
                        Text(
                            text = mode.name,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontFamily = FontFamily.Monospace,
                            color = if (isSelected) SignalAmber else TextSecondary
                        )
                    }
                }
            }

            // Mode Description
            Text(
                text = currentMode.description,
                fontSize = 11.sp,
                fontFamily = FontFamily.Default,
                color = TextSecondary,
                lineHeight = 14.sp
            )
        }
    }
}
