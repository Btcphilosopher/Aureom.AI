package com.example.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.random.Random

enum class SyntheticSignalType(val label: String) {
    OFF("Microphone Input"),
    SINE_1KHZ("Sine 1,000 Hz"),
    SINE_100HZ("Sine 100 Hz (Sub Bass)"),
    SINE_10KHZ("Sine 10,000 Hz (High)"),
    SWEEP_20_20K("Log Sweep 20 Hz → 20 kHz"),
    PINK_NOISE("Pink Noise (1/f)"),
    WHITE_NOISE("White Noise"),
    SPEECH_SIM("Speech Formant Simulation"),
    IMPULSE("Dirac Impulse (1-Sample)"),
    HIGH_AMP_STRESS("Limiter Stress Test (+3dBFS)")
}

class SyntheticSignalGenerator(private var sampleRate: Float = 48000f) {
    private var phase = 0.0
    private var sweepPhase = 0.0
    private var sweepTime = 0.0
    private val sweepDurationSec = 5.0

    // Pink noise filter state (Paul Kellet's filter)
    private var b0 = 0.0f
    private var b1 = 0.0f
    private var b2 = 0.0f
    private var b3 = 0.0f
    private var b4 = 0.0f
    private var b5 = 0.0f
    private var b6 = 0.0f

    fun configure(sr: Float) {
        sampleRate = sr
        phase = 0.0
        sweepPhase = 0.0
        sweepTime = 0.0
    }

    fun generateBlock(buffer: FloatArray, offset: Int, count: Int, type: SyntheticSignalType) {
        if (type == SyntheticSignalType.OFF) return

        when (type) {
            SyntheticSignalType.SINE_1KHZ -> generateSine(buffer, offset, count, 1000f, 0.5f)
            SyntheticSignalType.SINE_100HZ -> generateSine(buffer, offset, count, 100f, 0.5f)
            SyntheticSignalType.SINE_10KHZ -> generateSine(buffer, offset, count, 10000f, 0.5f)
            SyntheticSignalType.SWEEP_20_20K -> generateLogSweep(buffer, offset, count)
            SyntheticSignalType.WHITE_NOISE -> generateWhiteNoise(buffer, offset, count, 0.3f)
            SyntheticSignalType.PINK_NOISE -> generatePinkNoise(buffer, offset, count, 0.3f)
            SyntheticSignalType.SPEECH_SIM -> generateSpeechSim(buffer, offset, count)
            SyntheticSignalType.IMPULSE -> generateImpulse(buffer, offset, count)
            SyntheticSignalType.HIGH_AMP_STRESS -> generateSine(buffer, offset, count, 1000f, 1.414f) // +3dBFS overshoot
            SyntheticSignalType.OFF -> {}
        }
    }

    private fun generateSine(buffer: FloatArray, offset: Int, count: Int, freqHz: Float, amplitude: Float) {
        val phaseInc = 2.0 * PI * freqHz / sampleRate
        for (i in offset until (offset + count)) {
            buffer[i] = (sin(phase) * amplitude).toFloat()
            phase += phaseInc
            if (phase > 2.0 * PI) phase -= 2.0 * PI
        }
    }

    private fun generateLogSweep(buffer: FloatArray, offset: Int, count: Int) {
        val fStart = 20.0
        val fEnd = 20000.0
        val dt = 1.0 / sampleRate

        for (i in offset until (offset + count)) {
            sweepTime += dt
            if (sweepTime >= sweepDurationSec) {
                sweepTime = 0.0
            }
            val normT = sweepTime / sweepDurationSec
            val instantaneousFreq = fStart * Math.pow(fEnd / fStart, normT)
            sweepPhase += 2.0 * PI * instantaneousFreq * dt
            if (sweepPhase > 2.0 * PI) sweepPhase -= 2.0 * PI
            buffer[i] = (sin(sweepPhase) * 0.5).toFloat()
        }
    }

    private fun generateWhiteNoise(buffer: FloatArray, offset: Int, count: Int, amplitude: Float) {
        for (i in offset until (offset + count)) {
            val r = Random.nextFloat() * 2.0f - 1.0f
            buffer[i] = r * amplitude
        }
    }

    private fun generatePinkNoise(buffer: FloatArray, offset: Int, count: Int, amplitude: Float) {
        for (i in offset until (offset + count)) {
            val white = Random.nextFloat() * 2.0f - 1.0f
            b0 = 0.99886f * b0 + white * 0.0555179f
            b1 = 0.99332f * b1 + white * 0.0750759f
            b2 = 0.96900f * b2 + white * 0.1538520f
            b3 = 0.86650f * b3 + white * 0.3104856f
            b4 = 0.55000f * b4 + white * 0.5329522f
            b5 = -0.7616f * b5 - white * 0.0168980f
            val pink = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362f) * 0.11f
            b6 = white * 0.115926f
            buffer[i] = pink * amplitude
        }
    }

    private fun generateSpeechSim(buffer: FloatArray, offset: Int, count: Int) {
        val fundamental = 130.0 // Hz (Male/Female voice pitch)
        val phaseInc = 2.0 * PI * fundamental / sampleRate

        for (i in offset until (offset + count)) {
            // Formant synthesis (Fundamental + F1 700Hz + F2 1500Hz + F3 2800Hz + breath noise)
            val h1 = sin(phase) * 0.4
            val h2 = sin(phase * 2.0) * 0.25
            val h3 = sin(phase * 3.0) * 0.18
            val f1 = sin(phase * 5.4) * 0.35 // ~700 Hz
            val f2 = sin(phase * 11.5) * 0.20 // ~1500 Hz
            val f3 = sin(phase * 21.5) * 0.12 // ~2800 Hz
            val breath = (Random.nextFloat() * 2f - 1f) * 0.03

            buffer[i] = ((h1 + h2 + h3 + f1 + f2 + f3 + breath) * 0.4).toFloat()

            phase += phaseInc
            if (phase > 2.0 * PI) phase -= 2.0 * PI
        }
    }

    private fun generateImpulse(buffer: FloatArray, offset: Int, count: Int) {
        buffer.fill(0f, offset, offset + count)
        if (count > 0) {
            buffer[offset] = 1.0f // Single full-scale impulse
        }
    }
}
