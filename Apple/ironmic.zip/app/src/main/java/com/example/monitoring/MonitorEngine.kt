package com.example.monitoring

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.pow

data class MonitorState(
    val isEnabled: Boolean = false,
    val volumeGainDb: Float = 0.0f,
    val directBlend: Float = 0.0f, // 0 = 100% processed, 1 = 100% direct
    val isHeadphonesConnected: Boolean = false,
    val feedbackRiskActive: Boolean = false,
    val isEmergencyMuted: Boolean = false,
    val roundtripLatencyMs: Float = 6.4f
)

class MonitorEngine(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _monitorState = MutableStateFlow(MonitorState())
    val monitorState: StateFlow<MonitorState> = _monitorState.asStateFlow()

    private var audioTrack: AudioTrack? = null
    private var sampleRate = 48000
    private var bufferSizeFrames = 256
    private var isPlaying = false

    private val playBuffer = FloatArray(1024)

    init {
        checkHeadphoneState()
    }

    fun checkHeadphoneState() {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val isHeadphones = devices.any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            it.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
        }

        val feedbackRisk = !isHeadphones && _monitorState.value.isEnabled
        _monitorState.value = _monitorState.value.copy(
            isHeadphonesConnected = isHeadphones,
            feedbackRiskActive = feedbackRisk
        )
    }

    fun configure(sr: Int) {
        sampleRate = sr
        if (isPlaying) {
            stop()
            start()
        }
    }

    fun toggleMonitoring(enabled: Boolean) {
        if (enabled) {
            checkHeadphoneState()
            _monitorState.value = _monitorState.value.copy(isEnabled = true, isEmergencyMuted = false)
            start()
        } else {
            _monitorState.value = _monitorState.value.copy(isEnabled = false)
            stop()
        }
    }

    fun setVolumeGain(gainDb: Float) {
        _monitorState.value = _monitorState.value.copy(volumeGainDb = gainDb)
    }

    fun setDirectBlend(blend: Float) {
        _monitorState.value = _monitorState.value.copy(directBlend = blend.coerceIn(0f, 1f))
    }

    fun emergencyMute() {
        _monitorState.value = _monitorState.value.copy(isEmergencyMuted = true)
    }

    private fun start() {
        if (isPlaying) return
        try {
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_FLOAT
            )
            val bufSize = minBuf.coerceAtLeast(1024)

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufSize)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()
            isPlaying = true

            // Calculate estimated output latency
            val latencyFrames = bufSize / 4
            val latencyMs = (latencyFrames.toFloat() / sampleRate) * 1000f
            _monitorState.value = _monitorState.value.copy(roundtripLatencyMs = latencyMs + 2.5f)
        } catch (_: Exception) {
            isPlaying = false
        }
    }

    fun writeAudio(processedSamples: FloatArray, rawSamples: FloatArray, count: Int) {
        if (!isPlaying || !_monitorState.value.isEnabled || _monitorState.value.isEmergencyMuted) return
        val track = audioTrack ?: return

        val state = _monitorState.value
        val blend = state.directBlend
        var linearVol = 10.0f.pow(state.volumeGainDb / 20.0f)

        // Safety volume reduction if feedback risk
        if (state.feedbackRiskActive) {
            linearVol = linearVol.coerceAtMost(0.12f) // max -18dBFS
        }

        val writeCount = count.coerceAtMost(playBuffer.size)
        for (i in 0 until writeCount) {
            val mixed = processedSamples[i] * (1.0f - blend) + rawSamples[i] * blend
            playBuffer[i] = (mixed * linearVol).coerceIn(-1.0f, 1.0f)
        }

        track.write(playBuffer, 0, writeCount, AudioTrack.WRITE_NON_BLOCKING)
    }

    private fun stop() {
        isPlaying = false
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (_: Exception) {}
    }

    fun release() {
        stop()
    }
}
