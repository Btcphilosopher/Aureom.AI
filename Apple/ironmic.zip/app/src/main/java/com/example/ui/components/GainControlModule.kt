package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelBorderActive
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun GainControlModule(
    digitalGainDb: Float,
    isLocked: Boolean,
    onGainChanged: (Float) -> Unit,
    onToggleLock: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, if (isLocked) PanelBorder else PanelBorderActive, RoundedCornerShape(8.dp))
            .padding(12.dp)
            .testTag("gain_control_module")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header with Gain readout and Lock Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DIGITAL PREAMP GAIN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = SignalAmber,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Clean 64-bit float gain stage",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMuted
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = String.format(Locale.US, "%+.1f dB", digitalGainDb),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (digitalGainDb > 12f) SignalRed else if (digitalGainDb > 0f) SignalAmber else SignalGreen
                    )

                    OutlinedButton(
                        onClick = onToggleLock,
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("gain_lock_button"),
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isLocked) SignalAmber.copy(alpha = 0.15f) else Color.Transparent,
                            contentColor = if (isLocked) SignalAmber else TextSecondary
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(if (isLocked) SignalAmber else PanelBorder)
                        )
                    ) {
                        Text(
                            text = if (isLocked) "LOCKED" else "UNLOCK",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Slider Fader
            Slider(
                value = digitalGainDb,
                onValueChange = { if (!isLocked) onGainChanged(it) },
                valueRange = -24f..24f,
                steps = 95, // 0.5 dB steps
                enabled = !isLocked,
                colors = SliderDefaults.colors(
                    thumbColor = SignalAmber,
                    activeTrackColor = SignalAmber,
                    inactiveTrackColor = PanelBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gain_slider")
            )

            // Nudge Buttons (-3dB, -0.5dB, 0dB Reset, +0.5dB, +3dB)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                NudgeButton(label = "-3 dB", enabled = !isLocked) {
                    onGainChanged((digitalGainDb - 3.0f).coerceIn(-24f, 24f))
                }
                NudgeButton(label = "-0.5 dB", enabled = !isLocked) {
                    onGainChanged((digitalGainDb - 0.5f).coerceIn(-24f, 24f))
                }
                NudgeButton(label = "0 dB UNITY", enabled = !isLocked, isAccent = true) {
                    onGainChanged(0.0f)
                }
                NudgeButton(label = "+0.5 dB", enabled = !isLocked) {
                    onGainChanged((digitalGainDb + 0.5f).coerceIn(-24f, 24f))
                }
                NudgeButton(label = "+3 dB", enabled = !isLocked) {
                    onGainChanged((digitalGainDb + 3.0f).coerceIn(-24f, 24f))
                }
            }
        }
    }
}

@Composable
fun NudgeButton(
    label: String,
    enabled: Boolean,
    isAccent: Boolean = false,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.height(28.dp),
        shape = RoundedCornerShape(4.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color.Transparent,
            contentColor = if (isAccent) SignalCyan else TextSecondary
        ),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = androidx.compose.ui.graphics.SolidColor(if (isAccent) SignalCyan.copy(alpha = 0.5f) else PanelBorder)
        )
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
    }
}
