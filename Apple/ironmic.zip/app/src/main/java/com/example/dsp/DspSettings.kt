package com.example.dsp

data class EqBandConfig(
    val id: Int,
    val name: String,
    val type: FilterType = FilterType.PEAK,
    val frequency: Float = 1000f,
    val gainDb: Float = 0f,
    val q: Float = 1.0f,
    val enabled: Boolean = true
)

enum class FilterType {
    LOW_SHELF,
    PEAK,
    HIGH_SHELF,
    HIGH_PASS,
    LOW_PASS
}

enum class EqPreset(val label: String) {
    NEUTRAL("Neutral / Flat"),
    SPEECH("Speech Clarity"),
    PODCAST("Broadcast Podcast"),
    INTERVIEW("Field Interview"),
    FIELD("Field Nature"),
    MUSIC("Acoustic Music"),
    DEEP_VOICE("Deep Voice Body"),
    BRIGHT_VOICE("Air & Brightness")
}

data class DspSettings(
    val mode: ProcessingMode = ProcessingMode.RAW,
    val digitalGainDb: Float = 0.0f,
    val gainLocked: Boolean = false,
    val autoGainEnabled: Boolean = false,

    // HPF
    val hpfEnabled: Boolean = true,
    val hpfCutoffHz: Float = 80f,
    val hpfSlopeDbPerOct: Int = 18, // 6, 12, 18, 24

    // Parametric EQ
    val eqEnabled: Boolean = true,
    val eqBands: List<EqBandConfig> = defaultEqBands(),

    // Compressor
    val compressorEnabled: Boolean = false,
    val compThresholdDb: Float = -18f,
    val compRatio: Float = 3.0f,
    val compAttackMs: Float = 8.0f,
    val compReleaseMs: Float = 90.0f,
    val compKneeDb: Float = 6.0f,
    val compMakeupGainDb: Float = 0.0f,

    // Limiter
    val limiterEnabled: Boolean = true,
    val limiterCeilingDbtp: Float = -1.0f,
    val limiterReleaseMs: Float = 50.0f,

    // Noise Control
    val noiseGateEnabled: Boolean = false,
    val noiseGateThresholdDb: Float = -45.0f,
    val noiseGateHysteresisDb: Float = 4.0f,
    val expanderRatio: Float = 2.0f,
    val spectralNoiseReductionEnabled: Boolean = false,
    val spectralNoiseReductionDb: Float = 6.0f,

    // Wind Filter
    val windFilterEnabled: Boolean = false,
    val windSensitivity: Float = 1.0f,

    // De-Esser
    val deEsserEnabled: Boolean = false,
    val deEsserFrequencyHz: Float = 6500f,
    val deEsserThresholdDb: Float = -20f,

    // Saturation & Power
    val saturationEnabled: Boolean = false,
    val saturationDriveDb: Float = 3.0f,
    val powerIntensity: Float = 50.0f // 0 to 100
) {
    companion object {
        fun defaultEqBands(): List<EqBandConfig> = listOf(
            EqBandConfig(0, "HPF Sub", FilterType.HIGH_PASS, frequency = 40f, gainDb = 0f, q = 0.707f),
            EqBandConfig(1, "Low Shelf", FilterType.LOW_SHELF, frequency = 120f, gainDb = 0f, q = 0.707f),
            EqBandConfig(2, "Low Mid", FilterType.PEAK, frequency = 450f, gainDb = 0f, q = 1.2f),
            EqBandConfig(3, "Mid Presence", FilterType.PEAK, frequency = 2500f, gainDb = 0f, q = 1.5f),
            EqBandConfig(4, "High Clarity", FilterType.PEAK, frequency = 5000f, gainDb = 0f, q = 1.5f),
            EqBandConfig(5, "High Shelf Air", FilterType.HIGH_SHELF, frequency = 10000f, gainDb = 0f, q = 0.707f)
        )

        fun presetBands(preset: EqPreset): List<EqBandConfig> {
            return when (preset) {
                EqPreset.NEUTRAL -> defaultEqBands()
                EqPreset.SPEECH -> listOf(
                    EqBandConfig(0, "HPF Sub", FilterType.HIGH_PASS, 80f, 0f, 0.707f),
                    EqBandConfig(1, "Low Mud Cut", FilterType.PEAK, 250f, -2.5f, 1.4f),
                    EqBandConfig(2, "Body", FilterType.PEAK, 700f, +1.0f, 1.2f),
                    EqBandConfig(3, "Intelligibility", FilterType.PEAK, 3000f, +3.5f, 1.5f),
                    EqBandConfig(4, "Consonant Clarity", FilterType.PEAK, 5500f, +2.0f, 1.3f),
                    EqBandConfig(5, "Air Shelf", FilterType.HIGH_SHELF, 11000f, +1.5f, 0.707f)
                )
                EqPreset.PODCAST -> listOf(
                    EqBandConfig(0, "HPF Sub", FilterType.HIGH_PASS, 70f, 0f, 0.707f),
                    EqBandConfig(1, "Warm Lows", FilterType.LOW_SHELF, 150f, +2.0f, 0.707f),
                    EqBandConfig(2, "Boxiness Cut", FilterType.PEAK, 400f, -3.0f, 1.6f),
                    EqBandConfig(3, "Presence", FilterType.PEAK, 2800f, +2.5f, 1.4f),
                    EqBandConfig(4, "Sheen", FilterType.PEAK, 6000f, +2.0f, 1.2f),
                    EqBandConfig(5, "Air Shelf", FilterType.HIGH_SHELF, 12000f, +2.0f, 0.707f)
                )
                EqPreset.INTERVIEW -> listOf(
                    EqBandConfig(0, "HPF Sub", FilterType.HIGH_PASS, 90f, 0f, 0.707f),
                    EqBandConfig(1, "Rumble Cut", FilterType.PEAK, 180f, -2.0f, 1.5f),
                    EqBandConfig(2, "Voice Fundamental", FilterType.PEAK, 500f, +1.0f, 1.2f),
                    EqBandConfig(3, "Speech Punch", FilterType.PEAK, 2200f, +3.0f, 1.5f),
                    EqBandConfig(4, "Top End", FilterType.PEAK, 4800f, +1.5f, 1.2f),
                    EqBandConfig(5, "High Cut", FilterType.LOW_PASS, 14000f, 0f, 0.707f)
                )
                EqPreset.FIELD -> listOf(
                    EqBandConfig(0, "HPF Sub", FilterType.HIGH_PASS, 100f, 0f, 0.707f),
                    EqBandConfig(1, "Wind Low Cut", FilterType.LOW_SHELF, 120f, -4.0f, 0.707f),
                    EqBandConfig(2, "Mid Nature", FilterType.PEAK, 1000f, 0f, 1.0f),
                    EqBandConfig(3, "Foliage Detail", FilterType.PEAK, 4000f, +1.5f, 1.2f),
                    EqBandConfig(4, "Critter Shimmer", FilterType.PEAK, 8000f, +2.0f, 1.0f),
                    EqBandConfig(5, "Air Shelf", FilterType.HIGH_SHELF, 12000f, +1.0f, 0.707f)
                )
                EqPreset.MUSIC -> listOf(
                    EqBandConfig(0, "HPF Sub", FilterType.HIGH_PASS, 35f, 0f, 0.707f),
                    EqBandConfig(1, "Low Warmth", FilterType.LOW_SHELF, 100f, +1.5f, 0.707f),
                    EqBandConfig(2, "Mid Scoop", FilterType.PEAK, 600f, -1.5f, 1.0f),
                    EqBandConfig(3, "Instrument Core", FilterType.PEAK, 2500f, +1.0f, 1.2f),
                    EqBandConfig(4, "Harmonics", FilterType.PEAK, 7000f, +2.0f, 1.1f),
                    EqBandConfig(5, "Silk Air", FilterType.HIGH_SHELF, 14000f, +2.5f, 0.707f)
                )
                EqPreset.DEEP_VOICE -> listOf(
                    EqBandConfig(0, "HPF Sub", FilterType.HIGH_PASS, 60f, 0f, 0.707f),
                    EqBandConfig(1, "Chest Body", FilterType.LOW_SHELF, 110f, +3.5f, 0.707f),
                    EqBandConfig(2, "Boominess Cut", FilterType.PEAK, 220f, -2.5f, 1.8f),
                    EqBandConfig(3, "Articulate", FilterType.PEAK, 3200f, +3.0f, 1.4f),
                    EqBandConfig(4, "Crisp Edge", FilterType.PEAK, 6500f, +1.5f, 1.2f),
                    EqBandConfig(5, "Air", FilterType.HIGH_SHELF, 10000f, +1.0f, 0.707f)
                )
                EqPreset.BRIGHT_VOICE -> listOf(
                    EqBandConfig(0, "HPF Sub", FilterType.HIGH_PASS, 80f, 0f, 0.707f),
                    EqBandConfig(1, "Fullness", FilterType.LOW_SHELF, 180f, +1.5f, 0.707f),
                    EqBandConfig(2, "Nasal Notch", FilterType.PEAK, 1200f, -2.0f, 2.0f),
                    EqBandConfig(3, "Smooth Mid", FilterType.PEAK, 3000f, +1.0f, 1.0f),
                    EqBandConfig(4, "De-Harsh", FilterType.PEAK, 5800f, -1.5f, 2.2f),
                    EqBandConfig(5, "Brilliance", FilterType.HIGH_SHELF, 11000f, +3.0f, 0.707f)
                )
            }
        }
    }
}
