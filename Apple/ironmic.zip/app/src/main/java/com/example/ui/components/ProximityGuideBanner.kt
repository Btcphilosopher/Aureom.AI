package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.ProximityStatus
import com.example.audio.ProximityTarget
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ProximityGuideBanner(
    status: ProximityStatus,
    target: ProximityTarget,
    onSelectTarget: (ProximityTarget) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("proximity_guide_banner")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACOUSTIC PROXIMITY & GAIN GUIDE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber,
                    letterSpacing = 1.sp
                )

                Text(
                    text = when (status) {
                        ProximityStatus.TOO_FAR -> "INCREASE LEVEL / MOVE CLOSER"
                        ProximityStatus.TARGET -> "OPTIMAL LEVEL & DISTANCE"
                        ProximityStatus.TOO_CLOSE -> "BACK OFF / LOWER GAIN"
                    },
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = when (status) {
                        ProximityStatus.TOO_FAR -> SignalAmber
                        ProximityStatus.TARGET -> SignalGreen
                        ProximityStatus.TOO_CLOSE -> SignalRed
                    }
                )
            }

            // Target selector row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ProximityTarget.values().forEach { t ->
                    val isSelected = (t == target)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                color = if (isSelected) SignalAmber.copy(alpha = 0.2f) else androidx.compose.ui.graphics.Color(0xFF161A20),
                                shape = RoundedCornerShape(3.dp)
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) SignalAmber else PanelBorder,
                                shape = RoundedCornerShape(3.dp)
                            )
                            .clickable { onSelectTarget(t) }
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = t.name,
                            fontSize = 8.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontFamily = FontFamily.Monospace,
                            color = if (isSelected) SignalAmber else TextSecondary
                        )
                    }
                }
            }
        }
    }
}
