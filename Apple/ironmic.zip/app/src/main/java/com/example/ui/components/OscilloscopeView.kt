package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun RealTimeOscilloscopeView(
    waveform: FloatArray,
    modifier: Modifier = Modifier,
    timebaseMs: Float = 10f
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("realtime_oscilloscope_view")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "OSCILLOSCOPE (TIME DOMAIN)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalGreen,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "TIMEBASE: ${timebaseMs.toInt()} ms | TRIG: ZERO-X",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary
                )
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .background(CarbonDark, RoundedCornerShape(4.dp))
                    .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
            ) {
                val w = size.width
                val h = size.height
                val midY = h / 2f

                // Draw Reticle Grid
                val divisionsX = 10
                for (i in 1 until divisionsX) {
                    val x = i * (w / divisionsX)
                    drawLine(
                        color = Color(0x1A00E676),
                        start = Offset(x, 0f),
                        end = Offset(x, h),
                        strokeWidth = 1f
                    )
                }

                // Center Zero-Line
                drawLine(
                    color = Color(0x4000E676),
                    start = Offset(0f, midY),
                    end = Offset(w, midY),
                    strokeWidth = 1.5f
                )

                // Draw Waveform trace
                if (waveform.isNotEmpty()) {
                    val path = Path()
                    val count = waveform.size
                    val dx = w / (count - 1).coerceAtLeast(1)

                    for (i in 0 until count) {
                        val sample = waveform[i].coerceIn(-1.0f, 1.0f)
                        val x = i * dx
                        val y = midY - (sample * (midY * 0.9f))

                        if (i == 0) {
                            path.moveTo(x, y)
                        } else {
                            path.lineTo(x, y)
                        }
                    }

                    // Glow line effect
                    drawPath(
                        path = path,
                        color = SignalGreen.copy(alpha = 0.3f),
                        style = Stroke(width = 4.0f, cap = StrokeCap.Round)
                    )

                    drawPath(
                        path = path,
                        color = SignalGreen,
                        style = Stroke(width = 2.0f, cap = StrokeCap.Round)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "+1.0 FS",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
                Text(
                    text = "0.0 (DC NULL)",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
                Text(
                    text = "-1.0 FS",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
            }
        }
    }
}
