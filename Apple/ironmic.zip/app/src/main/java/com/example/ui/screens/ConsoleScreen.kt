package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.IronMicViewModel
import com.example.ui.components.GainControlModule
import com.example.ui.components.MasterVuMeter
import com.example.ui.components.ModeSelectorBar
import com.example.ui.components.MonitoringStrip
import com.example.ui.components.ProximityGuideBanner
import com.example.ui.components.RealTimeOscilloscopeView
import com.example.ui.components.RealTimeSpectrumView
import com.example.ui.components.RecordControlPanel
import com.example.ui.components.SignalChainDiagram

@Composable
fun ConsoleScreen(
    viewModel: IronMicViewModel,
    modifier: Modifier = Modifier
) {
    val meterReading by viewModel.meterReading.collectAsState()
    val recordingSession by viewModel.recordingSession.collectAsState()
    val spectrumMagnitudes by viewModel.spectrumMagnitudes.collectAsState()
    val scopeWaveform by viewModel.scopeWaveform.collectAsState()
    val dspSettings by viewModel.dspSettingsState.collectAsState()
    val dspTelemetry by viewModel.dspTelemetry.collectAsState()
    val monitorState by viewModel.monitorState.collectAsState()
    val captureConfig by viewModel.captureConfigState.collectAsState()
    val engineDiagnostics by viewModel.engineDiagnostics.collectAsState()
    val proximityStatus by viewModel.proximityStatus.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("console_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Master Hardware VU Meter
        MasterVuMeter(meterReading = meterReading)

        // 2. Real-Time FFT Spectrum Analyzer
        RealTimeSpectrumView(
            magnitudes = spectrumMagnitudes,
            fftSize = 2048
        )

        // 3. Time-Domain Oscilloscope
        RealTimeOscilloscopeView(
            waveform = scopeWaveform,
            timebaseMs = 10f
        )

        // 4. Record Engine Control Console
        RecordControlPanel(
            session = recordingSession,
            sampleRate = captureConfig.sampleRate,
            bitDepthBits = captureConfig.bitDepth.bits,
            onRecordToggle = { viewModel.toggleRecording() },
            onStopRecord = { viewModel.stopRecording() },
            onAddMarker = { viewModel.addTakeMarker(it) }
        )

        // 5. Preamp Gain Stage
        GainControlModule(
            digitalGainDb = dspSettings.digitalGainDb,
            isLocked = dspSettings.gainLocked,
            onGainChanged = { viewModel.setDigitalGainDb(it) },
            onToggleLock = { viewModel.toggleGainLock() }
        )

        // 6. Processing Mode Selector
        ModeSelectorBar(
            currentMode = dspSettings.mode,
            onModeSelected = { viewModel.setProcessingMode(it) }
        )

        // 7. Live Headphone Monitoring Strip
        MonitoringStrip(
            monitorState = monitorState,
            onToggleMonitoring = { viewModel.toggleMonitoring(it) },
            onVolumeChanged = { viewModel.setMonitorVolume(it) },
            onBlendChanged = { viewModel.setMonitorBlend(it) },
            onEmergencyMute = { viewModel.emergencyMute() }
        )

        // 8. Acoustic Proximity Guide
        ProximityGuideBanner(
            status = proximityStatus,
            target = viewModel.audioEngine.activeProximityTarget,
            onSelectTarget = { viewModel.setProximityTarget(it) }
        )

        // 9. Signal Chain Block Diagram
        SignalChainDiagram(
            dspSettings = dspSettings,
            telemetry = dspTelemetry,
            audioSource = engineDiagnostics.audioSourceUsed
        )
    }
}
