package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dsp.SyntheticSignalType
import com.example.ui.IronMicViewModel
import com.example.ui.components.RealTimeOscilloscopeView
import com.example.ui.components.RealTimeSpectrumView
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SignalGeneratorScreen(
    viewModel: IronMicViewModel,
    modifier: Modifier = Modifier
) {
    val activeSignal by viewModel.activeSyntheticType.collectAsState()
    val spectrumMagnitudes by viewModel.spectrumMagnitudes.collectAsState()
    val scopeWaveform by viewModel.scopeWaveform.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("signal_generator_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "SYNTHETIC SIGNAL INJECTOR & DSP TEST LAB",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Inject pure mathematical waveforms directly into the preamp pipeline to verify filter curves, compressor envelope ballistics, and spectrum linearity.",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Default,
                    color = TextSecondary,
                    lineHeight = 14.sp
                )
            }
        }

        // Signal Types List
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SyntheticSignalType.values().forEach { type ->
                    val isSelected = (type == activeSignal)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = if (isSelected) SignalCyan.copy(alpha = 0.2f) else Color(0xFF161A20),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .border(1.dp, if (isSelected) SignalCyan else PanelBorder, RoundedCornerShape(4.dp))
                            .clickable { viewModel.setSyntheticSignal(type) }
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = type.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontFamily = FontFamily.Monospace,
                                color = if (isSelected) SignalCyan else TextPrimary
                            )
                            Text(
                                text = if (isSelected) "ENGAGED" else if (type == SyntheticSignalType.OFF) "LIVE MIC" else "ARM",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (isSelected) SignalCyan else TextMuted
                            )
                        }
                    }
                }
            }
        }

        // Real-Time Visualizers
        RealTimeSpectrumView(magnitudes = spectrumMagnitudes, fftSize = 2048)
        RealTimeOscilloscopeView(waveform = scopeWaveform, timebaseMs = 10f)
    }
}
