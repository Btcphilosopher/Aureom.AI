package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.dsp.MeterReading
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.MeterCautionAmber
import com.example.ui.theme.MeterDangerRed
import com.example.ui.theme.MeterInactive
import com.example.ui.theme.MeterSafeGreen
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun MasterVuMeter(
    meterReading: MeterReading,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
            .testTag("master_vu_meter")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header with numeric dBFS readings & Clip LED
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "MASTER INPUT METER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = SignalAmber,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = String.format(
                            Locale.US,
                            "PEAK: %+.1f dBFS  |  RMS: %+.1f dBFS  |  LUFS-M: %+.1f",
                            meterReading.peakDbfs,
                            meterReading.rmsDbfs,
                            meterReading.lufsMomentary
                        ),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary
                    )
                }

                // Clip Warning LED Indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val isClipped = meterReading.peakDbfs >= -0.1f || meterReading.clipCount > 0
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                color = if (isClipped) SignalRed else Color(0xFF331111),
                                shape = RoundedCornerShape(50)
                            )
                            .border(1.dp, if (isClipped) SignalRed else PanelBorder, RoundedCornerShape(50))
                    )
                    Text(
                        text = if (isClipped) "CLIP (${meterReading.clipCount})" else "NORM",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isClipped) SignalRed else TextMuted
                    )
                }
            }

            // Dual segmented LED bar (Left / Right or Peak / RMS)
            SegmentedLedBar(
                peakDbfs = meterReading.peakDbfs,
                rmsDbfs = meterReading.rmsDbfs,
                truePeakDbtp = meterReading.truePeakDbtp
            )

            // Tick Scale (-60 to 0 dBFS)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("-60", "-48", "-36", "-24", "-18", "-12", "-6", "-3", "0", "+3").forEach { tick ->
                    Text(
                        text = tick,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = when (tick) {
                            "0", "+3" -> SignalRed
                            "-6", "-3" -> SignalAmber
                            else -> TextMuted
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun SegmentedLedBar(
    peakDbfs: Float,
    rmsDbfs: Float,
    truePeakDbtp: Float,
    modifier: Modifier = Modifier
) {
    val totalSegments = 40
    val minDb = -60.0f
    val maxDb = +3.0f

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .background(CarbonDark, RoundedCornerShape(4.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 4.dp)
    ) {
        val segmentWidth = (size.width - (totalSegments - 1) * 2f) / totalSegments
        val segmentHeight = size.height

        for (i in 0 until totalSegments) {
            val segmentDb = minDb + (i.toFloat() / totalSegments) * (maxDb - minDb)
            val isRmsLit = rmsDbfs >= segmentDb
            val isPeakLit = peakDbfs >= segmentDb
            val isTruePeakLit = (truePeakDbtp >= segmentDb && truePeakDbtp < (segmentDb + 1.5f))

            val segmentColor = when {
                segmentDb >= 0.0f -> MeterDangerRed
                segmentDb >= -12.0f -> MeterCautionAmber
                else -> MeterSafeGreen
            }

            val finalColor = when {
                isTruePeakLit -> SignalRed
                isPeakLit -> segmentColor
                isRmsLit -> segmentColor.copy(alpha = 0.65f)
                else -> MeterInactive
            }

            val x = i * (segmentWidth + 2f)
            drawRoundRect(
                color = finalColor,
                topLeft = Offset(x, 0f),
                size = Size(segmentWidth, segmentHeight),
                cornerRadius = CornerRadius(1.5f, 1.5f)
            )
        }
    }
}
