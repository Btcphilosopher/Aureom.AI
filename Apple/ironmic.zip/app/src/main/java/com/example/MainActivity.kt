package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.audio.RecordState
import com.example.dsp.ProcessingMode
import com.example.ui.AppTab
import com.example.ui.IronMicViewModel
import com.example.ui.screens.ConsoleScreen
import com.example.ui.screens.DeviceLabScreen
import com.example.ui.screens.DspMixerScreen
import com.example.ui.screens.InstrumentsScreen
import com.example.ui.screens.SignalGeneratorScreen
import com.example.ui.screens.TakesLibraryScreen
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelDark
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    private val viewModel: IronMicViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                IronMicMainApp(viewModel)
            }
        }
    }
}

@Composable
fun IronMicMainApp(viewModel: IronMicViewModel) {
    val context = LocalContext.current
    val activeTab by viewModel.activeTab.collectAsState()
    val recordingSession by viewModel.recordingSession.collectAsState()
    val dspSettings by viewModel.dspSettingsState.collectAsState()
    val captureConfig by viewModel.captureConfigState.collectAsState()
    val engineDiagnostics by viewModel.engineDiagnostics.collectAsState()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasMicPermission = results[Manifest.permission.RECORD_AUDIO] == true
    }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = CarbonDark,
        topBar = {
            IronMicHeaderBar(
                activeMode = dspSettings.mode,
                sampleRate = captureConfig.sampleRate,
                bitDepthBits = captureConfig.bitDepth.bits,
                isRecording = recordingSession.state == RecordState.RECORDING,
                xRuns = engineDiagnostics.xRuns
            )
        },
        bottomBar = {
            IronMicBottomNavigation(
                activeTab = activeTab,
                onSelectTab = { viewModel.selectTab(it) }
            )
        }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = CarbonDark
        ) {
            when (activeTab) {
                AppTab.CONSOLE -> ConsoleScreen(viewModel = viewModel)
                AppTab.DSP_MIXER -> DspMixerScreen(viewModel = viewModel)
                AppTab.INSTRUMENTS -> InstrumentsScreen(viewModel = viewModel)
                AppTab.DEVICE_LAB -> DeviceLabScreen(viewModel = viewModel)
                AppTab.TAKES -> TakesLibraryScreen(viewModel = viewModel)
                AppTab.SYNTH_LAB -> SignalGeneratorScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun IronMicHeaderBar(
    activeMode: ProcessingMode,
    sampleRate: Int,
    bitDepthBits: Int,
    isRecording: Boolean,
    xRuns: Int
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelDark)
            .border(1.dp, PanelBorder)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("ironmic_header_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand Title & Status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(if (isRecording) SignalRed else SignalGreen, CircleShape)
                        .border(1.dp, if (isRecording) SignalRed else SignalGreen, CircleShape)
                )

                Column {
                    Text(
                        text = "IRONMIC",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = TextPrimary,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "INSTRUMENT V3.6",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMuted
                    )
                }
            }

            // Engine Profile & Status badges
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Mode Badge
                Box(
                    modifier = Modifier
                        .background(SignalAmber.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .border(1.dp, SignalAmber.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = activeMode.name,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = SignalAmber
                    )
                }

                // Sample Rate & Bit Depth
                Box(
                    modifier = Modifier
                        .background(PanelElevated, RoundedCornerShape(4.dp))
                        .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "${sampleRate / 1000}k/${bitDepthBits}b",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = SignalCyan
                    )
                }

                // XRun Indicator (Dropouts)
                if (xRuns > 0) {
                    Box(
                        modifier = Modifier
                            .background(SignalRed.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .border(1.dp, SignalRed, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "XRUN: $xRuns",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SignalRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IronMicBottomNavigation(
    activeTab: AppTab,
    onSelectTab: (AppTab) -> Unit
) {
    NavigationBar(
        containerColor = PanelDark,
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, PanelBorder)
            .testTag("ironmic_bottom_navigation")
    ) {
        AppTab.values().forEach { tab ->
            val isSelected = (tab == activeTab)
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectTab(tab) },
                icon = {
                    Text(
                        text = tab.iconLabel,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isSelected) SignalAmber else TextMuted
                    )
                },
                label = {
                    Text(
                        text = tab.title,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (isSelected) SignalAmber else TextSecondary
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = SignalAmber.copy(alpha = 0.15f),
                    selectedIconColor = SignalAmber,
                    unselectedIconColor = TextMuted,
                    selectedTextColor = SignalAmber,
                    unselectedTextColor = TextSecondary
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
