package com.example.recording

import android.os.SystemClock
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

data class TakeMarker(
    val timestampMs: Long,
    val samplePosition: Long,
    val label: String,
    val peakDbfs: Float
)

class WavWriter(
    val file: File,
    val sampleRate: Int,
    val bitDepth: Int,
    val channelCount: Int
) {
    private var outputStream: FileOutputStream? = null
    private var totalSamplesWritten: Long = 0
    private var isClosed = false
    private val byteBuffer = ByteBuffer.allocate(8192).order(ByteOrder.LITTLE_ENDIAN)

    val markers = mutableListOf<TakeMarker>()

    init {
        outputStream = FileOutputStream(file)
        writePlaceholderHeader()
    }

    private fun writePlaceholderHeader() {
        val header = ByteArray(44)
        outputStream?.write(header)
    }

    fun writeSamples(floatSamples: FloatArray, count: Int) {
        if (isClosed) return
        val fos = outputStream ?: return

        byteBuffer.clear()

        when (bitDepth) {
            16 -> {
                for (i in 0 until count) {
                    val clamped = floatSamples[i].coerceIn(-1.0f, 1.0f)
                    val s16 = (clamped * 32767.0f).roundToInt().toShort()
                    if (byteBuffer.remaining() < 2) {
                        fos.write(byteBuffer.array(), 0, byteBuffer.position())
                        byteBuffer.clear()
                    }
                    byteBuffer.putShort(s16)
                }
            }
            24 -> {
                for (i in 0 until count) {
                    val clamped = floatSamples[i].coerceIn(-1.0f, 1.0f)
                    val s24 = (clamped * 8388607.0f).roundToInt()
                    if (byteBuffer.remaining() < 3) {
                        fos.write(byteBuffer.array(), 0, byteBuffer.position())
                        byteBuffer.clear()
                    }
                    byteBuffer.put((s24 and 0xFF).toByte())
                    byteBuffer.put(((s24 shr 8) and 0xFF).toByte())
                    byteBuffer.put(((s24 shr 16) and 0xFF).toByte())
                }
            }
            32 -> {
                for (i in 0 until count) {
                    val sample = floatSamples[i]
                    if (byteBuffer.remaining() < 4) {
                        fos.write(byteBuffer.array(), 0, byteBuffer.position())
                        byteBuffer.clear()
                    }
                    byteBuffer.putFloat(sample)
                }
            }
            else -> {
                // Default to 16
                for (i in 0 until count) {
                    val clamped = floatSamples[i].coerceIn(-1.0f, 1.0f)
                    val s16 = (clamped * 32767.0f).roundToInt().toShort()
                    if (byteBuffer.remaining() < 2) {
                        fos.write(byteBuffer.array(), 0, byteBuffer.position())
                        byteBuffer.clear()
                    }
                    byteBuffer.putShort(s16)
                }
            }
        }

        if (byteBuffer.position() > 0) {
            fos.write(byteBuffer.array(), 0, byteBuffer.position())
            byteBuffer.clear()
        }

        totalSamplesWritten += count
    }

    fun addMarker(label: String, peakDbfs: Float, elapsedMs: Long) {
        markers.add(
            TakeMarker(
                timestampMs = elapsedMs,
                samplePosition = totalSamplesWritten,
                label = label,
                peakDbfs = peakDbfs
            )
        )
    }

    fun finalizeAndClose() {
        if (isClosed) return
        isClosed = true

        try {
            outputStream?.flush()
            outputStream?.close()
        } catch (_: Exception) {}

        // Patch RIFF & DATA chunk headers with true byte sizes
        try {
            val bytesPerSample = bitDepth / 8
            val audioDataBytes = totalSamplesWritten * bytesPerSample
            val riffChunkSize = 36 + audioDataBytes
            val byteRate = sampleRate * channelCount * bytesPerSample
            val blockAlign = (channelCount * bytesPerSample).toShort()
            val formatCode: Short = if (bitDepth == 32) 3 /* IEEE FLOAT */ else 1 /* PCM */

            RandomAccessFile(file, "rw").use { raf ->
                raf.seek(0)
                // "RIFF"
                raf.writeBytes("RIFF")
                // Total file size minus 8
                raf.write(intToLittleEndian(riffChunkSize.toInt()))
                // "WAVE"
                raf.writeBytes("WAVE")
                // "fmt "
                raf.writeBytes("fmt ")
                // Subchunk1Size (16 for PCM/Float)
                raf.write(intToLittleEndian(16))
                // AudioFormat (1 = PCM, 3 = IEEE Float)
                raf.write(shortToLittleEndian(formatCode))
                // NumChannels
                raf.write(shortToLittleEndian(channelCount.toShort()))
                // SampleRate
                raf.write(intToLittleEndian(sampleRate))
                // ByteRate
                raf.write(intToLittleEndian(byteRate))
                // BlockAlign
                raf.write(shortToLittleEndian(blockAlign))
                // BitsPerSample
                raf.write(shortToLittleEndian(bitDepth.toShort()))
                // "data"
                raf.writeBytes("data")
                // Subchunk2Size
                raf.write(intToLittleEndian(audioDataBytes.toInt()))
            }
        } catch (_: Exception) {}
    }

    private fun intToLittleEndian(v: Int): ByteArray {
        return byteArrayOf(
            (v and 0xFF).toByte(),
            ((v shr 8) and 0xFF).toByte(),
            ((v shr 16) and 0xFF).toByte(),
            ((v shr 24) and 0xFF).toByte()
        )
    }

    private fun shortToLittleEndian(v: Short): ByteArray {
        val i = v.toInt()
        return byteArrayOf(
            (i and 0xFF).toByte(),
            ((i shr 8) and 0xFF).toByte()
        )
    }
}
