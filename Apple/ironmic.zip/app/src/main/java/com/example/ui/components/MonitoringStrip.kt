package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.monitoring.MonitorState
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun MonitoringStrip(
    monitorState: MonitorState,
    onToggleMonitoring: (Boolean) -> Unit,
    onVolumeChanged: (Float) -> Unit,
    onBlendChanged: (Float) -> Unit,
    onEmergencyMute: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
            .testTag("monitoring_strip")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header: Toggle, Latency & Feedback warning
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIVE HEADPHONE MONITOR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = SignalCyan,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "LATENCY: ~${String.format(Locale.US, "%.1f", monitorState.roundtripLatencyMs)} ms | ${if (monitorState.isHeadphonesConnected) "HP CONNECTED" else "NO HP (SPEAKER SAFEGUARD)"}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (monitorState.feedbackRiskActive) SignalRed else TextSecondary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (monitorState.isEnabled) {
                        OutlinedButton(
                            onClick = onEmergencyMute,
                            modifier = Modifier.height(30.dp),
                            shape = RoundedCornerShape(4.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (monitorState.isEmergencyMuted) SignalRed.copy(alpha = 0.2f) else Color.Transparent,
                                contentColor = SignalRed
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(SignalRed))
                        ) {
                            Text("MUTE", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedButton(
                        onClick = { onToggleMonitoring(!monitorState.isEnabled) },
                        modifier = Modifier
                            .height(30.dp)
                            .testTag("monitor_toggle_button"),
                        shape = RoundedCornerShape(4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (monitorState.isEnabled) SignalCyan.copy(alpha = 0.15f) else Color.Transparent,
                            contentColor = if (monitorState.isEnabled) SignalCyan else TextSecondary
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = SolidColor(if (monitorState.isEnabled) SignalCyan else PanelBorder)
                        )
                    ) {
                        Text(
                            text = if (monitorState.isEnabled) "ON" else "OFF",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (monitorState.isEnabled) {
                // Monitor Volume Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "VOLUME: ${String.format(Locale.US, "%+.1f dB", monitorState.volumeGainDb)}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary
                    )
                    Text(
                        text = "BLEND: ${((1f - monitorState.directBlend) * 100).toInt()}% DSP / ${(monitorState.directBlend * 100).toInt()}% DIR",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = SignalAmber
                    )
                }

                Slider(
                    value = monitorState.volumeGainDb,
                    onValueChange = onVolumeChanged,
                    valueRange = -36f..6f,
                    colors = SliderDefaults.colors(
                        thumbColor = SignalCyan,
                        activeTrackColor = SignalCyan,
                        inactiveTrackColor = PanelBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
