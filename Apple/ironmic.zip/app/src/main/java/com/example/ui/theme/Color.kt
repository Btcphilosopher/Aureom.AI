package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CarbonDark = Color(0xFF090A0D)
val PanelDark = Color(0xFF13161B)
val PanelElevated = Color(0xFF1C2128)
val PanelBorder = Color(0xFF2B333E)
val PanelBorderActive = Color(0xFF424F60)

// Meter & Signal Colors
val SignalAmber = Color(0xFFFF9D00)
val SignalAmberDark = Color(0xFF9E6100)
val SignalGreen = Color(0xFF00E676)
val SignalCyan = Color(0xFF00E5FF)
val SignalRed = Color(0xFFFF3D00)
val SignalRedGlow = Color(0x66FF3D00)

// Text & Status
val TextPrimary = Color(0xFFF0F3F6)
val TextSecondary = Color(0xFF9BA7B4)
val TextMuted = Color(0xFF5C6773)
val TextAmber = Color(0xFFFFB300)
val TextCyan = Color(0xFF80D8FF)

// LED Meter Segment Colors
val MeterSafeGreen = Color(0xFF00E676)
val MeterCautionAmber = Color(0xFFFFB300)
val MeterDangerRed = Color(0xFFFF1744)
val MeterInactive = Color(0xFF1E252D)
