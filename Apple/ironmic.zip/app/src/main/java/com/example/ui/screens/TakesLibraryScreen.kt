package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TakeEntity
import com.example.ui.IronMicViewModel
import com.example.ui.components.formatTimecode
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelBorderActive
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TakesLibraryScreen(
    viewModel: IronMicViewModel,
    modifier: Modifier = Modifier
) {
    val takes by viewModel.allTakes.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("takes_library_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Library Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FIELD RECORDINGS & TAKES LIBRARY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = SignalAmber,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${takes.size} RECORDED TAKES STORED LOCALLY",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary
                    )
                }
            }
        }

        // Active Player Bar (if playing)
        if (playbackState.currentTakeId != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PanelElevated, RoundedCornerShape(8.dp))
                    .border(1.dp, SignalCyan, RoundedCornerShape(8.dp))
                    .padding(10.dp)
                    .testTag("take_player_bar")
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PREVIEW PLAYER: ${formatTimecode(playbackState.currentPositionMs)} / ${formatTimecode(playbackState.durationMs)}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SignalCyan
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.togglePlayback() },
                                modifier = Modifier.height(26.dp),
                                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = SignalCyan),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(SignalCyan))
                            ) {
                                Text(if (playbackState.isPlaying) "PAUSE" else "PLAY", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                            OutlinedButton(
                                onClick = { viewModel.stopPlayback() },
                                modifier = Modifier.height(26.dp),
                                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = TextMuted),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(PanelBorder))
                            ) {
                                Text("CLOSE", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Slider(
                        value = playbackState.currentPositionMs.toFloat(),
                        onValueChange = { viewModel.seekPlayback(it.toLong()) },
                        valueRange = 0f..playbackState.durationMs.toFloat().coerceAtLeast(1f),
                        colors = SliderDefaults.colors(thumbColor = SignalCyan, activeTrackColor = SignalCyan, inactiveTrackColor = PanelBorder),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // List of Takes
        if (takes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(PanelElevated, RoundedCornerShape(8.dp))
                    .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "NO RECORDINGS YET",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary
                    )
                    Text(
                        text = "Arm the recording console to capture pristine audio takes.",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Default,
                        color = TextMuted
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(takes, key = { it.id }) { take ->
                    TakeItemCard(
                        take = take,
                        isPlaying = playbackState.currentTakeId == take.id && playbackState.isPlaying,
                        onPlay = { viewModel.playTake(take) },
                        onDelete = { viewModel.deleteTake(take) },
                        onSaveNote = { note -> viewModel.updateTakeNote(take, note) }
                    )
                }
            }
        }
    }
}

@Composable
fun TakeItemCard(
    take: TakeEntity,
    isPlaying: Boolean,
    onPlay: () -> Unit,
    onDelete: () -> Unit,
    onSaveNote: (String) -> Unit
) {
    var isEditingNote by remember { mutableStateOf(false) }
    var noteText by remember(take.notes) { mutableStateOf(take.notes) }

    val formattedDate = remember(take.createdAt) {
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(take.createdAt))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, if (isPlaying) SignalCyan else PanelBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("take_card_${take.id}")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = take.filename,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isPlaying) SignalCyan else TextPrimary
                    )
                    Text(
                        text = "$formattedDate | ${formatTimecode(take.durationMs)} | ${(take.fileSize / 1024 / 1024)} MB",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = onPlay,
                        modifier = Modifier.height(28.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isPlaying) SignalCyan.copy(alpha = 0.2f) else Color.Transparent,
                            contentColor = SignalCyan
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(if (isPlaying) SignalCyan else PanelBorder))
                    ) {
                        Text(if (isPlaying) "PAUSE" else "PLAY", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onDelete,
                        modifier = Modifier.height(28.dp),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = SignalRed),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(PanelBorder))
                    ) {
                        Text("DEL", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // Audio Spec badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${take.sampleRate / 1000}kHz / ${take.bitDepth}-bit | ${take.processingMode}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber
                )
                Text(
                    text = "PK: ${String.format(Locale.US, "%.1fdB", take.peakDbfs)} | I-LUFS: ${String.format(Locale.US, "%.1f", take.integratedLufs)}",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = SignalGreen
                )
            }

            // Note Editor
            if (isEditingNote) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Add field session notes...", fontSize = 10.sp, color = TextMuted) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SignalCyan,
                            unfocusedBorderColor = PanelBorder,
                            focusedContainerColor = CarbonDark,
                            unfocusedContainerColor = CarbonDark
                        )
                    )
                    OutlinedButton(
                        onClick = {
                            onSaveNote(noteText)
                            isEditingNote = false
                        },
                        modifier = Modifier.height(36.dp),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = SignalCyan),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(SignalCyan))
                    ) {
                        Text("SAVE", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isEditingNote = true }
                        .background(CarbonDark, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (take.notes.isNotBlank()) "NOTE: ${take.notes}" else "+ Add field notes...",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (take.notes.isNotBlank()) TextPrimary else TextMuted
                    )
                    Text("EDIT", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = SignalCyan)
                }
            }
        }
    }
}
