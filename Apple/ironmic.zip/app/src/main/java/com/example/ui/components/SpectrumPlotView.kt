package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlin.math.log10

@Composable
fun RealTimeSpectrumView(
    magnitudes: FloatArray,
    modifier: Modifier = Modifier,
    fftSize: Int = 2048
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
            .testTag("realtime_spectrum_view")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FFT SPECTRUM ANALYZER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalCyan,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "$fftSize PTS | 20 Hz - 20 kHz",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextSecondary
                )
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(CarbonDark, RoundedCornerShape(4.dp))
                    .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
            ) {
                val w = size.width
                val h = size.height

                // Draw dB grid lines (-80, -60, -40, -20, 0 dB)
                val dbLines = listOf(0f, -20f, -40f, -60f, -80f)
                dbLines.forEach { db ->
                    val y = ((0f - db) / 100f) * h
                    drawLine(
                        color = Color(0x22FFFFFF),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                // Draw Frequency vertical grid lines
                val freqMarkers = listOf(100f, 1000f, 10000f)
                val logMin = kotlin.math.ln(20.0)
                val logMax = kotlin.math.ln(20000.0)

                freqMarkers.forEach { freq ->
                    val normX = ((kotlin.math.ln(freq.toDouble()) - logMin) / (logMax - logMin)).toFloat()
                    val x = normX * w
                    drawLine(
                        color = Color(0x2200E5FF),
                        start = Offset(x, 0f),
                        end = Offset(x, h),
                        strokeWidth = 1f
                    )
                }

                if (magnitudes.isNotEmpty()) {
                    val path = Path()
                    val fillPath = Path()

                    val binCount = magnitudes.size
                    val dx = w / (binCount - 1).coerceAtLeast(1)

                    fillPath.moveTo(0f, h)

                    for (i in 0 until binCount) {
                        val mag = magnitudes[i].coerceIn(-100f, 0f)
                        val normY = (0f - mag) / 100f // 0dB at top, -100dB at bottom
                        val x = i * dx
                        val y = (normY * h).coerceIn(0f, h)

                        if (i == 0) {
                            path.moveTo(x, y)
                            fillPath.lineTo(x, y)
                        } else {
                            path.lineTo(x, y)
                            fillPath.lineTo(x, y)
                        }
                    }

                    fillPath.lineTo(w, h)
                    fillPath.close()

                    // Draw gradient fill under spectrum curve
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                SignalCyan.copy(alpha = 0.35f),
                                SignalAmber.copy(alpha = 0.10f),
                                Color.Transparent
                            )
                        )
                    )

                    // Draw primary stroke line
                    drawPath(
                        path = path,
                        color = SignalCyan,
                        style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                    )
                }
            }

            // Frequency Labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("20Hz", "100Hz", "500Hz", "1kHz", "5kHz", "10kHz", "20kHz").forEach { label ->
                    Text(
                        text = label,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMuted
                    )
                }
            }
        }
    }
}
