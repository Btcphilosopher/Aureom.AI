package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val IronMicDarkColorScheme = darkColorScheme(
    primary = SignalAmber,
    onPrimary = Color.Black,
    primaryContainer = PanelElevated,
    onPrimaryContainer = SignalAmber,
    secondary = SignalCyan,
    onSecondary = Color.Black,
    secondaryContainer = PanelDark,
    onSecondaryContainer = SignalCyan,
    tertiary = SignalGreen,
    onTertiary = Color.Black,
    background = CarbonDark,
    onBackground = TextPrimary,
    surface = PanelDark,
    onSurface = TextPrimary,
    surfaceVariant = PanelElevated,
    onSurfaceVariant = TextSecondary,
    outline = PanelBorder,
    outlineVariant = PanelBorderActive,
    error = SignalRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = IronMicDarkColorScheme,
        typography = Typography,
        content = content
    )
}
