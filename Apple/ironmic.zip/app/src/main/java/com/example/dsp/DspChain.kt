package com.example.dsp

import kotlin.math.pow

data class DspTelemetry(
    val processingTimeUs: Long = 0,
    val dspLoadPercent: Float = 0.0f,
    val compGainReductionDb: Float = 0.0f,
    val limiterGainReductionDb: Float = 0.0f,
    val deEsserReductionDb: Float = 0.0f,
    val windSeverity: WindSeverity = WindSeverity.NONE,
    val windRatio: Float = 0.0f,
    val noiseGateOpen: Boolean = true
)

class DspChain(var sampleRate: Float = 48000f) {
    val hpf = HighPassFilter(sampleRate)
    val eq = ParametricEQ(sampleRate)
    val compressor = Compressor(sampleRate)
    val limiter = Limiter(sampleRate)
    val noiseGate = NoiseGate(sampleRate)
    val windFilter = WindFilter(sampleRate)
    val deEsser = DeEsser(sampleRate)
    val saturation = Saturation()

    private var digitalGainLinear = 1.0f
    private var isRawBypass = true
    private var powerIntensity = 50.0f

    @Volatile
    var currentTelemetry = DspTelemetry()
        private set

    fun applySettings(settings: DspSettings, sr: Float) {
        sampleRate = sr
        isRawBypass = (settings.mode == ProcessingMode.RAW || settings.mode == ProcessingMode.MEASUREMENT)

        digitalGainLinear = 10.0f.pow(settings.digitalGainDb / 20.0f)
        powerIntensity = settings.powerIntensity

        when (settings.mode) {
            ProcessingMode.RAW -> {
                // All DSP completely bypassed
                hpf.configure(80f, 18, sampleRate, false)
                eq.configure(emptyList(), sampleRate, false)
                compressor.configure(false, -18f, 3f, 8f, 90f, 6f, 0f, sampleRate)
                limiter.configure(false, -1.0f, 50f, sampleRate)
                noiseGate.configure(false, -45f, 4f, 2f, sampleRate)
                windFilter.configure(false, 1.0f, sampleRate)
                deEsser.configure(false, 6500f, -20f, sampleRate)
                saturation.configure(false, 0f)
            }
            ProcessingMode.CLEAN -> {
                hpf.configure(40f, 12, sampleRate, true)
                eq.configure(emptyList(), sampleRate, false)
                compressor.configure(false, -18f, 2f, 10f, 100f, 6f, 0f, sampleRate)
                limiter.configure(true, -1.0f, 50f, sampleRate)
                noiseGate.configure(true, -55f, 4f, 1.5f, sampleRate) // gentle expander
                windFilter.configure(false, 1.0f, sampleRate)
                deEsser.configure(false, 6500f, -20f, sampleRate)
                saturation.configure(false, 0f)
            }
            ProcessingMode.VOICE -> {
                hpf.configure(80f, 18, sampleRate, true)
                val voiceBands = DspSettings.presetBands(EqPreset.SPEECH)
                eq.configure(voiceBands, sampleRate, true)
                compressor.configure(true, -18f, 3.2f, 8f, 85f, 6f, 2.5f, sampleRate)
                limiter.configure(true, -1.0f, 40f, sampleRate)
                noiseGate.configure(true, -44f, 4f, 2.5f, sampleRate)
                windFilter.configure(false, 1.0f, sampleRate)
                deEsser.configure(true, 6500f, -18f, sampleRate)
                saturation.configure(false, 0f)
            }
            ProcessingMode.FIELD -> {
                hpf.configure(100f, 24, sampleRate, true)
                val fieldBands = DspSettings.presetBands(EqPreset.FIELD)
                eq.configure(fieldBands, sampleRate, true)
                compressor.configure(true, -20f, 2.5f, 15f, 120f, 6f, 1.0f, sampleRate)
                limiter.configure(true, -1.0f, 40f, sampleRate)
                noiseGate.configure(true, -50f, 4f, 2.0f, sampleRate)
                windFilter.configure(true, 1.5f, sampleRate)
                deEsser.configure(false, 6500f, -20f, sampleRate)
                saturation.configure(false, 0f)
            }
            ProcessingMode.STUDIO -> {
                hpf.configure(20f, 6, sampleRate, true)
                eq.configure(emptyList(), sampleRate, false) // flat response
                compressor.configure(false, -18f, 2f, 10f, 100f, 6f, 0f, sampleRate)
                limiter.configure(settings.limiterEnabled, settings.limiterCeilingDbtp, settings.limiterReleaseMs, sampleRate)
                noiseGate.configure(false, -50f, 4f, 2f, sampleRate)
                windFilter.configure(false, 1.0f, sampleRate)
                deEsser.configure(false, 6500f, -20f, sampleRate)
                saturation.configure(false, 0f)
            }
            ProcessingMode.POWER -> {
                val p = (settings.powerIntensity / 100f).coerceIn(0f, 1f)
                hpf.configure(90f, 18, sampleRate, true)
                val powerBands = listOf(
                    EqBandConfig(0, "Sub Cut", FilterType.HIGH_PASS, 90f, 0f, 0.707f),
                    EqBandConfig(1, "Chest Punch", FilterType.PEAK, 200f, +1.5f * p, 1.4f),
                    EqBandConfig(2, "Mud Scoop", FilterType.PEAK, 500f, -2.5f * p, 1.5f),
                    EqBandConfig(3, "Presence Roar", FilterType.PEAK, 2800f, +4.5f * p, 1.6f),
                    EqBandConfig(4, "Top Sheen", FilterType.HIGH_SHELF, 8000f, +3.0f * p, 0.707f)
                )
                eq.configure(powerBands, sampleRate, true)
                val ratio = 3.5f + 3.0f * p
                val threshold = -22f - 4f * p
                val makeup = 3.0f + 5.0f * p
                compressor.configure(true, threshold, ratio, 4.0f, 60.0f, 8.0f, makeup, sampleRate)
                limiter.configure(true, -0.5f, 30.0f, sampleRate)
                noiseGate.configure(true, -40f, 5f, 3.0f, sampleRate)
                windFilter.configure(false, 1.0f, sampleRate)
                deEsser.configure(true, 6200f, -16f, sampleRate)
                saturation.configure(true, (2.0f + 6.0f * p), 0.9f)
            }
            ProcessingMode.MEASUREMENT -> {
                // Pure linear transmission, no non-linearities, safety limiter optional
                hpf.configure(10f, 6, sampleRate, false)
                eq.configure(emptyList(), sampleRate, false)
                compressor.configure(false, 0f, 1f, 10f, 100f, 0f, 0f, sampleRate)
                limiter.configure(false, 0f, 50f, sampleRate)
                noiseGate.configure(false, -90f, 0f, 1f, sampleRate)
                windFilter.configure(false, 1.0f, sampleRate)
                deEsser.configure(false, 6500f, -20f, sampleRate)
                saturation.configure(false, 0f)
            }
        }
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int, totalBlockBudgetUs: Long) {
        val startTime = System.nanoTime()

        // 1. Digital Gain Stage
        if (digitalGainLinear != 1.0f) {
            for (i in offset until (offset + count)) {
                buffer[i] *= digitalGainLinear
            }
        }

        if (!isRawBypass) {
            // 2. High Pass Filter
            hpf.processBlock(buffer, offset, count)

            // 3. Wind Filter
            windFilter.processBlock(buffer, offset, count)

            // 4. Noise Gate / Expander
            noiseGate.processBlock(buffer, offset, count)

            // 5. Parametric EQ
            eq.processBlock(buffer, offset, count)

            // 6. Compressor
            compressor.processBlock(buffer, offset, count)

            // 7. De-Esser
            deEsser.processBlock(buffer, offset, count)

            // 8. Saturation
            saturation.processBlock(buffer, offset, count)

            // 9. Safety Limiter
            limiter.processBlock(buffer, offset, count)
        } else {
            // Just check clipping in Limiter in RAW mode
            limiter.processBlock(buffer, offset, count)
        }

        val elapsedNs = System.nanoTime() - startTime
        val elapsedUs = elapsedNs / 1000L
        val dspLoad = if (totalBlockBudgetUs > 0) {
            (elapsedUs.toFloat() / totalBlockBudgetUs) * 100.0f
        } else {
            0.0f
        }

        currentTelemetry = DspTelemetry(
            processingTimeUs = elapsedUs,
            dspLoadPercent = dspLoad.coerceIn(0f, 100f),
            compGainReductionDb = compressor.currentGainReductionDb,
            limiterGainReductionDb = limiter.gainReductionDb,
            deEsserReductionDb = deEsser.activeReductionDb,
            windSeverity = windFilter.detectedSeverity,
            windRatio = windFilter.windEnergyRatio,
            noiseGateOpen = noiseGate.isOpen
        )
    }

    fun reset() {
        hpf.reset()
        eq.reset()
        compressor.reset()
        limiter.reset()
        noiseGate.reset()
        windFilter.reset()
        deEsser.reset()
        currentTelemetry = DspTelemetry()
    }
}
