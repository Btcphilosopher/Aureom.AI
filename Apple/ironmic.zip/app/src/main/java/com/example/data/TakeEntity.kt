package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "takes")
data class TakeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val filename: String,
    val filePath: String,
    val createdAt: Long = System.currentTimeMillis(),
    val durationMs: Long,
    val sampleRate: Int,
    val bitDepth: Int,
    val channels: Int,
    val fileSize: Long,
    val peakDbfs: Float,
    val integratedLufs: Float,
    val truePeakDbtp: Float,
    val notes: String = "",
    val processingMode: String = "RAW",
    val markersJson: String = "[]"
)
