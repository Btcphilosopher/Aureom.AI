package com.example.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Standard biquad IIR section using Transposed Direct Form II with denormal clamping.
 */
class BiquadFilter {
    private var b0 = 1.0f
    private var b1 = 0.0f
    private var b2 = 0.0f
    private var a1 = 0.0f
    private var a2 = 0.0f

    private var z1 = 0.0f
    private var z2 = 0.0f

    fun reset() {
        z1 = 0.0f
        z2 = 0.0f
    }

    fun setCoefficients(nb0: Float, nb1: Float, nb2: Float, na0: Float, na1: Float, na2: Float) {
        val invA0 = 1.0f / na0
        b0 = nb0 * invA0
        b1 = nb1 * invA0
        b2 = nb2 * invA0
        a1 = na1 * invA0
        a2 = na2 * invA0
    }

    fun processSample(input: Float): Float {
        val output = b0 * input + z1
        z1 = b1 * input - a1 * output + z2
        z2 = b2 * input - a2 * output

        // Anti-denormal protection
        if (z1 > -1e-15f && z1 < 1e-15f) z1 = 0.0f
        if (z2 > -1e-15f && z2 < 1e-15f) z2 = 0.0f

        return output
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        for (i in offset until (offset + count)) {
            buffer[i] = processSample(buffer[i])
        }
    }

    companion object {
        fun highPass(sampleRate: Float, cutoffHz: Float, q: Float = 0.707f): BiquadFilter {
            val filter = BiquadFilter()
            val omega = (2.0 * PI * cutoffHz.coerceIn(10f, sampleRate * 0.49f) / sampleRate).toFloat()
            val cosOmega = cos(omega)
            val sinOmega = sin(omega)
            val alpha = sinOmega / (2.0f * q.coerceAtLeast(0.1f))

            val b0 = (1.0f + cosOmega) / 2.0f
            val b1 = -(1.0f + cosOmega)
            val b2 = (1.0f + cosOmega) / 2.0f
            val a0 = 1.0f + alpha
            val a1 = -2.0f * cosOmega
            val a2 = 1.0f - alpha

            filter.setCoefficients(b0, b1, b2, a0, a1, a2)
            return filter
        }

        fun lowPass(sampleRate: Float, cutoffHz: Float, q: Float = 0.707f): BiquadFilter {
            val filter = BiquadFilter()
            val omega = (2.0 * PI * cutoffHz.coerceIn(20f, sampleRate * 0.49f) / sampleRate).toFloat()
            val cosOmega = cos(omega)
            val sinOmega = sin(omega)
            val alpha = sinOmega / (2.0f * q.coerceAtLeast(0.1f))

            val b0 = (1.0f - cosOmega) / 2.0f
            val b1 = 1.0f - cosOmega
            val b2 = (1.0f - cosOmega) / 2.0f
            val a0 = 1.0f + alpha
            val a1 = -2.0f * cosOmega
            val a2 = 1.0f - alpha

            filter.setCoefficients(b0, b1, b2, a0, a1, a2)
            return filter
        }

        fun peak(sampleRate: Float, centerFreqHz: Float, gainDb: Float, q: Float): BiquadFilter {
            val filter = BiquadFilter()
            val a = Math.pow(10.0, (gainDb / 40.0).toDouble()).toFloat()
            val omega = (2.0 * PI * centerFreqHz.coerceIn(20f, sampleRate * 0.49f) / sampleRate).toFloat()
            val cosOmega = cos(omega)
            val sinOmega = sin(omega)
            val alpha = sinOmega / (2.0f * q.coerceAtLeast(0.1f))

            val b0 = 1.0f + alpha * a
            val b1 = -2.0f * cosOmega
            val b2 = 1.0f - alpha * a
            val a0 = 1.0f + alpha / a
            val a1 = -2.0f * cosOmega
            val a2 = 1.0f - alpha / a

            filter.setCoefficients(b0, b1, b2, a0, a1, a2)
            return filter
        }

        fun lowShelf(sampleRate: Float, cutoffHz: Float, gainDb: Float, slope: Float = 1.0f): BiquadFilter {
            val filter = BiquadFilter()
            val a = Math.pow(10.0, (gainDb / 40.0).toDouble()).toFloat()
            val omega = (2.0 * PI * cutoffHz.coerceIn(20f, sampleRate * 0.49f) / sampleRate).toFloat()
            val cosOmega = cos(omega)
            val sinOmega = sin(omega)
            val alpha = (sinOmega / 2.0f) * sqrt((a + 1.0f / a) * (1.0f / slope - 1.0f) + 2.0f)
            val twoSqrtAAlpha = 2.0f * sqrt(a) * alpha

            val b0 = a * ((a + 1.0f) - (a - 1.0f) * cosOmega + twoSqrtAAlpha)
            val b1 = 2.0f * a * ((a - 1.0f) - (a + 1.0f) * cosOmega)
            val b2 = a * ((a + 1.0f) - (a - 1.0f) * cosOmega - twoSqrtAAlpha)
            val a0 = (a + 1.0f) + (a - 1.0f) * cosOmega + twoSqrtAAlpha
            val a1 = -2.0f * ((a - 1.0f) + (a + 1.0f) * cosOmega)
            val a2 = (a + 1.0f) + (a - 1.0f) * cosOmega - twoSqrtAAlpha

            filter.setCoefficients(b0, b1, b2, a0, a1, a2)
            return filter
        }

        fun highShelf(sampleRate: Float, cutoffHz: Float, gainDb: Float, slope: Float = 1.0f): BiquadFilter {
            val filter = BiquadFilter()
            val a = Math.pow(10.0, (gainDb / 40.0).toDouble()).toFloat()
            val omega = (2.0 * PI * cutoffHz.coerceIn(20f, sampleRate * 0.49f) / sampleRate).toFloat()
            val cosOmega = cos(omega)
            val sinOmega = sin(omega)
            val alpha = (sinOmega / 2.0f) * sqrt((a + 1.0f / a) * (1.0f / slope - 1.0f) + 2.0f)
            val twoSqrtAAlpha = 2.0f * sqrt(a) * alpha

            val b0 = a * ((a + 1.0f) + (a - 1.0f) * cosOmega + twoSqrtAAlpha)
            val b1 = -2.0f * a * ((a - 1.0f) + (a + 1.0f) * cosOmega)
            val b2 = a * ((a + 1.0f) + (a - 1.0f) * cosOmega - twoSqrtAAlpha)
            val a0 = (a + 1.0f) - (a - 1.0f) * cosOmega + twoSqrtAAlpha
            val a1 = 2.0f * ((a - 1.0f) - (a + 1.0f) * cosOmega)
            val a2 = (a + 1.0f) - (a - 1.0f) * cosOmega - twoSqrtAAlpha

            filter.setCoefficients(b0, b1, b2, a0, a1, a2)
            return filter
        }

        fun bandPass(sampleRate: Float, centerFreqHz: Float, q: Float): BiquadFilter {
            val filter = BiquadFilter()
            val omega = (2.0 * PI * centerFreqHz.coerceIn(20f, sampleRate * 0.49f) / sampleRate).toFloat()
            val cosOmega = cos(omega)
            val sinOmega = sin(omega)
            val alpha = sinOmega / (2.0f * q.coerceAtLeast(0.1f))

            val b0 = alpha
            val b1 = 0.0f
            val b2 = -alpha
            val a0 = 1.0f + alpha
            val a1 = -2.0f * cosOmega
            val a2 = 1.0f - alpha

            filter.setCoefficients(b0, b1, b2, a0, a1, a2)
            return filter
        }
    }
}
