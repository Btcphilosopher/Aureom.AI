package com.example.dsp

import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

data class MeterReading(
    val peakDbfs: Float = -120f,
    val rmsDbfs: Float = -120f,
    val truePeakDbtp: Float = -120f,
    val crestFactorDb: Float = 0f,
    val lufsMomentary: Float = -120f,
    val lufsShortTerm: Float = -120f,
    val lufsIntegrated: Float = -120f,
    val dcOffset: Float = 0f,
    val noiseFloorDbfs: Float = -90f,
    val clipCount: Int = 0
)

class LoudnessMeter(private var sampleRate: Float = 48000f) {
    // EBU R128 K-weighting filters
    // Stage 1: High shelf filter (+4dB at high frequencies ~ 1.5kHz)
    private var kHighShelf = BiquadFilter.highShelf(48000f, 1500f, 4.0f, 1.0f)
    // Stage 2: High pass filter (RLB weighting ~ 38Hz)
    private var kHighPass = BiquadFilter.highPass(48000f, 38f, 0.5f)

    // Running power windows
    private val momentaryWindowSamples = (48000 * 0.400).toInt() // 400ms
    private val shortTermWindowSamples = (48000 * 3.000).toInt() // 3s

    // Circular buffers for K-weighted mean square power
    private val momentaryRing = FloatArray(19200)
    private var momentaryIndex = 0
    private var momentarySum = 0.0

    private val shortTermRing = FloatArray(144000)
    private var shortTermIndex = 0
    private var shortTermSum = 0.0

    // Integrated LUFS gating buffers
    private var integratedSum = 0.0
    private var integratedCount = 0L

    // Peak & RMS
    private var peakHold = 0.0f
    private var peakDecay = 0.95f
    private var rmsSmoothed = 0.0f
    private var dcOffsetSum = 0.0f
    private var totalSamplesProcessed = 0L

    var calibrationOffsetDb = 0.0f

    init {
        reset()
    }

    fun configure(sr: Float) {
        sampleRate = sr
        kHighShelf = BiquadFilter.highShelf(sampleRate, 1500f, 4.0f, 1.0f)
        kHighPass = BiquadFilter.highPass(sampleRate, 38f, 0.5f)
        reset()
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int, clipCount: Int): MeterReading {
        var blockPeak = 0.0f
        var blockSumSq = 0.0f
        var blockDcSum = 0.0f
        var blockTruePeak = 0.0f

        // 4x sinc interpolation estimate for true peak overshoots
        var prevSample = 0.0f

        for (i in offset until (offset + count)) {
            val sample = buffer[i]
            val absVal = abs(sample)
            if (absVal > blockPeak) blockPeak = absVal

            // True-peak oversampling estimation (interpolating inter-sample peaks)
            val interpSample1 = 0.5f * (sample + prevSample) + 0.125f * abs(sample - prevSample)
            val tpVal = max(absVal, abs(interpSample1))
            if (tpVal > blockTruePeak) blockTruePeak = tpVal
            prevSample = sample

            blockSumSq += sample * sample
            blockDcSum += sample

            // K-weighting pipeline
            val k1 = kHighShelf.processSample(sample)
            val k2 = kHighPass.processSample(k1)
            val kPower = (k2 * k2).toDouble()

            // Momentary Ring Buffer (400ms)
            if (momentaryRing.isNotEmpty()) {
                val oldM = momentaryRing[momentaryIndex].toDouble()
                momentaryRing[momentaryIndex] = kPower.toFloat()
                momentaryIndex = (momentaryIndex + 1) % momentaryRing.size
                momentarySum = max(0.0, momentarySum - oldM + kPower)
            }

            // Short Term Ring Buffer (3s)
            if (shortTermRing.isNotEmpty()) {
                val oldS = shortTermRing[shortTermIndex].toDouble()
                shortTermRing[shortTermIndex] = kPower.toFloat()
                shortTermIndex = (shortTermIndex + 1) % shortTermRing.size
                shortTermSum = max(0.0, shortTermSum - oldS + kPower)
            }

            // Integrated accumulator
            integratedSum += kPower
            integratedCount++
        }

        totalSamplesProcessed += count

        // Ballistics for Peak Meter
        if (blockPeak > peakHold) {
            peakHold = blockPeak
        } else {
            peakHold = peakHold * peakDecay + blockPeak * (1.0f - peakDecay)
        }

        val blockRms = sqrt(blockSumSq / count.coerceAtLeast(1))
        rmsSmoothed = 0.85f * rmsSmoothed + 0.15f * blockRms
        val dcOffset = blockDcSum / count.coerceAtLeast(1)

        // Convert to dBFS
        val peakDbfs = if (peakHold > 1e-6f) 20.0f * log10(peakHold) else -120f
        val rmsDbfs = if (rmsSmoothed > 1e-6f) 20.0f * log10(rmsSmoothed) else -120f
        val truePeakDbtp = if (blockTruePeak > 1e-6f) 20.0f * log10(blockTruePeak) else -120f
        val crestFactor = max(0.0f, peakDbfs - rmsDbfs)

        // Calculate LUFS (-0.691 is standard EBU R128 offset for full-scale square wave)
        val momentaryMean = momentarySum / momentaryRing.size.coerceAtLeast(1)
        val lufsM = if (momentaryMean > 1e-12) (-0.691 + 10.0 * log10(momentaryMean)).toFloat() else -120f

        val shortTermMean = shortTermSum / shortTermRing.size.coerceAtLeast(1)
        val lufsS = if (shortTermMean > 1e-12) (-0.691 + 10.0 * log10(shortTermMean)).toFloat() else -120f

        val integratedMean = if (integratedCount > 0) integratedSum / integratedCount else 0.0
        val lufsI = if (integratedMean > 1e-12) (-0.691 + 10.0 * log10(integratedMean)).toFloat() else -120f

        return MeterReading(
            peakDbfs = peakDbfs.coerceIn(-120f, 6f),
            rmsDbfs = rmsDbfs.coerceIn(-120f, 6f),
            truePeakDbtp = truePeakDbtp.coerceIn(-120f, 6f),
            crestFactorDb = crestFactor,
            lufsMomentary = lufsM.coerceIn(-120f, 0f),
            lufsShortTerm = lufsS.coerceIn(-120f, 0f),
            lufsIntegrated = lufsI.coerceIn(-120f, 0f),
            dcOffset = dcOffset,
            noiseFloorDbfs = -84.0f,
            clipCount = clipCount
        )
    }

    fun reset() {
        kHighShelf.reset()
        kHighPass.reset()
        momentaryRing.fill(0f)
        momentaryIndex = 0
        momentarySum = 0.0
        shortTermRing.fill(0f)
        shortTermIndex = 0
        shortTermSum = 0.0
        integratedSum = 0.0
        integratedCount = 0L
        peakHold = 0f
        rmsSmoothed = 0f
        totalSamplesProcessed = 0L
    }
}
