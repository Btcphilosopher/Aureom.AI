package com.example.dsp

enum class ProcessingMode(
    val title: String,
    val subtitle: String,
    val description: String
) {
    RAW(
        title = "RAW",
        subtitle = "Direct Hardware Capture",
        description = "Cleanest available input path. Complete DSP bypass. Real-time hardware diagnostics and raw metering."
    ),
    CLEAN(
        title = "CLEAN",
        subtitle = "Conditioned & Transparent",
        description = "Gentle 40 Hz sub-rumble cutoff and light transparent expansion. Preserves maximum dynamic range."
    ),
    VOICE(
        title = "VOICE",
        subtitle = "Optimised Speech Chain",
        description = "High-pass 80 Hz, speech-presence EQ, noise gate, vocal compressor (3:1), de-esser, and safety limiter."
    ),
    FIELD(
        title = "FIELD",
        subtitle = "Wind & Environmental Control",
        description = "Turbulence detection, adaptive sub-bass attenuation, 100 Hz high-pass, and transparent safety limiting."
    ),
    STUDIO(
        title = "STUDIO",
        subtitle = "Maximum Fidelity & Headroom",
        description = "Linear flat response, zero color, maximum dynamic headroom with optional transparent true-peak protection."
    ),
    POWER(
        title = "POWER",
        subtitle = "Aggressive Presence & Loudness",
        description = "Punchy multi-stage gain boost, tight compression, presence EQ boost, analog warmth saturation, and brickwall limiter."
    ),
    MEASUREMENT(
        title = "MEASUREMENT",
        subtitle = "Precision Acoustic Analysis",
        description = "Zero coloration, linear frequency response, calibrated metering, THD estimation, and silence noise-floor testing."
    )
}
