package com.example.dsp

import kotlin.math.abs

enum class ScopeTriggerMode {
    AUTO,
    RISING_EDGE,
    FALLING_EDGE
}

class OscilloscopeBuffer(val capacity: Int = 48000) {
    private val ringBuffer = FloatArray(capacity)
    @Volatile
    private var writeHead = 0

    fun write(samples: FloatArray, count: Int) {
        var head = writeHead
        for (i in 0 until count) {
            ringBuffer[head] = samples[i]
            head = (head + 1) % capacity
        }
        writeHead = head
    }

    /**
     * Extracts a time window of samples with optional zero-crossing stabilization.
     */
    fun extractWaveform(
        output: FloatArray,
        sampleRate: Float,
        timebaseMs: Float,
        triggerMode: ScopeTriggerMode = ScopeTriggerMode.AUTO
    ) {
        val totalRequestedSamples = ((timebaseMs / 1000f) * sampleRate).toInt().coerceIn(64, capacity / 2)
        val currentHead = writeHead
        val outputCount = output.size.coerceAtMost(1024)

        // Find trigger zero-crossing within the last window
        var triggerOffset = 0
        if (triggerMode != ScopeTriggerMode.AUTO) {
            val searchWindow = (sampleRate * 0.020f).toInt() // 20ms search
            var bestIdx = -1
            for (offset in 0 until searchWindow) {
                val idx1 = (currentHead - totalRequestedSamples - offset - 1 + capacity * 2) % capacity
                val idx2 = (currentHead - totalRequestedSamples - offset + capacity * 2) % capacity
                val s1 = ringBuffer[idx1]
                val s2 = ringBuffer[idx2]

                if (triggerMode == ScopeTriggerMode.RISING_EDGE && s1 <= 0f && s2 > 0f) {
                    bestIdx = offset
                    break
                } else if (triggerMode == ScopeTriggerMode.FALLING_EDGE && s1 >= 0f && s2 < 0f) {
                    bestIdx = offset
                    break
                }
            }
            if (bestIdx >= 0) {
                triggerOffset = bestIdx
            }
        }

        val startPos = (currentHead - totalRequestedSamples - triggerOffset + capacity * 2) % capacity
        val step = totalRequestedSamples.toFloat() / outputCount

        for (i in 0 until outputCount) {
            val sampleIdx = (startPos + (i * step).toInt()) % capacity
            output[i] = ringBuffer[sampleIdx]
        }
    }
}
