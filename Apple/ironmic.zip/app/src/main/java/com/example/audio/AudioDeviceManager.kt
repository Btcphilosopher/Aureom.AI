package com.example.audio

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioDeviceManager(private val context: Context) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val packageManager = context.packageManager

    private val _availableDevices = MutableStateFlow<List<AudioDeviceModel>>(emptyList())
    val availableDevices: StateFlow<List<AudioDeviceModel>> = _availableDevices.asStateFlow()

    private val _activeDevice = MutableStateFlow<AudioDeviceModel?>(null)
    val activeDevice: StateFlow<AudioDeviceModel?> = _activeDevice.asStateFlow()

    private val _capabilityMatrix = MutableStateFlow(HardwareCapabilityMatrix())
    val capabilityMatrix: StateFlow<HardwareCapabilityMatrix> = _capabilityMatrix.asStateFlow()

    private val _deviceEventNotice = MutableStateFlow<String?>(null)
    val deviceEventNotice: StateFlow<String?> = _deviceEventNotice.asStateFlow()

    private val deviceCallback = object : android.media.AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
            refreshDevices()
            val micAdded = addedDevices?.any { it.isSource } == true
            if (micAdded) {
                _deviceEventNotice.value = "New audio input device connected."
            }
        }

        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
            refreshDevices()
            val micRemoved = removedDevices?.any { it.isSource } == true
            if (micRemoved) {
                _deviceEventNotice.value = "Audio input device disconnected. Captured stream safeguarded."
            }
        }
    }

    init {
        audioManager.registerAudioDeviceCallback(deviceCallback, null)
        refreshDevices()
    }

    fun clearNotice() {
        _deviceEventNotice.value = null
    }

    fun refreshDevices() {
        val inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val hasLowLatency = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_LOW_LATENCY)
        val hasProAudio = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_PRO)
        val hasAec = AcousticEchoCanceler.isAvailable()
        val hasNs = NoiseSuppressor.isAvailable()
        val hasAgc = AutomaticGainControl.isAvailable()

        val list = inputDevices.map { dev ->
            val sampleRates = dev.sampleRates.toList().ifEmpty { listOf(44100, 48000) }
            val channels = dev.channelCounts.toList().ifEmpty { listOf(1, 2) }
            val encodings = dev.encodings.map { encToString(it) }

            val typeName = deviceTypeToString(dev.type)
            val name = if (dev.productName.isNotBlank()) dev.productName.toString() else typeName

            AudioDeviceModel(
                id = dev.id,
                productName = name,
                typeName = typeName,
                typeConstant = dev.type,
                isSource = dev.isSource,
                sampleRates = sampleRates,
                channelCounts = channels,
                encodings = encodings,
                isUnprocessedSupported = true,
                isLowLatencySupported = hasLowLatency,
                isProAudioSupported = hasProAudio,
                aecAvailable = hasAec,
                nsAvailable = hasNs,
                agcAvailable = hasAgc,
                isSelected = false
            )
        }

        _availableDevices.value = list

        val defaultDev = list.firstOrNull { it.typeConstant == AudioDeviceInfo.TYPE_USB_DEVICE || it.typeConstant == AudioDeviceInfo.TYPE_USB_HEADSET }
            ?: list.firstOrNull { it.typeConstant == AudioDeviceInfo.TYPE_WIRED_HEADSET }
            ?: list.firstOrNull { it.typeConstant == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            ?: list.firstOrNull()

        _activeDevice.value = defaultDev

        // Build hardware capability matrix
        testHardwareCapabilities(defaultDev)
    }

    fun selectDevice(deviceId: Int) {
        val found = _availableDevices.value.firstOrNull { it.id == deviceId }
        if (found != null) {
            _activeDevice.value = found
            _availableDevices.value = _availableDevices.value.map {
                it.copy(isSelected = (it.id == deviceId))
            }
            testHardwareCapabilities(found)
        }
    }

    private fun testHardwareCapabilities(device: AudioDeviceModel?) {
        val hasLowLatency = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_LOW_LATENCY)
        val hasProAudio = packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_PRO)

        val r44100 = isFormatSupported(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r48000 = isFormatSupported(48000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r96000 = isFormatSupported(96000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r192000 = isFormatSupported(192000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)

        val pcm16 = isFormatSupported(48000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val pcm24 = isFormatSupported(48000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_24BIT_PACKED)
        val pcmFloat = isFormatSupported(48000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_FLOAT)

        val stereo = isFormatSupported(48000, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)

        _capabilityMatrix.value = HardwareCapabilityMatrix(
            deviceName = device?.productName ?: "Built-in Microphone",
            rate44100Supported = r44100,
            rate48000Supported = r48000,
            rate96000Supported = r96000,
            rate192000Supported = r192000,
            pcm16Supported = pcm16,
            pcm24Supported = pcm24,
            pcmFloatSupported = pcmFloat,
            monoSupported = true,
            stereoSupported = stereo,
            rawUnprocessedSupported = true,
            lowLatencySupported = hasLowLatency,
            proAudioFlag = hasProAudio,
            systemAecPresent = AcousticEchoCanceler.isAvailable(),
            systemNsPresent = NoiseSuppressor.isAvailable(),
            systemAgcPresent = AutomaticGainControl.isAvailable()
        )
    }

    private fun isFormatSupported(sampleRate: Int, channelMask: Int, encoding: Int): Boolean {
        return try {
            val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelMask, encoding)
            minBuf > 0 && minBuf != AudioRecord.ERROR && minBuf != AudioRecord.ERROR_BAD_VALUE
        } catch (_: Exception) {
            false
        }
    }

    private fun deviceTypeToString(type: Int): String {
        return when (type) {
            AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Built-in Microphone"
            AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired Headset Mic"
            AudioDeviceInfo.TYPE_USB_DEVICE -> "USB Audio Device"
            AudioDeviceInfo.TYPE_USB_HEADSET -> "USB Headset"
            AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB Accessory"
            AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth SCO Mic"
            AudioDeviceInfo.TYPE_BLE_HEADSET -> "BLE Audio Headset"
            AudioDeviceInfo.TYPE_TELEPHONY -> "Telephony Input"
            else -> "Audio Input ($type)"
        }
    }

    private fun encToString(enc: Int): String {
        return when (enc) {
            AudioFormat.ENCODING_PCM_16BIT -> "16-bit PCM"
            AudioFormat.ENCODING_PCM_24BIT_PACKED -> "24-bit PCM"
            AudioFormat.ENCODING_PCM_FLOAT -> "32-bit Float"
            AudioFormat.ENCODING_PCM_8BIT -> "8-bit PCM"
            else -> "Format $enc"
        }
    }
}
