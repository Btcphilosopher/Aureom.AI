package com.example.dsp

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow

class Compressor(private var sampleRate: Float = 48000f) {
    private var isEnabled = false
    private var thresholdDb = -18f
    private var ratio = 3.0f
    private var attackCoeff = 0.0f
    private var releaseCoeff = 0.0f
    private var kneeDb = 6.0f
    private var makeupLinear = 1.0f

    private var envelopeDb = -100f
    @Volatile
    var currentGainReductionDb = 0.0f
        private set

    fun configure(
        enabled: Boolean,
        threshDb: Float,
        compRatio: Float,
        attackMs: Float,
        releaseMs: Float,
        knee: Float,
        makeupGainDb: Float,
        sr: Float
    ) {
        isEnabled = enabled
        thresholdDb = threshDb
        ratio = compRatio.coerceAtLeast(1.0f)
        sampleRate = sr
        kneeDb = knee.coerceAtLeast(0.0f)
        makeupLinear = 10.0f.pow(makeupGainDb / 20.0f)

        val attackTimeSec = (attackMs.coerceAtLeast(0.1f)) / 1000f
        val releaseTimeSec = (releaseMs.coerceAtLeast(1.0f)) / 1000f

        attackCoeff = exp(-1.0f / (attackTimeSec * sampleRate))
        releaseCoeff = exp(-1.0f / (releaseTimeSec * sampleRate))
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        if (!isEnabled) {
            currentGainReductionDb = 0.0f
            return
        }

        var maxGr = 0.0f

        for (i in offset until (offset + count)) {
            val sample = buffer[i]
            val absSample = abs(sample)

            // Convert input level to dB
            val inputDb = if (absSample > 1e-6f) {
                20.0f * kotlin.math.log10(absSample)
            } else {
                -120.0f
            }

            // Ballistics envelope
            if (inputDb > envelopeDb) {
                envelopeDb = attackCoeff * envelopeDb + (1.0f - attackCoeff) * inputDb
            } else {
                envelopeDb = releaseCoeff * envelopeDb + (1.0f - releaseCoeff) * inputDb
            }

            // Soft-knee gain calculation
            val halfKnee = kneeDb / 2.0f
            val gainChangeDb = if (kneeDb > 0.0f && envelopeDb > (thresholdDb - halfKnee) && envelopeDb < (thresholdDb + halfKnee)) {
                // Inside knee
                val delta = envelopeDb - thresholdDb + halfKnee
                val kneeTerm = ((1.0f / ratio) - 1.0f) * (delta * delta) / (2.0f * kneeDb)
                kneeTerm
            } else if (envelopeDb >= (thresholdDb + halfKnee)) {
                // Above threshold
                (thresholdDb + (envelopeDb - thresholdDb) / ratio) - envelopeDb
            } else {
                // Below threshold
                0.0f
            }

            val grDb = -gainChangeDb // positive reduction amount
            if (grDb > maxGr) maxGr = grDb

            val linearGain = 10.0f.pow(gainChangeDb / 20.0f) * makeupLinear
            buffer[i] = sample * linearGain
        }

        currentGainReductionDb = maxGr
    }

    fun reset() {
        envelopeDb = -100f
        currentGainReductionDb = 0.0f
    }
}
