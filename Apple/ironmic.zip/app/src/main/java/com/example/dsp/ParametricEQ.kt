package com.example.dsp

class ParametricEQ(private var sampleRate: Float = 48000f) {
    private val filters = Array(8) { BiquadFilter() }
    private var activeBands: List<EqBandConfig> = emptyList()
    private var isEnabled = true

    fun configure(bands: List<EqBandConfig>, sr: Float, enabled: Boolean) {
        sampleRate = sr
        isEnabled = enabled
        activeBands = bands

        for (i in bands.indices) {
            if (i >= filters.size) break
            val band = bands[i]
            if (!band.enabled || !isEnabled) {
                filters[i] = BiquadFilter()
                continue
            }
            filters[i] = when (band.type) {
                FilterType.HIGH_PASS -> BiquadFilter.highPass(sampleRate, band.frequency, band.q)
                FilterType.LOW_SHELF -> BiquadFilter.lowShelf(sampleRate, band.frequency, band.gainDb, band.q)
                FilterType.PEAK -> BiquadFilter.peak(sampleRate, band.frequency, band.gainDb, band.q)
                FilterType.HIGH_SHELF -> BiquadFilter.highShelf(sampleRate, band.frequency, band.gainDb, band.q)
                FilterType.LOW_PASS -> BiquadFilter.lowPass(sampleRate, band.frequency, band.q)
            }
        }
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        if (!isEnabled) return

        for (i in activeBands.indices) {
            if (i >= filters.size) break
            if (activeBands[i].enabled && (activeBands[i].gainDb != 0f || activeBands[i].type == FilterType.HIGH_PASS || activeBands[i].type == FilterType.LOW_PASS)) {
                filters[i].processBlock(buffer, offset, count)
            }
        }
    }

    fun reset() {
        for (f in filters) f.reset()
    }
}
