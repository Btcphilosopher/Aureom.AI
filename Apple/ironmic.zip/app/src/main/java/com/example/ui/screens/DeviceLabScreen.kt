package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.BitDepth
import com.example.audio.ChannelConfig
import com.example.ui.IronMicViewModel
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelBorderActive
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun DeviceLabScreen(
    viewModel: IronMicViewModel,
    modifier: Modifier = Modifier
) {
    val devices by viewModel.availableDevices.collectAsState()
    val matrix by viewModel.capabilityMatrix.collectAsState()
    val captureConfig by viewModel.captureConfigState.collectAsState()
    val qualityDashboard by viewModel.micQualityDashboard.collectAsState()
    val silenceResult by viewModel.silenceTestResult.collectAsState()
    val toneResult by viewModel.toneTestResult.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
            .testTag("device_lab_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Section: Connected Microphones Selector
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
                .testTag("device_selector_module")
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "CONNECTED AUDIO INPUT DEVICES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber,
                    letterSpacing = 1.sp
                )

                if (devices.isEmpty()) {
                    Text(
                        text = "Querying system hardware audio inputs...",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextSecondary
                    )
                } else {
                    devices.forEach { dev ->
                        val isSelected = (captureConfig.preferredDeviceId == dev.id) || (captureConfig.preferredDeviceId == null && dev.typeConstant == android.media.AudioDeviceInfo.TYPE_BUILTIN_MIC)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = if (isSelected) SignalCyan.copy(alpha = 0.15f) else Color(0xFF161A20),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .border(1.dp, if (isSelected) SignalCyan else PanelBorder, RoundedCornerShape(4.dp))
                                .clickable { viewModel.selectDevice(dev.id) }
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = dev.productName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (isSelected) SignalCyan else TextPrimary
                                    )
                                    Text(
                                        text = "${dev.typeName} | ID: ${dev.id}",
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = TextSecondary
                                    )
                                }

                                Text(
                                    text = if (isSelected) "ACTIVE ROUTE" else "SELECT",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isSelected) SignalCyan else TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Format Configuration (Sample Rate, Bit Depth, Channels)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "CAPTURE FORMAT CONFIGURATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalCyan,
                    letterSpacing = 1.sp
                )

                // Sample Rate
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SAMPLE RATE:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(44100, 48000, 96000).forEach { rate ->
                            val isSel = (captureConfig.sampleRate == rate)
                            FormatPill(label = "${rate / 1000} kHz", isSelected = isSel) {
                                viewModel.selectCaptureConfig(sampleRate = rate)
                            }
                        }
                    }
                }

                // Bit Depth
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("BIT DEPTH:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BitDepth.values().forEach { depth ->
                            val isSel = (captureConfig.bitDepth == depth)
                            FormatPill(label = depth.label, isSelected = isSel) {
                                viewModel.selectCaptureConfig(bitDepth = depth)
                            }
                        }
                    }
                }

                // Channel Config
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CHANNELS:", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextSecondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ChannelConfig.values().forEach { ch ->
                            val isSel = (captureConfig.channelConfig == ch)
                            FormatPill(label = ch.label, isSelected = isSel) {
                                viewModel.selectCaptureConfig(channelConfig = ch)
                            }
                        }
                    }
                }
            }
        }

        // Section: Hardware Capability Diagnostic Matrix
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "HARDWARE CAPABILITY MATRIX",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalGreen,
                    letterSpacing = 1.sp
                )

                CapabilityRow("44.1 kHz Standard", matrix.rate44100Supported)
                CapabilityRow("48.0 kHz Studio Standard", matrix.rate48000Supported)
                CapabilityRow("96.0 kHz High Resolution", matrix.rate96000Supported)
                CapabilityRow("192.0 kHz Ultra High Res", matrix.rate192000Supported)
                CapabilityRow("16-Bit Linear PCM", matrix.pcm16Supported)
                CapabilityRow("24-Bit Linear PCM", matrix.pcm24Supported)
                CapabilityRow("32-Bit IEEE 754 Float", matrix.pcmFloatSupported)
                CapabilityRow("Stereo Capture Matrix", matrix.stereoSupported)
                CapabilityRow("Android Low-Latency Audio", matrix.lowLatencySupported)
                CapabilityRow("Android Pro-Audio Flag", matrix.proAudioFlag)
                CapabilityRow("Hardware Echo Canceler (AEC)", matrix.systemAecPresent)
                CapabilityRow("Hardware Noise Suppressor (NS)", matrix.systemNsPresent)
            }
        }

        // Section: Acoustic Calibration Tests
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelElevated, RoundedCornerShape(8.dp))
                .border(1.dp, PanelBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ACOUSTIC CALIBRATION LAB",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = SignalAmber,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.startSilenceCalibration() },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("silence_test_button"),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = SignalAmber),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(SignalAmber))
                    ) {
                        Text("3s SILENCE TEST", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.startToneCalibration() },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tone_test_button"),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = SignalCyan),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = SolidColor(SignalCyan))
                    ) {
                        Text("1kHz TONE TEST", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                if (silenceResult != null) {
                    val res = silenceResult!!
                    Text(
                        text = "SILENCE TEST: Noise Floor ${String.format(Locale.US, "%.1f", res.noiseFloorDbfs)} dBFS | Dynamic Range ${String.format(Locale.US, "%.1f", res.dynamicRangeDb)} dB\nRating: ${res.qualityRating}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = SignalGreen
                    )
                }

                if (toneResult != null) {
                    val res = toneResult!!
                    Text(
                        text = "TONE TEST: Freq ${String.format(Locale.US, "%.1f", res.detectedFrequencyHz)} Hz | Level ${String.format(Locale.US, "%.1f", res.toneLevelDbfs)} dBFS | THD ${String.format(Locale.US, "%.2f", res.thdPercent)}%\nRating: ${res.rating}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = SignalCyan
                    )
                }
            }
        }
    }
}

@Composable
fun FormatPill(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                color = if (isSelected) SignalCyan.copy(alpha = 0.2f) else Color(0xFF161A20),
                shape = RoundedCornerShape(4.dp)
            )
            .border(1.dp, if (isSelected) SignalCyan else PanelBorder, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) SignalCyan else TextSecondary
        )
    }
}

@Composable
fun CapabilityRow(label: String, isSupported: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = TextPrimary)
        Text(
            text = if (isSupported) "SUPPORTED" else "UNAVAILABLE",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = if (isSupported) SignalGreen else TextMuted
        )
    }
}
