package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.RecordState
import com.example.audio.RecordingSessionInfo
import com.example.ui.theme.CarbonDark
import com.example.ui.theme.PanelBorder
import com.example.ui.theme.PanelBorderActive
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalGreen
import com.example.ui.theme.SignalRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun RecordControlPanel(
    session: RecordingSessionInfo,
    sampleRate: Int,
    bitDepthBits: Int,
    onRecordToggle: () -> Unit,
    onStopRecord: () -> Unit,
    onAddMarker: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isRecording = session.state == RecordState.RECORDING
    val isPaused = session.state == RecordState.PAUSED

    val infiniteTransition = rememberInfiniteTransition(label = "rec_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelElevated, RoundedCornerShape(8.dp))
            .border(1.dp, if (isRecording) SignalRed else PanelBorder, RoundedCornerShape(8.dp))
            .padding(12.dp)
            .testTag("record_control_panel")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Header: State, Take Number & Format
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .alpha(if (isRecording) pulseAlpha else 1.0f)
                            .background(
                                color = when {
                                    isRecording -> SignalRed
                                    isPaused -> SignalAmber
                                    else -> SignalGreen
                                },
                                shape = CircleShape
                            )
                    )
                    Text(
                        text = when (session.state) {
                            RecordState.RECORDING -> "RECORDING LIVE"
                            RecordState.PAUSED -> "RECORDING PAUSED"
                            RecordState.FINALISING -> "FINALISING WAV..."
                            RecordState.SAVED -> "SAVED TO LIBRARY"
                            RecordState.ERROR -> "ERROR"
                            RecordState.READY -> "REC ENGINE ARMED"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = when {
                            isRecording -> SignalRed
                            isPaused -> SignalAmber
                            else -> SignalGreen
                        }
                    )
                }

                Text(
                    text = "${sampleRate / 1000}kHz / ${bitDepthBits}-BIT WAV",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = SignalCyan
                )
            }

            // Big Timecode & Take Info
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CarbonDark, RoundedCornerShape(4.dp))
                    .border(1.dp, PanelBorder, RoundedCornerShape(4.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = formatTimecode(session.durationMs),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isRecording) SignalRed else TextPrimary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "FREE STORAGE: ${String.format(Locale.US, "%.1f", session.storageFreeGb)} GB",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMuted
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = String.format(Locale.US, "TAKE #%03d", session.takeNumber),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = SignalAmber
                    )
                    if (session.currentTakeName.isNotEmpty()) {
                        Text(
                            text = session.currentTakeName.take(18) + if (session.currentTakeName.length > 18) "..." else "",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary
                        )
                    }
                }
            }

            // Physical-style Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Main Record / Pause Trigger
                Box(
                    modifier = Modifier
                        .weight(1.5f)
                        .height(48.dp)
                        .background(
                            color = if (isRecording) SignalRed.copy(alpha = 0.2f) else if (isPaused) SignalAmber.copy(alpha = 0.2f) else Color(0xFF241414),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .border(
                            width = 2.dp,
                            color = if (isRecording) SignalRed else if (isPaused) SignalAmber else Color(0xFF882222),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { onRecordToggle() }
                        .padding(horizontal = 12.dp)
                        .testTag("record_trigger_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .background(if (isRecording) SignalRed else Color(0xFFFF2222), CircleShape)
                        )
                        Text(
                            text = if (isRecording) "PAUSE" else if (isPaused) "RESUME" else "RECORD TAKE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = if (isRecording) SignalRed else TextPrimary
                        )
                    }
                }

                // Stop & Commit Button
                if (isRecording || isPaused) {
                    Box(
                        modifier = Modifier
                            .weight(1.0f)
                            .height(48.dp)
                            .background(Color(0xFF1E242C), RoundedCornerShape(6.dp))
                            .border(1.dp, PanelBorderActive, RoundedCornerShape(6.dp))
                            .clickable { onStopRecord() }
                            .padding(horizontal = 8.dp)
                            .testTag("stop_record_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "STOP / SAVE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = SignalAmber
                        )
                    }
                }
            }

            // Quick Marker Drop Buttons
            if (isRecording || isPaused) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MarkerPill(label = "+ MARKER") { onAddMarker("Cue Marker") }
                    MarkerPill(label = "★ GOOD TAKE") { onAddMarker("Good Take") }
                    MarkerPill(label = "SLATE") { onAddMarker("Slate") }
                    MarkerPill(label = "RETAKE") { onAddMarker("Retake") }
                }
            }
        }
    }
}

@Composable
fun MarkerPill(label: String, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.height(26.dp),
        shape = RoundedCornerShape(4.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color.Transparent,
            contentColor = SignalCyan
        ),
        border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = SolidColor(PanelBorder)
        )
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
    }
}

fun formatTimecode(ms: Long): String {
    val totalSecs = ms / 1000
    val hours = totalSecs / 3600
    val mins = (totalSecs % 3600) / 60
    val secs = totalSecs % 60
    val hundredths = (ms % 1000) / 10
    return String.format(Locale.US, "%02d:%02d:%02d.%02d", hours, mins, secs, hundredths)
}
