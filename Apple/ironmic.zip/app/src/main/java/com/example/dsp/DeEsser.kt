package com.example.dsp

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.pow

/**
 * Dynamic Voice De-Esser.
 * Uses a sidechain band-pass filter centered on sibilance (4.5 kHz - 9 kHz)
 * to attenuate harsh sibilant spikes dynamically.
 */
class DeEsser(private var sampleRate: Float = 48000f) {
    private var isEnabled = false
    private var thresholdLinear = 0.1f // -20 dBFS
    private var sidechainFilter = BiquadFilter.bandPass(48000f, 6500f, 1.8f)
    private var sibilanceNotch = BiquadFilter.peak(48000f, 6500f, 0f, 2.0f)

    private var sidechainEnv = 0.0f
    private var attackCoeff = 0.0f
    private var releaseCoeff = 0.0f

    @Volatile
    var activeReductionDb = 0.0f
        private set

    init {
        configure(false, 6500f, -20f, 48000f)
    }

    fun configure(enabled: Boolean, centerFreqHz: Float, threshDb: Float, sr: Float) {
        isEnabled = enabled
        sampleRate = sr
        thresholdLinear = 10.0f.pow(threshDb / 20.0f)
        sidechainFilter = BiquadFilter.bandPass(sampleRate, centerFreqHz, 1.8f)

        val attackSec = 0.001f // 1ms
        val releaseSec = 0.040f // 40ms
        attackCoeff = exp(-1.0f / (attackSec * sampleRate))
        releaseCoeff = exp(-1.0f / (releaseSec * sampleRate))
    }

    fun processBlock(buffer: FloatArray, offset: Int, count: Int) {
        if (!isEnabled) {
            activeReductionDb = 0.0f
            return
        }

        var maxRedDb = 0.0f

        for (i in offset until (offset + count)) {
            val sample = buffer[i]
            val scSample = sidechainFilter.processSample(sample)
            val absSc = abs(scSample)

            if (absSc > sidechainEnv) {
                sidechainEnv = attackCoeff * sidechainEnv + (1.0f - attackCoeff) * absSc
            } else {
                sidechainEnv = releaseCoeff * sidechainEnv + (1.0f - releaseCoeff) * absSc
            }

            if (sidechainEnv > thresholdLinear) {
                val excessDb = 20.0f * kotlin.math.log10(sidechainEnv / thresholdLinear)
                val reductionDb = (excessDb * 0.75f).coerceIn(0f, 12f)
                if (reductionDb > maxRedDb) maxRedDb = reductionDb

                val gainLinear = 10.0f.pow(-reductionDb / 20.0f)
                // Attenuate sibilance region
                buffer[i] = sample * (1.0f - (1.0f - gainLinear) * 0.7f)
            }
        }

        activeReductionDb = maxRedDb
    }

    fun reset() {
        sidechainFilter.reset()
        sibilanceNotch.reset()
        sidechainEnv = 0.0f
        activeReductionDb = 0.0f
    }
}
