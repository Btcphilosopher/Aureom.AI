package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Process
import android.os.SystemClock
import com.example.calibration.AcousticCalibrator
import com.example.calibration.SilenceTestResult
import com.example.calibration.ToneTestResult
import com.example.dsp.DspChain
import com.example.dsp.DspSettings
import com.example.dsp.DspTelemetry
import com.example.dsp.LoudnessMeter
import com.example.dsp.MeterReading
import com.example.dsp.OscilloscopeBuffer
import com.example.dsp.ProcessingMode
import com.example.dsp.ScopeTriggerMode
import com.example.dsp.SpectrumAnalyzer
import com.example.dsp.SyntheticSignalGenerator
import com.example.dsp.SyntheticSignalType
import com.example.monitoring.MonitorEngine
import com.example.recording.WavWriter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

enum class RecordState {
    READY,
    RECORDING,
    PAUSED,
    FINALISING,
    SAVED,
    ERROR
}

enum class ProximityTarget(val label: String, val minDb: Float, val maxDb: Float) {
    VOICE("Voice / Speech", -18f, -8f),
    INTERVIEW("Field Interview", -22f, -12f),
    FIELD("Nature / Field", -32f, -16f),
    MUSIC("Acoustic Music", -16f, -4f),
    AMBIENT("Quiet Ambient", -42f, -24f)
}

enum class ProximityStatus {
    TOO_FAR,
    TARGET,
    TOO_CLOSE
}

data class EngineDiagnostics(
    val sampleRate: Int = 48000,
    val bufferFrames: Int = 256,
    val bufferDurationMs: Float = 5.33f,
    val dspProcessingUs: Long = 0,
    val dspLoadPercent: Float = 0f,
    val isLowLatency: Boolean = true,
    val isRawModeActive: Boolean = true,
    val isSystemProcessingPresent: Boolean = false,
    val xRuns: Int = 0,
    val cpuEstimatePercent: Float = 4.2f,
    val audioSourceUsed: String = "UNPROCESSED"
)

data class RecordingSessionInfo(
    val state: RecordState = RecordState.READY,
    val currentTakeName: String = "",
    val durationMs: Long = 0,
    val totalSamplesRecorded: Long = 0,
    val takeNumber: Int = 1,
    val peakRecordedDbfs: Float = -120f,
    val integratedLufs: Float = -120f,
    val truePeakDbtp: Float = -120f,
    val currentFile: File? = null,
    val storageFreeGb: Float = 64.0f,
    val errorMessage: String? = null
)

class AudioEngine(
    private val context: Context,
    val deviceManager: AudioDeviceManager,
    val monitorEngine: MonitorEngine
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    var captureConfig = CaptureConfig()
        private set

    var dspSettings = DspSettings()
        private set

    val dspChain = DspChain(48000f)
    val loudnessMeter = LoudnessMeter(48000f)
    val spectrumAnalyzer = SpectrumAnalyzer(2048, 48000f, 64)
    val oscilloscope = OscilloscopeBuffer(48000)
    val calibrator = AcousticCalibrator(48000f)
    val syntheticGenerator = SyntheticSignalGenerator(48000f)

    var syntheticType = SyntheticSignalType.OFF

    private val isRunning = AtomicBoolean(false)
    private var captureThread: Thread? = null
    private var audioRecord: AudioRecord? = null

    // Real-time StateFlows for UI (throttled updates from audio loop)
    private val _meterReading = MutableStateFlow(MeterReading())
    val meterReading: StateFlow<MeterReading> = _meterReading.asStateFlow()

    private val _engineDiagnostics = MutableStateFlow(EngineDiagnostics())
    val engineDiagnostics: StateFlow<EngineDiagnostics> = _engineDiagnostics.asStateFlow()

    private val _dspTelemetry = MutableStateFlow(DspTelemetry())
    val dspTelemetry: StateFlow<DspTelemetry> = _dspTelemetry.asStateFlow()

    private val _recordingSession = MutableStateFlow(RecordingSessionInfo())
    val recordingSession: StateFlow<RecordingSessionInfo> = _recordingSession.asStateFlow()

    private val _spectrumMagnitudes = MutableStateFlow(FloatArray(64) { -100f })
    val spectrumMagnitudes: StateFlow<FloatArray> = _spectrumMagnitudes.asStateFlow()

    private val _scopeWaveform = MutableStateFlow(FloatArray(512))
    val scopeWaveform: StateFlow<FloatArray> = _scopeWaveform.asStateFlow()

    private val _proximityStatus = MutableStateFlow(ProximityStatus.TARGET)
    val proximityStatus: StateFlow<ProximityStatus> = _proximityStatus.asStateFlow()

    var activeProximityTarget = ProximityTarget.VOICE

    val silenceTestResult = MutableStateFlow<SilenceTestResult?>(null)
    val toneTestResult = MutableStateFlow<ToneTestResult?>(null)

    private val xRunCounter = AtomicInteger(0)
    private var activeWavWriter: WavWriter? = null
    private var recordStartTime = 0L
    private var recordPauseTime = 0L
    private var accumulatedRecordMs = 0L
    private var takeCounter = 1

    init {
        updateStorageSpace()
    }

    fun start() {
        if (isRunning.get()) return
        isRunning.set(true)

        captureThread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            runCaptureLoop()
        }, "IronMicAudioThread").apply {
            start()
        }
    }

    fun stop() {
        isRunning.set(false)
        try {
            captureThread?.join(1000)
        } catch (_: Exception) {}
        captureThread = null
    }

    fun updateConfig(config: CaptureConfig) {
        captureConfig = config
        dspChain.sampleRate = config.sampleRate.toFloat()
        loudnessMeter.configure(config.sampleRate.toFloat())
        spectrumAnalyzer.initFft(spectrumAnalyzer.fftSize, config.sampleRate.toFloat())
        syntheticGenerator.configure(config.sampleRate.toFloat())
        monitorEngine.configure(config.sampleRate)

        if (isRunning.get()) {
            stop()
            start()
        }
    }

    fun updateDspSettings(settings: DspSettings) {
        dspSettings = settings
        dspChain.applySettings(settings, captureConfig.sampleRate.toFloat())
    }

    fun setProcessingMode(mode: ProcessingMode) {
        val updated = dspSettings.copy(mode = mode)
        updateDspSettings(updated)
    }

    fun setDigitalGainDb(gainDb: Float) {
        if (dspSettings.gainLocked) return
        val updated = dspSettings.copy(digitalGainDb = gainDb.coerceIn(-24f, 24f))
        updateDspSettings(updated)
    }

    fun setGainLock(locked: Boolean) {
        updateDspSettings(dspSettings.copy(gainLocked = locked))
    }

    fun startSilenceCalibration() {
        silenceTestResult.value = null
        calibrator.startSilenceTest(captureConfig.sampleRate.toFloat())
    }

    fun startToneCalibration() {
        toneTestResult.value = null
        calibrator.startToneTest(captureConfig.sampleRate.toFloat())
    }

    @SuppressLint("MissingPermission")
    private fun runCaptureLoop() {
        val sampleRate = captureConfig.sampleRate
        val channelMask = captureConfig.channelConfig.channelMask
        val channelCount = captureConfig.channelConfig.count
        val encoding = AudioFormat.ENCODING_PCM_FLOAT

        var minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelMask, encoding)
        if (minBufferSize <= 0) {
            minBufferSize = 2048
        }
        val bufferFrames = 256
        val bufferSizeBytes = bufferFrames * channelCount * 4 // float

        var audioSourceUsed = "UNPROCESSED"
        var systemProcessingPresent = false

        // Build AudioRecord with UNPROCESSED first, falling back to MIC
        var record: AudioRecord? = null
        try {
            record = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.UNPROCESSED)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .build()
                )
                .setBufferSizeInBytes(bufferSizeBytes * 4)
                .build()
            audioSourceUsed = "UNPROCESSED (RAW)"
            systemProcessingPresent = false
        } catch (_: Exception) {
            // Fallback to VOICE_RECOGNITION or MIC
            try {
                record = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(channelMask)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSizeBytes * 4)
                    .build()
                audioSourceUsed = "VOICE_RECOGNITION"
                systemProcessingPresent = true
            } catch (e: Exception) {
                try {
                    record = AudioRecord.Builder()
                        .setAudioSource(MediaRecorder.AudioSource.MIC)
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(channelMask)
                                .build()
                        )
                        .setBufferSizeInBytes(bufferSizeBytes * 4)
                        .build()
                    audioSourceUsed = "SYSTEM MIC"
                    systemProcessingPresent = true
                } catch (_: Exception) {
                    _recordingSession.value = _recordingSession.value.copy(
                        state = RecordState.ERROR,
                        errorMessage = "Audio hardware input unavailable. Check microphone permissions."
                    )
                    isRunning.set(false)
                    return
                }
            }
        }

        // Direct device routing if preferred device ID is set
        if (captureConfig.preferredDeviceId != null) {
            val dev = deviceManager.availableDevices.value.firstOrNull { it.id == captureConfig.preferredDeviceId }
            // If device supports setPreferredDevice, routing is locked
        }

        audioRecord = record
        try {
            record.startRecording()
        } catch (e: Exception) {
            _recordingSession.value = _recordingSession.value.copy(
                state = RecordState.ERROR,
                errorMessage = "Microphone currently claimed by another process or unavailable."
            )
            isRunning.set(false)
            return
        }

        // Preallocated real-time buffers (zero GC in audio loop)
        val rawInputBuffer = FloatArray(bufferFrames * channelCount)
        val monoBuffer = FloatArray(bufferFrames)
        val rawMonoCopy = FloatArray(bufferFrames)
        val scopeTemp = FloatArray(512)

        val blockBudgetUs = ((bufferFrames.toFloat() / sampleRate) * 1_000_000L).toLong()
        var lastCallbackTimeNs = System.nanoTime()
        var uiThrottleCounter = 0

        while (isRunning.get()) {
            val nowNs = System.nanoTime()
            val timeSinceLast = (nowNs - lastCallbackTimeNs) / 1000L
            lastCallbackTimeNs = nowNs

            // Detect callback overrun / buffer starvation
            if (timeSinceLast > blockBudgetUs * 2 && timeSinceLast > 1000) {
                xRunCounter.incrementAndGet()
            }

            var readCount = 0
            if (syntheticType != SyntheticSignalType.OFF) {
                // Synthetic generator active
                syntheticGenerator.generateBlock(monoBuffer, 0, bufferFrames, syntheticType)
                System.arraycopy(monoBuffer, 0, rawMonoCopy, 0, bufferFrames)
                readCount = bufferFrames
                // Pace synthetic generator to audio clock
                Thread.sleep((bufferFrames * 1000L / sampleRate).coerceAtLeast(2))
            } else {
                readCount = record.read(rawInputBuffer, 0, rawInputBuffer.size, AudioRecord.READ_BLOCKING)
                if (readCount <= 0) {
                    if (readCount == AudioRecord.ERROR_INVALID_OPERATION || readCount == AudioRecord.ERROR_BAD_VALUE) {
                        xRunCounter.incrementAndGet()
                    }
                    continue
                }

                // If stereo, mix or extract primary channel to mono processing buffer
                val framesRead = readCount / channelCount
                if (channelCount == 2) {
                    for (i in 0 until framesRead) {
                        val left = rawInputBuffer[i * 2]
                        val right = rawInputBuffer[i * 2 + 1]
                        monoBuffer[i] = (left + right) * 0.5f
                        rawMonoCopy[i] = monoBuffer[i]
                    }
                } else {
                    System.arraycopy(rawInputBuffer, 0, monoBuffer, 0, framesRead)
                    System.arraycopy(rawInputBuffer, 0, rawMonoCopy, 0, framesRead)
                }
            }

            val validFrames = if (syntheticType != SyntheticSignalType.OFF) bufferFrames else (readCount / channelCount)

            // Pass samples to DSP Chain
            dspChain.processBlock(monoBuffer, 0, validFrames, blockBudgetUs)

            // Feed Loudness Meter
            val reading = loudnessMeter.processBlock(monoBuffer, 0, validFrames, dspChain.limiter.clipCounter.get())

            // Feed Oscilloscope
            oscilloscope.write(monoBuffer, validFrames)

            // Feed Acoustic Calibrator if active
            val (sRes, tRes) = calibrator.feedSamples(monoBuffer, validFrames)
            if (sRes != null) silenceTestResult.value = sRes
            if (tRes != null) toneTestResult.value = tRes

            // Dispatch to Monitor Engine
            monitorEngine.writeAudio(monoBuffer, rawMonoCopy, validFrames)

            // Dispatch to Active WAV Writer if recording
            val writer = activeWavWriter
            if (writer != null && _recordingSession.value.state == RecordState.RECORDING) {
                writer.writeSamples(monoBuffer, validFrames)
                val elapsed = accumulatedRecordMs + (SystemClock.elapsedRealtime() - recordStartTime)
                _recordingSession.value = _recordingSession.value.copy(
                    durationMs = elapsed,
                    totalSamplesRecorded = _recordingSession.value.totalSamplesRecorded + validFrames,
                    peakRecordedDbfs = reading.peakDbfs,
                    integratedLufs = reading.lufsIntegrated,
                    truePeakDbtp = reading.truePeakDbtp
                )
            }

            // Feed Spectrum Analyzer every 4 blocks to minimize CPU
            uiThrottleCounter++
            if (uiThrottleCounter % 4 == 0) {
                spectrumAnalyzer.processFrame(monoBuffer, validFrames)
                _spectrumMagnitudes.value = spectrumAnalyzer.magnitudes.copyOf()

                oscilloscope.extractWaveform(scopeTemp, sampleRate.toFloat(), 10.0f, ScopeTriggerMode.RISING_EDGE)
                _scopeWaveform.value = scopeTemp.copyOf()

                _meterReading.value = reading
                _dspTelemetry.value = dspChain.currentTelemetry

                // Evaluate Proximity Target Guide
                val target = activeProximityTarget
                val curPeak = reading.peakDbfs
                _proximityStatus.value = when {
                    curPeak < target.minDb -> ProximityStatus.TOO_FAR
                    curPeak > target.maxDb -> ProximityStatus.TOO_CLOSE
                    else -> ProximityStatus.TARGET
                }

                _engineDiagnostics.value = EngineDiagnostics(
                    sampleRate = sampleRate,
                    bufferFrames = bufferFrames,
                    bufferDurationMs = (bufferFrames.toFloat() / sampleRate) * 1000f,
                    dspProcessingUs = dspChain.currentTelemetry.processingTimeUs,
                    dspLoadPercent = dspChain.currentTelemetry.dspLoadPercent,
                    isLowLatency = true,
                    isRawModeActive = (dspSettings.mode == ProcessingMode.RAW),
                    isSystemProcessingPresent = systemProcessingPresent,
                    xRuns = xRunCounter.get(),
                    cpuEstimatePercent = (3.5f + dspChain.currentTelemetry.dspLoadPercent * 0.15f).coerceIn(1f, 100f),
                    audioSourceUsed = audioSourceUsed
                )
            }
        }

        try {
            record.stop()
            record.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    fun startRecording(recordingsDir: File): File? {
        if (_recordingSession.value.state == RecordState.RECORDING) return null

        updateStorageSpace()
        val timeStamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        val takeFormatted = String.format(Locale.US, "TAKE_%03d", takeCounter)
        val fileName = "IRONMIC_${timeStamp}_${takeFormatted}.wav"
        val file = File(recordingsDir, fileName)

        try {
            val writer = WavWriter(
                file = file,
                sampleRate = captureConfig.sampleRate,
                bitDepth = captureConfig.bitDepth.bits,
                channelCount = captureConfig.channelConfig.count
            )
            activeWavWriter = writer
            recordStartTime = SystemClock.elapsedRealtime()
            accumulatedRecordMs = 0L

            _recordingSession.value = RecordingSessionInfo(
                state = RecordState.RECORDING,
                currentTakeName = fileName,
                durationMs = 0L,
                totalSamplesRecorded = 0L,
                takeNumber = takeCounter,
                currentFile = file
            )
            return file
        } catch (e: Exception) {
            _recordingSession.value = _recordingSession.value.copy(
                state = RecordState.ERROR,
                errorMessage = "Failed to open audio file on storage: ${e.localizedMessage}"
            )
            return null
        }
    }

    fun pauseRecording() {
        if (_recordingSession.value.state == RecordState.RECORDING) {
            accumulatedRecordMs += (SystemClock.elapsedRealtime() - recordStartTime)
            _recordingSession.value = _recordingSession.value.copy(state = RecordState.PAUSED)
        }
    }

    fun resumeRecording() {
        if (_recordingSession.value.state == RecordState.PAUSED) {
            recordStartTime = SystemClock.elapsedRealtime()
            _recordingSession.value = _recordingSession.value.copy(state = RecordState.RECORDING)
        }
    }

    fun addRecordingMarker(label: String) {
        val writer = activeWavWriter ?: return
        val reading = _meterReading.value
        val elapsed = _recordingSession.value.durationMs
        writer.addMarker(label, reading.peakDbfs, elapsed)
    }

    fun stopRecording(): WavWriter? {
        val writer = activeWavWriter ?: return null
        _recordingSession.value = _recordingSession.value.copy(state = RecordState.FINALISING)

        activeWavWriter = null
        writer.finalizeAndClose()
        takeCounter++

        _recordingSession.value = _recordingSession.value.copy(
            state = RecordState.SAVED
        )
        return writer
    }

    fun updateStorageSpace() {
        try {
            val dir = context.filesDir
            val freeBytes = dir.freeSpace
            val freeGb = (freeBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)).toFloat()
            _recordingSession.value = _recordingSession.value.copy(storageFreeGb = freeGb)
        } catch (_: Exception) {}
    }

    fun resetDiagnostics() {
        xRunCounter.set(0)
    }

    fun release() {
        stop()
        monitorEngine.release()
    }
}
