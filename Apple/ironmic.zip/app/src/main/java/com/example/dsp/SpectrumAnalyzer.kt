package com.example.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

class SpectrumAnalyzer(
    var fftSize: Int = 2048,
    private var sampleRate: Float = 48000f,
    val numDisplayBins: Int = 64
) {
    // FFT Buffers
    private var real = FloatArray(fftSize)
    private var imag = FloatArray(fftSize)
    private var window = FloatArray(fftSize)

    // Log-spaced display bins
    val magnitudes = FloatArray(numDisplayBins) { -100f }
    val peakHoldMagnitudes = FloatArray(numDisplayBins) { -100f }
    val avgMagnitudes = FloatArray(numDisplayBins) { -100f }

    private val binFrequencies = FloatArray(numDisplayBins)
    private var isInitialized = false

    init {
        initFft(fftSize, sampleRate)
    }

    fun initFft(size: Int, sr: Float) {
        fftSize = size
        sampleRate = sr
        real = FloatArray(fftSize)
        imag = FloatArray(fftSize)
        window = FloatArray(fftSize)

        // Precompute Hann window
        for (i in 0 until fftSize) {
            window[i] = (0.5 * (1.0 - cos(2.0 * PI * i / (fftSize - 1)))).toFloat()
        }

        // Precompute log-frequency centers for 20 Hz to 20,000 Hz
        val minFreq = 20.0
        val maxFreq = (sampleRate * 0.48).toDouble().coerceAtLeast(10000.0)
        val logMin = kotlin.math.ln(minFreq)
        val logMax = kotlin.math.ln(maxFreq)

        for (b in 0 until numDisplayBins) {
            val logF = logMin + (b.toDouble() / (numDisplayBins - 1)) * (logMax - logMin)
            binFrequencies[b] = kotlin.math.exp(logF).toFloat()
        }

        isInitialized = true
    }

    fun getBinFrequency(binIndex: Int): Float {
        return if (binIndex in 0 until numDisplayBins) binFrequencies[binIndex] else 1000f
    }

    fun processFrame(samples: FloatArray, count: Int) {
        val n = fftSize
        val copyCount = count.coerceAtMost(n)

        // Zero out
        real.fill(0f)
        imag.fill(0f)

        // Apply Hann window
        for (i in 0 until copyCount) {
            real[i] = samples[i] * window[i]
        }

        // Radix-2 In-place FFT
        computeFft(real, imag, n)

        val nyquistBins = n / 2
        val binWidthHz = sampleRate / n

        // Map linear FFT bins to log display bins
        for (b in 0 until numDisplayBins) {
            val centerF = binFrequencies[b]
            val centerBin = (centerF / binWidthHz).toInt().coerceIn(1, nyquistBins - 1)

            // Group adjacent bins for higher frequency resolution
            val startBin = (centerBin - max(1, centerBin / 16)).coerceIn(0, nyquistBins - 1)
            val endBin = (centerBin + max(1, centerBin / 16)).coerceIn(startBin, nyquistBins - 1)

            var maxMag = 0.0f
            for (k in startBin..endBin) {
                val r = real[k]
                val im = imag[k]
                val mag = sqrt(r * r + im * im) * (2.0f / n)
                if (mag > maxMag) maxMag = mag
            }

            val magDb = if (maxMag > 1e-6f) 20.0f * log10(maxMag) else -100f

            // Smooth updates
            magnitudes[b] = 0.75f * magnitudes[b] + 0.25f * magDb.coerceIn(-100f, 6f)

            // Peak hold decay
            if (magnitudes[b] > peakHoldMagnitudes[b]) {
                peakHoldMagnitudes[b] = magnitudes[b]
            } else {
                peakHoldMagnitudes[b] = peakHoldMagnitudes[b] * 0.96f + magnitudes[b] * 0.04f
            }

            // Running average
            avgMagnitudes[b] = 0.95f * avgMagnitudes[b] + 0.05f * magnitudes[b]
        }
    }

    private fun computeFft(r: FloatArray, im: FloatArray, n: Int) {
        var j = 0
        for (i in 0 until n - 1) {
            if (i < j) {
                val tr = r[i]; r[i] = r[j]; r[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
            var k = n shr 1
            while (k <= j) {
                j -= k
                k = k shr 1
            }
            j += k
        }

        var l = 1
        while (l < n) {
            val step = l shl 1
            val angle = (-PI / l).toFloat()
            var wAngle = 0.0f
            for (m in 0 until l) {
                val wr = cos(wAngle)
                val wi = sin(wAngle)
                var i = m
                while (i < n) {
                    val pair = i + l
                    val tr = wr * r[pair] - wi * im[pair]
                    val ti = wr * im[pair] + wi * r[pair]
                    r[pair] = r[i] - tr
                    im[pair] = im[i] - ti
                    r[i] += tr
                    im[i] += ti
                    i += step
                }
                wAngle += angle
            }
            l = step
        }
    }
}
