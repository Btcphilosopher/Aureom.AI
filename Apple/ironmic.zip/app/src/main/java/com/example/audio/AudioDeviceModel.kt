package com.example.audio

data class AudioDeviceModel(
    val id: Int,
    val productName: String,
    val typeName: String,
    val typeConstant: Int,
    val isSource: Boolean,
    val sampleRates: List<Int>,
    val channelCounts: List<Int>,
    val encodings: List<String>,
    val isUnprocessedSupported: Boolean,
    val isLowLatencySupported: Boolean,
    val isProAudioSupported: Boolean,
    val aecAvailable: Boolean,
    val nsAvailable: Boolean,
    val agcAvailable: Boolean,
    val isSelected: Boolean = false
)

data class HardwareCapabilityMatrix(
    val deviceName: String = "Built-in Microphone",
    val rate44100Supported: Boolean = true,
    val rate48000Supported: Boolean = true,
    val rate96000Supported: Boolean = false,
    val rate192000Supported: Boolean = false,
    val pcm16Supported: Boolean = true,
    val pcm24Supported: Boolean = true,
    val pcmFloatSupported: Boolean = true,
    val monoSupported: Boolean = true,
    val stereoSupported: Boolean = false,
    val rawUnprocessedSupported: Boolean = true,
    val lowLatencySupported: Boolean = true,
    val proAudioFlag: Boolean = false,
    val systemAecPresent: Boolean = false,
    val systemNsPresent: Boolean = false,
    val systemAgcPresent: Boolean = false
)
