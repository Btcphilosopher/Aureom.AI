import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Mock Engine State
const engineState = {
  connected: true,
  processId: 84920,
  port: 8080,
  version: "2.4.0-python",
  lastHeartbeat: new Date().toISOString(),
  currentProject: {
    id: "proj-myvideoapp",
    name: "MyVideoApp",
    platform: "macOS",
    framework: "SwiftUI / Metal",
    path: "~/Developer/MyVideoApp",
    buildStatus: "PASS",
    testPassCount: 1842,
    totalTests: 1845,
    securityStatus: "GOOD",
    performanceStatus: "STABLE",
    architectureStatus: "HEALTHY",
    modifiedCount: 2,
    lastBuilt: "2 minutes ago"
  },
  targets: [
    { id: "t1", name: "MyVideoApp", platform: "macOS", buildConfigurations: ["Debug", "Release"] },
    { id: "t2", name: "MyVideoAppTests", platform: "macOS", buildConfigurations: ["Debug"] },
    { id: "t3", name: "ExportServiceCore", platform: "macOS Framework", buildConfigurations: ["Debug", "Release"] }
  ],
  devices: [
    { id: "dev-mac", name: "My Mac (Apple Silicon M3 Max)", os: "macOS 15.1", architecture: "arm64", status: "BOOTED", deviceType: "Mac" },
    { id: "dev-iphone", name: "iPhone 16 Pro Simulator", os: "iOS 18.1", architecture: "arm64", status: "BOOTED", deviceType: "iPhone" },
    { id: "dev-ipad", name: "iPad Pro 13-inch (M4)", os: "iPadOS 18.1", architecture: "arm64", status: "SHUTDOWN", deviceType: "iPad" },
    { id: "dev-watch", name: "Apple Watch Ultra 2", os: "watchOS 11.0", architecture: "arm64", status: "SHUTDOWN", deviceType: "Apple Watch" },
    { id: "dev-vision", name: "Apple Vision Pro", os: "visionOS 2.1", architecture: "arm64", status: "SHUTDOWN", deviceType: "Vision Pro" }
  ],
  logs: [
    { id: "l1", category: "System", level: "INFO", time: "10:14:02", text: "AppleCode Engine connected on localhost:8080" },
    { id: "l2", category: "Build", level: "SUCCESS", time: "10:14:15", text: "xcodebuild: Build Succeeded. Duration 38.4s" },
    { id: "l3", category: "Test", level: "INFO", time: "10:14:20", text: "Executed 1,845 tests across 14 test suites. 3 failed." },
    { id: "l4", category: "AI", level: "INFO", time: "10:15:00", text: "AI Engine indexed 12 source files in ExportService target." }
  ]
};

// REST API Endpoints for Python Engine Integration
app.get('/api/engine/status', (req, res) => {
  res.json({
    connected: true,
    processId: engineState.processId,
    port: engineState.port,
    version: engineState.version,
    lastHeartbeat: new Date().toISOString()
  });
});

app.get('/api/engine/project', (req, res) => {
  res.json({
    project: engineState.currentProject,
    targets: engineState.targets
  });
});

app.post('/api/engine/build', (req, res) => {
  const { target = "MyVideoApp", configuration = "Debug", destination = "My Mac" } = req.body;
  res.json({
    id: `build-${Date.now()}`,
    target,
    configuration,
    destination,
    status: "SUCCEEDED",
    durationSeconds: 38.4,
    warningsCount: 3,
    errorsCount: 0,
    stages: [
      { name: "Resolve Dependencies", durationSeconds: 1.2, status: "COMPLETED" },
      { name: "Compile Swift Sources", durationSeconds: 28.1, status: "COMPLETED" },
      { name: "Link Binaries", durationSeconds: 6.7, status: "COMPLETED" },
      { name: "Code Sign", durationSeconds: 0.8, status: "COMPLETED" },
      { name: "Package App Bundle", durationSeconds: 1.6, status: "COMPLETED" }
    ],
    diagnostics: [
      { severity: "WARNING", file: "PlayerView.swift", line: 48, column: 12, message: "'init(url:)' was deprecated in macOS 15.0: Use modern PlayerItem initializer" },
      { severity: "WARNING", file: "ExportService.swift", line: 112, column: 8, message: "Immutable value 'tempFile' was never used; consider replacing with '_'" },
      { severity: "WARNING", file: "VideoModel.swift", line: 89, column: 22, message: "Result of call to 'asyncTask()' is unused" }
    ]
  });
});

app.post('/api/engine/test', (req, res) => {
  res.json({
    id: `test-${Date.now()}`,
    totalCount: 1842,
    passedCount: 1839,
    failedCount: 3,
    skippedCount: 0,
    suites: {
      "Unit Tests": [
        { id: "t-1", suite: "ExportTests", name: "testExportPipelineInit", status: "PASSED", durationMs: 14 },
        { id: "t-2", suite: "ExportTests", name: "testLargeVideo", status: "FAILED", durationMs: 420, file: "ExportService.swift", line: 241, expected: "4K frame count = 120", actual: "118", failureMessage: "Frame count mismatch during 4K HEVC export encode." },
        { id: "t-3", suite: "VideoModelTests", name: "testMetadataParsing", status: "PASSED", durationMs: 8 }
      ],
      "Integration Tests": [
        { id: "t-4", suite: "EncoderIntegration", name: "testHardwareAccelerator", status: "FAILED", durationMs: 1200, file: "EncoderPipeline.swift", line: 88, expected: "Metal GPU queue active", actual: "CPU fallback engaged", failureMessage: "Metal encoder failed to reserve hardware unit." },
        { id: "t-5", suite: "EncoderIntegration", name: "testAudioMixerSync", status: "FAILED", durationMs: 310, file: "AudioMixer.swift", line: 104, expected: "Audio latency < 5ms", actual: "12ms", failureMessage: "Audio buffer overflow in multi-channel mix." }
      ],
      "UI Tests": [
        { id: "t-6", suite: "PlayerUITests", name: "testPlayPauseToggle", status: "PASSED", durationMs: 850 },
        { id: "t-7", suite: "PlayerUITests", name: "testTimelineScrubbing", status: "PASSED", durationMs: 1120 }
      ]
    }
  });
});

app.get('/api/engine/devices', (req, res) => {
  res.json(engineState.devices);
});

app.post('/api/engine/ai', async (req, res) => {
  const { prompt } = req.body;
  const apiKey = process.env['GEMINI_API_KEY'];

  let aiResponseText = "";
  if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `You are AppleCode.Studio AI Engineer for macOS / Swift / SwiftUI apps. Prompt: "${prompt}". Provide a concise engineering strategy and proposed Swift fix.`
      });
      aiResponseText = response.text || "";
    } catch (err) {
      console.error("Gemini API call failed:", err);
    }
  }

  res.json({
    prompt: prompt || "Optimise video export performance.",
    aiResponseText: aiResponseText || "Analyzed ExportService.swift background encoder queues. Identified synchronous main thread dispatch blocking frame render loop.",
    plan: [
      { number: 1, title: "Inspect ExportService", description: "Review main thread execution in frame processing dispatch queue." },
      { number: 2, title: "Analyse encoder pipeline", description: "Profile VideoToolbox HEVC hardware session allocation." },
      { number: 3, title: "Identify synchronous work", description: "Isolate blocking audio track sample buffer conversions." },
      { number: 4, title: "Introduce background processing", description: "Wrap VTCompressionSessionEncodeFrame in dedicated Task.detached high-priority actor." },
      { number: 5, title: "Add progress reporting", description: "Expose AsyncStream<Double> for UI timeline progress updates." },
      { number: 6, title: "Add regression tests", description: "Add testLargeVideo 4K frame count verification test." },
      { number: 7, title: "Build project", description: "Verify compilation against macOS 15 SDK." },
      { number: 8, title: "Run tests", description: "Validate zero test regressions across test suites." }
    ],
    patch: {
      id: "patch-001",
      title: "Asynchronous Export Service Optimization",
      summary: "Refactored synchronous VTCompressionSession calls to high-throughput background Tasks with Metal buffer reuse.",
      filePath: "Services/ExportService.swift",
      originalContent: `func processExport(video: Video) throws {\n    let encoder = try VTCompressionSession.create()\n    for frame in video.frames {\n        encoder.encode(frame) // synchronous block on main thread\n    }\n}`,
      modifiedContent: `func processExport(video: Video) async throws {\n    let encoder = try await VTCompressionSession.createAsync()\n    await withTaskGroup(of: Void.self) { group in\n        for frame in video.frames {\n            group.addTask(priority: .userInitiated) {\n                try? await encoder.encodeAsync(frame)\n            }\n        }\n    }\n}`,
      diffLines: [
        "- func processExport(video: Video) throws {",
        "-     let encoder = try VTCompressionSession.create()",
        "-     for frame in video.frames {",
        "-         encoder.encode(frame) // synchronous block on main thread",
        "-     }",
        "+ func processExport(video: Video) async throws {",
        "+     let encoder = try await VTCompressionSession.createAsync()",
        "+     await withTaskGroup(of: Void.self) { group in",
        "+         for frame in video.frames {",
        "+             group.addTask(priority: .userInitiated) {",
        "+                 try? await encoder.encodeAsync(frame)",
        "+             }",
        "+         }",
        "+     }"
      ]
    }
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 3000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`AppleCode Studio Node server listening on http://0.0.0.0:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
