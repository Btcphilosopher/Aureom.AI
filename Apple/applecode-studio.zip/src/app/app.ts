import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from './services/engine.service';
import { MacMenuBarComponent } from './components/mac-menu-bar.component';
import { TopToolbarComponent } from './components/top-toolbar.component';
import { MacSidebarComponent } from './components/mac-sidebar.component';
import { BottomDrawerComponent } from './components/bottom-drawer.component';
import { CommandPaletteComponent } from './components/command-palette.component';
import { WelcomeScreenComponent } from './components/welcome-screen.component';

import { OverviewViewComponent } from './views/overview-view.component';
import { CodeViewComponent } from './views/code-view.component';
import { AiViewComponent } from './views/ai-view.component';
import { BuildViewComponent } from './views/build-view.component';
import { TestViewComponent } from './views/test-view.component';
import { DeviceViewComponent } from './views/device-view.component';
import { PerformanceViewComponent } from './views/performance-view.component';
import { SecurityViewComponent } from './views/security-view.component';
import { ArchitectureViewComponent } from './views/architecture-view.component';
import { ReleaseViewComponent } from './views/release-view.component';
import { SettingsViewComponent } from './views/settings-view.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    MacMenuBarComponent,
    TopToolbarComponent,
    MacSidebarComponent,
    BottomDrawerComponent,
    CommandPaletteComponent,
    WelcomeScreenComponent,
    OverviewViewComponent,
    CodeViewComponent,
    AiViewComponent,
    BuildViewComponent,
    TestViewComponent,
    DeviceViewComponent,
    PerformanceViewComponent,
    SecurityViewComponent,
    ArchitectureViewComponent,
    ReleaseViewComponent,
    SettingsViewComponent
  ],
  template: `
    @if (!engine.hasOpenedProject()) {
      <app-welcome-screen></app-welcome-screen>
    } @else {
      <div class="h-screen w-screen flex flex-col bg-[var(--bg-system)] text-[var(--text-primary)] font-sans overflow-hidden antialiased">
        <!-- Top Application Menu Bar -->
        <app-mac-menu-bar></app-mac-menu-bar>

        <!-- Main Window Top Toolbar -->
        <app-top-toolbar></app-top-toolbar>

        <!-- Main Workspace (Sidebar + Dynamic View Content) -->
        <div class="flex-1 flex overflow-hidden">
          <app-mac-sidebar></app-mac-sidebar>

          <!-- Main View Routing Container -->
          <main class="flex-1 h-full bg-[var(--bg-elevated)] overflow-hidden">
            @switch (engine.activeRoute()) {
              @case ('Overview') { <app-overview-view></app-overview-view> }
              @case ('Files') { <app-code-view></app-code-view> }
              @case ('Code') { <app-code-view></app-code-view> }
              @case ('AI') { <app-ai-view></app-ai-view> }
              @case ('Builds') { <app-build-view></app-build-view> }
              @case ('Tests') { <app-test-view></app-test-view> }
              @case ('Simulator') { <app-device-view></app-device-view> }
              @case ('Performance') { <app-performance-view></app-performance-view> }
              @case ('Security') { <app-security-view></app-security-view> }
              @case ('Architecture') { <app-architecture-view></app-architecture-view> }
              @case ('Archives') { <app-release-view></app-release-view> }
              @case ('Distribution') { <app-release-view></app-release-view> }
              @case ('Settings') { <app-settings-view></app-settings-view> }
              @default { <app-overview-view></app-overview-view> }
            }
          </main>
        </div>

        <!-- Expandable Bottom Drawer Logs -->
        <app-bottom-drawer></app-bottom-drawer>

        <!-- Global Command Palette Modal (⌘K) -->
        <app-command-palette></app-command-palette>
      </div>
    }
  `
})
export class App {
  engine = inject(EngineService);
}
