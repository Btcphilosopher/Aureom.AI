import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';
import { SecurityFinding } from '../models/studio.models';

@Component({
  selector: 'app-security-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 select-none">
      <!-- Title Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[var(--border-color)]">
        <div>
          <h1 class="text-xl font-bold text-[var(--text-primary)]">SECURITY & ENTITLEMENTS AUDITOR</h1>
          <p class="text-xs text-[var(--text-secondary)]">Hardened Runtime, App Sandbox, and Static AST Security Analyzer</p>
        </div>

        <button (click)="runAudit()" class="px-3 py-1.5 rounded-md bg-[var(--accent-color)] text-white text-xs font-semibold hover:opacity-90 flex items-center gap-1">
          <span class="material-icons text-xs">shield</span>
          <span>Run Full Security Audit</span>
        </button>
      </div>

      <!-- Security Overview Grid (Section 23) -->
      <div class="grid grid-cols-6 gap-3">
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Secrets</div>
          <div class="text-sm font-bold text-[var(--success-color)] mt-1">CLEAN (0)</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Entitlements</div>
          <div class="text-sm font-bold text-[var(--warning-color)] mt-1">1 REVIEW</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Code Signing</div>
          <div class="text-sm font-bold text-[var(--success-color)] mt-1">VALID</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Dependencies</div>
          <div class="text-sm font-bold text-[var(--success-color)] mt-1">VERIFIED</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Filesystem</div>
          <div class="text-sm font-bold text-[var(--success-color)] mt-1">SANDBOXED</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Network TLS</div>
          <div class="text-sm font-bold text-[var(--success-color)] mt-1">ATS ENFORCED</div>
        </div>
      </div>

      <!-- Audit Findings -->
      <div class="space-y-3">
        <h2 class="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider">
          Security Audit Findings
        </h2>

        <div class="space-y-3">
          @for (item of engine.securityFindings(); track item.id) {
            <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-2 shadow-2xs">
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <span
                    [class]="item.severity === 'CRITICAL' || item.severity === 'HIGH'
                      ? 'bg-[var(--error-color)]/15 text-[var(--error-color)]'
                      : 'bg-[var(--warning-color)]/15 text-[var(--warning-color)]'"
                    class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                  >
                    {{ item.severity }}
                  </span>
                  <span class="font-bold text-xs text-[var(--text-primary)]">{{ item.title }}</span>
                </div>
                <span class="text-xs font-mono text-[var(--text-secondary)]">{{ item.category }}</span>
              </div>

              <p class="text-xs text-[var(--text-secondary)] font-mono">{{ item.description }}</p>

              <div class="pt-2 border-t border-[var(--border-color)] flex items-center justify-between text-xs">
                <span class="font-mono text-[11px] text-[var(--text-secondary)]">Target: {{ item.file }}</span>

                <button
                  (click)="remediate(item)"
                  class="px-3 py-1 bg-[var(--accent-color)] text-white rounded text-xs font-medium hover:opacity-90 flex items-center gap-1"
                >
                  <span class="material-icons text-xs">auto_awesome</span>
                  <span>Remediate with AI</span>
                </button>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Active macOS Entitlements -->
      <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
        <h2 class="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider">
          Verified App Sandbox Entitlements
        </h2>

        <div class="space-y-2 text-xs font-mono">
          <div class="p-2.5 rounded bg-[var(--bg-elevated)] border border-[var(--border-color)] flex justify-between items-center">
            <span class="text-[var(--text-primary)]">com.apple.security.app-sandbox</span>
            <span class="text-[var(--success-color)] font-bold">ENABLED</span>
          </div>

          <div class="p-2.5 rounded bg-[var(--bg-elevated)] border border-[var(--border-color)] flex justify-between items-center">
            <span class="text-[var(--text-primary)]">com.apple.security.files.user-selected.read-write</span>
            <span class="text-[var(--success-color)] font-bold">ENABLED</span>
          </div>

          <div class="p-2.5 rounded bg-[var(--bg-elevated)] border border-[var(--border-color)] flex justify-between items-center">
            <span class="text-[var(--text-primary)]">com.apple.security.network.client</span>
            <span class="text-[var(--success-color)] font-bold">ENABLED</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SecurityViewComponent {
  engine = inject(EngineService);

  remediate(item: SecurityFinding) {
    this.engine.aiPrompt.set(`Remediate security issue in ${item.file}: ${item.title}`);
    this.engine.setRoute('AI');
    this.engine.triggerAIAnalysis();
  }

  runAudit() {
    this.engine.addLog('Security', 'SUCCESS', 'Static security audit complete: 0 secret keys found, 1 entitlement suggestion.');
  }
}
