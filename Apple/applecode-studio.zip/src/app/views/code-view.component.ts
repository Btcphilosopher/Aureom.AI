import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';
import { SourceFileNode } from '../models/studio.models';

@Component({
  selector: 'app-code-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full flex overflow-hidden select-none">
      <!-- Pane 1: File Tree Navigator (220px) -->
      <div class="w-56 h-full bg-[var(--bg-system)] border-r border-[var(--border-color)] flex flex-col">
        <!-- Search & Filter Header -->
        <div class="p-2 border-b border-[var(--border-color)] space-y-1.5">
          <div class="flex items-center justify-between text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider px-1">
            <span>FILES</span>
            <button (click)="toggleExpandAll()" title="Collapse / Expand All" class="hover:text-[var(--text-primary)] cursor-pointer">
              <span class="material-icons text-xs block">unfold_more</span>
            </button>
          </div>
          <div class="relative">
            <span class="material-icons text-xs absolute left-2 top-1.5 text-[var(--text-secondary)]">search</span>
            <input
              type="text"
              placeholder="Search files..."
              [value]="fileSearchQuery()"
              (input)="onFileSearch($event)"
              class="w-full pl-6 pr-2 py-1 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded text-xs text-[var(--text-primary)] outline-none font-mono"
            />
          </div>
        </div>

        <!-- File Tree -->
        <div class="flex-1 overflow-y-auto p-2 space-y-0.5 text-xs">
          @for (node of engine.fileTree(); track node.path) {
            <ng-container *ngTemplateOutlet="fileNodeTemplate; context: { node: node, level: 0 }"></ng-container>
          }
        </div>
      </div>

      <!-- Recursive File Node Template -->
      <ng-template #fileNodeTemplate let-node="node" let-level="level">
        <div>
          <button
            (click)="onNodeClick(node)"
            [style.paddingLeft.px]="level * 14 + 6"
            [class]="engine.selectedFile()?.path === node.path
              ? 'bg-[var(--accent-color)] text-white font-medium'
              : 'hover:bg-[var(--bg-secondary)] text-[var(--text-primary)]'"
            class="w-full text-left py-1 px-2 rounded flex items-center justify-between cursor-pointer group transition-colors"
          >
            <div class="flex items-center space-x-1.5 truncate">
              @if (node.isDirectory) {
                <span class="material-icons text-xs text-[var(--text-secondary)] group-hover:text-current">
                  {{ isExpanded(node.path) ? 'folder_open' : 'folder' }}
                </span>
              } @else {
                <span class="material-icons text-xs text-[var(--accent-color)] group-hover:text-current">description</span>
              }
              <span class="truncate font-mono text-[11px]">{{ node.name }}</span>
            </div>

            <!-- Indicators: modified, error, warning -->
            <div class="flex items-center space-x-1 text-[10px]">
              @if (node.isModified) {
                <span class="w-1.5 h-1.5 rounded-full bg-[var(--warning-color)]" title="Modified in Git"></span>
              }
              @if (node.hasError) {
                <span class="w-1.5 h-1.5 rounded-full bg-[var(--error-color)]" title="Compilation Error"></span>
              }
              @if (node.hasWarning) {
                <span class="w-1.5 h-1.5 rounded-full bg-[var(--warning-color)] opacity-60" title="Warning"></span>
              }
            </div>
          </button>

          @if (node.isDirectory && isExpanded(node.path) && node.children) {
            <div>
              @for (child of node.children; track child.path) {
                <ng-container *ngTemplateOutlet="fileNodeTemplate; context: { node: child, level: level + 1 }"></ng-container>
              }
            </div>
          }
        </div>
      </ng-template>

      <!-- Pane 2: Code Editor (Flex-1) -->
      <div class="flex-1 h-full bg-[var(--bg-elevated)] flex flex-col overflow-hidden">
        <!-- Editor Breadcrumb & Actions Bar -->
        <div class="h-9 border-b border-[var(--border-color)] px-4 flex items-center justify-between text-xs font-mono bg-[var(--bg-system)]">
          <div class="flex items-center space-x-2 text-[var(--text-secondary)] truncate">
            <span class="material-icons text-sm text-[var(--accent-color)]">code</span>
            <span class="text-[var(--text-primary)] font-semibold">{{ engine.selectedFile()?.path || 'No File Selected' }}</span>
            @if (engine.selectedFile()?.isModified) {
              <span class="text-[10px] px-1.5 py-0.2 rounded bg-[var(--warning-color)]/15 text-[var(--warning-color)]">Modified</span>
            }
          </div>

          <div class="flex items-center space-x-3 text-[11px]">
            <button (click)="engine.triggerAIAnalysis('Optimise ' + engine.selectedFile()?.name)" class="px-2 py-0.5 rounded bg-[var(--accent-color)]/10 text-[var(--accent-color)] hover:bg-[var(--accent-color)]/20 font-sans flex items-center gap-1 cursor-pointer">
              <span class="material-icons text-xs">auto_awesome</span>
              <span>Ask AI about file</span>
            </button>
            <span class="text-[var(--text-secondary)]">Swift 5.10</span>
          </div>
        </div>

        <!-- Code Editor Area -->
        <div class="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed flex bg-[var(--bg-elevated)]">
          <!-- Line Numbers Column -->
          <div class="select-none text-right pr-4 text-[var(--text-secondary)] opacity-40 border-r border-[var(--border-color)] mr-4 space-y-1 text-[11px]">
            @for (line of editorLines(); track $index) {
              <div [class.text-[var(--accent-color)]]="activeLineIndex() === $index" [class.font-bold]="activeLineIndex() === $index">
                {{ $index + 1 }}
              </div>
            }
          </div>

          <!-- Code Content & Diagnostic Highlights -->
          <div class="flex-1 space-y-1 overflow-x-auto text-[11px]">
            @for (line of editorLines(); track $index) {
              <div
                (click)="activeLineIndex.set($index)"
                (keydown.enter)="activeLineIndex.set($index)"
                tabindex="0"
                role="button"
                [class]="activeLineIndex() === $index
                  ? 'bg-[var(--accent-color)]/10 -mx-2 px-2 rounded border-l-2 border-[var(--accent-color)]'
                  : 'hover:bg-[var(--bg-secondary)]/50 -mx-2 px-2 rounded'"
                class="whitespace-pre flex items-center justify-between group cursor-pointer outline-none"
              >
                <span [innerHTML]="highlightSwiftSyntax(line)"></span>

                @if (line.includes('VTCompressionSession') || line.includes('deprecated')) {
                  <span class="text-[10px] px-1.5 py-0.2 rounded bg-[var(--warning-color)]/20 text-[var(--warning-color)] font-sans ml-4">
                    ⚠️ Bottleneck / Warning
                  </span>
                }
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Pane 3: Inspector Pane (260px) -->
      <div class="w-64 h-full bg-[var(--bg-system)] border-l border-[var(--border-color)] flex flex-col p-3 space-y-4">
        <!-- Inspector Tabs -->
        <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-2">
          <h2 class="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-1">
            <span class="material-icons text-sm text-[var(--accent-color)]">search</span>
            <span>INSPECTOR</span>
          </h2>
        </div>

        <!-- Symbols List -->
        <div class="space-y-2">
          <h3 class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">Symbol Outline</h3>
          <div class="space-y-1 text-xs">
            @for (sym of engine.symbols(); track sym.name) {
              <div class="p-2 rounded bg-[var(--bg-elevated)] border border-[var(--border-color)] space-y-0.5">
                <div class="flex items-center justify-between">
                  <span class="font-mono font-medium text-[var(--text-primary)] text-[11px] truncate">{{ sym.name }}</span>
                  <span class="text-[9px] px-1 rounded bg-[var(--accent-color)]/10 text-[var(--accent-color)] font-mono">{{ sym.kind }}</span>
                </div>
                <div class="text-[10px] text-[var(--text-secondary)]">Line {{ sym.line }}</div>
                @if (sym.doc) {
                  <p class="text-[10px] text-[var(--text-secondary)] italic mt-1">{{ sym.doc }}</p>
                }
              </div>
            }
          </div>
        </div>

        <!-- Diagnostics in Active File -->
        <div class="space-y-2 pt-2 border-t border-[var(--border-color)]">
          <h3 class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">File Diagnostics</h3>
          <div class="p-2.5 rounded-lg bg-[var(--warning-color)]/10 border border-[var(--warning-color)]/30 space-y-1 text-xs">
            <div class="flex items-center justify-between font-semibold text-[var(--warning-color)] text-[11px]">
              <span>Performance Bottleneck</span>
              <span>Line 11</span>
            </div>
            <p class="text-[10px] text-[var(--text-primary)] leading-tight">
              Synchronous call to VTCompressionSession on main thread. Consider wrapping in background Task.
            </p>
            <button (click)="engine.triggerAIAnalysis()" class="mt-1 text-[10px] text-[var(--accent-color)] font-medium hover:underline flex items-center gap-0.5 cursor-pointer">
              <span>Remediate with AI</span>
              <span class="material-icons text-xs">arrow_forward</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CodeViewComponent {
  engine = inject(EngineService);
  fileSearchQuery = signal<string>('');
  expandedPaths = signal<Set<string>>(new Set(['MyApp', 'MyApp/App', 'MyApp/Views', 'MyApp/Services']));
  activeLineIndex = signal<number>(10);

  editorLines = computed(() => {
    const file = this.engine.selectedFile();
    if (!file || !file.content) {
      return [
        'import Foundation',
        'import VideoToolbox',
        '',
        'final class ExportService: ObservableObject {',
        '    @Published var isExporting = false',
        '    @Published var progress: Double = 0.0',
        '',
        '    func processExport(video: Video) throws {',
        '        let encoder = try VTCompressionSession.create()',
        '        for frame in video.frames {',
        '            encoder.encode(frame)',
        '        }',
        '    }',
        '}'
      ];
    }
    return file.content.split('\n');
  });

  isExpanded(path: string): boolean {
    return this.expandedPaths().has(path);
  }

  onNodeClick(node: SourceFileNode) {
    if (node.isDirectory) {
      const set = new Set(this.expandedPaths());
      if (set.has(node.path)) {
        set.delete(node.path);
      } else {
        set.add(node.path);
      }
      this.expandedPaths.set(set);
    } else {
      this.engine.selectedFile.set(node);
    }
  }

  toggleExpandAll() {
    if (this.expandedPaths().size > 0) {
      this.expandedPaths.set(new Set());
    } else {
      this.expandedPaths.set(new Set(['MyApp', 'MyApp/App', 'MyApp/Views', 'MyApp/Models', 'MyApp/Services', 'MyApp/Tests']));
    }
  }

  onFileSearch(e: Event) {
    this.fileSearchQuery.set((e.target as HTMLInputElement).value);
  }

  highlightSwiftSyntax(line: string): string {
    if (!line) return '&nbsp;';
    let escaped = line
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    escaped = escaped
      .replace(/\b(import|struct|class|final|var|let|func|throws|async|try|await|for|in|if|else|return|case|switch)\b/g, '<span style="color: #FF7AB2; font-weight: bold;">$1</span>')
      .replace(/\b(ObservableObject|Published|View|App|Video|VTCompressionSession|URL|UUID|Double|TimeInterval|String|Bool|Int)\b/g, '<span style="color: #78DCE8;">$1</span>')
      .replace(/(\/\/.+$)/g, '<span style="color: #7F8C8D; font-style: italic;">$1</span>')
      .replace(/("[^"]*")/g, '<span style="color: #FF8170;">$1</span>');

    return escaped;
  }
}
