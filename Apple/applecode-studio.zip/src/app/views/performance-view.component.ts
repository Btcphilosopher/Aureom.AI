import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

@Component({
  selector: 'app-performance-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 select-none">
      <!-- Title Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[var(--border-color)]">
        <div>
          <h1 class="text-xl font-bold text-[var(--text-primary)]">PERFORMANCE & SYSTEM PROFILER</h1>
          <p class="text-xs text-[var(--text-secondary)]">Metal GPU, VTCompressionSession, and CPU thread telemetry</p>
        </div>

        <div class="flex items-center space-x-2 text-xs">
          <button (click)="engine.triggerAIAnalysis('Optimise CPU thread usage')" class="px-3 py-1.5 rounded bg-[var(--accent-color)] text-white font-medium hover:opacity-90 flex items-center gap-1">
            <span class="material-icons text-xs">auto_awesome</span>
            <span>Analyse Regression with AI</span>
          </button>
        </div>
      </div>

      <!-- AI / Performance Regression Alert Connection (Section 57) -->
      <div class="p-3 bg-[var(--warning-color)]/10 border border-[var(--warning-color)]/30 rounded-xl flex items-center justify-between text-xs">
        <div class="flex items-center gap-2">
          <span class="material-icons text-base text-[var(--warning-color)]">speed</span>
          <div>
            <span class="font-bold text-[var(--warning-color)]">PERFORMANCE REGRESSION DETECTED</span>
            <p class="text-[11px] text-[var(--text-primary)]">Memory allocation spiked +18% during 4K HEVC export encode in ExportService.</p>
          </div>
        </div>

        <button (click)="analyzeRegression()" class="px-3 py-1.5 bg-[var(--accent-color)] text-white font-semibold rounded-lg hover:opacity-90 transition-opacity">
          Analyse with AI
        </button>
      </div>

      <!-- Top Metrics Dashboard (Section 20) -->
      <div class="grid grid-cols-5 gap-3">
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">CPU Usage</div>
          <div class="text-xl font-bold text-[var(--text-primary)] font-mono mt-1">48%</div>
          <div class="text-[9px] text-[var(--success-color)] mt-1">● 8 Cores Active</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Memory (RAM)</div>
          <div class="text-xl font-bold text-[var(--text-primary)] font-mono mt-1">1.21 GB</div>
          <div class="text-[9px] text-[var(--success-color)] mt-1">-0.21 GB vs Last</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">GPU Metal</div>
          <div class="text-xl font-bold text-[var(--text-primary)] font-mono mt-1">32%</div>
          <div class="text-[9px] text-[var(--text-secondary)] mt-1">Metal Pipeline Active</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Energy Impact</div>
          <div class="text-xl font-bold text-[var(--success-color)] font-mono mt-1">Low</div>
          <div class="text-[9px] text-[var(--text-secondary)] mt-1">Efficient Core Priority</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Network IO</div>
          <div class="text-xl font-bold text-[var(--text-primary)] font-mono mt-1">128 KB/s</div>
          <div class="text-[9px] text-[var(--text-secondary)] mt-1">Asset Sync Queue</div>
        </div>
      </div>

      <!-- Performance Graphs (Section 20 & 56) -->
      <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
        <h2 class="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider flex items-center justify-between">
          <span>Real-time Telemetry (CPU & Memory Trace)</span>
          <span class="text-[10px] font-mono text-[var(--accent-color)]">Click spike to inspect</span>
        </h2>

        <div class="h-40 w-full relative bg-[var(--bg-elevated)] rounded-lg border border-[var(--border-color)] p-2 flex items-end">
          <svg class="w-full h-full overflow-visible" viewBox="0 0 500 100" preserveAspectRatio="none">
            <!-- Grid Lines -->
            <line x1="0" y1="25" x2="500" y2="25" stroke="var(--border-color)" stroke-dasharray="2" />
            <line x1="0" y1="50" x2="500" y2="50" stroke="var(--border-color)" stroke-dasharray="2" />
            <line x1="0" y1="75" x2="500" y2="75" stroke="var(--border-color)" stroke-dasharray="2" />

            <!-- CPU Line Path -->
            <path
              d="M 0,70 L 50,65 L 100,80 L 150,30 L 200,85 L 250,20 L 300,60 L 350,40 L 400,65 L 450,50 L 500,60"
              fill="none"
              stroke="var(--accent-color)"
              stroke-width="2.5"
            />

            <!-- Memory Line Path -->
            <path
              d="M 0,85 L 50,80 L 100,75 L 150,60 L 200,55 L 250,45 L 300,50 L 350,40 L 400,35 L 450,30 L 500,28"
              fill="none"
              stroke="var(--success-color)"
              stroke-width="2"
              stroke-dasharray="4"
            />

            <!-- Clickable Spike Dot -->
            <circle (click)="selectSpike()" cx="250" cy="20" r="5" fill="var(--error-color)" class="cursor-pointer hover:r-7 transition-all" />
          </svg>

          <!-- Spike Hover Inspector Box -->
          @if (selectedSpikeInfo()) {
            <div class="absolute top-2 left-1/2 bg-[var(--bg-system)] border border-[var(--border-color)] p-2 rounded shadow-lg text-[10px] font-mono space-y-0.5">
              <div class="font-bold text-[var(--error-color)]">CPU Peak Spike: 92%</div>
              <div>Timestamp: 10:14:52</div>
              <div>Process: xcodebuild / ExportService</div>
              <div>Related: ExportService.swift:14</div>
            </div>
          }
        </div>
      </div>

      <!-- Performance Comparison (Section 21) -->
      <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
        <h2 class="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider">
          CURRENT BUILD vs PREVIOUS BUILD
        </h2>

        <div class="grid grid-cols-3 gap-4 text-xs font-mono">
          <div class="p-3 bg-[var(--bg-elevated)] rounded-lg border border-[var(--border-color)]">
            <div class="text-[10px] text-[var(--text-secondary)] uppercase">Build Time</div>
            <div class="text-sm font-bold text-[var(--success-color)] mt-1">102s → 91s (-10.7%)</div>
          </div>

          <div class="p-3 bg-[var(--bg-elevated)] rounded-lg border border-[var(--border-color)]">
            <div class="text-[10px] text-[var(--text-secondary)] uppercase">Peak Memory</div>
            <div class="text-sm font-bold text-[var(--success-color)] mt-1">1.42GB → 1.21GB (-14.7%)</div>
          </div>

          <div class="p-3 bg-[var(--bg-elevated)] rounded-lg border border-[var(--border-color)]">
            <div class="text-[10px] text-[var(--text-secondary)] uppercase">Average CPU</div>
            <div class="text-sm font-bold text-[var(--success-color)] mt-1">74% → 68% (-8.1%)</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class PerformanceViewComponent {
  engine = inject(EngineService);
  selectedSpikeInfo = signal<boolean>(false);

  selectSpike() {
    this.selectedSpikeInfo.update(v => !v);
  }

  analyzeRegression() {
    this.engine.aiPrompt.set('Optimise video export performance and memory allocation');
    this.engine.setRoute('AI');
    this.engine.triggerAIAnalysis();
  }
}
