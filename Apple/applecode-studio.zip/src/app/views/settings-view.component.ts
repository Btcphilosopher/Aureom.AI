import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

@Component({
  selector: 'app-settings-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full flex overflow-hidden select-none">
      <!-- Settings Categories Sidebar (200px) -->
      <div class="w-52 h-full bg-[var(--bg-system)] border-r border-[var(--border-color)] p-3 space-y-1">
        <h2 class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider px-2 mb-2">
          PREFERENCES
        </h2>

        @for (cat of categories; track cat) {
          <button
            (click)="selectedCategory.set(cat)"
            [class]="selectedCategory() === cat
              ? 'bg-[var(--accent-color)] text-white font-medium shadow-2xs'
              : 'text-[var(--text-primary)] hover:bg-[var(--bg-secondary)]'"
            class="w-full text-left px-3 py-1.5 rounded-md text-xs transition-colors cursor-pointer"
          >
            {{ cat }}
          </button>
        }
      </div>

      <!-- Settings Panel Content (Flex-1) -->
      <div class="flex-1 h-full bg-[var(--bg-elevated)] p-6 overflow-y-auto space-y-6">
        <div class="border-b border-[var(--border-color)] pb-3">
          <h1 class="text-lg font-bold text-[var(--text-primary)]">{{ selectedCategory() }} Settings</h1>
          <p class="text-xs text-[var(--text-secondary)]">Configure AppleCode.Studio macOS desktop preferences</p>
        </div>

        @switch (selectedCategory()) {
          @case ('Appearance') {
            <div class="space-y-4 max-w-lg text-xs">
              <div class="space-y-1">
                <div class="font-semibold text-[var(--text-primary)]">Color Theme</div>
                <div class="flex gap-3 pt-1">
                  <button (click)="engine.isDarkMode.set(false)" [class.border-[var(--accent-color)]]="!engine.isDarkMode()" class="px-3 py-2 rounded-lg border bg-white text-black font-medium cursor-pointer">
                    Light Theme
                  </button>
                  <button (click)="engine.isDarkMode.set(true)" [class.border-[var(--accent-color)]]="engine.isDarkMode()" class="px-3 py-2 rounded-lg border bg-black text-white font-medium cursor-pointer">
                    Dark Theme
                  </button>
                </div>
              </div>
            </div>
          }

          @case ('AI Engineer') {
            <div class="space-y-4 max-w-lg text-xs">
              <div class="p-3 rounded-lg bg-[var(--bg-system)] border border-[var(--border-color)] space-y-2">
                <div class="flex items-center justify-between">
                  <div>
                    <div class="font-bold text-[var(--text-primary)]">Autonomous Patch Mode</div>
                    <div class="text-[11px] text-[var(--text-secondary)]">Automatically apply patches without explicit code review prompt</div>
                  </div>
                  <input
                    type="checkbox"
                    [checked]="engine.autonomousMode()"
                    (change)="engine.autonomousMode.set(!engine.autonomousMode())"
                    class="accent-[var(--accent-color)] cursor-pointer"
                  />
                </div>
              </div>

              <div class="p-3 rounded-lg bg-[var(--bg-system)] border border-[var(--border-color)] space-y-1">
                <div class="font-bold text-[var(--text-primary)]">Python Engine Communication</div>
                <div class="text-[11px] text-[var(--text-secondary)] font-mono">http://127.0.0.1:8080/api/engine</div>
                <div class="text-[10px] text-[var(--success-color)] font-mono">● Process Active</div>
              </div>
            </div>
          }

          @default {
            <div class="space-y-4 max-w-lg text-xs">
              <div class="p-3 bg-[var(--bg-system)] border border-[var(--border-color)] rounded-lg space-y-2">
                <div class="font-bold text-[var(--text-primary)]">{{ selectedCategory() }} Configuration</div>
                <p class="text-[11px] text-[var(--text-secondary)]">All options for {{ selectedCategory() }} are active and synchronized with the local Python engine.</p>
              </div>
            </div>
          }
        }
      </div>
    </div>
  `
})
export class SettingsViewComponent {
  engine = inject(EngineService);
  categories = [
    'General', 'Appearance', 'Editor', 'AI Engineer', 'Build Control',
    'Testing', 'Devices', 'Performance', 'Security', 'Git', 'Advanced'
  ];
  selectedCategory = signal<string>('Appearance');
}
