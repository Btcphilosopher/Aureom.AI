import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';
import { DeviceItem } from '../models/studio.models';

@Component({
  selector: 'app-device-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 select-none">
      <!-- Title Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[var(--border-color)]">
        <div>
          <h1 class="text-xl font-bold text-[var(--text-primary)]">DISCOVERED SIMULATORS & HARDWARE</h1>
          <p class="text-xs text-[var(--text-secondary)]">xcodebuild / simctl backend runtime device manager</p>
        </div>

        <button (click)="refreshDevices()" class="px-3 py-1.5 rounded-md bg-[var(--bg-secondary)] border border-[var(--border-color)] text-xs text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] flex items-center gap-1">
          <span class="material-icons text-xs">refresh</span>
          <span>Refresh simctl list</span>
        </button>
      </div>

      <!-- Device Cards Grid (Section 19) -->
      <div class="grid grid-cols-3 gap-4">
        @for (dev of engine.devices(); track dev.id) {
          <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3 shadow-2xs">
            <div class="flex items-start justify-between">
              <div class="flex items-center space-x-3">
                <div class="w-10 h-10 rounded-lg bg-[var(--accent-color)]/10 text-[var(--accent-color)] flex items-center justify-center">
                  <span class="material-icons text-xl">{{ getDeviceIcon(dev.deviceType) }}</span>
                </div>
                <div>
                  <h3 class="font-bold text-xs text-[var(--text-primary)]">{{ dev.name }}</h3>
                  <div class="text-[10px] text-[var(--text-secondary)] font-mono">{{ dev.os }} · {{ dev.architecture }}</div>
                </div>
              </div>

              <span
                [class]="dev.status === 'BOOTED'
                  ? 'bg-[var(--success-color)]/15 text-[var(--success-color)]'
                  : 'bg-[var(--bg-secondary)] text-[var(--text-secondary)]'"
                class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
              >
                {{ dev.status }}
              </span>
            </div>

            <!-- Device Actions -->
            <div class="pt-2 border-t border-[var(--border-color)] flex items-center justify-between text-xs">
              <div class="space-x-1">
                @if (dev.status === 'SHUTDOWN') {
                  <button (click)="toggleDevice(dev)" class="px-2.5 py-1 bg-[var(--accent-color)] text-white rounded text-[11px] font-medium hover:opacity-90">
                    Boot
                  </button>
                } @else {
                  <button (click)="toggleDevice(dev)" class="px-2.5 py-1 bg-[var(--bg-secondary)] text-[var(--text-primary)] border border-[var(--border-color)] rounded text-[11px] hover:bg-[var(--bg-elevated)]">
                    Shutdown
                  </button>
                }

                <button (click)="launchApp(dev)" [disabled]="dev.status === 'SHUTDOWN'" class="px-2.5 py-1 bg-[var(--bg-secondary)] text-[var(--text-primary)] border border-[var(--border-color)] rounded text-[11px] disabled:opacity-40">
                  Launch App
                </button>
              </div>

              <button (click)="viewLogs(dev)" class="text-[11px] text-[var(--accent-color)] font-medium hover:underline">
                Logs →
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class DeviceViewComponent {
  engine = inject(EngineService);

  getDeviceIcon(type: string): string {
    switch (type) {
      case 'Mac': return 'desktop_mac';
      case 'iPhone': return 'smartphone';
      case 'iPad': return 'tablet_mac';
      case 'Apple Watch': return 'watch';
      case 'Apple TV': return 'tv';
      case 'Vision Pro': return 'visibility';
      default: return 'devices';
    }
  }

  toggleDevice(dev: DeviceItem) {
    const list = this.engine.devices().map(d => {
      if (d.id === dev.id) {
        return { ...d, status: (d.status === 'BOOTED' ? 'SHUTDOWN' : 'BOOTED') as 'BOOTED' | 'SHUTDOWN' };
      }
      return d;
    });
    this.engine.devices.set(list);
    this.engine.addLog('Simulator', 'INFO', `simctl state change for ${dev.name}: now ${dev.status === 'BOOTED' ? 'SHUTDOWN' : 'BOOTED'}`);
  }

  launchApp(dev: DeviceItem) {
    this.engine.addLog('Simulator', 'SUCCESS', `Installed and launched ${this.engine.activeProject().name} on ${dev.name}`);
  }

  viewLogs(dev: DeviceItem) {
    this.engine.activeLogCategory.set('Simulator');
    this.engine.bottomDrawerOpen.set(true);
    this.engine.addLog('Simulator', 'INFO', `Streaming simctl log stream for ${dev.name}...`);
  }

  refreshDevices() {
    this.engine.addLog('Simulator', 'INFO', 'Discovered 6 Apple runtime platforms from simctl API.');
  }
}
