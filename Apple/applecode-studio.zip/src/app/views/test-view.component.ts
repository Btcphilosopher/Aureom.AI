import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';
import { TestCase } from '../models/studio.models';

@Component({
  selector: 'app-test-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 select-none">
      <!-- Title Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[var(--border-color)]">
        <div>
          <h1 class="text-xl font-bold text-[var(--text-primary)]">TEST LAB & XCTEST SUITES</h1>
          <p class="text-xs text-[var(--text-secondary)]">Automated unit, integration, UI, and regression test orchestrator</p>
        </div>

        <button (click)="engine.setRoute('Tests')" class="px-3 py-1.5 rounded-md bg-[var(--accent-color)] text-white text-xs font-semibold hover:opacity-90 flex items-center gap-1 cursor-pointer">
          <span class="material-icons text-xs">play_arrow</span>
          <span>Run All Tests (⌘U)</span>
        </button>
      </div>

      <!-- Test Summary Bar (Section 17) -->
      <div class="grid grid-cols-4 gap-4">
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">Total Tests</div>
          <div class="text-2xl font-bold text-[var(--text-primary)] mt-1 font-mono">1,842</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">Passed</div>
          <div class="text-2xl font-bold text-[var(--success-color)] mt-1 font-mono">1,839</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">Failed</div>
          <div class="text-2xl font-bold text-[var(--error-color)] mt-1 font-mono">3</div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 shadow-2xs">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider">Pass Rate</div>
          <div class="text-2xl font-bold text-[var(--success-color)] mt-1 font-mono">99.8%</div>
        </div>
      </div>

      <!-- Test Failure Detailed Inspector (Section 18) -->
      <div class="space-y-3">
        <h2 class="text-xs font-bold text-[var(--error-color)] uppercase tracking-wider flex items-center gap-1.5">
          <span class="material-icons text-sm">error</span>
          <span>Failing Test Assertions (3)</span>
        </h2>

        <div class="space-y-3">
          @for (test of engine.failedTests(); track test.id) {
            <div class="bg-[var(--bg-system)] border border-[var(--error-color)]/30 rounded-xl p-4 space-y-3 shadow-2xs">
              <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-2">
                <div class="flex items-center space-x-2">
                  <span class="px-2 py-0.5 rounded bg-[var(--error-color)]/15 text-[var(--error-color)] font-mono text-[10px] font-bold uppercase">FAILED</span>
                  <span class="font-bold text-xs text-[var(--text-primary)] font-mono">{{ test.suite }}.{{ test.name }}</span>
                </div>
                <span class="text-xs font-mono text-[var(--text-secondary)]">{{ test.file }}:{{ test.line }}</span>
              </div>

              <!-- Assertion Details: Expected vs Actual -->
              <div class="grid grid-cols-2 gap-3 text-xs font-mono">
                <div class="p-2.5 rounded bg-[var(--bg-elevated)] border border-[var(--border-color)]">
                  <div class="text-[10px] text-[var(--text-secondary)] uppercase">Expected Output</div>
                  <div class="font-semibold text-[var(--success-color)] mt-0.5">{{ test.expected }}</div>
                </div>

                <div class="p-2.5 rounded bg-[var(--bg-elevated)] border border-[var(--border-color)]">
                  <div class="text-[10px] text-[var(--text-secondary)] uppercase">Actual Measured Output</div>
                  <div class="font-semibold text-[var(--error-color)] mt-0.5">{{ test.actual }}</div>
                </div>
              </div>

              <p class="text-xs text-[var(--error-color)] italic font-mono">{{ test.failureMessage }}</p>

              <!-- Action Buttons (Section 18) -->
              <div class="flex items-center space-x-2 pt-1 text-xs">
                <button
                  (click)="explainWithAi(test)"
                  class="px-3 py-1 rounded bg-[var(--accent-color)] text-white font-medium hover:opacity-90 flex items-center gap-1 cursor-pointer"
                >
                  <span class="material-icons text-xs">auto_awesome</span>
                  <span>Explain & Remediate with AI</span>
                </button>

                <button (click)="engine.setRoute('Code')" class="px-3 py-1 rounded border border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] cursor-pointer">
                  Open Source File
                </button>

                <button (click)="runTestAgain(test)" class="px-3 py-1 rounded border border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] cursor-pointer">
                  Run Again
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class TestViewComponent {
  engine = inject(EngineService);

  explainWithAi(test: TestCase) {
    this.engine.aiPrompt.set(`Explain test failure in ${test.suite}.${test.name} at line ${test.line}`);
    this.engine.setRoute('AI');
    this.engine.triggerAIAnalysis();
  }

  runTestAgain(test: TestCase) {
    this.engine.addLog('Test', 'INFO', `Re-executing test ${test.name}...`);
  }
}
