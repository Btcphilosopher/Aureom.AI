import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

@Component({
  selector: 'app-build-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 select-none">
      <!-- Title Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[var(--border-color)]">
        <div>
          <h1 class="text-xl font-bold text-[var(--text-primary)]">BUILD CONTROL & ORCHESTRATION</h1>
          <p class="text-xs text-[var(--text-secondary)]">xcodebuild native toolchain pipeline executor</p>
        </div>

        <div class="flex items-center space-x-2 text-xs font-mono">
          <span class="px-2 py-1 rounded bg-[var(--bg-system)] border border-[var(--border-color)] text-[var(--text-secondary)]">
            Xcode 16.1 (16B40)
          </span>
          <span class="px-2 py-1 rounded bg-[var(--bg-system)] border border-[var(--border-color)] text-[var(--text-secondary)]">
            macOS 15.1 SDK
          </span>
        </div>
      </div>

      <!-- Target Config & Destination Selector -->
      <div class="grid grid-cols-3 gap-4">
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-2">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider block">Target</div>
          <div class="font-semibold text-sm text-[var(--text-primary)] flex items-center gap-2">
            <span class="material-icons text-base text-[var(--accent-color)]">folder_special</span>
            <span>{{ engine.selectedTarget() }}</span>
          </div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-2">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider block">Configuration</div>
          <div class="font-semibold text-sm text-[var(--text-primary)] flex items-center gap-2">
            <span class="material-icons text-base text-[var(--warning-color)]">tune</span>
            <span>{{ engine.selectedConfig() }}</span>
          </div>
        </div>

        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-2">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] uppercase tracking-wider block">Destination</div>
          <div class="font-semibold text-sm text-[var(--text-primary)] flex items-center gap-2">
            <span class="material-icons text-base text-[var(--success-color)]">desktop_mac</span>
            <span>My Mac (M3 Max)</span>
          </div>
        </div>
      </div>

      <!-- Large Central Build Control (Section 15) -->
      <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-8 text-center space-y-4 shadow-2xs">
        <div class="max-w-md mx-auto space-y-3">
          <button
            (click)="engine.triggerBuild()"
            [disabled]="engine.isBuilding()"
            class="w-full py-4 bg-[var(--accent-color)] text-white text-base font-bold rounded-xl shadow-lg hover:opacity-95 disabled:opacity-50 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            @if (engine.isBuilding()) {
              <span class="material-icons text-xl animate-spin">sync</span>
              <span>BUILDING TARGET...</span>
            } @else {
              <span class="material-icons text-xl">play_circle</span>
              <span>BUILD NOW (⌘B)</span>
            }
          </button>

          <!-- Result banner after build -->
          @if (engine.lastBuildResult(); as build) {
            <div class="p-3 bg-[var(--success-color)]/10 border border-[var(--success-color)]/30 rounded-lg flex items-center justify-between text-xs">
              <div class="flex items-center gap-2 font-bold text-[var(--success-color)]">
                <span class="material-icons text-sm">check_circle</span>
                <span>BUILD SUCCEEDED</span>
              </div>
              <div class="font-mono text-[var(--text-secondary)] space-x-3">
                <span>Duration: <strong>{{ build.durationSeconds }}s</strong></span>
                <span class="text-[var(--warning-color)]">Warnings: <strong>{{ build.warningsCount }}</strong></span>
                <span>Errors: <strong>{{ build.errorsCount }}</strong></span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Build Timeline Stages (Section 16) -->
      @if (engine.lastBuildResult(); as build) {
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
          <h2 class="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider flex items-center gap-1.5">
            <span class="material-icons text-sm text-[var(--accent-color)]">schedule</span>
            <span>Build Pipeline Timeline & Stage Durations</span>
          </h2>

          <div class="grid grid-cols-5 gap-3 pt-2">
            @for (stage of build.stages; track stage.name) {
              <div class="p-3 rounded-lg bg-[var(--bg-elevated)] border border-[var(--border-color)] space-y-1 relative overflow-hidden">
                <div class="text-[11px] font-semibold text-[var(--text-primary)] truncate">{{ stage.name }}</div>
                <div class="text-xs font-mono font-bold text-[var(--accent-color)]">{{ stage.durationSeconds }}s</div>
                <div class="w-full bg-[var(--bg-secondary)] h-1 rounded-full overflow-hidden mt-2">
                  <div class="bg-[var(--success-color)] h-full w-full"></div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Build Warnings / Diagnostics -->
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
          <h2 class="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider flex items-center gap-1.5">
            <span class="material-icons text-sm text-[var(--warning-color)]">warning</span>
            <span>Compiler Diagnostics & Warnings ({{ build.diagnostics.length }})</span>
          </h2>

          <div class="space-y-2 text-xs font-mono">
            @for (diag of build.diagnostics; track diag.message) {
              <div class="p-2.5 rounded-lg bg-[var(--warning-color)]/10 border border-[var(--warning-color)]/20 flex items-start justify-between">
                <div>
                  <div class="font-bold text-[var(--warning-color)]">{{ diag.file }}:{{ diag.line }}:{{ diag.column }}</div>
                  <div class="text-[var(--text-primary)] mt-0.5">{{ diag.message }}</div>
                </div>
                <button (click)="engine.setRoute('Code')" class="text-[10px] text-[var(--accent-color)] font-sans hover:underline cursor-pointer">View in Code →</button>
              </div>
            }
          </div>
        </div>
      }
    </div>
  `
})
export class BuildViewComponent {
  engine = inject(EngineService);
}
