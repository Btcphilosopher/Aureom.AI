import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';
import { ArchNode } from '../models/studio.models';

@Component({
  selector: 'app-architecture-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full flex overflow-hidden select-none">
      <!-- Main Canvas Area -->
      <div class="flex-1 h-full bg-[var(--bg-system)] flex flex-col relative overflow-hidden">
        <!-- Canvas Toolbar Header -->
        <div class="h-10 border-b border-[var(--border-color)] px-4 flex items-center justify-between text-xs font-mono bg-[var(--bg-elevated)]">
          <div class="flex items-center space-x-2">
            <span class="material-icons text-sm text-[var(--accent-color)]">hub</span>
            <span class="font-bold text-[var(--text-primary)]">ARCHITECTURE & DEPENDENCY GRAPH</span>
          </div>

          <!-- Zoom & Controls -->
          <div class="flex items-center space-x-2">
            <button (click)="zoomOut()" class="p-1 hover:bg-[var(--bg-secondary)] rounded border border-[var(--border-color)] cursor-pointer">
              <span class="material-icons text-xs block">remove</span>
            </button>
            <span class="text-[11px] font-mono text-[var(--text-secondary)] px-1">{{ zoomLevel() }}%</span>
            <button (click)="zoomIn()" class="p-1 hover:bg-[var(--bg-secondary)] rounded border border-[var(--border-color)] cursor-pointer">
              <span class="material-icons text-xs block">add</span>
            </button>
            <button (click)="resetZoom()" class="p-1 hover:bg-[var(--bg-secondary)] rounded border border-[var(--border-color)] text-[10px] font-mono px-1.5 cursor-pointer">
              Reset
            </button>
          </div>
        </div>

        <!-- Canvas Area -->
        <div class="flex-1 relative overflow-auto p-8 flex items-center justify-center bg-[var(--bg-system)]">
          <div
            [style.transform]="'scale(' + zoomLevel() / 100 + ')'"
            class="relative w-[700px] h-[450px] transition-transform duration-150 border border-[var(--border-color)] rounded-2xl bg-[var(--bg-elevated)] p-6 shadow-xl"
          >
            <!-- Render SVG Connection Lines -->
            <svg class="absolute inset-0 w-full h-full pointer-events-none stroke-[var(--border-color)]" style="stroke-width: 2;">
              <!-- App to Views -->
              <line x1="350" y1="80" x2="200" y2="180" stroke-dasharray="4" />
              <!-- App to Services -->
              <line x1="350" y1="80" x2="500" y2="180" />
              <!-- Views to Services -->
              <line x1="200" y1="180" x2="500" y2="180" stroke-dasharray="4" />
              <!-- Services to VideoToolbox -->
              <line x1="500" y1="180" x2="350" y2="340" />
            </svg>

            <!-- Render Nodes -->
            @for (node of engine.archNodes(); track node.id) {
              <button
                (click)="selectNode(node)"
                [style.left.px]="node.x"
                [style.top.px]="node.y"
                [class]="selectedNode()?.id === node.id
                  ? 'border-[var(--accent-color)] shadow-lg scale-105 bg-[var(--accent-color)]/10'
                  : 'border-[var(--border-color)] bg-[var(--bg-system)] hover:border-[var(--accent-color)]/50'"
                class="absolute w-44 p-3 rounded-xl border transition-all cursor-pointer space-y-1 text-left outline-none"
              >
                <div class="flex items-center justify-between">
                  <span class="font-bold text-xs text-[var(--text-primary)] truncate">{{ node.label }}</span>
                  <span class="text-[9px] px-1.5 py-0.2 rounded bg-[var(--bg-secondary)] text-[var(--text-secondary)] font-mono">{{ node.type }}</span>
                </div>
                <div class="text-[10px] text-[var(--text-secondary)] font-mono">{{ node.linesCount }} LOC</div>
              </button>
            }
          </div>
        </div>
      </div>

      <!-- Node Inspector Sidebar (280px) -->
      <div class="w-72 h-full bg-[var(--bg-system)] border-l border-[var(--border-color)] p-4 flex flex-col space-y-4">
        <h2 class="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider border-b border-[var(--border-color)] pb-2 flex items-center justify-between">
          <span>NODE INSPECTOR</span>
          <span class="material-icons text-sm text-[var(--accent-color)]">info</span>
        </h2>

        @if (selectedNode(); as node) {
          <div class="space-y-3 text-xs">
            <div class="p-3 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-xl space-y-1">
              <div class="font-bold text-sm text-[var(--text-primary)]">{{ node.label }}</div>
              <div class="text-[11px] text-[var(--text-secondary)] font-mono">Type: {{ node.type }}</div>
              <div class="text-[11px] text-[var(--text-secondary)] font-mono">Lines of Code: {{ node.linesCount }}</div>
            </div>

            <div class="space-y-1">
              <h3 class="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Outgoing Dependencies</h3>
              <div class="p-2 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-lg font-mono text-[11px]">
                @for (dep of node.dependencies; track dep) {
                  <div>→ {{ dep }}</div>
                } @empty {
                  <div class="text-[var(--text-secondary)] italic">No outgoing dependencies</div>
                }
              </div>
            </div>

            <button
              (click)="analyzeArchitecture(node)"
              class="w-full py-2 bg-[var(--accent-color)] text-white font-semibold text-xs rounded-lg hover:opacity-90 transition-opacity flex items-center justify-center gap-1 shadow-2xs cursor-pointer"
            >
              <span class="material-icons text-xs">auto_awesome</span>
              <span>Analyse {{ node.label }} with AI</span>
            </button>
          </div>
        } @else {
          <div class="text-xs text-[var(--text-secondary)] italic text-center py-8">
            Click any module node in the graph to inspect its dependencies.
          </div>
        }
      </div>
    </div>
  `
})
export class ArchitectureViewComponent {
  engine = inject(EngineService);
  zoomLevel = signal<number>(100);
  selectedNode = signal<ArchNode | null>(null);

  selectNode(node: ArchNode) {
    this.selectedNode.set(node);
  }

  zoomIn() {
    this.zoomLevel.update(z => Math.min(150, z + 10));
  }

  zoomOut() {
    this.zoomLevel.update(z => Math.max(70, z - 10));
  }

  resetZoom() {
    this.zoomLevel.set(100);
  }

  analyzeArchitecture(node: ArchNode) {
    this.engine.aiPrompt.set(`Analyse dependency architecture for module ${node.label}`);
    this.engine.setRoute('AI');
    this.engine.triggerAIAnalysis();
  }
}
