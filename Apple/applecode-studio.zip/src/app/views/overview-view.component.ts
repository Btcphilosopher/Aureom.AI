import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

@Component({
  selector: 'app-overview-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6">
      <!-- Top Title Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[var(--border-color)]">
        <div>
          <h1 class="text-xl font-bold text-[var(--text-primary)] flex items-center gap-2">
            <span>{{ engine.activeProject().name }}</span>
            <span class="text-xs px-2 py-0.5 rounded-full bg-[var(--accent-color)]/10 text-[var(--accent-color)] font-mono font-medium">
              {{ engine.activeProject().platform }} Application
            </span>
          </h1>
          <p class="text-xs text-[var(--text-secondary)] mt-0.5 font-mono">{{ engine.activeProject().path }}</p>
        </div>

        <div class="flex items-center space-x-2">
          <button (click)="engine.triggerBuild()" class="px-3 py-1.5 rounded-md bg-[var(--accent-color)] text-white text-xs font-medium hover:opacity-90 transition-opacity flex items-center gap-1 shadow-2xs cursor-pointer">
            <span class="material-icons text-xs">play_arrow</span>
            <span>Build Project</span>
          </button>
          <button (click)="engine.setRoute('AI')" class="px-3 py-1.5 rounded-md bg-[var(--bg-secondary)] border border-[var(--border-color)] text-xs text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] transition-colors flex items-center gap-1 cursor-pointer">
            <span class="material-icons text-xs text-[var(--accent-color)]">auto_awesome</span>
            <span>AI Optimization</span>
          </button>
        </div>
      </div>

      <!-- Compact Status Indicators (Section 7) -->
      <div class="grid grid-cols-5 gap-3">
        <button (click)="engine.setRoute('Builds')" class="text-left bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs hover:border-[var(--accent-color)] transition-all cursor-pointer">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] tracking-wider uppercase mb-1">BUILD</div>
          <div class="text-sm font-bold text-[var(--success-color)] flex items-center gap-1">
            <span class="material-icons text-sm">check_circle</span>
            <span>PASS</span>
          </div>
          <div class="text-[10px] text-[var(--text-secondary)] mt-1 font-mono">38.4s · 0 Errors</div>
        </button>

        <button (click)="engine.setRoute('Tests')" class="text-left bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs hover:border-[var(--accent-color)] transition-all cursor-pointer">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] tracking-wider uppercase mb-1">TESTS</div>
          <div class="text-sm font-bold text-[var(--success-color)] flex items-center gap-1">
            <span class="material-icons text-sm">fact_check</span>
            <span>1,842 PASS</span>
          </div>
          <div class="text-[10px] text-[var(--warning-color)] mt-1 font-mono">3 Suites failing</div>
        </button>

        <button (click)="engine.setRoute('Security')" class="text-left bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs hover:border-[var(--accent-color)] transition-all cursor-pointer">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] tracking-wider uppercase mb-1">SECURITY</div>
          <div class="text-sm font-bold text-[var(--success-color)] flex items-center gap-1">
            <span class="material-icons text-sm">verified_user</span>
            <span>GOOD</span>
          </div>
          <div class="text-[10px] text-[var(--text-secondary)] mt-1 font-mono">0 Credentials exposed</div>
        </button>

        <button (click)="engine.setRoute('Performance')" class="text-left bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs hover:border-[var(--accent-color)] transition-all cursor-pointer">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] tracking-wider uppercase mb-1">PERFORMANCE</div>
          <div class="text-sm font-bold text-[var(--success-color)] flex items-center gap-1">
            <span class="material-icons text-sm">speed</span>
            <span>STABLE</span>
          </div>
          <div class="text-[10px] text-[var(--text-secondary)] mt-1 font-mono">CPU 48% · 1.21 GB</div>
        </button>

        <button (click)="engine.setRoute('Architecture')" class="text-left bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-3 shadow-2xs hover:border-[var(--accent-color)] transition-all cursor-pointer">
          <div class="text-[10px] font-bold text-[var(--text-secondary)] tracking-wider uppercase mb-1">ARCHITECTURE</div>
          <div class="text-sm font-bold text-[var(--success-color)] flex items-center gap-1">
            <span class="material-icons text-sm">hub</span>
            <span>HEALTHY</span>
          </div>
          <div class="text-[10px] text-[var(--text-secondary)] mt-1 font-mono">4 Core Modules</div>
        </button>
      </div>

      <!-- Project Health Summary & Engineering Context -->
      <div class="grid grid-cols-3 gap-6">
        <!-- Left 2 Cols: Engineering Metrics & Recent AI Actions -->
        <div class="col-span-2 space-y-4">
          <!-- Project Health Card -->
          <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-2">
              <h2 class="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-1.5">
                <span class="material-icons text-sm text-[var(--accent-color)]">insights</span>
                <span>Project Health & Index Score</span>
              </h2>
              <span class="text-xs font-mono text-[var(--success-color)] font-bold">98 / 100</span>
            </div>

            <div class="space-y-2.5 text-xs">
              <div>
                <div class="flex justify-between text-[11px] mb-1">
                  <span class="text-[var(--text-secondary)]">Compiler & Symbol Resolution</span>
                  <span class="font-mono text-[var(--text-primary)]">100%</span>
                </div>
                <div class="w-full bg-[var(--bg-secondary)] h-1.5 rounded-full overflow-hidden">
                  <div class="bg-[var(--success-color)] h-full w-full"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-[11px] mb-1">
                  <span class="text-[var(--text-secondary)]">Test Coverage (Unit & Integration)</span>
                  <span class="font-mono text-[var(--text-primary)]">89.4%</span>
                </div>
                <div class="w-full bg-[var(--bg-secondary)] h-1.5 rounded-full overflow-hidden">
                  <div class="bg-[var(--accent-color)] h-full w-[89.4%]"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between text-[11px] mb-1">
                  <span class="text-[var(--text-secondary)]">Memory & Energy Efficiency</span>
                  <span class="font-mono text-[var(--text-primary)]">94.0%</span>
                </div>
                <div class="w-full bg-[var(--bg-secondary)] h-1.5 rounded-full overflow-hidden">
                  <div class="bg-[var(--success-color)] h-full w-[94%]"></div>
                </div>
              </div>
            </div>
          </div>

          <!-- Active AI Recommendations -->
          <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-2">
              <h2 class="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider flex items-center gap-1.5">
                <span class="material-icons text-sm text-[var(--accent-color)]">auto_awesome</span>
                <span>AI Engineering Insights</span>
              </h2>
              <button (click)="engine.setRoute('AI')" class="text-[11px] text-[var(--accent-color)] hover:underline cursor-pointer">View All Plans →</button>
            </div>

            <div class="p-3 bg-[var(--bg-secondary)] border border-[var(--border-color)] rounded-lg space-y-2">
              <div class="flex items-center justify-between">
                <span class="font-semibold text-xs text-[var(--text-primary)]">4K Video Export Thread Bottleneck</span>
                <span class="text-[10px] px-2 py-0.5 rounded bg-[var(--warning-color)]/15 text-[var(--warning-color)] font-mono">Performance Impact</span>
              </div>
              <p class="text-xs text-[var(--text-secondary)]">
                Synchronous call to <code class="font-mono text-[var(--text-primary)]">VTCompressionSession.encode()</code> blocks frame queue on main thread. AI has prepared an async background task patch.
              </p>
              <div class="pt-1 flex items-center gap-2">
                <button (click)="engine.setRoute('AI')" class="px-2.5 py-1 rounded bg-[var(--accent-color)] text-white text-[11px] font-medium hover:opacity-90 cursor-pointer">
                  Review AI Patch
                </button>
                <button (click)="engine.triggerAIAnalysis()" class="px-2.5 py-1 rounded border border-[var(--border-color)] text-[11px] text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] cursor-pointer">
                  Re-analyze
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Right Col: Discovered Devices & Targets -->
        <div class="space-y-4">
          <!-- Active Targets -->
          <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
            <h2 class="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider border-b border-[var(--border-color)] pb-2">
              Targets & Frameworks
            </h2>
            <div class="space-y-2 text-xs">
              <div class="p-2 rounded bg-[var(--bg-secondary)] border border-[var(--border-color)] flex justify-between items-center">
                <div>
                  <div class="font-medium text-[var(--text-primary)]">MyVideoApp</div>
                  <div class="text-[10px] text-[var(--text-secondary)] font-mono">macOS Application · Swift 5.10</div>
                </div>
                <span class="text-[10px] px-1.5 py-0.5 rounded bg-[var(--success-color)]/15 text-[var(--success-color)]">Active</span>
              </div>

              <div class="p-2 rounded bg-[var(--bg-secondary)] border border-[var(--border-color)] flex justify-between items-center">
                <div>
                  <div class="font-medium text-[var(--text-primary)]">ExportServiceCore</div>
                  <div class="text-[10px] text-[var(--text-secondary)] font-mono">Dynamic Framework</div>
                </div>
                <span class="text-[10px] px-1.5 py-0.5 rounded bg-[var(--bg-elevated)] text-[var(--text-secondary)]">Framework</span>
              </div>
            </div>
          </div>

          <!-- Connected Simulator Devices -->
          <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-2">
              <h2 class="text-xs font-bold text-[var(--text-primary)] uppercase tracking-wider">
                Detected Simulators
              </h2>
              <button (click)="engine.setRoute('Simulator')" class="text-[11px] text-[var(--accent-color)] cursor-pointer">View All →</button>
            </div>

            <div class="space-y-2 text-xs">
              @for (dev of engine.devices().slice(0, 3); track dev.id) {
                <div class="flex items-center justify-between p-2 rounded bg-[var(--bg-secondary)] border border-[var(--border-color)]">
                  <div class="flex items-center space-x-2">
                    <span class="material-icons text-sm text-[var(--text-secondary)]">
                      {{ dev.deviceType === 'Mac' ? 'desktop_mac' : dev.deviceType === 'iPhone' ? 'smartphone' : 'devices' }}
                    </span>
                    <div>
                      <div class="font-medium text-[var(--text-primary)] text-[11px] truncate max-w-[130px]">{{ dev.name }}</div>
                      <div class="text-[9px] text-[var(--text-secondary)] font-mono">{{ dev.os }} · {{ dev.architecture }}</div>
                    </div>
                  </div>
                  <span
                    [class]="dev.status === 'BOOTED' ? 'text-[var(--success-color)] bg-[var(--success-color)]/10' : 'text-[var(--text-secondary)] bg-[var(--bg-elevated)]'"
                    class="text-[9px] px-1.5 py-0.5 rounded font-mono font-medium"
                  >
                    {{ dev.status }}
                  </span>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OverviewViewComponent {
  engine = inject(EngineService);
}
