import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

@Component({
  selector: 'app-ai-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 select-none">
      <!-- Title Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[var(--border-color)]">
        <div class="flex items-center space-x-3">
          <div class="w-8 h-8 rounded-lg bg-[var(--accent-color)]/10 text-[var(--accent-color)] flex items-center justify-center">
            <span class="material-icons">auto_awesome</span>
          </div>
          <div>
            <h1 class="text-xl font-bold text-[var(--text-primary)]">AI ENGINE WORKSPACE</h1>
            <p class="text-xs text-[var(--text-secondary)]">Autonomous Engineering Intelligence & Code Patch Generator</p>
          </div>
        </div>

        <div class="flex items-center space-x-3 text-xs">
          <label for="autonomous-toggle" class="flex items-center gap-2 cursor-pointer bg-[var(--bg-system)] border border-[var(--border-color)] px-3 py-1.5 rounded-lg">
            <span class="text-[var(--text-secondary)]">Autonomous Mode:</span>
            <input
              id="autonomous-toggle"
              type="checkbox"
              [checked]="engine.autonomousMode()"
              (change)="engine.autonomousMode.set(!engine.autonomousMode())"
              class="accent-[var(--accent-color)] cursor-pointer"
            />
            <span [class]="engine.autonomousMode() ? 'text-[var(--warning-color)] font-bold' : 'text-[var(--text-secondary)]'">
              {{ engine.autonomousMode() ? 'ON (Auto-Apply)' : 'OFF (Requires Review)' }}
            </span>
          </label>
        </div>
      </div>

      <!-- AI Prompt Bar (Section 11) -->
      <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 shadow-2xs space-y-3">
        <div class="block text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider">
          What should I change in {{ engine.activeProject().name }}?
        </div>
        <div class="flex items-center gap-3">
          <input
            type="text"
            [value]="engine.aiPrompt()"
            (input)="onPromptInput($event)"
            placeholder="e.g. Optimise video export performance, fix memory leak, add unit test..."
            class="flex-1 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-lg px-3 py-2 text-xs text-[var(--text-primary)] outline-none focus:border-[var(--accent-color)] font-sans"
          />
          <button
            (click)="engine.triggerAIAnalysis()"
            [disabled]="engine.isAiAnalyzing()"
            class="px-4 py-2 bg-[var(--accent-color)] text-white text-xs font-semibold rounded-lg hover:opacity-90 disabled:opacity-50 transition-all flex items-center gap-1.5 shadow-2xs cursor-pointer"
          >
            @if (engine.isAiAnalyzing()) {
              <span class="material-icons text-xs animate-spin">sync</span>
              <span>ANALYSING...</span>
            } @else {
              <span class="material-icons text-xs">play_arrow</span>
              <span>Analyse & Generate Patch</span>
            }
          </button>
        </div>
      </div>

      <!-- Live Pipeline State & Activity Panel (Section 14) -->
      <div class="grid grid-cols-4 gap-4">
        <!-- Live Status Indicators -->
        <div class="col-span-3 bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
          <h2 class="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider flex items-center gap-1.5">
            <span class="material-icons text-sm text-[var(--accent-color)]">timeline</span>
            <span>AI Pipeline Execution Workflow</span>
          </h2>

          <div class="grid grid-cols-5 gap-2 text-[11px] text-center font-mono">
            <div [class]="getPipelineStepClass(1)" class="p-2 rounded-lg border">
              1. ANALYSING
            </div>
            <div [class]="getPipelineStepClass(3)" class="p-2 rounded-lg border">
              2. CONTEXT
            </div>
            <div [class]="getPipelineStepClass(5)" class="p-2 rounded-lg border">
              3. FILES
            </div>
            <div [class]="getPipelineStepClass(7)" class="p-2 rounded-lg border">
              4. PLANNING
            </div>
            <div [class]="getPipelineStepClass(8)" class="p-2 rounded-lg border">
              5. PATCH READY
            </div>
          </div>
        </div>

        <!-- Live Activity Tracker -->
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-2">
          <h2 class="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider">
            AI Engine Activity
          </h2>
          <div class="space-y-1 text-xs font-mono">
            <div class="flex items-center gap-2 text-[var(--success-color)]">
              <span>●</span>
              <span>Analysing 12 files</span>
            </div>
            <div class="flex items-center gap-2 text-[var(--success-color)]">
              <span>●</span>
              <span>Building dependency graph</span>
            </div>
            <div class="flex items-center gap-2 text-[var(--success-color)]">
              <span>●</span>
              <span>Reviewing ExportService</span>
            </div>
            <div [class]="engine.isAiAnalyzing() ? 'text-[var(--accent-color)] animate-pulse' : 'text-[var(--text-secondary)]'" class="flex items-center gap-2">
              <span>○</span>
              <span>Generate patch & run tests</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Implementation Plan (Section 12) -->
      @if (engine.aiActivePatch(); as patch) {
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-3">
            <div>
              <h2 class="text-sm font-bold text-[var(--text-primary)]">Implementation Plan</h2>
              <p class="text-xs text-[var(--text-secondary)]">{{ patch.summary }}</p>
            </div>
            <div class="flex items-center space-x-2">
              <button (click)="engine.applyPatch()" class="px-3 py-1.5 bg-[var(--success-color)] text-white text-xs font-semibold rounded-lg hover:opacity-90 transition-opacity flex items-center gap-1 cursor-pointer">
                <span class="material-icons text-xs">check</span>
                <span>Apply Patch</span>
              </button>
              <button (click)="engine.aiActivePatch.set(null)" class="px-3 py-1.5 border border-[var(--border-color)] text-xs text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-lg cursor-pointer">
                Reject
              </button>
            </div>
          </div>

          <!-- Plan Steps Checklist -->
          <div class="grid grid-cols-2 gap-3 text-xs">
            @for (step of patch.plan; track step.number) {
              <div class="p-2.5 rounded-lg bg-[var(--bg-elevated)] border border-[var(--border-color)] flex items-start gap-2.5">
                <span class="w-5 h-5 rounded-full bg-[var(--accent-color)]/10 text-[var(--accent-color)] flex items-center justify-center font-mono font-bold text-[10px]">
                  {{ step.number }}
                </span>
                <div>
                  <div class="font-semibold text-[var(--text-primary)]">{{ step.title }}</div>
                  <div class="text-[11px] text-[var(--text-secondary)]">{{ step.description }}</div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- AI Patch Diff Viewer (Section 13) -->
        <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
          <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-2">
            <div class="flex items-center space-x-2">
              <span class="material-icons text-sm text-[var(--accent-color)]">difference</span>
              <span class="font-mono text-xs font-bold text-[var(--text-primary)]">{{ patch.filePath }}</span>
            </div>

            <div class="flex items-center space-x-2 text-xs">
              <button (click)="engine.applyPatch()" class="px-2.5 py-1 rounded bg-[var(--accent-color)] text-white font-medium hover:opacity-90 cursor-pointer">
                Apply File
              </button>
              <button (click)="engine.setRoute('Code')" class="px-2.5 py-1 rounded border border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-elevated)] cursor-pointer">
                Open File
              </button>
            </div>
          </div>

          <!-- Line-by-Line Diff Display -->
          <div class="font-mono text-xs leading-relaxed bg-[var(--bg-elevated)] p-4 rounded-lg border border-[var(--border-color)] overflow-x-auto space-y-1">
            @for (line of patch.diffLines; track $index) {
              <div
                [class]="line.startsWith('+')
                  ? 'bg-[var(--success-color)]/15 text-[var(--success-color)] -mx-2 px-2 py-0.5 rounded font-medium'
                  : line.startsWith('-')
                    ? 'bg-[var(--error-color)]/15 text-[var(--error-color)] line-through -mx-2 px-2 py-0.5 rounded opacity-80'
                    : 'text-[var(--text-primary)]'"
                class="whitespace-pre"
              >
                {{ line }}
              </div>
            }
          </div>
        </div>
      }
    </div>
  `
})
export class AiViewComponent {
  engine = inject(EngineService);

  onPromptInput(e: Event) {
    this.engine.aiPrompt.set((e.target as HTMLInputElement).value);
  }

  getPipelineStepClass(stepRequired: number): string {
    const currentStep = this.engine.aiStepIndex();
    if (currentStep >= stepRequired) {
      return 'bg-[var(--success-color)]/15 border-[var(--success-color)] text-[var(--success-color)] font-bold';
    } else if (this.engine.isAiAnalyzing() && currentStep === stepRequired - 1) {
      return 'bg-[var(--accent-color)]/15 border-[var(--accent-color)] text-[var(--accent-color)] animate-pulse font-bold';
    } else {
      return 'bg-[var(--bg-elevated)] border-[var(--border-color)] text-[var(--text-secondary)] opacity-60';
    }
  }
}
