import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

@Component({
  selector: 'app-release-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-full overflow-y-auto p-6 space-y-6 select-none">
      <!-- Title Header -->
      <div class="flex items-center justify-between pb-4 border-b border-[var(--border-color)]">
        <div>
          <h1 class="text-xl font-bold text-[var(--text-primary)]">RELEASE & DISTRIBUTION CENTRE</h1>
          <p class="text-xs text-[var(--text-secondary)]">App Store Connect notarization, archiving, and TestFlight release</p>
        </div>

        <button (click)="startReleasePipeline()" class="px-3 py-1.5 rounded-md bg-[var(--accent-color)] text-white text-xs font-semibold hover:opacity-90 flex items-center gap-1">
          <span class="material-icons text-xs">inventory_2</span>
          <span>Archive & Build Release</span>
        </button>
      </div>

      <!-- Release Pipeline Steps (Section 24) -->
      <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-3">
        <h2 class="text-xs font-bold text-[var(--text-secondary)] uppercase tracking-wider">
          Release Pipeline Workflow
        </h2>

        <div class="grid grid-cols-6 gap-2 text-center text-xs font-mono">
          <div [class]="getStepClass(1)" class="p-2.5 rounded-lg border">
            1. BUILD
          </div>
          <div [class]="getStepClass(2)" class="p-2.5 rounded-lg border">
            2. TEST
          </div>
          <div [class]="getStepClass(3)" class="p-2.5 rounded-lg border">
            3. ARCHIVE
          </div>
          <div [class]="getStepClass(4)" class="p-2.5 rounded-lg border">
            4. VALIDATE
          </div>
          <div [class]="getStepClass(5)" class="p-2.5 rounded-lg border">
            5. SIGN & NOTARISE
          </div>
          <div [class]="getStepClass(6)" class="p-2.5 rounded-lg border">
            6. DISTRIBUTE
          </div>
        </div>
      </div>

      <!-- Active Archive Details -->
      <div class="bg-[var(--bg-system)] border border-[var(--border-color)] rounded-xl p-4 space-y-4">
        <div class="flex items-center justify-between border-b border-[var(--border-color)] pb-3">
          <div>
            <h2 class="text-sm font-bold text-[var(--text-primary)]">MyVideoApp.xcarchive</h2>
            <p class="text-xs text-[var(--text-secondary)]">macOS Universal Binary (x86_64 + arm64e)</p>
          </div>
          <span class="px-2.5 py-1 rounded bg-[var(--success-color)]/15 text-[var(--success-color)] text-xs font-mono font-bold">
            VALIDATED & NOTARIZED
          </span>
        </div>

        <div class="grid grid-cols-4 gap-4 text-xs font-mono">
          <div class="p-3 bg-[var(--bg-elevated)] rounded-lg border border-[var(--border-color)]">
            <div class="text-[10px] text-[var(--text-secondary)] uppercase">Version</div>
            <div class="text-sm font-bold text-[var(--text-primary)] mt-0.5">v2.4.0 (Build 184)</div>
          </div>

          <div class="p-3 bg-[var(--bg-elevated)] rounded-lg border border-[var(--border-color)]">
            <div class="text-[10px] text-[var(--text-secondary)] uppercase">Binary Size</div>
            <div class="text-sm font-bold text-[var(--text-primary)] mt-0.5">42.8 MB</div>
          </div>

          <div class="p-3 bg-[var(--bg-elevated)] rounded-lg border border-[var(--border-color)]">
            <div class="text-[10px] text-[var(--text-secondary)] uppercase">Developer Certificate</div>
            <div class="text-sm font-bold text-[var(--text-primary)] mt-0.5">Developer ID Application</div>
          </div>

          <div class="p-3 bg-[var(--bg-elevated)] rounded-lg border border-[var(--border-color)]">
            <div class="text-[10px] text-[var(--text-secondary)] uppercase">Notarization Ticket</div>
            <div class="text-sm font-bold text-[var(--success-color)] mt-0.5">STAPLED</div>
          </div>
        </div>

        <!-- Release Actions -->
        <div class="pt-2 flex items-center justify-end space-x-3 text-xs">
          <button (click)="exportApp()" class="px-3 py-2 border border-[var(--border-color)] text-[var(--text-primary)] rounded-lg hover:bg-[var(--bg-elevated)]">
            Export App Package (.app)
          </button>
          <button (click)="uploadTestFlight()" class="px-4 py-2 bg-[var(--accent-color)] text-white font-semibold rounded-lg hover:opacity-90 transition-opacity">
            Upload to TestFlight / App Store Connect
          </button>
        </div>
      </div>
    </div>
  `
})
export class ReleaseViewComponent {
  engine = inject(EngineService);
  releaseStep = signal<number>(4);

  getStepClass(step: number): string {
    if (step < this.releaseStep()) {
      return 'bg-[var(--success-color)]/15 border-[var(--success-color)] text-[var(--success-color)] font-bold';
    } else if (step === this.releaseStep()) {
      return 'bg-[var(--accent-color)]/15 border-[var(--accent-color)] text-[var(--accent-color)] font-bold animate-pulse';
    } else {
      return 'bg-[var(--bg-elevated)] border-[var(--border-color)] text-[var(--text-secondary)]';
    }
  }

  startReleasePipeline() {
    this.releaseStep.set(1);
    this.engine.addLog('Build', 'INFO', 'Starting archiving release pipeline for App Store Connect...');
  }

  exportApp() {
    this.engine.addLog('System', 'SUCCESS', 'Exported signed notarized MyVideoApp.app to ~/Desktop/Releases');
  }

  uploadTestFlight() {
    this.engine.addLog('System', 'SUCCESS', 'Uploading MyVideoApp build 184 to TestFlight via App Store Connect API...');
  }
}
