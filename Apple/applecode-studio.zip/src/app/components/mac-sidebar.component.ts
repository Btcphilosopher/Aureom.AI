import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';
import { AppRoute } from '../models/studio.models';

interface NavItem {
  route: AppRoute;
  label: string;
  icon: string;
  badge?: string | number;
  badgeType?: 'info' | 'warning' | 'error' | 'success';
}

interface NavSection {
  title: string;
  items: NavItem[];
}

@Component({
  selector: 'app-mac-sidebar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <aside class="w-60 h-full bg-[var(--bg-system)] border-r border-[var(--border-color)] flex flex-col select-none py-3 px-2">
      <!-- Project Summary Header -->
      <div class="px-3 pb-3 mb-2 border-b border-[var(--border-color)] flex items-center justify-between">
        <div class="flex items-center space-x-2 truncate">
          <div class="w-7 h-7 rounded-lg bg-[var(--accent-color)]/10 text-[var(--accent-color)] border border-[var(--accent-color)]/20 flex items-center justify-center font-bold text-xs">
            
          </div>
          <div class="truncate">
            <h2 class="text-xs font-semibold text-[var(--text-primary)] truncate">{{ engine.activeProject().name }}</h2>
            <p class="text-[10px] text-[var(--text-secondary)] truncate">{{ engine.activeProject().platform }} · {{ engine.activeProject().framework }}</p>
          </div>
        </div>
        <button (click)="engine.closeProject()" title="Switch Project" class="text-[var(--text-secondary)] hover:text-[var(--text-primary)] text-xs p-1">
          <span class="material-icons text-xs block">swap_horiz</span>
        </button>
      </div>

      <!-- Navigation Sections -->
      <div class="flex-1 overflow-y-auto space-y-4 pr-1">
        @for (section of navSections; track section.title) {
          <div>
            <h3 class="px-3 text-[10px] font-bold tracking-wider text-[var(--text-secondary)] uppercase mb-1">
              {{ section.title }}
            </h3>
            <div class="space-y-0.5">
              @for (item of section.items; track item.route) {
                <button
                  (click)="selectRoute(item.route)"
                  [class]="engine.activeRoute() === item.route
                    ? 'bg-[var(--accent-color)]/20 text-[var(--accent-color)] font-medium border border-[var(--accent-color)]/30'
                    : 'text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] border border-transparent'"
                  class="w-full text-left px-3 py-1.5 rounded-md text-xs flex items-center justify-between transition-colors cursor-pointer group"
                >
                  <div class="flex items-center space-x-2.5 truncate">
                    <span
                      class="material-icons text-sm opacity-80 group-hover:opacity-100 transition-opacity"
                      [class.text-[var(--accent-color)]]="engine.activeRoute() === item.route"
                    >
                      {{ item.icon }}
                    </span>
                    <span class="truncate">{{ item.label }}</span>
                  </div>

                  @if (item.badge) {
                    <span
                      [class]="getBadgeClass(item.badgeType, engine.activeRoute() === item.route)"
                      class="text-[10px] px-1.5 py-0.2 rounded-full font-mono font-medium"
                    >
                      {{ item.badge }}
                    </span>
                  }
                </button>
              }
            </div>
          </div>
        }
      </div>

      <!-- Bottom Engine Quick Info -->
      <div class="pt-2 border-t border-[var(--border-color)] px-2 flex items-center justify-between text-[10px] text-[var(--text-secondary)]">
        <div class="flex items-center gap-1.5">
          <span class="material-icons text-xs">terminal</span>
          <span>Python Engine 2.4</span>
        </div>
        <span class="font-mono">PID {{ engine.engineProcessId() }}</span>
      </div>
    </aside>
  `
})
export class MacSidebarComponent {
  engine = inject(EngineService);

  navSections: NavSection[] = [
    {
      title: 'PROJECT',
      items: [
        { route: 'Overview', label: 'Overview', icon: 'dashboard' },
        { route: 'Files', label: 'Files', icon: 'folder', badge: 2, badgeType: 'info' },
        { route: 'Targets', label: 'Targets', icon: 'category' },
        { route: 'Dependencies', label: 'Dependencies', icon: 'account_tree' },
        { route: 'Git', label: 'Git', icon: 'merge_type', badge: '● 2', badgeType: 'warning' }
      ]
    },
    {
      title: 'DEVELOP',
      items: [
        { route: 'Code', label: 'Code', icon: 'code' },
        { route: 'AI', label: 'AI Engineer', icon: 'auto_awesome', badge: 'Active', badgeType: 'success' },
        { route: 'Tests', label: 'Tests', icon: 'fact_check', badge: '3 Fail', badgeType: 'error' },
        { route: 'Builds', label: 'Builds', icon: 'build' },
        { route: 'Simulator', label: 'Simulator', icon: 'devices' }
      ]
    },
    {
      title: 'ANALYSE',
      items: [
        { route: 'Performance', label: 'Performance', icon: 'speed' },
        { route: 'Memory', label: 'Memory', icon: 'memory' },
        { route: 'GPU', label: 'GPU', icon: 'aspect_ratio' },
        { route: 'Energy', label: 'Energy', icon: 'bolt' },
        { route: 'Security', label: 'Security', icon: 'shield' },
        { route: 'Architecture', label: 'Architecture', icon: 'hub' }
      ]
    },
    {
      title: 'RELEASE',
      items: [
        { route: 'Archives', label: 'Archives', icon: 'inventory_2' },
        { route: 'Validation', label: 'Validation', icon: 'verified' },
        { route: 'Distribution', label: 'Distribution', icon: 'file_download' },
        { route: 'Settings', label: 'Settings', icon: 'settings' }
      ]
    }
  ];

  selectRoute(route: AppRoute) {
    this.engine.setRoute(route);
  }

  getBadgeClass(type?: string, isActive = false): string {
    if (isActive) return 'bg-white/20 text-white';
    switch (type) {
      case 'error': return 'bg-[var(--error-color)]/15 text-[var(--error-color)]';
      case 'warning': return 'bg-[var(--warning-color)]/15 text-[var(--warning-color)]';
      case 'success': return 'bg-[var(--success-color)]/15 text-[var(--success-color)]';
      default: return 'bg-[var(--bg-secondary)] text-[var(--text-secondary)]';
    }
  }
}
