import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';
import { AppRoute } from '../models/studio.models';

@Component({
  selector: 'app-mac-menu-bar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="h-7 bg-[var(--bg-system)] border-b border-[var(--border-color)] px-3 flex items-center justify-between text-xs select-none">
      <!-- Left: Apple logo & Main Menus -->
      <div class="flex items-center space-x-3">
        <!-- App Menu -->
        <div class="relative">
          <button (click)="toggleMenu('app')" class="font-semibold text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] px-2 py-0.5 rounded flex items-center gap-1">
            <span class="font-bold text-sm leading-none"></span>
            <span>AppleCode Studio</span>
          </button>
          @if (activeMenu() === 'app') {
            <div class="absolute top-full left-0 mt-1 w-52 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-lg shadow-xl py-1 z-50 text-[11px]">
              <button (click)="openRoute('Overview')" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>About AppleCode Studio</span>
              </button>
              <button (click)="openRoute('Settings')" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Settings...</span>
                <span class="opacity-60 font-mono">⌘,</span>
              </button>
              <div class="my-1 border-t border-[var(--border-color)]"></div>
              <button (click)="engine.toggleTheme()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Toggle Appearance ({{ engine.isDarkMode() ? 'Light' : 'Dark' }})</span>
              </button>
            </div>
          }
        </div>

        <!-- File Menu -->
        <div class="relative">
          <button (click)="toggleMenu('file')" class="text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] px-2 py-0.5 rounded">File</button>
          @if (activeMenu() === 'file') {
            <div class="absolute top-full left-0 mt-1 w-48 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-lg shadow-xl py-1 z-50 text-[11px]">
              <button (click)="engine.hasOpenedProject.set(false); closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white">New Window / Project</button>
              <button (click)="openRoute('Files')" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Open Quick File</span>
                <span class="opacity-60 font-mono">⌘P</span>
              </button>
              <div class="my-1 border-t border-[var(--border-color)]"></div>
              <button (click)="closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Save All</span>
                <span class="opacity-60 font-mono">⌘S</span>
              </button>
            </div>
          }
        </div>

        <!-- Edit Menu -->
        <div class="relative">
          <button (click)="toggleMenu('edit')" class="text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] px-2 py-0.5 rounded">Edit</button>
          @if (activeMenu() === 'edit') {
            <div class="absolute top-full left-0 mt-1 w-48 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-lg shadow-xl py-1 z-50 text-[11px]">
              <button (click)="closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Undo</span>
                <span class="opacity-60 font-mono">⌘Z</span>
              </button>
              <button (click)="closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Redo</span>
                <span class="opacity-60 font-mono">⌘⇧Z</span>
              </button>
              <div class="my-1 border-t border-[var(--border-color)]"></div>
              <button (click)="openRoute('Code')" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Find in Workspace</span>
                <span class="opacity-60 font-mono">⌘⇧F</span>
              </button>
            </div>
          }
        </div>

        <!-- Build Menu -->
        <div class="relative">
          <button (click)="toggleMenu('build')" class="text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] px-2 py-0.5 rounded">Build</button>
          @if (activeMenu() === 'build') {
            <div class="absolute top-full left-0 mt-1 w-48 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-lg shadow-xl py-1 z-50 text-[11px]">
              <button (click)="engine.triggerBuild(); closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Build Project</span>
                <span class="opacity-60 font-mono">⌘B</span>
              </button>
              <button (click)="openRoute('Builds'); closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Run</span>
                <span class="opacity-60 font-mono">⌘R</span>
              </button>
              <button (click)="closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Clean Build Folder</span>
                <span class="opacity-60 font-mono">⌘K</span>
              </button>
            </div>
          }
        </div>

        <!-- Test Menu -->
        <div class="relative">
          <button (click)="toggleMenu('test')" class="text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] px-2 py-0.5 rounded">Test</button>
          @if (activeMenu() === 'test') {
            <div class="absolute top-full left-0 mt-1 w-48 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-lg shadow-xl py-1 z-50 text-[11px]">
              <button (click)="openRoute('Tests'); closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Run All Tests</span>
                <span class="opacity-60 font-mono">⌘U</span>
              </button>
            </div>
          }
        </div>

        <!-- AI Menu -->
        <div class="relative">
          <button (click)="toggleMenu('ai')" class="text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] px-2 py-0.5 rounded">AI Engineer</button>
          @if (activeMenu() === 'ai') {
            <div class="absolute top-full left-0 mt-1 w-52 bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-lg shadow-xl py-1 z-50 text-[11px]">
              <button (click)="openRoute('AI'); closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white flex justify-between">
                <span>Open AI Workspace</span>
                <span class="opacity-60 font-mono">⌘⇧A</span>
              </button>
              <button (click)="engine.triggerAIAnalysis(); closeMenu()" class="w-full text-left px-3 py-1 hover:bg-[var(--accent-color)] hover:text-white">
                <span>Analyze Current Bottleneck</span>
              </button>
            </div>
          }
        </div>
      </div>

      <!-- Right side: Status indicator -->
      <div class="flex items-center space-x-3 text-[11px] text-[var(--text-secondary)]">
        <span class="flex items-center gap-1">
          <span class="w-2 h-2 rounded-full bg-[var(--success-color)]"></span>
          Python Engine v2.4.0
        </span>
      </div>
    </div>
  `
})
export class MacMenuBarComponent {
  engine = inject(EngineService);
  activeMenu = signal<string | null>(null);

  toggleMenu(name: string) {
    if (this.activeMenu() === name) {
      this.activeMenu.set(null);
    } else {
      this.activeMenu.set(name);
    }
  }

  closeMenu() {
    this.activeMenu.set(null);
  }

  openRoute(route: AppRoute) {
    this.engine.setRoute(route);
    this.closeMenu();
  }
}
