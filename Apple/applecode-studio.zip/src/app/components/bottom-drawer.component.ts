import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

type LogCategory = 'Build' | 'Test' | 'AI' | 'Simulator' | 'Security' | 'System';

@Component({
  selector: 'app-bottom-drawer',
  standalone: true,
  imports: [CommonModule],
  template: `
    <footer class="bg-[var(--bg-system)] border-t border-[var(--border-color)] flex flex-col select-none">
      <!-- Drawer Header / Controls -->
      <div class="h-8 px-3 flex items-center justify-between border-b border-[var(--border-color)] text-xs">
        <div class="flex items-center space-x-4">
          <button
            (click)="toggleDrawer()"
            class="flex items-center gap-1 font-bold text-[10px] tracking-wider text-[var(--text-secondary)] uppercase hover:text-[var(--text-primary)] transition-colors cursor-pointer"
          >
            <span class="material-icons text-xs">{{ engine.bottomDrawerOpen() ? 'keyboard_arrow_down' : 'keyboard_arrow_up' }}</span>
            <span>TERMINAL & LOGS</span>
          </button>

          <!-- Category Tabs -->
          <div class="flex items-center space-x-1">
            @for (cat of categories; track cat) {
              <button
                (click)="selectCategory(cat)"
                [class]="engine.activeLogCategory() === cat
                  ? 'bg-[var(--bg-elevated)] text-[var(--accent-color)] font-semibold border-[var(--border-color)]'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] border-transparent'"
                class="px-2 py-0.5 rounded text-[11px] border transition-colors cursor-pointer"
              >
                {{ cat }}
              </button>
            }
          </div>
        </div>

        <!-- Filter Search & Actions -->
        <div class="flex items-center space-x-2 text-[11px]">
          <input
            type="text"
            placeholder="Filter logs..."
            [value]="searchQuery()"
            (input)="onSearchInput($event)"
            class="bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded px-2 py-0.5 text-[11px] text-[var(--text-primary)] outline-none w-36 font-mono"
          />

          <button (click)="copyLogs()" title="Copy Logs" class="p-1 hover:bg-[var(--bg-secondary)] rounded text-[var(--text-secondary)] hover:text-[var(--text-primary)]">
            <span class="material-icons text-xs block">content_copy</span>
          </button>

          <button (click)="clearLogs()" title="Clear Output" class="p-1 hover:bg-[var(--bg-secondary)] rounded text-[var(--text-secondary)] hover:text-[var(--text-primary)]">
            <span class="material-icons text-xs block">block</span>
          </button>
        </div>
      </div>

      <!-- Expandable Log Output Panel -->
      @if (engine.bottomDrawerOpen()) {
        <div class="h-44 bg-[var(--bg-elevated)] p-3 overflow-y-auto font-mono text-[11px] leading-relaxed space-y-1">
          @for (log of filteredLogs(); track log.id) {
            <div class="flex items-start gap-2">
              <span class="text-[var(--text-secondary)] opacity-60 select-none">[{{ log.time }}]</span>
              <span [class]="getCategoryBadgeClass(log.category)" class="px-1 rounded text-[9px] font-bold uppercase">{{ log.category }}</span>
              <span [class]="getLevelClass(log.level)" class="flex-1 whitespace-pre-wrap">{{ log.text }}</span>
            </div>
          } @empty {
            <div class="text-[var(--text-secondary)] italic py-4 text-center">No log entries recorded for {{ engine.activeLogCategory() }}.</div>
          }
        </div>
      }
    </footer>
  `
})
export class BottomDrawerComponent {
  engine = inject(EngineService);
  categories: LogCategory[] = [
    'Build', 'Test', 'AI', 'Simulator', 'Security', 'System'
  ];

  searchQuery = signal<string>('');

  filteredLogs = computed(() => {
    const activeCat = this.engine.activeLogCategory();
    const query = this.searchQuery().toLowerCase();
    return this.engine.logs().filter(log => {
      const catMatch = log.category === activeCat || activeCat === 'System';
      const queryMatch = !query || log.text.toLowerCase().includes(query) || log.category.toLowerCase().includes(query);
      return catMatch && queryMatch;
    });
  });

  toggleDrawer() {
    this.engine.bottomDrawerOpen.update(v => !v);
  }

  selectCategory(cat: LogCategory) {
    this.engine.activeLogCategory.set(cat);
    if (!this.engine.bottomDrawerOpen()) {
      this.engine.bottomDrawerOpen.set(true);
    }
  }

  onSearchInput(e: Event) {
    this.searchQuery.set((e.target as HTMLInputElement).value);
  }

  clearLogs() {
    this.engine.logs.set([]);
  }

  copyLogs() {
    const text = this.filteredLogs().map(l => `[${l.time}] [${l.category}] ${l.text}`).join('\n');
    navigator.clipboard?.writeText(text);
    this.engine.addLog('System', 'INFO', 'Logs copied to clipboard.');
  }

  getCategoryBadgeClass(category: string): string {
    switch (category) {
      case 'Build': return 'bg-[var(--accent-color)]/15 text-[var(--accent-color)]';
      case 'Test': return 'bg-[var(--warning-color)]/15 text-[var(--warning-color)]';
      case 'AI': return 'bg-[var(--success-color)]/15 text-[var(--success-color)]';
      default: return 'bg-[var(--bg-secondary)] text-[var(--text-secondary)]';
    }
  }

  getLevelClass(level: string): string {
    switch (level) {
      case 'ERROR': return 'text-[var(--error-color)] font-semibold';
      case 'WARN': return 'text-[var(--warning-color)]';
      case 'SUCCESS': return 'text-[var(--success-color)]';
      default: return 'text-[var(--text-primary)]';
    }
  }
}
