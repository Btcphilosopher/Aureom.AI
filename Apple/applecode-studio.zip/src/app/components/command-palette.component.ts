import { Component, inject, signal, computed, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

interface CommandItem {
  id: string;
  title: string;
  category: 'Command' | 'File' | 'Target' | 'AI' | 'Navigation';
  icon: string;
  shortcut?: string;
  action: () => void;
}

@Component({
  selector: 'app-command-palette',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (engine.commandPaletteOpen()) {
      <div
        (click)="close()"
        (keydown.escape)="close()"
        tabindex="0"
        role="button"
        class="fixed inset-0 bg-black/40 backdrop-blur-xs z-50 flex items-start justify-center pt-24 select-none outline-none"
      >
        <div
          (click)="$event.stopPropagation()"
          (keydown)="$event.stopPropagation()"
          tabindex="0"
          role="dialog"
          class="w-full max-w-xl bg-[var(--bg-elevated)] border border-[var(--border-color)] rounded-xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in duration-150 outline-none"
        >
          <!-- Search Header Input -->
          <div class="p-3 border-b border-[var(--border-color)] flex items-center gap-2">
            <span class="material-icons text-lg text-[var(--text-secondary)]">search</span>
            <input
              type="text"
              placeholder="Type a command or search files (e.g. build, test, export, AI)..."
              [value]="query()"
              (input)="onQueryChange($event)"
              class="w-full bg-transparent text-sm text-[var(--text-primary)] outline-none placeholder-[var(--text-secondary)]"
            />
            <span class="text-[10px] font-mono text-[var(--text-secondary)] bg-[var(--bg-secondary)] px-1.5 py-0.5 rounded border border-[var(--border-color)]">ESC</span>
          </div>

          <!-- Command Items List -->
          <div class="max-h-80 overflow-y-auto p-1 space-y-1">
            @for (cmd of filteredCommands(); track cmd.id) {
              <button
                (click)="execute(cmd)"
                class="w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between hover:bg-[var(--accent-color)] hover:text-white group transition-colors cursor-pointer"
              >
                <div class="flex items-center space-x-3">
                  <span class="material-icons text-sm text-[var(--text-secondary)] group-hover:text-white">{{ cmd.icon }}</span>
                  <div>
                    <div class="font-medium text-[var(--text-primary)] group-hover:text-white">{{ cmd.title }}</div>
                    <div class="text-[10px] text-[var(--text-secondary)] group-hover:text-white/80 font-mono">{{ cmd.category }}</div>
                  </div>
                </div>

                @if (cmd.shortcut) {
                  <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[var(--bg-secondary)] group-hover:bg-white/20 group-hover:text-white text-[var(--text-secondary)]">
                    {{ cmd.shortcut }}
                  </span>
                }
              </button>
            } @empty {
              <div class="text-center text-xs text-[var(--text-secondary)] py-8">
                No commands matching "{{ query() }}"
              </div>
            }
          </div>

          <!-- Keyboard Shortcuts Footer -->
          <div class="p-2 border-t border-[var(--border-color)] bg-[var(--bg-system)] flex items-center justify-between text-[10px] text-[var(--text-secondary)] px-3">
            <div class="flex items-center space-x-3">
              <span><kbd class="font-mono bg-[var(--bg-elevated)] px-1 rounded border">↑↓</kbd> Navigate</span>
              <span><kbd class="font-mono bg-[var(--bg-elevated)] px-1 rounded border">↵</kbd> Select</span>
            </div>
            <span>AppleCode Command Palette</span>
          </div>
        </div>
      </div>
    }
  `
})
export class CommandPaletteComponent {
  engine = inject(EngineService);
  query = signal<string>('');

  @HostListener('window:keydown', ['$event'])
  handleKeyboardShortcut(event: KeyboardEvent) {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.engine.commandPaletteOpen.update(v => !v);
    } else if (event.key === 'Escape' && this.engine.commandPaletteOpen()) {
      this.close();
    } else if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'b') {
      event.preventDefault();
      this.engine.triggerBuild();
    } else if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'u') {
      event.preventDefault();
      this.engine.setRoute('Tests');
    }
  }

  commands: CommandItem[] = [
    { id: 'cmd-build', title: 'Build Project', category: 'Command', icon: 'build', shortcut: '⌘B', action: () => this.engine.triggerBuild() },
    { id: 'cmd-run', title: 'Run Target on My Mac', category: 'Command', icon: 'play_arrow', shortcut: '⌘R', action: () => this.engine.setRoute('Builds') },
    { id: 'cmd-test', title: 'Run All Test Suites (1,842 tests)', category: 'Command', icon: 'fact_check', shortcut: '⌘U', action: () => this.engine.setRoute('Tests') },
    { id: 'cmd-ai', title: 'AI Engineer: Optimise Performance', category: 'AI', icon: 'auto_awesome', shortcut: '⌘⇧A', action: () => { this.engine.setRoute('AI'); this.engine.triggerAIAnalysis(); } },
    { id: 'cmd-file-export', title: 'ExportService.swift', category: 'File', icon: 'description', shortcut: '⌘P', action: () => this.engine.setRoute('Code') },
    { id: 'cmd-file-content', title: 'ContentView.swift', category: 'File', icon: 'description', action: () => this.engine.setRoute('Code') },
    { id: 'cmd-perf', title: 'Performance Dashboard & CPU Profiler', category: 'Navigation', icon: 'speed', action: () => this.engine.setRoute('Performance') },
    { id: 'cmd-sec', title: 'Security Audit & Credential Check', category: 'Navigation', icon: 'shield', action: () => this.engine.setRoute('Security') },
    { id: 'cmd-arch', title: 'Architecture Dependency Graph', category: 'Navigation', icon: 'hub', action: () => this.engine.setRoute('Architecture') },
    { id: 'cmd-devices', title: 'Discovered Simulators & Devices', category: 'Navigation', icon: 'devices', action: () => this.engine.setRoute('Simulator') }
  ];

  filteredCommands = computed(() => {
    const q = this.query().toLowerCase().trim();
    if (!q) return this.commands;
    return this.commands.filter(cmd =>
      cmd.title.toLowerCase().includes(q) ||
      cmd.category.toLowerCase().includes(q)
    );
  });

  onQueryChange(e: Event) {
    this.query.set((e.target as HTMLInputElement).value);
  }

  execute(cmd: CommandItem) {
    cmd.action();
    this.close();
  }

  close() {
    this.engine.commandPaletteOpen.set(false);
    this.query.set('');
  }
}
