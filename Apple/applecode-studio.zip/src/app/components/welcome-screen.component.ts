import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';

@Component({
  selector: 'app-welcome-screen',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="min-h-screen bg-[var(--bg-system)] flex flex-col justify-between p-8 select-none">
      <!-- Title Bar Header -->
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-2">
          <div class="flex items-center space-x-2 mr-4">
            <span class="w-3 h-3 rounded-full bg-[#FF5F56] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#FFBD2E] inline-block"></span>
            <span class="w-3 h-3 rounded-full bg-[#27C93F] inline-block"></span>
          </div>
          <span class="font-bold text-xs font-mono tracking-wider text-[var(--text-primary)]">APPLECODE.STUDIO</span>
        </div>

        <button
          (click)="engine.toggleTheme()"
          class="px-2.5 py-1 text-xs rounded-md bg-[var(--bg-elevated)] border border-[var(--border-color)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] cursor-pointer"
        >
          {{ engine.isDarkMode() ? '☀️ Light' : '🌙 Dark' }} Mode
        </button>
      </div>

      <!-- Main Welcome Center -->
      <div class="max-w-xl mx-auto w-full my-auto space-y-8">
        <div>
          <h1 class="text-3xl font-light text-[var(--text-primary)] mb-1">Good evening.</h1>
          <p class="text-xs text-[var(--text-secondary)]">AppleCode.Studio Desktop Control Centre for Python Engineering Engine</p>
        </div>

        <div class="space-y-3">
          <h2 class="text-xs font-bold tracking-wider uppercase text-[var(--text-secondary)]">My Projects</h2>

          @for (proj of engine.allProjects(); track proj.id) {
            <div
              (click)="engine.openProject(proj)"
              (keydown.enter)="engine.openProject(proj)"
              tabindex="0"
              role="button"
              class="bg-[var(--bg-elevated)] border border-[var(--border-color)] hover:border-[var(--accent-color)]/50 rounded-xl p-4 shadow-2xs hover:shadow-md transition-all cursor-pointer flex items-center justify-between group outline-none"
            >
              <div class="space-y-1">
                <div class="flex items-center space-x-2">
                  <h3 class="font-semibold text-sm text-[var(--text-primary)] group-hover:text-[var(--accent-color)] transition-colors">{{ proj.name }}</h3>
                  <span class="text-[10px] px-1.5 py-0.5 rounded bg-[var(--bg-secondary)] text-[var(--text-secondary)] font-mono">{{ proj.platform }} · {{ proj.framework }}</span>
                </div>
                <div class="flex items-center space-x-3 text-xs text-[var(--text-secondary)]">
                  <span class="flex items-center gap-1 text-[var(--success-color)]"><span class="material-icons text-xs">check_circle</span> Build</span>
                  <span class="flex items-center gap-1 text-[var(--success-color)]"><span class="material-icons text-xs">check_circle</span> Tests</span>
                  @if (proj.modifiedCount > 0) {
                    <span class="flex items-center gap-1 text-[var(--warning-color)]">● {{ proj.modifiedCount }} changes</span>
                  }
                </div>
              </div>

              <div class="flex items-center text-[var(--accent-color)] text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Open Project</span>
                <span class="material-icons text-sm ml-1">chevron_right</span>
              </div>
            </div>
          }
        </div>

        <div class="pt-2 flex items-center justify-between border-t border-[var(--border-color)]">
          <button (click)="engine.openProject(engine.allProjects()[0])" class="px-4 py-2 bg-[var(--accent-color)] text-white text-xs font-medium rounded-lg shadow-sm hover:opacity-90 transition-opacity cursor-pointer">
            Open Selected Project
          </button>
          <span class="text-[11px] text-[var(--text-secondary)] font-mono">Python Local Engine Connected</span>
        </div>
      </div>

      <!-- Footer -->
      <div class="text-center text-[10px] text-[var(--text-secondary)] font-mono">
        AppleCode Studio v2.4.0 · Native macOS Engineering Instrument
      </div>
    </div>
  `
})
export class WelcomeScreenComponent {
  engine = inject(EngineService);
}
