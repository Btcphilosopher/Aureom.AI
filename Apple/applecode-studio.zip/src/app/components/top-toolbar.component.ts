import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EngineService } from '../services/engine.service';
import { AppRoute } from '../models/studio.models';

@Component({
  selector: 'app-top-toolbar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header class="h-13 bg-[var(--bg-system)] border-b border-[var(--border-color)] px-4 flex items-center justify-between select-none">
      <!-- Left: macOS Window Controls & Branding -->
      <div class="flex items-center space-x-3">
        <!-- Traffic lights -->
        <div class="flex items-center space-x-2 mr-2">
          <button (click)="engine.hasOpenedProject.set(false)" title="Close Window" class="w-3 h-3 rounded-full bg-[#FF5F56] border border-[#E0443E] hover:opacity-80 transition-opacity"></button>
          <button title="Minimize" class="w-3 h-3 rounded-full bg-[#FFBD2E] border border-[#DEA123] hover:opacity-80 transition-opacity"></button>
          <button title="Fullscreen" class="w-3 h-3 rounded-full bg-[#27C93F] border border-[#1AAB29] hover:opacity-80 transition-opacity"></button>
        </div>

        <div class="h-4 w-[1px] bg-[var(--border-color)]"></div>

        <!-- Branding & Engine Status -->
        <div class="flex items-center space-x-2">
          <span class="font-bold tracking-tight text-xs font-mono text-[var(--text-primary)]">APPLECODE.STUDIO</span>
          <button
            (click)="toggleStatusModal()"
            [class]="engine.isConnected() ? 'bg-[var(--success-color)]/10 text-[var(--success-color)] border-[var(--success-color)]/20' : 'bg-[var(--error-color)]/10 text-[var(--error-color)] border-[var(--error-color)]/20'"
            class="px-2 py-0.5 rounded-full border text-[10px] font-medium flex items-center gap-1 transition-all hover:opacity-90 cursor-pointer"
          >
            <span [class]="engine.isConnected() ? 'bg-[var(--success-color)]' : 'bg-[var(--error-color)]'" class="w-1.5 h-1.5 rounded-full animate-pulse"></span>
            <span>{{ engine.isConnected() ? '● Engine Connected' : '○ Engine Offline' }}</span>
          </button>
        </div>
      </div>

      <!-- Centre: Target, Configuration, Destination Selector Pills -->
      <div class="flex items-center space-x-1.5 bg-[var(--bg-secondary)] p-1 rounded-lg border border-[var(--border-color)] text-xs">
        <div class="flex items-center px-2 py-1 bg-[var(--bg-elevated)] rounded border border-[var(--border-color)] text-[11px] font-medium text-[var(--text-primary)] shadow-2xs">
          <span class="material-icons text-xs text-[var(--accent-color)] mr-1">folder</span>
          <span>{{ engine.activeProject().name }}</span>
        </div>

        <span class="text-[var(--text-secondary)] text-[10px]">/</span>

        <select
          [value]="engine.selectedTarget()"
          (change)="onTargetChange($event)"
          class="bg-[var(--bg-elevated)] text-[var(--text-primary)] text-[11px] font-medium px-2 py-1 rounded border border-[var(--border-color)] outline-none cursor-pointer"
        >
          <option value="MyVideoApp">MyVideoApp (macOS App)</option>
          <option value="MyVideoAppTests">MyVideoAppTests</option>
          <option value="ExportServiceCore">ExportServiceCore.framework</option>
        </select>

        <span class="text-[var(--text-secondary)] text-[10px]">/</span>

        <select
          [value]="engine.selectedConfig()"
          (change)="onConfigChange($event)"
          class="bg-[var(--bg-elevated)] text-[var(--text-primary)] text-[11px] font-medium px-2 py-1 rounded border border-[var(--border-color)] outline-none cursor-pointer"
        >
          <option value="Debug">Debug</option>
          <option value="Release">Release</option>
        </select>

        <span class="text-[var(--text-secondary)] text-[10px]">/</span>

        <div class="flex items-center px-2 py-1 bg-[var(--bg-elevated)] rounded border border-[var(--border-color)] text-[11px] text-[var(--text-primary)]">
          <span class="material-icons text-xs text-[var(--text-secondary)] mr-1">desktop_mac</span>
          <span>My Mac (M3 Max)</span>
        </div>
      </div>

      <!-- Right: Action Buttons -->
      <div class="flex items-center space-x-2">
        <!-- AI Engineer Quick Button -->
        <button
          (click)="openRoute('AI')"
          class="px-2.5 py-1 rounded-md text-xs font-medium border border-[var(--accent-color)]/30 text-[var(--accent-color)] hover:bg-[var(--accent-color)]/10 transition-colors flex items-center gap-1"
        >
          <span class="material-icons text-xs">auto_awesome</span>
          <span>AI Engineer</span>
        </button>

        <!-- Build Button -->
        <button
          (click)="engine.triggerBuild()"
          [disabled]="engine.isBuilding()"
          class="px-3 py-1 rounded-md text-xs font-medium bg-[var(--accent-color)] text-white hover:opacity-90 disabled:opacity-50 transition-all flex items-center gap-1 shadow-2xs cursor-pointer"
        >
          @if (engine.isBuilding()) {
            <span class="material-icons text-xs animate-spin">sync</span>
            <span>BUILDING...</span>
          } @else {
            <span class="material-icons text-xs">play_arrow</span>
            <span>BUILD ⌘B</span>
          }
        </button>

        <!-- Run / Test Quick Buttons -->
        <button
          (click)="openRoute('Tests')"
          title="Run Tests (⌘U)"
          class="p-1.5 rounded-md border border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] transition-colors"
        >
          <span class="material-icons text-sm block">fact_check</span>
        </button>

        <button
          (click)="openRoute('Simulator')"
          title="Devices & Simulators"
          class="p-1.5 rounded-md border border-[var(--border-color)] text-[var(--text-primary)] hover:bg-[var(--bg-secondary)] transition-colors"
        >
          <span class="material-icons text-sm block">devices</span>
        </button>

        <!-- Global Search / Command Palette ⌘K -->
        <button
          (click)="engine.commandPaletteOpen.set(true)"
          class="px-2.5 py-1 rounded-md bg-[var(--bg-secondary)] border border-[var(--border-color)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <span class="material-icons text-xs">search</span>
          <span class="font-mono text-[10px] bg-[var(--bg-elevated)] px-1 rounded border border-[var(--border-color)]">⌘K</span>
        </button>
      </div>
    </header>
  `
})
export class TopToolbarComponent {
  engine = inject(EngineService);

  onTargetChange(event: Event) {
    const target = (event.target as HTMLSelectElement).value;
    this.engine.selectedTarget.set(target);
  }

  onConfigChange(event: Event) {
    const cfg = (event.target as HTMLSelectElement).value;
    this.engine.selectedConfig.set(cfg);
  }

  openRoute(route: AppRoute) {
    this.engine.setRoute(route);
  }

  toggleStatusModal() {
    this.engine.addLog('System', 'INFO', `Engine Status Check: Process #${this.engine.engineProcessId()} on localhost:8080`);
  }
}
