import { Injectable, signal } from '@angular/core';
import {
  Project,
  SourceFileNode,
  BuildResult,
  TestCase,
  DeviceItem,
  PerformancePoint,
  SecurityFinding,
  AIPatch,
  LogEntry,
  AppRoute,
  SymbolItem,
  ArchNode
} from '../models/studio.models';

@Injectable({
  providedIn: 'root'
})
export class EngineService {
  constructor() {
    if (typeof document !== 'undefined') {
      if (this.isDarkMode()) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }

  // Navigation & Screen State
  hasOpenedProject = signal<boolean>(true); // Starts with project workspace loaded, user can switch or close
  activeRoute = signal<AppRoute>('Overview');
  commandPaletteOpen = signal<boolean>(false);
  bottomDrawerOpen = signal<boolean>(false);
  activeLogCategory = signal<'Build' | 'Test' | 'AI' | 'Simulator' | 'Security' | 'System'>('Build');
  isDarkMode = signal<boolean>(true);

  // Engine Connection State
  isConnected = signal<boolean>(true);
  engineVersion = signal<string>('2.4.0-python');
  engineProcessId = signal<number>(84920);

  // Current Selected Project & Target
  activeProject = signal<Project>({
    id: 'proj-myvideoapp',
    name: 'MyVideoApp',
    platform: 'macOS',
    framework: 'SwiftUI / Metal',
    path: '~/Developer/MyVideoApp',
    buildStatus: 'PASS',
    testPassCount: 1842,
    totalTests: 1845,
    securityStatus: 'GOOD',
    performanceStatus: 'STABLE',
    architectureStatus: 'HEALTHY',
    modifiedCount: 2,
    lastBuilt: '2 minutes ago'
  });

  selectedTarget = signal<string>('MyVideoApp');
  selectedConfig = signal<string>('Debug');
  selectedDestination = signal<string>('My Mac (Apple Silicon)');

  // Projects list for Welcome Screen
  allProjects = signal<Project[]>([
    {
      id: 'proj-myvideoapp',
      name: 'MyVideoApp',
      platform: 'macOS',
      framework: 'SwiftUI / Metal',
      path: '~/Developer/MyVideoApp',
      buildStatus: 'PASS',
      testPassCount: 1842,
      totalTests: 1845,
      securityStatus: 'GOOD',
      performanceStatus: 'STABLE',
      architectureStatus: 'HEALTHY',
      modifiedCount: 2,
      lastBuilt: '2 mins ago'
    },
    {
      id: 'proj-datastudio',
      name: 'DataStudio',
      platform: 'macOS',
      framework: 'Swift Data Engine',
      path: '~/Developer/DataStudio',
      buildStatus: 'PASS',
      testPassCount: 612,
      totalTests: 612,
      securityStatus: 'GOOD',
      performanceStatus: 'STABLE',
      architectureStatus: 'HEALTHY',
      modifiedCount: 0,
      lastBuilt: '1 hour ago'
    }
  ]);

  // File Tree Data
  fileTree = signal<SourceFileNode[]>([
    {
      name: 'MyApp',
      path: 'MyApp',
      isDirectory: true,
      children: [
        {
          name: 'App',
          path: 'MyApp/App',
          isDirectory: true,
          children: [
            { name: 'MyApp.swift', path: 'MyApp/App/MyApp.swift', isDirectory: false, extension: 'swift', content: `import SwiftUI\n\n@main\nstruct MyApp: App {\n    @StateObject private var exportService = ExportService()\n\n    var body: some Scene {\n        WindowGroup {\n            ContentView()\n                .environmentObject(exportService)\n        }\n        .windowStyle(.hiddenTitleBar)\n    }\n}` }
          ]
        },
        {
          name: 'Views',
          path: 'MyApp/Views',
          isDirectory: true,
          children: [
            { name: 'ContentView.swift', path: 'MyApp/Views/ContentView.swift', isDirectory: false, extension: 'swift', isModified: true, content: `import SwiftUI\n\nstruct ContentView: View {\n    @EnvironmentObject var exportService: ExportService\n    @State private var selectedVideo: Video? = Video.sample\n\n    var body: some View {\n        NavigationSplitView {\n            SidebarView(selection: $selectedVideo)\n        } detail: {\n            if let video = selectedVideo {\n                PlayerView(video: video)\n            } else {\n                ContentUnavailableView("No Video Selected", systemImage: "video")\n            }\n        }\n    }\n}` },
            { name: 'PlayerView.swift', path: 'MyApp/Views/PlayerView.swift', isDirectory: false, extension: 'swift', hasWarning: true, content: `import SwiftUI\nimport AVKit\n\nstruct PlayerView: View {\n    let video: Video\n    @State private var isPlaying = false\n\n    var body: some View {\n        VStack {\n            VideoPlayer(player: AVPlayer(url: video.fileURL)) // Deprecated warning in macOS 15\n                .frame(minHeight: 300)\n            \n            HStack {\n                Button(isPlaying ? "Pause" : "Play") {\n                    isPlaying.toggle()\n                }\n                .buttonStyle(.borderedProminent)\n            }\n            .padding()\n        }\n    }\n}` }
          ]
        },
        {
          name: 'Models',
          path: 'MyApp/Models',
          isDirectory: true,
          children: [
            { name: 'Video.swift', path: 'MyApp/Models/Video.swift', isDirectory: false, extension: 'swift', content: `import Foundation\n\nstruct Video: Identifiable, Hashable {\n    let id: UUID\n    let title: String\n    let duration: TimeInterval\n    let fileURL: URL\n    let resolution: String\n\n    static val sample = Video(\n        id: UUID(),\n        title: "Keynote_4K_HDR.mov",\n        duration: 120.0,\n        fileURL: URL(string: "file:///sample.mov")!,\n        resolution: "3840x2160"\n    )\n}` }
          ]
        },
        {
          name: 'Services',
          path: 'MyApp/Services',
          isDirectory: true,
          children: [
            { name: 'ExportService.swift', path: 'MyApp/Services/ExportService.swift', isDirectory: false, extension: 'swift', isModified: true, hasError: true, content: `import Foundation\nimport VideoToolbox\n\nfinal class ExportService: ObservableObject {\n    @Published var isExporting = false\n    @Published var progress: Double = 0.0\n\n    func processExport(video: Video) throws {\n        let encoder = try VTCompressionSession.create()\n        for frame in video.frames {\n            encoder.encode(frame) // Synchronous main thread bottleneck\n        }\n    }\n}` }
          ]
        },
        {
          name: 'Tests',
          path: 'MyApp/Tests',
          isDirectory: true,
          children: [
            { name: 'ExportTests.swift', path: 'MyApp/Tests/ExportTests.swift', isDirectory: false, extension: 'swift', hasError: true, content: `import XCTest\n@testable import MyVideoApp\n\nfinal class ExportTests: XCTestCase {\n    func testLargeVideo() throws {\n        let service = ExportService()\n        let result = try service.processExport(video: Video.sample)\n        XCTAssertEqual(result.frameCount, 120, "Expected 120 frames in 4K export")\n    }\n}` }
          ]
        }
      ]
    }
  ]);

  selectedFile = signal<SourceFileNode | null>({
    name: 'ExportService.swift',
    path: 'MyApp/Services/ExportService.swift',
    isDirectory: false,
    extension: 'swift',
    isModified: true,
    hasError: true,
    content: `import Foundation\nimport VideoToolbox\nimport AVFoundation\n\nfinal class ExportService: ObservableObject {\n    @Published var isExporting = false\n    @Published var progress: Double = 0.0\n\n    /// Processes 4K/8K video frames through VTCompressionSession\n    func processExport(video: Video) throws {\n        let encoder = try VTCompressionSession.create()\n        for frame in video.frames {\n            encoder.encode(frame) // Bottleneck: synchronous main-thread blocking\n        }\n    }\n}`
  });

  // Symbols for Inspector
  symbols = signal<SymbolItem[]>([
    { name: 'ExportService', kind: 'class', line: 5, file: 'ExportService.swift', doc: 'Core hardware-accelerated video export coordinator.' },
    { name: 'isExporting', kind: 'var', line: 6, file: 'ExportService.swift', doc: 'Published reactive flag for active export.' },
    { name: 'progress', kind: 'var', line: 7, file: 'ExportService.swift', doc: 'Normalized export progress ratio (0.0 to 1.0).' },
    { name: 'processExport(video:)', kind: 'func', line: 10, file: 'ExportService.swift', doc: 'Encodes raw video frames to target codec output.' }
  ]);

  // Build State
  isBuilding = signal<boolean>(false);
  lastBuildResult = signal<BuildResult>({
    id: 'build-101',
    target: 'MyVideoApp',
    configuration: 'Debug',
    destination: 'My Mac',
    status: 'SUCCEEDED',
    durationSeconds: 38.4,
    warningsCount: 3,
    errorsCount: 0,
    stages: [
      { name: 'Resolve Dependencies', durationSeconds: 1.2, status: 'COMPLETED' },
      { name: 'Compile Swift Sources', durationSeconds: 28.1, status: 'COMPLETED' },
      { name: 'Link Binaries', durationSeconds: 6.7, status: 'COMPLETED' },
      { name: 'Code Sign', durationSeconds: 0.8, status: 'COMPLETED' },
      { name: 'Package App Bundle', durationSeconds: 1.6, status: 'COMPLETED' }
    ],
    diagnostics: [
      { severity: 'WARNING', file: 'PlayerView.swift', line: 48, column: 12, message: "'init(url:)' was deprecated in macOS 15.0: Use modern PlayerItem initializer" },
      { severity: 'WARNING', file: 'ExportService.swift', line: 112, column: 8, message: "Immutable value 'tempFile' was never used; consider replacing with '_'" },
      { severity: 'WARNING', file: 'VideoModel.swift', line: 89, column: 22, message: "Result of call to 'asyncTask()' is unused" }
    ]
  });

  // AI Workspace State
  aiPrompt = signal<string>('Optimise video export performance.');
  isAiAnalyzing = signal<boolean>(false);
  aiStepIndex = signal<number>(0);
  autonomousMode = signal<boolean>(false);

  aiActivePatch = signal<AIPatch | null>({
    id: 'patch-001',
    title: 'Asynchronous Background Encoding Pipeline',
    summary: 'Refactored ExportService to utilize background actor concurrency and VideoToolbox asynchronous frame queues.',
    filePath: 'MyApp/Services/ExportService.swift',
    plan: [
      { number: 1, title: 'Inspect ExportService', description: 'Isolate main-thread synchronous calls in ExportService.swift.' },
      { number: 2, title: 'Analyse encoder pipeline', description: 'Evaluate VTCompressionSession memory footprint under 4K heavy workloads.' },
      { number: 3, title: 'Identify synchronous work', description: 'Isolate blocking sample buffer locks during frame iteration.' },
      { number: 4, title: 'Introduce background processing', description: 'Convert processExport to async throws and dispatch to background TaskGroup.' },
      { number: 5, title: 'Add progress reporting', description: 'Emit AsyncStream<Double> progress updates.' },
      { number: 6, title: 'Add regression tests', description: 'Update ExportTests.testLargeVideo to verify 4K frame count accuracy.' },
      { number: 7, title: 'Build project', description: 'Verify zero compilation errors on macOS 15 SDK.' },
      { number: 8, title: 'Run tests', description: 'Ensure test suite passes with 100% success rate.' }
    ],
    originalContent: `func processExport(video: Video) throws {\n    let encoder = try VTCompressionSession.create()\n    for frame in video.frames {\n        encoder.encode(frame)\n    }\n}`,
    modifiedContent: `func processExport(video: Video) async throws {\n    let encoder = try await VTCompressionSession.createAsync()\n    await withTaskGroup(of: Void.self) { group in\n        for frame in video.frames {\n            group.addTask(priority: .userInitiated) {\n                try? await encoder.encodeAsync(frame)\n            }\n        }\n    }\n}`,
    diffLines: [
      '- func processExport(video: Video) throws {',
      '-     let encoder = try VTCompressionSession.create()',
      '-     for frame in video.frames {',
      '-         encoder.encode(frame) // synchronous block on main thread',
      '-     }',
      '+ func processExport(video: Video) async throws {',
      '+     let encoder = try await VTCompressionSession.createAsync()',
      '+     await withTaskGroup(of: Void.self) { group in',
      '+         for frame in video.frames {',
      '+             group.addTask(priority: .userInitiated) {',
      '+                 try? await encoder.encodeAsync(frame)',
      '+             }',
      '+         }',
      '+     }'
    ]
  });

  // Tests State
  failedTests = signal<TestCase[]>([
    {
      id: 't-2',
      suite: 'ExportTests',
      name: 'testLargeVideo',
      status: 'FAILED',
      durationMs: 420,
      file: 'ExportTests.swift',
      line: 241,
      expected: '4K frame count = 120',
      actual: '118',
      failureMessage: 'Frame count mismatch during 4K HEVC export encode. 2 dropped frames detected.'
    },
    {
      id: 't-4',
      suite: 'EncoderIntegration',
      name: 'testHardwareAccelerator',
      status: 'FAILED',
      durationMs: 1200,
      file: 'EncoderPipeline.swift',
      line: 88,
      expected: 'Metal GPU queue active',
      actual: 'CPU fallback engaged',
      failureMessage: 'Metal encoder failed to reserve hardware unit.'
    },
    {
      id: 't-5',
      suite: 'EncoderIntegration',
      name: 'testAudioMixerSync',
      status: 'FAILED',
      durationMs: 310,
      file: 'AudioMixer.swift',
      line: 104,
      expected: 'Audio latency < 5ms',
      actual: '12ms',
      failureMessage: 'Audio buffer overflow in multi-channel mix.'
    }
  ]);

  // Devices & Simulators State
  devices = signal<DeviceItem[]>([
    { id: 'dev-mac', name: 'My Mac (Apple Silicon M3 Max)', os: 'macOS 15.1', architecture: 'arm64', status: 'BOOTED', deviceType: 'Mac' },
    { id: 'dev-iphone', name: 'iPhone 16 Pro Simulator', os: 'iOS 18.1', architecture: 'arm64', status: 'BOOTED', deviceType: 'iPhone' },
    { id: 'dev-ipad', name: 'iPad Pro 13-inch (M4)', os: 'iPadOS 18.1', architecture: 'arm64', status: 'SHUTDOWN', deviceType: 'iPad' },
    { id: 'dev-watch', name: 'Apple Watch Ultra 2', os: 'watchOS 11.0', architecture: 'arm64', status: 'SHUTDOWN', deviceType: 'Apple Watch' },
    { id: 'dev-tv', name: 'Apple TV 4K', os: 'tvOS 18.0', architecture: 'arm64', status: 'SHUTDOWN', deviceType: 'Apple TV' },
    { id: 'dev-vision', name: 'Apple Vision Pro', os: 'visionOS 2.1', architecture: 'arm64', status: 'SHUTDOWN', deviceType: 'Vision Pro' }
  ]);

  // Performance Data State
  performancePoint = signal<PerformancePoint>({
    timestamp: Date.now(),
    cpuPercent: 48,
    memoryGb: 1.21,
    gpuPercent: 32,
    energyLevel: 'Low',
    networkKbps: 128
  });

  // Architecture Graph State
  archNodes = signal<ArchNode[]>([
    { id: 'app', label: 'MyVideoApp', type: 'App Target', linesCount: 1420, x: 280, y: 30, dependencies: ['views', 'services'] },
    { id: 'views', label: 'UI & SwiftUI Views', type: 'View Layer', linesCount: 3890, x: 120, y: 150, dependencies: ['services'] },
    { id: 'services', label: 'ExportService Core', type: 'Framework', linesCount: 2150, x: 420, y: 150, dependencies: ['vtbox'] },
    { id: 'vtbox', label: 'VideoToolbox (Apple)', type: 'System SDK', linesCount: 0, x: 270, y: 310, dependencies: [] }
  ]);

  // Security Audit State
  securityFindings = signal<SecurityFinding[]>([
    {
      id: 'sec-1',
      severity: 'GOOD',
      title: 'No Exposed Credentials',
      category: 'Secrets',
      description: 'Scanned 142 source files and build configurations. No hardcoded API keys or private tokens detected.',
      remediation: 'Complies with Apple security guidelines.'
    },
    {
      id: 'sec-2',
      severity: 'GOOD',
      title: 'Signing Configuration Valid',
      category: 'Signing',
      description: 'Provisioning profile and developer identity valid for Mac App Store & Direct Distribution.',
      remediation: 'Certificate active until Nov 2027.'
    },
    {
      id: 'sec-3',
      severity: 'WARNING',
      title: '2 Dependency Updates Available',
      category: 'Dependencies',
      description: 'SwiftPackage SwiftLint version 0.54.0 -> 0.56.0 is available with security patches.',
      remediation: 'Run [Resolve Dependencies] to update SPM package locks.'
    }
  ]);

  // System Log Stream
  logs = signal<LogEntry[]>([
    { id: 'l1', category: 'System', level: 'INFO', time: '10:14:02', text: 'AppleCode Engine connected on localhost:8080' },
    { id: 'l2', category: 'Build', level: 'SUCCESS', time: '10:14:15', text: 'xcodebuild: Build Succeeded. Duration 38.4s' },
    { id: 'l3', category: 'Test', level: 'INFO', time: '10:14:20', text: 'Executed 1,845 tests across 14 test suites. 3 failed.' },
    { id: 'l4', category: 'AI', level: 'INFO', time: '10:15:00', text: 'AI Engine indexed 12 source files in ExportService target.' }
  ]);

  // Actions
  toggleTheme() {
    this.isDarkMode.update(v => !v);
    if (this.isDarkMode()) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }

  setRoute(route: AppRoute) {
    this.activeRoute.set(route);
  }

  openProject(proj: Project) {
    this.activeProject.set(proj);
    this.hasOpenedProject.set(true);
    this.activeRoute.set('Overview');
  }

  closeProject() {
    this.hasOpenedProject.set(false);
  }

  triggerBuild() {
    if (this.isBuilding()) return;
    this.isBuilding.set(true);
    this.addLog('Build', 'INFO', `Starting build for target ${this.selectedTarget()} (${this.selectedConfig()})...`);

    setTimeout(() => {
      this.isBuilding.set(false);
      this.lastBuildResult.set({
        ...this.lastBuildResult(),
        durationSeconds: 38.4,
        status: 'SUCCEEDED'
      });
      this.addLog('Build', 'SUCCESS', 'Build Succeeded in 38.4s. 0 errors, 3 warnings.');
    }, 2500);
  }

  triggerAIAnalysis(customPrompt?: string) {
    const promptToUse = customPrompt || this.aiPrompt();
    this.isAiAnalyzing.set(true);
    this.aiStepIndex.set(1);
    this.addLog('AI', 'INFO', `AI Engine starting analysis: "${promptToUse}"`);

    // Simulate pipeline progression
    const interval = setInterval(() => {
      if (this.aiStepIndex() < 8) {
        this.aiStepIndex.update(idx => idx + 1);
      } else {
        clearInterval(interval);
        this.isAiAnalyzing.set(false);
        this.addLog('AI', 'SUCCESS', `AI Analysis complete. Patch generated for ExportService.swift.`);
      }
    }, 600);
  }

  applyPatch() {
    this.addLog('AI', 'SUCCESS', 'Applied AI Patch to ExportService.swift.');
    this.activeRoute.set('Code');
  }

  addLog(category: 'Build' | 'Test' | 'AI' | 'Simulator' | 'Security' | 'System', level: 'INFO' | 'SUCCESS' | 'WARN' | 'ERROR', text: string) {
    const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false });
    const newLog: LogEntry = {
      id: `log-${Date.now()}`,
      category,
      level,
      time: timeStr,
      text
    };
    this.logs.update(list => [...list, newLog]);
  }
}
