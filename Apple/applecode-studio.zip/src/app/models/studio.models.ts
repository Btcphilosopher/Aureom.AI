export interface Project {
  id: string;
  name: string;
  platform: string;
  framework: string;
  path: string;
  buildStatus: 'PASS' | 'FAIL' | 'BUILDING';
  testPassCount: number;
  totalTests: number;
  securityStatus: 'GOOD' | 'WARNING' | 'CRITICAL';
  performanceStatus: 'STABLE' | 'DEGRADED';
  architectureStatus: 'HEALTHY' | 'COMPLEX';
  modifiedCount: number;
  lastBuilt: string;
}

export interface Target {
  id: string;
  name: string;
  platform: string;
  buildConfigurations: string[];
}

export interface SourceFileNode {
  name: string;
  path: string;
  isDirectory: boolean;
  extension?: string;
  isModified?: boolean;
  hasError?: boolean;
  hasWarning?: boolean;
  children?: SourceFileNode[];
  content?: string;
}

export interface SymbolItem {
  name: string;
  kind: 'struct' | 'class' | 'func' | 'var' | 'enum';
  line: number;
  file: string;
  doc?: string;
}

export interface BuildDiagnostic {
  severity: 'ERROR' | 'WARNING' | 'INFO';
  file: string;
  line: number;
  column: number;
  message: string;
}

export interface BuildStage {
  name: string;
  durationSeconds: number;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING';
}

export interface BuildResult {
  id: string;
  target: string;
  configuration: string;
  destination: string;
  status: 'SUCCEEDED' | 'FAILED' | 'BUILDING';
  durationSeconds: number;
  warningsCount: number;
  errorsCount: number;
  stages: BuildStage[];
  diagnostics: BuildDiagnostic[];
}

export interface TestCase {
  id: string;
  suite: string;
  name: string;
  status: 'PASSED' | 'FAILED' | 'SKIPPED';
  durationMs: number;
  file?: string;
  line?: number;
  expected?: string;
  actual?: string;
  failureMessage?: string;
}

export interface TestSuiteGroup {
  name: string;
  cases: TestCase[];
}

export interface DeviceItem {
  id: string;
  name: string;
  os: string;
  architecture: string;
  status: 'BOOTED' | 'SHUTDOWN' | 'CONNECTED';
  deviceType: 'Mac' | 'iPhone' | 'iPad' | 'Apple Watch' | 'Apple TV' | 'Vision Pro';
  udid?: string;
}

export interface PerformancePoint {
  timestamp: number;
  cpuPercent: number;
  memoryGb: number;
  gpuPercent: number;
  energyLevel: string;
  networkKbps: number;
}

export interface ArchNode {
  id: string;
  label: string;
  type: string;
  linesCount: number;
  x: number;
  y: number;
  dependencies: string[];
}

export interface SecurityFinding {
  id: string;
  severity: 'CRITICAL' | 'HIGH' | 'WARNING' | 'GOOD';
  title: string;
  category: 'Secrets' | 'Entitlements' | 'Signing' | 'Dependencies' | 'Filesystem' | 'Network';
  file?: string;
  line?: number;
  description: string;
  remediation: string;
}

export interface AIPlanStep {
  number: number;
  title: string;
  description: string;
  file?: string;
}

export interface AIPatch {
  id: string;
  title: string;
  summary: string;
  plan: AIPlanStep[];
  filePath: string;
  originalContent: string;
  modifiedContent: string;
  diffLines: string[];
}

export interface ReleaseStage {
  name: string;
  status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING' | 'FAILED';
  timestamp?: string;
}

export interface LogEntry {
  id: string;
  category: 'Build' | 'Test' | 'AI' | 'Simulator' | 'Security' | 'System';
  level: 'INFO' | 'SUCCESS' | 'WARN' | 'ERROR';
  time: string;
  text: string;
}

export type AppRoute =
  | 'Overview'
  | 'Files'
  | 'Targets'
  | 'Dependencies'
  | 'Git'
  | 'Code'
  | 'AI'
  | 'Tests'
  | 'Builds'
  | 'Simulator'
  | 'Performance'
  | 'Memory'
  | 'GPU'
  | 'Energy'
  | 'Security'
  | 'Architecture'
  | 'Archives'
  | 'Validation'
  | 'Distribution'
  | 'Settings';
