package studio.applecode

import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowState
import androidx.compose.ui.window.application
import studio.applecode.app.AppleCodeApp
import studio.applecode.theme.AppleCodeTheme

fun main() = application {
    val windowState = WindowState(size = DpSize(1440.dp, 900.dp))
    Window(
        onCloseRequest = ::exitApplication,
        title = "AppleCode Studio — Visual Control Centre",
        state = windowState
    ) {
        AppleCodeTheme {
            AppleCodeApp()
        }
    }
}
