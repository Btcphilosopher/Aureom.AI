package studio.applecode.models

import kotlinx.serialization.Serializable

@Serializable
data class Project(
    val id: String,
    val name: String,
    val platform: String,
    val framework: String,
    val path: String,
    val buildStatus: String,
    val testPassCount: Int,
    val totalTests: Int,
    val securityStatus: String,
    val performanceStatus: String,
    val architectureStatus: String,
    val modifiedCount: Int,
    val lastBuilt: String
)

@Serializable
data class Target(
    val id: String,
    val name: String,
    val platform: String,
    val buildConfigurations: List<String>
)

@Serializable
data class SourceFile(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val extension: String? = null,
    val isModified: Boolean = false,
    val hasError: Boolean = false,
    val hasWarning: Boolean = false,
    val children: List<SourceFile> = emptyList()
)

@Serializable
data class Symbol(
    val name: String,
    val kind: String,
    val line: Int,
    val file: String
)

@Serializable
data class BuildDiagnostic(
    val severity: String, // ERROR, WARNING, INFO
    val file: String,
    val line: Int,
    val column: Int,
    val message: String
)

@Serializable
data class BuildStage(
    val name: String,
    val durationSeconds: Double,
    val status: String
)

@Serializable
data class Build(
    val id: String,
    val target: String,
    val configuration: String,
    val destination: String,
    val status: String,
    val durationSeconds: Double,
    val warningsCount: Int,
    val errorsCount: Int,
    val stages: List<BuildStage> = emptyList(),
    val diagnostics: List<BuildDiagnostic> = emptyList()
)

@Serializable
data class TestCase(
    val id: String,
    val suite: String,
    val name: String,
    val status: String, // PASSED, FAILED, SKIPPED
    val durationMs: Long,
    val file: String? = null,
    val line: Int? = null,
    val expected: String? = null,
    val actual: String? = null,
    val failureMessage: String? = null
)

@Serializable
data class TestRun(
    val id: String,
    val totalCount: Int,
    val passedCount: Int,
    val failedCount: Int,
    val skippedCount: Int,
    val suites: Map<String, List<TestCase>>
)

@Serializable
data class Device(
    val id: String,
    val name: String,
    val os: String,
    val architecture: String,
    val status: String, // BOOTED, SHUTDOWN, CONNECTED
    val deviceType: String // Mac, iPhone, iPad, Apple Watch, Apple TV, Vision Pro
)

@Serializable
data class PerformancePoint(
    val timestamp: Long,
    val cpuPercent: Double,
    val memoryMb: Double,
    val gpuPercent: Double,
    val energyLevel: String,
    val networkKbps: Double
)

@Serializable
data class PerformanceRun(
    val currentCpu: Double,
    val currentMemoryGb: Double,
    val currentGpu: Double,
    val currentEnergy: String,
    val networkKbps: Double,
    val history: List<PerformancePoint>,
    val comparison: PerformanceComparison? = null
)

@Serializable
data class PerformanceComparison(
    val buildTimeOld: Double,
    val buildTimeNew: Double,
    val memoryOldGb: Double,
    val memoryNewGb: Double,
    val cpuOldPercent: Double,
    val cpuNewPercent: Double
)

@Serializable
data class SecurityFinding(
    val id: String,
    val severity: String, // HIGH, MEDIUM, LOW, INFO
    val title: String,
    val category: String, // Secrets, Entitlements, Signing, Dependencies, Filesystem, Network
    val file: String? = null,
    val line: Int? = null,
    val description: String,
    val remediation: String
)

@Serializable
data class SecurityReport(
    val overallStatus: String,
    val findings: List<SecurityFinding>
)

@Serializable
data class AIRequest(
    val prompt: String,
    val contextFiles: List<String> = emptyList(),
    val targetModule: String? = null
)

@Serializable
data class AIPlanStep(
    val number: Int,
    val title: String,
    val description: String,
    val file: String? = null
)

@Serializable
data class AIPatch(
    val id: String,
    val title: String,
    val summary: String,
    val plan: List<AIPlanStep>,
    val filePath: String,
    val originalContent: String,
    val modifiedContent: String,
    val diffLines: List<String>
)

@Serializable
data class ReleaseStage(
    val name: String,
    val status: String, // PENDING, IN_PROGRESS, COMPLETED, FAILED
    val timestamp: String? = null
)

@Serializable
data class Release(
    val version: String,
    val buildNumber: Int,
    val stages: List<ReleaseStage>
)

@Serializable
data class EngineEvent(
    val type: String, // PROJECT_UPDATED, BUILD_STARTED, BUILD_PROGRESS, BUILD_COMPLETED, TEST_STARTED, TEST_COMPLETED, AI_STARTED, AI_PROGRESS, AI_PATCH_READY, PERFORMANCE_UPDATED, SECURITY_UPDATED, DEVICE_CHANGED
    val payload: String
)
