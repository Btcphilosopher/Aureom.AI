package studio.applecode.viewmodels

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import studio.applecode.models.*

data class ProjectUiState(
    val project: Project? = null,
    val targets: List<Target> = emptyList(),
    val selectedTarget: Target? = null,
    val selectedConfig: String = "Debug",
    val selectedDevice: String = "My Mac (Apple Silicon)",
    val isLoading: Boolean = false,
    val isConnected: Boolean = true,
    val errorMessage: String? = null
)

class ProjectViewModel {
    private val _uiState = MutableStateFlow(ProjectUiState())
    val uiState: StateFlow<ProjectUiState> = _uiState.asStateFlow()

    fun selectTarget(target: Target) {
        _uiState.value = _uiState.value.copy(selectedTarget = target)
    }

    fun selectConfig(config: String) {
        _uiState.value = _uiState.value.copy(selectedConfig = config)
    }

    fun selectDevice(device: String) {
        _uiState.value = _uiState.value.copy(selectedDevice = device)
    }
}

data class BuildUiState(
    val currentBuild: Build? = null,
    val isBuilding: Boolean = false,
    val buildHistory: List<Build> = emptyList()
)

class BuildViewModel {
    private val _uiState = MutableStateFlow(BuildUiState())
    val uiState: StateFlow<BuildUiState> = _uiState.asStateFlow()

    fun startBuild(target: String, config: String) {
        _uiState.value = _uiState.value.copy(isBuilding = true)
    }
}

data class AIUiState(
    val prompt: String = "",
    val isAnalysing: Boolean = false,
    val activePatch: AIPatch? = null,
    val history: List<AIPatch> = emptyList(),
    val autonomousMode: Boolean = false
)

class AIViewModel {
    private val _uiState = MutableStateFlow(AIUiState())
    val uiState: StateFlow<AIUiState> = _uiState.asStateFlow()

    fun setPrompt(text: String) {
        _uiState.value = _uiState.value.copy(prompt = text)
    }

    fun toggleAutonomousMode() {
        _uiState.value = _uiState.value.copy(autonomousMode = !_uiState.value.autonomousMode)
    }
}
