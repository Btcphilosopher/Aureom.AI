package studio.applecode.app

enum class AppRoute(val title: String, val section: String) {
    OVERVIEW("Overview", "PROJECT"),
    FILES("Files", "PROJECT"),
    TARGETS("Targets", "PROJECT"),
    DEPENDENCIES("Dependencies", "PROJECT"),
    GIT("Git", "PROJECT"),

    CODE("Code Workspace", "DEVELOP"),
    AI("AI Engineer", "DEVELOP"),
    TESTS("Test Lab", "DEVELOP"),
    BUILDS("Build Control", "DEVELOP"),
    SIMULATOR("Simulator & Devices", "DEVELOP"),

    PERFORMANCE("Performance", "ANALYSE"),
    MEMORY("Memory", "ANALYSE"),
    GPU("GPU", "ANALYSE"),
    ENERGY("Energy", "ANALYSE"),
    SECURITY("Security", "ANALYSE"),
    ARCHITECTURE("Architecture Graph", "ANALYSE"),

    ARCHIVES("Archives", "RELEASE"),
    VALIDATION("Validation", "RELEASE"),
    DISTRIBUTION("Distribution", "RELEASE"),

    SETTINGS("Settings", "SYSTEM")
}
