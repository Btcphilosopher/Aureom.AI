package studio.applecode.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import studio.applecode.theme.LocalAppleCodeColors

@Composable
fun AppleCodeApp() {
    val colors = LocalAppleCodeColors.current
    var currentRoute by remember { mutableStateOf(AppRoute.OVERVIEW) }
    var isCommandPaletteOpen by remember { mutableStateOf(false) }
    var isDrawerOpen by remember { mutableStateOf(false) }
    var drawerTab by remember { mutableStateOf("Logs") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        // macOS TitleBar & Top Toolbar
        TopToolbar(
            currentRoute = currentRoute,
            onCommandPaletteToggle = { isCommandPaletteOpen = !isCommandPaletteOpen }
        )

        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
            // Sidebar Navigation
            SidebarNav(
                currentRoute = currentRoute,
                onRouteSelected = { currentRoute = it }
            )

            // Main Workspace View
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(colors.elevatedBackground)
            ) {
                when (currentRoute) {
                    AppRoute.OVERVIEW -> Text("Project Overview", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.CODE -> Text("Code Workspace (Files, Editor, Inspector)", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.AI -> Text("AI Engineering Workspace & Diff Viewer", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.BUILDS -> Text("Build Control & Stage Timeline", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.TESTS -> Text("Test Lab & Test Failure Diagnostics", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.SIMULATOR -> Text("Simulator & Discovered Devices", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.PERFORMANCE -> Text("Performance & Memory Dashboard", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.SECURITY -> Text("Security Findings & Audit", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.ARCHITECTURE -> Text("Interactive Architecture Dependency Graph", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.ARCHIVES -> Text("Release Pipeline & Distribution", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    AppRoute.SETTINGS -> Text("AppleCode Preferences", color = colors.primaryText, modifier = Modifier.padding(24.dp))
                    else -> Text(currentRoute.title, color = colors.primaryText, modifier = Modifier.padding(24.dp))
                }
            }
        }

        // Bottom Expandable Drawer (Terminal / Logs)
        BottomLogDrawer(
            isOpen = isDrawerOpen,
            activeTab = drawerTab,
            onToggle = { isDrawerOpen = !isDrawerOpen },
            onTabSelect = { drawerTab = it }
        )
    }
}

@Composable
fun TopToolbar(
    currentRoute: AppRoute,
    onCommandPaletteToggle: () -> Unit
) {
    val colors = LocalAppleCodeColors.current
    Surface(
        modifier = Modifier.fillMaxWidth().height(52.dp),
        color = colors.background,
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // macOS Window Control Dots + Branding
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(modifier = Modifier.size(12.dp).background(Color(0xFFFF5F56), shape = RoundedCornerShape(6.dp)))
                    Box(modifier = Modifier.size(12.dp).background(Color(0xFFFFBD2E), shape = RoundedCornerShape(6.dp)))
                    Box(modifier = Modifier.size(12.dp).background(Color(0xFF27C93F), shape = RoundedCornerShape(6.dp)))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "APPLECODE.STUDIO",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    color = colors.primaryText
                )
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .background(colors.success.copy(alpha = 0.15f), shape = RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("● Engine Connected", fontSize = 10.sp, color = colors.success)
                }
            }

            // Target Dropdowns
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                CompactPill(text = "MyVideoApp")
                Text("•", color = colors.secondaryText, fontSize = 11.sp)
                CompactPill(text = "macOS")
                Text("•", color = colors.secondaryText, fontSize = 11.sp)
                CompactPill(text = "Debug")
            }

            // Quick Actions
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { },
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("BUILD ⌘B", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onCommandPaletteToggle) {
                    Icon(Icons.Default.Search, contentDescription = "Command Palette", tint = colors.primaryText)
                }
            }
        }
    }
}

@Composable
fun CompactPill(text: String) {
    val colors = LocalAppleCodeColors.current
    Box(
        modifier = Modifier
            .background(colors.secondaryBackground, shape = RoundedCornerShape(4.dp))
            .border(1.dp, colors.border, shape = RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text, fontSize = 11.sp, color = colors.primaryText, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun SidebarNav(
    currentRoute: AppRoute,
    onRouteSelected: (AppRoute) -> Unit
) {
    val colors = LocalAppleCodeColors.current
    Column(
        modifier = Modifier
            .width(220.dp)
            .fillMaxHeight()
            .background(colors.background)
            .border(end = 1.dp, color = colors.border)
            .padding(vertical = 12.dp, horizontal = 8.dp)
    ) {
        val sections = AppRoute.values().groupBy { it.section }
        sections.forEach { (section, routes) ->
            Text(
                text = section,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = colors.secondaryText,
                modifier = Modifier.padding(start = 8.dp, top = 8.dp, bottom = 4.dp)
            )
            routes.forEach { route ->
                val isSelected = currentRoute == route
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .background(
                            if (isSelected) colors.accent.copy(alpha = 0.15f) else Color.Transparent,
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { onRouteSelected(route) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = route.title,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (isSelected) colors.accent else colors.primaryText
                    )
                }
            }
        }
    }
}

@Composable
fun BottomLogDrawer(
    isOpen: Boolean,
    activeTab: String,
    onToggle: () -> Unit,
    onTabSelect: (String) -> Unit
) {
    val colors = LocalAppleCodeColors.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.background)
            .border(top = 1.dp, color = colors.border)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(32.dp)
                .clickable { onToggle() }
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("LOGS & DIAGNOSTICS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = colors.secondaryText)
                listOf("Build", "Test", "AI", "Simulator", "Security", "System").forEach { tab ->
                    Text(
                        text = tab,
                        fontSize = 11.sp,
                        fontWeight = if (activeTab == tab) FontWeight.Bold else FontWeight.Normal,
                        color = if (activeTab == tab) colors.accent else colors.secondaryText,
                        modifier = Modifier.clickable { onTabSelect(tab) }
                    )
                }
            }
            Text(if (isOpen) "▼ Hide" else "▲ Expand", fontSize = 10.sp, color = colors.secondaryText)
        }
        if (isOpen) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(colors.elevatedBackground)
                    .padding(8.dp)
            ) {
                Text(
                    text = "[10:14:15] xcodebuild: Build Succeeded. Duration 38.4s\n[10:14:20] Executed 1,845 tests across 14 test suites. 3 failed.\n[10:15:00] AI Engine indexed 12 source files in ExportService target.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = colors.primaryText
                )
            }
        }
    }
}
