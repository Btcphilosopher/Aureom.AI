package studio.applecode.network

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.websocket.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json
import studio.applecode.models.*

class PythonEngineClient(
    private val baseUrl: String = "http://127.0.0.1:3000/api/engine"
) {
    private val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                prettyPrint = true
            })
        }
        install(WebSockets)
    }

    suspend fun getStatus(): Map<String, String> {
        return try {
            client.get("$baseUrl/status").body()
        } catch (e: Exception) {
            mapOf("connected" to "false", "error" to (e.message ?: "Offline"))
        }
    }

    suspend fun getProject(): Project {
        return client.get("$baseUrl/project").body()
    }

    suspend fun triggerBuild(target: String, configuration: String): Build {
        return client.post("$baseUrl/build") {
            contentType(ContentType.Application.Json)
            setBody(mapOf("target" to target, "configuration" to configuration))
        }.body()
    }

    suspend fun runTests(): TestRun {
        return client.post("$baseUrl/test").body()
    }

    suspend fun requestAIAnalysis(prompt: String): AIPatch {
        return client.post("$baseUrl/ai") {
            contentType(ContentType.Application.Json)
            setBody(mapOf("prompt" to prompt))
        }.body()
    }

    suspend fun getDevices(): List<Device> {
        return client.get("$baseUrl/devices").body()
    }
}
