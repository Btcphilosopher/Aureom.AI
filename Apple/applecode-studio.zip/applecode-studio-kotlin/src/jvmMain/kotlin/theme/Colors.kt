package studio.applecode.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object AppleCodeColors {
    // Light Palette
    val LightBackground = Color(0xFFF6F6F8)
    val LightElevatedBackground = Color(0xFFFFFFFF)
    val LightSecondaryBackground = Color(0xFFEBECEF)
    val LightPrimaryText = Color(0xFF1D1D1F)
    val LightSecondaryText = Color(0xFF6E6E73)
    val LightBorder = Color(0xFFE2E2E7)

    // Dark Palette
    val DarkBackground = Color(0xFF1E1E20)
    val DarkElevatedBackground = Color(0xFF28282A)
    val DarkSecondaryBackground = Color(0xFF323235)
    val DarkPrimaryText = Color(0xFFF5F5F7)
    val DarkSecondaryText = Color(0xFF86868B)
    val DarkBorder = Color(0xFF38383A)

    // Accents
    val SystemBlue = Color(0xFF007AFF)
    val SystemGreen = Color(0xFF34C759)
    val SystemOrange = Color(0xFFFF9500)
    val SystemRed = Color(0xFFFF3B30)
    val SystemPurple = Color(0xFFAF52DE)

    // Code Syntax
    val SyntaxKeyword = Color(0xFFFF7AB2)
    val SyntaxString = Color(0xFFFF8170)
    val SyntaxNumber = Color(0xFFD0BF69)
    val SyntaxComment = Color(0xFF7F8C8D)
    val SyntaxFunction = Color(0xFF78DCE8)
}

object AppleCodeDimensions {
    val sidebarWidth: Dp = 240.dp
    val inspectorWidth: Dp = 280.dp
    val toolbarHeight: Dp = 52.dp
    val bottomDrawerHeaderHeight: Dp = 36.dp
    val panelRadius: Dp = 10.dp
    val buttonRadius: Dp = 6.dp
    val badgeRadius: Dp = 4.dp
}
