package studio.applecode.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf

data class AppleCodeThemeColors(
    val background: androidx.compose.ui.graphics.Color,
    val elevatedBackground: androidx.compose.ui.graphics.Color,
    val secondaryBackground: androidx.compose.ui.graphics.Color,
    val primaryText: androidx.compose.ui.graphics.Color,
    val secondaryText: androidx.compose.ui.graphics.Color,
    val border: androidx.compose.ui.graphics.Color,
    val accent: androidx.compose.ui.graphics.Color,
    val success: androidx.compose.ui.graphics.Color,
    val warning: androidx.compose.ui.graphics.Color,
    val error: androidx.compose.ui.graphics.Color
)

val LocalAppleCodeColors = staticCompositionLocalOf {
    AppleCodeThemeColors(
        background = AppleCodeColors.DarkBackground,
        elevatedBackground = AppleCodeColors.DarkElevatedBackground,
        secondaryBackground = AppleCodeColors.DarkSecondaryBackground,
        primaryText = AppleCodeColors.DarkPrimaryText,
        secondaryText = AppleCodeColors.DarkSecondaryText,
        border = AppleCodeColors.DarkBorder,
        accent = AppleCodeColors.SystemBlue,
        success = AppleCodeColors.SystemGreen,
        warning = AppleCodeColors.SystemOrange,
        error = AppleCodeColors.SystemRed
    )
}

@Composable
fun AppleCodeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val themeColors = if (darkTheme) {
        AppleCodeThemeColors(
            background = AppleCodeColors.DarkBackground,
            elevatedBackground = AppleCodeColors.DarkElevatedBackground,
            secondaryBackground = AppleCodeColors.DarkSecondaryBackground,
            primaryText = AppleCodeColors.DarkPrimaryText,
            secondaryText = AppleCodeColors.DarkSecondaryText,
            border = AppleCodeColors.DarkBorder,
            accent = AppleCodeColors.SystemBlue,
            success = AppleCodeColors.SystemGreen,
            warning = AppleCodeColors.SystemOrange,
            error = AppleCodeColors.SystemRed
        )
    } else {
        AppleCodeThemeColors(
            background = AppleCodeColors.LightBackground,
            elevatedBackground = AppleCodeColors.LightElevatedBackground,
            secondaryBackground = AppleCodeColors.LightSecondaryBackground,
            primaryText = AppleCodeColors.LightPrimaryText,
            secondaryText = AppleCodeColors.LightSecondaryText,
            border = AppleCodeColors.LightBorder,
            accent = AppleCodeColors.SystemBlue,
            success = AppleCodeColors.SystemGreen,
            warning = AppleCodeColors.SystemOrange,
            error = AppleCodeColors.SystemRed
        )
    }

    val materialColorScheme = if (darkTheme) {
        darkColorScheme(
            background = themeColors.background,
            surface = themeColors.elevatedBackground,
            primary = themeColors.accent,
            onPrimary = themeColors.primaryText,
            onSurface = themeColors.primaryText
        )
    } else {
        lightColorScheme(
            background = themeColors.background,
            surface = themeColors.elevatedBackground,
            primary = themeColors.accent,
            onPrimary = themeColors.primaryText,
            onSurface = themeColors.primaryText
        )
    }

    CompositionLocalProvider(LocalAppleCodeColors provides themeColors) {
        MaterialTheme(
            colorScheme = materialColorScheme,
            content = content
        )
    }
}
