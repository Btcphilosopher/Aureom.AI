import Cocoa
import UniformTypeIdentifiers

/**
 * WORDCORE.OS - Native macOS AppKit & TextKit 2 Document Window Controller
 * File: macos/WordCoreApp.swift
 */
@main
class WordCoreApplication: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSDocumentController.shared.openUntitledDocumentAndDisplay(true) { doc, success, err in
            print("[WORDCORE.OS] Native TextKit 2 Document Initialized.")
        }
    }
}

class WordCoreDocument: NSDocument {
    var documentContent: String = ""
    
    override class var autosavesInPlace: Bool {
        return true
    }
    
    override func makeWindowControllers() {
        let windowController = WordCoreWindowController()
        self.addWindowController(windowController)
    }
    
    override func data(ofType typeName: String) throws -> Data {
        return documentContent.data(using: .utf8) ?? Data()
    }
    
    override func read(from data: Data, ofType typeName: String) throws {
        self.documentContent = String(data: data, encoding: .utf8) ?? ""
    }
}

class WordCoreWindowController: NSWindowController {
    convenience init() {
        let window = NSWindow(
            contentRect: NSRect(x: 100, y: 100, width: 1200, height: 850),
            styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView],
            backing: .buffered,
            defer: false
        )
        window.title = "WORDCORE.OS"
        window.titlebarAppearsTransparent = true
        self.init(window: window)
    }
}
