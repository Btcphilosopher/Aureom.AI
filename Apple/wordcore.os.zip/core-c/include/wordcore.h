/**
 * WORDCORE.OS - High-Performance C Engine Header
 * File: core-c/include/wordcore.h
 * Library: libwordcore
 */

#ifndef WORDCORE_H
#define WORDCORE_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define WORDCORE_VERSION_MAJOR 1
#define WORDCORE_VERSION_MINOR 0
#define WORDCORE_VERSION_PATCH 0

/* Error Codes */
typedef enum {
    WORDCORE_OK = 0,
    WORDCORE_ERR_NULL_PTR = -1,
    WORDCORE_ERR_OUT_OF_MEMORY = -2,
    WORDCORE_ERR_INVALID_RANGE = -3,
    WORDCORE_ERR_QUORUM_DEFICIT = -4
} wordcore_status_t;

/* Diff Operations */
typedef enum {
    DIFF_OP_UNCHANGED = 0,
    DIFF_OP_ADDED = 1,
    DIFF_OP_DELETED = 2,
    DIFF_OP_MODIFIED = 3
} wordcore_diff_op_t;

typedef struct {
    wordcore_diff_op_t op;
    size_t start_offset;
    size_t length;
    const char *text_ptr;
} wordcore_diff_chunk_t;

typedef struct {
    wordcore_diff_chunk_t *chunks;
    size_t chunk_count;
    size_t additions;
    size_t deletions;
    size_t modifications;
    double similarity_ratio;
    double execution_time_ms;
} wordcore_diff_result_t;

/* Document Statistics */
typedef struct {
    uint64_t total_words;
    uint64_t total_chars;
    uint64_t total_chars_no_spaces;
    uint64_t total_sentences;
    uint64_t total_paragraphs;
    uint64_t complex_words;
    double flesch_reading_ease;
    double flesch_kincaid_grade;
    double gunning_fog_index;
    double lexical_diversity_ttr;
} wordcore_stats_t;

/* Token Index */
typedef struct {
    size_t word_offset;
    size_t char_offset;
    size_t length;
} wordcore_token_t;

/* API Exports */
wordcore_status_t wordcore_tokenize(
    const char *input_text,
    size_t input_len,
    wordcore_token_t **out_tokens,
    size_t *out_count
);

wordcore_status_t wordcore_diff(
    const char *original_text,
    size_t orig_len,
    const char *proposed_text,
    size_t prop_len,
    wordcore_diff_result_t *out_result
);

wordcore_status_t wordcore_search_exact(
    const char *haystack,
    size_t haystack_len,
    const char *needle,
    size_t needle_len,
    bool case_sensitive,
    size_t **out_matches,
    size_t *out_match_count
);

wordcore_status_t wordcore_compute_stats(
    const char *document_text,
    size_t length,
    wordcore_stats_t *out_stats
);

void wordcore_diff_free(wordcore_diff_result_t *result);
void wordcore_tokens_free(wordcore_token_t *tokens);

#ifdef __cplusplus
}
#endif

#endif /* WORDCORE_H */
