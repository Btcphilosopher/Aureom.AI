export type SectionType =
  | 'heading'
  | 'paragraph'
  | 'list'
  | 'table'
  | 'quote'
  | 'code'
  | 'image'
  | 'footnote'
  | 'divider';

export type HeadingLevel = 1 | 2 | 3 | 4;

export type ListType = 'bullet' | 'numbered' | 'checkbox';

export interface ListItem {
  id: string;
  text: string;
  checked?: boolean;
}

export interface TableCell {
  id: string;
  content: string;
  align?: 'left' | 'center' | 'right';
  bold?: boolean;
}

export interface TableData {
  headers: TableCell[];
  rows: TableCell[][];
  caption?: string;
}

export interface SectionAnnotation {
  id: string;
  startOffset: number;
  endOffset: number;
  type: 'grammar' | 'style' | 'fact' | 'comment' | 'ai-suggestion';
  message: string;
  suggestion?: string;
  confidence?: number;
  author?: string;
  createdAt: string;
}

export interface WordCoreSection {
  id: string;
  type: SectionType;
  level?: HeadingLevel;
  content?: string;
  listType?: ListType;
  listItems?: ListItem[];
  tableData?: TableData;
  quoteAuthor?: string;
  codeLanguage?: string;
  imageUrl?: string;
  imageCaption?: string;
  footnoteNumber?: number;
  annotations?: SectionAnnotation[];
  aiMetadata?: {
    lastAnalyzed?: string;
    readabilityScore?: number;
    tone?: string;
    complexity?: number;
    passiveVoice?: boolean;
    keywords?: string[];
  };
}

export interface WordCoreCitation {
  id: string;
  key: string; // e.g. "Smith2024"
  title: string;
  authors: string[];
  year: number;
  journalOrPublisher?: string;
  volume?: string;
  issue?: string;
  pages?: string;
  doiOrUrl?: string;
  style?: 'APA' | 'MLA' | 'Chicago' | 'Harvard' | 'Custom';
}

export interface DefinedConcept {
  id: string;
  term: string;
  expansionOrDefinition: string;
  abbreviation?: string;
  firstMentionSectionId: string;
  category: 'term' | 'entity' | 'abbreviation' | 'fact';
  confidence: number;
}

export interface KnowledgeNode {
  id: string;
  label: string;
  type: 'concept' | 'section' | 'entity' | 'claim';
  sectionId?: string;
}

export interface KnowledgeEdge {
  id: string;
  source: string;
  target: string;
  relation: 'defines' | 'references' | 'contradicts' | 'supports' | 'mentions' | 'depends_on';
  note?: string;
}

export interface WordCoreKnowledgeGraph {
  nodes: KnowledgeNode[];
  edges: KnowledgeEdge[];
}

export interface WordCoreVersion {
  versionNumber: number;
  timestamp: string;
  author: string;
  summary: string;
  wordCount: number;
  snapshot: string; // serialized JSON
}

export interface WordCoreMetadata {
  id: string;
  title: string;
  subtitle?: string;
  author: string;
  createdAt: string;
  updatedAt: string;
  language: string;
  tags: string[];
  pageFormat: 'US-Letter' | 'A4' | 'Executive';
  marginsInch: { top: number; right: number; bottom: number; left: number };
  lineSpacing: number; // 1.15, 1.5, 2.0
  fontFamily: 'SF Pro' | 'Newsreader' | 'JetBrains Mono' | 'Georgia' | 'Helvetica';
  fontSize: number; // pt
}

export interface WordCoreDocument {
  format: 'wordcore';
  version: number;
  metadata: WordCoreMetadata;
  sections: WordCoreSection[];
  citations: WordCoreCitation[];
  definedConcepts: DefinedConcept[];
  knowledgeGraph: WordCoreKnowledgeGraph;
  versionHistory: WordCoreVersion[];
}

// C Engine Diff types
export type DiffOp = 'UNCHANGED' | 'ADDED' | 'DELETED' | 'MODIFIED';

export interface DiffChunk {
  op: DiffOp;
  text: string;
  originalText?: string;
  proposedText?: string;
  startIndex: number;
  endIndex: number;
}

export interface DiffResult {
  hasChanges: boolean;
  chunks: DiffChunk[];
  insertionsCount: number;
  deletionsCount: number;
  modificationsCount: number;
  similarityRatio: number;
  executionTimeMs: number;
}

export interface ExactSearchMatch {
  sectionId: string;
  sectionIndex: number;
  startOffset: number;
  endOffset: number;
  snippet: string;
  exactTerm: string;
}

export interface DocumentStatsSummary {
  words: number;
  characters: number;
  charactersNoSpaces: number;
  sentences: number;
  paragraphs: number;
  sections: number;
  readingTimeMinutes: number;
  speakingTimeMinutes: number;
  pagesEstimated: number;
  lexicalDiversity: number;
  fleschReadingEase: number;
  fleschKincaidGrade: number;
  gunningFogIndex: number;
  avgWordsPerSentence: number;
  avgSentencesPerParagraph: number;
  activePassivesRatio: number;
}

// AI Engine Types
export type AIScope =
  | 'CURRENT_WORD'
  | 'CURRENT_SENTENCE'
  | 'CURRENT_PARAGRAPH'
  | 'CURRENT_SECTION'
  | 'CURRENT_SELECTION'
  | 'CURRENT_PAGE'
  | 'ENTIRE_DOCUMENT';

export interface AIProposal {
  id: string;
  prompt: string;
  scope: AIScope;
  targetSectionId?: string;
  originalText: string;
  proposedText: string;
  explanation: string;
  diff: DiffResult;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED';
  timestamp: string;
}

export interface GrammarIssue {
  id: string;
  sectionId: string;
  range: { start: number; end: number };
  original: string;
  replacement: string;
  reason: string;
  ruleCategory: 'Grammar' | 'Punctuation' | 'Spelling' | 'Clarity' | 'Redundancy';
  confidence: number;
}

export interface StyleMetric {
  name: string;
  score: number; // 0 - 100
  rating: 'Excellent' | 'Good' | 'Fair' | 'Needs Attention';
  description: string;
}

export type StyleProfile =
  | 'academic'
  | 'business'
  | 'technical'
  | 'journalistic'
  | 'creative'
  | 'legal'
  | 'plain_english'
  | 'casual';

export interface StyleAnalysis {
  profile: StyleProfile;
  formalityScore: number;
  clarityScore: number;
  concisenessScore: number;
  toneScore: number;
  sentenceVariationScore: number;
  metrics: StyleMetric[];
  suggestions: string[];
}

export interface ContradictionAlert {
  id: string;
  type: 'POTENTIAL_CONTRADICTION' | 'FACT_INCONSISTENCY' | 'TIMELINE_DISCREPANCY';
  confidence: number;
  claimA: string;
  claimB: string;
  sectionIdA: string;
  sectionIdB: string;
  sectionTitleA: string;
  sectionTitleB: string;
  explanation: string;
  evidence: string[];
}

export interface OutlineItem {
  id: string;
  sectionId: string;
  title: string;
  level: number;
  summary?: string;
  argumentType?: 'thesis' | 'background' | 'evidence' | 'analysis' | 'counter-argument' | 'conclusion';
  wordCount: number;
  subItems?: OutlineItem[];
}

export interface SemanticSearchResult {
  sectionId: string;
  sectionTitle: string;
  snippet: string;
  score: number; // 0 - 1
  relevanceExplanation: string;
}

// R Engine Types
export interface RReadabilityReport {
  fleschReadingEase: number;
  fleschReadingEaseLabel: string;
  fleschKincaidGradeLevel: number;
  gunningFogIndex: number;
  colemanLiauIndex: number;
  smogIndex: number;
  automatedReadabilityIndex: number;
  daleChallScore: number;
  targetAudience: string;
}

export interface RLexicalStats {
  typeTokenRatio: number;
  movingAverageTTR: number;
  hapaxLegomenaPercentage: number;
  yulesKCharacteristic: number;
  vocabularyRichnessLabel: string;
}

export interface RWordFrequencyItem {
  word: string;
  count: number;
  frequency: number;
  isStopword: boolean;
}

export interface RWritingTimelinePoint {
  timeIndex: number;
  timestamp: string;
  totalWords: number;
  netAdded: number;
  complexityScore: number;
  readabilityScore: number;
}
