import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AIProposal } from '../../models/wordcore.types';

@Component({
  selector: 'app-diff-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div
        class="w-full max-w-4xl bg-[#121215] border border-white/10 rounded-xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        <!-- Header -->
        <div class="px-5 py-3.5 bg-[#18181d] border-b border-white/10 flex items-center justify-between">
          <div class="flex items-center gap-2.5">
            <mat-icon class="text-blue-400">compare_arrows</mat-icon>
            <div>
              <div class="text-sm font-semibold text-white flex items-center gap-2">
                <span>AI Proposed Revision</span>
                <span class="px-2 py-0.5 rounded text-[10px] uppercase font-mono bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  libwordcore Myers Diff
                </span>
              </div>
              <div class="text-xs text-zinc-400">{{ proposal.prompt }}</div>
            </div>
          </div>

          <!-- Diff View Mode Selector -->
          <div class="flex items-center gap-2">
            <div class="flex bg-[#202026] p-0.5 rounded border border-white/10 text-xs">
              <button
                (click)="viewMode.set('unified')"
                [class.bg-[#30303a]]="viewMode() === 'unified'"
                [class.text-white]="viewMode() === 'unified'"
                [class.text-zinc-400]="viewMode() !== 'unified'"
                class="px-2.5 py-1 rounded transition cursor-pointer"
              >
                Unified Diff
              </button>
              <button
                (click)="viewMode.set('split')"
                [class.bg-[#30303a]]="viewMode() === 'split'"
                [class.text-white]="viewMode() === 'split'"
                [class.text-zinc-400]="viewMode() !== 'split'"
                class="px-2.5 py-1 rounded transition cursor-pointer"
              >
                Side-by-Side
              </button>
            </div>
            <button (click)="reject()" class="p-1 text-zinc-400 hover:text-white transition cursor-pointer">
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>
        </div>

        <!-- Metric Statistics Bar -->
        <div class="px-5 py-2 bg-[#0c0c0e] border-b border-white/5 flex items-center justify-between text-xs text-zinc-400 font-mono">
          <div class="flex items-center gap-4">
            <span class="text-emerald-400 font-semibold">+{{ proposal.diff.insertionsCount }} added</span>
            <span class="text-red-400 font-semibold">-{{ proposal.diff.deletionsCount }} deleted</span>
            <span class="text-blue-400 font-semibold">~{{ proposal.diff.modificationsCount }} modified</span>
            <span>Similarity: {{ (proposal.diff.similarityRatio * 100).toFixed(0) }}%</span>
          </div>
          <span class="text-zinc-400">C Engine Execution: {{ proposal.diff.executionTimeMs }}ms</span>
        </div>

        <!-- Diff Content Area -->
        <div class="p-5 flex-1 overflow-y-auto bg-[#0a0a0c]">
          <!-- AI Explanation note -->
          <div class="mb-4 p-3 rounded-lg bg-blue-950/20 border border-blue-500/20 text-xs text-blue-200 flex items-start gap-2.5">
            <mat-icon class="text-blue-400 text-sm shrink-0">info</mat-icon>
            <div>
              <span class="font-semibold text-blue-300">Semantic Explanation:</span>
              <span class="ml-1">{{ proposal.explanation }}</span>
            </div>
          </div>

          <!-- Unified Diff View -->
          @if (viewMode() === 'unified') {
            <div class="p-4 rounded-lg bg-[#141418] border border-white/10 text-sm leading-relaxed text-zinc-200 select-text">
              @for (chunk of proposal.diff.chunks; track $index) {
                @if (chunk.op === 'UNCHANGED') {
                  <span>{{ chunk.text }} </span>
                } @else if (chunk.op === 'ADDED') {
                  <span class="diff-added">{{ chunk.text }} </span>
                } @else if (chunk.op === 'DELETED') {
                  <span class="diff-deleted">{{ chunk.text }} </span>
                } @else if (chunk.op === 'MODIFIED') {
                  <span class="diff-modified" title="Modified from: '{{ chunk.originalText }}'">
                    {{ chunk.proposedText }} </span>
                }
              }
            </div>
          }

          <!-- Side-by-Side Split View -->
          @if (viewMode() === 'split') {
            <div class="grid grid-cols-2 gap-4">
              <!-- Original Panel -->
              <div class="flex flex-col rounded-lg bg-[#141418] border border-red-500/20 overflow-hidden">
                <div class="px-3 py-1.5 bg-red-950/20 border-b border-red-500/20 text-xs font-semibold text-red-300 uppercase tracking-wider font-mono">
                  Original Text
                </div>
                <div class="p-4 text-sm leading-relaxed text-zinc-300 flex-1 whitespace-pre-wrap select-text">
                  {{ proposal.originalText }}
                </div>
              </div>

              <!-- Proposed Panel -->
              <div class="flex flex-col rounded-lg bg-[#141418] border border-emerald-500/20 overflow-hidden">
                <div class="px-3 py-1.5 bg-emerald-950/20 border-b border-emerald-500/20 text-xs font-semibold text-emerald-300 uppercase tracking-wider font-mono">
                  AI Proposal
                </div>
                <div class="p-4 text-sm leading-relaxed text-zinc-200 flex-1 whitespace-pre-wrap select-text">
                  {{ proposal.proposedText }}
                </div>
              </div>
            </div>
          }
        </div>

        <!-- Action Footer -->
        <div class="px-5 py-3.5 bg-[#18181d] border-t border-white/10 flex items-center justify-between">
          <div class="text-xs text-zinc-400 font-mono">
            Reviewing proposal for <span class="text-white">{{ proposal.scope }}</span>
          </div>

          <div class="flex items-center gap-2">
            <button
              (click)="reject()"
              class="px-4 py-2 rounded-lg bg-[#22222a] hover:bg-[#2c2c36] text-zinc-300 hover:text-white text-xs font-medium transition cursor-pointer border border-white/10 flex items-center gap-1.5"
            >
              <mat-icon class="text-sm text-red-400">close</mat-icon>
              Reject
            </button>
            <button
              (click)="accept()"
              class="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition cursor-pointer shadow-md flex items-center gap-1.5"
            >
              <mat-icon class="text-sm">check</mat-icon>
              Accept Proposal
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class DiffModalComponent {
  @Input({ required: true }) proposal!: AIProposal;
  @Output() accepted = new EventEmitter<AIProposal>();
  @Output() rejected = new EventEmitter<AIProposal>();

  viewMode = signal<'unified' | 'split'>('unified');

  accept() {
    this.accepted.emit(this.proposal);
  }

  reject() {
    this.rejected.emit(this.proposal);
  }
}
