import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { AIScope } from '../../models/wordcore.types';

@Component({
  selector: 'app-ai-command-bar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div
      role="dialog"
      aria-modal="true"
      tabindex="0"
      class="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center pt-24 px-4"
      (click)="onBackdropClick($event)"
      (keydown.escape)="close()"
    >
      <div
        class="w-full max-w-2xl bg-[#121215] border border-white/10 rounded-xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150"
      >
        <!-- Top Scope and Privacy Bar -->
        <div class="px-4 py-2.5 bg-[#18181d] border-b border-white/10 flex items-center justify-between text-xs">
          <div class="flex items-center gap-2">
            <span class="text-zinc-400 font-medium">Scope:</span>
            <select
              [value]="selectedScope()"
              (change)="onScopeChange($event)"
              class="bg-[#24242a] border border-white/15 text-blue-400 font-medium rounded px-2 py-0.5 text-xs focus:outline-none focus:border-blue-500"
            >
              <option value="CURRENT_PARAGRAPH">Current Paragraph</option>
              <option value="CURRENT_SECTION">Current Section</option>
              <option value="CURRENT_SENTENCE">Current Sentence</option>
              <option value="CURRENT_SELECTION">Current Selection</option>
              <option value="ENTIRE_DOCUMENT">Entire Document</option>
            </select>
          </div>

          <div class="flex items-center gap-3">
            <div class="flex items-center gap-1.5 text-zinc-400">
              <span class="w-2 h-2 rounded-full" [class.bg-emerald-400]="isRemoteAi" [class.bg-blue-400]="!isRemoteAi"></span>
              <span class="text-[11px]">{{ isRemoteAi ? 'Gemini 3.8 Intelligence' : 'Local C/Python Rules' }}</span>
            </div>
            <button (click)="close()" class="text-zinc-400 hover:text-white transition cursor-pointer">
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>
        </div>

        <!-- Input Bar -->
        <div class="p-4 flex items-center gap-3 bg-[#0c0c0e]">
          <mat-icon class="text-blue-400 text-xl">auto_fix_high</mat-icon>
          <input
            #commandInput
            type="text"
            [(ngModel)]="promptText"
            (keydown.enter)="submit()"
            (keydown.escape)="close()"
            placeholder="Ask WordCore... (e.g. 'Make this more concise', 'Turn into formal report')"
            class="w-full bg-transparent text-white placeholder-zinc-500 text-sm focus:outline-none"
          />
          <button
            (click)="submit()"
            [disabled]="!promptText.trim() || isProcessing"
            class="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white font-medium text-xs transition flex items-center gap-1 cursor-pointer shrink-0 shadow-sm"
          >
            <mat-icon class="text-sm">{{ isProcessing ? 'sync' : 'arrow_forward' }}</mat-icon>
            {{ isProcessing ? 'Processing...' : 'Run' }}
          </button>
        </div>

        <!-- Quick Presets -->
        <div class="p-3 bg-[#151518] border-t border-white/5 flex flex-col gap-2">
          <span class="text-[10px] font-semibold uppercase tracking-wider text-zinc-400">Quick Prompt Directives</span>
          <div class="flex flex-wrap gap-1.5">
            @for (preset of promptPresets; track preset) {
              <button
                (click)="selectPreset(preset)"
                class="px-2.5 py-1 rounded bg-[#202026] hover:bg-[#2a2a32] border border-white/5 text-zinc-300 hover:text-white text-xs transition cursor-pointer"
              >
                {{ preset }}
              </button>
            }
          </div>
        </div>

        <!-- Helper hint footer -->
        <div class="px-4 py-2 bg-[#09090b] text-[10px] text-zinc-400 flex items-center justify-between border-t border-white/5 font-mono">
          <span>Press ↵ Enter to execute proposal &bull; esc to cancel</span>
          <span class="text-blue-400">Non-destructive proposal & C diff preview</span>
        </div>
      </div>
    </div>
  `,
})
export class AICommandBarComponent {
  @Input() isRemoteAi = true;
  @Input() isProcessing = false;
  @Output() execute = new EventEmitter<{ prompt: string; scope: AIScope }>();
  @Output() dismiss = new EventEmitter<void>();

  selectedScope = signal<AIScope>('CURRENT_PARAGRAPH');
  promptText = '';

  promptPresets = [
    'Make this more concise.',
    'Turn this into a formal report.',
    'Explain this paragraph.',
    'Rewrite this in British English.',
    'Make this suitable for an academic paper.',
    'Find contradictions.',
    'Convert this section into bullet points.',
    'Find unsupported claims.',
  ];

  onBackdropClick(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.close();
    }
  }

  onScopeChange(event: Event) {
    const val = (event.target as HTMLSelectElement).value as AIScope;
    this.selectedScope.set(val);
  }

  selectPreset(preset: string) {
    this.promptText = preset;
    this.submit();
  }

  submit() {
    if (!this.promptText.trim() || this.isProcessing) return;
    this.execute.emit({
      prompt: this.promptText.trim(),
      scope: this.selectedScope(),
    });
  }

  close() {
    this.dismiss.emit();
  }
}
