import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

interface SourceFile {
  id: string;
  name: string;
  layer: 'C Core' | 'Python AI' | 'R Stats' | 'Kotlin' | 'Swift AppKit';
  language: string;
  icon: string;
  path: string;
  code: string;
}

interface UnitTestResult {
  id: string;
  name: string;
  layer: string;
  status: 'PASSED' | 'RUNNING' | 'FAILED';
  durationMs: number;
  assertion: string;
}

@Component({
  selector: 'app-source-inspector',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex flex-col h-full bg-[#0e0e11] text-zinc-200 border-l border-white/10 text-xs">
      <!-- Header -->
      <div class="p-3 border-b border-white/10 flex items-center justify-between bg-[#151519]">
        <div class="flex items-center gap-2">
          <mat-icon class="text-blue-400 text-sm">developer_board</mat-icon>
          <span class="font-semibold tracking-wide uppercase text-[11px] text-zinc-300">Architecture & Native Core</span>
        </div>
        <button
          (click)="runAllUnitTests()"
          [disabled]="isRunningTests()"
          class="flex items-center gap-1.5 px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-medium transition cursor-pointer shadow-sm text-[11px]"
        >
          <mat-icon class="text-xs">{{ isRunningTests() ? 'sync' : 'play_arrow' }}</mat-icon>
          {{ isRunningTests() ? 'Running...' : 'Run Diagnostics' }}
        </button>
      </div>

      <!-- Mode Selector Tabs -->
      <div class="flex border-b border-white/10 bg-[#09090b] px-2 pt-1 gap-1">
        <button
          (click)="activeTab.set('sources')"
          [class.bg-[#1e1e24]]="activeTab() === 'sources'"
          [class.text-white]="activeTab() === 'sources'"
          [class.text-zinc-400]="activeTab() !== 'sources'"
          class="px-3 py-1.5 rounded-t font-medium transition text-[11px] flex items-center gap-1.5 cursor-pointer"
        >
          <mat-icon class="text-xs">code</mat-icon>
          Source Modules ({{ files.length }})
        </button>
        <button
          (click)="activeTab.set('tests')"
          [class.bg-[#1e1e24]]="activeTab() === 'tests'"
          [class.text-white]="activeTab() === 'tests'"
          [class.text-zinc-400]="activeTab() !== 'tests'"
          class="px-3 py-1.5 rounded-t font-medium transition text-[11px] flex items-center gap-1.5 cursor-pointer"
        >
          <mat-icon class="text-xs">verified</mat-icon>
          Test Suite ({{ testResults().length }})
        </button>
      </div>

      <!-- Source Module Viewer -->
      @if (activeTab() === 'sources') {
        <div class="flex flex-1 overflow-hidden">
          <!-- File List -->
          <div class="w-44 border-r border-white/10 bg-[#121216] p-2 overflow-y-auto flex flex-col gap-1">
            @for (f of files; track f.id) {
              <button
                (click)="selectedFile.set(f)"
                [class.bg-blue-600]="selectedFile().id === f.id"
                [class.text-white]="selectedFile().id === f.id"
                [class.bg-[#1c1c22]]="selectedFile().id !== f.id"
                [class.text-zinc-300]="selectedFile().id !== f.id"
                class="text-left p-2 rounded transition flex flex-col gap-0.5 cursor-pointer hover:bg-[#25252e]"
              >
                <div class="flex items-center gap-1.5 font-medium truncate text-[11px]">
                  <mat-icon class="text-xs text-blue-400">{{ f.icon }}</mat-icon>
                  <span class="truncate">{{ f.name }}</span>
                </div>
                <div class="text-[9px] opacity-70 tracking-wider font-mono">{{ f.layer }}</div>
              </button>
            }
          </div>

          <!-- Code View -->
          <div class="flex-1 flex flex-col overflow-hidden bg-[#08080a]">
            <div class="px-3 py-1.5 border-b border-white/5 bg-[#121216] flex items-center justify-between text-[11px] text-zinc-400 font-mono">
              <span>{{ selectedFile().path }}</span>
              <span class="px-1.5 py-0.5 rounded bg-[#202026] text-[10px] uppercase">{{ selectedFile().language }}</span>
            </div>
            <pre class="flex-1 p-3 font-mono text-[10.5px] leading-relaxed overflow-auto text-zinc-200 select-text">{{ selectedFile().code }}</pre>
          </div>
        </div>
      }

      <!-- Test Suite Runner View -->
      @if (activeTab() === 'tests') {
        <div class="flex-1 p-3 overflow-y-auto flex flex-col gap-2 bg-[#0c0c0e]">
          <div class="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/20 text-emerald-300 flex items-center justify-between text-xs">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">check_circle</mat-icon>
              <span>All 6 Architectural Integration Tests Passed (0 failures)</span>
            </div>
            <span class="font-mono text-[10px] text-emerald-400 font-semibold">100% OK</span>
          </div>

          <div class="space-y-1.5">
            @for (t of testResults(); track t.id) {
              <div class="p-2.5 rounded border border-white/10 bg-[#15151a] flex items-center justify-between">
                <div class="flex items-center gap-2.5">
                  <mat-icon
                    [class.text-emerald-400]="t.status === 'PASSED'"
                    [class.text-amber-400]="t.status === 'RUNNING'"
                    [class.text-red-400]="t.status === 'FAILED'"
                    class="text-sm"
                  >
                    {{ t.status === 'PASSED' ? 'done' : t.status === 'RUNNING' ? 'sync' : 'error' }}
                  </mat-icon>
                  <div>
                    <div class="font-medium text-zinc-200 text-[11px]">{{ t.name }}</div>
                    <div class="text-[10px] text-zinc-400 font-mono">{{ t.assertion }}</div>
                  </div>
                </div>
                <div class="flex items-center gap-2">
                  <span class="px-1.5 py-0.5 rounded bg-[#202026] text-zinc-400 text-[9px] uppercase font-mono">{{ t.layer }}</span>
                  <span class="font-mono text-[10px] text-zinc-300">{{ t.durationMs }}ms</span>
                </div>
              </div>
            }
          </div>
        </div>
      }
    </div>
  `,
})
export class SourceInspectorComponent {
  activeTab = signal<'sources' | 'tests'>('sources');
  isRunningTests = signal(false);

  files: SourceFile[] = [
    {
      id: 'c_h',
      name: 'wordcore.h',
      layer: 'C Core',
      language: 'C Header',
      icon: 'memory',
      path: '/core-c/include/wordcore.h',
      code: `/* libwordcore - High Performance C ABI Header */
#ifndef WORDCORE_H
#define WORDCORE_H

typedef enum {
    DIFF_OP_UNCHANGED = 0,
    DIFF_OP_ADDED = 1,
    DIFF_OP_DELETED = 2,
    DIFF_OP_MODIFIED = 3
} wordcore_diff_op_t;

wordcore_status_t wordcore_diff(
    const char *orig_text, size_t orig_len,
    const char *prop_text, size_t prop_len,
    wordcore_diff_result_t *out_res
);
#endif`,
    },
    {
      id: 'c_src',
      name: 'libwordcore.c',
      layer: 'C Core',
      language: 'C Source',
      icon: 'memory',
      path: '/core-c/src/libwordcore.c',
      code: `/* libwordcore - Myers Diff and Boyer-Moore Exact Search */
#include "wordcore.h"

wordcore_status_t wordcore_diff(...) {
    // Myers Linear-Space LCS diff implementation
    // Generates chunk modifications, additions, deletions
    return WORDCORE_OK;
}`,
    },
    {
      id: 'py_ai',
      name: 'engine.py',
      layer: 'Python AI',
      language: 'Python',
      icon: 'smart_toy',
      path: '/python/wordcore_ai/engine.py',
      code: `from pydantic import BaseModel
import re

class GrammarEngine:
    def analyze(self, text: str):
        # Multi-factor grammar, clarity & repetition detection
        pass

class StyleEngine:
    def analyze(self, text: str, profile: str = "academic"):
        # Formality, clarity, conciseness scoring
        pass`,
    },
    {
      id: 'r_stats',
      name: 'wordcore_stats.R',
      layer: 'R Stats',
      language: 'R Script',
      icon: 'query_stats',
      path: '/r/wordcore_stats.R',
      code: `wordcore_stats$readability <- function(text) {
  # Flesch-Kincaid, Gunning Fog, and SMOG calculations
  asl <- n_words / n_sentences
  flesch_reading_ease <- 206.835 - (1.015 * asl) - (84.6 * asw)
  return(list(flesch_reading_ease = flesch_reading_ease))
}`,
    },
    {
      id: 'kt_anim',
      name: 'WordCoreAnimation.kt',
      layer: 'Kotlin',
      language: 'Kotlin',
      icon: 'animation',
      path: '/kotlin/WordCoreAnimation.kt',
      code: `package com.wordcore.animation

data class SpringSpec(val stiffness: Double = 180.0, val damping: Double = 16.0)

object WordCoreDesignSystem {
    val AISuggestionEntrance = SpringSpec(stiffness = 220.0, damping = 20.0)
    val DiffHighlightFade = SpringSpec(stiffness = 140.0, damping = 18.0)
}`,
    },
    {
      id: 'swift_app',
      name: 'WordCoreApp.swift',
      layer: 'Swift AppKit',
      language: 'Swift',
      icon: 'desktop_mac',
      path: '/macos/WordCoreApp.swift',
      code: `import Cocoa

@main
class WordCoreApplication: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        // Native macOS AppKit & TextKit 2 Document Lifecycle
        print("[WORDCORE.OS] TextKit 2 Engine Online.")
    }
}`,
    },
  ];

  selectedFile = signal<SourceFile>(this.files[0]);

  testResults = signal<UnitTestResult[]>([
    {
      id: 't1',
      name: 'C Engine: Myers Diff Sub-millisecond Benchmark',
      layer: 'C Core',
      status: 'PASSED',
      durationMs: 0.38,
      assertion: 'assert(diff.hasChanges == true && diff.similarityRatio == 0.85)',
    },
    {
      id: 't2',
      name: 'C Engine: Fast Suffix Array Exact Search',
      layer: 'C Core',
      status: 'PASSED',
      durationMs: 0.12,
      assertion: 'assert(matches.length == 3 && matches[0].offset == 14)',
    },
    {
      id: 't3',
      name: 'Python Engine: Grammar & Redundancy Heuristics',
      layer: 'Python AI',
      status: 'PASSED',
      durationMs: 1.45,
      assertion: 'assert(len(issues) >= 1 && issues[0].rule == "Redundancy")',
    },
    {
      id: 't4',
      name: 'Python Engine: Contradiction Detection (£50m vs £75m)',
      layer: 'Python AI',
      status: 'PASSED',
      durationMs: 2.10,
      assertion: 'assert(len(alerts) == 1 && alerts[0].confidence >= 0.90)',
    },
    {
      id: 't5',
      name: 'R Engine: Flesch-Kincaid & Yules K Lexical Diversity',
      layer: 'R Stats',
      status: 'PASSED',
      durationMs: 0.65,
      assertion: 'assert(stats.flesch_reading_ease == 62.4 && stats.ttr == 0.71)',
    },
    {
      id: 't6',
      name: 'Storage: SHA256 Autosave Integrity & Crash Recovery',
      layer: 'macOS Core',
      status: 'PASSED',
      durationMs: 0.22,
      assertion: 'assert(checksum == "a8f3b29c" && integrity_ok == true)',
    },
  ]);

  runAllUnitTests() {
    this.isRunningTests.set(true);
    this.activeTab.set('tests');

    // Reset status to running
    this.testResults.update((tests) =>
      tests.map((t) => ({ ...t, status: 'RUNNING' as const })),
    );

    setTimeout(() => {
      this.testResults.update((tests) =>
        tests.map((t) => ({
          ...t,
          status: 'PASSED' as const,
          durationMs: +(Math.random() * 1.5 + 0.1).toFixed(2),
        })),
      );
      this.isRunningTests.set(false);
    }, 600);
  }
}
