import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  HostListener,
  ViewChild,
  computed,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DocumentStore } from './services/document-store';
import { CEngine } from './services/c-engine';
import { PythonAIEngine } from './services/python-ai';
import { RStatsEngine } from './services/r-stats';
import { DocumentConverter } from './services/document-converter';
import { AICommandBarComponent } from './components/ai-command-bar/ai-command-bar';
import { DiffModalComponent } from './components/diff-modal/diff-modal';
import { SourceInspectorComponent } from './components/source-inspector/source-inspector';
import {
  AIProposal,
  AIScope,
  ContradictionAlert,
  ExactSearchMatch,
  GrammarIssue,
  OutlineItem,
  RLexicalStats,
  RReadabilityReport,
  RWordFrequencyItem,
  RWritingTimelinePoint,
  SemanticSearchResult,
  StyleAnalysis,
  StyleProfile,
  TableCell,
  WordCoreCitation,
  WordCoreDocument,
  WordCoreSection,
} from './models/wordcore.types';

export type SidebarTab =
  | 'outline'
  | 'search'
  | 'ai'
  | 'contradictions'
  | 'graph'
  | 'citations'
  | 'analytics'
  | 'versions'
  | 'architecture';

export type ViewMode = 'page' | 'continuous' | 'focus';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,
    AICommandBarComponent,
    DiffModalComponent,
    SourceInspectorComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  docStore = inject(DocumentStore);
  cEngine = inject(CEngine);
  aiEngine = inject(PythonAIEngine);
  rStats = inject(RStatsEngine);
  converter = inject(DocumentConverter);

  @ViewChild('fileInput') fileInputRef!: ElementRef<HTMLInputElement>;
  @ViewChild('documentCanvas') documentCanvasRef!: ElementRef<HTMLDivElement>;

  // UI state
  activeSidebarTab = signal<SidebarTab | null>('outline');
  viewMode = signal<ViewMode>('page');
  zoomLevel = signal<number>(100);
  activeMenu = signal<string | null>(null);

  // Command bar & proposal state
  isCommandBarOpen = signal(false);
  isProcessingAI = signal(false);
  activeProposal = signal<AIProposal | null>(null);
  exportModalOpen = signal(false);
  privacyModalOpen = signal(false);

  // Selection & Inline floating AI toolbar
  floatingToolbar = signal<{ visible: boolean; top: number; left: number; text: string; sectionId: string } | null>(null);

  // Exact & Semantic Search State
  exactSearchQuery = signal('');
  exactMatches = signal<ExactSearchMatch[]>([]);
  isCaseSensitive = signal(false);
  useRegex = signal(false);
  semanticSearchQuery = signal('');
  semanticMatches = signal<SemanticSearchResult[]>([]);
  isSearchingSemantic = signal(false);

  // Live Analysis Results
  grammarIssues = signal<GrammarIssue[]>([]);
  styleProfile = signal<StyleProfile>('academic');
  styleAnalysis = signal<StyleAnalysis | null>(null);
  contradictionAlerts = signal<ContradictionAlert[]>([]);
  outlineItems = signal<OutlineItem[]>([]);
  readabilityReport = signal<RReadabilityReport | null>(null);
  lexicalStats = signal<RLexicalStats | null>(null);
  wordFrequencies = signal<RWordFrequencyItem[]>([]);
  writingTimeline = signal<RWritingTimelinePoint[]>([]);

  // Citation form state
  isAddingCitation = signal(false);
  newCitation = signal<Omit<WordCoreCitation, 'id'>>({
    key: '',
    title: '',
    authors: [''],
    year: new Date().getFullYear(),
    journalOrPublisher: '',
    style: 'APA',
  });

  // Current active document computed shortcuts
  currentDoc = computed(() => this.docStore.activeDocument());
  stats = computed(() => this.docStore.documentStats());

  readonly Math = Math;

  constructor() {
    this.refreshAllAnalytics();
  }

  // Keyboard shortcut handler
  @HostListener('window:keydown', ['$event'])
  handleKeyboardShortcuts(event: KeyboardEvent) {
    const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
    const modifier = isMac ? event.metaKey : event.ctrlKey;

    if (modifier && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.isCommandBarOpen.set(!this.isCommandBarOpen());
    } else if (modifier && event.key.toLowerCase() === 'n') {
      event.preventDefault();
      this.docStore.createNewDocument();
    } else if (modifier && event.altKey && event.key.toLowerCase() === 's') {
      event.preventDefault();
      this.toggleSidebar('outline');
    } else if (modifier && !event.altKey && event.key.toLowerCase() === 's') {
      event.preventDefault();
      this.docStore.createVersionSnapshot('Manual Checkpoint');
      this.refreshAllAnalytics();
    } else if (modifier && event.key.toLowerCase() === 'f') {
      event.preventDefault();
      this.activeSidebarTab.set('search');
    } else if (modifier && !event.shiftKey && event.key.toLowerCase() === 'z') {
      event.preventDefault();
      this.docStore.undo();
      this.refreshAllAnalytics();
    } else if (modifier && (event.key.toLowerCase() === 'y' || (event.key.toLowerCase() === 'z' && event.shiftKey))) {
      event.preventDefault();
      this.docStore.redo();
      this.refreshAllAnalytics();
    } else if (modifier && event.key.toLowerCase() === 'p') {
      event.preventDefault();
      this.printDocument();
    } else if (event.key === 'Escape') {
      this.activeMenu.set(null);
      this.floatingToolbar.set(null);
      this.isCommandBarOpen.set(false);
    }
  }

  // Document Menu toggle
  toggleMenu(menuName: string, event: MouseEvent) {
    event.stopPropagation();
    this.activeMenu.update((m) => (m === menuName ? null : menuName));
  }

  closeMenu() {
    this.activeMenu.set(null);
  }

  // Sidebar controls
  toggleSidebar(tab: SidebarTab) {
    this.activeSidebarTab.update((current) => (current === tab ? null : tab));
  }

  // Text formatting
  setFontFamily(family: WordCoreDocument['metadata']['fontFamily']) {
    this.docStore.updateMetadata({ fontFamily: family });
  }

  setFontSize(size: number) {
    this.docStore.updateMetadata({ fontSize: size });
  }

  setLineSpacing(spacing: number) {
    this.docStore.updateMetadata({ lineSpacing: spacing });
  }

  // Text selection tracking for inline floating toolbar
  onTextSelection(sectionId: string) {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) {
      this.floatingToolbar.set(null);
      return;
    }

    const selectedText = selection.toString().trim();
    if (selectedText.length > 2) {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      this.floatingToolbar.set({
        visible: true,
        top: Math.max(10, rect.top - 48),
        left: Math.max(10, rect.left + rect.width / 2 - 160),
        text: selectedText,
        sectionId,
      });
    } else {
      this.floatingToolbar.set(null);
    }
  }

  private aiAnalysisTimeout: ReturnType<typeof setTimeout> | null = null;

  // Section content updating
  onSectionContentChange(section: WordCoreSection, newContent: string) {
    this.docStore.updateSection(section.id, { content: newContent });
    this.refreshFastStats();
    this.scheduleDeepAiAnalysis();
  }

  // Fast statistics calculated immediately on keystroke
  refreshFastStats() {
    const doc = this.currentDoc();
    const fullText = this.rStats.extractDocumentText(doc);

    this.readabilityReport.set(this.rStats.computeReadability(fullText));
    this.lexicalStats.set(this.rStats.computeLexicalStats(fullText));
    this.wordFrequencies.set(this.rStats.computeWordFrequency(fullText, 12));
    this.writingTimeline.set(this.rStats.generateWritingTimeline(doc));

    this.aiEngine.inferOutline(doc).then((outline) => {
      this.outlineItems.set(outline);
    });
  }

  // Debounced deep AI processing for grammar, style, and contradictions
  scheduleDeepAiAnalysis(delay = 1000) {
    if (this.aiAnalysisTimeout) {
      clearTimeout(this.aiAnalysisTimeout);
    }
    this.aiAnalysisTimeout = setTimeout(() => {
      this.runDeepAiAnalysis();
    }, delay);
  }

  async runDeepAiAnalysis() {
    const doc = this.currentDoc();
    try {
      const [grammar, contra, style] = await Promise.all([
        this.aiEngine.analyzeGrammar(doc),
        this.aiEngine.detectContradictions(doc),
        this.aiEngine.analyzeStyle(doc, this.styleProfile()),
      ]);
      this.grammarIssues.set(grammar);
      this.contradictionAlerts.set(contra);
      this.styleAnalysis.set(style);
    } catch {
      // Handled gracefully in engine
    }
  }

  // Refresh all statistical and AI analytics on demand
  async refreshAllAnalytics() {
    this.refreshFastStats();
    await this.runDeepAiAnalysis();
  }

  // List item actions
  addListItem(section: WordCoreSection) {
    const items = [...(section.listItems || [])];
    items.push({ id: 'li_' + Math.random().toString(36).substr(2, 6), text: '' });
    this.docStore.updateSection(section.id, { listItems: items });
  }

  updateListItem(section: WordCoreSection, index: number, text: string) {
    const items = [...(section.listItems || [])];
    items[index] = { ...items[index], text };
    this.docStore.updateSection(section.id, { listItems: items });
  }

  toggleListItemCheck(section: WordCoreSection, index: number) {
    const items = [...(section.listItems || [])];
    items[index] = { ...items[index], checked: !items[index].checked };
    this.docStore.updateSection(section.id, { listItems: items });
  }

  deleteListItem(section: WordCoreSection, index: number) {
    const items = section.listItems?.filter((_, idx) => idx !== index) || [];
    this.docStore.updateSection(section.id, { listItems: items });
  }

  // Table actions
  addTableRow(section: WordCoreSection) {
    if (!section.tableData) return;
    const colCount = section.tableData.headers.length;
    const newRow: TableCell[] = Array.from({ length: colCount }, () => ({
      id: `c_${Math.random().toString(36).substr(2, 6)}`,
      content: '',
    }));

    const updated = {
      ...section.tableData,
      rows: [...section.tableData.rows, newRow],
    };
    this.docStore.updateSection(section.id, { tableData: updated });
  }

  addTableColumn(section: WordCoreSection) {
    if (!section.tableData) return;
    const newHeader: TableCell = {
      id: `h_${Math.random().toString(36).substr(2, 6)}`,
      content: `Col ${section.tableData.headers.length + 1}`,
      bold: true,
    };
    const updated = {
      ...section.tableData,
      headers: [...section.tableData.headers, newHeader],
      rows: section.tableData.rows.map((row) => [
        ...row,
        { id: `c_${Math.random().toString(36).substr(2, 6)}`, content: '' },
      ]),
    };
    this.docStore.updateSection(section.id, { tableData: updated });
  }

  updateTableCell(section: WordCoreSection, rowIndex: number, colIndex: number, content: string, isHeader = false) {
    if (!section.tableData) return;
    if (isHeader) {
      const headers = [...section.tableData.headers];
      headers[colIndex] = { ...headers[colIndex], content };
      this.docStore.updateSection(section.id, {
        tableData: { ...section.tableData, headers },
      });
    } else {
      const rows = section.tableData.rows.map((r, rIdx) => {
        if (rIdx !== rowIndex) return r;
        const newRow = [...r];
        newRow[colIndex] = { ...newRow[colIndex], content };
        return newRow;
      });
      this.docStore.updateSection(section.id, {
        tableData: { ...section.tableData, rows },
      });
    }
  }

  // AI Execution pipeline
  async triggerAICommand(prompt: string, scope: AIScope, targetSectionId?: string, selectedText?: string) {
    this.isProcessingAI.set(true);
    const doc = this.currentDoc();
    const targetSection = targetSectionId
      ? doc.sections.find((s) => s.id === targetSectionId)
      : doc.sections[0];

    try {
      const proposal = await this.aiEngine.executeCommand(
        prompt,
        scope,
        doc,
        targetSection,
        selectedText,
      );
      this.activeProposal.set(proposal);
      this.isCommandBarOpen.set(false);
      this.floatingToolbar.set(null);
    } catch (err) {
      console.error('AI command error:', err);
    } finally {
      this.isProcessingAI.set(false);
    }
  }

  onProposalAccepted(proposal: AIProposal) {
    if (proposal.targetSectionId) {
      this.docStore.updateSection(proposal.targetSectionId, {
        content: proposal.proposedText,
      });
    } else {
      // If full document rewrite, replace first paragraph or update
      if (this.currentDoc().sections.length > 0) {
        this.docStore.updateSection(this.currentDoc().sections[0].id, {
          content: proposal.proposedText,
        });
      }
    }
    this.activeProposal.set(null);
    this.refreshAllAnalytics();
  }

  onProposalRejected() {
    this.activeProposal.set(null);
  }

  // Exact Search via C Engine
  runExactSearch() {
    const q = this.exactSearchQuery();
    if (!q.trim()) {
      this.exactMatches.set([]);
      return;
    }
    const matches = this.cEngine.exactSearch(
      this.currentDoc().sections,
      q,
      this.isCaseSensitive(),
      this.useRegex(),
    );
    this.exactMatches.set(matches);
  }

  // Semantic Search via Python AI Engine
  async runSemanticSearch() {
    const q = this.semanticSearchQuery();
    if (!q.trim()) {
      this.semanticMatches.set([]);
      return;
    }
    this.isSearchingSemantic.set(true);
    try {
      const results = await this.aiEngine.semanticSearch(this.currentDoc(), q);
      this.semanticMatches.set(results);
    } finally {
      this.isSearchingSemantic.set(false);
    }
  }

  // Jump to specific section
  scrollToSection(sectionId: string) {
    this.docStore.selectedSectionId.set(sectionId);
    const el = document.getElementById(`section-${sectionId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('ring-2', 'ring-blue-500/80', 'transition-all');
      setTimeout(() => el.classList.remove('ring-2', 'ring-blue-500/80'), 1500);
    }
  }

  // Citation management
  saveCitation() {
    const c = this.newCitation();
    if (!c.title || !c.key) return;
    this.docStore.addCitation(c);
    this.isAddingCitation.set(false);
    this.newCitation.set({
      key: '',
      title: '',
      authors: [''],
      year: new Date().getFullYear(),
      journalOrPublisher: '',
      style: 'APA',
    });
  }

  // File Import / Export
  exportDocument(format: 'wordcore' | 'markdown' | 'html' | 'rtf' | 'txt' | 'print') {
    const doc = this.currentDoc();
    let content = '';
    let mimeType = 'text/plain';
    let filename = `${doc.metadata.title.toLowerCase().replace(/\s+/g, '_')}`;

    if (format === 'wordcore') {
      content = JSON.stringify(doc, null, 2);
      mimeType = 'application/json';
      filename += '.wordcore';
    } else if (format === 'markdown') {
      content = this.converter.exportToMarkdown(doc);
      mimeType = 'text/markdown';
      filename += '.md';
    } else if (format === 'html') {
      content = this.converter.exportToHtml(doc);
      mimeType = 'text/html';
      filename += '.html';
    } else if (format === 'rtf') {
      content = this.converter.exportToRtf(doc);
      mimeType = 'application/rtf';
      filename += '.rtf';
    } else if (format === 'txt') {
      content = this.rStats.extractDocumentText(doc);
      mimeType = 'text/plain';
      filename += '.txt';
    } else if (format === 'print') {
      this.printDocument();
      return;
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
    this.exportModalOpen.set(false);
  }

  triggerFileInput() {
    this.fileInputRef.nativeElement.click();
  }

  onFileSelected(event: Event) {
    const target = event.target as HTMLInputElement;
    const file = target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      if (file.name.endsWith('.wordcore') || file.name.endsWith('.json')) {
        try {
          const parsed = JSON.parse(text);
          if (parsed.format === 'wordcore' && parsed.sections) {
            this.docStore.openDocuments.update((docs) => [...docs, parsed]);
            this.docStore.activeDocumentId.set(parsed.metadata.id);
            this.refreshAllAnalytics();
          }
        } catch {
          console.error('Invalid .wordcore JSON file');
        }
      } else {
        // Markdown or Text import
        const importedDoc = this.converter.importFromMarkdown(text, file.name.replace(/\.[^/.]+$/, ''));
        this.docStore.openDocuments.update((docs) => [...docs, importedDoc]);
        this.docStore.activeDocumentId.set(importedDoc.metadata.id);
        this.refreshAllAnalytics();
      }
    };
    reader.readAsText(file);
    target.value = '';
  }

  printDocument() {
    window.print();
  }

  // Zoom controls
  adjustZoom(delta: number) {
    this.zoomLevel.update((z) => Math.max(50, Math.min(200, z + delta)));
  }
}
