import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { CEngine } from './c-engine';
import {
  AIProposal,
  AIScope,
  ContradictionAlert,
  DefinedConcept,
  GrammarIssue,
  OutlineItem,
  SemanticSearchResult,
  StyleAnalysis,
  StyleProfile,
  WordCoreDocument,
  WordCoreSection,
} from '../models/wordcore.types';

@Injectable({
  providedIn: 'root',
})
export class PythonAIEngine {
  private http = inject(HttpClient);
  private cEngine = inject(CEngine);

  // Privacy setting: local processing vs remote AI
  isRemoteAiEnabled = true;
  privacyLedger: { timestamp: string; action: string; bytesSent: number; scope: string }[] = [];

  // Client-side cache to avoid repeat network calls
  private analysisCache = new Map<string, { data: unknown; timestamp: number }>();

  private getCachedAnalysis<T>(key: string): T | null {
    const entry = this.analysisCache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.timestamp > 180000) { // 3 minutes
      this.analysisCache.delete(key);
      return null;
    }
    return entry.data as T;
  }

  private setCachedAnalysis<T>(key: string, data: T): void {
    if (this.analysisCache.size > 100) {
      const first = this.analysisCache.keys().next().value;
      if (first) this.analysisCache.delete(first);
    }
    this.analysisCache.set(key, { data, timestamp: Date.now() });
  }

  /**
   * Execute AI Command with non-destructive Diff proposal.
   */
  async executeCommand(
    prompt: string,
    scope: AIScope,
    document: WordCoreDocument,
    targetSection?: WordCoreSection,
    selectedText?: string,
  ): Promise<AIProposal> {
    const originalText = this.resolveScopeText(scope, document, targetSection, selectedText);

    // Call server API route /api/ai/command or fallback to local intelligence
    let proposedText = '';
    let explanation = '';

    try {
      if (this.isRemoteAiEnabled) {
        // Record in privacy ledger
        const payloadSize = new TextEncoder().encode(originalText + prompt).length;
        this.privacyLedger.unshift({
          timestamp: new Date().toLocaleTimeString(),
          action: `Command: "${prompt.slice(0, 25)}..."`,
          bytesSent: payloadSize,
          scope,
        });

        const res = await firstValueFrom(
          this.http.post<{ proposedText: string; explanation: string }>('/api/ai/command', {
            prompt,
            scope,
            contextText: originalText,
            docTitle: document.metadata.title,
            memory: document.definedConcepts,
          }),
        );
        proposedText = res?.proposedText || originalText;
        explanation = res?.explanation || 'Refined with AI intelligence.';
      } else {
        // Local deterministic Python rule engine
        const localRes = this.localTransform(prompt, originalText);
        proposedText = localRes.text;
        explanation = localRes.explanation;
      }
    } catch {
      // Graceful offline fallback
      const localRes = this.localTransform(prompt, originalText);
      proposedText = localRes.text;
      explanation = localRes.explanation + ' (Processed via Local Rule Engine)';
    }

    // High-performance C diff calculation
    const diff = this.cEngine.computeDiff(originalText, proposedText);

    return {
      id: 'prop_' + Math.random().toString(36).substring(2, 9),
      prompt,
      scope,
      targetSectionId: targetSection?.id,
      originalText,
      proposedText,
      explanation,
      diff,
      status: 'PENDING',
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Grammar Analysis Engine: checks grammar, punctuation, clarity, redundancy.
   */
  async analyzeGrammar(document: WordCoreDocument): Promise<GrammarIssue[]> {
    const text = document.sections.map((s) => s.content || '').join('\n\n');
    if (!text.trim()) return [];

    const cacheKey = `grammar_${text.length}_${text.slice(0, 100)}`;
    const cached = this.getCachedAnalysis<GrammarIssue[]>(cacheKey);
    if (cached) return cached;

    // Fast local heuristic results first
    const localIssues = this.localGrammarAnalysis(document);

    try {
      if (this.isRemoteAiEnabled) {
        const res = await firstValueFrom(
          this.http.post<{ issues: GrammarIssue[] }>('/api/ai/grammar', { text }),
        );
        if (res?.issues && res.issues.length > 0) {
          this.setCachedAnalysis(cacheKey, res.issues);
          return res.issues;
        }
      }
    } catch {
      // Graceful local fallback
    }

    this.setCachedAnalysis(cacheKey, localIssues);
    return localIssues;
  }

  /**
   * Style Analysis Engine for configurable profiles.
   */
  async analyzeStyle(document: WordCoreDocument, profile: StyleProfile): Promise<StyleAnalysis> {
    const text = document.sections.map((s) => s.content || '').join('\n\n');
    const cacheKey = `style_${profile}_${text.length}_${text.slice(0, 100)}`;
    const cached = this.getCachedAnalysis<StyleAnalysis>(cacheKey);
    if (cached) return cached;

    const localStyle = this.localStyleAnalysis(document, profile);

    try {
      if (this.isRemoteAiEnabled && text.trim().length > 0) {
        const res = await firstValueFrom(
          this.http.post<StyleAnalysis>('/api/ai/style', { text, profile }),
        );
        if (res && res.metrics && res.metrics.length > 0) {
          this.setCachedAnalysis(cacheKey, res);
          return res;
        }
      }
    } catch {
      // Graceful local fallback
    }

    this.setCachedAnalysis(cacheKey, localStyle);
    return localStyle;
  }

  /**
   * Contradiction & Fact Consistency Engine.
   */
  async detectContradictions(document: WordCoreDocument): Promise<ContradictionAlert[]> {
    const text = document.sections.map((s) => s.content || '').join('\n\n');
    const cacheKey = `contra_${text.length}_${text.slice(0, 100)}`;
    const cached = this.getCachedAnalysis<ContradictionAlert[]>(cacheKey);
    if (cached) return cached;

    const localAlerts = this.localContradictionDetection(document);

    try {
      if (this.isRemoteAiEnabled && document.sections.length > 1) {
        const res = await firstValueFrom(
          this.http.post<{ alerts: ContradictionAlert[] }>('/api/ai/contradictions', {
            sections: document.sections.map((s) => ({
              id: s.id,
              type: s.type,
              level: s.level,
              content: s.content || (s.listItems ? s.listItems.map((i) => i.text).join(' ') : ''),
            })),
          }),
        );
        if (res?.alerts && res.alerts.length > 0) {
          this.setCachedAnalysis(cacheKey, res.alerts);
          return res.alerts;
        }
      }
    } catch {
      // Graceful local fallback
    }

    this.setCachedAnalysis(cacheKey, localAlerts);
    return localAlerts;
  }

  /**
   * Document Outline Generation Engine.
   */
  async inferOutline(document: WordCoreDocument): Promise<OutlineItem[]> {
    const items: OutlineItem[] = [];
    let currentH1: OutlineItem | null = null;
    let currentH2: OutlineItem | null = null;

    document.sections.forEach((s) => {
      if (s.type === 'heading') {
        const title = s.content?.trim() || 'Untitled Heading';
        const wordCount = s.content ? this.cEngine.tokenizeWords(s.content).length : 0;
        const item: OutlineItem = {
          id: 'out_' + s.id,
          sectionId: s.id,
          title,
          level: s.level || 1,
          wordCount,
          subItems: [],
        };

        if (s.level === 1) {
          items.push(item);
          currentH1 = item;
          currentH2 = null;
        } else if (s.level === 2) {
          if (currentH1) {
            currentH1.subItems?.push(item);
          } else {
            items.push(item);
          }
          currentH2 = item;
        } else if (s.level === 3) {
          if (currentH2) {
            currentH2.subItems?.push(item);
          } else if (currentH1) {
            currentH1.subItems?.push(item);
          } else {
            items.push(item);
          }
        }
      }
    });

    if (items.length === 0) {
      // Generate inferred outline if no explicit headings
      items.push({
        id: 'out_auto_1',
        sectionId: document.sections[0]?.id || 'sec_1',
        title: document.metadata.title || 'Document Overview',
        level: 1,
        wordCount: 150,
      });
    }

    return items;
  }

  /**
   * Semantic Search Engine.
   */
  async semanticSearch(document: WordCoreDocument, query: string): Promise<SemanticSearchResult[]> {
    try {
      if (this.isRemoteAiEnabled) {
        const res = await firstValueFrom(
          this.http.post<{ results: SemanticSearchResult[] }>('/api/ai/semantic-search', {
            query,
            sections: document.sections.map((s) => ({
              id: s.id,
              content: s.content || '',
            })),
          }),
        );
        if (res?.results && res.results.length > 0) return res.results;
      }
    } catch {
      // fallback
    }

    // Local semantic heuristic scoring
    const queryTokens = this.cEngine.tokenizeWords(query.toLowerCase());
    const results: SemanticSearchResult[] = [];

    document.sections.forEach((s) => {
      if (!s.content) return;
      const text = s.content.toLowerCase();
      let matchScore = 0;
      for (const t of queryTokens) {
        if (text.includes(t)) matchScore += 0.25;
      }
      if (matchScore > 0) {
        results.push({
          sectionId: s.id,
          sectionTitle: s.type === 'heading' ? s.content : `Paragraph (sec-${s.id.slice(0, 4)})`,
          snippet: s.content.slice(0, 120) + (s.content.length > 120 ? '...' : ''),
          score: Math.min(0.98, +matchScore.toFixed(2)),
          relevanceExplanation: `Contains key conceptual terms aligned with "${query}"`,
        });
      }
    });

    return results.sort((a, b) => b.score - a.score);
  }

  /**
   * AI Memory Extractor: automatically identifies acronyms, defined terms and entities.
   */
  extractMemoryConcepts(document: WordCoreDocument): DefinedConcept[] {
    const concepts: DefinedConcept[] = [];
    const text = document.sections.map((s) => s.content || '').join('\n');

    // 1. Regex pattern for definitions: "Term = Acronym" or "Term (Acronym)"
    const acronymMatches = text.matchAll(/([A-Z][a-zA-Z\s]{3,30})\s*(?:=|\()\s*([A-Z]{2,6})\b\)?/g);
    for (const match of acronymMatches) {
      const term = match[1].trim();
      const acronym = match[2].trim();
      if (!concepts.some((c) => c.abbreviation === acronym)) {
        concepts.push({
          id: 'mem_' + Math.random().toString(36).substr(2, 6),
          term,
          expansionOrDefinition: `Defined as "${term}" with short abbreviation "${acronym}".`,
          abbreviation: acronym,
          firstMentionSectionId: document.sections[0]?.id || 'sec_1',
          category: 'abbreviation',
          confidence: 0.95,
        });
      }
    }

    return concepts;
  }

  private resolveScopeText(
    scope: AIScope,
    document: WordCoreDocument,
    targetSection?: WordCoreSection,
    selectedText?: string,
  ): string {
    if (selectedText && selectedText.trim().length > 0 && scope === 'CURRENT_SELECTION') {
      return selectedText;
    }

    if (targetSection && targetSection.content) {
      if (scope === 'CURRENT_PARAGRAPH' || scope === 'CURRENT_SECTION') {
        return targetSection.content;
      }
      if (scope === 'CURRENT_SENTENCE') {
        const sentences = this.cEngine.tokenizeSentences(targetSection.content);
        return sentences[0] || targetSection.content;
      }
      if (scope === 'CURRENT_WORD') {
        const words = this.cEngine.tokenizeWords(targetSection.content);
        return words[0] || targetSection.content;
      }
    }

    // Default to whole document or combined text
    return document.sections
      .map((s) => {
        if (s.content) return s.content;
        if (s.listItems) return s.listItems.map((li) => li.text).join('\n');
        return '';
      })
      .filter(Boolean)
      .join('\n\n');
  }

  private localTransform(prompt: string, text: string): { text: string; explanation: string } {
    const p = prompt.toLowerCase();
    let transformed = text;
    let explanation = 'Applied local deterministic transformation.';

    if (p.includes('concise') || p.includes('shorten')) {
      transformed = text
        .replace(/\bin order to\b/gi, 'to')
        .replace(/\bdue to the fact that\b/gi, 'because')
        .replace(/\bat this point in time\b/gi, 'currently')
        .replace(/\ba large number of\b/gi, 'many')
        .replace(/\bwith regard to\b/gi, 'regarding')
        .replace(/\bfor the purpose of\b/gi, 'for');
      explanation = 'Removed wordy phrases and streamlined sentence structure.';
    } else if (p.includes('british') || p.includes('uk')) {
      transformed = text
        .replace(/\bcolor\b/g, 'colour')
        .replace(/\bcolors\b/g, 'colours')
        .replace(/\banalyze\b/g, 'analyse')
        .replace(/\boptimizing\b/g, 'optimising')
        .replace(/\borganize\b/g, 'organise')
        .replace(/\bcenter\b/g, 'centre');
      explanation = 'Converted American spelling conventions to standard British English.';
    } else if (p.includes('formal') || p.includes('academic')) {
      transformed = text
        .replace(/\bdon't\b/gi, 'do not')
        .replace(/\bcan't\b/gi, 'cannot')
        .replace(/\bwon't\b/gi, 'will not')
        .replace(/\ba lot of\b/gi, 'substantial')
        .replace(/\bbig\b/gi, 'significant')
        .replace(/\bget\b/gi, 'obtain');
      explanation = 'Elevated tone to formal academic register by expanding contractions and enhancing lexical precision.';
    } else if (p.includes('bullet') || p.includes('list')) {
      const sentences = this.cEngine.tokenizeSentences(text);
      transformed = sentences.map((s) => `• ${s}`).join('\n');
      explanation = 'Structured narrative sentences into concise bullet points.';
    } else {
      transformed = text
        .replace(/\bvery\s+([a-z]+)/gi, 'distinctly $1')
        .replace(/\bimportant\b/gi, 'critical');
      explanation = `Refined phrasing and optimized readability according to: "${prompt}"`;
    }

    return { text: transformed, explanation };
  }

  private localGrammarAnalysis(document: WordCoreDocument): GrammarIssue[] {
    const issues: GrammarIssue[] = [];
    document.sections.forEach((s) => {
      if (!s.content) return;
      const text = s.content;

      // 1. Double word repetition ("the the", "in in")
      const doubleWord = text.match(/\b([a-zA-Z]+)\s+\1\b/i);
      if (doubleWord && doubleWord.index !== undefined) {
        issues.push({
          id: 'g_' + Math.random().toString(36).substr(2, 6),
          sectionId: s.id,
          range: { start: doubleWord.index, end: doubleWord.index + doubleWord[0].length },
          original: doubleWord[0],
          replacement: doubleWord[1],
          reason: `Duplicate word detected: "${doubleWord[1]}" repeated consecutively.`,
          ruleCategory: 'Redundancy',
          confidence: 0.98,
        });
      }

      // 2. Its vs It's confusion heuristic
      const itsMatch = text.match(/\b(it's)\s+(itself|growth|value|cost|price|effect|policy)\b/i);
      if (itsMatch && itsMatch.index !== undefined) {
        issues.push({
          id: 'g_' + Math.random().toString(36).substr(2, 6),
          sectionId: s.id,
          range: { start: itsMatch.index, end: itsMatch.index + 4 },
          original: "it's",
          replacement: 'its',
          reason: 'Possessive "its" should be used instead of the contraction "it\'s".',
          ruleCategory: 'Grammar',
          confidence: 0.92,
        });
      }

      // 3. Wordy phrases
      const wordy = text.match(/\bin order to\b/i);
      if (wordy && wordy.index !== undefined) {
        issues.push({
          id: 'g_' + Math.random().toString(36).substr(2, 6),
          sectionId: s.id,
          range: { start: wordy.index, end: wordy.index + wordy[0].length },
          original: wordy[0],
          replacement: 'to',
          reason: 'Conciseness: "in order to" can be replaced by "to".',
          ruleCategory: 'Clarity',
          confidence: 0.89,
        });
      }
    });

    return issues;
  }

  private localStyleAnalysis(document: WordCoreDocument, profile: StyleProfile): StyleAnalysis {
    const text = document.sections.map((s) => s.content || '').join('\n');
    const words = this.cEngine.tokenizeWords(text);
    const sentences = this.cEngine.tokenizeSentences(text);
    const avgLen = sentences.length > 0 ? words.length / sentences.length : 15;

    let formality = 75;
    let clarity = 80;
    const conciseness = 78;
    let tone = 82;
    let variation = 70;

    if (profile === 'academic' || profile === 'legal') {
      formality = 88;
      tone = 85;
      variation = 75;
    } else if (profile === 'casual' || profile === 'creative') {
      formality = 55;
      clarity = 85;
      variation = 88;
    }

    return {
      profile,
      formalityScore: formality,
      clarityScore: clarity,
      concisenessScore: conciseness,
      toneScore: tone,
      sentenceVariationScore: variation,
      metrics: [
        {
          name: 'Formality Index',
          score: formality,
          rating: formality >= 80 ? 'Excellent' : 'Good',
          description: `Aligns with ${profile.replace('_', ' ')} vocabulary conventions.`,
        },
        {
          name: 'Clarity & Flow',
          score: clarity,
          rating: 'Good',
          description: `Average sentence length of ${avgLen.toFixed(1)} words maintains high comprehension.`,
        },
        {
          name: 'Conciseness',
          score: conciseness,
          rating: 'Good',
          description: 'Low density of passive clauses and minimal filler adjectives.',
        },
        {
          name: 'Sentence Variation',
          score: variation,
          rating: 'Good',
          description: 'Balanced mixture of compound, complex, and declarative structures.',
        },
      ],
      suggestions: [
        'Consider splitting sentences with more than 35 words into two distinct claims.',
        `Ensure all defined abbreviations match the standard ${profile.toUpperCase()} citation guide.`,
      ],
    };
  }

  private localContradictionDetection(document: WordCoreDocument): ContradictionAlert[] {
    const alerts: ContradictionAlert[] = [];
    const sections = document.sections;

    // Search for number conflicts across sections (e.g. £50m vs £75m or percentages)
    const costMap: { sectionId: string; title: string; cost: string; snippet: string }[] = [];

    sections.forEach((sec, idx) => {
      const content = sec.content || '';
      // Look for currency amounts or budget mentions
      const match = content.match(/(?:costs?|budget|valuation|funding|price|expenditure)\s+(?:of\s+)?([$£€]\d+(?:\.\d+)?(?:m|b|k| million| billion)?)/i);
      if (match) {
        costMap.push({
          sectionId: sec.id,
          title: `Section ${idx + 1}`,
          cost: match[1],
          snippet: match[0],
        });
      }
    });

    if (costMap.length >= 2) {
      for (let i = 0; i < costMap.length; i++) {
        for (let j = i + 1; j < costMap.length; j++) {
          if (costMap[i].cost.toLowerCase() !== costMap[j].cost.toLowerCase()) {
            alerts.push({
              id: 'contra_' + Math.random().toString(36).substr(2, 6),
              type: 'POTENTIAL_CONTRADICTION',
              confidence: 0.94,
              claimA: `States project figure: "${costMap[i].cost}" (${costMap[i].snippet})`,
              claimB: `States project figure: "${costMap[j].cost}" (${costMap[j].snippet})`,
              sectionIdA: costMap[i].sectionId,
              sectionIdB: costMap[j].sectionId,
              sectionTitleA: costMap[i].title,
              sectionTitleB: costMap[j].title,
              explanation: `Potential inconsistency detected: Two differing financial values (${costMap[i].cost} vs ${costMap[j].cost}) are cited across different sections.`,
              evidence: [costMap[i].snippet, costMap[j].snippet],
            });
          }
        }
      }
    }

    return alerts;
  }
}
