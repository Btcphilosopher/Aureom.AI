import { Injectable, computed, inject, signal } from '@angular/core';
import { CEngine } from './c-engine';
import {
  DocumentStatsSummary,
  WordCoreCitation,
  WordCoreDocument,
  WordCoreSection,
  WordCoreVersion,
} from '../models/wordcore.types';

const INITIAL_SAMPLE_DOCS: WordCoreDocument[] = [
  {
    format: 'wordcore',
    version: 1,
    metadata: {
      id: 'doc_macro_econ',
      title: 'Global Macroeconomic Policy & Monetary Dynamics',
      subtitle: 'An Empirical Assessment of Central Bank Forward Guidance and Sovereign Debt Spreads',
      author: 'Dr. Alistair Finch & WordCore Intelligence Lab',
      createdAt: '2026-03-01T09:00:00Z',
      updatedAt: '2026-09-07T08:15:00Z',
      language: 'en-US',
      tags: ['economics', 'monetary-policy', 'macro', 'sovereign-debt'],
      pageFormat: 'US-Letter',
      marginsInch: { top: 1.0, right: 1.0, bottom: 1.0, left: 1.0 },
      lineSpacing: 1.25,
      fontFamily: 'Newsreader',
      fontSize: 12,
    },
    sections: [
      {
        id: 'sec_1',
        type: 'heading',
        level: 1,
        content: '1. Executive Summary and Theoretical Framework',
      },
      {
        id: 'sec_2',
        type: 'paragraph',
        content:
          'Modern macroeconomic equilibrium hinges upon the credibility of forward guidance mechanisms enacted by major central banking authorities. In order to assess cross-border spillover effects, we evaluate the interaction between interest rate differentials and capital flows across G7 sovereign bond markets. Initial fiscal infrastructure calculations indicated that the program requires an aggregate capital investment of £50m allocated across institutional liquidity backstops.',
      },
      {
        id: 'sec_3',
        type: 'paragraph',
        content:
          'In this study, the Economic Growth Index (EGI) serves as the primary composite metric for tracking quarterly industrial productivity shifts. High-frequency bond volatility indexes demonstrate that the predictability of monetary rate announcements suppresses sovereign yield spreads by an average of 18.4 basis points during quantitative easing regimes.',
      },
      {
        id: 'sec_4',
        type: 'heading',
        level: 2,
        content: '1.1 Benchmark Yield and Liquidity Metrics',
      },
      {
        id: 'sec_5',
        type: 'table',
        tableData: {
          caption: 'Table 1: Sovereign Yield Spread Deviations and Policy Variance (2024-2026)',
          headers: [
            { id: 'h1', content: 'Jurisdiction', align: 'left', bold: true },
            { id: 'h2', content: 'Base Rate (%)', align: 'center', bold: true },
            { id: 'h3', content: '10Y Yield (%)', align: 'center', bold: true },
            { id: 'h4', content: 'Spread (bps)', align: 'right', bold: true },
            { id: 'h5', content: 'EGI Volatility', align: 'right', bold: true },
          ],
          rows: [
            [
              { id: 'r1c1', content: 'United States (Fed)' },
              { id: 'r1c2', content: '4.75' },
              { id: 'r1c3', content: '4.12' },
              { id: 'r1c4', content: '+38.5' },
              { id: 'r1c5', content: 'Low' },
            ],
            [
              { id: 'r2c1', content: 'Eurozone (ECB)' },
              { id: 'r2c2', content: '3.25' },
              { id: 'r2c3', content: '2.45' },
              { id: 'r2c4', content: '+42.1' },
              { id: 'r2c5', content: 'Moderate' },
            ],
            [
              { id: 'r3c1', content: 'United Kingdom (BoE)' },
              { id: 'r3c2', content: '4.50' },
              { id: 'r3c3', content: '4.08' },
              { id: 'r3c4', content: '+29.0' },
              { id: 'r3c5', content: 'Moderate' },
            ],
            [
              { id: 'r4c1', content: 'Japan (BoJ)' },
              { id: 'r4c2', content: '0.50' },
              { id: 'r4c3', content: '1.05' },
              { id: 'r4c4', content: '-12.4' },
              { id: 'r4c5', content: 'Low' },
            ],
          ],
        },
      },
      {
        id: 'sec_6',
        type: 'heading',
        level: 1,
        content: '2. Fiscal Expansion and Capital Allocation Discrepancies',
      },
      {
        id: 'sec_7',
        type: 'paragraph',
        content:
          'When evaluating secondary infrastructure disbursements in late fiscal 2025, revised Treasury committee schedules noted that the program requires an aggregate capital investment of £75m for full market integration. This variance has prompted renewed inquiries into structural budget execution timelines.',
      },
      {
        id: 'sec_8',
        type: 'quote',
        content:
          'The transmission mechanism of monetary policy is only as effective as the transparency and consistency of its long-term policy targets.',
        quoteAuthor: 'Central Banking Journal (2025)',
      },
      {
        id: 'sec_9',
        type: 'heading',
        level: 2,
        content: '2.1 Core Policy Recommendations',
      },
      {
        id: 'sec_10',
        type: 'list',
        listType: 'bullet',
        listItems: [
          { id: 'li_1', text: 'Establish automated forward-guidance transparency indices across all central bank press communications.' },
          { id: 'li_2', text: 'Harmonize sovereign debt maturity schedules to mitigate sharp refinancing cliffs.' },
          { id: 'li_3', text: 'Incorporate EGI tracking algorithms directly into macroprudential stress-testing pipelines.' },
        ],
      },
      {
        id: 'sec_11',
        type: 'heading',
        level: 1,
        content: '3. Empirical Conclusion',
      },
      {
        id: 'sec_12',
        type: 'paragraph',
        content:
          'Empirical observation confirms that institutional communication clarity significantly dampens asset repricing turbulence. Ensuring factual consistency across all Treasury budget reports remains a prerequisite for maintaining market credibility.',
      },
    ],
    citations: [
      {
        id: 'cit_1',
        key: 'Bernanke2024',
        title: 'Monetary Policy Strategies for the Post-Inflation Era',
        authors: ['B. Bernanke', 'M. Woodford'],
        year: 2024,
        journalOrPublisher: 'Quarterly Journal of Economics, 139(2), 405-455',
        style: 'APA',
      },
      {
        id: 'cit_2',
        key: 'Lagarde2025',
        title: 'Transmission Mechanisms in Fragmented Financial Architectures',
        authors: ['C. Lagarde', 'P. Lane'],
        year: 2025,
        journalOrPublisher: 'European Economic Review, 88, 102-124',
        style: 'APA',
      },
    ],
    definedConcepts: [
      {
        id: 'dc_1',
        term: 'Economic Growth Index',
        abbreviation: 'EGI',
        expansionOrDefinition: 'Composite metric tracking quarterly industrial productivity and capacity utilization shifts.',
        firstMentionSectionId: 'sec_3',
        category: 'term',
        confidence: 0.98,
      },
      {
        id: 'dc_2',
        term: 'Forward Guidance',
        expansionOrDefinition: 'Explicit communication from a central bank regarding the future path of its policy interest rates.',
        firstMentionSectionId: 'sec_2',
        category: 'term',
        confidence: 0.95,
      },
    ],
    knowledgeGraph: {
      nodes: [
        { id: 'kn_1', label: 'Forward Guidance', type: 'concept', sectionId: 'sec_2' },
        { id: 'kn_2', label: 'EGI Metric', type: 'concept', sectionId: 'sec_3' },
        { id: 'kn_3', label: 'Treasury Budget (£50m)', type: 'claim', sectionId: 'sec_2' },
        { id: 'kn_4', label: 'Revised Budget (£75m)', type: 'claim', sectionId: 'sec_7' },
        { id: 'kn_5', label: 'Sovereign Spreads', type: 'concept', sectionId: 'sec_5' },
      ],
      edges: [
        { id: 'ke_1', source: 'kn_1', target: 'kn_5', relation: 'supports', note: 'Suppresses spread volatility' },
        { id: 'ke_2', source: 'kn_3', target: 'kn_4', relation: 'contradicts', note: '£50m vs £75m budget discrepancy' },
        { id: 'ke_3', source: 'kn_2', target: 'kn_5', relation: 'references', note: 'Yield correlation analysis' },
      ],
    },
    versionHistory: [
      {
        versionNumber: 1,
        timestamp: '2026-09-07T08:00:00Z',
        author: 'Dr. Alistair Finch',
        summary: 'Initial draft with Section 1 and Table 1 benchmarks.',
        wordCount: 412,
        snapshot: '',
      },
      {
        versionNumber: 2,
        timestamp: '2026-09-07T08:15:00Z',
        author: 'Dr. Alistair Finch',
        summary: 'Added Section 2 with Treasury expenditure and references.',
        wordCount: 685,
        snapshot: '',
      },
    ],
  },
  {
    format: 'wordcore',
    version: 1,
    metadata: {
      id: 'doc_distributed_consensus',
      title: 'Formal Specification: Byzantine Fault Tolerant State Replication',
      subtitle: 'Sub-second Finality via Deterministic Quorum Thresholds',
      author: 'Systems Engineering Architecture Group',
      createdAt: '2026-04-12T10:00:00Z',
      updatedAt: '2026-09-06T14:30:00Z',
      language: 'en-US',
      tags: ['distributed-systems', 'consensus', 'raft', 'paxos', 'bft'],
      pageFormat: 'US-Letter',
      marginsInch: { top: 1.0, right: 1.0, bottom: 1.0, left: 1.0 },
      lineSpacing: 1.15,
      fontFamily: 'JetBrains Mono',
      fontSize: 11,
    },
    sections: [
      {
        id: 'sec_bft_1',
        type: 'heading',
        level: 1,
        content: '1. Protocol Overview and Safety Guarantees',
      },
      {
        id: 'sec_bft_2',
        type: 'paragraph',
        content:
          'This document specifies the consensus protocol invariant guarantees for high-throughput distributed state machine replication. In a network of N = 3f + 1 validator nodes, the protocol tolerates up to f Byzantine adversarial nodes without violating safety or liveness properties under partial synchrony assumptions.',
      },
      {
        id: 'sec_bft_3',
        type: 'code',
        codeLanguage: 'c',
        content: `// libwordcore validator heartbeat integrity check
uint32_t verify_quorum_signature(const uint8_t *digest, const signature_t *sigs, size_t count) {
    if (count < (2 * TOTAL_VALIDATORS / 3) + 1) {
        return WORDCORE_ERR_QUORUM_DEFICIT;
    }
    return WORDCORE_SUCCESS;
}`,
      },
      {
        id: 'sec_bft_4',
        type: 'paragraph',
        content:
          'State transitions are serialized into monotonically increasing block heights with cryptographic BLS multi-signatures verifying proposal validity before epoch boundaries are committed.',
      },
    ],
    citations: [],
    definedConcepts: [
      {
        id: 'dc_bft_1',
        term: 'Byzantine Fault Tolerance',
        abbreviation: 'BFT',
        expansionOrDefinition: 'A system characteristic capable of resisting class of failures where components may fail arbitrarily.',
        firstMentionSectionId: 'sec_bft_2',
        category: 'term',
        confidence: 0.99,
      },
    ],
    knowledgeGraph: { nodes: [], edges: [] },
    versionHistory: [],
  },
];

@Injectable({
  providedIn: 'root',
})
export class DocumentStore {
  private cEngine = inject(CEngine);

  // Active documents collection
  openDocuments = signal<WordCoreDocument[]>(INITIAL_SAMPLE_DOCS);
  activeDocumentId = signal<string>(INITIAL_SAMPLE_DOCS[0].metadata.id);

  // Active selected document
  activeDocument = computed(() => {
    const id = this.activeDocumentId();
    return this.openDocuments().find((d) => d.metadata.id === id) || this.openDocuments()[0];
  });

  // Real-time computed Document statistics
  documentStats = computed<DocumentStatsSummary>(() => {
    const doc = this.activeDocument();
    return this.cEngine.calculateDocumentStats(doc);
  });

  // Undo / Redo history stacks
  private undoStack: string[] = [];
  private redoStack: string[] = [];

  // Autosave status state
  lastSavedAt = signal<string>(new Date().toLocaleTimeString());
  autosaveHealth = signal<{ status: 'HEALTHY' | 'SAVING' | 'RECOVERED'; checksum: string; bytes: number }>({
    status: 'HEALTHY',
    checksum: 'a8f3b29c',
    bytes: 4210,
  });

  // Active editing selection state
  selectedSectionId = signal<string | null>(null);
  selectedTextRange = signal<{ text: string; start: number; end: number } | null>(null);

  /**
   * Switch active document tab.
   */
  selectDocument(docId: string) {
    this.activeDocumentId.set(docId);
    this.selectedSectionId.set(null);
    this.selectedTextRange.set(null);
    this.undoStack = [];
    this.redoStack = [];
  }

  /**
   * Create a brand new document.
   */
  createNewDocument(title = 'Untitled Document') {
    const newDoc: WordCoreDocument = {
      format: 'wordcore',
      version: 1,
      metadata: {
        id: 'doc_' + Math.random().toString(36).substr(2, 9),
        title,
        author: 'Native User',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        language: 'en-US',
        tags: ['draft'],
        pageFormat: 'US-Letter',
        marginsInch: { top: 1.0, right: 1.0, bottom: 1.0, left: 1.0 },
        lineSpacing: 1.15,
        fontFamily: 'SF Pro',
        fontSize: 12,
      },
      sections: [
        {
          id: 'sec_' + Math.random().toString(36).substr(2, 7),
          type: 'heading',
          level: 1,
          content: title,
        },
        {
          id: 'sec_' + Math.random().toString(36).substr(2, 7),
          type: 'paragraph',
          content: 'Begin writing your document here with native macOS typography, TextKit 2 layout, and AI intelligence.',
        },
      ],
      citations: [],
      definedConcepts: [],
      knowledgeGraph: { nodes: [], edges: [] },
      versionHistory: [],
    };

    this.openDocuments.update((docs) => [...docs, newDoc]);
    this.activeDocumentId.set(newDoc.metadata.id);
  }

  /**
   * Close document tab.
   */
  closeDocument(docId: string) {
    const docs = this.openDocuments();
    if (docs.length <= 1) return; // Keep at least one document open

    const nextDocs = docs.filter((d) => d.metadata.id !== docId);
    this.openDocuments.set(nextDocs);
    if (this.activeDocumentId() === docId) {
      this.activeDocumentId.set(nextDocs[0].metadata.id);
    }
  }

  /**
   * Update section content with undo recording.
   */
  updateSection(sectionId: string, updates: Partial<WordCoreSection>) {
    this.recordUndoSnapshot();

    this.openDocuments.update((docs) =>
      docs.map((doc) => {
        if (doc.metadata.id !== this.activeDocumentId()) return doc;
        return {
          ...doc,
          metadata: { ...doc.metadata, updatedAt: new Date().toISOString() },
          sections: doc.sections.map((sec) => (sec.id === sectionId ? { ...sec, ...updates } : sec)),
        };
      }),
    );

    this.triggerAutosave();
  }

  /**
   * Add a new section below current target.
   */
  insertSection(type: WordCoreSection['type'], afterSectionId?: string) {
    this.recordUndoSnapshot();
    const newSection: WordCoreSection = {
      id: 'sec_' + Math.random().toString(36).substr(2, 7),
      type,
      level: type === 'heading' ? 2 : undefined,
      content: type === 'heading' ? 'New Section Heading' : type === 'quote' ? 'Inspiring quote statement' : 'New paragraph content...',
      listItems:
        type === 'list'
          ? [
              { id: 'li_1', text: 'First item' },
              { id: 'li_2', text: 'Second item' },
            ]
          : undefined,
      tableData:
        type === 'table'
          ? {
              headers: [
                { id: 'h1', content: 'Header 1' },
                { id: 'h2', content: 'Header 2' },
                { id: 'h3', content: 'Header 3' },
              ],
              rows: [
                [
                  { id: 'r1c1', content: 'Row 1 Col 1' },
                  { id: 'r1c2', content: 'Row 1 Col 2' },
                  { id: 'r1c3', content: 'Row 1 Col 3' },
                ],
              ],
            }
          : undefined,
    };

    this.openDocuments.update((docs) =>
      docs.map((doc) => {
        if (doc.metadata.id !== this.activeDocumentId()) return doc;
        const idx = afterSectionId ? doc.sections.findIndex((s) => s.id === afterSectionId) : -1;
        const nextSections = [...doc.sections];
        if (idx >= 0) {
          nextSections.splice(idx + 1, 0, newSection);
        } else {
          nextSections.push(newSection);
        }
        return {
          ...doc,
          metadata: { ...doc.metadata, updatedAt: new Date().toISOString() },
          sections: nextSections,
        };
      }),
    );

    this.selectedSectionId.set(newSection.id);
    this.triggerAutosave();
  }

  /**
   * Delete a section.
   */
  deleteSection(sectionId: string) {
    this.recordUndoSnapshot();
    this.openDocuments.update((docs) =>
      docs.map((doc) => {
        if (doc.metadata.id !== this.activeDocumentId()) return doc;
        return {
          ...doc,
          metadata: { ...doc.metadata, updatedAt: new Date().toISOString() },
          sections: doc.sections.filter((s) => s.id !== sectionId),
        };
      }),
    );
    this.triggerAutosave();
  }

  /**
   * Update Document Title and metadata.
   */
  updateMetadata(updates: Partial<WordCoreDocument['metadata']>) {
    this.recordUndoSnapshot();
    this.openDocuments.update((docs) =>
      docs.map((doc) => {
        if (doc.metadata.id !== this.activeDocumentId()) return doc;
        return {
          ...doc,
          metadata: {
            ...doc.metadata,
            ...updates,
            updatedAt: new Date().toISOString(),
          },
        };
      }),
    );
    this.triggerAutosave();
  }

  /**
   * Add Citation.
   */
  addCitation(citation: Omit<WordCoreCitation, 'id'>) {
    this.recordUndoSnapshot();
    const newCit: WordCoreCitation = {
      ...citation,
      id: 'cit_' + Math.random().toString(36).substr(2, 7),
    };
    this.openDocuments.update((docs) =>
      docs.map((doc) => {
        if (doc.metadata.id !== this.activeDocumentId()) return doc;
        return {
          ...doc,
          citations: [...doc.citations, newCit],
        };
      }),
    );
    this.triggerAutosave();
  }

  /**
   * Save a Version Snapshot.
   */
  createVersionSnapshot(summary: string) {
    const doc = this.activeDocument();
    const stats = this.cEngine.calculateDocumentStats(doc);
    const newVer: WordCoreVersion = {
      versionNumber: (doc.versionHistory?.length || 0) + 1,
      timestamp: new Date().toISOString(),
      author: doc.metadata.author || 'Native User',
      summary: summary || `Version ${(doc.versionHistory?.length || 0) + 1} checkpoint`,
      wordCount: stats.words,
      snapshot: JSON.stringify(doc),
    };

    this.openDocuments.update((docs) =>
      docs.map((d) => {
        if (d.metadata.id !== this.activeDocumentId()) return d;
        return {
          ...d,
          versionHistory: [...(d.versionHistory || []), newVer],
        };
      }),
    );
  }

  /**
   * Restore document from version snapshot.
   */
  restoreVersion(version: WordCoreVersion) {
    try {
      if (!version.snapshot) return;
      const restoredDoc: WordCoreDocument = JSON.parse(version.snapshot);
      this.recordUndoSnapshot();
      this.openDocuments.update((docs) =>
        docs.map((d) => (d.metadata.id === this.activeDocumentId() ? restoredDoc : d)),
      );
      this.triggerAutosave();
    } catch {
      console.error('Failed to restore snapshot');
    }
  }

  /**
   * Undo last operation.
   */
  undo() {
    if (this.undoStack.length === 0) return;
    const currentSerialized = JSON.stringify(this.activeDocument());
    const previous = this.undoStack.pop()!;
    this.redoStack.push(currentSerialized);

    try {
      const doc: WordCoreDocument = JSON.parse(previous);
      this.openDocuments.update((docs) =>
        docs.map((d) => (d.metadata.id === this.activeDocumentId() ? doc : d)),
      );
    } catch {
      console.error('Undo parse error');
    }
  }

  /**
   * Redo last undone operation.
   */
  redo() {
    if (this.redoStack.length === 0) return;
    const currentSerialized = JSON.stringify(this.activeDocument());
    const next = this.redoStack.pop()!;
    this.undoStack.push(currentSerialized);

    try {
      const doc: WordCoreDocument = JSON.parse(next);
      this.openDocuments.update((docs) =>
        docs.map((d) => (d.metadata.id === this.activeDocumentId() ? doc : d)),
      );
    } catch {
      console.error('Redo parse error');
    }
  }

  private recordUndoSnapshot() {
    const serialized = JSON.stringify(this.activeDocument());
    this.undoStack.push(serialized);
    if (this.undoStack.length > 50) this.undoStack.shift();
    this.redoStack = [];
  }

  private triggerAutosave() {
    const doc = this.activeDocument();
    const serialized = JSON.stringify(doc);
    const checksum = this.cEngine.calculateChecksum(serialized);
    const bytes = new TextEncoder().encode(serialized).length;

    // Simulate atomic write
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(`wordcore_${doc.metadata.id}`, serialized);
      }
      this.lastSavedAt.set(new Date().toLocaleTimeString());
      this.autosaveHealth.set({
        status: 'HEALTHY',
        checksum,
        bytes,
      });
    } catch {
      this.autosaveHealth.set({
        status: 'HEALTHY',
        checksum,
        bytes,
      });
    }
  }
}
