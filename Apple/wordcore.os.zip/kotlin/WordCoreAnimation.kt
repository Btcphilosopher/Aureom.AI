package com.wordcore.animation

import kotlin.math.sin
import kotlin.math.PI

/**
 * WORDCORE.OS - Kotlin Animation and Design System Specification
 * Provides spring curves, timing functions, and design tokens for macOS UI.
 */
data class SpringSpec(
    val stiffness: Double = 180.0,
    val damping: Double = 16.0,
    val mass: Double = 1.0,
    val initialVelocity: Double = 0.0
)

enum class WordCoreAnimationType {
    AI_SUGGESTION_APPEAR,
    DIFF_HIGHLIGHT_TRANSITION,
    SIDEBAR_ACCORDION,
    COMMAND_BAR_SPOTLIGHT,
    TIMELINE_SCRUBBING,
    TYPING_CADENCE_PULSE
}

object WordCoreDesignSystem {
    // Animation Specs
    val AISuggestionEntrance = SpringSpec(stiffness = 220.0, damping = 20.0)
    val DiffHighlightFade = SpringSpec(stiffness = 140.0, damping = 18.0)
    val SidebarTransition = SpringSpec(stiffness = 190.0, damping = 22.0)
    
    // Design Tokens
    const val BORDER_RADIUS_MODAL = 12.0
    const val BORDER_RADIUS_PILL = 9999.0
    const val ACCENT_COLOR_HEX = "#3b82f6"
    const val SURFACE_DARK_HEX = "#1e1e24"
    const val TEXT_PRIMARY_HEX = "#f8fafc"
}
