# WORDCORE.OS - R Statistical Analytics Service
# File: r/wordcore_stats.R

library(jsonlite)

wordcore_stats <- list()

#' Compute Flesch, Flesch-Kincaid, and Gunning Fog readability indices
wordcore_stats$readability <- function(text) {
  words <- unlist(strsplit(tolower(text), "\\W+"))
  words <- words[nchar(words) > 0]
  sentences <- unlist(strsplit(text, "[.!?]+"))
  sentences <- sentences[nchar(trimws(sentences)) > 0]
  
  n_words <- length(words)
  n_sentences <- max(1, length(sentences))
  asl <- n_words / n_sentences
  
  # Approximate syllable counts
  syllables <- sum(sapply(words, function(w) {
    max(1, nchar(gsub("[^aeiouy]", "", w)))
  }))
  asw <- syllables / max(1, n_words)
  
  flesch_reading_ease <- 206.835 - (1.015 * asl) - (84.6 * asw)
  flesch_kincaid_grade <- (0.39 * asl) + (11.8 * asw) - 15.59
  
  return(list(
    flesch_reading_ease = round(flesch_reading_ease, 2),
    flesch_kincaid_grade = round(flesch_kincaid_grade, 2),
    average_sentence_length = round(asl, 2),
    words_total = n_words,
    sentences_total = n_sentences
  ))
}

#' Compute lexical diversity and Yule's K
wordcore_stats$lexical_diversity <- function(text) {
  words <- unlist(strsplit(tolower(text), "\\W+"))
  words <- words[nchar(words) > 0]
  n_words <- length(words)
  
  if (n_words == 0) return(list(ttr = 0, yules_k = 0))
  
  freq_table <- table(words)
  types <- length(freq_table)
  ttr <- types / n_words
  
  # Yule's K calculation
  spectrum <- table(freq_table)
  m1 <- sum(as.numeric(names(spectrum)) * spectrum)
  m2 <- sum(as.numeric(names(spectrum))^2 * spectrum)
  yules_k <- 10^4 * (m2 - m1) / (m1^2)
  
  return(list(
    type_token_ratio = round(ttr, 3),
    unique_types = types,
    total_tokens = n_words,
    yules_k = round(yules_k, 2)
  ))
}
