package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aureom TV Cinematic Palette
val AureomBlack = Color(0xFF070708)
val AureomDeepGraphite = Color(0xFF151618)
val AureomMediumGrey = Color(0xFF282A2E)
val AureomSoftGrey = Color(0xFF8E9094)
val AureomSilver = Color(0xFFE5E7EB)
val AureomWhite = Color(0xFFFFFFFF)
val AureomAccent = Color(0xFFFFFFFF) // Pure focus accent

// Classic fallback tokens for M3
val Purple80 = Color(0xFFFFFFFF)
val PurpleGrey80 = Color(0xFF8E9094)
val Pink80 = Color(0xFFE5E7EB)
val Purple40 = Color(0xFF151618)
val PurpleGrey40 = Color(0xFF282A2E)
val Pink40 = Color(0xFF070708)
