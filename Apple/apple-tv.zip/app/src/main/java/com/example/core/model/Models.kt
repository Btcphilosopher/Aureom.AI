package com.example.core.model

import java.util.UUID

interface BaseEntity {
    val id: String
    val createdAt: Long
    val updatedAt: Long
    val version: Int
    val status: String
}

data class Profile(
    override val id: String = UUID.randomUUID().toString(),
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val name: String,
    val avatarUrl: String,
    val role: String = "Adult", // Adult, Teen, Child, Guest
    val pin: String? = null,
    val isKidsSafe: Boolean = false,
    val screenTimeLimitMinutes: Int = 0
) : BaseEntity

data class Movie(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val title: String,
    val description: String,
    val imageUrl: String,
    val bannerUrl: String,
    val year: Int,
    val runtimeMinutes: Int,
    val rating: String, // G, PG, PG-13, R
    val genre: String,
    val studio: String,
    val ratingPercent: Int = 85,
    val price: Double = 14.99,
    val rentPrice: Double = 3.99,
    val videoUrl: String,
    val director: String,
    val cast: List<String> = emptyList()
) : BaseEntity

data class Series(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val title: String,
    val description: String,
    val imageUrl: String,
    val bannerUrl: String,
    val year: Int,
    val rating: String,
    val genre: String,
    val studio: String,
    val ratingPercent: Int = 90,
    val creator: String,
    val cast: List<String> = emptyList()
) : BaseEntity

data class Season(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val seriesId: String,
    val seasonNumber: Int,
    val title: String
) : BaseEntity

data class Episode(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val seasonId: String,
    val episodeNumber: Int,
    val title: String,
    val description: String,
    val durationMinutes: Int,
    val videoUrl: String,
    val imageUrl: String,
    val seriesId: String
) : BaseEntity

data class SportEvent(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val league: String, // Premier League, NBA, NFL
    val teamHome: String,
    val teamAway: String,
    val scoreHome: Int = 0,
    val scoreAway: Int = 0,
    val period: String = "Upcoming", // Q1, Full Time, Live, Upcoming
    val gameClock: String = "00:00",
    val videoUrl: String,
    val bannerUrl: String,
    val liveStats: Map<String, String> = emptyMap(),
    val eventTimeline: List<String> = emptyList()
) : BaseEntity

data class LiveChannel(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val name: String,
    val currentProgram: String,
    val programDescription: String,
    val imageUrl: String,
    val bannerUrl: String,
    val videoUrl: String
) : BaseEntity

data class WatchProgress(
    override val id: String, // profileId_contentId
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val profileId: String,
    val titleId: String, // Movie ID or Series ID
    val episodeId: String?, // Null for movies
    val positionMs: Long,
    val durationMs: Long,
    val lastPlayedAt: Long = System.currentTimeMillis(),
    val completed: Boolean = false
) : BaseEntity {
    val percentage: Float get() = if (durationMs > 0) positionMs.toFloat() / durationMs.toFloat() else 0f
}

data class LibraryItem(
    override val id: String, // profileId_titleId
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val profileId: String,
    val titleId: String, // Movie ID or Series ID
    val type: String, // "PURCHASE", "RENTAL", "WATCHLIST"
    val purchasedAt: Long = System.currentTimeMillis(),
    val expirationTime: Long? = null // For rentals
) : BaseEntity

data class SubscriptionPlan(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val name: String, // "Aureom Original", "Premier Sports", "Kids Fun Channel"
    val priceMonthly: Double,
    val isSubscribed: Boolean = false,
    val description: String
) : BaseEntity

data class AppItem(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val title: String,
    val packageName: String,
    val appState: String, // "NOT_INSTALLED", "DOWNLOADING", "INSTALLED"
    val isSystem: Boolean = false,
    val logoUrl: String,
    val description: String = ""
) : BaseEntity

data class AudioRoute(
    override val id: String,
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "ACTIVE",
    val name: String,
    val type: String, // "INTERNAL_SPEAKER", "BLUETOOTH", "AIRPLAY", "HDMI"
    val isSelected: Boolean = false
) : BaseEntity

data class DiscoveryDevice(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: String, // "TV", "Speaker", "Phone", "Tablet"
    val room: String,
    val isPaired: Boolean = false
)

data class Transaction(
    override val id: String = UUID.randomUUID().toString(),
    override val createdAt: Long = System.currentTimeMillis(),
    override val updatedAt: Long = System.currentTimeMillis(),
    override val version: Int = 1,
    override val status: String = "COMPLETED",
    val profileId: String,
    val itemId: String,
    val amount: Double,
    val purchaseType: String // "PURCHASE", "RENTAL", "SUBSCRIPTION"
) : BaseEntity
