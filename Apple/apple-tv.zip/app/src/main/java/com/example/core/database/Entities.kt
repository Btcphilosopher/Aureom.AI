package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val avatarUrl: String,
    val role: String,
    val pin: String?,
    val isKidsSafe: Boolean,
    val screenTimeLimitMinutes: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val version: Int,
    val status: String
)

@Entity(tableName = "watch_progress")
data class WatchProgressEntity(
    @PrimaryKey val id: String, // profileId_titleId
    val profileId: String,
    val titleId: String,
    val episodeId: String?,
    val positionMs: Long,
    val durationMs: Long,
    val lastPlayedAt: Long,
    val completed: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val version: Int,
    val status: String
)

@Entity(tableName = "library_items")
data class LibraryItemEntity(
    @PrimaryKey val id: String, // profileId_titleId_type
    val profileId: String,
    val titleId: String,
    val type: String, // PURCHASE, RENTAL, WATCHLIST
    val purchasedAt: Long,
    val expirationTime: Long?,
    val createdAt: Long,
    val updatedAt: Long,
    val version: Int,
    val status: String
)

@Entity(tableName = "subscriptions")
data class SubscriptionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val priceMonthly: Double,
    val isSubscribed: Boolean,
    val description: String,
    val createdAt: Long,
    val updatedAt: Long,
    val version: Int,
    val status: String
)

@Entity(tableName = "installed_apps")
data class AppEntity(
    @PrimaryKey val id: String,
    val title: String,
    val packageName: String,
    val appState: String, // NOT_INSTALLED, DOWNLOADING, INSTALLED
    val isSystem: Boolean,
    val logoUrl: String,
    val description: String,
    val createdAt: Long,
    val updatedAt: Long,
    val version: Int,
    val status: String
)

@Entity(tableName = "audio_routes")
data class AudioRouteEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val isSelected: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val version: Int,
    val status: String
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)
