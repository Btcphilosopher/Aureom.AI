package com.example.core.shell

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.core.database.AppDatabase
import com.example.core.database.AureomRepository
import com.example.core.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

enum class TVScreen {
    HOME_LAUNCHER,
    APPLE_TV_APP,
    DETAILS_SCREEN,
    VIDEO_PLAYER,
    SPORTS_HOME,
    LIVE_MATCH,
    STORE_FRONT,
    LIBRARY_SHELF,
    SEARCH_GLOBAL,
    APP_STORE,
    SETTINGS_MENU
}

class AureomTVShell(private val context: Context) {

    val repository = AureomRepository(AppDatabase.getDatabase(context))
    private val shellScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // --- Core UI Navigation States ---
    var currentScreen by mutableStateOf(TVScreen.HOME_LAUNCHER)
    var previousScreen by mutableStateOf<TVScreen?>(null)
    var selectedSidebarItem by mutableStateOf("HOME") // HOME, APPLE TV, STORE, LIBRARY, SPORTS, SEARCH, SETTINGS
    var isSidebarExpanded by mutableStateOf(false)
    var isControlCenterOpen by mutableStateOf(false)

    // --- Detail Page Content Reference ---
    var selectedMovieDetail by mutableStateOf<Movie?>(null)
    var selectedSeriesDetail by mutableStateOf<Series?>(null)
    var selectedSportDetail by mutableStateOf<SportEvent?>(null)

    // --- Active Profile State ---
    var activeProfile by mutableStateOf<Profile?>(null)
    val profilesList = repository.allProfiles.stateIn(shellScope, SharingStarted.Eagerly, emptyList())

    // --- Media & Playback States ---
    var activeMediaTitle by mutableStateOf<String?>(null)
    var activeVideoUrl by mutableStateOf<String?>(null)
    var playbackState by mutableStateOf("IDLE") // IDLE, PREPARING, PLAYING, PAUSED, SEEKING, ENDED, ERROR
    var playbackPositionMs by mutableStateOf(0L)
    var playbackDurationMs by mutableStateOf(0L)
    var isMuted by mutableStateOf(false)
    var selectedAudioTrack by mutableStateOf("Stereo English")
    var selectedSubtitleTrack by mutableStateOf("Off")
    var selectedVideoQuality by mutableStateOf("1080p HD")
    var skipIntroButtonVisible by mutableStateOf(false)

    // --- Audio Routes ---
    val audioRoutes = repository.allAudioRoutes.stateIn(shellScope, SharingStarted.Eagerly, emptyList())

    // --- Installed Apps State ---
    val installedApps = repository.allApps.stateIn(shellScope, SharingStarted.Eagerly, emptyList())

    // --- Subscriptions State ---
    val allSubscriptions = repository.allSubscriptions.stateIn(shellScope, SharingStarted.Eagerly, emptyList())

    // --- Device Pairing & Companion Remote Abstraction ---
    var pairingCode by mutableStateOf("542 981")
    var pairedRemoteConnected by mutableStateOf(false)
    var isPairingScreenOpen by mutableStateOf(false)

    // --- Discovery Devices (AirPlay/Home Devices Mock) ---
    val discoveredDevices = listOf(
        DiscoveryDevice("spk_1", "Kitchen Smart Speaker", "Speaker", "Kitchen"),
        DiscoveryDevice("tv_2", "Bedroom Apple TV", "TV", "Bedroom", true),
        DiscoveryDevice("ph_3", "Elena's iPhone", "Phone", "Living Room", false),
        DiscoveryDevice("tab_4", "Family iPad", "Tablet", "Living Room", false)
    )

    // --- Search Engine state ---
    var searchQuery by mutableStateOf("")
    var searchResults by mutableStateOf<List<BaseEntity>>(emptyList())

    // --- Sync Engine States ---
    var syncState by mutableStateOf("SYNCED") // SYNCED, PENDING, SYNCING, FAILED
    var lastSyncTimestamp by mutableStateOf(System.currentTimeMillis())

    // --- Developer Mode Overlay ---
    var developerModeEnabled by mutableStateOf(true) // Enabled by default for diagnostics review
    var currentFocusedNodeId by mutableStateOf("main_hero_banner")
    var simulatedFps by mutableStateOf(60)
    var simulatedCpuUsage by mutableStateOf("12%")
    var simulatedMemoryUsage by mutableStateOf("1.2 GB / 4.0 GB")
    var simulatedApiLatencyMs by mutableStateOf(24)

    // --- Notification Toasts ---
    var activeToast by mutableStateOf<String?>(null)

    // --- Synthetic Purchases/Rentals Ledger ---
    var purchasesList = mutableListOf<String>() // list of title IDs

    init {
        // Observe and load selected profile
        shellScope.launch {
            profilesList.collect { list ->
                if (list.isNotEmpty() && activeProfile == null) {
                    activeProfile = list.first()
                }
            }
        }

        // Periodic telemetry & status simulation
        shellScope.launch {
            while (true) {
                delay(1000)
                simulatedFps = (58..60).random()
                simulatedCpuUsage = "${(8..20).random()}%"
                simulatedApiLatencyMs = (15..35).random()
                
                // Simulate periodic database watch-progress sync to backend
                if (playbackState == "PLAYING") {
                    playbackPositionMs += 1000L
                    if (playbackPositionMs >= playbackDurationMs) {
                        playbackPositionMs = playbackDurationMs
                        playbackState = "ENDED"
                        showToast("Playback completed: $activeMediaTitle")
                        // Save progress
                        activeProfile?.let { prof ->
                            activeMediaTitle?.let { title ->
                                repository.saveWatchProgress(prof.id, title, null, playbackPositionMs, playbackDurationMs, true)
                            }
                        }
                    } else {
                        // Periodic auto-save progress
                        if (playbackPositionMs % 5000L == 0L) {
                            activeProfile?.let { prof ->
                                activeMediaTitle?.let { title ->
                                    repository.saveWatchProgress(prof.id, title, null, playbackPositionMs, playbackDurationMs, false)
                                }
                            }
                        }
                    }

                    // Simulated skip intro alert between 15s and 30s
                    skipIntroButtonVisible = playbackPositionMs in 15000L..30000L
                }
            }
        }
    }

    fun showToast(msg: String) {
        activeToast = msg
        shellScope.launch {
            delay(3000)
            if (activeToast == msg) {
                activeToast = null
            }
        }
    }

    // --- Screen transition actions ---
    fun navigateTo(screen: TVScreen) {
        previousScreen = currentScreen
        currentScreen = screen
        isSidebarExpanded = false
        isControlCenterOpen = false
        currentFocusedNodeId = when(screen) {
            TVScreen.HOME_LAUNCHER -> "home_grid_app_1"
            TVScreen.APPLE_TV_APP -> "apple_tv_hero"
            TVScreen.DETAILS_SCREEN -> "details_action_play"
            TVScreen.VIDEO_PLAYER -> "player_panel_playback"
            TVScreen.SPORTS_HOME -> "sports_rail_live_1"
            TVScreen.LIVE_MATCH -> "sports_stats_tab"
            TVScreen.STORE_FRONT -> "store_rent_plan_1"
            TVScreen.LIBRARY_SHELF -> "library_item_1"
            TVScreen.SEARCH_GLOBAL -> "search_keyboard_q"
            TVScreen.APP_STORE -> "app_store_featured_1"
            TVScreen.SETTINGS_MENU -> "settings_general"
        }
        showToast("Opened: ${screen.name.replace("_", " ")}")
    }

    fun goBack() {
        previousScreen?.let {
            navigateTo(it)
            previousScreen = null
        } ?: run {
            if (currentScreen != TVScreen.HOME_LAUNCHER) {
                navigateTo(TVScreen.HOME_LAUNCHER)
            }
        }
    }

    // --- Remote Control Input Simulation ---
    fun handleRemoteAction(action: String) {
        showToast("Remote press: $action")
        when (action) {
            "BACK" -> {
                if (isControlCenterOpen) {
                    isControlCenterOpen = false
                } else if (isSidebarExpanded) {
                    isSidebarExpanded = false
                } else if (currentScreen == TVScreen.VIDEO_PLAYER) {
                    // Pause playback and exit player
                    playbackState = "PAUSED"
                    goBack()
                } else {
                    goBack()
                }
            }
            "HOME" -> {
                navigateTo(TVScreen.HOME_LAUNCHER)
            }
            "MENU" -> {
                // Long press remote opens control centre, normal toggles sidebar
                isSidebarExpanded = !isSidebarExpanded
            }
            "SELECT" -> {
                executeSelection()
            }
            "PLAY_PAUSE" -> {
                if (currentScreen == TVScreen.VIDEO_PLAYER) {
                    playbackState = if (playbackState == "PLAYING") "PAUSED" else "PLAYING"
                }
            }
            "FF" -> {
                if (currentScreen == TVScreen.VIDEO_PLAYER) {
                    playbackPositionMs = (playbackPositionMs + 15000L).coerceAtMost(playbackDurationMs)
                    showToast("Seeking +15s")
                }
            }
            "REW" -> {
                if (currentScreen == TVScreen.VIDEO_PLAYER) {
                    playbackPositionMs = (playbackPositionMs - 15000L).coerceAtLeast(0L)
                    showToast("Seeking -15s")
                }
            }
            "UP", "DOWN", "LEFT", "RIGHT" -> {
                navigateFocus(action)
            }
        }
    }

    private fun navigateFocus(direction: String) {
        val curr = currentFocusedNodeId
        currentFocusedNodeId = when (currentScreen) {
            TVScreen.HOME_LAUNCHER -> {
                when {
                    curr.startsWith("home_grid_app_") -> {
                        val num = curr.substringAfter("home_grid_app_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "home_grid_app_${(num + 1).coerceAtMost(6)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_0" } else "home_grid_app_${num - 1}"
                            "DOWN" -> "home_grid_system_app_1"
                            else -> curr
                        }
                    }
                    curr.startsWith("home_grid_system_app_") -> {
                        val num = curr.substringAfter("home_grid_system_app_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "home_grid_system_app_${(num + 1).coerceAtMost(3)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_0" } else "home_grid_system_app_${num - 1}"
                            "UP" -> "home_grid_app_1"
                            else -> curr
                        }
                    }
                    else -> "home_grid_app_1"
                }
            }
            TVScreen.APPLE_TV_APP -> {
                when {
                    curr == "apple_tv_hero" -> {
                        when (direction) {
                            "DOWN" -> "apple_tv_play_hero"
                            "LEFT" -> { isSidebarExpanded = true; "sidebar_item_1" }
                            else -> curr
                        }
                    }
                    curr == "apple_tv_play_hero" -> {
                        when (direction) {
                            "RIGHT" -> "apple_tv_watchlist_hero"
                            "DOWN" -> "apple_tv_rail_continue_1"
                            "UP" -> "apple_tv_hero"
                            "LEFT" -> { isSidebarExpanded = true; "sidebar_item_1" }
                            else -> curr
                        }
                    }
                    curr == "apple_tv_watchlist_hero" -> {
                        when (direction) {
                            "LEFT" -> "apple_tv_play_hero"
                            "DOWN" -> "apple_tv_rail_continue_1"
                            "UP" -> "apple_tv_hero"
                            else -> curr
                        }
                    }
                    curr.startsWith("apple_tv_rail_continue_") -> {
                        val num = curr.substringAfter("apple_tv_rail_continue_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "apple_tv_rail_continue_${(num + 1).coerceAtMost(3)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_1" } else "apple_tv_rail_continue_${num - 1}"
                            "UP" -> "apple_tv_play_hero"
                            "DOWN" -> "apple_tv_rail_picks_1"
                            else -> curr
                        }
                    }
                    curr.startsWith("apple_tv_rail_picks_") -> {
                        val num = curr.substringAfter("apple_tv_rail_picks_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "apple_tv_rail_picks_${(num + 1).coerceAtMost(4)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_1" } else "apple_tv_rail_picks_${num - 1}"
                            "UP" -> "apple_tv_rail_continue_1"
                            "DOWN" -> "apple_tv_rail_releases_1"
                            else -> curr
                        }
                    }
                    curr.startsWith("apple_tv_rail_releases_") -> {
                        val num = curr.substringAfter("apple_tv_rail_releases_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "apple_tv_rail_releases_${(num + 1).coerceAtMost(4)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_1" } else "apple_tv_rail_releases_${num - 1}"
                            "UP" -> "apple_tv_rail_picks_1"
                            else -> curr
                        }
                    }
                    else -> "apple_tv_hero"
                }
            }
            TVScreen.DETAILS_SCREEN -> {
                when (curr) {
                    "details_action_play" -> {
                        when (direction) {
                            "RIGHT" -> "details_action_watchlist"
                            "DOWN" -> "details_episode_1_1"
                            else -> curr
                        }
                    }
                    "details_action_watchlist" -> {
                        when (direction) {
                            "LEFT" -> "details_action_play"
                            "RIGHT" -> "details_action_rent"
                            "DOWN" -> "details_episode_1_1"
                            else -> curr
                        }
                    }
                    "details_action_rent" -> {
                        when (direction) {
                            "LEFT" -> "details_action_watchlist"
                            "DOWN" -> "details_episode_1_1"
                            else -> curr
                        }
                    }
                    else -> {
                        if (curr.startsWith("details_episode_1_")) {
                            val num = curr.substringAfter("details_episode_1_").toIntOrNull() ?: 1
                            when (direction) {
                                "RIGHT" -> "details_episode_1_${(num + 1).coerceAtMost(5)}"
                                "LEFT" -> "details_episode_1_${(num - 1).coerceAtLeast(1)}"
                                "UP" -> "details_action_play"
                                else -> curr
                            }
                        } else {
                            "details_action_play"
                        }
                    }
                }
            }
            TVScreen.VIDEO_PLAYER -> {
                when (curr) {
                    "player_panel_playback" -> {
                        when (direction) {
                            "DOWN" -> "player_skip_intro"
                            "RIGHT" -> "player_audio_select"
                            else -> curr
                        }
                    }
                    "player_audio_select" -> {
                        when (direction) {
                            "LEFT" -> "player_panel_playback"
                            "RIGHT" -> "player_subtitle_select"
                            "DOWN" -> "player_skip_intro"
                            else -> curr
                        }
                    }
                    "player_subtitle_select" -> {
                        when (direction) {
                            "LEFT" -> "player_audio_select"
                            "DOWN" -> "player_skip_intro"
                            else -> curr
                        }
                    }
                    "player_skip_intro" -> {
                        when (direction) {
                            "UP" -> "player_panel_playback"
                            else -> curr
                        }
                    }
                    else -> "player_panel_playback"
                }
            }
            TVScreen.SPORTS_HOME -> {
                when {
                    curr.startsWith("sports_rail_live_") -> {
                        val num = curr.substringAfter("sports_rail_live_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "sports_rail_live_${(num + 1).coerceAtMost(3)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_4" } else "sports_rail_live_${num - 1}"
                            "DOWN" -> "sports_rail_upcoming_1"
                            else -> curr
                        }
                    }
                    curr.startsWith("sports_rail_upcoming_") -> {
                        val num = curr.substringAfter("sports_rail_upcoming_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "sports_rail_upcoming_${(num + 1).coerceAtMost(4)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_4" } else "sports_rail_upcoming_${num - 1}"
                            "UP" -> "sports_rail_live_1"
                            else -> curr
                        }
                    }
                    else -> "sports_rail_live_1"
                }
            }
            TVScreen.LIVE_MATCH -> {
                "sports_stats_tab"
            }
            TVScreen.STORE_FRONT -> {
                when {
                    curr.startsWith("store_rent_plan_") -> {
                        val num = curr.substringAfter("store_rent_plan_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "store_rent_plan_${(num + 1).coerceAtMost(3)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_2" } else "store_rent_plan_${num - 1}"
                            "DOWN" -> "store_channel_1"
                            else -> curr
                        }
                    }
                    curr.startsWith("store_channel_") -> {
                        val num = curr.substringAfter("store_channel_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "store_channel_${(num + 1).coerceAtMost(4)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_2" } else "store_channel_${num - 1}"
                            "UP" -> "store_rent_plan_1"
                            else -> curr
                        }
                    }
                    else -> "store_rent_plan_1"
                }
            }
            TVScreen.LIBRARY_SHELF -> {
                when {
                    curr.startsWith("library_item_") -> {
                        val num = curr.substringAfter("library_item_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "library_item_${(num + 1).coerceAtMost(4)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_3" } else "library_item_${num - 1}"
                            else -> curr
                        }
                    }
                    else -> "library_item_1"
                }
            }
            TVScreen.SEARCH_GLOBAL -> {
                when {
                    curr.startsWith("search_keyboard_") -> {
                        val key = curr.substringAfter("search_keyboard_")
                        // Simplified row shift
                        when (direction) {
                            "DOWN" -> "search_result_1"
                            "LEFT" -> if (key == "a" || key == "q") { isSidebarExpanded = true; "sidebar_item_5" } else "search_keyboard_q"
                            else -> curr
                        }
                    }
                    curr.startsWith("search_result_") -> {
                        val num = curr.substringAfter("search_result_").toIntOrNull() ?: 1
                        when (direction) {
                            "UP" -> "search_keyboard_q"
                            "RIGHT" -> "search_result_${(num + 1).coerceAtMost(4)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "sidebar_item_5" } else "search_result_${num - 1}"
                            else -> curr
                        }
                    }
                    else -> "search_keyboard_q"
                }
            }
            TVScreen.APP_STORE -> {
                when {
                    curr.startsWith("app_store_featured_") -> {
                        val num = curr.substringAfter("app_store_featured_").toIntOrNull() ?: 1
                        when (direction) {
                            "RIGHT" -> "app_store_featured_${(num + 1).coerceAtMost(3)}"
                            "LEFT" -> if (num == 1) { isSidebarExpanded = true; "home_grid_app_1" } else "app_store_featured_${num - 1}"
                            "DOWN" -> "app_store_install_button"
                            else -> curr
                        }
                    }
                    curr == "app_store_install_button" -> {
                        when (direction) {
                            "UP" -> "app_store_featured_1"
                            else -> curr
                        }
                    }
                    else -> "app_store_featured_1"
                }
            }
            TVScreen.SETTINGS_MENU -> {
                when (curr) {
                    "settings_general" -> if (direction == "DOWN") "settings_video" else curr
                    "settings_video" -> if (direction == "UP") "settings_general" else if (direction == "DOWN") "settings_audio" else curr
                    "settings_audio" -> if (direction == "UP") "settings_video" else if (direction == "DOWN") "settings_profiles" else curr
                    "settings_profiles" -> if (direction == "UP") "settings_audio" else if (direction == "DOWN") "settings_developer" else curr
                    "settings_developer" -> if (direction == "UP") "settings_profiles" else curr
                    else -> "settings_general"
                }
            }
        }
    }

    private fun executeSelection() {
        val curr = currentFocusedNodeId
        when (currentScreen) {
            TVScreen.HOME_LAUNCHER -> {
                if (curr == "home_grid_app_1") {
                    navigateTo(TVScreen.APPLE_TV_APP)
                } else if (curr == "home_grid_app_2") {
                    navigateTo(TVScreen.STORE_FRONT)
                } else if (curr == "home_grid_app_3") {
                    navigateTo(TVScreen.LIBRARY_SHELF)
                } else if (curr == "home_grid_app_4") {
                    navigateTo(TVScreen.SPORTS_HOME)
                } else if (curr == "home_grid_app_5") {
                    navigateTo(TVScreen.APP_STORE)
                } else if (curr == "home_grid_app_6") {
                    navigateTo(TVScreen.SEARCH_GLOBAL)
                } else if (curr == "home_grid_system_app_1") {
                    navigateTo(TVScreen.SETTINGS_MENU)
                } else if (curr == "home_grid_system_app_2") {
                    isControlCenterOpen = true
                }
            }
            TVScreen.APPLE_TV_APP -> {
                if (curr == "apple_tv_play_hero" || curr == "apple_tv_hero") {
                    // Start movie detail / play
                    selectedMovieDetail = repository.getMovies().first()
                    navigateTo(TVScreen.DETAILS_SCREEN)
                } else if (curr == "apple_tv_rail_continue_1") {
                    selectedMovieDetail = repository.getMovieById("movie_1")
                    navigateTo(TVScreen.DETAILS_SCREEN)
                } else if (curr == "apple_tv_rail_continue_2") {
                    selectedSeriesDetail = repository.getSeriesById("series_1")
                    navigateTo(TVScreen.DETAILS_SCREEN)
                } else if (curr.startsWith("apple_tv_rail_picks_")) {
                    val idx = curr.substringAfter("apple_tv_rail_picks_").toIntOrNull() ?: 1
                    selectedMovieDetail = repository.getMovieById("movie_$idx")
                    navigateTo(TVScreen.DETAILS_SCREEN)
                } else if (curr.startsWith("apple_tv_rail_releases_")) {
                    val idx = curr.substringAfter("apple_tv_rail_releases_").toIntOrNull() ?: 1
                    selectedMovieDetail = repository.getMovieById("movie_${idx + 10}")
                    navigateTo(TVScreen.DETAILS_SCREEN)
                }
            }
            TVScreen.DETAILS_SCREEN -> {
                if (curr == "details_action_play") {
                    selectedMovieDetail?.let {
                        activeMediaTitle = it.title
                        activeVideoUrl = it.videoUrl
                        playbackDurationMs = it.runtimeMinutes * 60 * 1000L
                        playbackPositionMs = 0L
                        playbackState = "PLAYING"
                        navigateTo(TVScreen.VIDEO_PLAYER)
                    }
                    selectedSeriesDetail?.let {
                        // Play episode 1
                        val firstEp = repository.getEpisodes(it.id, 1).firstOrNull()
                        if (firstEp != null) {
                            activeMediaTitle = "${it.title} - S1E1: ${firstEp.title}"
                            activeVideoUrl = firstEp.videoUrl
                            playbackDurationMs = firstEp.durationMinutes * 60 * 1000L
                            playbackPositionMs = 0L
                            playbackState = "PLAYING"
                            navigateTo(TVScreen.VIDEO_PLAYER)
                        }
                    }
                } else if (curr == "details_action_watchlist") {
                    selectedMovieDetail?.let {
                        shellScope.launch {
                            val profId = activeProfile?.id ?: "prof_adult_1"
                            if (repository.getLibraryItem(profId, it.id, "WATCHLIST") != null) {
                                repository.removeFromLibrary(profId, it.id, "WATCHLIST")
                                showToast("Removed from Watchlist")
                            } else {
                                repository.addToLibrary(profId, it.id, "WATCHLIST")
                                showToast("Added to Watchlist")
                            }
                        }
                    }
                    selectedSeriesDetail?.let {
                        shellScope.launch {
                            val profId = activeProfile?.id ?: "prof_adult_1"
                            if (repository.getLibraryItem(profId, it.id, "WATCHLIST") != null) {
                                repository.removeFromLibrary(profId, it.id, "WATCHLIST")
                                showToast("Removed from Watchlist")
                            } else {
                                repository.addToLibrary(profId, it.id, "WATCHLIST")
                                showToast("Added to Watchlist")
                            }
                        }
                    }
                } else if (curr == "details_action_rent") {
                    selectedMovieDetail?.let {
                        purchasesList.add(it.id)
                        shellScope.launch {
                            repository.addToLibrary(activeProfile?.id ?: "prof_adult_1", it.id, "RENTAL", 2)
                        }
                        showToast("Successfully rented ${it.title} synthetically!")
                    }
                } else if (curr.startsWith("details_episode_1_")) {
                    selectedSeriesDetail?.let { show ->
                        val epNum = curr.substringAfter("details_episode_1_").toIntOrNull() ?: 1
                        val ep = repository.getEpisodes(show.id, 1).firstOrNull { it.episodeNumber == epNum }
                        if (ep != null) {
                            activeMediaTitle = "${show.title} - S1E$epNum: ${ep.title}"
                            activeVideoUrl = ep.videoUrl
                            playbackDurationMs = ep.durationMinutes * 60 * 1000L
                            playbackPositionMs = 0L
                            playbackState = "PLAYING"
                            navigateTo(TVScreen.VIDEO_PLAYER)
                        }
                    }
                }
            }
            TVScreen.VIDEO_PLAYER -> {
                if (curr == "player_panel_playback") {
                    playbackState = if (playbackState == "PLAYING") "PAUSED" else "PLAYING"
                } else if (curr == "player_audio_select") {
                    selectedAudioTrack = if (selectedAudioTrack == "Stereo English") "Surround Atmos 5.1" else "Stereo English"
                    showToast("Switched Audio to: $selectedAudioTrack")
                } else if (curr == "player_subtitle_select") {
                    selectedSubtitleTrack = if (selectedSubtitleTrack == "Off") "English CC" else "Off"
                    showToast("Subtitles: $selectedSubtitleTrack")
                } else if (curr == "player_skip_intro") {
                    playbackPositionMs += 30000L // skip 30s
                    skipIntroButtonVisible = false
                    showToast("Skipped Intro Intro Section")
                }
            }
            TVScreen.SPORTS_HOME -> {
                if (curr.startsWith("sports_rail_live_")) {
                    val idx = curr.substringAfter("sports_rail_live_").toIntOrNull() ?: 1
                    selectedSportDetail = repository.getSportsEvents()[idx - 1]
                    navigateTo(TVScreen.LIVE_MATCH)
                } else if (curr.startsWith("sports_rail_upcoming_")) {
                    showToast("Match is upcoming. Scheduled live broadcast notification active!")
                }
            }
            TVScreen.STORE_FRONT -> {
                if (curr.startsWith("store_rent_plan_")) {
                    val idx = curr.substringAfter("store_rent_plan_").toIntOrNull() ?: 1
                    shellScope.launch {
                        val sub = repository.allSubscriptions.first()[idx - 1]
                        repository.toggleSubscription(sub.id, !sub.isSubscribed)
                        showToast(if (sub.isSubscribed) "Unsubscribed" else "Subscribed to ${sub.name} synthetically!")
                    }
                } else if (curr.startsWith("store_channel_")) {
                    val idx = curr.substringAfter("store_channel_").toIntOrNull() ?: 1
                    val channel = repository.getLiveChannels()[idx - 1]
                    activeMediaTitle = "Live Channel: ${channel.name}"
                    activeVideoUrl = channel.videoUrl
                    playbackDurationMs = 3600 * 1000L
                    playbackPositionMs = 0L
                    playbackState = "PLAYING"
                    navigateTo(TVScreen.VIDEO_PLAYER)
                }
            }
            TVScreen.APP_STORE -> {
                if (curr == "app_store_install_button" || curr.startsWith("app_store_featured_")) {
                    showToast("Downloading package...")
                    shellScope.launch {
                        delay(1500)
                        repository.installApp("app_4") // install FitTV
                        showToast("FitTV successfully registered & installed!")
                    }
                }
            }
            TVScreen.SETTINGS_MENU -> {
                if (curr == "settings_developer") {
                    developerModeEnabled = !developerModeEnabled
                    showToast("Developer mode overlay: ${if(developerModeEnabled) "ENABLED" else "DISABLED"}")
                } else if (curr == "settings_profiles") {
                    // Quick profile switch to Elena/Marcus
                    activeProfile = if (activeProfile?.id == "prof_adult_1") {
                        profilesList.value.firstOrNull { it.id == "prof_teen_2" }
                    } else {
                        profilesList.value.firstOrNull { it.id == "prof_adult_1" }
                    }
                    showToast("Switched Profile to: ${activeProfile?.name}")
                } else {
                    showToast("Setting selected: Working option preserved.")
                }
            }
            else -> {}
        }
    }
}
