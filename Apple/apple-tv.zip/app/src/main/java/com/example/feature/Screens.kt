package com.example.feature

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.model.*
import com.example.core.shell.AureomTVShell
import com.example.core.shell.TVScreen
import com.example.ui.theme.*

// --- MAIN CENTRAL ROUTER ---
@Composable
fun TVAppRouter(shell: AureomTVShell) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AureomBlack)
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            // Collapsible Sidebar (tvOS Left Navigation Rail style)
            TVSidebarComponent(shell = shell)

            // Content Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                AnimatedContent(
                    targetState = shell.currentScreen,
                    transitionSpec = {
                        fadeIn(tween(300)) togetherWith fadeOut(tween(300))
                    },
                    label = "screen_transition"
                ) { screen ->
                    when (screen) {
                        TVScreen.HOME_LAUNCHER -> LauncherScreen(shell)
                        TVScreen.APPLE_TV_APP -> AppleTVAppScreen(shell)
                        TVScreen.DETAILS_SCREEN -> DetailsScreen(shell)
                        TVScreen.VIDEO_PLAYER -> VideoPlayerScreen(shell)
                        TVScreen.SPORTS_HOME -> SportsHomeScreen(shell)
                        TVScreen.LIVE_MATCH -> LiveMatchScreen(shell)
                        TVScreen.STORE_FRONT -> StoreScreen(shell)
                        TVScreen.LIBRARY_SHELF -> LibraryScreen(shell)
                        TVScreen.SEARCH_GLOBAL -> SearchScreen(shell)
                        TVScreen.APP_STORE -> AppStoreScreen(shell)
                        TVScreen.SETTINGS_MENU -> SettingsScreen(shell)
                    }
                }
            }
        }

        // Control Center Panel Overlay (tvOS right panel style)
        ControlCenterPanel(shell = shell)

        // Diagnostic Telemetry HUD
        DeveloperModeOverlay(shell = shell)

        // Standard notification toasts
        shell.activeToast?.let {
            TVToast(message = it, modifier = Modifier.align(Alignment.TopCenter))
        }
    }
}

// --- SIDEBAR COMPONENT ---
@Composable
fun TVSidebarComponent(shell: AureomTVShell) {
    val items = listOf(
        Triple("HOME", Icons.Default.Home, TVScreen.HOME_LAUNCHER),
        Triple("APPLE TV", Icons.Default.Tv, TVScreen.APPLE_TV_APP),
        Triple("STORE", Icons.Default.ShoppingBag, TVScreen.STORE_FRONT),
        Triple("LIBRARY", Icons.Default.VideoLibrary, TVScreen.LIBRARY_SHELF),
        Triple("SPORTS", Icons.Default.SportsBasketball, TVScreen.SPORTS_HOME),
        Triple("SEARCH", Icons.Default.Search, TVScreen.SEARCH_GLOBAL),
        Triple("SETTINGS", Icons.Default.Settings, TVScreen.SETTINGS_MENU)
    )

    AnimatedVisibility(
        visible = shell.isSidebarExpanded || shell.currentScreen != TVScreen.VIDEO_PLAYER,
        enter = slideInHorizontally() + fadeIn(),
        exit = slideOutHorizontally() + fadeOut()
    ) {
        val width = if (shell.isSidebarExpanded) 220.dp else 70.dp
        Column(
            modifier = Modifier
                .width(width)
                .fillMaxHeight()
                .background(AureomDeepGraphite)
                .padding(vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profile switcher icon at top of sidebar
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(AureomMediumGrey)
                    .clickable { shell.isControlCenterOpen = true },
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = shell.activeProfile?.avatarUrl ?: "https://picsum.photos/id/64/100/100",
                    contentDescription = "Avatar",
                    modifier = Modifier.fillMaxSize().clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            }

            Spacer(modifier = Modifier.height(30.dp))

            items.forEachIndexed { idx, item ->
                val (label, icon, screen) = item
                val isSelected = shell.selectedSidebarItem == label
                val nodeId = "sidebar_item_$idx"
                val isFocused = shell.currentFocusedNodeId == nodeId

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag(nodeId)
                        .background(
                            if (isFocused) AureomMediumGrey 
                            else if (isSelected && !shell.isSidebarExpanded) AureomBlack 
                            else Color.Transparent
                        )
                        .border(
                            width = if (isFocused) 1.5.dp else 0.dp,
                            color = if (isFocused) AureomWhite else Color.Transparent
                        )
                        .clickable {
                            shell.currentFocusedNodeId = nodeId
                            shell.selectedSidebarItem = label
                            shell.navigateTo(screen)
                        }
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isFocused || isSelected) AureomWhite else AureomSoftGrey,
                        modifier = Modifier.size(20.dp)
                    )
                    if (shell.isSidebarExpanded) {
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = label,
                            color = if (isFocused || isSelected) AureomWhite else AureomSoftGrey,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

// --- HOME LAUNCHER SCREEN ---
@Composable
fun LauncherScreen(shell: AureomTVShell) {
    val appsList by shell.installedApps.collectAsState()
    val activeApps = appsList.filter { it.appState == "INSTALLED" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp, vertical = 30.dp)
    ) {
        item {
            // Elegant Aureom TV Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "AUREOM TV", color = AureomWhite, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text(text = "ORCHARD TV OPERATING SHELL", color = AureomSoftGrey, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.weight(1f))
                TVBadge(text = "ONLINE", containerColor = Color(0xFF2E7D32), contentColor = AureomWhite)
                Spacer(modifier = Modifier.width(16.dp))
                Text(text = "06:36 AM", color = AureomWhite, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.height(40.dp))
        }

        item {
            Text(text = "Favorite Applications", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                TVFocusCard(nodeId = "home_grid_app_1", shell = shell, onClick = { shell.navigateTo(TVScreen.APPLE_TV_APP) }) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.Tv, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Apple TV App", color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                TVFocusCard(nodeId = "home_grid_app_2", shell = shell, onClick = { shell.navigateTo(TVScreen.STORE_FRONT) }) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Store", color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                TVFocusCard(nodeId = "home_grid_app_3", shell = shell, onClick = { shell.navigateTo(TVScreen.LIBRARY_SHELF) }) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.VideoLibrary, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Library", color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                TVFocusCard(nodeId = "home_grid_app_4", shell = shell, onClick = { shell.navigateTo(TVScreen.SPORTS_HOME) }) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.SportsBasketball, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Sports", color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                TVFocusCard(nodeId = "home_grid_app_5", shell = shell, onClick = { shell.navigateTo(TVScreen.APP_STORE) }) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.Shop, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "App Store", color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                TVFocusCard(nodeId = "home_grid_app_6", shell = shell, onClick = { shell.navigateTo(TVScreen.SEARCH_GLOBAL) }) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Search", color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Programmatically installed third-party apps
                activeApps.filter { !it.isSystem }.forEachIndexed { idx, app ->
                    val appNodeId = "home_grid_installed_app_$idx"
                    TVFocusCard(nodeId = appNodeId, shell = shell, onClick = { shell.showToast("Launching visual App: ${app.title}") }) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            AsyncImage(
                                model = app.logoUrl,
                                contentDescription = app.title,
                                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(text = app.title, color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(40.dp))
        }

        item {
            Text(text = "System Shortcuts", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                TVFocusCard(nodeId = "home_grid_system_app_1", shell = shell, onClick = { shell.navigateTo(TVScreen.SETTINGS_MENU) }) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = "Settings", color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }

                TVFocusCard(nodeId = "home_grid_system_app_2", shell = shell, onClick = { shell.isControlCenterOpen = true }) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Tune, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = "Control Center", color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// --- APPLE TV CATALOG APP SCREEN ---
@Composable
fun AppleTVAppScreen(shell: AureomTVShell) {
    val movies = shell.repository.getMovies()
    val series = shell.repository.getSeries()
    val watchProgressList by shell.repository.getWatchProgressFlow(shell.activeProfile?.id ?: "prof_adult_1").collectAsState(emptyList())

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 40.dp)
    ) {
        // Hero Cinematic Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp)
                    .background(AureomDeepGraphite)
            ) {
                // Background Banner Art
                AsyncImage(
                    model = "https://picsum.photos/id/80/1200/500",
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Gradient Scrim overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Transparent,
                                    AureomBlack.copy(alpha = 0.5f),
                                    AureomBlack
                                )
                            )
                        )
                )

                // Hero Metadata Details Overlay
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .padding(horizontal = 40.dp, vertical = 24.dp)
                ) {
                    TVBadge(text = "AUREOM ORIGINAL", containerColor = AureomWhite, contentColor = AureomBlack)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "The Last Observatory", color = AureomWhite, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(6.dp))
                    TVMetadataLine(year = 2024, runtime = "2h 14m", rating = "PG-13", genre = "Sci-Fi & Mystery")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Humanity's final hope lies in a forgotten deep space tracking station in the North Atlantic. Follow Elena Vance as she decrypts the final signal.",
                        color = AureomSilver,
                        fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth(0.6f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        TVButton(
                            nodeId = "apple_tv_play_hero",
                            shell = shell,
                            text = "Play Movie",
                            icon = Icons.Default.PlayArrow,
                            onClick = {
                                shell.selectedMovieDetail = movies.first()
                                shell.navigateTo(TVScreen.DETAILS_SCREEN)
                            }
                        )
                        TVButton(
                            nodeId = "apple_tv_watchlist_hero",
                            shell = shell,
                            text = "Add to Watchlist",
                            icon = Icons.Default.Add,
                            isPrimary = false,
                            onClick = {
                                shell.showToast("Added to Watchlist")
                            }
                        )
                    }
                }
            }
        }

        // Row 1: Continue Watching (only if watch history has elements)
        if (watchProgressList.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(start = 40.dp, top = 20.dp)) {
                    Text(text = "Continue Watching", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(14.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        items(watchProgressList.take(3)) { progress ->
                            val movie = shell.repository.getMovieById(progress.titleId)
                            val show = shell.repository.getSeriesById(progress.titleId)
                            val titleText = movie?.title ?: show?.title ?: "Unknown Title"
                            val imgUrl = movie?.imageUrl ?: show?.imageUrl ?: "https://picsum.photos/300/180"
                            val subtitle = if (progress.episodeId != null) "S1E${progress.episodeId.substringAfterLast("_")}" else "Movie"

                            TVLandscapePoster(
                                nodeId = "apple_tv_rail_continue_${progress.titleId}",
                                shell = shell,
                                title = titleText,
                                imageUrl = imgUrl,
                                subtitle = subtitle,
                                progress = progress.percentage,
                                onClick = {
                                    if (movie != null) {
                                        shell.selectedMovieDetail = movie
                                        shell.navigateTo(TVScreen.DETAILS_SCREEN)
                                    } else if (show != null) {
                                        shell.selectedSeriesDetail = show
                                        shell.navigateTo(TVScreen.DETAILS_SCREEN)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // Row 2: Top Picks (Aureom Originals collection)
        item {
            Column(modifier = Modifier.padding(start = 40.dp, top = 24.dp)) {
                Text(text = "Top Picks For You", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(14.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    items((1..4).toList()) { idx ->
                        val movie = movies[idx]
                        TVPoster(
                            nodeId = "apple_tv_rail_picks_$idx",
                            shell = shell,
                            title = movie.title,
                            imageUrl = movie.imageUrl,
                            subtitle = movie.genre,
                            onClick = {
                                shell.selectedMovieDetail = movie
                                shell.navigateTo(TVScreen.DETAILS_SCREEN)
                            }
                        )
                    }
                }
            }
        }

        // Row 3: New Releases
        item {
            Column(modifier = Modifier.padding(start = 40.dp, top = 24.dp)) {
                Text(text = "New Releases", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(14.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    items((1..4).toList()) { idx ->
                        val movie = movies[idx + 10]
                        TVPoster(
                            nodeId = "apple_tv_rail_releases_$idx",
                            shell = shell,
                            title = movie.title,
                            imageUrl = movie.imageUrl,
                            subtitle = movie.studio,
                            onClick = {
                                shell.selectedMovieDetail = movie
                                shell.navigateTo(TVScreen.DETAILS_SCREEN)
                            }
                        )
                    }
                }
            }
        }
    }
}

// --- DETAILS / PRODUCT PAGE ---
@Composable
fun DetailsScreen(shell: AureomTVShell) {
    val movie = shell.selectedMovieDetail
    val series = shell.selectedSeriesDetail

    val title = movie?.title ?: series?.title ?: "Title Details"
    val bannerUrl = movie?.bannerUrl ?: series?.bannerUrl ?: "https://picsum.photos/1200/500"
    val year = movie?.year ?: series?.year ?: 2024
    val genre = movie?.genre ?: series?.genre ?: "Drama"
    val studio = movie?.studio ?: series?.studio ?: "Aureom Original"
    val rating = movie?.rating ?: series?.rating ?: "PG"
    val desc = movie?.description ?: series?.description ?: "Full content details..."
    val runtime = movie?.let { "${it.runtimeMinutes} mins" } ?: "2 Seasons"
    val directorCreator = movie?.director ?: series?.creator ?: "Director"

    Box(modifier = Modifier.fillMaxSize()) {
        // Backdrop Image
        AsyncImage(
            model = bannerUrl,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        // Soft focus scrim and twilight gradient overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            AureomBlack.copy(alpha = 0.2f),
                            AureomBlack.copy(alpha = 0.8f),
                            AureomBlack
                        )
                    )
                )
        )

        // Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 40.dp),
            contentPadding = PaddingValues(top = 100.dp, bottom = 40.dp)
        ) {
            item {
                Column(modifier = Modifier.fillMaxWidth(0.6f)) {
                    Text(text = studio, color = AureomSoftGrey, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = title, color = AureomWhite, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(10.dp))
                    TVMetadataLine(year = year, runtime = runtime, rating = rating, genre = genre)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = desc, color = AureomSilver, fontSize = 14.sp, lineHeight = 20.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Creator / Director: $directorCreator", color = AureomSoftGrey, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(24.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        TVButton(
                            nodeId = "details_action_play",
                            shell = shell,
                            text = "Play",
                            icon = Icons.Default.PlayArrow,
                            onClick = {
                                shell.handleRemoteAction("SELECT")
                            }
                        )
                        TVButton(
                            nodeId = "details_action_watchlist",
                            shell = shell,
                            text = "Watchlist",
                            icon = Icons.Default.Add,
                            isPrimary = false,
                            onClick = {
                                shell.handleRemoteAction("RIGHT")
                                shell.handleRemoteAction("SELECT")
                            }
                        )
                        if (movie != null) {
                            TVButton(
                                nodeId = "details_action_rent",
                                shell = shell,
                                text = "Rent \$${movie.rentPrice}",
                                icon = Icons.Default.MonetizationOn,
                                isPrimary = false,
                                onClick = {
                                    shell.handleRemoteAction("RIGHT")
                                    shell.handleRemoteAction("RIGHT")
                                    shell.handleRemoteAction("SELECT")
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(40.dp))
            }

            // Episode Grid if Series
            if (series != null) {
                item {
                    Column {
                        Text(text = "Season 1 Episodes", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(14.dp))
                        val eps = shell.repository.getEpisodes(series.id, 1)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            items(eps) { ep ->
                                val epNodeId = "details_episode_1_${ep.episodeNumber}"
                                TVLandscapePoster(
                                    nodeId = epNodeId,
                                    shell = shell,
                                    title = ep.title,
                                    imageUrl = ep.imageUrl,
                                    subtitle = "Episode ${ep.episodeNumber} • ${ep.durationMinutes}m",
                                    onClick = {
                                        shell.currentFocusedNodeId = epNodeId
                                        shell.handleRemoteAction("SELECT")
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- VIDEO PLAYER SCREEN ---
@Composable
fun VideoPlayerScreen(shell: AureomTVShell) {
    // Elegant full-bleed visual mock with timeline progress updates
    val curTime = shell.playbackPositionMs
    val durTime = shell.playbackDurationMs
    val progress = if (durTime > 0) curTime.toFloat() / durTime.toFloat() else 0f

    val formattedCurTime = String.format("%02d:%02d", (curTime / 1000) / 60, (curTime / 1000) % 60)
    val formattedDurTime = String.format("%02d:%02d", (durTime / 1000) / 60, (durTime / 1000) % 60)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Background Player placeholder indicating simulated active file playback
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = if (shell.playbackState == "PLAYING") Icons.Default.PlayArrow else Icons.Default.Pause,
                contentDescription = null,
                tint = AureomSilver.copy(alpha = 0.15f),
                modifier = Modifier.size(100.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Simulating Streaming Stream variant: ${shell.activeMediaTitle}",
                color = AureomSoftGrey,
                fontSize = 13.sp
            )
            Text(
                text = "Track Output Quality: ${shell.selectedVideoQuality} (${shell.selectedAudioTrack})",
                color = AureomSoftGrey,
                fontSize = 11.sp
            )
        }

        // Skip Intro Button overlay (dynamic action)
        AnimatedVisibility(
            visible = shell.skipIntroButtonVisible,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 120.dp, end = 40.dp)
        ) {
            TVButton(
                nodeId = "player_skip_intro",
                shell = shell,
                text = "SKIP INTRO",
                icon = Icons.Default.SkipNext,
                onClick = {
                    shell.handleRemoteAction("DOWN")
                    shell.handleRemoteAction("SELECT")
                }
            )
        }

        // Player Controls Dashboard Overlay
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f), Color.Black)))
                .padding(horizontal = 40.dp, vertical = 24.dp)
        ) {
            // Interactive Timeline
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = formattedCurTime, color = AureomWhite, fontSize = 12.sp)
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(AureomMediumGrey)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progress)
                            .fillMaxHeight()
                            .background(AureomWhite)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = formattedDurTime, color = AureomWhite, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Control Buttons Panel
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                TVButton(
                    nodeId = "player_panel_playback",
                    shell = shell,
                    text = if (shell.playbackState == "PLAYING") "PAUSE" else "PLAY",
                    icon = if (shell.playbackState == "PLAYING") Icons.Default.Pause else Icons.Default.PlayArrow,
                    onClick = {
                        shell.playbackState = if (shell.playbackState == "PLAYING") "PAUSED" else "PLAYING"
                    }
                )
                Spacer(modifier = Modifier.width(16.dp))
                TVButton(
                    nodeId = "player_audio_select",
                    shell = shell,
                    text = "Audio: ${shell.selectedAudioTrack}",
                    icon = Icons.Default.VolumeUp,
                    isPrimary = false,
                    onClick = {
                        shell.handleRemoteAction("RIGHT")
                        shell.handleRemoteAction("SELECT")
                    }
                )
                Spacer(modifier = Modifier.width(16.dp))
                TVButton(
                    nodeId = "player_subtitle_select",
                    shell = shell,
                    text = "Subtitles: ${shell.selectedSubtitleTrack}",
                    icon = Icons.Default.ClosedCaption,
                    isPrimary = false,
                    onClick = {
                        shell.handleRemoteAction("RIGHT")
                        shell.handleRemoteAction("SELECT")
                    }
                )
            }
        }
    }
}

// --- SPORTS HOME SCREEN ---
@Composable
fun SportsHomeScreen(shell: AureomTVShell) {
    val sportsList = shell.repository.getSportsEvents()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp, vertical = 30.dp)
    ) {
        item {
            Text(text = "Aureom Sports Arena", color = AureomWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(text = "Fictional live championship scores and fixtures", color = AureomSoftGrey, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(30.dp))
        }

        item {
            Text(text = "Live Now", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(14.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(sportsList.filter { it.period == "Live" }) { match ->
                    val nodeId = "sports_rail_live_${match.id.substringAfter("sport_")}"
                    TVLandscapePoster(
                        nodeId = nodeId,
                        shell = shell,
                        title = "${match.teamHome} vs ${match.teamAway}",
                        imageUrl = match.bannerUrl,
                        subtitle = "Live • ${match.scoreHome} - ${match.scoreAway} (${match.gameClock})",
                        onClick = {
                            shell.currentFocusedNodeId = nodeId
                            shell.selectedSportDetail = match
                            shell.navigateTo(TVScreen.LIVE_MATCH)
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.height(30.dp))
        }

        item {
            Text(text = "Upcoming Games", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(14.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(sportsList.filter { it.period == "Upcoming" }) { match ->
                    val nodeId = "sports_rail_upcoming_${match.id.substringAfter("sport_")}"
                    TVLandscapePoster(
                        nodeId = nodeId,
                        shell = shell,
                        title = "${match.teamHome} vs ${match.teamAway}",
                        imageUrl = match.bannerUrl,
                        subtitle = "Scheduled • ${match.league}",
                        onClick = {
                            shell.currentFocusedNodeId = nodeId
                            shell.handleRemoteAction("SELECT")
                        }
                    )
                }
            }
        }
    }
}

// --- LIVE MATCH DETAIL DASHBOARD ---
@Composable
fun LiveMatchScreen(shell: AureomTVShell) {
    val match = shell.selectedSportDetail ?: shell.repository.getSportsEvents().first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp, vertical = 30.dp)
    ) {
        // Main Live Score banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = AureomDeepGraphite)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = match.league, color = AureomSoftGrey, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = match.teamHome, color = AureomWhite, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Text(text = "Home", color = AureomSoftGrey, fontSize = 11.sp)
                    }

                    Text(text = "${match.scoreHome} - ${match.scoreAway}", color = AureomWhite, fontSize = 38.sp, fontWeight = FontWeight.Black)

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = match.teamAway, color = AureomWhite, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Text(text = "Away", color = AureomSoftGrey, fontSize = 11.sp)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                TVBadge(text = "LIVE - ${match.gameClock}", containerColor = Color(0xFFC62828), contentColor = AureomWhite)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Match Stats and Timeline Feed Split Pane
        Row(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = "Live Match Statistics", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(14.dp))
                match.liveStats.forEach { (stat, valStr) ->
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Text(text = stat, color = AureomSoftGrey, fontSize = 13.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(text = valStr, color = AureomWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Divider(color = AureomMediumGrey)
                }
                Spacer(modifier = Modifier.height(20.dp))
                TVButton(nodeId = "sports_stats_tab", shell = shell, text = "START BROADCAST PLAYBACK", icon = Icons.Default.PlayArrow, onClick = {
                    shell.activeMediaTitle = "${match.teamHome} vs ${match.teamAway} (Sports)"
                    shell.activeVideoUrl = match.videoUrl
                    shell.playbackDurationMs = 7200 * 1000L
                    shell.playbackPositionMs = 1500 * 1000L
                    shell.playbackState = "PLAYING"
                    shell.navigateTo(TVScreen.VIDEO_PLAYER)
                })
            }

            Spacer(modifier = Modifier.width(40.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = "Broadcast Timeline", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(14.dp))
                match.eventTimeline.forEach { ev ->
                    Row(modifier = Modifier.padding(vertical = 6.dp)) {
                        Icon(imageVector = Icons.Default.Notifications, contentDescription = null, tint = AureomSilver, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = ev, color = AureomSilver, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// --- STORE FRONT SCREEN ---
@Composable
fun StoreScreen(shell: AureomTVShell) {
    val subs by shell.allSubscriptions.collectAsState(emptyList())
    val channels = shell.repository.getLiveChannels()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp, vertical = 30.dp)
    ) {
        item {
            Text(text = "Aureom Store", color = AureomWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(text = "Subscribe to synthetic channels or rent fictional features", color = AureomSoftGrey, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(30.dp))
        }

        item {
            Text(text = "Available Subscription Passports", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                subs.take(3).forEachIndexed { idx, sub ->
                    val nodeId = "store_rent_plan_${idx + 1}"
                    TVFocusCard(nodeId = nodeId, shell = shell, onClick = {
                        shell.currentFocusedNodeId = nodeId
                        shell.handleRemoteAction("SELECT")
                    }) { isFocused ->
                        Column(modifier = Modifier.padding(16.dp)) {
                            TVBadge(text = if (sub.isSubscribed) "SUBSCRIBED" else "AVAILABLE", containerColor = if(sub.isSubscribed) Color(0xFF2E7D32) else AureomMediumGrey)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(text = sub.name, color = AureomWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = sub.description, color = AureomSoftGrey, fontSize = 11.sp, maxLines = 2)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(text = "\$${sub.priceMonthly} / month", color = AureomWhite, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(30.dp))
        }

        item {
            Text(text = "Live Broadcast Channels", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(14.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(channels.take(4)) { ch ->
                    val nodeId = "store_channel_${ch.id.substringAfter("channel_")}"
                    TVLandscapePoster(
                        nodeId = nodeId,
                        shell = shell,
                        title = ch.name,
                        imageUrl = ch.imageUrl,
                        subtitle = "Live • ${ch.currentProgram}",
                        onClick = {
                            shell.currentFocusedNodeId = nodeId
                            shell.handleRemoteAction("SELECT")
                        }
                    )
                }
            }
        }
    }
}

// --- LIBRARY SCREEN ---
@Composable
fun LibraryScreen(shell: AureomTVShell) {
    val libraryItems by shell.repository.getLibraryItemsFlow(shell.activeProfile?.id ?: "prof_adult_1").collectAsState(emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp, vertical = 30.dp)
    ) {
        Text(text = "Your Personal Library", color = AureomWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(text = "Purchased titles, active rentals, and watchlist items preserved offline-first", color = AureomSoftGrey, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(30.dp))

        if (libraryItems.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Inbox, contentDescription = null, tint = AureomSoftGrey, modifier = Modifier.size(50.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Your Library is Empty", color = AureomWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Add titles to Watchlist or Rent movies in Store", color = AureomSoftGrey, fontSize = 12.sp)
                }
            }
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(libraryItems) { lib ->
                    val movie = shell.repository.getMovieById(lib.titleId)
                    val show = shell.repository.getSeriesById(lib.titleId)
                    val titleText = movie?.title ?: show?.title ?: "Title ID: ${lib.titleId}"
                    val imgUrl = movie?.imageUrl ?: show?.imageUrl ?: "https://picsum.photos/300/450"
                    val nodeId = "library_item_${lib.titleId}"

                    TVPoster(
                        nodeId = nodeId,
                        shell = shell,
                        title = titleText,
                        imageUrl = imgUrl,
                        subtitle = lib.type,
                        onClick = {
                            shell.currentFocusedNodeId = nodeId
                            if (movie != null) {
                                shell.selectedMovieDetail = movie
                                shell.navigateTo(TVScreen.DETAILS_SCREEN)
                            } else if (show != null) {
                                shell.selectedSeriesDetail = show
                                shell.navigateTo(TVScreen.DETAILS_SCREEN)
                            }
                        }
                    )
                }
            }
        }
    }
}

// --- GLOBAL SEARCH WITH KEYBOARD ---
@Composable
fun SearchScreen(shell: AureomTVShell) {
    // Elegant split pane layout: virtual keyboard grid on left, matching results list on right
    val alphabet = listOf("a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z")

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp, vertical = 30.dp)
    ) {
        // Left Keyboard Column
        Column(modifier = Modifier.width(320.dp)) {
            Text(text = "Search Catalogue", color = AureomWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar Text Display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(AureomDeepGraphite)
                    .border(1.dp, AureomSoftGrey.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = if (shell.searchQuery.isEmpty()) "Enter title, actor, or genre..." else shell.searchQuery.uppercase(),
                    color = if (shell.searchQuery.isEmpty()) AureomSoftGrey else AureomWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Visual Grid Keyboard (Rows of 6 keys)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (row in 0..4) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (col in 0..5) {
                            val idx = row * 6 + col
                            if (idx < alphabet.size) {
                                val char = alphabet[idx]
                                val keyNodeId = "search_keyboard_$char"
                                val isFocused = shell.currentFocusedNodeId == keyNodeId

                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isFocused) AureomWhite else AureomMediumGrey)
                                        .clickable {
                                            shell.currentFocusedNodeId = keyNodeId
                                            shell.searchQuery += char
                                            shell.searchResults = shell.repository.search(shell.searchQuery)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = char.uppercase(),
                                        color = if (isFocused) AureomBlack else AureomWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Delete & Clear Actions Row
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(AureomMediumGrey)
                            .clickable {
                                if (shell.searchQuery.isNotEmpty()) {
                                    shell.searchQuery = shell.searchQuery.dropLast(1)
                                    shell.searchResults = shell.repository.search(shell.searchQuery)
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "BACKSPACE", color = AureomWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(AureomMediumGrey)
                            .clickable {
                                shell.searchQuery = ""
                                shell.searchResults = emptyList()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "CLEAR ALL", color = AureomWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(40.dp))

        // Right Results Column
        Column(modifier = Modifier.weight(1f)) {
            Text(text = "Search Results (${shell.searchResults.size})", color = AureomWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(14.dp))

            if (shell.searchResults.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = AureomSoftGrey, modifier = Modifier.size(50.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "Search the Aureom Catalog", color = AureomSoftGrey, fontSize = 13.sp)
                    }
                }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    items(shell.searchResults.take(5)) { item ->
                        val nodeId = "search_result_${item.id}"
                        when (item) {
                            is Movie -> {
                                TVPoster(
                                    nodeId = nodeId,
                                    shell = shell,
                                    title = item.title,
                                    imageUrl = item.imageUrl,
                                    subtitle = "Movie • ${item.genre}",
                                    onClick = {
                                        shell.currentFocusedNodeId = nodeId
                                        shell.selectedMovieDetail = item
                                        shell.navigateTo(TVScreen.DETAILS_SCREEN)
                                    }
                                )
                            }
                            is Series -> {
                                TVPoster(
                                    nodeId = nodeId,
                                    shell = shell,
                                    title = item.title,
                                    imageUrl = item.imageUrl,
                                    subtitle = "Series • ${item.genre}",
                                    onClick = {
                                        shell.currentFocusedNodeId = nodeId
                                        shell.selectedSeriesDetail = item
                                        shell.navigateTo(TVScreen.DETAILS_SCREEN)
                                    }
                                )
                            }
                            is SportEvent -> {
                                TVPoster(
                                    nodeId = nodeId,
                                    shell = shell,
                                    title = "${item.teamHome} vs ${item.teamAway}",
                                    imageUrl = item.bannerUrl,
                                    subtitle = "Sport Event",
                                    onClick = {
                                        shell.currentFocusedNodeId = nodeId
                                        shell.selectedSportDetail = item
                                        shell.navigateTo(TVScreen.LIVE_MATCH)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SYNTHETIC APP STORE ---
@Composable
fun AppStoreScreen(shell: AureomTVShell) {
    val appsList by shell.installedApps.collectAsState()
    val app = appsList.firstOrNull { it.id == "app_4" } // FitTV

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp, vertical = 30.dp)
    ) {
        Text(text = "Aureom Application Store", color = AureomWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(text = "Discover and install interactive modules in the simulator", color = AureomSoftGrey, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(30.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AureomDeepGraphite)
        ) {
            Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(AureomMediumGrey),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.FitnessCenter, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(50.dp))
                }

                Spacer(modifier = Modifier.width(24.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "FitTV: Interactive At-Home Workouts", color = AureomWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Turn your living room into a high-performance wellness gym with professional guided sessions.", color = AureomSoftGrey, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    TVBadge(text = "DEVELOPER: ORCHARD LABS", containerColor = AureomMediumGrey)
                }

                Spacer(modifier = Modifier.width(20.dp))

                TVButton(
                    nodeId = "app_store_install_button",
                    shell = shell,
                    text = if (app?.appState == "INSTALLED") "INSTALLED" else "INSTALL FREE",
                    icon = if (app?.appState == "INSTALLED") Icons.Default.Check else Icons.Default.FileDownload,
                    onClick = {
                        shell.handleRemoteAction("SELECT")
                    }
                )
            }
        }
    }
}

// --- SYSTEM SETTINGS SCREEN ---
@Composable
fun SettingsScreen(shell: AureomTVShell) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp, vertical = 30.dp)
    ) {
        Text(text = "System Settings", color = AureomWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(text = "Orchard TV system control configuration registry", color = AureomSoftGrey, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(30.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            // Options List Column
            Column(
                modifier = Modifier.weight(1.2f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TVSettingsRow(nodeId = "settings_general", shell = shell, title = "General Preferences", value = "Standard", icon = Icons.Default.Settings, onClick = {})
                TVSettingsRow(nodeId = "settings_video", shell = shell, title = "Video Output Resolution", value = "2160p 4K UHD", icon = Icons.Default.Tv, onClick = {})
                TVSettingsRow(nodeId = "settings_audio", shell = shell, title = "Audio Output Route", value = "TV Internal Speakers", icon = Icons.Default.VolumeUp, onClick = {})
                TVSettingsRow(nodeId = "settings_profiles", shell = shell, title = "Profiles (Quick Toggle)", value = shell.activeProfile?.name ?: "Elena", icon = Icons.Default.Person, onClick = {
                    shell.handleRemoteAction("SELECT")
                })
                TVSettingsRow(nodeId = "settings_developer", shell = shell, title = "Developer Diagnostics HUD", value = if (shell.developerModeEnabled) "ON" else "OFF", icon = Icons.Default.Terminal, onClick = {
                    shell.handleRemoteAction("SELECT")
                })
            }

            Spacer(modifier = Modifier.width(40.dp))

            // Explanation panel on right
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(AureomDeepGraphite)
                    .padding(24.dp),
                contentAlignment = Alignment.TopStart
            ) {
                Column {
                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = AureomSoftGrey, modifier = Modifier.size(30.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Selected Parameter Details", color = AureomWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Orchard TV utilizes local DataStore keys to preserve all layout parameters. Adjusting values triggers direct re-rendering cycles in the core operating system shell.",
                        color = AureomSoftGrey,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

// --- CONTROL CENTER DRAWER OVERLAY ---
@Composable
fun ControlCenterPanel(shell: AureomTVShell) {
    AnimatedVisibility(
        visible = shell.isControlCenterOpen,
        enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
        exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable { shell.isControlCenterOpen = false }
        ) {
            Card(
                shape = RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp),
                colors = CardDefaults.cardColors(containerColor = AureomDeepGraphite),
                modifier = Modifier
                    .width(320.dp)
                    .fillMaxHeight()
                    .align(Alignment.CenterEnd)
                    .border(
                        width = 1.dp,
                        color = AureomSoftGrey.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp)
                    )
                    .clickable(enabled = false) {}
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                ) {
                    Text(text = "Control Center", color = AureomWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(24.dp))

                    // Profile summary
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(AureomMediumGrey)
                        ) {
                            AsyncImage(
                                model = shell.activeProfile?.avatarUrl,
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize().clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(text = shell.activeProfile?.name ?: "User", color = AureomWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Access Level: ${shell.activeProfile?.role}", color = AureomSoftGrey, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(30.dp))

                    Text(text = "Quick Controls", color = AureomWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Wi-Fi
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Wifi, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = "Wi-Fi: Aureom_Net", color = AureomWhite, fontSize = 13.sp)
                    }

                    // Bluetooth
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Bluetooth, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = "Bluetooth: Enabled", color = AureomWhite, fontSize = 13.sp)
                    }

                    // Audio Route switcher panel
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(text = "Active Audio Routing", color = AureomWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))

                    shell.audioRoutes.value.forEach { route ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (route.isSelected) AureomMediumGrey else Color.Transparent)
                                .clickable {
                                    shell.showToast("Changed Audio Route: ${route.name}")
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (route.type == "BLUETOOTH") Icons.Default.BluetoothAudio else Icons.Default.Speaker,
                                contentDescription = null,
                                tint = AureomWhite,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = route.name, color = AureomWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.weight(1f))
                            if (route.isSelected) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- DIAGNOSTICS HUD ---
@Composable
fun DeveloperModeOverlay(shell: AureomTVShell) {
    if (shell.developerModeEnabled) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = AureomDeepGraphite.copy(alpha = 0.85f)),
                modifier = Modifier
                    .width(280.dp)
                    .border(1.dp, AureomSoftGrey.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = "DIAGNOSTICS ANALYTICS OVERLAY", color = Color(0xFFFFB300), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(text = "Frame Rate:", color = AureomSoftGrey, fontSize = 11.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(text = "${shell.simulatedFps} FPS", color = Color.Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(text = "CPU Load:", color = AureomSoftGrey, fontSize = 11.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(text = shell.simulatedCpuUsage, color = AureomWhite, fontSize = 11.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(text = "Active Screen:", color = AureomSoftGrey, fontSize = 11.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(text = shell.currentScreen.name, color = AureomSilver, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(text = "Focused Node:", color = AureomSoftGrey, fontSize = 11.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(text = shell.currentFocusedNodeId, color = AureomWhite, fontSize = 10.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(text = "API Latency:", color = AureomSoftGrey, fontSize = 11.sp)
                        Spacer(modifier = Modifier.weight(1f))
                        Text(text = "${shell.simulatedApiLatencyMs} ms", color = AureomSilver, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
