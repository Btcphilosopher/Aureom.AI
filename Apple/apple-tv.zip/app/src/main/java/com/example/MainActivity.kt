package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.shell.AureomTVShell
import com.example.feature.TVAppRouter
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Initialize the unified Aureom TV Shell state coordinator
        val tvShell = AureomTVShell(this)

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = AureomBlack
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        val configuration = LocalConfiguration.current
                        val isWideScreen = configuration.screenWidthDp > 800

                        if (isWideScreen) {
                            // Large widescreen dual-pane layout: Left is TV Display, Right is Remote Simulator
                            Row(modifier = Modifier.fillMaxSize()) {
                                // 1. Active TV Screen Display Pane
                                Box(
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .fillMaxHeight()
                                        .padding(20.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        // 16:9 bounded TV bezel frame with ambient shadow
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .aspectRatio(16f / 9f)
                                                .clip(RoundedCornerShape(16.dp))
                                                .border(4.dp, Color(0xFF1E1E1F), RoundedCornerShape(16.dp))
                                                .background(AureomBlack)
                                        ) {
                                            TVAppRouter(shell = tvShell)
                                        }

                                        Spacer(modifier = Modifier.height(16.dp))

                                        // Simulated TV Hardware specs line
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(imageVector = Icons.Default.Tv, contentDescription = null, tint = AureomSoftGrey, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(text = "AUREOM CINEMA DISPLAY PRO (4K UHD)", color = AureomSoftGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color.Green))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(text = "SIMULATOR ACTIVE", color = Color.Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                // Vertical Divider dividing Workspace
                                Divider(
                                    modifier = Modifier
                                        .width(1.dp)
                                        .fillMaxHeight()
                                        .background(AureomMediumGrey)
                                )

                                // 2. Interactive brushed aluminum Siri-Remote Simulator
                                Box(
                                    modifier = Modifier
                                        .weight(0.7f)
                                        .fillMaxHeight()
                                        .background(AureomDeepGraphite)
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxHeight()
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(text = "SIRI REMOTE", color = AureomWhite, fontSize = 14.sp, fontWeight = FontWeight.Black)
                                            Text(text = "ORCHARD HARMONY CHIP", color = AureomSoftGrey, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Spacer(modifier = Modifier.height(20.dp))

                                        // Physical Remote Body Frame
                                        RemoteControlShell(shell = tvShell)

                                        Spacer(modifier = Modifier.height(20.dp))

                                        // Companion simulator details
                                        Card(
                                            shape = RoundedCornerShape(8.dp),
                                            colors = CardDefaults.cardColors(containerColor = AureomMediumGrey)
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Text(text = "SIMULATOR CONTROLS", color = AureomWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(text = "Touch or click the remote pad above to interact. Direction clicks navigate focused items deterministically.", color = AureomSoftGrey, fontSize = 10.sp, lineHeight = 14.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            // Standard single pane for compact vertical displays
                            Box(modifier = Modifier.fillMaxSize()) {
                                TVAppRouter(shell = tvShell)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- INTERACTIVE PHYSICAL REMOTE SIMULATOR DRAW COMPONENT ---
@Composable
fun RemoteControlShell(shell: AureomTVShell) {
    // Elegant brushed silver capsule mockup
    Box(
        modifier = Modifier
            .width(220.dp)
            .height(440.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFE5E7EB), // Silver light
                        Color(0xFF9CA3AF), // Medium silver
                        Color(0xFF4B5563)  // Dark silver base
                    )
                )
            )
            .border(3.dp, Color(0xFFD1D5DB), RoundedCornerShape(32.dp))
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Apple-style Clickpad (Circular tactile trackpad)
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1F2937)) // Dark slate glass
                    .border(2.dp, Color(0xFF4B5563), CircleShape)
            ) {
                // Directional triggers overlays inside the pad
                // Up Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(45.dp)
                        .align(Alignment.TopCenter)
                        .clickable { shell.handleRemoteAction("UP") }
                        .testTag("remote_up"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.ArrowDropUp, contentDescription = "UP", tint = AureomWhite)
                }

                // Down Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(45.dp)
                        .align(Alignment.BottomCenter)
                        .clickable { shell.handleRemoteAction("DOWN") }
                        .testTag("remote_down"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "DOWN", tint = AureomWhite)
                }

                // Left Button
                Box(
                    modifier = Modifier
                        .width(45.dp)
                        .fillMaxHeight()
                        .align(Alignment.CenterStart)
                        .clickable { shell.handleRemoteAction("LEFT") }
                        .testTag("remote_left"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.ArrowLeft, contentDescription = "LEFT", tint = AureomWhite)
                }

                // Right Button
                Box(
                    modifier = Modifier
                        .width(45.dp)
                        .fillMaxHeight()
                        .align(Alignment.CenterEnd)
                        .clickable { shell.handleRemoteAction("RIGHT") }
                        .testTag("remote_right"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.ArrowRight, contentDescription = "RIGHT", tint = AureomWhite)
                }

                // Center SELECT click button
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF374151))
                        .align(Alignment.Center)
                        .clickable { shell.handleRemoteAction("SELECT") }
                        .testTag("remote_select"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(AureomWhite)
                    )
                }
            }

            // 2. Control Key Grid (BACK, HOME, MENU, PLAY/PAUSE, REW, FF)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Row 1: BACK (Siri `<` arrow) & HOME (TV screen icon)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    RemoteRoundButton(icon = Icons.Default.ChevronLeft, label = "BACK", tag = "remote_back") {
                        shell.handleRemoteAction("BACK")
                    }
                    RemoteRoundButton(icon = Icons.Default.Tv, label = "HOME", tag = "remote_home") {
                        shell.handleRemoteAction("HOME")
                    }
                }

                // Row 2: MENU & PLAY/PAUSE
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    RemoteRoundButton(icon = Icons.Default.Menu, label = "MENU", tag = "remote_menu") {
                        shell.handleRemoteAction("MENU")
                    }
                    RemoteRoundButton(icon = Icons.Default.PlayArrow, label = "PLAY", tag = "remote_play_pause") {
                        shell.handleRemoteAction("PLAY_PAUSE")
                    }
                }

                // Row 3: Seek controls REW & FF
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    RemoteRoundButton(icon = Icons.Default.FastRewind, label = "REW", tag = "remote_rew") {
                        shell.handleRemoteAction("REW")
                    }
                    RemoteRoundButton(icon = Icons.Default.FastForward, label = "FF", tag = "remote_ff") {
                        shell.handleRemoteAction("FF")
                    }
                }
            }

            // Bottom brand logo
            Text(
                text = "A U R E O M",
                color = Color(0xFF374151),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
    }
}

// --- STANDARD SOLID REMOTE BUTTON ---
@Composable
fun RemoteRoundButton(
    icon: ImageVector,
    label: String,
    tag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color(0xFF374151)) // Dark grey glass button
                .clickable { onClick() }
                .testTag(tag),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = AureomWhite,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, color = Color(0xFF374151), fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}
