package com.example.core.model

import java.util.UUID
import kotlin.random.Random

object CatalogDataset {
    val genres = (1..100).map { i ->
        when (i % 8) {
            0 -> "Action & Adventure"
            1 -> "Drama"
            2 -> "Sci-Fi & Fantasy"
            3 -> "Comedy"
            4 -> "Thriller & Suspense"
            5 -> "Documentary"
            6 -> "Kids & Family"
            else -> "Sports & Fitness"
        } + " " + (if (i > 8) "Cat $i" else "").trim()
    }

    val actors = (1..100).map { i ->
        val firstNames = listOf("Elena", "Marcus", "James", "Sophia", "Lucas", "Aria", "Julian", "Olivia", "Victor", "Clara", "Ethan", "Zara")
        val lastNames = listOf("Vance", "Rostova", "Sterling", "Hayes", "Mercer", "Blackwood", "Sloane", "Cross", "Kaelen", "Hawthorne", "Devlin", "Nolan")
        val fn = firstNames[i % firstNames.size]
        val ln = lastNames[(i + 7) % lastNames.size]
        "$fn $ln ($i)"
    }

    val directors = (1..100).map { i ->
        val firstNames = listOf("Christopher", "Sofia", "Denis", "Kathryn", "Quentin", "Greta", "Guillermo", "Jane", "David", "Chloé", "Wes", "Ava")
        val lastNames = listOf("Nolan", "Coppola", "Villeneuve", "Bigelow", "Tarantino", "Gerwig", "del Toro", "Campion", "Fincher", "Zhao", "Anderson", "DuVernay")
        val fn = firstNames[i % firstNames.size]
        val ln = lastNames[(i + 3) % lastNames.size]
        "$fn $ln ($i)"
    }

    val subscriptionPlans = (1..20).map { i ->
        val names = listOf("Aureom Originals Plus", "Orchard Sports Premium", "Kids Play Pass", "Global News Stream", "Retro Channel", "Cinematic Universe", "Fitness Studio", "Live TV Elite", "Independent Cinema", "Indie Music Plus")
        val name = names[i % names.size] + " " + (if (i > 10) "Tier ${i/10 + 1}" else "").trim()
        SubscriptionPlan(
            id = "sub_plan_$i",
            name = name.trim(),
            priceMonthly = 4.99 + (i % 5) * 2.50,
            isSubscribed = i == 1, // Subscribe to the first one by default
            description = "Get full premium high-definition access to all features in $name."
        )
    }

    val apps = (1..50).map { i ->
        val appNames = listOf("Retro Arcade", "FitTV", "SoundFlow", "MoviPlay", "ZenSpace", "NewsFlash", "WeatherSphere", "PlayCast", "PhotoSilo", "ChefChannel", "GameZone", "SpeedRun", "MindFull", "Acoustix", "DocuStream")
        val title = appNames[i % appNames.size] + " " + (if (i > 15) "v$i" else "").trim()
        val pName = "com.aureom.apps." + title.lowercase().replace(" ", "").trim()
        AppItem(
            id = "app_$i",
            title = title.trim(),
            packageName = pName,
            appState = if (i <= 5) "INSTALLED" else "NOT_INSTALLED",
            isSystem = i <= 3,
            logoUrl = "https://picsum.photos/id/${(10 + i) % 100}/180/180",
            description = "Experience the best of digital interactive television with the $title launcher module."
        )
    }

    val movies: List<Movie> = generateMovies()
    val series: List<Series> = generateSeries()
    val seasons: List<Season> = generateSeasons()
    val episodes: List<Episode> = generateEpisodes()
    val sportsEvents: List<SportEvent> = generateSports()
    val liveChannels: List<LiveChannel> = generateLiveChannels()

    private fun generateMovies(): List<Movie> {
        val adjectives = listOf("The Last", "Cities of", "North", "Black", "Sovereign", "Echoes of", "Beneath the", "Shadow over", "Secrets of", "Whispering", "Kingdom of", "Journey to", "Chronicles of", "The Golden", "Forgotten", "Stellar", "Midnight", "Infinite")
        val nouns = listOf("Observatory", "Glass", "Atlantic", "Meridian", "Water", "Sky", "Silence", "Dawn", "Embers", "Tides", "Labyrinth", "Horizon", "Empire", "Mirror", "Prophecy", "Desolation", "Pulse", "Wasteland")
        
        val random = Random(42) // Stable seed
        return (1..500).map { i ->
            val adj = adjectives[i % adjectives.size]
            val noun = nouns[(i + 13) % nouns.size]
            val title = if (i == 1) "The Last Observatory" 
                        else if (i == 2) "Cities of Glass" 
                        else if (i == 3) "North Atlantic" 
                        else if (i == 4) "The Meridian" 
                        else if (i == 5) "Blackwater"
                        else "$adj $noun"
            
            val year = 1995 + (i % 32)
            val runtime = 80 + (i % 120)
            val genre = genres[i % genres.size]
            val rating = when (i % 4) {
                0 -> "G"
                1 -> "PG"
                2 -> "PG-13"
                else -> "R"
            }
            val studio = when (i % 5) {
                0 -> "Aureom Originals"
                1 -> "Orchard Studios"
                2 -> "Deep Blue Films"
                3 -> "Horizon Cine"
                else -> "Sovereign TV"
            }
            // Real openly licensed/test streaming MP4 content for actual video playback demonstration!
            val videoUrl = when (i % 3) {
                0 -> "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                1 -> "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
                else -> "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
            }

            Movie(
                id = "movie_$i",
                title = title,
                description = "An immersive $genre story from $studio, where a $adj $noun unfolds with dramatic consequence. Critically acclaimed for its superb direction, stunning visual artistry, and beautiful cinematic soundtrack.",
                imageUrl = "https://picsum.photos/id/${(i * 3) % 1000}/300/450",
                bannerUrl = "https://picsum.photos/id/${(i * 7) % 1000}/1920/1080",
                year = year,
                runtimeMinutes = runtime,
                rating = rating,
                genre = genre,
                studio = studio,
                ratingPercent = 60 + (i % 40),
                price = 9.99 + (i % 6) * 2.0,
                rentPrice = 2.99 + (i % 3) * 1.0,
                videoUrl = videoUrl,
                director = directors[i % directors.size],
                cast = listOf(actors[i % actors.size], actors[(i + 1) % actors.size], actors[(i + 2) % actors.size])
            )
        }
    }

    private fun generateSeries(): List<Series> {
        val seriesTitles = listOf(
            "Blackwater Chronicles", "The Last Observatory: Redux", "Cities of Glass: Stories", "Sovereign Nights", 
            "Echoes of Horizon", "Beneath the Silence", "Shadow of Deep Blue", "Stellar Pulse", "Labyrinth Empire", "The Golden Embers"
        )
        val random = Random(84)
        return (1..100).map { i ->
            val idx = i - 1
            val title = if (idx < seriesTitles.size) seriesTitles[idx] else "Fictional Series Show $i"
            val genre = genres[(i + 5) % genres.size]
            val studio = when (i % 5) {
                0 -> "Aureom Originals"
                1 -> "Orchard Studios"
                2 -> "Deep Blue Films"
                3 -> "Horizon Cine"
                else -> "Sovereign TV"
            }
            Series(
                id = "series_$i",
                title = title,
                description = "A magnificent episodic drama tracing the complex, high-stakes lives within $title. Full of suspenseful story arcs, award-winning performances, and spectacular modern production design.",
                imageUrl = "https://picsum.photos/id/${(200 + i * 2) % 1000}/300/450",
                bannerUrl = "https://picsum.photos/id/${(300 + i * 4) % 1000}/1920/1080",
                year = 2015 + (i % 12),
                rating = "PG-13",
                genre = genre,
                studio = studio,
                ratingPercent = 70 + (i % 30),
                creator = directors[(i + 15) % directors.size],
                cast = listOf(actors[(i + 4) % actors.size], actors[(i + 5) % actors.size], actors[(i + 6) % actors.size])
            )
        }
    }

    private fun generateSeasons(): List<Season> {
        return series.flatMap { show ->
            listOf(
                Season(id = "season_${show.id}_1", seriesId = show.id, seasonNumber = 1, title = "Season 1"),
                Season(id = "season_${show.id}_2", seriesId = show.id, seasonNumber = 2, title = "Season 2")
            )
        }
    }

    private fun generateEpisodes(): List<Episode> {
        // We need around 1,000 episodes for 100 series
        // With 100 series, 2 seasons each, and 5 episodes per season = 1,000 episodes!
        return series.flatMap { show ->
            val showNum = show.id.substringAfter("series_").toIntOrNull() ?: 1
            listOf(1, 2).flatMap { seasonNum ->
                val seasonId = "season_${show.id}_$seasonNum"
                (1..5).map { epNum ->
                    val globalEpIndex = showNum * 10 + seasonNum * 5 + epNum
                    val videoUrl = when (globalEpIndex % 3) {
                        0 -> "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                        1 -> "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
                        else -> "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
                    }
                    Episode(
                        id = "episode_${show.id}_${seasonNum}_$epNum",
                        seriesId = show.id,
                        seasonId = seasonId,
                        episodeNumber = epNum,
                        title = "Episode $epNum: Convergence of Fate",
                        description = "Tensions rise as plans are set in motion. A surprising revelation in season $seasonNum chapter $epNum shifts alliances in the quest for control.",
                        durationMinutes = 40 + (globalEpIndex % 20),
                        videoUrl = videoUrl,
                        imageUrl = "https://picsum.photos/id/${(400 + globalEpIndex * 5) % 1000}/320/180"
                    )
                }
            }
        }
    }

    private fun generateSports(): List<SportEvent> {
        val leagues = listOf("Aureom Football League", "Orchard Basketball Association", "Global Racers Grand Prix", "Sovereign Rugby Union")
        val teams = listOf("Red Claws", "Golden Wings", "Silver Stars", "Emerald Giants", "Midnight Wolves", "Solar Flares", "Tidal Waves", "Alpine Peaks", "Neon Knights", "Shadow Strikers")
        
        return (1..50).map { i ->
            val league = leagues[i % leagues.size]
            val teamA = teams[i % teams.size]
            val teamB = teams[(i + 3) % teams.size]
            val scoreA = i % 5
            val scoreB = (i + 2) % 5
            val period = when {
                i <= 10 -> "Live"
                i <= 25 -> "Upcoming"
                else -> "Full Time"
            }
            val clock = if (period == "Live") "${10 + i % 80}:21" else "00:00"
            
            // Sports demo video link
            val videoUrl = "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"

            SportEvent(
                id = "sport_$i",
                league = league,
                teamHome = teamA,
                teamAway = teamB,
                scoreHome = scoreA,
                scoreAway = scoreB,
                period = period,
                gameClock = clock,
                videoUrl = videoUrl,
                bannerUrl = "https://picsum.photos/id/${(500 + i * 8) % 1000}/1920/1080",
                liveStats = mapOf(
                    "Possession" to "${45 + i % 11}% - ${55 - i % 11}%",
                    "Shots on Target" to "${i % 6} - ${(i + 1) % 6}",
                    "Fouls" to "${5 + i % 5} - ${4 + (i + 1) % 5}"
                ),
                eventTimeline = listOf(
                    "10' Kick-off under dramatic overcast skies.",
                    "24' Substitution for $teamA due to sudden ankle strain.",
                    "42' Brilliant counter-attack resulting in scoring opportunity."
                )
            )
        }
    }

    private fun generateLiveChannels(): List<LiveChannel> {
        val names = listOf("Aureom News 24", "Orchard Sports HD", "Cinema Premier", "Family Toons", "Aureom Documentaries", "Music Flow TV", "Indie Box", "EcoSphere Live", "Retro Action Channel", "Space Science TV")
        val progs = listOf("Morning World Report", "Championship Arena Live", "Fictional Cinema Showcase", "Saturday Cartoon Jam", "Secrets of the Deep Ocean", "Ultimate Indie Anthems", "Cult Classic Hour", "Climate Watch Special", "Showdown at High Noon", "Voyage of the Voyager")
        
        return (1..30).map { i ->
            val name = names[i % names.size] + " " + (if (i > 10) "Zone ${i/10 + 1}" else "").trim()
            val prog = progs[(i + 2) % progs.size]
            val videoUrl = "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4" // Sci-fi live action stream
            LiveChannel(
                id = "channel_$i",
                name = name.trim(),
                currentProgram = prog,
                programDescription = "Broadcast live around the globe. Stay tuned for uninterrupted programming of high-quality $name entertainment.",
                imageUrl = "https://picsum.photos/id/${(700 + i * 11) % 1000}/320/180",
                bannerUrl = "https://picsum.photos/id/${(800 + i * 13) % 1000}/1920/1080",
                videoUrl = videoUrl
            )
        }
    }
}
