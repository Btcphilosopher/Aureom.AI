package com.example.ui.theme

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.shell.AureomTVShell

@Composable
fun TVFocusCard(
    nodeId: String,
    shell: AureomTVShell,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
    content: @Composable BoxScope.(Boolean) -> Unit
) {
    val isFocused = shell.currentFocusedNodeId == nodeId
    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.06f else 1.0f,
        animationSpec = tween(durationMillis = 200),
        label = "scale"
    )

    Box(
        modifier = modifier
            .scale(scale)
            .testTag(nodeId)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isFocused) AureomMediumGrey else AureomDeepGraphite)
            .border(
                width = if (isFocused) 2.dp else 0.dp,
                color = if (isFocused) AureomWhite else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable {
                shell.currentFocusedNodeId = nodeId
                onClick()
            }
    ) {
        content(isFocused)
    }
}

@Composable
fun TVButton(
    nodeId: String,
    shell: AureomTVShell,
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    isPrimary: Boolean = true,
    onClick: () -> Unit = {}
) {
    val isFocused = shell.currentFocusedNodeId == nodeId
    val scale by animateFloatAsState(targetValue = if (isFocused) 1.08f else 1.0f, label = "btn_scale")

    val bgBrush = if (isFocused) {
        Brush.horizontalGradient(listOf(AureomWhite, AureomSilver))
    } else if (isPrimary) {
        Brush.horizontalGradient(listOf(AureomMediumGrey, AureomDeepGraphite))
    } else {
        Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
    }

    val contentColor = if (isFocused) AureomBlack else AureomWhite

    Row(
        modifier = modifier
            .scale(scale)
            .testTag(nodeId)
            .clip(RoundedCornerShape(8.dp))
            .background(bgBrush)
            .border(
                width = if (!isFocused && !isPrimary) 1.dp else 0.dp,
                color = if (!isFocused && !isPrimary) AureomSoftGrey else Color.Transparent,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable {
                shell.currentFocusedNodeId = nodeId
                onClick()
            }
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = contentColor,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            color = contentColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun TVPoster(
    nodeId: String,
    shell: AureomTVShell,
    title: String,
    imageUrl: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    onClick: () -> Unit = {}
) {
    TVFocusCard(
        nodeId = nodeId,
        shell = shell,
        modifier = modifier.width(150.dp),
        onClick = onClick
    ) { isFocused ->
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .background(AureomMediumGrey)
            ) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                if (isFocused) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.1f))
                    )
                }
            }
            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = title,
                    color = AureomWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        color = AureomSoftGrey,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun TVLandscapePoster(
    nodeId: String,
    shell: AureomTVShell,
    title: String,
    imageUrl: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    progress: Float? = null,
    onClick: () -> Unit = {}
) {
    TVFocusCard(
        nodeId = nodeId,
        shell = shell,
        modifier = modifier.width(260.dp),
        onClick = onClick
    ) { isFocused ->
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(146.dp)
                    .background(AureomMediumGrey)
            ) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                if (progress != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .background(Color.White.copy(alpha = 0.3f))
                            .align(Alignment.BottomStart)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(progress)
                                .fillMaxHeight()
                                .background(AureomSilver)
                        )
                    }
                }
            }
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = title,
                    color = AureomWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        color = AureomSoftGrey,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun TVBadge(
    text: String,
    modifier: Modifier = Modifier,
    containerColor: Color = AureomMediumGrey,
    contentColor: Color = AureomSilver
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(containerColor)
            .padding(horizontal = 6.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = contentColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun TVMetadataLine(
    year: Int,
    runtime: String,
    rating: String,
    genre: String,
    modifier: Modifier = Modifier,
    extraBadges: List<String> = listOf("4K", "HDR", "Atmos")
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = "$year", color = AureomSoftGrey, fontSize = 12.sp)
        Text(text = "  •  ", color = AureomSoftGrey, fontSize = 12.sp)
        Text(text = runtime, color = AureomSoftGrey, fontSize = 12.sp)
        Text(text = "  •  ", color = AureomSoftGrey, fontSize = 12.sp)
        TVBadge(text = rating)
        Text(text = "  •  ", color = AureomSoftGrey, fontSize = 12.sp)
        Text(text = genre, color = AureomSoftGrey, fontSize = 12.sp)
        extraBadges.forEach { b ->
            Spacer(modifier = Modifier.width(8.dp))
            TVBadge(text = b, containerColor = AureomWhite, contentColor = AureomBlack)
        }
    }
}

@Composable
fun TVToast(
    message: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 40.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = AureomDeepGraphite.copy(alpha = 0.9f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier.border(1.dp, AureomSoftGrey.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = AureomWhite,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = message,
                    color = AureomWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun TVSettingsRow(
    nodeId: String,
    shell: AureomTVShell,
    title: String,
    value: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    val isFocused = shell.currentFocusedNodeId == nodeId
    val scale by animateFloatAsState(targetValue = if (isFocused) 1.03f else 1.0f, label = "row_scale")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .testTag(nodeId)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isFocused) AureomMediumGrey else Color.Transparent)
            .border(
                width = if (isFocused) 1.5.dp else 0.dp,
                color = if (isFocused) AureomWhite else Color.Transparent,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable {
                shell.currentFocusedNodeId = nodeId
                onClick()
            }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = AureomWhite, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = title, color = AureomWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.weight(1f))
        Text(text = value, color = AureomSoftGrey, fontSize = 14.sp)
        Spacer(modifier = Modifier.width(8.dp))
        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = AureomSoftGrey, modifier = Modifier.size(16.dp))
    }
}
