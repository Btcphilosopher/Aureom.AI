package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AureomWhite,
    secondary = AureomSoftGrey,
    tertiary = AureomSilver,
    background = AureomBlack,
    surface = AureomDeepGraphite,
    onPrimary = AureomBlack,
    onSecondary = AureomWhite,
    onTertiary = AureomBlack,
    onBackground = AureomWhite,
    onSurface = AureomSilver,
    surfaceVariant = AureomMediumGrey,
    onSurfaceVariant = AureomWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Television is always dark themed for cinema comfort
    dynamicColor: Boolean = false, // Force our custom high-fidelity cinematic dark theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
