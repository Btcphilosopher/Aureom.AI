package com.example.core.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY name ASC")
    fun getAllProfiles(): Flow<List<ProfileEntity>>

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: String): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ProfileEntity)

    @Delete
    suspend fun deleteProfile(profile: ProfileEntity)
}

@Dao
interface WatchProgressDao {
    @Query("SELECT * FROM watch_progress WHERE profileId = :profileId ORDER BY lastPlayedAt DESC")
    fun getWatchProgressForProfile(profileId: String): Flow<List<WatchProgressEntity>>

    @Query("SELECT * FROM watch_progress WHERE profileId = :profileId AND titleId = :titleId LIMIT 1")
    suspend fun getProgressForTitle(profileId: String, titleId: String): WatchProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: WatchProgressEntity)

    @Query("DELETE FROM watch_progress WHERE profileId = :profileId AND titleId = :titleId")
    suspend fun deleteProgress(profileId: String, titleId: String)

    @Query("DELETE FROM watch_progress WHERE profileId = :profileId")
    suspend fun clearHistory(profileId: String)
}

@Dao
interface LibraryItemDao {
    @Query("SELECT * FROM library_items WHERE profileId = :profileId")
    fun getLibraryItemsForProfile(profileId: String): Flow<List<LibraryItemEntity>>

    @Query("SELECT * FROM library_items WHERE profileId = :profileId AND titleId = :titleId AND type = :type LIMIT 1")
    suspend fun getLibraryItem(profileId: String, titleId: String, type: String): LibraryItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLibraryItem(item: LibraryItemEntity)

    @Query("DELETE FROM library_items WHERE profileId = :profileId AND titleId = :titleId AND type = :type")
    suspend fun deleteLibraryItem(profileId: String, titleId: String, type: String)
}

@Dao
interface SubscriptionDao {
    @Query("SELECT * FROM subscriptions")
    fun getAllSubscriptions(): Flow<List<SubscriptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubscription(sub: SubscriptionEntity)

    @Query("UPDATE subscriptions SET isSubscribed = :isSubscribed WHERE id = :id")
    suspend fun updateSubscriptionStatus(id: String, isSubscribed: Boolean)
}

@Dao
interface AppDao {
    @Query("SELECT * FROM installed_apps")
    fun getAllApps(): Flow<List<AppEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: AppEntity)

    @Query("UPDATE installed_apps SET appState = :state WHERE id = :id")
    suspend fun updateAppState(id: String, state: String)
}

@Dao
interface AudioRouteDao {
    @Query("SELECT * FROM audio_routes")
    fun getAllAudioRoutes(): Flow<List<AudioRouteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudioRoute(route: AudioRouteEntity)

    @Query("UPDATE audio_routes SET isSelected = (id = :selectedId)")
    suspend fun selectAudioRoute(selectedId: String)
}

@Dao
interface SettingDao {
    @Query("SELECT * FROM settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): SettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetting(setting: SettingEntity)

    @Query("SELECT * FROM settings")
    fun getAllSettings(): Flow<List<SettingEntity>>
}
