package com.example.core.database

import com.example.core.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class AureomRepository(private val db: AppDatabase) {

    // --- PROFILES ---
    val allProfiles: Flow<List<Profile>> = db.profileDao().getAllProfiles().map { list ->
        if (list.isEmpty()) {
            // Seed default profiles
            val defaultProfiles = listOf(
                ProfileEntity("prof_adult_1", "Elena (Adult)", "https://picsum.photos/id/64/150/150", "Adult", null, false, 0, System.currentTimeMillis(), System.currentTimeMillis(), 1, "ACTIVE"),
                ProfileEntity("prof_teen_2", "Marcus (Teen)", "https://picsum.photos/id/91/150/150", "Teen", null, false, 0, System.currentTimeMillis(), System.currentTimeMillis(), 1, "ACTIVE"),
                ProfileEntity("prof_kids_3", "Kids Fun", "https://picsum.photos/id/342/150/150", "Child", "1234", true, 60, System.currentTimeMillis(), System.currentTimeMillis(), 1, "ACTIVE")
            )
            defaultProfiles.forEach { db.profileDao().insertProfile(it) }
            defaultProfiles.map { it.toDomain() }
        } else {
            list.map { it.toDomain() }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun getProfileById(id: String): Profile? = withContext(Dispatchers.IO) {
        db.profileDao().getProfileById(id)?.toDomain()
    }

    suspend fun insertProfile(profile: Profile) = withContext(Dispatchers.IO) {
        db.profileDao().insertProfile(profile.toEntity())
    }

    suspend fun deleteProfile(profile: Profile) = withContext(Dispatchers.IO) {
        db.profileDao().deleteProfile(profile.toEntity())
    }


    // --- CATALOG ACCESSIBILITY ---
    fun getMovies(): List<Movie> = CatalogDataset.movies
    fun getSeries(): List<Series> = CatalogDataset.series
    fun getSeasons(seriesId: String): List<Season> = CatalogDataset.seasons.filter { it.seriesId == seriesId }
    fun getEpisodes(seriesId: String, seasonNumber: Int): List<Episode> {
        val season = CatalogDataset.seasons.firstOrNull { it.seriesId == seriesId && it.seasonNumber == seasonNumber }
        return if (season != null) {
            CatalogDataset.episodes.filter { it.seasonId == season.id }
        } else {
            emptyList()
        }
    }

    fun getMovieById(id: String): Movie? = CatalogDataset.movies.firstOrNull { it.id == id }
    fun getSeriesById(id: String): Series? = CatalogDataset.series.firstOrNull { it.id == id }
    fun getEpisodeById(id: String): Episode? = CatalogDataset.episodes.firstOrNull { it.id == id }


    // --- WATCH PROGRESS & RESUME ---
    fun getWatchProgressFlow(profileId: String): Flow<List<WatchProgress>> = db.watchProgressDao()
        .getWatchProgressForProfile(profileId)
        .map { list -> list.map { it.toDomain() } }
        .flowOn(Dispatchers.IO)

    suspend fun getProgressForTitle(profileId: String, titleId: String): WatchProgress? = withContext(Dispatchers.IO) {
        db.watchProgressDao().getProgressForTitle(profileId, titleId)?.toDomain()
    }

    suspend fun saveWatchProgress(
        profileId: String,
        titleId: String,
        episodeId: String?,
        positionMs: Long,
        durationMs: Long,
        completed: Boolean = false
    ) = withContext(Dispatchers.IO) {
        val id = "${profileId}_${titleId}"
        val progress = WatchProgressEntity(
            id = id,
            profileId = profileId,
            titleId = titleId,
            episodeId = episodeId,
            positionMs = positionMs,
            durationMs = durationMs,
            lastPlayedAt = System.currentTimeMillis(),
            completed = completed,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            version = 1,
            status = "ACTIVE"
        )
        db.watchProgressDao().insertProgress(progress)
    }

    suspend fun clearHistory(profileId: String) = withContext(Dispatchers.IO) {
        db.watchProgressDao().clearHistory(profileId)
    }


    // --- LIBRARY & WATCHLIST ---
    fun getLibraryItemsFlow(profileId: String): Flow<List<LibraryItem>> = db.libraryItemDao()
        .getLibraryItemsForProfile(profileId)
        .map { list -> list.map { it.toDomain() } }
        .flowOn(Dispatchers.IO)

    suspend fun getLibraryItem(profileId: String, titleId: String, type: String): LibraryItem? = withContext(Dispatchers.IO) {
        db.libraryItemDao().getLibraryItem(profileId, titleId, type)?.toDomain()
    }

    suspend fun addToLibrary(profileId: String, titleId: String, type: String, durationDays: Int? = null) = withContext(Dispatchers.IO) {
        val id = "${profileId}_${titleId}_${type}"
        val expiration = if (durationDays != null) System.currentTimeMillis() + (durationDays * 24 * 3600 * 1000L) else null
        val item = LibraryItemEntity(
            id = id,
            profileId = profileId,
            titleId = titleId,
            type = type,
            purchasedAt = System.currentTimeMillis(),
            expirationTime = expiration,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            version = 1,
            status = "ACTIVE"
        )
        db.libraryItemDao().insertLibraryItem(item)
    }

    suspend fun removeFromLibrary(profileId: String, titleId: String, type: String) = withContext(Dispatchers.IO) {
        db.libraryItemDao().deleteLibraryItem(profileId, titleId, type)
    }


    // --- SUBSCRIPTIONS ---
    val allSubscriptions: Flow<List<SubscriptionPlan>> = db.subscriptionDao().getAllSubscriptions().map { list ->
        if (list.isEmpty()) {
            CatalogDataset.subscriptionPlans.forEach { db.subscriptionDao().insertSubscription(it.toEntity()) }
            CatalogDataset.subscriptionPlans
        } else {
            list.map { it.toDomain() }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun toggleSubscription(id: String, isSubscribed: Boolean) = withContext(Dispatchers.IO) {
        db.subscriptionDao().updateSubscriptionStatus(id, isSubscribed)
    }


    // --- APPS & SYSTEM APPLICATIONS ---
    val allApps: Flow<List<AppItem>> = db.appDao().getAllApps().map { list ->
        if (list.isEmpty()) {
            CatalogDataset.apps.forEach { db.appDao().insertApp(it.toEntity()) }
            CatalogDataset.apps
        } else {
            list.map { it.toDomain() }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun installApp(id: String) = withContext(Dispatchers.IO) {
        db.appDao().updateAppState(id, "INSTALLED")
    }


    // --- AUDIO ROUTES ---
    val allAudioRoutes: Flow<List<AudioRoute>> = db.audioRouteDao().getAllAudioRoutes().map { list ->
        if (list.isEmpty()) {
            val defaults = listOf(
                AudioRouteEntity("route_internal", "TV Internal Speakers", "INTERNAL_SPEAKER", true, System.currentTimeMillis(), System.currentTimeMillis(), 1, "ACTIVE"),
                AudioRouteEntity("route_bluetooth", "Studio Bluetooth Headphones", "BLUETOOTH", false, System.currentTimeMillis(), System.currentTimeMillis(), 1, "ACTIVE"),
                AudioRouteEntity("route_airplay_spk", "Living Room AirPlay Speaker", "AIRPLAY", false, System.currentTimeMillis(), System.currentTimeMillis(), 1, "ACTIVE"),
                AudioRouteEntity("route_hdmi_amp", "Receiver (HDMI eARC)", "HDMI", false, System.currentTimeMillis(), System.currentTimeMillis(), 1, "ACTIVE")
            )
            defaults.forEach { db.audioRouteDao().insertAudioRoute(it) }
            defaults.map { it.toDomain() }
        } else {
            list.map { it.toDomain() }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun selectAudioRoute(id: String) = withContext(Dispatchers.IO) {
        db.audioRouteDao().selectAudioRoute(id)
    }


    // --- SETTINGS (KEY-VALUE STORE) ---
    val allSettings: Flow<Map<String, String>> = db.settingDao().getAllSettings().map { list ->
        list.associate { it.key to it.value }
    }.flowOn(Dispatchers.IO)

    suspend fun getSetting(key: String, defaultValue: String): String = withContext(Dispatchers.IO) {
        db.settingDao().getSetting(key)?.value ?: defaultValue
    }

    suspend fun saveSetting(key: String, value: String) = withContext(Dispatchers.IO) {
        db.settingDao().insertSetting(SettingEntity(key, value))
    }


    // --- SPORTS & LIVE CHANNELS ---
    fun getSportsEvents(): List<SportEvent> = CatalogDataset.sportsEvents
    fun getLiveChannels(): List<LiveChannel> = CatalogDataset.liveChannels


    // --- SEARCH GLOBAL ---
    fun search(query: String): List<BaseEntity> {
        if (query.isBlank()) return emptyList()
        val q = query.lowercase().trim()
        val results = mutableListOf<BaseEntity>()
        
        results.addAll(CatalogDataset.movies.filter { 
            it.title.lowercase().contains(q) || 
            it.genre.lowercase().contains(q) || 
            it.director.lowercase().contains(q) ||
            it.cast.any { actor -> actor.lowercase().contains(q) }
        })
        results.addAll(CatalogDataset.series.filter { 
            it.title.lowercase().contains(q) || 
            it.genre.lowercase().contains(q) ||
            it.cast.any { actor -> actor.lowercase().contains(q) }
        })
        results.addAll(CatalogDataset.sportsEvents.filter { 
            it.teamHome.lowercase().contains(q) || 
            it.teamAway.lowercase().contains(q) || 
            it.league.lowercase().contains(q) 
        })
        return results
    }

    // --- MAPPER EXTENSIONS ---
    private fun ProfileEntity.toDomain() = Profile(id, createdAt, updatedAt, version, status, name, avatarUrl, role, pin, isKidsSafe, screenTimeLimitMinutes)
    private fun Profile.toEntity() = ProfileEntity(id, name, avatarUrl, role, pin, isKidsSafe, screenTimeLimitMinutes, createdAt, updatedAt, version, status)

    private fun WatchProgressEntity.toDomain() = WatchProgress(id, createdAt, updatedAt, version, status, profileId, titleId, episodeId, positionMs, durationMs, lastPlayedAt, completed)
    private fun WatchProgress.toEntity() = WatchProgressEntity(id, profileId, titleId, episodeId, positionMs, durationMs, lastPlayedAt, completed, createdAt, updatedAt, version, status)

    private fun LibraryItemEntity.toDomain() = LibraryItem(id, createdAt, updatedAt, version, status, profileId, titleId, type, purchasedAt, expirationTime)
    private fun LibraryItem.toEntity() = LibraryItemEntity(id, profileId, titleId, type, purchasedAt, expirationTime, createdAt, updatedAt, version, status)

    private fun SubscriptionEntity.toDomain() = SubscriptionPlan(id, createdAt, updatedAt, version, status, name, priceMonthly, isSubscribed, description)
    private fun SubscriptionPlan.toEntity() = SubscriptionEntity(id, name, priceMonthly, isSubscribed, description, createdAt, updatedAt, version, status)

    private fun AppEntity.toDomain() = AppItem(id, createdAt, updatedAt, version, status, title, packageName, appState, isSystem, logoUrl, description)
    private fun AppItem.toEntity() = AppEntity(id, title, packageName, appState, isSystem, logoUrl, description, createdAt, updatedAt, version, status)

    private fun AudioRouteEntity.toDomain() = AudioRoute(id, createdAt, updatedAt, version, status, name, type, isSelected)
    private fun AudioRoute.toEntity() = AudioRouteEntity(id, name, type, isSelected, createdAt, updatedAt, version, status)
}
