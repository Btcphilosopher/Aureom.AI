import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { exec, execSync } from "child_process";
import { createServer as createViteServer } from "vite";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    try {
      const doctorOutput = execSync("python3 scripts/doctor.py", { encoding: "utf-8" });
      res.json({ status: "ok", doctor: doctorOutput });
    } catch (e: any) {
      res.json({ status: "ok", doctor: e.stdout || e.message });
    }
  });

  app.get("/api/actions", (req, res) => {
    const pythonCode = `
import json
from macro_os.engine.registry import ActionRegistry
from macro_os.actions import *
reg = ActionRegistry.get_instance()
print(json.dumps(reg.list_actions()))
`;
    exec(`PYTHONPATH=. python3 -c '${pythonCode}'`, (err, stdout, stderr) => {
      if (err) {
        return res.status(500).json({ error: stderr || err.message });
      }
      try {
        res.json({ actions: JSON.parse(stdout) });
      } catch (e: any) {
        res.status(500).json({ error: "Failed to parse action list JSON" });
      }
    });
  });

  app.get("/api/workflows", (req, res) => {
    const pythonCode = `
import json
from macro_os.storage.database import Database
db = Database()
print(json.dumps(db.list_workflows()))
`;
    exec(`PYTHONPATH=. python3 -c '${pythonCode}'`, (err, stdout, stderr) => {
      if (err) {
        return res.status(500).json({ error: stderr || err.message });
      }
      try {
        res.json({ workflows: JSON.parse(stdout) });
      } catch (e: any) {
        res.status(500).json({ error: "Failed to parse workflows JSON" });
      }
    });
  });

  app.post("/api/workflows", (req, res) => {
    const workflowData = req.body;
    if (!workflowData || !workflowData.id) {
      return res.status(400).json({ error: "Workflow JSON must include 'id'" });
    }

    const tempFile = path.join("/tmp", `wf_${Date.now()}.json`);
    fs.writeFileSync(tempFile, JSON.stringify(workflowData, null, 2));

    const pythonCode = `
import json
from macro_os.workflows.loader import WorkflowLoader
from macro_os.storage.database import Database
wf = WorkflowLoader.load_from_file('${tempFile}')
db = Database()
db.save_workflow(wf.to_dict())
print(json.dumps({"success": True, "workflow": wf.to_dict()}))
`;
    exec(`PYTHONPATH=. python3 -c '${pythonCode}'`, (err, stdout, stderr) => {
      if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
      if (err) {
        return res.status(500).json({ error: stderr || err.message });
      }
      res.json(JSON.parse(stdout));
    });
  });

  app.post("/api/run", (req, res) => {
    const { workflow, variables, dry_run } = req.body;
    if (!workflow) {
      return res.status(400).json({ error: "Workflow payload required" });
    }

    const tempFile = path.join("/tmp", `run_${Date.now()}.json`);
    fs.writeFileSync(tempFile, JSON.stringify(workflow, null, 2));

    const varsJson = JSON.stringify(variables || {});

    const pythonCode = `
import asyncio, json
from macro_os.workflows.loader import WorkflowLoader
from macro_os.engine.engine import MacroEngine
wf = WorkflowLoader.load_from_file('${tempFile}')
engine = MacroEngine()
res = asyncio.run(engine.run_workflow(wf, inputs=${JSON.stringify(variables || {})}, dry_run=${dry_run ? "True" : "False"}))
print(json.dumps(res))
`;

    exec(`PYTHONPATH=. python3 -c '${pythonCode}'`, (err, stdout, stderr) => {
      if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
      if (err) {
        return res.status(500).json({ error: stderr || err.message, raw_stdout: stdout });
      }
      try {
        res.json(JSON.parse(stdout));
      } catch (e: any) {
        res.json({ success: true, raw_output: stdout });
      }
    });
  });

  app.post("/api/validate", (req, res) => {
    const { workflow } = req.body;
    const tempFile = path.join("/tmp", `val_${Date.now()}.json`);
    fs.writeFileSync(tempFile, JSON.stringify(workflow, null, 2));

    const pythonCode = `
import json
from macro_os.workflows.loader import WorkflowLoader
from macro_os.engine.compiler import WorkflowCompiler
wf = WorkflowLoader.load_from_file('${tempFile}')
compiler = WorkflowCompiler()
plan = compiler.compile(wf)
print(json.dumps({"valid": True, "plan": plan.to_dict()}))
`;

    exec(`PYTHONPATH=. python3 -c '${pythonCode}'`, (err, stdout, stderr) => {
      if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
      if (err) {
        return res.status(400).json({ valid: false, error: stderr || err.message });
      }
      res.json(JSON.parse(stdout));
    });
  });

  app.get("/api/executions", (req, res) => {
    const pythonCode = `
import json
from macro_os.storage.database import Database
db = Database()
print(json.dumps(db.list_executions(30)))
`;
    exec(`PYTHONPATH=. python3 -c '${pythonCode}'`, (err, stdout, stderr) => {
      if (err) {
        return res.status(500).json({ error: stderr || err.message });
      }
      try {
        res.json({ executions: JSON.parse(stdout) });
      } catch (e) {
        res.status(500).json({ error: "Failed to parse executions" });
      }
    });
  });

  app.post("/api/stop-all", (req, res) => {
    const pythonCode = `
import json
from macro_os.engine.cancellation import EmergencyStopController
ctrl = EmergencyStopController()
count = ctrl.stop_all("API_EMERGENCY_STOP")
print(json.dumps({"success": True, "stopped_count": count}))
`;
    exec(`PYTHONPATH=. python3 -c '${pythonCode}'`, (err, stdout, stderr) => {
      if (err) return res.status(500).json({ error: stderr || err.message });
      res.json(JSON.parse(stdout));
    });
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[MACRO.OS Server] Operating System Engine active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
