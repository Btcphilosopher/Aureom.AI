# MACRO.OS — High-Powered macOS Automation, Macro & Workflow Engine

MACRO.OS is a professional, production-oriented macOS workflow engine and automation platform designed as a hard execution engine for desktop processes, filesystem orchestration, semantic UI automation, and AppleScript/JXA bridge operations.

## Architecture Highlights
- **Workflow Engine**: DAG compilation with graph cycle detection, validation, topological execution plans.
- **Action Runtime**: Typed `Action` classes supporting `execute()`, `cancel()`, `rollback()`, `dry_run()`.
- **Semantic Automation Engine**: Accessibility ID & role-based UI target resolver with coordinate fallbacks.
- **macOS Automation Bridge**: AppleScript, JXA, NSWorkspace, and System Events coordination.
- **AI Workflow Planner**: Natural language to structured MACRO.OS workflow generation powered by Gemini API.
- **Security & Policy**: Command allowlists, directory sandbox, permission declarations, Keychain secret references.
- **Observability**: ExecutionSpan timelines, structured JSON logs, database audit trail, and performance profiler.

## Quick Start CLI
```bash
macro doctor                       # Run system diagnostic checks
macro validate examples/file_processor.json   # Validate workflow schema & DAG graph
macro simulate examples/file_processor.json   # Perform dry-run side-effect calculation
macro run examples/file_processor.json        # Execute workflow
macro stop --all                   # Emergency stop all active execution jobs
```
