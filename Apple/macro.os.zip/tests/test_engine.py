import asyncio
from macro_os.workflows.loader import WorkflowLoader
from macro_os.workflows.validator import WorkflowValidator
from macro_os.engine.compiler import WorkflowCompiler
from macro_os.engine.engine import MacroEngine
from macro_os.engine.context import ExpressionEngine, ExecutionContext
from macro_os.security.policy import SecurityPolicy
from macro_os.profiler.profiler import WorkflowOptimizer

def test_workflow_validation_and_compilation():
    wf = WorkflowLoader.load_from_file("examples/sample_workflow.json")
    compiler = WorkflowCompiler()
    plan = compiler.compile(wf)
    assert plan.workflow_id == "sample_mac_automation"
    assert len(plan.steps) >= 5

def test_expression_engine():
    vars = {"count": 10, "name": "MACRO.OS", "active": True, "file": {"size": 2000000}}
    assert ExpressionEngine.evaluate("count > 5 and active", vars) == True
    assert ExpressionEngine.evaluate("file.size > 1000000", vars) == True
    assert ExpressionEngine.evaluate("name == 'MACRO.OS'", vars) == True

def test_engine_workflow_execution():
    wf = WorkflowLoader.load_from_file("examples/sample_workflow.json")
    engine = MacroEngine()
    res = asyncio.run(engine.run_workflow(wf))
    if not res.get("success"):
        print("\n[DEBUG EXECUTION FAILURE]:", res)
    assert res["success"] == True
    assert res["action_count"] == 6
    assert "step_outputs" in res

def test_dry_run_simulation():
    wf = WorkflowLoader.load_from_file("examples/sample_workflow.json")
    engine = MacroEngine()
    res = asyncio.run(engine.run_workflow(wf, dry_run=True))
    assert res["dry_run"] == True
    assert len(res["simulated_actions"]) == 6

def test_workflow_optimizer():
    wf = WorkflowLoader.load_from_file("examples/sample_workflow.json")
    proposal = WorkflowOptimizer.analyze_and_propose(wf)
    assert "proposals" in proposal
