import sys
from tests.test_engine import (
    test_workflow_validation_and_compilation,
    test_expression_engine,
    test_engine_workflow_execution,
    test_dry_run_simulation,
    test_workflow_optimizer
)

def run_all():
    print("🧪 Running MACRO.OS Python Test Suite...")
    
    print("  • Testing Workflow Validation and Compilation...")
    test_workflow_validation_and_compilation()
    
    print("  • Testing AST Expression Engine...")
    test_expression_engine()
    
    print("  • Testing Engine Workflow Execution...")
    test_engine_workflow_execution()
    
    print("  • Testing Dry-Run Simulation...")
    test_dry_run_simulation()
    
    print("  • Testing Workflow Optimizer...")
    test_workflow_optimizer()

    print("\n✅ ALL TESTS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    run_all()
