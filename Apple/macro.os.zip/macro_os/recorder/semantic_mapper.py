"""
MACRO.OS Semantic Action Mapper
Transforms raw coordinate interactions into semantic UI Target actions.
"""
from typing import Dict, Any, Optional
from macro_os.recorder.ui_targets import UITarget

class SemanticMapper:
    @staticmethod
    def map_raw_event_to_semantic_target(raw_event: Dict[str, Any]) -> UITarget:
        """
        Maps raw input event (e.g. click at X, Y or keypress) to structured UITarget.
        If accessibility role/title elements exist in payload, attaches them for HIGH/MEDIUM robustness.
        Otherwise falls back to coordinates (LOW robustness).
        """
        app = raw_event.get("application")
        bundle_id = raw_event.get("bundle_id")
        window = raw_event.get("window")
        role = raw_event.get("role")
        title = raw_event.get("title")
        identifier = raw_event.get("identifier")
        x = raw_event.get("x")
        y = raw_event.get("y")

        pos = (x, y) if x is not None and y is not None else None

        return UITarget(
            application=app,
            bundle_id=bundle_id,
            window=window,
            role=role,
            title=title,
            identifier=identifier,
            position=pos
        )
