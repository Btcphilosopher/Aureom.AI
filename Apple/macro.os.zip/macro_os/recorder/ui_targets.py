"""
MACRO.OS UI Target Model & Semantic Target Resolver
Defines accessibility, role, title, window hierarchy, and coordinate targets.
"""
from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict, Any

@dataclass
class UITarget:
    application: Optional[str] = None
    bundle_id: Optional[str] = None
    window: Optional[str] = None
    role: Optional[str] = None  # e.g., "button", "text_field", "checkbox", "menu_item"
    title: Optional[str] = None # e.g., "Export", "Submit", "Save"
    identifier: Optional[str] = None # Accessibility Identifier (highest robustness)
    value: Optional[str] = None
    position: Optional[Tuple[int, int]] = None # Fallback coordinate (X, Y)
    path: Optional[str] = None # AXUIElement hierarchy path

    @property
    def robustness(self) -> str:
        if self.identifier:
            return "HIGH"
        if self.role and self.title:
            return "MEDIUM"
        if self.window and self.role:
            return "MEDIUM"
        if self.position:
            return "LOW"
        return "UNKNOWN"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UITarget':
        pos = data.get("position")
        pos_tuple = tuple(pos) if isinstance(pos, (list, tuple)) and len(pos) == 2 else None
        return cls(
            application=data.get("application"),
            bundle_id=data.get("bundle_id"),
            window=data.get("window"),
            role=data.get("role"),
            title=data.get("title"),
            identifier=data.get("identifier"),
            value=data.get("value"),
            position=pos_tuple,
            path=data.get("path")
        )

    def to_dict(self) -> Dict[str, Any]:
        res = {
            "robustness": self.robustness
        }
        if self.application: res["application"] = self.application
        if self.bundle_id: res["bundle_id"] = self.bundle_id
        if self.window: res["window"] = self.window
        if self.role: res["role"] = self.role
        if self.title: res["title"] = self.title
        if self.identifier: res["identifier"] = self.identifier
        if self.value: res["value"] = self.value
        if self.position: res["position"] = list(self.position)
        if self.path: res["path"] = self.path
        return res
