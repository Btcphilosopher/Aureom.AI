"""
MACRO.OS SQLite Database Layer
Stores workflows, executions, action_results, schedules, audit logs, and crash state.
"""
import sqlite3
import json
import time
from pathlib import Path
from typing import Dict, Any, List, Optional

class Database:
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or (Path.home() / ".macroos" / "macroos.db")
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self):
        with self.get_connection() as conn:
            conn.executescript("""
            CREATE TABLE IF NOT EXISTS workflows (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                version INTEGER DEFAULT 1,
                description TEXT,
                definition_json TEXT NOT NULL,
                created_at REAL,
                updated_at REAL
            );

            CREATE TABLE IF NOT EXISTS executions (
                execution_id TEXT PRIMARY KEY,
                workflow_id TEXT NOT NULL,
                status TEXT NOT NULL, -- QUEUED, RUNNING, COMPLETED, FAILED, CANCELLED, INTERRUPTED
                start_time REAL,
                end_time REAL,
                duration REAL,
                action_count INTEGER DEFAULT 0,
                failure_count INTEGER DEFAULT 0,
                variables_json TEXT,
                error_message TEXT
            );

            CREATE TABLE IF NOT EXISTS action_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                execution_id TEXT NOT NULL,
                node_id TEXT NOT NULL,
                action_type TEXT NOT NULL,
                status TEXT NOT NULL,
                duration REAL,
                stdout TEXT,
                stderr TEXT,
                output_json TEXT,
                error_message TEXT,
                executed_at REAL
            );

            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                workflow_id TEXT,
                execution_id TEXT,
                action TEXT NOT NULL,
                permission TEXT,
                target TEXT,
                result TEXT,
                details_json TEXT
            );

            CREATE TABLE IF NOT EXISTS schedules (
                id TEXT PRIMARY KEY,
                workflow_id TEXT NOT NULL,
                trigger_type TEXT NOT NULL,
                config_json TEXT NOT NULL,
                active INTEGER DEFAULT 1,
                last_run REAL,
                next_run REAL
            );
            """)

    def save_workflow(self, workflow_dict: Dict[str, Any]):
        now = time.time()
        w_id = workflow_dict["id"]
        with self.get_connection() as conn:
            conn.execute("""
            INSERT INTO workflows (id, name, version, description, definition_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                name=excluded.name,
                version=excluded.version,
                description=excluded.description,
                definition_json=excluded.definition_json,
                updated_at=excluded.updated_at
            """, (
                w_id,
                workflow_dict.get("name", "Untitled"),
                workflow_dict.get("version", 1),
                workflow_dict.get("description", ""),
                json.dumps(workflow_dict),
                now,
                now
            ))

    def list_workflows(self) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            rows = conn.execute("SELECT id, name, version, description, updated_at FROM workflows ORDER BY updated_at DESC").fetchall()
            return [dict(r) for r in rows]

    def get_workflow(self, workflow_id: str) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            row = conn.execute("SELECT definition_json FROM workflows WHERE id = ?", (workflow_id,)).fetchone()
            if row:
                return json.loads(row["definition_json"])
            return None

    def record_execution_start(self, execution_id: str, workflow_id: str, variables: Dict[str, Any]):
        with self.get_connection() as conn:
            conn.execute("""
            INSERT INTO executions (execution_id, workflow_id, status, start_time, variables_json)
            VALUES (?, ?, 'RUNNING', ?, ?)
            """, (execution_id, workflow_id, time.time(), json.dumps(variables)))

    def record_execution_finish(self, execution_id: str, status: str, duration: float, action_count: int, failure_count: int, error_msg: Optional[str] = None):
        with self.get_connection() as conn:
            conn.execute("""
            UPDATE executions
            SET status = ?, end_time = ?, duration = ?, action_count = ?, failure_count = ?, error_message = ?
            WHERE execution_id = ?
            """, (status, time.time(), duration, action_count, failure_count, error_msg, execution_id))

    def record_action_result(self, execution_id: str, node_id: str, action_type: str, status: str, duration: float, output: Dict[str, Any], error: Optional[str] = None):
        with self.get_connection() as conn:
            conn.execute("""
            INSERT INTO action_results (execution_id, node_id, action_type, status, duration, output_json, error_message, executed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                execution_id, node_id, action_type, status, duration,
                json.dumps(output), error, time.time()
            ))

    def list_executions(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM executions ORDER BY start_time DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]

    def get_execution_details(self, execution_id: str) -> Optional[Dict[str, Any]]:
        with self.get_connection() as conn:
            exec_row = conn.execute("SELECT * FROM executions WHERE execution_id = ?", (execution_id,)).fetchone()
            if not exec_row:
                return None
            res = dict(exec_row)
            action_rows = conn.execute("SELECT * FROM action_results WHERE execution_id = ? ORDER BY executed_at ASC", (execution_id,)).fetchall()
            res["action_results"] = [dict(a) for a in action_rows]
            return res

    def recover_crashes(self):
        """CRASH RECOVERY §88: On restart, detect incomplete executions and mark INTERRUPTED."""
        with self.get_connection() as conn:
            conn.execute("UPDATE executions SET status = 'INTERRUPTED' WHERE status = 'RUNNING'")
