from macro_os.storage.database import Database

__all__ = ["Database"]
