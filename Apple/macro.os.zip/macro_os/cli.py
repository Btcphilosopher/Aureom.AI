"""
MACRO.OS Command Line Interface (CLI)
Executable interface for running, compiling, testing, profiling, recording, and managing MACRO.OS workflows.
"""
import sys
import asyncio
import json
import argparse
from pathlib import Path
from macro_os.workflows.loader import WorkflowLoader
from macro_os.workflows.validator import WorkflowValidator
from macro_os.engine.compiler import WorkflowCompiler
from macro_os.engine.engine import MacroEngine
from macro_os.profiler.profiler import WorkflowOptimizer
from macro_os.testing.engine import WorkflowTestRunner
from macro_os.recorder.recorder import MacroRecorder
from macro_os.storage.database import Database

def main():
    parser = argparse.ArgumentParser(prog="macroos", description="MACRO.OS Automation Engine CLI")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # run
    run_parser = subparsers.add_parser("run", help="Execute a workflow JSON file")
    run_parser.add_argument("file", help="Path to workflow JSON file")
    run_parser.add_argument("--vars", help="JSON string or file of input variables")
    run_parser.add_argument("--dry-run", action="store_true", help="Simulate execution without side effects")

    # validate
    val_parser = subparsers.add_parser("validate", help="Validate a workflow schema")
    val_parser.add_argument("file", help="Path to workflow JSON file")

    # dry-run
    dry_parser = subparsers.add_parser("dry-run", help="Simulate workflow execution")
    dry_parser.add_argument("file", help="Path to workflow JSON file")

    # test
    test_parser = subparsers.add_parser("test", help="Run automated test suite on workflow")
    test_parser.add_argument("file", help="Path to workflow JSON file")

    # list
    subparsers.add_parser("list", help="List stored workflows and execution logs")

    # optimize
    opt_parser = subparsers.add_parser("optimize", help="Generate optimization proposal for workflow")
    opt_parser.add_argument("file", help="Path to workflow JSON file")

    # stop-all
    subparsers.add_parser("stop-all", help="EMERGENCY STOP: Cancel all active workflows immediately")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    db = Database()
    engine = MacroEngine(db=db)

    if args.command == "run":
        wf = WorkflowLoader.load_from_file(args.file)
        inputs = json.loads(args.vars) if args.vars else {}
        print(f"🚀 [MACRO.OS] Executing Workflow '{wf.name}' ({wf.id})...")
        res = asyncio.run(engine.run_workflow(wf, inputs=inputs, dry_run=args.dry_run))
        print(json.dumps(res, indent=2))

    elif args.command == "validate":
        wf = WorkflowLoader.load_from_file(args.file)
        compiler = WorkflowCompiler()
        plan = compiler.compile(wf)
        print(f"✅ Workflow '{wf.name}' is VALID.")
        print(f"📊 Execution Plan ({len(plan.steps)} steps):")
        print(json.dumps(plan.to_dict(), indent=2))

    elif args.command == "dry-run":
        wf = WorkflowLoader.load_from_file(args.file)
        res = asyncio.run(engine.run_workflow(wf, dry_run=True))
        print(json.dumps(res, indent=2))

    elif args.command == "test":
        wf = WorkflowLoader.load_from_file(args.file)
        runner = WorkflowTestRunner(engine=engine)
        test_res = asyncio.run(runner.run_test(wf))
        print(json.dumps(test_res, indent=2))

    elif args.command == "list":
        wfs = db.list_workflows()
        print(f"📁 Stored Workflows ({len(wfs)}):")
        for w in wfs:
            print(f"  • {w['id']} | {w['name']} (v{w['version']}) - Updated: {w['updated_at']}")

    elif args.command == "optimize":
        wf = WorkflowLoader.load_from_file(args.file)
        proposal = WorkflowOptimizer.analyze_and_propose(wf)
        print(json.dumps(proposal, indent=2))

    elif args.command == "stop-all":
        count = engine.kill_switch.stop_all("USER_CLI_STOP_ALL")
        print(f"🛑 [EMERGENCY STOP] Stopped {count} running workflows.")

if __name__ == "__main__":
    main()
