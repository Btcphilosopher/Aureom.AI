"""
MACRO.OS Workflow Testing Engine
Automated testing framework for workflow assertion, action mocking, and dry-run verification.
"""
from typing import Dict, Any, List, Optional
from macro_os.workflows.schema import WorkflowSchema
from macro_os.engine.engine import MacroEngine

class WorkflowTestRunner:
    def __init__(self, engine: Optional[MacroEngine] = None):
        self.engine = engine or MacroEngine()

    async def run_test(
        self,
        schema: WorkflowSchema,
        inputs: Dict[str, Any] = None,
        expected_outputs: Dict[str, Any] = None,
        max_duration_seconds: float = 30.0
    ) -> Dict[str, Any]:
        """Runs workflow and asserts step outputs, success state, and execution time bounds."""
        res = await self.engine.run_workflow(schema, inputs=inputs)

        assertions = []
        all_passed = True

        # Assert workflow success
        if res.get("success"):
            assertions.append({"test": "Workflow Execution Status", "passed": True, "message": "Workflow executed successfully"})
        else:
            assertions.append({"test": "Workflow Execution Status", "passed": False, "message": f"Execution failed: {res.get('error')}"})
            all_passed = False

        # Assert time bound
        duration = res.get("duration", 0)
        if duration <= max_duration_seconds:
            assertions.append({"test": "Performance Threshold", "passed": True, "message": f"Execution time {duration}s <= {max_duration_seconds}s"})
        else:
            assertions.append({"test": "Performance Threshold", "passed": False, "message": f"Execution time {duration}s exceeded max {max_duration_seconds}s"})
            all_passed = False

        # Assert expected outputs
        if expected_outputs:
            step_outputs = res.get("step_outputs", {})
            for step_id, expected_val in expected_outputs.items():
                actual_val = step_outputs.get(step_id)
                if actual_val == expected_val:
                    assertions.append({"test": f"Step Output '{step_id}'", "passed": True, "value": actual_val})
                else:
                    assertions.append({"test": f"Step Output '{step_id}'", "passed": False, "expected": expected_val, "actual": actual_val})
                    all_passed = False

        return {
            "passed": all_passed,
            "workflow_id": schema.id,
            "duration": duration,
            "assertions": assertions
        }
