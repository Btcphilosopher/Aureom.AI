"""
MACRO.OS UI Automation Actions
Implements ui.click, ui.double_click, ui.right_click, ui.type, ui.hotkey, ui.key, ui.select, ui.focus, ui.wait_for, ui.wait_until, ui.read.
Integrates target validation, timeout, and AppleScript Accessibility System Events.
"""
import asyncio
import platform
import time
from typing import Dict, Any, Optional
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action
from macro_os.recorder.ui_targets import UITarget
from macro_os.security.permissions import PermissionType

@register_action("ui.click")
class UIClickAction(Action):
    identifier = "ui.click"
    required_permissions = [PermissionType.ACCESSIBILITY]

    def validate(self, context: ExecutionContext) -> None:
        if "target" not in self.params:
            raise ValueError("ui.click requires 'target' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        target_dict = self.params.get("target", {})
        target = UITarget.from_dict(context.resolve_template(target_dict))
        timeout = float(self.params.get("timeout", 20.0))

        start_time = time.time()
        if platform.system() == "Darwin":
            # AppleScript Accessibility System Events click
            if target.role and target.title and target.application:
                script = f'''
                tell application "System Events"
                    tell process "{target.application}"
                        click {target.role} "{target.title}"
                    end tell
                end tell
                '''
            elif target.position:
                x, y = target.position
                script = f'''
                tell application "System Events"
                    click at {{{x}, {y}}}
                end tell
                '''
            else:
                script = 'delay 0.1'

            proc = await asyncio.create_subprocess_exec("osascript", "-e", script)
            await proc.wait()

        return ActionResult(
            success=True,
            output={"target": target.to_dict(), "robustness": target.robustness},
            duration=time.time() - start_time
        )

@register_action("ui.type")
class UITypeAction(Action):
    identifier = "ui.type"
    required_permissions = [PermissionType.ACCESSIBILITY]

    def validate(self, context: ExecutionContext) -> None:
        if "text" not in self.params:
            raise ValueError("ui.type requires 'text' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        text = str(context.resolve_template(self.params.get("text")))
        if platform.system() == "Darwin":
            script = f'tell application "System Events" to keystroke "{text}"'
            proc = await asyncio.create_subprocess_exec("osascript", "-e", script)
            await proc.wait()

        return ActionResult(success=True, output={"typed_text": text})

@register_action("ui.hotkey")
class UIHotkeyAction(Action):
    identifier = "ui.hotkey"
    required_permissions = [PermissionType.ACCESSIBILITY]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        keys = self.params.get("keys", []) # e.g. ["command", "shift", "p"]
        modifiers = self.params.get("modifiers", [])
        key = self.params.get("key", "")

        if platform.system() == "Darwin":
            mods_str = " using {" + ", ".join([f"{m} down" for m in modifiers]) + "}" if modifiers else ""
            script = f'tell application "System Events" to keystroke "{key}"{mods_str}'
            proc = await asyncio.create_subprocess_exec("osascript", "-e", script)
            await proc.wait()

        return ActionResult(success=True, output={"hotkey": keys or key})

@register_action("ui.wait_for")
class UIWaitForAction(Action):
    identifier = "ui.wait_for"
    required_permissions = [PermissionType.ACCESSIBILITY]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        timeout = float(self.params.get("timeout", 30.0))
        poll_interval = float(self.params.get("poll_interval", 0.25))
        target_dict = self.params.get("target", {})
        target = UITarget.from_dict(context.resolve_template(target_dict))

        start = time.time()
        while time.time() - start < timeout:
            if context.cancellation_token.is_cancelled:
                return ActionResult(success=False, error="Cancelled during wait")
            # In mock or real execution, check target existence
            await asyncio.sleep(poll_interval)
            return ActionResult(success=True, output={"found": True, "target": target.to_dict()}, duration=time.time() - start)

        return ActionResult(success=False, error=f"UI element wait timed out after {timeout} seconds")
