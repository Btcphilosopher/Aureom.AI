"""
MACRO.OS AppleScript Engine
Executes AppleScript via osascript with safe argument array passing.
"""
import asyncio
import time
import platform
from typing import Dict, Any, List
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action
from macro_os.security.permissions import PermissionType

@register_action("applescript.execute")
class AppleScriptAction(Action):
    identifier = "applescript.execute"
    required_permissions = [PermissionType.APPLICATION_CONTROL, PermissionType.PROCESS_EXECUTION]

    def validate(self, context: ExecutionContext) -> None:
        if "script" not in self.params and "script_path" not in self.params:
            raise ValueError("applescript.execute requires 'script' or 'script_path' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        script = self.params.get("script")
        script_path = self.params.get("script_path")
        args = [str(context.resolve_template(a)) for a in self.params.get("args", [])]
        timeout = float(self.params.get("timeout", 30.0))

        # Check platform
        if platform.system() != "Darwin":
            # Container / non-macOS runtime mock mode
            return ActionResult(
                success=True,
                output={
                    "stdout": "[MOCK_APPLESCRIPT] Execution completed (Emulated on non-macOS platform)",
                    "stderr": "",
                    "return_code": 0,
                    "mock": True
                },
                duration=0.01
            )

        start_time = time.time()
        try:
            if script:
                resolved_script = context.resolve_template(script)
                cmd = ["osascript", "-e", resolved_script] + args
            else:
                resolved_path = context.resolve_template(script_path)
                cmd = ["osascript", resolved_path] + args

            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            duration = time.time() - start_time

            stdout = stdout_b.decode("utf-8", errors="replace").strip()
            stderr = stderr_b.decode("utf-8", errors="replace").strip()
            rc = proc.returncode

            return ActionResult(
                success=(rc == 0),
                output={"stdout": stdout, "stderr": stderr, "return_code": rc, "result": stdout},
                duration=duration,
                error=stderr if rc != 0 else None
            )
        except asyncio.TimeoutError:
            return ActionResult(success=False, error=f"AppleScript execution timed out after {timeout} seconds")
        except Exception as e:
            return ActionResult(success=False, error=f"AppleScript Error: {str(e)}")

    async def dry_run(self, context: ExecutionContext) -> Dict[str, Any]:
        return {"action": self.identifier, "would_modify": True, "description": "Would run AppleScript"}
