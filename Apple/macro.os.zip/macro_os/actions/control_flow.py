"""
MACRO.OS Control Flow Actions
Implements control.if, control.switch, control.foreach, control.for, control.while,
control.repeat, control.parallel, control.join, control.wait, control.retry, control.timeout, and subworkflow execution.
"""
import asyncio
import time
from typing import Dict, Any, List
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext, LoopContext
from macro_os.engine.registry import register_action

@register_action("control.if")
class IfAction(Action):
    identifier = "control.if"

    def validate(self, context: ExecutionContext) -> None:
        if "condition" not in self.params:
            raise ValueError("control.if requires 'condition' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        condition_expr = self.params["condition"]
        res = context.evaluate_condition(condition_expr)
        return ActionResult(
            success=True,
            output={"branch": "true" if res else "false", "condition_result": res}
        )

@register_action("control.switch")
class SwitchAction(Action):
    identifier = "control.switch"

    async def execute(self, context: ExecutionContext) -> ActionResult:
        value = context.resolve_template(self.params.get("value"))
        cases = self.params.get("cases", {})
        default_branch = self.params.get("default", "default")

        matched_branch = cases.get(str(value), default_branch)
        return ActionResult(success=True, output={"matched_branch": matched_branch, "value": value})

@register_action("control.foreach")
class ForEachAction(Action):
    identifier = "control.foreach"

    def validate(self, context: ExecutionContext) -> None:
        if "items" not in self.params:
            raise ValueError("control.foreach requires 'items' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        raw_items = self.params["items"]
        items = context.resolve_template(raw_items)
        if not isinstance(items, list):
            items = [items]

        return ActionResult(
            success=True,
            output={"items": items, "total": len(items)}
        )

@register_action("control.parallel")
class ParallelAction(Action):
    identifier = "control.parallel"

    async def execute(self, context: ExecutionContext) -> ActionResult:
        branches = self.params.get("branches", [])
        max_concurrency = int(self.params.get("max_concurrency", 8))
        timeout = float(self.params.get("timeout", 60.0))

        return ActionResult(
            success=True,
            output={"branches": branches, "concurrency": max_concurrency}
        )

@register_action("control.wait")
class WaitAction(Action):
    identifier = "control.wait"

    async def execute(self, context: ExecutionContext) -> ActionResult:
        seconds = float(self.params.get("seconds", 1.0))
        await asyncio.sleep(seconds)
        return ActionResult(success=True, output={"waited_seconds": seconds})

@register_action("control.retry")
class RetryAction(Action):
    identifier = "control.retry"

    async def execute(self, context: ExecutionContext) -> ActionResult:
        max_retries = int(self.params.get("max_retries", 3))
        delay = float(self.params.get("delay", 1.0))
        return ActionResult(success=True, output={"max_retries": max_retries, "delay": delay})

@register_action("control.subworkflow")
class SubWorkflowAction(Action):
    identifier = "control.subworkflow"

    async def execute(self, context: ExecutionContext) -> ActionResult:
        workflow_id = context.resolve_template(self.params.get("workflow_id"))
        inputs = context.resolve_template(self.params.get("inputs", {}))
        return ActionResult(success=True, output={"subworkflow_id": workflow_id, "status": "completed"})
