"""
MACRO.OS JavaScript for Automation (JXA) Engine
Executes JXA scripts via osascript -l JavaScript with safe argument arrays.
"""
import asyncio
import time
import platform
from typing import Dict, Any
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action
from macro_os.security.permissions import PermissionType

@register_action("jxa.execute")
class JXAAction(Action):
    identifier = "jxa.execute"
    required_permissions = [PermissionType.APPLICATION_CONTROL, PermissionType.PROCESS_EXECUTION]

    def validate(self, context: ExecutionContext) -> None:
        if "script" not in self.params and "script_path" not in self.params:
            raise ValueError("jxa.execute requires 'script' or 'script_path' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        script = self.params.get("script")
        script_path = self.params.get("script_path")
        args = [str(context.resolve_template(a)) for a in self.params.get("args", [])]
        timeout = float(self.params.get("timeout", 30.0))

        if platform.system() != "Darwin":
            return ActionResult(
                success=True,
                output={
                    "stdout": "[MOCK_JXA] JavaScript for Automation completed (Emulated)",
                    "stderr": "",
                    "return_code": 0,
                    "mock": True
                },
                duration=0.01
            )

        start_time = time.time()
        try:
            if script:
                resolved_script = context.resolve_template(script)
                cmd = ["osascript", "-l", "JavaScript", "-e", resolved_script] + args
            else:
                resolved_path = context.resolve_template(script_path)
                cmd = ["osascript", "-l", "JavaScript", resolved_path] + args

            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            duration = time.time() - start_time

            stdout = stdout_b.decode("utf-8", errors="replace").strip()
            stderr = stderr_b.decode("utf-8", errors="replace").strip()
            rc = proc.returncode

            return ActionResult(
                success=(rc == 0),
                output={"stdout": stdout, "stderr": stderr, "return_code": rc, "result": stdout},
                duration=duration,
                error=stderr if rc != 0 else None
            )
        except asyncio.TimeoutError:
            return ActionResult(success=False, error=f"JXA execution timed out after {timeout} seconds")
        except Exception as e:
            return ActionResult(success=False, error=f"JXA Error: {str(e)}")
