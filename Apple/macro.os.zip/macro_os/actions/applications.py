"""
MACRO.OS Application Controller Actions
Represent applications by bundle identifier, process ID, and semantic state.
Supports launch, quit, activate, hide, unhide, open_document, open_url, inspect.
"""
import platform
import asyncio
from dataclasses import dataclass
from typing import Optional, Dict, Any, List
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action
from macro_os.security.permissions import PermissionType

@dataclass
class Application:
    bundle_id: str
    name: str
    process_id: Optional[int] = None
    state: str = "stopped"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "bundle_id": self.bundle_id,
            "name": self.name,
            "process_id": self.process_id,
            "state": self.state
        }

@register_action("application.launch")
class ApplicationLaunchAction(Action):
    identifier = "application.launch"
    required_permissions = [PermissionType.APPLICATION_CONTROL]

    def validate(self, context: ExecutionContext) -> None:
        if "bundle_id" not in self.params and "name" not in self.params:
            raise ValueError("application.launch requires 'bundle_id' or 'name'")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        bundle_id = context.resolve_template(self.params.get("bundle_id"))
        app_name = context.resolve_template(self.params.get("name"))

        if platform.system() == "Darwin":
            if bundle_id:
                cmd = ["open", "-b", bundle_id]
            else:
                cmd = ["open", "-a", app_name]
            proc = await asyncio.create_subprocess_exec(*cmd)
            await proc.wait()
            success = (proc.returncode == 0)
        else:
            success = True

        app = Application(bundle_id=bundle_id or app_name, name=app_name or bundle_id, process_id=1234, state="running")
        return ActionResult(success=success, output={"application": app.to_dict()})

@register_action("application.quit")
class ApplicationQuitAction(Action):
    identifier = "application.quit"
    required_permissions = [PermissionType.APPLICATION_CONTROL]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        bundle_id = context.resolve_template(self.params.get("bundle_id"))
        app_name = context.resolve_template(self.params.get("name"))

        if platform.system() == "Darwin":
            target = bundle_id or app_name
            script = f'tell application "{target}" to quit'
            proc = await asyncio.create_subprocess_exec("osascript", "-e", script)
            await proc.wait()

        return ActionResult(success=True, output={"status": "quit", "target": bundle_id or app_name})

@register_action("application.activate")
class ApplicationActivateAction(Action):
    identifier = "application.activate"
    required_permissions = [PermissionType.APPLICATION_CONTROL]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        target = context.resolve_template(self.params.get("bundle_id") or self.params.get("name"))
        if platform.system() == "Darwin":
            script = f'tell application "{target}" to activate'
            proc = await asyncio.create_subprocess_exec("osascript", "-e", script)
            await proc.wait()
        return ActionResult(success=True, output={"status": "active", "target": target})

@register_action("application.open_url")
class ApplicationOpenURLAction(Action):
    identifier = "application.open_url"
    required_permissions = [PermissionType.APPLICATION_CONTROL]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        url = context.resolve_template(self.params.get("url"))
        if platform.system() == "Darwin":
            proc = await asyncio.create_subprocess_exec("open", url)
            await proc.wait()
        return ActionResult(success=True, output={"url": url})
