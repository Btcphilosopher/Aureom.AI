"""
MACRO.OS Notification Engine
User notification alerts with title, body, sound, workflow execution context.
"""
import platform
import asyncio
from typing import Dict, Any
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action

@register_action("notification.send")
class NotificationSendAction(Action):
    identifier = "notification.send"

    async def execute(self, context: ExecutionContext) -> ActionResult:
        title = context.resolve_template(self.params.get("title", "MACRO.OS Notification"))
        body = context.resolve_template(self.params.get("body", "Workflow action completed."))
        sound = self.params.get("sound", "default")

        if platform.system() == "Darwin":
            script = f'display notification "{body}" with title "{title}" sound name "{sound}"'
            proc = await asyncio.create_subprocess_exec("osascript", "-e", script)
            await proc.wait()

        return ActionResult(success=True, output={"title": title, "body": body})
