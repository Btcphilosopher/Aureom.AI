"""
MACRO.OS Network Actions
HTTP requests, downloads, webhooks with opt-in network permissions, domain allowlist, TLS validation.
"""
import urllib.request
import urllib.parse
import json
import time
from typing import Dict, Any
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action
from macro_os.security.permissions import PermissionType

@register_action("network.http")
class HTTPAction(Action):
    identifier = "network.http"
    required_permissions = [PermissionType.NETWORK]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        url = context.resolve_template(self.params.get("url"))
        method = self.params.get("method", "GET").upper()
        headers = context.resolve_template(self.params.get("headers", {}))
        body = context.resolve_template(self.params.get("body"))
        timeout = float(self.params.get("timeout", 15.0))

        start = time.time()
        try:
            req_data = None
            if body:
                if isinstance(body, dict):
                    req_data = json.dumps(body).encode("utf-8")
                    headers["Content-Type"] = "application/json"
                else:
                    req_data = str(body).encode("utf-8")

            req = urllib.request.Request(url, data=req_data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=timeout) as response:
                resp_bytes = response.read()
                resp_text = resp_bytes.decode("utf-8", errors="replace")
                status_code = response.status

                try:
                    resp_data = json.loads(resp_text)
                except Exception:
                    resp_data = resp_text

                return ActionResult(
                    success=(200 <= status_code < 300),
                    output={"status_code": status_code, "response": resp_data},
                    duration=time.time() - start
                )
        except Exception as e:
            return ActionResult(success=False, error=f"HTTP Request Failed: {str(e)}")
