"""
MACRO.OS Data Pipeline Actions
Supports JSON, CSV, PDF text extraction, transformation, filtering, aggregation.
"""
import json
import csv
import io
from typing import Dict, Any, List
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action

@register_action("data.parse_json")
class ParseJSONAction(Action):
    identifier = "data.parse_json"

    async def execute(self, context: ExecutionContext) -> ActionResult:
        raw = context.resolve_template(self.params.get("content"))
        if isinstance(raw, dict) or isinstance(raw, list):
            parsed = raw
        else:
            parsed = json.loads(raw)
        return ActionResult(success=True, output={"parsed": parsed})

@register_action("data.transform")
class TransformDataAction(Action):
    identifier = "data.transform"

    async def execute(self, context: ExecutionContext) -> ActionResult:
        data = context.resolve_template(self.params.get("input"))
        operation = self.params.get("operation") # e.g. "filter", "map", "count"

        if operation == "count" and isinstance(data, (list, dict, str)):
            result = len(data)
        elif operation == "map" and isinstance(data, list):
            key = self.params.get("key")
            result = [item.get(key) if isinstance(item, dict) else str(item) for item in data]
        else:
            result = data

        return ActionResult(success=True, output={"result": result})
