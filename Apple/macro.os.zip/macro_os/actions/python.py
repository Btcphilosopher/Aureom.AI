"""
MACRO.OS Python Engine
Executes Python scripts, inline code blocks, or functions with full ExecutionContext access.
"""
import asyncio
import time
import sys
import io
import contextlib
from typing import Dict, Any
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action
from macro_os.security.permissions import PermissionType

@register_action("python.execute")
class PythonAction(Action):
    identifier = "python.execute"
    required_permissions = [PermissionType.PROCESS_EXECUTION]

    def validate(self, context: ExecutionContext) -> None:
        if "code" not in self.params and "script_path" not in self.params:
            raise ValueError("python.execute requires 'code' or 'script_path' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        code = self.params.get("code")
        script_path = self.params.get("script_path")
        timeout = float(self.params.get("timeout", 60.0))

        start_time = time.time()
        stdout_buf = io.StringIO()
        stderr_buf = io.StringIO()

        scope = {
            "context": context,
            "variables": context.variables,
            "step_outputs": context.step_outputs,
            "result": {}
        }

        try:
            if code:
                resolved_code = context.resolve_template(code)
                with contextlib.redirect_stdout(stdout_buf), contextlib.redirect_stderr(stderr_buf):
                    exec(resolved_code, scope)
                duration = time.time() - start_time
                return ActionResult(
                    success=True,
                    output={
                        "stdout": stdout_buf.getvalue(),
                        "stderr": stderr_buf.getvalue(),
                        "result": scope.get("result", {})
                    },
                    duration=duration
                )
            elif script_path:
                resolved_path = context.resolve_template(script_path)
                proc = await asyncio.create_subprocess_exec(
                    sys.executable, resolved_path,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
                duration = time.time() - start_time
                stdout = stdout_b.decode("utf-8", errors="replace")
                stderr = stderr_b.decode("utf-8", errors="replace")
                rc = proc.returncode
                return ActionResult(
                    success=(rc == 0),
                    output={"stdout": stdout, "stderr": stderr, "return_code": rc},
                    duration=duration,
                    error=stderr if rc != 0 else None
                )
        except asyncio.TimeoutError:
            return ActionResult(success=False, error=f"Python execution timed out after {timeout} seconds")
        except Exception as e:
            return ActionResult(
                success=False,
                error=f"Python Execution Error: {str(e)}",
                output={"stderr": stderr_buf.getvalue()}
            )
        return ActionResult(success=False, error="Invalid configuration")

    async def dry_run(self, context: ExecutionContext) -> Dict[str, Any]:
        return {"action": self.identifier, "would_modify": True, "description": "Would execute Python script/code block"}
