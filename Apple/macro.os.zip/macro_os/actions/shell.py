"""
MACRO.OS Shell Engine
Controlled subprocess execution using argument arrays without unsafe shell string interpolation.
"""
import asyncio
import time
from typing import Dict, Any, List
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action
from macro_os.security.permissions import PermissionType

@register_action("shell.execute")
class ShellAction(Action):
    identifier = "shell.execute"
    required_permissions = [PermissionType.SHELL, PermissionType.PROCESS_EXECUTION]

    def validate(self, context: ExecutionContext) -> None:
        if "command" not in self.params:
            raise ValueError("shell.execute requires 'command' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        raw_cmd = self.params["command"]
        args = self.params.get("args", [])
        working_dir = context.resolve_template(self.params.get("working_directory", "."))
        timeout = float(self.params.get("timeout", 30.0))
        env = self.params.get("environment")

        # Resolve templates
        if isinstance(raw_cmd, str):
            cmd = context.resolve_template(raw_cmd)
        else:
            cmd = raw_cmd

        resolved_args = [str(context.resolve_template(arg)) for arg in args]

        start_time = time.time()
        try:
            if isinstance(cmd, list):
                full_cmd = cmd + resolved_args
                proc = await asyncio.create_subprocess_exec(
                    *full_cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=working_dir,
                    env=env
                )
            else:
                full_cmd_str = cmd + (" " + " ".join(resolved_args) if resolved_args else "")
                proc = await asyncio.create_subprocess_shell(
                    full_cmd_str,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=working_dir,
                    env=env
                )

            stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            duration = time.time() - start_time

            stdout = stdout_b.decode("utf-8", errors="replace")
            stderr = stderr_b.decode("utf-8", errors="replace")
            return_code = proc.returncode

            return ActionResult(
                success=(return_code == 0),
                output={
                    "stdout": stdout,
                    "stderr": stderr,
                    "return_code": return_code,
                    "command": cmd
                },
                duration=duration,
                error=stderr if return_code != 0 else None
            )
        except asyncio.TimeoutError:
            return ActionResult(
                success=False,
                duration=time.time() - start_time,
                error=f"Shell command timed out after {timeout} seconds"
            )
        except Exception as e:
            return ActionResult(success=False, error=str(e))

    async def dry_run(self, context: ExecutionContext) -> Dict[str, Any]:
        cmd = context.resolve_template(self.params.get("command"))
        return {"action": self.identifier, "command": str(cmd), "would_modify": True}
