"""
MACRO.OS Action Base Class & ActionResult Model
Defines the abstract interface for all executable actions in MACRO.OS.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, TYPE_CHECKING

if TYPE_CHECKING:
    from macro_os.engine.context import ExecutionContext

@dataclass
class ActionResult:
    success: bool
    output: Dict[str, Any] = field(default_factory=dict)
    duration: float = 0.0
    error: Optional[str] = None
    audit_log: List[Dict[str, Any]] = field(default_factory=list)
    dry_run_info: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "output": self.output,
            "duration": round(self.duration, 4),
            "error": self.error,
            "audit_log": self.audit_log,
            "dry_run_info": self.dry_run_info
        }

class Action(ABC):
    identifier: str = "base.action"
    required_permissions: List[str] = []

    def __init__(self, params: Dict[str, Any] = None):
        self.params: Dict[str, Any] = params or {}

    def validate(self, context: ExecutionContext) -> None:
        """Validate parameter structure and context requirements before execution."""
        pass

    @abstractmethod
    async def execute(self, context: ExecutionContext) -> ActionResult:
        """Execute the action asynchronously within the given execution context."""
        pass

    async def cancel() -> None:
        """Cooperative cancellation hook called when execution is aborted."""
        pass

    async def rollback(self, context: ExecutionContext) -> None:
        """Attempt to revert changes if workflow step fails downstream."""
        pass

    async def dry_run(self, context: ExecutionContext) -> Dict[str, Any]:
        """Calculate side-effects and changes without modifying actual state."""
        return {
            "action": self.identifier,
            "would_modify": False,
            "description": f"Dry run for {self.identifier}"
        }
