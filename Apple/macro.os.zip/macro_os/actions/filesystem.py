"""
MACRO.OS Filesystem Actions Engine
Supports read, write, copy, move, rename, delete, mkdir, list, exists, metadata, archive, extract, and watch.
Implements safe file operations: dry_run, confirmation_required, backup_before_change, rollback, and audit logging.
"""
import os
import shutil
import glob
import re
import datetime
import zipfile
from pathlib import Path
from typing import Dict, Any, List, Optional
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import register_action
from macro_os.security.permissions import PermissionType

def create_file_backup(file_path: Path) -> Path:
    backup_dir = Path.home() / ".macroos" / "cache" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_path = backup_dir / f"{file_path.name}.{timestamp}.bak"
    if file_path.is_file():
        shutil.copy2(file_path, backup_path)
    elif file_path.is_dir():
        shutil.copytree(file_path, backup_path)
    return backup_path

@register_action("filesystem.read")
class FileReadAction(Action):
    identifier = "filesystem.read"
    required_permissions = [PermissionType.FILESYSTEM_READ]

    def validate(self, context: ExecutionContext) -> None:
        path = self.params.get("path")
        if not path:
            raise ValueError("filesystem.read requires 'path' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        resolved_path = Path(context.resolve_template(self.params["path"])).expanduser().resolve()
        encoding = self.params.get("encoding", "utf-8")
        if not resolved_path.exists():
            return ActionResult(success=False, error=f"File not found: {resolved_path}")
        content = resolved_path.read_text(encoding=encoding)
        return ActionResult(
            success=True,
            output={"content": content, "path": str(resolved_path), "size": len(content)}
        )

    async def dry_run(self, context: ExecutionContext) -> Dict[str, Any]:
        path = context.resolve_template(self.params.get("path"))
        return {"action": self.identifier, "path": str(path), "would_modify": False}

@register_action("filesystem.write")
class FileWriteAction(Action):
    identifier = "filesystem.write"
    required_permissions = [PermissionType.FILESYSTEM_WRITE]

    def validate(self, context: ExecutionContext) -> None:
        if "path" not in self.params or "content" not in self.params:
            raise ValueError("filesystem.write requires 'path' and 'content' parameters")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        resolved_path = Path(context.resolve_template(self.params["path"])).expanduser().resolve()
        content = str(context.resolve_template(self.params["content"]))
        append = self.params.get("append", False)
        backup = self.params.get("backup", True)

        audit_log = []
        if resolved_path.exists() and backup:
            backup_path = create_file_backup(resolved_path)
            audit_log.append({"event": "backup_created", "backup_path": str(backup_path)})

        resolved_path.parent.mkdir(parents=True, exist_ok=True)
        mode = "a" if append else "w"
        with open(resolved_path, mode, encoding="utf-8") as f:
            f.write(content)

        context.log_audit("filesystem.write", PermissionType.FILESYSTEM_WRITE, str(resolved_path), "success")
        return ActionResult(
            success=True,
            output={"path": str(resolved_path), "bytes_written": len(content.encode("utf-8"))},
            audit_log=audit_log
        )

    async def dry_run(self, context: ExecutionContext) -> Dict[str, Any]:
        path = context.resolve_template(self.params.get("path"))
        return {"action": self.identifier, "path": str(path), "would_modify": True, "append": self.params.get("append", False)}

@register_action("filesystem.copy")
class FileCopyAction(Action):
    identifier = "filesystem.copy"
    required_permissions = [PermissionType.FILESYSTEM_READ, PermissionType.FILESYSTEM_WRITE]

    def validate(self, context: ExecutionContext) -> None:
        if "source" not in self.params or "destination" not in self.params:
            raise ValueError("filesystem.copy requires 'source' and 'destination' parameters")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        src = Path(context.resolve_template(self.params["source"])).expanduser().resolve()
        dst = Path(context.resolve_template(self.params["destination"])).expanduser().resolve()

        if not src.exists():
            return ActionResult(success=False, error=f"Source path does not exist: {src}")

        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)

        context.log_audit("filesystem.copy", PermissionType.FILESYSTEM_WRITE, str(dst), "success", {"source": str(src)})
        return ActionResult(success=True, output={"source": str(src), "destination": str(dst)})

    async def dry_run(self, context: ExecutionContext) -> Dict[str, Any]:
        src = context.resolve_template(self.params.get("source"))
        dst = context.resolve_template(self.params.get("destination"))
        return {"action": self.identifier, "source": str(src), "destination": str(dst), "would_modify": True}

@register_action("filesystem.move")
class FileMoveAction(Action):
    identifier = "filesystem.move"
    required_permissions = [PermissionType.FILESYSTEM_WRITE]

    def validate(self, context: ExecutionContext) -> None:
        if "source" not in self.params or "destination" not in self.params:
            raise ValueError("filesystem.move requires 'source' and 'destination' parameters")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        src = Path(context.resolve_template(self.params["source"])).expanduser().resolve()
        dst = Path(context.resolve_template(self.params["destination"])).expanduser().resolve()

        if not src.exists():
            return ActionResult(success=False, error=f"Source path does not exist: {src}")

        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        context.log_audit("filesystem.move", PermissionType.FILESYSTEM_WRITE, str(dst), "success", {"source": str(src)})
        return ActionResult(success=True, output={"source": str(src), "destination": str(dst)})

@register_action("filesystem.delete")
class FileDeleteAction(Action):
    identifier = "filesystem.delete"
    required_permissions = [PermissionType.FILESYSTEM_DELETE]

    def validate(self, context: ExecutionContext) -> None:
        if "path" not in self.params:
            raise ValueError("filesystem.delete requires 'path' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        target_path = Path(context.resolve_template(self.params["path"])).expanduser().resolve()
        backup = self.params.get("backup", True)

        if not target_path.exists():
            return ActionResult(success=True, output={"message": f"Path already deleted or does not exist: {target_path}"})

        audit_log = []
        if backup:
            b_path = create_file_backup(target_path)
            audit_log.append({"event": "backup_created", "backup_path": str(b_path)})

        if target_path.is_dir():
            shutil.rmtree(target_path)
        else:
            target_path.unlink()

        context.log_audit("filesystem.delete", PermissionType.FILESYSTEM_DELETE, str(target_path), "success")
        return ActionResult(success=True, output={"deleted_path": str(target_path)}, audit_log=audit_log)

    async def dry_run(self, context: ExecutionContext) -> Dict[str, Any]:
        p = context.resolve_template(self.params.get("path"))
        return {"action": self.identifier, "path": str(p), "would_modify": True, "would_delete": True}

@register_action("filesystem.list")
class FileListAction(Action):
    identifier = "filesystem.list"
    required_permissions = [PermissionType.FILESYSTEM_READ]

    def validate(self, context: ExecutionContext) -> None:
        if "directory" not in self.params and "path" not in self.params:
            raise ValueError("filesystem.list requires 'directory' or 'path' parameter")

    async def execute(self, context: ExecutionContext) -> ActionResult:
        dir_path = Path(context.resolve_template(self.params.get("directory") or self.params.get("path"))).expanduser().resolve()
        pattern = self.params.get("pattern", "*")
        regex_filter = self.params.get("regex")

        if not dir_path.exists():
            return ActionResult(success=False, error=f"Directory does not exist: {dir_path}")

        matched_files = []
        for p in dir_path.glob(pattern):
            if regex_filter and not re.search(regex_filter, p.name):
                continue
            matched_files.append({
                "path": str(p),
                "name": p.name,
                "is_dir": p.is_dir(),
                "size": p.stat().st_size if p.is_file() else 0,
                "modified": datetime.datetime.fromtimestamp(p.stat().st_mtime).isoformat()
            })

        return ActionResult(success=True, output={"files": matched_files, "count": len(matched_files)})

@register_action("filesystem.mkdir")
class FileMkdirAction(Action):
    identifier = "filesystem.mkdir"
    required_permissions = [PermissionType.FILESYSTEM_WRITE]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        path = Path(context.resolve_template(self.params["path"])).expanduser().resolve()
        path.mkdir(parents=True, exist_ok=True)
        return ActionResult(success=True, output={"directory": str(path)})

@register_action("filesystem.exists")
class FileExistsAction(Action):
    identifier = "filesystem.exists"
    required_permissions = [PermissionType.FILESYSTEM_READ]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        path = Path(context.resolve_template(self.params["path"])).expanduser().resolve()
        exists = path.exists()
        return ActionResult(success=True, output={"exists": exists, "path": str(path)})

@register_action("filesystem.metadata")
class FileMetadataAction(Action):
    identifier = "filesystem.metadata"
    required_permissions = [PermissionType.FILESYSTEM_READ]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        path = Path(context.resolve_template(self.params["path"])).expanduser().resolve()
        if not path.exists():
            return ActionResult(success=False, error=f"File not found: {path}")
        st = path.stat()
        return ActionResult(success=True, output={
            "path": str(path),
            "name": path.name,
            "extension": path.suffix,
            "size": st.st_size,
            "created": datetime.datetime.fromtimestamp(st.st_ctime).isoformat(),
            "modified": datetime.datetime.fromtimestamp(st.st_mtime).isoformat(),
            "is_file": path.is_file(),
            "is_dir": path.is_dir(),
            "permissions": oct(st.st_mode)[-3:]
        })

@register_action("filesystem.archive")
class FileArchiveAction(Action):
    identifier = "filesystem.archive"
    required_permissions = [PermissionType.FILESYSTEM_READ, PermissionType.FILESYSTEM_WRITE]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        src = Path(context.resolve_template(self.params["source"])).expanduser().resolve()
        archive_path = Path(context.resolve_template(self.params["archive_path"])).expanduser().resolve()
        archive_path.parent.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            if src.is_dir():
                for root, _, files in os.walk(src):
                    for file in files:
                        fp = Path(root) / file
                        zipf.write(fp, fp.relative_to(src))
            else:
                zipf.write(src, src.name)

        return ActionResult(success=True, output={"archive": str(archive_path)})

@register_action("filesystem.extract")
class FileExtractAction(Action):
    identifier = "filesystem.extract"
    required_permissions = [PermissionType.FILESYSTEM_READ, PermissionType.FILESYSTEM_WRITE]

    async def execute(self, context: ExecutionContext) -> ActionResult:
        archive_path = Path(context.resolve_template(self.params["archive_path"])).expanduser().resolve()
        destination = Path(context.resolve_template(self.params["destination"])).expanduser().resolve()
        destination.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(archive_path, 'r') as zipf:
            zipf.extractall(destination)

        return ActionResult(success=True, output={"extracted_to": str(destination)})
