"""
MACRO.OS Workflow Profiler & Optimizer
Measures execution spans, CPU/memory overhead, and generates optimization proposals.
"""
import time
import uuid
from typing import Dict, Any, List, Optional
from macro_os.profiler.telemetry import ExecutionSpan
from macro_os.workflows.schema import WorkflowSchema

class WorkflowProfiler:
    def __init__(self, execution_id: str):
        self.execution_id = execution_id
        self.spans: Dict[str, ExecutionSpan] = {}
        self.root_spans: List[ExecutionSpan] = []
        self.start_time: float = time.time()
        self.end_time: Optional[float] = None

    def start_span(self, action_id: str, action_type: str, parent_id: str = None) -> ExecutionSpan:
        span_id = f"span_{uuid.uuid4().hex[:8]}"
        span = ExecutionSpan(
            span_id=span_id,
            action_id=action_id,
            action_type=action_type,
            start_time=time.time(),
            parent_id=parent_id
        )
        self.spans[span_id] = span
        if parent_id and parent_id in self.spans:
            self.spans[parent_id].children.append(span)
        else:
            self.root_spans.append(span)
        return span

    def finish_span(self, span_id: str, status: str = "COMPLETED"):
        if span_id in self.spans:
            self.spans[span_id].finish(status)

    def finish_profiling(self) -> Dict[str, Any]:
        self.end_time = time.time()
        total_duration = round(self.end_time - self.start_time, 4)
        action_breakdown = {}
        for span in self.spans.values():
            action_breakdown[f"{span.action_id} ({span.action_type})"] = f"{span.duration}s"

        return {
            "execution_id": self.execution_id,
            "total_duration": total_duration,
            "spans": [s.to_dict() for s in self.root_spans],
            "breakdown": action_breakdown
        }

class WorkflowOptimizer:
    """Analyzes workflow graphs for parallelization, batching, and redundant wait removal proposals."""
    @staticmethod
    def analyze_and_propose(schema: WorkflowSchema) -> Dict[str, Any]:
        proposals = []

        # 1. Check serial independent file actions that could run in parallel
        serial_file_nodes = [n for n in schema.nodes if n.action.startswith("filesystem.") or n.action.startswith("data.")]
        if len(serial_file_nodes) >= 3 and len(schema.edges) == len(schema.nodes) - 1:
            proposals.append({
                "type": "PARALLEL_EXECUTION_OPPORTUNITY",
                "title": "Parallelize Independent File Operations",
                "description": f"Found {len(serial_file_nodes)} sequential file actions. Converting them to control.parallel can reduce runtime by up to 60%.",
                "affected_nodes": [n.id for n in serial_file_nodes],
                "estimated_speedup": "2.5x"
            })

        # 2. Check redundant waits
        wait_nodes = [n for n in schema.nodes if n.action == "control.wait"]
        for w in wait_nodes:
            sec = w.params.get("seconds", 0)
            if sec > 5:
                proposals.append({
                    "type": "REDUNDANT_WAIT_WARNING",
                    "title": f"Excessive Sleep Wait ({sec}s) in Node '{w.id}'",
                    "description": "Replace explicit sleep waits with event-based wait_for_file or wait_for_window conditions.",
                    "affected_nodes": [w.id],
                    "estimated_speedup": f"-{sec}s delay"
                })

        return {
            "workflow_id": schema.id,
            "proposal_count": len(proposals),
            "proposals": proposals,
            "status": "PROPOSAL_GENERATED"
        }
