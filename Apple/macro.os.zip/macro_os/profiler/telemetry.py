"""
MACRO.OS Telemetry & Execution Spans
Tree structure tracking action durations, parent/child spans, CPU/memory metrics.
"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
import time

@dataclass
class ExecutionSpan:
    span_id: str
    action_id: str
    action_type: str
    start_time: float
    end_time: Optional[float] = None
    duration: float = 0.0
    status: str = "RUNNING" # RUNNING, COMPLETED, FAILED, CANCELLED
    parent_id: Optional[str] = None
    children: List['ExecutionSpan'] = field(default_factory=list)
    memory_mb: float = 0.0
    cpu_percent: float = 0.0

    def finish(self, status: str = "COMPLETED"):
        self.end_time = time.time()
        self.duration = round(self.end_time - self.start_time, 4)
        self.status = status

    def to_dict(self) -> Dict[str, Any]:
        return {
            "span_id": self.span_id,
            "action_id": self.action_id,
            "action_type": self.action_type,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration": self.duration,
            "status": self.status,
            "parent_id": self.parent_id,
            "children": [c.to_dict() for c in self.children],
            "memory_mb": self.memory_mb,
            "cpu_percent": self.cpu_percent
        }
