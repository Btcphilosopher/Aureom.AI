"""
MACRO.OS — High-Powered macOS Automation, Macro & Workflow Engine
"""

__version__ = "1.0.0"
