"""
MACRO.OS Workflow Loader
Loads workflows from JSON/YAML files or dictionary structures into typed WorkflowSchema objects.
"""
import json
from pathlib import Path
from typing import Union, Dict, Any
from macro_os.workflows.schema import WorkflowSchema

class WorkflowLoader:
    @staticmethod
    def load_from_dict(data: Dict[str, Any]) -> WorkflowSchema:
        return WorkflowSchema.from_dict(data)

    @staticmethod
    def load_from_json_string(json_str: str) -> WorkflowSchema:
        data = json.loads(json_str)
        return WorkflowSchema.from_dict(data)

    @staticmethod
    def load_from_file(file_path: Union[str, Path]) -> WorkflowSchema:
        path = Path(file_path).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Workflow file not found: {path}")
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return WorkflowSchema.from_dict(data)

    @staticmethod
    def save_to_file(workflow: WorkflowSchema, file_path: Union[str, Path]) -> None:
        path = Path(file_path).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(workflow.to_dict(), f, indent=2)
