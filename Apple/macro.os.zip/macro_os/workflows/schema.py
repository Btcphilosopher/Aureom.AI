"""
MACRO.OS Workflow Schema Definitions
Versioned JSON Schema models for workflows, nodes, edges, triggers, and permissions.
"""
from __future__ import annotations
from typing import Dict, List, Any, Optional, Union
from enum import Enum
from dataclasses import dataclass, field

class TriggerType(str, Enum):
    MANUAL = "manual"
    FILE_CREATED = "file.created"
    FILE_CHANGED = "file.changed"
    DIRECTORY_CHANGED = "directory.changed"
    SCHEDULE_INTERVAL = "schedule.interval"
    SCHEDULE_CRON = "schedule.cron"
    APPLICATION_LAUNCHED = "application.launched"
    APPLICATION_QUIT = "application.quit"
    WEBHOOK = "webhook"
    EVENT = "event"

class RetryPolicy(str, Enum):
    NONE = "none"
    FIXED = "fixed"
    EXPONENTIAL = "exponential"

@dataclass
class RetryConfig:
    max_retries: int = 3
    delay_seconds: float = 1.0
    policy: RetryPolicy = RetryPolicy.FIXED

@dataclass
class TriggerConfig:
    type: TriggerType = TriggerType.MANUAL
    path: Optional[str] = None
    pattern: Optional[str] = None
    cron: Optional[str] = None
    interval_seconds: Optional[float] = None
    bundle_id: Optional[str] = None
    event_name: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> TriggerConfig:
        ttype_str = data.get("type", "manual")
        try:
            ttype = TriggerType(ttype_str)
        except ValueError:
            ttype = TriggerType.MANUAL
        return cls(
            type=ttype,
            path=data.get("path"),
            pattern=data.get("pattern"),
            cron=data.get("cron"),
            interval_seconds=data.get("interval_seconds"),
            bundle_id=data.get("bundle_id"),
            event_name=data.get("event_name"),
            extra={k: v for k, v in data.items() if k not in ("type", "path", "pattern", "cron", "interval_seconds", "bundle_id", "event_name")}
        )

    def to_dict(self) -> Dict[str, Any]:
        res = {"type": self.type.value}
        if self.path: res["path"] = self.path
        if self.pattern: res["pattern"] = self.pattern
        if self.cron: res["cron"] = self.cron
        if self.interval_seconds is not None: res["interval_seconds"] = self.interval_seconds
        if self.bundle_id: res["bundle_id"] = self.bundle_id
        if self.event_name: res["event_name"] = self.event_name
        res.update(self.extra)
        return res

@dataclass
class WorkflowNode:
    id: str
    action: str
    params: Dict[str, Any] = field(default_factory=dict)
    permissions: List[str] = field(default_factory=list)
    timeout_seconds: Optional[float] = 30.0
    retry: Optional[RetryConfig] = None
    description: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> WorkflowNode:
        retry_data = data.get("retry")
        retry_cfg = None
        if isinstance(retry_data, dict):
            retry_cfg = RetryConfig(
                max_retries=retry_data.get("max_retries", 3),
                delay_seconds=retry_data.get("delay_seconds", 1.0),
                policy=RetryPolicy(retry_data.get("policy", "fixed"))
            )
        return cls(
            id=data["id"],
            action=data["action"],
            params=data.get("params", {}),
            permissions=data.get("permissions", []),
            timeout_seconds=data.get("timeout_seconds", 30.0),
            retry=retry_cfg,
            description=data.get("description")
        )

    def to_dict(self) -> Dict[str, Any]:
        res = {
            "id": self.id,
            "action": self.action,
            "params": self.params,
            "permissions": self.permissions,
            "timeout_seconds": self.timeout_seconds,
        }
        if self.description:
            res["description"] = self.description
        if self.retry:
            res["retry"] = {
                "max_retries": self.retry.max_retries,
                "delay_seconds": self.retry.delay_seconds,
                "policy": self.retry.policy.value
            }
        return res

@dataclass
class WorkflowEdge:
    source: str
    target: str
    condition: Optional[str] = None  # e.g., "true", "false", or boolean expression

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> WorkflowEdge:
        return cls(
            source=data["source"],
            target=data["target"],
            condition=data.get("condition")
        )

    def to_dict(self) -> Dict[str, Any]:
        res = {"source": self.source, "target": self.target}
        if self.condition is not None:
            res["condition"] = self.condition
        return res

@dataclass
class WorkflowSchema:
    id: str
    name: str
    version: int = 1
    description: str = ""
    trigger: TriggerConfig = field(default_factory=TriggerConfig)
    nodes: List[WorkflowNode] = field(default_factory=list)
    edges: List[WorkflowEdge] = field(default_factory=list)
    permissions: List[str] = field(default_factory=list)
    variables: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> WorkflowSchema:
        trig_dict = data.get("trigger", {})
        trigger = TriggerConfig.from_dict(trig_dict) if isinstance(trig_dict, dict) else TriggerConfig()
        nodes = [WorkflowNode.from_dict(n) for n in data.get("nodes", [])]
        edges = [WorkflowEdge.from_dict(e) for e in data.get("edges", [])]
        return cls(
            id=data.get("id", "untitled_workflow"),
            name=data.get("name", "Untitled Workflow"),
            version=data.get("version", 1),
            description=data.get("description", ""),
            trigger=trigger,
            nodes=nodes,
            edges=edges,
            permissions=data.get("permissions", []),
            variables=data.get("variables", {})
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "trigger": self.trigger.to_dict(),
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "permissions": self.permissions,
            "variables": self.variables
        }
