"""
MACRO.OS Workflow Schema & Structural Validator
Validates JSON structure, node uniqueness, edge references, permissions, and variables.
"""
from typing import List, Dict, Any, Set
from macro_os.workflows.schema import WorkflowSchema

class WorkflowValidationError:
    def __init__(self, code: str, message: str, node_id: str = None):
        self.code = code
        self.message = message
        self.node_id = node_id

    def __repr__(self):
        prefix = f"[{self.node_id}] " if self.node_id else ""
        return f"{prefix}{self.code}: {self.message}"

    def to_dict(self) -> Dict[str, Any]:
        res = {"code": self.code, "message": self.message}
        if self.node_id:
            res["node_id"] = self.node_id
        return res

class WorkflowValidator:
    @staticmethod
    def validate(schema: WorkflowSchema, registered_actions: Set[str] = None) -> List[WorkflowValidationError]:
        errors: List[WorkflowValidationError] = []

        if not schema.id or not isinstance(schema.id, str):
            errors.append(WorkflowValidationError("INVALID_ID", "Workflow ID must be a non-empty string"))

        if not schema.nodes:
            errors.append(WorkflowValidationError("EMPTY_WORKFLOW", "Workflow must contain at least one node"))

        # Check duplicate node IDs
        node_ids: Set[str] = set()
        for node in schema.nodes:
            if not node.id:
                errors.append(WorkflowValidationError("MISSING_NODE_ID", "Node missing required 'id'"))
                continue
            if node.id in node_ids:
                errors.append(WorkflowValidationError("DUPLICATE_NODE_ID", f"Duplicate node ID: {node.id}", node.id))
            node_ids.add(node.id)

            if not node.action:
                errors.append(WorkflowValidationError("MISSING_ACTION", f"Node '{node.id}' missing required 'action'", node.id))
            elif registered_actions and node.action not in registered_actions:
                errors.append(WorkflowValidationError("UNREGISTERED_ACTION", f"Node '{node.id}' references unregistered action '{node.action}'", node.id))

        # Check edge targets/sources
        for edge in schema.edges:
            if edge.source not in node_ids:
                errors.append(WorkflowValidationError("INVALID_EDGE_SOURCE", f"Edge references non-existent source node '{edge.source}'"))
            if edge.target not in node_ids:
                errors.append(WorkflowValidationError("INVALID_EDGE_TARGET", f"Edge references non-existent target node '{edge.target}'"))

        # Detect unreachable nodes (nodes with no incoming edges that aren't roots)
        if len(schema.nodes) > 1 and schema.edges:
            targets = {e.target for e in schema.edges}
            sources = {e.source for e in schema.edges}
            root_nodes = node_ids - targets
            if not root_nodes:
                errors.append(WorkflowValidationError("CYCLE_DETECTED", "Graph contains a cycle or has no root entry node"))

        return errors
