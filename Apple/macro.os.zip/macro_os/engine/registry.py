"""
MACRO.OS Action Registry
Dynamic registry mapping stable action identifiers to typed Action classes.
"""
from typing import Dict, Type, List, Optional, Any

class ActionRegistry:
    _instance: Optional['ActionRegistry'] = None

    def __init__(self):
        self._registry: Dict[str, Any] = {}

    @classmethod
    def get_instance(cls) -> 'ActionRegistry':
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def register(self, action_class: Any, identifier: str = None) -> None:
        key = identifier or getattr(action_class, "identifier", action_class.__name__)
        self._registry[key] = action_class

    def get(self, identifier: str) -> Optional[Any]:
        return self._registry.get(identifier)

    def create(self, identifier: str, params: dict = None) -> Any:
        action_cls = self.get(identifier)
        if not action_cls:
            raise KeyError(f"Action '{identifier}' is not registered in ActionRegistry")
        return action_cls(params or {})

    def list_actions(self) -> List[Dict[str, Any]]:
        result = []
        for key, cls in sorted(self._registry.items()):
            result.append({
                "identifier": key,
                "class": cls.__name__,
                "permissions": getattr(cls, "required_permissions", []),
                "doc": (cls.__doc__ or "").strip()
            })
        return result

def register_action(identifier: str = None):
    """Decorator to register an Action class."""
    def decorator(cls: Any):
        ActionRegistry.get_instance().register(cls, identifier)
        return cls
    return decorator
