"""
MACRO.OS ActionExecutor & JobQueue
Handles individual action execution with retries, timeouts, permissions, and status queue management.
"""
import asyncio
import time
import uuid
from typing import Dict, Any, Optional, List
from enum import Enum
from dataclasses import dataclass, field
from macro_os.actions.base import Action, ActionResult
from macro_os.engine.context import ExecutionContext
from macro_os.engine.registry import ActionRegistry
from macro_os.security.permissions import PermissionManager
from macro_os.profiler.profiler import WorkflowProfiler

class JobState(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    TIMED_OUT = "TIMED_OUT"

@dataclass
class ExecutionJob:
    execution_id: str
    workflow_id: str
    priority: int = 0
    state: JobState = JobState.QUEUED
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    error_message: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "workflow_id": self.workflow_id,
            "priority": self.priority,
            "state": self.state.value,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "error_message": self.error_message
        }

class JobQueue:
    def __init__(self):
        self.jobs: Dict[str, ExecutionJob] = {}

    def create_job(self, workflow_id: str, priority: int = 0) -> ExecutionJob:
        exec_id = f"exec_{uuid.uuid4().hex[:10]}"
        job = ExecutionJob(execution_id=exec_id, workflow_id=workflow_id, priority=priority)
        self.jobs[exec_id] = job
        return job

    def get_job(self, execution_id: str) -> Optional[ExecutionJob]:
        return self.jobs.get(execution_id)

    def update_state(self, execution_id: str, state: JobState, error_msg: Optional[str] = None):
        job = self.jobs.get(execution_id)
        if job:
            job.state = state
            if state == JobState.RUNNING and job.started_at is None:
                job.started_at = time.time()
            elif state in (JobState.COMPLETED, JobState.FAILED, JobState.CANCELLED, JobState.TIMED_OUT):
                job.finished_at = time.time()
            if error_msg:
                job.error_message = error_msg

class ActionExecutor:
    def __init__(self, registry: Optional[ActionRegistry] = None, permission_manager: Optional[PermissionManager] = None):
        self.registry = registry or ActionRegistry.get_instance()
        self.permission_manager = permission_manager or PermissionManager()

    async def execute_action(
        self,
        node_id: str,
        action_type: str,
        params: Dict[str, Any],
        context: ExecutionContext,
        profiler: Optional[WorkflowProfiler] = None,
        timeout_seconds: float = 30.0,
        max_retries: int = 1
    ) -> ActionResult:
        # Check cancellation
        if context.cancellation_token.is_cancelled:
            return ActionResult(success=False, error=f"Cancelled: {context.cancellation_token.reason}")

        # Instantiate action
        try:
            action_obj = self.registry.create(action_type, params)
        except KeyError as e:
            return ActionResult(success=False, error=str(e))

        # Check required permissions
        for perm in getattr(action_obj, "required_permissions", []):
            try:
                self.permission_manager.require_permission(perm, f"Node: {node_id}")
            except PermissionError as pe:
                return ActionResult(success=False, error=str(pe))

        # Validate action
        try:
            action_obj.validate(context)
        except Exception as ve:
            return ActionResult(success=False, error=f"Action validation failed: {ve}")

        # Start telemetry span
        span = profiler.start_span(node_id, action_type) if profiler else None

        # Retry loop
        attempt = 0
        last_result = None
        while attempt < max_retries:
            attempt += 1
            try:
                result = await asyncio.wait_for(action_obj.execute(context), timeout=timeout_seconds)
                last_result = result
                if result.success:
                    break
            except asyncio.TimeoutError:
                last_result = ActionResult(success=False, error=f"Action '{action_type}' timed out after {timeout_seconds}s")
            except Exception as e:
                last_result = ActionResult(success=False, error=f"Execution error: {str(e)}")

            if attempt < max_retries:
                await asyncio.sleep(1.0 * attempt) # fixed/exponential backoff

        if span:
            profiler.finish_span(span.span_id, status="COMPLETED" if (last_result and last_result.success) else "FAILED")

        return last_result or ActionResult(success=False, error="Action execution failed")
