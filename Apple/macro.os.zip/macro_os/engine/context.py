"""
MACRO.OS Execution Context & Expression Engine
Provides strongly typed variable resolution, LoopContext tracking, and restricted AST expression evaluation without eval().
"""
from __future__ import annotations
import ast
import re
import datetime
from pathlib import Path
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass, field
from macro_os.engine.cancellation import CancellationToken

@dataclass
class LoopContext:
    index: int = 0
    item: Any = None
    total: int = 0
    first: bool = True
    last: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "item": self.item,
            "total": self.total,
            "first": self.first,
            "last": self.last
        }

class ExpressionEvaluator(ast.NodeVisitor):
    """Restricted AST evaluator for safe execution of expressions without eval()."""

    ALLOWED_NODES = (
        ast.Expression, ast.Name, ast.Load, ast.Constant, ast.Attribute,
        ast.BinOp, ast.UnaryOp, ast.Compare, ast.BoolOp, ast.Call,
        ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod,
        ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn,
        ast.And, ast.Or, ast.Not, ast.USub, ast.UAdd
    )

    def __init__(self, variables: Dict[str, Any]):
        self.variables = variables

    def evaluate(self, expr_str: str) -> Any:
        try:
            tree = ast.parse(expr_str.strip(), mode="eval")
        except SyntaxError as e:
            raise ValueError(f"Invalid expression syntax: '{expr_str}': {e}")
        
        # Verify node safety
        for node in ast.walk(tree):
            if not isinstance(node, self.ALLOWED_NODES):
                raise ValueError(f"Security violation: AST Node '{type(node).__name__}' is forbidden in expressions")
        
        return self.visit(tree.body)

    def visit_Constant(self, node: ast.Constant) -> Any:
        return node.value

    def visit_Name(self, node: ast.Name) -> Any:
        if node.id == "True": return True
        if node.id == "False": return False
        if node.id == "None": return None
        if node.id in self.variables:
            return self.variables[node.id]
        raise ValueError(f"Undefined variable in expression: '{node.id}'")

    def visit_Attribute(self, node: ast.Attribute) -> Any:
        obj = self.visit(node.value)
        if hasattr(obj, node.attr):
            return getattr(obj, node.attr)
        if isinstance(obj, dict) and node.attr in obj:
            return obj[node.attr]
        raise ValueError(f"Attribute/key '{node.attr}' not found on object")

    def visit_UnaryOp(self, node: ast.UnaryOp) -> Any:
        operand = self.visit(node.operand)
        if isinstance(node.op, ast.Not): return not operand
        if isinstance(node.op, ast.USub): return -operand
        if isinstance(node.op, ast.UAdd): return +operand
        raise ValueError(f"Unsupported unary operator: {type(node.op).__name__}")

    def visit_BinOp(self, node: ast.BinOp) -> Any:
        left = self.visit(node.left)
        right = self.visit(node.right)
        if isinstance(node.op, ast.Add): return left + right
        if isinstance(node.op, ast.Sub): return left - right
        if isinstance(node.op, ast.Mult): return left * right
        if isinstance(node.op, ast.Div): return left / right if right != 0 else 0
        if isinstance(node.op, ast.Mod): return left % right if right != 0 else 0
        raise ValueError(f"Unsupported binary operator: {type(node.op).__name__}")

    def visit_Compare(self, node: ast.Compare) -> Any:
        left = self.visit(node.left)
        for op, comparator in zip(node.ops, node.comparators):
            right = self.visit(comparator)
            res = False
            if isinstance(op, ast.Eq): res = (left == right)
            elif isinstance(op, ast.NotEq): res = (left != right)
            elif isinstance(op, ast.Lt): res = (left < right)
            elif isinstance(op, ast.LtE): res = (left <= right)
            elif isinstance(op, ast.Gt): res = (left > right)
            elif isinstance(op, ast.GtE): res = (left >= right)
            elif isinstance(op, ast.In): res = (left in right)
            elif isinstance(op, ast.NotIn): res = (left not in right)
            else:
                raise ValueError(f"Unsupported comparison operator: {type(op).__name__}")
            if not res:
                return False
            left = right
        return True

    def visit_BoolOp(self, node: ast.BoolOp) -> Any:
        if isinstance(node.op, ast.And):
            for value in node.values:
                if not self.visit(value):
                    return False
            return True
        elif isinstance(node.op, ast.Or):
            for value in node.values:
                if self.visit(value):
                    return True
            return False
        raise ValueError(f"Unsupported boolean operator: {type(node.op).__name__}")

    def visit_Call(self, node: ast.Call) -> Any:
        # Allow safe method calls on object like .endswith(), .startswith(), .lower(), len()
        if isinstance(node.func, ast.Attribute):
            obj = self.visit(node.func.value)
            method_name = node.func.attr
            if method_name in ("endswith", "startswith", "lower", "upper", "strip", "contains"):
                args = [self.visit(a) for a in node.args]
                func = getattr(obj, method_name, None)
                if callable(func):
                    return func(*args)
        elif isinstance(node.func, ast.Name):
            func_name = node.func.id
            args = [self.visit(a) for a in node.args]
            if func_name == "len" and args:
                return len(args[0])
            if func_name in ("str", "int", "float", "bool") and args:
                if func_name == "str": return str(args[0])
                if func_name == "int": return int(args[0])
                if func_name == "float": return float(args[0])
                if func_name == "bool": return bool(args[0])
        raise ValueError("Arbitrary function execution is strictly prohibited")

class ExpressionEngine:
    @staticmethod
    def evaluate(expression: str, variables: Dict[str, Any]) -> Any:
        evaluator = ExpressionEvaluator(variables)
        return evaluator.evaluate(expression)

class ExecutionContext:
    def __init__(
        self,
        execution_id: str,
        workflow_id: str,
        variables: Optional[Dict[str, Any]] = None,
        cancellation_token: Optional[CancellationToken] = None,
        secrets: Optional[Dict[str, str]] = None
    ):
        self.execution_id = execution_id
        self.workflow_id = workflow_id
        self.variables: Dict[str, Any] = {
            "workflow": {"id": workflow_id},
            "execution": {"id": execution_id},
            "now": datetime.datetime.now().isoformat(),
        }
        if variables:
            self.variables.update(variables)
        self.step_outputs: Dict[str, Any] = {}
        self.loop: Optional[LoopContext] = None
        self.cancellation_token = cancellation_token or CancellationToken()
        self.secrets: Dict[str, str] = secrets or {}
        self.audit_logs: List[Dict[str, Any]] = []

    def set_variable(self, name: str, value: Any) -> None:
        self.variables[name] = value

    def get_variable(self, name: str, default: Any = None) -> Any:
        return self.variables.get(name, default)

    def set_step_output(self, node_id: str, output: Any) -> None:
        self.step_outputs[node_id] = output
        self.variables[f"step_{node_id}"] = output

    def resolve_template(self, template: Any) -> Any:
        """Resolves {{variable_name}} mustache-style templates safely."""
        if not isinstance(template, str):
            if isinstance(template, dict):
                return {k: self.resolve_template(v) for k, v in template.items()}
            if isinstance(template, list):
                return [self.resolve_template(item) for item in template]
            return template

        # Exact template string match (e.g., "{{some_var}}") -> preserve object type
        exact_match = re.fullmatch(r"\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}", template.strip())
        if exact_match:
            var_path = exact_match.group(1)
            return self._resolve_variable_path(var_path)

        # In-line string substitution
        def replace_var(match):
            path = match.group(1)
            val = self._resolve_variable_path(path)
            return str(val) if val is not None else ""

        return re.sub(r"\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}", replace_var, template)

    def _resolve_variable_path(self, path: str) -> Any:
        parts = path.split(".")
        current = self.variables
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            elif hasattr(current, part):
                current = getattr(current, part)
            else:
                return None
        return current

    def evaluate_condition(self, expression: str) -> bool:
        if expression in ("true", "True", "TRUE"): return True
        if expression in ("false", "False", "FALSE"): return False
        res = ExpressionEngine.evaluate(expression, self.variables)
        return bool(res)

    def log_audit(self, action: str, permission: str, target: str, result: str, details: Dict[str, Any] = None):
        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "execution_id": self.execution_id,
            "workflow_id": self.workflow_id,
            "action": action,
            "permission": permission,
            "target": target,
            "result": result,
            "details": details or {}
        }
        self.audit_logs.append(entry)
