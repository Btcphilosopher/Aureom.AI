"""
MACRO.OS Primary Workflow Engine
Orchestrates Workflow Compilation, Execution Context, Job Queue, Action Execution, and SQLite Persistence.
"""
import asyncio
import time
from typing import Dict, Any, Optional, List, Callable
from macro_os.workflows.schema import WorkflowSchema
from macro_os.workflows.loader import WorkflowLoader
from macro_os.engine.compiler import WorkflowCompiler, ExecutionPlan
from macro_os.engine.context import ExecutionContext
from macro_os.engine.executor import ActionExecutor, JobQueue, JobState, ExecutionJob
from macro_os.engine.cancellation import EmergencyStopController, CancellationToken
from macro_os.storage.database import Database
from macro_os.profiler.profiler import WorkflowProfiler
from macro_os.actions.base import ActionResult

class MacroEngine:
    def __init__(self, db: Optional[Database] = None):
        self.db = db or Database()
        self.compiler = WorkflowCompiler()
        self.executor = ActionExecutor()
        self.job_queue = JobQueue()
        self.kill_switch = EmergencyStopController()
        # Recover interrupted workflows on engine startup
        self.db.recover_crashes()

    async def run_workflow(
        self,
        schema: WorkflowSchema,
        inputs: Dict[str, Any] = None,
        dry_run: bool = False,
        progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None
    ) -> Dict[str, Any]:
        # Save or update workflow in database
        self.db.save_workflow(schema.to_dict())

        # Create job
        job = self.job_queue.create_job(schema.id)
        token = CancellationToken()
        self.kill_switch.register(job.execution_id, token)

        # Build context
        context = ExecutionContext(
            execution_id=job.execution_id,
            workflow_id=schema.id,
            variables=inputs or schema.variables,
            cancellation_token=token
        )

        profiler = WorkflowProfiler(job.execution_id)

        if dry_run:
            # Dry run simulation mode
            simulated_actions = []
            for node in schema.nodes:
                simulated_actions.append({
                    "node_id": node.id,
                    "action": node.action,
                    "params": node.params,
                    "would_modify": True
                })
            return {
                "dry_run": True,
                "workflow_id": schema.id,
                "execution_id": job.execution_id,
                "simulated_actions": simulated_actions,
                "message": "Dry-run simulation complete. No permanent side-effects occurred."
            }

        # 1. Compile
        try:
            plan = self.compiler.compile(schema)
        except Exception as ce:
            self.job_queue.update_state(job.execution_id, JobState.FAILED, str(ce))
            return {"success": False, "error": f"Compilation Error: {ce}"}

        # Record start in DB
        self.job_queue.update_state(job.execution_id, JobState.RUNNING)
        self.db.record_execution_start(job.execution_id, schema.id, context.variables)

        start_time = time.time()
        action_count = 0
        failure_count = 0
        results: Dict[str, ActionResult] = {}

        # Execute step by step
        for step in plan.steps:
            if token.is_cancelled:
                self.job_queue.update_state(job.execution_id, JobState.CANCELLED, token.reason)
                self.db.record_execution_finish(job.execution_id, "CANCELLED", time.time() - start_time, action_count, failure_count, token.reason)
                return {"success": False, "error": f"Workflow Cancelled: {token.reason}"}

            # Parallel step execution for nodes in current layer
            tasks = []
            for node in step.nodes:
                action_count += 1
                if progress_callback:
                    progress_callback({"event": "action_started", "node_id": node.id, "action": node.action})

                retry_cfg = node.retry
                max_retries = retry_cfg.max_retries if retry_cfg else 1
                task = self.executor.execute_action(
                    node_id=node.id,
                    action_type=node.action,
                    params=node.params,
                    context=context,
                    profiler=profiler,
                    timeout_seconds=node.timeout_seconds or 30.0,
                    max_retries=max_retries
                )
                tasks.append((node.id, node.action, task))

            # Await all nodes in step
            step_outcomes = await asyncio.gather(*[t[2] for t in tasks], return_exceptions=True)

            for (node_id, action_type, _), outcome in zip(tasks, step_outcomes):
                if isinstance(outcome, Exception):
                    res = ActionResult(success=False, error=str(outcome))
                else:
                    res = outcome

                results[node_id] = res
                context.set_step_output(node_id, res.output)

                status_str = "COMPLETED" if res.success else "FAILED"
                if not res.success:
                    failure_count += 1

                self.db.record_action_result(
                    execution_id=job.execution_id,
                    node_id=node_id,
                    action_type=action_type,
                    status=status_str,
                    duration=res.duration,
                    output=res.output,
                    error=res.error
                )

                if progress_callback:
                    progress_callback({
                        "event": "action_completed" if res.success else "action_failed",
                        "node_id": node_id,
                        "action": action_type,
                        "success": res.success,
                        "duration": res.duration,
                        "output": res.output,
                        "error": res.error
                    })

        # Finish execution
        duration = time.time() - start_time
        overall_status = "COMPLETED" if failure_count == 0 else "FAILED"
        self.job_queue.update_state(job.execution_id, JobState(overall_status))
        self.db.record_execution_finish(job.execution_id, overall_status, duration, action_count, failure_count)
        self.kill_switch.unregister(job.execution_id)

        profiler_data = profiler.finish_profiling()

        return {
            "success": (failure_count == 0),
            "execution_id": job.execution_id,
            "workflow_id": schema.id,
            "duration": round(duration, 4),
            "action_count": action_count,
            "failure_count": failure_count,
            "step_outputs": context.step_outputs,
            "profiler": profiler_data,
            "audit_logs": context.audit_logs
        }
