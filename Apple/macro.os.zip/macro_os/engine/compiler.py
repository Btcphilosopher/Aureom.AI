"""
MACRO.OS Workflow Graph & Compiler
Builds directed acyclic execution graphs (DAGs), resolves dependencies, detects cycles, and generates ExecutionPlans.
"""
from typing import Dict, List, Set, Any, Optional
from collections import defaultdict, deque
from macro_os.workflows.schema import WorkflowSchema, WorkflowNode, WorkflowEdge
from macro_os.workflows.validator import WorkflowValidator, WorkflowValidationError
from macro_os.engine.registry import ActionRegistry

class ExecutionStep:
    """Group of nodes that can be executed in parallel during a phase."""
    def __init__(self, step_number: int, nodes: List[WorkflowNode]):
        self.step_number = step_number
        self.nodes = nodes

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_number": self.step_number,
            "nodes": [n.id for n in self.nodes]
        }

class ExecutionPlan:
    def __init__(self, workflow_id: str, steps: List[ExecutionStep]):
        self.workflow_id = workflow_id
        self.steps = steps

    def to_dict(self) -> Dict[str, Any]:
        return {
            "workflow_id": self.workflow_id,
            "total_steps": len(self.steps),
            "steps": [s.to_dict() for s in self.steps]
        }

class WorkflowGraph:
    def __init__(self, schema: WorkflowSchema):
        self.schema = schema
        self.nodes_by_id: Dict[str, WorkflowNode] = {n.id: n for n in schema.nodes}
        self.in_degree: Dict[str, int] = {n.id: 0 for n in schema.nodes}
        self.adj_list: Dict[str, List[str]] = defaultdict(list)
        self.conditional_edges: Dict[str, Dict[str, str]] = defaultdict(dict) # src -> {target: condition}

        for edge in schema.edges:
            if edge.source in self.nodes_by_id and edge.target in self.nodes_by_id:
                self.adj_list[edge.source].append(edge.target)
                self.in_degree[edge.target] += 1
                if edge.condition:
                    self.conditional_edges[edge.source][edge.target] = edge.condition

    def detect_cycles(self) -> bool:
        visited_count = 0
        in_deg = dict(self.in_degree)
        queue = deque([n_id for n_id, deg in in_deg.items() if deg == 0])

        while queue:
            curr = queue.popleft()
            visited_count += 1
            for neighbor in self.adj_list[curr]:
                in_deg[neighbor] -= 1
                if in_deg[neighbor] == 0:
                    queue.append(neighbor)

        return visited_count != len(self.nodes_by_id)

    def topological_sort_steps(self) -> List[ExecutionStep]:
        in_deg = dict(self.in_degree)
        queue = deque([n_id for n_id, deg in in_deg.items() if deg == 0])
        steps: List[ExecutionStep] = []
        step_idx = 1

        while queue:
            current_layer = list(queue)
            queue.clear()

            layer_nodes = [self.nodes_by_id[nid] for nid in current_layer]
            steps.append(ExecutionStep(step_idx, layer_nodes))
            step_idx += 1

            for curr in current_layer:
                for neighbor in self.adj_list[curr]:
                    in_deg[neighbor] -= 1
                    if in_deg[neighbor] == 0:
                        queue.append(neighbor)

        return steps

class WorkflowCompiler:
    def __init__(self, registry: Optional[ActionRegistry] = None):
        self.registry = registry or ActionRegistry.get_instance()

    def compile(self, schema: WorkflowSchema) -> ExecutionPlan:
        # 1. Schema & structural validation
        registered_action_keys = {a["identifier"] for a in self.registry.list_actions()}
        errors = WorkflowValidator.validate(schema, registered_actions=registered_action_keys)
        if errors:
            err_msg = "; ".join([str(e) for e in errors])
            raise ValueError(f"Workflow Compilation Error: {err_msg}")

        # 2. Graph construction & Cycle check
        graph = WorkflowGraph(schema)
        if graph.detect_cycles():
            raise ValueError(f"Workflow Compilation Error: Cycle detected in workflow '{schema.id}'")

        # 3. Generate topological execution plan
        steps = graph.topological_sort_steps()
        return ExecutionPlan(workflow_id=schema.id, steps=steps)
