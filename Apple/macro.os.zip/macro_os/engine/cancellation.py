"""
MACRO.OS Cancellation Engine & Emergency Stop Controller (Global Kill Switch)
"""
import asyncio
from typing import Dict, Set

class CancellationToken:
    def __init__(self):
        self._event = asyncio.Event()
        self._reason: str = ""

    def cancel(self, reason: str = "User requested cancellation"):
        self._reason = reason
        self._event.set()

    @property
    def is_cancelled(self) -> bool:
        return self._event.is_set()

    @property
    def reason(self) -> str:
        return self._reason

    async def wait(self):
        await self._event.wait()

class EmergencyStopController:
    """Global Kill Switch maintaining active executions and safely stopping all active workflows."""
    def __init__(self):
        self._tokens: Dict[str, CancellationToken] = {}

    def register(self, execution_id: str, token: CancellationToken):
        self._tokens[execution_id] = token

    def unregister(self, execution_id: str):
        self._tokens.pop(execution_id, None)

    def cancel_execution(self, execution_id: str, reason: str = "Individual cancellation"):
        token = self._tokens.get(execution_id)
        if token:
            token.cancel(reason)

    def stop_all(self, reason: str = "EMERGENCY_STOP_TRIGGERED"):
        """GLOBAL KILL SWITCH: Cancel all currently running workflows immediately."""
        count = len(self._tokens)
        for execution_id, token in list(self._tokens.items()):
            token.cancel(reason)
        return count

    def active_executions(self) -> Set[str]:
        return set(self._tokens.keys())
