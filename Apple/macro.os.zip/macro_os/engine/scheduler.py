"""
MACRO.OS MacroScheduler
Supports one-time, interval, cron, startup, file watcher, and application triggers.
"""
import asyncio
import time
from typing import Dict, Any, List, Optional
from macro_os.workflows.schema import WorkflowSchema, TriggerType
from macro_os.scheduler.triggers import EventBus, SystemEventType
from macro_os.scheduler.watcher import FileWatcher

class MacroScheduler:
    def __init__(self, engine=None):
        self.engine = engine
        self.schedules: Dict[str, Dict[str, Any]] = {}
        self.file_watcher = FileWatcher()
        self.event_bus = EventBus.get_instance()
        self._running = False

    def schedule_workflow(self, schema: WorkflowSchema) -> str:
        sched_id = f"sched_{schema.id}"
        trig = schema.trigger
        self.schedules[sched_id] = {
            "id": sched_id,
            "workflow_id": schema.id,
            "schema": schema,
            "type": trig.type.value,
            "path": trig.path,
            "interval_seconds": trig.interval_seconds or 60.0,
            "last_run": 0.0
        }

        # Subscribe to EventBus
        if trig.type == TriggerType.FILE_CREATED:
            self.event_bus.subscribe(SystemEventType.FILE_CREATED.value, lambda payload: self._on_event_trigger(sched_id, payload))

        return sched_id

    def _on_event_trigger(self, sched_id: str, payload: Dict[str, Any]):
        sched = self.schedules.get(sched_id)
        if sched and self.engine:
            asyncio.create_task(self.engine.run_workflow(sched["schema"], inputs=payload))

    async def start(self):
        self._running = True
        while self._running:
            now = time.time()
            for sched in list(self.schedules.values()):
                if sched["type"] == TriggerType.SCHEDULE_INTERVAL.value:
                    if now - sched["last_run"] >= sched["interval_seconds"]:
                        sched["last_run"] = now
                        if self.engine:
                            asyncio.create_task(self.engine.run_workflow(sched["schema"]))
            await asyncio.sleep(1.0)

    def stop(self):
        self._running = False
