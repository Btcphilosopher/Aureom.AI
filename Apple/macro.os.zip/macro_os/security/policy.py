"""
MACRO.OS Security Policy & Resource Limits
Enforces command allowlists, directory sandboxing, maximum execution time, and resource limits.
"""
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Set, Optional, Dict, Any, Union

@dataclass
class ResourceLimits:
    max_runtime_seconds: float = 300.0
    max_actions: int = 1000
    max_subprocesses: int = 50
    max_concurrency: int = 8
    max_files_modified: int = 500

class SecurityPolicy:
    def __init__(
        self,
        allowed_commands: Optional[List[str]] = None,
        allowed_directories: Optional[List[str]] = None,
        allowed_domains: Optional[List[str]] = None,
        resource_limits: Optional[ResourceLimits] = None
    ):
        self.allowed_commands: Set[str] = set(allowed_commands or [
            "/usr/bin/python3", "/usr/bin/ditto", "/usr/bin/osascript",
            "/usr/bin/git", "/bin/ls", "/bin/mkdir", "/bin/cp", "/bin/mv", "/bin/rm"
        ])
        self.allowed_directories: List[Path] = [
            Path(d).expanduser().resolve() for d in (allowed_directories or ["~", "/tmp"])
        ]
        self.allowed_domains: Set[str] = set(allowed_domains or ["*"])
        self.limits: ResourceLimits = resource_limits or ResourceLimits()

    def validate_command(self, cmd: str):
        binary = cmd.split()[0] if cmd else ""
        if "*" in self.allowed_commands:
            return
        # Resolve full path or check binary name
        if binary not in self.allowed_commands and Path(binary).name not in [Path(c).name for c in self.allowed_commands]:
            raise SecurityError(f"Security Violation: Command '{cmd}' is not in allowed command list: {list(self.allowed_commands)}")

    def validate_path_traversal(self, path: Union[str, Path]):
        resolved = Path(path).expanduser().resolve()
        # Check against allowed directories
        allowed = False
        for allowed_dir in self.allowed_directories:
            try:
                resolved.relative_to(allowed_dir)
                allowed = True
                break
            except ValueError:
                continue
        if not allowed:
            raise SecurityError(f"Security Violation: Path '{path}' is outside permitted directories")

    def validate_domain(self, domain: str):
        if "*" in self.allowed_domains:
            return
        if domain not in self.allowed_domains:
            raise SecurityError(f"Security Violation: Network domain '{domain}' is not allowed by security policy")

class SecurityError(Exception):
    pass
