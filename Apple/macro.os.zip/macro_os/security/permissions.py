"""
MACRO.OS Permission Engine
Defines permission identifiers and verifies workflow and action permissions.
"""
from typing import List, Set, Dict, Any

class PermissionType:
    FILESYSTEM_READ = "filesystem.read"
    FILESYSTEM_WRITE = "filesystem.write"
    FILESYSTEM_DELETE = "filesystem.delete"
    ACCESSIBILITY = "accessibility"
    APPLICATION_CONTROL = "application_control"
    PROCESS_EXECUTION = "process_execution"
    SHELL = "shell"
    NETWORK = "network"
    KEYCHAIN = "keychain"

ALL_PERMISSIONS = {
    PermissionType.FILESYSTEM_READ,
    PermissionType.FILESYSTEM_WRITE,
    PermissionType.FILESYSTEM_DELETE,
    PermissionType.ACCESSIBILITY,
    PermissionType.APPLICATION_CONTROL,
    PermissionType.PROCESS_EXECUTION,
    PermissionType.SHELL,
    PermissionType.NETWORK,
    PermissionType.KEYCHAIN,
}

class PermissionManager:
    def __init__(self, granted_permissions: List[str] = None):
        self.granted: Set[str] = set(granted_permissions or ALL_PERMISSIONS)

    def check_permission(self, permission: str) -> bool:
        return permission in self.granted

    def require_permission(self, permission: str, context_info: str = ""):
        if not self.check_permission(permission):
            raise PermissionError(
                f"Permission Denied: Required permission '{permission}' is not granted for this workflow. {context_info}"
            )

    def grant(self, permission: str):
        self.granted.add(permission)

    def revoke(self, permission: str):
        self.granted.discard(permission)
