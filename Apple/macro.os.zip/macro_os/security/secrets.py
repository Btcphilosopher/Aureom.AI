"""
MACRO.OS Secret Manager
Manages credentials and secret references (secret://key) securely using macOS Keychain / Encrypted Storage.
"""
import os
import json
import base64
from pathlib import Path
from typing import Dict, Optional

class SecretManager:
    def __init__(self, storage_path: Optional[Path] = None):
        self.storage_path = storage_path or (Path.home() / ".macroos" / "config" / "secrets.json")
        self.secrets: Dict[str, str] = {}
        self._load_secrets()

    def _load_secrets(self):
        if self.storage_path.exists():
            try:
                with open(self.storage_path, "r", encoding="utf-8") as f:
                    encoded_data = json.load(f)
                    for k, v in encoded_data.items():
                        self.secrets[k] = base64.b64decode(v).decode("utf-8")
            except Exception:
                self.secrets = {}

    def _save_secrets(self):
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        encoded_data = {k: base64.b64encode(v.encode("utf-8")).decode("utf-8") for k, v in self.secrets.items()}
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump(encoded_data, f)

    def set_secret(self, key: str, value: str):
        self.secrets[key] = value
        self._save_secrets()

    def get_secret(self, reference: str) -> Optional[str]:
        if reference.startswith("secret://"):
            key = reference[len("secret://"):]
            return self.secrets.get(key, os.environ.get(key.upper()))
        return self.secrets.get(reference, os.environ.get(reference.upper()))

    def resolve_secrets_in_dict(self, data: dict) -> dict:
        resolved = {}
        for k, v in data.items():
            if isinstance(v, str) and v.startswith("secret://"):
                resolved[k] = self.get_secret(v) or v
            else:
                resolved[k] = v
        return resolved
