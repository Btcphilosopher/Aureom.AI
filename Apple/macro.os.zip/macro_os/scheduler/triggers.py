"""
MACRO.OS Event Bus & Triggers Engine
Synchronous and asynchronous event subscription and event bus.
"""
import asyncio
from enum import Enum
from typing import Dict, List, Callable, Any
import datetime

class SystemEventType(str, Enum):
    APPLICATION_LAUNCHED = "APPLICATION_LAUNCHED"
    APPLICATION_QUIT = "APPLICATION_QUIT"
    FILE_CREATED = "FILE_CREATED"
    FILE_CHANGED = "FILE_CHANGED"
    FILE_MOVED = "FILE_MOVED"
    FILE_DELETED = "FILE_DELETED"
    WORKFLOW_STARTED = "WORKFLOW_STARTED"
    WORKFLOW_COMPLETED = "WORKFLOW_COMPLETED"
    WORKFLOW_FAILED = "WORKFLOW_FAILED"
    SCHEDULE_TRIGGERED = "SCHEDULE_TRIGGERED"
    USER_TRIGGERED = "USER_TRIGGERED"
    SYSTEM_EVENT = "SYSTEM_EVENT"

class EventBus:
    _instance = None

    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[Dict[str, Any]], None]]] = {}

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def subscribe(self, event_type: str, callback: Callable[[Dict[str, Any]], None]):
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        self._subscribers[event_type].append(callback)

    def publish(self, event_type: str, payload: Dict[str, Any]):
        payload["event_type"] = event_type
        payload["timestamp"] = datetime.datetime.now().isoformat()
        for callback in self._subscribers.get(event_type, []):
            try:
                if asyncio.iscoroutinefunction(callback):
                    asyncio.create_task(callback(payload))
                else:
                    callback(payload)
            except Exception as e:
                print(f"[EventBus Error] Event '{event_type}' subscriber failed: {e}")
