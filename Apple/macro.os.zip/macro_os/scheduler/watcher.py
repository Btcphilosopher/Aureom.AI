"""
MACRO.OS File Watcher
Watches directory changes with debouncing to prevent rapid duplicate executions.
"""
import time
import glob
import re
from pathlib import Path
from typing import Dict, Any, Callable, Optional
from macro_os.scheduler.triggers import EventBus, SystemEventType

class FileWatcher:
    def __init__(self, debounce_seconds: float = 1.0):
        self.debounce_seconds = debounce_seconds
        self.last_triggered: Dict[str, float] = {}
        self.event_bus = EventBus.get_instance()

    def check_and_trigger(self, path_pattern: str, event_type: SystemEventType = SystemEventType.FILE_CREATED) -> Optional[str]:
        expanded = str(Path(path_pattern).expanduser().resolve())
        now = time.time()
        last = self.last_triggered.get(expanded, 0.0)

        if now - last < self.debounce_seconds:
            return None # Debounced

        self.last_triggered[expanded] = now
        self.event_bus.publish(event_type.value, {"path": expanded, "pattern": path_pattern})
        return expanded
