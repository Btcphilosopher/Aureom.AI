#!/usr/bin/env bash
set -e

echo "=== MACRO.OS Installer ==="
PYTHON_CMD=$(which python3 || echo "")

if [ -z "$PYTHON_CMD" ]; then
    echo "Error: Python 3 is required to install MACRO.OS."
    exit 1
fi

echo "Detected Python at: $PYTHON_CMD"
$PYTHON_CMD -c "import sys; assert sys.version_info >= (3, 10), 'Python 3.10+ required'"

MACRO_DIR="$HOME/.macroos"
echo "Initializing data directory at $MACRO_DIR..."
mkdir -p "$MACRO_DIR/workflows" "$MACRO_DIR/executions" "$MACRO_DIR/logs" "$MACRO_DIR/cache" "$MACRO_DIR/profiles" "$MACRO_DIR/plugins" "$MACRO_DIR/config"

echo "MACRO.OS installed successfully."
