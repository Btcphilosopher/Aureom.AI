import React, { useState, useEffect } from "react";
import {
  Play,
  CheckCircle,
  AlertTriangle,
  Terminal,
  Activity,
  Zap,
  Folder,
  Layers,
  Cpu,
  Shield,
  Clock,
  RefreshCw,
  FileCode,
  Sliders,
  Radio,
  FileText,
  Copy,
  Plus,
  Trash2,
  StopCircle,
  Gauge
} from "lucide-react";

interface WorkflowNode {
  id: string;
  action: string;
  params: Record<string, any>;
  timeout_seconds?: number;
}

interface WorkflowEdge {
  source: string;
  target: string;
  condition?: string;
}

interface Workflow {
  id: string;
  name: string;
  version: number;
  description: string;
  variables: Record<string, any>;
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
}

const SAMPLE_WORKFLOWS: Record<string, Workflow> = {
  file_pipeline: {
    id: "file_organizer_pipeline",
    name: "File Organizer & Data Processor",
    version: 1,
    description: "Automated filesystem organization, JSON extraction, Python processing & notification",
    variables: {
      output_dir: "/tmp/macroos_demo_output",
      customer: "Acme Enterprise"
    },
    nodes: [
      { id: "step_mkdir", action: "filesystem.mkdir", params: { path: "{{output_dir}}" } },
      { id: "step_write", action: "filesystem.write", params: { path: "{{output_dir}}/report.json", content: '{"customer": "{{customer}}", "status": "COMPLETED"}' } },
      { id: "step_read", action: "filesystem.read", params: { path: "{{output_dir}}/report.json" } },
      { id: "step_parse", action: "data.parse_json", params: { content: "{{step_step_read.content}}" } },
      { id: "step_python", action: "python.execute", params: { code: "result['summary'] = f'Successfully processed record for {variables[\"customer\"]}'\nprint('Processed python task!')" } },
      { id: "step_notify", action: "notification.send", params: { title: "MACRO.OS Pipeline", body: "Completed processing for {{customer}}" } }
    ],
    edges: [
      { source: "step_mkdir", target: "step_write" },
      { source: "step_write", target: "step_read" },
      { source: "step_read", target: "step_parse" },
      { source: "step_parse", target: "step_python" },
      { source: "step_python", target: "step_notify" }
    ]
  },
  system_diagnostics: {
    id: "system_health_audit",
    name: "macOS System Health Diagnostics",
    version: 1,
    description: "Executes shell commands, monitors processes, checks disk space, and verifies AppleScript capability",
    variables: { target_host: "localhost" },
    nodes: [
      { id: "step_disk", action: "shell.execute", params: { command: "df -h /" } },
      { id: "step_uptime", action: "shell.execute", params: { command: "uptime" } },
      { id: "step_applescript", action: "applescript.execute", params: { script: 'return "macOS Automation Runtime Active"' } },
      { id: "step_log", action: "python.execute", params: { code: "result['audit'] = 'System health verification complete'\nprint('Diagnostics complete')" } }
    ],
    edges: [
      { source: "step_disk", target: "step_uptime" },
      { source: "step_uptime", target: "step_applescript" },
      { source: "step_applescript", target: "step_log" }
    ]
  }
};

export default function App() {
  const [activeTab, setActiveTab] = useState<"designer" | "actions" | "executions" | "doctor">("designer");
  const [currentWorkflow, setCurrentWorkflow] = useState<Workflow>(SAMPLE_WORKFLOWS.file_pipeline);
  const [jsonInput, setJsonInput] = useState<string>(JSON.stringify(SAMPLE_WORKFLOWS.file_pipeline, null, 2));
  const [actionsList, setActionsList] = useState<any[]>([]);
  const [executionResult, setExecutionResult] = useState<any>(null);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [isDryRun, setIsDryRun] = useState<boolean>(false);
  const [doctorInfo, setDoctorInfo] = useState<string>("");
  const [storedWorkflows, setStoredWorkflows] = useState<any[]>([]);
  const [executionsHistory, setExecutionsHistory] = useState<any[]>([]);
  const [viewMode, setViewMode] = useState<"visual" | "json">("visual");

  useEffect(() => {
    fetchHealth();
    fetchActions();
    fetchWorkflows();
    fetchExecutions();
  }, []);

  const fetchHealth = async () => {
    try {
      const res = await fetch("/api/health");
      const data = await res.json();
      setDoctorInfo(data.doctor || "System operational");
    } catch (e) {
      setDoctorInfo("Failed to reach backend server");
    }
  };

  const fetchActions = async () => {
    try {
      const res = await fetch("/api/actions");
      const data = await res.json();
      setActionsList(data.actions || []);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchWorkflows = async () => {
    try {
      const res = await fetch("/api/workflows");
      const data = await res.json();
      setStoredWorkflows(data.workflows || []);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchExecutions = async () => {
    try {
      const res = await fetch("/api/executions");
      const data = await res.json();
      setExecutionsHistory(data.executions || []);
    } catch (e) {
      console.error(e);
    }
  };

  const handleWorkflowPresetChange = (key: string) => {
    const wf = SAMPLE_WORKFLOWS[key];
    if (wf) {
      setCurrentWorkflow(wf);
      setJsonInput(JSON.stringify(wf, null, 2));
      setExecutionResult(null);
    }
  };

  const handleJsonChange = (val: string) => {
    setJsonInput(val);
    try {
      const parsed = JSON.parse(val);
      if (parsed.id && parsed.nodes) {
        setCurrentWorkflow(parsed);
      }
    } catch (e) {
      // JSON syntax error during typing
    }
  };

  const runWorkflow = async () => {
    setIsRunning(true);
    setExecutionResult(null);
    try {
      const wfToRun = JSON.parse(jsonInput);
      const res = await fetch("/api/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          workflow: wfToRun,
          variables: wfToRun.variables || {},
          dry_run: isDryRun
        })
      });
      const data = await res.json();
      setExecutionResult(data);
      fetchExecutions();
    } catch (e: any) {
      setExecutionResult({ success: false, error: e.message || "Failed to execute workflow" });
    } finally {
      setIsRunning(false);
    }
  };

  const validateWorkflow = async () => {
    try {
      const wfToVal = JSON.parse(jsonInput);
      const res = await fetch("/api/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ workflow: wfToVal })
      });
      const data = await res.json();
      alert(data.valid ? `✅ Workflow is valid! Execution plan generated with ${data.plan.total_steps} steps.` : `❌ Validation failed: ${data.error}`);
    } catch (e: any) {
      alert(`Invalid JSON format: ${e.message}`);
    }
  };

  const emergencyStop = async () => {
    try {
      const res = await fetch("/api/stop-all", { method: "POST" });
      const data = await res.json();
      alert(`🛑 EMERGENCY KILL SWITCH TRIGGERED! Stopped ${data.stopped_count} running workflows.`);
    } catch (e: any) {
      alert(`Error triggering stop: ${e.message}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col antialiased">
      {/* Top Application Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md px-6 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-tr from-cyan-500 to-blue-600 p-2 rounded-xl shadow-lg shadow-cyan-500/20">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-bold tracking-tight text-white">MACRO.OS</h1>
              <span className="px-2 py-0.5 text-xs font-mono bg-cyan-950 text-cyan-400 border border-cyan-800 rounded-full">v1.0.0</span>
            </div>
            <p className="text-xs text-slate-400">High-Powered macOS Automation & Workflow Engine</p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center space-x-3">
          <button
            onClick={emergencyStop}
            id="btn-emergency-stop"
            className="flex items-center space-x-2 bg-red-950/80 hover:bg-red-900 text-red-400 border border-red-800/80 px-3 py-1.5 rounded-lg text-xs font-semibold transition shadow-sm"
          >
            <StopCircle className="w-4 h-4 text-red-400" />
            <span>Emergency Kill Switch</span>
          </button>
          <div className="h-5 w-px bg-slate-800" />
          <button
            onClick={runWorkflow}
            disabled={isRunning}
            id="btn-run-workflow"
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-bold transition shadow-lg ${
              isRunning
                ? "bg-slate-800 text-slate-500 cursor-not-allowed"
                : "bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-cyan-500/20"
            }`}
          >
            <Play className={`w-4 h-4 ${isRunning ? "animate-spin" : ""}`} />
            <span>{isRunning ? "Executing..." : isDryRun ? "Simulate Dry Run" : "Execute Workflow"}</span>
          </button>
        </div>
      </header>

      {/* Navigation Sub-header */}
      <div className="border-b border-slate-800 bg-slate-900/40 px-6 py-2 flex items-center justify-between">
        <nav className="flex space-x-1">
          {[
            { id: "designer", label: "Workflow Graph", icon: Layers },
            { id: "actions", label: "Action Inventory", icon: Cpu },
            { id: "executions", label: "Execution History", icon: Clock },
            { id: "doctor", label: "System Diagnostics", icon: Shield }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                id={`tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                  isActive
                    ? "bg-slate-800 text-cyan-400 border border-slate-700"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {activeTab === "designer" && (
          <div className="flex items-center space-x-3 text-xs">
            <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={isDryRun}
                onChange={(e) => setIsDryRun(e.target.checked)}
                className="rounded border-slate-700 bg-slate-900 text-cyan-500 focus:ring-cyan-500"
              />
              <span>Dry Run Simulation Mode</span>
            </label>
            <div className="h-4 w-px bg-slate-800" />
            <button
              onClick={validateWorkflow}
              className="text-slate-400 hover:text-cyan-400 font-mono transition"
            >
              [Validate Schema]
            </button>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden">
        {activeTab === "designer" && (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Left Sidebar: Presets & Variables */}
            <aside className="w-full md:w-80 border-r border-slate-800 bg-slate-900/30 p-4 flex flex-col space-y-6 overflow-y-auto">
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center space-x-2">
                  <Folder className="w-4 h-4 text-cyan-400" />
                  <span>Workflow Presets</span>
                </h3>
                <div className="space-y-2">
                  {Object.entries(SAMPLE_WORKFLOWS).map(([key, wf]) => (
                    <button
                      key={key}
                      id={`preset-${key}`}
                      onClick={() => handleWorkflowPresetChange(key)}
                      className={`w-full text-left p-3 rounded-xl border text-xs transition ${
                        currentWorkflow.id === wf.id
                          ? "bg-slate-800/80 border-cyan-500/50 text-cyan-300"
                          : "bg-slate-900/40 border-slate-800 text-slate-300 hover:bg-slate-800/40"
                      }`}
                    >
                      <div className="font-semibold">{wf.name}</div>
                      <div className="text-[11px] text-slate-400 line-clamp-2 mt-1">{wf.description}</div>
                      <div className="mt-2 flex items-center space-x-2 text-[10px] font-mono text-slate-500">
                        <span>{wf.nodes.length} nodes</span>
                        <span>•</span>
                        <span>v{wf.version}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-800 pt-4">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center space-x-2">
                  <Sliders className="w-4 h-4 text-blue-400" />
                  <span>Workflow Inputs</span>
                </h3>
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3 space-y-3">
                  {Object.entries(currentWorkflow.variables || {}).map(([k, v]) => (
                    <div key={k} className="space-y-1">
                      <label className="text-[11px] font-mono text-cyan-400">{k}</label>
                      <input
                        type="text"
                        value={String(v)}
                        onChange={(e) => {
                          const updated = { ...currentWorkflow.variables, [k]: e.target.value };
                          const wf = { ...currentWorkflow, variables: updated };
                          setCurrentWorkflow(wf);
                          setJsonInput(JSON.stringify(wf, null, 2));
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-200 focus:border-cyan-500 focus:outline-none"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </aside>

            {/* Center Canvas: Visual DAG or JSON Code View */}
            <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
              <div className="border-b border-slate-800 px-4 py-2 bg-slate-900/20 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-semibold text-slate-300">{currentWorkflow.name}</span>
                  <span className="text-[10px] font-mono text-slate-500">({currentWorkflow.id})</span>
                </div>
                <div className="flex bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs">
                  <button
                    onClick={() => setViewMode("visual")}
                    className={`px-3 py-1 rounded-md transition ${viewMode === "visual" ? "bg-slate-800 text-cyan-400 font-medium" : "text-slate-400 hover:text-slate-200"}`}
                  >
                    Visual DAG
                  </button>
                  <button
                    onClick={() => setViewMode("json")}
                    className={`px-3 py-1 rounded-md transition ${viewMode === "json" ? "bg-slate-800 text-cyan-400 font-medium" : "text-slate-400 hover:text-slate-200"}`}
                  >
                    Raw JSON Schema
                  </button>
                </div>
              </div>

              <div className="flex-1 p-6 overflow-y-auto">
                {viewMode === "visual" ? (
                  <div className="max-w-3xl mx-auto space-y-4">
                    {currentWorkflow.nodes.map((node, index) => {
                      const stepOutput = executionResult?.step_outputs?.[node.id];
                      return (
                        <div key={node.id} className="relative">
                          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-sm hover:border-slate-700 transition">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-3">
                                <span className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-mono font-bold text-slate-300">
                                  {index + 1}
                                </span>
                                <div>
                                  <h4 className="text-sm font-semibold text-slate-200 font-mono">{node.id}</h4>
                                  <span className="inline-block px-2 py-0.5 text-[10px] font-mono bg-cyan-950/60 text-cyan-400 border border-cyan-800/60 rounded-md mt-0.5">
                                    {node.action}
                                  </span>
                                </div>
                              </div>
                              {stepOutput && (
                                <span className="flex items-center space-x-1 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-800/40 px-2 py-1 rounded-md font-mono">
                                  <CheckCircle className="w-3.5 h-3.5" />
                                  <span>Passed</span>
                                </span>
                              )}
                            </div>

                            {/* Node Parameters */}
                            <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3 text-xs font-mono text-slate-400 space-y-1">
                              {Object.entries(node.params).map(([pk, pv]) => (
                                <div key={pk} className="flex space-x-2">
                                  <span className="text-slate-500">{pk}:</span>
                                  <span className="text-slate-300 break-all">{typeof pv === "object" ? JSON.stringify(pv) : String(pv)}</span>
                                </div>
                              ))}
                            </div>

                            {/* Output Inspector */}
                            {stepOutput && (
                              <div className="mt-3 border-t border-slate-800/80 pt-2 text-[11px] font-mono text-slate-400">
                                <span className="text-slate-500">Output Payload:</span>
                                <pre className="bg-slate-950 p-2 rounded-lg mt-1 text-slate-300 overflow-x-auto border border-slate-800">
                                  {JSON.stringify(stepOutput, null, 2)}
                                </pre>
                              </div>
                            )}
                          </div>

                          {index < currentWorkflow.nodes.length - 1 && (
                            <div className="flex justify-center my-2">
                              <div className="w-0.5 h-6 bg-cyan-500/30" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <textarea
                    value={jsonInput}
                    onChange={(e) => handleJsonChange(e.target.value)}
                    className="w-full h-full bg-slate-900 border border-slate-800 rounded-2xl p-4 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
                  />
                )}
              </div>
            </div>

            {/* Right Sidebar: Execution Telemetry & Audit Logs */}
            <aside className="w-full md:w-96 border-l border-slate-800 bg-slate-900/40 p-4 flex flex-col space-y-6 overflow-y-auto">
              <div>
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>Execution Telemetry</span>
                </h3>

                {executionResult ? (
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-400">Status</span>
                      <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded-md ${executionResult.success ? "bg-emerald-950 text-emerald-400 border border-emerald-800" : "bg-red-950 text-red-400 border border-red-800"}`}>
                        {executionResult.success ? "SUCCESS" : "FAILED"}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                        <div className="text-slate-500 text-[10px]">Duration</div>
                        <div className="text-cyan-400 font-bold mt-0.5">{executionResult.duration || 0}s</div>
                      </div>
                      <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                        <div className="text-slate-500 text-[10px]">Actions</div>
                        <div className="text-slate-200 font-bold mt-0.5">{executionResult.action_count || 0} executed</div>
                      </div>
                    </div>

                    {executionResult.profiler && (
                      <div className="border-t border-slate-800 pt-3">
                        <h4 className="text-[11px] font-semibold text-slate-400 mb-2">Performance Breakdown</h4>
                        <div className="space-y-1.5 text-[11px] font-mono">
                          {Object.entries(executionResult.profiler.breakdown || {}).map(([act, dur]) => (
                            <div key={act} className="flex justify-between text-slate-300">
                              <span className="truncate pr-2">{act}</span>
                              <span className="text-cyan-400">{String(dur)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 text-center text-xs text-slate-500">
                    No active execution runs yet. Click "Execute Workflow" to start.
                  </div>
                )}
              </div>
            </aside>
          </div>
        )}

        {activeTab === "actions" && (
          <div className="flex-1 p-6 overflow-y-auto">
            <h2 className="text-lg font-bold text-white mb-2">MACRO.OS Action Inventory</h2>
            <p className="text-xs text-slate-400 mb-6">Registered typed actions across Filesystem, UI, System, Python, AppleScript, and Control Flow</p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {actionsList.map((act) => (
                <div key={act.identifier} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 hover:border-slate-700 transition">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono font-bold text-cyan-400">{act.identifier}</span>
                    <span className="text-[10px] font-mono bg-slate-800 text-slate-400 px-2 py-0.5 rounded-md">{act.class}</span>
                  </div>
                  <p className="text-xs text-slate-300 mb-3">{act.doc || "Standard MACRO.OS automation action"}</p>
                  <div className="flex items-center space-x-1">
                    {act.permissions.map((p: string) => (
                      <span key={p} className="text-[10px] font-mono bg-cyan-950 text-cyan-400 border border-cyan-800 px-1.5 py-0.5 rounded-md">
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === "executions" && (
          <div className="flex-1 p-6 overflow-y-auto">
            <h2 className="text-lg font-bold text-white mb-2">Workflow Execution Log History</h2>
            <p className="text-xs text-slate-400 mb-6">SQLite persisted execution runs and audit trails</p>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 border-b border-slate-800 text-slate-400">
                  <tr>
                    <th className="p-3">Execution ID</th>
                    <th className="p-3">Workflow ID</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Duration</th>
                    <th className="p-3">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {executionsHistory.map((ex) => (
                    <tr key={ex.execution_id} className="hover:bg-slate-800/40">
                      <td className="p-3 text-cyan-400 font-bold">{ex.execution_id}</td>
                      <td className="p-3">{ex.workflow_id}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-md text-[10px] ${ex.status === "COMPLETED" ? "bg-emerald-950 text-emerald-400" : "bg-red-950 text-red-400"}`}>
                          {ex.status}
                        </span>
                      </td>
                      <td className="p-3">{ex.duration ? `${ex.duration.toFixed(3)}s` : "N/A"}</td>
                      <td className="p-3">{ex.action_count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "doctor" && (
          <div className="flex-1 p-6 overflow-y-auto">
            <h2 className="text-lg font-bold text-white mb-2">MACRO.OS System Diagnostics</h2>
            <p className="text-xs text-slate-400 mb-6">Real-time environment capability check</p>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <pre className="text-xs font-mono text-cyan-300 whitespace-pre-wrap">{doctorInfo}</pre>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
