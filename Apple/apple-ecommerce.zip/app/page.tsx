'use client';

import React, { useState } from 'react';
import { TopBar } from '@/components/Navigation/TopBar';
import { MegaMenu } from '@/components/MegaMenu/MegaMenu';
import { HeroSection } from '@/components/Hero/HeroSection';
import { BentoGrid } from '@/components/BentoGrid/BentoGrid';
import { EcosystemSection } from '@/components/Ecosystem/EcosystemSection';
import { ConfiguratorModal } from '@/components/ProductConfigurator/ConfiguratorModal';
import { BagDrawer } from '@/components/Bag/BagDrawer';
import { CheckoutModal } from '@/components/Checkout/CheckoutModal';
import { SearchOverlay } from '@/components/Search/SearchOverlay';
import { ProductCompareModal } from '@/components/Compare/ProductCompareModal';
import { MotionLab } from '@/components/MotionLab/MotionLab';
import { MotionDebugHUD } from '@/components/MotionDebug/MotionDebugHUD';
import { Footer } from '@/components/Footer/Footer';

export default function HomePage() {
  const [activeMegaCategory, setActiveMegaCategory] = useState<string | null>(null);

  return (
    <main className="min-h-screen bg-[#000000] text-white flex flex-col relative selection:bg-white selection:text-black">
      {/* 1. Global Navigation Top Bar */}
      <TopBar
        onHoverCategory={setActiveMegaCategory}
        activeMegaCategory={activeMegaCategory}
      />

      {/* 2. Interactive Mega Menu Dropdown */}
      <MegaMenu
        category={activeMegaCategory}
        onClose={() => setActiveMegaCategory(null)}
      />

      {/* 3. Cinematic Hero Section (iPhone 17 Pro + A19 Pro Silicon Callout) */}
      <div id="iphone">
        <HeroSection />
      </div>

      {/* 4. Bento Hardware Grid (MacBook Pro, iPad Pro, Apple Watch, AirPods Pro) */}
      <div id="mac">
        <BentoGrid />
      </div>

      {/* 5. Health, Adventure & iOS 26 Ecosystem Section */}
      <div id="watch">
        <EcosystemSection />
      </div>

      {/* 6. Footer with Legal Footnotes, Apple Directory & Locale */}
      <Footer />

      {/* 7. Floating Overlays & Spatial Surfaces */}
      <ConfiguratorModal />
      <BagDrawer />
      <CheckoutModal />
      <SearchOverlay />
      <ProductCompareModal />
      <MotionLab />
      <MotionDebugHUD />
    </main>
  );
}
