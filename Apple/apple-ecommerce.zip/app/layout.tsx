import type { Metadata } from 'next';
import './globals.css';
import { StoreProvider } from '@/lib/store';

export const metadata: Metadata = {
  title: 'Apple (UK) — Flagship Store & Precision Hardware',
  description:
    'The next generation of premium ecommerce, blending cinematic spatial composition, precision product configurator, real flight-to-bag physics, interactive 3D studio, and motion lab.',
  openGraph: {
    title: 'Apple (UK) — Flagship Store & Precision Hardware',
    description:
      'The next generation of premium ecommerce, blending cinematic spatial composition, precision product configurator, real flight-to-bag physics, interactive 3D studio, and motion lab.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Apple (UK) — Flagship Store & Precision Hardware',
    description:
      'The next generation of premium ecommerce, blending cinematic spatial composition, precision product configurator, real flight-to-bag physics, interactive 3D studio, and motion lab.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark bg-black text-white antialiased selection:bg-white selection:text-black">
      <body suppressHydrationWarning className="min-h-screen bg-[#000000] text-white flex flex-col font-sans">
        <StoreProvider>
          {children}
        </StoreProvider>
      </body>
    </html>
  );
}
