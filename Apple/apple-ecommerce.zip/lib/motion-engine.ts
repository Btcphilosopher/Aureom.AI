/**
 * Central Motion Physics Engine
 * Handles real spatial product flight paths, curves, and animations
 */

import { soundEngine } from './sound-engine';

export interface FlightOptions {
  sourceElement?: HTMLElement | null;
  destinationElement?: HTMLElement | null;
  image: string;
  duration?: number;
  onArrival?: () => void;
}

export function checkReducedMotion(): boolean {
  if (typeof window === 'undefined') return false;
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

export function animateProductToBag({
  sourceElement,
  destinationElement,
  image,
  duration = 680,
  onArrival,
}: FlightOptions) {
  if (typeof window === 'undefined') return;

  // 1. Accessibility Check: Skip flight if reduced motion is requested
  if (checkReducedMotion()) {
    soundEngine.playBagArrival();
    onArrival?.();
    return;
  }

  // Fallback to top right if destinationElement not provided
  let destX = window.innerWidth - 60;
  let destY = 24;

  if (destinationElement) {
    const destRect = destinationElement.getBoundingClientRect();
    destX = destRect.left + destRect.width / 2;
    destY = destRect.top + destRect.height / 2;
  }

  let srcX = window.innerWidth / 2;
  let srcY = window.innerHeight / 2;
  let srcWidth = 120;
  let srcHeight = 120;

  if (sourceElement) {
    const srcRect = sourceElement.getBoundingClientRect();
    srcX = srcRect.left + srcRect.width / 2;
    srcY = srcRect.top + srcRect.height / 2;
    srcWidth = Math.min(srcRect.width, 160);
    srcHeight = Math.min(srcRect.height, 160);
  }

  // Create temporary visual clone
  const clone = document.createElement('div');
  clone.className = 'product-flight-clone';
  clone.style.position = 'fixed';
  clone.style.left = `${srcX - srcWidth / 2}px`;
  clone.style.top = `${srcY - srcHeight / 2}px`;
  clone.style.width = `${srcWidth}px`;
  clone.style.height = `${srcHeight}px`;
  clone.style.zIndex = '999999';
  clone.style.pointerEvents = 'none';
  clone.style.borderRadius = '18px';
  clone.style.overflow = 'hidden';
  clone.style.boxShadow = '0 20px 50px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.15)';
  clone.style.willChange = 'transform, opacity';
  clone.style.transformOrigin = 'center center';

  const img = document.createElement('img');
  img.src = image;
  img.alt = 'Flying product clone';
  img.style.width = '100%';
  img.style.height = '100%';
  img.style.objectFit = 'contain';
  img.style.backgroundColor = 'rgba(20, 20, 25, 0.85)';
  img.style.backdropFilter = 'blur(12px)';
  clone.appendChild(img);

  document.body.appendChild(clone);

  // Flight curve mathematics: Quadratic Bezier Curve with elevated control point
  const startX = srcX - srcWidth / 2;
  const startY = srcY - srcHeight / 2;
  const targetX = destX - srcWidth / 2;
  const targetY = destY - srcHeight / 2;

  // Arc apex offset (lifts upwards before curving towards destination)
  const ctrlX = (startX + targetX) / 2 + (targetX > startX ? 40 : -40);
  const ctrlY = Math.min(startY, targetY) - 120; // Lift above both points

  const startTime = performance.now();

  function easeOutCubic(t: number): number {
    return 1 - Math.pow(1 - t, 3);
  }

  function step(now: number) {
    const elapsed = now - startTime;
    const rawProgress = Math.min(elapsed / duration, 1);
    const progress = easeOutCubic(rawProgress);

    // Quadratic bezier: B(t) = (1-t)^2 * P0 + 2(1-t)t * P1 + t^2 * P2
    const currentX =
      Math.pow(1 - progress, 2) * startX +
      2 * (1 - progress) * progress * ctrlX +
      Math.pow(progress, 2) * targetX;

    const currentY =
      Math.pow(1 - progress, 2) * startY +
      2 * (1 - progress) * progress * ctrlY +
      Math.pow(progress, 2) * targetY;

    // Scale from 1.05 down to 0.12 near destination
    const scale = rawProgress < 0.15
      ? 1 + rawProgress * 0.4
      : Math.max(0.12, 1.06 - Math.pow(progress, 1.4) * 0.94);

    // Tilt along velocity
    const rotation = (targetX > startX ? 1 : -1) * (progress * 22);

    // Slight fade at final 10%
    const opacity = progress > 0.88 ? 1 - (progress - 0.88) / 0.12 : 1;

    clone.style.transform = `translate3d(${currentX - startX}px, ${currentY - startY}px, 0) scale(${scale}) rotate(${rotation}deg)`;
    clone.style.opacity = `${opacity}`;

    if (rawProgress < 1) {
      requestAnimationFrame(step);
    } else {
      if (document.body.contains(clone)) {
        document.body.removeChild(clone);
      }
      soundEngine.playBagArrival();
      onArrival?.();
    }
  }

  requestAnimationFrame(step);
}
