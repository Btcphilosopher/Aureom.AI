'use client';

import React, { createContext, useContext, useState, useRef } from 'react';
import { Product, ProductVariant, StorageOption, AccessoryOption, BagItem, SavedItem, OrderDetails } from './types';
import { PRODUCTS, ACCESSORIES } from './catalog';
import { animateProductToBag } from './motion-engine';
import { soundEngine } from './sound-engine';

interface StoreContextType {
  // Catalog
  products: Product[];
  selectedProduct: Product;
  setSelectedProduct: (p: Product) => void;

  // Bag State
  bagItems: BagItem[];
  isBagOpen: boolean;
  setIsBagOpen: (open: boolean) => void;
  addToBag: (
    product: Product,
    variant: ProductVariant,
    storage: StorageOption,
    accessories?: AccessoryOption[],
    sourceElement?: HTMLElement | null
  ) => void;
  updateBagQuantity: (itemId: string, delta: number) => void;
  removeFromBag: (itemId: string) => void;
  bagCount: number;
  bagSubtotal: number;

  // Saved Items
  savedItems: SavedItem[];
  saveForLater: (item: BagItem) => void;
  moveToBag: (savedItem: SavedItem) => void;
  removeSavedItem: (id: string) => void;

  // Modals & Panels
  isConfiguratorOpen: boolean;
  setIsConfiguratorOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isCompareOpen: boolean;
  setIsCompareOpen: (open: boolean) => void;
  compareProductA: Product;
  setCompareProductA: (p: Product) => void;
  compareProductB: Product;
  setCompareProductB: (p: Product) => void;
  isMotionLabOpen: boolean;
  setIsMotionLabOpen: (open: boolean) => void;
  isMotionDebugOpen: boolean;
  setIsMotionDebugOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  completedOrder: OrderDetails | null;
  setCompletedOrder: (order: OrderDetails | null) => void;

  // Sound & Motion state
  isAudioMuted: boolean;
  toggleAudio: () => void;
  bagButtonRef: React.RefObject<HTMLButtonElement | null>;
  bagBumpState: boolean;

  // Analytics event dispatcher
  trackEvent: (eventName: string, properties?: Record<string, unknown>) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

const INITIAL_TIMESTAMP = 1774000000000;

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [products] = useState<Product[]>(PRODUCTS);
  const [selectedProduct, setSelectedProduct] = useState<Product>(PRODUCTS[0]);

  // Initial Bag Items from catalog for immediate rich experience
  const [bagItems, setBagItems] = useState<BagItem[]>([
    {
      id: 'bag-default-1',
      productId: PRODUCTS[0].id,
      name: PRODUCTS[0].name,
      variant: PRODUCTS[0].variants[0],
      storage: PRODUCTS[0].storageOptions[1],
      accessories: [ACCESSORIES[1]],
      quantity: 1,
      unitPrice: 1299 + 59,
      totalPrice: 1358,
      image: PRODUCTS[0].heroImage,
      addedAt: INITIAL_TIMESTAMP,
    },
  ]);

  const [savedItems, setSavedItems] = useState<SavedItem[]>([
    {
      id: 'saved-default-1',
      productId: PRODUCTS[3].id,
      name: PRODUCTS[3].name,
      variant: PRODUCTS[3].variants[0],
      storage: PRODUCTS[3].storageOptions[0],
      price: PRODUCTS[3].basePrice,
      image: PRODUCTS[3].heroImage,
      savedAt: INITIAL_TIMESTAMP - 3600000,
    },
  ]);

  const [isBagOpen, setIsBagOpen] = useState(false);
  const [isConfiguratorOpen, setIsConfiguratorOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [compareProductA, setCompareProductA] = useState<Product>(PRODUCTS[0]);
  const [compareProductB, setCompareProductB] = useState<Product>(PRODUCTS[1]);
  const [isMotionLabOpen, setIsMotionLabOpen] = useState(false);
  const [isMotionDebugOpen, setIsMotionDebugOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<OrderDetails | null>(null);

  // Lazy initializer to avoid synchronous setState inside an effect
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(() => soundEngine.getMuted());
  const [bagBumpState, setBagBumpState] = useState(false);

  const bagButtonRef = useRef<HTMLButtonElement | null>(null);

  const toggleAudio = () => {
    const muted = soundEngine.toggleMuted();
    setIsAudioMuted(muted);
  };

  const trackEvent = (eventName: string, properties?: Record<string, unknown>) => {
    if (typeof window !== 'undefined') {
      // Abstract telemetry logging
      console.info(`[Analytics Event] ${eventName}:`, properties || {});
    }
  };

  const bagCount = bagItems.reduce((acc, item) => acc + item.quantity, 0);
  const bagSubtotal = bagItems.reduce((acc, item) => acc + item.totalPrice, 0);

  const addToBag = (
    product: Product,
    variant: ProductVariant,
    storage: StorageOption,
    accessories: AccessoryOption[] = [],
    sourceElement?: HTMLElement | null
  ) => {
    const accCost = accessories.reduce((sum, a) => sum + a.price, 0);
    const unitPrice = product.basePrice + storage.priceDelta + accCost;

    const newItem: BagItem = {
      id: `bag-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      productId: product.id,
      name: product.name,
      variant,
      storage,
      accessories,
      quantity: 1,
      unitPrice,
      totalPrice: unitPrice,
      image: variant.image || product.heroImage,
      addedAt: Date.now(),
    };

    // Trigger flight animation
    animateProductToBag({
      sourceElement: sourceElement,
      destinationElement: bagButtonRef.current,
      image: newItem.image,
      onArrival: () => {
        setBagItems((prev) => [newItem, ...prev]);
        setBagBumpState(true);
        setTimeout(() => setBagBumpState(false), 350);
        trackEvent('added_to_bag', { productId: product.id, price: unitPrice });
      },
    });
  };

  const updateBagQuantity = (itemId: string, delta: number) => {
    setBagItems((prev) =>
      prev
        .map((item) => {
          if (item.id === itemId) {
            const nextQty = Math.max(0, item.quantity + delta);
            return nextQty === 0
              ? null
              : { ...item, quantity: nextQty, totalPrice: nextQty * item.unitPrice };
          }
          return item;
        })
        .filter(Boolean) as BagItem[]
    );
    soundEngine.playClick();
  };

  const removeFromBag = (itemId: string) => {
    setBagItems((prev) => prev.filter((item) => item.id !== itemId));
    trackEvent('removed_from_bag', { itemId });
    soundEngine.playClick();
  };

  const saveForLater = (item: BagItem) => {
    const saved: SavedItem = {
      id: `saved-${Date.now()}`,
      productId: item.productId,
      name: item.name,
      variant: item.variant,
      storage: item.storage,
      price: item.unitPrice,
      image: item.image,
      savedAt: Date.now(),
    };
    setSavedItems((prev) => [saved, ...prev]);
    removeFromBag(item.id);
    trackEvent('saved_for_later', { productId: item.productId });
  };

  const moveToBag = (saved: SavedItem) => {
    const product = products.find((p) => p.id === saved.productId) || products[0];
    addToBag(product, saved.variant, saved.storage, [], null);
    removeSavedItem(saved.id);
  };

  const removeSavedItem = (id: string) => {
    setSavedItems((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <StoreContext.Provider
      value={{
        products,
        selectedProduct,
        setSelectedProduct,
        bagItems,
        isBagOpen,
        setIsBagOpen,
        addToBag,
        updateBagQuantity,
        removeFromBag,
        bagCount,
        bagSubtotal,
        savedItems,
        saveForLater,
        moveToBag,
        removeSavedItem,
        isConfiguratorOpen,
        setIsConfiguratorOpen,
        isSearchOpen,
        setIsSearchOpen,
        isCompareOpen,
        setIsCompareOpen,
        compareProductA,
        setCompareProductA,
        compareProductB,
        setCompareProductB,
        isMotionLabOpen,
        setIsMotionLabOpen,
        isMotionDebugOpen,
        setIsMotionDebugOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        completedOrder,
        setCompletedOrder,
        isAudioMuted,
        toggleAudio,
        bagButtonRef,
        bagBumpState,
        trackEvent,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
