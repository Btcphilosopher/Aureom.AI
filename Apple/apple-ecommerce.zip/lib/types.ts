export interface ProductVariant {
  id: string;
  name: string;
  colorHex: string;
  finishLabel: string;
  image: string;
}

export interface StorageOption {
  id: string;
  capacity: string;
  priceDelta: number;
}

export interface AccessoryOption {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
}

export interface Product {
  id: string;
  name: string;
  tagline: string;
  kicker: string;
  description: string;
  basePrice: number;
  heroImage: string;
  category: 'iPhone' | 'Mac' | 'iPad' | 'Watch' | 'AirPods';
  badge?: string;
  variants: ProductVariant[];
  storageOptions: StorageOption[];
  specs: {
    chip: string;
    display: string;
    camera: string;
    battery: string;
    weight: string;
    waterResistance: string;
  };
  details: string[];
}

export interface BagItem {
  id: string;
  productId: string;
  name: string;
  variant: ProductVariant;
  storage: StorageOption;
  accessories: AccessoryOption[];
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  image: string;
  addedAt: number;
}

export interface SavedItem {
  id: string;
  productId: string;
  name: string;
  variant: ProductVariant;
  storage: StorageOption;
  price: number;
  image: string;
  savedAt: number;
}

export interface OrderDetails {
  orderNumber: string;
  createdAt: string;
  items: BagItem[];
  subtotal: number;
  tax: number;
  total: number;
  shippingMethod: 'Express Delivery (Tomorrow)' | 'Standard Delivery' | 'Apple Store Pickup';
  shippingAddress: {
    fullName: string;
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  paymentMethod: 'Apple Pay' | 'Credit Card' | 'Apple Card Monthly Installments';
}
