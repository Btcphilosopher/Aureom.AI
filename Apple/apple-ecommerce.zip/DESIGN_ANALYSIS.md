# DESIGN_ANALYSIS.md
# APPLE ECOMMERCE — Visual & Architectural Analysis

## 1. Executive Summary & Design Truth
The supplied design (`image.png`) captures the pinnacle of contemporary luxury industrial design applied to web commerce. It merges restrained dark-field cinema with airy, high-contrast light bento surfaces, creating an intentional rhythm between immersive editorial storytelling and crisp product acquisition.

Rather than copying Apple mechanically, our implementation treats the mock-up as an engineered physical object: surfaces hold depth, products have mass, navigation expands into structured information spaces, and shopping transitions are treated as physical spatial journeys.

---

## 2. Visual & Structural Dimensions

### A. Layout System & Grid
- **Global Viewport Baseline**: 1440px target width with responsive scaling from 375px (mobile) to 1920px+ (ultra-wide).
- **Hero Module**: Full-bleed 100vh cinematic stage with an asymmetric 55/45 split. Left 55% provides typographic negative space for the headline, value thesis, and CTA cluster; Right 45% houses the macro titanium camera bump and chassis with ambient horizon glow and interactive silicon callout (`A19 Pro`).
- **Mid-Tier Bento Grid**: 4-column balanced grid (`grid-cols-1 md:grid-cols-2 lg:grid-cols-4`, `gap-5` to `gap-6`). Alternating dark/light visual weight:
  - Card 1 (MacBook Pro): Pitch dark `#000000`, luminous blue screen.
  - Card 2 (iPad Pro): Pure light `#F5F5F7`, razor-thin diagonal overlap.
  - Card 3 (Apple Watch): Soft cool mist `#E9ECEF` with Midnight hardware.
  - Card 4 (AirPods Pro 2): Deep obsidian `#050505` with acoustic backlight halo.
- **Lower Story Bento**: 2-column asymmetric split (60% Lifestyle Story / 40% Platform Software).
  - Card 5 (Healthier You): Full-bleed alpine hiker landscape with floating frosted glass biometric telemetry cards (Heart Rate, Sleep, Activity Rings).
  - Card 6 (iOS 26): Minimal off-white stage featuring edge-to-edge hardware silhouette and floating frosted navigation dock with system capabilities.

### B. Spacing System
- **Micro Space**: `4px` (0.25rem), `8px` (0.5rem), `12px` (0.75rem).
- **Component Padding**: Card internal padding strictly `32px` (`p-8`), mobile `20px` (`p-5`).
- **Section Margins**: `64px` (`my-16`) to `96px` (`my-24`) of pure breathing room.
- **Mathematical Invariant**: Inner child margin $\le$ container inner padding.

### C. Typography
- **Display Heading**: High-density geometric grotesque with tight tracking (`-0.03em`), optical kerning, and strict `text-wrap: balance`.
  - Hero Headline: `clamp(2.75rem, 5vw, 4.5rem)` (44px–72px), weight 600.
  - Bento Titles: `22px`–`28px`, weight 600.
- **Body & Editorial**: Neutral legible sans (`15px`–`17px`, line-height `1.55`, color `#86868B` dark / `#1D1D1F` light).
- **Technical & Pricing**: Monospaced tabular numerals (`font-mono tabular-nums`) for jitter-free real-time price updates.
- **Kickers & Overlines**: `13px`–`14px`, weight 500, unboxed without pill enclosures.

### D. Colour Architecture (60-30-10 Distribution)
- **60% Dominant Neutral Canvas**:
  - Dark zones: `#000000` pitch black to `#0D0E12` deep space twilight.
  - Light zones: `#F5F5F7` clean ceramic off-white and `#FFFFFF` pure card faces.
- **30% Structural Surfaces**:
  - Translucent glass: `rgba(255, 255, 255, 0.08)` (dark) and `rgba(255, 255, 255, 0.65)` (frosted light).
  - Hairline dividers: `1px solid rgba(255, 255, 255, 0.12)` (dark) / `rgba(0, 0, 0, 0.08)` (light).
- **10% Accent Budget**:
  - Apple Horizon Glow: `#E09F67` warm twilight gold.
  - Interactive Action: `#0071E3` high-precision cobalt (or pure inverse white `#FFFFFF` in dark hero).

### E. Radius & Card Geometry
- Outer Bento Cards: `28px` (`rounded-[28px]`).
- Nested Controls & Buttons: `14px` (`rounded-[14px]`) to `9999px` for pill primary actions.
- Mathematical Rule: $r_{\text{inner}} = r_{\text{outer}} - \text{padding}$.

### F. Shadows & Ambient Lighting
- Subtle multi-layered ambient occlusion: `0 20px 40px -15px rgba(0, 0, 0, 0.12)`.
- Frosted glass backdrop blur: `backdrop-blur-xl` (16px–24px blur radius).
- Rim-lighting highlights on dark hardware: top-edge 1px highlight `inset 0 1px 0 rgba(255, 255, 255, 0.15)`.

---

## 3. Product Scale & Image Ratios
- **Hero Device**: Massive cinematic crop occupying 60% of right viewport, revealing fine precision details of the titanium alloy, sapphire lens bevels, and micro-machined microphone apertures.
- **Bento Devices**: Centered hardware floating with natural perspective, occupying 65%–75% of card visual height.
- **Aspect Ratios**:
  - Hero: `16:9` / full screen responsive container.
  - Product Bento: `4:3` container with contained device scaling.
  - Lifestyle Story: `16:10` landscape with overlaid UI panels.

---

## 4. Navigation & Interaction Architecture
- **Header**: Sticky single-row top bar with 3-zone contract (Brand mark -> 10 contextual category links -> Search + Bag trigger).
- **Mega-Navigation Surface**: Seamless vertical drawer reveal on category hover with featured hardware models, tech specs, and instant buy triggers.
- **Search Experience**: Instant spatial header expansion with fuzzy matching, hotkey `/` or `Cmd+K`, keyboard arrow selection, and instant add-to-bag.
- **The Bag**: First-class spatial drawer with curved flight trajectory animation from product coordinates to bag icon coordinates.
- **Configurator Engine**: Live dynamic configurator for Model, Finish, Storage, Accessories, and Trade-in with animated tabular price ticker and delivery estimates.

---

## 5. Accessibility & Performance Constraints
- Full WCAG AA contrast compliance across both dark and light zones.
- Native `prefers-reduced-motion` detection, replacing spatial fly-to-cart with clean instantaneous state transitions.
- GPU-only animations (`transform`, `opacity`, `filter`). Zero animation of `top`, `left`, `width`, or `height`.
- Tabular figures for all currency and metrics.
