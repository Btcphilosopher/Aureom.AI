/**
 * Design System Tokens: Motion Physics & Choreography
 * Springs, standard easings, and duration thresholds
 */

export const motionTokens = {
  duration: {
    instant: 0.1,
    micro: 0.18,
    fast: 0.28,
    normal: 0.45,
    slow: 0.7,
    cinematic: 1.0,
  },
  easing: {
    // Apple standard smooth deceleration curve
    standard: [0.16, 1, 0.3, 1] as const,
    emphasized: [0.2, 0.0, 0, 1.0] as const,
    enter: [0.0, 0.0, 0.2, 1] as const,
    exit: [0.4, 0.0, 1, 1] as const,
    flight: [0.25, 0.9, 0.25, 1.0] as const,
  },
  spring: {
    soft: { stiffness: 120, damping: 20 },
    gentle: { stiffness: 200, damping: 24 },
    medium: { stiffness: 300, damping: 26 },
    snappy: { stiffness: 450, damping: 30 },
    bouncy: { stiffness: 500, damping: 18 },
  },
} as const;

export type MotionToken = typeof motionTokens;
