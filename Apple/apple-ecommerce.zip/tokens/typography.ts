/**
 * Design System Tokens: Typography Hierarchy
 * Controlled scales, line heights, and letter-spacings
 */

export const typography = {
  fontFamily: {
    sans: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Helvetica, Arial, sans-serif',
    mono: 'SF Mono, Monaco, "Roboto Mono", Consolas, monospace',
  },
  fontSize: {
    hero: 'clamp(2.75rem, 5.5vw, 4.75rem)', // 44px - 76px
    display1: 'clamp(2.25rem, 4vw, 3.5rem)',
    display2: 'clamp(1.75rem, 3vw, 2.5rem)',
    title1: '1.75rem', // 28px
    title2: '1.5rem',  // 24px
    title3: '1.25rem', // 20px
    headline: '1.0625rem', // 17px
    body: '0.9375rem', // 15px
    callout: '0.875rem', // 14px
    subhead: '0.8125rem', // 13px
    footnote: '0.75rem', // 12px
    caption: '0.6875rem', // 11px
  },
  lineHeight: {
    tight: '1.08',
    snug: '1.2',
    normal: '1.45',
    relaxed: '1.6',
  },
  letterSpacing: {
    tighter: '-0.035em',
    tight: '-0.02em',
    normal: '0em',
    wide: '0.015em',
    wider: '0.04em',
  },
  fontWeight: {
    regular: '400',
    medium: '500',
    semibold: '600',
    bold: '700',
  },
} as const;

export type TypographyToken = typeof typography;
