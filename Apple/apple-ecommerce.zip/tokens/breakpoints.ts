/**
 * Design System Tokens: Responsive Breakpoints
 */

export const breakpoints = {
  xs: '375px',
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  '2xl': '1440px',
  '3xl': '1920px',
} as const;

export type BreakpointToken = typeof breakpoints;
