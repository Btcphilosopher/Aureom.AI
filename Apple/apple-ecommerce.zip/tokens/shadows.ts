/**
 * Design System Tokens: Ambient Occlusion & Shadows
 * Multi-layered physical light dropoffs
 */

export const shadows = {
  none: 'none',
  subtle: '0 2px 8px -2px rgba(0, 0, 0, 0.05)',
  card: '0 12px 32px -8px rgba(0, 0, 0, 0.08), 0 4px 12px -2px rgba(0, 0, 0, 0.03)',
  cardDark: '0 20px 50px -12px rgba(0, 0, 0, 0.7), 0 0 1px 1px rgba(255, 255, 255, 0.08)',
  elevated: '0 24px 64px -16px rgba(0, 0, 0, 0.16)',
  modal: '0 32px 80px -20px rgba(0, 0, 0, 0.28), 0 0 0 1px rgba(0, 0, 0, 0.05)',
  glowHorizon: '0 0 80px 20px rgba(224, 159, 103, 0.18)',
  glowAcoustic: '0 0 60px 15px rgba(180, 210, 255, 0.25)',
  rimLight: 'inset 0 1px 0 0 rgba(255, 255, 255, 0.15)',
} as const;

export type ShadowsToken = typeof shadows;
