/**
 * Design System Tokens: Geometry & Border Radius
 * Nested radius formula: r_inner = r_outer - padding
 */

export const radius = {
  none: '0px',
  xs: '6px',
  sm: '8px',
  md: '12px',
  lg: '16px',
  xl: '20px',
  card: '28px',
  surface: '32px',
  full: '9999px',
} as const;

export type RadiusToken = typeof radius;
