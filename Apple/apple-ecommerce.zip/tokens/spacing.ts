/**
 * Design System Tokens: Spacing & Layout
 * Systematic spacing derived from an 8pt base grid
 */

export const spacing = {
  px: '1px',
  0: '0px',
  1: '4px',
  2: '8px',
  3: '12px',
  4: '16px',
  5: '20px',
  6: '24px',
  8: '32px',
  10: '40px',
  12: '48px',
  16: '64px',
  20: '80px',
  24: '96px',
  32: '128px',
  
  container: {
    max: '1440px',
    content: '1200px',
    compact: '960px',
  },
} as const;

export type SpacingToken = typeof spacing;
