/**
 * Design System Tokens: Colour Architecture
 * Follows the 60-30-10 distribution constitution:
 * 60% neutral canvas, 30% structural surfaces, 10% accent budget
 */

export const colour = {
  // Dominant Neutrals
  canvas: {
    dark: '#000000',
    darkMuted: '#0b0c10',
    darkElevated: '#121318',
    light: '#F5F5F7',
    lightPure: '#FFFFFF',
    lightMuted: '#E9ECEF',
  },

  // Structural Surfaces & Translucencies
  surface: {
    glassDark: 'rgba(255, 255, 255, 0.08)',
    glassDarkSubtle: 'rgba(255, 255, 255, 0.04)',
    glassLight: 'rgba(255, 255, 255, 0.72)',
    glassLightSubtle: 'rgba(255, 255, 255, 0.45)',
    borderDark: 'rgba(255, 255, 255, 0.12)',
    borderDarkSubtle: 'rgba(255, 255, 255, 0.06)',
    borderLight: 'rgba(0, 0, 0, 0.08)',
    borderLightSubtle: 'rgba(0, 0, 0, 0.04)',
  },

  // Text Hierarchies
  text: {
    darkPrimary: '#F5F5F7',
    darkSecondary: '#86868B',
    darkTertiary: '#6E6E73',
    lightPrimary: '#1D1D1F',
    lightSecondary: '#6E6E73',
    lightTertiary: '#86868B',
  },

  // 10% High-Intent Accents
  accent: {
    cobalt: '#0071E3',
    cobaltHover: '#0077ED',
    horizonGold: '#E09F67',
    titaniumNatural: '#9E978E',
    titaniumDesert: '#C5A98F',
    titaniumBlack: '#2B2A2E',
    titaniumWhite: '#E2E3E5',
    success: '#30D158',
    warning: '#FF9F0A',
    danger: '#FF453A',
  },
} as const;

export type ColourToken = typeof colour;
