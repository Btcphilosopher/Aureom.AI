'use client';

import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Rotate3d, Sparkles, Compass } from 'lucide-react';

interface Interactive3DViewerProps {
  colorHex?: string;
  finishName?: string;
  className?: string;
}

export function Interactive3DViewer({
  colorHex = '#9E978E',
  finishName = 'Natural Titanium',
  className = '',
}: Interactive3DViewerProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [isRotating, setIsRotating] = useState(true);
  const isRotatingRef = useRef(true);

  useEffect(() => {
    isRotatingRef.current = isRotating;
  }, [isRotating]);

  const initialColorRef = useRef(colorHex);

  const [activePreset, setActivePreset] = useState<'hero' | 'cameras' | 'profile' | 'front'>('hero');

  // References to three objects for runtime updates
  const sceneRef = useRef<THREE.Scene | null>(null);
  const phoneGroupRef = useRef<THREE.Group | null>(null);
  const materialsRef = useRef<THREE.MeshStandardMaterial[]>([]);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const targetRotationRef = useRef<{ x: number; y: number }>({ x: 0.15, y: -0.45 });
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    // 1. Scene & Camera Setup
    const width = mount.clientWidth || 400;
    const height = mount.clientHeight || 400;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0, 7.5);
    cameraRef.current = camera;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch {
      return;
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    mount.replaceChildren(renderer.domElement);

    // 2. Lighting Setup (Studio Rim + Key Light + Ambient)
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff8ee, 1.8);
    keyLight.position.set(5, 6, 5);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x70aaff, 1.4);
    rimLight.position.set(-6, -2, -4);
    scene.add(rimLight);

    const bottomBounce = new THREE.DirectionalLight(0xe09f67, 0.6);
    bottomBounce.position.set(0, -6, 2);
    scene.add(bottomBounce);

    // 3. Procedural Precision Model of Titanium Smartphone
    const phoneGroup = new THREE.Group();
    phoneGroupRef.current = phoneGroup;

    materialsRef.current = [];

    // Body Material (Titanium Brushed Finish)
    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(initialColorRef.current),
      metalness: 0.92,
      roughness: 0.28,
      envMapIntensity: 1.2,
    });
    materialsRef.current.push(bodyMaterial);

    // Glass Screen & Backplate
    const glassFront = new THREE.MeshPhysicalMaterial({
      color: 0x050508,
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.1,
      reflectivity: 0.9,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05,
    });

    const glassBack = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(initialColorRef.current),
      metalness: 0.35,
      roughness: 0.22,
      clearcoat: 0.8,
    });
    materialsRef.current.push(glassBack);

    // Ceramic Chassis Body
    const bodyGeometry = new THREE.BoxGeometry(2.1, 4.3, 0.22);
    const bodyMesh = new THREE.Mesh(bodyGeometry, bodyMaterial);
    bodyMesh.castShadow = true;
    bodyMesh.receiveShadow = true;
    phoneGroup.add(bodyMesh);

    // Front Screen Panel
    const screenGeo = new THREE.BoxGeometry(1.98, 4.18, 0.02);
    const screenMesh = new THREE.Mesh(screenGeo, glassFront);
    screenMesh.position.z = 0.115;
    phoneGroup.add(screenMesh);

    // Back Frosted Matte Glass
    const backGeo = new THREE.BoxGeometry(1.98, 4.18, 0.02);
    const backMesh = new THREE.Mesh(backGeo, glassBack);
    backMesh.position.z = -0.115;
    phoneGroup.add(backMesh);

    // Camera Island (Raised Plateau)
    const islandMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(initialColorRef.current),
      metalness: 0.7,
      roughness: 0.15,
      clearcoat: 1.0,
    });
    materialsRef.current.push(islandMaterial);

    const islandGeo = new THREE.BoxGeometry(0.95, 0.95, 0.08);
    const islandMesh = new THREE.Mesh(islandGeo, islandMaterial);
    islandMesh.position.set(-0.48, 1.48, -0.15);
    phoneGroup.add(islandMesh);

    // 3 Triple Periscope & Fusion Camera Lenses
    const lensPositions = [
      [-0.68, 1.7, -0.21],
      [-0.68, 1.25, -0.21],
      [-0.28, 1.48, -0.21],
    ];

    const lensRingMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color(initialColorRef.current).offsetHSL(0, 0, 0.1),
      metalness: 0.98,
      roughness: 0.1,
    });
    materialsRef.current.push(lensRingMaterial);

    const lensGlassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x051025,
      metalness: 0.9,
      roughness: 0.02,
      clearcoat: 1.0,
      reflectivity: 1.0,
    });

    lensPositions.forEach(([x, y, z]) => {
      const ringGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.06, 32);
      ringGeo.rotateX(Math.PI / 2);
      const ringMesh = new THREE.Mesh(ringGeo, lensRingMaterial);
      ringMesh.position.set(x, y, z);
      phoneGroup.add(ringMesh);

      const glassLensGeo = new THREE.CylinderGeometry(0.13, 0.13, 0.065, 32);
      glassLensGeo.rotateX(Math.PI / 2);
      const glassMesh = new THREE.Mesh(glassLensGeo, lensGlassMaterial);
      glassMesh.position.set(x, y, z - 0.005);
      phoneGroup.add(glassMesh);
    });

    // Subtle Apple Logo Emboss
    const logoGeo = new THREE.CircleGeometry(0.18, 32);
    const logoMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(initialColorRef.current).offsetHSL(0, 0, -0.12),
      metalness: 0.95,
      roughness: 0.1,
    });
    const logoMesh = new THREE.Mesh(logoGeo, logoMat);
    logoMesh.position.set(0, 0.2, -0.126);
    logoMesh.rotation.y = Math.PI;
    phoneGroup.add(logoMesh);

    scene.add(phoneGroup);

    phoneGroup.rotation.x = targetRotationRef.current.x;
    phoneGroup.rotation.y = targetRotationRef.current.y;

    // 4. Mouse / Touch Drag Orbit Handlers
    const onPointerDown = (e: MouseEvent | TouchEvent) => {
      isDraggingRef.current = true;
      setIsRotating(false);
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
      previousMousePositionRef.current = { x: clientX, y: clientY };
    };

    const onPointerMove = (e: MouseEvent | TouchEvent) => {
      if (!isDraggingRef.current) return;
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

      const deltaX = clientX - previousMousePositionRef.current.x;
      const deltaY = clientY - previousMousePositionRef.current.y;

      targetRotationRef.current.y += deltaX * 0.008;
      targetRotationRef.current.x += deltaY * 0.008;

      // Clamp vertical tilt
      targetRotationRef.current.x = Math.max(-0.8, Math.min(0.8, targetRotationRef.current.x));

      previousMousePositionRef.current = { x: clientX, y: clientY };
    };

    const onPointerUp = () => {
      isDraggingRef.current = false;
    };

    mount.addEventListener('mousedown', onPointerDown);
    mount.addEventListener('touchstart', onPointerDown, { passive: true });
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('touchmove', onPointerMove, { passive: true });
    window.addEventListener('mouseup', onPointerUp);
    window.addEventListener('touchend', onPointerUp);

    // 5. Animation Loop
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (phoneGroupRef.current) {
        if (isRotatingRef.current && !isDraggingRef.current) {
          targetRotationRef.current.y += 0.004;
        }

        // Smooth damping interpolation
        phoneGroupRef.current.rotation.y +=
          (targetRotationRef.current.y - phoneGroupRef.current.rotation.y) * 0.08;
        phoneGroupRef.current.rotation.x +=
          (targetRotationRef.current.x - phoneGroupRef.current.rotation.x) * 0.08;
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!mountRef.current || !renderer || !camera) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      mount.removeEventListener('mousedown', onPointerDown);
      mount.removeEventListener('touchstart', onPointerDown);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      window.removeEventListener('touchend', onPointerUp);
      renderer.dispose();
      mount.replaceChildren();
    };
  }, []);

  // Update material color when finish changes
  useEffect(() => {
    if (materialsRef.current.length > 0) {
      const col = new THREE.Color(colorHex);
      materialsRef.current.forEach((mat) => {
        mat.color.set(col);
      });
    }
  }, [colorHex]);

  const setCameraPreset = (preset: 'hero' | 'cameras' | 'profile' | 'front') => {
    setActivePreset(preset);
    setIsRotating(false);
    if (preset === 'hero') {
      targetRotationRef.current = { x: 0.15, y: -0.45 };
    } else if (preset === 'cameras') {
      targetRotationRef.current = { x: 0.12, y: Math.PI - 0.2 };
    } else if (preset === 'profile') {
      targetRotationRef.current = { x: 0, y: Math.PI / 2 };
    } else if (preset === 'front') {
      targetRotationRef.current = { x: 0, y: 0 };
    }
  };

  return (
    <div className={`relative flex flex-col items-center justify-center select-none ${className}`}>
      {/* 3D WebGL Canvas Mount Container */}
      <div
        ref={mountRef}
        className="w-full h-[360px] md:h-[460px] cursor-grab active:cursor-grabbing touch-none flex items-center justify-center"
      />

      {/* Subtle Spatial Controls & Angle Presets */}
      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between px-3 py-2 bg-black/60 backdrop-blur-md rounded-2xl border border-white/10 text-xs text-white/80">
        <div className="flex items-center gap-2">
          <Rotate3d className="w-3.5 h-3.5 text-white/60" />
          <span className="hidden sm:inline text-white/60">Drag to rotate 360°</span>
          <span className="sm:hidden text-white/60">Drag 360°</span>
        </div>

        {/* Camera Preset Segmented Control */}
        <div className="flex items-center gap-1 bg-white/10 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setCameraPreset('hero')}
            className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
              activePreset === 'hero' ? 'bg-white text-black font-semibold' : 'text-white/80 hover:text-white'
            }`}
          >
            Angle
          </button>
          <button
            type="button"
            onClick={() => setCameraPreset('cameras')}
            className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
              activePreset === 'cameras' ? 'bg-white text-black font-semibold' : 'text-white/80 hover:text-white'
            }`}
          >
            Optics
          </button>
          <button
            type="button"
            onClick={() => setCameraPreset('profile')}
            className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
              activePreset === 'profile' ? 'bg-white text-black font-semibold' : 'text-white/80 hover:text-white'
            }`}
          >
            Edge
          </button>
          <button
            type="button"
            onClick={() => setCameraPreset('front')}
            className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
              activePreset === 'front' ? 'bg-white text-black font-semibold' : 'text-white/80 hover:text-white'
            }`}
          >
            Display
          </button>
        </div>

        <button
          type="button"
          onClick={() => setIsRotating(!isRotating)}
          className={`flex items-center gap-1 px-2 py-1 rounded-lg transition-colors ${
            isRotating ? 'bg-white/20 text-white' : 'text-white/50 hover:text-white'
          }`}
          title="Toggle Auto Orbit"
        >
          <Compass className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin' : ''}`} />
          <span className="hidden md:inline">{isRotating ? 'Orbiting' : 'Paused'}</span>
        </button>
      </div>

      {/* Micro Material Label */}
      <div className="absolute top-4 left-4 flex items-center gap-1.5 px-3 py-1 bg-black/40 backdrop-blur-md rounded-full border border-white/10 text-[11px] text-white/90">
        <span
          className="w-2.5 h-2.5 rounded-full border border-white/30"
          style={{ backgroundColor: colorHex }}
        />
        <span>{finishName}</span>
      </div>
    </div>
  );
}
