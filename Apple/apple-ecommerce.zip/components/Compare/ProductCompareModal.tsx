'use client';

import React from 'react';
import Image from 'next/image';
import { X, ArrowRightLeft, Check, Sparkles } from 'lucide-react';
import { useStore } from '@/lib/store';
import { soundEngine } from '@/lib/sound-engine';

export function ProductCompareModal() {
  const {
    isCompareOpen,
    setIsCompareOpen,
    products,
    compareProductA,
    setCompareProductA,
    compareProductB,
    setCompareProductB,
    setSelectedProduct,
    setIsConfiguratorOpen,
  } = useStore();

  if (!isCompareOpen) return null;

  const handleSwap = () => {
    soundEngine.playClick();
    const temp = compareProductA;
    setCompareProductA(compareProductB);
    setCompareProductB(temp);
  };

  const handleBuy = (product: typeof compareProductA) => {
    soundEngine.playClick();
    setSelectedProduct(product);
    setIsCompareOpen(false);
    setIsConfiguratorOpen(true);
  };

  const specsList = [
    { label: 'Processing Silicon', keyA: compareProductA.specs.chip, keyB: compareProductB.specs.chip },
    { label: 'Display Technology', keyA: compareProductA.specs.display, keyB: compareProductB.specs.display },
    { label: 'Optical Camera Array', keyA: compareProductA.specs.camera, keyB: compareProductB.specs.camera },
    { label: 'Battery Life', keyA: compareProductA.specs.battery, keyB: compareProductB.specs.battery },
    { label: 'Chassis & Weight', keyA: compareProductA.specs.weight, keyB: compareProductB.specs.weight },
    { label: 'Water Protection', keyA: compareProductA.specs.waterResistance, keyB: compareProductB.specs.waterResistance },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-2xl flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-300">
      <div className="relative w-full max-w-4xl bg-[#14151B] text-white rounded-[32px] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#14151B]/90 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <h2 className="text-base font-semibold tracking-tight text-white">Compare Hardware Models</h2>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleSwap}
              className="p-1.5 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-colors"
              title="Swap Models"
            >
              <ArrowRightLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setIsCompareOpen(false)}
              className="p-1.5 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-colors"
              aria-label="Close Compare"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Comparison Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-8">
          {/* Top Stage: 2 Selected Models */}
          <div className="grid grid-cols-2 gap-6 sm:gap-12 text-center">
            {/* Product A */}
            <div className="space-y-4 flex flex-col items-center">
              <select
                value={compareProductA.id}
                onChange={(e) => {
                  const match = products.find((p) => p.id === e.target.value);
                  if (match) setCompareProductA(match);
                }}
                className="bg-white/10 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id} className="bg-neutral-900 text-white">
                    {p.name}
                  </option>
                ))}
              </select>

              <div className="relative w-36 h-36 sm:w-48 sm:h-48 flex items-center justify-center">
                <Image
                  src={compareProductA.heroImage}
                  alt={compareProductA.name}
                  fill
                  className="object-contain p-2"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div>
                <h3 className="text-lg sm:text-xl font-semibold text-white">{compareProductA.name}</h3>
                <p className="text-xs text-white/60 mt-0.5">{compareProductA.tagline}</p>
                <p className="text-sm font-semibold font-mono text-white mt-1">From £{compareProductA.basePrice}</p>
              </div>

              <button
                type="button"
                onClick={() => handleBuy(compareProductA)}
                className="px-5 py-2 bg-white text-black font-semibold text-xs rounded-full hover:bg-white/90 transition-colors"
              >
                Buy {compareProductA.name}
              </button>
            </div>

            {/* Product B */}
            <div className="space-y-4 flex flex-col items-center">
              <select
                value={compareProductB.id}
                onChange={(e) => {
                  const match = products.find((p) => p.id === e.target.value);
                  if (match) setCompareProductB(match);
                }}
                className="bg-white/10 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id} className="bg-neutral-900 text-white">
                    {p.name}
                  </option>
                ))}
              </select>

              <div className="relative w-36 h-36 sm:w-48 sm:h-48 flex items-center justify-center">
                <Image
                  src={compareProductB.heroImage}
                  alt={compareProductB.name}
                  fill
                  className="object-contain p-2"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div>
                <h3 className="text-lg sm:text-xl font-semibold text-white">{compareProductB.name}</h3>
                <p className="text-xs text-white/60 mt-0.5">{compareProductB.tagline}</p>
                <p className="text-sm font-semibold font-mono text-white mt-1">From £{compareProductB.basePrice}</p>
              </div>

              <button
                type="button"
                onClick={() => handleBuy(compareProductB)}
                className="px-5 py-2 bg-white text-black font-semibold text-xs rounded-full hover:bg-white/90 transition-colors"
              >
                Buy {compareProductB.name}
              </button>
            </div>
          </div>

          {/* Aligned Specifications Comparison */}
          <div className="pt-6 border-t border-white/10 space-y-4">
            <h4 className="text-xs uppercase tracking-wider text-white/40 font-semibold text-center">
              Direct Technical Comparison
            </h4>

            <div className="divide-y divide-white/10">
              {specsList.map((spec, idx) => (
                <div key={idx} className="py-4 grid grid-cols-12 gap-4 items-center text-xs">
                  <div className="col-span-5 text-right font-medium text-white/90 pr-2">
                    {spec.keyA}
                  </div>
                  <div className="col-span-2 text-center text-[10px] text-white/40 uppercase tracking-wider">
                    {spec.label}
                  </div>
                  <div className="col-span-5 text-left font-medium text-white/90 pl-2">
                    {spec.keyB}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
