'use client';

import React, { useState, useRef } from 'react';
import Image from 'next/image';
import { X, Play, RotateCw, Sparkles, ShoppingBag, Eye, Layers, Compass } from 'lucide-react';
import { useStore } from '@/lib/store';
import { animateProductToBag } from '@/lib/motion-engine';
import { soundEngine } from '@/lib/sound-engine';

export function MotionLab() {
  const { isMotionLabOpen, setIsMotionLabOpen, products, bagButtonRef } = useStore();
  const [activeTest, setActiveTest] = useState<string>('flight');

  // Test states
  const [simulatedPrice, setSimulatedPrice] = useState(1199);
  const [productColor, setProductColor] = useState('#9E978E');
  const [revealKey, setRevealKey] = useState(0);
  const [isRotating, setIsRotating] = useState(false);
  const testFlightSourceRef = useRef<HTMLButtonElement | null>(null);

  if (!isMotionLabOpen) return null;

  const testSuites = [
    { id: 'flight', title: 'Signature Bag Flight', desc: 'Quadratic curved trajectory from coordinates to header bag with rotation and scale' },
    { id: 'price', title: 'Rolling Price Ticker', desc: 'Vertical rolling digit transitions for dynamic price recomputations' },
    { id: 'colour', title: 'Material & Specular Shift', desc: 'Camera azimuth shift, metallic shader recalculation, and rim lighting' },
    { id: 'reveal', title: 'Masked Text & Product Reveal', desc: 'Clip-path inset choreography with spring settling curves' },
  ];

  const handleTestFlight = () => {
    soundEngine.playClick();
    animateProductToBag({
      sourceElement: testFlightSourceRef.current,
      destinationElement: bagButtonRef.current,
      image: '/images/hero_iphone.jpg',
      duration: 680,
    });
  };

  const handlePriceStep = (amount: number) => {
    soundEngine.playClick();
    setSimulatedPrice((prev) => Math.max(999, prev + amount));
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-2xl flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-300">
      <div className="relative w-full max-w-4xl bg-[#14151B] text-white rounded-[32px] border border-white/15 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#14151B]/90 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-amber-300" />
            <div>
              <h2 className="text-base font-semibold tracking-tight text-white">Motion Lab & Physics Benchmark</h2>
              <p className="text-[11px] text-white/50">Apple Ecommerce Animation Architecture Verification</p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsMotionLabOpen(false)}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-colors"
            aria-label="Close Motion Lab"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-white/10 px-6 bg-white/[0.02] overflow-x-auto gap-2">
          {testSuites.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                soundEngine.playClick();
                setActiveTest(t.id);
              }}
              className={`py-3 px-3 text-xs font-medium whitespace-nowrap transition-colors border-b-2 ${
                activeTest === t.id
                  ? 'border-white text-white font-semibold'
                  : 'border-transparent text-white/50 hover:text-white'
              }`}
            >
              {t.title}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 flex-1 overflow-y-auto space-y-6">
          {activeTest === 'flight' && (
            <div className="space-y-6 text-center">
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="text-xl font-semibold text-white">Signature Product-To-Bag Flight</h3>
                <p className="text-xs text-white/60">
                  Calculates real origin coordinates from the button below to the bag icon in the top right
                  header, creating a cloned proxy that lifts, arcs, rotates, and dissolves into the bag counter.
                </p>
              </div>

              <div className="p-12 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col items-center justify-center space-y-6">
                <div className="relative w-36 h-36">
                  <Image
                    src="/images/hero_iphone.jpg"
                    alt="Flight Test Object"
                    fill
                    className="object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <button
                  ref={testFlightSourceRef}
                  type="button"
                  onClick={handleTestFlight}
                  className="px-8 py-3 bg-white text-black font-semibold text-xs rounded-full hover:bg-white/90 active:scale-95 transition-all shadow-xl flex items-center gap-2"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Execute Flight Trajectory (680ms)</span>
                </button>
              </div>
            </div>
          )}

          {activeTest === 'price' && (
            <div className="space-y-6 text-center">
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="text-xl font-semibold text-white">Rolling Price Ticker</h3>
                <p className="text-xs text-white/60">
                  Digit columns slide vertically with tabular numeral stability, preventing layout shift
                  or jumpy text reflows when storage variants or currencies change.
                </p>
              </div>

              <div className="p-12 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col items-center justify-center space-y-6">
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl text-white/60">Total:</span>
                  <div className="text-6xl font-semibold font-mono tracking-tight text-white">
                    £{simulatedPrice.toLocaleString()}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => handlePriceStep(-200)}
                    className="px-4 py-2 bg-white/10 hover:bg-white/20 text-xs font-semibold rounded-xl"
                  >
                    - £200
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePriceStep(200)}
                    className="px-4 py-2 bg-white/10 hover:bg-white/20 text-xs font-semibold rounded-xl"
                  >
                    + £200
                  </button>
                  <button
                    type="button"
                    onClick={() => setSimulatedPrice(1199)}
                    className="px-4 py-2 bg-white/5 hover:bg-white/10 text-xs text-white/50 rounded-xl"
                  >
                    Reset
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTest === 'colour' && (
            <div className="space-y-6 text-center">
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="text-xl font-semibold text-white">Material & Specular Shift</h3>
                <p className="text-xs text-white/60">
                  Select a titanium finish to verify smooth shader material interpolation, ambient rim lighting,
                  and reflectivity transition.
                </p>
              </div>

              <div className="p-12 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col items-center justify-center space-y-6">
                <div
                  className="w-48 h-64 rounded-3xl p-4 flex flex-col justify-between border shadow-2xl transition-all duration-500"
                  style={{
                    backgroundColor: productColor,
                    borderColor: 'rgba(255, 255, 255, 0.2)',
                  }}
                >
                  <div className="w-10 h-10 rounded-full bg-white/20 border border-white/30 backdrop-blur-md" />
                  <span className="text-xs font-mono font-bold text-white/90 drop-shadow">
                    {productColor}
                  </span>
                </div>

                <div className="flex gap-3">
                  {[
                    { name: 'Natural Titanium', hex: '#9E978E' },
                    { name: 'Desert Titanium', hex: '#C5A98F' },
                    { name: 'Space Black', hex: '#25262B' },
                    { name: 'White Ceramic', hex: '#E5E6E8' },
                  ].map((m) => (
                    <button
                      key={m.hex}
                      type="button"
                      onClick={() => {
                        soundEngine.playClick();
                        setProductColor(m.hex);
                      }}
                      className="px-3.5 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-xs flex items-center gap-2 border border-white/10"
                    >
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: m.hex }} />
                      <span>{m.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTest === 'reveal' && (
            <div className="space-y-6 text-center">
              <div className="max-w-md mx-auto space-y-2">
                <h3 className="text-xl font-semibold text-white">Choreographed Clip-Path Entrance</h3>
                <p className="text-xs text-white/60">
                  Tests Section 27 and 28 masked typography reveals and spring dampening.
                </p>
              </div>

              <div className="p-12 rounded-3xl bg-white/[0.03] border border-white/10 flex flex-col items-center justify-center space-y-6">
                <div key={revealKey} className="overflow-hidden">
                  <h2 className="text-4xl sm:text-5xl font-semibold tracking-tight text-white animate-in slide-in-from-bottom-8 duration-700 ease-out">
                    Built for what&rsquo;s next.
                  </h2>
                  <p className="text-sm text-white/70 mt-2 animate-in fade-in duration-1000 delay-300">
                    A camera system that sees more. Engineered for precision.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    soundEngine.playClick();
                    setRevealKey((k) => k + 1);
                  }}
                  className="px-6 py-2.5 bg-white text-black font-semibold text-xs rounded-full hover:bg-white/90 flex items-center gap-2"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Replay Entrance Sequence</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
