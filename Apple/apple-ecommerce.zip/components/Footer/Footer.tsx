'use client';

import React from 'react';
import { Globe } from 'lucide-react';

export function Footer() {
  const directorySections = [
    {
      title: 'Shop and Learn',
      links: ['Store', 'Mac', 'iPad', 'iPhone', 'Watch', 'Vision', 'AirPods', 'TV & Home', 'AirTag', 'Accessories', 'Gift Cards'],
    },
    {
      title: 'Account',
      links: ['Manage Your Apple ID', 'Apple Store Account', 'iCloud.com'],
    },
    {
      title: 'Entertainment',
      links: ['Apple One', 'Apple TV+', 'Apple Music', 'Apple Arcade', 'Apple Fitness+', 'Apple News+', 'Apple Podcasts', 'Apple Books', 'App Store'],
    },
    {
      title: 'Apple Store',
      links: ['Find a Store', 'Genius Bar', 'Today at Apple', 'Apple Summer Camp', 'Apple Store App', 'Certified Refurbished', 'Apple Trade In', 'Order Status', 'Shopping Help'],
    },
    {
      title: 'For Business & Education',
      links: ['Apple and Business', 'Shop for Business', 'Apple and Education', 'Shop for K-12', 'Shop for College'],
    },
    {
      title: 'Apple Values & About',
      links: ['Accessibility', 'Education', 'Environment', 'Inclusion and Diversity', 'Privacy', 'Racial Equity and Justice', 'Supply Chain', 'Newsroom', 'Apple Leadership', 'Career Opportunities', 'Investors', 'Ethics & Compliance'],
    },
  ];

  return (
    <footer className="w-full bg-[#050507] text-[#86868B] text-[11px] border-t border-white/[0.08] mt-16">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 py-10 space-y-6">
        {/* Footnotes & Disclaimers per Section 25 */}
        <div className="space-y-2 border-b border-white/[0.08] pb-6 leading-relaxed">
          <p>
            1. Trade-in values will vary based on the condition, year, and configuration of your eligible trade-in device. Not all devices are eligible for credit. You must be at least 18 years old to be eligible to trade in for credit or for an Apple Gift Card. Trade-in value may be applied toward qualifying new device purchase, or added to an Apple Gift Card.
          </p>
          <p>
            2. Available for qualified applicants and subject to credit approval and credit limit. 0% APR financing is available for 24 months on eligible iPhone and Mac purchases with Apple Card Monthly Installments.
          </p>
          <p>
            3. iPhone 17 Pro is splash, water, and dust resistant and was tested under controlled laboratory conditions with a rating of IP68 under IEC standard 60529 (maximum depth of 6 meters up to 30 minutes). Splash, water, and dust resistance are not permanent conditions and resistance might decrease as a result of normal wear.
          </p>
          <p>
            4. Battery life claims depend on network configuration and many other factors; actual results will vary. Battery has limited recharge cycles and may eventually need to be replaced.
          </p>
        </div>

        {/* Apple Directory Column Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 py-4">
          {directorySections.map((section, idx) => (
            <div key={idx} className="space-y-2.5">
              <h4 className="text-white/80 font-semibold tracking-tight text-xs">
                {section.title}
              </h4>
              <ul className="space-y-1.5">
                {section.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="hover:text-white transition-colors"
                      onClick={(e) => e.preventDefault()}
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Global Footer Sub-bar */}
        <div className="pt-6 border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 text-center sm:text-left">
            <span>Copyright © 2026 Apple Inc. All rights reserved.</span>
            <div className="flex flex-wrap items-center gap-2 text-white/60">
              <a href="#" className="hover:text-white">Privacy Policy</a>
              <span>·</span>
              <a href="#" className="hover:text-white">Terms of Use</a>
              <span>·</span>
              <a href="#" className="hover:text-white">Sales Policy</a>
              <span>·</span>
              <a href="#" className="hover:text-white">Legal</a>
              <span>·</span>
              <a href="#" className="hover:text-white">Site Map</a>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-white/80 hover:text-white cursor-pointer">
            <Globe className="w-3.5 h-3.5" />
            <span>United Kingdom</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
