'use client';

import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { X, CheckCircle2, CreditCard, ShieldCheck, Truck, Store, ArrowRight, ArrowLeft, Lock } from 'lucide-react';
import { useStore } from '@/lib/store';
import { soundEngine } from '@/lib/sound-engine';
import { OrderDetails } from '@/lib/types';

export function CheckoutModal() {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    bagItems,
    bagSubtotal,
    setCompletedOrder,
    trackEvent,
  } = useStore();

  const [step, setStep] = useState<'shipping' | 'payment' | 'processing' | 'confirmed'>('shipping');
  const [shippingMethod, setShippingMethod] = useState<'Express Delivery (Tomorrow)' | 'Standard Delivery' | 'Apple Store Pickup'>('Express Delivery (Tomorrow)');

  const [formData, setFormData] = useState({
    fullName: 'Alexander Sterling',
    street: '1 Hanover Square',
    city: 'London',
    state: 'Greater London',
    zipCode: 'W1S 1JQ',
    country: 'United Kingdom',
    email: 'alexander.sterling@icloud.com',
    cardNumber: '•••• •••• •••• 4242',
  });

  if (!isCheckoutOpen) return null;

  const handleNextStep = () => {
    soundEngine.playClick();
    if (step === 'shipping') {
      setStep('payment');
    } else if (step === 'payment') {
      setStep('processing');
      // Simulate real bank authorization
      setTimeout(() => {
        const orderNumber = `W${Math.floor(100000000 + Math.random() * 900000000)}`;
        const order: OrderDetails = {
          orderNumber,
          createdAt: new Date().toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'long',
            year: 'numeric',
          }),
          items: bagItems,
          subtotal: bagSubtotal,
          tax: Math.round(bagSubtotal * 0.2),
          total: bagSubtotal,
          shippingMethod,
          shippingAddress: formData,
          paymentMethod: 'Apple Pay',
        };

        setCompletedOrder(order);
        setStep('confirmed');
        soundEngine.playCheckoutSuccess();
        trackEvent('checkout_completed', { orderNumber, total: bagSubtotal });

        // Trigger celebratory confetti burst
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#0071E3', '#FFFFFF', '#E09F67', '#30D158'],
          });
        } catch {
          // graceful fallback
        }
      }, 1200);
    }
  };

  const handleClose = () => {
    setIsCheckoutOpen(false);
    setStep('shipping');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-2xl flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-300">
      <div className="relative w-full max-w-2xl bg-[#14151B] text-white rounded-[32px] border border-white/10 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#14151B]/90 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <Lock className="w-4 h-4 text-emerald-400" />
            <span className="text-sm font-semibold tracking-tight text-white">Apple Secure Checkout</span>
          </div>

          <button
            type="button"
            onClick={handleClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-colors"
            aria-label="Close Checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Multi-Step Flow */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Step 1: Shipping Details */}
          {step === 'shipping' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="space-y-1">
                <h3 className="text-xl font-semibold tracking-tight text-white">
                  Where should we send your order?
                </h3>
                <p className="text-xs text-white/60">
                  Select your preferred delivery speed or pick up today at an Apple Store.
                </p>
              </div>

              {/* Shipping Speed Radios */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setShippingMethod('Express Delivery (Tomorrow)')}
                  className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                    shippingMethod === 'Express Delivery (Tomorrow)'
                      ? 'border-white bg-white/10 ring-1 ring-white/30'
                      : 'border-white/10 hover:border-white/20 bg-white/[0.02]'
                  }`}
                >
                  <Truck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-white">Express Delivery (Tomorrow)</p>
                    <p className="text-[11px] text-white/60 mt-0.5">Signature required · Tracked Courier</p>
                    <p className="text-xs font-semibold text-emerald-400 mt-1">FREE</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setShippingMethod('Apple Store Pickup')}
                  className={`p-4 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                    shippingMethod === 'Apple Store Pickup'
                      ? 'border-white bg-white/10 ring-1 ring-white/30'
                      : 'border-white/10 hover:border-white/20 bg-white/[0.02]'
                  }`}
                >
                  <Store className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-white">Apple Regent Street</p>
                    <p className="text-[11px] text-white/60 mt-0.5">Ready for pickup today in 2 hours</p>
                    <p className="text-xs font-semibold text-emerald-400 mt-1">FREE</p>
                  </div>
                </button>
              </div>

              {/* Address Form Inputs */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-white/50">
                  Shipping Address
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-white/60 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-white/60 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-white"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] text-white/60 mb-1">Street Address</label>
                    <input
                      type="text"
                      value={formData.street}
                      onChange={(e) => setFormData({ ...formData, street: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-white/60 mb-1">City</label>
                    <input
                      type="text"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-white/60 mb-1">Postal Code</label>
                    <input
                      type="text"
                      value={formData.zipCode}
                      onChange={(e) => setFormData({ ...formData, zipCode: e.target.value })}
                      className="w-full px-3.5 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-white"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Payment Options */}
          {step === 'payment' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="space-y-1">
                <h3 className="text-xl font-semibold tracking-tight text-white">
                  Payment Method
                </h3>
                <p className="text-xs text-white/60">
                  Biometrically verified payment powered by Apple Pay or major card networks.
                </p>
              </div>

              {/* Apple Pay 1-Click Banner */}
              <div className="p-5 rounded-2xl bg-white text-black flex items-center justify-between shadow-xl cursor-pointer hover:bg-neutral-100 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-black text-white rounded-xl flex items-center justify-center font-semibold text-xs">
                    Pay
                  </div>
                  <div>
                    <p className="text-xs font-semibold">Pay with Apple Pay</p>
                    <p className="text-[11px] text-neutral-600">Default Card · Touch ID / Face ID verified</p>
                  </div>
                </div>
                <span className="text-xs font-semibold px-3 py-1 bg-black text-white rounded-full">
                  Quick Pay
                </span>
              </div>

              <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-white/10" />
                <span className="flex-shrink mx-4 text-[11px] text-white/40 uppercase">
                  Or pay with Credit Card
                </span>
                <div className="flex-grow border-t border-white/10" />
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white">Apple Card & Major Credit Cards</span>
                  <CreditCard className="w-4 h-4 text-white/60" />
                </div>
                <input
                  type="text"
                  readOnly
                  value="4242 •••• •••• 4242 (Expires 12/28)"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/10 rounded-xl text-xs text-white font-mono"
                />
                <p className="text-[11px] text-emerald-400">
                  Earn 3% Daily Cash back when you pay with Apple Card.
                </p>
              </div>
            </div>
          )}

          {/* Step 3: Authorization Animation */}
          {step === 'processing' && (
            <div className="py-16 flex flex-col items-center justify-center text-center space-y-4 animate-in fade-in">
              <div className="w-16 h-16 rounded-full border-2 border-white/20 border-t-white animate-spin" />
              <h3 className="text-lg font-semibold text-white">Securing Authorization...</h3>
              <p className="text-xs text-white/60 max-w-xs">
                Encrypted transaction through Apple Secure Enclave.
              </p>
            </div>
          )}

          {/* Step 4: Confirmed Order Receipt & Passbook */}
          {step === 'confirmed' && (
            <div className="space-y-6 animate-in fade-in zoom-in-95 duration-300">
              <div className="text-center space-y-2">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                <h3 className="text-2xl font-semibold text-white tracking-tight">
                  Thank you for your order.
                </h3>
                <p className="text-xs text-white/70">
                  We’ve sent your confirmation and tracking link to{' '}
                  <span className="text-white font-medium">{formData.email}</span>.
                </p>
              </div>

              {/* Passbook / Receipt Card */}
              <div className="p-5 rounded-2xl bg-white/[0.04] border border-white/10 space-y-4">
                <div className="flex justify-between items-center border-b border-white/10 pb-3 text-xs">
                  <div>
                    <p className="text-white/40">Order Number</p>
                    <p className="font-mono font-semibold text-white mt-0.5">W984218942</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white/40">Estimated Arrival</p>
                    <p className="font-semibold text-emerald-400 mt-0.5">Thursday, 25 Sep</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-[11px] uppercase tracking-wider text-white/40">Items</p>
                  {bagItems.map((item) => (
                    <div key={item.id} className="flex justify-between text-xs">
                      <span className="text-white/80">
                        {item.quantity}x {item.name} ({item.variant.name})
                      </span>
                      <span className="font-mono text-white">£{item.totalPrice.toLocaleString()}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-white/10 pt-3 flex justify-between items-center text-sm font-semibold">
                  <span className="text-white/70">Total Paid</span>
                  <span className="font-mono text-white text-base">
                    £{bagSubtotal.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="flex justify-center pt-2">
                <button
                  type="button"
                  onClick={handleClose}
                  className="px-8 py-3 bg-white text-black text-xs font-semibold rounded-full hover:bg-white/90 transition-colors"
                >
                  Return to Storefront
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        {step !== 'confirmed' && step !== 'processing' && (
          <div className="px-6 py-4 border-t border-white/10 bg-[#101116] shrink-0 flex items-center justify-between">
            {step === 'payment' ? (
              <button
                type="button"
                onClick={() => setStep('shipping')}
                className="inline-flex items-center gap-1.5 text-xs text-white/60 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Shipping</span>
              </button>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-white/50">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>256-bit SSL Protection</span>
              </div>
            )}

            <button
              type="button"
              onClick={handleNextStep}
              className="px-6 py-2.5 bg-white text-black font-semibold text-xs rounded-full hover:bg-white/90 transition-all flex items-center gap-1.5"
            >
              <span>{step === 'shipping' ? 'Continue to Payment' : `Authorize £${bagSubtotal.toLocaleString()}`}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
