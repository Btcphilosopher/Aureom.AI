'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Search, ShoppingBag, Volume2, VolumeX, Activity, Menu, X, Sparkles, Scale } from 'lucide-react';
import { useStore } from '@/lib/store';
import { soundEngine } from '@/lib/sound-engine';

interface TopBarProps {
  onHoverCategory?: (category: string | null) => void;
  activeMegaCategory?: string | null;
}

const NAV_LINKS = [
  'Store',
  'Mac',
  'iPad',
  'iPhone',
  'Watch',
  'Vision',
  'AirPods',
  'TV & Home',
  'Entertainment',
  'Accessories',
  'Support',
];

export function TopBar({ onHoverCategory, activeMegaCategory }: TopBarProps) {
  const {
    bagCount,
    setIsBagOpen,
    setIsSearchOpen,
    setIsCompareOpen,
    setIsMotionLabOpen,
    setIsMotionDebugOpen,
    isMotionDebugOpen,
    isAudioMuted,
    toggleAudio,
    bagButtonRef,
    bagBumpState,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (category: string) => {
    soundEngine.playClick();
    if (category === 'iPhone' || category === 'Mac' || category === 'iPad' || category === 'Watch' || category === 'AirPods') {
      const el = document.getElementById(category.toLowerCase());
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-[#000000]/80 backdrop-blur-xl border-b border-white/[0.08] transition-colors duration-300">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 h-12 flex items-center justify-between text-xs tracking-normal">
        {/* Zone 1: Brand Wordmark / Apple Monogram */}
        <div className="flex items-center gap-3 shrink-0">
          <Link
            href="/"
            className="flex items-center gap-1.5 text-white/90 hover:text-white transition-opacity focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-white/40 rounded-sm"
            aria-label="Apple Ecommerce Home"
          >
            {/* Apple Logo SVG */}
            <svg
              className="w-4 h-4 fill-current text-white"
              viewBox="0 0 170 170"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.04-7.69-7.8-12-14.28-6.19-9.35-11.12-20.03-14.77-32.06-3.66-12.02-5.5-23.47-5.5-34.33 0-14.35 3.42-26.23 10.27-35.63 6.85-9.4 15.42-14.21 25.7-14.42 5.02 0 10.59 1.41 16.71 4.23 6.13 2.83 10.15 4.3 12.06 4.44 1.52-.14 5.79-1.68 12.8-4.64 7.02-2.95 13.06-4.22 18.14-3.8 13.48.77 24.36 5.66 32.64 14.67-11.75 7.13-17.48 16.9-17.2 29.31.29 9.8 4.14 18.06 11.55 24.78 7.42 6.72 16.27 10.42 26.56 11.12-2.58 8.01-5.91 16.32-9.99 24.94zM119.22 33.15c0-7.39 2.68-14.39 8.04-20.98 5.36-6.6 12.09-10.82 20.19-12.67.22 1.3.33 2.45.33 3.43 0 7.39-2.78 14.52-8.35 21.39-5.57 6.87-12.38 11.02-20.43 12.44-.22-1.08-.33-2.13-.33-3.61z" />
            </svg>
            <span className="font-semibold text-sm tracking-tight text-white">Apple</span>
          </Link>
        </div>

        {/* Zone 2: Navigation Links (Desktop) */}
        <nav
          className="hidden lg:flex items-center space-x-6 text-white/70 font-normal"
          onMouseLeave={() => onHoverCategory?.(null)}
        >
          {NAV_LINKS.map((link) => (
            <button
              key={link}
              type="button"
              onClick={() => handleNavClick(link)}
              onMouseEnter={() => onHoverCategory?.(link)}
              className={`hover:text-white transition-colors duration-150 py-3 relative ${
                activeMegaCategory === link ? 'text-white' : ''
              }`}
            >
              {link}
              {activeMegaCategory === link && (
                <span className="absolute bottom-1 left-0 right-0 h-[2px] bg-white rounded-full transition-all" />
              )}
            </button>
          ))}
        </nav>

        {/* Zone 3: Primary Actions (Search, Compare, Motion Lab, Audio, Bag) */}
        <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0 text-white/80">
          {/* Compare Modal Trigger */}
          <button
            type="button"
            onClick={() => {
              soundEngine.playClick();
              setIsCompareOpen(true);
            }}
            className="p-1.5 hover:text-white transition-colors rounded-full hover:bg-white/10 hidden sm:flex items-center gap-1"
            title="Compare Models"
            aria-label="Compare Products"
          >
            <Scale className="w-3.5 h-3.5" />
            <span className="text-[11px] font-medium hidden md:inline">Compare</span>
          </button>

          {/* Search Trigger */}
          <button
            type="button"
            onClick={() => {
              soundEngine.playClick();
              setIsSearchOpen(true);
            }}
            className="p-1.5 hover:text-white transition-colors rounded-full hover:bg-white/10"
            title="Search Products (Cmd+K)"
            aria-label="Search Catalog"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Sound Architecture Toggle (Muted by default) */}
          <button
            type="button"
            onClick={toggleAudio}
            className={`p-1.5 transition-colors rounded-full ${
              isAudioMuted ? 'text-white/40 hover:text-white hover:bg-white/10' : 'text-white bg-white/15'
            }`}
            title={isAudioMuted ? 'Unmute Sound Effects' : 'Mute Sound Effects'}
            aria-label="Toggle Interaction Sound"
          >
            {isAudioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Motion Lab Trigger */}
          <button
            type="button"
            onClick={() => {
              soundEngine.playClick();
              setIsMotionLabOpen(true);
            }}
            className="hidden sm:flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-white/90 bg-white/10 hover:bg-white/20 rounded-full transition-all border border-white/10"
            title="Open Motion Lab"
          >
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>Motion Lab</span>
          </button>

          {/* Motion Debug HUD Toggle */}
          <button
            type="button"
            onClick={() => setIsMotionDebugOpen(!isMotionDebugOpen)}
            className={`p-1.5 transition-colors rounded-full hidden xl:block ${
              isMotionDebugOpen ? 'text-emerald-400 bg-white/15' : 'text-white/40 hover:text-white hover:bg-white/10'
            }`}
            title="Toggle Motion Debug HUD"
            aria-label="Motion Debug HUD"
          >
            <Activity className="w-3.5 h-3.5" />
          </button>

          {/* The Shopping Bag Icon with Flight Target Ref & Rolling Digit Counter */}
          <button
            ref={bagButtonRef}
            type="button"
            onClick={() => {
              soundEngine.playClick();
              setIsBagOpen(true);
            }}
            className={`relative p-1.5 hover:text-white transition-transform duration-200 rounded-full hover:bg-white/10 ${
              bagBumpState ? 'scale-125 text-white' : 'scale-100'
            }`}
            title="Open Shopping Bag"
            aria-label={`Shopping Bag (${bagCount} items)`}
          >
            <ShoppingBag className="w-4 h-4" />
            {/* Dynamic Digit Counter with Vertical Slide Transition */}
            {bagCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-white text-black text-[10px] font-bold rounded-full flex items-center justify-center overflow-hidden shadow-sm">
                <span className="block transform transition-transform duration-200">
                  {bagCount}
                </span>
              </span>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 text-white/80 hover:text-white"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-12 bottom-0 bg-black/95 backdrop-blur-2xl z-40 p-6 flex flex-col justify-between overflow-y-auto animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col space-y-4 pt-4">
            {NAV_LINKS.map((link) => (
              <button
                key={link}
                type="button"
                onClick={() => {
                  handleNavClick(link);
                  setMobileMenuOpen(false);
                }}
                className="text-left text-2xl font-medium text-white/90 hover:text-white py-2 border-b border-white/10"
              >
                {link}
              </button>
            ))}
          </div>

          <div className="pt-6 border-t border-white/15 flex flex-col gap-3">
            <button
              type="button"
              onClick={() => {
                setIsMotionLabOpen(true);
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-center gap-2 w-full py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl text-sm font-medium"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Launch Motion Lab</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setIsCompareOpen(true);
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-center gap-2 w-full py-3 bg-white text-black rounded-xl text-sm font-medium"
            >
              <Scale className="w-4 h-4" />
              <span>Compare All Models</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
