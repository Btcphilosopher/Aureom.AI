'use client';

import React, { useRef, useState } from 'react';
import Image from 'next/image';
import { ChevronRight, Plus, ShoppingBag } from 'lucide-react';
import { useStore } from '@/lib/store';
import { Product } from '@/lib/types';
import { soundEngine } from '@/lib/sound-engine';

export function BentoGrid() {
  const { products, setSelectedProduct, setIsConfiguratorOpen, addToBag } = useStore();

  const macbook = products.find((p) => p.id === 'macbook-pro-m4') || products[1];
  const ipad = products.find((p) => p.id === 'ipad-pro-m4') || products[2];
  const watch = products.find((p) => p.id === 'apple-watch-ultra-2') || products[3];
  const airpods = products.find((p) => p.id === 'airpods-pro-2') || products[4];

  const cards = [
    {
      product: macbook,
      theme: 'dark',
      bgClass: 'bg-[#050507] text-white border-white/[0.08]',
      titleColor: 'text-white',
      subColor: 'text-white/60',
      linkColor: 'text-white/80 hover:text-white',
      image: '/images/product_macbook.jpg',
      aspectClass: 'h-64 sm:h-72',
    },
    {
      product: ipad,
      theme: 'light',
      bgClass: 'bg-[#F5F5F7] text-black border-black/[0.06]',
      titleColor: 'text-[#1D1D1F]',
      subColor: 'text-[#86868B]',
      linkColor: 'text-[#0071E3] hover:text-[#0077ED]',
      image: '/images/product_ipad.jpg',
      aspectClass: 'h-64 sm:h-72',
    },
    {
      product: watch,
      theme: 'light-cool',
      bgClass: 'bg-[#E9ECEF] text-black border-black/[0.06]',
      titleColor: 'text-[#1D1D1F]',
      subColor: 'text-[#86868B]',
      linkColor: 'text-[#0071E3] hover:text-[#0077ED]',
      image: '/images/product_watch.jpg',
      aspectClass: 'h-64 sm:h-72',
    },
    {
      product: airpods,
      theme: 'dark',
      bgClass: 'bg-[#000000] text-white border-white/[0.08]',
      titleColor: 'text-white',
      subColor: 'text-white/60',
      linkColor: 'text-white/80 hover:text-white',
      image: '/images/product_airpods.jpg',
      aspectClass: 'h-64 sm:h-72',
    },
  ];

  return (
    <section className="w-full max-w-[1440px] mx-auto px-4 sm:px-8 py-8 sm:py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {cards.map((card, idx) => (
          <BentoCard
            key={card.product.id || idx}
            product={card.product}
            theme={card.theme}
            bgClass={card.bgClass}
            titleColor={card.titleColor}
            subColor={card.subColor}
            linkColor={card.linkColor}
            image={card.image}
            aspectClass={card.aspectClass}
            onConfigure={() => {
              soundEngine.playClick();
              setSelectedProduct(card.product);
              setIsConfiguratorOpen(true);
            }}
            onQuickAdd={(targetEl) => {
              addToBag(
                card.product,
                card.product.variants[0],
                card.product.storageOptions[0],
                [],
                targetEl
              );
            }}
          />
        ))}
      </div>
    </section>
  );
}

interface BentoCardProps {
  product: Product;
  theme: string;
  bgClass: string;
  titleColor: string;
  subColor: string;
  linkColor: string;
  image: string;
  aspectClass: string;
  onConfigure: () => void;
  onQuickAdd: (el: HTMLElement | null) => void;
}

function BentoCard({
  product,
  bgClass,
  titleColor,
  subColor,
  linkColor,
  image,
  aspectClass,
  onConfigure,
  onQuickAdd,
}: BentoCardProps) {
  const cardRef = useRef<HTMLDivElement | null>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0, scale: 1 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    // Section 20 restraint: scale 1.00 -> 1.015
    setTilt({ x: x * 6, y: -y * 6, scale: 1.012 });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0, scale: 1 });
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`group relative rounded-[28px] border overflow-hidden p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 ease-out ${bgClass}`}
      style={{
        transform: `perspective(1000px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg) scale(${tilt.scale})`,
        transformStyle: 'preserve-3d',
      }}
    >
      {/* Top Header Information */}
      <div className="z-10">
        <h3 className={`text-xl sm:text-2xl font-semibold tracking-tight ${titleColor}`}>
          {product.name}
        </h3>
        <p className={`text-xs sm:text-sm mt-1 font-normal ${subColor}`}>{product.tagline}</p>
      </div>

      {/* Center Hardware Image with dynamic float */}
      <div className={`relative w-full ${aspectClass} my-4 flex items-center justify-center transition-transform duration-500 group-hover:scale-105`}>
        <Image
          src={image}
          alt={product.name}
          fill
          className="object-contain p-2 drop-shadow-xl"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Bottom Footer Actions (Learn more > & Quick Add) */}
      <div className="z-10 flex items-center justify-between pt-2 border-t border-current/10">
        <button
          type="button"
          onClick={onConfigure}
          className={`inline-flex items-center gap-1 text-xs font-medium ${linkColor} group/btn`}
        >
          <span>Learn more</span>
          <ChevronRight className="w-3.5 h-3.5 transform group-hover/btn:translate-x-0.5 transition-transform" />
        </button>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onQuickAdd(cardRef.current);
          }}
          className="p-1.5 rounded-full hover:bg-current/10 transition-colors opacity-80 hover:opacity-100 flex items-center gap-1 text-xs"
          title={`Quick add ${product.name} to Bag`}
          aria-label={`Quick add ${product.name}`}
        >
          <Plus className="w-3.5 h-3.5" />
          <span className="hidden group-hover:inline text-[11px] font-medium">Add</span>
        </button>
      </div>
    </div>
  );
}
