'use client';

import React, { useState, useRef } from 'react';
import Image from 'next/image';
import { Play, Sparkles, Cpu, Rotate3d, X, Check } from 'lucide-react';
import { useStore } from '@/lib/store';
import { soundEngine } from '@/lib/sound-engine';

export function HeroSection() {
  const { setSelectedProduct, setIsConfiguratorOpen, products } = useStore();
  const [filmModalOpen, setFilmModalOpen] = useState(false);
  const [mouseOffset, setMouseOffset] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLDivElement | null>(null);

  const iphone = products.find((p) => p.id === 'iphone-17-pro') || products[0];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!heroRef.current) return;
    const rect = heroRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMouseOffset({ x: x * 18, y: y * 18 });
  };

  const handleConfigure = () => {
    soundEngine.playClick();
    setSelectedProduct(iphone);
    setIsConfiguratorOpen(true);
  };

  return (
    <section
      ref={heroRef}
      onMouseMove={handleMouseMove}
      className="relative w-full min-h-[92vh] lg:min-h-[96vh] bg-[#000000] text-white overflow-hidden flex flex-col justify-between"
    >
      {/* Twilight Horizon Atmospheric Background Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Soft mountain silhouette at bottom horizon */}
        <div className="absolute bottom-0 inset-x-0 h-96 bg-gradient-to-t from-black via-black/80 to-transparent z-10" />
        
        {/* Warm twilight orange/gold atmospheric ambient bleed matching mock-up */}
        <div
          className="absolute -right-20 top-1/3 w-[700px] h-[550px] rounded-full blur-[140px] opacity-35 pointer-events-none transition-transform duration-700 ease-out"
          style={{
            background: 'radial-gradient(circle, #E09F67 0%, #A35C2B 40%, transparent 70%)',
            transform: `translate(${mouseOffset.x * 0.8}px, ${mouseOffset.y * 0.8}px)`,
          }}
        />

        {/* Deep blue alpine atmospheric counter-gradient on left */}
        <div
          className="absolute -left-32 top-1/4 w-[600px] h-[500px] rounded-full blur-[160px] opacity-20 pointer-events-none"
          style={{
            background: 'radial-gradient(circle, #1A365D 0%, #0F172A 50%, transparent 80%)',
          }}
        />
      </div>

      {/* Main Content Container */}
      <div className="max-w-[1440px] w-full mx-auto px-6 sm:px-12 lg:px-16 pt-16 lg:pt-24 pb-12 z-20 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center flex-1">
        {/* Left Column: Typographic Thesis & Value Proposition */}
        <div className="lg:col-span-6 space-y-6 pt-4 lg:pt-0">
          {/* Overline Kicker */}
          <div className="inline-flex items-center gap-2">
            <span className="text-sm md:text-base font-medium tracking-tight text-white/70">
              iPhone 17 Pro
            </span>
          </div>

          {/* Headline: "Built for what's next." */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-semibold tracking-tight text-white leading-[1.05] text-balance">
            Built for what’s <br className="hidden sm:inline" />
            next.
          </h1>

          {/* Subheading Prose */}
          <p className="text-base sm:text-lg text-white/70 max-w-xl font-normal leading-relaxed text-pretty">
            More power. A brighter display. A camera system that sees more. iPhone 17 Pro is engineered
            for the next generation of what you do.
          </p>

          {/* CTA Cluster */}
          <div className="pt-2 flex flex-wrap items-center gap-4 sm:gap-6">
            <button
              type="button"
              onClick={handleConfigure}
              className="px-6 py-2.5 bg-white text-black text-sm font-semibold rounded-full hover:bg-white/90 active:scale-98 transition-all shadow-lg hover:shadow-white/10"
            >
              Learn more
            </button>

            <button
              type="button"
              onClick={() => {
                soundEngine.playClick();
                setFilmModalOpen(true);
              }}
              className="group inline-flex items-center gap-2 text-sm font-medium text-white/90 hover:text-white transition-colors"
            >
              <span>Watch the film</span>
              <span className="w-6 h-6 rounded-full border border-white/30 flex items-center justify-center group-hover:border-white group-hover:bg-white/10 transition-all">
                <Play className="w-2.5 h-2.5 fill-current ml-0.5" />
              </span>
            </button>
          </div>

          {/* Micro Specification Badges */}
          <div className="pt-6 border-t border-white/10 grid grid-cols-3 gap-4 max-w-md text-left">
            <div>
              <p className="text-xl sm:text-2xl font-semibold text-white tracking-tight">48MP</p>
              <p className="text-[11px] text-white/50 uppercase tracking-wider mt-0.5">Fusion Optics</p>
            </div>
            <div>
              <p className="text-xl sm:text-2xl font-semibold text-white tracking-tight">120Hz</p>
              <p className="text-[11px] text-white/50 uppercase tracking-wider mt-0.5">ProMotion OLED</p>
            </div>
            <div>
              <p className="text-xl sm:text-2xl font-semibold text-white tracking-tight">33 hrs</p>
              <p className="text-[11px] text-white/50 uppercase tracking-wider mt-0.5">Battery Life</p>
            </div>
          </div>
        </div>

        {/* Right Column: Hero Cinematic Product Image & Interactive Silicon Callout */}
        <div className="lg:col-span-6 relative flex items-center justify-center min-h-[420px] lg:min-h-[580px]">
          {/* Main Hardware Visual with Smooth Parallax */}
          <div
            className="relative w-full h-[400px] sm:h-[500px] lg:h-[620px] transition-transform duration-500 ease-out will-change-transform"
            style={{
              transform: `translate3d(${mouseOffset.x}px, ${mouseOffset.y}px, 0) scale(1.02)`,
            }}
          >
            <Image
              src="/images/hero_iphone.jpg"
              alt="iPhone 17 Pro Titanium Camera System"
              fill
              priority
              className="object-contain object-center drop-shadow-[0_25px_50px_rgba(0,0,0,0.85)]"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Interactive Silicon Callout matching exact mock-up layout: "A19 Pro / The most powerful chip in a smartphone." */}
          <div
            className="absolute top-8 right-0 sm:right-6 lg:right-4 z-30 max-w-[210px] text-left transition-transform duration-700 ease-out pointer-events-auto group cursor-pointer"
            style={{
              transform: `translate3d(${mouseOffset.x * 0.4}px, ${mouseOffset.y * 0.4}px, 0)`,
            }}
            onClick={handleConfigure}
          >
            {/* Fine Technical Diagonal Hairline Pointer */}
            <div className="relative">
              <div className="flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-amber-300 group-hover:scale-110 transition-transform" />
                <h3 className="text-sm font-semibold text-white tracking-tight">A19 Pro</h3>
              </div>
              <p className="text-xs text-white/60 mt-1 leading-snug">
                The most powerful chip in a smartphone.
              </p>
              {/* Callout Hairline Leader */}
              <div className="mt-2 w-16 h-[1px] bg-white/30 group-hover:w-24 group-hover:bg-amber-300/80 transition-all duration-300" />
            </div>
          </div>

          {/* 3D Configurator Quick-Action Button */}
          <div className="absolute bottom-4 right-4 z-30">
            <button
              type="button"
              onClick={handleConfigure}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/15 rounded-full text-xs text-white/90 transition-all hover:scale-105"
            >
              <Rotate3d className="w-3.5 h-3.5 text-amber-300" />
              <span>Interactive 3D Studio</span>
            </button>
          </div>
        </div>
      </div>

      {/* Cinematic Film Modal */}
      {filmModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-2xl p-4 sm:p-8 animate-in fade-in duration-300">
          <div className="relative w-full max-w-4xl bg-black rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
            <div className="p-4 sm:p-6 flex items-center justify-between border-b border-white/10">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <h4 className="text-sm font-semibold text-white">iPhone 17 Pro — Introducing Titanium Precision</h4>
              </div>
              <button
                type="button"
                onClick={() => setFilmModalOpen(false)}
                className="p-1 text-white/60 hover:text-white rounded-full hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Video Showcase Simulation */}
            <div className="relative aspect-video w-full bg-neutral-950 flex flex-col items-center justify-center p-8 text-center">
              <Image
                src="/images/hero_iphone.jpg"
                alt="Cinematic Preview"
                fill
                className="object-cover opacity-30 blur-sm"
              />
              <div className="relative z-10 max-w-md space-y-4">
                <div className="w-16 h-16 rounded-full bg-white/10 border border-white/20 mx-auto flex items-center justify-center animate-pulse">
                  <Play className="w-6 h-6 fill-current text-white ml-1" />
                </div>
                <h3 className="text-2xl font-bold text-white tracking-tight">The Film: Titanium Mastery</h3>
                <p className="text-xs text-white/70">
                  Experience how Grade 5 titanium is forged and micro-machined to house the A19 Pro silicon and periscope optical zoom.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setFilmModalOpen(false);
                    handleConfigure();
                  }}
                  className="px-5 py-2 bg-white text-black font-semibold text-xs rounded-full hover:bg-white/90"
                >
                  Configure Your iPhone 17 Pro
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
