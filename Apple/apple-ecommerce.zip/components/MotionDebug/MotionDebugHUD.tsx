'use client';

import React, { useState, useEffect } from 'react';
import { Activity, X, Gauge, Zap, Clock } from 'lucide-react';
import { useStore } from '@/lib/store';

export function MotionDebugHUD() {
  const { isMotionDebugOpen, setIsMotionDebugOpen } = useStore();
  const [fps, setFps] = useState(60);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);

  useEffect(() => {
    if (!isMotionDebugOpen) return;

    let frameCount = 0;
    let lastTime = performance.now();
    let animId: number;

    const calculateFps = (now: number) => {
      frameCount++;
      if (now - lastTime >= 1000) {
        setFps(Math.round((frameCount * 1000) / (now - lastTime)));
        frameCount = 0;
        lastTime = now;
      }
      animId = requestAnimationFrame(calculateFps);
    };

    animId = requestAnimationFrame(calculateFps);
    return () => cancelAnimationFrame(animId);
  }, [isMotionDebugOpen]);

  if (!isMotionDebugOpen) return null;

  return (
    <div className="fixed bottom-6 left-6 z-50 bg-[#14151B]/95 backdrop-blur-xl border border-emerald-500/30 text-white rounded-2xl p-4 shadow-2xl w-80 text-xs space-y-3 font-mono">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/10 pb-2">
        <div className="flex items-center gap-2 text-emerald-400">
          <Activity className="w-4 h-4 animate-pulse" />
          <span className="font-semibold text-xs tracking-wider uppercase">Motion HUD</span>
        </div>
        <button
          type="button"
          onClick={() => setIsMotionDebugOpen(false)}
          className="text-white/40 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Frame Rate Indicator */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-white/60">
          <Gauge className="w-3.5 h-3.5" />
          <span>Render Cadence:</span>
        </div>
        <span
          className={`font-bold px-2 py-0.5 rounded ${
            fps >= 55 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
          }`}
        >
          {fps} FPS
        </span>
      </div>

      {/* Spring Physics Parameters */}
      <div className="space-y-1 text-[11px] text-white/70 bg-white/5 p-2 rounded-xl">
        <div className="flex justify-between">
          <span>Curve:</span>
          <span className="text-white">cubic-bezier(0.16, 1, 0.3, 1)</span>
        </div>
        <div className="flex justify-between">
          <span>Stiffness / Damping:</span>
          <span className="text-white">300 / 26</span>
        </div>
        <div className="flex justify-between">
          <span>Flight Duration:</span>
          <span className="text-white">680 ms</span>
        </div>
      </div>

      {/* Slow-Motion Speed Control */}
      <div className="space-y-1.5 pt-1">
        <div className="flex items-center gap-1.5 text-white/60">
          <Clock className="w-3.5 h-3.5" />
          <span>Motion Time Scale:</span>
        </div>
        <div className="grid grid-cols-3 gap-1.5 text-center">
          {[0.25, 0.5, 1.0].map((speed) => (
            <button
              key={speed}
              type="button"
              onClick={() => setPlaybackSpeed(speed)}
              className={`py-1 rounded-lg border transition-colors ${
                playbackSpeed === speed
                  ? 'border-emerald-400 bg-emerald-500/20 text-emerald-300 font-bold'
                  : 'border-white/10 hover:border-white/20 text-white/70'
              }`}
            >
              {speed}x
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
