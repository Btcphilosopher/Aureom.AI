'use client';

import React, { useState, useRef } from 'react';
import Image from 'next/image';
import { X, Check, Truck, Store, Shield, Sparkles, Rotate3d, Image as ImageIcon } from 'lucide-react';
import { useStore } from '@/lib/store';
import { ACCESSORIES } from '@/lib/catalog';
import { AccessoryOption } from '@/lib/types';
import { Interactive3DViewer } from '@/components/3DProduct/Interactive3DViewer';
import { soundEngine } from '@/lib/sound-engine';

export function ConfiguratorModal() {
  const {
    selectedProduct,
    isConfiguratorOpen,
    setIsConfiguratorOpen,
    addToBag,
    trackEvent,
  } = useStore();

  const [selectedVariant, setSelectedVariant] = useState(selectedProduct.variants[0]);
  const [selectedStorage, setSelectedStorage] = useState(selectedProduct.storageOptions[0]);
  const [selectedAccessories, setSelectedAccessories] = useState<AccessoryOption[]>([]);
  const [viewMode, setViewMode] = useState<'3d' | 'photo'>('3d');
  const [tradeInAccepted, setTradeInAccepted] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  const buyButtonRef = useRef<HTMLButtonElement | null>(null);

  const [prevProductId, setPrevProductId] = useState(selectedProduct.id);
  if (prevProductId !== selectedProduct.id) {
    setPrevProductId(selectedProduct.id);
    setSelectedVariant(selectedProduct.variants[0]);
    setSelectedStorage(selectedProduct.storageOptions[0]);
    setSelectedAccessories([]);
    setTradeInAccepted(false);
  }

  if (!isConfiguratorOpen) return null;

  const tradeInCredit = tradeInAccepted ? 350 : 0;
  const accessoriesTotal = selectedAccessories.reduce((acc, a) => acc + a.price, 0);
  const calculatedPrice = Math.max(
    0,
    selectedProduct.basePrice + selectedStorage.priceDelta + accessoriesTotal - tradeInCredit
  );

  const toggleAccessory = (accessory: AccessoryOption) => {
    soundEngine.playClick();
    setSelectedAccessories((prev) =>
      prev.some((a) => a.id === accessory.id)
        ? prev.filter((a) => a.id !== accessory.id)
        : [...prev, accessory]
    );
  };

  const handleAdd = () => {
    soundEngine.playClick();
    setIsAdding(true);

    addToBag(
      selectedProduct,
      selectedVariant,
      selectedStorage,
      selectedAccessories,
      buyButtonRef.current
    );

    trackEvent('product_configured', {
      productId: selectedProduct.id,
      finish: selectedVariant.name,
      storage: selectedStorage.capacity,
      price: calculatedPrice,
    });

    setTimeout(() => {
      setIsAdding(false);
      setIsConfiguratorOpen(false);
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-2xl flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-300">
      <div className="relative w-full max-w-5xl bg-[#14151B] text-white rounded-[32px] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 shrink-0 bg-[#14151B]/80 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <span className="text-xs font-semibold text-white/50 uppercase tracking-wider">
              Configurator
            </span>
            <span className="text-white/20">/</span>
            <h2 className="text-base font-semibold text-white tracking-tight">
              {selectedProduct.name}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* View Mode Toggle (3D vs Studio Photo) */}
            <div className="flex items-center gap-1 bg-white/10 p-1 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setViewMode('3d')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-colors ${
                  viewMode === '3d' ? 'bg-white text-black font-semibold' : 'text-white/70 hover:text-white'
                }`}
              >
                <Rotate3d className="w-3.5 h-3.5" />
                <span>3D Studio</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('photo')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-colors ${
                  viewMode === 'photo' ? 'bg-white text-black font-semibold' : 'text-white/70 hover:text-white'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>Studio Photo</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => setIsConfiguratorOpen(false)}
              className="p-1.5 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-colors"
              aria-label="Close Configurator"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: 2-Column Responsive Split */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-6 p-6 sm:p-8">
          {/* Left Column: Interactive Product Viewport (3D or High-Res) */}
          <div className="lg:col-span-6 flex flex-col items-center justify-center bg-black/40 rounded-3xl p-6 border border-white/5 relative min-h-[380px] lg:min-h-[500px]">
            {viewMode === '3d' ? (
              <Interactive3DViewer
                colorHex={selectedVariant.colorHex}
                finishName={selectedVariant.finishLabel}
                className="w-full h-full"
              />
            ) : (
              <div className="relative w-full h-[360px] sm:h-[440px] flex items-center justify-center">
                <Image
                  src={selectedVariant.image || selectedProduct.heroImage}
                  alt={selectedProduct.name}
                  fill
                  className="object-contain p-4 drop-shadow-[0_20px_40px_rgba(0,0,0,0.8)]"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}

            {/* Spec Capsule Bar */}
            <div className="w-full mt-4 pt-4 border-t border-white/10 flex items-center justify-around text-center text-xs text-white/70">
              <div>
                <p className="font-semibold text-white">{selectedProduct.specs.weight}</p>
                <p className="text-[10px] text-white/40">Chassis Weight</p>
              </div>
              <div className="h-6 w-[1px] bg-white/10" />
              <div>
                <p className="font-semibold text-white">{selectedStorage.capacity}</p>
                <p className="text-[10px] text-white/40">Selected Storage</p>
              </div>
              <div className="h-6 w-[1px] bg-white/10" />
              <div>
                <p className="font-semibold text-emerald-400">In Stock</p>
                <p className="text-[10px] text-white/40">Ships Tomorrow</p>
              </div>
            </div>
          </div>

          {/* Right Column: Configuration Choices */}
          <div className="lg:col-span-6 space-y-6">
            {/* 1. Finish / Colour Selection */}
            <div>
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold text-white">
                  Finish. <span className="font-normal text-white/60">Choose your titanium alloy.</span>
                </h4>
                <span className="text-xs text-amber-300/90 font-medium">
                  {selectedVariant.finishLabel}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-3">
                {selectedProduct.variants.map((v) => (
                  <button
                    key={v.id}
                    type="button"
                    onClick={() => {
                      soundEngine.playClick();
                      setSelectedVariant(v);
                    }}
                    className={`flex flex-col items-center gap-2 p-3 rounded-2xl border transition-all text-center ${
                      selectedVariant.id === v.id
                        ? 'border-white bg-white/10 ring-1 ring-white/30'
                        : 'border-white/10 hover:border-white/20 bg-white/[0.02]'
                    }`}
                  >
                    <span
                      className="w-6 h-6 rounded-full border border-white/20 shadow-inner"
                      style={{ backgroundColor: v.colorHex }}
                    />
                    <span className="text-xs font-medium text-white">{v.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Storage / Capacity Selection */}
            <div>
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold text-white">
                  Storage. <span className="font-normal text-white/60">How much space do you need?</span>
                </h4>
              </div>
              <div className="grid grid-cols-2 gap-2.5 mt-3">
                {selectedProduct.storageOptions.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      soundEngine.playClick();
                      setSelectedStorage(opt);
                    }}
                    className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                      selectedStorage.id === opt.id
                        ? 'border-white bg-white/10 ring-1 ring-white/30'
                        : 'border-white/10 hover:border-white/20 bg-white/[0.02]'
                    }`}
                  >
                    <span className="text-sm font-semibold text-white">{opt.capacity}</span>
                    <span className="text-xs font-mono text-white/60">
                      {opt.priceDelta === 0 ? 'Included' : `+£${opt.priceDelta}`}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Apple Trade-In Toggle */}
            <div className="p-4 rounded-2xl border border-white/10 bg-white/[0.02] flex items-center justify-between gap-4">
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <p className="text-xs font-semibold text-white">Apple Trade In</p>
                </div>
                <p className="text-[11px] text-white/60">
                  Trade in an eligible device for up to £350 instant credit towards your purchase.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playClick();
                  setTradeInAccepted(!tradeInAccepted);
                }}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap ${
                  tradeInAccepted
                    ? 'bg-emerald-500 text-white border-emerald-400'
                    : 'bg-white/10 text-white/80 border-white/10 hover:bg-white/20'
                }`}
              >
                {tradeInAccepted ? '✓ Applied (-£350)' : 'Apply Trade-In'}
              </button>
            </div>

            {/* 4. Accessories Add-ons */}
            <div>
              <h4 className="text-sm font-semibold text-white">
                Essential Additions. <span className="font-normal text-white/60">Crafted for your device.</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mt-3">
                {ACCESSORIES.map((acc) => {
                  const isSelected = selectedAccessories.some((a) => a.id === acc.id);
                  return (
                    <button
                      key={acc.id}
                      type="button"
                      onClick={() => toggleAccessory(acc)}
                      className={`flex flex-col justify-between p-3 rounded-2xl border text-left transition-all ${
                        isSelected
                          ? 'border-white bg-white/10 ring-1 ring-white/30'
                          : 'border-white/10 hover:border-white/20 bg-white/[0.02]'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <span className="text-xs font-medium text-white leading-tight">{acc.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 ml-1" />}
                      </div>
                      <span className="text-xs font-mono text-white/60 mt-2">+£{acc.price}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 5. Delivery & In-Store Availability Guarantee */}
            <div className="space-y-2 pt-2 border-t border-white/10 text-xs text-white/70">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-400" />
                <span>
                  <strong>Free Express Delivery:</strong> Arrives Thursday, September 25 with signature courier.
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Store className="w-4 h-4 text-white/60" />
                <span>
                  <strong>Apple Store Pickup:</strong> Available today at Regent Street & Covent Garden.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer: Sticky Purchase Module with Rolling Price Animation */}
        <div className="px-6 sm:px-8 py-5 border-t border-white/10 bg-[#101116] shrink-0 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-baseline gap-3">
            <span className="text-xs text-white/60 uppercase tracking-wider">Total Due</span>
            {/* Animated Tabular Price Ticker per Section 42 */}
            <span className="text-3xl font-semibold font-mono tracking-tight text-white">
              £{calculatedPrice.toLocaleString()}
            </span>
            <span className="text-xs text-white/40">
              or £{(calculatedPrice / 24).toFixed(2)}/mo. for 24 mo. with 0% APR
            </span>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              ref={buyButtonRef}
              type="button"
              disabled={isAdding}
              onClick={handleAdd}
              className={`w-full sm:w-auto px-8 py-3 bg-white text-black font-semibold text-sm rounded-full transition-all duration-200 shadow-xl hover:bg-white/90 active:scale-95 flex items-center justify-center gap-2 ${
                isAdding ? 'opacity-80 scale-95' : ''
              }`}
            >
              {isAdding ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Adding to Bag...</span>
                </>
              ) : (
                <span>Add to Bag</span>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
