'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import Image from 'next/image';
import { Search, X, ArrowRight } from 'lucide-react';
import { useStore } from '@/lib/store';
import { soundEngine } from '@/lib/sound-engine';
import { Product } from '@/lib/types';

export function SearchOverlay() {
  const { isSearchOpen, setIsSearchOpen, products, setSelectedProduct, setIsConfiguratorOpen } = useStore();
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isSearchOpen]);

  const handleClose = useCallback(() => {
    setQuery('');
    setIsSearchOpen(false);
  }, [setIsSearchOpen]);

  // Global hotkeys: Cmd+K or "/" to open, Escape to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      } else if (e.key === '/' && !isSearchOpen && document.activeElement?.tagName !== 'INPUT') {
        e.preventDefault();
        setIsSearchOpen(true);
      } else if (e.key === 'Escape' && isSearchOpen) {
        handleClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, setIsSearchOpen, handleClose]);

  if (!isSearchOpen) return null;

  const quickLinks = ['iPhone 17 Pro', 'MacBook Pro M4', 'Apple Watch Ultra', 'AirPods Pro 2', 'Titanium'];

  const filteredProducts = products.filter((p) => {
    if (!query.trim()) return false;
    const q = query.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.tagline.toLowerCase().includes(q)
    );
  });

  const handleSelectProduct = (product: Product) => {
    soundEngine.playClick();
    setSelectedProduct(product);
    setIsConfiguratorOpen(true);
    handleClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-2xl flex flex-col items-center justify-start p-4 sm:p-8 animate-in fade-in duration-200">
      <div className="w-full max-w-3xl space-y-6 pt-8 sm:pt-16">
        {/* Search Input Bar */}
        <div className="relative flex items-center border-b border-white/20 pb-3">
          <Search className="w-6 h-6 text-white/50 shrink-0 mr-3" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for hardware, specifications, or accessories..."
            className="w-full bg-transparent text-xl sm:text-2xl text-white placeholder-white/40 focus:outline-none tracking-tight font-normal"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="p-1 text-white/50 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          ) : (
            <div className="hidden sm:flex items-center gap-1 text-[11px] text-white/40 bg-white/10 px-2 py-0.5 rounded">
              <span>ESC to exit</span>
            </div>
          )}
          <button
            type="button"
            onClick={handleClose}
            className="sm:hidden p-1 text-white/60 ml-2"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Dynamic Suggestions & Results */}
        {!query ? (
          <div className="space-y-4 pt-2">
            <p className="text-xs uppercase tracking-wider text-white/40 font-semibold">
              Quick Links
            </p>
            <div className="flex flex-wrap gap-2">
              {quickLinks.map((link) => (
                <button
                  key={link}
                  type="button"
                  onClick={() => setQuery(link)}
                  className="px-3.5 py-1.5 rounded-full bg-white/5 hover:bg-white/15 text-xs text-white/80 hover:text-white border border-white/10 transition-colors"
                >
                  {link}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4 pt-2">
            <p className="text-xs uppercase tracking-wider text-white/40 font-semibold">
              Results ({filteredProducts.length})
            </p>

            {filteredProducts.length === 0 ? (
              <div className="p-8 text-center text-white/50 text-sm">
                No matching devices found for &ldquo;{query}&rdquo;.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {filteredProducts.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleSelectProduct(p)}
                    className="p-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-left flex items-center justify-between gap-4 transition-all group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative w-12 h-12 bg-black/40 rounded-xl overflow-hidden shrink-0 flex items-center justify-center p-1">
                        <Image
                          src={p.heroImage}
                          alt={p.name}
                          fill
                          className="object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-white group-hover:text-amber-300 transition-colors">
                          {p.name}
                        </h4>
                        <p className="text-xs text-white/50 line-clamp-1">{p.tagline}</p>
                        <span className="text-xs font-mono font-medium text-white/90">
                          From £{p.basePrice}
                        </span>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-white/40 group-hover:text-white group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
