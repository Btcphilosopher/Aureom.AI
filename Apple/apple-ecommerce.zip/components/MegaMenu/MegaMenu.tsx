'use client';

import React from 'react';
import Image from 'next/image';
import { ChevronRight, ArrowRight } from 'lucide-react';
import { useStore } from '@/lib/store';
import { soundEngine } from '@/lib/sound-engine';

interface MegaMenuProps {
  category: string | null;
  onClose: () => void;
}

export function MegaMenu({ category, onClose }: MegaMenuProps) {
  const { products, setSelectedProduct, setIsConfiguratorOpen } = useStore();

  if (!category) return null;

  // Filter relevant items or fallback to featured flagship products
  const matchingProduct =
    products.find((p) => p.category.toLowerCase() === category.toLowerCase()) || products[0];

  const handleProductSelect = () => {
    soundEngine.playClick();
    setSelectedProduct(matchingProduct);
    setIsConfiguratorOpen(true);
    onClose();
  };

  return (
    <div
      onMouseLeave={onClose}
      className="absolute top-12 left-0 right-0 w-full bg-[#000000]/95 backdrop-blur-2xl border-b border-white/10 z-40 animate-in fade-in slide-in-from-top-2 duration-300 shadow-2xl"
    >
      <div className="max-w-[1440px] mx-auto px-8 py-10">
        <div className="grid grid-cols-12 gap-8 items-center">
          {/* Column 1: Explore Links */}
          <div className="col-span-3 space-y-4">
            <p className="text-[11px] font-medium tracking-wider text-white/40 uppercase">
              Explore {category}
            </p>
            <div className="space-y-2.5">
              <button
                type="button"
                onClick={handleProductSelect}
                className="block text-left text-xl font-semibold text-white hover:text-white/80 transition-colors"
              >
                Explore All {category}
              </button>
              <div className="flex flex-col space-y-1.5 text-sm text-white/70">
                <button
                  type="button"
                  onClick={handleProductSelect}
                  className="text-left hover:text-white transition-colors flex items-center gap-1 group"
                >
                  <span>{matchingProduct.name}</span>
                  <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
                <button
                  type="button"
                  onClick={handleProductSelect}
                  className="text-left hover:text-white transition-colors flex items-center gap-1 group"
                >
                  <span>Compare Models</span>
                  <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
                <button
                  type="button"
                  onClick={handleProductSelect}
                  className="text-left hover:text-white transition-colors flex items-center gap-1 group"
                >
                  <span>Accessories & Care</span>
                  <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              </div>
            </div>
          </div>

          {/* Column 2: Large Visual Showcase */}
          <div className="col-span-6 flex flex-col items-center justify-center p-6 bg-white/[0.03] rounded-3xl border border-white/[0.08] relative group">
            <div className="relative w-full h-48 overflow-hidden rounded-2xl flex items-center justify-center">
              <Image
                src={matchingProduct.heroImage}
                alt={matchingProduct.name}
                fill
                className="object-contain transform group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="mt-4 text-center">
              <span className="text-xs font-semibold tracking-wide text-amber-300/90 uppercase">
                {matchingProduct.badge || 'Flagship Edition'}
              </span>
              <h4 className="text-lg font-semibold text-white mt-0.5">{matchingProduct.name}</h4>
              <p className="text-xs text-white/60 max-w-sm mt-1">{matchingProduct.tagline}</p>
              <div className="mt-3 flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={handleProductSelect}
                  className="px-4 py-1.5 bg-white text-black text-xs font-semibold rounded-full hover:bg-white/90 transition-colors"
                >
                  Configure & Buy
                </button>
                <button
                  type="button"
                  onClick={handleProductSelect}
                  className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1"
                >
                  <span>Learn more</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Column 3: Quick Tech Specs & Highlights */}
          <div className="col-span-3 space-y-4">
            <p className="text-[11px] font-medium tracking-wider text-white/40 uppercase">
              Silicon & Hardware
            </p>
            <div className="space-y-3">
              <div className="p-3 bg-white/[0.02] rounded-xl border border-white/[0.06]">
                <p className="text-[11px] text-white/50">Processing Architecture</p>
                <p className="text-xs font-medium text-white/90 mt-0.5">{matchingProduct.specs.chip}</p>
              </div>
              <div className="p-3 bg-white/[0.02] rounded-xl border border-white/[0.06]">
                <p className="text-[11px] text-white/50">Display Technology</p>
                <p className="text-xs font-medium text-white/90 mt-0.5">{matchingProduct.specs.display}</p>
              </div>
              <div className="p-3 bg-white/[0.02] rounded-xl border border-white/[0.06]">
                <p className="text-[11px] text-white/50">Starting Price</p>
                <p className="text-sm font-semibold text-white font-mono mt-0.5">
                  From £{matchingProduct.basePrice}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
