'use client';

import React from 'react';
import Image from 'next/image';
import { X, Trash2, Bookmark, Plus, Minus, ArrowRight, ShieldCheck, Truck, Store } from 'lucide-react';
import { useStore } from '@/lib/store';
import { soundEngine } from '@/lib/sound-engine';

export function BagDrawer() {
  const {
    isBagOpen,
    setIsBagOpen,
    bagItems,
    updateBagQuantity,
    removeFromBag,
    saveForLater,
    bagCount,
    bagSubtotal,
    setIsCheckoutOpen,
    trackEvent,
  } = useStore();

  if (!isBagOpen) return null;

  const freeDelivery = true;
  const estimatedTax = Math.round(bagSubtotal * 0.2); // 20% VAT included
  const total = bagSubtotal;

  const handleStartCheckout = () => {
    soundEngine.playClick();
    setIsBagOpen(false);
    setIsCheckoutOpen(true);
    trackEvent('checkout_started', { total: bagSubtotal, count: bagCount });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop with Soft Recession */}
      <div
        onClick={() => setIsBagOpen(false)}
        className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity duration-300 animate-in fade-in"
      />

      {/* Spatially Coherent Bag Surface */}
      <div className="relative w-full max-w-lg bg-[#14151B] text-white h-full shadow-2xl z-10 flex flex-col border-l border-white/10 animate-in slide-in-from-right duration-350 ease-out">
        {/* Header */}
        <div className="px-6 py-5 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#14151B]/90 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-semibold tracking-tight text-white">Your Bag</h2>
            <span className="text-xs text-white/50 font-mono">({bagCount} items)</span>
          </div>

          <button
            type="button"
            onClick={() => setIsBagOpen(false)}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/60 hover:text-white transition-colors"
            aria-label="Close Bag"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {bagItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40">
                <Bookmark className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-white">Your Bag is empty.</h3>
              <p className="text-xs text-white/60 max-w-xs">
                Items you add from the store will appear here with live delivery estimates and financing options.
              </p>
              <button
                type="button"
                onClick={() => setIsBagOpen(false)}
                className="px-6 py-2.5 bg-white text-black text-xs font-semibold rounded-full hover:bg-white/90 transition-colors"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            <div className="space-y-4 divide-y divide-white/10">
              {bagItems.map((item) => (
                <div key={item.id} className="pt-4 first:pt-0 space-y-3">
                  <div className="flex gap-4">
                    {/* Item Visual */}
                    <div className="relative w-20 h-20 sm:w-24 sm:h-24 bg-white/5 rounded-2xl border border-white/10 shrink-0 overflow-hidden flex items-center justify-center p-2">
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        className="object-contain p-1"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Item Info */}
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="text-sm font-semibold text-white tracking-tight">
                            {item.name}
                          </h4>
                          <span className="text-sm font-semibold font-mono text-white">
                            £{item.totalPrice.toLocaleString()}
                          </span>
                        </div>
                        <p className="text-xs text-white/60 mt-0.5">
                          {item.variant.name} · {item.storage.capacity}
                        </p>
                        {item.accessories.length > 0 && (
                          <p className="text-[11px] text-white/40 mt-0.5">
                            + {item.accessories.map((a) => a.name).join(', ')}
                          </p>
                        )}
                      </div>

                      {/* Quantity Stepper & Actions */}
                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-lg p-1">
                          <button
                            type="button"
                            onClick={() => updateBagQuantity(item.id, -1)}
                            className="p-1 text-white/60 hover:text-white rounded hover:bg-white/10 transition-colors"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-mono font-medium px-1.5 min-w-[20px] text-center">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateBagQuantity(item.id, 1)}
                            className="p-1 text-white/60 hover:text-white rounded hover:bg-white/10 transition-colors"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="flex items-center gap-3 text-xs text-white/50">
                          <button
                            type="button"
                            onClick={() => saveForLater(item)}
                            className="hover:text-white transition-colors"
                          >
                            Save for later
                          </button>
                          <span>·</span>
                          <button
                            type="button"
                            onClick={() => removeFromBag(item.id)}
                            className="hover:text-rose-400 transition-colors"
                            aria-label="Remove item"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Delivery & Logistics Assurance */}
          {bagItems.length > 0 && (
            <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/10 space-y-2 text-xs text-white/70">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-400" />
                <span>Free delivery on all orders over £50</span>
              </div>
              <div className="flex items-center gap-2">
                <Store className="w-4 h-4 text-white/50" />
                <span>Free pickup at any official Apple Store</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                <span>2-year hardware warranty included</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer Summary & Checkout CTA */}
        {bagItems.length > 0 && (
          <div className="p-6 border-t border-white/10 bg-[#101116] shrink-0 space-y-4">
            <div className="space-y-1.5 text-xs text-white/70">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-mono text-white">£{bagSubtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping</span>
                <span className="font-mono text-emerald-400">FREE</span>
              </div>
              <div className="flex justify-between">
                <span>Estimated VAT (20% included)</span>
                <span className="font-mono">£{estimatedTax.toLocaleString()}</span>
              </div>
              <div className="pt-2 border-t border-white/10 flex justify-between text-base font-semibold text-white">
                <span>Total</span>
                <span className="font-mono text-lg">£{total.toLocaleString()}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleStartCheckout}
              className="w-full py-3.5 bg-white text-black font-semibold text-sm rounded-full hover:bg-white/90 active:scale-98 transition-all shadow-xl flex items-center justify-center gap-2 group"
            >
              <span>Continue to Checkout</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
