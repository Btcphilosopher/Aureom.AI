'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ChevronRight, ChevronLeft, Heart, Moon, Flame, Sparkles, Layers, Globe, Mic } from 'lucide-react';
import { useStore } from '@/lib/store';
import { soundEngine } from '@/lib/sound-engine';

export function EcosystemSection() {
  const { products, setSelectedProduct, setIsConfiguratorOpen } = useStore();
  const [activeStoryIndex, setActiveStoryIndex] = useState(0);

  const watch = products.find((p) => p.id === 'apple-watch-ultra-2') || products[3];
  const iphone = products.find((p) => p.id === 'iphone-17-pro') || products[0];

  const stories = [
    {
      kicker: 'Health & Biometrics',
      headline: 'A healthier you is a brighter you.',
      description:
        'Apple Watch helps you stay active, keep track of your health, and feel more connected — every day.',
      image: '/images/lifestyle_hiker.jpg',
    },
    {
      kicker: 'Endurance & Exploration',
      headline: 'Engineered for the extremes.',
      description:
        'Dual-frequency GPS, custom waypoint tracking, and depth gauges ready for any ocean summit.',
      image: '/images/lifestyle_hiker.jpg',
    },
  ];

  const currentStory = stories[activeStoryIndex];

  return (
    <section className="w-full max-w-[1440px] mx-auto px-4 sm:px-8 py-8 sm:py-12 space-y-8">
      {/* 2-Column Bento Story Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Wide Card: Apple Watch Hiking & Health Experience */}
        <div className="lg:col-span-7 relative rounded-[28px] overflow-hidden min-h-[480px] sm:min-h-[540px] flex flex-col justify-between p-7 sm:p-10 border border-black/[0.08] shadow-lg group">
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
            <Image
              src={currentStory.image}
              alt="Hiker with Apple Watch"
              fill
              className="object-cover object-center group-hover:scale-102 transition-transform duration-700 ease-out"
              referrerPolicy="no-referrer"
            />
            {/* Measured Scrim for WCAG AA readability */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/25" />
          </div>

          {/* Top Editorial Copy */}
          <div className="relative z-10 max-w-md space-y-3 text-white">
            <h3 className="text-2xl sm:text-3xl lg:text-4xl font-semibold tracking-tight text-white leading-tight text-balance">
              {currentStory.headline}
            </h3>
            <p className="text-sm sm:text-base text-white/80 leading-relaxed text-pretty">
              {currentStory.description}
            </p>
            <div className="pt-1">
              <button
                type="button"
                onClick={() => {
                  soundEngine.playClick();
                  setSelectedProduct(watch);
                  setIsConfiguratorOpen(true);
                }}
                className="inline-flex items-center gap-1 text-sm font-medium text-white hover:text-white/80 group/btn"
              >
                <span>Learn more</span>
                <ChevronRight className="w-4 h-4 transform group-hover/btn:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>

          {/* Bottom Floating Translucent Frosted Glass Health Widgets matching mock-up */}
          <div className="relative z-10 pt-8 flex flex-col sm:flex-row items-end sm:items-center justify-between gap-4">
            {/* Carousel navigation controls */}
            <div className="flex items-center gap-2 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/10 text-white/80 text-xs">
              <button
                type="button"
                onClick={() => {
                  soundEngine.playClick();
                  setActiveStoryIndex((prev) => (prev === 0 ? stories.length - 1 : prev - 1));
                }}
                className="p-1 hover:text-white transition-colors"
                aria-label="Previous story"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <div className="flex items-center gap-1 px-1">
                {stories.map((_, i) => (
                  <span
                    key={i}
                    className={`w-1.5 h-1.5 rounded-full transition-all ${
                      i === activeStoryIndex ? 'w-4 bg-white' : 'bg-white/40'
                    }`}
                  />
                ))}
              </div>
              <button
                type="button"
                onClick={() => {
                  soundEngine.playClick();
                  setActiveStoryIndex((prev) => (prev === stories.length - 1 ? 0 : prev + 1));
                }}
                className="p-1 hover:text-white transition-colors"
                aria-label="Next story"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Translucent Frosted Telemetry Cluster */}
            <div className="flex flex-col gap-2.5 w-full sm:w-auto">
              {/* Heart Rate Glass Card */}
              <div className="flex items-center justify-between gap-4 px-4 py-2.5 bg-black/45 backdrop-blur-xl rounded-2xl border border-white/15 text-white shadow-xl min-w-[200px]">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-rose-500/20 flex items-center justify-center text-rose-400">
                    <Heart className="w-3.5 h-3.5 fill-current animate-pulse" />
                  </div>
                  <div>
                    <p className="text-[10px] text-white/60 uppercase tracking-wider">Heart Rate</p>
                    <p className="text-sm font-semibold tracking-tight">72 <span className="text-[10px] font-normal text-white/70">BPM</span></p>
                  </div>
                </div>
                {/* SVG Sparkline */}
                <svg className="w-16 h-6 stroke-rose-400 fill-none stroke-[1.8]" viewBox="0 0 60 20">
                  <path d="M0,10 L15,10 L20,3 L25,17 L30,5 L35,12 L40,10 L60,10" />
                </svg>
              </div>

              {/* Sleep Glass Card */}
              <div className="flex items-center justify-between gap-4 px-4 py-2.5 bg-black/45 backdrop-blur-xl rounded-2xl border border-white/15 text-white shadow-xl min-w-[200px]">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400">
                    <Moon className="w-3.5 h-3.5 fill-current" />
                  </div>
                  <div>
                    <p className="text-[10px] text-white/60 uppercase tracking-wider">Sleep</p>
                    <p className="text-sm font-semibold tracking-tight">7h 48m</p>
                  </div>
                </div>
                {/* Mini Sleep Stage Bars */}
                <div className="flex items-end gap-1 h-5">
                  <span className="w-1.5 h-3 bg-indigo-400/50 rounded-sm" />
                  <span className="w-1.5 h-5 bg-indigo-400 rounded-sm" />
                  <span className="w-1.5 h-2 bg-indigo-400/40 rounded-sm" />
                  <span className="w-1.5 h-4 bg-indigo-400/80 rounded-sm" />
                  <span className="w-1.5 h-5 bg-indigo-400 rounded-sm" />
                </div>
              </div>

              {/* Activity Glass Card */}
              <div className="flex items-center justify-between gap-4 px-4 py-2.5 bg-black/45 backdrop-blur-xl rounded-2xl border border-white/15 text-white shadow-xl min-w-[200px]">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-orange-500/20 flex items-center justify-center text-orange-400">
                    <Flame className="w-3.5 h-3.5 fill-current" />
                  </div>
                  <div>
                    <p className="text-[10px] text-white/60 uppercase tracking-wider">Activity</p>
                    <p className="text-sm font-semibold tracking-tight">1,240 <span className="text-[10px] font-normal text-white/70">kcal</span></p>
                  </div>
                </div>
                {/* Mini Circular Activity Ring Simulation */}
                <div className="w-6 h-6 rounded-full border-2 border-red-500 flex items-center justify-center">
                  <div className="w-3.5 h-3.5 rounded-full border-2 border-emerald-400" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Card: iOS 26 / A More Personal Experience */}
        <div className="lg:col-span-5 relative rounded-[28px] bg-[#F5F5F7] overflow-hidden min-h-[480px] sm:min-h-[540px] flex flex-col justify-between p-7 sm:p-10 border border-black/[0.06] shadow-sm group">
          {/* Header Copy */}
          <div className="z-10 max-w-sm space-y-2">
            <span className="text-xs font-semibold text-[#86868B] uppercase tracking-wider">
              iOS 26
            </span>
            <h3 className="text-2xl sm:text-3xl font-semibold tracking-tight text-[#1D1D1F] leading-tight text-balance">
              A more personal experience.
            </h3>
            <p className="text-xs sm:text-sm text-[#86868B] leading-relaxed text-pretty">
              New design. Smarter tools. A more connected you.
            </p>
            <div className="pt-2">
              <button
                type="button"
                onClick={() => {
                  soundEngine.playClick();
                  setSelectedProduct(iphone);
                  setIsConfiguratorOpen(true);
                }}
                className="inline-flex items-center gap-1 text-xs font-medium text-[#0071E3] hover:text-[#0077ED] group/btn"
              >
                <span>Learn more</span>
                <ChevronRight className="w-3.5 h-3.5 transform group-hover/btn:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>

          {/* Central Hardware Mockup showing Lockscreen Clock & Wallpapers */}
          <div className="relative w-full h-64 sm:h-72 my-4 flex items-center justify-center">
            {/* Stylized Bezel Edge Device Screen */}
            <div className="relative w-56 h-72 bg-gradient-to-b from-[#60A5FA] via-[#3B82F6] to-[#1E3A8A] rounded-[36px] p-4 shadow-2xl border-4 border-black/80 flex flex-col justify-between overflow-hidden">
              {/* Dynamic Island Pill */}
              <div className="w-16 h-3.5 bg-black rounded-full mx-auto" />

              {/* Lockscreen Time */}
              <div className="text-center text-white space-y-0.5 -mt-8">
                <p className="text-[11px] font-medium opacity-90">Tuesday, September 9</p>
                <p className="text-5xl font-bold tracking-tighter">9:41</p>
              </div>

              {/* Ambient Glow in Phone Screen */}
              <div className="w-40 h-28 bg-white/20 rounded-full blur-2xl mx-auto pointer-events-none" />
            </div>
          </div>

          {/* Floating Frosted Dock matching mock-up: Liquid Glass, Apple Intelligence, Live Translation, Smarter Siri */}
          <div className="z-10 bg-white/80 backdrop-blur-xl rounded-2xl p-3 border border-black/5 shadow-md grid grid-cols-4 gap-2 text-center">
            <div className="flex flex-col items-center gap-1.5 p-1 rounded-xl hover:bg-black/[0.04] transition-colors">
              <div className="w-8 h-8 rounded-xl bg-blue-500/15 text-blue-600 flex items-center justify-center">
                <Layers className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-medium text-[#1D1D1F] leading-tight">Liquid Glass Design</span>
            </div>

            <div className="flex flex-col items-center gap-1.5 p-1 rounded-xl hover:bg-black/[0.04] transition-colors">
              <div className="w-8 h-8 rounded-xl bg-purple-500/15 text-purple-600 flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-medium text-[#1D1D1F] leading-tight">Apple Intelligence</span>
            </div>

            <div className="flex flex-col items-center gap-1.5 p-1 rounded-xl hover:bg-black/[0.04] transition-colors">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/15 text-cyan-600 flex items-center justify-center">
                <Globe className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-medium text-[#1D1D1F] leading-tight">Live Translation</span>
            </div>

            <div className="flex flex-col items-center gap-1.5 p-1 rounded-xl hover:bg-black/[0.04] transition-colors">
              <div className="w-8 h-8 rounded-xl bg-rose-500/15 text-rose-600 flex items-center justify-center">
                <Mic className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-medium text-[#1D1D1F] leading-tight">Smarter Siri</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Ecosystem Banner matching bottom of mock-up */}
      <div className="pt-8 pb-4 flex flex-col items-center justify-center text-center space-y-2">
        <svg
          className="w-5 h-5 fill-current text-white/80"
          viewBox="0 0 170 170"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.04-7.69-7.8-12-14.28-6.19-9.35-11.12-20.03-14.77-32.06-3.66-12.02-5.5-23.47-5.5-34.33 0-14.35 3.42-26.23 10.27-35.63 6.85-9.4 15.42-14.21 25.7-14.42 5.02 0 10.59 1.41 16.71 4.23 6.13 2.83 10.15 4.3 12.06 4.44 1.52-.14 5.79-1.68 12.8-4.64 7.02-2.95 13.06-4.22 18.14-3.8 13.48.77 24.36 5.66 32.64 14.67-11.75 7.13-17.48 16.9-17.2 29.31.29 9.8 4.14 18.06 11.55 24.78 7.42 6.72 16.27 10.42 26.56 11.12-2.58 8.01-5.91 16.32-9.99 24.94zM119.22 33.15c0-7.39 2.68-14.39 8.04-20.98 5.36-6.6 12.09-10.82 20.19-12.67.22 1.3.33 2.45.33 3.43 0 7.39-2.78 14.52-8.35 21.39-5.57 6.87-12.38 11.02-20.43 12.44-.22-1.08-.33-2.13-.33-3.61z" />
        </svg>
        <p className="text-sm font-medium text-white/90">Technology should make life better.</p>
        <button
          type="button"
          onClick={() => {
            soundEngine.playClick();
            setSelectedProduct(iphone);
            setIsConfiguratorOpen(true);
          }}
          className="text-xs text-blue-400 hover:text-blue-300 font-medium inline-flex items-center gap-1"
        >
          <span>Explore the Apple ecosystem</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </section>
  );
}
