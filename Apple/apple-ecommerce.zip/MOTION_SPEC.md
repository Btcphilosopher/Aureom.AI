# MOTION_SPEC.md
# APPLE ECOMMERCE — Animation Specification & Choreography

## Motion Philosophy
Every animation is an engineered physical reaction. Surfaces hold mass, lights respond to pointer angle, and products traverse spatial coordinates along calculated bezier flight paths.

---

## 1. Hero Entrance Choreography

| Parameter | Specification |
| :--- | :--- |
| **Trigger** | Page Mount / Initial DOM Hydration |
| **Stage 1 (0.00s–0.40s)** | Background canvas fades from pitch black to twilight atmosphere (`opacity: 0 -> 1`, duration: 400ms, ease: `[0.16, 1, 0.3, 1]`) |
| **Stage 2 (0.15s–0.85s)** | Titanium iPhone 17 Pro slides subtly from right with depth rotation (`opacity: 0 -> 1`, `scale: 1.04 -> 1.00`, `translateX: 40px -> 0`, duration: 700ms, spring: `{ damping: 28, stiffness: 180 }`) |
| **Stage 3 (0.35s–0.85s)** | Headline text masked reveal (`clip-path: inset(0 0 100% 0) -> inset(0 0 0% 0)`, `translateY: 28px -> 0`, duration: 500ms) |
| **Stage 4 (0.50s–0.90s)** | Subheading prose & A19 Pro silicon callout tracer resolve (`opacity: 0 -> 1`, `translateY: 16px -> 0`) |
| **Stage 5 (0.70s–1.00s)** | CTA button cluster unlocks with smooth micro-glow |
| **Stage 6 (1.00s+)** | Continuous subtle pointer parallax active ($\pm 12\text{px}$ camera shift) |
| **Reduced Motion Fallback** | Instantaneous `opacity: 1`, zero transforms or parallax |

---

## 2. Signature Product-To-Bag Flight (`animateProductToBag`)

| Parameter | Specification |
| :--- | :--- |
| **Trigger** | User clicks "Add to Bag" on any product card, configurator, or quick-buy trigger |
| **Initial State** | Cloned product visual created at `sourceElement.getBoundingClientRect()` coordinates. Source element remains untouched. |
| **Intermediate State** | Clone elevates with soft shadow (`scale: 1.05`, `translateZ: 30px`), tilts along velocity vector towards bag coordinates, scales down to 0.18 over a quadratic bezier arc with an apex offset of -80px to -120px vertical curve. |
| **Final State** | Clone enters destination bounding rect (the Bag icon in TopBar), shrinks to `scale: 0`, and unmounts from DOM. |
| **Duration** | 680ms |
| **Easing** | Custom cubic bezier `cubic-bezier(0.25, 0.9, 0.25, 1.0)` |
| **Bag Response** | Bag icon scales up (`1.0 -> 1.25 -> 1.0`) over 280ms (`spring: { stiffness: 450, damping: 15 }`), emits subtle radial pulse. |
| **Rolling Digit Transition** | Previous count rolls upwards (`translateY: 0% -> -100%`, `opacity: 1 -> 0`), incoming count rolls in from below (`translateY: 100% -> 0%`, `opacity: 0 -> 1`) in 240ms. |
| **Reduced Motion Fallback** | No flight clone. Numeric count increments instantaneously; subtle checkmark flash. |

---

## 3. Product Configurator Material & Colour Shift

| Parameter | Specification |
| :--- | :--- |
| **Trigger** | User selects a different finish (e.g. Natural Titanium $\to$ Desert Titanium $\to$ Space Black) |
| **Initial State** | Active 3D canvas / high-res visual at current material color |
| **Intermediate State** | Camera rotates $12^\circ$ on yaw axis (`rotateY: 0deg -> 12deg -> 0deg`), specular highlight sweeps across titanium edge (`opacity: 0 -> 0.8 -> 0` via gradient mask), color tone transitions smoothly |
| **Final State** | New material stabilizes with accurate ambient occlusion and rim reflections |
| **Duration** | 450ms |
| **Easing** | `cubic-bezier(0.16, 1, 0.3, 1)` |
| **Reduced Motion Fallback** | Instant color replacement without camera rotation |

---

## 4. Rolling Price Ticker

| Parameter | Specification |
| :--- | :--- |
| **Trigger** | Configuration change modifying total price (e.g., 256GB $\to$ 1TB) |
| **Initial State** | Current price digits (e.g. `£1,199`) |
| **Transition** | Individual changing digit slots slide vertically with subtle motion blur (`filter: blur(1px) -> blur(0px)`), fixed currency symbol and invariant digits remain stationary. |
| **Duration** | 320ms |
| **Easing** | `cubic-bezier(0.2, 0.8, 0.2, 1)` |

---

## 5. The Bag Drawer Opening & Background Recession

| Parameter | Specification |
| :--- | :--- |
| **Trigger** | Click on Bag icon or post-purchase review request |
| **Initial State** | Drawer off-canvas (`translateX: 100%` on desktop, `translateY: 100%` on mobile) |
| **Background Effect** | Main document scales down slightly (`scale: 0.985`), corners round to `16px`, backdrop filters blur (`backdrop-blur-md`, `brightness: 0.65`) |
| **Bag Surface** | Expands smoothly (`translateX: 0%`, `duration: 400ms`, ease: `[0.32, 0.72, 0, 1]`) |
| **Item Cascade** | Item list items stagger in (`staggerChildren: 0.05s`, `translateY: 15px -> 0`, `opacity: 0 -> 1`) |
| **Reduced Motion Fallback** | Instant drawer visibility, no document scale or filter effects |

---

## 6. Mega-Navigation Horizon Surface

| Parameter | Specification |
| :--- | :--- |
| **Trigger** | Hovering or focusing a primary category link in TopBar (e.g., Mac, iPhone, Watch) |
| **Initial State** | `height: 0px`, `opacity: 0`, overflow hidden |
| **Intermediate State** | Height expands dynamically to content size (`280px`–`360px`), items fade and translate upward (`translateY: 12px -> 0px`, duration: 250ms), background dim overlay appears |
| **Final State** | Crisp product cards and category links visible with hover micro-scales |
| **Reduced Motion Fallback** | Clean simple fade, no height expansion animation |

---

## 7. Interactive 3D Product Orbit & Gyroscope

| Parameter | Specification |
| :--- | :--- |
| **Trigger** | Pointer drag / touch drag on interactive 3D studio viewport |
| **Behavior** | Continuous inertia-based quaternion rotation with damping (`dampingFactor: 0.05`). Metallic shader recalculates Fresnel rim light based on virtual studio light rigs. |
| **Presets Trigger** | Clicking camera angle buttons (Front, Back, Camera Macro, Angle, Silhouette) smoothly animates camera position via slerp over 600ms. |

---

## 8. Checkout Continuity Transition

| Parameter | Specification |
| :--- | :--- |
| **Trigger** | User clicks "Continue to Checkout" inside Bag Drawer |
| **Morph Sequence** | Bag Drawer structure does not dismount; it smoothly transforms its content container into the 3-step checkout flow (Shipping Details $\to$ Payment Selection $\to$ Order Processing $\to$ Confirmation Pass). |
| **Success Moment** | Confetti blast using Canvas particles, celebratory haptic sound chime, order reference badge resolves with animated checkmark. |
