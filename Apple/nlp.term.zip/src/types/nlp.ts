export type RiskLevel = 'SAFE' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type ProjectMode =
  | 'BUILD'
  | 'DEBUG'
  | 'REFACTOR'
  | 'LEARN'
  | 'RESEARCH'
  | 'OPERATE'
  | 'DEPLOY'
  | 'AUDIT';

export type AgentRole =
  | 'Architect'
  | 'Coder'
  | 'Debugger'
  | 'Tester'
  | 'Security'
  | 'Performance'
  | 'Documentation'
  | 'DevOps'
  | 'Researcher'
  | 'Reviewer';

export interface AgentTask {
  id: string;
  role: AgentRole;
  title: string;
  description: string;
  status: 'pending' | 'active' | 'completed' | 'failed';
  output?: string;
  artifacts?: string[];
}

export type OperationType =
  | 'filesystem.read'
  | 'filesystem.write'
  | 'filesystem.create_directory'
  | 'filesystem.delete'
  | 'filesystem.move'
  | 'filesystem.copy'
  | 'shell.execute'
  | 'compiler.run'
  | 'tester.run'
  | 'benchmark.run'
  | 'git.commit'
  | 'git.branch'
  | 'git.diff'
  | 'package.install'
  | 'network.request'
  | 'database.query';

export interface Operation {
  id: string;
  type: OperationType;
  path?: string;
  command?: string;
  content?: string;
  diff?: {
    file: string;
    before: string;
    after: string;
    additions: number;
    deletions: number;
  };
  explanation: {
    why: string;
    effect: string;
    filesAffected: string[];
    network: boolean;
    risk: RiskLevel;
  };
  status: 'pending' | 'approved' | 'executing' | 'success' | 'failed' | 'skipped' | 'rolled_back';
  output?: string;
  exitCode?: number;
  durationMs?: number;
}

export interface VerificationSpec {
  id: string;
  type: 'test' | 'compile' | 'lint' | 'benchmark' | 'hash_check' | 'custom';
  command: string;
  expectedOutcome: string;
  status: 'pending' | 'passed' | 'failed';
  actualOutput?: string;
}

export interface ProgramIntent {
  rawPrompt: string;
  intentKey: string;
  actionVerb: string;
  targetEntities: string[];
  requirements: string[];
  constraints: string[];
  detectedLanguage?: string;
  isAmbiguous?: boolean;
  ambiguityReason?: string;
  clarificationOptions?: string[];
  risk: RiskLevel;
}

export interface ExecutionPlan {
  id: string;
  timestamp: string;
  intent: ProgramIntent;
  summary: string;
  steps: {
    id: number;
    title: string;
    description: string;
    status: 'pending' | 'running' | 'completed' | 'failed';
  }[];
  operations: Operation[];
  verifications: VerificationSpec[];
  filesToCreate: string[];
  filesToModify: string[];
  filesToDelete: string[];
  requiresConfirmation: boolean;
  state: 'awaiting_confirmation' | 'executing' | 'completed' | 'failed' | 'rolled_back' | 'cancelled';
  rollbackSnapshotId?: string;
  telemetry?: {
    durationMs: number;
    cpuPeakPercent: number;
    memoryPeakMb: number;
    tokenCount: number;
  };
}

export interface FileItem {
  path: string;
  name: string;
  isDirectory: boolean;
  content?: string;
  sizeBytes: number;
  updatedAt: string;
  hash: string;
  language?: string;
}

export interface Snapshot {
  id: string;
  timestamp: string;
  planId: string;
  description: string;
  files: Record<string, { content: string; hash: string }>;
  canRollback: boolean;
}

export interface BenchmarkMetrics {
  id: string;
  timestamp: string;
  title: string;
  targetMetric: string;
  baseline: {
    startupMs: number;
    memoryMb: number;
    requestsPerSec: number;
    p99LatencyMs: number;
  };
  proposed: {
    startupMs: number;
    memoryMb: number;
    requestsPerSec: number;
    p99LatencyMs: number;
  };
  bottleneckIdentified: string;
  optimizationApplied: string;
  percentageImprovement: number;
  isVerifiedImprovement: boolean;
}

export interface NLPProgram {
  id: string;
  title: string;
  name: string;
  filename: string;
  description: string;
  content: string;
  steps: string[];
  triggers?: string[];
  requireConstraints?: string[];
  verifyClauses?: string[];
  onFailureStrategy?: 'rollback' | 'retry' | 'alert';
}

export interface NLPMacro {
  name: string;
  description: string;
  pipeline: string[];
  filename: string;
  risk?: RiskLevel;
}

export interface ContextGraph {
  projectName: string;
  currentBranch: string;
  rootPath: string;
  languages: string[];
  frameworks: string[];
  packageManager: string;
  testFramework: string;
  buildSystem: string;
  symbols: {
    name: string;
    kind: 'function' | 'class' | 'interface' | 'struct' | 'type' | 'endpoint';
    file: string;
    line: number;
    doc?: string;
  }[];
  dependencies: {
    name: string;
    version: string;
    direct: boolean;
  }[];
  recentCommands: string[];
  geminiInstructions: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  userPrompt: string;
  intentKey: string;
  model: string;
  durationMs: number;
  operationsCount: number;
  filesModified: string[];
  commandsRun: string[];
  outputSummary: string;
  verificationStatus: string;
  snapshotId: string;
}

export interface TerminalMessage {
  id: string;
  timestamp: string;
  type: 'user' | 'system' | 'plan' | 'output' | 'error' | 'success' | 'diff' | 'question';
  content: string;
  plan?: ExecutionPlan;
  diff?: {
    file: string;
    before: string;
    after: string;
  };
  meta?: Record<string, unknown>;
}
