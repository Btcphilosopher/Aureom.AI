import { FileItem, ContextGraph, NLPMacro, NLPProgram, BenchmarkMetrics, AuditEntry } from '../types/nlp';

export interface ProjectWorkspace {
  id: string;
  name: string;
  branch: string;
  description: string;
  runtime: 'local' | 'sandbox' | 'container';
  files: Record<string, FileItem>;
  context: ContextGraph;
  macros: NLPMacro[];
  programs: NLPProgram[];
  benchmarks: BenchmarkMetrics[];
}

export const DEFAULT_MACROS: NLPMacro[] = [
  {
    name: 'ship it',
    filename: 'ship.toml',
    description: 'Run test suite, compile optimized release binary, generate changelog, show diff, and commit',
    risk: 'MEDIUM',
    pipeline: [
      'run tests',
      'build production binary',
      'generate changelog',
      'show git diff',
      'ask for confirmation',
      'commit',
    ],
  },
  {
    name: 'security audit',
    filename: 'audit.toml',
    description: 'Scan dependencies for CVEs, audit unsafe blocks, and verify constant-time crypto',
    risk: 'SAFE',
    pipeline: [
      'scan dependencies',
      'audit unsafe rust blocks',
      'verify constant-time crypto comparison',
      'produce security report',
    ],
  },
];

export const DEFAULT_PROGRAMS: NLPProgram[] = [
  {
    id: 'nlp-prog-1',
    title: 'Automated Cryptographic Project Archival',
    name: 'archive_project',
    filename: 'archive_project.nlp',
    description: 'Automated archival workflow with strict SHA-256 integrity verification',
    content: `PROGRAM archive_project

WHEN:
    user requests archive

DO:
    calculate SHA256 hashes
    preserve original files
    generate metadata
    generate manifest
    create archive
    verify archive
    report results

REQUIRE:
    originals must not be modified

VERIFY:
    every object hash must match

ON FAILURE:
    rollback
    preserve error log
`,
    steps: [
      'Calculate SHA256 hash trees for all source assets',
      'Preserve original directory hierarchy without mutations',
      'Generate JSON metadata manifest with cryptographic signatures',
      'Create compressed tarball archive vault_archive.tar.zst',
      'Execute round-trip extraction & verification check',
    ],
  },
  {
    id: 'nlp-prog-2',
    title: 'Zero-Downtime Release Pipeline',
    name: 'deploy_pipeline',
    filename: 'deploy_pipeline.nlp',
    description: 'Build cross-platform release binaries, sign certificates, and update distribution formulas',
    content: `PROGRAM deploy_pipeline

WHEN:
    a new release tag is pushed

DO:
    run the full test suite
    build release binaries for Linux and macOS
    sign binaries with production certificate
    upload binaries to distribution channel
    update packaging formula

REQUIRE:
    test pass rate: 100%
    signed binaries exist

VERIFY:
    download release binary in fresh container
    assert binary executes --version

ON FAILURE:
    abort deployment
    rollback tags
    notify release channel
    preserve build logs
`,
    steps: [
      'Run comprehensive test suite across all targets',
      'Compile optimized release binaries for Linux x86_64 and macOS ARM64',
      'Sign binaries with cryptographic developer identity',
      'Publish assets to release registry',
      'Verify containerized execution',
    ],
  },
];

export const DEFAULT_AUDIT_LOGS: AuditEntry[] = [
  {
    id: 'audit-001',
    timestamp: '2026-09-10 08:30:14',
    userPrompt: 'create a Rust HTTP server with a health endpoint',
    intentKey: 'create_rust_http_server',
    model: 'gemini-3.7-flash',
    durationMs: 240,
    operationsCount: 5,
    filesModified: ['Cargo.toml', 'src/main.rs', 'tests/health.rs'],
    commandsRun: ['cargo check', 'cargo test'],
    outputSummary: 'Compiled Axum async HTTP server listening on 127.0.0.1:8080 with verified GET /health endpoint.',
    verificationStatus: 'VERIFIED',
    snapshotId: 'snap-8f2a1b',
  },
  {
    id: 'audit-002',
    timestamp: '2026-09-10 08:45:22',
    userPrompt: 'find why the tests are failing and fix them',
    intentKey: 'fix_failing_auth_tests',
    model: 'gemini-3.7-flash',
    durationMs: 190,
    operationsCount: 2,
    filesModified: ['src/auth/session.rs'],
    commandsRun: ['cargo test --test auth_tests'],
    outputSummary: 'Corrected inverted epoch timestamp comparison in Session::is_expired. All 2 unit tests passing.',
    verificationStatus: 'VERIFIED',
    snapshotId: 'snap-9c3b2c',
  },
];

export const DEFAULT_BENCHMARKS: BenchmarkMetrics[] = [
  {
    id: 'bench-1',
    timestamp: '2026-09-10 08:42:12',
    title: 'Archive Verifier Throughput Optimization',
    targetMetric: 'Throughput (req/s) & Latency',
    baseline: {
      startupMs: 2810,
      memoryMb: 412,
      requestsPerSec: 1842,
      p99LatencyMs: 4.2,
    },
    proposed: {
      startupMs: 2180,
      memoryMb: 368,
      requestsPerSec: 2410,
      p99LatencyMs: 2.1,
    },
    bottleneckIdentified: 'Payload deserialization copying memory buffers instead of zero-copy slice streaming',
    optimizationApplied: 'Zero-copy Bytes slice parsing with chunked SIMD-accelerated SHA-256 batch hasher',
    percentageImprovement: 30.8,
    isVerifiedImprovement: true,
  },
];

export const DEFAULT_PROJECTS: Record<string, ProjectWorkspace> = {
  'vault-os': {
    id: 'vault-os',
    name: 'vault-os',
    branch: 'main',
    description: 'High-integrity cryptographic archive & verification engine in Rust',
    runtime: 'sandbox',
    files: {
      'Cargo.toml': {
        path: 'Cargo.toml',
        name: 'Cargo.toml',
        isDirectory: false,
        sizeBytes: 420,
        updatedAt: '2026-09-10 08:30',
        hash: 'sha256-a1b2c3d4',
        language: 'toml',
        content: `[package]
name = "vault-os"
version = "0.4.2"
edition = "2021"
description = "Enterprise cryptographic storage & verification daemon"

[dependencies]
tokio = { version = "1.38", features = ["full"] }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
sha2 = "0.10"
axum = "0.7"
sqlx = { version = "0.7", features = ["runtime-tokio", "postgres"] }
tracing = "0.1"

[dev-dependencies]
criterion = "0.5"
reqwest = { version = "0.12", features = ["json"] }
`,
      },
      'src/main.rs': {
        path: 'src/main.rs',
        name: 'main.rs',
        isDirectory: false,
        sizeBytes: 980,
        updatedAt: '2026-09-10 08:35',
        hash: 'sha256-f9e8d7c6',
        language: 'rust',
        content: `use axum::{routing::get, Json, Router};
use std::net::SocketAddr;
use serde::Serialize;

mod archive;
mod auth;

#[derive(Serialize)]
struct StatusResponse {
    status: &'static str,
    engine: &'static str,
    integrity_check: bool,
}

async fn health_check() -> Json<StatusResponse> {
    Json(StatusResponse {
        status: "healthy",
        engine: "vault-os v0.4.2",
        integrity_check: true,
    })
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();

    let app = Router::new()
        .route("/health", get(health_check))
        .route("/api/archive/verify", get(archive::verifier::verify_archive_handler));

    let addr = SocketAddr::from(([127, 0, 0, 1], 8080));
    println!("vault-os engine running on http://{}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
`,
      },
      'src/archive/verifier.rs': {
        path: 'src/archive/verifier.rs',
        name: 'verifier.rs',
        isDirectory: false,
        sizeBytes: 1350,
        updatedAt: '2026-09-10 08:40',
        hash: 'sha256-e5d4c3b2',
        language: 'rust',
        content: `use axum::Json;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Serialize, Deserialize)]
pub struct VerifyRequest {
    pub manifest_id: String,
    pub expected_checksum: String,
    pub payload_bytes: Vec<u8>,
}

#[derive(Serialize)]
pub struct VerifyResult {
    pub is_valid: bool,
    pub computed_sha256: String,
    pub latency_us: u64,
}

pub async fn verify_archive_handler(Json(req): Json<VerifyRequest>) -> Json<VerifyResult> {
    let start = std::time::Instant::now();
    let mut hasher = Sha256::new();
    hasher.update(&req.payload_bytes);
    let result = hasher.finalize();
    let hash_hex = format!("{:x}", result);

    Json(VerifyResult {
        is_valid: hash_hex == req.expected_checksum,
        computed_sha256: hash_hex,
        latency_us: start.elapsed().as_micros() as u64,
    })
}
`,
      },
      'src/auth/session.rs': {
        path: 'src/auth/session.rs',
        name: 'session.rs',
        isDirectory: false,
        sizeBytes: 1120,
        updatedAt: '2026-09-10 08:45',
        hash: 'sha256-7a8b9c0d',
        language: 'rust',
        content: `use serde::{Deserialize, Serialize};

#[derive(Clone, Serialize, Deserialize)]
pub struct Session {
    pub user_id: String,
    pub token: String,
    pub expires_at: i64,
}

impl Session {
    // Note: Bug simulation for "fix the failing authentication tests"
    pub fn is_expired(&self, current_timestamp: i64) -> bool {
        // BUG: Inverted logic causing session tests to fail
        current_timestamp < self.expires_at
    }

    pub fn new(user_id: &str, duration_secs: i64) -> Self {
        Self {
            user_id: user_id.to_string(),
            token: format!("tok_{}_{}", user_id, duration_secs),
            expires_at: 1757490000 + duration_secs,
        }
    }
}
`,
      },
      'tests/auth_tests.rs': {
        path: 'tests/auth_tests.rs',
        name: 'auth_tests.rs',
        isDirectory: false,
        sizeBytes: 780,
        updatedAt: '2026-09-10 08:45',
        hash: 'sha256-11223344',
        language: 'rust',
        content: `#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_session_not_expired() {
        let session = Session::new("usr_99", 3600);
        let now = 1757490100; // within 3600s
        assert!(!session.is_expired(now), "Session should not be expired");
    }

    #[test]
    fn test_past_session_is_expired() {
        let session = Session::new("usr_99", 300);
        let now = 1757500000; // far in the future
        assert!(session.is_expired(now), "Session must be marked expired");
    }
}
`,
      },
      'GEMINI.md': {
        path: 'GEMINI.md',
        name: 'GEMINI.md',
        isDirectory: false,
        sizeBytes: 520,
        updatedAt: '2026-09-10 08:00',
        hash: 'sha256-gemini-md',
        language: 'markdown',
        content: `# Project Context: vault-os

- Enterprise cryptographic verification engine written in async Rust (Axum, Tokio).
- Strict SHA-256 and constant-time integrity standards.
- Production target must maintain startup < 2.5s and throughput > 2,000 req/s.
- Always require verification tests and diff confirmation before applying changes to auth or core crypto.
`,
      },
    },
    context: {
      projectName: 'vault-os',
      currentBranch: 'main',
      rootPath: '/projects/vault-os',
      languages: ['Rust', 'TOML', 'NLP'],
      frameworks: ['Axum', 'Tokio', 'SQLx'],
      packageManager: 'cargo',
      testFramework: 'cargo test',
      buildSystem: 'cargo build --release',
      symbols: [
        { name: 'verify_archive_handler', kind: 'endpoint', file: 'src/archive/verifier.rs', line: 20, doc: 'Validates SHA256 against manifest' },
        { name: 'health_check', kind: 'endpoint', file: 'src/main.rs', line: 16, doc: 'System heartbeat and integrity check' },
        { name: 'Session', kind: 'struct', file: 'src/auth/session.rs', line: 4, doc: 'User session entity with UTC timestamps' },
        { name: 'is_expired', kind: 'function', file: 'src/auth/session.rs', line: 12, doc: 'Checks if session timestamp has lapsed' },
      ],
      dependencies: [
        { name: 'tokio', version: '1.38', direct: true },
        { name: 'axum', version: '0.7', direct: true },
        { name: 'sha2', version: '0.10', direct: true },
        { name: 'serde', version: '1.0', direct: true },
        { name: 'sqlx', version: '0.7', direct: true },
      ],
      recentCommands: ['cargo check', 'cargo test', 'nlp> inspect this project'],
      geminiInstructions: 'High-integrity Rust service. Never bypass confirmation for auth changes.',
    },
    macros: DEFAULT_MACROS,
    programs: DEFAULT_PROGRAMS,
    benchmarks: DEFAULT_BENCHMARKS,
  },
  'weather-engine': {
    id: 'weather-engine',
    name: 'weather-engine',
    branch: 'develop',
    description: 'High-throughput async Python weather analytics & radar stream processor',
    runtime: 'sandbox',
    files: {
      'pyproject.toml': {
        path: 'pyproject.toml',
        name: 'pyproject.toml',
        isDirectory: false,
        sizeBytes: 380,
        updatedAt: '2026-09-10 07:15',
        hash: 'sha256-py-01',
        language: 'toml',
        content: `[project]
name = "weather-engine"
version = "0.2.0"
dependencies = [
    "fastapi>=0.111.0",
    "uvicorn>=0.30.0",
    "pydantic>=2.7.0",
    "httpx>=0.27.0",
    "polars>=0.20.0",
]

[tool.pytest.ini_options]
testpaths = ["tests"]
`,
      },
      'main.py': {
        path: 'main.py',
        name: 'main.py',
        isDirectory: false,
        sizeBytes: 850,
        updatedAt: '2026-09-10 07:20',
        hash: 'sha256-py-02',
        language: 'python',
        content: `from fastapi import FastAPI
import uvicorn

app = FastAPI(title="Weather Engine", version="0.2.0")

@app.get("/health")
async def health():
    return {"status": "ok", "service": "weather-engine", "version": "0.2.0"}

@app.get("/forecast/{city}")
async def get_forecast(city: str):
    return {
        "city": city,
        "temperature_c": 19.5,
        "humidity_pct": 62,
        "conditions": "Partly Cloudy",
        "station_id": "WX-9021"
    }

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
`,
      },
      'tests/test_forecast.py': {
        path: 'tests/test_forecast.py',
        name: 'test_forecast.py',
        isDirectory: false,
        sizeBytes: 520,
        updatedAt: '2026-09-10 07:25',
        hash: 'sha256-py-03',
        language: 'python',
        content: `from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"

def test_forecast():
    res = client.get("/forecast/London")
    assert res.status_code == 200
    assert res.json()["city"] == "London"
`,
      },
    },
    context: {
      projectName: 'weather-engine',
      currentBranch: 'develop',
      rootPath: '/projects/weather-engine',
      languages: ['Python', 'TOML'],
      frameworks: ['FastAPI', 'Polars', 'Uvicorn'],
      packageManager: 'uv / pip',
      testFramework: 'pytest',
      buildSystem: 'uv build',
      symbols: [
        { name: 'health', kind: 'endpoint', file: 'main.py', line: 6, doc: 'Health status check' },
        { name: 'get_forecast', kind: 'endpoint', file: 'main.py', line: 10, doc: 'Retrieves radar weather report' },
      ],
      dependencies: [
        { name: 'fastapi', version: '0.111.0', direct: true },
        { name: 'uvicorn', version: '0.30.0', direct: true },
        { name: 'polars', version: '0.20.0', direct: true },
      ],
      recentCommands: ['pytest', 'uvicorn main:app'],
      geminiInstructions: 'FastAPI async microservice. Ensure data transformation uses polars.',
    },
    macros: [],
    programs: [],
    benchmarks: [],
  },
};
