import React, { useState, useCallback } from 'react';
import {
  ProjectMode,
  TerminalMessage,
  ExecutionPlan,
  AgentTask,
  NLPMacro,
  NLPProgram,
  AuditEntry,
  BenchmarkMetrics,
} from './types/nlp';
import {
  DEFAULT_PROJECTS,
  DEFAULT_MACROS,
  DEFAULT_PROGRAMS,
  DEFAULT_AUDIT_LOGS,
  DEFAULT_BENCHMARKS,
  ProjectWorkspace,
} from './data/defaultProjects';
import { TerminalHeader } from './components/terminal/TerminalHeader';
import { TerminalConsole } from './components/terminal/TerminalConsole';
import { ExecutionPipelineView } from './components/terminal/ExecutionPipelineView';
import { DiffViewer } from './components/terminal/DiffViewer';
import { ProjectExplorer } from './components/terminal/ProjectExplorer';
import { AgentsPanel } from './components/terminal/AgentsPanel';
import { BenchmarkPanel } from './components/terminal/BenchmarkPanel';
import { NLPProgramsPanel } from './components/terminal/NLPProgramsPanel';
import { MacrosManager } from './components/terminal/MacrosManager';
import { AuditHistoryView } from './components/terminal/AuditHistoryView';

export default function App() {
  const [projects, setProjects] = useState<Record<string, ProjectWorkspace>>(
    JSON.parse(JSON.stringify(DEFAULT_PROJECTS))
  );
  const [currentProjectId, setCurrentProjectId] = useState<string>('vault-os');
  const [projectMode, setProjectMode] = useState<ProjectMode>('BUILD');
  const [activeTab, setActiveTab] = useState<
    | 'terminal'
    | 'pipeline'
    | 'diff'
    | 'files'
    | 'agents'
    | 'benchmarks'
    | 'programs'
    | 'audit'
    | 'macros'
  >('terminal');

  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [activePlan, setActivePlan] = useState<ExecutionPlan | null>(null);
  const [agentTasks, setAgentTasks] = useState<AgentTask[]>([]);
  const [isOrchestrating, setIsOrchestrating] = useState<boolean>(false);
  const [macros, setMacros] = useState<NLPMacro[]>(DEFAULT_MACROS);
  const [programs] = useState<NLPProgram[]>(DEFAULT_PROGRAMS);
  const [auditLogs, setAuditLogs] = useState<AuditEntry[]>(DEFAULT_AUDIT_LOGS);
  const [benchmarks, setBenchmarks] = useState<BenchmarkMetrics[]>(DEFAULT_BENCHMARKS);

  const currentProject = projects[currentProjectId] || projects['vault-os'];

  const [messages, setMessages] = useState<TerminalMessage[]>([
    {
      id: 'init-1',
      type: 'system',
      content: `NLP.TERM runtime environment initialized. Project '${currentProject.name}' ready on branch '${currentProject.branch}'.`,
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  const addMessage = useCallback((msg: Omit<TerminalMessage, 'id' | 'timestamp'>) => {
    const newMsg: TerminalMessage = {
      ...msg,
      id: 'msg-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toLocaleTimeString(),
    };
    setMessages((prev) => [...prev, newMsg]);
    return newMsg;
  }, []);

  // Handle Slash Commands
  const handleSlashCommand = (cmd: string) => {
    const parts = cmd.split(' ');
    const root = parts[0].toLowerCase();

    switch (root) {
      case '/help':
        addMessage({
          type: 'output',
          content: `NLP.TERM Built-in Commands:
  /help                  Display this command index
  /status                Show active project, branch, model, and memory state
  /plan                  Inspect the current pending execution plan
  /run <text>            Compile and immediately execute a natural language task
  /undo                  Rollback the most recent state change
  /history               Show recent execution audit records
  /files                 List all workspace files
  /diff                  Open the diff inspection view
  /benchmark             Trigger benchmark performance profiling
  /agents <goal>         Dispatch specialized multi-agent squad
  /mode <MODE>           Set mode: BUILD, DEBUG, REFACTOR, LEARN, AUDIT, OPERATE, DEPLOY, RESEARCH
  !command               Execute raw shell command directly (e.g. !cargo test, !ls -la)`,
        });
        break;

      case '/status':
        addMessage({
          type: 'output',
          content: `PROJECT STATUS:
  Name: ${currentProject.name}
  Branch: ${currentProject.branch}
  Runtime: ${currentProject.runtime} (container sandbox)
  Mode: ${projectMode}
  Model: gemini-3.7-flash (Intent Compiler active)
  Files: ${Object.keys(currentProject.files).length} files indexed
  Pending Plan: ${activePlan ? activePlan.id + ' (' + activePlan.state + ')' : 'None'}`,
        });
        break;

      case '/files':
        addMessage({
          type: 'output',
          content: Object.keys(currentProject.files)
            .map((f) => `  ${f} (${currentProject.files[f].sizeBytes} bytes)`)
            .join('\n'),
        });
        break;

      case '/diff':
        setActiveTab('diff');
        break;

      case '/plan':
        setActiveTab('pipeline');
        break;

      case '/benchmark':
        setActiveTab('benchmarks');
        break;

      case '/mode':
        if (parts[1]) {
          const m = parts[1].toUpperCase() as ProjectMode;
          setProjectMode(m);
          addMessage({
            type: 'success',
            content: `Switched project mode to ${m}`,
          });
        } else {
          addMessage({
            type: 'system',
            content: `Current mode is ${projectMode}. Available: BUILD, DEBUG, REFACTOR, LEARN, AUDIT, OPERATE, DEPLOY, RESEARCH`,
          });
        }
        break;

      case '/undo':
        handleRollback();
        break;

      default:
        addMessage({
          type: 'error',
          content: `Unknown slash command '${root}'. Type /help for assistance.`,
        });
        break;
    }
  };

  // Compile Natural Language
  const handleCompilePrompt = async (promptText: string) => {
    addMessage({
      type: 'user',
      content: promptText,
    });

    // Check if it's a shell command prefixed with !
    if (promptText.startsWith('!')) {
      const rawCmd = promptText.substring(1).trim();
      addMessage({
        type: 'output',
        content: `$ ${rawCmd}\nExecuting directly in ${currentProject.runtime} environment...\n` +
          (rawCmd.includes('test')
            ? 'running 2 tests\ntest auth::test_is_expired ... ok\ntest auth::test_session_create ... ok\n\ntest result: ok. 2 passed; 0 failed; finished in 0.04s'
            : rawCmd.includes('ls')
            ? Object.keys(currentProject.files).join('  ')
            : `Exit code: 0 (Command '${rawCmd}' completed successfully)`),
      });
      return;
    }

    // Check if it's a slash command
    if (promptText.startsWith('/')) {
      handleSlashCommand(promptText);
      return;
    }

    // Check if it's macro trigger (e.g. "ship it")
    const matchedMacro = macros.find(
      (m) => m.name.toLowerCase() === promptText.toLowerCase().trim()
    );
    if (matchedMacro) {
      handleRunMacro(matchedMacro);
      return;
    }

    // Natural Language Compilation
    setIsCompiling(true);
    try {
      const res = await fetch('/api/nlp/compile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptText,
          projectContext: {
            projectName: currentProject.name,
            currentBranch: currentProject.branch,
            languages: currentProject.context.languages,
            frameworks: currentProject.context.frameworks,
            symbols: currentProject.context.symbols,
          },
          projectMode,
          currentFiles: currentProject.files,
        }),
      });

      const data = await res.json();
      if (data.plan) {
        setActivePlan(data.plan);
        addMessage({
          type: 'plan',
          content: data.plan.summary,
          plan: data.plan,
        });
      } else {
        addMessage({
          type: 'error',
          content: 'Compiler failed to generate plan.',
        });
      }
    } catch (err: any) {
      addMessage({
        type: 'error',
        content: `Compilation error: ${err.message}`,
      });
    } finally {
      setIsCompiling(false);
    }
  };

  // Plan Execution Approval
  const handleApprovePlan = async (planId: string) => {
    if (!activePlan || activePlan.id !== planId) return;

    const executingPlan: ExecutionPlan = {
      ...activePlan,
      state: 'executing',
    };
    setActivePlan(executingPlan);

    // Update message feed to executing state
    setMessages((prev) =>
      prev.map((m) =>
        m.plan?.id === planId ? { ...m, plan: executingPlan } : m
      )
    );

    // Simulate safe execution & verification
    setTimeout(() => {
      // Apply file changes to workspace
      const updatedFiles = { ...currentProject.files };
      const timestamp = new Date().toISOString();
      const snapshotId = 'snap-' + Date.now().toString(36);

      // Create new files
      activePlan.operations.forEach((op) => {
        if (op.type === 'filesystem.write' && op.path && op.content) {
          updatedFiles[op.path] = {
            path: op.path,
            content: op.content,
            sizeBytes: op.content.length,
            updatedAt: timestamp,
            hash: 'h_' + Math.random().toString(36).substring(2, 8),
          };
        }
      });

      // Update project state
      setProjects((prev) => ({
        ...prev,
        [currentProjectId]: {
          ...prev[currentProjectId],
          files: updatedFiles,
        },
      }));

      // Record in immutable audit trail
      const auditEntry: AuditEntry = {
        id: 'audit-' + Date.now(),
        timestamp: new Date().toLocaleTimeString(),
        userPrompt: activePlan.intent.rawPrompt,
        intentKey: activePlan.intent.intentKey,
        model: 'gemini-3.7-flash',
        durationMs: activePlan.telemetry?.durationMs || 220,
        operationsCount: activePlan.operations.length,
        filesModified: [
          ...activePlan.filesToCreate,
          ...activePlan.filesToModify,
        ],
        commandsRun: activePlan.operations
          .filter((o) => o.command)
          .map((o) => o.command!),
        outputSummary: activePlan.summary,
        verificationStatus: 'VERIFIED_OK',
        snapshotId,
      };

      setAuditLogs((prev) => [auditEntry, ...prev]);

      const completedPlan: ExecutionPlan = {
        ...activePlan,
        state: 'completed',
        rollbackSnapshotId: snapshotId,
      };

      setActivePlan(completedPlan);

      setMessages((prev) =>
        prev.map((m) =>
          m.plan?.id === planId ? { ...m, plan: completedPlan } : m
        )
      );

      addMessage({
        type: 'success',
        content: `Execution completed successfully. Snapshot created: ${snapshotId}`,
      });

      // If benchmarks were verified, update benchmark panel
      if (activePlan.intent.intentKey.includes('benchmark')) {
        setActiveTab('benchmarks');
      }
    }, 1200);
  };

  // Reject Plan
  const handleRejectPlan = (planId: string) => {
    setActivePlan(null);
    addMessage({
      type: 'system',
      content: `Execution plan ${planId} was rejected and cancelled by operator. No files or commands were executed.`,
    });
  };

  // Rollback to snapshot
  const handleRollback = (snapshotId?: string) => {
    const targetSnapshot =
      snapshotId || auditLogs[0]?.snapshotId || 'initial-baseline';
    addMessage({
      type: 'system',
      content: `Initiating cryptographic rollback to snapshot: ${targetSnapshot}...`,
    });

    setTimeout(() => {
      // Revert files to baseline
      setProjects((prev) => ({
        ...prev,
        [currentProjectId]: JSON.parse(
          JSON.stringify(DEFAULT_PROJECTS[currentProjectId])
        ),
      }));
      setActivePlan(null);

      addMessage({
        type: 'success',
        content: `Workspace safely rolled back to snapshot ${targetSnapshot}. All verified clean.`,
      });
    }, 600);
  };

  // Reset entire workspace
  const handleResetWorkspace = () => {
    setProjects(JSON.parse(JSON.stringify(DEFAULT_PROJECTS)));
    setActivePlan(null);
    addMessage({
      type: 'system',
      content: 'Workspace reset to original pristine template.',
    });
  };

  // Multi-Agent Orchestration
  const handleTriggerOrchestration = async (goal: string) => {
    setIsOrchestrating(true);
    addMessage({
      type: 'user',
      content: `orchestrate team: "${goal}"`,
    });

    try {
      const res = await fetch('/api/nlp/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: goal,
          projectName: currentProject.name,
        }),
      });
      const data = await res.json();
      if (data.tasks) {
        setAgentTasks(data.tasks);
        addMessage({
          type: 'success',
          content: `Spawned ${data.tasks.length} specialized agents for goal: "${goal}". Inspect details in the Agents tab.`,
        });
        setActiveTab('agents');
      }
    } catch (e: any) {
      addMessage({
        type: 'error',
        content: `Agent orchestration error: ${e.message}`,
      });
    } finally {
      setIsOrchestrating(false);
    }
  };

  // Stored .nlp Program runner
  const handleRunProgram = (prog: NLPProgram) => {
    addMessage({
      type: 'user',
      content: `run ${prog.filename}`,
    });

    addMessage({
      type: 'system',
      content: `Compiling declarative .nlp program '${prog.filename}' into deterministic DAG...`,
    });

    setTimeout(() => {
      addMessage({
        type: 'success',
        content: `Program '${prog.filename}' compiled and verified with 0 warnings. All requirements satisfied.`,
      });
    }, 800);
  };

  // Macro Execution
  const handleRunMacro = (macro: NLPMacro) => {
    addMessage({
      type: 'user',
      content: macro.name,
    });

    addMessage({
      type: 'system',
      content: `Executing composite macro "${macro.name}" from .nlpterm/commands/${macro.filename}...`,
    });

    // Run first step as compilation
    handleCompilePrompt(macro.pipeline[0]);
  };

  // Add custom macro
  const handleAddMacro = (
    name: string,
    description: string,
    pipeline: string[]
  ) => {
    const newMacro: NLPMacro = {
      name,
      description,
      pipeline,
      filename: `${name.toLowerCase().replace(/\s+/g, '_')}.toml`,
    };
    setMacros((prev) => [...prev, newMacro]);
    addMessage({
      type: 'success',
      content: `Saved new natural language macro "${name}" in .nlpterm/commands/${newMacro.filename}`,
    });
  };

  // Trigger benchmark
  const handleTriggerBenchmark = () => {
    handleCompilePrompt('make the application 30% faster');
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-[#0c0e14] text-[#d4d4d8] overflow-hidden select-none font-sans">
      {/* Topbar Navigation */}
      <TerminalHeader
        currentProject={currentProject}
        projects={projects}
        onSelectProject={(id) => setCurrentProjectId(id)}
        projectMode={projectMode}
        onSelectMode={(mode) => {
          setProjectMode(mode);
          addMessage({
            type: 'system',
            content: `Switched project mode to ${mode}`,
          });
        }}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        hasPendingPlan={activePlan?.state === 'awaiting_confirmation'}
        hasDiff={(activePlan?.operations || []).some((o) => !!o.diff)}
        onResetWorkspace={handleResetWorkspace}
      />

      {/* Dynamic View Panels */}
      <main className="flex-1 flex overflow-hidden">
        {activeTab === 'terminal' && (
          <TerminalConsole
            messages={messages}
            onSendMessage={handleCompilePrompt}
            currentProject={currentProject}
            projectMode={projectMode}
            isCompiling={isCompiling}
            activePlan={activePlan}
            onApprovePlan={handleApprovePlan}
            onRejectPlan={handleRejectPlan}
            onViewDiff={() => setActiveTab('diff')}
            onRollback={handleRollback}
          />
        )}

        {activeTab === 'pipeline' && (
          <ExecutionPipelineView
            plan={activePlan}
            onApprovePlan={handleApprovePlan}
            onRejectPlan={handleRejectPlan}
            onViewDiff={() => setActiveTab('diff')}
            onRollback={handleRollback}
          />
        )}

        {activeTab === 'diff' && (
          <DiffViewer
            plan={activePlan}
            onApprovePlan={handleApprovePlan}
            onRejectPlan={handleRejectPlan}
            onRollback={handleRollback}
          />
        )}

        {activeTab === 'files' && (
          <ProjectExplorer project={currentProject} />
        )}

        {activeTab === 'agents' && (
          <AgentsPanel
            tasks={agentTasks}
            onTriggerOrchestration={handleTriggerOrchestration}
            isOrchestrating={isOrchestrating}
          />
        )}

        {activeTab === 'benchmarks' && (
          <BenchmarkPanel
            benchmarks={benchmarks}
            onTriggerBenchmark={handleTriggerBenchmark}
          />
        )}

        {activeTab === 'programs' && (
          <NLPProgramsPanel
            programs={programs}
            onRunProgram={handleRunProgram}
            isRunningProgram={false}
          />
        )}

        {activeTab === 'macros' && (
          <MacrosManager
            macros={macros}
            onRunMacro={handleRunMacro}
            onAddMacro={handleAddMacro}
          />
        )}

        {activeTab === 'audit' && (
          <AuditHistoryView
            entries={auditLogs}
            onRollback={handleRollback}
          />
        )}
      </main>
    </div>
  );
}
