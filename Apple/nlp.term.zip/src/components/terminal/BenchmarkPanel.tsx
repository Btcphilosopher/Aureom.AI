import React from 'react';
import { BenchmarkMetrics } from '../../types/nlp';
import {
  Activity,
  Zap,
  TrendingUp,
  Cpu,
  HardDrive,
  Clock,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';

interface BenchmarkPanelProps {
  benchmarks: BenchmarkMetrics[];
  onTriggerBenchmark: () => void;
}

export const BenchmarkPanel: React.FC<BenchmarkPanelProps> = ({
  benchmarks,
  onTriggerBenchmark,
}) => {
  const current = benchmarks[0] || {
    id: 'bench-1',
    timestamp: '2026-09-10 08:42:12',
    title: 'Archive Verifier Throughput Optimization',
    targetMetric: 'Throughput (req/s) & Latency',
    baseline: {
      startupMs: 2810,
      memoryMb: 412,
      requestsPerSec: 1842,
      p99LatencyMs: 4.2,
    },
    proposed: {
      startupMs: 2180,
      memoryMb: 368,
      requestsPerSec: 2410,
      p99LatencyMs: 2.1,
    },
    bottleneckIdentified:
      'Payload deserialization copying memory buffers instead of zero-copy slice streaming',
    optimizationApplied:
      'Zero-copy Bytes slice parsing with chunked SIMD-accelerated SHA-256 batch hasher',
    percentageImprovement: 30.8,
    isVerifiedImprovement: true,
  };

  return (
    <div className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-xs overflow-hidden">
      {/* Top bar */}
      <div className="bg-[#10141f] border-b border-[#1c2333] px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-[#f59e0b]" />
          <span className="font-bold text-[#f1f5f9] text-xs">
            Benchmark-Driven Programming Engine
          </span>
          <span className="text-[10px] text-[#64748b]">
            (Never claim improvement without verifiable measurement)
          </span>
        </div>
        <button
          onClick={onTriggerBenchmark}
          className="flex items-center gap-1.5 px-3 py-1 bg-[#f59e0b] hover:bg-[#d97706] text-[#0c0e14] rounded font-bold text-xs transition"
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Run Benchmark Suite</span>
        </button>
      </div>

      {/* Main Benchmarks View */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-4xl mx-auto">
        {/* Title Card */}
        <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[#f8fafc] flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#10b981]" />
              <span>{current.title}</span>
            </h3>
            <span className="text-[11px] px-2 py-0.5 bg-[#10b981]/20 text-[#34d399] border border-[#10b981]/30 rounded font-bold">
              +{current.percentageImprovement}% Throughput Gain
            </span>
          </div>
          <div className="text-[11px] text-[#94a3b8]">
            <span className="text-[#64748b]">Timestamp: </span>
            {current.timestamp}
          </div>
        </div>

        {/* Comparative 4-Metric Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Metric 1: Requests/sec */}
          <div className="bg-[#10141f] border border-[#1e273a] rounded-lg p-3.5 space-y-2">
            <div className="text-[10px] uppercase text-[#64748b] font-bold">
              Throughput (req/sec)
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-lg font-bold text-[#34d399]">
                {current.proposed.requestsPerSec.toLocaleString()}
              </span>
              <span className="text-xs text-[#64748b] line-through">
                {current.baseline.requestsPerSec.toLocaleString()}
              </span>
            </div>
            <div className="text-[10px] text-[#10b981] font-semibold">
              ▲ +{Math.round(((current.proposed.requestsPerSec - current.baseline.requestsPerSec) / current.baseline.requestsPerSec) * 100)}% increase
            </div>
          </div>

          {/* Metric 2: P99 Latency */}
          <div className="bg-[#10141f] border border-[#1e273a] rounded-lg p-3.5 space-y-2">
            <div className="text-[10px] uppercase text-[#64748b] font-bold">
              P99 Latency
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-lg font-bold text-[#38bdf8]">
                {current.proposed.p99LatencyMs} ms
              </span>
              <span className="text-xs text-[#64748b] line-through">
                {current.baseline.p99LatencyMs} ms
              </span>
            </div>
            <div className="text-[10px] text-[#38bdf8] font-semibold">
              ▼ -50% latency drop
            </div>
          </div>

          {/* Metric 3: Memory Footprint */}
          <div className="bg-[#10141f] border border-[#1e273a] rounded-lg p-3.5 space-y-2">
            <div className="text-[10px] uppercase text-[#64748b] font-bold">
              Peak RAM Footprint
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-lg font-bold text-[#a855f7]">
                {current.proposed.memoryMb} MB
              </span>
              <span className="text-xs text-[#64748b] line-through">
                {current.baseline.memoryMb} MB
              </span>
            </div>
            <div className="text-[10px] text-[#a855f7] font-semibold">
              ▼ -44 MB saved
            </div>
          </div>

          {/* Metric 4: Cold Startup */}
          <div className="bg-[#10141f] border border-[#1e273a] rounded-lg p-3.5 space-y-2">
            <div className="text-[10px] uppercase text-[#64748b] font-bold">
              Cold Startup
            </div>
            <div className="flex items-baseline justify-between">
              <span className="text-lg font-bold text-[#f59e0b]">
                {(current.proposed.startupMs / 1000).toFixed(2)} s
              </span>
              <span className="text-xs text-[#64748b] line-through">
                {(current.baseline.startupMs / 1000).toFixed(2)} s
              </span>
            </div>
            <div className="text-[10px] text-[#f59e0b] font-semibold">
              ▼ -22.4% faster boot
            </div>
          </div>
        </div>

        {/* Diagnosis & Optimization Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-2">
            <div className="text-[11px] font-bold text-[#f87171] uppercase">
              1. Bottleneck Identified via Profiler
            </div>
            <p className="text-xs text-[#cbd5e1] leading-relaxed">
              {current.bottleneckIdentified}
            </p>
          </div>

          <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-2">
            <div className="text-[11px] font-bold text-[#34d399] uppercase">
              2. Applied Optimization Patch
            </div>
            <p className="text-xs text-[#cbd5e1] leading-relaxed">
              {current.optimizationApplied}
            </p>
          </div>
        </div>

        {/* Verification Safety Guard */}
        <div className="bg-[#101624] border border-[#1c2942] rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-[#10b981]" />
            <div>
              <div className="text-xs font-bold text-[#f1f5f9]">
                Automated Regression Guard: PASSED
              </div>
              <div className="text-[11px] text-[#94a3b8]">
                Criterion benchmarks satisfied. Memory remained below baseline threshold.
              </div>
            </div>
          </div>
          <span className="text-[10px] px-2.5 py-1 bg-[#10b981]/20 text-[#34d399] border border-[#10b981]/40 rounded font-bold uppercase">
            Keep Change
          </span>
        </div>
      </div>
    </div>
  );
};
