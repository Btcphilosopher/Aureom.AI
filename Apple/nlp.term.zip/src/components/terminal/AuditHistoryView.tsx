import React, { useState } from 'react';
import { AuditEntry } from '../../types/nlp';
import {
  History,
  RotateCcw,
  Shield,
  CheckCircle2,
  Clock,
  FileCode,
  Terminal,
  Cpu,
  ArrowRight,
} from 'lucide-react';

interface AuditHistoryViewProps {
  entries: AuditEntry[];
  onRollback: (snapshotId: string) => void;
}

export const AuditHistoryView: React.FC<AuditHistoryViewProps> = ({
  entries,
  onRollback,
}) => {
  const [selectedEntryId, setSelectedEntryId] = useState<string>(
    entries[0]?.id || ''
  );

  const activeEntry = entries.find((e) => e.id === selectedEntryId) || entries[0];

  return (
    <div className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-xs overflow-hidden">
      {/* Top bar */}
      <div className="bg-[#10141f] border-b border-[#1c2333] px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-[#94a3b8]" />
          <span className="font-bold text-[#f1f5f9] text-xs">
            Immutable Audit Trail &amp; Cryptographic History
          </span>
          <span className="text-[10px] text-[#64748b]">
            ({entries.length} recorded state transitions in .nlpterm/history/)
          </span>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-[#10b981]">
          <Shield className="w-3.5 h-3.5" />
          <span>SHA-256 Snapshot Integrity Verified</span>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Entries List */}
        <div className="w-80 bg-[#0a0d13] border-r border-[#181f2c] p-2 space-y-1 overflow-y-auto shrink-0">
          <div className="text-[10px] uppercase text-[#64748b] font-bold px-2 py-1">
            Execution Log
          </div>
          {entries.map((entry) => (
            <button
              key={entry.id}
              onClick={() => setSelectedEntryId(entry.id)}
              className={`w-full text-left p-2.5 rounded transition space-y-1.5 ${
                selectedEntryId === entry.id
                  ? 'bg-[#161f30] border border-[#23324d] text-[#38bdf8]'
                  : 'text-[#94a3b8] hover:bg-[#121620] hover:text-[#cbd5e1]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#64748b]">{entry.timestamp}</span>
                <span className="text-[9px] px-1.5 py-0.2 bg-[#10b981]/20 text-[#34d399] rounded font-semibold">
                  {entry.verificationStatus}
                </span>
              </div>
              <div className="font-bold text-xs text-[#f1f5f9] truncate">
                &quot;{entry.userPrompt}&quot;
              </div>
              <div className="text-[10px] text-[#64748b] font-mono flex items-center justify-between">
                <span>{entry.operationsCount} operations</span>
                <span>{entry.snapshotId}</span>
              </div>
            </button>
          ))}
        </div>

        {/* Right Detail View */}
        {activeEntry && (
          <div className="flex-1 flex flex-col overflow-y-auto p-4 space-y-4 bg-[#080a0f]">
            {/* Header info */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-[#64748b] uppercase">User Prompt</div>
                  <div className="text-sm font-bold text-[#f8fafc] mt-0.5">
                    &quot;{activeEntry.userPrompt}&quot;
                  </div>
                </div>
                <button
                  onClick={() => onRollback(activeEntry.snapshotId)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded font-bold text-xs transition cursor-pointer shadow"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Rollback to Snapshot</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-[#1a2336] text-[11px]">
                <div>
                  <span className="text-[#64748b]">Intent: </span>
                  <span className="text-[#38bdf8]">{activeEntry.intentKey}</span>
                </div>
                <div>
                  <span className="text-[#64748b]">Model: </span>
                  <span className="text-[#f59e0b]">{activeEntry.model}</span>
                </div>
                <div>
                  <span className="text-[#64748b]">Duration: </span>
                  <span className="text-[#cbd5e1]">{activeEntry.durationMs} ms</span>
                </div>
                <div>
                  <span className="text-[#64748b]">Snapshot: </span>
                  <span className="text-[#a855f7] font-mono">{activeEntry.snapshotId}</span>
                </div>
              </div>
            </div>

            {/* Affected Files */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-2">
              <div className="text-xs font-bold text-[#38bdf8] uppercase">
                Files Modified / Created
              </div>
              <div className="flex flex-wrap gap-2">
                {activeEntry.filesModified.map((f) => (
                  <span
                    key={f}
                    className="text-xs font-mono px-2.5 py-1 bg-[#121927] text-[#cbd5e1] border border-[#1f2b42] rounded flex items-center gap-1"
                  >
                    <FileCode className="w-3.5 h-3.5 text-[#38bdf8]" />
                    <span>{f}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Commands executed */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-2">
              <div className="text-xs font-bold text-[#10b981] uppercase">
                Tool &amp; Shell Commands Executed
              </div>
              <div className="space-y-1.5">
                {activeEntry.commandsRun.map((cmd, i) => (
                  <div
                    key={i}
                    className="p-2 bg-[#121826] border border-[#1c2438] rounded text-xs font-mono text-[#a5b4fc]"
                  >
                    $ {cmd}
                  </div>
                ))}
              </div>
            </div>

            {/* Verification status */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-1 text-xs">
              <div className="text-xs font-bold text-[#34d399] uppercase flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#10b981]" />
                <span>Verification Outcome: {activeEntry.verificationStatus}</span>
              </div>
              <p className="text-[11px] text-[#94a3b8]">{activeEntry.outputSummary}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
