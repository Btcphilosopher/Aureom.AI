import React, { useState, useRef, useEffect } from 'react';
import {
  TerminalMessage,
  ExecutionPlan,
  ProjectMode,
} from '../../types/nlp';
import { ProjectWorkspace } from '../../data/defaultProjects';
import {
  CornerDownLeft,
  Sparkles,
  Play,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  Shield,
  Layers,
  HelpCircle,
  RotateCcw,
  Sliders,
  Check,
  X,
  Clock,
} from 'lucide-react';

interface TerminalConsoleProps {
  messages: TerminalMessage[];
  onSendMessage: (text: string) => void;
  currentProject: ProjectWorkspace;
  projectMode: ProjectMode;
  isCompiling: boolean;
  activePlan: ExecutionPlan | null;
  onApprovePlan: (planId: string) => void;
  onRejectPlan: (planId: string) => void;
  onViewDiff: () => void;
  onRollback: (snapshotId?: string) => void;
}

const QUICK_DEMOS = [
  {
    label: '🚀 Slice 1: Rust HTTP Server',
    query: 'create a Rust HTTP server with a health endpoint',
    desc: 'Generates Cargo.toml, src/main.rs, tests/health.rs with Axum',
  },
  {
    label: '🔍 Slice 2: Explain Architecture',
    query: 'inspect this project and explain the architecture',
    desc: 'Deep AST symbol scan and module breakdown',
  },
  {
    label: '🛠️ Slice 3: Fix Failing Tests',
    query: 'find why the tests are failing and fix them',
    desc: 'Detects inverted session timestamp bug in auth/session.rs & patches',
  },
  {
    label: '⚡ Slice 4: 30% Faster Benchmark',
    query: 'make the application 30% faster',
    desc: 'Zero-copy SIMD optimization with baseline vs proposed benchmark',
  },
  {
    label: '⚠️ Safety: Ambiguity Check',
    query: 'delete the old files',
    desc: 'Tests ambiguity compiler guard requiring target clarification',
  },
  {
    label: '📜 .NLP Program: Archive',
    query: 'run archive_project.nlp',
    desc: 'Executes declarative .nlp program with cryptographic rollback',
  },
  {
    label: '🤖 Agents: Media Server',
    query: 'build a production-ready media server with full agent team',
    desc: 'Spawns Architect, Coder, Tester, Security, Performance & Reviewer',
  },
  {
    label: '📦 Macro: "ship it"',
    query: 'ship it',
    desc: 'Executes composite pipeline defined in .nlpterm/commands/ship.toml',
  },
];

export const TerminalConsole: React.FC<TerminalConsoleProps> = ({
  messages,
  onSendMessage,
  currentProject,
  projectMode,
  isCompiling,
  activePlan,
  onApprovePlan,
  onRejectPlan,
  onViewDiff,
  onRollback,
}) => {
  const [input, setInput] = useState('');
  const [historyIndex, setHistoryIndex] = useState<number | null>(null);
  const commandHistory = useRef<string[]>([]);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isCompiling, activePlan]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isCompiling) return;

    commandHistory.current.push(trimmed);
    setHistoryIndex(null);
    onSendMessage(trimmed);
    setInput('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.current.length === 0) return;
      const nextIndex =
        historyIndex === null
          ? commandHistory.current.length - 1
          : Math.max(0, historyIndex - 1);
      setHistoryIndex(nextIndex);
      setInput(commandHistory.current[nextIndex]);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex === null) return;
      const nextIndex = historyIndex + 1;
      if (nextIndex >= commandHistory.current.length) {
        setHistoryIndex(null);
        setInput('');
      } else {
        setHistoryIndex(nextIndex);
        setInput(commandHistory.current[nextIndex]);
      }
    }
  };

  return (
    <div
      className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-[13px] leading-relaxed overflow-hidden"
      onClick={() => inputRef.current?.focus()}
    >
      {/* Quick Interactive Demo Selector Chips */}
      <div className="bg-[#10131c] border-b border-[#1b212e] px-4 py-2 flex items-center gap-1.5 overflow-x-auto shrink-0 select-none">
        <span className="text-[11px] text-[#64748b] font-semibold uppercase tracking-wider shrink-0 flex items-center gap-1 mr-1">
          <Sparkles className="w-3 h-3 text-[#38bdf8]" />
          Demos:
        </span>
        {QUICK_DEMOS.map((demo) => (
          <button
            key={demo.label}
            onClick={(e) => {
              e.stopPropagation();
              onSendMessage(demo.query);
            }}
            disabled={isCompiling}
            title={demo.desc}
            className="text-[11px] px-2.5 py-1 bg-[#161b26] hover:bg-[#202738] active:bg-[#2563eb] text-[#94a3b8] hover:text-[#f8fafc] border border-[#232b3d] hover:border-[#3b82f6]/40 rounded transition shrink-0 flex items-center gap-1 cursor-pointer disabled:opacity-50"
          >
            <span>{demo.label}</span>
          </button>
        ))}
      </div>

      {/* Main Terminal Message Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono">
        {/* Banner Box */}
        <div className="text-[#38bdf8] select-none text-xs leading-tight opacity-90 max-w-2xl">
          <div className="border border-[#2563eb]/40 bg-[#0e1322] rounded p-3 text-[#e2e8f0]">
            <div className="text-[#38bdf8] font-bold text-sm">NLP.TERM</div>
            <div className="text-[#94a3b8] text-[11px] mt-0.5">
              Natural Language Programming Environment for the Terminal
            </div>
            <div className="mt-2 text-[11px] space-y-0.5 text-[#cbd5e1] border-t border-[#1e293b] pt-2">
              <div>
                <span className="text-[#64748b]">project: </span>
                <span className="text-[#38bdf8] font-semibold">{currentProject.name}</span>
              </div>
              <div>
                <span className="text-[#64748b]">branch: </span>
                <span className="text-[#a855f7]">{currentProject.branch}</span>
              </div>
              <div>
                <span className="text-[#64748b]">runtime: </span>
                <span className="text-[#10b981]">{currentProject.runtime}</span>
              </div>
              <div>
                <span className="text-[#64748b]">model: </span>
                <span className="text-[#f59e0b]">gemini-3.7-flash (Intent Compiler active)</span>
              </div>
              <div>
                <span className="text-[#64748b]">mode: </span>
                <span className="text-[#38bdf8] font-bold uppercase">{projectMode}</span>
              </div>
            </div>
            <div className="mt-2 text-[10px] text-[#64748b]">
              Type in natural language (e.g. <code className="text-[#38bdf8]">create a Rust HTTP server</code>) or use <code className="text-[#94a3b8]">/help</code>, <code className="text-[#94a3b8]">!command</code>.
            </div>
          </div>
        </div>

        {/* Dynamic Messages */}
        {messages.map((msg) => (
          <div key={msg.id} className="space-y-1.5">
            {msg.type === 'user' && (
              <div className="flex items-start gap-2 text-[#f8fafc]">
                <span className="text-[#38bdf8] font-bold select-none">nlp&gt;</span>
                <span className="font-semibold text-white">{msg.content}</span>
              </div>
            )}

            {msg.type === 'plan' && msg.plan && (
              <div className="border border-[#263147] bg-[#0e1320] rounded-lg p-3.5 space-y-3 max-w-3xl my-2 text-xs">
                {/* Ambiguity Alert if present */}
                {msg.plan.intent.isAmbiguous ? (
                  <div className="border border-[#eab308]/40 bg-[#eab308]/10 text-[#fef08a] p-3 rounded space-y-2">
                    <div className="flex items-center gap-2 font-bold text-sm text-[#facc15]">
                      <AlertTriangle className="w-4 h-4" />
                      <span>AMBIGUITY DETECTED</span>
                    </div>
                    <p className="text-xs text-[#fef9c3] leading-relaxed">
                      {msg.plan.intent.ambiguityReason}
                    </p>
                    {msg.plan.intent.clarificationOptions && (
                      <div className="space-y-1 pt-1">
                        <span className="text-[11px] text-[#fef08a] font-semibold">Please specify the target:</span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                          {msg.plan.intent.clarificationOptions.map((opt, idx) => (
                            <button
                              key={idx}
                              onClick={() => onSendMessage(opt)}
                              className="text-left px-2.5 py-1.5 bg-[#171c28] hover:bg-[#2563eb] text-[#e2e8f0] hover:text-white rounded border border-[#333d52] transition text-[11px]"
                            >
                              {opt}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    {/* Header Intent */}
                    <div className="border-b border-[#1c2436] pb-2">
                      <div className="flex items-center justify-between">
                        <div className="text-[#38bdf8] font-bold text-xs uppercase tracking-wider flex items-center gap-1.5">
                          <Layers className="w-3.5 h-3.5" />
                          <span>INTENT DETECTED</span>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                            msg.plan.intent.risk === 'SAFE'
                              ? 'bg-[#10b981]/20 text-[#10b981] border border-[#10b981]/30'
                              : msg.plan.intent.risk === 'LOW'
                              ? 'bg-[#3b82f6]/20 text-[#60a5fa] border border-[#3b82f6]/30'
                              : msg.plan.intent.risk === 'MEDIUM'
                              ? 'bg-[#f59e0b]/20 text-[#f59e0b] border border-[#f59e0b]/30'
                              : 'bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30'
                          }`}
                        >
                          RISK: {msg.plan.intent.risk}
                        </span>
                      </div>
                      <div className="mt-1.5 text-[#e2e8f0] font-medium text-[13px]">
                        {msg.plan.summary}
                      </div>
                      {msg.plan.intent.requirements.length > 0 && (
                        <div className="mt-1.5 space-y-0.5 text-[11px] text-[#94a3b8]">
                          <span className="text-[#64748b]">Requirements: </span>
                          {msg.plan.intent.requirements.join(' • ')}
                        </div>
                      )}
                    </div>

                    {/* Step-by-Step Plan */}
                    <div className="space-y-1.5">
                      <div className="text-[11px] text-[#64748b] font-bold uppercase tracking-wider">
                        PLAN
                      </div>
                      <div className="space-y-1">
                        {msg.plan.steps.map((step) => (
                          <div
                            key={step.id}
                            className="flex items-start gap-2 text-[12px] text-[#cbd5e1]"
                          >
                            <span className="text-[#38bdf8] font-semibold select-none">
                              {step.id}.
                            </span>
                            <div>
                              <span className="font-medium text-[#f1f5f9]">{step.title}</span>
                              <span className="text-[#64748b] text-[11px] ml-1.5">
                                — {step.description}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Files to Create / Modify */}
                    {(msg.plan.filesToCreate.length > 0 ||
                      msg.plan.filesToModify.length > 0) && (
                      <div className="pt-2 border-t border-[#1c2436] space-y-1">
                        <div className="text-[11px] text-[#64748b] font-bold uppercase tracking-wider">
                          FILES AFFECTED
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {msg.plan.filesToCreate.map((f) => (
                            <span
                              key={f}
                              className="text-[11px] px-2 py-0.5 bg-[#10b981]/15 text-[#34d399] border border-[#10b981]/30 rounded font-mono flex items-center gap-1"
                            >
                              <span>+</span> {f}
                            </span>
                          ))}
                          {msg.plan.filesToModify.map((f) => (
                            <span
                              key={f}
                              className="text-[11px] px-2 py-0.5 bg-[#3b82f6]/15 text-[#60a5fa] border border-[#3b82f6]/30 rounded font-mono flex items-center gap-1"
                            >
                              <span>~</span> {f}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Operations Explainability Box */}
                    {msg.plan.operations.length > 0 && msg.plan.operations[0].explanation && (
                      <div className="bg-[#121724] border border-[#1e273a] rounded p-2.5 space-y-1 text-[11px]">
                        <div className="text-[#38bdf8] font-bold">WHY:</div>
                        <p className="text-[#cbd5e1]">{msg.plan.operations[0].explanation.why}</p>
                        <div className="text-[#38bdf8] font-bold pt-1">EFFECT:</div>
                        <p className="text-[#94a3b8]">{msg.plan.operations[0].explanation.effect}</p>
                      </div>
                    )}

                    {/* Confirmation Bar */}
                    {msg.plan.state === 'awaiting_confirmation' && (
                      <div className="pt-2 border-t border-[#1e273a] flex items-center justify-between flex-wrap gap-2">
                        <div className="text-xs text-[#f59e0b] font-semibold flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Proceed with execution?</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {msg.plan.filesToModify.length > 0 && (
                            <button
                              onClick={onViewDiff}
                              className="flex items-center gap-1 px-2.5 py-1 text-xs bg-[#171e2e] hover:bg-[#20293d] text-[#38bdf8] border border-[#2b374f] rounded transition"
                            >
                              <Sliders className="w-3 h-3" />
                              <span>View Diff</span>
                            </button>
                          )}
                          <button
                            onClick={() => onRejectPlan(msg.plan!.id)}
                            className="flex items-center gap-1 px-2.5 py-1 text-xs bg-[#1f1619] hover:bg-[#2d1b22] text-[#f87171] border border-[#48232c] rounded transition"
                          >
                            <X className="w-3 h-3" />
                            <span>Reject [n]</span>
                          </button>
                          <button
                            onClick={() => onApprovePlan(msg.plan!.id)}
                            className="flex items-center gap-1.5 px-3.5 py-1 text-xs font-bold bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded shadow transition cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Proceed [Y]</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Execution in progress */}
                    {msg.plan.state === 'executing' && (
                      <div className="pt-2 flex items-center gap-2 text-[#38bdf8] text-xs">
                        <div className="w-3 h-3 border-2 border-[#38bdf8] border-t-transparent rounded-full animate-spin" />
                        <span>Executing typed operations and running verification checks...</span>
                      </div>
                    )}

                    {/* Completed */}
                    {msg.plan.state === 'completed' && (
                      <div className="pt-2 border-t border-[#1e273a] flex items-center justify-between text-xs text-[#10b981]">
                        <div className="flex items-center gap-1.5 font-bold">
                          <CheckCircle2 className="w-4 h-4 text-[#10b981]" />
                          <span>All operations executed and verified</span>
                        </div>
                        {msg.plan.rollbackSnapshotId && (
                          <button
                            onClick={() => onRollback(msg.plan!.rollbackSnapshotId)}
                            className="flex items-center gap-1 text-[11px] text-[#94a3b8] hover:text-white bg-[#141a28] hover:bg-[#1e263a] px-2 py-0.5 border border-[#273248] rounded transition"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>Rollback</span>
                          </button>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            )}

            {msg.type === 'output' && (
              <pre className="text-[#a1a1aa] text-xs whitespace-pre-wrap pl-4 border-l border-[#27272a] py-0.5 font-mono">
                {msg.content}
              </pre>
            )}

            {msg.type === 'success' && (
              <div className="text-[#34d399] flex items-center gap-2 pl-4 py-0.5 font-semibold text-xs">
                <span>✓</span>
                <span>{msg.content}</span>
              </div>
            )}

            {msg.type === 'error' && (
              <div className="text-[#f87171] flex items-start gap-2 pl-4 py-0.5 text-xs bg-[#ef4444]/10 border-l-2 border-[#ef4444] rounded-r p-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-[#ef4444]" />
                <div className="whitespace-pre-wrap font-mono">{msg.content}</div>
              </div>
            )}

            {msg.type === 'system' && (
              <div className="text-[#64748b] text-[11px] italic pl-4 py-0.5">
                {msg.content}
              </div>
            )}
          </div>
        ))}

        {/* Compiling Spinner */}
        {isCompiling && (
          <div className="flex items-center gap-2 text-xs text-[#38bdf8] pl-2 py-1">
            <div className="w-3.5 h-3.5 border-2 border-[#38bdf8] border-t-transparent rounded-full animate-spin" />
            <span>Compiling natural language into typed execution plan...</span>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input Prompt Box */}
      <div className="bg-[#0e1118] border-t border-[#1c2230] p-3 shrink-0">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <span className="text-[#38bdf8] font-bold text-sm select-none pl-1">
            nlp&gt;
          </span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isCompiling}
            placeholder="Type in English (e.g. 'create a python project', 'make this faster', '!ls', '/help')..."
            className="flex-1 bg-transparent text-[#f8fafc] placeholder-[#475569] outline-none font-mono text-xs md:text-[13px]"
            autoFocus
          />
          <button
            type="submit"
            disabled={!input.trim() || isCompiling}
            className="px-3 py-1.5 bg-[#2563eb] hover:bg-[#1d4ed8] disabled:opacity-30 disabled:hover:bg-[#2563eb] text-white rounded text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
          >
            <span>Execute</span>
            <CornerDownLeft className="w-3 h-3" />
          </button>
        </form>
        <div className="flex items-center justify-between text-[10px] text-[#64748b] pt-1.5 px-1 select-none">
          <span>Tip: Natural language by default • Use <code className="text-[#94a3b8]">/command</code> or <code className="text-[#94a3b8]">!shell</code> for raw CLI.</span>
          <span className="font-mono text-[#38bdf8]/70">Gemini 3.7 Flash Intent Compiler</span>
        </div>
      </div>
    </div>
  );
};
