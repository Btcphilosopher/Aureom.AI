import React from 'react';
import {
  Terminal,
  Cpu,
  Shield,
  Layers,
  Activity,
  History,
  GitBranch,
  FolderTree,
  FileCode,
  Zap,
  Users,
  Settings2,
  RefreshCw,
  Sliders,
} from 'lucide-react';
import { ProjectMode } from '../../types/nlp';
import { ProjectWorkspace } from '../../data/defaultProjects';

interface TerminalHeaderProps {
  currentProject: ProjectWorkspace;
  projects: Record<string, ProjectWorkspace>;
  onSelectProject: (id: string) => void;
  projectMode: ProjectMode;
  onSelectMode: (mode: ProjectMode) => void;
  activeTab: 'terminal' | 'pipeline' | 'diff' | 'files' | 'agents' | 'benchmarks' | 'programs' | 'audit' | 'macros';
  setActiveTab: (tab: 'terminal' | 'pipeline' | 'diff' | 'files' | 'agents' | 'benchmarks' | 'programs' | 'audit' | 'macros') => void;
  hasPendingPlan: boolean;
  hasDiff: boolean;
  onResetWorkspace: () => void;
}

const MODES: { mode: ProjectMode; desc: string }[] = [
  { mode: 'BUILD', desc: 'Construct & generate software' },
  { mode: 'DEBUG', desc: 'Diagnose failures & fix code' },
  { mode: 'REFACTOR', desc: 'Improve structure & performance' },
  { mode: 'AUDIT', desc: 'Inspect security & correctness' },
  { mode: 'LEARN', desc: 'Explain & inspect architecture' },
  { mode: 'OPERATE', desc: 'Run systems & processes' },
  { mode: 'DEPLOY', desc: 'Package & build release' },
  { mode: 'RESEARCH', desc: 'Deep code exploration' },
];

export const TerminalHeader: React.FC<TerminalHeaderProps> = ({
  currentProject,
  projects,
  onSelectProject,
  projectMode,
  onSelectMode,
  activeTab,
  setActiveTab,
  hasPendingPlan,
  hasDiff,
  onResetWorkspace,
}) => {
  return (
    <header className="border-b border-[#1f2430] bg-[#0c0e14]/95 backdrop-blur px-4 py-2.5 flex flex-col gap-2 shrink-0 select-none">
      {/* Upper bar: Identity + Meta Badges + System Info */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-2 py-1 bg-[#131722] border border-[#272e3f] rounded">
            <Terminal className="w-4 h-4 text-[#38bdf8]" />
            <span className="font-mono text-xs font-bold tracking-wider text-[#f1f5f9]">NLP.TERM</span>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 bg-[#2563eb]/20 text-[#60a5fa] border border-[#3b82f6]/30 rounded">
              v1.0-ir
            </span>
          </div>

          {/* Project Switcher */}
          <div className="flex items-center gap-1.5 bg-[#11141d] border border-[#1e2433] rounded px-2.5 py-1 text-xs font-mono">
            <span className="text-[#64748b]">project:</span>
            <select
              value={currentProject.id}
              onChange={(e) => onSelectProject(e.target.value)}
              aria-label="Select Project"
              className="bg-transparent text-[#38bdf8] font-semibold outline-none cursor-pointer"
            >
              {(Object.values(projects) as ProjectWorkspace[]).map((p) => (
                <option key={p.id} value={p.id} className="bg-[#11141d] text-[#e2e8f0]">
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          {/* Git Branch */}
          <div className="flex items-center gap-1.5 bg-[#11141d] border border-[#1e2433] rounded px-2 py-1 text-xs font-mono text-[#94a3b8]">
            <GitBranch className="w-3.5 h-3.5 text-[#a855f7]" />
            <span>{currentProject.branch}</span>
          </div>

          {/* Runtime */}
          <div className="flex items-center gap-1.5 bg-[#11141d] border border-[#1e2433] rounded px-2 py-1 text-xs font-mono">
            <div className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse" />
            <span className="text-[#64748b]">runtime:</span>
            <span className="text-[#10b981]">{currentProject.runtime}</span>
          </div>

          {/* Model */}
          <div className="flex items-center gap-1.5 bg-[#11141d] border border-[#1e2433] rounded px-2 py-1 text-xs font-mono">
            <Cpu className="w-3.5 h-3.5 text-[#f59e0b]" />
            <span className="text-[#64748b]">model:</span>
            <span className="text-[#f59e0b] font-medium">gemini-3.7-flash</span>
          </div>
        </div>

        {/* Right Tools */}
        <div className="flex items-center gap-2">
          <button
            onClick={onResetWorkspace}
            title="Reset workspace to clean baseline"
            className="flex items-center gap-1.5 text-[11px] font-mono px-2.5 py-1 text-[#94a3b8] hover:text-[#f1f5f9] bg-[#141824] hover:bg-[#1c2234] border border-[#22293b] rounded transition"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Lower Bar: Mode selector + Tab Views Navigation */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pt-1 border-t border-[#181d29]">
        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1">
          <button
            onClick={() => setActiveTab('terminal')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'terminal'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Console</span>
          </button>

          <button
            onClick={() => setActiveTab('pipeline')}
            className={`relative flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'pipeline'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span>Pipeline & IR</span>
            {hasPendingPlan && (
              <span className="w-2 h-2 rounded-full bg-[#f59e0b] animate-ping ml-0.5" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('diff')}
            className={`relative flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'diff'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-[#a855f7]" />
            <span>Diffs</span>
            {hasDiff && (
              <span className="w-1.5 h-1.5 rounded-full bg-[#38bdf8] ml-0.5" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'files'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5 text-[#10b981]" />
            <span>Files & AST</span>
          </button>

          <button
            onClick={() => setActiveTab('agents')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'agents'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-[#ec4899]" />
            <span>Agents</span>
          </button>

          <button
            onClick={() => setActiveTab('benchmarks')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'benchmarks'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-[#f59e0b]" />
            <span>Benchmarks</span>
          </button>

          <button
            onClick={() => setActiveTab('programs')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'programs'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-[#06b6d4]" />
            <span>.nlp Workflows</span>
          </button>

          <button
            onClick={() => setActiveTab('macros')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'macros'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-[#eab308]" />
            <span>Macros</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`flex items-center gap-1.5 px-3 py-1 text-xs font-mono rounded transition ${
              activeTab === 'audit'
                ? 'bg-[#2563eb] text-white shadow-sm font-semibold'
                : 'text-[#94a3b8] hover:text-[#e2e8f0] hover:bg-[#171c28]'
            }`}
          >
            <History className="w-3.5 h-3.5 text-[#94a3b8]" />
            <span>Audit History</span>
          </button>
        </nav>

        {/* Project Mode Selector */}
        <div className="flex items-center gap-1 shrink-0">
          <span className="text-[11px] font-mono text-[#64748b] mr-1 hidden sm:inline">MODE:</span>
          {MODES.map((m) => (
            <button
              key={m.mode}
              onClick={() => onSelectMode(m.mode)}
              title={m.desc}
              className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase tracking-wider transition ${
                projectMode === m.mode
                  ? 'bg-[#38bdf8]/20 text-[#38bdf8] border border-[#38bdf8]/40 font-bold'
                  : 'bg-[#121622] text-[#64748b] hover:text-[#94a3b8] border border-transparent'
              }`}
            >
              {m.mode}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
