import React, { useState } from 'react';
import { AgentTask, AgentRole } from '../../types/nlp';
import {
  Users,
  Cpu,
  ShieldCheck,
  Activity,
  CheckCircle2,
  Clock,
  FileCode,
  Sparkles,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface AgentsPanelProps {
  tasks: AgentTask[];
  onTriggerOrchestration: (goal: string) => void;
  isOrchestrating: boolean;
}

const AGENT_BADGES: Record<AgentRole, { color: string; border: string; bg: string }> = {
  Architect: { color: 'text-[#38bdf8]', border: 'border-[#38bdf8]/40', bg: 'bg-[#38bdf8]/10' },
  Coder: { color: 'text-[#34d399]', border: 'border-[#34d399]/40', bg: 'bg-[#34d399]/10' },
  Debugger: { color: 'text-[#f87171]', border: 'border-[#f87171]/40', bg: 'bg-[#f87171]/10' },
  Tester: { color: 'text-[#fbbf24]', border: 'border-[#fbbf24]/40', bg: 'bg-[#fbbf24]/10' },
  Security: { color: 'text-[#f43f5e]', border: 'border-[#f43f5e]/40', bg: 'bg-[#f43f5e]/10' },
  Performance: { color: 'text-[#a855f7]', border: 'border-[#a855f7]/40', bg: 'bg-[#a855f7]/10' },
  Documentation: { color: 'text-[#60a5fa]', border: 'border-[#60a5fa]/40', bg: 'bg-[#60a5fa]/10' },
  DevOps: { color: 'text-[#06b6d4]', border: 'border-[#06b6d4]/40', bg: 'bg-[#06b6d4]/10' },
  Researcher: { color: 'text-[#e879f9]', border: 'border-[#e879f9]/40', bg: 'bg-[#e879f9]/10' },
  Reviewer: { color: 'text-[#2dd4bf]', border: 'border-[#2dd4bf]/40', bg: 'bg-[#2dd4bf]/10' },
};

export const AgentsPanel: React.FC<AgentsPanelProps> = ({
  tasks,
  onTriggerOrchestration,
  isOrchestrating,
}) => {
  const [customGoal, setCustomGoal] = useState('');

  const defaultTasks: AgentTask[] = tasks.length > 0 ? tasks : [
    {
      id: 'agent-1',
      role: 'Architect',
      title: 'Design distributed zero-copy pipeline',
      description: 'Define subsystem boundaries, module layout, and memory streaming APIs',
      status: 'completed',
      output: 'Architecture blueprint finalized: modular pipeline with zero-copy stream processing.',
      artifacts: ['docs/architecture.md', 'src/types.rs'],
    },
    {
      id: 'agent-2',
      role: 'Coder',
      title: 'Implement async SHA-256 verifier',
      description: 'Write type-safe implementation matching architectural specs',
      status: 'completed',
      output: 'Core verifier routines implemented in Rust Axum with strict compile-time safety.',
      artifacts: ['src/archive/verifier.rs'],
    },
    {
      id: 'agent-3',
      role: 'Tester',
      title: 'Construct integration & regression tests',
      description: 'Develop edge-case fixtures and validation suites',
      status: 'completed',
      output: 'Created unit tests asserting payload validation and error boundaries.',
      artifacts: ['tests/auth_tests.rs'],
    },
    {
      id: 'agent-4',
      role: 'Security',
      title: 'Security & vulnerability audit',
      description: 'Check memory boundaries, constant-time comparisons, and secret isolation',
      status: 'completed',
      output: 'Audit complete: No CVEs. Safe memory patterns confirmed with zero unsafe blocks.',
      artifacts: ['reports/security_audit.json'],
    },
    {
      id: 'agent-5',
      role: 'Performance',
      title: 'Benchmark & profile hot paths',
      description: 'Execute latency and throughput stress suites',
      status: 'completed',
      output: 'Benchmark verified: P99 latency is 2.1ms under 2,400 req/s load (+30.8% boost).',
      artifacts: ['reports/benchmark_summary.txt'],
    },
    {
      id: 'agent-6',
      role: 'Reviewer',
      title: 'Final diff inspection & release sign-off',
      description: 'Inspect complete code delta and approve commit',
      status: 'completed',
      output: 'Ready for deployment. All verification criteria satisfied.',
      artifacts: ['CHANGELOG.md'],
    },
  ];

  const handleOrchestrate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customGoal.trim() || isOrchestrating) return;
    onTriggerOrchestration(customGoal.trim());
    setCustomGoal('');
  };

  return (
    <div className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-xs overflow-hidden">
      {/* Top bar */}
      <div className="bg-[#10141f] border-b border-[#1c2333] px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-[#ec4899]" />
          <span className="font-bold text-[#f1f5f9] text-xs">Multi-Agent Orchestrator</span>
          <span className="text-[10px] text-[#64748b]">
            (Coordinated Task Delegation with Shared Typed State)
          </span>
        </div>
        <div className="text-[10px] px-2 py-0.5 bg-[#172033] text-[#38bdf8] border border-[#23314d] rounded">
          Active Team: 6 Agents
        </div>
      </div>

      {/* Goal Dispatcher */}
      <div className="bg-[#0e121b] border-b border-[#182030] p-4 shrink-0">
        <form onSubmit={handleOrchestrate} className="flex gap-2">
          <input
            type="text"
            value={customGoal}
            onChange={(e) => setCustomGoal(e.target.value)}
            disabled={isOrchestrating}
            placeholder="Describe high-level software engineering goal to orchestrate (e.g. 'build a production media server')..."
            className="flex-1 bg-[#131926] border border-[#222c40] rounded px-3 py-1.5 text-xs text-[#f1f5f9] placeholder-[#475569] outline-none"
          />
          <button
            type="submit"
            disabled={!customGoal.trim() || isOrchestrating}
            className="px-4 py-1.5 bg-[#ec4899] hover:bg-[#db2777] disabled:opacity-40 text-white rounded font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isOrchestrating ? 'Orchestrating...' : 'Delegate Team'}</span>
          </button>
        </form>
      </div>

      {/* Agents Task Board */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {defaultTasks.map((task) => {
            const badge = AGENT_BADGES[task.role] || AGENT_BADGES.Architect;
            return (
              <div
                key={task.id}
                className="bg-[#0f1422] border border-[#1d273a] rounded-lg p-3.5 space-y-2.5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase border ${badge.bg} ${badge.color} ${badge.border}`}
                    >
                      {task.role}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] text-[#10b981] font-semibold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{task.status}</span>
                    </span>
                  </div>
                  <div className="text-xs font-bold text-[#f1f5f9] mt-2">
                    {task.title}
                  </div>
                  <p className="text-[11px] text-[#94a3b8] mt-1 leading-relaxed">
                    {task.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-[#182132] space-y-1.5">
                  <div className="text-[10px] text-[#64748b] uppercase font-bold">Output:</div>
                  <div className="text-[11px] text-[#cbd5e1] bg-[#141b2c] p-2 rounded border border-[#1f2a42]">
                    {task.output}
                  </div>
                  {task.artifacts && task.artifacts.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-1">
                      {task.artifacts.map((art) => (
                        <span
                          key={art}
                          className="text-[10px] font-mono px-1.5 py-0.5 bg-[#1c2436] text-[#38bdf8] rounded"
                        >
                          {art}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
