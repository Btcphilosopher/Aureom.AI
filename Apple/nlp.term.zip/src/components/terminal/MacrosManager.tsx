import React, { useState } from 'react';
import { NLPMacro } from '../../types/nlp';
import {
  Zap,
  Play,
  Plus,
  Trash2,
  FileCode,
  CheckCircle2,
  Sliders,
  Terminal,
} from 'lucide-react';

interface MacrosManagerProps {
  macros: NLPMacro[];
  onRunMacro: (macro: NLPMacro) => void;
  onAddMacro: (name: string, description: string, pipeline: string[]) => void;
}

export const MacrosManager: React.FC<MacrosManagerProps> = ({
  macros,
  onRunMacro,
  onAddMacro,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [macroName, setMacroName] = useState('');
  const [macroDesc, setMacroDesc] = useState('');
  const [macroSteps, setMacroSteps] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!macroName.trim() || !macroSteps.trim()) return;

    const steps = macroSteps
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    onAddMacro(macroName.trim(), macroDesc.trim() || 'Custom user macro', steps);
    setMacroName('');
    setMacroDesc('');
    setMacroSteps('');
    setShowAddForm(false);
  };

  return (
    <div className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-xs overflow-hidden">
      {/* Top bar */}
      <div className="bg-[#10141f] border-b border-[#1c2333] px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#eab308]" />
          <span className="font-bold text-[#f1f5f9] text-xs">
            Natural Language Macros (.nlpterm/commands/)
          </span>
          <span className="text-[10px] text-[#64748b]">
            (Repeatable Composite Workflows)
          </span>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-1.5 px-3 py-1 bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded font-bold text-xs transition cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{showAddForm ? 'Cancel' : 'Define New Macro'}</span>
        </button>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-w-4xl mx-auto">
        {/* Create form */}
        {showAddForm && (
          <form
            onSubmit={handleCreate}
            className="bg-[#0f1422] border border-[#23314d] rounded-lg p-4 space-y-3"
          >
            <div className="text-xs font-bold text-[#38bdf8] uppercase">
              Define Natural Language Macro
            </div>
            <div>
              <label className="text-[11px] text-[#64748b]">Macro Trigger Phrase</label>
              <input
                type="text"
                value={macroName}
                onChange={(e) => setMacroName(e.target.value)}
                placeholder="e.g. ship it, audit memory, prepare release"
                className="w-full bg-[#141b2c] border border-[#222e47] rounded px-3 py-1.5 text-xs text-[#f1f5f9] outline-none mt-1"
                required
              />
            </div>
            <div>
              <label className="text-[11px] text-[#64748b]">Description</label>
              <input
                type="text"
                value={macroDesc}
                onChange={(e) => setMacroDesc(e.target.value)}
                placeholder="What this workflow accomplishes"
                className="w-full bg-[#141b2c] border border-[#222e47] rounded px-3 py-1.5 text-xs text-[#f1f5f9] outline-none mt-1"
              />
            </div>
            <div>
              <label className="text-[11px] text-[#64748b]">
                Pipeline Steps (one English instruction per line)
              </label>
              <textarea
                value={macroSteps}
                onChange={(e) => setMacroSteps(e.target.value)}
                placeholder="1. run cargo test&#10;2. bump patch version&#10;3. generate changelog from recent commits&#10;4. build release binary"
                rows={4}
                className="w-full bg-[#141b2c] border border-[#222e47] rounded p-2.5 text-xs text-[#f1f5f9] outline-none mt-1 font-mono"
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3 py-1 text-xs text-[#94a3b8] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#2563eb] hover:bg-[#1d4ed8] text-white font-bold rounded text-xs transition"
              >
                Save Macro (.toml)
              </button>
            </div>
          </form>
        )}

        {/* Existing Macros Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {macros.map((macro) => (
            <div
              key={macro.name}
              className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-[#eab308] flex items-center gap-1.5">
                    <Zap className="w-4 h-4 fill-current" />
                    <span>&quot;{macro.name}&quot;</span>
                  </span>
                  <span className="text-[10px] font-mono text-[#64748b]">
                    {macro.filename}
                  </span>
                </div>
                <p className="text-[11px] text-[#94a3b8] mt-1">{macro.description}</p>

                <div className="mt-3 space-y-1.5 bg-[#121826] p-2.5 rounded border border-[#1b2336]">
                  <div className="text-[10px] uppercase text-[#64748b] font-bold">
                    Pipeline Steps ({macro.pipeline.length})
                  </div>
                  {macro.pipeline.map((step, i) => (
                    <div
                      key={i}
                      className="text-[11px] text-[#cbd5e1] flex items-center gap-2"
                    >
                      <span className="text-[#38bdf8] font-bold">{i + 1}.</span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t border-[#182132] flex justify-between items-center">
                <span className="text-[10px] text-[#64748b]">
                  Trigger by typing: <code className="text-[#38bdf8]">{macro.name}</code>
                </span>
                <button
                  onClick={() => onRunMacro(macro)}
                  className="flex items-center gap-1.5 px-3 py-1 bg-[#eab308] hover:bg-[#ca8a04] text-[#0c0e14] rounded font-bold text-xs transition cursor-pointer"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>Execute</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
