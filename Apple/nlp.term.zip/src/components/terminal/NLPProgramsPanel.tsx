import React, { useState } from 'react';
import { NLPProgram } from '../../types/nlp';
import {
  FileCode,
  Play,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Layers,
  Shield,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface NLPProgramsPanelProps {
  programs: NLPProgram[];
  onRunProgram: (prog: NLPProgram) => void;
  isRunningProgram: boolean;
}

export const NLPProgramsPanel: React.FC<NLPProgramsPanelProps> = ({
  programs,
  onRunProgram,
  isRunningProgram,
}) => {
  const [selectedProgramId, setSelectedProgramId] = useState<string>(
    programs[0]?.id || 'nlp-prog-1'
  );

  const activeProgram =
    programs.find((p) => p.id === selectedProgramId) || programs[0];

  return (
    <div className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-xs overflow-hidden">
      {/* Top Bar */}
      <div className="bg-[#10141f] border-b border-[#1c2333] px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <FileCode className="w-4 h-4 text-[#06b6d4]" />
          <span className="font-bold text-[#f1f5f9] text-xs">
            Stored Natural Language Programs (.nlp)
          </span>
          <span className="text-[10px] text-[#64748b]">
            (Declarative Workflows Stored in .nlpterm/programs/)
          </span>
        </div>
        {activeProgram && (
          <button
            onClick={() => onRunProgram(activeProgram)}
            disabled={isRunningProgram}
            className="flex items-center gap-1.5 px-3 py-1 bg-[#06b6d4] hover:bg-[#0891b2] disabled:opacity-50 text-[#0c0e14] rounded font-bold text-xs transition cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isRunningProgram ? 'Compiling & Executing...' : 'Execute .nlp Program'}</span>
          </button>
        )}
      </div>

      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Program List */}
        <div className="w-72 bg-[#0a0d13] border-r border-[#181f2c] p-2 space-y-1 overflow-y-auto shrink-0">
          <div className="text-[10px] uppercase text-[#64748b] font-bold px-2 py-1">
            Available .nlp Files
          </div>
          {programs.map((prog) => (
            <button
              key={prog.id}
              onClick={() => setSelectedProgramId(prog.id)}
              className={`w-full text-left p-2.5 rounded transition space-y-1 ${
                selectedProgramId === prog.id
                  ? 'bg-[#152233] border border-[#233a59] text-[#38bdf8]'
                  : 'text-[#94a3b8] hover:bg-[#121620] hover:text-[#cbd5e1]'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-xs">
                <FileCode className="w-3.5 h-3.5 text-[#06b6d4] shrink-0" />
                <span>{prog.filename}</span>
              </div>
              <div className="text-[10px] text-[#64748b] line-clamp-1">{prog.title}</div>
            </button>
          ))}
        </div>

        {/* Right Program Inspector & Execution Graph */}
        {activeProgram && (
          <div className="flex-1 flex flex-col overflow-y-auto p-4 space-y-4 bg-[#080a0f]">
            {/* Title card */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-[#f8fafc]">{activeProgram.title}</span>
                <span className="text-[10px] font-mono px-2 py-0.5 bg-[#162033] text-[#38bdf8] border border-[#23324d] rounded">
                  .nlpterm/programs/{activeProgram.filename}
                </span>
              </div>
              <p className="text-xs text-[#94a3b8]">{activeProgram.description}</p>
            </div>

            {/* Stored .nlp Program Source */}
            <div className="bg-[#0c101a] border border-[#1b2438] rounded-lg overflow-hidden">
              <div className="bg-[#121826] border-b border-[#1b2438] px-3 py-1.5 text-[11px] font-bold text-[#06b6d4] flex items-center justify-between">
                <span>Declarative Source Text</span>
                <span className="text-[10px] text-[#64748b]">Plaintext NL Syntax</span>
              </div>
              <pre className="p-4 font-mono text-xs leading-relaxed text-[#a5f3fc] overflow-x-auto whitespace-pre">
                {activeProgram.content}
              </pre>
            </div>

            {/* Compiled Execution Graph Preview */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-[#1b2334] pb-2">
                <div className="text-xs font-bold text-[#38bdf8] uppercase flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5" />
                  <span>Compiled Deterministic Graph ({activeProgram.steps.length} Nodes)</span>
                </div>
                <span className="text-[10px] text-[#10b981] flex items-center gap-1">
                  <Shield className="w-3 h-3" />
                  <span>Deterministic Replay Enabled</span>
                </span>
              </div>

              <div className="space-y-2">
                {activeProgram.steps.map((step, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 bg-[#121826] border border-[#1c2438] rounded flex items-start gap-3 text-xs"
                  >
                    <span className="w-5 h-5 rounded-full bg-[#1c273c] text-[#38bdf8] font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <div>
                      <div className="font-semibold text-[#f1f5f9]">{step}</div>
                      <div className="text-[10px] text-[#64748b] mt-0.5 font-mono">
                        verification: assert status == 0 &amp;&amp; sandbox_boundary_intact
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Failure Policy */}
              <div className="p-2.5 bg-[#26151a] border border-[#48202a] rounded text-[11px] text-[#fca5a5] flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-[#f87171] shrink-0" />
                <div>
                  <span className="font-bold text-[#f87171]">ON FAILURE POLICY: </span>
                  <span>Abort execution, preserve forensic log, trigger automatic rollback.</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
