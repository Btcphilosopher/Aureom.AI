import React, { useState } from 'react';
import { ProjectWorkspace } from '../../data/defaultProjects';
import { FileItem } from '../../types/nlp';
import {
  FolderTree,
  FileCode,
  Search,
  Code2,
  Package,
  Layers,
  FileText,
  Terminal,
  Hash,
  Copy,
  Plus,
  Trash2,
} from 'lucide-react';

interface ProjectExplorerProps {
  project: ProjectWorkspace;
  onFileUpdate?: (path: string, content: string) => void;
  onSearchQuery?: (query: string) => void;
}

export const ProjectExplorer: React.FC<ProjectExplorerProps> = ({
  project,
  onFileUpdate,
}) => {
  const [selectedFile, setSelectedFile] = useState<string>('src/main.rs');
  const [symbolSearch, setSymbolSearch] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<'files' | 'ast' | 'context'>('files');

  const files = Object.values(project.files) as FileItem[];
  const currentFile = project.files[selectedFile] || files[0];

  const filteredSymbols = (project.context.symbols || []).filter((s) =>
    s.name.toLowerCase().includes(symbolSearch.toLowerCase()) ||
    s.file.toLowerCase().includes(symbolSearch.toLowerCase()) ||
    (s.doc && s.doc.toLowerCase().includes(symbolSearch.toLowerCase()))
  );

  return (
    <div className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-xs overflow-hidden">
      {/* Top Header */}
      <div className="bg-[#10141f] border-b border-[#1c2333] px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <FolderTree className="w-4 h-4 text-[#10b981]" />
          <span className="font-bold text-[#f1f5f9] text-xs">Project Explorer &amp; AST Index</span>
          <span className="text-[10px] text-[#64748b]">({files.length} files indexed)</span>
        </div>

        {/* Sub-tabs */}
        <div className="flex items-center bg-[#141926] border border-[#20293d] rounded p-0.5 text-[11px]">
          <button
            onClick={() => setActiveSubTab('files')}
            className={`px-2.5 py-1 rounded transition ${
              activeSubTab === 'files' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            File Tree
          </button>
          <button
            onClick={() => setActiveSubTab('ast')}
            className={`px-2.5 py-1 rounded transition ${
              activeSubTab === 'ast' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            AST Symbol Index ({project.context.symbols.length})
          </button>
          <button
            onClick={() => setActiveSubTab('context')}
            className={`px-2.5 py-1 rounded transition ${
              activeSubTab === 'context' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'
            }`}
          >
            Context Graph &amp; GEMINI.md
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <div className="w-64 bg-[#0a0d13] border-r border-[#181f2c] flex flex-col overflow-hidden shrink-0">
          {activeSubTab === 'files' && (
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
              <div className="text-[10px] uppercase text-[#64748b] font-bold px-2 py-1">
                Workspace Files
              </div>
              {files.map((file) => (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file.path)}
                  className={`w-full text-left px-2.5 py-1.5 rounded flex items-center justify-between text-xs transition ${
                    selectedFile === file.path
                      ? 'bg-[#1e2638] text-[#38bdf8] font-semibold border border-[#29354d]'
                      : 'text-[#94a3b8] hover:bg-[#121620] hover:text-[#cbd5e1]'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <FileCode className="w-3.5 h-3.5 text-[#38bdf8] shrink-0" />
                    <span className="truncate">{file.path}</span>
                  </div>
                  <span className="text-[10px] text-[#475569] shrink-0">
                    {Math.round(file.sizeBytes / 10) / 100}k
                  </span>
                </button>
              ))}
            </div>
          )}

          {activeSubTab === 'ast' && (
            <div className="flex-1 flex flex-col overflow-hidden p-2">
              <div className="mb-2 relative">
                <Search className="w-3.5 h-3.5 text-[#64748b] absolute left-2 top-2" />
                <input
                  type="text"
                  value={symbolSearch}
                  onChange={(e) => setSymbolSearch(e.target.value)}
                  placeholder="Search symbols, functions..."
                  className="w-full bg-[#121722] border border-[#202738] rounded pl-7 pr-2 py-1 text-[11px] text-[#e2e8f0] outline-none"
                />
              </div>
              <div className="flex-1 overflow-y-auto space-y-1">
                {filteredSymbols.map((sym, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedFile(sym.file)}
                    className="w-full text-left p-2 rounded bg-[#10141f] hover:bg-[#192132] border border-[#1b2334] transition text-xs space-y-0.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#38bdf8] truncate">{sym.name}</span>
                      <span className="text-[9px] uppercase px-1 bg-[#2563eb]/20 text-[#60a5fa] rounded">
                        {sym.kind}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#64748b] truncate">{sym.file}:{sym.line}</div>
                    {sym.doc && <div className="text-[10px] text-[#94a3b8] italic truncate">{sym.doc}</div>}
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeSubTab === 'context' && (
            <div className="flex-1 overflow-y-auto p-3 space-y-3 text-xs">
              <div>
                <div className="text-[10px] uppercase text-[#64748b] font-bold">Languages</div>
                <div className="text-[#38bdf8] font-semibold">{project.context.languages.join(', ')}</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-[#64748b] font-bold">Frameworks</div>
                <div className="text-[#a855f7]">{project.context.frameworks.join(', ')}</div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-[#64748b] font-bold">Build &amp; Test</div>
                <div className="text-[#cbd5e1] font-mono text-[11px]">
                  <div>Build: {project.context.buildSystem}</div>
                  <div>Test: {project.context.testFramework}</div>
                </div>
              </div>
              <div>
                <div className="text-[10px] uppercase text-[#64748b] font-bold">Dependencies</div>
                <div className="space-y-1 mt-1">
                  {project.context.dependencies.map((d) => (
                    <div key={d.name} className="flex justify-between text-[11px] text-[#94a3b8]">
                      <span>{d.name}</span>
                      <span className="font-mono text-[#64748b]">v{d.version}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Editor / File View */}
        <div className="flex-1 flex flex-col overflow-hidden bg-[#080a0f]">
          <div className="bg-[#10141f] border-b border-[#1a2130] px-4 py-2 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <FileCode className="w-4 h-4 text-[#38bdf8]" />
              <span className="font-bold text-[#f1f5f9]">{currentFile?.path}</span>
              <span className="text-[10px] text-[#64748b] font-mono">hash: {currentFile?.hash}</span>
            </div>
            <div className="text-[10px] text-[#64748b]">
              Updated: {currentFile?.updatedAt}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 font-mono text-xs leading-relaxed text-[#e2e8f0]">
            <pre className="whitespace-pre overflow-x-auto">
              {(currentFile?.content || '').split('\n').map((line, idx) => (
                <div key={idx} className="flex items-start hover:bg-[#121622] px-1 rounded">
                  <span className="text-[#475569] select-none text-[10px] w-8 text-right shrink-0 pr-3">
                    {idx + 1}
                  </span>
                  <span>{line}</span>
                </div>
              ))}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
