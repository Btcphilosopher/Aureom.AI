import React, { useState } from 'react';
import { ExecutionPlan } from '../../types/nlp';
import {
  Sliders,
  Check,
  X,
  FileCode,
  RotateCcw,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';

interface DiffViewerProps {
  plan: ExecutionPlan | null;
  onApprovePlan: (planId: string) => void;
  onRejectPlan: (planId: string) => void;
  onRollback: (snapshotId?: string) => void;
}

export const DiffViewer: React.FC<DiffViewerProps> = ({
  plan,
  onApprovePlan,
  onRejectPlan,
  onRollback,
}) => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);

  // Extract operations with diffs
  const diffOps = (plan?.operations || []).filter((op) => op.diff);

  if (diffOps.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#0c0e14] text-[#64748b] font-mono text-xs">
        <Sliders className="w-12 h-12 text-[#1e2738] mb-3" />
        <div className="text-sm font-semibold text-[#94a3b8]">No Active Code Diffs</div>
        <p className="max-w-md mt-1 text-[11px] leading-relaxed">
          Diffs are generated when a plan proposes modifying existing source files (e.g. &quot;find why the tests are failing and fix them&quot; or &quot;make the application 30% faster&quot;).
        </p>
      </div>
    );
  }

  const activeOp = diffOps[selectedFileIndex] || diffOps[0];
  const diff = activeOp?.diff;

  const beforeLines = (diff?.before || '').split('\n');
  const afterLines = (diff?.after || '').split('\n');

  return (
    <div className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-xs overflow-hidden">
      {/* Header bar */}
      <div className="bg-[#10141f] border-b border-[#1c2333] px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#a855f7]" />
            <span className="font-bold text-[#f1f5f9] text-xs">Proposed Code Diff</span>
          </div>

          <div className="flex items-center gap-2 text-[11px]">
            <span className="text-[#64748b]">{diffOps.length} file{diffOps.length > 1 ? 's' : ''} modified:</span>
            <div className="flex gap-1">
              {diffOps.map((op, idx) => (
                <button
                  key={op.id}
                  onClick={() => setSelectedFileIndex(idx)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono transition ${
                    selectedFileIndex === idx
                      ? 'bg-[#2563eb] text-white font-semibold'
                      : 'bg-[#151a26] text-[#94a3b8] hover:text-white'
                  }`}
                >
                  {op.diff?.file || op.path}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Action buttons */}
        {plan?.state === 'awaiting_confirmation' && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => onRejectPlan(plan.id)}
              className="flex items-center gap-1 px-3 py-1 bg-[#231518] hover:bg-[#341b21] text-[#f87171] border border-[#4d232c] rounded text-xs transition"
            >
              <X className="w-3 h-3" />
              <span>Reject</span>
            </button>
            <button
              onClick={() => onApprovePlan(plan.id)}
              className="flex items-center gap-1 px-3.5 py-1 bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded font-bold text-xs transition shadow"
            >
              <Check className="w-3 h-3" />
              <span>Apply Patch</span>
            </button>
          </div>
        )}
      </div>

      {/* Diff Meta Summary */}
      <div className="bg-[#0b0e14] border-b border-[#181e2b] px-4 py-2 flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-3">
          <span className="text-[#38bdf8] font-bold">{diff?.file}</span>
          <span className="text-[#34d399]">+{diff?.additions || afterLines.length} lines</span>
          <span className="text-[#f87171]">-{diff?.deletions || beforeLines.length} lines</span>
        </div>
        <div className="text-[#64748b] flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-[#10b981]" />
          <span>Pre-execution snapshot will be saved to .nlpterm/history/</span>
        </div>
      </div>

      {/* Side-by-side or unified code diff display */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 overflow-hidden bg-[#080a0f]">
        {/* Before Column */}
        <div className="flex flex-col border-r border-[#1a2130] overflow-hidden">
          <div className="bg-[#10141f] border-b border-[#1a2130] px-3 py-1.5 text-[11px] font-bold text-[#f87171] flex items-center justify-between">
            <span>BEFORE (Original)</span>
            <span className="text-[10px] text-[#64748b]">Snapshot Baseline</span>
          </div>
          <div className="flex-1 overflow-y-auto p-3 font-mono text-xs leading-relaxed text-[#fca5a5]/90 space-y-0.5">
            {beforeLines.map((line, idx) => (
              <div key={idx} className="flex items-start gap-3 bg-[#450a0a]/30 px-2 py-0.5 rounded">
                <span className="text-[#64748b] select-none text-[10px] w-6 text-right shrink-0">
                  {idx + 1}
                </span>
                <span className="text-[#ef4444] select-none">-</span>
                <span className="whitespace-pre overflow-x-auto">{line}</span>
              </div>
            ))}
          </div>
        </div>

        {/* After Column */}
        <div className="flex flex-col overflow-hidden">
          <div className="bg-[#10141f] border-b border-[#1a2130] px-3 py-1.5 text-[11px] font-bold text-[#34d399] flex items-center justify-between">
            <span>AFTER (Proposed Patch)</span>
            <span className="text-[10px] text-[#10b981]">Verified Fix</span>
          </div>
          <div className="flex-1 overflow-y-auto p-3 font-mono text-xs leading-relaxed text-[#86efac]/90 space-y-0.5">
            {afterLines.map((line, idx) => (
              <div key={idx} className="flex items-start gap-3 bg-[#064e3b]/30 px-2 py-0.5 rounded">
                <span className="text-[#64748b] select-none text-[10px] w-6 text-right shrink-0">
                  {idx + 1}
                </span>
                <span className="text-[#10b981] select-none">+</span>
                <span className="whitespace-pre overflow-x-auto">{line}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
