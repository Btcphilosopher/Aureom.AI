import React, { useState } from 'react';
import { ExecutionPlan, Operation, RiskLevel } from '../../types/nlp';
import {
  Layers,
  ArrowDown,
  Shield,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Cpu,
  HardDrive,
  FileCode,
  Terminal,
  Activity,
  Sliders,
  Check,
  X,
  RotateCcw,
  Copy,
} from 'lucide-react';

interface ExecutionPipelineViewProps {
  plan: ExecutionPlan | null;
  onApprovePlan: (planId: string) => void;
  onRejectPlan: (planId: string) => void;
  onViewDiff: () => void;
  onRollback: (snapshotId?: string) => void;
}

export const ExecutionPipelineView: React.FC<ExecutionPipelineViewProps> = ({
  plan,
  onApprovePlan,
  onRejectPlan,
  onViewDiff,
  onRollback,
}) => {
  const [viewMode, setViewMode] = useState<'visual' | 'ir_json'>('visual');
  const [copied, setCopied] = useState(false);

  const copyJson = () => {
    if (!plan) return;
    navigator.clipboard.writeText(JSON.stringify(plan, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!plan) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-[#0c0e14] text-[#64748b] font-mono text-xs">
        <Layers className="w-12 h-12 text-[#1e2738] mb-3" />
        <div className="text-sm font-semibold text-[#94a3b8]">No Active Plan in Memory</div>
        <p className="max-w-md mt-1 text-[11px] leading-relaxed">
          Type any natural language command in the console (e.g. &quot;create a Rust HTTP server&quot; or &quot;make the application 30% faster&quot;) to compile a typed Execution Plan.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-[#0c0e14] text-[#d4d4d8] font-mono text-xs overflow-hidden">
      {/* Header bar */}
      <div className="bg-[#10141f] border-b border-[#1c2333] px-4 py-2.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#38bdf8]" />
          <span className="font-bold text-[#f1f5f9] text-xs">Execution Plan &amp; Typed IR</span>
          <span className="text-[10px] px-2 py-0.5 bg-[#172033] text-[#38bdf8] border border-[#23314d] rounded">
            ID: {plan.id}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[#141926] border border-[#20293d] rounded p-0.5 text-[11px]">
            <button
              onClick={() => setViewMode('visual')}
              className={`px-2.5 py-1 rounded transition ${
                viewMode === 'visual' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'
              }`}
            >
              Visual Pipeline
            </button>
            <button
              onClick={() => setViewMode('ir_json')}
              className={`px-2.5 py-1 rounded transition ${
                viewMode === 'ir_json' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-white'
              }`}
            >
              Raw IR (JSON)
            </button>
          </div>

          {viewMode === 'ir_json' && (
            <button
              onClick={copyJson}
              className="flex items-center gap-1 px-2.5 py-1 bg-[#171e2e] hover:bg-[#20293d] text-[#cbd5e1] border border-[#2b374f] rounded text-[11px] transition"
            >
              <Copy className="w-3 h-3" />
              <span>{copied ? 'Copied!' : 'Copy IR'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {viewMode === 'ir_json' ? (
          <pre className="bg-[#080a0f] border border-[#1a2130] rounded-lg p-4 text-[#a5b4fc] text-xs whitespace-pre font-mono overflow-x-auto">
            {JSON.stringify(plan, null, 2)}
          </pre>
        ) : (
          <div className="space-y-4 max-w-4xl mx-auto">
            {/* Top Telemetry & Status Card */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div className="bg-[#10141f] border border-[#1e2638] rounded p-2.5">
                <div className="text-[10px] text-[#64748b] uppercase">State</div>
                <div className="text-xs font-bold text-[#38bdf8] uppercase mt-0.5">
                  {plan.state.replace(/_/g, ' ')}
                </div>
              </div>
              <div className="bg-[#10141f] border border-[#1e2638] rounded p-2.5">
                <div className="text-[10px] text-[#64748b] uppercase">Risk Level</div>
                <div
                  className={`text-xs font-bold uppercase mt-0.5 ${
                    plan.intent.risk === 'SAFE'
                      ? 'text-[#10b981]'
                      : plan.intent.risk === 'LOW'
                      ? 'text-[#60a5fa]'
                      : plan.intent.risk === 'MEDIUM'
                      ? 'text-[#f59e0b]'
                      : 'text-[#ef4444]'
                  }`}
                >
                  {plan.intent.risk}
                </div>
              </div>
              <div className="bg-[#10141f] border border-[#1e2638] rounded p-2.5">
                <div className="text-[10px] text-[#64748b] uppercase">Compiler Latency</div>
                <div className="text-xs font-bold text-[#cbd5e1] mt-0.5 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-[#38bdf8]" />
                  <span>{plan.telemetry?.durationMs || 180} ms</span>
                </div>
              </div>
              <div className="bg-[#10141f] border border-[#1e2638] rounded p-2.5">
                <div className="text-[10px] text-[#64748b] uppercase">Token Usage</div>
                <div className="text-xs font-bold text-[#f59e0b] mt-0.5 flex items-center gap-1">
                  <Cpu className="w-3 h-3 text-[#f59e0b]" />
                  <span>{plan.telemetry?.tokenCount || 340} tokens</span>
                </div>
              </div>
            </div>

            {/* STAGE 1: INTENT */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4 relative">
              <div className="flex items-center justify-between border-b border-[#1b2334] pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#2563eb] text-white font-bold flex items-center justify-center text-[10px]">
                    1
                  </span>
                  <span className="font-bold text-[#38bdf8] text-xs uppercase tracking-wider">
                    INTENT STAGE
                  </span>
                </div>
                <span className="text-[10px] text-[#94a3b8] font-mono">
                  key: {plan.intent.intentKey}
                </span>
              </div>
              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-[#64748b]">Raw Human Prompt: </span>
                  <span className="text-[#f8fafc] font-semibold">&quot;{plan.intent.rawPrompt}&quot;</span>
                </div>
                <div>
                  <span className="text-[#64748b]">Action Verb: </span>
                  <span className="text-[#38bdf8] uppercase font-bold">{plan.intent.actionVerb}</span>
                </div>
                <div>
                  <span className="text-[#64748b]">Target Entities: </span>
                  <span className="text-[#cbd5e1]">{plan.intent.targetEntities.join(', ')}</span>
                </div>
                <div>
                  <span className="text-[#64748b]">Extracted Requirements: </span>
                  <ul className="list-disc list-inside text-[#94a3b8] pl-1 space-y-0.5 mt-0.5">
                    {plan.intent.requirements.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Down Connector */}
            <div className="flex justify-center -my-2 text-[#38bdf8]">
              <ArrowDown className="w-4 h-4 animate-bounce" />
            </div>

            {/* STAGE 2: EXECUTION PLAN */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4">
              <div className="flex items-center justify-between border-b border-[#1b2334] pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#38bdf8] text-[#0c0e14] font-bold flex items-center justify-center text-[10px]">
                    2
                  </span>
                  <span className="font-bold text-[#38bdf8] text-xs uppercase tracking-wider">
                    TYPED EXECUTION PLAN
                  </span>
                </div>
                <span className="text-[10px] text-[#94a3b8] font-mono">
                  {plan.steps.length} sequential steps
                </span>
              </div>
              <p className="text-xs text-[#cbd5e1] mb-3">{plan.summary}</p>
              <div className="space-y-2">
                {plan.steps.map((step) => (
                  <div
                    key={step.id}
                    className="flex items-start gap-2.5 p-2 bg-[#121826] border border-[#1c2438] rounded"
                  >
                    <span className="text-[#38bdf8] font-bold">{step.id}.</span>
                    <div className="flex-1">
                      <div className="text-xs font-semibold text-[#f1f5f9]">{step.title}</div>
                      <div className="text-[11px] text-[#94a3b8]">{step.description}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Down Connector */}
            <div className="flex justify-center -my-2 text-[#38bdf8]">
              <ArrowDown className="w-4 h-4 animate-bounce" />
            </div>

            {/* STAGE 3: TOOLS & OPERATIONS */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4">
              <div className="flex items-center justify-between border-b border-[#1b2334] pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#10b981] text-[#0c0e14] font-bold flex items-center justify-center text-[10px]">
                    3
                  </span>
                  <span className="font-bold text-[#10b981] text-xs uppercase tracking-wider">
                    TOOLS &amp; OPERATIONS
                  </span>
                </div>
                <span className="text-[10px] text-[#94a3b8] font-mono">
                  {plan.operations.length} deterministic tool calls
                </span>
              </div>
              <div className="space-y-2">
                {plan.operations.map((op) => (
                  <div
                    key={op.id}
                    className="bg-[#121826] border border-[#1c2438] rounded p-3 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#38bdf8] text-xs font-mono">
                        {op.type}
                      </span>
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                          op.explanation.risk === 'SAFE'
                            ? 'bg-[#10b981]/20 text-[#10b981]'
                            : op.explanation.risk === 'LOW'
                            ? 'bg-[#3b82f6]/20 text-[#60a5fa]'
                            : 'bg-[#f59e0b]/20 text-[#f59e0b]'
                        }`}
                      >
                        {op.explanation.risk}
                      </span>
                    </div>
                    {op.path && (
                      <div className="text-[11px] text-[#cbd5e1]">
                        <span className="text-[#64748b]">Path: </span>
                        <code>{op.path}</code>
                      </div>
                    )}
                    {op.command && (
                      <div className="text-[11px] text-[#cbd5e1]">
                        <span className="text-[#64748b]">Command: </span>
                        <code className="text-[#a5b4fc] bg-[#1a2133] px-1.5 py-0.5 rounded">
                          {op.command}
                        </code>
                      </div>
                    )}
                    <div className="text-[11px] text-[#94a3b8] pt-1 border-t border-[#1a2133]">
                      <span className="text-[#64748b]">Why: </span> {op.explanation.why}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Down Connector */}
            <div className="flex justify-center -my-2 text-[#38bdf8]">
              <ArrowDown className="w-4 h-4 animate-bounce" />
            </div>

            {/* STAGE 4: VERIFICATION CLAUSES */}
            <div className="bg-[#0e1320] border border-[#1e273a] rounded-lg p-4">
              <div className="flex items-center justify-between border-b border-[#1b2334] pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-[#f59e0b] text-[#0c0e14] font-bold flex items-center justify-center text-[10px]">
                    4
                  </span>
                  <span className="font-bold text-[#f59e0b] text-xs uppercase tracking-wider">
                    VERIFICATION &amp; SAFETY CLAUSES
                  </span>
                </div>
                <span className="text-[10px] text-[#94a3b8] font-mono">
                  {plan.verifications.length} validation gates
                </span>
              </div>
              <div className="space-y-2">
                {plan.verifications.map((v) => (
                  <div
                    key={v.id}
                    className="p-2.5 bg-[#121826] border border-[#1c2438] rounded flex items-start gap-2 text-xs"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0 mt-0.5" />
                    <div>
                      <div className="font-mono text-[#cbd5e1]">
                        <span className="text-[#64748b]">Command: </span>
                        <code className="text-[#38bdf8]">{v.command}</code>
                      </div>
                      <div className="text-[11px] text-[#94a3b8] mt-0.5">
                        <span className="text-[#64748b]">Expected: </span>
                        {v.expectedOutcome}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions Bar */}
            {plan.state === 'awaiting_confirmation' && (
              <div className="bg-[#111726] border border-[#23314d] rounded-lg p-4 flex items-center justify-between flex-wrap gap-3">
                <div className="text-xs text-[#f59e0b] font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Execution requires human operator authorization</span>
                </div>
                <div className="flex items-center gap-2">
                  {plan.filesToModify.length > 0 && (
                    <button
                      onClick={onViewDiff}
                      className="px-3 py-1.5 bg-[#171e2e] hover:bg-[#20293d] text-[#38bdf8] border border-[#2b374f] rounded text-xs transition"
                    >
                      Inspect Diff
                    </button>
                  )}
                  <button
                    onClick={() => onRejectPlan(plan.id)}
                    className="px-3 py-1.5 bg-[#231518] hover:bg-[#341b21] text-[#f87171] border border-[#4d232c] rounded text-xs transition"
                  >
                    Reject Plan
                  </button>
                  <button
                    onClick={() => onApprovePlan(plan.id)}
                    className="px-4 py-1.5 bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded font-bold text-xs transition shadow"
                  >
                    Authorize &amp; Execute
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
