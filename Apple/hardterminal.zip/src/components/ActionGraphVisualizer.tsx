import React from "react";
import { ActionGraph, ActionNode } from "../types";
import { ArrowRight, CheckCircle2, Clock, AlertTriangle, XCircle, ShieldCheck, Undo2 } from "lucide-react";

interface Props {
  graph: ActionGraph;
  executionStatus?: Record<string, any>;
}

export const ActionGraphVisualizer: React.FC<Props> = ({ graph, executionStatus }) => {
  if (!graph || !graph.nodes || graph.nodes.length === 0) {
    return (
      <div className="text-center py-8 text-neutral-400 text-sm">
        No active execution graph
      </div>
    );
  }

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "CRITICAL":
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-red-900/40 text-red-400 border border-red-700/50">CRITICAL</span>;
      case "HIGH":
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-orange-900/40 text-orange-400 border border-orange-700/50">HIGH</span>;
      case "MEDIUM":
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-yellow-900/40 text-yellow-400 border border-yellow-700/50">MEDIUM</span>;
      case "LOW":
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-blue-900/40 text-blue-400 border border-blue-700/50">LOW</span>;
      default:
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-emerald-900/40 text-emerald-400 border border-emerald-700/50">SAFE (NONE)</span>;
    }
  };

  const getNodeStatus = (node: ActionNode) => {
    if (executionStatus && executionStatus[node.action_id]) {
      const st = executionStatus[node.action_id];
      if (st.success) {
        return (
          <span className="flex items-center gap-1 text-xs text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> Success ({st.duration_ms?.toFixed(1) || 0}ms)
          </span>
        );
      } else {
        return (
          <span className="flex items-center gap-1 text-xs text-red-400">
            <XCircle className="w-3.5 h-3.5" /> Failed: {st.error || "Error"}
          </span>
        );
      }
    }
    return (
      <span className="flex items-center gap-1 text-xs text-neutral-400">
        <Clock className="w-3.5 h-3.5" /> Queued (~{node.estimated_cost_ms}ms)
      </span>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-xs text-neutral-400 pb-2 border-b border-neutral-800">
        <span>Deterministic Action Graph: <strong className="text-neutral-200">{graph.graph_id}</strong></span>
        <span>{graph.nodes.length} Executable Node{graph.nodes.length === 1 ? "" : "s"}</span>
      </div>

      <div className="flex flex-col gap-3">
        {graph.nodes.map((node, index) => {
          const hasDeps = node.dependencies && node.dependencies.length > 0;

          return (
            <div key={node.action_id} className="relative">
              {index > 0 && (
                <div className="flex justify-center my-1 text-neutral-600">
                  <ArrowRight className="w-4 h-4 rotate-90" />
                </div>
              )}

              <div className="bg-neutral-900/90 border border-neutral-800 rounded-lg p-3.5 hover:border-neutral-700 transition-colors shadow-sm">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-amber-400 bg-amber-950/40 border border-amber-800/40 px-2 py-0.5 rounded">
                      {node.verb}
                    </span>
                    <span className="font-mono text-xs text-neutral-300 font-medium">
                      {node.action_id}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {getRiskBadge(node.risk)}
                    {node.reversible && (
                      <span className="flex items-center gap-1 px-1.5 py-0.5 text-[10px] rounded bg-purple-950/40 text-purple-300 border border-purple-800/40" title="Auto snapshot taken">
                        <Undo2 className="w-3 h-3" /> Reversible
                      </span>
                    )}
                  </div>
                </div>

                <div className="mt-2.5 grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-neutral-500">Target: </span>
                    <span className="font-mono text-neutral-200">{node.target || "(context)"}</span>
                  </div>
                  <div className="text-right md:text-right">
                    {getNodeStatus(node)}
                  </div>
                </div>

                {Object.keys(node.parameters || {}).length > 0 && (
                  <div className="mt-2 pt-2 border-t border-neutral-800/70 text-[11px] font-mono text-neutral-400">
                    <span className="text-neutral-500">Parameters: </span>
                    {Object.entries(node.parameters).map(([k, v]) => (
                      <span key={k} className="inline-block bg-neutral-950 px-1.5 py-0.5 rounded mr-1.5 mb-1 text-neutral-300 border border-neutral-800">
                        {k}: <strong className="text-amber-300">{JSON.stringify(v)}</strong>
                      </span>
                    ))}
                  </div>
                )}

                {hasDeps && (
                  <div className="mt-1.5 text-[11px] text-neutral-500 flex items-center gap-1.5">
                    <span>Depends on:</span>
                    {node.dependencies.map(d => (
                      <span key={d} className="font-mono text-neutral-400 bg-neutral-800 px-1.5 py-0.2 rounded text-[10px]">
                        {d}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
