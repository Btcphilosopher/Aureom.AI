import React, { useState } from "react";
import { VerbDefinition } from "../types";
import { Search, ShieldAlert, ShieldCheck, Play, ArrowRight, BookOpen, Layers, Terminal } from "lucide-react";

interface Props {
  verbs: VerbDefinition[];
  onSelectVerb: (sampleCommand: string) => void;
}

const CATEGORY_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  ACQUISITION: { bg: "bg-blue-950/40", text: "text-blue-400", border: "border-blue-800/40" },
  INSPECTION: { bg: "bg-cyan-950/40", text: "text-cyan-400", border: "border-cyan-800/40" },
  MODIFICATION: { bg: "bg-amber-950/40", text: "text-amber-400", border: "border-amber-800/40" },
  FILESYSTEM: { bg: "bg-orange-950/40", text: "text-orange-400", border: "border-orange-800/40" },
  DATA: { bg: "bg-emerald-950/40", text: "text-emerald-400", border: "border-emerald-800/40" },
  VALIDATION: { bg: "bg-teal-950/40", text: "text-teal-400", border: "border-teal-800/40" },
  CONVERSION: { bg: "bg-indigo-950/40", text: "text-indigo-400", border: "border-indigo-800/40" },
  SYSTEM: { bg: "bg-red-950/40", text: "text-red-400", border: "border-red-800/40" },
  AUTOMATION: { bg: "bg-violet-950/40", text: "text-violet-400", border: "border-violet-800/40" },
  OUTPUT: { bg: "bg-pink-950/40", text: "text-pink-400", border: "border-pink-800/40" },
  CONTROL: { bg: "bg-neutral-800/40", text: "text-neutral-300", border: "border-neutral-700/40" },
};

export const VerbRegistryView: React.FC<Props> = ({ verbs, onSelectVerb }) => {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");
  const [selectedVerb, setSelectedVerb] = useState<VerbDefinition | null>(null);

  const categories = ["ALL", ...Array.from(new Set(verbs.map((v) => v.category)))];

  const filteredVerbs = verbs.filter((v) => {
    const matchesCategory = selectedCategory === "ALL" || v.category === selectedCategory;
    const matchesSearch =
      v.name.toLowerCase().includes(search.toLowerCase()) ||
      v.description.toLowerCase().includes(search.toLowerCase()) ||
      v.category.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const generateSampleCommand = (v: VerbDefinition) => {
    switch (v.name) {
      case "FIND":
        return "find all CSV files in .";
      case "GRAB":
        return "grab all error lines in app.log";
      case "INSPECT":
        return "inspect settings.json";
      case "EDIT":
        return "edit quarterly_summary.txt find 'STABLE' replace 'OPTIMIZED'";
      case "SORT":
        return "sort sales_q3.csv by revenue descending";
      case "FILTER":
        return "filter sales_q3.csv revenue > 15000";
      case "CALCULATE":
        return "calculate total revenue on sales_q3.csv";
      case "ANALYSE":
        return "analyse sales_q3.csv";
      case "HASH":
        return "hash benchmark.py";
      case "VALIDATE":
        return "validate settings.json";
      case "DIFF":
        return "diff quarterly_summary.txt with settings.json";
      case "COPY":
        return "copy sales_q3.csv to sales_backup.csv";
      case "PLAN":
        return "plan filter sales_q3.csv revenue > 10000";
      case "PREVIEW":
        return "preview sort sales_q3.csv by revenue";
      case "REPORT":
        return "report format JSON";
      case "COUNT":
        return "count lines in app.log";
      default:
        return `${v.name.toLowerCase()} .`;
    }
  };

  return (
    <div className="space-y-6">
      {/* Search and Category Filter Bar */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-4 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
          <input
            type="text"
            placeholder="Search hardcoded verbs, parameters, descriptions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-neutral-950 border border-neutral-800 rounded-lg pl-9 pr-4 py-2 text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                  : "bg-neutral-950 text-neutral-400 border border-neutral-800 hover:text-neutral-200"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Verbs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filteredVerbs.map((verb) => {
          const catStyle = CATEGORY_COLORS[verb.category] || CATEGORY_COLORS.CONTROL;
          const sampleCmd = generateSampleCommand(verb);

          return (
            <div
              key={verb.name}
              className={`bg-neutral-900 border border-neutral-800 rounded-xl p-4 hover:border-neutral-700 transition-all flex flex-col justify-between ${
                selectedVerb?.name === verb.name ? "ring-1 ring-amber-500 border-amber-500/60" : ""
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-base font-bold text-neutral-100 tracking-wide">
                      {verb.name}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${catStyle.bg} ${catStyle.text} ${catStyle.border}`}
                    >
                      {verb.category}
                    </span>
                  </div>

                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                      verb.risk_level === "CRITICAL"
                        ? "bg-red-950/50 text-red-400 border-red-800/40"
                        : verb.risk_level === "HIGH"
                        ? "bg-orange-950/50 text-orange-400 border-orange-800/40"
                        : verb.risk_level === "MEDIUM"
                        ? "bg-yellow-950/50 text-yellow-400 border-yellow-800/40"
                        : "bg-emerald-950/50 text-emerald-400 border-emerald-800/40"
                    }`}
                  >
                    RISK: {verb.risk_level}
                  </span>
                </div>

                <p className="text-xs text-neutral-400 line-clamp-2 mb-3 leading-relaxed">
                  {verb.description}
                </p>

                {Object.keys(verb.parameters || {}).length > 0 && (
                  <div className="mb-3 space-y-1">
                    <span className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider block">
                      Parameters ({Object.keys(verb.parameters).length})
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(verb.parameters).map(([pName, param]) => {
                        const pVal = param as any;
                        return (
                          <span
                            key={pName}
                            className="font-mono text-[10px] bg-neutral-950 px-1.5 py-0.5 rounded text-neutral-300 border border-neutral-800"
                            title={pVal.description}
                          >
                            {pName}
                            {pVal.required && <strong className="text-amber-400">*</strong>}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-neutral-800/60 flex items-center justify-between gap-2">
                <button
                  onClick={() => setSelectedVerb(selectedVerb?.name === verb.name ? null : verb)}
                  className="text-xs text-neutral-400 hover:text-neutral-200 flex items-center gap-1"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  {selectedVerb?.name === verb.name ? "Hide Spec" : "Inspect Spec"}
                </button>

                <button
                  onClick={() => onSelectVerb(sampleCmd)}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-lg bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/30 transition-colors"
                >
                  <Terminal className="w-3.5 h-3.5" />
                  Try Syntax
                </button>
              </div>

              {selectedVerb?.name === verb.name && (
                <div className="mt-3 pt-3 border-t border-neutral-800 text-xs bg-neutral-950 p-3 rounded-lg space-y-2">
                  <div className="font-semibold text-neutral-200">Parameter Schema:</div>
                  {Object.entries(verb.parameters).map(([pName, param]) => {
                    const pVal = param as any;
                    return (
                      <div key={pName} className="font-mono text-[11px] text-neutral-300">
                        <span className="text-amber-400">{pName}</span> ({pVal.param_type})
                        {pVal.required ? " [REQUIRED]" : ` [default=${JSON.stringify(pVal.default)}]`}:{" "}
                        <span className="text-neutral-400">{pVal.description}</span>
                      </div>
                    );
                  })}
                  <div className="text-[11px] text-neutral-400 pt-1">
                    <strong>Reversible:</strong> {verb.reversible ? "YES (Snapshot backup)" : "NO"} |{" "}
                    <strong>Requires Confirmation:</strong> {verb.requires_confirmation ? "YES" : "NO"}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
