import React, { useState } from "react";
import { WorkspaceFile, TargetHandleItem } from "../types";
import { Folder, FileText, FileSpreadsheet, FileCode, Hash, RefreshCw, Eye, Sparkles } from "lucide-react";

interface Props {
  files: WorkspaceFile[];
  handles: TargetHandleItem[];
  workspacePath: string;
  onRefresh: () => void;
  onReadFile: (path: string) => Promise<string | null>;
  onSeed: () => void;
}

export const WorkspaceExplorer: React.FC<Props> = ({
  files,
  handles,
  workspacePath,
  onRefresh,
  onReadFile,
  onSeed,
}) => {
  const [selectedFile, setSelectedFile] = useState<WorkspaceFile | null>(null);
  const [fileContent, setFileContent] = useState<string>("");
  const [loadingFile, setLoadingFile] = useState(false);

  const handleSelectFile = async (f: WorkspaceFile) => {
    setSelectedFile(f);
    setLoadingFile(true);
    const content = await onReadFile(f.rel_path);
    setFileContent(content || "(Empty or binary content)");
    setLoadingFile(false);
  };

  const getFileIcon = (ext: string) => {
    switch (ext) {
      case "csv":
        return <FileSpreadsheet className="w-4 h-4 text-emerald-400" />;
      case "json":
      case "py":
      case "sh":
        return <FileCode className="w-4 h-4 text-amber-400" />;
      case "log":
      case "txt":
        return <FileText className="w-4 h-4 text-cyan-400" />;
      default:
        return <FileText className="w-4 h-4 text-neutral-400" />;
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Files and Handles Column */}
      <div className="lg:col-span-6 space-y-6">
        {/* Workspace Files Card */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <Folder className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-semibold text-neutral-200">Workspace Sandbox Files</h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={onSeed}
                className="px-2 py-1 text-xs font-medium rounded-lg bg-neutral-800 text-neutral-300 hover:bg-neutral-700 flex items-center gap-1 transition-colors"
                title="Reset sample files"
              >
                <Sparkles className="w-3 h-3 text-amber-400" /> Reset Samples
              </button>
              <button
                onClick={onRefresh}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition-colors"
                title="Refresh"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <p className="text-[11px] font-mono text-neutral-500 mb-3 truncate">
            Path: {workspacePath}
          </p>

          {files.length === 0 ? (
            <div className="text-center py-6 text-xs text-neutral-500">
              No files in sandbox. Click "Reset Samples" to populate sample data.
            </div>
          ) : (
            <div className="divide-y divide-neutral-800/60 font-mono text-xs">
              {files.map((f) => (
                <div
                  key={f.rel_path}
                  onClick={() => handleSelectFile(f)}
                  className={`py-2.5 px-2 flex items-center justify-between rounded-lg cursor-pointer transition-colors ${
                    selectedFile?.rel_path === f.rel_path
                      ? "bg-amber-500/10 text-amber-300 border border-amber-500/30"
                      : "hover:bg-neutral-950/60 text-neutral-300"
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    {getFileIcon(f.ext)}
                    <span className="truncate">{f.name}</span>
                  </div>
                  <div className="flex items-center gap-3 text-neutral-500 text-[11px] shrink-0">
                    <span>{formatSize(f.size_bytes)}</span>
                    <Eye className="w-3.5 h-3.5 hover:text-neutral-300" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Active Target Handles Card */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <Hash className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-neutral-200">Active Object Handles</h3>
            </div>
            <span className="text-xs font-mono text-neutral-400">
              {handles.length} Allocated Handle{handles.length === 1 ? "" : "s"}
            </span>
          </div>

          {handles.length === 0 ? (
            <div className="text-center py-4 text-xs text-neutral-500 leading-relaxed">
              No target handles active. Execute a query (e.g. <code>find all CSV files in .</code>) to create inspectable handles like <code>#001</code>.
            </div>
          ) : (
            <div className="space-y-2 font-mono text-xs">
              {handles.map((h) => (
                <div
                  key={h.handle}
                  className="p-2.5 bg-neutral-950 border border-neutral-800 rounded-lg flex items-center justify-between"
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className="font-bold text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-800/40">
                      {h.handle}
                    </span>
                    <span className="text-neutral-300 truncate">{h.path}</span>
                  </div>
                  <span className="text-[10px] text-neutral-500 uppercase px-1.5 py-0.5 rounded bg-neutral-900">
                    {h.target_type}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* File Content Preview Column */}
      <div className="lg:col-span-6">
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 h-full flex flex-col">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-semibold text-neutral-200">
                {selectedFile ? `Preview: ${selectedFile.name}` : "File Viewer"}
              </h3>
            </div>
            {selectedFile && (
              <span className="text-xs font-mono text-neutral-400">
                {formatSize(selectedFile.size_bytes)}
              </span>
            )}
          </div>

          {loadingFile ? (
            <div className="flex-1 flex items-center justify-center text-xs text-neutral-400">
              Loading file preview...
            </div>
          ) : selectedFile ? (
            <pre className="flex-1 font-mono text-xs text-neutral-300 bg-neutral-950 p-4 rounded-lg overflow-auto border border-neutral-800/80 leading-relaxed whitespace-pre-wrap">
              {fileContent}
            </pre>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-neutral-500 text-xs">
              <FileText className="w-10 h-10 mb-2 stroke-[1.2] text-neutral-600" />
              <p>Select any workspace file on the left to inspect its raw content</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
