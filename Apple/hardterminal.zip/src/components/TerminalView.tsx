import React, { useState } from "react";
import { ExecutionPlan, ExecutionReport, TargetHandleItem } from "../types";
import { ActionGraphVisualizer } from "./ActionGraphVisualizer";
import {
  Terminal as TerminalIcon,
  Play,
  Eye,
  FileText,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  RotateCcw,
  Zap,
} from "lucide-react";

interface Props {
  onExecute: (query: string, dryRun?: boolean) => void;
  onPlan: (query: string) => void;
  onPreview: (query: string) => void;
  loading: boolean;
  activePlan: ExecutionPlan | null;
  activeReport: ExecutionReport | null;
  ambiguityError: { message: string; required_parameters: string[]; hint?: string } | null;
  generalError: { message: string; hint?: string } | null;
  queryInput: string;
  setQueryInput: (q: string) => void;
  onClear: () => void;
}

const PIPELINE_STAGES = [
  "PLAIN LANGUAGE",
  "VERB IDENTIFICATION",
  "TARGET IDENTIFICATION",
  "PARAMETERS",
  "ACTION GRAPH",
  "SAFETY VALIDATION",
  "OPTIMISATION",
  "PREVIEW",
  "EXECUTION",
  "VERIFICATION",
  "AUDIT",
];

const PRESET_QUERIES = [
  { label: "Find all CSVs", query: "find all CSV files in ." },
  { label: "Filter sales > 15000", query: "filter sales_q3.csv revenue > 15000" },
  { label: "Sort sales descending", query: "sort sales_q3.csv by revenue descending" },
  { label: "Edit summary text", query: "edit quarterly_summary.txt find 'STABLE' replace 'OPTIMIZED'" },
  { label: "Calculate total revenue", query: "calculate total revenue on sales_q3.csv" },
  { label: "Inspect settings JSON", query: "inspect settings.json" },
  { label: "Multi-verb Pipeline", query: "find all CSV files in . | filter revenue > 15000 | sort by revenue descending" },
  { label: "Ambiguous: 'clean directory'", query: "clean this directory" },
  { label: "Blocked: '/System'", query: "edit /System/kernel.sys find 'a' replace 'b'" },
];

export const TerminalView: React.FC<Props> = ({
  onExecute,
  onPlan,
  onPreview,
  loading,
  activePlan,
  activeReport,
  ambiguityError,
  generalError,
  queryInput,
  setQueryInput,
  onClear,
}) => {
  const [activeTab, setActiveTab] = useState<"plan" | "output" | "raw_text">("plan");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!queryInput.trim() || loading) return;
    onExecute(queryInput.trim());
  };

  const handlePlanOnly = () => {
    if (!queryInput.trim() || loading) return;
    onPlan(queryInput.trim());
    setActiveTab("plan");
  };

  const handlePreviewOnly = () => {
    if (!queryInput.trim() || loading) return;
    onPreview(queryInput.trim());
    setActiveTab("plan");
  };

  return (
    <div className="space-y-6">
      {/* 11-Stage Pipeline Status Tracker */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-4 overflow-hidden shadow-sm">
        <div className="flex items-center justify-between mb-3 text-xs text-neutral-400">
          <span className="font-semibold uppercase tracking-wider text-[11px] text-neutral-300">
            HardTerminal Kernel Pipeline Flow
          </span>
          <span className="font-mono text-neutral-500 text-[10px]">
            DETERMINISTIC VERB COMPILER
          </span>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none text-[10px] font-mono">
          {PIPELINE_STAGES.map((stage, idx) => {
            const isCompleted = activeReport?.success && idx <= 10;
            const isPlanned = activePlan && idx <= 6;
            const isCurrent = (activePlan && idx === 4) || (activeReport && idx === 9);

            return (
              <div key={stage} className="flex items-center gap-1 shrink-0">
                <div
                  className={`px-2 py-1 rounded-md border flex items-center gap-1 transition-colors ${
                    isCompleted
                      ? "bg-emerald-950/40 text-emerald-300 border-emerald-800/40"
                      : isCurrent
                      ? "bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold"
                      : isPlanned
                      ? "bg-blue-950/40 text-blue-300 border-blue-800/40"
                      : "bg-neutral-950 text-neutral-500 border-neutral-800"
                  }`}
                >
                  <span>{idx + 1}.</span>
                  <span>{stage}</span>
                </div>
                {idx < PIPELINE_STAGES.length - 1 && (
                  <ArrowRight className="w-3 h-3 text-neutral-700 shrink-0" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Command Input Box */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <label htmlFor="terminal-input" className="flex items-center gap-2 font-medium text-neutral-200">
              <TerminalIcon className="w-4 h-4 text-amber-400" />
              Plain-Language Command or Hard Verb Pipeline
            </label>
            <span className="font-mono text-[11px] text-neutral-500">
              macOS Verb Kernel v1.0
            </span>
          </div>

          <div className="relative flex items-center">
            <span className="absolute left-4 font-mono font-bold text-amber-400 text-sm select-none">
              hardterminal&gt;
            </span>
            <input
              id="terminal-input"
              type="text"
              value={queryInput}
              onChange={(e) => setQueryInput(e.target.value)}
              placeholder="e.g. 'find all CSV files in .' or 'sort sales_q3.csv by revenue descending'"
              className="w-full bg-neutral-950 border border-neutral-700/80 rounded-xl pl-36 pr-4 py-3.5 font-mono text-sm text-neutral-100 placeholder-neutral-600 focus:outline-none focus:ring-1 focus:ring-amber-500 focus:border-amber-500 transition-all"
            />
          </div>

          {/* Action Buttons & Presets */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="submit"
                disabled={loading || !queryInput.trim()}
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-amber-500 text-neutral-950 font-semibold text-xs hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                {loading ? "Executing..." : "Execute (PLAN ➔ RUN)"}
              </button>

              <button
                type="button"
                onClick={handlePlanOnly}
                disabled={loading || !queryInput.trim()}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg bg-neutral-800 text-neutral-200 hover:bg-neutral-700 text-xs font-medium disabled:opacity-50 transition-colors"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                Plan Graph
              </button>

              <button
                type="button"
                onClick={handlePreviewOnly}
                disabled={loading || !queryInput.trim()}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg bg-neutral-800 text-neutral-200 hover:bg-neutral-700 text-xs font-medium disabled:opacity-50 transition-colors"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                Dry-Run Preview
              </button>

              {(activePlan || activeReport || ambiguityError || generalError) && (
                <button
                  type="button"
                  onClick={onClear}
                  className="flex items-center gap-1 px-3 py-2 rounded-lg text-neutral-500 hover:text-neutral-300 text-xs transition-colors"
                >
                  <RotateCcw className="w-3 h-3" /> Clear
                </button>
              )}
            </div>

            <span className="text-[11px] text-neutral-500 font-mono">
              Press Enter to Execute
            </span>
          </div>
        </form>

        {/* Quick Presets Bar */}
        <div className="mt-4 pt-3 border-t border-neutral-800/80">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] font-medium text-neutral-400">Quick Test Requests:</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {PRESET_QUERIES.map((p) => (
              <button
                key={p.label}
                onClick={() => setQueryInput(p.query)}
                className="px-2 py-1 text-[11px] font-mono rounded bg-neutral-950 border border-neutral-800 text-neutral-400 hover:text-amber-300 hover:border-neutral-700 transition-colors"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Ambiguity Rejection Notice */}
      {ambiguityError && (
        <div className="bg-amber-950/20 border border-amber-500/40 rounded-xl p-5 space-y-3">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-amber-300">
                Deterministic Ambiguity Rejection
              </h3>
              <p className="text-xs text-neutral-300 mt-1">
                {ambiguityError.message}
              </p>
              <div className="mt-3 bg-neutral-950/80 p-3 rounded-lg border border-amber-900/30">
                <span className="text-xs font-semibold text-neutral-300 block mb-1">
                  Required Parameters:
                </span>
                <ul className="list-disc list-inside text-xs text-neutral-400 space-y-0.5">
                  {ambiguityError.required_parameters.map((p, i) => (
                    <li key={i} className="font-mono text-amber-300/90">{p}</li>
                  ))}
                </ul>
              </div>
              {ambiguityError.hint && (
                <div className="mt-2 text-xs text-neutral-400">
                  <strong>Hint:</strong> <span className="font-mono text-neutral-300">{ambiguityError.hint}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* General Error Notice */}
      {generalError && (
        <div className="bg-red-950/20 border border-red-500/40 rounded-xl p-5 space-y-2">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-red-300">Execution Safety Policy Violation</h3>
              <p className="text-xs text-neutral-300 mt-1">{generalError.message}</p>
              {generalError.hint && (
                <div className="mt-2 text-xs text-neutral-400">
                  <strong>Hint:</strong> <span className="font-mono text-neutral-300">{generalError.hint}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Plan / Execution Output Dashboard */}
      {(activePlan || activeReport) && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden shadow-sm">
          {/* Header Tabs */}
          <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-neutral-800">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setActiveTab("plan")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === "plan"
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                    : "text-neutral-400 hover:text-neutral-200"
                }`}
              >
                <Zap className="w-3.5 h-3.5" /> Action Graph DAG
              </button>

              <button
                onClick={() => setActiveTab("output")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === "output"
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                    : "text-neutral-400 hover:text-neutral-200"
                }`}
              >
                <TerminalIcon className="w-3.5 h-3.5" /> Terminal Execution Report
              </button>

              <button
                onClick={() => setActiveTab("raw_text")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === "raw_text"
                    ? "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                    : "text-neutral-400 hover:text-neutral-200"
                }`}
              >
                <FileText className="w-3.5 h-3.5" /> Formatted Plan Text
              </button>
            </div>

            {activeReport && (
              <div className="flex items-center gap-2">
                {activeReport.success ? (
                  <span className="flex items-center gap-1 text-xs font-semibold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
                    <CheckCircle2 className="w-3.5 h-3.5" /> SUCCESS ({activeReport.duration_ms.toFixed(1)}ms)
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-xs font-semibold text-red-400 bg-red-950/40 px-2 py-0.5 rounded border border-red-800/40">
                    <XCircle className="w-3.5 h-3.5" /> FAILED
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Tab Content */}
          <div className="p-5">
            {activeTab === "plan" && activePlan && (
              <div className="space-y-5">
                {/* Plan Overview Badges */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase tracking-wider block">Primary Verb</span>
                    <span className="font-mono text-sm font-bold text-amber-400">{activePlan.primary_verb}</span>
                  </div>
                  <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase tracking-wider block">Target</span>
                    <span className="font-mono text-sm text-neutral-200 truncate block">{activePlan.target_summary || "(context)"}</span>
                  </div>
                  <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase tracking-wider block">Risk Level</span>
                    <span className="font-mono text-sm font-bold text-neutral-200">{activePlan.risk.level}</span>
                  </div>
                  <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase tracking-wider block">Est. Duration</span>
                    <span className="font-mono text-sm text-neutral-200">{activePlan.estimated_cost_ms.toFixed(1)}ms</span>
                  </div>
                </div>

                {/* Visual Action Graph */}
                <ActionGraphVisualizer
                  graph={activePlan.action_graph}
                  executionStatus={activeReport?.node_results}
                />
              </div>
            )}

            {activeTab === "output" && (
              <div className="space-y-4 font-mono text-xs">
                {activeReport ? (
                  <div className="space-y-4">
                    <div className="bg-neutral-950 p-4 rounded-lg border border-neutral-800 space-y-2">
                      <div className="text-neutral-400">
                        Summary: <span className="text-emerald-400 font-semibold">{activeReport.summary_message}</span>
                      </div>
                      <div className="text-neutral-400">
                        Execution Time: <span className="text-neutral-200">{activeReport.duration_ms.toFixed(2)}ms</span>
                      </div>
                      {activeReport.transaction_id && (
                        <div className="text-neutral-400">
                          Transaction ID: <span className="text-purple-300 font-bold">{activeReport.transaction_id}</span> (Reversible snapshot saved)
                        </div>
                      )}
                    </div>

                    {/* Affected Targets / Handles */}
                    {activeReport.affected_targets && activeReport.affected_targets.length > 0 && (
                      <div className="bg-neutral-950 p-4 rounded-lg border border-neutral-800">
                        <div className="text-neutral-400 text-xs font-semibold mb-2">
                          Allocated Handles ({activeReport.affected_targets.length}):
                        </div>
                        <div className="space-y-1.5">
                          {activeReport.affected_targets.map((t) => (
                            <div key={t.handle} className="flex items-center gap-2 text-xs">
                              <span className="text-cyan-400 bg-cyan-950 px-1.5 py-0.5 rounded border border-cyan-800">
                                {t.handle}
                              </span>
                              <span className="text-neutral-200">{t.path}</span>
                              <span className="text-neutral-500">[{t.target_type}]</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Node Results Details */}
                    {activeReport.node_results && (
                      <div className="bg-neutral-950 p-4 rounded-lg border border-neutral-800 space-y-2">
                        <div className="text-neutral-400 text-xs font-semibold mb-1">
                          Node Output Data:
                        </div>
                        <pre className="text-neutral-300 overflow-x-auto text-[11px] leading-relaxed">
                          {JSON.stringify(activeReport.node_results, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8 text-neutral-500">
                    No execution report yet. Click "Execute" to run the plan.
                  </div>
                )}
              </div>
            )}

            {activeTab === "raw_text" && activePlan && (
              <pre className="font-mono text-xs text-amber-300/90 bg-neutral-950 p-4 rounded-lg border border-neutral-800 overflow-x-auto leading-relaxed whitespace-pre-wrap">
                {activePlan.formatted_text}
              </pre>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
