import React from "react";
import { TransactionRecord } from "../types";
import { History, Undo2, CheckCircle2, AlertCircle, Clock, ShieldCheck } from "lucide-react";

interface Props {
  transactions: TransactionRecord[];
  onUndo: () => void;
  loading: boolean;
}

export const TransactionLedger: React.FC<Props> = ({ transactions, onUndo, loading }) => {
  return (
    <div className="space-y-6">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <History className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-neutral-100">ACID Transaction Ledger & Snapshots</h2>
          </div>
          <p className="text-xs text-neutral-400">
            Reversible state journal. Modifying operations create point-in-time snapshots for atomic rollback.
          </p>
        </div>

        <button
          onClick={onUndo}
          disabled={loading || transactions.length === 0}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-amber-500 text-neutral-950 hover:bg-amber-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
        >
          <Undo2 className="w-4 h-4" />
          Rollback Last Action (UNDO)
        </button>
      </div>

      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-neutral-800">
          <h3 className="text-sm font-semibold text-neutral-200">Transaction Journal History</h3>
          <span className="text-xs font-mono text-neutral-400">
            {transactions.length} Recorded Transaction{transactions.length === 1 ? "" : "s"}
          </span>
        </div>

        {transactions.length === 0 ? (
          <div className="text-center py-8 text-xs text-neutral-500">
            No transactions recorded yet. Modifying verbs (like <code>EDIT</code> or <code>DELETE</code>) will appear here with instant rollback capabilities.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-neutral-800 text-neutral-500 font-mono">
                  <th className="py-2 px-3">TRANSACTION ID</th>
                  <th className="py-2 px-3">VERB</th>
                  <th className="py-2 px-3">DESCRIPTION</th>
                  <th className="py-2 px-3">SNAPSHOTS</th>
                  <th className="py-2 px-3">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60 font-mono">
                {transactions.map((tx) => (
                  <tr key={tx.tx_id} className="hover:bg-neutral-950/40">
                    <td className="py-3 px-3 font-semibold text-neutral-200">{tx.tx_id}</td>
                    <td className="py-3 px-3">
                      <span className="bg-amber-950/60 text-amber-300 border border-amber-800/40 px-2 py-0.5 rounded text-[11px]">
                        {tx.verb}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-neutral-300">{tx.description || `Transaction for ${tx.verb}`}</td>
                    <td className="py-3 px-3 text-neutral-400">{tx.snapshot_count} snapshot files</td>
                    <td className="py-3 px-3">
                      {tx.rolled_back ? (
                        <span className="text-purple-400 bg-purple-950/50 px-2 py-0.5 rounded border border-purple-800/40 text-[10px] font-semibold">
                          ROLLED BACK
                        </span>
                      ) : tx.committed ? (
                        <span className="text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-800/40 text-[10px] font-semibold flex items-center gap-1 w-fit">
                          <CheckCircle2 className="w-3 h-3" /> COMMITTED
                        </span>
                      ) : (
                        <span className="text-yellow-400 bg-yellow-950/50 px-2 py-0.5 rounded border border-yellow-800/40 text-[10px] font-semibold">
                          ACTIVE
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
