import React from "react";
import { Shield, ShieldAlert, ShieldCheck, Lock, AlertOctagon, CheckCircle2, FileCode, Ban } from "lucide-react";

export const SafetyMatrixView: React.FC = () => {
  const protectedPaths = [
    { path: "/System", reason: "macOS Core OS Root & SIP Protected" },
    { path: "/Library", reason: "System-wide Application Support & Daemons" },
    { path: "/usr", reason: "System Utilities & Binaries" },
    { path: "/bin", reason: "Essential System Executables" },
    { path: "/sbin", reason: "System Admin Binaries" },
    { path: "/etc", reason: "Core System Configurations" },
    { path: "/var", reason: "System Daemon Spool & Logs" },
  ];

  const safetyPrinciples = [
    {
      title: "Hard Verb Whitelist Principle",
      desc: "Natural language may select and parameterise registered verbs, but it can never synthesize or execute arbitrary bash commands, uninspected subshells, or unregistered binaries.",
      icon: <Lock className="w-5 h-5 text-amber-400" />,
    },
    {
      title: "Deterministic Ambiguity Rejection",
      desc: "Vague, destructive commands like 'clean this directory' or 'remove the old files' are deterministically halted and rejected, requiring concrete targets or parameters.",
      icon: <AlertOctagon className="w-5 h-5 text-orange-400" />,
    },
    {
      title: "ACID Transaction & Snapshot Engine",
      desc: "All modifying operations (EDIT, DELETE, REPLACE, TRUNCATE, CLEAR) capture pre-execution file snapshots to allow instantaneous, deterministic single-click rollback (UNDO).",
      icon: <ShieldCheck className="w-5 h-5 text-emerald-400" />,
    },
    {
      title: "Two-Phase Inspection (PLAN ➔ VERIFY)",
      desc: "Every intent compiles into an inspectable Directed Acyclic Graph (DAG) with exact cost estimates, blast radius analysis, and post-execution checksum verification.",
      icon: <FileCode className="w-5 h-5 text-blue-400" />,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Policy Hero Card */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
            <Shield className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-neutral-100">HardTerminal Safety & Quarantine Architecture</h2>
            <p className="text-xs text-neutral-400">Strict sandboxing, deterministic policy enforcement, and macOS root path protection</p>
          </div>
        </div>
      </div>

      {/* 4 Core Principles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {safetyPrinciples.map((sp) => (
          <div key={sp.title} className="bg-neutral-900 border border-neutral-800 rounded-xl p-5">
            <div className="flex items-center gap-3 mb-2.5">
              <div className="p-2 rounded-lg bg-neutral-950 border border-neutral-800">
                {sp.icon}
              </div>
              <h3 className="text-sm font-semibold text-neutral-200">{sp.title}</h3>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed">{sp.desc}</p>
          </div>
        ))}
      </div>

      {/* Protected Roots Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Ban className="w-4 h-4 text-red-400" />
            <h3 className="text-sm font-semibold text-neutral-200">System Protected Paths (Hard Quarantine)</h3>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
            ENFORCEMENT: STRICT
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-500 font-mono">
                <th className="py-2 px-3">PROTECTED ROOT PATH</th>
                <th className="py-2 px-3">POLICY RESTRICTION</th>
                <th className="py-2 px-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-mono">
              {protectedPaths.map((pp) => (
                <tr key={pp.path} className="hover:bg-neutral-950/40">
                  <td className="py-2.5 px-3 font-semibold text-amber-300">{pp.path}</td>
                  <td className="py-2.5 px-3 text-neutral-400">{pp.reason}</td>
                  <td className="py-2.5 px-3">
                    <span className="text-[10px] text-red-400 bg-red-950/40 px-2 py-0.5 rounded border border-red-800/40">
                      BLOCKED / QUARANTINED
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
