import React, { useState, useEffect } from "react";
import {
  Terminal as TerminalIcon,
  Layers,
  Shield,
  FolderTree,
  History,
  Sparkles,
  RefreshCw,
  Undo2,
  TerminalSquare,
  Bot,
  Activity,
  CheckCircle2,
} from "lucide-react";
import { TerminalView } from "./components/TerminalView";
import { VerbRegistryView } from "./components/VerbRegistryView";
import { SafetyMatrixView } from "./components/SafetyMatrixView";
import { WorkspaceExplorer } from "./components/WorkspaceExplorer";
import { TransactionLedger } from "./components/TransactionLedger";
import { AIAssistantModal } from "./components/AIAssistantModal";
import {
  ExecutionPlan,
  ExecutionReport,
  VerbDefinition,
  WorkspaceFile,
  TargetHandleItem,
  TransactionRecord,
  WorkspaceStatus,
} from "./types";

export default function App() {
  const [activeTab, setActiveTab] = useState<
    "terminal" | "verbs" | "safety" | "workspace" | "transactions"
  >("terminal");

  // Terminal state
  const [queryInput, setQueryInput] = useState<string>("find all CSV files in .");
  const [loading, setLoading] = useState<boolean>(false);
  const [activePlan, setActivePlan] = useState<ExecutionPlan | null>(null);
  const [activeReport, setActiveReport] = useState<ExecutionReport | null>(null);
  const [ambiguityError, setAmbiguityError] = useState<{
    message: string;
    required_parameters: string[];
    hint?: string;
  } | null>(null);
  const [generalError, setGeneralError] = useState<{
    message: string;
    hint?: string;
  } | null>(null);

  // App state
  const [verbs, setVerbs] = useState<VerbDefinition[]>([]);
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [handles, setHandles] = useState<TargetHandleItem[]>([]);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [workspaceStatus, setWorkspaceStatus] = useState<WorkspaceStatus | null>(null);
  const [copilotOpen, setCopilotOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Fetch initial verbs and workspace status
  const fetchVerbs = async () => {
    try {
      const res = await fetch("/api/verbs");
      const data = await res.json();
      if (data.success && data.verbs) {
        setVerbs(data.verbs);
      }
    } catch (e) {
      console.error("Failed to fetch verbs", e);
    }
  };

  const fetchWorkspace = async () => {
    try {
      const res = await fetch("/api/workspace");
      const data = await res.json();
      if (data.success) {
        setFiles(data.files || []);
        setHandles(data.handles || []);
        setTransactions(data.transactions || []);
        setWorkspaceStatus(data.context || null);
      }
    } catch (e) {
      console.error("Failed to fetch workspace", e);
    }
  };

  useEffect(() => {
    fetchVerbs();
    fetchWorkspace();
  }, []);

  const handlePlan = async (query: string) => {
    setLoading(true);
    setAmbiguityError(null);
    setGeneralError(null);

    try {
      const res = await fetch("/api/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });
      const data = await res.json();
      if (data.success) {
        setActivePlan(data.plan);
      } else {
        if (data.error_type === "AmbiguousRequestError") {
          setAmbiguityError({
            message: data.message,
            required_parameters: data.required_parameters || [],
            hint: data.hint,
          });
        } else {
          setGeneralError({ message: data.message || "Failed to generate plan", hint: data.hint });
        }
      }
    } catch (e: any) {
      setGeneralError({ message: e.message || "Network error" });
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = async (query: string) => {
    setLoading(true);
    setAmbiguityError(null);
    setGeneralError(null);

    try {
      const res = await fetch("/api/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });
      const data = await res.json();
      if (data.success) {
        setActivePlan(data.plan);
        showToast("Dry-run preview generated. No files modified.");
      } else {
        if (data.error_type === "AmbiguousRequestError") {
          setAmbiguityError({
            message: data.message,
            required_parameters: data.required_parameters || [],
            hint: data.hint,
          });
        } else {
          setGeneralError({ message: data.message || "Preview failed", hint: data.hint });
        }
      }
    } catch (e: any) {
      setGeneralError({ message: e.message || "Network error" });
    } finally {
      setLoading(false);
    }
  };

  const handleExecute = async (query: string, dryRun: boolean = false) => {
    setLoading(true);
    setAmbiguityError(null);
    setGeneralError(null);

    try {
      const res = await fetch("/api/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, dry_run: dryRun }),
      });
      const data = await res.json();
      if (data.success) {
        setActivePlan(data.plan);
        setActiveReport(data.report);
        showToast(`Executed: ${data.summary || "Success"}`);
        fetchWorkspace();
      } else {
        if (data.error_type === "AmbiguousRequestError") {
          setAmbiguityError({
            message: data.message,
            required_parameters: data.required_parameters || [],
            hint: data.hint,
          });
        } else {
          setGeneralError({ message: data.message || "Execution failed", hint: data.hint });
        }
      }
    } catch (e: any) {
      setGeneralError({ message: e.message || "Network error" });
    } finally {
      setLoading(false);
    }
  };

  const handleUndo = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/undo", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        showToast("Transaction rollback successful (UNDO).");
        fetchWorkspace();
      } else {
        showToast(`Rollback failed: ${data.error || "No active transaction to undo"}`);
      }
    } catch (e: any) {
      showToast(`Rollback error: ${e.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleSeed = async () => {
    try {
      const res = await fetch("/api/seed", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        showToast("Sample datasets reset.");
        fetchWorkspace();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleReadFile = async (filePath: string): Promise<string | null> => {
    try {
      const res = await fetch("/api/read_file", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: filePath }),
      });
      const data = await res.json();
      if (data.success) {
        return data.content;
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  const handleSelectVerbFromCatalog = (cmd: string) => {
    setQueryInput(cmd);
    setActiveTab("terminal");
  };

  const handleClear = () => {
    setActivePlan(null);
    setActiveReport(null);
    setAmbiguityError(null);
    setGeneralError(null);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top macOS Style Navigation Header */}
      <header className="bg-neutral-900/90 backdrop-blur-md border-b border-neutral-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Brand & macOS dots */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-yellow-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-green-500/80 inline-block"></span>
            </div>

            <div className="h-4 w-px bg-neutral-800 hidden sm:block"></div>

            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/30">
                <TerminalSquare className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm text-neutral-100 tracking-wide font-mono">
                    HardTerminal
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-800/40 font-semibold">
                    v1.0 PYTHON KERNEL
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Center Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-xs">
            <button
              onClick={() => setActiveTab("terminal")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === "terminal"
                  ? "bg-amber-500 text-neutral-950 font-semibold shadow-sm"
                  : "text-neutral-400 hover:text-neutral-200"
              }`}
            >
              <TerminalIcon className="w-3.5 h-3.5" />
              Terminal & Graph
            </button>

            <button
              onClick={() => setActiveTab("verbs")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === "verbs"
                  ? "bg-amber-500 text-neutral-950 font-semibold shadow-sm"
                  : "text-neutral-400 hover:text-neutral-200"
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Verb Registry ({verbs.length || 60})
            </button>

            <button
              onClick={() => setActiveTab("safety")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === "safety"
                  ? "bg-amber-500 text-neutral-950 font-semibold shadow-sm"
                  : "text-neutral-400 hover:text-neutral-200"
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              Safety Policy
            </button>

            <button
              onClick={() => setActiveTab("workspace")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === "workspace"
                  ? "bg-amber-500 text-neutral-950 font-semibold shadow-sm"
                  : "text-neutral-400 hover:text-neutral-200"
              }`}
            >
              <FolderTree className="w-3.5 h-3.5" />
              Sandbox Files
            </button>

            <button
              onClick={() => setActiveTab("transactions")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === "transactions"
                  ? "bg-amber-500 text-neutral-950 font-semibold shadow-sm"
                  : "text-neutral-400 hover:text-neutral-200"
              }`}
            >
              <History className="w-3.5 h-3.5" />
              ACID Ledger
              {transactions.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
              )}
            </button>
          </nav>

          {/* Right Status Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleUndo}
              disabled={loading || transactions.length === 0}
              className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-amber-300 hover:border-neutral-700 disabled:opacity-40 flex items-center gap-1 transition-colors"
              title="Rollback last transaction"
            >
              <Undo2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Undo</span>
            </button>

            <button
              onClick={() => setCopilotOpen(true)}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Copilot</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="md:hidden flex items-center justify-around border-t border-neutral-800/80 px-2 py-1.5 text-xs bg-neutral-950">
          <button
            onClick={() => setActiveTab("terminal")}
            className={`p-2 rounded-lg ${activeTab === "terminal" ? "text-amber-400 font-bold" : "text-neutral-400"}`}
          >
            Terminal
          </button>
          <button
            onClick={() => setActiveTab("verbs")}
            className={`p-2 rounded-lg ${activeTab === "verbs" ? "text-amber-400 font-bold" : "text-neutral-400"}`}
          >
            Verbs
          </button>
          <button
            onClick={() => setActiveTab("safety")}
            className={`p-2 rounded-lg ${activeTab === "safety" ? "text-amber-400 font-bold" : "text-neutral-400"}`}
          >
            Safety
          </button>
          <button
            onClick={() => setActiveTab("workspace")}
            className={`p-2 rounded-lg ${activeTab === "workspace" ? "text-amber-400 font-bold" : "text-neutral-400"}`}
          >
            Files
          </button>
          <button
            onClick={() => setActiveTab("transactions")}
            className={`p-2 rounded-lg ${activeTab === "transactions" ? "text-amber-400 font-bold" : "text-neutral-400"}`}
          >
            Ledger
          </button>
        </div>
      </header>

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === "terminal" && (
          <TerminalView
            onExecute={handleExecute}
            onPlan={handlePlan}
            onPreview={handlePreview}
            loading={loading}
            activePlan={activePlan}
            activeReport={activeReport}
            ambiguityError={ambiguityError}
            generalError={generalError}
            queryInput={queryInput}
            setQueryInput={setQueryInput}
            onClear={handleClear}
          />
        )}

        {activeTab === "verbs" && (
          <VerbRegistryView
            verbs={verbs}
            onSelectVerb={handleSelectVerbFromCatalog}
          />
        )}

        {activeTab === "safety" && <SafetyMatrixView />}

        {activeTab === "workspace" && (
          <WorkspaceExplorer
            files={files}
            handles={handles}
            workspacePath={workspaceStatus?.workspace || "./workspace_sandbox"}
            onRefresh={fetchWorkspace}
            onReadFile={handleReadFile}
            onSeed={handleSeed}
          />
        )}

        {activeTab === "transactions" && (
          <TransactionLedger
            transactions={transactions}
            onUndo={handleUndo}
            loading={loading}
          />
        )}
      </main>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-neutral-900 border border-neutral-700 text-neutral-100 text-xs px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* AI Assistant Modal */}
      <AIAssistantModal
        isOpen={copilotOpen}
        onClose={() => setCopilotOpen(false)}
        onApplyQuery={(q) => {
          setQueryInput(q);
          setActiveTab("terminal");
          setCopilotOpen(false);
        }}
      />
    </div>
  );
}
