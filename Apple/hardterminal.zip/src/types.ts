export interface VerbParameter {
  name: string;
  description: string;
  param_type: string;
  required: boolean;
  default: any;
  choices?: string[];
}

export interface VerbDefinition {
  name: string;
  description: string;
  category: string;
  parameters: Record<string, VerbParameter>;
  target_types: string[];
  risk_level: "NONE" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  requires_confirmation: boolean;
  reversible: boolean;
}

export interface ActionNode {
  action_id: string;
  verb: string;
  target: string | null;
  parameters: Record<string, any>;
  dependencies: string[];
  risk: "NONE" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  estimated_cost_ms: number;
  status: "QUEUED" | "RUNNING" | "SUCCESS" | "FAILED" | "SKIPPED";
  requires_confirmation: boolean;
  reversible: boolean;
  error?: string | null;
}

export interface ActionGraph {
  graph_id: string;
  nodes: ActionNode[];
  node_count: number;
}

export interface RiskAssessment {
  level: "NONE" | "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  reason: string;
  requires_confirmation: boolean;
  is_destructive: boolean;
  affected_count: number;
  warnings: string[];
}

export interface ExecutionPlan {
  plan_id: string;
  primary_verb: string;
  target_summary: string;
  action_graph: ActionGraph;
  risk: RiskAssessment;
  estimated_cost_ms: number;
  requires_confirmation: boolean;
  reversible: boolean;
  description: string;
  parameters_summary: Record<string, any>;
  formatted_text: string;
}

export interface Intent {
  verb: string;
  target: string | null;
  parameters: Record<string, any>;
  is_pipeline?: boolean;
  pipeline_steps?: Intent[];
  flags: Record<string, any>;
  raw_query?: string;
}

export interface TargetHandleItem {
  handle: string;
  path: string;
  target_type: string;
  exists: boolean;
  size_bytes?: number;
  metadata?: Record<string, any>;
}

export interface WorkspaceFile {
  name: string;
  rel_path: string;
  size_bytes: number;
  modified: number;
  ext: string;
}

export interface TransactionRecord {
  tx_id: string;
  verb: string;
  timestamp: number;
  description: string;
  committed: boolean;
  rolled_back: boolean;
  snapshot_count: number;
}

export interface ExecutionReport {
  plan_id: string;
  primary_verb: string;
  success: boolean;
  duration_ms: number;
  dry_run: boolean;
  affected_targets: TargetHandleItem[];
  failed_nodes: string[];
  transaction_id?: string | null;
  verification?: {
    all_verified: boolean;
    target_count: number;
    verifications: any[];
  };
  summary_message: string;
  node_results?: Record<string, {
    success: boolean;
    data: any;
    error: string | null;
    duration_ms: number;
  }>;
}

export interface WorkspaceStatus {
  workspace: string;
  target_count: number;
  state: string;
  active_project: string;
  history_count: number;
}
