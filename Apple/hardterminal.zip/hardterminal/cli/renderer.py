"""CLI Terminal Renderer and Box Graphics for macOS HardTerminal."""

import sys


class TerminalRenderer:
    """Renders formatted boxed headers, plans, previews, and ASCII graphs."""

    @staticmethod
    def render_header(workspace: str, target_count: int, state: str = "READY") -> str:
        w_display = workspace if len(workspace) < 32 else ("..." + workspace[-29:])
        lines = [
            "╔════════════════════════════════════════════════╗",
            "║                  HARDTERMINAL                  ║",
            "╠════════════════════════════════════════════════╣",
            f"║ Workspace: {w_display:<35} ║",
            f"║ Targets:   {target_count:<35} ║",
            f"║ State:     {state:<35} ║",
            "╚════════════════════════════════════════════════╝",
        ]
        return "\n".join(lines)

    @staticmethod
    def render_plan_box(plan_text: str) -> str:
        return f"\n{plan_text}\n"

    @staticmethod
    def render_preview_box(count: int, from_dir: str, to_dir: str) -> str:
        lines = [
            "PREVIEW",
            "──────────────────────────────",
            "",
            f"{count} objects affected",
            "",
            "FROM:",
            f"{from_dir}",
            "",
            "TO:",
            f"{to_dir}",
            "",
            "No filesystem changes made.",
        ]
        return "\n".join(lines)

    @staticmethod
    def render_dry_run_box(count: int, space_recovered: str = "0 B") -> str:
        lines = [
            "DRY RUN",
            "",
            f"{count} files would be deleted / modified.",
            "",
            "Estimated space recovered:",
            f"{space_recovered}",
            "",
            "NO CHANGES MADE.",
        ]
        return "\n".join(lines)

    @staticmethod
    def render_history_table(records: list) -> str:
        lines = [
            f"{'JOB':<6}{'TIME':<8}{'VERB':<12}{'TARGET':<22}{'STATUS':<10}{'LATENCY':<10}",
            "─" * 68,
        ]
        for r in records:
            dur = f"{r.duration_ms:.1f}ms"
            lines.append(f"{r.job_id:<6}{r.timestamp:<8}{r.verb:<12}{r.target_summary[:20]:<22}{r.status:<10}{dur:<10}")
        return "\n".join(lines)
