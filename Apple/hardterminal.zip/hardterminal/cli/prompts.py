"""Intelligent Completion and Interactive Prompts."""

from hardterminal.core.registry import VerbRegistry
from hardterminal.core.context import WorkspaceContext


class CompleterEngine:
    """Provides TAB auto-completion for verbs, targets, handles (#12), and paths."""

    def __init__(self, registry: VerbRegistry, context: WorkspaceContext):
        self.registry = registry
        self.context = context

    def get_completions(self, prefix: str) -> list[str]:
        prefix_clean = prefix.strip()
        if not prefix_clean:
            return sorted([v.name for v in self.registry.list_all()][:15])

        # Handle prefix e.g. # or move #
        tokens = prefix_clean.split()
        last_tok = tokens[-1]

        # Handle completions: #001, #12
        if last_tok.startswith("#"):
            handles = list(self.context.targets.keys()) + list(self.context.collections.keys())
            return [h for h in handles if h.startswith(last_tok)]

        # Verb name completions
        if len(tokens) == 1:
            all_verbs = [v.name for v in self.registry.list_all()]
            matches = [v for v in all_verbs if v.startswith(last_tok.upper())]
            return matches

        # Parameter keywords
        keywords = ["PATTERN", "TO", "WITH", "BY", "FORMAT", "SIZE", "MODIFIED", "WHERE", "--dry-run", "--json"]
        return [k for k in keywords if k.startswith(last_tok.upper())]
