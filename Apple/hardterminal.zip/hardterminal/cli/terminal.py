"""HardTerminal Interactive CLI and Machine-Readable runner."""

import sys
import os
import json
import argparse
from hardterminal import HardTerminal
from hardterminal.cli.renderer import TerminalRenderer
from hardterminal.cli.prompts import CompleterEngine
from hardterminal.core.errors import HardTerminalError, AmbiguousRequestError


def run_cli(workspace: str = ".", json_mode: bool = False, execute_cmd: str | None = None):
    terminal = HardTerminal(workspace_path=workspace)
    renderer = TerminalRenderer()
    completer = CompleterEngine(terminal.registry, terminal.context)

    # Direct one-shot command execution
    if execute_cmd:
        try:
            intent = terminal.interpret(execute_cmd)
            plan = terminal.plan(intent)
            report = terminal.execute(plan, dry_run=intent.flags.get("dry_run", False))
            if json_mode:
                out = {
                    "verb": plan.primary_verb,
                    "target": plan.target_summary,
                    "status": "SUCCESS" if report.success else "FAILED",
                    "duration_ms": report.duration_ms,
                    "affected_count": len(report.affected_targets),
                    "details": report.to_dict(),
                }
                print(json.dumps(out, indent=2))
            else:
                if intent.flags.get("dry_run"):
                    print(renderer.render_dry_run_box(len(report.affected_targets)))
                else:
                    print(report.summary_message)
            return 0 if report.success else 1
        except HardTerminalError as e:
            if json_mode:
                print(json.dumps({"status": "ERROR", "error": e.to_dict()}, indent=2))
            else:
                print(f"\nERROR: {e.message}")
                if e.hint:
                    print(f"HINT: {e.hint}")
            return 1

    # Interactive Shell Mode
    status = terminal.context.get_status_summary()
    print(renderer.render_header(status["workspace"], status["target_count"], status["state"]))
    print("\nType plain language requests or explicit verbs (e.g. 'find all CSV files', 'help', 'history', 'exit').")

    while True:
        try:
            prompt_str = "\nhardterminal> "
            user_input = input(prompt_str).strip()
            if not user_input:
                continue

            if user_input.lower() in ["exit", "quit", "q"]:
                print("Session terminated. Releasing locks.")
                break

            if user_input.lower() == "history":
                print(renderer.render_history_table(terminal.context.history))
                continue

            if user_input.lower() == "help":
                print("\nRegistered HardTerminal Verbs:")
                verbs = sorted([v.name for v in terminal.registry.list_all()])
                for i in range(0, len(verbs), 8):
                    print("  " + "  ".join(f"{v:<10}" for v in verbs[i:i+8]))
                continue

            # Process through compiler
            intent = terminal.interpret(user_input)
            plan = terminal.plan(intent)

            # Check if user requested PLAN or PREVIEW
            if intent.verb in ["PLAN", "EXPLAIN"]:
                print(renderer.render_plan_box(plan.formatted_text()))
                continue
            if intent.verb == "PREVIEW":
                preview = terminal.preview(plan)
                print(json.dumps(preview, indent=2))
                continue

            # Display plan and check confirmation if required
            if plan.requires_confirmation and not intent.flags.get("dry_run"):
                print(f"\nVERB: {plan.primary_verb}")
                print(f"TARGET: {plan.target_summary}")
                if plan.parameters_summary:
                    print(f"PARAMETERS: {plan.parameters_summary}")
                print("\nPLAN READY.")
                conf = input("Execute? [Y/n]: ").strip().lower()
                if conf in ["n", "no"]:
                    print("Execution cancelled by user. No action taken.")
                    continue

            # Execute
            report = terminal.execute(plan, dry_run=intent.flags.get("dry_run", False))
            if report.dry_run:
                print(renderer.render_dry_run_box(len(report.affected_targets)))
            else:
                print(f"\n[{report.primary_verb}] {report.summary_message}")
                if report.affected_targets:
                    print(f"Active handles: {', '.join(t.handle for t in report.affected_targets[:6])}")

        except AmbiguousRequestError as e:
            print("\nAMBIGUOUS REQUEST")
            print(f"\"{e.message}\"")
            print("\nI need:")
            for p in e.required_parameters:
                print(f"- {p}")
            print("\nNo action taken.")
        except HardTerminalError as e:
            print(f"\nERROR: {e.message}")
            if e.hint:
                print(f"HINT: {e.hint}")
        except KeyboardInterrupt:
            print("\nOperation interrupted.")
        except EOFError:
            break


def main():
    parser = argparse.ArgumentParser(description="HardTerminal — Plain-language macOS Verb Kernel")
    parser.add_argument("command", nargs="*", help="Direct command to execute")
    parser.add_argument("--json", action="store_true", help="Return structured machine-readable JSON")
    parser.add_argument("--workspace", default=".", help="Workspace path")
    args = parser.parse_args()

    cmd_str = " ".join(args.command) if args.command else None
    sys.exit(run_cli(workspace=args.workspace, json_mode=args.json, execute_cmd=cmd_str))


if __name__ == "__main__":
    main()
