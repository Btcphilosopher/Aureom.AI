"""Data and Transformation Verbs (SORT, FILTER, GROUP, COUNT, ANALYSE, CALCULATE, MEASURE, TRANSFORM, MERGE, SPLIT, COMPRESS, EXTRACT, CONVERT, GENERATE)."""

import os
import csv
import json
import zipfile
import tarfile
from collections import defaultdict
from typing import Any
from hardterminal.core.targets import Target, TargetType, infer_target_type
from hardterminal.core.registry import VerbResult
from hardterminal.filesystem.edit import _extract_target_list


def _read_dataset(target: Target) -> tuple[list[str], list[dict[str, Any]]]:
    """Helper to parse CSV or JSON array into headers and list of row dicts."""
    p = target.resolved_path
    if not os.path.isfile(p):
        return [], []

    if target.target_type == TargetType.CSV or p.endswith(".csv"):
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames or []
            rows = list(reader)
            return list(headers), rows
    elif target.target_type == TargetType.JSON or p.endswith(".json"):
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            data = json.load(f)
            if isinstance(data, list) and data and isinstance(data[0], dict):
                headers = list(data[0].keys())
                return headers, data
    return [], []


def _write_dataset(path: str, headers: list[str], rows: list[dict[str, Any]]):
    """Writes list of dicts to CSV or JSON."""
    if path.endswith(".json"):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(rows, f, indent=2)
    else:
        with open(path, "w", encoding="utf-8", newline="") as f:
            if not headers and rows:
                headers = list(rows[0].keys())
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(rows)


def sort_handler(context: Any, target_ref: str | None = None, by: str | None = None, descending: bool = False, **kwargs) -> VerbResult:
    """Sorts dataset rows by key or lines of text."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for SORT.")

    target = targets[0]
    headers, rows = _read_dataset(target)

    if rows:
        sort_key = by or headers[0] if headers else None
        if not sort_key:
            return VerbResult(success=False, error="No column specified to sort by.")

        def _val(r):
            v = r.get(sort_key, "")
            try:
                return (0, float(v))
            except ValueError:
                return (1, str(v))

        sorted_rows = sorted(rows, key=_val, reverse=descending)
        _write_dataset(target.resolved_path, headers, sorted_rows)
        return VerbResult(
            success=True,
            data={"sorted_by": sort_key, "descending": descending, "row_count": len(sorted_rows), "preview": sorted_rows[:5]},
            targets=[target],
        )

    # Fallback text sorting
    try:
        with open(target.resolved_path, "r", encoding="utf-8") as f:
            lines = sorted(f.readlines(), reverse=descending)
        with open(target.resolved_path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        return VerbResult(success=True, data={"sorted_lines": len(lines), "descending": descending}, targets=[target])
    except Exception as e:
        return VerbResult(success=False, error=f"Sort failed: {e}")


def filter_handler(
    context: Any,
    target_ref: str | None = None,
    condition: str | None = None,
    column: str | None = None,
    operator: str = "==",
    value: Any = None,
    **kwargs,
) -> VerbResult:
    """Filters dataset records by condition (e.g. revenue > 1000)."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for FILTER.")

    target = targets[0]
    headers, rows = _read_dataset(target)

    # Parse condition string if supplied
    if condition:
        for op in [">=", "<=", "!=", ">", "<", "==", "contains"]:
            if op in condition:
                parts = condition.split(op, 1)
                column = parts[0].strip()
                operator = op
                value = parts[1].strip()
                break

    if not column or not rows:
        return VerbResult(success=False, error=f"FILTER requires a valid column and condition. Headers: {headers}")

    filtered: list[dict[str, Any]] = []
    for r in rows:
        row_v = r.get(column)
        if row_v is None:
            continue

        # Try numeric compare
        try:
            num_r = float(row_v)
            num_v = float(value)
            matched = False
            if operator == ">":
                matched = num_r > num_v
            elif operator == ">=":
                matched = num_r >= num_v
            elif operator == "<":
                matched = num_r < num_v
            elif operator == "<=":
                matched = num_r <= num_v
            elif operator == "==":
                matched = num_r == num_v
            elif operator == "!=":
                matched = num_r != num_v
            if matched:
                filtered.append(r)
                continue
        except (ValueError, TypeError):
            pass

        # String match
        str_r = str(row_v).lower()
        str_v = str(value).lower().strip("\"'")
        if operator == "contains" and str_v in str_r:
            filtered.append(r)
        elif operator == "==" and str_r == str_v:
            filtered.append(r)
        elif operator == "!=" and str_r != str_v:
            filtered.append(r)

    # Write back to target
    _write_dataset(target.resolved_path, headers, filtered)

    return VerbResult(
        success=True,
        data={
            "matched_rows": len(filtered),
            "original_rows": len(rows),
            "filter_column": column,
            "operator": operator,
            "value": value,
            "sample": filtered[:5],
        },
        targets=[target],
    )


def group_handler(context: Any, target_ref: str | None = None, by: str = "", **kwargs) -> VerbResult:
    """Groups rows by column key."""
    if not by:
        return VerbResult(success=False, error="GROUP requires 'by' parameter.")

    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for GROUP.")

    headers, rows = _read_dataset(targets[0])
    groups: dict[str, list[dict]] = defaultdict(list)
    for r in rows:
        k = str(r.get(by, "UNKNOWN"))
        groups[k].append(r)

    summary = {k: len(v) for k, v in groups.items()}
    return VerbResult(
        success=True,
        data={"grouped_by": by, "group_count": len(groups), "distribution": summary},
        targets=targets,
    )


def count_handler(context: Any, target_ref: str | None = None, **kwargs) -> VerbResult:
    """Counts rows, elements, or targets."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for COUNT.")

    counts: list[dict] = []
    for t in targets:
        headers, rows = _read_dataset(t)
        if rows:
            counts.append({"handle": t.handle, "path": t.resolved_path, "type": "DATASET", "count": len(rows)})
        elif os.path.isfile(t.resolved_path):
            with open(t.resolved_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()
                counts.append({"handle": t.handle, "path": t.resolved_path, "type": "LINES", "count": len(lines)})
        elif os.path.isdir(t.resolved_path):
            entries = os.listdir(t.resolved_path)
            counts.append({"handle": t.handle, "path": t.resolved_path, "type": "DIR_ENTRIES", "count": len(entries)})

    total = sum(c["count"] for c in counts)
    return VerbResult(success=True, data={"total_count": total, "details": counts}, targets=targets)


def analyse_handler(context: Any, target_ref: str | None = None, column: str | None = None, **kwargs) -> VerbResult:
    """Statistical and schema analysis of dataset."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for ANALYSE.")

    target = targets[0]
    headers, rows = _read_dataset(target)

    if not rows:
        # Fallback file inspection
        st = os.stat(target.resolved_path)
        return VerbResult(
            success=True,
            data={"type": "FILE", "size_bytes": st.st_size, "modified": st.st_mtime},
            targets=[target],
        )

    # Column metrics
    col_stats: dict[str, Any] = {}
    for col in headers:
        values = [r.get(col) for r in rows if r.get(col) is not None and r.get(col) != ""]
        numeric_vals: list[float] = []
        for v in values:
            try:
                numeric_vals.append(float(v))
            except (ValueError, TypeError):
                pass

        is_numeric = len(numeric_vals) == len(values) and len(numeric_vals) > 0
        stats: dict[str, Any] = {
            "total_records": len(rows),
            "present_values": len(values),
            "missing_values": len(rows) - len(values),
            "unique_values": len(set(values)),
            "inferred_type": "NUMERIC" if is_numeric else "STRING",
        }
        if is_numeric:
            stats["min"] = min(numeric_vals)
            stats["max"] = max(numeric_vals)
            stats["sum"] = sum(numeric_vals)
            stats["mean"] = sum(numeric_vals) / len(numeric_vals)

        col_stats[col] = stats

    return VerbResult(
        success=True,
        data={
            "handle": target.handle,
            "path": target.resolved_path,
            "total_rows": len(rows),
            "total_columns": len(headers),
            "columns": headers,
            "column_statistics": col_stats,
        },
        targets=[target],
    )


def calculate_handler(context: Any, target_ref: str | None = None, metric: str = "sum", column: str | None = None, **kwargs) -> VerbResult:
    """Calculates aggregate metrics (sum, mean, min, max, count)."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for CALCULATE.")

    headers, rows = _read_dataset(targets[0])
    target_col = column or (headers[0] if headers else None)
    if not target_col:
        return VerbResult(success=False, error="No column specified for calculation.")

    numbers: list[float] = []
    for r in rows:
        v = r.get(target_col)
        if v is not None:
            try:
                numbers.append(float(v))
            except ValueError:
                pass

    if not numbers:
        return VerbResult(success=False, error=f"No numeric values in column '{target_col}'.")

    metric_lower = metric.lower()
    val = 0.0
    if metric_lower in ["sum", "total"]:
        val = sum(numbers)
    elif metric_lower in ["mean", "avg", "average"]:
        val = sum(numbers) / len(numbers)
    elif metric_lower == "min":
        val = min(numbers)
    elif metric_lower == "max":
        val = max(numbers)
    elif metric_lower == "count":
        val = float(len(numbers))

    return VerbResult(
        success=True,
        data={"metric": metric_lower, "column": target_col, "result": val, "sample_size": len(numbers)},
        targets=targets,
    )


def measure_handler(context: Any, target_ref: str | None = None, **kwargs) -> VerbResult:
    """Measures byte sizes, lines, words, tokens."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for MEASURE.")

    measurements: list[dict] = []
    for t in targets:
        if os.path.isfile(t.resolved_path):
            with open(t.resolved_path, "r", encoding="utf-8", errors="ignore") as f:
                text = f.read()
                words = len(text.split())
                lines = text.count("\n")
                chars = len(text)
                tokens_est = int(words * 1.3)
                measurements.append({
                    "handle": t.handle,
                    "path": t.resolved_path,
                    "bytes": t.size_bytes,
                    "lines": lines,
                    "words": words,
                    "chars": chars,
                    "tokens_est": tokens_est,
                })

    return VerbResult(success=True, data={"measurements": measurements}, targets=targets)


def transform_handler(context: Any, target_ref: str | None = None, operation: str = "", **kwargs) -> VerbResult:
    """Transforms case, trim, or formatting."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for TRANSFORM.")

    target = targets[0]
    try:
        with open(target.resolved_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()

        op = operation.lower()
        if op == "uppercase":
            new_content = content.upper()
        elif op == "lowercase":
            new_content = content.lower()
        elif op == "titlecase":
            new_content = content.title()
        elif op == "strip":
            new_content = "\n".join(l.strip() for l in content.splitlines())
        else:
            new_content = content

        with open(target.resolved_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        return VerbResult(success=True, data={"operation": op, "path": target.resolved_path}, targets=[target])
    except Exception as e:
        return VerbResult(success=False, error=f"Transform failed: {e}")


def merge_handler(context: Any, target_ref: str | None = None, output: str | None = None, **kwargs) -> VerbResult:
    """Merges multiple files or datasets."""
    targets = _extract_target_list(context, target_ref)
    if len(targets) < 2:
        return VerbResult(success=False, error="MERGE requires at least two targets.")

    out_name = output or "merged_output.csv"
    out_path = context.resolver.resolve_path(out_name, context.current_dir)

    all_rows: list[dict] = []
    combined_headers: list[str] = []

    for t in targets:
        h, r = _read_dataset(t)
        for header in h:
            if header not in combined_headers:
                combined_headers.append(header)
        all_rows.extend(r)

    _write_dataset(out_path, combined_headers, all_rows)
    new_t = context.allocate_target(out_path)

    return VerbResult(
        success=True,
        data={"merged_count": len(targets), "total_rows": len(all_rows), "output": out_path},
        targets=[new_t],
    )


def split_handler(context: Any, target_ref: str | None = None, lines_or_chunks: int = 1000, **kwargs) -> VerbResult:
    """Splits target file into chunks."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for SPLIT.")

    target = targets[0]
    out_targets: list[Target] = []

    with open(target.resolved_path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()

    base, ext = os.path.splitext(target.resolved_path)
    chunk_idx = 1
    for i in range(0, len(lines), lines_or_chunks):
        chunk_lines = lines[i : i + lines_or_chunks]
        chunk_path = f"{base}_part_{chunk_idx:03d}{ext}"
        with open(chunk_path, "w", encoding="utf-8") as out:
            out.writelines(chunk_lines)
        t = context.allocate_target(chunk_path)
        out_targets.append(t)
        chunk_idx += 1

    return VerbResult(
        success=True,
        data={"parts_created": len(out_targets), "targets": [t.to_dict() for t in out_targets]},
        targets=out_targets,
    )


def compress_handler(context: Any, target_ref: str | None = None, format: str = "zip", **kwargs) -> VerbResult:
    """Compresses targets into zip or tar.gz."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="No targets to compress.")

    out_name = f"compressed_{targets[0].handle.replace('#', '')}.zip"
    out_path = context.resolver.resolve_path(out_name, context.current_dir)

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for t in targets:
            if os.path.isfile(t.resolved_path):
                zf.write(t.resolved_path, os.path.basename(t.resolved_path))

    new_t = context.allocate_target(out_path)
    return VerbResult(
        success=True,
        data={"archive_path": out_path, "targets_compressed": len(targets)},
        targets=[new_t],
    )


def extract_handler(context: Any, target_ref: str | None = None, destination: str = ".", **kwargs) -> VerbResult:
    """Extracts archive."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target archive not found.")

    target = targets[0]
    dest_path = context.resolver.resolve_path(destination, context.current_dir)
    os.makedirs(dest_path, exist_ok=True)

    extracted_targets: list[Target] = []
    if zipfile.is_zipfile(target.resolved_path):
        with zipfile.ZipFile(target.resolved_path, "r") as zf:
            zf.extractall(dest_path)
            for name in zf.namelist():
                extracted_targets.append(context.allocate_target(os.path.join(dest_path, name)))

    return VerbResult(
        success=True,
        data={"extracted_count": len(extracted_targets), "destination": dest_path},
        targets=extracted_targets,
    )


def convert_handler(context: Any, target_ref: str | None = None, to_format: str = "", **kwargs) -> VerbResult:
    """Converts CSV to JSON or JSON to CSV."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error="Target not found for CONVERT.")

    target = targets[0]
    to_fmt = to_format.lower().lstrip(".")
    headers, rows = _read_dataset(target)

    base, _ = os.path.splitext(target.resolved_path)
    new_path = f"{base}.{to_fmt}"
    _write_dataset(new_path, headers, rows)
    new_t = context.allocate_target(new_path)

    return VerbResult(
        success=True,
        data={"from": target.resolved_path, "to": new_path, "format": to_fmt},
        targets=[new_t],
    )


def generate_handler(context: Any, target_ref: str | None = None, artifact_type: str = "sample_csv", **kwargs) -> VerbResult:
    """Generates sample dataset or files."""
    filename = target_ref or "sample_dataset.csv"
    out_path = context.resolver.resolve_path(filename, context.current_dir)

    rows = [
        {"id": "001", "region": "North", "quarter": "Q1", "revenue": "12500", "units": "42", "status": "APPROVED"},
        {"id": "002", "region": "South", "quarter": "Q1", "revenue": "8900", "units": "31", "status": "PENDING"},
        {"id": "003", "region": "East", "quarter": "Q1", "revenue": "15400", "units": "56", "status": "APPROVED"},
        {"id": "004", "region": "West", "quarter": "Q1", "revenue": "9300", "units": "28", "status": "REVIEW"},
        {"id": "005", "region": "North", "quarter": "Q2", "revenue": "18200", "units": "64", "status": "APPROVED"},
        {"id": "006", "region": "South", "quarter": "Q2", "revenue": "11200", "units": "39", "status": "APPROVED"},
    ]
    _write_dataset(out_path, list(rows[0].keys()), rows)
    t = context.allocate_target(out_path)

    return VerbResult(
        success=True,
        data={"generated": out_path, "rows": len(rows)},
        targets=[t],
    )
