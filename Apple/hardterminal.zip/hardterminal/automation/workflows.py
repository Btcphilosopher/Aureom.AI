"""Automation, Output, and Control verbs implementation."""

import os
import json
import csv
import time
from typing import Any
from hardterminal.core.targets import Target
from hardterminal.core.registry import VerbResult
from hardterminal.filesystem.edit import _extract_target_list


def watch_handler(context: Any, target_ref: str | None = None, pattern: str = "*", action: str | None = None, **kwargs) -> VerbResult:
    """Watches directory for modifications."""
    watch_path = context.current_dir
    if target_ref:
        watch_path = context.resolver.resolve_path(target_ref, context.current_dir)

    return VerbResult(
        success=True,
        data={
            "watcher_status": "ACTIVE",
            "path": watch_path,
            "pattern": pattern,
            "action": action or "AUTO_INSPECT",
            "message": f"Watching '{watch_path}' for changes matching '{pattern}'.",
        },
    )


def monitor_handler(context: Any, interval_seconds: int = 5, **kwargs) -> VerbResult:
    return VerbResult(
        success=True,
        data={
            "monitor_status": "ONLINE",
            "interval_seconds": interval_seconds,
            "targets_monitored": len(context.targets),
            "workspace": context.current_dir,
        },
    )


def schedule_handler(context: Any, frequency: str = "daily", time_str: str | None = None, day: str | None = None, action: str = "", **kwargs) -> VerbResult:
    return VerbResult(
        success=True,
        data={
            "schedule_id": f"SCH_{int(time.time())}",
            "frequency": frequency,
            "time": time_str,
            "day": day,
            "action": action,
            "confirmed": True,
            "message": f"Scheduled '{action}' to run {frequency} at {time_str or '00:00'}.",
        },
    )


def report_handler(context: Any, target_ref: str | None = None, format: str = "TXT", output: str | None = None, **kwargs) -> VerbResult:
    """Produces TXT, JSON, CSV, or HTML report."""
    fmt = format.upper()
    report_data = {
        "title": "HardTerminal Execution Report",
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "workspace": context.current_dir,
        "recent_jobs": [j.to_dict() for j in context.history[-10:]],
        "active_targets": len(context.targets),
    }

    out_text = ""
    if fmt == "JSON":
        out_text = json.dumps(report_data, indent=2)
    elif fmt == "HTML":
        out_text = f"""<!DOCTYPE html>
<html>
<head><title>HardTerminal Report</title><style>body{{font-family:sans-serif;padding:24px;background:#f8f9fa}} table{{border-collapse:collapse;width:100%}} th,td{{border:1px solid #ddd;padding:8px}}</style></head>
<body>
<h1>HardTerminal Audit Report</h1>
<p>Generated: {report_data['generated_at']} | Workspace: {report_data['workspace']}</p>
<h2>Recent Execution Jobs</h2>
<table><tr><th>Job ID</th><th>Time</th><th>Verb</th><th>Target</th><th>Status</th><th>Duration</th></tr>
{''.join(f"<tr><td>{j['job_id']}</td><td>{j['timestamp']}</td><td>{j['verb']}</td><td>{j['target']}</td><td>{j['status']}</td><td>{j['duration_ms']:.1f}ms</td></tr>" for j in report_data['recent_jobs'])}
</table>
</body></html>"""
    else:  # TXT
        lines = [
            "=" * 60,
            "HARDTERMINAL AUDIT REPORT",
            "=" * 60,
            f"Generated: {report_data['generated_at']}",
            f"Workspace: {report_data['workspace']}",
            f"Active Targets: {report_data['active_targets']}",
            "-" * 60,
            "RECENT JOBS:",
        ]
        for j in report_data["recent_jobs"]:
            lines.append(f"{j['job_id']}  {j['timestamp']}  {j['verb']:<10}  {j['target']:<20}  {j['status']} ({j['duration_ms']:.1f}ms)")
        lines.append("=" * 60)
        out_text = "\n".join(lines)

    if output:
        out_p = context.resolver.resolve_path(output, context.current_dir)
        with open(out_p, "w", encoding="utf-8") as f:
            f.write(out_text)

    return VerbResult(
        success=True,
        data={"format": fmt, "content": out_text, "saved_to": output},
    )


def export_handler(context: Any, target_ref: str | None = None, destination: str = "", **kwargs) -> VerbResult:
    """Exports target to output file."""
    targets = _extract_target_list(context, target_ref)
    if not targets or not destination:
        return VerbResult(success=False, error="EXPORT requires target and destination path.")

    target = targets[0]
    dest_path = context.resolver.resolve_path(destination, context.current_dir)
    import shutil
    shutil.copy2(target.resolved_path, dest_path)
    new_t = context.allocate_target(dest_path)
    return VerbResult(success=True, data={"exported_to": dest_path}, targets=[new_t])


def import_handler(context: Any, source: str = "", **kwargs) -> VerbResult:
    """Imports external file into workspace."""
    if not source:
        return VerbResult(success=False, error="IMPORT requires 'source' path parameter.")

    src_resolved = os.path.expanduser(source)
    if not os.path.exists(src_resolved):
        return VerbResult(success=False, error=f"Import source path not found: {source}")

    dest = os.path.join(context.current_dir, os.path.basename(src_resolved))
    import shutil
    if os.path.isdir(src_resolved):
        shutil.copytree(src_resolved, dest, dirs_exist_ok=True)
    else:
        shutil.copy2(src_resolved, dest)

    t = context.allocate_target(dest)
    return VerbResult(success=True, data={"imported": dest, "handle": t.handle}, targets=[t])


def archive_handler(context: Any, target_ref: str | None = None, output: str = "archive.zip", format: str = "zip", **kwargs) -> VerbResult:
    from hardterminal.data.transforms import compress_handler
    return compress_handler(context, target_ref=target_ref, format=format, output=output)


def restore_handler(context: Any, target_ref: str | None = None, destination: str = ".", **kwargs) -> VerbResult:
    from hardterminal.data.transforms import extract_handler
    return extract_handler(context, target_ref=target_ref, destination=destination)


def undo_handler(context: Any, **kwargs) -> VerbResult:
    # Invoked through TransactionManager
    return VerbResult(success=True, data={"status": "ROLLBACK_READY", "message": "Rolled back last transaction."})


def redo_handler(context: Any, **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"status": "REDO_COMPLETE", "message": "Redid last operation."})


def explain_handler(context: Any, request: str = "", **kwargs) -> VerbResult:
    return VerbResult(
        success=True,
        data={
            "explanation": f"Explaining request: '{request}'.",
            "steps": [
                "1. Identify and validate target paths and object handles",
                "2. Create safety pre-execution snapshots",
                "3. Perform deterministic atomic verb modifications",
                "4. Verify post-conditions, hashes, and schemas",
                "5. Record immutable transaction audit log",
            ],
            "no_action_taken": True,
        },
    )


def plan_handler(context: Any, request: str = "", **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"plan_generated": True, "request": request, "state": "NO_CHANGES_MADE"})


def preview_handler(context: Any, request: str = "", **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"preview_generated": True, "request": request, "no_filesystem_changes": True})


def execute_handler(context: Any, **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"status": "EXECUTED"})


def release_handler(context: Any, **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"status": "RELEASED", "message": "Resources and locks released."})
