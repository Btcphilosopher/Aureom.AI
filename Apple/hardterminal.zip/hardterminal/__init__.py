"""HardTerminal — Industrial-grade Python Verb Kernel for macOS.

Transforms plain-language requests into deterministic, inspectable execution plans.
"""

from hardterminal.core.verbs import VerbName, VerbCategory
from hardterminal.core.registry import (
    VerbRegistry,
    VerbDefinition,
    VerbParameter,
    VerbResult,
    default_registry,
)
from hardterminal.core.targets import (
    Target,
    TargetCollection,
    TargetType,
    TargetHandle,
    TargetResolver,
)
from hardterminal.core.intents import Intent, ExecutionRequest
from hardterminal.core.context import WorkspaceContext
from hardterminal.planning.planner import ExecutionPlan, PlanGenerator
from hardterminal.planning.graph import ActionGraph, ActionNode, ActionDependency, ActionStatus
from hardterminal.safety.risk import RiskLevel, RiskEngine
from hardterminal.safety.policies import SafetyController, PolicyEngine
from hardterminal.execution.executor import GraphExecutor, ExecutionReport
from hardterminal.execution.transactions import Transaction, TransactionManager
from hardterminal.parser.compiler import IntentCompiler
from hardterminal.parser.parser import HardGrammarParser

__version__ = "1.0.0"


class HardTerminal:
    """Primary programmatic entry point for HardTerminal."""

    def __init__(self, workspace_path: str = "."):
        self.registry = default_registry()
        self.context = WorkspaceContext(root_dir=workspace_path)
        self.compiler = IntentCompiler(self.registry)
        self.parser = HardGrammarParser()
        self.risk_engine = RiskEngine()
        self.safety = SafetyController()
        self.planner = PlanGenerator(self.registry, self.risk_engine, self.safety)
        self.transactions = TransactionManager(self.context.root_dir)
        self.executor = GraphExecutor(self.registry, self.safety, self.transactions)

    def interpret(self, raw_input: str) -> Intent:
        """Deterministically compile plain language or grammar into a verified Intent."""
        return self.compiler.compile(raw_input, self.context)

    def plan(self, intent_or_request: Intent | ExecutionRequest) -> ExecutionPlan:
        """Create a validated, dependency-resolved ActionGraph execution plan."""
        return self.planner.create_plan(intent_or_request, self.context)

    def preview(self, plan: ExecutionPlan) -> dict:
        """Produce an inspectable preview of actions without applying side-effects."""
        return self.planner.preview_plan(plan, self.context)

    def execute(self, plan: ExecutionPlan, dry_run: bool = False) -> ExecutionReport:
        """Execute the action graph through safety gates, transactions, and verification."""
        report = self.executor.execute_plan(plan, self.context, dry_run=dry_run)
        self.context.record_job(plan, report)
        return report

    def verify(self, report: ExecutionReport) -> dict:
        """Verify the integrity and state after execution."""
        return self.executor.verify_report(report, self.context)

    def execute_verb(self, verb_name: str | VerbName, target: str | None = None, **parameters) -> VerbResult:
        """Directly and deterministically execute a registered verb."""
        verb_str = verb_name.value if isinstance(verb_name, VerbName) else str(verb_name).upper()
        intent = Intent(verb=verb_str, target=target, parameters=parameters)
        plan = self.plan(intent)
        report = self.execute(plan, dry_run=False)
        if report.failed_nodes:
            first_err = report.node_results.get(report.failed_nodes[0])
            err_msg = first_err.error if first_err else "Execution failed"
            return VerbResult(success=False, error=err_msg, data=report.to_dict())

        merged_data = report.to_dict()
        for nr in report.node_results.values():
            if nr.data and isinstance(nr.data, dict):
                merged_data.update(nr.data)

        return VerbResult(success=True, data=merged_data, targets=report.affected_targets)

    def undo(self) -> VerbResult:
        """Rollback the last transaction."""
        return self.transactions.rollback_last(self.context)
