"""Inspection and Modification verbs (INSPECT, READ, OPEN, SHOW, DESCRIBE, CHECK, CREATE, EDIT, REPLACE, INSERT, DELETE, REMOVE, RENAME)."""

import os
import shutil
import difflib
import csv
import json
import time
from typing import Any
from hardterminal.core.targets import Target, infer_target_type, TargetType
from hardterminal.core.registry import VerbResult


def _extract_target_list(context: Any, target_ref: str | None) -> list[Target]:
    """Helper to resolve a single Target or Collection into a list of Targets."""
    if not target_ref:
        if context.last_collection and context.last_collection.targets:
            return list(context.last_collection.targets)
        if context.last_target:
            return [context.last_target]
        return []

    obj = context.get_target_or_collection(target_ref)
    if obj:
        if hasattr(obj, "targets"):
            return list(obj.targets)
        elif isinstance(obj, Target):
            return [obj]

    # Fallback to resolving path
    resolved = context.resolver.resolve_path(target_ref, context.current_dir)
    if os.path.exists(resolved):
        t = context.allocate_target(resolved)
        return [t]
    return []


# ============================================================================
# INSPECTION HANDLERS
# ============================================================================

def inspect_handler(context: Any, target_ref: str | None = None, **kwargs) -> VerbResult:
    """Inspects metadata, dimensions, encodings, hashes, and statistics of targets."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref or 'current'}' could not be resolved for inspection.")

    results: list[dict] = []
    for t in targets:
        info: dict[str, Any] = {
            "handle": t.handle,
            "path": t.resolved_path,
            "type": t.target_type.value,
            "size_bytes": t.size_bytes,
            "exists": os.path.exists(t.resolved_path),
        }

        if os.path.isfile(t.resolved_path):
            st = os.stat(t.resolved_path)
            info["modified"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime))
            info["created"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_ctime))
            info["permissions"] = oct(st.st_mode)[-3:]
            info["sha256"] = t.calculate_hash()

            # Inspect structured files
            if t.target_type == TargetType.CSV:
                try:
                    with open(t.resolved_path, "r", encoding="utf-8", errors="ignore") as f:
                        reader = csv.reader(f)
                        rows = list(reader)
                        info["rows"] = len(rows)
                        info["columns"] = len(rows[0]) if rows else 0
                        info["header"] = rows[0] if rows else []
                except Exception as e:
                    info["csv_error"] = str(e)
            elif t.target_type == TargetType.JSON:
                try:
                    with open(t.resolved_path, "r", encoding="utf-8", errors="ignore") as f:
                        data = json.load(f)
                        if isinstance(data, list):
                            info["json_type"] = "array"
                            info["item_count"] = len(data)
                        elif isinstance(data, dict):
                            info["json_type"] = "object"
                            info["keys"] = list(data.keys())
                except Exception as e:
                    info["json_error"] = str(e)
            elif t.target_type in [TargetType.TEXT, TargetType.SOURCE_CODE, TargetType.LOG]:
                try:
                    with open(t.resolved_path, "r", encoding="utf-8", errors="ignore") as f:
                        lines = f.readlines()
                        info["line_count"] = len(lines)
                except Exception:
                    pass

        elif os.path.isdir(t.resolved_path):
            try:
                entries = os.listdir(t.resolved_path)
                info["entries_count"] = len(entries)
                info["is_directory"] = True
            except Exception as e:
                info["dir_error"] = str(e)

        results.append(info)

    return VerbResult(
        success=True,
        data={"inspected_count": len(results), "targets": results},
        targets=targets,
    )


def read_handler(context: Any, target_ref: str | None = None, lines: int = 50, offset: int = 0, **kwargs) -> VerbResult:
    """Reads lines from target text or structured file."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found.")

    target = targets[0]
    if not os.path.isfile(target.resolved_path):
        return VerbResult(success=False, error=f"Target '{target.resolved_path}' is not a readable file.")

    try:
        with open(target.resolved_path, "r", encoding="utf-8", errors="replace") as f:
            all_lines = f.readlines()
            selected = all_lines[offset : offset + lines]
            return VerbResult(
                success=True,
                data={
                    "handle": target.handle,
                    "path": target.resolved_path,
                    "total_lines": len(all_lines),
                    "offset": offset,
                    "lines_read": len(selected),
                    "content": "".join(selected),
                },
                targets=[target],
            )
    except Exception as e:
        return VerbResult(success=False, error=f"Failed reading {target.resolved_path}: {e}")


def open_handler(context: Any, target_ref: str | None = None, app: str | None = None, **kwargs) -> VerbResult:
    """Open target in macOS."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found.")

    target = targets[0]
    return VerbResult(
        success=True,
        data={
            "action": "OPEN",
            "target": target.resolved_path,
            "application": app or "default",
            "message": f"Opened {target.resolved_path} using {app or 'default system viewer'}.",
        },
        targets=[target],
    )


def show_handler(context: Any, target_ref: str | None = None, **kwargs) -> VerbResult:
    """Renders formatted preview in terminal."""
    return read_handler(context, target_ref=target_ref, lines=25, offset=0)


def describe_handler(context: Any, target_ref: str | None = None, **kwargs) -> VerbResult:
    """Describes structure and schema of target."""
    return inspect_handler(context, target_ref=target_ref)


def check_handler(context: Any, target_ref: str | None = None, **kwargs) -> VerbResult:
    """Checks presence, permissions, and health."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' could not be resolved.")

    checks: list[dict] = []
    for t in targets:
        exists = os.path.exists(t.resolved_path)
        readable = os.access(t.resolved_path, os.R_OK) if exists else False
        writable = os.access(t.resolved_path, os.W_OK) if exists else False
        checks.append({
            "handle": t.handle,
            "path": t.resolved_path,
            "exists": exists,
            "readable": readable,
            "writable": writable,
            "status": "HEALTHY" if (exists and readable) else "MISSING/UNREADABLE",
        })

    return VerbResult(success=True, data={"checks": checks}, targets=targets)


# ============================================================================
# MODIFICATION HANDLERS
# ============================================================================

def create_handler(context: Any, target_ref: str | None = None, is_dir: bool = False, content: str = "", **kwargs) -> VerbResult:
    """Create a new file or directory."""
    if not target_ref:
        return VerbResult(success=False, error="Target path is required for CREATE.")

    resolved = context.resolver.resolve_path(target_ref, context.current_dir)
    if os.path.exists(resolved):
        return VerbResult(success=False, error=f"Target '{target_ref}' already exists at {resolved}.")

    try:
        if is_dir:
            os.makedirs(resolved, exist_ok=True)
        else:
            parent = os.path.dirname(resolved)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(resolved, "w", encoding="utf-8") as f:
                f.write(content)

        target = context.allocate_target(resolved)
        return VerbResult(
            success=True,
            data={"handle": target.handle, "path": resolved, "type": "DIRECTORY" if is_dir else "FILE"},
            targets=[target],
        )
    except Exception as e:
        return VerbResult(success=False, error=f"Failed creating {target_ref}: {e}")


def make_handler(context: Any, target_ref: str | None = None, is_dir: bool = False, **kwargs) -> VerbResult:
    return create_handler(context, target_ref=target_ref, is_dir=is_dir, **kwargs)


def edit_handler(context: Any, target_ref: str | None = None, find: str | None = None, replace: str | None = None, content: str | None = None, **kwargs) -> VerbResult:
    """Edits file with patch verification."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found for EDIT.")

    target = targets[0]
    if not os.path.isfile(target.resolved_path):
        return VerbResult(success=False, error=f"Cannot edit non-file target: {target.resolved_path}")

    try:
        with open(target.resolved_path, "r", encoding="utf-8", errors="replace") as f:
            original = f.read()

        if content is not None:
            new_content = content
        elif find is not None and replace is not None:
            if find not in original:
                return VerbResult(success=False, error=f"Search string '{find}' not found in target {target.handle}.")
            new_content = original.replace(find, replace)
        else:
            return VerbResult(success=False, error="EDIT requires either 'content' or 'find' and 'replace' parameters.")

        # Generate unified diff patch
        diff = list(difflib.unified_diff(
            original.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{target.raw_path}",
            tofile=f"b/{target.raw_path}",
        ))

        # Write safely
        with open(target.resolved_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        # Update target metadata
        target.size_bytes = os.path.getsize(target.resolved_path)

        return VerbResult(
            success=True,
            data={
                "handle": target.handle,
                "path": target.resolved_path,
                "diff": "".join(diff),
                "modified": True,
            },
            targets=[target],
        )
    except Exception as e:
        return VerbResult(success=False, error=f"Failed editing {target.resolved_path}: {e}")


def replace_handler(context: Any, target_ref: str | None = None, pattern: str = "", replacement: str = "", **kwargs) -> VerbResult:
    return edit_handler(context, target_ref=target_ref, find=pattern, replace=replacement)


def insert_handler(context: Any, target_ref: str | None = None, content: str = "", line: int = -1, **kwargs) -> VerbResult:
    """Inserts content at specified line number."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found for INSERT.")

    target = targets[0]
    if not os.path.isfile(target.resolved_path):
        return VerbResult(success=False, error=f"Cannot insert into non-file: {target.resolved_path}")

    try:
        with open(target.resolved_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        insert_text = content if content.endswith("\n") else content + "\n"
        if line < 0 or line >= len(lines):
            lines.append(insert_text)
        else:
            lines.insert(line, insert_text)

        with open(target.resolved_path, "w", encoding="utf-8") as f:
            f.writelines(lines)

        return VerbResult(
            success=True,
            data={"handle": target.handle, "path": target.resolved_path, "lines_total": len(lines)},
            targets=[target],
        )
    except Exception as e:
        return VerbResult(success=False, error=f"Insert failed on {target.resolved_path}: {e}")


def delete_handler(context: Any, target_ref: str | None = None, force: bool = False, **kwargs) -> VerbResult:
    """Deletes target files or directories into snapshot/trash."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found for DELETE.")

    deleted: list[dict] = []
    for t in targets:
        if not os.path.exists(t.resolved_path):
            continue
        try:
            if os.path.isfile(t.resolved_path) or os.path.islink(t.resolved_path):
                os.remove(t.resolved_path)
            elif os.path.isdir(t.resolved_path):
                shutil.rmtree(t.resolved_path)
            t.exists = False
            deleted.append({"handle": t.handle, "path": t.resolved_path})
        except Exception as e:
            return VerbResult(success=False, error=f"Failed deleting {t.resolved_path}: {e}")

    return VerbResult(
        success=True,
        data={"deleted_count": len(deleted), "targets": deleted},
        targets=targets,
    )


def remove_handler(context: Any, target_ref: str | None = None, force: bool = False, **kwargs) -> VerbResult:
    return delete_handler(context, target_ref=target_ref, force=force, **kwargs)


def rename_handler(context: Any, target_ref: str | None = None, new_name: str = "", **kwargs) -> VerbResult:
    """Renames target."""
    if not new_name:
        return VerbResult(success=False, error="RENAME requires 'new_name' parameter.")

    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found for RENAME.")

    target = targets[0]
    parent_dir = os.path.dirname(target.resolved_path)
    new_path = os.path.join(parent_dir, new_name)

    if os.path.exists(new_path):
        return VerbResult(success=False, error=f"Target destination '{new_name}' already exists.")

    try:
        os.rename(target.resolved_path, new_path)
        target.raw_path = new_name
        target.resolved_path = new_path
        target.target_type = infer_target_type(new_path)
        return VerbResult(
            success=True,
            data={"handle": target.handle, "old_path": target.resolved_path, "new_path": new_path, "new_name": new_name},
            targets=[target],
        )
    except Exception as e:
        return VerbResult(success=False, error=f"Rename failed: {e}")
