"""Validation and Hashing verbs (HASH, COMPARE, DIFF, VALIDATE, VERIFY)."""

import os
import hashlib
import difflib
import json
import csv
from typing import Any
from hardterminal.core.targets import Target, TargetType
from hardterminal.core.registry import VerbResult
from hardterminal.filesystem.edit import _extract_target_list


def hash_handler(context: Any, target_ref: str | None = None, algorithm: str = "sha256", **kwargs) -> VerbResult:
    """Computes cryptographic hashes for targets."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found for HASH.")

    hashes: list[dict] = []
    for t in targets:
        if not os.path.isfile(t.resolved_path):
            continue

        algo = algorithm.lower()
        if algo == "md5":
            hasher = hashlib.md5()
        elif algo == "sha1":
            hasher = hashlib.sha1()
        else:
            hasher = hashlib.sha256()

        try:
            with open(t.resolved_path, "rb") as f:
                while chunk := f.read(65536):
                    hasher.update(chunk)
            digest = hasher.hexdigest()
            hashes.append({"handle": t.handle, "path": t.resolved_path, "algorithm": algo, "hash": digest})
        except Exception as e:
            return VerbResult(success=False, error=f"Hash calculation failed for {t.resolved_path}: {e}")

    return VerbResult(success=True, data={"hashes": hashes}, targets=targets)


def compare_handler(context: Any, target_ref: str | None = None, with_target: str | None = None, **kwargs) -> VerbResult:
    """Compares two targets for byte equality and metadata equality."""
    if not with_target:
        return VerbResult(success=False, error="COMPARE requires a 'with_target' parameter.")

    src_targets = _extract_target_list(context, target_ref)
    other_targets = _extract_target_list(context, with_target)

    if not src_targets or not other_targets:
        return VerbResult(success=False, error=f"Both targets must be resolved. Got {src_targets} and {other_targets}.")

    t1, t2 = src_targets[0], other_targets[0]

    if not os.path.exists(t1.resolved_path) or not os.path.exists(t2.resolved_path):
        return VerbResult(success=False, error="One or both targets do not exist on disk.")

    size_match = t1.size_bytes == t2.size_bytes
    hash1 = t1.calculate_hash()
    hash2 = t2.calculate_hash()
    exact_match = (hash1 == hash2) if (hash1 and hash2) else False

    return VerbResult(
        success=True,
        data={
            "target_1": {"handle": t1.handle, "path": t1.resolved_path, "size": t1.size_bytes, "sha256": hash1},
            "target_2": {"handle": t2.handle, "path": t2.resolved_path, "size": t2.size_bytes, "sha256": hash2},
            "identical": exact_match,
            "size_match": size_match,
        },
        targets=[t1, t2],
    )


def diff_handler(context: Any, target_ref: str | None = None, with_target: str | None = None, **kwargs) -> VerbResult:
    """Generates unified diff between two text targets."""
    if not with_target:
        return VerbResult(success=False, error="DIFF requires a 'with_target' parameter.")

    src_targets = _extract_target_list(context, target_ref)
    other_targets = _extract_target_list(context, with_target)

    if not src_targets or not other_targets:
        return VerbResult(success=False, error="Failed resolving targets for DIFF.")

    t1, t2 = src_targets[0], other_targets[0]

    try:
        with open(t1.resolved_path, "r", encoding="utf-8", errors="replace") as f1:
            lines1 = f1.readlines()
        with open(t2.resolved_path, "r", encoding="utf-8", errors="replace") as f2:
            lines2 = f2.readlines()

        diff_lines = list(difflib.unified_diff(
            lines1,
            lines2,
            fromfile=t1.resolved_path,
            tofile=t2.resolved_path,
        ))

        return VerbResult(
            success=True,
            data={
                "target_1": t1.resolved_path,
                "target_2": t2.resolved_path,
                "diff": "".join(diff_lines),
                "differences_found": len(diff_lines) > 0,
            },
            targets=[t1, t2],
        )
    except Exception as e:
        return VerbResult(success=False, error=f"Diff generation failed: {e}")


def validate_handler(context: Any, target_ref: str | None = None, schema: str | None = None, **kwargs) -> VerbResult:
    """Validates syntax and integrity of JSON, CSV, or YAML targets."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found for VALIDATE.")

    reports: list[dict] = []
    all_valid = True

    for t in targets:
        p = t.resolved_path
        status = "VALID"
        err_msg = None

        if t.target_type == TargetType.JSON or p.endswith(".json"):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    json.load(f)
            except Exception as e:
                status = "INVALID"
                err_msg = str(e)
                all_valid = False
        elif t.target_type == TargetType.CSV or p.endswith(".csv"):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    reader = csv.reader(f)
                    row_len = None
                    for i, r in enumerate(reader):
                        if row_len is None:
                            row_len = len(r)
                        elif len(r) != row_len and len(r) > 0:
                            status = "WARNING_INCONSISTENT_COLUMNS"
                            err_msg = f"Row {i+1} has {len(r)} columns; expected {row_len}"
            except Exception as e:
                status = "INVALID"
                err_msg = str(e)
                all_valid = False

        reports.append({"handle": t.handle, "path": p, "status": status, "error": err_msg})

    return VerbResult(success=all_valid, data={"validation_reports": reports, "all_valid": all_valid}, targets=targets)


def verify_handler(context: Any, target_ref: str | None = None, **kwargs) -> VerbResult:
    """Post-execution verification."""
    targets = _extract_target_list(context, target_ref)
    verified: list[dict] = []
    success = True

    for t in targets:
        exists = os.path.exists(t.resolved_path)
        if not exists and t.exists:
            success = False
        verified.append({
            "handle": t.handle,
            "path": t.resolved_path,
            "verified": exists,
            "size_bytes": os.path.getsize(t.resolved_path) if exists else 0,
        })

    return VerbResult(success=success, data={"verified_targets": verified, "verified": success}, targets=targets)
