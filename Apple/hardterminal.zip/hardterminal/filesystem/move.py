"""MOVE, COPY, and DUPLICATE filesystem handlers."""

import os
import shutil
from typing import Any
from hardterminal.core.targets import Target, infer_target_type
from hardterminal.core.registry import VerbResult
from hardterminal.filesystem.edit import _extract_target_list


def move_handler(context: Any, target_ref: str | None = None, destination: str = "", **kwargs) -> VerbResult:
    """Moves one or more filesystem objects to destination directory or target path."""
    if not destination:
        return VerbResult(success=False, error="MOVE requires a 'destination' parameter.")

    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' could not be resolved for MOVE.")

    dest_resolved = context.resolver.resolve_path(destination, context.current_dir)
    moved: list[dict] = []

    # If moving multiple files, destination must be a directory
    if len(targets) > 1 and not os.path.exists(dest_resolved):
        os.makedirs(dest_resolved, exist_ok=True)

    for t in targets:
        src = t.resolved_path
        if not os.path.exists(src):
            continue

        if os.path.isdir(dest_resolved):
            target_dest = os.path.join(dest_resolved, os.path.basename(src))
        else:
            target_dest = dest_resolved

        # Ensure parent exists
        parent = os.path.dirname(target_dest)
        if parent:
            os.makedirs(parent, exist_ok=True)

        try:
            shutil.move(src, target_dest)
            t.resolved_path = target_dest
            t.raw_path = target_dest
            t.target_type = infer_target_type(target_dest)
            moved.append({"handle": t.handle, "from": src, "to": target_dest})
        except Exception as e:
            return VerbResult(success=False, error=f"Failed moving {src} to {target_dest}: {e}")

    return VerbResult(
        success=True,
        data={"moved_count": len(moved), "destination": dest_resolved, "moves": moved},
        targets=targets,
    )


def copy_handler(context: Any, target_ref: str | None = None, destination: str = "", **kwargs) -> VerbResult:
    """Copies targets to destination."""
    if not destination:
        return VerbResult(success=False, error="COPY requires a 'destination' parameter.")

    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' could not be resolved for COPY.")

    dest_resolved = context.resolver.resolve_path(destination, context.current_dir)
    copied_targets: list[Target] = []

    if len(targets) > 1 and not os.path.exists(dest_resolved):
        os.makedirs(dest_resolved, exist_ok=True)

    for t in targets:
        src = t.resolved_path
        if not os.path.exists(src):
            continue

        if os.path.isdir(dest_resolved):
            target_dest = os.path.join(dest_resolved, os.path.basename(src))
        else:
            target_dest = dest_resolved

        parent = os.path.dirname(target_dest)
        if parent:
            os.makedirs(parent, exist_ok=True)

        try:
            if os.path.isdir(src):
                if os.path.exists(target_dest):
                    shutil.rmtree(target_dest)
                shutil.copytree(src, target_dest)
            else:
                shutil.copy2(src, target_dest)

            new_target = context.allocate_target(target_dest)
            copied_targets.append(new_target)
        except Exception as e:
            return VerbResult(success=False, error=f"Failed copying {src} to {target_dest}: {e}")

    return VerbResult(
        success=True,
        data={"copied_count": len(copied_targets), "destination": dest_resolved},
        targets=copied_targets,
    )


def duplicate_handler(context: Any, target_ref: str | None = None, suffix: str = "-copy", **kwargs) -> VerbResult:
    """Duplicates target in place with suffix."""
    targets = _extract_target_list(context, target_ref)
    if not targets:
        return VerbResult(success=False, error=f"Target '{target_ref}' not found for DUPLICATE.")

    duplicated: list[Target] = []
    for t in targets:
        src = t.resolved_path
        if not os.path.exists(src):
            continue

        base, ext = os.path.splitext(src)
        dup_path = f"{base}{suffix}{ext}"
        counter = 1
        while os.path.exists(dup_path):
            dup_path = f"{base}{suffix}_{counter}{ext}"
            counter += 1

        try:
            if os.path.isdir(src):
                shutil.copytree(src, dup_path)
            else:
                shutil.copy2(src, dup_path)

            new_t = context.allocate_target(dup_path)
            duplicated.append(new_t)
        except Exception as e:
            return VerbResult(success=False, error=f"Duplicate failed for {src}: {e}")

    return VerbResult(
        success=True,
        data={"duplicated_count": len(duplicated), "targets": [t.to_dict() for t in duplicated]},
        targets=duplicated,
    )
