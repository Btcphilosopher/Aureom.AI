"""FIND, SEARCH, and LIST verb implementations."""

import os
import fnmatch
import time
from typing import Any
from hardterminal.core.targets import Target
from hardterminal.core.registry import VerbResult


def _parse_size_bytes(size_str: str) -> tuple[str, int]:
    """Parse comparison like '> 100 MB' or '< 10KB' into operator and integer bytes."""
    size_str = size_str.strip()
    op = ">"
    if size_str.startswith(">="):
        op, size_str = ">=", size_str[2:]
    elif size_str.startswith("<="):
        op, size_str = "<=", size_str[2:]
    elif size_str.startswith(">"):
        op, size_str = ">", size_str[1:]
    elif size_str.startswith("<"):
        op, size_str = "<", size_str[1:]
    elif size_str.startswith("="):
        op, size_str = "==", size_str[1:]

    size_str = size_str.strip().upper()
    multiplier = 1
    if size_str.endswith("GB"):
        multiplier = 1024 * 1024 * 1024
        size_str = size_str[:-2]
    elif size_str.endswith("MB"):
        multiplier = 1024 * 1024
        size_str = size_str[:-2]
    elif size_str.endswith("KB"):
        multiplier = 1024
        size_str = size_str[:-2]
    elif size_str.endswith("B"):
        multiplier = 1
        size_str = size_str[:-1]

    try:
        val = float(size_str.strip())
        return op, int(val * multiplier)
    except ValueError:
        return op, 0


def _parse_time_seconds(time_str: str) -> tuple[str, float]:
    """Parse time filters like '> 180 days' or '< 2 hours'."""
    time_str = time_str.strip().lower()
    op = ">"
    if time_str.startswith(">"):
        op, time_str = ">", time_str[1:]
    elif time_str.startswith("<"):
        op, time_str = "<", time_str[1:]

    time_str = time_str.strip()
    seconds = 0.0
    parts = time_str.split()
    if len(parts) >= 2:
        try:
            val = float(parts[0])
            unit = parts[1]
            if "day" in unit:
                seconds = val * 86400
            elif "hour" in unit:
                seconds = val * 3600
            elif "min" in unit:
                seconds = val * 60
            elif "sec" in unit:
                seconds = val
            elif "month" in unit:
                seconds = val * 30 * 86400
            elif "year" in unit:
                seconds = val * 365 * 86400
        except ValueError:
            pass
    return op, seconds


def find_handler(
    context: Any,
    target_ref: str | None = None,
    pattern: str | None = None,
    extension: str | None = None,
    size: str | None = None,
    modified: str | None = None,
    created: str | None = None,
    content: str | None = None,
    max_depth: int = 10,
    **kwargs,
) -> VerbResult:
    """Recursively find files matching patterns, sizes, dates, and contents."""
    search_dir = context.current_dir
    if target_ref and not target_ref.startswith("#"):
        search_dir = context.resolver.resolve_path(target_ref, context.current_dir)

    if not os.path.exists(search_dir):
        return VerbResult(success=False, error=f"Target directory not found: {search_dir}")

    matches: list[Target] = []
    current_time = time.time()

    # Pre-parse filters
    size_op, size_val = _parse_size_bytes(size) if size else (None, 0)
    mod_op, mod_val = _parse_time_seconds(modified) if modified else (None, 0.0)

    # Normalize pattern / extension
    glob_pat = pattern or "*"
    if extension:
        ext_clean = extension.lstrip(".")
        if glob_pat == "*":
            glob_pat = f"*.{ext_clean}"
        elif not glob_pat.endswith(f".{ext_clean}"):
            glob_pat = f"{glob_pat}.{ext_clean}"

    base_depth = len(search_dir.rstrip(os.sep).split(os.sep))

    for root, dirs, files in os.walk(search_dir):
        # Exclude hidden directories and node_modules/.git for performance
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ["node_modules", ".git", "__pycache__", "dist"]]
        cur_depth = len(root.rstrip(os.sep).split(os.sep)) - base_depth
        if cur_depth > max_depth:
            dirs[:] = []
            continue

        for filename in files:
            if filename.startswith("."):
                continue

            if not fnmatch.fnmatch(filename, glob_pat):
                continue

            full_path = os.path.join(root, filename)
            try:
                st = os.stat(full_path)
            except Exception:
                continue

            # Size filter
            if size_op:
                if size_op == ">" and not (st.st_size > size_val):
                    continue
                if size_op == ">=" and not (st.st_size >= size_val):
                    continue
                if size_op == "<" and not (st.st_size < size_val):
                    continue
                if size_op == "<=" and not (st.st_size <= size_val):
                    continue
                if size_op == "==" and not (st.st_size == size_val):
                    continue

            # Modified date filter
            if mod_op:
                age_seconds = current_time - st.st_mtime
                if mod_op == ">" and not (age_seconds > mod_val):
                    continue
                if mod_op == "<" and not (age_seconds < mod_val):
                    continue

            # Content search filter
            if content:
                try:
                    with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
                        if content not in f.read(1024 * 1024):  # limit 1MB inspect
                            continue
                except Exception:
                    continue

            target = context.allocate_target(full_path)
            matches.append(target)

    collection = context.allocate_collection(
        matches,
        description=f"Found {len(matches)} matches in {search_dir} (pattern='{glob_pat}')",
        source_verb="FIND"
    )

    return VerbResult(
        success=True,
        data={
            "matches": len(matches),
            "collection_handle": collection.handle,
            "search_root": search_dir,
            "pattern": glob_pat,
            "targets": [t.to_dict() for t in matches[:50]],  # cap summary list
        },
        targets=matches,
    )


def search_handler(context: Any, target_ref: str | None = None, query: str = "", **kwargs) -> VerbResult:
    """Search for query string across filenames or contents."""
    return find_handler(context, target_ref=target_ref, content=query, pattern=f"*{query}*" if not query else "*")


def list_handler(context: Any, target_ref: str | None = None, detailed: bool = True, **kwargs) -> VerbResult:
    """List objects in current directory or target path."""
    target_path = context.current_dir
    if target_ref:
        target_path = context.resolver.resolve_path(target_ref, context.current_dir)

    if not os.path.exists(target_path):
        return VerbResult(success=False, error=f"Path not found: {target_path}")

    items: list[dict] = []
    allocated: list[Target] = []

    try:
        entries = sorted(os.listdir(target_path))
        for entry in entries:
            full_p = os.path.join(target_path, entry)
            t = context.allocate_target(full_p)
            allocated.append(t)
            items.append({
                "handle": t.handle,
                "name": entry,
                "type": t.target_type.value,
                "size_bytes": t.size_bytes,
                "is_dir": os.path.isdir(full_p),
            })
    except Exception as e:
        return VerbResult(success=False, error=f"Failed to list directory {target_path}: {e}")

    collection = context.allocate_collection(allocated, description=f"List of {len(items)} items in {target_path}", source_verb="LIST")

    return VerbResult(
        success=True,
        data={
            "collection_handle": collection.handle,
            "count": len(items),
            "path": target_path,
            "items": items,
        },
        targets=allocated,
    )
