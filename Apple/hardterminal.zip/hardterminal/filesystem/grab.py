"""GRAB verb implementation — the fundamental acquisition operation."""

import os
import fnmatch
from typing import Any
from hardterminal.core.targets import Target
from hardterminal.core.registry import VerbResult


def grab_handler(context: Any, target_ref: str | None = None, pattern: str | None = None, **kwargs) -> VerbResult:
    """Acquires one or more filesystem objects into a numbered Target Collection."""
    if not target_ref and not pattern:
        target_ref = context.current_dir

    acquired_targets: list[Target] = []

    # Check if target_ref is an existing handle or context reference
    existing = context.get_target_or_collection(target_ref)
    if existing:
        if hasattr(existing, "targets"):
            acquired_targets = list(existing.targets)
        elif isinstance(existing, Target):
            acquired_targets = [existing]

    if not acquired_targets and target_ref:
        resolved = context.resolver.resolve_path(target_ref, context.current_dir)
        if os.path.isfile(resolved):
            t = context.allocate_target(resolved)
            acquired_targets.append(t)
        elif os.path.isdir(resolved):
            # Grab items inside directory
            try:
                for entry in sorted(os.listdir(resolved)):
                    if entry.startswith("."):
                        continue
                    if pattern and not fnmatch.fnmatch(entry, pattern):
                        continue
                    full_p = os.path.join(resolved, entry)
                    t = context.allocate_target(full_p)
                    acquired_targets.append(t)
            except Exception as e:
                return VerbResult(success=False, error=f"Failed to grab items from {target_ref}: {e}")
        else:
            # Try wildcard glob
            dir_name = os.path.dirname(resolved) or context.current_dir
            base_pattern = os.path.basename(resolved)
            if os.path.isdir(dir_name):
                for entry in sorted(os.listdir(dir_name)):
                    if fnmatch.fnmatch(entry, base_pattern):
                        t = context.allocate_target(os.path.join(dir_name, entry))
                        acquired_targets.append(t)

    if not acquired_targets:
        return VerbResult(success=False, error=f"No matching objects found to grab for '{target_ref or pattern}'.")

    collection = context.allocate_collection(
        acquired_targets,
        description=f"Grabbed {len(acquired_targets)} objects from {target_ref or 'workspace'}",
        source_verb="GRAB"
    )

    return VerbResult(
        success=True,
        data={
            "collection_handle": collection.handle,
            "count": collection.count,
            "total_size_bytes": collection.total_size_bytes,
            "summary": f"Acquired {collection.count} targets into {collection.handle}",
        },
        targets=acquired_targets,
    )
