"""Safety Controller and Policy Enforcement Engine."""

from dataclasses import dataclass, field
from hardterminal.safety.permissions import PermissionChecker
from hardterminal.core.errors import SafetyViolationError


# Allowed binaries for RUN verb to prevent arbitrary shell injection
DEFAULT_ALLOWED_EXECUTABLES = {
    "python",
    "python3",
    "pytest",
    "node",
    "npm",
    "npx",
    "git",
    "cargo",
    "rustc",
    "go",
    "make",
    "tar",
    "gzip",
    "zip",
    "unzip",
    "curl",
    "cat",
    "ls",
    "grep",
    "wc",
    "head",
    "tail",
    "diff",
    "uname",
    "echo",
}


@dataclass
class SafetyPolicy:
    """Configurable system safety thresholds."""
    max_batch_size: int = 500
    max_data_size_bytes: int = 500 * 1024 * 1024  # 500 MB
    max_recursion_depth: int = 15
    max_execution_time_seconds: int = 120
    allowed_executables: set[str] = field(default_factory=lambda: set(DEFAULT_ALLOWED_EXECUTABLES))
    allow_force_destructive: bool = False
    strict_confirmation: bool = True


class PolicyEngine:
    """Validates actions and parameters against system constraints."""

    def __init__(self, policy: SafetyPolicy | None = None):
        self.policy = policy or SafetyPolicy()
        self.permissions = PermissionChecker()

    def check_target_count(self, count: int):
        if count > self.policy.max_batch_size:
            raise SafetyViolationError(
                f"Batch size {count} exceeds safety limit of {self.policy.max_batch_size}.",
                hint="Reduce batch size or adjust workspace safety limits."
            )

    def check_data_size(self, size_bytes: int):
        if size_bytes > self.policy.max_data_size_bytes:
            raise SafetyViolationError(
                f"Target size {size_bytes / (1024*1024):.1f}MB exceeds safety limit of {self.policy.max_data_size_bytes / (1024*1024):.1f}MB."
            )

    def check_executable(self, executable: str):
        if not self.permissions.check_executable_allowed(executable, self.policy.allowed_executables):
            raise SafetyViolationError(
                f"Executable '{executable}' is not in the registered allowlist.",
                hint=f"Allowed executables: {', '.join(sorted(list(self.policy.allowed_executables))[:10])}..."
            )


class SafetyController:
    """Unified safety boundary validator for HardTerminal operations."""

    def __init__(self, policy: SafetyPolicy | None = None):
        self.policy_engine = PolicyEngine(policy)
        self.permissions = PermissionChecker()

    def validate_action(self, verb: str, targets: list[str] | None = None, parameters: dict | None = None):
        """Validate safety constraints prior to planning or execution."""
        verb_upper = str(verb).upper()
        target_paths = targets or []
        params = parameters or {}

        # 1. Batch size verification
        self.policy_engine.check_target_count(len(target_paths))

        # 2. Path safety checks for modifying/destructive verbs
        read_only_verbs = ["SHOW", "READ", "INSPECT", "DESCRIBE", "CHECK", "COUNT", "ANALYSE", "CALCULATE", "MEASURE", "VALIDATE", "HASH", "COMPARE", "DIFF", "LIST", "FIND", "SEARCH", "GRAB", "EXPLAIN", "PLAN", "PREVIEW"]
        is_read_only = verb_upper in read_only_verbs

        for p in target_paths:
            if isinstance(p, str):
                self.permissions.validate_path_safety(p, allow_read_only=is_read_only)

        # Destination path check for COPY, MOVE, EXPORT, RESTORE
        if "destination" in params and isinstance(params["destination"], str):
            self.permissions.validate_path_safety(params["destination"], allow_read_only=False)

        # 3. Executable binary allowlist check for RUN
        if verb_upper == "RUN":
            executable = params.get("executable")
            if not executable:
                raise SafetyViolationError("Verb RUN requires an explicit 'executable' parameter.")
            self.policy_engine.check_executable(str(executable))
