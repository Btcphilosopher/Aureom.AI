"""Risk Engine and classification levels for HardTerminal."""

from enum import Enum, unique
from dataclasses import dataclass
from typing import Any
from hardterminal.core.verbs import VerbName


@unique
class RiskLevel(str, Enum):
    NONE = "NONE"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

    @property
    def severity_score(self) -> int:
        scores = {
            RiskLevel.NONE: 0,
            RiskLevel.LOW: 1,
            RiskLevel.MEDIUM: 2,
            RiskLevel.HIGH: 3,
            RiskLevel.CRITICAL: 4,
        }
        return scores[self]


# Standard risk level baselines for verbs
VERB_RISK_MAP: dict[str, RiskLevel] = {
    # Read-only / Inspection -> NONE
    VerbName.SHOW.value: RiskLevel.NONE,
    VerbName.READ.value: RiskLevel.NONE,
    VerbName.INSPECT.value: RiskLevel.NONE,
    VerbName.DESCRIBE.value: RiskLevel.NONE,
    VerbName.CHECK.value: RiskLevel.NONE,
    VerbName.COUNT.value: RiskLevel.NONE,
    VerbName.ANALYSE.value: RiskLevel.NONE,
    VerbName.CALCULATE.value: RiskLevel.NONE,
    VerbName.MEASURE.value: RiskLevel.NONE,
    VerbName.VALIDATE.value: RiskLevel.NONE,
    VerbName.HASH.value: RiskLevel.NONE,
    VerbName.COMPARE.value: RiskLevel.NONE,
    VerbName.DIFF.value: RiskLevel.NONE,
    VerbName.VERIFY.value: RiskLevel.NONE,
    VerbName.EXPLAIN.value: RiskLevel.NONE,
    VerbName.PLAN.value: RiskLevel.NONE,
    VerbName.PREVIEW.value: RiskLevel.NONE,
    VerbName.RELEASE.value: RiskLevel.NONE,
    VerbName.REPORT.value: RiskLevel.NONE,
    VerbName.MONITOR.value: RiskLevel.NONE,
    VerbName.LIST.value: RiskLevel.NONE,
    VerbName.FIND.value: RiskLevel.NONE,
    VerbName.SEARCH.value: RiskLevel.NONE,
    VerbName.GRAB.value: RiskLevel.NONE,
    VerbName.SORT.value: RiskLevel.NONE,
    VerbName.FILTER.value: RiskLevel.NONE,
    VerbName.GROUP.value: RiskLevel.NONE,

    # Low risk modifications
    VerbName.COPY.value: RiskLevel.LOW,
    VerbName.DUPLICATE.value: RiskLevel.LOW,
    VerbName.CREATE.value: RiskLevel.LOW,
    VerbName.MAKE.value: RiskLevel.LOW,
    VerbName.OPEN.value: RiskLevel.LOW,
    VerbName.SPLIT.value: RiskLevel.LOW,
    VerbName.ARCHIVE.value: RiskLevel.LOW,
    VerbName.COMPRESS.value: RiskLevel.LOW,
    VerbName.CONVERT.value: RiskLevel.LOW,
    VerbName.TRANSFORM.value: RiskLevel.LOW,
    VerbName.GENERATE.value: RiskLevel.LOW,
    VerbName.EXPORT.value: RiskLevel.LOW,
    VerbName.IMPORT.value: RiskLevel.LOW,
    VerbName.WATCH.value: RiskLevel.LOW,
    VerbName.PAUSE.value: RiskLevel.LOW,
    VerbName.RESUME.value: RiskLevel.LOW,

    # Medium risk modifications (in-place edits, moves, builds)
    VerbName.MOVE.value: RiskLevel.MEDIUM,
    VerbName.RENAME.value: RiskLevel.MEDIUM,
    VerbName.EDIT.value: RiskLevel.MEDIUM,
    VerbName.REPLACE.value: RiskLevel.MEDIUM,
    VerbName.INSERT.value: RiskLevel.MEDIUM,
    VerbName.MERGE.value: RiskLevel.MEDIUM,
    VerbName.RESTORE.value: RiskLevel.MEDIUM,
    VerbName.EXTRACT.value: RiskLevel.MEDIUM,
    VerbName.BUILD.value: RiskLevel.MEDIUM,
    VerbName.TEST.value: RiskLevel.MEDIUM,
    VerbName.START.value: RiskLevel.MEDIUM,
    VerbName.SCHEDULE.value: RiskLevel.MEDIUM,
    VerbName.UNDO.value: RiskLevel.MEDIUM,
    VerbName.REDO.value: RiskLevel.MEDIUM,
    VerbName.EXECUTE.value: RiskLevel.MEDIUM,

    # High risk operations
    VerbName.DELETE.value: RiskLevel.HIGH,
    VerbName.REMOVE.value: RiskLevel.HIGH,
    VerbName.STOP.value: RiskLevel.HIGH,
    VerbName.RUN.value: RiskLevel.HIGH,
}


@dataclass
class RiskAssessment:
    """Detailed risk assessment outcome for an action."""
    level: RiskLevel
    reason: str
    requires_confirmation: bool
    is_destructive: bool
    affected_count: int = 1
    warnings: list[str] = None

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []

    def to_dict(self) -> dict:
        return {
            "level": self.level.value,
            "reason": self.reason,
            "requires_confirmation": self.requires_confirmation,
            "is_destructive": self.is_destructive,
            "affected_count": self.affected_count,
            "warnings": self.warnings,
        }


class RiskEngine:
    """Calculates risk levels based on verbs, targets, batch sizes, and system sensitivity."""

    def assess(self, verb_name: str, targets: list[Any] | None = None, parameters: dict | None = None) -> RiskAssessment:
        verb_str = str(verb_name).upper()
        base_risk = VERB_RISK_MAP.get(verb_str, RiskLevel.MEDIUM)
        params = parameters or {}
        target_list = targets or []
        count = len(target_list) if isinstance(target_list, list) else 1
        warnings: list[str] = []

        is_destructive = verb_str in [VerbName.DELETE.value, VerbName.REMOVE.value, VerbName.EDIT.value, VerbName.REPLACE.value]
        requires_conf = base_risk in [RiskLevel.HIGH, RiskLevel.CRITICAL] or verb_str in [VerbName.MOVE.value, VerbName.RUN.value, VerbName.SCHEDULE.value]

        final_risk = base_risk

        # Mass destruction escalation
        if is_destructive and count > 10:
            final_risk = RiskLevel.CRITICAL
            requires_conf = True
            warnings.append(f"Mass deletion / modification affecting {count} targets.")
        elif count > 50 and base_risk == RiskLevel.MEDIUM:
            final_risk = RiskLevel.HIGH
            requires_conf = True
            warnings.append(f"Large batch operation affecting {count} targets.")

        # Check for force flag
        if params.get("force"):
            warnings.append("Explicit 'force' flag requested.")

        reason = f"Verb '{verb_str}' base risk is {base_risk.value}."
        if warnings:
            reason += " " + " ".join(warnings)

        return RiskAssessment(
            level=final_risk,
            reason=reason,
            requires_confirmation=requires_conf,
            is_destructive=is_destructive,
            affected_count=count,
            warnings=warnings,
        )
