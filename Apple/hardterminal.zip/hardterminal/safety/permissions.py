"""macOS Protected Paths and Permissions Checker."""

import os
import pathlib
from hardterminal.core.errors import SafetyViolationError


# Standard macOS / POSIX protected system roots and sensitive directories
PROTECTED_ROOTS = [
    "/System",
    "/System/Library",
    "/Library",
    "/usr",
    "/bin",
    "/sbin",
    "/etc",
    "/var",
    "/private",
    "/dev",
    "/cores",
    "/Volumes",
    "/Applications",
]

PROTECTED_USER_PATHS = [
    ".ssh",
    ".gnupg",
    ".aws",
    ".config/gcloud",
    ".bash_profile",
    ".zshrc",
    "Keychain",
    "Keychains",
]


class PermissionChecker:
    """Verifies filesystem access constraints and permissions."""

    def is_protected_path(self, path: str) -> bool:
        """Check if path falls under protected system boundaries."""
        if not path:
            return False

        resolved = os.path.abspath(os.path.expanduser(path))
        norm = os.path.normpath(resolved)

        # Root protection
        if norm == "/":
            return True

        for protected in PROTECTED_ROOTS:
            if norm == protected or norm.startswith(protected + "/"):
                return True

        # User sensitive keys & credentials protection
        parts = pathlib.Path(norm).parts
        for part in parts:
            if part in PROTECTED_USER_PATHS:
                return True

        return False

    def validate_path_safety(self, path: str, allow_read_only: bool = False):
        """Raise SafetyViolationError if writing/modifying protected system paths."""
        if self.is_protected_path(path) and not allow_read_only:
            raise SafetyViolationError(
                f"Access denied: '{path}' is a protected system or credential path.",
                hint="HardTerminal strictly protects macOS system roots, /bin, /etc, /Library, and user credential directories."
            )

    def check_executable_allowed(self, executable: str, allowlist: set[str]) -> bool:
        """Verify binary execution against strict allowlist."""
        base_name = os.path.basename(executable).lower()
        return base_name in allowlist
