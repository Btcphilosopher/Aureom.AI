"""Transaction Model and Rollback Management (PLAN -> SNAPSHOT -> EXECUTE -> VERIFY -> COMMIT)."""

import os
import shutil
import time
from dataclasses import dataclass, field
from typing import Any
from hardterminal.core.registry import VerbResult
from hardterminal.core.errors import TransactionError


@dataclass
class SnapshotEntry:
    """Pre-modification snapshot of a target file or state."""
    original_path: str
    backup_path: str
    existed_before: bool
    is_dir: bool = False


@dataclass
class Transaction:
    """Atomic reversible transaction record."""
    tx_id: str
    verb: str
    timestamp: float
    description: str
    snapshots: list[SnapshotEntry] = field(default_factory=list)
    committed: bool = False
    rolled_back: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "tx_id": self.tx_id,
            "verb": self.verb,
            "timestamp": self.timestamp,
            "description": self.description,
            "committed": self.committed,
            "rolled_back": self.rolled_back,
            "snapshot_count": len(self.snapshots),
        }


class TransactionManager:
    """Manages transactional snapshots and rollback for modifying operations."""

    def __init__(self, workspace_root: str):
        self.workspace_root = os.path.abspath(workspace_root)
        self.tx_dir = os.path.join(self.workspace_root, ".hardterminal", "transactions")
        os.makedirs(self.tx_dir, exist_ok=True)
        self.active_transactions: list[Transaction] = []
        self.committed_history: list[Transaction] = []
        self._tx_counter = 1

    def begin_transaction(self, verb: str, description: str = "") -> Transaction:
        tx_id = f"TX_{int(time.time())}_{self._tx_counter:04d}"
        self._tx_counter += 1
        tx = Transaction(
            tx_id=tx_id,
            verb=verb,
            timestamp=time.time(),
            description=description or f"Transaction for {verb}",
        )
        self.active_transactions.append(tx)
        return tx

    def snapshot_target(self, tx: Transaction, target_path: str):
        """Capture copy of target prior to modification."""
        resolved = os.path.abspath(target_path)
        existed = os.path.exists(resolved)
        is_dir = os.path.isdir(resolved) if existed else False

        backup_sub = os.path.join(self.tx_dir, tx.tx_id)
        os.makedirs(backup_sub, exist_ok=True)

        backup_file = os.path.join(backup_sub, f"snap_{len(tx.snapshots)}_{os.path.basename(resolved)}")

        if existed:
            if is_dir:
                shutil.copytree(resolved, backup_file)
            else:
                shutil.copy2(resolved, backup_file)

        entry = SnapshotEntry(
            original_path=resolved,
            backup_path=backup_file,
            existed_before=existed,
            is_dir=is_dir,
        )
        tx.snapshots.append(entry)

    def commit(self, tx: Transaction):
        """Commit transaction changes permanently."""
        tx.committed = True
        self.committed_history.append(tx)
        if tx in self.active_transactions:
            self.active_transactions.remove(tx)

    def rollback(self, tx: Transaction) -> VerbResult:
        """Rollback all changes recorded in transaction snapshots."""
        if tx.rolled_back:
            return VerbResult(success=False, error=f"Transaction {tx.tx_id} was already rolled back.")

        restored_paths: list[str] = []
        try:
            for snap in reversed(tx.snapshots):
                # If file existed before, restore from backup
                if snap.existed_before:
                    if os.path.exists(snap.original_path):
                        if snap.is_dir:
                            shutil.rmtree(snap.original_path)
                        else:
                            os.remove(snap.original_path)

                    if snap.is_dir:
                        shutil.copytree(snap.backup_path, snap.original_path)
                    else:
                        shutil.copy2(snap.backup_path, snap.original_path)
                    restored_paths.append(snap.original_path)
                else:
                    # File was newly created by operation, remove it
                    if os.path.exists(snap.original_path):
                        if os.path.isdir(snap.original_path):
                            shutil.rmtree(snap.original_path)
                        else:
                            os.remove(snap.original_path)
                        restored_paths.append(f"removed:{snap.original_path}")

            tx.rolled_back = True
            return VerbResult(
                success=True,
                data={
                    "tx_id": tx.tx_id,
                    "verb": tx.verb,
                    "restored_count": len(restored_paths),
                    "restored": restored_paths,
                    "message": f"Successfully rolled back transaction {tx.tx_id} ({tx.verb}).",
                },
            )
        except Exception as e:
            raise TransactionError(f"Failed rolling back transaction {tx.tx_id}: {e}")

    def rollback_last(self, context: Any) -> VerbResult:
        """Rollback the most recent reversible transaction."""
        for tx in reversed(self.committed_history):
            if not tx.rolled_back and tx.snapshots:
                return self.rollback(tx)
        return VerbResult(success=False, error="No reversible transactions available in history.")
