"""Execution Verification Engine."""

import os
from hardterminal.core.registry import VerbResult
from hardterminal.core.targets import Target


class VerificationEngine:
    """Verifies state, checksums, and targets post-execution."""

    def verify(self, targets: list[Target]) -> dict:
        results = []
        all_ok = True
        for t in targets:
            exists = os.path.exists(t.resolved_path)
            # If target was deleted, existence being false is expected
            ok = True if not t.exists else exists
            if not ok:
                all_ok = False
            results.append({
                "handle": t.handle,
                "path": t.resolved_path,
                "verified": ok,
                "exists_now": exists,
            })

        return {
            "all_verified": all_ok,
            "target_count": len(targets),
            "verifications": results,
        }
