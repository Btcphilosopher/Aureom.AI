"""Action Graph Executor and Lifecycle Manager."""

import time
from dataclasses import dataclass, field
from typing import Any
from hardterminal.core.registry import VerbRegistry, VerbResult
from hardterminal.core.targets import Target
from hardterminal.planning.planner import ExecutionPlan
from hardterminal.planning.graph import ActionNode, ActionStatus
from hardterminal.safety.policies import SafetyController
from hardterminal.execution.transactions import TransactionManager, Transaction
from hardterminal.execution.verification import VerificationEngine
from hardterminal.core.errors import ExecutionError


@dataclass
class ExecutionReport:
    """Comprehensive post-execution audit and status report."""
    plan_id: str
    primary_verb: str
    success: bool
    duration_ms: float
    dry_run: bool = False
    affected_targets: list[Target] = field(default_factory=list)
    node_results: dict[str, VerbResult] = field(default_factory=dict)
    failed_nodes: list[str] = field(default_factory=list)
    transaction_id: str | None = None
    verification: dict[str, Any] = field(default_factory=dict)
    summary_message: str = ""

    def to_dict(self) -> dict:
        return {
            "plan_id": self.plan_id,
            "primary_verb": self.primary_verb,
            "success": self.success,
            "duration_ms": self.duration_ms,
            "dry_run": self.dry_run,
            "affected_targets": [t.to_dict() if hasattr(t, "to_dict") else str(t) for t in self.affected_targets],
            "failed_nodes": self.failed_nodes,
            "transaction_id": self.transaction_id,
            "verification": self.verification,
            "summary_message": self.summary_message,
        }


class GraphExecutor:
    """Executes Action Graph nodes in topological dependency order with safety & transactions."""

    def __init__(self, registry: VerbRegistry, safety: SafetyController, transactions: TransactionManager):
        self.registry = registry
        self.safety = safety
        self.transactions = transactions
        self.verification = VerificationEngine()

    def execute_plan(self, plan: ExecutionPlan, context: Any, dry_run: bool = False) -> ExecutionReport:
        start_time = time.perf_counter()
        nodes = plan.action_graph.topological_order()

        # Pre-execution safety validation
        for node in nodes:
            target_paths = [node.target] if node.target and not node.target.startswith("$") else []
            self.safety.validate_action(node.verb, targets=target_paths, parameters=node.parameters)

        node_results: dict[str, VerbResult] = {}
        failed_nodes: list[str] = []
        all_affected_targets: list[Target] = []
        tx: Transaction | None = None

        if dry_run:
            for node in nodes:
                node.status = ActionStatus.SUCCESS
            duration = (time.perf_counter() - start_time) * 1000
            return ExecutionReport(
                plan_id=plan.plan_id,
                primary_verb=plan.primary_verb,
                success=True,
                duration_ms=duration,
                dry_run=True,
                summary_message=f"DRY RUN completed for {plan.primary_verb}. No filesystem changes made.",
            )

        # Start transaction if any node is reversible
        is_modifying = any(n.reversible or n.verb in ["EDIT", "REPLACE", "MOVE", "DELETE", "REMOVE", "RENAME"] for n in nodes)
        if is_modifying:
            tx = self.transactions.begin_transaction(plan.primary_verb, plan.description)

        pipeline_last_targets: list[Target] = []

        for node in nodes:
            node.status = ActionStatus.RUNNING
            v_def = self.registry.get(node.verb)

            # Resolve target
            target_ref = node.target
            if target_ref == "$context.previous_results" and pipeline_last_targets:
                target_ref = None  # Will be passed as context targets

            # Snapshot target for transaction before modifying
            if tx and node.target and not node.target.startswith("$"):
                obj = context.get_target_or_collection(node.target)
                if obj:
                    paths = [t.resolved_path for t in obj.targets] if hasattr(obj, "targets") else [obj.resolved_path]
                    for p in paths:
                        self.transactions.snapshot_target(tx, p)

            # Execute handler
            try:
                handler = v_def.handler
                if not handler:
                    raise ExecutionError(f"No handler registered for verb {node.verb}")

                kwargs = dict(node.parameters)
                res = handler(context, target_ref=target_ref, **kwargs)

                if res.success:
                    node.status = ActionStatus.SUCCESS
                    node.result = res.data
                    node_results[node.action_id] = res

                    if res.targets:
                        pipeline_last_targets = list(res.targets)
                        all_affected_targets.extend(res.targets)
                else:
                    node.status = ActionStatus.FAILED
                    node.error = res.error
                    node_results[node.action_id] = res
                    failed_nodes.append(node.action_id)
                    break

            except Exception as e:
                node.status = ActionStatus.FAILED
                node.error = str(e)
                failed_nodes.append(node.action_id)
                node_results[node.action_id] = VerbResult(success=False, error=str(e))
                break

        # Post-execution verification & commit/rollback
        if failed_nodes:
            if tx:
                self.transactions.rollback(tx)
            success = False
            summary = f"Execution failed at node {failed_nodes[0]}: {node_results[failed_nodes[0]].error}"
        else:
            if tx:
                self.transactions.commit(tx)
            success = True
            for n in nodes:
                n.status = ActionStatus.VERIFIED
            summary = f"Successfully executed {plan.primary_verb} ({len(nodes)} graph nodes)."

        verify_report = self.verification.verify(all_affected_targets)
        duration = (time.perf_counter() - start_time) * 1000

        return ExecutionReport(
            plan_id=plan.plan_id,
            primary_verb=plan.primary_verb,
            success=success,
            duration_ms=duration,
            dry_run=False,
            affected_targets=all_affected_targets,
            node_results=node_results,
            failed_nodes=failed_nodes,
            transaction_id=tx.tx_id if tx else None,
            verification=verify_report,
            summary_message=summary,
        )

    def verify_report(self, report: ExecutionReport, context: Any) -> dict:
        return self.verification.verify(report.affected_targets)
