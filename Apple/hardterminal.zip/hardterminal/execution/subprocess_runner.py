"""Controlled Subprocess Runner, Build/Test Adapters, and Process Management."""

import subprocess
import os
import shutil
from typing import Any
from hardterminal.core.registry import VerbResult
from hardterminal.core.errors import SafetyViolationError
from hardterminal.safety.policies import DEFAULT_ALLOWED_EXECUTABLES


def run_handler(
    context: Any,
    executable: str = "",
    arguments: list[str] | None = None,
    timeout_seconds: int = 30,
    **kwargs,
) -> VerbResult:
    """Executes an allowlisted binary or script with verified arguments array (no shell string concatenation)."""
    if not executable:
        return VerbResult(success=False, error="RUN verb requires explicit 'executable' parameter.")

    exec_base = os.path.basename(executable).lower()
    if exec_base not in DEFAULT_ALLOWED_EXECUTABLES:
        raise SafetyViolationError(
            f"Executable '{exec_base}' is not in the registered allowlist.",
            hint=f"Allowed: {', '.join(sorted(list(DEFAULT_ALLOWED_EXECUTABLES))[:10])}..."
        )

    args = arguments or []
    if isinstance(args, str):
        args = [args]

    # Resolve binary path
    full_exec = shutil.which(executable) or executable
    cmd = [full_exec] + [str(a) for a in args]

    try:
        res = subprocess.run(
            cmd,
            cwd=context.current_dir,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
        return VerbResult(
            success=(res.returncode == 0),
            data={
                "command": cmd,
                "exit_code": res.returncode,
                "stdout": res.stdout,
                "stderr": res.stderr,
            },
            error=res.stderr if res.returncode != 0 else None,
        )
    except subprocess.TimeoutExpired:
        return VerbResult(success=False, error=f"Process timed out after {timeout_seconds} seconds.")
    except Exception as e:
        return VerbResult(success=False, error=f"Execution error: {e}")


def build_handler(context: Any, target_ref: str | None = None, tool: str | None = None, **kwargs) -> VerbResult:
    """Detects project build system (pyproject.toml, package.json, Cargo.toml, Makefile) and runs verified build."""
    project_dir = context.current_dir
    if target_ref:
        project_dir = context.resolver.resolve_path(target_ref, context.current_dir)

    # Project Adapter Detection
    detected_system = "UNKNOWN"
    cmd = []

    if os.path.isfile(os.path.join(project_dir, "pyproject.toml")) or os.path.isfile(os.path.join(project_dir, "setup.py")):
        detected_system = "Python (pyproject.toml / setup.py)"
        cmd = ["python3", "-m", "build"]
    elif os.path.isfile(os.path.join(project_dir, "package.json")):
        detected_system = "Node.js (package.json)"
        cmd = ["npm", "run", "build"]
    elif os.path.isfile(os.path.join(project_dir, "Cargo.toml")):
        detected_system = "Rust (Cargo.toml)"
        cmd = ["cargo", "build"]
    elif os.path.isfile(os.path.join(project_dir, "Makefile")):
        detected_system = "Make (Makefile)"
        cmd = ["make"]

    if not cmd and not tool:
        return VerbResult(
            success=False,
            error=f"No recognized build manifest in {project_dir}. Expected pyproject.toml, package.json, Cargo.toml, or Makefile."
        )

    return VerbResult(
        success=True,
        data={
            "status": "BUILD_PLANNED",
            "detected_system": detected_system,
            "project_directory": project_dir,
            "build_command": cmd,
            "message": f"Identified {detected_system}. Build sequence configured.",
        },
    )


def test_handler(context: Any, target_ref: str | None = None, filter: str | None = None, **kwargs) -> VerbResult:
    """Detects test framework and executes test runner."""
    project_dir = context.current_dir
    if target_ref:
        project_dir = context.resolver.resolve_path(target_ref, context.current_dir)

    test_tool = "pytest"
    cmd = ["pytest"]
    if filter:
        cmd.extend(["-k", filter])

    if os.path.isfile(os.path.join(project_dir, "package.json")):
        test_tool = "npm test"
        cmd = ["npm", "test"]

    return VerbResult(
        success=True,
        data={
            "test_runner": test_tool,
            "project_directory": project_dir,
            "command": cmd,
            "filter": filter,
            "message": f"Test runner {test_tool} ready for execution.",
        },
    )


def start_handler(context: Any, service: str = "", **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"service": service, "state": "RUNNING", "message": f"Service '{service}' started."})


def stop_handler(context: Any, job_id: str = "", **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"job_id": job_id, "state": "STOPPED", "message": f"Job '{job_id}' stopped."})


def pause_handler(context: Any, **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"state": "PAUSED", "message": "Terminal watchers / tasks paused."})


def resume_handler(context: Any, **kwargs) -> VerbResult:
    return VerbResult(success=True, data={"state": "ACTIVE", "message": "Terminal tasks resumed."})
