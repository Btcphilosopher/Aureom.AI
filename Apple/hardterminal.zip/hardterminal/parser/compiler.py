"""Intent Compiler — Deterministic translation of natural language and syntax into verified Intents."""

import re
from typing import Any
from hardterminal.core.intents import Intent
from hardterminal.core.verbs import VerbName
from hardterminal.core.registry import VerbRegistry
from hardterminal.core.errors import AmbiguousRequestError, UnknownVerbError
from hardterminal.parser.aliases import resolve_verb_alias
from hardterminal.parser.parser import HardGrammarParser
from hardterminal.core.ast import VerbCommandNode, PipelineNode


class IntentCompiler:
    """Translates user natural language or explicit grammar into verified, parameterised Intents."""

    def __init__(self, registry: VerbRegistry):
        self.registry = registry
        self.parser = HardGrammarParser()

    def compile(self, raw_input: str, context: Any) -> Intent:
        clean = raw_input.strip()
        if not clean:
            raise AmbiguousRequestError("Empty request provided.", required_parameters=["verb", "target"])

        # Check for explicit flags like --dry-run or --json
        flags: dict[str, bool] = {}
        if "--dry-run" in clean:
            flags["dry_run"] = True
            clean = clean.replace("--dry-run", "").strip()
        if "--force" in clean:
            flags["force"] = True
            clean = clean.replace("--force", "").strip()

        # Check if this is a pipeline (contains | or -> or multiple clauses)
        if "|" in clean or "->" in clean:
            return self._compile_pipeline(clean, context, flags)

        # Check for ambiguous general queries before greedy matching
        self._check_ambiguous_requests(clean)

        # 1. First attempt to resolve via registered verb or alias
        verb_enum, remaining = resolve_verb_alias(clean)

        if not verb_enum:
            tokens = clean.split()
            if tokens:
                first_word = tokens[0].upper()
                if self.registry.contains(first_word):
                    verb_enum = VerbName(first_word)
                    remaining = " ".join(tokens[1:])

        if not verb_enum:
            raise UnknownVerbError(
                f"Could not map request '{clean}' to any registered HardTerminal verb.",
                hint="Registered verbs include FIND, GRAB, INSPECT, EDIT, MOVE, COPY, DELETE, SORT, FILTER, ANALYSE..."
            )

        verb_str = verb_enum.value

        # Ambiguity checks for destructive verbs
        if verb_str in [VerbName.DELETE.value, VerbName.REMOVE.value]:
            if not remaining or remaining.lower() in ["the old files", "old files", "files", "temp files"]:
                raise AmbiguousRequestError(
                    f"Ambiguous delete request: '{clean}'",
                    required_parameters=["target directory", "definition of 'old' (e.g. modified > 30 days)"],
                    hint='Specify concrete target, e.g.: FIND ~/Downloads MODIFIED "> 30 days" | DELETE'
                )

        # 2. Extract targets, handles, and parameters
        target, parameters = self._extract_parameters(verb_str, remaining, context)

        # Apply flags
        if flags:
            parameters.update(flags)

        return Intent(
            verb=verb_str,
            target=target,
            parameters=parameters,
            raw_query=raw_input,
            flags=flags,
        )

    def _check_ambiguous_requests(self, text: str):
        """Reject common ambiguous queries that lack concrete operational targets."""
        lower = text.lower().strip()
        if lower.startswith("clean this") or lower.startswith("clean ") or lower == "clean directory":
            raise AmbiguousRequestError(
                "Ambiguous request: 'Clean this directory'.",
                required_parameters=["pattern or extensions to remove", "safety confirmation"],
                hint="Use FIND with explicit pattern e.g. FIND . PATTERN '*.tmp'"
            )
        if lower.startswith("fix the") or "fix config" in lower or "fix the configuration" in lower:
            raise AmbiguousRequestError(
                f"Ambiguous request: '{text}'. HardTerminal verbs require deterministic patch instructions.",
                required_parameters=["target file", "find string", "replace string"],
                hint="Use EDIT with find and replace parameters"
            )
        if "make it smaller" in lower or "make it small" in lower or ("compress it" in lower and not any(h in lower for h in ["#", "/"])):
            raise AmbiguousRequestError(
                "Ambiguous request: Target and compression target unspecified.",
                required_parameters=["target object handle or path"],
                hint="Specify target handle, e.g. COMPRESS #001"
            )
        if lower.startswith("remove the old") or lower.startswith("delete the old"):
            raise AmbiguousRequestError(
                f"Ambiguous delete request: '{text}'",
                required_parameters=["target directory", "definition of 'old' (e.g. modified > 30 days)"],
                hint='Specify concrete target, e.g.: FIND ~/Downloads MODIFIED "> 30 days" | DELETE'
            )

    def _compile_pipeline(self, pipeline_text: str, context: Any, flags: dict) -> Intent:
        """Parses multi-step pipeline."""
        ast_pipeline = self.parser.parse(pipeline_text)
        if isinstance(ast_pipeline, PipelineNode):
            steps: list[Intent] = []
            for step_node in ast_pipeline.steps:
                target_val = step_node.target.raw_value if step_node.target else None
                step_intent = Intent(
                    verb=step_node.verb,
                    target=target_val,
                    parameters=step_node.parameters,
                    flags=step_node.flags,
                )
                steps.append(step_intent)

            primary_verb = steps[0].verb if steps else "PIPELINE"
            return Intent(
                verb=primary_verb,
                target=steps[0].target if steps else None,
                is_pipeline=True,
                pipeline_steps=steps,
                raw_query=pipeline_text,
                flags=flags,
            )
        else:
            return self.compile(pipeline_text, context)

    def _extract_parameters(self, verb: str, text: str, context: Any) -> tuple[str | None, dict[str, Any]]:
        """Deterministically extracts target path/handle and named parameters."""
        parameters: dict[str, Any] = {}
        target: str | None = None
        clean = text.strip()

        # Handle reference detection e.g. #001, #12, TARGET #17
        handle_match = re.search(r"#\d+", clean)
        if handle_match:
            target = handle_match.group()
            clean = clean.replace(target, "").strip()

        # Contextual pronouns referring to previous results
        context_pronouns = ["those", "them", "these", "the results", "targets", "results"]
        for cp in context_pronouns:
            pattern = r"\b" + cp + r"\b"
            if re.search(pattern, clean, re.IGNORECASE):
                target = "$context.previous_results"
                clean = re.sub(pattern, "", clean, flags=re.IGNORECASE).strip()
                break

        # Check for find '...' and replace '...' parameters for EDIT / REPLACE
        find_match = re.search(r"\bfind\s+('[^']*'|\"[^\"]*\"|[^\s]+)", clean, re.IGNORECASE)
        if find_match:
            parameters["find"] = find_match.group(1).strip("\"'")
            clean = clean[:find_match.start()] + clean[find_match.end():]
            clean = clean.strip()

        replace_match = re.search(r"\breplace\s+('[^']*'|\"[^\"]*\"|[^\s]+)", clean, re.IGNORECASE)
        if replace_match:
            parameters["replace"] = replace_match.group(1).strip("\"'")
            clean = clean[:replace_match.start()] + clean[replace_match.end():]
            clean = clean.strip()

        content_match = re.search(r"\bcontent\s+('[^']*'|\"[^\"]*\"|[^\s]+)", clean, re.IGNORECASE)
        if content_match:
            parameters["content"] = content_match.group(1).strip("\"'")
            clean = clean[:content_match.start()] + clean[content_match.end():]
            clean = clean.strip()

        # Check for destination ("into Archive", "to ~/Documents/Archive")
        dest_match = re.search(r"\b(into|to)\s+([^\s,]+|\"[^\"]+\")", clean, re.IGNORECASE)
        if dest_match:
            parameters["destination"] = dest_match.group(2).strip("\"'")
            clean = clean[:dest_match.start()] + clean[dest_match.end():]
            clean = clean.strip()

        # Check for secondary comparison target ("with TARGET #21", "with #21")
        with_match = re.search(r"\bwith\s+(target\s+)?(#\d+|[^\s,]+)", clean, re.IGNORECASE)
        if with_match:
            parameters["with_target"] = with_match.group(2).strip("\"'")
            clean = clean[:with_match.start()] + clean[with_match.end():]
            clean = clean.strip()

        # Check for size specifications (e.g. "large", "> 100 MB", "above 50MB")
        if "large" in clean.lower():
            parameters["size"] = "> 100 MB"
            clean = re.sub(r"\blarge\b", "", clean, flags=re.IGNORECASE).strip()
        size_match = re.search(r"\b(size\s+)?(>|<|>=|<=)?\s*(\d+\s*(?:GB|MB|KB|B))\b", clean, re.IGNORECASE)
        if size_match:
            op = size_match.group(2) or ">"
            parameters["size"] = f"{op} {size_match.group(3)}"
            clean = clean[:size_match.start()] + clean[size_match.end():]
            clean = clean.strip()

        # Check for file extension (e.g. "PDFs", "CSV files", "Python files", "*.pdf")
        ext_patterns = [
            (r"\b(pdfs?|pdf\s+files?)\b", "pdf"),
            (r"\b(csvs?|csv\s+files?)\b", "csv"),
            (r"\b(jsons?|json\s+files?)\b", "json"),
            (r"\b(images?|pngs?|jpegs?|jpgs?)\b", "png"),
            (r"\b(python\s+files?|py\s+files?)\b", "py"),
            (r"\b(logs?|log\s+files?)\b", "log"),
            (r"\b(text\s+files?|txt\s+files?)\b", "txt"),
        ]
        for pat, ext in ext_patterns:
            if re.search(pat, clean, re.IGNORECASE):
                parameters["pattern"] = f"*.{ext}"
                clean = re.sub(pat, "", clean, flags=re.IGNORECASE).strip()
                break

        # Check for explicit PATTERN "*.pdf"
        pat_match = re.search(r"\bpattern\s+([^\s,]+|\"[^\"]+\")", clean, re.IGNORECASE)
        if pat_match:
            parameters["pattern"] = pat_match.group(1).strip("\"'")
            clean = clean[:pat_match.start()] + clean[pat_match.end():]
            clean = clean.strip()

        # Check for directory / search path (e.g. "in Downloads", "in ./project", "~/Downloads")
        in_match = re.search(r"\bin\s+([^\s,]+|\"[^\"]+\")", clean, re.IGNORECASE)
        if in_match:
            path_val = in_match.group(1).strip("\"'")
            if path_val.lower() == "downloads":
                path_val = "~/Downloads"
            elif path_val.lower() in ["documents", "reports", "desktop"]:
                path_val = f"~/{path_val.capitalize()}"
            if not target:
                target = path_val
            clean = clean[:in_match.start()] + clean[in_match.end():]
            clean = clean.strip()

        # Data verb conditions (e.g. "revenue above 1000", "filter revenue > 1000", "by region")
        by_match = re.search(r"\bby\s+([a-zA-Z0-9_]+)", clean, re.IGNORECASE)
        if by_match:
            parameters["by"] = by_match.group(1)
            clean = clean[:by_match.start()] + clean[by_match.end():]
            clean = clean.strip()

        cond_match = re.search(r"\b([a-zA-Z0-9_]+)\s*(>|<|>=|<=|==|!=|above|below)\s*(\d+|\"[^\"]+\"|[a-zA-Z0-9_]+)\b", clean, re.IGNORECASE)
        if cond_match:
            col = cond_match.group(1)
            op_raw = cond_match.group(2).lower()
            val = cond_match.group(3).strip("\"'")
            op = ">" if op_raw == "above" else ("<" if op_raw == "below" else op_raw)
            parameters["condition"] = f"{col} {op} {val}"
            parameters["column"] = col
            parameters["operator"] = op
            parameters["value"] = val
            clean = clean[:cond_match.start()] + clean[cond_match.end():]
            clean = clean.strip()

        # Data aggregation metrics (e.g. "total revenue", "average score", "highest first")
        if "highest first" in clean.lower() or "descending" in clean.lower():
            parameters["descending"] = True
            clean = re.sub(r"\b(highest first|descending)\b", "", clean, flags=re.IGNORECASE).strip()
        if "lowest first" in clean.lower() or "ascending" in clean.lower():
            parameters["descending"] = False
            clean = re.sub(r"\b(lowest first|ascending)\b", "", clean, flags=re.IGNORECASE).strip()

        calc_match = re.search(r"\b(total|sum|mean|average|avg|min|max|count)\s+([a-zA-Z0-9_]+)", clean, re.IGNORECASE)
        if calc_match:
            parameters["metric"] = calc_match.group(1).lower()
            parameters["column"] = calc_match.group(2)
            clean = clean[:calc_match.start()] + clean[calc_match.end():]
            clean = clean.strip()

        # Remaining text as target or arguments
        clean = re.sub(r"\b(all|the|for|this|project)\b", "", clean, flags=re.IGNORECASE).strip()
        if clean and not target:
            target = clean.split()[0].strip("\"'")

        return target, parameters

        return target, parameters
