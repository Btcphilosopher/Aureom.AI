"""Hard Verb Grammar Parser (LLM-Free Deterministic AST Construction)."""

from hardterminal.parser.lexer import HardLexer, TokenType, Token
from hardterminal.core.ast import (
    VerbCommandNode,
    TargetExpressionNode,
    PipelineNode,
    WorkflowNode,
)
from hardterminal.core.errors import HardTerminalError


class HardGrammarParser:
    """Parses explicit HardTerminal syntax into AST without any LLM dependencies."""

    def __init__(self):
        self.lexer = HardLexer()

    def parse(self, text: str) -> VerbCommandNode | PipelineNode | WorkflowNode:
        tokens = self.lexer.tokenize(text)
        if not tokens or tokens[0].type == TokenType.EOF:
            raise HardTerminalError("Empty input provided to grammar parser.")

        # Check for pipeline delimiter | or ->
        has_pipe = any(t.type == TokenType.PIPE for t in tokens)
        if has_pipe:
            return self._parse_pipeline(tokens)

        return self._parse_single_command(tokens)

    def _parse_single_command(self, tokens: list[Token]) -> VerbCommandNode:
        idx = 0
        verb_token = tokens[idx]
        verb_name = verb_token.value.upper()
        idx += 1

        target_node: TargetExpressionNode | None = None
        with_target_node: TargetExpressionNode | None = None
        params: dict = {}
        flags: dict = {}

        while idx < len(tokens):
            tok = tokens[idx]
            if tok.type == TokenType.EOF:
                break

            if tok.type == TokenType.FLAG:
                flag_name = tok.value.lstrip("-")
                flags[flag_name] = True
                idx += 1
                continue

            if tok.type == TokenType.HANDLE:
                target_node = TargetExpressionNode(
                    raw_value=tok.value,
                    is_handle=True,
                    handle_number=int(tok.value[1:]),
                )
                idx += 1
                continue

            if tok.type == TokenType.KEYWORD:
                kw = tok.value.upper()
                idx += 1
                if kw in ["TARGET", "TARGETS"]:
                    if idx < len(tokens) and tokens[idx].type in [TokenType.HANDLE, TokenType.IDENTIFIER, TokenType.STRING]:
                        t_val = tokens[idx].value
                        is_h = tokens[idx].type == TokenType.HANDLE
                        target_node = TargetExpressionNode(
                            raw_value=t_val,
                            is_handle=is_h,
                            is_context_ref=(kw == "TARGETS" and not is_h),
                            handle_number=int(t_val[1:]) if is_h else None,
                        )
                        idx += 1
                    else:
                        target_node = TargetExpressionNode(raw_value="$context.previous_results", is_context_ref=True)
                elif kw in ["TO", "INTO"]:
                    if idx < len(tokens):
                        params["destination"] = tokens[idx].value
                        idx += 1
                elif kw == "WITH":
                    if idx < len(tokens):
                        with_tok = tokens[idx]
                        is_h = with_tok.type == TokenType.HANDLE
                        with_target_node = TargetExpressionNode(
                            raw_value=with_tok.value,
                            is_handle=is_h,
                            handle_number=int(with_tok.value[1:]) if is_h else None,
                        )
                        params["with_target"] = with_tok.value
                        idx += 1
                elif kw in ["PATTERN", "MATCHING"]:
                    if idx < len(tokens):
                        params["pattern"] = tokens[idx].value
                        idx += 1
                elif kw in ["BY"]:
                    if idx < len(tokens):
                        params["by"] = tokens[idx].value
                        idx += 1
                elif kw in ["FORMAT"]:
                    if idx < len(tokens):
                        params["format"] = tokens[idx].value
                        idx += 1
                elif kw in ["SIZE"]:
                    if idx < len(tokens):
                        params["size"] = tokens[idx].value
                        idx += 1
                elif kw in ["MODIFIED"]:
                    if idx < len(tokens):
                        params["modified"] = tokens[idx].value
                        idx += 1
                continue

            # Standard identifier or string target
            if target_node is None and tok.type in [TokenType.IDENTIFIER, TokenType.STRING]:
                target_node = TargetExpressionNode(raw_value=tok.value)
                idx += 1
                continue

            # Additional arguments
            if tok.type in [TokenType.IDENTIFIER, TokenType.STRING, TokenType.NUMBER]:
                params.setdefault("args", []).append(tok.value)
                idx += 1
                continue

            idx += 1

        return VerbCommandNode(
            verb=verb_name,
            target=target_node,
            with_target=with_target_node,
            parameters=params,
            flags=flags,
        )

    def _parse_pipeline(self, tokens: list[Token]) -> PipelineNode:
        segments: list[list[Token]] = []
        current: list[Token] = []

        for tok in tokens:
            if tok.type == TokenType.PIPE:
                if current:
                    current.append(Token(TokenType.EOF, "", 0))
                    segments.append(current)
                    current = []
            else:
                current.append(tok)

        if current:
            segments.append(current)

        steps = [self._parse_single_command(seg) for seg in segments if seg]
        return PipelineNode(steps=steps)
