"""Lexer and Tokenizer for HardTerminal Grammar and Natural Input."""

import re
from dataclasses import dataclass
from enum import Enum, unique


@unique
class TokenType(str, Enum):
    VERB = "VERB"
    HANDLE = "HANDLE"  # #001, #12
    PATH = "PATH"      # ~/Downloads, ./src, report.csv
    KEYWORD = "KEYWORD"  # PATTERN, TO, WITH, BY, AS, FORMAT, TARGET, TARGETS
    STRING = "STRING"  # "quoted text"
    FLAG = "FLAG"      # --dry-run, --force, --json
    PIPE = "PIPE"      # | or ->
    IDENTIFIER = "IDENTIFIER"
    OPERATOR = "OPERATOR"  # >, <, >=, <=, ==, !=
    NUMBER = "NUMBER"
    EOF = "EOF"


@dataclass
class Token:
    type: TokenType
    value: str
    position: int = 0

    def to_dict(self) -> dict:
        return {"type": self.type.value, "value": self.value, "position": self.position}


class HardLexer:
    """Tokenizes raw command strings into strongly typed tokens."""

    GRAMMAR_KEYWORDS = {
        "PATTERN", "EXT", "EXTENSION", "TO", "INTO", "WITH", "BY", "AS",
        "FORMAT", "TARGET", "TARGETS", "WHERE", "CONVERT", "FROM", "IN",
        "FOR", "MATCHING", "ON", "AFTER", "BEFORE", "SIZE", "MODIFIED"
    }

    def tokenize(self, text: str) -> list[Token]:
        tokens: list[Token] = []
        clean = text.strip()
        if not clean:
            return [Token(TokenType.EOF, "", 0)]

        # Regex token pattern matching
        token_spec = [
            ("PIPE", r"(\||\-\>)"),
            ("FLAG", r"\-\-[a-zA-Z0-9_\-]+"),
            ("HANDLE", r"\#[0-9]+"),
            ("STRING", r'"[^"\\]*(?:\\.[^"\\]*)*"|\'[^\'\\]*(?:\\.[^\'\\]*)*\''),
            ("OPERATOR", r"(>=|<=|!=|==|>|<)"),
            ("NUMBER", r"\b\d+(\.\d+)?\b"),
            ("WORD", r"[^\s\(\)\|\-\>\"\'\#]+"),
        ]

        master_regex = re.compile("|".join(f"(?P<{name}>{pattern})" for name, pattern in token_spec))

        for match in master_regex.finditer(clean):
            kind = match.lastgroup
            val = match.group()
            pos = match.start()

            if kind == "PIPE":
                tokens.append(Token(TokenType.PIPE, val, pos))
            elif kind == "FLAG":
                tokens.append(Token(TokenType.FLAG, val, pos))
            elif kind == "HANDLE":
                tokens.append(Token(TokenType.HANDLE, val, pos))
            elif kind == "STRING":
                # Unquote
                tokens.append(Token(TokenType.STRING, val[1:-1], pos))
            elif kind == "OPERATOR":
                tokens.append(Token(TokenType.OPERATOR, val, pos))
            elif kind == "NUMBER":
                tokens.append(Token(TokenType.NUMBER, val, pos))
            elif kind == "WORD":
                upper_val = val.upper()
                if upper_val in self.GRAMMAR_KEYWORDS:
                    tokens.append(Token(TokenType.KEYWORD, upper_val, pos))
                else:
                    tokens.append(Token(TokenType.IDENTIFIER, val, pos))

        tokens.append(Token(TokenType.EOF, "", len(clean)))
        return tokens
