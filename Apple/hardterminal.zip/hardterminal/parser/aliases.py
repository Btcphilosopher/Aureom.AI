"""Natural Language Aliases mapping directly and strictly to registered verbs."""

from hardterminal.core.verbs import VerbName


# Exact phrase mappings sorted longest first for greedier matching
NATURAL_LANGUAGE_ALIASES: list[tuple[str, VerbName]] = [
    # Multi-word aliases
    ("look for", VerbName.FIND),
    ("search for", VerbName.SEARCH),
    ("search in", VerbName.SEARCH),
    ("tell me about", VerbName.INSPECT),
    ("show me", VerbName.SHOW),
    ("make a copy of", VerbName.DUPLICATE),
    ("make a copy", VerbName.DUPLICATE),
    ("make a new", VerbName.CREATE),
    ("create a new", VerbName.CREATE),
    ("create new", VerbName.CREATE),
    ("change name of", VerbName.RENAME),
    ("undo that", VerbName.UNDO),
    ("roll back", VerbName.UNDO),
    ("rollback", VerbName.UNDO),
    ("sort by", VerbName.SORT),
    ("order by", VerbName.SORT),
    ("group by", VerbName.GROUP),
    ("how many", VerbName.COUNT),
    ("count total", VerbName.COUNT),
    ("combine those", VerbName.MERGE),
    ("combine them", VerbName.MERGE),
    ("combine these", VerbName.MERGE),
    ("combine", VerbName.MERGE),
    ("put those into", VerbName.MOVE),
    ("put them into", VerbName.MOVE),
    ("put these into", VerbName.MOVE),
    ("put into", VerbName.MOVE),
    ("put in", VerbName.MOVE),
    ("put", VerbName.MOVE),
    ("clean up", VerbName.DELETE),
    ("get rid of", VerbName.DELETE),
    ("dry run", VerbName.PREVIEW),

    # Single-word aliases
    ("locate", VerbName.FIND),
    ("find", VerbName.FIND),
    ("search", VerbName.SEARCH),
    ("grab", VerbName.GRAB),
    ("inspect", VerbName.INSPECT),
    ("read", VerbName.READ),
    ("cat", VerbName.READ),
    ("open", VerbName.OPEN),
    ("show", VerbName.SHOW),
    ("display", VerbName.SHOW),
    ("view", VerbName.SHOW),
    ("describe", VerbName.DESCRIBE),
    ("check", VerbName.CHECK),
    ("create", VerbName.CREATE),
    ("make", VerbName.MAKE),
    ("edit", VerbName.EDIT),
    ("change", VerbName.EDIT),
    ("alter", VerbName.EDIT),
    ("modify", VerbName.EDIT),
    ("patch", VerbName.EDIT),
    ("replace", VerbName.REPLACE),
    ("insert", VerbName.INSERT),
    ("delete", VerbName.DELETE),
    ("remove", VerbName.REMOVE),
    ("erase", VerbName.DELETE),
    ("trash", VerbName.DELETE),
    ("rename", VerbName.RENAME),
    ("copy", VerbName.COPY),
    ("cp", VerbName.COPY),
    ("move", VerbName.MOVE),
    ("mv", VerbName.MOVE),
    ("duplicate", VerbName.DUPLICATE),
    ("merge", VerbName.MERGE),
    ("split", VerbName.SPLIT),
    ("archive", VerbName.ARCHIVE),
    ("zip", VerbName.ARCHIVE),
    ("unzip", VerbName.EXTRACT),
    ("restore", VerbName.RESTORE),
    ("sort", VerbName.SORT),
    ("filter", VerbName.FILTER),
    ("group", VerbName.GROUP),
    ("count", VerbName.COUNT),
    ("analyse", VerbName.ANALYSE),
    ("analyze", VerbName.ANALYSE),
    ("calculate", VerbName.CALCULATE),
    ("measure", VerbName.MEASURE),
    ("transform", VerbName.TRANSFORM),
    ("validate", VerbName.VALIDATE),
    ("hash", VerbName.HASH),
    ("checksum", VerbName.HASH),
    ("compare", VerbName.COMPARE),
    ("diff", VerbName.DIFF),
    ("verify", VerbName.VERIFY),
    ("compress", VerbName.COMPRESS),
    ("extract", VerbName.EXTRACT),
    ("convert", VerbName.CONVERT),
    ("generate", VerbName.GENERATE),
    ("run", VerbName.RUN),
    ("execute", VerbName.EXECUTE),
    ("build", VerbName.BUILD),
    ("compile", VerbName.BUILD),
    ("test", VerbName.TEST),
    ("watch", VerbName.WATCH),
    ("monitor", VerbName.MONITOR),
    ("schedule", VerbName.SCHEDULE),
    ("report", VerbName.REPORT),
    ("export", VerbName.EXPORT),
    ("import", VerbName.IMPORT),
    ("undo", VerbName.UNDO),
    ("redo", VerbName.REDO),
    ("revert", VerbName.UNDO),
    ("list", VerbName.LIST),
    ("ls", VerbName.LIST),
    ("explain", VerbName.EXPLAIN),
    ("plan", VerbName.PLAN),
    ("preview", VerbName.PREVIEW),
    ("release", VerbName.RELEASE),
]


def resolve_verb_alias(raw_text: str) -> tuple[VerbName | None, str]:
    """Finds matching registered verb alias from start of text, returning (VerbName, remaining_text)."""
    clean = raw_text.strip()
    clean_lower = clean.lower()

    for alias, verb in NATURAL_LANGUAGE_ALIASES:
        # Check start with word boundary
        if clean_lower == alias:
            return verb, ""
        if clean_lower.startswith(alias + " ") or clean_lower.startswith(alias + ":"):
            remaining = clean[len(alias):].lstrip(" :")
            return verb, remaining

    return None, clean
