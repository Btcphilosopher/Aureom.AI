"""Execution Plan Generator and Graph Builder."""

import time
from dataclasses import dataclass, field
from typing import Any
from hardterminal.core.intents import Intent, ExecutionRequest
from hardterminal.core.registry import VerbRegistry
from hardterminal.safety.risk import RiskEngine, RiskAssessment, RiskLevel
from hardterminal.safety.policies import SafetyController
from hardterminal.planning.graph import ActionGraph, ActionNode
from hardterminal.planning.optimizer import GraphOptimizer
from hardterminal.planning.estimator import PlanEstimator


@dataclass
class ExecutionPlan:
    """A fully validated, inspectable execution plan."""
    plan_id: str
    primary_verb: str
    target_summary: str
    action_graph: ActionGraph
    risk: RiskAssessment
    estimated_cost_ms: float
    requires_confirmation: bool
    reversible: bool
    description: str = ""
    parameters_summary: dict[str, Any] = field(default_factory=dict)
    preview_details: dict[str, Any] = field(default_factory=dict)

    def formatted_text(self) -> str:
        """Produce the standard HardTerminal plan display string."""
        lines = [
            "HARDTERMINAL PLAN",
            "─" * 30,
            "",
        ]

        nodes = self.action_graph.topological_order()
        for i, node in enumerate(nodes):
            lines.append(f"VERB: {node.verb}")
            if node.target:
                lines.append(f"TARGET: {node.target}")

            if node.parameters:
                for k, v in node.parameters.items():
                    if v is not None and v != "":
                        lines.append(f"{k.upper()}:")
                        lines.append(f"{v}")
                        lines.append("")

            if i < len(nodes) - 1:
                lines.append("↓")
                lines.append("")

        lines.append("No changes made.")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "plan_id": self.plan_id,
            "primary_verb": self.primary_verb,
            "target_summary": self.target_summary,
            "action_graph": self.action_graph.to_dict(),
            "risk": self.risk.to_dict(),
            "estimated_cost_ms": self.estimated_cost_ms,
            "requires_confirmation": self.requires_confirmation,
            "reversible": self.reversible,
            "description": self.description,
            "parameters_summary": self.parameters_summary,
            "formatted_text": self.formatted_text(),
        }


class PlanGenerator:
    """Constructs ExecutionPlan and ActionGraph from Intents or ExecutionRequests."""

    def __init__(self, registry: VerbRegistry, risk_engine: RiskEngine, safety: SafetyController):
        self.registry = registry
        self.risk_engine = RiskEngine()
        self.safety = safety
        self.optimizer = GraphOptimizer()
        self.estimator = PlanEstimator()
        self._counter = 1

    def create_plan(self, intent_or_req: Intent | ExecutionRequest, context: Any) -> ExecutionPlan:
        plan_id = f"PLAN_{int(time.time())}_{self._counter:03d}"
        self._counter += 1

        if isinstance(intent_or_req, ExecutionRequest):
            verb = intent_or_req.verb.upper()
            target = intent_or_req.target
            parameters = intent_or_req.parameters
            is_pipeline = False
            pipeline_steps = []
        else:
            verb = intent_or_req.verb.upper()
            target = intent_or_req.target
            parameters = intent_or_req.parameters
            is_pipeline = intent_or_req.is_pipeline
            pipeline_steps = intent_or_req.pipeline_steps

        # Validate verb registered
        v_def = self.registry.get(verb)
        validated_params = v_def.validate_parameters(parameters)

        # Build Action Graph
        graph = ActionGraph(graph_id=f"GRAPH_{plan_id}")

        if is_pipeline and pipeline_steps:
            prev_node_id = None
            for idx, step_intent in enumerate(pipeline_steps):
                step_verb = step_intent.verb.upper()
                s_def = self.registry.get(step_verb)
                s_params = s_def.validate_parameters(step_intent.parameters)
                node_id = f"ACT_{plan_id}_{idx+1:02d}"
                node = ActionNode(
                    action_id=node_id,
                    verb=step_verb,
                    target=step_intent.target if idx == 0 else "$context.previous_results",
                    parameters=s_params,
                    risk=s_def.risk_level,
                    requires_confirmation=s_def.requires_confirmation,
                    reversible=s_def.reversible,
                )
                graph.add_node(node)
                if prev_node_id:
                    graph.add_dependency(prev_node_id, node_id, pass_output=True)
                prev_node_id = node_id
        else:
            node_id = f"ACT_{plan_id}_01"
            primary_node = ActionNode(
                action_id=node_id,
                verb=verb,
                target=target,
                parameters=validated_params,
                risk=v_def.risk_level,
                requires_confirmation=v_def.requires_confirmation,
                reversible=v_def.reversible,
            )
            graph.add_node(primary_node)

            # Auto-attach VERIFY and RELEASE nodes for modifying verbs
            if v_def.reversible or verb in ["MOVE", "COPY", "DELETE", "EDIT", "ARCHIVE"]:
                verify_id = f"ACT_{plan_id}_VERIFY"
                verify_node = ActionNode(action_id=verify_id, verb="VERIFY", target=target, risk=RiskLevel.NONE)
                graph.add_node(verify_node)
                graph.add_dependency(node_id, verify_id)

                release_id = f"ACT_{plan_id}_RELEASE"
                release_node = ActionNode(action_id=release_id, verb="RELEASE", target=target, risk=RiskLevel.NONE)
                graph.add_node(release_node)
                graph.add_dependency(verify_id, release_id)

        # Optimize graph
        graph = self.optimizer.optimize(graph)

        # Calculate risk and estimates
        risk = self.risk_engine.assess(verb, parameters=validated_params)
        estimates = self.estimator.estimate_action(verb, parameters=validated_params)

        target_summary = target or context.current_dir

        return ExecutionPlan(
            plan_id=plan_id,
            primary_verb=verb,
            target_summary=target_summary,
            action_graph=graph,
            risk=risk,
            estimated_cost_ms=estimates["estimated_cost_ms"],
            requires_confirmation=risk.requires_confirmation or v_def.requires_confirmation,
            reversible=v_def.reversible,
            description=f"Execute {verb} on {target_summary}",
            parameters_summary=validated_params,
        )

    def preview_plan(self, plan: ExecutionPlan, context: Any) -> dict:
        """Produce preview without executing side-effects."""
        return {
            "plan_id": plan.plan_id,
            "primary_verb": plan.primary_verb,
            "target": plan.target_summary,
            "risk_level": plan.risk.level.value,
            "requires_confirmation": plan.requires_confirmation,
            "affected_targets_est": plan.risk.affected_count,
            "formatted_plan": plan.formatted_text(),
            "no_filesystem_changes": True,
        }
