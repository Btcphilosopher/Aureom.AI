"""Action Graph Optimizer."""

from hardterminal.planning.graph import ActionGraph


class GraphOptimizer:
    """Optimizes action nodes, prunes redundant traversals, and combines steps."""

    def optimize(self, graph: ActionGraph) -> ActionGraph:
        # Deduplicate identical consecutive inspection nodes
        seen_verbs = set()
        for node in list(graph.nodes.values()):
            if node.verb in ["INSPECT", "CHECK"] and (node.verb, node.target) in seen_verbs:
                # Remove redundant
                del graph.nodes[node.action_id]
            else:
                seen_verbs.add((node.verb, node.target))

        return graph
