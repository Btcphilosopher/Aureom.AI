"""Action Graph, Nodes, Dependencies, and Execution Status."""

from dataclasses import dataclass, field
from enum import Enum, unique
from typing import Any
from hardterminal.safety.risk import RiskLevel


@unique
class ActionStatus(str, Enum):
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    VERIFIED = "VERIFIED"
    SKIPPED = "SKIPPED"


@dataclass
class ActionDependency:
    """Dependency link between action nodes."""
    parent_node_id: str
    child_node_id: str
    pass_output_as_target: bool = True


@dataclass
class ActionNode:
    """An individual atomic executable node inside the Action Graph."""
    action_id: str
    verb: str
    target: str | None = None
    parameters: dict[str, Any] = field(default_factory=dict)
    dependencies: list[str] = field(default_factory=list)  # parent action_ids
    risk: RiskLevel = RiskLevel.NONE
    estimated_cost_ms: float = 10.0
    status: ActionStatus = ActionStatus.QUEUED
    result: Any = None
    error: str | None = None
    requires_confirmation: bool = False
    reversible: bool = False

    def to_dict(self) -> dict:
        return {
            "action_id": self.action_id,
            "verb": self.verb,
            "target": self.target,
            "parameters": self.parameters,
            "dependencies": self.dependencies,
            "risk": self.risk.value if hasattr(self.risk, "value") else str(self.risk),
            "estimated_cost_ms": self.estimated_cost_ms,
            "status": self.status.value,
            "requires_confirmation": self.requires_confirmation,
            "reversible": self.reversible,
            "error": self.error,
        }


@dataclass
class ActionGraph:
    """Deterministic Directed Acyclic Graph (DAG) of executable actions."""
    graph_id: str
    nodes: dict[str, ActionNode] = field(default_factory=dict)
    dependencies: list[ActionDependency] = field(default_factory=list)

    def add_node(self, node: ActionNode):
        self.nodes[node.action_id] = node

    def add_dependency(self, parent_id: str, child_id: str, pass_output: bool = True):
        if parent_id in self.nodes and child_id in self.nodes:
            self.nodes[child_id].dependencies.append(parent_id)
            self.dependencies.append(ActionDependency(parent_id, child_id, pass_output))

    def topological_order(self) -> list[ActionNode]:
        """Compute execution order for the DAG."""
        visited: set[str] = set()
        order: list[ActionNode] = []

        def dfs(node_id: str):
            if node_id in visited:
                return
            node = self.nodes[node_id]
            for p in node.dependencies:
                if p in self.nodes:
                    dfs(p)
            visited.add(node_id)
            order.append(node)

        for n_id in self.nodes:
            dfs(n_id)

        return order

    def to_dict(self) -> dict:
        return {
            "graph_id": self.graph_id,
            "nodes": [n.to_dict() for n in self.topological_order()],
            "node_count": len(self.nodes),
        }
