"""Resource, latency, and disk space estimation."""

from hardterminal.core.targets import Target


class PlanEstimator:
    """Estimates latency, bytes affected, and disk space for an action."""

    def estimate_action(self, verb: str, targets: list[Target] | None = None, parameters: dict | None = None) -> dict:
        v_upper = str(verb).upper()
        target_list = targets or []
        count = len(target_list) if target_list else 1
        total_bytes = sum(t.size_bytes for t in target_list)

        # Baseline ms estimate
        cost_ms = 5.0
        if v_upper in ["FIND", "SEARCH"]:
            cost_ms = 20.0 + (count * 0.1)
        elif v_upper in ["COPY", "DUPLICATE", "COMPRESS", "ARCHIVE"]:
            cost_ms = 10.0 + (total_bytes / (1024 * 1024)) * 5.0
        elif v_upper in ["HASH", "VALIDATE", "DIFF", "COMPARE"]:
            cost_ms = 5.0 + (total_bytes / (1024 * 1024)) * 3.0
        elif v_upper in ["ANALYSE", "CALCULATE", "SORT", "FILTER"]:
            cost_ms = 8.0 + (count * 0.2)
        elif v_upper == "RUN":
            cost_ms = 100.0

        return {
            "estimated_cost_ms": max(1.0, cost_ms),
            "estimated_affected_objects": count,
            "estimated_bytes": total_bytes,
        }
