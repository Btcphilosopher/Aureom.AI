"""Audit Logger and Trail Persistence."""

import json
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class AuditEntry:
    entry_id: str
    timestamp: float
    actor: str
    verb: str
    target: str
    parameters: dict[str, Any]
    status: str
    risk_level: str
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "entry_id": self.entry_id,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self.timestamp)),
            "actor": self.actor,
            "verb": self.verb,
            "target": self.target,
            "parameters": self.parameters,
            "status": self.status,
            "risk_level": self.risk_level,
            "details": self.details,
        }


class AuditLogger:
    """Records every intent, execution, and transaction to an append-only audit trail."""

    def __init__(self):
        self.entries: list[AuditEntry] = []
        self._counter = 1

    def log_action(self, verb: str, target: str, parameters: dict, status: str, risk_level: str, details: dict | None = None) -> AuditEntry:
        entry = AuditEntry(
            entry_id=f"AUD_{int(time.time())}_{self._counter:04d}",
            timestamp=time.time(),
            actor="user",
            verb=verb,
            target=target,
            parameters=parameters,
            status=status,
            risk_level=risk_level,
            details=details or {},
        )
        self._counter += 1
        self.entries.append(entry)
        return entry

    def export_json(self) -> str:
        return json.dumps([e.to_dict() for e in self.entries], indent=2)
