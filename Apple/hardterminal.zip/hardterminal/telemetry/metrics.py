"""Telemetry and Performance Metrics Collector."""

import time
from dataclasses import dataclass, field


@dataclass
class PerformanceMetrics:
    """System and Execution telemetry metrics."""
    total_commands: int = 0
    successful_commands: int = 0
    failed_commands: int = 0
    total_latency_ms: float = 0.0
    files_processed: int = 0
    bytes_processed: int = 0
    start_time: float = field(default_factory=time.time)

    @property
    def success_rate_pct(self) -> float:
        if self.total_commands == 0:
            return 100.0
        return (self.successful_commands / self.total_commands) * 100.0

    @property
    def avg_latency_ms(self) -> float:
        if self.total_commands == 0:
            return 0.0
        return self.total_latency_ms / self.total_commands

    @property
    def throughput_objs_per_sec(self) -> float:
        elapsed = time.time() - self.start_time
        if elapsed <= 0:
            return 0.0
        return self.files_processed / elapsed

    def record_job(self, success: bool, duration_ms: float, files_count: int = 0, bytes_count: int = 0):
        self.total_commands += 1
        if success:
            self.successful_commands += 1
        else:
            self.failed_commands += 1
        self.total_latency_ms += duration_ms
        self.files_processed += files_count
        self.bytes_processed += bytes_count

    def to_dict(self) -> dict:
        return {
            "total_commands": self.total_commands,
            "successful_commands": self.successful_commands,
            "failed_commands": self.failed_commands,
            "success_rate_pct": round(self.success_rate_pct, 2),
            "avg_latency_ms": round(self.avg_latency_ms, 2),
            "files_processed": self.files_processed,
            "bytes_processed": self.bytes_processed,
            "throughput_objs_per_sec": round(self.throughput_objs_per_sec, 2),
            "uptime_seconds": round(time.time() - self.start_time, 1),
        }
