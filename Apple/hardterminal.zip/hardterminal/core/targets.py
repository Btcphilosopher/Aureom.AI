"""Target Object System and Handle Management."""

from dataclasses import dataclass, field
from enum import Enum, unique
import os
import pathlib
import mimetypes
from typing import Any
import hashlib


@unique
class TargetType(str, Enum):
    FILE = "FILE"
    DIRECTORY = "DIRECTORY"
    TEXT = "TEXT"
    IMAGE = "IMAGE"
    VIDEO = "VIDEO"
    AUDIO = "AUDIO"
    JSON = "JSON"
    CSV = "CSV"
    XML = "XML"
    YAML = "YAML"
    LOG = "LOG"
    SOURCE_CODE = "SOURCE_CODE"
    APPLICATION = "APPLICATION"
    PROCESS = "PROCESS"
    COMMAND_OUTPUT = "COMMAND_OUTPUT"
    DATASET = "DATASET"
    ARCHIVE = "ARCHIVE"
    ANY = "ANY"


def infer_target_type(path_str: str) -> TargetType:
    """Deterministically infer the TargetType of a path or object."""
    if not path_str:
        return TargetType.FILE

    p = pathlib.Path(path_str).expanduser()
    if p.is_dir():
        if p.suffix == ".app":
            return TargetType.APPLICATION
        return TargetType.DIRECTORY

    ext = p.suffix.lower()
    if ext in [".csv", ".tsv"]:
        return TargetType.CSV
    if ext in [".json", ".jsonl", ".geojson"]:
        return TargetType.JSON
    if ext in [".yaml", ".yml"]:
        return TargetType.YAML
    if ext in [".xml", ".html", ".svg"]:
        return TargetType.XML
    if ext in [".log", ".out"]:
        return TargetType.LOG
    if ext in [".py", ".ts", ".js", ".tsx", ".jsx", ".rs", ".go", ".c", ".cpp", ".h", ".sh", ".swift", ".java", ".rb"]:
        return TargetType.SOURCE_CODE
    if ext in [".zip", ".tar", ".gz", ".tgz", ".bz2", ".7z", ".rar"]:
        return TargetType.ARCHIVE
    if ext in [".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tiff", ".heic"]:
        return TargetType.IMAGE
    if ext in [".mp4", ".mov", ".avi", ".mkv", ".webm"]:
        return TargetType.VIDEO
    if ext in [".mp3", ".wav", ".aac", ".flac", ".m4a", ".ogg"]:
        return TargetType.AUDIO
    if ext in [".txt", ".md", ".rst", ".rtf", ".pdf"]:
        return TargetType.TEXT

    mime, _ = mimetypes.guess_type(path_str)
    if mime:
        if mime.startswith("text/"):
            return TargetType.TEXT
        if mime.startswith("image/"):
            return TargetType.IMAGE
        if mime.startswith("video/"):
            return TargetType.VIDEO
        if mime.startswith("audio/"):
            return TargetType.AUDIO

    return TargetType.FILE


@dataclass
class Target:
    """Individual target instance in the HardTerminal environment."""
    handle: str
    raw_path: str
    resolved_path: str
    target_type: TargetType
    metadata: dict[str, Any] = field(default_factory=dict)
    size_bytes: int = 0
    content: Any = None
    exists: bool = True

    def calculate_hash(self) -> str:
        """Compute sha256 checksum if file exists."""
        if not self.exists or not os.path.isfile(self.resolved_path):
            return ""
        hasher = hashlib.sha256()
        try:
            with open(self.resolved_path, "rb") as f:
                while chunk := f.read(65536):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except Exception:
            return ""

    def to_dict(self) -> dict:
        return {
            "handle": self.handle,
            "raw_path": self.raw_path,
            "resolved_path": self.resolved_path,
            "target_type": self.target_type.value,
            "size_bytes": self.size_bytes,
            "exists": self.exists,
            "metadata": self.metadata,
        }


@dataclass
class TargetCollection:
    """A collection of targets bound together with an aggregate handle."""
    handle: str
    targets: list[Target] = field(default_factory=list)
    description: str = ""
    source_verb: str = ""

    @property
    def count(self) -> int:
        return len(self.targets)

    @property
    def total_size_bytes(self) -> int:
        return sum(t.size_bytes for t in self.targets)

    def to_dict(self) -> dict:
        return {
            "handle": self.handle,
            "count": self.count,
            "total_size_bytes": self.total_size_bytes,
            "description": self.description,
            "source_verb": self.source_verb,
            "targets": [t.to_dict() for t in self.targets],
        }


class TargetHandle:
    """Helper for formatting and validating target handle strings (e.g. #001, #12)."""
    @staticmethod
    def format(number: int) -> str:
        return f"#{number:03d}" if number < 1000 else f"#{number}"

    @staticmethod
    def is_handle(token: str) -> bool:
        if not token:
            return False
        token = token.strip()
        return token.startswith("#") and token[1:].isdigit()

    @staticmethod
    def parse_number(token: str) -> int:
        if not TargetHandle.is_handle(token):
            raise ValueError(f"Invalid handle format: {token}")
        return int(token.strip()[1:])


class TargetResolver:
    """Resolves path strings, handles, and context references to concrete Target objects."""
    def __init__(self, workspace_root: str = "."):
        self.workspace_root = os.path.abspath(os.path.expanduser(workspace_root))

    def resolve_path(self, raw_path: str, working_dir: str | None = None) -> str:
        """Resolve a raw path to an absolute normalized filesystem path."""
        if not raw_path:
            return self.workspace_root

        base = working_dir or self.workspace_root
        expanded = os.path.expanduser(raw_path)
        if os.path.isabs(expanded):
            return os.path.normpath(expanded)
        return os.path.normpath(os.path.join(base, expanded))

    def create_target(self, path_str: str, handle_str: str, working_dir: str | None = None) -> Target:
        """Construct a validated Target from a path."""
        resolved = self.resolve_path(path_str, working_dir)
        exists = os.path.exists(resolved)
        t_type = infer_target_type(resolved)
        size = 0
        metadata: dict[str, Any] = {}

        if exists:
            try:
                st = os.stat(resolved)
                size = st.st_size
                metadata = {
                    "mode": oct(st.st_mode),
                    "modified": st.st_mtime,
                    "created": st.st_ctime,
                    "is_dir": os.path.isdir(resolved),
                    "is_file": os.path.isfile(resolved),
                }
            except Exception as e:
                metadata["stat_error"] = str(e)

        return Target(
            handle=handle_str,
            raw_path=path_str,
            resolved_path=resolved,
            target_type=t_type,
            metadata=metadata,
            size_bytes=size,
            exists=exists,
        )
