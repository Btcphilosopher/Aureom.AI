"""Abstract Syntax Tree (AST) definitions for HardTerminal Grammar."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ASTNode:
    """Base node for HardTerminal syntax tree."""
    def to_dict(self) -> dict:
        return {"node_type": self.__class__.__name__}


@dataclass
class TargetExpressionNode(ASTNode):
    """Expression identifying a target (handle, path, or context reference)."""
    raw_value: str
    is_handle: bool = False
    is_context_ref: bool = False
    handle_number: int | None = None

    def to_dict(self) -> dict:
        return {
            "node_type": "TargetExpressionNode",
            "raw_value": self.raw_value,
            "is_handle": self.is_handle,
            "is_context_ref": self.is_context_ref,
            "handle_number": self.handle_number,
        }


@dataclass
class ParameterNode(ASTNode):
    """Key-value parameter node."""
    key: str
    value: Any
    raw_text: str = ""

    def to_dict(self) -> dict:
        return {
            "node_type": "ParameterNode",
            "key": self.key,
            "value": self.value,
            "raw_text": self.raw_text,
        }


@dataclass
class VerbCommandNode(ASTNode):
    """An individual verb invocation node."""
    verb: str
    target: TargetExpressionNode | None = None
    parameters: dict[str, Any] = field(default_factory=dict)
    flags: dict[str, bool] = field(default_factory=dict)
    with_target: TargetExpressionNode | None = None  # e.g. COMPARE #1 WITH #2

    def to_dict(self) -> dict:
        return {
            "node_type": "VerbCommandNode",
            "verb": self.verb,
            "target": self.target.to_dict() if self.target else None,
            "with_target": self.with_target.to_dict() if self.with_target else None,
            "parameters": self.parameters,
            "flags": self.flags,
        }


@dataclass
class PipelineNode(ASTNode):
    """A series of piped verbs (e.g. FIND -> GRAB -> ANALYSE)."""
    steps: list[VerbCommandNode] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "node_type": "PipelineNode",
            "steps": [s.to_dict() for s in self.steps],
        }


@dataclass
class WorkflowNode(ASTNode):
    """An executable multi-statement script or .hardterminal workflow."""
    name: str = ""
    statements: list[ASTNode] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "node_type": "WorkflowNode",
            "name": self.name,
            "statements": [s.to_dict() for s in self.statements],
        }


@dataclass
class ScheduleExpressionNode(ASTNode):
    """Schedule specification AST node."""
    frequency: str  # daily, weekly, hourly, once
    day: str | None = None
    time: str | None = None
    action_command: VerbCommandNode | PipelineNode | None = None

    def to_dict(self) -> dict:
        return {
            "node_type": "ScheduleExpressionNode",
            "frequency": self.frequency,
            "day": self.day,
            "time": self.time,
            "action": self.action_command.to_dict() if self.action_command else None,
        }
