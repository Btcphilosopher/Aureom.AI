"""Context Engine and Workspace State Management."""

from dataclasses import dataclass, field
from typing import Any
import os
import time
from hardterminal.core.targets import (
    Target,
    TargetCollection,
    TargetHandle,
    TargetResolver,
)


@dataclass
class JobRecord:
    """Historical record of an executed command or pipeline."""
    job_id: str
    timestamp: str
    verb: str
    target_summary: str
    status: str
    duration_ms: float
    affected_count: int
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "job_id": self.job_id,
            "timestamp": self.timestamp,
            "verb": self.verb,
            "target": self.target_summary,
            "status": self.status,
            "duration_ms": self.duration_ms,
            "affected_count": self.affected_count,
            "details": self.details,
        }


class WorkspaceContext:
    """Stateful runtime context for a HardTerminal session."""

    def __init__(self, root_dir: str = "."):
        self.root_dir = os.path.abspath(os.path.expanduser(root_dir))
        self.current_dir = self.root_dir
        self.resolver = TargetResolver(self.root_dir)

        # Object handle storage
        self.targets: dict[str, Target] = {}
        self.collections: dict[str, TargetCollection] = {}
        self._next_target_id = 1
        self._next_collection_id = 1

        # Session state
        self.previous_targets: list[Target] = []
        self.last_target: Target | None = None
        self.last_collection: TargetCollection | None = None
        self.last_verb: str = ""
        self.last_result: Any = None
        self.active_project: str | None = None
        self.active_dataset: str | None = None
        self.active_job: str | None = None

        # History
        self.history: list[JobRecord] = []
        self._job_counter = 1

    def change_directory(self, new_dir: str) -> str:
        """Change current directory safely."""
        resolved = self.resolver.resolve_path(new_dir, self.current_dir)
        if not os.path.isdir(resolved):
            raise FileNotFoundError(f"Directory not found: {new_dir}")
        self.current_dir = resolved
        return self.current_dir

    def allocate_target(self, path: str, metadata: dict[str, Any] | None = None) -> Target:
        """Create and store a numbered Target handle."""
        handle = TargetHandle.format(self._next_target_id)
        self._next_target_id += 1
        target = self.resolver.create_target(path, handle, self.current_dir)
        if metadata:
            target.metadata.update(metadata)
        self.targets[handle] = target
        self.last_target = target
        return target

    def allocate_collection(self, targets: list[Target], description: str = "", source_verb: str = "") -> TargetCollection:
        """Group a set of targets into a target collection handle."""
        col_handle = f"#{self._next_collection_id:02d}" if self._next_collection_id < 100 else f"#{self._next_collection_id}"
        self._next_collection_id += 1
        collection = TargetCollection(
            handle=col_handle,
            targets=targets,
            description=description,
            source_verb=source_verb,
        )
        self.collections[col_handle] = collection
        self.last_collection = collection
        self.previous_targets = list(targets)
        return collection

    def get_target_or_collection(self, handle_or_path: str) -> Target | TargetCollection | None:
        """Retrieve by #handle or path reference."""
        if not handle_or_path:
            return None

        handle_clean = handle_or_path.strip()
        if handle_clean in self.targets:
            return self.targets[handle_clean]
        if handle_clean in self.collections:
            return self.collections[handle_clean]

        # Check for context reference strings
        if handle_clean in ["$context.previous_results", "$previous", "these", "them", "those", "results", "TARGETS"]:
            if self.last_collection and self.last_collection.targets:
                return self.last_collection
            if self.previous_targets:
                return self.allocate_collection(self.previous_targets, "Previous results")
            if self.last_target:
                return self.last_target

        # Try resolving as file/directory path
        resolved = self.resolver.resolve_path(handle_clean, self.current_dir)
        if os.path.exists(resolved):
            return self.allocate_target(handle_clean)

        return None

    def record_job(self, plan: Any, report: Any):
        """Append to workspace history."""
        job_id = f"{self._job_counter:03d}"
        self._job_counter += 1
        ts = time.strftime("%H:%M:%S")

        verb = getattr(plan, "primary_verb", "UNKNOWN")
        target_summary = str(getattr(plan, "target_summary", "workspace"))
        status = "SUCCESS" if getattr(report, "success", False) else "FAILED"
        duration_ms = getattr(report, "duration_ms", 0.0)
        affected = len(getattr(report, "affected_targets", []))

        record = JobRecord(
            job_id=job_id,
            timestamp=ts,
            verb=verb,
            target_summary=target_summary,
            status=status,
            duration_ms=duration_ms,
            affected_count=affected,
            details=report.to_dict() if hasattr(report, "to_dict") else {},
        )
        self.history.append(record)
        self.last_operation = verb
        self.last_result = report

    def get_status_summary(self) -> dict:
        """Return high-level summary for workspace status bar."""
        rel_ws = self.current_dir.replace(os.path.expanduser("~"), "~")
        return {
            "workspace": rel_ws,
            "target_count": len(self.targets) + sum(c.count for c in self.collections.values()),
            "state": "READY",
            "active_project": self.active_project or "default",
            "history_count": len(self.history),
        }
