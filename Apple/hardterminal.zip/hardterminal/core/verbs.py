"""All 60+ hard-coded primary verbs and categories."""

from enum import Enum, unique


@unique
class VerbName(str, Enum):
    # Acquisition
    GRAB = "GRAB"
    FIND = "FIND"
    SEARCH = "SEARCH"
    LIST = "LIST"

    # Inspection
    INSPECT = "INSPECT"
    READ = "READ"
    OPEN = "OPEN"
    SHOW = "SHOW"
    DESCRIBE = "DESCRIBE"
    CHECK = "CHECK"

    # Modification
    CREATE = "CREATE"
    MAKE = "MAKE"
    EDIT = "EDIT"
    REPLACE = "REPLACE"
    INSERT = "INSERT"
    DELETE = "DELETE"
    REMOVE = "REMOVE"
    RENAME = "RENAME"

    # Filesystem
    COPY = "COPY"
    MOVE = "MOVE"
    DUPLICATE = "DUPLICATE"
    MERGE = "MERGE"
    SPLIT = "SPLIT"
    ARCHIVE = "ARCHIVE"
    RESTORE = "RESTORE"

    # Data
    SORT = "SORT"
    FILTER = "FILTER"
    GROUP = "GROUP"
    COUNT = "COUNT"
    ANALYSE = "ANALYSE"
    CALCULATE = "CALCULATE"
    MEASURE = "MEASURE"
    TRANSFORM = "TRANSFORM"

    # Validation
    VALIDATE = "VALIDATE"
    HASH = "HASH"
    COMPARE = "COMPARE"
    DIFF = "DIFF"
    VERIFY = "VERIFY"

    # Compression / Conversion
    COMPRESS = "COMPRESS"
    EXTRACT = "EXTRACT"
    CONVERT = "CONVERT"
    GENERATE = "GENERATE"

    # System
    RUN = "RUN"
    BUILD = "BUILD"
    TEST = "TEST"
    START = "START"
    STOP = "STOP"
    PAUSE = "PAUSE"
    RESUME = "RESUME"

    # Automation
    WATCH = "WATCH"
    MONITOR = "MONITOR"
    SCHEDULE = "SCHEDULE"

    # Output
    REPORT = "REPORT"
    EXPORT = "EXPORT"
    IMPORT = "IMPORT"

    # Control
    PLAN = "PLAN"
    PREVIEW = "PREVIEW"
    EXECUTE = "EXECUTE"
    RELEASE = "RELEASE"
    UNDO = "UNDO"
    REDO = "REDO"
    EXPLAIN = "EXPLAIN"


@unique
class VerbCategory(str, Enum):
    ACQUISITION = "Acquisition"
    INSPECTION = "Inspection"
    MODIFICATION = "Modification"
    FILESYSTEM = "Filesystem"
    DATA = "Data"
    VALIDATION = "Validation"
    CONVERSION = "Conversion"
    SYSTEM = "System"
    AUTOMATION = "Automation"
    OUTPUT = "Output"
    CONTROL = "Control"


VERB_CATEGORY_MAP: dict[VerbName, VerbCategory] = {
    # Acquisition
    VerbName.GRAB: VerbCategory.ACQUISITION,
    VerbName.FIND: VerbCategory.ACQUISITION,
    VerbName.SEARCH: VerbCategory.ACQUISITION,
    VerbName.LIST: VerbCategory.ACQUISITION,

    # Inspection
    VerbName.INSPECT: VerbCategory.INSPECTION,
    VerbName.READ: VerbCategory.INSPECTION,
    VerbName.OPEN: VerbCategory.INSPECTION,
    VerbName.SHOW: VerbCategory.INSPECTION,
    VerbName.DESCRIBE: VerbCategory.INSPECTION,
    VerbName.CHECK: VerbCategory.INSPECTION,

    # Modification
    VerbName.CREATE: VerbCategory.MODIFICATION,
    VerbName.MAKE: VerbCategory.MODIFICATION,
    VerbName.EDIT: VerbCategory.MODIFICATION,
    VerbName.REPLACE: VerbCategory.MODIFICATION,
    VerbName.INSERT: VerbCategory.MODIFICATION,
    VerbName.DELETE: VerbCategory.MODIFICATION,
    VerbName.REMOVE: VerbCategory.MODIFICATION,
    VerbName.RENAME: VerbCategory.MODIFICATION,

    # Filesystem
    VerbName.COPY: VerbCategory.FILESYSTEM,
    VerbName.MOVE: VerbCategory.FILESYSTEM,
    VerbName.DUPLICATE: VerbCategory.FILESYSTEM,
    VerbName.MERGE: VerbCategory.FILESYSTEM,
    VerbName.SPLIT: VerbCategory.FILESYSTEM,
    VerbName.ARCHIVE: VerbCategory.FILESYSTEM,
    VerbName.RESTORE: VerbCategory.FILESYSTEM,

    # Data
    VerbName.SORT: VerbCategory.DATA,
    VerbName.FILTER: VerbCategory.DATA,
    VerbName.GROUP: VerbCategory.DATA,
    VerbName.COUNT: VerbCategory.DATA,
    VerbName.ANALYSE: VerbCategory.DATA,
    VerbName.CALCULATE: VerbCategory.DATA,
    VerbName.MEASURE: VerbCategory.DATA,
    VerbName.TRANSFORM: VerbCategory.DATA,

    # Validation
    VerbName.VALIDATE: VerbCategory.VALIDATION,
    VerbName.HASH: VerbCategory.VALIDATION,
    VerbName.COMPARE: VerbCategory.VALIDATION,
    VerbName.DIFF: VerbCategory.VALIDATION,
    VerbName.VERIFY: VerbCategory.VALIDATION,

    # Conversion
    VerbName.COMPRESS: VerbCategory.CONVERSION,
    VerbName.EXTRACT: VerbCategory.CONVERSION,
    VerbName.CONVERT: VerbCategory.CONVERSION,
    VerbName.GENERATE: VerbCategory.CONVERSION,

    # System
    VerbName.RUN: VerbCategory.SYSTEM,
    VerbName.BUILD: VerbCategory.SYSTEM,
    VerbName.TEST: VerbCategory.SYSTEM,
    VerbName.START: VerbCategory.SYSTEM,
    VerbName.STOP: VerbCategory.SYSTEM,
    VerbName.PAUSE: VerbCategory.SYSTEM,
    VerbName.RESUME: VerbCategory.SYSTEM,

    # Automation
    VerbName.WATCH: VerbCategory.AUTOMATION,
    VerbName.MONITOR: VerbCategory.AUTOMATION,
    VerbName.SCHEDULE: VerbCategory.AUTOMATION,

    # Output
    VerbName.REPORT: VerbCategory.OUTPUT,
    VerbName.EXPORT: VerbCategory.OUTPUT,
    VerbName.IMPORT: VerbCategory.OUTPUT,

    # Control
    VerbName.PLAN: VerbCategory.CONTROL,
    VerbName.PREVIEW: VerbCategory.CONTROL,
    VerbName.EXECUTE: VerbCategory.CONTROL,
    VerbName.RELEASE: VerbCategory.CONTROL,
    VerbName.UNDO: VerbCategory.CONTROL,
    VerbName.REDO: VerbCategory.CONTROL,
    VerbName.EXPLAIN: VerbCategory.CONTROL,
}
