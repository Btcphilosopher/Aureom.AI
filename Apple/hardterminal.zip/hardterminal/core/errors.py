"""Deterministic error types for HardTerminal kernel."""


class HardTerminalError(Exception):
    """Base exception for all HardTerminal errors."""
    def __init__(self, message: str, hint: str | None = None, details: dict | None = None):
        super().__init__(message)
        self.message = message
        self.hint = hint
        self.details = details or {}

    def to_dict(self) -> dict:
        return {
            "error_type": self.__class__.__name__,
            "message": self.message,
            "hint": self.hint,
            "details": self.details,
        }


class UnknownVerbError(HardTerminalError):
    """Raised when an unregistered verb is invoked."""
    pass


class AmbiguousRequestError(HardTerminalError):
    """Raised when natural language cannot deterministically resolve to required parameters."""
    def __init__(self, message: str, required_parameters: list[str] | None = None, hint: str | None = None):
        super().__init__(message, hint=hint, details={"required_parameters": required_parameters or []})
        self.required_parameters = required_parameters or []


class SafetyViolationError(HardTerminalError):
    """Raised when an action violates system safety policies or protected paths."""
    pass


class TargetNotFoundError(HardTerminalError):
    """Raised when a handle or path target does not exist or cannot be resolved."""
    pass


class InvalidTargetTypeError(HardTerminalError):
    """Raised when a verb is passed a target type it does not support."""
    pass


class InvalidParameterError(HardTerminalError):
    """Raised when parameter names or values do not match registered definitions."""
    pass


class ExecutionError(HardTerminalError):
    """Raised when an action node fails during graph execution."""
    pass


class TransactionError(HardTerminalError):
    """Raised when a transaction snapshot or rollback fails."""
    pass


class PipelineError(HardTerminalError):
    """Raised when verbs in a pipeline cannot be composed due to type mismatch."""
    pass
