"""Hard-coded Verb Registry and Definitions."""

from dataclasses import dataclass, field
from typing import Any, Callable
from hardterminal.core.verbs import VerbName, VerbCategory, VERB_CATEGORY_MAP
from hardterminal.core.targets import TargetType
from hardterminal.safety.risk import RiskLevel
from hardterminal.core.errors import UnknownVerbError, InvalidParameterError


@dataclass
class VerbParameter:
    """Declared parameter for a registered verb."""
    name: str
    description: str
    param_type: str = "str"
    required: bool = False
    default: Any = None
    choices: list[Any] | None = None

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "param_type": self.param_type,
            "required": self.required,
            "default": self.default,
            "choices": self.choices,
        }


@dataclass
class VerbResult:
    """Deterministic result structure returned from verb execution."""
    success: bool
    data: Any = None
    error: str | None = None
    targets: list[Any] = field(default_factory=list)
    duration_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "data": self.data,
            "error": self.error,
            "targets": [t.to_dict() if hasattr(t, "to_dict") else str(t) for t in self.targets],
            "duration_ms": self.duration_ms,
            "metadata": self.metadata,
        }


@dataclass
class VerbDefinition:
    """Registered hard-coded definition of an executable verb."""
    name: str
    description: str
    category: VerbCategory
    handler: Callable[..., VerbResult] | None = None
    parameters: dict[str, VerbParameter] = field(default_factory=dict)
    target_types: list[TargetType] = field(default_factory=lambda: [TargetType.ANY])
    risk_level: RiskLevel = RiskLevel.NONE
    reversible: bool = False
    requires_confirmation: bool = False
    supports_dry_run: bool = True
    supports_batch: bool = True
    supports_pipeline: bool = True

    def validate_parameters(self, given_params: dict[str, Any]) -> dict[str, Any]:
        """Validate and apply defaults to passed parameters."""
        validated: dict[str, Any] = {}

        # Check required parameters
        for p_name, p_def in self.parameters.items():
            if p_name in given_params and given_params[p_name] is not None:
                val = given_params[p_name]
                if p_def.choices and val not in p_def.choices:
                    raise InvalidParameterError(
                        f"Value '{val}' for parameter '{p_name}' not in allowed choices: {p_def.choices}"
                    )
                validated[p_name] = val
            elif p_def.required:
                raise InvalidParameterError(f"Verb '{self.name}' requires parameter '{p_name}'.")
            else:
                validated[p_name] = p_def.default

        # Allow extra parameter pass-through if not in strict violation
        for k, v in given_params.items():
            if k not in validated:
                validated[k] = v

        return validated

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "category": self.category.value,
            "parameters": {k: v.to_dict() for k, v in self.parameters.items()},
            "target_types": [t.value for t in self.target_types],
            "risk_level": self.risk_level.value,
            "reversible": self.reversible,
            "requires_confirmation": self.requires_confirmation,
            "supports_dry_run": self.supports_dry_run,
            "supports_batch": self.supports_batch,
            "supports_pipeline": self.supports_pipeline,
        }


class VerbRegistry:
    """Extensible yet strict registry for all executable verbs."""

    def __init__(self):
        self._verbs: dict[str, VerbDefinition] = {}

    def register(self, definition: VerbDefinition):
        name_key = definition.name.upper()
        self._verbs[name_key] = definition

    def get(self, name: str | VerbName) -> VerbDefinition:
        key = name.value.upper() if isinstance(name, VerbName) else str(name).upper()
        if key not in self._verbs:
            raise UnknownVerbError(
                f"Unknown verb '{key}'. HardTerminal only allows registered verbs.",
                hint=f"Available verbs include: {', '.join(list(self._verbs.keys())[:8])}..."
            )
        return self._verbs[key]

    def contains(self, name: str | VerbName) -> bool:
        key = name.value.upper() if isinstance(name, VerbName) else str(name).upper()
        return key in self._verbs

    def list_all(self) -> list[VerbDefinition]:
        return list(self._verbs.values())

    def list_by_category(self, category: VerbCategory) -> list[VerbDefinition]:
        return [v for v in self._verbs.values() if v.category == category]


_default_registry_instance: VerbRegistry | None = None


def default_registry() -> VerbRegistry:
    """Instantiate and populate the standard HardTerminal verb registry."""
    global _default_registry_instance
    if _default_registry_instance is not None:
        return _default_registry_instance

    reg = VerbRegistry()

    # Import verb handlers from filesystem, data, validation, system, automation, control
    from hardterminal.filesystem.grab import grab_handler
    from hardterminal.filesystem.find import find_handler, search_handler, list_handler
    from hardterminal.filesystem.edit import (
        inspect_handler, read_handler, open_handler, show_handler, describe_handler, check_handler,
        edit_handler, replace_handler, insert_handler, delete_handler, remove_handler, rename_handler,
        create_handler, make_handler
    )
    from hardterminal.filesystem.move import move_handler, copy_handler, duplicate_handler
    from hardterminal.filesystem.hashing import hash_handler, compare_handler, diff_handler, validate_handler, verify_handler
    from hardterminal.data.transforms import (
        sort_handler, filter_handler, group_handler, count_handler,
        analyse_handler, calculate_handler, measure_handler, transform_handler,
        merge_handler, split_handler, compress_handler, extract_handler, convert_handler, generate_handler
    )
    from hardterminal.execution.subprocess_runner import run_handler, build_handler, test_handler, start_handler, stop_handler, pause_handler, resume_handler
    from hardterminal.automation.workflows import (
        watch_handler, monitor_handler, schedule_handler,
        report_handler, export_handler, import_handler,
        archive_handler, restore_handler, undo_handler, redo_handler,
        explain_handler, plan_handler, preview_handler, execute_handler, release_handler
    )

    # 1. ACQUISITION
    reg.register(VerbDefinition(
        name=VerbName.GRAB.value,
        description="Acquire one or more objects into a numbered Target Collection",
        category=VerbCategory.ACQUISITION,
        handler=grab_handler,
        parameters={"pattern": VerbParameter("pattern", "Wildcard filter pattern", default=None)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
        supports_batch=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.FIND.value,
        description="Search directory hierarchy matching pattern, size, date, or extension",
        category=VerbCategory.ACQUISITION,
        handler=find_handler,
        parameters={
            "pattern": VerbParameter("pattern", "Glob pattern or filename match", default="*"),
            "extension": VerbParameter("extension", "File extension (e.g. pdf, csv)", default=None),
            "size": VerbParameter("size", "Size constraint (e.g. >100MB, <10KB)", default=None),
            "modified": VerbParameter("modified", "Modification time constraint (e.g. >180 days)", default=None),
            "created": VerbParameter("created", "Creation time constraint", default=None),
            "content": VerbParameter("content", "Search text within file contents", default=None),
            "max_depth": VerbParameter("max_depth", "Maximum directory recursion depth", param_type="int", default=10),
        },
        target_types=[TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.SEARCH.value,
        description="Full-text and metadata search within target collections or paths",
        category=VerbCategory.ACQUISITION,
        handler=search_handler,
        parameters={"query": VerbParameter("query", "Text or regex query string", required=False, default="")},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.LIST.value,
        description="List contents and handles of a directory or active workspace",
        category=VerbCategory.ACQUISITION,
        handler=list_handler,
        parameters={"detailed": VerbParameter("detailed", "Show detailed metadata", param_type="bool", default=True)},
        target_types=[TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))

    # 2. INSPECTION
    reg.register(VerbDefinition(
        name=VerbName.INSPECT.value,
        description="Inspect metadata, dimensions, encodings, and statistics of targets",
        category=VerbCategory.INSPECTION,
        handler=inspect_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.READ.value,
        description="Read text or structured content of a target",
        category=VerbCategory.INSPECTION,
        handler=read_handler,
        parameters={
            "lines": VerbParameter("lines", "Number of lines to read", param_type="int", default=50),
            "offset": VerbParameter("offset", "Starting line offset", param_type="int", default=0),
        },
        target_types=[TargetType.FILE, TargetType.TEXT, TargetType.CSV, TargetType.JSON, TargetType.LOG, TargetType.SOURCE_CODE],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.OPEN.value,
        description="Open target using macOS default application",
        category=VerbCategory.INSPECTION,
        handler=open_handler,
        parameters={"app": VerbParameter("app", "Specific application name", default=None)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
    ))
    reg.register(VerbDefinition(
        name=VerbName.SHOW.value,
        description="Render preview, table, or representation of target in terminal",
        category=VerbCategory.INSPECTION,
        handler=show_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.DESCRIBE.value,
        description="Describe schema, structure, or purpose of targets",
        category=VerbCategory.INSPECTION,
        handler=describe_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.CHECK.value,
        description="Check status, presence, permissions, or health of target",
        category=VerbCategory.INSPECTION,
        handler=check_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))

    # 3. MODIFICATION
    reg.register(VerbDefinition(
        name=VerbName.CREATE.value,
        description="Create a new file or directory",
        category=VerbCategory.MODIFICATION,
        handler=create_handler,
        parameters={
            "is_dir": VerbParameter("is_dir", "Create as directory", param_type="bool", default=False),
            "content": VerbParameter("content", "Initial text content", default=""),
        },
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.MAKE.value,
        description="Make a file, directory, or artifact",
        category=VerbCategory.MODIFICATION,
        handler=make_handler,
        parameters={"is_dir": VerbParameter("is_dir", "Create directory", param_type="bool", default=False)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.EDIT.value,
        description="Apply structured patch, replacement, or modification to a target",
        category=VerbCategory.MODIFICATION,
        handler=edit_handler,
        parameters={
            "find": VerbParameter("find", "Substring or regex to find", default=None),
            "replace": VerbParameter("replace", "Replacement text", default=None),
            "content": VerbParameter("content", "New full content", default=None),
        },
        target_types=[TargetType.TEXT, TargetType.FILE, TargetType.SOURCE_CODE, TargetType.CSV, TargetType.JSON, TargetType.YAML, TargetType.LOG],
        risk_level=RiskLevel.MEDIUM,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.REPLACE.value,
        description="Replace text, pattern, or data in target",
        category=VerbCategory.MODIFICATION,
        handler=replace_handler,
        parameters={
            "pattern": VerbParameter("pattern", "Pattern or string to replace", required=True),
            "replacement": VerbParameter("replacement", "Replacement string", required=True),
        },
        target_types=[TargetType.TEXT, TargetType.FILE, TargetType.SOURCE_CODE, TargetType.DATASET],
        risk_level=RiskLevel.MEDIUM,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.INSERT.value,
        description="Insert text or lines at specified position",
        category=VerbCategory.MODIFICATION,
        handler=insert_handler,
        parameters={
            "content": VerbParameter("content", "Content to insert", required=True),
            "line": VerbParameter("line", "Line number to insert at", param_type="int", default=-1),
        },
        target_types=[TargetType.TEXT, TargetType.FILE, TargetType.SOURCE_CODE],
        risk_level=RiskLevel.MEDIUM,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.DELETE.value,
        description="Delete target files or directories into safety trash / snapshot",
        category=VerbCategory.MODIFICATION,
        handler=delete_handler,
        parameters={"force": VerbParameter("force", "Force deletion", param_type="bool", default=False)},
        target_types=[TargetType.FILE, TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.HIGH,
        reversible=True,
        requires_confirmation=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.REMOVE.value,
        description="Remove target files or entries",
        category=VerbCategory.MODIFICATION,
        handler=remove_handler,
        parameters={"force": VerbParameter("force", "Force removal", param_type="bool", default=False)},
        target_types=[TargetType.FILE, TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.HIGH,
        reversible=True,
        requires_confirmation=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.RENAME.value,
        description="Rename a target object to a new name",
        category=VerbCategory.MODIFICATION,
        handler=rename_handler,
        parameters={"new_name": VerbParameter("new_name", "New filename or handle title", required=True)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
        reversible=True,
    ))

    # 4. FILESYSTEM
    reg.register(VerbDefinition(
        name=VerbName.COPY.value,
        description="Copy targets to destination path or directory",
        category=VerbCategory.FILESYSTEM,
        handler=copy_handler,
        parameters={"destination": VerbParameter("destination", "Destination folder or file", required=True)},
        target_types=[TargetType.FILE, TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.LOW,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.MOVE.value,
        description="Move one or more filesystem objects",
        category=VerbCategory.FILESYSTEM,
        handler=move_handler,
        parameters={"destination": VerbParameter("destination", "Destination folder or file", required=True)},
        target_types=[TargetType.FILE, TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
        reversible=True,
        requires_confirmation=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.DUPLICATE.value,
        description="Create an exact duplicate copy of target in place",
        category=VerbCategory.FILESYSTEM,
        handler=duplicate_handler,
        parameters={"suffix": VerbParameter("suffix", "Duplicate suffix", default="-copy")},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.MERGE.value,
        description="Merge multiple files or datasets into one target",
        category=VerbCategory.FILESYSTEM,
        handler=merge_handler,
        parameters={"output": VerbParameter("output", "Output filename", default=None)},
        target_types=[TargetType.CSV, TargetType.JSON, TargetType.TEXT, TargetType.FILE],
        risk_level=RiskLevel.MEDIUM,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.SPLIT.value,
        description="Split target file or dataset into chunks or files",
        category=VerbCategory.FILESYSTEM,
        handler=split_handler,
        parameters={"lines_or_chunks": VerbParameter("lines_or_chunks", "Number of lines or chunks", param_type="int", default=1000)},
        target_types=[TargetType.CSV, TargetType.TEXT, TargetType.FILE],
        risk_level=RiskLevel.LOW,
    ))
    reg.register(VerbDefinition(
        name=VerbName.ARCHIVE.value,
        description="Archive targets into compressed archive (.zip or .tar.gz)",
        category=VerbCategory.FILESYSTEM,
        handler=archive_handler,
        parameters={
            "output": VerbParameter("output", "Archive filename", default="archive.zip"),
            "format": VerbParameter("format", "Archive format", default="zip", choices=["zip", "tar.gz"]),
        },
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
        reversible=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.RESTORE.value,
        description="Restore targets from archive or transaction snapshot",
        category=VerbCategory.FILESYSTEM,
        handler=restore_handler,
        parameters={"destination": VerbParameter("destination", "Destination folder", default=".")},
        target_types=[TargetType.ARCHIVE, TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
        reversible=True,
    ))

    # 5. DATA VERBS
    reg.register(VerbDefinition(
        name=VerbName.SORT.value,
        description="Sort records or lines by column or order",
        category=VerbCategory.DATA,
        handler=sort_handler,
        parameters={
            "by": VerbParameter("by", "Column or field name to sort by", default=None),
            "descending": VerbParameter("descending", "Sort descending / highest first", param_type="bool", default=False),
        },
        target_types=[TargetType.CSV, TargetType.JSON, TargetType.DATASET, TargetType.TEXT],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.FILTER.value,
        description="Filter records or rows matching a condition",
        category=VerbCategory.DATA,
        handler=filter_handler,
        parameters={
            "condition": VerbParameter("condition", "Filter expression (e.g. revenue > 1000)", required=False, default=None),
            "column": VerbParameter("column", "Target column name", default=None),
            "operator": VerbParameter("operator", "Comparison operator (>, <, ==, !=, contains)", default="=="),
            "value": VerbParameter("value", "Comparison value", default=None),
        },
        target_types=[TargetType.CSV, TargetType.JSON, TargetType.DATASET, TargetType.LOG, TargetType.TEXT],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.GROUP.value,
        description="Group dataset records by one or more keys",
        category=VerbCategory.DATA,
        handler=group_handler,
        parameters={"by": VerbParameter("by", "Column key to group by", required=True)},
        target_types=[TargetType.CSV, TargetType.JSON, TargetType.DATASET],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.COUNT.value,
        description="Count rows, items, matches, or lines in target",
        category=VerbCategory.DATA,
        handler=count_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.ANALYSE.value,
        description="Perform comprehensive statistical, columnar, and schema analysis",
        category=VerbCategory.DATA,
        handler=analyse_handler,
        parameters={"column": VerbParameter("column", "Specific column to analyze", default=None)},
        target_types=[TargetType.CSV, TargetType.JSON, TargetType.LOG, TargetType.DATASET, TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.CALCULATE.value,
        description="Calculate aggregate metrics (sum, mean, min, max, total) on dataset",
        category=VerbCategory.DATA,
        handler=calculate_handler,
        parameters={
            "metric": VerbParameter("metric", "Aggregation (sum, mean, min, max, count)", default="sum"),
            "column": VerbParameter("column", "Column to aggregate", default=None),
        },
        target_types=[TargetType.CSV, TargetType.JSON, TargetType.DATASET],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.MEASURE.value,
        description="Measure dimensions, byte sizes, token lengths, or line counts",
        category=VerbCategory.DATA,
        handler=measure_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.TRANSFORM.value,
        description="Transform dataset structure, casing, or format",
        category=VerbCategory.DATA,
        handler=transform_handler,
        parameters={"operation": VerbParameter("operation", "Transformation to apply", required=True)},
        target_types=[TargetType.CSV, TargetType.JSON, TargetType.DATASET, TargetType.TEXT],
        risk_level=RiskLevel.LOW,
    ))

    # 6. VALIDATION
    reg.register(VerbDefinition(
        name=VerbName.VALIDATE.value,
        description="Validate syntax, schema, JSON/CSV integrity, or path safety",
        category=VerbCategory.VALIDATION,
        handler=validate_handler,
        parameters={"schema": VerbParameter("schema", "Schema path or format", default=None)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.HASH.value,
        description="Compute cryptographic hash checksum (sha256, md5)",
        category=VerbCategory.VALIDATION,
        handler=hash_handler,
        parameters={"algorithm": VerbParameter("algorithm", "Hash algorithm", default="sha256", choices=["sha256", "sha1", "md5"])},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.COMPARE.value,
        description="Compare two targets for byte or semantic equality",
        category=VerbCategory.VALIDATION,
        handler=compare_handler,
        parameters={"with_target": VerbParameter("with_target", "Secondary target to compare with", required=True)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.DIFF.value,
        description="Generate unified diff patch between two text targets",
        category=VerbCategory.VALIDATION,
        handler=diff_handler,
        parameters={"with_target": VerbParameter("with_target", "Secondary target to diff against", required=True)},
        target_types=[TargetType.TEXT, TargetType.FILE, TargetType.SOURCE_CODE],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.VERIFY.value,
        description="Verify post-execution state, checksums, or target existence",
        category=VerbCategory.VALIDATION,
        handler=verify_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))

    # 7. CONVERSION
    reg.register(VerbDefinition(
        name=VerbName.COMPRESS.value,
        description="Compress target files with gzip, bz2, or zip",
        category=VerbCategory.CONVERSION,
        handler=compress_handler,
        parameters={"format": VerbParameter("format", "Compression format", default="zip")},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
    ))
    reg.register(VerbDefinition(
        name=VerbName.EXTRACT.value,
        description="Extract compressed archive contents",
        category=VerbCategory.CONVERSION,
        handler=extract_handler,
        parameters={"destination": VerbParameter("destination", "Destination folder", default=".")},
        target_types=[TargetType.ARCHIVE, TargetType.FILE],
        risk_level=RiskLevel.MEDIUM,
    ))
    reg.register(VerbDefinition(
        name=VerbName.CONVERT.value,
        description="Convert file format (e.g. CSV <-> JSON, YAML <-> JSON)",
        category=VerbCategory.CONVERSION,
        handler=convert_handler,
        parameters={"to_format": VerbParameter("to_format", "Target format extension", required=True)},
        target_types=[TargetType.CSV, TargetType.JSON, TargetType.YAML, TargetType.TEXT],
        risk_level=RiskLevel.LOW,
    ))
    reg.register(VerbDefinition(
        name=VerbName.GENERATE.value,
        description="Generate deterministic test data, hashes, or schema files",
        category=VerbCategory.CONVERSION,
        handler=generate_handler,
        parameters={"artifact_type": VerbParameter("artifact_type", "Type of artifact to generate", default="sample_csv")},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
    ))

    # 8. SYSTEM (Tightly controlled subprocess runner with executable allowlist)
    reg.register(VerbDefinition(
        name=VerbName.RUN.value,
        description="Execute an allowlisted binary or script with verified arguments array",
        category=VerbCategory.SYSTEM,
        handler=run_handler,
        parameters={
            "executable": VerbParameter("executable", "Allowlisted executable name", required=True),
            "arguments": VerbParameter("arguments", "Arguments list", default=[]),
            "timeout_seconds": VerbParameter("timeout_seconds", "Timeout in seconds", param_type="int", default=30),
        },
        target_types=[TargetType.SOURCE_CODE, TargetType.APPLICATION, TargetType.ANY],
        risk_level=RiskLevel.HIGH,
        requires_confirmation=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.BUILD.value,
        description="Detect project system (pyproject.toml, package.json) and run build pipeline",
        category=VerbCategory.SYSTEM,
        handler=build_handler,
        parameters={"tool": VerbParameter("tool", "Explicit build tool", default=None)},
        target_types=[TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
    ))
    reg.register(VerbDefinition(
        name=VerbName.TEST.value,
        description="Detect project test runner (pytest, npm test) and execute test suite",
        category=VerbCategory.SYSTEM,
        handler=test_handler,
        parameters={"filter": VerbParameter("filter", "Test filter pattern", default=None)},
        target_types=[TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
    ))
    reg.register(VerbDefinition(
        name=VerbName.START.value,
        description="Start a managed local background job or service",
        category=VerbCategory.SYSTEM,
        handler=start_handler,
        parameters={"service": VerbParameter("service", "Service name", required=True)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
    ))
    reg.register(VerbDefinition(
        name=VerbName.STOP.value,
        description="Stop an active background job",
        category=VerbCategory.SYSTEM,
        handler=stop_handler,
        parameters={"job_id": VerbParameter("job_id", "Job or process identifier", required=True)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.HIGH,
        requires_confirmation=True,
    ))
    reg.register(VerbDefinition(
        name=VerbName.PAUSE.value,
        description="Pause execution or watcher",
        category=VerbCategory.SYSTEM,
        handler=pause_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
    ))
    reg.register(VerbDefinition(
        name=VerbName.RESUME.value,
        description="Resume paused execution or watcher",
        category=VerbCategory.SYSTEM,
        handler=resume_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
    ))

    # 9. AUTOMATION
    reg.register(VerbDefinition(
        name=VerbName.WATCH.value,
        description="Watch directory for changes and trigger validated pipeline on event",
        category=VerbCategory.AUTOMATION,
        handler=watch_handler,
        parameters={
            "pattern": VerbParameter("pattern", "File pattern to watch", default="*"),
            "action": VerbParameter("action", "Verb or pipeline to trigger", default=None),
        },
        target_types=[TargetType.DIRECTORY, TargetType.ANY],
        risk_level=RiskLevel.LOW,
    ))
    reg.register(VerbDefinition(
        name=VerbName.MONITOR.value,
        description="Monitor system metrics, workspace file changes, or target status",
        category=VerbCategory.AUTOMATION,
        handler=monitor_handler,
        parameters={"interval_seconds": VerbParameter("interval_seconds", "Polling interval", param_type="int", default=5)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.SCHEDULE.value,
        description="Schedule recurring task (frequency, day, time) with confirmation",
        category=VerbCategory.AUTOMATION,
        handler=schedule_handler,
        parameters={
            "frequency": VerbParameter("frequency", "Frequency (daily, weekly, hourly)", required=True),
            "time": VerbParameter("time", "Time string (e.g. 18:00)", default=None),
            "day": VerbParameter("day", "Day of week", default=None),
            "action": VerbParameter("action", "Verb action to schedule", required=True),
        },
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
        requires_confirmation=True,
    ))

    # 10. OUTPUT
    reg.register(VerbDefinition(
        name=VerbName.REPORT.value,
        description="Generate structured audit report in TXT, JSON, CSV, or HTML format",
        category=VerbCategory.OUTPUT,
        handler=report_handler,
        parameters={
            "format": VerbParameter("format", "Report format (TXT, JSON, CSV, HTML)", default="TXT", choices=["TXT", "JSON", "CSV", "HTML"]),
            "output": VerbParameter("output", "Output report path", default=None),
        },
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.EXPORT.value,
        description="Export target dataset or collection to file",
        category=VerbCategory.OUTPUT,
        handler=export_handler,
        parameters={"destination": VerbParameter("destination", "Export destination file path", required=True)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
    ))
    reg.register(VerbDefinition(
        name=VerbName.IMPORT.value,
        description="Import external file or data into workspace context",
        category=VerbCategory.OUTPUT,
        handler=import_handler,
        parameters={"source": VerbParameter("source", "Source path to import", required=True)},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.LOW,
    ))

    # 11. CONTROL
    reg.register(VerbDefinition(
        name=VerbName.PLAN.value,
        description="Generate and inspect execution plan without making changes",
        category=VerbCategory.CONTROL,
        handler=plan_handler,
        parameters={"request": VerbParameter("request", "Plan query string", default="")},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.PREVIEW.value,
        description="Display detailed dry-run preview of affected targets and operations",
        category=VerbCategory.CONTROL,
        handler=preview_handler,
        parameters={"request": VerbParameter("request", "Preview query string", default="")},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.EXECUTE.value,
        description="Execute a planned action graph or intent",
        category=VerbCategory.CONTROL,
        handler=execute_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
    ))
    reg.register(VerbDefinition(
        name=VerbName.RELEASE.value,
        description="Finalize transaction and release resources / locks",
        category=VerbCategory.CONTROL,
        handler=release_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))
    reg.register(VerbDefinition(
        name=VerbName.UNDO.value,
        description="Rollback last reversible transaction",
        category=VerbCategory.CONTROL,
        handler=undo_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
    ))
    reg.register(VerbDefinition(
        name=VerbName.REDO.value,
        description="Redo last rolled-back transaction",
        category=VerbCategory.CONTROL,
        handler=redo_handler,
        parameters={},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.MEDIUM,
    ))
    reg.register(VerbDefinition(
        name=VerbName.EXPLAIN.value,
        description="Explain what an action graph or plan will perform in plain terms",
        category=VerbCategory.CONTROL,
        handler=explain_handler,
        parameters={"request": VerbParameter("request", "Plan to explain", default="")},
        target_types=[TargetType.ANY],
        risk_level=RiskLevel.NONE,
    ))

    _default_registry_instance = reg
    return reg
