"""Structured Intent representations compiled from language or syntax."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Parameter:
    """Individual typed parameter in an Intent."""
    name: str
    value: Any
    raw_text: str = ""
    param_type: str = "string"

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "value": self.value,
            "raw_text": self.raw_text,
            "param_type": self.param_type,
        }


@dataclass
class Intent:
    """Deterministic intent compiled from user input."""
    verb: str
    target: str | None = None
    parameters: dict[str, Any] = field(default_factory=dict)
    raw_query: str = ""
    is_pipeline: bool = False
    pipeline_steps: list["Intent"] = field(default_factory=list)
    confidence: float = 1.0
    flags: dict[str, bool] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "verb": self.verb,
            "target": self.target,
            "parameters": self.parameters,
            "raw_query": self.raw_query,
            "is_pipeline": self.is_pipeline,
            "pipeline_steps": [s.to_dict() for s in self.pipeline_steps],
            "flags": self.flags,
        }


@dataclass
class ExecutionRequest:
    """A direct execution request ready for the planning layer."""
    verb: str
    target: str | None = None
    parameters: dict[str, Any] = field(default_factory=dict)
    dry_run: bool = False
    confirmed: bool = False
    session_id: str = "default"

    def to_dict(self) -> dict:
        return {
            "verb": self.verb,
            "target": self.target,
            "parameters": self.parameters,
            "dry_run": self.dry_run,
            "confirmed": self.confirmed,
            "session_id": self.session_id,
        }
