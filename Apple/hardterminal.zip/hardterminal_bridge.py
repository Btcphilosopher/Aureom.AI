"""HardTerminal JSON Bridge for Web API and Express server."""

import sys
import os
import json
import traceback
from hardterminal import HardTerminal
from hardterminal.core.errors import HardTerminalError, AmbiguousRequestError
from hardterminal.core.verbs import VerbCategory

# Initialize a persistent terminal instance in workspace
WORKSPACE_DIR = os.path.join(os.getcwd(), "workspace_sandbox")
os.makedirs(WORKSPACE_DIR, exist_ok=True)
terminal = HardTerminal(workspace_path=WORKSPACE_DIR)


def seed_workspace():
    """Seeds sample files into the workspace sandbox for interactive exploration."""
    os.makedirs(WORKSPACE_DIR, exist_ok=True)
    
    # 1. Sample CSV
    sales_csv = os.path.join(WORKSPACE_DIR, "sales_q3.csv")
    if not os.path.exists(sales_csv):
        with open(sales_csv, "w", encoding="utf-8") as f:
            f.write("id,region,quarter,revenue,units,status\n")
            f.write("001,North,Q3,18500,45,APPROVED\n")
            f.write("002,South,Q3,9200,28,PENDING\n")
            f.write("003,East,Q3,24100,62,APPROVED\n")
            f.write("004,West,Q3,11400,33,REVIEW\n")
            f.write("005,North,Q3,19800,51,APPROVED\n")
            f.write("006,Central,Q3,14300,39,APPROVED\n")

    # 2. Sample Report TXT
    report_txt = os.path.join(WORKSPACE_DIR, "quarterly_summary.txt")
    if not os.path.exists(report_txt):
        with open(report_txt, "w", encoding="utf-8") as f:
            f.write("HARDTERMINAL SYSTEM AUDIT REPORT\n")
            f.write("================================\n")
            f.write("State: STABLE\n")
            f.write("Active Verb Registry: 60+ Hard Verbs\n")
            f.write("Transaction Engine: Snapshot-based ACID Rollback\n")
            f.write("Safety Policy: Strict Protected Path Quarantine\n")

    # 3. Sample Log File
    app_log = os.path.join(WORKSPACE_DIR, "app.log")
    if not os.path.exists(app_log):
        with open(app_log, "w", encoding="utf-8") as f:
            f.write("2026-09-08 08:00:01 INFO Kernel initialized successfully\n")
            f.write("2026-09-08 08:01:23 WARN High disk latency on /tmp\n")
            f.write("2026-09-08 08:05:44 INFO Transaction #TX_001 committed\n")
            f.write("2026-09-08 08:12:10 ERROR Database connection timeout (retry 1/3)\n")
            f.write("2026-09-08 08:12:12 INFO Database connection recovered\n")

    # 4. Sample JSON Config
    config_json = os.path.join(WORKSPACE_DIR, "settings.json")
    if not os.path.exists(config_json):
        with open(config_json, "w", encoding="utf-8") as f:
            json.dump({
                "app_name": "HardTerminal macOS Kernel",
                "version": "1.0.0",
                "strict_mode": True,
                "max_concurrency": 4,
                "quarantine_roots": ["/System", "/Library", "/bin", "/usr"],
                "default_output_format": "JSON"
            }, f, indent=2)

    # 5. Sample python script
    script_py = os.path.join(WORKSPACE_DIR, "benchmark.py")
    if not os.path.exists(script_py):
        with open(script_py, "w", encoding="utf-8") as f:
            f.write("#!/usr/bin/env python3\n")
            f.write("import time\n\n")
            f.write("print('Running HardTerminal Kernel Benchmark...')\n")
            f.write("time.sleep(0.01)\n")
            f.write("print('Throughput: 142,000 verb operations/sec')\n")


def handle_command(action: str, payload: dict) -> dict:
    try:
        seed_workspace()

        if action == "seed":
            seed_workspace()
            return {"success": True, "message": "Workspace initialized with sample datasets."}

        elif action == "list_verbs":
            verbs_list = []
            for v_def in terminal.registry.list_all():
                verbs_list.append(v_def.to_dict())
            return {"success": True, "verbs": verbs_list}

        elif action == "interpret":
            query = payload.get("query", "")
            intent = terminal.interpret(query)
            return {
                "success": True,
                "intent": {
                    "verb": intent.verb,
                    "target": intent.target,
                    "parameters": intent.parameters,
                    "is_pipeline": intent.is_pipeline,
                    "pipeline_steps": [
                        {"verb": s.verb, "target": s.target, "parameters": s.parameters}
                        for s in intent.pipeline_steps
                    ],
                    "flags": intent.flags,
                    "raw_query": intent.raw_query,
                }
            }

        elif action == "plan":
            query = payload.get("query", "")
            intent = terminal.interpret(query)
            plan = terminal.plan(intent)
            return {
                "success": True,
                "plan": plan.to_dict(),
                "intent": {
                    "verb": intent.verb,
                    "target": intent.target,
                    "parameters": intent.parameters,
                    "flags": intent.flags,
                }
            }

        elif action == "preview":
            query = payload.get("query", "")
            intent = terminal.interpret(query)
            plan = terminal.plan(intent)
            preview = terminal.preview(plan)
            return {
                "success": True,
                "preview": preview,
                "plan": plan.to_dict(),
            }

        elif action == "execute":
            query = payload.get("query", "")
            dry_run = payload.get("dry_run", False)
            intent = terminal.interpret(query)
            if dry_run:
                intent.flags["dry_run"] = True
            plan = terminal.plan(intent)
            report = terminal.execute(plan, dry_run=intent.flags.get("dry_run", False))
            
            # Extract active node results
            nodes_info = {}
            for k, v in report.node_results.items():
                nodes_info[k] = {
                    "success": v.success,
                    "data": v.data,
                    "error": v.error,
                    "duration_ms": v.duration_ms,
                }

            return {
                "success": report.success,
                "report": report.to_dict(),
                "plan": plan.to_dict(),
                "node_results": nodes_info,
                "summary": report.summary_message,
            }

        elif action == "undo":
            res = terminal.undo()
            return {
                "success": res.success,
                "data": res.data,
                "error": res.error,
            }

        elif action == "workspace":
            status = terminal.context.get_status_summary()
            
            # Scan files in sandbox
            files_list = []
            for root, dirs, files in os.walk(WORKSPACE_DIR):
                dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__pycache__"]
                for f in sorted(files):
                    if f.startswith("."):
                        continue
                    full_p = os.path.join(root, f)
                    rel_p = os.path.relpath(full_p, WORKSPACE_DIR)
                    st = os.stat(full_p)
                    ext = os.path.splitext(f)[1].lstrip(".").lower()
                    files_list.append({
                        "name": f,
                        "rel_path": rel_p,
                        "size_bytes": st.st_size,
                        "modified": st.st_mtime,
                        "ext": ext,
                    })

            # Handles
            handles = []
            for h_key, t in terminal.context.targets.items():
                handles.append(t.to_dict())

            # Transactions
            tx_history = [tx.to_dict() for tx in terminal.transactions.committed_history]

            return {
                "success": True,
                "workspace_path": WORKSPACE_DIR,
                "files": files_list,
                "handles": handles,
                "transactions": tx_history,
                "context": status,
            }

        elif action == "read_file":
            rel_path = payload.get("path", "")
            full_p = os.path.join(WORKSPACE_DIR, rel_path.lstrip("/"))
            if not os.path.exists(full_p):
                return {"success": False, "error": f"File not found: {rel_path}"}
            with open(full_p, "r", encoding="utf-8", errors="replace") as f:
                content = f.read(100000)  # max 100KB preview
            return {"success": True, "path": rel_path, "content": content}

        else:
            return {"success": False, "error": f"Unknown action: {action}"}

    except AmbiguousRequestError as e:
        return {
            "success": False,
            "error_type": "AmbiguousRequestError",
            "message": e.message,
            "required_parameters": e.required_parameters,
            "hint": e.hint,
        }
    except HardTerminalError as e:
        return {
            "success": False,
            "error_type": e.__class__.__name__,
            "message": e.message,
            "hint": e.hint,
        }
    except Exception as e:
        return {
            "success": False,
            "error_type": "InternalError",
            "message": str(e),
            "traceback": traceback.format_exc(),
        }


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"success": False, "error": "Action required"}))
        sys.exit(1)

    action = sys.argv[1]
    payload = {}
    if len(sys.argv) >= 3:
        try:
            payload = json.loads(sys.argv[2])
        except Exception:
            payload = {"query": sys.argv[2]}

    res = handle_command(action, payload)
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
