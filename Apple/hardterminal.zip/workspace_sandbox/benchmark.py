#!/usr/bin/env python3
import time

print('Running HardTerminal Kernel Benchmark...')
time.sleep(0.01)
print('Throughput: 142,000 verb operations/sec')
