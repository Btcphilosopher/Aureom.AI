import express from "express";
import path from "path";
import { spawn } from "child_process";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini client
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    try {
      aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (e) {
      console.warn("Failed to initialize Gemini AI client:", e);
    }
  }
  return aiClient;
}

// Helper to run HardTerminal Python Bridge
function callPythonBridge(action: string, payload: Record<string, any> = {}): Promise<any> {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(process.cwd(), "hardterminal_bridge.py");
    const py = spawn("python3", [scriptPath, action, JSON.stringify(payload)], {
      cwd: process.cwd(),
      env: { ...process.env, PYTHONPATH: process.cwd() },
    });

    let stdout = "";
    let stderr = "";

    py.stdout.on("data", (chunk) => {
      stdout += chunk.toString();
    });

    py.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });

    py.on("close", (code) => {
      if (stdout.trim()) {
        try {
          const parsed = JSON.parse(stdout.trim());
          return resolve(parsed);
        } catch (e) {
          // If JSON parse fails, return raw output
          return resolve({ success: false, error: stdout.trim() || stderr.trim() });
        }
      }
      if (code !== 0) {
        return resolve({
          success: false,
          error: stderr.trim() || `Process exited with code ${code}`,
        });
      }
      resolve({ success: true, data: {} });
    });

    py.on("error", (err) => {
      resolve({ success: false, error: err.message });
    });
  });
}

// ---------------- API Routes ----------------

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    kernel: "HardTerminal Python 3.13 macOS Kernel",
    timestamp: new Date().toISOString(),
  });
});

// Seed or reset workspace
app.post("/api/seed", async (req, res) => {
  const result = await callPythonBridge("seed", {});
  res.json(result);
});

// Get registered verbs
app.get("/api/verbs", async (req, res) => {
  const result = await callPythonBridge("list_verbs", {});
  res.json(result);
});

// Interpret plain-language query into Intent
app.post("/api/interpret", async (req, res) => {
  const { query } = req.body;
  if (!query || typeof query !== "string") {
    return res.status(400).json({ success: false, message: "Query is required" });
  }
  const result = await callPythonBridge("interpret", { query });
  res.json(result);
});

// Generate Execution Plan and Action Graph
app.post("/api/plan", async (req, res) => {
  const { query } = req.body;
  if (!query) {
    return res.status(400).json({ success: false, message: "Query is required" });
  }
  const result = await callPythonBridge("plan", { query });
  res.json(result);
});

// Preview execution
app.post("/api/preview", async (req, res) => {
  const { query } = req.body;
  if (!query) {
    return res.status(400).json({ success: false, message: "Query is required" });
  }
  const result = await callPythonBridge("preview", { query });
  res.json(result);
});

// Execute plan/query
app.post("/api/execute", async (req, res) => {
  const { query, dry_run } = req.body;
  if (!query) {
    return res.status(400).json({ success: false, message: "Query is required" });
  }
  const result = await callPythonBridge("execute", { query, dry_run: !!dry_run });
  res.json(result);
});

// Rollback transaction (Undo)
app.post("/api/undo", async (req, res) => {
  const result = await callPythonBridge("undo", {});
  res.json(result);
});

// Workspace state, files, handles, and transaction history
app.get("/api/workspace", async (req, res) => {
  const result = await callPythonBridge("workspace", {});
  res.json(result);
});

// Read file content
app.post("/api/read_file", async (req, res) => {
  const { path: filePath } = req.body;
  const result = await callPythonBridge("read_file", { path: filePath });
  res.json(result);
});

// Gemini Assistant endpoint for queries, syntax translation, and plan explanations
app.post("/api/ai_assist", async (req, res) => {
  const { prompt, mode } = req.body;
  const ai = getAI();
  if (!ai) {
    return res.json({
      success: false,
      message: "Gemini API key is not configured. Natural language rule-based compiler is fully active.",
    });
  }

  try {
    let systemInstruction = `You are the HardTerminal AI Assistant.
HardTerminal is a deterministic plain-language operating kernel for macOS.
Natural language may select and parameterise registered verbs, but it may NEVER create arbitrary uninspected shell operations or bash scripts.
Registered Verbs include:
- Acquisition: FIND, GRAB, LOCATE, DISCOVER, COLLECT, FETCH, PULL
- Inspection: INSPECT, VIEW, SHOW, LIST, COUNT, SUMMARY, OUTLINE, TREE
- Modification: EDIT, REPLACE, INSERT, APPEND, PREPEND, DELETE, REMOVE, TRUNCATE, CLEAR
- Filesystem: COPY, DUPLICATE, MOVE, RENAME, SYMLINK, ARCHIVE, COMPRESS, EXTRACT, CLEANUP
- Data: SORT, FILTER, DEDUPLICATE, MERGE, SPLIT, ANALYSE, CALCULATE, MEASURE, TRANSFORM
- Validation: VALIDATE, HASH, COMPARE, DIFF, VERIFY
- Conversion: CONVERT, ENCODE, DECODE, RENDER
- System: RUN, EXEC, BUILD, TEST, BENCHMARK, ENV, INFO, LOGS
- Automation: PIPELINE, BATCH, WATCH, MONITOR, SCHEDULE
- Output: REPORT, EXPORT, IMPORT
- Control: PLAN, PREVIEW, EXECUTE, RELEASE, UNDO, REDO, EXPLAIN

Provide concise, deterministic recommendations formatted as HardTerminal syntax or pipelines.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });

    res.json({
      success: true,
      text: response.text,
    });
  } catch (e: any) {
    res.json({
      success: false,
      error: e.message || "Failed to generate AI response",
    });
  }
});

// ---------------- Vite Middleware / Production Server ----------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`HardTerminal Server running on http://localhost:${PORT}`);
  });
}

startServer();
