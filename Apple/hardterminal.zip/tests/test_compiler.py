"""Unit tests for Natural Language Compiler, Aliases, and Ambiguity Rejection."""

import unittest
from hardterminal import HardTerminal
from hardterminal.core.errors import AmbiguousRequestError, UnknownVerbError


class TestIntentCompiler(unittest.TestCase):
    def setUp(self):
        self.terminal = HardTerminal()

    def test_find_pdfs_in_downloads(self):
        intent = self.terminal.interpret("find all PDFs in Downloads")
        self.assertEqual(intent.verb, "FIND")
        self.assertEqual(intent.target, "~/Downloads")
        self.assertEqual(intent.parameters.get("pattern"), "*.pdf")

    def test_move_those_into_archive(self):
        intent = self.terminal.interpret("move those into Archive")
        self.assertEqual(intent.verb, "MOVE")
        self.assertEqual(intent.target, "$context.previous_results")
        self.assertEqual(intent.parameters.get("destination"), "Archive")

    def test_natural_language_aliases(self):
        cases = [
            ("look for reports", "FIND"),
            ("locate documents", "FIND"),
            ("search for error", "SEARCH"),
            ("show me #001", "SHOW"),
            ("tell me about #002", "INSPECT"),
            ("change name of #003", "RENAME"),
            ("make a copy of report.pdf", "DUPLICATE"),
            ("remove old.txt", "REMOVE"),
            ("check server", "CHECK"),
            ("undo that", "UNDO"),
            ("calculate total revenue", "CALCULATE"),
        ]
        for query, expected_verb in cases:
            intent = self.terminal.interpret(query)
            self.assertEqual(intent.verb, expected_verb, f"Query '{query}' should compile to {expected_verb}")

    def test_ambiguity_rejection(self):
        # Must refuse to guess when parameters or targets are insufficient
        ambiguous_queries = [
            "remove the old files",
            "clean this directory",
            "fix the configuration",
            "make it smaller",
        ]
        for query in ambiguous_queries:
            with self.assertRaises(AmbiguousRequestError, msg=f"Query '{query}' should raise AmbiguousRequestError"):
                self.terminal.interpret(query)

    def test_unknown_verb_rejection(self):
        with self.assertRaises(UnknownVerbError):
            self.terminal.interpret("teleport spaceship to Mars")


if __name__ == "__main__":
    unittest.main()
