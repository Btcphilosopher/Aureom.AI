"""Unit tests for HardTerminal verb registry and verb execution."""

import os
import tempfile
import unittest
from hardterminal import HardTerminal
from hardterminal.core.verbs import VerbName, VerbCategory
from hardterminal.core.registry import default_registry
from hardterminal.safety.risk import RiskLevel


class TestVerbRegistry(unittest.TestCase):
    def setUp(self):
        self.registry = default_registry()

    def test_core_verbs_registered(self):
        expected_verbs = [
            "GRAB", "FIND", "SEARCH", "INSPECT", "READ", "OPEN", "CREATE", "MAKE",
            "EDIT", "REPLACE", "INSERT", "DELETE", "REMOVE", "COPY", "MOVE", "RENAME",
            "DUPLICATE", "COMPARE", "DIFF", "MERGE", "SPLIT", "SORT", "FILTER", "GROUP",
            "COUNT", "ANALYSE", "CALCULATE", "MEASURE", "CHECK", "VALIDATE", "HASH",
            "COMPRESS", "EXTRACT", "CONVERT", "TRANSFORM", "GENERATE", "RUN", "BUILD",
            "TEST", "WATCH", "MONITOR", "SCHEDULE", "STOP", "START", "PAUSE", "RESUME",
            "REPORT", "EXPORT", "IMPORT", "ARCHIVE", "RESTORE", "UNDO", "REDO", "LIST",
            "SHOW", "DESCRIBE", "EXPLAIN", "PLAN", "PREVIEW", "EXECUTE", "VERIFY", "RELEASE"
        ]
        for verb in expected_verbs:
            self.assertTrue(self.registry.contains(verb), f"Verb {verb} must be registered.")
            v_def = self.registry.get(verb)
            self.assertEqual(v_def.name, verb)
            self.assertIsNotNone(v_def.handler)

    def test_risk_levels(self):
        self.assertEqual(self.registry.get("INSPECT").risk_level, RiskLevel.NONE)
        self.assertEqual(self.registry.get("COPY").risk_level, RiskLevel.LOW)
        self.assertEqual(self.registry.get("MOVE").risk_level, RiskLevel.MEDIUM)
        self.assertEqual(self.registry.get("DELETE").risk_level, RiskLevel.HIGH)

    def test_verb_categories(self):
        self.assertEqual(self.registry.get("FIND").category, VerbCategory.ACQUISITION)
        self.assertEqual(self.registry.get("SORT").category, VerbCategory.DATA)
        self.assertEqual(self.registry.get("HASH").category, VerbCategory.VALIDATION)


class TestVerbExecution(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.terminal = HardTerminal(workspace_path=self.test_dir)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_create_and_read_verb(self):
        res = self.terminal.execute_verb("CREATE", target="notes.txt", content="HardTerminal Plain Language OS")
        self.assertTrue(res.success)
        self.assertTrue(os.path.isfile(os.path.join(self.test_dir, "notes.txt")))

        read_res = self.terminal.execute_verb("READ", target="notes.txt")
        self.assertTrue(read_res.success)
        self.assertIn("HardTerminal", read_res.data.get("content", ""))

    def test_find_and_grab(self):
        # Create dummy pdf files
        for name in ["doc1.pdf", "doc2.pdf", "report.csv"]:
            with open(os.path.join(self.test_dir, name), "w") as f:
                f.write("content")

        find_res = self.terminal.execute_verb("FIND", target=self.test_dir, pattern="*.pdf")
        self.assertTrue(find_res.success)
        self.assertEqual(find_res.data["matches"], 2)

    def test_data_verbs_csv_flow(self):
        # Generate sample CSV
        gen_res = self.terminal.execute_verb("GENERATE", target="sales.csv")
        self.assertTrue(gen_res.success)

        # Filter
        filt_res = self.terminal.execute_verb("FILTER", target="sales.csv", condition="revenue > 10000")
        self.assertTrue(filt_res.success)
        self.assertGreater(filt_res.data["matched_rows"], 0)

        # Calculate
        calc_res = self.terminal.execute_verb("CALCULATE", target="sales.csv", metric="sum", column="revenue")
        self.assertTrue(calc_res.success)
        self.assertGreater(calc_res.data["result"], 0)

        # Sort
        sort_res = self.terminal.execute_verb("SORT", target="sales.csv", by="revenue", descending=True)
        self.assertTrue(sort_res.success)


if __name__ == "__main__":
    unittest.main()
