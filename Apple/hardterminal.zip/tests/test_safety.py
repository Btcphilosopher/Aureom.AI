"""Unit tests for Safety Controller, Transactions, Rollback, and Protected Paths."""

import os
import tempfile
import unittest
from hardterminal import HardTerminal
from hardterminal.core.errors import SafetyViolationError


class TestSafetyAndTransactions(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.mkdtemp()
        self.terminal = HardTerminal(workspace_path=self.test_dir)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_protected_system_paths_rejected(self):
        # Must block attempts to write/delete system roots
        with self.assertRaises(SafetyViolationError):
            self.terminal.safety.validate_action("DELETE", targets=["/System/Library"])

        with self.assertRaises(SafetyViolationError):
            self.terminal.safety.validate_action("MOVE", targets=["/bin/sh"], parameters={"destination": "./bad"})

    def test_unregistered_binary_in_run_rejected(self):
        with self.assertRaises(SafetyViolationError):
            self.terminal.safety.validate_action("RUN", parameters={"executable": "malicious_exploit_bin"})

    def test_transaction_snapshot_and_undo(self):
        # Create a file
        f_path = os.path.join(self.test_dir, "draft.txt")
        with open(f_path, "w") as f:
            f.write("Initial state version 1")

        # Edit the file
        intent = self.terminal.interpret(f"edit draft.txt find 'version 1' replace 'version 2'")
        plan = self.terminal.plan(intent)
        report = self.terminal.execute(plan)
        self.assertTrue(report.success)

        # Verify edited content
        with open(f_path, "r") as f:
            self.assertEqual(f.read(), "Initial state version 2")

        # Rollback via UNDO
        undo_res = self.terminal.undo()
        self.assertTrue(undo_res.success)

        # Verify reverted to original
        with open(f_path, "r") as f:
            self.assertEqual(f.read(), "Initial state version 1")


if __name__ == "__main__":
    unittest.main()
