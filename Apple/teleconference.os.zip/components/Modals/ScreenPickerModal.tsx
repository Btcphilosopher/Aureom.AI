"use client";

import React, { useState } from "react";
import { 
  Monitor, 
  AppWindow, 
  Tv, 
  Volume2, 
  VolumeX, 
  X, 
  Check, 
  Sparkles,
  Layers,
  FileCode,
  Globe,
  Sliders
} from "lucide-react";

interface ScreenPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartShare: (type: "display" | "keynote" | "xcode" | "safari", shareSystemAudio: boolean) => void;
}

const DISPLAY_TARGETS = [
  { id: "display-1", label: "Built-in Liquid Retina XDR (3024 × 1964)", icon: <Monitor className="w-8 h-8 text-blue-400" />, type: "display" },
  { id: "display-2", label: "Apple Studio Display 5K (5120 × 2880)", icon: <Tv className="w-8 h-8 text-purple-400" />, type: "display" }
];

const APP_TARGETS = [
  { id: "app-keynote", label: "Keynote — Teleconference Architecture 2026", icon: <Tv className="w-8 h-8 text-amber-400" />, type: "keynote" },
  { id: "app-xcode", label: "Xcode — MeetingEngine.swift & ScreenCaptureKit", icon: <FileCode className="w-8 h-8 text-blue-400" />, type: "xcode" },
  { id: "app-safari", label: "Safari — Apple Developer Documentation", icon: <Globe className="w-8 h-8 text-cyan-400" />, type: "safari" }
];

export const ScreenPickerModal: React.FC<ScreenPickerModalProps> = ({
  isOpen,
  onClose,
  onStartShare
}) => {
  const [activeCategory, setActiveCategory] = useState<"displays" | "apps">("apps");
  const [selectedTarget, setSelectedTarget] = useState<string>("app-keynote");
  const [shareSystemAudio, setShareSystemAudio] = useState(true);

  if (!isOpen) return null;

  const handleConfirm = () => {
    const target = [...DISPLAY_TARGETS, ...APP_TARGETS].find(t => t.id === selectedTarget);
    const type = (target?.type as any) || "keynote";
    onStartShare(type, shareSystemAudio);
    onClose();
  };

  return (
    <div 
      id="screen-picker-modal"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in select-none"
    >
      <div className="w-full max-w-xl bg-[#141826]/95 border border-white/[0.14] rounded-2xl shadow-2xl overflow-hidden flex flex-col justify-between">
        {/* Header */}
        <div className="h-12 border-b border-white/[0.08] px-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Tv className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="font-semibold text-white text-xs">ScreenCaptureKit Content Picker</p>
              <p className="text-[10px] text-neutral-400">Select display, application or window to share</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/[0.08]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Category Tabs */}
        <div className="p-3 border-b border-white/[0.06] flex items-center space-x-2">
          <button
            onClick={() => setActiveCategory("apps")}
            className={`flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeCategory === "apps" 
                ? "bg-blue-600 text-white shadow-md" 
                : "bg-white/[0.04] text-neutral-300 hover:bg-white/[0.08]"
            }`}
          >
            <AppWindow className="w-3.5 h-3.5" />
            <span>Applications & Windows</span>
          </button>

          <button
            onClick={() => setActiveCategory("displays")}
            className={`flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeCategory === "displays" 
                ? "bg-blue-600 text-white shadow-md" 
                : "bg-white/[0.04] text-neutral-300 hover:bg-white/[0.08]"
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Entire Displays</span>
          </button>
        </div>

        {/* Targets Grid */}
        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-64 overflow-y-auto">
          {(activeCategory === "apps" ? APP_TARGETS : DISPLAY_TARGETS).map((item) => {
            const isSelected = selectedTarget === item.id;
            return (
              <div
                key={item.id}
                onClick={() => setSelectedTarget(item.id)}
                className={`p-3 rounded-xl border cursor-pointer transition-all flex flex-col items-center justify-center text-center space-y-2 relative ${
                  isSelected 
                    ? "bg-blue-600/20 border-blue-500 shadow-lg shadow-blue-500/20" 
                    : "bg-[#181c2e] border-white/[0.08] hover:border-white/[0.18]"
                }`}
              >
                {isSelected && (
                  <span className="absolute top-2 right-2 w-4 h-4 rounded-full bg-blue-500 flex items-center justify-center text-white">
                    <Check className="w-2.5 h-2.5" />
                  </span>
                )}
                {item.icon}
                <p className="text-xs font-medium text-white leading-tight">{item.label}</p>
              </div>
            );
          })}
        </div>

        {/* Audio sharing & Options */}
        <div className="p-4 border-t border-white/[0.08] bg-[#0f121d] space-y-3">
          <label className="flex items-center justify-between cursor-pointer">
            <div className="flex items-center space-x-2 text-xs text-neutral-200">
              <Volume2 className="w-4 h-4 text-emerald-400" />
              <div>
                <p className="font-semibold text-white">Share macOS System Audio</p>
                <p className="text-[10px] text-neutral-400">Stream high-fidelity app sound via Core Audio loopback</p>
              </div>
            </div>
            <input 
              type="checkbox"
              checked={shareSystemAudio}
              onChange={(e) => setShareSystemAudio(e.target.checked)}
              className="w-4 h-4 rounded accent-blue-600"
            />
          </label>

          <div className="flex items-center space-x-2 pt-2">
            <button
              onClick={onClose}
              className="flex-1 py-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-neutral-300 font-semibold text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleConfirm}
              className="flex-1 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-blue-600/30"
            >
              Start Sharing
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
