"use client";

import React, { useState } from "react";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Lock, 
  Users, 
  Disc, 
  X, 
  Check, 
  ChevronRight,
  Plus
} from "lucide-react";
import { ScheduledMeeting } from "@/lib/types";

interface ScheduleMeetingModalProps {
  isOpen: boolean;
  onClose: () => void;
  scheduledMeetings: ScheduledMeeting[];
  onScheduleMeeting: (meeting: Partial<ScheduledMeeting>) => void;
  onJoinScheduledMeeting: (m: ScheduledMeeting) => void;
}

export const ScheduleMeetingModal: React.FC<ScheduleMeetingModalProps> = ({
  isOpen,
  onClose,
  scheduledMeetings,
  onScheduleMeeting,
  onJoinScheduledMeeting
}) => {
  const [activeTab, setActiveTab] = useState<"upcoming" | "create">("upcoming");
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("2026-09-08");
  const [time, setTime] = useState("14:00");
  const [duration, setDuration] = useState("45 min");
  const [requireWaitingRoom, setRequireWaitingRoom] = useState(true);
  const [autoRecord, setAutoRecord] = useState(false);

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onScheduleMeeting({
      title: title.trim(),
      date,
      time,
      duration,
      requireWaitingRoom,
      autoRecord
    });
    setTitle("");
    setActiveTab("upcoming");
  };

  return (
    <div 
      id="schedule-modal"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in select-none"
    >
      <div className="w-full max-w-lg bg-[#141826]/95 border border-white/[0.14] rounded-2xl shadow-2xl overflow-hidden flex flex-col justify-between">
        {/* Header */}
        <div className="h-12 border-b border-white/[0.08] px-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <CalendarIcon className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-white text-xs">Calendar & Meeting Scheduler</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/[0.08]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="p-3 border-b border-white/[0.06] flex items-center space-x-2">
          <button
            onClick={() => setActiveTab("upcoming")}
            className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === "upcoming" 
                ? "bg-blue-600 text-white" 
                : "bg-white/[0.04] text-neutral-400 hover:text-white"
            }`}
          >
            Upcoming Meetings ({scheduledMeetings.length})
          </button>
          <button
            onClick={() => setActiveTab("create")}
            className={`flex-1 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center space-x-1 ${
              activeTab === "create" 
                ? "bg-blue-600 text-white" 
                : "bg-white/[0.04] text-neutral-400 hover:text-white"
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule New</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-4 max-h-80 overflow-y-auto">
          {activeTab === "upcoming" ? (
            <div className="space-y-2.5">
              {scheduledMeetings.map((m) => (
                <div 
                  key={m.id}
                  className="bg-[#181d2e] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between hover:border-white/[0.18] transition-colors"
                >
                  <div className="space-y-1">
                    <p className="font-semibold text-xs text-white">{m.title}</p>
                    <div className="flex items-center space-x-3 text-[11px] text-neutral-400">
                      <span className="flex items-center space-x-1">
                        <CalendarIcon className="w-3 h-3 text-blue-400" />
                        <span>{m.date} at {m.time}</span>
                      </span>
                      <span>•</span>
                      <span>{m.duration}</span>
                      <span>•</span>
                      <span>{m.participants.length} invited</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onJoinScheduledMeeting(m);
                      onClose();
                    }}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors"
                  >
                    Join Room
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <form onSubmit={handleCreate} className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-medium text-neutral-300 mb-1">Meeting Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Executive Architecture Sync"
                  className="w-full bg-[#181d2e] border border-white/[0.1] rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-medium text-neutral-300 mb-1">Date</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-[#181d2e] border border-white/[0.1] rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-neutral-300 mb-1">Time</label>
                  <input
                    type="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full bg-[#181d2e] border border-white/[0.1] rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-white/[0.06]">
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-neutral-200">Require Waiting Room</span>
                  <input 
                    type="checkbox"
                    checked={requireWaitingRoom}
                    onChange={(e) => setRequireWaitingRoom(e.target.checked)}
                    className="rounded accent-blue-600"
                  />
                </label>
                <label className="flex items-center justify-between cursor-pointer">
                  <span className="text-neutral-200">Auto-Record to Secure Storage</span>
                  <input 
                    type="checkbox"
                    checked={autoRecord}
                    onChange={(e) => setAutoRecord(e.target.checked)}
                    className="rounded accent-blue-600"
                  />
                </label>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl mt-2 transition-colors"
              >
                Schedule Conference
              </button>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="h-11 border-t border-white/[0.08] px-4 bg-[#0f121d] flex items-center justify-between text-[11px] text-neutral-400">
          <span>Synced with Apple Calendar (EventKit)</span>
          <button onClick={onClose} className="hover:text-white font-medium">Close</button>
        </div>
      </div>
    </div>
  );
};
