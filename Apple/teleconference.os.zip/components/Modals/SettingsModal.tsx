"use client";

import React, { useState } from "react";
import { 
  Settings, 
  Mic, 
  Video, 
  ShieldCheck, 
  Keyboard, 
  Subtitles, 
  X, 
  Check, 
  Volume2, 
  Sliders, 
  Cpu, 
  Lock
} from "lucide-react";
import { DeviceConfig, CaptionsConfig } from "@/lib/types";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  deviceConfig: DeviceConfig;
  captionsConfig: CaptionsConfig;
  onUpdateDeviceConfig: (cfg: Partial<DeviceConfig>) => void;
  onUpdateCaptionsConfig: (cfg: Partial<CaptionsConfig>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  deviceConfig,
  captionsConfig,
  onUpdateDeviceConfig,
  onUpdateCaptionsConfig
}) => {
  const [activeTab, setActiveTab] = useState<"audio" | "video" | "captions" | "security" | "shortcuts">("audio");

  if (!isOpen) return null;

  return (
    <div 
      id="settings-modal"
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in select-none"
    >
      <div className="w-full max-w-2xl bg-[#141826]/95 border border-white/[0.14] rounded-2xl shadow-2xl overflow-hidden flex flex-col justify-between h-[520px]">
        {/* Header */}
        <div className="h-12 border-b border-white/[0.08] px-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Settings className="w-4 h-4 text-neutral-300" />
            <span className="font-semibold text-white text-xs">TELECONFERENCE.OS Preferences</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/[0.08]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Split View */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Sidebar */}
          <div className="w-48 bg-[#0f121d] border-r border-white/[0.08] p-2 space-y-1 text-xs">
            {[
              { id: "audio", label: "Audio & Mic", icon: <Mic className="w-4 h-4" /> },
              { id: "video", label: "Camera & Video", icon: <Video className="w-4 h-4" /> },
              { id: "captions", label: "Live Captions", icon: <Subtitles className="w-4 h-4" /> },
              { id: "security", label: "Security & MLS", icon: <ShieldCheck className="w-4 h-4" /> },
              { id: "shortcuts", label: "Shortcuts", icon: <Keyboard className="w-4 h-4" /> }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl text-left font-medium transition-colors ${
                  activeTab === tab.id 
                    ? "bg-blue-600 text-white shadow-md shadow-blue-600/20" 
                    : "text-neutral-400 hover:bg-white/[0.04] hover:text-neutral-200"
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Right Tab Content */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs">
            
            {/* 1. AUDIO TAB */}
            {activeTab === "audio" && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white mb-1">Core Audio Engine</h3>
                  <p className="text-[11px] text-neutral-400">Configure macOS hardware audio inputs and spatial processing.</p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-medium text-neutral-300 mb-1">Microphone Input</label>
                    <select
                      value={deviceConfig.micDeviceId}
                      onChange={(e) => onUpdateDeviceConfig({ micDeviceId: e.target.value })}
                      className="w-full bg-[#181d2e] border border-white/[0.1] rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="MacBook Pro Microphone (Built-in)">MacBook Pro Microphone (Built-in)</option>
                      <option value="Studio Display Array Microphone">Studio Display Array Microphone</option>
                      <option value="AirPods Pro (Spatial Audio)">AirPods Pro (Spatial Audio)</option>
                    </select>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-white/[0.06]">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-neutral-200">Acoustic Echo Cancellation (AEC)</span>
                      <input 
                        type="checkbox"
                        checked={deviceConfig.echoCancellation}
                        onChange={(e) => onUpdateDeviceConfig({ echoCancellation: e.target.checked })}
                        className="rounded accent-blue-600"
                      />
                    </label>

                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-neutral-200">Voice Isolation (Deep Neural Filter)</span>
                      <input 
                        type="checkbox"
                        checked={deviceConfig.noiseSuppression}
                        onChange={(e) => onUpdateDeviceConfig({ noiseSuppression: e.target.checked })}
                        className="rounded accent-blue-600"
                      />
                    </label>

                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-neutral-200">Automatic Gain Control (AGC)</span>
                      <input 
                        type="checkbox"
                        checked={deviceConfig.autoGainControl}
                        onChange={(e) => onUpdateDeviceConfig({ autoGainControl: e.target.checked })}
                        className="rounded accent-blue-600"
                      />
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* 2. VIDEO TAB */}
            {activeTab === "video" && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white mb-1">AVFoundation Camera Pipeline</h3>
                  <p className="text-[11px] text-neutral-400">Zero-copy Metal texture capture parameters.</p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-medium text-neutral-300 mb-1">Camera Device</label>
                    <select
                      value={deviceConfig.cameraDeviceId}
                      onChange={(e) => onUpdateDeviceConfig({ cameraDeviceId: e.target.value })}
                      className="w-full bg-[#181d2e] border border-white/[0.1] rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="FaceTime HD Camera (Built-in)">FaceTime HD Camera (Built-in)</option>
                      <option value="iPhone 16 Pro (Continuity Camera)">iPhone 16 Pro (Continuity Camera)</option>
                      <option value="Studio Display Ultra Wide">Studio Display Ultra Wide</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-neutral-300 mb-1">Target Resolution</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(["720p", "1080p", "4K"] as const).map((r) => (
                        <button
                          key={r}
                          onClick={() => onUpdateDeviceConfig({ resolution: r })}
                          className={`py-2 rounded-lg font-mono text-xs font-semibold transition-colors ${
                            deviceConfig.resolution === r
                              ? "bg-blue-600 text-white shadow"
                              : "bg-white/[0.04] text-neutral-300 hover:bg-white/[0.08]"
                          }`}
                        >
                          {r}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-neutral-300 mb-1">Frame Rate Limit</label>
                    <div className="grid grid-cols-2 gap-2">
                      {([30, 60] as const).map((fps) => (
                        <button
                          key={fps}
                          onClick={() => onUpdateDeviceConfig({ frameRate: fps })}
                          className={`py-2 rounded-lg font-mono text-xs font-semibold transition-colors ${
                            deviceConfig.frameRate === fps
                              ? "bg-blue-600 text-white shadow"
                              : "bg-white/[0.04] text-neutral-300 hover:bg-white/[0.08]"
                          }`}
                        >
                          {fps} FPS
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3. CAPTIONS TAB */}
            {activeTab === "captions" && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white mb-1">Real-Time Captions & Accessibility</h3>
                  <p className="text-[11px] text-neutral-400">Speech-to-text overlay appearance.</p>
                </div>

                <div className="space-y-3">
                  <label className="flex items-center justify-between cursor-pointer p-2 rounded-lg bg-white/[0.04]">
                    <span className="text-neutral-200 font-medium">Enable Live Captions</span>
                    <input 
                      type="checkbox"
                      checked={captionsConfig.enabled}
                      onChange={(e) => onUpdateCaptionsConfig({ enabled: e.target.checked })}
                      className="rounded accent-blue-600"
                    />
                  </label>

                  <div>
                    <label className="block text-[11px] font-medium text-neutral-300 mb-1">Font Size</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(["small", "medium", "large"] as const).map((sz) => (
                        <button
                          key={sz}
                          onClick={() => onUpdateCaptionsConfig({ fontSize: sz })}
                          className={`py-1.5 rounded-lg capitalize font-medium transition-colors ${
                            captionsConfig.fontSize === sz
                              ? "bg-blue-600 text-white"
                              : "bg-white/[0.04] text-neutral-300 hover:bg-white/[0.08]"
                          }`}
                        >
                          {sz}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-neutral-300 mb-1">Visual Theme</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(["glass", "dark", "high-contrast"] as const).map((th) => (
                        <button
                          key={th}
                          onClick={() => onUpdateCaptionsConfig({ background: th })}
                          className={`py-1.5 rounded-lg capitalize font-medium transition-colors ${
                            captionsConfig.background === th
                              ? "bg-blue-600 text-white"
                              : "bg-white/[0.04] text-neutral-300 hover:bg-white/[0.08]"
                          }`}
                        >
                          {th}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 4. SECURITY & MLS */}
            {activeTab === "security" && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-white mb-1">Cryptographic Security Enclave</h3>
                  <p className="text-[11px] text-neutral-400">Zero-Trust E2EE MLS Architecture specifications.</p>
                </div>

                <div className="bg-[#181d2e] border border-white/[0.08] rounded-xl p-3 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">MLS Group Ratchet:</span>
                    <span className="text-emerald-400 font-mono font-bold">Synchronized (Epoch #14)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">Hardware Enclave:</span>
                    <span className="text-white font-mono">Apple T2 / M-Series SE</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">E2EE Protocol:</span>
                    <span className="text-white font-mono">MLS RFC 9420 / TLS 1.3</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-400">Public Key Fingerprint:</span>
                    <span className="text-blue-400 font-mono text-[10px]">SHA256:7f8e...39ab</span>
                  </div>
                </div>
              </div>
            )}

            {/* 5. SHORTCUTS */}
            {activeTab === "shortcuts" && (
              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-white mb-1">Native macOS Keyboard Shortcuts</h3>
                <div className="space-y-1.5">
                  {[
                    { action: "Toggle Microphone Mute", keys: "⌘ + ⇧ + M" },
                    { action: "Toggle Camera Video", keys: "⌘ + ⇧ + V" },
                    { action: "Toggle Screen Sharing", keys: "⌘ + ⇧ + S" },
                    { action: "Toggle Meeting Chat", keys: "⌘ + ⇧ + C" },
                    { action: "Raise / Lower Hand", keys: "⌘ + ⇧ + R" },
                    { action: "Open Preferences", keys: "⌘ + ," }
                  ].map((sc, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-white/[0.02] border border-white/[0.04]">
                      <span className="text-neutral-300">{sc.action}</span>
                      <kbd className="px-2 py-0.5 rounded bg-black/40 border border-white/20 font-mono text-neutral-300 text-[11px]">
                        {sc.keys}
                      </kbd>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-12 border-t border-white/[0.08] px-4 bg-[#0f121d] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
