"use client";

import React, { useState, useRef, useEffect } from "react";
import { 
  Send, 
  Smile, 
  Paperclip, 
  X, 
  Lock, 
  Globe, 
  User, 
  Check, 
  FileText,
  Sparkles
} from "lucide-react";
import { ChatMessage, Participant } from "@/lib/types";

interface ChatPanelProps {
  messages: ChatMessage[];
  participants: Participant[];
  currentUser: Participant;
  onSendMessage: (text: string, isPrivate?: boolean, recipientId?: string) => void;
  onAddReaction: (messageId: string, emoji: string) => void;
  onClose: () => void;
}

const QUICK_REACTIONS = ["👍", "❤️", "🚀", "🎯", "👏", "🔥"];

export const ChatPanel: React.FC<ChatPanelProps> = ({
  messages,
  participants,
  currentUser,
  onSendMessage,
  onAddReaction,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<"public" | "private">("public");
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>("");
  const [inputText, setInputText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    if (activeTab === "private" && selectedRecipientId) {
      onSendMessage(inputText.trim(), true, selectedRecipientId);
    } else {
      onSendMessage(inputText.trim(), false);
    }
    setInputText("");
  };

  const filteredMessages = messages.filter(m => {
    if (activeTab === "public") return !m.isPrivate;
    return m.isPrivate && (m.senderId === currentUser.id || m.recipientId === currentUser.id);
  });

  return (
    <div 
      id="side-panel-chat"
      className="w-full h-full bg-[#1C1C1E] border-l border-white/10 flex flex-col justify-between z-30 select-none shadow-2xl"
    >
      {/* Panel Header */}
      <div className="h-12 border-b border-white/10 px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="font-semibold text-[#F5F5F7] text-xs">Meeting Chat</span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono">
            TLS 1.3
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs: Public vs Private */}
      <div className="p-2 border-b border-white/10 flex items-center space-x-1 bg-[#161617]">
        <button
          onClick={() => setActiveTab("public")}
          className={`flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
            activeTab === "public" 
              ? "bg-blue-600/20 text-blue-300 border border-blue-500/30" 
              : "text-neutral-400 hover:bg-white/5"
          }`}
        >
          <Globe className="w-3.5 h-3.5" />
          <span>Public (Everyone)</span>
        </button>
        <button
          onClick={() => setActiveTab("private")}
          className={`flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
            activeTab === "private" 
              ? "bg-purple-600/20 text-purple-300 border border-purple-500/30" 
              : "text-neutral-400 hover:bg-white/5"
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Direct Message</span>
        </button>
      </div>

      {/* Private Recipient Picker */}
      {activeTab === "private" && (
        <div className="px-3 py-2 bg-[#161617] border-b border-white/10 flex items-center space-x-2 text-xs">
          <span className="text-neutral-400 text-[11px] font-medium">To:</span>
          <select
            value={selectedRecipientId}
            onChange={(e) => setSelectedRecipientId(e.target.value)}
            className="flex-1 bg-[#2C2C2E] border border-white/10 rounded-md px-2.5 py-1 text-xs text-white focus:outline-none focus:border-blue-500"
          >
            <option value="">Select participant...</option>
            {participants.filter(p => !p.isLocal).map((p) => (
              <option key={p.id} value={p.id}>{p.displayName} ({p.role})</option>
            ))}
          </select>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 p-3 overflow-y-auto space-y-3">
        {filteredMessages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 text-xs px-4">
            <Globe className="w-8 h-8 mb-2 opacity-30 text-blue-400" />
            <p>No messages yet.</p>
            <p className="text-[11px] text-neutral-500 mt-1">Send a message to start the conversation.</p>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isMe = msg.senderId === currentUser.id;
            return (
              <div key={msg.id} className={`flex flex-col ${isMe ? "items-end" : "items-start"} group`}>
                <div className="flex items-center space-x-1.5 mb-1 text-[11px] text-neutral-400">
                  <span className="font-semibold text-neutral-300">{msg.senderName}</span>
                  <span>•</span>
                  <span>{msg.timestamp}</span>
                  {msg.isPrivate && (
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      Direct
                    </span>
                  )}
                </div>

                {/* Bubble */}
                <div 
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed break-words relative ${
                    isMe 
                      ? "bg-[#007AFF] text-white rounded-br-none shadow-md" 
                      : "bg-[#2C2C2E] text-[#F5F5F7] border border-white/5 rounded-bl-none shadow-sm"
                  }`}
                >
                  <p>{msg.text}</p>

                  {/* Attachment if present */}
                  {msg.attachments && msg.attachments.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-white/10 space-y-1">
                      {msg.attachments.map((att, idx) => (
                        <div key={idx} className="flex items-center space-x-2 bg-black/20 p-2 rounded-lg text-[11px]">
                          <FileText className="w-3.5 h-3.5 text-blue-300" />
                          <span className="truncate">{att.name}</span>
                          <span className="text-[10px] text-neutral-400">({att.size})</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Quick Reaction Bar on hover */}
                  <div className="absolute top-0 right-0 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#161617] border border-white/20 rounded-full px-2 py-0.5 flex items-center space-x-1 shadow-lg z-10">
                    {QUICK_REACTIONS.map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => onAddReaction(msg.id, emoji)}
                        className="hover:scale-125 transition-transform text-xs"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Reaction Badges */}
                {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-1">
                    {Object.entries(msg.reactions).map(([emoji, users]) => (
                      <button
                        key={emoji}
                        onClick={() => onAddReaction(msg.id, emoji)}
                        className="px-2 py-0.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] flex items-center space-x-1 text-neutral-300"
                        title={users.join(", ")}
                      >
                        <span>{emoji}</span>
                        <span className="font-mono text-neutral-400">{users.length}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <form onSubmit={handleSend} className="p-3 border-t border-white/10 bg-[#161617]">
        <div className="relative flex items-center">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={activeTab === "public" ? "Message everyone..." : "Direct message..."}
            className="w-full bg-[#2C2C2E] border border-white/10 rounded-xl pl-3.5 pr-20 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500 transition-all"
          />

          <div className="absolute right-2 flex items-center space-x-1">
            <button
              type="button"
              className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
              title="Attach File"
            >
              <Paperclip className="w-3.5 h-3.5" />
            </button>
            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
