"use client";

import React, { useState, useRef } from "react";
import { 
  Edit3, 
  Square, 
  Circle, 
  Type, 
  ArrowRight, 
  Eraser, 
  Trash2, 
  Download, 
  Undo, 
  X,
  Palette,
  StickyNote
} from "lucide-react";
import { WhiteboardElement } from "@/lib/types";

interface WhiteboardPanelProps {
  onClose: () => void;
}

const COLORS = ["#3b82f6", "#ef4444", "#10b981", "#f59e0b", "#8b5cf6", "#ec4899", "#ffffff", "#64748b"];

export const WhiteboardPanel: React.FC<WhiteboardPanelProps> = ({ onClose }) => {
  const [elements, setElements] = useState<WhiteboardElement[]>([
    {
      id: "el-1",
      type: "sticky",
      x: 40,
      y: 40,
      width: 140,
      height: 100,
      color: "#f59e0b",
      strokeWidth: 2,
      text: "TELECONFERENCE.OS\nArchitecture Review"
    },
    {
      id: "el-2",
      type: "rect",
      x: 220,
      y: 40,
      width: 150,
      height: 90,
      color: "#3b82f6",
      strokeWidth: 2,
      text: "AVFoundation 60FPS"
    },
    {
      id: "el-3",
      type: "arrow",
      x: 180,
      y: 90,
      points: [180, 90, 220, 90],
      color: "#10b981",
      strokeWidth: 3
    }
  ]);

  const [activeTool, setActiveTool] = useState<WhiteboardElement["type"]>("pen");
  const [selectedColor, setSelectedColor] = useState("#3b82f6");
  const [strokeWidth, setStrokeWidth] = useState(3);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPath, setCurrentPath] = useState<number[]>([]);
  const svgRef = useRef<SVGSVGElement>(null);

  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (activeTool === "sticky") {
      const newElem: WhiteboardElement = {
        id: `el-${Date.now()}`,
        type: "sticky",
        x,
        y,
        width: 130,
        height: 90,
        color: selectedColor,
        strokeWidth: 2,
        text: "New Note"
      };
      setElements(prev => [...prev, newElem]);
      return;
    }

    if (activeTool === "rect") {
      const newElem: WhiteboardElement = {
        id: `el-${Date.now()}`,
        type: "rect",
        x,
        y,
        width: 120,
        height: 70,
        color: selectedColor,
        strokeWidth
      };
      setElements(prev => [...prev, newElem]);
      return;
    }

    if (activeTool === "circle") {
      const newElem: WhiteboardElement = {
        id: `el-${Date.now()}`,
        type: "circle",
        x: x + 40,
        y: y + 40,
        width: 80,
        height: 80,
        color: selectedColor,
        strokeWidth
      };
      setElements(prev => [...prev, newElem]);
      return;
    }

    setIsDrawing(true);
    setCurrentPath([x, y]);
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isDrawing) return;
    const rect = svgRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setCurrentPath(prev => [...prev, x, y]);
  };

  const handleMouseUp = () => {
    if (isDrawing && currentPath.length > 2) {
      const newElem: WhiteboardElement = {
        id: `el-${Date.now()}`,
        type: "pen",
        x: 0,
        y: 0,
        points: currentPath,
        color: selectedColor,
        strokeWidth
      };
      setElements(prev => [...prev, newElem]);
    }
    setIsDrawing(false);
    setCurrentPath([]);
  };

  const handleClear = () => {
    setElements([]);
  };

  const handleUndo = () => {
    setElements(prev => prev.slice(0, -1));
  };

  // Convert points array [x1, y1, x2, y2, ...] or [{x, y}] to SVG path d string
  const pointsToSvgPath = (pts?: number[] | { x: number; y: number }[]) => {
    if (!pts || pts.length === 0) return "";
    if (typeof pts[0] === "number") {
      const numPts = pts as number[];
      if (numPts.length < 2) return "";
      let d = `M ${numPts[0]} ${numPts[1]}`;
      for (let i = 2; i < numPts.length; i += 2) {
        d += ` L ${numPts[i]} ${numPts[i + 1]}`;
      }
      return d;
    } else {
      const objPts = pts as { x: number; y: number }[];
      let d = `M ${objPts[0].x} ${objPts[0].y}`;
      for (let i = 1; i < objPts.length; i++) {
        d += ` L ${objPts[i].x} ${objPts[i].y}`;
      }
      return d;
    }
  };

  return (
    <div 
      id="side-panel-whiteboard"
      className="w-full h-full bg-[#11141f]/95 backdrop-blur-xl border-l border-white/[0.08] flex flex-col justify-between z-30 select-none shadow-2xl"
    >
      {/* Header */}
      <div className="h-12 border-b border-white/[0.08] px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Edit3 className="w-4 h-4 text-purple-400" />
          <span className="font-semibold text-white text-xs">Collaborative Canvas</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-mono">
            Vector Real-Time
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/[0.08] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Toolbar */}
      <div className="p-2 border-b border-white/[0.08] bg-[#141826] flex items-center justify-between flex-wrap gap-1 text-xs">
        {/* Tool selectors */}
        <div className="flex items-center space-x-1">
          {[
            { id: "pen", icon: <Edit3 className="w-3.5 h-3.5" />, title: "Freehand Pen" },
            { id: "rect", icon: <Square className="w-3.5 h-3.5" />, title: "Rectangle" },
            { id: "circle", icon: <Circle className="w-3.5 h-3.5" />, title: "Circle" },
            { id: "sticky", icon: <StickyNote className="w-3.5 h-3.5" />, title: "Sticky Note" }
          ].map(tool => (
            <button
              key={tool.id}
              onClick={() => setActiveTool(tool.id as any)}
              className={`p-1.5 rounded-lg transition-colors ${
                activeTool === tool.id ? "bg-blue-600 text-white shadow" : "text-neutral-400 hover:bg-white/[0.08] hover:text-white"
              }`}
              title={tool.title}
            >
              {tool.icon}
            </button>
          ))}
        </div>

        {/* Color Palette */}
        <div className="flex items-center space-x-1">
          {COLORS.map(c => (
            <button
              key={c}
              onClick={() => setSelectedColor(c)}
              className={`w-4 h-4 rounded-full border transition-transform ${
                selectedColor === c ? "scale-125 border-white shadow-lg" : "border-transparent opacity-80"
              }`}
              style={{ backgroundColor: c }}
            />
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-1">
          <button
            onClick={handleUndo}
            disabled={elements.length === 0}
            className="p-1.5 rounded text-neutral-400 hover:text-white disabled:opacity-30"
            title="Undo"
          >
            <Undo className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleClear}
            disabled={elements.length === 0}
            className="p-1.5 rounded text-neutral-400 hover:text-red-400 disabled:opacity-30"
            title="Clear Whiteboard"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* SVG Canvas */}
      <div className="relative flex-1 w-full h-full bg-[#0d1017] overflow-hidden cursor-crosshair">
        {/* Subtle grid pattern background */}
        <svg 
          ref={svgRef}
          className="w-full h-full"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
        >
          <defs>
            <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse">
              <path d="M 24 0 L 0 0 0 24" fill="none" stroke="rgba(255,255,255,0.04)" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />

          {/* Render Elements */}
          {elements.map((el) => {
            if (el.type === "pen" && el.points) {
              return (
                <path
                  key={el.id}
                  d={pointsToSvgPath(el.points)}
                  fill="none"
                  stroke={el.color}
                  strokeWidth={el.strokeWidth}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              );
            }
            if (el.type === "rect") {
              const ex = el.x || 0;
              const ey = el.y || 0;
              const ew = el.width || 100;
              const eh = el.height || 60;
              return (
                <g key={el.id}>
                  <rect
                    x={ex}
                    y={ey}
                    width={ew}
                    height={eh}
                    fill="rgba(255,255,255,0.05)"
                    stroke={el.color}
                    strokeWidth={el.strokeWidth}
                    rx="8"
                  />
                  {el.text && (
                    <text
                      x={ex + ew / 2}
                      y={ey + eh / 2 + 4}
                      fill="#ffffff"
                      fontSize="11"
                      textAnchor="middle"
                      fontFamily="system-ui"
                    >
                      {el.text}
                    </text>
                  )}
                </g>
              );
            }
            if (el.type === "circle") {
              const ex = el.x || 0;
              const ey = el.y || 0;
              const ew = el.width || 60;
              return (
                <circle
                  key={el.id}
                  cx={ex}
                  cy={ey}
                  r={ew / 2}
                  fill="rgba(255,255,255,0.05)"
                  stroke={el.color}
                  strokeWidth={el.strokeWidth}
                />
              );
            }
            if (el.type === "sticky") {
              const ex = el.x || 0;
              const ey = el.y || 0;
              const ew = el.width || 120;
              const eh = el.height || 80;
              return (
                <g key={el.id}>
                  <rect
                    x={ex}
                    y={ey}
                    width={ew}
                    height={eh}
                    fill={el.color}
                    rx="6"
                    opacity="0.9"
                  />
                  <text
                    x={ex + 8}
                    y={ey + 20}
                    fill="#000000"
                    fontSize="11"
                    fontWeight="bold"
                    fontFamily="system-ui"
                  >
                    {el.text}
                  </text>
                </g>
              );
            }
            if (el.type === "arrow" && el.points && Array.isArray(el.points)) {
              const p = el.points as any[];
              const x1 = typeof p[0] === "number" ? p[0] : p[0]?.x || 0;
              const y1 = typeof p[1] === "number" ? p[1] : p[0]?.y || 0;
              const x2 = typeof p[2] === "number" ? p[2] : p[1]?.x || 0;
              const y2 = typeof p[3] === "number" ? p[3] : p[1]?.y || 0;
              return (
                <line
                  key={el.id}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke={el.color}
                  strokeWidth={el.strokeWidth}
                  strokeLinecap="round"
                />
              );
            }
            return null;
          })}

          {/* Current Live Drawing Path */}
          {isDrawing && currentPath.length > 2 && (
            <path
              d={pointsToSvgPath(currentPath)}
              fill="none"
              stroke={selectedColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          )}
        </svg>
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-white/[0.08] bg-[#0e111a] text-[11px] text-neutral-400 flex items-center justify-between">
        <span>Shared Apple Pencil Canvas</span>
        <span className="font-mono text-purple-400">{elements.length} Vector Elements</span>
      </div>
    </div>
  );
};
