"use client";

import React, { useState } from "react";
import { 
  Activity, 
  Cpu, 
  Wifi, 
  Layers, 
  ShieldCheck, 
  Sliders, 
  Users, 
  RefreshCw, 
  X, 
  Check, 
  AlertTriangle, 
  Server,
  Zap
} from "lucide-react";
import { QualityScore, NetworkQuality, ThermalState } from "@/lib/types";

interface AdminDiagnosticsPanelProps {
  qualityScore: QualityScore;
  thermalState: ThermalState;
  networkQuality: NetworkQuality;
  onUpdateThermal: (state: ThermalState) => void;
  onUpdateNetwork: (quality: NetworkQuality, latency: number, loss: number) => void;
  onSimulateParticipants: (count: number) => void;
  onClose: () => void;
}

export const AdminDiagnosticsPanel: React.FC<AdminDiagnosticsPanelProps> = ({
  qualityScore,
  thermalState,
  networkQuality,
  onUpdateThermal,
  onUpdateNetwork,
  onSimulateParticipants,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<"twin" | "quality" | "simulator">("twin");
  const [customLatency, setCustomLatency] = useState(18);
  const [customLoss, setCustomLoss] = useState(0.01);

  return (
    <div 
      id="side-panel-diagnostics"
      className="w-full h-full bg-[#11141f]/95 backdrop-blur-xl border-l border-white/[0.08] flex flex-col justify-between z-30 select-none shadow-2xl"
    >
      {/* Header */}
      <div className="h-12 border-b border-white/[0.08] px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          <span className="font-semibold text-white text-xs">Enterprise Admin & Diagnostics</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-mono">
            macOS Telemetry
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/[0.08] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="p-2 border-b border-white/[0.06] grid grid-cols-3 gap-1 text-[11px]">
        <button
          onClick={() => setActiveTab("twin")}
          className={`py-1.5 rounded-lg font-medium text-center transition-colors ${
            activeTab === "twin" ? "bg-cyan-600/30 text-cyan-300 border border-cyan-500/30" : "text-neutral-400 hover:bg-white/[0.04]"
          }`}
        >
          Digital Twin
        </button>
        <button
          onClick={() => setActiveTab("quality")}
          className={`py-1.5 rounded-lg font-medium text-center transition-colors ${
            activeTab === "quality" ? "bg-cyan-600/30 text-cyan-300 border border-cyan-500/30" : "text-neutral-400 hover:bg-white/[0.04]"
          }`}
        >
          Quality Matrix
        </button>
        <button
          onClick={() => setActiveTab("simulator")}
          className={`py-1.5 rounded-lg font-medium text-center transition-colors ${
            activeTab === "simulator" ? "bg-cyan-600/30 text-cyan-300 border border-cyan-500/30" : "text-neutral-400 hover:bg-white/[0.04]"
          }`}
        >
          Lab Simulators
        </button>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 p-3 overflow-y-auto space-y-4">
        
        {/* TAB 1: CONFERENCE DIGITAL TWIN TOPOLOGY */}
        {activeTab === "twin" && (
          <div className="space-y-4">
            <div className="bg-black/40 border border-white/[0.08] rounded-xl p-3 relative overflow-hidden">
              <p className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider mb-2 flex items-center justify-between">
                <span>Conference Digital Twin (Real-Time Mesh)</span>
                <span className="text-emerald-400 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  Synced
                </span>
              </p>

              {/* Topology SVG Visualization */}
              <div className="w-full h-44 bg-[#0d1017] rounded-lg border border-white/[0.06] p-2 flex items-center justify-center relative">
                <svg className="w-full h-full" viewBox="0 0 300 150">
                  {/* Connection lines */}
                  <line x1="150" y1="30" x2="60" y2="100" stroke="rgba(59,130,246,0.5)" strokeWidth="1.5" strokeDasharray="3 3" />
                  <line x1="150" y1="30" x2="150" y2="100" stroke="rgba(16,185,129,0.5)" strokeWidth="1.5" />
                  <line x1="150" y1="30" x2="240" y2="100" stroke="rgba(168,85,247,0.5)" strokeWidth="1.5" strokeDasharray="3 3" />

                  {/* Central SFU/MLS Core */}
                  <circle cx="150" cy="30" r="16" fill="#1e293b" stroke="#38bdf8" strokeWidth="2" />
                  <text x="150" y="34" fill="#38bdf8" fontSize="8" textAnchor="middle" fontWeight="bold">MLS/SFU</text>

                  {/* Nodes */}
                  <circle cx="60" cy="100" r="14" fill="#1e293b" stroke="#3b82f6" strokeWidth="2" />
                  <text x="60" y="103" fill="#ffffff" fontSize="7" textAnchor="middle">You (Host)</text>

                  <circle cx="150" cy="100" r="14" fill="#1e293b" stroke="#10b981" strokeWidth="2" />
                  <text x="150" y="103" fill="#ffffff" fontSize="7" textAnchor="middle">Presenter</text>

                  <circle cx="240" cy="100" r="14" fill="#1e293b" stroke="#a855f7" strokeWidth="2" />
                  <text x="240" y="103" fill="#ffffff" fontSize="7" textAnchor="middle">Remote (3)</text>
                </svg>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div className="bg-[#141826] p-2 rounded-lg border border-white/[0.06]">
                  <p className="text-[10px] text-neutral-400">Transport Protocol</p>
                  <p className="font-semibold text-white">WebRTC / QUIC Media</p>
                </div>
                <div className="bg-[#141826] p-2 rounded-lg border border-white/[0.06]">
                  <p className="text-[10px] text-neutral-400">Crypto Enclave</p>
                  <p className="font-semibold text-emerald-400">MLS 256-bit Ratchet</p>
                </div>
              </div>
            </div>

            {/* Media Engine Pipeline Details */}
            <div className="space-y-2">
              <p className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider px-1">
                Active macOS Subsystems
              </p>
              <div className="space-y-1.5 text-xs">
                <div className="p-2 bg-[#181d2e] rounded-lg border border-white/[0.06] flex items-center justify-between">
                  <span className="text-neutral-300">AVCaptureSession (Metal Zero-Copy)</span>
                  <span className="text-emerald-400 font-mono text-[11px]">60.0 FPS</span>
                </div>
                <div className="p-2 bg-[#181d2e] rounded-lg border border-white/[0.06] flex items-center justify-between">
                  <span className="text-neutral-300">ScreenCaptureKit System Audio Stream</span>
                  <span className="text-blue-400 font-mono text-[11px]">48kHz Lossless</span>
                </div>
                <div className="p-2 bg-[#181d2e] rounded-lg border border-white/[0.06] flex items-center justify-between">
                  <span className="text-neutral-300">Core Audio Realtime HAL Engine</span>
                  <span className="text-purple-400 font-mono text-[11px]">Latency 8.4ms</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: QUALITY MATRIX */}
        {activeTab === "quality" && (
          <div className="space-y-4">
            {/* Overall Score Header */}
            <div className="bg-gradient-to-br from-[#141c2e] to-[#111624] border border-blue-500/20 rounded-xl p-4 text-center">
              <p className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">
                Meeting Quality Index
              </p>
              <div className="text-4xl font-extrabold text-white my-1">
                {qualityScore.score}<span className="text-lg text-neutral-400 font-normal">/100</span>
              </div>
              <p className="text-xs text-emerald-400 font-semibold">Excellent Stability & Fidelity</p>
            </div>

            {/* Metrics Breakdown Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-[#181d2e] p-2.5 rounded-lg border border-white/[0.06]">
                <p className="text-[10px] text-neutral-400">Roundtrip Latency</p>
                <p className="text-base font-bold text-white font-mono">{qualityScore.latencyMs} ms</p>
              </div>
              <div className="bg-[#181d2e] p-2.5 rounded-lg border border-white/[0.06]">
                <p className="text-[10px] text-neutral-400">Packet Loss</p>
                <p className="text-base font-bold text-emerald-400 font-mono">{(qualityScore.packetLoss * 100).toFixed(2)} %</p>
              </div>
              <div className="bg-[#181d2e] p-2.5 rounded-lg border border-white/[0.06]">
                <p className="text-[10px] text-neutral-400">Jitter Variance</p>
                <p className="text-base font-bold text-white font-mono">{qualityScore.jitterMs} ms</p>
              </div>
              <div className="bg-[#181d2e] p-2.5 rounded-lg border border-white/[0.06]">
                <p className="text-[10px] text-neutral-400">Target Bitrate</p>
                <p className="text-base font-bold text-blue-400 font-mono">{qualityScore.bitrateKbps} kbps</p>
              </div>
            </div>

            {/* A/V Sync & FPS */}
            <div className="p-3 bg-[#181d2e] rounded-xl border border-white/[0.06] space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">Video Render FPS:</span>
                <span className="font-mono text-white font-bold">{qualityScore.fps} FPS</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">A/V Lip-Sync Alignment:</span>
                <span className="font-mono text-emerald-400 font-bold">+1.8 ms</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">Total Dropped Frames:</span>
                <span className="font-mono text-white">0 (0.00%)</span>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: SIMULATORS & STRESS TESTING */}
        {activeTab === "simulator" && (
          <div className="space-y-4">
            
            {/* 1. Thermal State Simulator */}
            <div className="bg-[#181d2e] border border-white/[0.08] rounded-xl p-3 space-y-2">
              <p className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider flex items-center justify-between">
                <span>Thermal Throttling Simulator</span>
                <Cpu className="w-3.5 h-3.5" />
              </p>
              <p className="text-[11px] text-neutral-400 leading-snug">
                Test how the Adaptive Bitrate (ABR) engine preserves audio when macOS experiences thermal pressure.
              </p>

              <div className="grid grid-cols-2 gap-1.5 pt-1">
                {(["nominal", "fair", "serious", "critical"] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => onUpdateThermal(t)}
                    className={`py-1.5 px-2 rounded-lg text-xs font-semibold capitalize transition-colors ${
                      thermalState === t
                        ? t === "critical"
                          ? "bg-red-600 text-white"
                          : t === "serious"
                          ? "bg-amber-600 text-white"
                          : "bg-blue-600 text-white"
                        : "bg-white/[0.06] hover:bg-white/[0.1] text-neutral-300"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Network Simulator */}
            <div className="bg-[#181d2e] border border-white/[0.08] rounded-xl p-3 space-y-2">
              <p className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider flex items-center justify-between">
                <span>Network Conditions Simulator</span>
                <Wifi className="w-3.5 h-3.5" />
              </p>

              <div className="grid grid-cols-3 gap-1">
                {(["Excellent", "Good", "Fair", "Poor", "Reconnecting"] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => {
                      const lat = q === "Excellent" ? 18 : q === "Good" ? 45 : q === "Fair" ? 120 : 350;
                      const loss = q === "Excellent" ? 0.001 : q === "Good" ? 0.01 : q === "Fair" ? 0.05 : 0.2;
                      onUpdateNetwork(q, lat, loss);
                    }}
                    className={`py-1 rounded text-[11px] font-medium transition-colors ${
                      networkQuality === q 
                        ? "bg-blue-600 text-white font-bold" 
                        : "bg-white/[0.06] text-neutral-300 hover:bg-white/[0.1]"
                    }`}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Participant Scale Stress Tester */}
            <div className="bg-[#181d2e] border border-white/[0.08] rounded-xl p-3 space-y-2">
              <p className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider flex items-center justify-between">
                <span>Participant Scale Stress Test</span>
                <Users className="w-3.5 h-3.5" />
              </p>
              <p className="text-[11px] text-neutral-400 leading-snug">
                Simulate large enterprise conference loads (5 - 50 peers).
              </p>

              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {[4, 8, 16, 32].map((count) => (
                  <button
                    key={count}
                    onClick={() => onSimulateParticipants(count)}
                    className="py-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] text-xs font-mono text-neutral-200 border border-white/[0.06]"
                  >
                    {count} Users
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-white/[0.08] bg-[#0e111a] text-[11px] text-neutral-400 flex items-center justify-between">
        <span>Hardware Acceleration: Apple Silicon</span>
        <span className="font-mono text-cyan-400">Metal 3 Enabled</span>
      </div>
    </div>
  );
};
