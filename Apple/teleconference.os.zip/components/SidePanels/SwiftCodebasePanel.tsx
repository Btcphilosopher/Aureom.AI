"use client";

import React, { useState } from "react";
import { 
  Code, 
  Copy, 
  Check, 
  Folder, 
  FileCode, 
  X, 
  Download, 
  Layers, 
  Sparkles,
  ExternalLink
} from "lucide-react";
import { SWIFT_PROJECT_FILES } from "@/lib/swiftCodebase";

interface SwiftCodebasePanelProps {
  onClose: () => void;
}

export const SwiftCodebasePanel: React.FC<SwiftCodebasePanelProps> = ({ onClose }) => {
  const [selectedFilePath, setSelectedFilePath] = useState<string>("Package.swift");
  const [copied, setCopied] = useState(false);

  const currentFile = SWIFT_PROJECT_FILES.find(f => f.path === selectedFilePath || f.name === selectedFilePath) || SWIFT_PROJECT_FILES[0];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadAll = () => {
    const blob = new Blob([currentFile.code], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = currentFile.name;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div 
      id="side-panel-swift-codebase"
      className="w-full h-full bg-[#11141f]/95 backdrop-blur-xl border-l border-white/[0.08] flex flex-col justify-between z-30 select-none shadow-2xl"
    >
      {/* Header */}
      <div className="h-12 border-b border-white/[0.08] px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Code className="w-4 h-4 text-blue-400" />
          <span className="font-semibold text-white text-xs">Native Swift Architecture</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 font-mono">
            Swift 5.10 / macOS 14+
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/[0.08] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* File Tree Selector */}
      <div className="p-2 border-b border-white/[0.06] flex items-center space-x-1.5 overflow-x-auto text-[11px]">
        {SWIFT_PROJECT_FILES.map((file) => (
          <button
            key={file.path}
            onClick={() => setSelectedFilePath(file.path)}
            className={`px-2.5 py-1.5 rounded-lg flex items-center space-x-1.5 flex-shrink-0 transition-colors ${
              selectedFilePath === file.path 
                ? "bg-blue-600/30 text-blue-300 border border-blue-500/30 font-medium" 
                : "text-neutral-400 hover:bg-white/[0.04] hover:text-neutral-200"
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-blue-400" />
            <span>{file.name}</span>
          </button>
        ))}
      </div>

      {/* Code Viewer */}
      <div className="flex-1 p-3 overflow-hidden flex flex-col justify-between">
        <div className="flex items-center justify-between pb-2 text-[11px] text-neutral-400">
          <span className="font-mono text-white truncate">{currentFile.path}</span>
          <div className="flex items-center space-x-1">
            <button
              onClick={handleCopyCode}
              className="flex items-center space-x-1 px-2 py-1 rounded bg-white/[0.06] hover:bg-white/[0.12] text-neutral-300 transition-colors"
              title="Copy Code to Clipboard"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied" : "Copy"}</span>
            </button>
            <button
              onClick={handleDownloadAll}
              className="flex items-center space-x-1 px-2 py-1 rounded bg-white/[0.06] hover:bg-white/[0.12] text-neutral-300 transition-colors"
              title="Download Swift File"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
          </div>
        </div>

        <div className="flex-1 bg-[#0b0e17] rounded-xl border border-white/[0.08] p-3 overflow-auto font-mono text-[11px] text-neutral-300 leading-relaxed shadow-inner">
          <pre className="text-neutral-300">
            <code>{currentFile.code}</code>
          </pre>
        </div>
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-white/[0.08] bg-[#0e111a] text-[11px] text-neutral-400 flex items-center justify-between">
        <span>Framework: AVFoundation & ScreenCaptureKit</span>
        <span className="font-mono text-blue-400">SPM Compliant</span>
      </div>
    </div>
  );
};
