"use client";

import React, { useState } from "react";
import { 
  Sparkles, 
  Search, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Shield, 
  X, 
  RefreshCw, 
  ChevronRight, 
  Layers, 
  Send,
  HelpCircle,
  BrainCircuit,
  Lock
} from "lucide-react";
import { TranscriptItem, AISummaryResult, AIPrivacyMode, DocumentAttachment } from "@/lib/types";

interface AIAssistantPanelProps {
  transcript: TranscriptItem[];
  attachedDocs: DocumentAttachment[];
  meetingTitle: string;
  privacyMode: AIPrivacyMode;
  onUpdatePrivacyMode: (mode: AIPrivacyMode) => void;
  onClose: () => void;
}

export const AIAssistantPanel: React.FC<AIAssistantPanelProps> = ({
  transcript,
  attachedDocs,
  meetingTitle,
  privacyMode,
  onUpdatePrivacyMode,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<"summary" | "search" | "docs" | "transcript">("summary");
  const [summaryData, setSummaryData] = useState<AISummaryResult | null>(null);
  const [loadingSummary, setLoadingSummary] = useState(false);
  
  const [searchQuery, setSearchQuery] = useState("");
  const [searchAnswer, setSearchAnswer] = useState<string | null>(null);
  const [loadingSearch, setLoadingSearch] = useState(false);

  const [docQuery, setDocQuery] = useState("");
  const [selectedDocId, setSelectedDocId] = useState<string>(attachedDocs[0]?.id || "");
  const [docAnswer, setDocAnswer] = useState<string | null>(null);
  const [loadingDocQA, setLoadingDocQA] = useState(false);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fullTranscriptText = transcript
    .map(t => `[${t.timestamp}] ${t.speakerName}: ${t.text}`)
    .join("\n");

  const handleGenerateSummary = async () => {
    if (privacyMode === "AI_OFF") {
      setErrorMessage("AI is currently disabled by privacy settings. Please switch to Local AI or Remote AI.");
      return;
    }

    setLoadingSummary(true);
    setErrorMessage(null);

    try {
      const res = await fetch("/api/ai/meeting-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "summarize",
          transcript: fullTranscriptText,
          meetingTitle,
          privacyMode
        })
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "Failed to generate AI summary.");
      }

      setSummaryData(data.data);
    } catch (err: any) {
      setErrorMessage(err.message || "AI summarization encountered an issue.");
    } finally {
      setLoadingSummary(false);
    }
  };

  const handleSearchTranscript = async (queryToRun?: string) => {
    const q = queryToRun || searchQuery;
    if (!q.trim()) return;

    if (privacyMode === "AI_OFF") {
      setErrorMessage("AI is disabled by privacy settings (AI OFF).");
      return;
    }

    setLoadingSearch(true);
    setErrorMessage(null);

    try {
      const res = await fetch("/api/ai/meeting-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "search_transcript",
          transcript: fullTranscriptText,
          query: q,
          privacyMode
        })
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "Search failed.");
      }

      setSearchAnswer(data.answer);
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to search meeting transcript.");
    } finally {
      setLoadingSearch(false);
    }
  };

  const handleDocQA = async () => {
    if (!docQuery.trim()) return;
    const doc = attachedDocs.find(d => d.id === selectedDocId) || attachedDocs[0];
    if (!doc) return;

    setLoadingDocQA(true);
    setErrorMessage(null);

    try {
      const res = await fetch("/api/ai/meeting-assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "document_qa",
          transcript: fullTranscriptText,
          documentText: doc.textContent,
          query: docQuery,
          privacyMode
        })
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "Document analysis failed.");
      }

      setDocAnswer(data.answer);
    } catch (err: any) {
      setErrorMessage(err.message || "Document intelligence error.");
    } finally {
      setLoadingDocQA(false);
    }
  };

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case "DECISION":
        return { label: "DECISION", bg: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" };
      case "FACT":
        return { label: "FACT", bg: "bg-blue-500/20 text-blue-300 border-blue-500/30" };
      case "SUGGESTION":
        return { label: "SUGGESTION", bg: "bg-amber-500/20 text-amber-300 border-amber-500/30" };
      case "INFERENCE":
        return { label: "INFERENCE", bg: "bg-purple-500/20 text-purple-300 border-purple-500/30" };
      default:
        return { label: cat, bg: "bg-neutral-800 text-neutral-300 border-neutral-700" };
    }
  };

  return (
    <div 
      id="side-panel-ai"
      className="w-full h-full bg-[#11141f]/95 backdrop-blur-xl border-l border-white/[0.08] flex flex-col justify-between z-30 select-none shadow-2xl"
    >
      {/* Header */}
      <div className="h-12 border-b border-white/[0.08] px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-5 h-5 rounded-md bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white shadow-sm">
            <Sparkles className="w-3 h-3" />
          </div>
          <span className="font-semibold text-white text-xs">AI Meeting Intelligence</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-mono">
            Gemini 3.8
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/[0.08] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* AI Privacy Control Banner */}
      <div className="px-3 py-2 bg-white/[0.02] border-b border-white/[0.06] flex items-center justify-between text-xs">
        <div className="flex items-center space-x-1.5 text-neutral-300">
          <Shield className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-[11px] font-medium">Privacy:</span>
        </div>

        <div className="flex items-center space-x-1 bg-black/40 p-0.5 rounded-lg border border-white/[0.08]">
          {(["AI_OFF", "LOCAL_AI", "REMOTE_AI"] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => onUpdatePrivacyMode(mode)}
              className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                privacyMode === mode 
                  ? "bg-blue-600 text-white shadow" 
                  : "text-neutral-400 hover:text-neutral-200"
              }`}
            >
              {mode === "AI_OFF" ? "AI OFF" : mode === "LOCAL_AI" ? "LOCAL AI" : "REMOTE AI"}
            </button>
          ))}
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="p-2 border-b border-white/[0.06] grid grid-cols-4 gap-1 text-[11px]">
        <button
          onClick={() => setActiveTab("summary")}
          className={`py-1.5 rounded-lg font-medium text-center transition-colors ${
            activeTab === "summary" ? "bg-blue-600/30 text-blue-300 border border-blue-500/30" : "text-neutral-400 hover:bg-white/[0.04]"
          }`}
        >
          Summary
        </button>
        <button
          onClick={() => setActiveTab("search")}
          className={`py-1.5 rounded-lg font-medium text-center transition-colors ${
            activeTab === "search" ? "bg-blue-600/30 text-blue-300 border border-blue-500/30" : "text-neutral-400 hover:bg-white/[0.04]"
          }`}
        >
          Search
        </button>
        <button
          onClick={() => setActiveTab("docs")}
          className={`py-1.5 rounded-lg font-medium text-center transition-colors ${
            activeTab === "docs" ? "bg-blue-600/30 text-blue-300 border border-blue-500/30" : "text-neutral-400 hover:bg-white/[0.04]"
          }`}
        >
          Docs Q&A
        </button>
        <button
          onClick={() => setActiveTab("transcript")}
          className={`py-1.5 rounded-lg font-medium text-center transition-colors ${
            activeTab === "transcript" ? "bg-blue-600/30 text-blue-300 border border-blue-500/30" : "text-neutral-400 hover:bg-white/[0.04]"
          }`}
        >
          Transcript
        </button>
      </div>

      {/* Error display */}
      {errorMessage && (
        <div className="m-3 p-2.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-300 text-xs flex items-start space-x-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Tab Content */}
      <div className="flex-1 p-3 overflow-y-auto space-y-4">
        
        {/* TAB 1: SUMMARY & ACTION ITEMS */}
        {activeTab === "summary" && (
          <div className="space-y-4">
            <button
              onClick={handleGenerateSummary}
              disabled={loadingSummary || privacyMode === "AI_OFF"}
              className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 disabled:opacity-40 text-white text-xs font-semibold flex items-center justify-center space-x-2 shadow-lg transition-all"
            >
              {loadingSummary ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Synthesizing Intelligence...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate Executive Summary</span>
                </>
              )}
            </button>

            {summaryData ? (
              <div className="space-y-4 animate-in fade-in">
                {/* Executive Briefing */}
                <div className="bg-white/[0.04] border border-white/[0.08] rounded-xl p-3">
                  <p className="text-[10px] uppercase font-bold text-blue-400 tracking-wider mb-1">
                    Executive Summary
                  </p>
                  <p className="text-xs text-neutral-200 leading-relaxed">
                    {summaryData.executiveSummary}
                  </p>
                </div>

                {/* Decisions Categorized (FACT, DECISION, SUGGESTION, INFERENCE) */}
                <div className="space-y-2">
                  <p className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider px-1">
                    Key Decisions & Facts
                  </p>
                  <div className="space-y-1.5">
                    {summaryData.decisions.map((dec, idx) => {
                      const badge = getCategoryBadge(dec.category);
                      return (
                        <div key={idx} className="bg-black/30 border border-white/[0.06] rounded-lg p-2.5 space-y-1">
                          <div className="flex items-center justify-between">
                            <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${badge.bg}`}>
                              {badge.label}
                            </span>
                            {dec.speaker && (
                              <span className="text-[10px] text-neutral-400">{dec.speaker}</span>
                            )}
                          </div>
                          <p className="text-xs text-neutral-200">{dec.statement}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Action Items */}
                <div className="space-y-2">
                  <p className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider px-1">
                    Action Items ({summaryData.actionItems.length})
                  </p>
                  <div className="space-y-1.5">
                    {summaryData.actionItems.map((act, idx) => (
                      <div key={idx} className="bg-[#181d2e] border border-white/[0.08] rounded-lg p-2.5 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-white">{act.task}</span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 font-mono">
                            {act.priority}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1">
                          <span>Assignee: <strong className="text-neutral-200">{act.assignee}</strong></span>
                          <span>Deadline: <strong className="text-neutral-200">{act.deadline}</strong></span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-neutral-500 text-xs">
                <BrainCircuit className="w-8 h-8 mx-auto mb-2 text-purple-400 opacity-40" />
                <p>No summary generated yet.</p>
                <p className="text-[11px] text-neutral-600 mt-1">Click &ldquo;Generate Executive Summary&rdquo; to analyze the conversation.</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: TRANSCRIPT SEARCH */}
        {activeTab === "search" && (
          <div className="space-y-3">
            <div className="space-y-1.5">
              <p className="text-[10px] uppercase font-bold text-neutral-400">Search This Meeting</p>
              <div className="flex items-center space-x-1.5">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="e.g. What did we decide about the budget?"
                  className="flex-1 bg-[#181d2e] border border-white/[0.1] rounded-lg px-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500"
                  onKeyDown={(e) => e.key === "Enter" && handleSearchTranscript()}
                />
                <button
                  onClick={() => handleSearchTranscript()}
                  disabled={loadingSearch || !searchQuery.trim()}
                  className="p-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white rounded-lg"
                >
                  <Search className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Quick suggested questions */}
            <div className="space-y-1">
              <p className="text-[10px] text-neutral-500">Suggested queries:</p>
              {[
                "What did we decide about the budget?",
                "When did Alice mention Friday?",
                "What were the three main decisions?",
                "Show all action items"
              ].map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSearchQuery(q);
                    handleSearchTranscript(q);
                  }}
                  className="w-full text-left text-[11px] text-blue-400 hover:text-blue-300 bg-white/[0.02] hover:bg-white/[0.06] p-1.5 rounded border border-white/[0.04] transition-colors truncate"
                >
                  &ldquo;{q}&rdquo;
                </button>
              ))}
            </div>

            {/* Answer Display */}
            {loadingSearch && (
              <div className="flex items-center space-x-2 text-xs text-neutral-400 py-3">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
                <span>Searching meeting transcript with citations...</span>
              </div>
            )}

            {searchAnswer && !loadingSearch && (
              <div className="bg-[#181d2e] border border-white/[0.1] rounded-xl p-3 text-xs text-neutral-200 leading-relaxed animate-in fade-in">
                <div className="flex items-center space-x-1.5 text-blue-400 font-semibold mb-1 text-[11px]">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Answer from Transcript:</span>
                </div>
                <p className="whitespace-pre-line">{searchAnswer}</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: DOCUMENT INTELLIGENCE */}
        {activeTab === "docs" && (
          <div className="space-y-3">
            <div className="space-y-1.5">
              <p className="text-[10px] uppercase font-bold text-neutral-400">Attached Meeting Document</p>
              <select
                value={selectedDocId}
                onChange={(e) => setSelectedDocId(e.target.value)}
                className="w-full bg-[#181d2e] border border-white/[0.1] rounded-lg p-2 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                {attachedDocs.map((doc) => (
                  <option key={doc.id} value={doc.id}>{doc.name} ({doc.size})</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase font-bold text-neutral-400">Ask Question about Document</p>
              <div className="flex items-center space-x-1.5">
                <input
                  type="text"
                  value={docQuery}
                  onChange={(e) => setDocQuery(e.target.value)}
                  placeholder="e.g. What does the proposal say about costs?"
                  className="flex-1 bg-[#181d2e] border border-white/[0.1] rounded-lg px-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500"
                  onKeyDown={(e) => e.key === "Enter" && handleDocQA()}
                />
                <button
                  onClick={handleDocQA}
                  disabled={loadingDocQA || !docQuery.trim()}
                  className="p-1.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white rounded-lg"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>

            {loadingDocQA && (
              <div className="flex items-center space-x-2 text-xs text-neutral-400 py-3">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-purple-400" />
                <span>Cross-referencing document & discussions...</span>
              </div>
            )}

            {docAnswer && !loadingDocQA && (
              <div className="bg-[#181d2e] border border-white/[0.1] rounded-xl p-3 text-xs text-neutral-200 leading-relaxed animate-in fade-in">
                <div className="flex items-center space-x-1.5 text-purple-400 font-semibold mb-1 text-[11px]">
                  <FileText className="w-3.5 h-3.5" />
                  <span>Document Intelligence Analysis:</span>
                </div>
                <p className="whitespace-pre-line">{docAnswer}</p>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: LIVE TRANSCRIPT FEED */}
        {activeTab === "transcript" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-[11px] text-neutral-400">
              <span className="font-semibold text-white">Live Transcription ({transcript.length})</span>
              <span className="text-emerald-400 font-mono">AVAudioTap Stream</span>
            </div>

            <div className="space-y-2">
              {transcript.map((item) => (
                <div key={item.id} className="bg-black/30 border border-white/[0.06] rounded-lg p-2.5 space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-neutral-400">
                    <span className="font-semibold text-blue-300">{item.speakerName}</span>
                    <span className="font-mono">{item.timestamp}</span>
                  </div>
                  <p className="text-xs text-neutral-200">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-white/[0.08] bg-[#0e111a] text-[11px] text-neutral-400 flex items-center justify-between">
        <span>Zero-Retention Enterprise AI</span>
        <span className="font-mono text-blue-400">Gemini 3.8 Flash</span>
      </div>
    </div>
  );
};
