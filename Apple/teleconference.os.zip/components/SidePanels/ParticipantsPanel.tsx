"use client";

import React, { useState } from "react";
import { 
  Users, 
  Search, 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Hand, 
  Crown, 
  Shield, 
  Tv, 
  MoreHorizontal, 
  Lock, 
  Unlock, 
  Check, 
  X, 
  UserPlus, 
  UserMinus,
  Sparkles
} from "lucide-react";
import { Participant, Role, WaitingRoomUser } from "@/lib/types";

interface ParticipantsPanelProps {
  participants: Participant[];
  waitingRoom: WaitingRoomUser[];
  currentUser: Participant;
  isMeetingLocked: boolean;
  onAdmitUser: (id: string) => void;
  onDenyUser: (id: string) => void;
  onAdmitAll: () => void;
  onMuteParticipant: (id: string) => void;
  onRemoveParticipant: (id: string) => void;
  onPromoteRole: (id: string, role: Role) => void;
  onMuteAll: () => void;
  onToggleLockMeeting: () => void;
  onClose: () => void;
}

export const ParticipantsPanel: React.FC<ParticipantsPanelProps> = ({
  participants,
  waitingRoom,
  currentUser,
  isMeetingLocked,
  onAdmitUser,
  onDenyUser,
  onAdmitAll,
  onMuteParticipant,
  onRemoveParticipant,
  onPromoteRole,
  onMuteAll,
  onToggleLockMeeting,
  onClose
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUserForMenu, setSelectedUserForMenu] = useState<string | null>(null);

  const isHostOrCoHost = currentUser.role === "HOST" || currentUser.role === "CO_HOST";

  const filteredParticipants = participants.filter(p => 
    p.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (p.department && p.department.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div 
      id="side-panel-participants"
      className="w-full h-full bg-[#1C1C1E] border-l border-white/10 flex flex-col justify-between z-30 select-none shadow-2xl"
    >
      {/* Header */}
      <div className="h-12 border-b border-white/10 px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="font-semibold text-[#F5F5F7] text-xs">Participants ({participants.length})</span>
          {isMeetingLocked && (
            <span className="text-[10px] px-2 py-0.5 rounded bg-[#FF3B30]/20 text-[#FF3B30] flex items-center gap-1 border border-[#FF3B30]/30 font-semibold">
              <Lock className="w-2.5 h-2.5" /> Locked
            </span>
          )}
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Host Controls Banner */}
      {isHostOrCoHost && (
        <div className="p-2.5 bg-[#161617] border-b border-white/10 flex items-center justify-between gap-2 text-xs">
          <button
            onClick={onMuteAll}
            className="flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white font-semibold transition-colors border border-white/10"
            title="Mute all participant microphones"
          >
            <MicOff className="w-3.5 h-3.5 text-[#FF3B30]" />
            <span>Mute All</span>
          </button>

          <button
            onClick={onToggleLockMeeting}
            className={`flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg font-semibold transition-colors border ${
              isMeetingLocked 
                ? "bg-[#FF3B30]/20 text-[#FF3B30] border-[#FF3B30]/30" 
                : "bg-white/5 hover:bg-white/10 text-neutral-300 border-white/10"
            }`}
            title="Lock meeting to prevent new entries"
          >
            {isMeetingLocked ? <Lock className="w-3.5 h-3.5 text-[#FF3B30]" /> : <Unlock className="w-3.5 h-3.5 text-emerald-400" />}
            <span>{isMeetingLocked ? "Unlock" : "Lock Room"}</span>
          </button>
        </div>
      )}

      {/* Search Input */}
      <div className="p-2.5 border-b border-white/10 bg-[#161617]">
        <div className="relative flex items-center">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search participants..."
            className="w-full bg-[#2C2C2E] border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Content Scroll Area */}
      <div className="flex-1 p-3 overflow-y-auto space-y-4">
        
        {/* 1. WAITING ROOM QUEUE */}
        {waitingRoom.length > 0 && isHostOrCoHost && (
          <div className="bg-[#FEBC2E]/10 border border-[#FEBC2E]/20 rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-[#FEBC2E]">
              <span className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                <span>Waiting Room ({waitingRoom.length})</span>
              </span>
              <button
                onClick={onAdmitAll}
                className="text-[11px] text-[#FEBC2E] hover:underline font-semibold"
              >
                Admit All
              </button>
            </div>

            <div className="space-y-1.5">
              {waitingRoom.map((w) => (
                <div key={w.id} className="flex items-center justify-between bg-black/40 p-2 rounded-lg text-xs border border-white/5">
                  <div className="flex items-center space-x-2 truncate">
                    <img src={w.avatar} alt={w.name} className="w-6 h-6 rounded-full object-cover" />
                    <div className="truncate">
                      <p className="font-semibold text-white truncate">{w.name}</p>
                      <p className="text-[10px] text-neutral-400">Waiting since {w.requestedAt}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-1 pl-2">
                    <button
                      onClick={() => onAdmitUser(w.id)}
                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-bold"
                      title="Admit to Meeting"
                    >
                      Admit
                    </button>
                    <button
                      onClick={() => onDenyUser(w.id)}
                      className="p-1 text-neutral-400 hover:text-[#FF3B30]"
                      title="Deny Access"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 2. IN-MEETING PARTICIPANTS LIST */}
        <div className="space-y-1">
          <p className="text-[10px] uppercase font-bold text-neutral-400 px-1 mb-1 tracking-wider">
            In Call ({filteredParticipants.length})
          </p>

          {filteredParticipants.map((p) => {
            const isMe = p.isLocal;
            return (
              <div 
                key={p.id}
                className="flex items-center justify-between p-2 rounded-xl hover:bg-white/5 transition-colors relative group"
              >
                {/* Left: Avatar + Name + Role */}
                <div className="flex items-center space-x-2.5 truncate">
                  <div className="relative">
                    <img 
                      src={p.avatar} 
                      alt={p.displayName} 
                      className="w-8 h-8 rounded-full object-cover border border-white/10"
                    />
                    {p.speaking && (
                      <span className="absolute -inset-0.5 rounded-full border border-blue-500 animate-ping" />
                    )}
                  </div>

                  <div className="truncate">
                    <div className="flex items-center space-x-1.5">
                      <p className="font-semibold text-xs text-[#F5F5F7] truncate">{p.displayName}</p>
                      {isMe && <span className="text-[10px] text-blue-400 font-normal uppercase tracking-wider">(You)</span>}
                    </div>
                    <div className="flex items-center space-x-1 text-[10px] text-neutral-400">
                      <span className="uppercase font-medium text-[9px]">{p.role}</span>
                      {p.department && <span>• {p.department}</span>}
                    </div>
                  </div>
                </div>

                {/* Right: Status Icons & Action Dropdown */}
                <div className="flex items-center space-x-2 flex-shrink-0">
                  {p.handRaised && (
                    <Hand className="w-3.5 h-3.5 text-[#FEBC2E] fill-[#FEBC2E]" />
                  )}

                  {p.microphoneEnabled ? (
                    <Mic className={`w-3.5 h-3.5 ${p.speaking ? "text-blue-400" : "text-neutral-400"}`} />
                  ) : (
                    <MicOff className="w-3.5 h-3.5 text-[#FF3B30]" />
                  )}

                  {p.cameraEnabled ? (
                    <Video className="w-3.5 h-3.5 text-blue-400" />
                  ) : (
                    <VideoOff className="w-3.5 h-3.5 text-neutral-500" />
                  )}

                  {/* Host Action Popover Trigger */}
                  {isHostOrCoHost && !isMe && (
                    <div className="relative">
                      <button
                        onClick={() => setSelectedUserForMenu(selectedUserForMenu === p.id ? null : p.id)}
                        className="p-1 rounded text-neutral-400 hover:text-white hover:bg-white/10"
                        title="Participant Actions"
                      >
                        <MoreHorizontal className="w-3.5 h-3.5" />
                      </button>

                      {selectedUserForMenu === p.id && (
                        <div 
                          className="absolute right-0 top-full mt-1 w-48 bg-[#161617] border border-white/10 rounded-xl p-1 shadow-2xl z-50 text-xs text-neutral-200 animate-in fade-in zoom-in-95"
                        >
                          <button
                            onClick={() => {
                              onMuteParticipant(p.id);
                              setSelectedUserForMenu(null);
                            }}
                            className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-left"
                          >
                            <MicOff className="w-3.5 h-3.5 text-[#FF3B30]" />
                            <span>{p.microphoneEnabled ? "Mute Microphone" : "Request Unmute"}</span>
                          </button>

                          <button
                            onClick={() => {
                              onPromoteRole(p.id, "CO_HOST");
                              setSelectedUserForMenu(null);
                            }}
                            className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-left"
                          >
                            <Shield className="w-3.5 h-3.5 text-purple-400" />
                            <span>Make Co-Host</span>
                          </button>

                          <button
                            onClick={() => {
                              onPromoteRole(p.id, "PRESENTER");
                              setSelectedUserForMenu(null);
                            }}
                            className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-left"
                          >
                            <Tv className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Assign as Presenter</span>
                          </button>

                          <div className="my-1 border-t border-white/10" />

                          <button
                            onClick={() => {
                              onRemoveParticipant(p.id);
                              setSelectedUserForMenu(null);
                            }}
                            className="w-full flex items-center space-x-2 px-2.5 py-1.5 rounded-lg hover:bg-[#FF3B30]/20 text-[#FF3B30] text-left font-semibold"
                          >
                            <UserMinus className="w-3.5 h-3.5" />
                            <span>Remove from Meeting</span>
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer Info */}
      <div className="p-3 border-t border-white/10 bg-[#161617] text-[11px] text-neutral-400 flex items-center justify-between">
        <span>Deterministic State Engine</span>
        <span className="font-mono text-blue-400">All Peers Connected</span>
      </div>
    </div>
  );
};
