"use client";

import React, { useState } from "react";
import { 
  FolderOpen, 
  UploadCloud, 
  FileText, 
  Download, 
  Eye, 
  Trash2, 
  X, 
  Check, 
  FileCode, 
  FileAudio, 
  FileImage,
  Sparkles
} from "lucide-react";
import { SharedFile } from "@/lib/types";

interface FilesPanelProps {
  files: SharedFile[];
  onUploadFile: (file: File) => void;
  onDeleteFile: (id: string) => void;
  onClose: () => void;
}

export const FilesPanel: React.FC<FilesPanelProps> = ({
  files,
  onUploadFile,
  onDeleteFile,
  onClose
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [previewFile, setPreviewFile] = useState<SharedFile | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onUploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onUploadFile(e.target.files[0]);
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case "code":
        return <FileCode className="w-5 h-5 text-blue-400" />;
      case "audio":
        return <FileAudio className="w-5 h-5 text-purple-400" />;
      case "image":
        return <FileImage className="w-5 h-5 text-emerald-400" />;
      default:
        return <FileText className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <div 
      id="side-panel-files"
      className="w-full h-full bg-[#11141f]/95 backdrop-blur-xl border-l border-white/[0.08] flex flex-col justify-between z-30 select-none shadow-2xl"
    >
      {/* Header */}
      <div className="h-12 border-b border-white/[0.08] px-4 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <FolderOpen className="w-4 h-4 text-blue-400" />
          <span className="font-semibold text-white text-xs">Shared Documents ({files.length})</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 font-mono">
            E2EE Blob
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-white/[0.08] transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Drag and Drop Zone */}
      <div className="p-3 border-b border-white/[0.06]">
        <label
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`w-full border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-all ${
            isDragging 
              ? "border-blue-500 bg-blue-500/10 scale-102" 
              : "border-white/[0.12] hover:border-white/[0.24] bg-white/[0.02]"
          }`}
        >
          <UploadCloud className="w-6 h-6 text-blue-400 mb-1 animate-bounce" />
          <p className="text-xs font-semibold text-white">Click or drag files here</p>
          <p className="text-[10px] text-neutral-400 mt-0.5">Keynote, PDF, Swift, Images, Audio (Max 100MB)</p>
          <input type="file" onChange={handleFileInput} className="hidden" />
        </label>
      </div>

      {/* Files List */}
      <div className="flex-1 p-3 overflow-y-auto space-y-2">
        {files.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 text-xs">
            <FolderOpen className="w-8 h-8 mb-2 opacity-30 text-blue-400" />
            <p>No documents uploaded yet.</p>
          </div>
        ) : (
          files.map((file) => (
            <div 
              key={file.id}
              className="bg-[#181d2e] border border-white/[0.08] rounded-xl p-3 flex items-center justify-between group hover:border-white/[0.18] transition-colors"
            >
              <div className="flex items-center space-x-3 truncate">
                <div className="p-2 rounded-lg bg-black/30 border border-white/[0.06]">
                  {getFileIcon(file.type)}
                </div>
                <div className="truncate">
                  <p className="font-semibold text-xs text-white truncate">{file.name}</p>
                  <p className="text-[10px] text-neutral-400">
                    {file.size} • Uploaded by {file.uploadedBy} at {file.uploadedAt}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-1 pl-2">
                <button
                  onClick={() => setPreviewFile(file)}
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/[0.08]"
                  title="Preview"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>
                <a
                  href={file.url}
                  download={file.name}
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-blue-400 hover:bg-white/[0.08]"
                  title="Download File"
                >
                  <Download className="w-3.5 h-3.5" />
                </a>
                <button
                  onClick={() => onDeleteFile(file.id)}
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-red-400 hover:bg-white/[0.08]"
                  title="Delete File"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* File Preview Modal overlay */}
      {previewFile && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-white/[0.1]">
            <p className="font-semibold text-white text-xs">{previewFile.name}</p>
            <button onClick={() => setPreviewFile(null)} className="text-neutral-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="flex-1 flex items-center justify-center p-4">
            <div className="bg-[#141826] border border-white/10 p-6 rounded-xl text-center space-y-2 max-w-sm">
              <FileText className="w-12 h-12 text-blue-400 mx-auto" />
              <p className="font-semibold text-white text-sm">{previewFile.name}</p>
              <p className="text-xs text-neutral-400">Size: {previewFile.size}</p>
              <p className="text-[11px] text-neutral-300 bg-black/40 p-2 rounded border border-white/[0.08]">
                Protected by MLS End-to-End Encryption & Apple Secure Enclave
              </p>
            </div>
          </div>
          <button 
            onClick={() => setPreviewFile(null)}
            className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg"
          >
            Close Preview
          </button>
        </div>
      )}

      {/* Footer */}
      <div className="p-3 border-t border-white/[0.08] bg-[#0e111a] text-[11px] text-neutral-400 flex items-center justify-between">
        <span>Encrypted Workspace Storage</span>
        <span className="font-mono text-emerald-400">Total: 4.8 MB</span>
      </div>
    </div>
  );
};
