"use client";

import React, { useState } from "react";
import { 
  ShieldCheck, 
  Copy, 
  Check, 
  LayoutGrid, 
  User, 
  Maximize2, 
  Monitor, 
  SplitSquareHorizontal, 
  Tv, 
  Sparkles,
  ChevronDown,
  Layers,
  PictureInPicture,
  Minimize2
} from "lucide-react";
import { LayoutMode } from "@/lib/types";

interface MainWindowHeaderProps {
  meetingTitle: string;
  meetingId: string;
  currentLayout: LayoutMode;
  onLayoutChange: (layout: LayoutMode) => void;
  onTogglePiP: () => void;
  onToggleFullscreen: () => void;
  isFullscreen: boolean;
  onOpenMultiMonitor: () => void;
}

const LAYOUT_OPTIONS: { id: LayoutMode; label: string; icon: React.ReactNode; desc: string }[] = [
  { id: "SPEAKER", label: "Active Speaker", icon: <User className="w-4 h-4" />, desc: "Focuses primary speaker with filmstrip" },
  { id: "GALLERY", label: "Gallery Grid", icon: <LayoutGrid className="w-4 h-4" />, desc: "Equal grid of all participants" },
  { id: "PRESENTATION", label: "Presentation", icon: <Tv className="w-4 h-4" />, desc: "Maximized screen or document share" },
  { id: "PRESENTATION_SPEAKER", label: "Presentation + Speaker", icon: <Layers className="w-4 h-4" />, desc: "Shared content with floating speaker" },
  { id: "SIDE_BY_SIDE", label: "Side by Side", icon: <SplitSquareHorizontal className="w-4 h-4" />, desc: "Split presentation and video grid" },
  { id: "SPOTLIGHT", label: "Spotlight", icon: <Sparkles className="w-4 h-4" />, desc: "Cinematic highlighted presenter" },
  { id: "DIRECTOR", label: "Director Mode", icon: <Monitor className="w-4 h-4" />, desc: "Multi-camera broadcast switching" }
];

export const MainWindowHeader: React.FC<MainWindowHeaderProps> = ({
  meetingTitle,
  meetingId,
  currentLayout,
  onLayoutChange,
  onTogglePiP,
  onToggleFullscreen,
  isFullscreen,
  onOpenMultiMonitor
}) => {
  const [copied, setCopied] = useState(false);
  const [showLayoutMenu, setShowLayoutMenu] = useState(false);

  const copyMeetingLink = () => {
    navigator.clipboard.writeText(`https://teleconference.apple.corp/room/${meetingId}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const activeLayoutInfo = LAYOUT_OPTIONS.find(l => l.id === currentLayout) || LAYOUT_OPTIONS[0];

  return (
    <div 
      id="main-window-header"
      className="h-12 bg-[#161617] border-b border-white/10 px-4 flex items-center justify-between select-none z-40 relative"
    >
      {/* Left: macOS Traffic Lights & Title */}
      <div className="flex items-center space-x-3.5">
        {/* macOS Traffic Lights */}
        <div className="flex items-center space-x-1.5 group">
          <button 
            id="traffic-light-close"
            className="w-3 h-3 rounded-full bg-[#FF5F57] flex items-center justify-center text-black/60 opacity-90 group-hover:opacity-100 focus:outline-none transition-transform active:scale-95"
            title="Close Window"
          >
            <span className="opacity-0 group-hover:opacity-100 text-[9px] font-bold leading-none">×</span>
          </button>
          <button 
            id="traffic-light-minimize"
            className="w-3 h-3 rounded-full bg-[#FEBC2E] flex items-center justify-center text-black/60 opacity-90 group-hover:opacity-100 focus:outline-none transition-transform active:scale-95"
            title="Minimize"
          >
            <span className="opacity-0 group-hover:opacity-100 text-[9px] font-bold leading-none">−</span>
          </button>
          <button 
            id="traffic-light-fullscreen"
            onClick={onToggleFullscreen}
            className="w-3 h-3 rounded-full bg-[#28C840] flex items-center justify-center text-black/60 opacity-90 group-hover:opacity-100 focus:outline-none transition-transform active:scale-95"
            title="Zoom / Full Screen"
          >
            <span className="opacity-0 group-hover:opacity-100 text-[8px] font-bold leading-none">+</span>
          </button>
        </div>

        <div className="h-4 w-px bg-white/10 mx-1"></div>

        {/* Meeting Title & E2EE Badge */}
        <div className="flex items-center space-x-2.5">
          <h1 className="text-sm font-semibold text-[#F5F5F7] tracking-tight">
            {meetingTitle}
          </h1>

          <div 
            className="flex items-center space-x-1 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-semibold uppercase tracking-wider"
            title="End-to-End Encrypted via MLS & TLS 1.3 Secure Enclave"
          >
            <ShieldCheck className="w-3 h-3" />
            <span>E2EE</span>
          </div>
        </div>
      </div>

      {/* Center: Meeting ID & Quick Copy */}
      <div className="hidden md:flex items-center space-x-2 bg-white/5 border border-white/10 px-3 py-1 rounded-md text-xs text-[#F5F5F7]">
        <span className="text-[11px] text-white/50 uppercase tracking-wider font-mono">Room Code</span>
        <span className="text-xs font-mono font-semibold text-blue-400">{meetingId}</span>
        <div className="h-3 w-px bg-white/10 mx-1"></div>
        <button
          onClick={copyMeetingLink}
          className="hover:text-white transition-colors focus:outline-none flex items-center gap-1 text-[11px] text-white/70"
          title="Copy Meeting URL"
        >
          {copied ? (
            <Check className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <Copy className="w-3.5 h-3.5 text-neutral-400 hover:text-white" />
          )}
          <span>{copied ? "Copied" : "Copy"}</span>
        </button>
      </div>

      {/* Right: Dynamic Layout Switcher & Window Tools */}
      <div className="flex items-center space-x-2">
        {/* Dynamic Layout Menu */}
        <div className="relative">
          <button
            id="layout-switcher-btn"
            onClick={() => setShowLayoutMenu(!showLayoutMenu)}
            className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-white/10 text-xs font-medium text-[#F5F5F7] transition-colors"
          >
            {activeLayoutInfo.icon}
            <span className="hidden sm:inline">{activeLayoutInfo.label}</span>
            <ChevronDown className="w-3 h-3 text-neutral-400" />
          </button>

          {showLayoutMenu && (
            <div 
              id="layout-switcher-dropdown"
              className="absolute right-0 top-full mt-2 w-64 bg-[#161617] border border-white/10 rounded-xl p-2 shadow-2xl z-50 text-neutral-200"
            >
              <div className="px-2.5 py-1.5 text-[10px] uppercase font-bold text-blue-400 tracking-widest">
                Stage Layouts
              </div>
              <div className="space-y-1">
                {LAYOUT_OPTIONS.map((opt) => {
                  const isSelected = opt.id === currentLayout;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => {
                        onLayoutChange(opt.id);
                        setShowLayoutMenu(false);
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-2 rounded-lg text-xs text-left transition-colors ${
                        isSelected 
                          ? "bg-blue-600/20 text-blue-300 font-medium border border-blue-500/30" 
                          : "hover:bg-white/5 text-neutral-300"
                      }`}
                    >
                      <div className="flex items-center space-x-2.5">
                        <span className={isSelected ? "text-blue-400" : "text-neutral-400"}>{opt.icon}</span>
                        <div>
                          <p className="font-medium text-xs leading-none text-white">{opt.label}</p>
                          <p className="text-[10px] text-neutral-400 mt-1 leading-tight">{opt.desc}</p>
                        </div>
                      </div>
                      {isSelected && <Check className="w-3.5 h-3.5 text-blue-400" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Multi-Monitor Detacher */}
        <button
          onClick={onOpenMultiMonitor}
          className="p-2 rounded-lg bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-white/10 text-neutral-300 hover:text-white transition-colors"
          title="Multi-Monitor Workspace (Display 1 Meeting, Display 2 Notes/Presentation)"
        >
          <Monitor className="w-4 h-4" />
        </button>

        {/* Native Picture-in-Picture */}
        <button
          onClick={onTogglePiP}
          className="p-2 rounded-lg bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-white/10 text-neutral-300 hover:text-white transition-colors"
          title="Toggle macOS Picture-in-Picture Mini Overlay"
        >
          <PictureInPicture className="w-4 h-4" />
        </button>

        {/* Fullscreen Toggle */}
        <button
          onClick={onToggleFullscreen}
          className="p-2 rounded-lg bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-white/10 text-neutral-300 hover:text-white transition-colors"
          title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};
