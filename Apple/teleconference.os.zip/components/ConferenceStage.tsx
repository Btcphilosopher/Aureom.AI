"use client";

import React, { useState } from "react";
import { 
  LayoutMode, 
  Participant, 
  CaptionsConfig, 
  TranscriptItem 
} from "@/lib/types";
import { ParticipantVideoCard } from "./ParticipantVideoCard";
import { PresentationCanvas } from "./PresentationCanvas";
import { Sparkles, Users, Tv, Volume2 } from "lucide-react";

interface ConferenceStageProps {
  layout: LayoutMode;
  participants: Participant[];
  activeSpeaker: Participant;
  presenter: Participant | null;
  localVideoStream: MediaStream | null;
  screenStream: MediaStream | null;
  isSharingScreen: boolean;
  isSharingSystemAudio: boolean;
  onStopScreenSharing: () => void;
  captionsConfig: CaptionsConfig;
  latestTranscript: TranscriptItem | null;
  reactions: { id: string; emoji: string; x: number; y: number }[];
  onSelectParticipant: (p: Participant) => void;
}

export const ConferenceStage: React.FC<ConferenceStageProps> = ({
  layout,
  participants,
  activeSpeaker,
  presenter,
  localVideoStream,
  screenStream,
  isSharingScreen,
  isSharingSystemAudio,
  onStopScreenSharing,
  captionsConfig,
  latestTranscript,
  reactions,
  onSelectParticipant
}) => {
  // If someone is sharing screen or presentation layout is requested, prefer presentation view
  const isPresentationActive = isSharingScreen || layout === "PRESENTATION" || layout === "PRESENTATION_SPEAKER" || layout === "SIDE_BY_SIDE";
  const primaryPresenter = presenter || activeSpeaker;

  // Render Live Captions overlay
  const renderCaptionsOverlay = () => {
    if (!captionsConfig.enabled || !latestTranscript) return null;

    const fontSizeClass = {
      small: "text-xs",
      medium: "text-sm",
      large: "text-base font-semibold"
    }[captionsConfig.fontSize];

    const bgClass = {
      glass: "bg-black/70 backdrop-blur-xl border-white/[0.12] text-white",
      dark: "bg-neutral-900 border-neutral-700 text-white",
      "high-contrast": "bg-yellow-400 text-black border-black font-bold"
    }[captionsConfig.background];

    return (
      <div 
        id="live-captions-overlay"
        className={`absolute z-30 left-1/2 -translate-x-1/2 px-4 py-2 rounded-xl border shadow-2xl transition-all max-w-xl text-center pointer-events-none ${
          captionsConfig.position === "top" ? "top-4" : "bottom-20"
        } ${bgClass}`}
      >
        <p className="text-[10px] text-blue-400 uppercase font-mono tracking-wider mb-0.5">
          Live Caption • {latestTranscript.speakerName}
        </p>
        <p className={`${fontSizeClass} leading-snug`}>
          &ldquo;{latestTranscript.text}&rdquo;
        </p>
      </div>
    );
  };

  // Render Reaction Bursts
  const renderReactions = () => (
    <div className="absolute inset-0 pointer-events-none z-40 overflow-hidden">
      {reactions.map((r) => (
        <div
          key={r.id}
          className="absolute text-3xl animate-[bounce_1.5s_ease-out_infinite] transition-all"
          style={{ left: `${r.x}%`, top: `${r.y}%` }}
        >
          {r.emoji}
        </div>
      ))}
    </div>
  );

  return (
    <div 
      id="conference-stage"
      className="relative flex-1 w-full h-full bg-[#0A0A0A] p-4 flex flex-col justify-between overflow-hidden"
    >
      {/* Dynamic Main Stage Viewport */}
      <div className="relative flex-1 w-full h-full flex items-center justify-center overflow-hidden min-h-0">
        
        {/* LAYOUT: GALLERY GRID */}
        {layout === "GALLERY" && !isSharingScreen && (
          <div className="w-full h-full grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 p-1 auto-rows-fr">
            {participants.map((p) => (
              <ParticipantVideoCard
                key={p.id}
                participant={p}
                isLocal={p.isLocal}
                localVideoStream={localVideoStream}
                onSelect={() => onSelectParticipant(p)}
              />
            ))}
          </div>
        )}

        {/* LAYOUT: SPEAKER (Large centerpiece + filmstrip) */}
        {layout === "SPEAKER" && !isSharingScreen && (
          <div className="w-full h-full flex flex-col justify-between gap-3">
            {/* Main Center Speaker Tile */}
            <div className="flex-1 w-full h-full min-h-0">
              <ParticipantVideoCard
                participant={activeSpeaker}
                isLocal={activeSpeaker.isLocal}
                localVideoStream={localVideoStream}
                isPrimary={true}
                onSelect={() => onSelectParticipant(activeSpeaker)}
              />
            </div>
          </div>
        )}

        {/* LAYOUT: PRESENTATION / PRESENTATION + SPEAKER */}
        {(layout === "PRESENTATION" || layout === "PRESENTATION_SPEAKER" || isSharingScreen) && (
          <div className="relative w-full h-full flex items-center justify-center">
            {/* Screen / Keynote Presentation Canvas */}
            <PresentationCanvas
              presenter={primaryPresenter}
              screenStream={screenStream}
              isSharingSystemAudio={isSharingSystemAudio}
              onStopSharing={onStopScreenSharing}
            />

            {/* Inset Presenter Overlay Box (for PRESENTATION_SPEAKER) */}
            {layout === "PRESENTATION_SPEAKER" && (
              <div className="absolute bottom-4 right-4 w-64 h-40 z-30 shadow-2xl rounded-xl overflow-hidden border border-white/20">
                <ParticipantVideoCard
                  participant={primaryPresenter}
                  isLocal={primaryPresenter.isLocal}
                  localVideoStream={localVideoStream}
                />
              </div>
            )}
          </div>
        )}

        {/* LAYOUT: SIDE BY SIDE (50% Presentation, 50% Video Grid) */}
        {layout === "SIDE_BY_SIDE" && (
          <div className="w-full h-full grid grid-cols-1 lg:grid-cols-2 gap-3">
            <PresentationCanvas
              presenter={primaryPresenter}
              screenStream={screenStream}
              isSharingSystemAudio={isSharingSystemAudio}
              onStopSharing={onStopScreenSharing}
            />
            <div className="grid grid-cols-2 gap-2 h-full auto-rows-fr">
              {participants.slice(0, 4).map((p) => (
                <ParticipantVideoCard
                  key={p.id}
                  participant={p}
                  isLocal={p.isLocal}
                  localVideoStream={localVideoStream}
                  onSelect={() => onSelectParticipant(p)}
                />
              ))}
            </div>
          </div>
        )}

        {/* LAYOUT: SPOTLIGHT */}
        {layout === "SPOTLIGHT" && !isSharingScreen && (
          <div className="w-full h-full flex items-center justify-center p-2">
            <div className="w-full max-w-5xl h-full rounded-2xl overflow-hidden shadow-2xl">
              <ParticipantVideoCard
                participant={activeSpeaker}
                isLocal={activeSpeaker.isLocal}
                localVideoStream={localVideoStream}
                isPrimary={true}
              />
            </div>
          </div>
        )}

        {/* LAYOUT: DIRECTOR */}
        {layout === "DIRECTOR" && !isSharingScreen && (
          <div className="w-full h-full grid grid-cols-3 gap-3 p-1">
            <div className="col-span-2 h-full">
              <ParticipantVideoCard
                participant={activeSpeaker}
                isLocal={activeSpeaker.isLocal}
                localVideoStream={localVideoStream}
                isPrimary={true}
              />
            </div>
            <div className="flex flex-col gap-2 h-full overflow-y-auto pr-1">
              {participants.filter(p => p.id !== activeSpeaker.id).map((p) => (
                <div key={p.id} className="h-36 flex-shrink-0">
                  <ParticipantVideoCard
                    participant={p}
                    isLocal={p.isLocal}
                    localVideoStream={localVideoStream}
                    onSelect={() => onSelectParticipant(p)}
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Bottom Filmstrip (Displayed in SPEAKER and PRESENTATION mode) */}
      {(layout === "SPEAKER" || layout === "PRESENTATION") && (
        <div 
          id="conference-bottom-filmstrip"
          className="h-28 w-full mt-3 flex items-center space-x-2.5 overflow-x-auto py-1 px-1 z-20"
        >
          {participants.map((p) => (
            <ParticipantVideoCard
              key={p.id}
              participant={p}
              isLocal={p.isLocal}
              localVideoStream={localVideoStream}
              isFilmstrip={true}
              onSelect={() => onSelectParticipant(p)}
            />
          ))}
        </div>
      )}

      {/* Floating Overlays */}
      {renderCaptionsOverlay()}
      {renderReactions()}
    </div>
  );
};
