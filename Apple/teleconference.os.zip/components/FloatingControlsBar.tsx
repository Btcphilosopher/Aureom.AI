"use client";

import React, { useState } from "react";
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  MonitorUp, 
  MessageSquare, 
  Users, 
  Hand, 
  Edit3, 
  Sparkles, 
  FolderOpen, 
  Disc, 
  Activity, 
  Code, 
  Calendar, 
  Settings, 
  PhoneOff, 
  ChevronUp, 
  Check, 
  Sliders, 
  Volume2,
  Smile,
  Shield
} from "lucide-react";
import { DeviceConfig } from "@/lib/types";

interface FloatingControlsBarProps {
  isMuted: boolean;
  isCameraOff: boolean;
  isScreenSharing: boolean;
  isRecording: boolean;
  handRaised: boolean;
  activePanel: string | null;
  unreadChatCount: number;
  participantsCount: number;
  waitingRoomCount: number;
  deviceConfig: DeviceConfig;
  micAudioLevel: number;
  onToggleMute: () => void;
  onToggleCamera: () => void;
  onToggleScreenShare: () => void;
  onToggleRecording: () => void;
  onToggleHand: () => void;
  onTogglePanel: (panel: string) => void;
  onSendReaction: (emoji: string) => void;
  onOpenScheduleModal: () => void;
  onOpenSettingsModal: () => void;
  onLeaveMeeting: () => void;
  onUpdateDeviceConfig: (cfg: Partial<DeviceConfig>) => void;
}

const EMOJI_REACTIONS = ["👍", "❤️", "🎉", "✋", "❓", "‼️", "👏", "🚀"];

export const FloatingControlsBar: React.FC<FloatingControlsBarProps> = ({
  isMuted,
  isCameraOff,
  isScreenSharing,
  isRecording,
  handRaised,
  activePanel,
  unreadChatCount,
  participantsCount,
  waitingRoomCount,
  deviceConfig,
  micAudioLevel,
  onToggleMute,
  onToggleCamera,
  onToggleScreenShare,
  onToggleRecording,
  onToggleHand,
  onTogglePanel,
  onSendReaction,
  onOpenScheduleModal,
  onOpenSettingsModal,
  onLeaveMeeting,
  onUpdateDeviceConfig
}) => {
  const [showMicMenu, setShowMicMenu] = useState(false);
  const [showCameraMenu, setShowCameraMenu] = useState(false);
  const [showReactionsMenu, setShowReactionsMenu] = useState(false);

  return (
    <div 
      id="floating-controls-bar"
      className="relative z-40 flex items-center justify-center px-4"
    >
      {/* Frosted Glass Floating Capsule */}
      <div className="bg-[#161617]/95 backdrop-blur-2xl border border-white/10 rounded-2xl px-3.5 py-2 macos-floating-pill flex items-center space-x-2 shadow-2xl">
        
        {/* 1. MICROPHONE CONTROL WITH LEVEL METER & POPUP */}
        <div className="relative flex items-center">
          <button
            id="control-mic-btn"
            onClick={onToggleMute}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all relative overflow-hidden ${
              isMuted 
                ? "bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/40 hover:bg-[#FF3B30]/30" 
                : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
            }`}
            title="Mute / Unmute (⌘⇧M)"
          >
            {/* Real Audio Meter Ring Glow when talking */}
            {!isMuted && micAudioLevel > 0.05 && (
              <span 
                className="absolute inset-0 bg-blue-500/20 pointer-events-none transition-opacity"
                style={{ opacity: Math.min(micAudioLevel * 2, 0.8) }}
              />
            )}
            {isMuted ? <MicOff className="w-4 h-4 text-[#FF3B30]" /> : <Mic className="w-4 h-4 text-blue-400" />}
            <span className="hidden sm:inline">{isMuted ? "Unmute" : "Mute"}</span>
          </button>

          <button
            onClick={() => setShowMicMenu(!showMicMenu)}
            className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white transition-colors ml-0.5"
            title="Microphone Settings"
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>

          {/* Microphone Quick Settings Popover */}
          {showMicMenu && (
            <div 
              id="mic-settings-popover"
              className="absolute bottom-full mb-3 left-0 w-72 bg-[#161617] border border-white/10 rounded-2xl p-3 shadow-2xl z-50 text-xs text-neutral-200"
            >
              <div className="font-semibold text-white pb-2 border-b border-white/10 flex items-center justify-between">
                <span>Core Audio Microphone Engine</span>
                <span className="text-[10px] text-blue-400 font-mono">AVAudioEngine</span>
              </div>
              
              <div className="py-2 space-y-2">
                <p className="text-[10px] uppercase font-bold text-neutral-400">Audio Input Device</p>
                <div className="space-y-1">
                  {["MacBook Pro Microphone (Built-in)", "Studio Display Array Microphone", "AirPods Pro (Spatial Audio)"].map((dev, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        onUpdateDeviceConfig({ micDeviceId: dev });
                        setShowMicMenu(false);
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left transition-colors ${
                        deviceConfig.micDeviceId === dev ? "bg-blue-600/20 text-blue-300 font-medium border border-blue-500/30" : "hover:bg-white/5"
                      }`}
                    >
                      <span className="truncate">{dev}</span>
                      {deviceConfig.micDeviceId === dev && <Check className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />}
                    </button>
                  ))}
                </div>

                <div className="pt-2 border-t border-white/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <span>Echo Cancellation</span>
                    <input 
                      type="checkbox" 
                      checked={deviceConfig.echoCancellation}
                      onChange={(e) => onUpdateDeviceConfig({ echoCancellation: e.target.checked })}
                      className="rounded accent-blue-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Voice Isolation (Noise Sup.)</span>
                    <input 
                      type="checkbox" 
                      checked={deviceConfig.noiseSuppression}
                      onChange={(e) => onUpdateDeviceConfig({ noiseSuppression: e.target.checked })}
                      className="rounded accent-blue-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 2. CAMERA CONTROL WITH RESOLUTION POPUP */}
        <div className="relative flex items-center">
          <button
            id="control-camera-btn"
            onClick={onToggleCamera}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
              isCameraOff 
                ? "bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/40 hover:bg-[#FF3B30]/30" 
                : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
            }`}
            title="Camera On / Off (⌘⇧V)"
          >
            {isCameraOff ? <VideoOff className="w-4 h-4 text-[#FF3B30]" /> : <Video className="w-4 h-4 text-blue-400" />}
            <span className="hidden sm:inline">{isCameraOff ? "Start Video" : "Stop Video"}</span>
          </button>

          <button
            onClick={() => setShowCameraMenu(!showCameraMenu)}
            className="p-1.5 rounded-lg hover:bg-white/10 text-neutral-400 hover:text-white transition-colors ml-0.5"
            title="Camera Quality & Capture Settings"
          >
            <ChevronUp className="w-3.5 h-3.5" />
          </button>

          {/* Camera Quick Settings Popover */}
          {showCameraMenu && (
            <div 
              id="camera-settings-popover"
              className="absolute bottom-full mb-3 left-0 w-72 bg-[#161617] border border-white/10 rounded-2xl p-3 shadow-2xl z-50 text-xs text-neutral-200"
            >
              <div className="font-semibold text-white pb-2 border-b border-white/10 flex items-center justify-between">
                <span>AVFoundation Capture Pipeline</span>
                <span className="text-[10px] text-blue-400 font-mono">AVCaptureSession</span>
              </div>
              
              <div className="py-2 space-y-2">
                <p className="text-[10px] uppercase font-bold text-neutral-400">Capture Device</p>
                <div className="space-y-1">
                  {["FaceTime HD Camera (Built-in)", "iPhone 16 Pro (Continuity Camera)", "Studio Display Ultra Wide"].map((dev, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        onUpdateDeviceConfig({ cameraDeviceId: dev });
                        setShowCameraMenu(false);
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left transition-colors ${
                        deviceConfig.cameraDeviceId === dev ? "bg-blue-600/20 text-blue-300 font-medium border border-blue-500/30" : "hover:bg-white/5"
                      }`}
                    >
                      <span className="truncate">{dev}</span>
                      {deviceConfig.cameraDeviceId === dev && <Check className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />}
                    </button>
                  ))}
                </div>

                <div className="pt-2 border-t border-white/10">
                  <p className="text-[10px] uppercase font-bold text-neutral-400 mb-1.5">Stream Target Resolution</p>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(["720p", "1080p", "4K"] as const).map((res) => (
                      <button
                        key={res}
                        onClick={() => onUpdateDeviceConfig({ resolution: res })}
                        className={`py-1.5 rounded text-center font-mono text-[11px] transition-colors ${
                          deviceConfig.resolution === res 
                            ? "bg-blue-600 text-white font-bold" 
                            : "bg-white/5 text-neutral-300 hover:bg-white/10"
                        }`}
                      >
                        {res}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 3. SCREEN SHARE (SCREENCAPTUREKIT) */}
        <button
          id="control-screenshare-btn"
          onClick={onToggleScreenShare}
          className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
            isScreenSharing 
              ? "bg-blue-600/20 text-[#007AFF] border border-blue-500/40 hover:bg-blue-600/30" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="Share Screen (⌘⇧S)"
        >
          <MonitorUp className={`w-4 h-4 ${isScreenSharing ? "text-[#007AFF]" : "text-neutral-300"}`} />
          <span className="hidden sm:inline font-bold uppercase tracking-wider text-[11px]">{isScreenSharing ? "Sharing" : "Share"}</span>
        </button>

        {/* 4. CHAT */}
        <button
          id="control-chat-btn"
          onClick={() => onTogglePanel("chat")}
          className={`relative flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
            activePanel === "chat" 
              ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="Meeting Chat (⌘⇧C)"
        >
          <MessageSquare className="w-4 h-4" />
          <span className="hidden md:inline">Chat</span>
          {unreadChatCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-blue-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center shadow-lg">
              {unreadChatCount}
            </span>
          )}
        </button>

        {/* 5. PARTICIPANTS */}
        <button
          id="control-participants-btn"
          onClick={() => onTogglePanel("participants")}
          className={`relative flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
            activePanel === "participants" 
              ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="Participants & Waiting Room"
        >
          <Users className="w-4 h-4" />
          <span className="hidden md:inline">{participantsCount}</span>
          {waitingRoomCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-black text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-bounce shadow-lg">
              {waitingRoomCount}
            </span>
          )}
        </button>

        {/* 6. RAISE HAND */}
        <button
          id="control-raisehand-btn"
          onClick={onToggleHand}
          className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
            handRaised 
              ? "bg-[#FEBC2E] text-black shadow-lg shadow-[#FEBC2E]/30" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="Raise / Lower Hand (⌘⇧R)"
        >
          <Hand className={`w-4 h-4 ${handRaised ? "fill-black" : ""}`} />
          <span className="hidden lg:inline">{handRaised ? "Lowered" : "Raise"}</span>
        </button>

        {/* 7. EMOJI REACTIONS BAR */}
        <div className="relative">
          <button
            id="control-reactions-btn"
            onClick={() => setShowReactionsMenu(!showReactionsMenu)}
            className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/5 text-white transition-all"
            title="Reactions (👍 ❤️ 🎉 ✋ ❓ ‼️)"
          >
            <Smile className="w-4 h-4 text-yellow-400" />
          </button>

          {showReactionsMenu && (
            <div 
              id="reactions-menu-popover"
              className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 bg-[#161617] border border-white/10 rounded-2xl p-2 shadow-2xl flex items-center space-x-1 z-50 animate-in fade-in zoom-in-95 duration-150"
            >
              {EMOJI_REACTIONS.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => {
                    onSendReaction(emoji);
                    setShowReactionsMenu(false);
                  }}
                  className="p-1.5 text-xl hover:scale-125 transition-transform active:scale-95"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 8. COLLABORATIVE WHITEBOARD */}
        <button
          id="control-whiteboard-btn"
          onClick={() => onTogglePanel("whiteboard")}
          className={`p-2.5 rounded-xl transition-all ${
            activePanel === "whiteboard" 
              ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="Collaborative Whiteboard"
        >
          <Edit3 className="w-4 h-4 text-purple-400" />
        </button>

        {/* 9. AI MEETING INTELLIGENCE (GEMINI) */}
        <button
          id="control-ai-btn"
          onClick={() => onTogglePanel("aiAssistant")}
          className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
            activePanel === "aiAssistant" 
              ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-indigo-600/30" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="AI Meeting Assistant (Summarize, Action Items, Document Q&A)"
        >
          <Sparkles className="w-4 h-4 text-blue-400" />
          <span className="hidden md:inline font-bold uppercase tracking-wider text-[11px] text-blue-400">AI Intelligence</span>
        </button>

        {/* 10. RECORDING */}
        <button
          id="control-record-btn"
          onClick={onToggleRecording}
          className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
            isRecording 
              ? "bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/40 animate-pulse" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="Record Conference"
        >
          <Disc className={`w-4 h-4 ${isRecording ? "text-[#FF3B30]" : "text-neutral-300"}`} />
          <span className="hidden xl:inline">{isRecording ? "Recording" : "Record"}</span>
        </button>

        {/* 11. ENTERPRISE ADMIN & DIAGNOSTICS */}
        <button
          id="control-diagnostics-btn"
          onClick={() => onTogglePanel("diagnostics")}
          className={`p-2.5 rounded-xl transition-all ${
            activePanel === "diagnostics" 
              ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="Enterprise Diagnostics & Digital Twin"
        >
          <Activity className="w-4 h-4 text-cyan-400" />
        </button>

        {/* 12. SWIFT SOURCE CODE EXPLORER */}
        <button
          id="control-swift-code-btn"
          onClick={() => onTogglePanel("swiftCode")}
          className={`p-2.5 rounded-xl transition-all ${
            activePanel === "swiftCode" 
              ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30" 
              : "bg-white/10 text-white hover:bg-white/20 border border-white/5"
          }`}
          title="View Native Swift Architecture"
        >
          <Code className="w-4 h-4 text-blue-400" />
        </button>

        {/* 13. SETTINGS */}
        <button
          id="control-settings-btn"
          onClick={onOpenSettingsModal}
          className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/5 text-neutral-300 hover:text-white transition-all"
          title="Settings (⌘,)"
        >
          <Settings className="w-4 h-4" />
        </button>

        {/* 14. END / LEAVE MEETING */}
        <button
          id="control-leave-btn"
          onClick={onLeaveMeeting}
          className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-[#FF3B30] hover:bg-[#D70015] text-white text-xs font-bold transition-all shadow-lg shadow-[#FF3B30]/30 active:scale-95 ml-1"
          title="Leave or End Meeting"
        >
          <PhoneOff className="w-4 h-4" />
          <span className="hidden sm:inline">End</span>
        </button>
      </div>
    </div>
  );
};
