"use client";

import React, { useState, useEffect } from "react";
import { 
  Video, 
  Mic, 
  MicOff, 
  Wifi, 
  Radio, 
  Cpu, 
  ChevronDown, 
  Check, 
  Circle, 
  PhoneOff, 
  ExternalLink,
  Shield,
  Activity,
  Sparkles,
  Sliders
} from "lucide-react";
import { MeetingState, NetworkQuality, ThermalState } from "@/lib/types";

interface MacMenuBarProps {
  meetingState: MeetingState;
  meetingTitle: string;
  isMuted: boolean;
  isCameraOff: boolean;
  isRecording: boolean;
  networkQuality: NetworkQuality;
  thermalState: ThermalState;
  qualityScore: number;
  participantsCount: number;
  onToggleMute: () => void;
  onToggleCamera: () => void;
  onLeaveMeeting: () => void;
  onOpenSettings: () => void;
  onOpenDiagnostics: () => void;
  onOpenCodebase: () => void;
}

export const MacMenuBar: React.FC<MacMenuBarProps> = ({
  meetingState,
  meetingTitle,
  isMuted,
  isCameraOff,
  isRecording,
  networkQuality,
  thermalState,
  qualityScore,
  participantsCount,
  onToggleMute,
  onToggleCamera,
  onLeaveMeeting,
  onOpenSettings,
  onOpenDiagnostics,
  onOpenCodebase
}) => {
  const [timeStr, setTimeStr] = useState<string>("");
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [showStatusDropdown, setShowStatusDropdown] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })
      );
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Close menus on outside click
  useEffect(() => {
    const handleClick = () => {
      setActiveMenu(null);
      setShowStatusDropdown(false);
    };
    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, []);

  const getThermalBadge = () => {
    switch (thermalState) {
      case "critical":
        return { label: "Thermal Critical", color: "bg-red-500/20 text-red-400 border-red-500/30" };
      case "serious":
        return { label: "Thermal Throttled", color: "bg-amber-500/20 text-amber-400 border-amber-500/30" };
      case "fair":
        return { label: "Thermal Warm", color: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30" };
      default:
        return { label: "Thermal Nominal", color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" };
    }
  };

  const thermalInfo = getThermalBadge();

  return (
    <header 
      id="mac-menu-bar"
      className="w-full h-11 bg-[#161617] border-b border-white/10 px-4 flex items-center justify-between text-xs text-[#F5F5F7] select-none z-50 relative"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Left Menu Items */}
      <div className="flex items-center space-x-3.5">
        {/* Apple Logo */}
        <button 
          id="apple-menu-btn"
          className="text-[#F5F5F7]/80 hover:text-white transition-colors focus:outline-none flex items-center"
          onClick={() => setActiveMenu(activeMenu === "apple" ? null : "apple")}
        >
          <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 170 170">
            <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.7-3.04-7.69-7.85-11.97-14.43-6.4-9.84-11.45-21.46-15.15-34.86-3.7-13.4-5.55-25.59-5.55-36.57 0-14.42 3.65-26.4 10.96-35.94 7.31-9.54 16.59-14.42 27.84-14.65 4.89 0 10.37 1.25 16.44 3.76 6.07 2.5 9.94 3.82 11.61 3.96 1.3.13 5.42-1.33 12.35-4.38 6.94-3.05 12.65-4.43 17.13-4.14 12.77.65 22.84 5.38 30.2 14.2-11.16 6.78-16.63 16.03-16.42 27.76.22 9.17 3.75 16.89 10.59 23.16 6.84 6.27 15.01 9.77 24.51 10.5-2.07 6.31-4.78 13.06-8.14 20.25zM119.22 31.84c0-7.39 2.66-14.46 7.98-21.21 5.32-6.75 11.83-10.63 19.53-11.63.22 1.09.33 2.07.33 2.94 0 7.28-2.77 14.35-8.31 21.21-5.54 6.86-12.06 10.68-19.53 11.47z"/>
          </svg>
        </button>

        {/* Application Name */}
        <span className="text-[12px] font-bold tracking-wider uppercase text-[#F5F5F7] opacity-90">
          TELECONFERENCE.OS
        </span>

        <div className="h-3.5 w-px bg-white/10 mx-0.5"></div>

        {/* Standard Menus */}
        <div className="flex items-center space-x-3 text-[12px] text-[#F5F5F7]/70 font-medium">
          <button 
            id="menu-file-btn"
            className="hover:text-white transition-colors"
            onClick={() => setActiveMenu(activeMenu === "meeting" ? null : "meeting")}
          >
            Meeting
          </button>
          <button 
            id="menu-edit-btn"
            className="hover:text-white transition-colors"
            onClick={() => setActiveMenu(activeMenu === "view" ? null : "view")}
          >
            View
          </button>
          <button 
            id="menu-audio-btn"
            className="hover:text-white transition-colors"
            onClick={() => setActiveMenu(activeMenu === "audio" ? null : "audio")}
          >
            Audio & Video
          </button>
          <button 
            id="menu-tools-btn"
            className="hover:text-white transition-colors"
            onClick={onOpenDiagnostics}
          >
            Diagnostics
          </button>
          <button 
            id="menu-swift-btn"
            className="hover:text-white transition-colors flex items-center gap-1.5 text-blue-400 hover:text-blue-300 font-medium"
            onClick={onOpenCodebase}
          >
            <span>Swift Architecture</span>
            <span className="text-[9px] bg-blue-500/20 text-blue-300 uppercase tracking-wider px-1.5 py-0.5 rounded border border-blue-500/30">macOS 14+</span>
          </button>
        </div>
      </div>

      {/* Right System Items */}
      <div className="flex items-center space-x-3 text-neutral-300">
        {/* Recording Indicator */}
        {isRecording && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 bg-red-500/10 rounded-md border border-red-500/20">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
            <span className="text-[10px] font-bold text-red-500 uppercase tracking-widest">Recording</span>
          </div>
        )}

        {/* Thermal Badge */}
        <button
          onClick={onOpenDiagnostics}
          className={`px-2.5 py-1 rounded text-[10px] font-semibold border flex items-center space-x-1.5 ${thermalInfo.color}`}
          title="Thermal Management Engine"
        >
          <Cpu className="w-3 h-3" />
          <span className="uppercase tracking-wider">{thermalInfo.label}</span>
        </button>

        {/* Network Quality Score */}
        <button
          onClick={onOpenDiagnostics}
          className="flex items-center space-x-1.5 px-3 py-1 bg-white/5 rounded text-[11px] font-medium border border-white/10 hover:bg-white/10 transition-colors"
          title="Meeting Quality Index"
        >
          <Activity className="w-3 h-3 text-blue-400" />
          <span>QoS: {qualityScore}/100</span>
        </button>

        {/* Menu Bar Status Extra Dropdown */}
        <div className="relative">
          <button
            id="menubar-extra-btn"
            onClick={() => setShowStatusDropdown(!showStatusDropdown)}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-[#1C1C1E] border border-white/10 hover:bg-white/10 transition-colors focus:outline-none"
          >
            {isMuted ? (
              <MicOff className="w-3 h-3 text-red-400" />
            ) : (
              <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
            )}
            <Video className="w-3 h-3 text-blue-400" />
            <span className="font-semibold text-[11px] text-white uppercase tracking-wider">{meetingState === "CONNECTED" ? "Live" : meetingState}</span>
            <ChevronDown className="w-3 h-3 text-neutral-400" />
          </button>

          {/* Menu Bar Extra Popover (matches native Apple menu bar extra) */}
          {showStatusDropdown && (
            <div 
              id="menubar-extra-popover"
              className="absolute right-0 top-full mt-2 w-64 bg-[#161617] border border-white/10 rounded-xl p-3 shadow-2xl z-50 text-neutral-200"
            >
              <div className="flex items-center space-x-2.5 pb-2.5 border-b border-white/10">
                <div className="w-7 h-7 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                  <Video className="w-3.5 h-3.5" />
                </div>
                <div className="truncate">
                  <p className="font-semibold text-white text-xs truncate">{meetingTitle}</p>
                  <p className="text-[10px] text-neutral-400 uppercase tracking-wider">{participantsCount} Active Participants</p>
                </div>
              </div>

              <div className="py-2 space-y-1 text-xs">
                <button
                  onClick={onToggleMute}
                  className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <span className="flex items-center space-x-2">
                    {isMuted ? <MicOff className="w-3.5 h-3.5 text-red-400" /> : <Mic className="w-3.5 h-3.5 text-emerald-400" />}
                    <span>{isMuted ? "Unmute Microphone" : "Mute Microphone"}</span>
                  </span>
                  <span className="text-[10px] text-neutral-500 font-mono">⌘⇧M</span>
                </button>

                <button
                  onClick={onToggleCamera}
                  className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <span className="flex items-center space-x-2">
                    <Video className="w-3.5 h-3.5 text-blue-400" />
                    <span>{isCameraOff ? "Start Camera" : "Stop Camera"}</span>
                  </span>
                  <span className="text-[10px] text-neutral-500 font-mono">⌘⇧V</span>
                </button>

                <button
                  onClick={onOpenSettings}
                  className="w-full flex items-center justify-between px-2.5 py-2 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <span className="flex items-center space-x-2">
                    <Sliders className="w-3.5 h-3.5 text-purple-400" />
                    <span>Audio & Video Settings...</span>
                  </span>
                  <span className="text-[10px] text-neutral-500 font-mono">⌘,</span>
                </button>
              </div>

              <div className="pt-2 border-t border-white/10">
                <button
                  onClick={onLeaveMeeting}
                  className="w-full flex items-center justify-center space-x-2 px-2.5 py-2 rounded-lg bg-[#FF3B30]/20 hover:bg-[#FF3B30] text-[#FF3B30] hover:text-white font-bold transition-colors text-xs"
                >
                  <PhoneOff className="w-3.5 h-3.5" />
                  <span>Leave Meeting</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Clock */}
        <span className="text-white/60 font-mono pl-1 text-[12px]">{timeStr || "10:42:05"}</span>
      </div>
    </header>
  );
};
