"use client";

import React, { useState, useRef, useEffect } from "react";
import { 
  Tv, 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  Volume2, 
  Layers, 
  MousePointer, 
  PenTool, 
  Sparkles,
  StopCircle,
  Code,
  Globe,
  FileText
} from "lucide-react";
import { Participant } from "@/lib/types";

interface PresentationCanvasProps {
  presenter: Participant;
  screenStream: MediaStream | null;
  isSharingSystemAudio: boolean;
  onStopSharing: () => void;
  sharedContentType?: "display" | "keynote" | "xcode" | "safari" | "pdf";
}

const SLIDES = [
  {
    title: "TELECONFERENCE.OS Architecture",
    subtitle: "Native Apple Frameworks: AVFoundation + ScreenCaptureKit + Core Audio",
    points: [
      "AVCaptureSession with zero-copy Metal sample buffer rendering (60 FPS)",
      "ScreenCaptureKit fine-grained display, app & window picker with system audio",
      "Network.framework & WebRTC transport with adaptive bitrate (ABR)",
      "On-device Gemini 3.8 Flash intelligence with strict privacy boundaries"
    ],
    codeSnippet: `// Swift Native ScreenCaptureKit Integration
let config = SCStreamConfiguration()
config.width = 3840 // 4K UHD
config.height = 2160
config.minimumFrameInterval = CMTime(value: 1, timescale: 60)
config.capturesAudio = true`
  },
  {
    title: "MLS Cryptographic Security & Privacy",
    subtitle: "Zero-Trust End-to-End Encryption with Secure Enclave",
    points: [
      "Separate signaling, media transport, encryption, and identity layers",
      "Per-participant rotating ratchet keys derived inside Apple Secure Enclave",
      "AI Privacy Modes: AI OFF, LOCAL CoreML, or REMOTE Gemini Assistant",
      "NSScreenCaptureUsageDescription strict macOS permission lifecycle"
    ],
    codeSnippet: `// MLS Ratchet State Transition
guard let enclaveKey = SecureEnclave.generatePrivateKey() else {
    throw SecurityError.hardwareUnavailable
}`
  },
  {
    title: "Thermal Management & ABR Engine",
    subtitle: "Dynamic Frame Rate & Resolution Scaling under CPU/GPU Constraints",
    points: [
      "ProcessInfo.thermalState monitoring: Nominal → Fair → Serious → Critical",
      "Audio preservation priority: Video drops to 720p/360p before audio degrades",
      "Sub-20ms audio latency via Core Audio Realtime HAL tap",
      "Automatic recovery to 1080p 60FPS when thermal nominal restored"
    ],
    codeSnippet: `// Adaptive Bitrate Logic
if thermalState == .critical || packetLoss > 0.08 {
    adaptStream(resolution: .hd1280x720, fps: 24)
}`
  }
];

export const PresentationCanvas: React.FC<PresentationCanvasProps> = ({
  presenter,
  screenStream,
  isSharingSystemAudio,
  onStopSharing,
  sharedContentType = "keynote"
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [activeTool, setActiveTool] = useState<"pointer" | "pen">("pointer");
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && screenStream) {
      videoRef.current.srcObject = screenStream;
    }
  }, [screenStream]);

  const slide = SLIDES[currentSlide];

  return (
    <div 
      id="presentation-canvas-container"
      className="relative w-full h-full bg-[#0A0A0A] rounded-2xl overflow-hidden border border-white/5 flex flex-col justify-between select-none shadow-2xl"
    >
      {/* Top Presentation Bar */}
      <div className="h-11 bg-[#161617] border-b border-white/10 px-4 flex items-center justify-between z-20">
        <div className="flex items-center space-x-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-semibold text-[#F5F5F7] tracking-wide">
            {presenter.displayName}&apos;s Screen
          </span>
          <span className="px-2.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-mono uppercase tracking-wider">
            {screenStream ? "Live ScreenCaptureKit (4K 60FPS)" : "Keynote Presentation (Native)"}
          </span>
        </div>

        {/* Audio sharing & controls */}
        <div className="flex items-center space-x-3 text-xs">
          {isSharingSystemAudio && (
            <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold uppercase tracking-wider">
              <Volume2 className="w-3.5 h-3.5" />
              <span>SYSTEM AUDIO ON</span>
            </div>
          )}

          <div className="px-3 py-1 bg-blue-500 text-white rounded text-xs font-bold uppercase tracking-tighter shadow-sm">
            Ultra HD 4K
          </div>

          <button
            onClick={onStopSharing}
            className="flex items-center space-x-1.5 px-3 py-1 rounded bg-[#FF3B30]/20 hover:bg-[#FF3B30] text-[#FF3B30] hover:text-white font-bold transition-colors border border-[#FF3B30]/30 text-xs"
          >
            <StopCircle className="w-3.5 h-3.5" />
            <span>Stop Sharing</span>
          </button>
        </div>
      </div>

      {/* Main Slide / Screen Share Stream Area */}
      <div className="relative flex-1 w-full h-full flex items-center justify-center p-6 overflow-hidden bg-black">
        {screenStream ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-full object-contain rounded-xl shadow-2xl bg-black"
          />
        ) : (
          /* High-Fidelity Apple Keynote Presentation View */
          <div className="w-full max-w-4xl bg-[#1C1C1E] rounded-2xl border border-white/5 p-8 shadow-2xl flex flex-col justify-between aspect-video relative overflow-hidden group">
            {/* Presentation Decorative Background Elements */}
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/60 pointer-events-none" />
            <div className="absolute -top-24 -right-24 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

            {/* Slide Header */}
            <div className="relative z-10">
              <div className="flex items-center space-x-2 text-blue-400 text-xs font-mono tracking-widest uppercase mb-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Enterprise macOS Teleconferencing • Slide {currentSlide + 1} of {SLIDES.length}</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#F5F5F7] tracking-tight">
                {slide.title}
              </h2>
              <p className="text-sm text-neutral-400 mt-1">
                {slide.subtitle}
              </p>
            </div>

            {/* Slide Content */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-4 relative z-10">
              <div className="space-y-3">
                {slide.points.map((pt, idx) => (
                  <div key={idx} className="flex items-start space-x-2 text-xs sm:text-sm text-[#F5F5F7]/90">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5 flex-shrink-0" />
                    <span>{pt}</span>
                  </div>
                ))}
              </div>

              {/* Code Box */}
              <div className="bg-[#0A0A0A] rounded-xl border border-white/10 p-3.5 font-mono text-[11px] text-neutral-300 overflow-x-auto shadow-inner">
                <div className="flex items-center space-x-1.5 pb-2 mb-2 border-b border-white/10 text-neutral-400 text-[10px] uppercase tracking-wider">
                  <Code className="w-3.5 h-3.5 text-blue-400" />
                  <span>ScreenCaptureKitStream.swift</span>
                </div>
                <pre className="text-blue-300 leading-relaxed font-mono">
                  <code>{slide.codeSnippet}</code>
                </pre>
              </div>
            </div>

            {/* Slide Footer */}
            <div className="relative z-10 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-neutral-400">
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-widest opacity-50 font-bold">Presenting</span>
                <span className="text-sm font-medium text-white">{presenter.displayName}</span>
              </div>
              <span className="text-[11px] font-mono text-white/40">TELECONFERENCE.OS • Apple Platform 2026</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Presentation Controls Bar */}
      {!screenStream && (
        <div className="h-11 bg-[#161617] border-t border-white/10 px-4 flex items-center justify-between z-20 text-xs">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveTool("pointer")}
              className={`p-1.5 rounded-md transition-colors ${activeTool === "pointer" ? "bg-blue-600/20 text-blue-300 border border-blue-500/30" : "text-neutral-400 hover:text-white"}`}
              title="Laser Pointer"
            >
              <MousePointer className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setActiveTool("pen")}
              className={`p-1.5 rounded-md transition-colors ${activeTool === "pen" ? "bg-blue-600/20 text-blue-300 border border-blue-500/30" : "text-neutral-400 hover:text-white"}`}
              title="Annotation Pen"
            >
              <PenTool className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Slide navigation */}
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setCurrentSlide(prev => Math.max(0, prev - 1))}
              disabled={currentSlide === 0}
              className="p-1.5 rounded hover:bg-white/10 disabled:opacity-30 text-neutral-300 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono text-neutral-300">
              {currentSlide + 1} / {SLIDES.length}
            </span>
            <button
              onClick={() => setCurrentSlide(prev => Math.min(SLIDES.length - 1, prev + 1))}
              disabled={currentSlide === SLIDES.length - 1}
              className="p-1.5 rounded hover:bg-white/10 disabled:opacity-30 text-neutral-300 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
