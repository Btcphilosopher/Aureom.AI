"use client";

import React, { useRef, useEffect } from "react";
import { 
  Mic, 
  MicOff, 
  Hand, 
  Crown, 
  Tv, 
  Wifi, 
  Radio, 
  Volume2, 
  VolumeX,
  Sparkles,
  Shield
} from "lucide-react";
import { Participant } from "@/lib/types";

interface ParticipantVideoCardProps {
  participant: Participant;
  isLocal?: boolean;
  localVideoStream?: MediaStream | null;
  isPrimary?: boolean;
  isFilmstrip?: boolean;
  onSelect?: () => void;
  onMuteToggle?: () => void;
  onPromoteRole?: (role: Participant["role"]) => void;
}

export const ParticipantVideoCard: React.FC<ParticipantVideoCardProps> = ({
  participant,
  isLocal = false,
  localVideoStream,
  isPrimary = false,
  isFilmstrip = false,
  onSelect,
  onMuteToggle
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  // Attach local media stream if available
  useEffect(() => {
    if (isLocal && videoRef.current && localVideoStream) {
      videoRef.current.srcObject = localVideoStream;
    }
  }, [isLocal, localVideoStream, participant.cameraEnabled]);

  const getRoleBadge = () => {
    switch (participant.role) {
      case "HOST":
        return { label: "Host", bg: "bg-blue-500/20 text-blue-400 border-blue-500/30" };
      case "CO_HOST":
        return { label: "Co-Host", bg: "bg-purple-500/20 text-purple-400 border-purple-500/30" };
      case "PRESENTER":
        return { label: "Presenter", bg: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" };
      default:
        return null;
    }
  };

  const roleInfo = getRoleBadge();

  return (
    <div
      id={`participant-card-${participant.id}`}
      onClick={onSelect}
      className={`relative rounded-xl overflow-hidden bg-[#1C1C1E] border transition-all duration-300 flex items-center justify-center select-none group ${
        participant.speaking
          ? "macos-active-speaker-ring border-blue-500"
          : "border-white/5 hover:border-white/10"
      } ${isFilmstrip ? "w-44 h-28 flex-shrink-0 cursor-pointer" : "w-full h-full"}`}
    >
      {/* Video Content or Avatar Fallback */}
      {participant.cameraEnabled ? (
        isLocal && localVideoStream ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover -scale-x-100"
          />
        ) : (
          <div className="relative w-full h-full bg-[#1C1C1E] flex items-center justify-center overflow-hidden">
            {/* Realistic Pro Camera Stream Render */}
            <img 
              src={participant.avatar} 
              alt={participant.displayName}
              className="absolute inset-0 w-full h-full object-cover filter brightness-95 contrast-105"
            />
            {/* Subtle video noise / ambient glow */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
          </div>
        )
      ) : (
        /* Camera Off - Elegant Avatar State with Audio Ripples */
        <div className="w-full h-full bg-[#1C1C1E] flex flex-col items-center justify-center p-4 relative">
          <div className="w-full h-full absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500 to-transparent pointer-events-none" />
          <div className="relative">
            {participant.speaking && (
              <div className="absolute -inset-2.5 rounded-full bg-blue-500/20 animate-ping" />
            )}
            <div 
              className={`w-14 h-14 md:w-16 md:h-16 rounded-full flex items-center justify-center text-lg font-bold text-white shadow-xl relative z-10 border border-white/10`}
              style={{ backgroundColor: participant.color || "#007AFF" }}
            >
              {participant.displayName.charAt(0)}
            </div>
          </div>
          {!isFilmstrip && (
            <p className="mt-2 text-xs font-semibold text-[#F5F5F7]">
              {participant.displayName}
            </p>
          )}
        </div>
      )}

      {/* Hand Raised Banner */}
      {participant.handRaised && (
        <div className="absolute top-2.5 right-2.5 z-20 flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-[#FEBC2E] text-black font-bold text-[10px] uppercase tracking-wider shadow-lg animate-bounce">
          <Hand className="w-3 h-3 fill-black" />
          <span>Hand Raised</span>
        </div>
      )}

      {/* Top Left: Role & Network Quality */}
      <div className="absolute top-2.5 left-2.5 z-20 flex items-center space-x-1.5">
        {roleInfo && (
          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${roleInfo.bg}`}>
            {roleInfo.label}
          </span>
        )}
        {participant.networkQuality !== "Excellent" && (
          <span 
            className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-[#FEBC2E]/20 text-[#FEBC2E] border border-[#FEBC2E]/30"
            title={`Network Quality: ${participant.networkQuality}`}
          >
            {participant.networkQuality}
          </span>
        )}
      </div>

      {/* Speaking Soundwave Indicator (Bottom Center when speaking) */}
      {participant.speaking && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex items-center space-x-1 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-full border border-blue-500/40">
          <div className="w-1 h-2 bg-blue-500 rounded-full animate-pulse" />
          <div className="w-1 h-3.5 bg-blue-500 rounded-full animate-pulse" />
          <div className="w-1 h-1.5 bg-blue-500 rounded-full animate-pulse" />
          <span className="text-[10px] text-blue-400 font-bold uppercase tracking-widest pl-1">Active</span>
        </div>
      )}

      {/* Bottom Info Bar */}
      <div className="absolute bottom-2.5 left-2.5 right-2.5 z-20 flex items-center justify-between pointer-events-none">
        {/* Name Pill */}
        <div className="flex items-center space-x-1.5 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10 text-xs font-semibold text-[#F5F5F7] max-w-[80%] truncate">
          <span className="truncate">{participant.displayName}</span>
          {isLocal && <span className="text-[10px] text-blue-400 font-normal uppercase tracking-wider">(You)</span>}
        </div>

        {/* Mic & Audio Status Pill */}
        <div className="flex items-center space-x-1 bg-black/60 backdrop-blur-md p-1.5 rounded-lg border border-white/10">
          {participant.microphoneEnabled ? (
            <Mic className={`w-3.5 h-3.5 ${participant.speaking ? "text-blue-400" : "text-neutral-300"}`} />
          ) : (
            <div className="text-[#FF3B30]">
              <MicOff className="w-3.5 h-3.5" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
