"use client";

import React, { useState } from "react";
import { 
  Maximize2, 
  Mic, 
  MicOff, 
  Video, 
  PhoneOff, 
  X,
  Radio
} from "lucide-react";
import { Participant } from "@/lib/types";

interface PictureInPictureOverlayProps {
  isOpen: boolean;
  activeSpeaker: Participant;
  isMuted: boolean;
  onToggleMute: () => void;
  onRestore: () => void;
  onLeave: () => void;
}

export const PictureInPictureOverlay: React.FC<PictureInPictureOverlayProps> = ({
  isOpen,
  activeSpeaker,
  isMuted,
  onToggleMute,
  onRestore,
  onLeave
}) => {
  if (!isOpen) return null;

  return (
    <div 
      id="picture-in-picture-overlay"
      className="fixed bottom-6 right-6 w-80 h-48 bg-[#121624]/95 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-2xl overflow-hidden z-50 flex flex-col justify-between animate-in fade-in zoom-in-95 select-none"
    >
      {/* Top Header */}
      <div className="h-8 bg-black/50 px-3 flex items-center justify-between z-10 text-xs">
        <div className="flex items-center space-x-1.5 truncate">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-white truncate text-[11px]">{activeSpeaker.displayName}</span>
        </div>
        <div className="flex items-center space-x-1">
          <button 
            onClick={onRestore}
            className="p-1 rounded hover:bg-white/10 text-neutral-300 hover:text-white"
            title="Restore Window"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Video Content */}
      <div className="relative flex-1 w-full h-full bg-[#161a29] flex items-center justify-center overflow-hidden">
        {activeSpeaker.cameraEnabled ? (
          <img 
            src={activeSpeaker.avatar} 
            alt={activeSpeaker.displayName} 
            className="w-full h-full object-cover filter brightness-90"
          />
        ) : (
          <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-base shadow-lg">
            {activeSpeaker.displayName.charAt(0)}
          </div>
        )}
      </div>

      {/* Bottom Floating Pill */}
      <div className="h-10 bg-black/60 backdrop-blur-md px-3 flex items-center justify-between z-10">
        <button
          onClick={onToggleMute}
          className={`p-1.5 rounded-lg text-xs font-semibold ${isMuted ? "bg-red-500/20 text-red-400" : "bg-white/10 text-white"}`}
        >
          {isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-emerald-400" />}
        </button>

        <button
          onClick={onRestore}
          className="px-2.5 py-1 rounded-lg bg-blue-600 text-white text-[11px] font-semibold hover:bg-blue-500 transition-colors"
        >
          Expand Meeting
        </button>

        <button
          onClick={onLeave}
          className="p-1.5 rounded-lg bg-red-600/30 text-red-400 hover:bg-red-600 hover:text-white transition-colors"
        >
          <PhoneOff className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
