import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'TELECONFERENCE.OS — Native macOS Enterprise Teleconferencing',
  description: 'Native Apple macOS Enterprise Teleconferencing Platform featuring AVFoundation, ScreenCaptureKit, Core Audio, AI Intelligence, and Collaborative Workspaces.',
  openGraph: {
    title: 'TELECONFERENCE.OS — Native macOS Enterprise Teleconferencing',
    description: 'Native Apple macOS Enterprise Teleconferencing Platform featuring AVFoundation, ScreenCaptureKit, Core Audio, AI Intelligence, and Collaborative Workspaces.',
    type: 'website',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
      </head>
      <body suppressHydrationWarning className="bg-[#0b0d13] text-[#e4e7ee] antialiased selection:bg-blue-500/30 selection:text-blue-200 overflow-hidden font-['Plus_Jakarta_Sans',-apple-system,BlinkMacSystemFont,'SF_Pro_Text','Helvetica_Neue',sans-serif]">
        {children}
      </body>
    </html>
  );
}

