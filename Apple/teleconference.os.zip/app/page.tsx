"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import { 
  MeetingState, 
  LayoutMode, 
  Participant, 
  ChatMessage, 
  TranscriptItem, 
  DocumentAttachment, 
  SharedFile, 
  ScheduledMeeting, 
  WaitingRoomUser, 
  QualityScore, 
  ThermalState, 
  NetworkQuality, 
  DeviceConfig, 
  CaptionsConfig, 
  AIPrivacyMode,
  Role
} from "@/lib/types";
import { 
  INITIAL_PARTICIPANTS, 
  INITIAL_CHAT_MESSAGES, 
  INITIAL_TRANSCRIPT, 
  INITIAL_ATTACHED_DOCS, 
  INITIAL_FILES, 
  INITIAL_SCHEDULED_MEETINGS, 
  INITIAL_WAITING_ROOM 
} from "@/lib/mockData";

import { MacMenuBar } from "@/components/MacMenuBar";
import { MainWindowHeader } from "@/components/MainWindowHeader";
import { ConferenceStage } from "@/components/ConferenceStage";
import { FloatingControlsBar } from "@/components/FloatingControlsBar";
import { ChatPanel } from "@/components/SidePanels/ChatPanel";
import { ParticipantsPanel } from "@/components/SidePanels/ParticipantsPanel";
import { AIAssistantPanel } from "@/components/SidePanels/AIAssistantPanel";
import { WhiteboardPanel } from "@/components/SidePanels/WhiteboardPanel";
import { FilesPanel } from "@/components/SidePanels/FilesPanel";
import { AdminDiagnosticsPanel } from "@/components/SidePanels/AdminDiagnosticsPanel";
import { SwiftCodebasePanel } from "@/components/SidePanels/SwiftCodebasePanel";

import { ScreenPickerModal } from "@/components/Modals/ScreenPickerModal";
import { SettingsModal } from "@/components/Modals/SettingsModal";
import { ScheduleMeetingModal } from "@/components/Modals/ScheduleMeetingModal";
import { PictureInPictureOverlay } from "@/components/PictureInPictureOverlay";

export default function TeleconferenceOSApp() {
  // 1. Meeting Connection State
  const [meetingState, setMeetingState] = useState<MeetingState>("CONNECTED");
  const [meetingTitle, setMeetingTitle] = useState("Apple Architecture & Metal Zero-Copy Review");
  const [meetingId] = useState("749-820-914");
  const [isMeetingLocked, setIsMeetingLocked] = useState(false);

  // 2. Layout Mode
  const [currentLayout, setCurrentLayout] = useState<LayoutMode>("SPEAKER");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPiPOpen, setIsPiPOpen] = useState(false);

  // 3. Participants & Active Speaker
  const [participants, setParticipants] = useState<Participant[]>(INITIAL_PARTICIPANTS);
  const [waitingRoom, setWaitingRoom] = useState<WaitingRoomUser[]>(INITIAL_WAITING_ROOM);
  const [activeSpeakerId, setActiveSpeakerId] = useState<string>("user-2"); // Alice Smith initial speaker

  // 4. Local User Media States
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isSharingSystemAudio, setIsSharingSystemAudio] = useState(true);
  const [isRecording, setIsRecording] = useState(true);
  const [handRaised, setHandRaised] = useState(false);
  const [micAudioLevel, setMicAudioLevel] = useState(0);

  // 5. Media Streams (Local Camera + Screen Share)
  const [localVideoStream, setLocalVideoStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);

  // 6. Active Side Panel
  const [activePanel, setActivePanel] = useState<string | null>(null);

  // 7. Modals
  const [isScreenPickerOpen, setIsScreenPickerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isScheduleOpen, setIsScheduleOpen] = useState(false);

  // 8. Communication & Data
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [transcript, setTranscript] = useState<TranscriptItem[]>(INITIAL_TRANSCRIPT);
  const [attachedDocs] = useState<DocumentAttachment[]>(INITIAL_ATTACHED_DOCS);
  const [sharedFiles, setSharedFiles] = useState<SharedFile[]>(INITIAL_FILES);
  const [scheduledMeetings, setScheduledMeetings] = useState<ScheduledMeeting[]>(INITIAL_SCHEDULED_MEETINGS);

  // 9. Captions & Accessibility
  const [captionsConfig, setCaptionsConfig] = useState<CaptionsConfig>({
    enabled: true,
    fontSize: "medium",
    position: "bottom",
    background: "glass"
  });

  // 10. AI & Privacy
  const [aiPrivacyMode, setAiPrivacyMode] = useState<AIPrivacyMode>("REMOTE_AI");

  // 11. Hardware, Network & Diagnostics
  const [deviceConfig, setDeviceConfig] = useState<DeviceConfig>({
    cameraDeviceId: "FaceTime HD Camera (Built-in)",
    micDeviceId: "MacBook Pro Microphone (Built-in)",
    speakerDeviceId: "MacBook Pro Speakers",
    resolution: "1080p",
    frameRate: 60,
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true
  });

  const [thermalState, setThermalState] = useState<ThermalState>("nominal");
  const [networkQuality, setNetworkQuality] = useState<NetworkQuality>("Excellent");
  const [qualityScore, setQualityScore] = useState<QualityScore>({
    score: 96,
    latencyMs: 18,
    jitterMs: 1.2,
    packetLoss: 0.001,
    bitrateKbps: 4200,
    fps: 60,
    reconnections: 0
  });

  // 12. Floating Reactions
  const [reactions, setReactions] = useState<{ id: string; emoji: string; x: number; y: number }[]>([]);

  // Find local user & active speaker
  const currentUser = participants.find(p => p.isLocal) || participants[0];
  const activeSpeaker = participants.find(p => p.id === activeSpeakerId) || currentUser;
  const presenter = participants.find(p => p.role === "PRESENTER") || null;
  const unreadChatCount = 0;

  // Initialize Real Camera/Microphone on user opt-in
  useEffect(() => {
    let audioContext: AudioContext | null = null;
    let analyser: AnalyserNode | null = null;
    let animFrame: number | null = null;

    async function initLocalMedia() {
      if (isCameraOff && isMuted) {
        setLocalVideoStream(null);
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: !isCameraOff ? { width: 1280, height: 720 } : false,
          audio: !isMuted
        });
        setLocalVideoStream(stream);

        // Setup real audio level analyzer for mic VU meter
        if (!isMuted && stream.getAudioTracks().length > 0) {
          const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (AudioContextClass) {
            audioContext = new AudioContextClass();
            const source = audioContext.createMediaStreamSource(stream);
            analyser = audioContext.createAnalyser();
            analyser.fftSize = 256;
            source.connect(analyser);

            const dataArray = new Uint8Array(analyser.frequencyBinCount);
            const updateAudioLevel = () => {
              if (analyser) {
                analyser.getByteFrequencyData(dataArray);
                let sum = 0;
                for (let i = 0; i < dataArray.length; i++) {
                  sum += dataArray[i];
                }
                const avg = sum / dataArray.length / 255;
                setMicAudioLevel(avg);
              }
              animFrame = requestAnimationFrame(updateAudioLevel);
            };
            updateAudioLevel();
          }
        }
      } catch (err) {
        console.warn("Using simulated high-fidelity native media pipeline:", err);
      }
    }

    initLocalMedia();

    return () => {
      if (animFrame) cancelAnimationFrame(animFrame);
      if (audioContext && audioContext.state !== "closed") audioContext.close();
    };
  }, [isCameraOff, isMuted]);

  // Simulate active speaker rotation and realistic audio activity
  useEffect(() => {
    const speakerInterval = setInterval(() => {
      const candidates = participants.filter(p => p.microphoneEnabled);
      if (candidates.length > 0) {
        const randomSpeaker = candidates[Math.floor(Math.random() * candidates.length)];
        setActiveSpeakerId(randomSpeaker.id);

        // Update participant speaking flags
        setParticipants(prev => prev.map(p => ({
          ...p,
          speaking: p.id === randomSpeaker.id
        })));
      }
    }, 8000);

    return () => clearInterval(speakerInterval);
  }, [participants]);

  // Global macOS Keyboard Shortcuts Handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey && e.shiftKey) {
        if (e.key === "M" || e.key === "m") {
          e.preventDefault();
          setIsMuted(prev => !prev);
        } else if (e.key === "V" || e.key === "v") {
          e.preventDefault();
          setIsCameraOff(prev => !prev);
        } else if (e.key === "S" || e.key === "s") {
          e.preventDefault();
          setIsScreenPickerOpen(prev => !prev);
        } else if (e.key === "C" || e.key === "c") {
          e.preventDefault();
          setActivePanel(prev => prev === "chat" ? null : "chat");
        } else if (e.key === "R" || e.key === "r") {
          e.preventDefault();
          setHandRaised(prev => !prev);
        }
      } else if (e.metaKey && e.key === ",") {
        e.preventDefault();
        setIsSettingsOpen(true);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Handlers
  const handleToggleMute = useCallback(() => {
    setIsMuted(prev => {
      const next = !prev;
      setParticipants(list => list.map(p => p.isLocal ? { ...p, microphoneEnabled: !next } : p));
      return next;
    });
  }, []);

  const handleToggleCamera = useCallback(() => {
    setIsCameraOff(prev => {
      const next = !prev;
      setParticipants(list => list.map(p => p.isLocal ? { ...p, cameraEnabled: !next } : p));
      return next;
    });
  }, []);

  const handleToggleScreenShare = () => {
    if (isScreenSharing) {
      if (screenStream) {
        screenStream.getTracks().forEach(t => t.stop());
        setScreenStream(null);
      }
      setIsScreenSharing(false);
    } else {
      setIsScreenPickerOpen(true);
    }
  };

  const handleStartShareFromPicker = async (type: string, shareAudio: boolean) => {
    setIsSharingSystemAudio(shareAudio);
    setIsScreenSharing(true);

    // Attempt real screen share if display is selected and browser permits
    if (type === "display" && navigator.mediaDevices?.getDisplayMedia) {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: shareAudio
        });
        setScreenStream(stream);
        stream.getVideoTracks()[0].onended = () => {
          setIsScreenSharing(false);
          setScreenStream(null);
        };
      } catch (err) {
        console.warn("ScreenCaptureKit presentation view active:", err);
      }
    }
  };

  const handleSendReaction = (emoji: string) => {
    const id = `react-${Date.now()}-${Math.random()}`;
    const newReact = {
      id,
      emoji,
      x: 30 + Math.random() * 40,
      y: 60 + Math.random() * 20
    };
    setReactions(prev => [...prev, newReact]);
    setTimeout(() => {
      setReactions(prev => prev.filter(r => r.id !== id));
    }, 2000);
  };

  const handleSendMessage = (text: string, isPrivate = false, recipientId?: string) => {
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.displayName,
      senderAvatar: currentUser.avatar,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isPrivate,
      recipientId,
      reactions: {}
    };
    setMessages(prev => [...prev, newMsg]);
  };

  const handleAddReactionToMessage = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(m => {
      if (m.id === messageId) {
        const existing = m.reactions || {};
        const users = existing[emoji] || [];
        const updated = users.includes(currentUser.displayName) 
          ? users.filter(u => u !== currentUser.displayName)
          : [...users, currentUser.displayName];
        
        const newReactions = { ...existing };
        if (updated.length > 0) {
          newReactions[emoji] = updated;
        } else {
          delete newReactions[emoji];
        }
        return { ...m, reactions: newReactions };
      }
      return m;
    }));
  };

  // Waiting Room Operations
  const handleAdmitUser = (id: string) => {
    const user = waitingRoom.find(w => w.id === id);
    if (!user) return;
    setWaitingRoom(prev => prev.filter(w => w.id !== id));
    const newParticipant: Participant = {
      id: `user-${Date.now()}`,
      displayName: user.name,
      role: "ATTENDEE",
      avatar: user.avatar,
      speaking: false,
      handRaised: false,
      cameraEnabled: true,
      microphoneEnabled: true,
      networkQuality: "Excellent",
      isLocal: false,
      color: "#3b82f6"
    };
    setParticipants(prev => [...prev, newParticipant]);
  };

  const handleDenyUser = (id: string) => {
    setWaitingRoom(prev => prev.filter(w => w.id !== id));
  };

  const handleAdmitAll = () => {
    waitingRoom.forEach(w => handleAdmitUser(w.id));
  };

  // Participant Controls
  const handleMuteParticipant = (id: string) => {
    setParticipants(prev => prev.map(p => p.id === id ? { ...p, microphoneEnabled: false, speaking: false } : p));
  };

  const handleRemoveParticipant = (id: string) => {
    setParticipants(prev => prev.filter(p => p.id !== id));
  };

  const handlePromoteRole = (id: string, role: Role) => {
    setParticipants(prev => prev.map(p => p.id === id ? { ...p, role } : p));
  };

  const handleMuteAll = () => {
    setParticipants(prev => prev.map(p => p.isLocal ? p : { ...p, microphoneEnabled: false, speaking: false }));
  };

  // Stress test participant simulator
  const handleSimulateParticipants = (count: number) => {
    const generated: Participant[] = [];
    const roles: Role[] = ["ATTENDEE", "PRESENTER", "CO_HOST"];
    for (let i = 1; i <= count; i++) {
      generated.push({
        id: `sim-user-${i}`,
        displayName: `Enterprise Peer ${i}`,
        role: roles[i % roles.length],
        avatar: `https://picsum.photos/seed/peer${i}/200/200`,
        speaking: i === 1,
        handRaised: i % 5 === 0,
        cameraEnabled: i % 2 === 0,
        microphoneEnabled: i % 3 !== 0,
        networkQuality: "Excellent",
        isLocal: false,
        color: ["#3b82f6", "#10b981", "#8b5cf6", "#f59e0b", "#ec4899"][i % 5]
      });
    }
    setParticipants([currentUser, ...generated]);
  };

  // Files
  const handleUploadFile = (file: File) => {
    const newFile: SharedFile = {
      id: `file-${Date.now()}`,
      name: file.name,
      size: `${(file.size / 1024).toFixed(1)} KB`,
      type: file.name.endsWith(".swift") ? "code" : file.type.startsWith("image/") ? "image" : "pdf",
      uploadedBy: currentUser.displayName,
      uploadedAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      url: URL.createObjectURL(file)
    };
    setSharedFiles(prev => [newFile, ...prev]);
  };

  const handleDeleteFile = (id: string) => {
    setSharedFiles(prev => prev.filter(f => f.id !== id));
  };

  return (
    <div 
      id="teleconference-os-root"
      className="w-screen h-screen bg-[#07090e] text-white flex flex-col justify-between select-none overflow-hidden font-sans"
    >
      {/* 1. TOP SYSTEM MENU BAR (Apple Menu Bar + Extra) */}
      <MacMenuBar
        meetingState={meetingState}
        meetingTitle={meetingTitle}
        isMuted={isMuted}
        isCameraOff={isCameraOff}
        isRecording={isRecording}
        networkQuality={networkQuality}
        thermalState={thermalState}
        qualityScore={qualityScore.score}
        participantsCount={participants.length}
        onToggleMute={handleToggleMute}
        onToggleCamera={handleToggleCamera}
        onLeaveMeeting={() => setMeetingState(meetingState === "CONNECTED" ? "DISCONNECTED" : "CONNECTED")}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenDiagnostics={() => setActivePanel("diagnostics")}
        onOpenCodebase={() => setActivePanel("swiftCode")}
      />

      {/* 2. MAIN TELECONFERENCE APPLICATION WINDOW */}
      <div className="flex-1 w-full flex flex-col overflow-hidden relative">
        
        {/* Window Title Bar with Traffic Lights and Layout Switcher */}
        <MainWindowHeader
          meetingTitle={meetingTitle}
          meetingId={meetingId}
          currentLayout={currentLayout}
          onLayoutChange={setCurrentLayout}
          onTogglePiP={() => setIsPiPOpen(!isPiPOpen)}
          onToggleFullscreen={() => setIsFullscreen(!isFullscreen)}
          isFullscreen={isFullscreen}
          onOpenMultiMonitor={() => setActivePanel("diagnostics")}
        />

        {/* Middle Stage + Collapsible Side Panel Area */}
        <div className="flex-1 w-full flex overflow-hidden relative min-h-0">
          
          {/* Main Stage Viewport */}
          <ConferenceStage
            layout={currentLayout}
            participants={participants}
            activeSpeaker={activeSpeaker}
            presenter={presenter}
            localVideoStream={localVideoStream}
            screenStream={screenStream}
            isSharingScreen={isScreenSharing}
            isSharingSystemAudio={isSharingSystemAudio}
            onStopScreenSharing={() => setIsScreenSharing(false)}
            captionsConfig={captionsConfig}
            latestTranscript={transcript[transcript.length - 1] || null}
            reactions={reactions}
            onSelectParticipant={(p) => setActiveSpeakerId(p.id)}
          />

          {/* Active Side Drawer Panel */}
          {activePanel && (
            <div className="w-80 md:w-96 h-full flex-shrink-0 relative z-30 transition-all">
              {activePanel === "chat" && (
                <ChatPanel
                  messages={messages}
                  participants={participants}
                  currentUser={currentUser}
                  onSendMessage={handleSendMessage}
                  onAddReaction={handleAddReactionToMessage}
                  onClose={() => setActivePanel(null)}
                />
              )}

              {activePanel === "participants" && (
                <ParticipantsPanel
                  participants={participants}
                  waitingRoom={waitingRoom}
                  currentUser={currentUser}
                  isMeetingLocked={isMeetingLocked}
                  onAdmitUser={handleAdmitUser}
                  onDenyUser={handleDenyUser}
                  onAdmitAll={handleAdmitAll}
                  onMuteParticipant={handleMuteParticipant}
                  onRemoveParticipant={handleRemoveParticipant}
                  onPromoteRole={handlePromoteRole}
                  onMuteAll={handleMuteAll}
                  onToggleLockMeeting={() => setIsMeetingLocked(!isMeetingLocked)}
                  onClose={() => setActivePanel(null)}
                />
              )}

              {activePanel === "aiAssistant" && (
                <AIAssistantPanel
                  transcript={transcript}
                  attachedDocs={attachedDocs}
                  meetingTitle={meetingTitle}
                  privacyMode={aiPrivacyMode}
                  onUpdatePrivacyMode={setAiPrivacyMode}
                  onClose={() => setActivePanel(null)}
                />
              )}

              {activePanel === "whiteboard" && (
                <WhiteboardPanel
                  onClose={() => setActivePanel(null)}
                />
              )}

              {activePanel === "files" && (
                <FilesPanel
                  files={sharedFiles}
                  onUploadFile={handleUploadFile}
                  onDeleteFile={handleDeleteFile}
                  onClose={() => setActivePanel(null)}
                />
              )}

              {activePanel === "diagnostics" && (
                <AdminDiagnosticsPanel
                  qualityScore={qualityScore}
                  thermalState={thermalState}
                  networkQuality={networkQuality}
                  onUpdateThermal={setThermalState}
                  onUpdateNetwork={(q, lat, loss) => {
                    setNetworkQuality(q);
                    setQualityScore(prev => ({
                      ...prev,
                      latencyMs: lat,
                      packetLoss: loss,
                      score: q === "Excellent" ? 96 : q === "Good" ? 88 : q === "Fair" ? 72 : 45
                    }));
                  }}
                  onSimulateParticipants={handleSimulateParticipants}
                  onClose={() => setActivePanel(null)}
                />
              )}

              {activePanel === "swiftCode" && (
                <SwiftCodebasePanel
                  onClose={() => setActivePanel(null)}
                />
              )}
            </div>
          )}
        </div>

        {/* 3. BOTTOM FLOATING CONTROLS BAR */}
        <div className="pb-3 pt-1">
          <FloatingControlsBar
            isMuted={isMuted}
            isCameraOff={isCameraOff}
            isScreenSharing={isScreenSharing}
            isRecording={isRecording}
            handRaised={handRaised}
            activePanel={activePanel}
            unreadChatCount={unreadChatCount}
            participantsCount={participants.length}
            waitingRoomCount={waitingRoom.length}
            deviceConfig={deviceConfig}
            micAudioLevel={micAudioLevel}
            onToggleMute={handleToggleMute}
            onToggleCamera={handleToggleCamera}
            onToggleScreenShare={handleToggleScreenShare}
            onToggleRecording={() => setIsRecording(!isRecording)}
            onToggleHand={() => setHandRaised(!handRaised)}
            onTogglePanel={(panel) => setActivePanel(activePanel === panel ? null : panel)}
            onSendReaction={handleSendReaction}
            onOpenScheduleModal={() => setIsScheduleOpen(true)}
            onOpenSettingsModal={() => setIsSettingsOpen(true)}
            onLeaveMeeting={() => setMeetingState(meetingState === "CONNECTED" ? "DISCONNECTED" : "CONNECTED")}
            onUpdateDeviceConfig={(cfg) => setDeviceConfig(prev => ({ ...prev, ...cfg }))}
          />
        </div>
      </div>

      {/* MODALS & OVERLAYS */}
      <ScreenPickerModal
        isOpen={isScreenPickerOpen}
        onClose={() => setIsScreenPickerOpen(false)}
        onStartShare={handleStartShareFromPicker}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        deviceConfig={deviceConfig}
        captionsConfig={captionsConfig}
        onUpdateDeviceConfig={(cfg) => setDeviceConfig(prev => ({ ...prev, ...cfg }))}
        onUpdateCaptionsConfig={(cfg) => setCaptionsConfig(prev => ({ ...prev, ...cfg }))}
      />

      <ScheduleMeetingModal
        isOpen={isScheduleOpen}
        onClose={() => setIsScheduleOpen(false)}
        scheduledMeetings={scheduledMeetings}
        onScheduleMeeting={(m) => {
          const newM: ScheduledMeeting = {
            id: `sch-${Date.now()}`,
            title: m.title || "Untitled Meeting",
            date: m.date || "2026-09-08",
            time: m.time || "10:00",
            duration: m.duration || "30 min",
            participants: ["Tim Cook", "Craig Federighi", "John Ternus"],
            requireWaitingRoom: m.requireWaitingRoom ?? true,
            autoRecord: m.autoRecord ?? false
          };
          setScheduledMeetings(prev => [newM, ...prev]);
        }}
        onJoinScheduledMeeting={(m) => {
          setMeetingTitle(m.title);
        }}
      />

      {/* Picture-in-Picture Mini Overlay */}
      <PictureInPictureOverlay
        isOpen={isPiPOpen}
        activeSpeaker={activeSpeaker}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onRestore={() => setIsPiPOpen(false)}
        onLeave={() => setMeetingState("DISCONNECTED")}
      />
    </div>
  );
}
