import { GoogleGenAI, Type } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action, transcript, query, documentText, meetingTitle, privacyMode } = body;

    // Check if user disabled AI processing for privacy
    if (privacyMode === "AI_OFF") {
      return NextResponse.json({
        error: "AI processing is disabled by privacy settings (AI OFF)."
      }, { status: 403 });
    }

    if (action === "summarize") {
      const prompt = `You are TELECONFERENCE.OS native Apple-style AI Meeting Intelligence.
Analyze the following meeting transcript for "${meetingTitle || 'Enterprise Review'}".
Provide a structured executive briefing.

You MUST categorize items accurately into:
- FACTS (verified statements/data mentioned)
- DECISIONS (concrete agreed outcomes)
- SUGGESTIONS (ideas proposed but pending approval)
- INFERENCES (analytical insights derived from the conversation)

Also generate:
- Executive Summary (2-3 concise sentences)
- Action Items (with explicit Assignee, Task description, Priority [High/Medium/Low], and Deadline)
- Key Topics Discussed

Meeting Transcript:
${transcript || "No transcript provided."}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are an executive enterprise teleconference AI assistant designed for macOS corporate meetings. Maintain professional, crisp, factual communication.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              executiveSummary: { type: Type.STRING },
              decisions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    category: { type: Type.STRING, description: "FACT | DECISION | SUGGESTION | INFERENCE" },
                    statement: { type: Type.STRING },
                    speaker: { type: Type.STRING },
                  },
                  required: ["category", "statement"]
                }
              },
              actionItems: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    task: { type: Type.STRING },
                    assignee: { type: Type.STRING },
                    deadline: { type: Type.STRING },
                    priority: { type: Type.STRING, description: "High | Medium | Low" }
                  },
                  required: ["task", "assignee", "deadline", "priority"]
                }
              },
              keyTopics: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              overallSentiment: { type: Type.STRING, description: "Constructive | Decisive | Exploratory | Challenging" }
            },
            required: ["executiveSummary", "decisions", "actionItems", "keyTopics"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      return NextResponse.json({ success: true, data: parsed });
    }

    if (action === "search_transcript") {
      const prompt = `You are TELECONFERENCE.OS Meeting Search Assistant.
User Query: "${query}"

Here is the meeting transcript:
${transcript || "No transcript data."}

Answer the user's question directly, clearly quoting the exact speakers and timestamps if relevant. Distinguish between facts, decisions, and suggestions.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          systemInstruction: "You answer questions accurately based purely on the meeting transcript provided. If information is missing, state it clearly.",
        }
      });

      return NextResponse.json({
        success: true,
        answer: response.text || "No direct answer found in transcript."
      });
    }

    if (action === "document_qa") {
      const prompt = `You are TELECONFERENCE.OS Document & Meeting Intelligence Assistant.
The presenter attached a document to the meeting:
---
${documentText || "No document content."}
---

Meeting Context & Transcript:
${transcript || "No transcript context."}

User Question: "${query}"

Answer the question thoroughly combining the document data and meeting discussions.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
      });

      return NextResponse.json({
        success: true,
        answer: response.text || "Unable to answer based on the attached document."
      });
    }

    if (action === "live_action_detect") {
      const prompt = `Review the latest speech segment: "${query}".
Did this mention a new actionable task or decision? If so, extract it. Otherwise return hasAction: false.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              hasAction: { type: Type.BOOLEAN },
              actionText: { type: Type.STRING },
              assignee: { type: Type.STRING },
              category: { type: Type.STRING, description: "DECISION | ACTION | NOTE" }
            },
            required: ["hasAction"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      return NextResponse.json({ success: true, data: parsed });
    }

    return NextResponse.json({ error: "Invalid action specified." }, { status: 400 });
  } catch (err: any) {
    console.error("AI Assistant API error:", err);
    return NextResponse.json({
      error: err?.message || "Internal AI service failure"
    }, { status: 500 });
  }
}
