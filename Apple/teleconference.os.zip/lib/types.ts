export type Role = 'HOST' | 'CO_HOST' | 'PRESENTER' | 'PARTICIPANT' | 'GUEST' | 'OBSERVER' | 'ATTENDEE';

export type ConnectionState = 'CONNECTED' | 'RECONNECTING' | 'DEGRADED' | 'DISCONNECTED';

export type NetworkQuality = 'Excellent' | 'Good' | 'Fair' | 'Poor' | 'Reconnecting';

export interface Participant {
  id: string;
  displayName: string;
  avatar: string;
  cameraEnabled: boolean;
  microphoneEnabled: boolean;
  screenSharing?: boolean;
  speaking: boolean;
  connectionState?: ConnectionState;
  networkQuality: NetworkQuality;
  handRaised: boolean;
  role: Role;
  speakingDurationSec?: number;
  audioLevel?: number; // 0 to 1
  isLocal?: boolean;
  title?: string;
  department?: string;
  color?: string;
  simulatedVideoFeedUrl?: string;
}

export type MeetingState = 'WAITING' | 'CONNECTING' | 'CONNECTED' | 'RECONNECTING' | 'ENDED' | 'FAILED' | 'DISCONNECTED';

export type LayoutMode = 
  | 'SPEAKER'
  | 'GALLERY'
  | 'PRESENTATION'
  | 'PRESENTATION_SPEAKER'
  | 'SIDE_BY_SIDE'
  | 'SPOTLIGHT'
  | 'DIRECTOR';

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: string;
  isPrivate?: boolean;
  recipientId?: string;
  recipientName?: string;
  reactions: Record<string, string[]>; // emoji -> [userNames]
  attachments?: {
    name: string;
    size: string;
    type: string;
    url?: string;
  }[];
}

export interface TranscriptItem {
  id: string;
  speakerId: string;
  speakerName: string;
  timestamp: string;
  text: string;
  confidence: number;
  language: string;
  isLive?: boolean;
}

export type WhiteboardTool = 'pen' | 'line' | 'rect' | 'circle' | 'text' | 'arrow' | 'eraser' | 'sticky';

export interface WhiteboardElement {
  id: string;
  type: WhiteboardTool;
  points?: { x: number; y: number }[] | number[];
  x?: number;
  y?: number;
  width?: number;
  height?: number;
  color?: string;
  strokeColor?: string;
  fillColor?: string;
  strokeWidth: number;
  text?: string;
  author?: string;
}

export interface ScheduledMeeting {
  id: string;
  title: string;
  date: string;
  time: string;
  duration: string;
  participants: string[];
  requireWaitingRoom: boolean;
  autoRecord: boolean;
  passcode?: string;
}

export interface CalendarMeeting {
  id: string;
  title: string;
  startTime: string; // ISO or human readable
  durationMin: number;
  host: string;
  participants: string[];
  meetingUrl: string;
  recurrence: string;
  waitingRoom: boolean;
  autoRecord: boolean;
  isOngoing?: boolean;
  passcode?: string;
}

export interface SharedFile {
  id: string;
  name: string;
  size: string;
  type: string;
  uploadedBy?: string;
  uploadedAt?: string;
  senderName?: string;
  senderId?: string;
  timestamp?: string;
  url?: string;
  downloadUrl?: string;
  contentPreview?: string;
}

export interface QualityScore {
  score: number; // 0-100
  overall?: number; // 0-100
  latencyMs: number; // ms
  jitterMs: number; // ms
  packetLoss: number; // %
  bitrateKbps: number; // kbps
  fps: number;
  reconnections: number;
  connection?: number;
  audio?: number;
  video?: number;
  status?: 'Excellent' | 'Good' | 'Fair' | 'Poor';
}

export interface DeviceConfig {
  cameraDeviceId: string;
  micDeviceId: string;
  speakerDeviceId: string;
  resolution: '720p' | '1080p' | '4K';
  frameRate: 30 | 60;
  echoCancellation: boolean;
  noiseSuppression: boolean;
  autoGainControl: boolean;
  systemAudioShared?: boolean;
  isTestingMic?: boolean;
  isTestingSpeaker?: boolean;
  micGain?: number; // 0-100
  outputVolume?: number; // 0-100
}

export type ThermalState = 'nominal' | 'fair' | 'serious' | 'critical';

export interface WaitingRoomUser {
  id: string;
  name: string;
  avatar: string;
  role: Role;
  requestedAt: string;
}

export interface CaptionsConfig {
  enabled: boolean;
  fontSize: 'small' | 'medium' | 'large';
  position: 'bottom' | 'top';
  language?: string;
  background: 'glass' | 'dark' | 'high-contrast';
}

export type AIPrivacyMode = 'AI_OFF' | 'LOCAL_AI' | 'REMOTE_AI';

export interface AISummaryResult {
  executiveSummary: string;
  decisions: {
    category: 'FACT' | 'DECISION' | 'SUGGESTION' | 'INFERENCE';
    statement: string;
    speaker?: string;
  }[];
  actionItems: {
    task: string;
    assignee: string;
    deadline: string;
    priority: 'High' | 'Medium' | 'Low';
  }[];
  keyTopics: string[];
  overallSentiment?: string;
}

export interface DocumentAttachment {
  id: string;
  name: string;
  size: string;
  textContent: string;
  uploadedBy: string;
}
