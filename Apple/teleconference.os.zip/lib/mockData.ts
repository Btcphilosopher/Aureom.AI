import { Participant, CalendarMeeting, ChatMessage, TranscriptItem, SharedFile, DocumentAttachment } from "./types";

export const INITIAL_PARTICIPANTS: Participant[] = [
  {
    id: "user-local",
    displayName: "Tom Miller (You)",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
    cameraEnabled: true,
    microphoneEnabled: true,
    screenSharing: false,
    speaking: false,
    connectionState: "CONNECTED",
    networkQuality: "Excellent",
    handRaised: false,
    role: "HOST",
    speakingDurationSec: 142,
    audioLevel: 0,
    isLocal: true,
    title: "Chief Architect",
    department: "Core Systems",
    color: "#3b82f6"
  },
  {
    id: "user-sarah",
    displayName: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80",
    cameraEnabled: true,
    microphoneEnabled: true,
    screenSharing: false,
    speaking: true,
    connectionState: "CONNECTED",
    networkQuality: "Excellent",
    handRaised: false,
    role: "PRESENTER",
    speakingDurationSec: 320,
    audioLevel: 0.65,
    title: "VP of Engineering",
    department: "Media Transport",
    color: "#10b981",
    simulatedVideoFeedUrl: "https://picsum.photos/seed/sarah_cam/640/360"
  },
  {
    id: "user-alice",
    displayName: "Alice Vance",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
    cameraEnabled: true,
    microphoneEnabled: true,
    screenSharing: false,
    speaking: false,
    connectionState: "CONNECTED",
    networkQuality: "Good",
    handRaised: true,
    role: "CO_HOST",
    speakingDurationSec: 190,
    audioLevel: 0.1,
    title: "Product Lead",
    department: "Enterprise Apps",
    color: "#8b5cf6"
  },
  {
    id: "user-bob",
    displayName: "Bob Martinez",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    cameraEnabled: true,
    microphoneEnabled: false,
    screenSharing: false,
    speaking: false,
    connectionState: "CONNECTED",
    networkQuality: "Excellent",
    handRaised: false,
    role: "PARTICIPANT",
    speakingDurationSec: 65,
    audioLevel: 0,
    title: "Security Director",
    department: "InfoSec & E2EE",
    color: "#f59e0b"
  },
  {
    id: "user-elena",
    displayName: "Elena Rostova",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
    cameraEnabled: true,
    microphoneEnabled: true,
    screenSharing: false,
    speaking: false,
    connectionState: "CONNECTED",
    networkQuality: "Fair",
    handRaised: false,
    role: "PARTICIPANT",
    speakingDurationSec: 88,
    audioLevel: 0.05,
    title: "Principal QA",
    department: "Reliability & ABR",
    color: "#ec4899"
  },
  {
    id: "user-marcus",
    displayName: "Marcus Wright",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
    cameraEnabled: false,
    microphoneEnabled: true,
    screenSharing: false,
    speaking: false,
    connectionState: "CONNECTED",
    networkQuality: "Excellent",
    handRaised: false,
    role: "PARTICIPANT",
    speakingDurationSec: 45,
    audioLevel: 0,
    title: "Core Audio Engineer",
    department: "AVFoundation",
    color: "#06b6d4"
  },
  {
    id: "user-david",
    displayName: "David Kim",
    avatar: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80",
    cameraEnabled: true,
    microphoneEnabled: false,
    screenSharing: false,
    speaking: false,
    connectionState: "CONNECTED",
    networkQuality: "Good",
    handRaised: false,
    role: "OBSERVER",
    speakingDurationSec: 12,
    audioLevel: 0,
    title: "Legal Counsel",
    department: "Privacy Compliance",
    color: "#64748b"
  },
  {
    id: "user-chloe",
    displayName: "Chloe Dupont",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
    cameraEnabled: true,
    microphoneEnabled: true,
    screenSharing: false,
    speaking: false,
    connectionState: "CONNECTED",
    networkQuality: "Excellent",
    handRaised: false,
    role: "PARTICIPANT",
    speakingDurationSec: 78,
    audioLevel: 0,
    title: "Design Systems Lead",
    department: "macOS Human Interface",
    color: "#f43f5e"
  }
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: "msg-1",
    senderId: "user-alice",
    senderName: "Alice Vance",
    senderAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
    text: "Can everyone see the architecture slides on ScreenCaptureKit pipeline?",
    timestamp: "10:41 AM",
    reactions: { "👍": ["Tom Miller (You)", "Bob Martinez"], "🚀": ["Sarah Chen"] }
  },
  {
    id: "msg-2",
    senderId: "user-bob",
    senderName: "Bob Martinez",
    senderAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    text: "Yes, 60 FPS stream looks crystal clear. Zero packet loss on TLS session.",
    timestamp: "10:42 AM",
    reactions: { "❤️": ["Alice Vance"] }
  },
  {
    id: "msg-3",
    senderId: "user-sarah",
    senderName: "Sarah Chen",
    senderAvatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80",
    text: "Let's review the revised Phase 2 budget allocation before Friday's rollout.",
    timestamp: "10:43 AM",
    reactions: { "🎯": ["Tom Miller (You)", "Marcus Wright"] }
  }
];

export const INITIAL_TRANSCRIPT: TranscriptItem[] = [
  {
    id: "tr-1",
    speakerId: "user-local",
    speakerName: "Tom Miller (You)",
    timestamp: "10:39:15",
    text: "Welcome everyone to the TELECONFERENCE.OS Core Architecture Review. Today we're finalizing our native macOS teleconferencing stack.",
    confidence: 0.98,
    language: "en-US"
  },
  {
    id: "tr-2",
    speakerId: "user-sarah",
    speakerName: "Sarah Chen",
    timestamp: "10:40:02",
    text: "We have fully verified ScreenCaptureKit integration for 4K 60FPS sharing with deterministic fallback to 1080p when thermal throttling kicks in.",
    confidence: 0.99,
    language: "en-US"
  },
  {
    id: "tr-3",
    speakerId: "user-alice",
    speakerName: "Alice Vance",
    timestamp: "10:41:20",
    text: "I propose we approve the Phase 2 deployment plan today. I will prepare the revised budget by Friday morning.",
    confidence: 0.97,
    language: "en-US"
  },
  {
    id: "tr-4",
    speakerId: "user-bob",
    speakerName: "Bob Martinez",
    timestamp: "10:42:05",
    text: "InfoSec has verified the MLS End-to-End Encryption protocol. All cryptographic keys remain strictly in the macOS Secure Enclave.",
    confidence: 0.99,
    language: "en-US"
  }
];

export const INITIAL_CALENDAR_MEETINGS: CalendarMeeting[] = [
  {
    id: "m-001",
    title: "Q4 Enterprise Infrastructure & AI Platform Launch",
    startTime: "Today, 10:30 AM - 11:30 AM",
    durationMin: 60,
    host: "Tom Miller (You)",
    participants: ["Sarah Chen", "Alice Vance", "Bob Martinez", "Elena Rostova", "+4 others"],
    meetingUrl: "https://teleconference.apple.corp/room/q4-launch",
    recurrence: "Weekly on Mondays",
    waitingRoom: true,
    autoRecord: true,
    isOngoing: true,
    passcode: "APPLE-2026"
  },
  {
    id: "m-002",
    title: "ScreenCaptureKit & CoreAudio HAL Optimization",
    startTime: "Today, 2:00 PM - 3:00 PM",
    durationMin: 60,
    host: "Marcus Wright",
    participants: ["Tom Miller", "Sarah Chen", "Elena Rostova"],
    meetingUrl: "https://teleconference.apple.corp/room/sc-audio",
    recurrence: "Bi-weekly",
    waitingRoom: false,
    autoRecord: false
  },
  {
    id: "m-003",
    title: "Executive Committee: Annual Security & Privacy Audit",
    startTime: "Tomorrow, 9:00 AM - 10:00 AM",
    durationMin: 60,
    host: "Bob Martinez",
    participants: ["David Kim", "Alice Vance", "Tom Miller"],
    meetingUrl: "https://teleconference.apple.corp/room/security-audit",
    recurrence: "Monthly",
    waitingRoom: true,
    autoRecord: true
  }
];

export const INITIAL_ATTACHED_DOCS: DocumentAttachment[] = [
  {
    id: "doc-1",
    name: "Project_Phase_2_Executive_Proposal.txt",
    size: "142 KB",
    uploadedBy: "Alice Vance",
    textContent: `PROJECT PHASE 2 EXECUTIVE PROPOSAL
Total Budget: $4.2M
Key Objectives:
1. Roll out native ScreenCaptureKit multi-window streaming to 50,000 corporate macOS seats.
2. Integrate MLS (Messaging Layer Security) E2EE cryptographic transport for zero-trust compliance.
3. Deploy on-device CoreML / Gemini 3.8 Flash AI Assistant with strict privacy boundaries (AI OFF / LOCAL / REMOTE modes).
Cost Allocations:
- Core Media Engineering: $1.8M
- Cloud Infrastructure & TURN/STUN relays: $1.2M
- Security Audit & Penetration Testing: $600K
- UI / Apple Human Interface Polish: $600K
Milestones:
- Feature Freeze: October 15
- Internal Beta: November 1
- General Enterprise Availability: December 10`
  }
];

export const INITIAL_FILES: SharedFile[] = [
  {
    id: "file-1",
    name: "TELECONFERENCE_OS_Arch_Spec_v3.2.pdf",
    size: "4.8 MB",
    type: "application/pdf",
    uploadedBy: "Sarah Chen",
    uploadedAt: "10:35 AM",
    senderName: "Sarah Chen",
    senderId: "user-sarah",
    timestamp: "10:35 AM",
    contentPreview: "TELECONFERENCE.OS Technical Specification: Native macOS AVFoundation capture pipeline, ScreenCaptureKit stream coordinator, and WebRTC zero-copy Metal compositor."
  },
  {
    id: "file-2",
    name: "Enterprise_Phase2_Budget_Breakdown.key",
    size: "18.2 MB",
    type: "application/x-iwork-keynote",
    uploadedBy: "Alice Vance",
    uploadedAt: "10:38 AM",
    senderName: "Alice Vance",
    senderId: "user-alice",
    timestamp: "10:38 AM",
    contentPreview: "Phase 2 Financial Overview: Server infrastructure, bandwidth egress allocations, and enterprise security compliance audits."
  }
];

export const INITIAL_SCHEDULED_MEETINGS = [
  {
    id: "m-001",
    title: "Q4 Enterprise Infrastructure & AI Platform Launch",
    date: "2026-09-08",
    time: "10:30 AM",
    duration: "60 min",
    participants: ["Sarah Chen", "Alice Vance", "Bob Martinez", "Elena Rostova", "+4 others"],
    requireWaitingRoom: true,
    autoRecord: true,
    passcode: "APPLE-2026"
  },
  {
    id: "m-002",
    title: "ScreenCaptureKit & CoreAudio HAL Optimization",
    date: "2026-09-08",
    time: "02:00 PM",
    duration: "45 min",
    participants: ["Tom Miller", "Sarah Chen", "Elena Rostova"],
    requireWaitingRoom: false,
    autoRecord: false
  },
  {
    id: "m-003",
    title: "Executive Committee: Annual Security & Privacy Audit",
    date: "2026-09-09",
    time: "09:00 AM",
    duration: "60 min",
    participants: ["David Kim", "Alice Vance", "Tom Miller"],
    requireWaitingRoom: true,
    autoRecord: true
  }
];

export const INITIAL_WAITING_ROOM = [
  {
    id: "wait-1",
    name: "Jonathan Ive (Design Partner)",
    avatar: "https://picsum.photos/seed/jony/150/150",
    role: "GUEST" as const,
    requestedAt: "10:44 AM"
  },
  {
    id: "wait-2",
    name: "Katherine Patel (Security Auditor)",
    avatar: "https://picsum.photos/seed/katherine/150/150",
    role: "OBSERVER" as const,
    requestedAt: "10:45 AM"
  }
];

