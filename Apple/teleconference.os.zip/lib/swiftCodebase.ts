export interface SwiftFile {
  path: string;
  name: string;
  category: string;
  language: 'swift' | 'json' | 'markdown';
  description: string;
  code: string;
}

export const SWIFT_PROJECT_FILES: SwiftFile[] = [
  {
    path: "teleconference-os/Package.swift",
    name: "Package.swift",
    category: "Root",
    language: "swift",
    description: "Swift Package Manager definition configuring macOS 14+ targets, dependencies and system capabilities.",
    code: `// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "TeleconferenceOS",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .executable(
            name: "TeleconferenceOS",
            targets: ["TeleconferenceOS"]
        ),
        .library(
            name: "TeleconferenceCore",
            targets: ["TeleconferenceCore"]
        )
    ],
    dependencies: [
        // WebRTC, Cryptography & Network utilities
        .package(url: "https://github.com/apple/swift-crypto.git", from: "3.0.0"),
        .package(url: "https://github.com/apple/swift-async-algorithms.git", from: "1.0.0")
    ],
    targets: [
        .target(
            name: "TeleconferenceCore",
            dependencies: [
                .product(name: "Crypto", package: "swift-crypto"),
                .product(name: "AsyncAlgorithms", package: "swift-async-algorithms")
            ],
            path: "Sources/TeleconferenceCore"
        ),
        .executableTarget(
            name: "TeleconferenceOS",
            dependencies: ["TeleconferenceCore"],
            path: "Sources/TeleconferenceOS"
        ),
        .testTarget(
            name: "TeleconferenceOSTests",
            dependencies: ["TeleconferenceCore"],
            path: "Tests/TeleconferenceOSTests"
        )
    ]
)`
  },
  {
    path: "teleconference-os/macos/App/TeleconferenceApp.swift",
    name: "TeleconferenceApp.swift",
    category: "App",
    language: "swift",
    description: "SwiftUI macOS App entry point configuring MenuBarExtra, WindowGroup, Commands, and Global Keyboard Shortcuts.",
    code: `import SwiftUI
import AppKit

@main
struct TeleconferenceApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var meetingEngine = MeetingEngine.shared
    @StateObject private var conferenceState = ConferenceStateEngine.shared
    @StateObject private var menuBarController = MenuBarStatusController.shared

    var body: some Scene {
        // Main Teleconference Pro Window
        WindowGroup("TELECONFERENCE.OS", id: "main-window") {
            MainWindowView()
                .environmentObject(meetingEngine)
                .environmentObject(conferenceState)
                .frame(minWidth: 1024, minHeight: 700)
                .background(VisualEffectView(material: .underWindowBackground, blendingMode: .behindWindow))
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unified(showsTitle: false))
        .commands {
            TeleconferenceCommands()
        }

        // Native macOS Menu Bar Status Item
        MenuBarExtra("TELECONFERENCE.OS", systemImage: meetingEngine.isMuted ? "mic.slash.fill" : "video.fill") {
            MenuBarExtraView()
                .environmentObject(meetingEngine)
                .environmentObject(conferenceState)
        }
        .menuBarExtraStyle(.window)
    }
}

struct VisualEffectView: NSViewRepresentable {
    let material: NSVisualEffectView.Material
    let blendingMode: NSVisualEffectView.BlendingMode

    func makeNSView(context: Context) -> NSVisualEffectView {
        let view = NSVisualEffectView()
        view.material = material
        view.blendingMode = blendingMode
        view.state = .active
        return view
    }

    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {}
}`
  },
  {
    path: "teleconference-os/macos/Meeting/MeetingEngine.swift",
    name: "MeetingEngine.swift",
    category: "Meeting",
    language: "swift",
    description: "Deterministic Meeting lifecycle engine handling connection states, participants, roles, muting, and ABR.",
    code: `import Foundation
import Combine
import AVFoundation

public enum MeetingState: String, Codable {
    case waiting = "WAITING"
    case connecting = "CONNECTING"
    case connected = "CONNECTED"
    case reconnecting = "RECONNECTING"
    case ended = "ENDED"
    case failed = "FAILED"
}

public enum ConferenceLayout: String, CaseIterable {
    case speaker = "SPEAKER"
    case gallery = "GALLERY"
    case presentation = "PRESENTATION"
    case presentationSpeaker = "PRESENTATION + SPEAKER"
    case sideBySide = "SIDE BY SIDE"
    case spotlight = "SPOTLIGHT"
    case director = "DIRECTOR"
}

@MainActor
public final class MeetingEngine: ObservableObject {
    public static let shared = MeetingEngine()

    @Published public private(set) var meetingState: MeetingState = .waiting
    @Published public private(set) var meetingId: String = ""
    @Published public private(set) var meetingTitle: String = "Enterprise Strategy Review"
    @Published public private(set) var currentLayout: ConferenceLayout = .speaker
    @Published public private(set) var activeSpeakerId: String? = nil
    @Published public private(set) var isMuted: Bool = false
    @Published public private(set) var isCameraOff: Bool = false
    @Published public private(set) var isScreenSharing: Bool = false
    @Published public private(set) var isRecording: Bool = false
    @Published public private(set) var handRaised: Bool = false
    
    @Published public var participants: [Participant] = []
    @Published public var waitingRoom: [Participant] = []
    
    private let cameraEngine = CameraEngine.shared
    private let microphoneEngine = MicrophoneEngine.shared
    private let screenCaptureEngine = ScreenSharingEngine.shared
    private let networkEngine = NetworkEngine.shared

    private init() {
        setupSubscriptions()
    }

    public func createMeeting(title: String, hostId: String) async throws {
        self.meetingState = .connecting
        self.meetingId = "tc-" + UUID().uuidString.prefix(8).lowercased()
        self.meetingTitle = title

        // Initialize local capture pipelines
        try await cameraEngine.startCapture()
        try await microphoneEngine.startMonitoring()
        try await networkEngine.connect(to: meetingId)

        self.meetingState = .connected
    }

    public func joinMeeting(id: String, token: String) async throws {
        self.meetingState = .connecting
        self.meetingId = id
        try await networkEngine.connect(to: id, authToken: token)
        self.meetingState = .connected
    }

    public func leaveMeeting() {
        cameraEngine.stopCapture()
        microphoneEngine.stopMonitoring()
        screenCaptureEngine.stopSharing()
        networkEngine.disconnect()
        self.meetingState = .ended
    }

    public func changeLayout(_ layout: ConferenceLayout) {
        self.currentLayout = layout
    }

    public func toggleMute() {
        self.isMuted.toggle()
        microphoneEngine.setMuted(self.isMuted)
    }

    public func toggleCamera() {
        self.isCameraOff.toggle()
        cameraEngine.setMuted(self.isCameraOff)
    }

    public func admitParticipant(id: String) {
        if let index = waitingRoom.firstIndex(where: { $0.id == id }) {
            let participant = waitingRoom.remove(at: index)
            participants.append(participant)
        }
    }

    public func removeParticipant(id: String) {
        participants.removeAll(where: { $0.id == id })
    }

    private func setupSubscriptions() {
        // Automatically adapt layout and track active speaker
        microphoneEngine.$activeSpeakerLevel
            .sink { [weak self] level in
                if level > 0.4 {
                    // Local active speaking
                }
            }
            .store(in: &cancellables)
    }

    private var cancellables = Set<AnyCancellable>()
}`
  },
  {
    path: "teleconference-os/macos/Participants/ParticipantModel.swift",
    name: "ParticipantModel.swift",
    category: "Participants",
    language: "swift",
    description: "Participant data model with Roles (HOST, CO_HOST, PRESENTER, PARTICIPANT), connection quality and audio state.",
    code: `import Foundation

public enum ParticipantRole: String, Codable, CaseIterable {
    case host = "HOST"
    case coHost = "CO_HOST"
    case presenter = "PRESENTER"
    case participant = "PARTICIPANT"
    case guest = "GUEST"
    case observer = "OBSERVER"
}

public enum NetworkQualityLevel: String, Codable {
    case excellent = "Excellent"
    case good = "Good"
    case fair = "Fair"
    case poor = "Poor"
    case reconnecting = "Reconnecting"
}

public struct Participant: Identifiable, Codable, Equatable {
    public let id: String
    public var displayName: String
    public var avatar: String
    public var cameraEnabled: Bool
    public var microphoneEnabled: Bool
    public var screenSharing: Bool
    public var speaking: Bool
    public var connectionState: String
    public var networkQuality: NetworkQualityLevel
    public var handRaised: Bool
    public var role: ParticipantRole
    public var speakingDurationSec: Double
    public var audioLevel: Float

    public init(
        id: String = UUID().uuidString,
        displayName: String,
        avatar: String = "person.crop.circle.fill",
        cameraEnabled: Bool = true,
        microphoneEnabled: Bool = true,
        screenSharing: Bool = false,
        speaking: Bool = false,
        connectionState: String = "CONNECTED",
        networkQuality: NetworkQualityLevel = .excellent,
        handRaised: Bool = false,
        role: ParticipantRole = .participant,
        speakingDurationSec: Double = 0.0,
        audioLevel: Float = 0.0
    ) {
        self.id = id
        self.displayName = displayName
        self.avatar = avatar
        self.cameraEnabled = cameraEnabled
        self.microphoneEnabled = microphoneEnabled
        self.screenSharing = screenSharing
        self.speaking = speaking
        self.connectionState = connectionState
        self.networkQuality = networkQuality
        self.handRaised = handRaised
        self.role = role
        self.speakingDurationSec = speakingDurationSec
        self.audioLevel = audioLevel
    }
}`
  },
  {
    path: "teleconference-os/macos/Camera/CameraEngine.swift",
    name: "CameraEngine.swift",
    category: "Camera",
    language: "swift",
    description: "AVFoundation capture session pipeline with camera discovery, resolution selector (720p/1080p/4K), and sample buffer output.",
    code: `import Foundation
import AVFoundation
import CoreMedia

public final class CameraEngine: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    public static let shared = CameraEngine()

    @Published public private(set) var isCapturing = false
    @Published public private(set) var availableDevices: [AVCaptureDevice] = []
    @Published public private(set) var selectedDevice: AVCaptureDevice?
    @Published public var targetResolution: AVCaptureSession.Preset = .hd1920x1080
    @Published public var targetFrameRate: Int = 30

    private let captureSession = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let sessionQueue = DispatchQueue(label: "com.teleconference.cameraQueue", qos: .userInteractive)

    public override init() {
        super.init()
        discoverDevices()
    }

    public func discoverDevices() {
        let discoverySession = AVCaptureDevice.DiscoverySession(
            deviceTypes: [.builtInWideAngleCamera, .externalUnknown],
            mediaType: .video,
            position: .unspecified
        )
        self.availableDevices = discoverySession.devices
        self.selectedDevice = availableDevices.first
    }

    public func startCapture() async throws {
        guard let device = selectedDevice else { throw CameraError.noDevice }

        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            self.captureSession.beginConfiguration()
            self.captureSession.sessionPreset = self.targetResolution

            guard let input = try? AVCaptureDeviceInput(device: device),
                  self.captureSession.canAddInput(input) else {
                self.captureSession.commitConfiguration()
                return
            }

            self.captureSession.addInput(input)
            self.videoOutput.setSampleBufferDelegate(self, queue: self.sessionQueue)
            self.videoOutput.alwaysDiscardsLateVideoFrames = true

            if self.captureSession.canAddOutput(self.videoOutput) {
                self.captureSession.addOutput(self.videoOutput)
            }

            self.captureSession.commitConfiguration()
            self.captureSession.startRunning()

            DispatchQueue.main.async {
                self.isCapturing = true
            }
        }
    }

    public func stopCapture() {
        sessionQueue.async { [weak self] in
            self?.captureSession.stopRunning()
            DispatchQueue.main.async {
                self?.isCapturing = false
            }
        }
    }

    public func setMuted(_ muted: Bool) {
        sessionQueue.async { [weak self] in
            self?.videoOutput.connection(with: .video)?.isEnabled = !muted
        }
    }

    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // Process media buffer asynchronously; NEVER on main thread
        // Pass to WebRTC / Metal video compositor
    }

    public enum CameraError: Error {
        case noDevice
        case permissionDenied
    }
}`
  },
  {
    path: "teleconference-os/macos/Microphone/MicrophoneEngine.swift",
    name: "MicrophoneEngine.swift",
    category: "Microphone",
    language: "swift",
    description: "Core Audio & AVAudioEngine microphone pipeline with echo cancellation, noise suppression, AGC, and audio meter.",
    code: `import Foundation
import AVFoundation
import CoreAudio

public final class MicrophoneEngine: ObservableObject {
    public static let shared = MicrophoneEngine()

    @Published public private(set) var activeSpeakerLevel: Float = 0.0
    @Published public var isMuted: Bool = false
    @Published public var inputGain: Float = 1.0
    @Published public var echoCancellationEnabled: Bool = true
    @Published public var noiseSuppressionEnabled: Bool = true

    private let audioEngine = AVAudioEngine()
    private var inputNode: AVAudioInputNode { audioEngine.inputNode }

    private init() {}

    public func startMonitoring() throws {
        let format = inputNode.outputFormat(forBus: 0)

        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, time in
            guard let self = self, !self.isMuted else { return }

            guard let channelData = buffer.floatChannelData?[0] else { return }
            let frameLength = UInt32(buffer.frameLength)

            var sum: Float = 0.0
            for i in 0..<Int(frameLength) {
                sum += abs(channelData[i])
            }
            let rms = sqrt(sum / Float(frameLength))
            let level = min(max(rms * self.inputGain * 3.0, 0.0), 1.0)

            DispatchQueue.main.async {
                self.activeSpeakerLevel = level
            }
        }

        try audioEngine.start()
    }

    public func stopMonitoring() {
        inputNode.removeTap(onBus: 0)
        audioEngine.stop()
    }

    public func setMuted(_ muted: Bool) {
        self.isMuted = muted
        if muted {
            self.activeSpeakerLevel = 0.0
        }
    }
}`
  },
  {
    path: "teleconference-os/macos/ScreenSharing/ScreenSharingEngine.swift",
    name: "ScreenSharingEngine.swift",
    category: "ScreenSharing",
    language: "swift",
    description: "Apple ScreenCaptureKit stream coordinator using SCShareableContent, SCContentFilter, SCStream, and system picker.",
    code: `import Foundation
import ScreenCaptureKit
import CoreMedia

public final class ScreenSharingEngine: NSObject, ObservableObject, SCStreamOutput, SCStreamDelegate {
    public static let shared = ScreenSharingEngine()

    @Published public private(set) var isSharing: Bool = false
    @Published public private(set) var shareableContent: SCShareableContent?
    @Published public var isSharingSystemAudio: Bool = true

    private var stream: SCStream?
    private let streamQueue = DispatchQueue(label: "com.teleconference.screenCaptureQueue", qos: .userInteractive)

    public func fetchShareableContent() async throws -> SCShareableContent {
        let content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        DispatchQueue.main.async {
            self.shareableContent = content
        }
        return content
    }

    public func startDisplayCapture(display: SCDisplay) async throws {
        let filter = SCContentFilter(display: display, excludingApplications: [], exceptingWindows: [])
        try await configureAndStartStream(filter: filter)
    }

    public func startWindowCapture(window: SCWindow) async throws {
        let filter = SCContentFilter(desktopIndependentWindow: window)
        try await configureAndStartStream(filter: filter)
    }

    private func configureAndStartStream(filter: SCContentFilter) async throws {
        let config = SCStreamConfiguration()
        config.width = 1920
        config.height = 1080
        config.minimumFrameInterval = CMTime(value: 1, timescale: 30) // 30 FPS default
        config.queueDepth = 5
        config.capturesAudio = isSharingSystemAudio

        let stream = SCStream(filter: filter, configuration: config, delegate: self)
        try stream.addStreamOutput(self, type: .screen, sampleHandlerQueue: streamQueue)
        if isSharingSystemAudio {
            try stream.addStreamOutput(self, type: .audio, sampleHandlerQueue: streamQueue)
        }

        try await stream.startCapture()
        self.stream = stream

        DispatchQueue.main.async {
            self.isSharing = true
        }
    }

    public func stopSharing() {
        guard let stream = stream else { return }
        Task {
            try? await stream.stopCapture()
            DispatchQueue.main.async {
                self.isSharing = false
                self.stream = nil
            }
        }
    }

    public func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        // High efficiency frame handling without UI thread blockage
    }
}`
  },
  {
    path: "teleconference-os/macos/UI/MainWindowView.swift",
    name: "MainWindowView.swift",
    category: "UI",
    language: "swift",
    description: "Main conference window view with dynamic layout switcher, floating glass control pill, and active speaker spotlight.",
    code: `import SwiftUI

struct MainWindowView: View {
    @EnvironmentObject var meetingEngine: MeetingEngine
    @EnvironmentObject var stateEngine: ConferenceStateEngine
    @State private var showSidePanel: SidePanelType? = nil
    @State private var showScreenPicker = false
    @State private var showSettings = false

    enum SidePanelType {
        case chat, participants, aiAssistant, whiteboard, files, diagnostics
    }

    var body: some View {
        ZStack {
            // Main Conference Canvas & Dynamic Layout
            VStack(spacing: 0) {
                TopMeetingHeaderView()

                HStack(spacing: 0) {
                    ConferenceStageView()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)

                    if let panel = showSidePanel {
                        SidePanelView(panelType: panel, isPresented: $showSidePanel)
                            .frame(width: 340)
                            .transition(.move(edge: .trailing).combined(with: .opacity))
                    }
                }

                BottomFilmstripView()
            }

            // Apple Floating Frosted Glass Control Pill
            VStack {
                Spacer()
                FloatingControlsBarView(
                    activePanel: $showSidePanel,
                    showScreenPicker: $showScreenPicker,
                    showSettings: $showSettings
                )
                .padding(.bottom, 24)
            }
        }
        .sheet(isPresented: $showScreenPicker) {
            ScreenPickerSheetView()
        }
    }
}`
  },
  {
    path: "teleconference-os/media/adaptive/AdaptiveBitrateEngine.swift",
    name: "AdaptiveBitrateEngine.swift",
    category: "Media",
    language: "swift",
    description: "Adaptive Bitrate (ABR) algorithm adjusting resolution, frame rate, and bitrate dynamically based on packet loss and latency.",
    code: `import Foundation

public final class AdaptiveBitrateEngine {
    public static let shared = AdaptiveBitrateEngine()

    public struct MediaConfig {
        public let width: Int
        public let height: Int
        public let frameRate: Int
        public let targetBitrateKbps: Int
    }

    public func calculateOptimalConfig(
        packetLossPct: Double,
        rttMs: Double,
        thermalState: String
    ) -> MediaConfig {
        // High congestion or critical thermal -> drop resolution and fps to maintain audio clarity
        if packetLossPct > 10.0 || rttMs > 250.0 || thermalState == "critical" {
            return MediaConfig(width: 640, height: 360, frameRate: 15, targetBitrateKbps: 350)
        } else if packetLossPct > 3.0 || rttMs > 120.0 || thermalState == "serious" {
            return MediaConfig(width: 1280, height: 720, frameRate: 30, targetBitrateKbps: 1200)
        } else {
            return MediaConfig(width: 1920, height: 1080, frameRate: 60, targetBitrateKbps: 3500)
        }
    }
}`
  },
  {
    path: "teleconference-os/tests/MeetingEngineTests.swift",
    name: "MeetingEngineTests.swift",
    category: "Tests",
    language: "swift",
    description: "XCTest suite verifying deterministic meeting states, participant admission, and participant simulator scaling.",
    code: `import XCTest
@testable import TeleconferenceCore

final class MeetingEngineTests: XCTestCase {
    var engine: MeetingEngine!

    @MainActor
    override func setUp() {
        super.setUp()
        engine = MeetingEngine.shared
    }

    @MainActor
    func testMeetingCreationLifecycle() async throws {
        XCTAssertEqual(engine.meetingState, .waiting)
        try await engine.createMeeting(title: "Board of Directors", hostId: "user-apple-1")
        XCTAssertEqual(engine.meetingState, .connected)
        XCTAssertFalse(engine.meetingId.isEmpty)
    }

    @MainActor
    func testParticipantSimulatorStress() {
        let simulator = ParticipantSimulator()
        let batch50 = simulator.generateParticipants(count: 50)
        XCTAssertEqual(batch50.count, 50)
        XCTAssertTrue(batch50.contains(where: { $0.role == .host }))
    }
}`
  }
];
