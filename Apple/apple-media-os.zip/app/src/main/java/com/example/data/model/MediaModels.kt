package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class NavigationSection {
    MUSIC_SONGS,
    MUSIC_ALBUMS,
    MUSIC_ARTISTS,
    MUSIC_GENRES,
    PLAYLISTS,
    PODCASTS,
    AUDIOBOOKS,
    VIDEOS,
    DEVICES,
    AI_ASSISTANT,
    HEALTH_DASHBOARD,
    RECOMMENDATIONS
}

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String, // UUID
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val year: Int,
    val durationSeconds: Long,
    val bpm: Double,
    val key: String,
    val rating: Int, // 1 to 5
    val playCount: Int,
    val dateAdded: Long,
    val lastPlayed: Long,
    val artworkUri: String?,
    val trackNumber: Int,
    val discNumber: Int,
    val composer: String,
    val comment: String = "",
    val energy: Double = 0.5,
    val dynamicRange: Double = 8.0,
    val isFavorite: Boolean = false,
    val filePath: String = "",
    val mimeType: String = "audio/mp3",
    val fileSize: Long = 8500000L,
    val lyrics: String = ""
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isSmart: Boolean = false,
    val rulesJson: String = "", // Serialized rules for smart playlists
    val folderId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val description: String = ""
)

@Entity(tableName = "playlist_items", primaryKeys = ["playlistId", "trackId"])
data class PlaylistItemEntity(
    val playlistId: String,
    val trackId: String,
    val orderIndex: Int
)

@Entity(tableName = "podcasts")
data class PodcastShowEntity(
    @PrimaryKey val id: String,
    val title: String,
    val author: String,
    val description: String,
    val artworkUri: String?,
    val isSubscribed: Boolean = true,
    val unplayedCount: Int = 0,
    val category: String = "Technology"
)

@Entity(tableName = "podcast_episodes")
data class PodcastEpisodeEntity(
    @PrimaryKey val id: String,
    val showId: String,
    val title: String,
    val publishDate: Long,
    val durationSeconds: Long,
    val playbackPositionSeconds: Long = 0L,
    val isDownloaded: Boolean = true,
    val isPlayed: Boolean = false,
    val summary: String = ""
)

@Entity(tableName = "audiobooks")
data class AudiobookEntity(
    @PrimaryKey val id: String,
    val title: String,
    val author: String,
    val narrator: String,
    val durationSeconds: Long,
    val currentChapterIndex: Int = 0,
    val playbackPositionSeconds: Long = 0L,
    val artworkUri: String?,
    val completionPercentage: Float = 0.0f
)

@Entity(tableName = "audiobook_chapters")
data class AudiobookChapterEntity(
    @PrimaryKey val id: String,
    val audiobookId: String,
    val title: String,
    val durationSeconds: Long,
    val chapterIndex: Int
)

@Entity(tableName = "videos")
data class VideoItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String, // FILM, TV_SHOW, HOME_VIDEO, MUSIC_VIDEO
    val year: Int,
    val durationSeconds: Long,
    val resolution: String = "4K HDR",
    val genre: String,
    val artworkUri: String?,
    val seasonNumber: Int = 1,
    val episodeNumber: Int = 1
)

@Entity(tableName = "devices")
data class DeviceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // IPHONE, IPAD, MAC, MOCK
    val capacityBytes: Long, // e.g., 128 GB
    val usedStorageBytes: Long,
    val batteryLevel: Int, // 0-100
    val connectionType: String, // USB, WIFI, NETWORK
    val syncStatus: String = "READY",
    val lastBackupTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "play_history")
data class PlayHistoryEntity(
    @PrimaryKey(autoGenerate = true) val historyId: Long = 0,
    val trackId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val completionPercentage: Float = 1.0f
)

data class AudioAnalysisResult(
    val bpm: Double,
    val key: String,
    val loudnessDb: Double,
    val energy: Double,
    val spectralCentroid: Double,
    val dynamicRange: Double
)

data class Recommendation(
    val track: TrackEntity,
    val reason: String
)

data class SmartRule(
    val field: String, // "Artist", "Genre", "BPM", "Rating", "PlayCount", "Year"
    val operator: String, // "=", ">", ">=", "<", "CONTAINS"
    val value: String
)

enum class LogicalOperator {
    AND, OR, NOT
}

data class DuplicateGroup(
    val mainTrack: TrackEntity,
    val duplicateTrack: TrackEntity,
    val similarityScore: Int // e.g. 98%
)

data class SyncPreviewItem(
    val musicTracksToAdd: Int,
    val podcastsToAdd: Int,
    val videosToRemove: Int,
    val storageRequiredBytes: Long
)
