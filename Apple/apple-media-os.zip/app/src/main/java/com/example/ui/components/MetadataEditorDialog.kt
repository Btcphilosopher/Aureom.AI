package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.TrackEntity
import com.example.ui.theme.*

@Composable
fun MetadataEditorDialog(
    track: TrackEntity,
    onDismiss: () -> Unit,
    onSave: (TrackEntity) -> Unit
) {
    var title by remember { mutableStateOf(track.title) }
    var artist by remember { mutableStateOf(track.artist) }
    var album by remember { mutableStateOf(track.album) }
    var genre by remember { mutableStateOf(track.genre) }
    var yearText by remember { mutableStateOf(track.year.toString()) }
    var composer by remember { mutableStateOf(track.composer) }
    var trackNumberText by remember { mutableStateOf(track.trackNumber.toString()) }
    var discNumberText by remember { mutableStateOf(track.discNumber.toString()) }
    var comment by remember { mutableStateOf(track.comment) }
    var lyrics by remember { mutableStateOf(track.lyrics) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .width(480.dp)
                .wrapContentHeight()
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, MacCardBorder, RoundedCornerShape(12.dp)),
            color = MacHeaderBg
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "EDIT TRACK METADATA",
                    color = AppleItunesRed,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Changes will be updated in the central SQLite media database.",
                    color = MacTextMuted,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                MetadataField("Title", title) { title = it }
                MetadataField("Artist", artist) { artist = it }
                MetadataField("Album", album) { album = it }
                MetadataField("Genre", genre) { genre = it }
                MetadataField("Composer", composer) { composer = it }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.weight(1f)) {
                        MetadataField("Year", yearText) { yearText = it }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MetadataField("Track #", trackNumberText) { trackNumberText = it }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MetadataField("Disc #", discNumberText) { discNumberText = it }
                    }
                }

                MetadataField("Comment", comment) { comment = it }
                MetadataField("Lyrics", lyrics, singleLine = false) { lyrics = it }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss, modifier = Modifier.testTag("cancel_metadata_edit")) {
                        Text("Cancel", color = MacTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val updatedTrack = track.copy(
                                title = title,
                                artist = artist,
                                album = album,
                                genre = genre,
                                year = yearText.toIntOrNull() ?: track.year,
                                composer = composer,
                                trackNumber = trackNumberText.toIntOrNull() ?: track.trackNumber,
                                discNumber = discNumberText.toIntOrNull() ?: track.discNumber,
                                comment = comment,
                                lyrics = lyrics
                            )
                            onSave(updatedTrack)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AppleItunesRed),
                        modifier = Modifier.testTag("save_metadata_edit")
                    ) {
                        Text("Save Changes", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetadataField(
    label: String,
    value: String,
    singleLine: Boolean = true,
    onValueChange: (String) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = label, color = MacTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = singleLine,
            maxLines = if (singleLine) 1 else 3,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AppleItunesRed,
                unfocusedBorderColor = MacCardBorder,
                focusedContainerColor = MacWindowBg,
                unfocusedContainerColor = MacWindowBg,
                focusedTextColor = MacTextPrimary,
                unfocusedTextColor = MacTextPrimary
            ),
            modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
        )
    }
}
