package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Apple Media OS - Frosted Glass Dark Aesthetic Palette
val MacWindowBg = Color(0xFF050505)
val MacSidebarBg = Color(0x0FFFFFFF)
val MacHeaderBg = Color(0x66000000)
val MacCardBg = Color(0x0DFFFFFF)
val MacCardBorder = Color(0x26FFFFFF)
val MacGlassPlayerBg = Color(0x1CFFFFFF)

val AppleItunesRed = Color(0xFFFA233B)
val AppleBlue = Color(0xFF3B82F6)
val AppleCyan = Color(0xFF64D2FF)
val ApplePurple = Color(0xFFA855F7)

val MacTrafficRed = Color(0xFFFF5F57)
val MacTrafficYellow = Color(0xFFFFBD2E)
val MacTrafficGreen = Color(0xFF28C840)

val MacTextPrimary = Color(0xFFF1F5F9)
val MacTextSecondary = Color(0x99FFFFFF)
val MacTextMuted = Color(0x66FFFFFF)

