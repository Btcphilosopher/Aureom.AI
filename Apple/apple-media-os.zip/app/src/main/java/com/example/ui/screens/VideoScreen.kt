package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.VideoItemEntity
import com.example.ui.components.formatTimeSeconds
import com.example.ui.theme.*

@Composable
fun VideoScreen(
    videos: List<VideoItemEntity>,
    onPlayVideo: (VideoItemEntity) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("ALL") }
    var activeVideoPlayerModal by remember { mutableStateOf<VideoItemEntity?>(null) }

    val filteredVideos = remember(videos, selectedCategory) {
        if (selectedCategory == "ALL") videos else videos.filter { it.category.equals(selectedCategory, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MacWindowBg)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("VIDEO LIBRARY", color = MacTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("AVFoundation video rendering with PIP and resolution metadata.", color = MacTextSecondary, fontSize = 11.sp)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("ALL", "FILM", "TV_SHOW", "MUSIC_VIDEO").forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat.replace("_", " "), fontSize = 11.sp) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 240.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredVideos) { video ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { activeVideoPlayerModal = video },
                    colors = CardDefaults.cardColors(containerColor = MacCardBg),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, MacCardBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = AppleItunesRed, modifier = Modifier.size(48.dp))
                            Surface(
                                color = Color.Black.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                            ) {
                                Text(video.resolution, color = AppleCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(video.title, color = MacTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("${video.genre} • ${video.year} • ${formatTimeSeconds(video.durationSeconds)}", color = MacTextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }

    if (activeVideoPlayerModal != null) {
        val vid = activeVideoPlayerModal!!
        Dialog(onDismissRequest = { activeVideoPlayerModal = null }) {
            Surface(
                modifier = Modifier
                    .width(560.dp)
                    .height(380.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, MacCardBorder, RoundedCornerShape(12.dp)),
                color = Color.Black
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Playing Video", tint = AppleItunesRed, modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("PLAYING: ${vid.title.uppercase()}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("AVKit Player Engine • ${vid.resolution}", color = AppleCyan, fontSize = 11.sp)
                    }

                    Button(
                        onClick = {
                            onPlayVideo(vid)
                            activeVideoPlayerModal = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AppleItunesRed),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp)
                            .testTag("full_video_player_play_button")
                    ) {
                        Text("Open Full Video Player", color = Color.White)
                    }
                }
            }
        }
    }
}
