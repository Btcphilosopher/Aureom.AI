package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val MacDarkColorScheme = darkColorScheme(
    primary = AppleItunesRed,
    secondary = AppleBlue,
    tertiary = ApplePurple,
    background = MacWindowBg,
    surface = MacCardBg,
    surfaceVariant = MacSidebarBg,
    onPrimary = MacTextPrimary,
    onSecondary = MacTextPrimary,
    onBackground = MacTextPrimary,
    onSurface = MacTextPrimary,
    onSurfaceVariant = MacTextSecondary,
    outline = MacCardBorder
)

@Composable
fun AppleMediaOsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MacDarkColorScheme,
        typography = Typography,
        content = content
    )
}

