package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.engine.SyncEngine
import com.example.data.model.DeviceEntity
import com.example.data.model.SyncPreviewItem
import com.example.ui.theme.*

@Composable
fun SyncPreviewDialog(
    device: DeviceEntity,
    previewItem: SyncPreviewItem,
    onConfirmSync: () -> Unit,
    onDismiss: () -> Unit
) {
    var selectedConflictStrategy by remember { mutableStateOf("Keep Mac") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .width(440.dp)
                .wrapContentHeight()
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, MacCardBorder, RoundedCornerShape(12.dp)),
            color = MacHeaderBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Smartphone,
                        contentDescription = null,
                        tint = AppleBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "SYNC PREVIEW - ${device.name.uppercase()}",
                            color = MacTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Review sync modifications before applying to device.",
                            color = MacTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MacCardBg)
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Music", color = MacTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("+ ${previewItem.musicTracksToAdd} tracks", color = MacTrafficGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Podcasts", color = MacTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("+ ${previewItem.podcastsToAdd} episodes", color = MacTrafficGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Videos", color = MacTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("- ${previewItem.videosToRemove} removed", color = MacTrafficRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Divider(color = MacCardBorder, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Storage Required:", color = MacTextSecondary, fontSize = 12.sp)
                            Text(SyncEngine.formatBytes(previewItem.storageRequiredBytes), color = AppleCyan, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("Sync Conflict Strategy:", color = MacTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Keep Mac", "Keep Device", "Keep Both").forEach { option ->
                        FilterChip(
                            selected = selectedConflictStrategy == option,
                            onClick = { selectedConflictStrategy = option },
                            label = { Text(option, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = MacTextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onConfirmSync,
                        colors = ButtonDefaults.buttonColors(containerColor = AppleBlue),
                        modifier = Modifier.testTag("confirm_device_sync_button")
                    ) {
                        Text("Sync Now", color = Color.White)
                    }
                }
            }
        }
    }
}
