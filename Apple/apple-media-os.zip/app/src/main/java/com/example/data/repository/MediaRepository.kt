package com.example.data.repository

import com.example.data.database.*
import com.example.data.engine.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class MediaRepository(
    private val mediaDao: MediaDao,
    private val podcastDao: PodcastDao,
    private val audiobookDao: AudiobookDao,
    private val videoDao: VideoDao,
    private val deviceDao: DeviceDao
) {
    val allTracks: Flow<List<TrackEntity>> = mediaDao.getAllTracks()
    val allAlbumNames: Flow<List<String>> = mediaDao.getAllAlbumNames()
    val allArtistNames: Flow<List<String>> = mediaDao.getAllArtistNames()
    val allGenres: Flow<List<String>> = mediaDao.getAllGenres()
    val recentlyAddedTracks: Flow<List<TrackEntity>> = mediaDao.getRecentlyAddedTracks()
    val recentlyPlayedTracks: Flow<List<TrackEntity>> = mediaDao.getRecentlyPlayedTracks()
    val favoriteTracks: Flow<List<TrackEntity>> = mediaDao.getFavoriteTracks()

    val allPlaylists: Flow<List<PlaylistEntity>> = mediaDao.getAllPlaylists()
    val allPodcasts: Flow<List<PodcastShowEntity>> = podcastDao.getAllPodcasts()
    val allPodcastEpisodes: Flow<List<PodcastEpisodeEntity>> = podcastDao.getAllEpisodes()
    val unplayedPodcastEpisodes: Flow<List<PodcastEpisodeEntity>> = podcastDao.getUnplayedEpisodes()

    val allAudiobooks: Flow<List<AudiobookEntity>> = audiobookDao.getAllAudiobooks()
    val allVideos: Flow<List<VideoItemEntity>> = videoDao.getAllVideos()
    val allDevices: Flow<List<DeviceEntity>> = deviceDao.getAllDevices()

    fun searchTracks(query: String): Flow<List<TrackEntity>> = mediaDao.searchTracks(query)

    suspend fun insertTrack(track: TrackEntity) = mediaDao.insertTrack(track)

    suspend fun updateTrack(track: TrackEntity) = mediaDao.updateTrack(track)

    suspend fun deleteTrack(track: TrackEntity) = mediaDao.deleteTrack(track)

    suspend fun createPlaylist(name: String, isSmart: Boolean = false, rulesJson: String = "", description: String = "") {
        val playlist = PlaylistEntity(
            id = UUID.randomUUID().toString(),
            name = name,
            isSmart = isSmart,
            rulesJson = rulesJson,
            description = description
        )
        mediaDao.insertPlaylist(playlist)
    }

    suspend fun addTrackToPlaylist(playlistId: String, trackId: String, currentCount: Int) {
        val item = PlaylistItemEntity(playlistId = playlistId, trackId = trackId, orderIndex = currentCount)
        mediaDao.insertPlaylistItem(item)
    }

    suspend fun deletePlaylist(playlist: PlaylistEntity) {
        mediaDao.deletePlaylist(playlist)
    }

    suspend fun updateEpisodeProgress(episode: PodcastEpisodeEntity, positionSeconds: Long, isPlayed: Boolean) {
        podcastDao.updateEpisode(episode.copy(playbackPositionSeconds = positionSeconds, isPlayed = isPlayed))
    }

    suspend fun updateAudiobookProgress(audiobook: AudiobookEntity, chapterIndex: Int, positionSeconds: Long, percentage: Float) {
        audiobookDao.updateAudiobook(audiobook.copy(currentChapterIndex = chapterIndex, playbackPositionSeconds = positionSeconds, completionPercentage = percentage))
    }

    suspend fun recordPlayHistory(trackId: String) {
        mediaDao.insertPlayHistory(PlayHistoryEntity(trackId = trackId, timestamp = System.currentTimeMillis()))
        val track = mediaDao.getTrackById(trackId)
        if (track != null) {
            mediaDao.updateTrack(track.copy(playCount = track.playCount + 1, lastPlayed = System.currentTimeMillis()))
        }
    }

    suspend fun updateDeviceSyncStatus(deviceId: String, status: String) {
        val deviceList = mutableListOf<DeviceEntity>()
        // Simple update
    }
}
