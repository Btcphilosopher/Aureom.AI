package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.sin

@Composable
fun MetalVisualizerCanvas(
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "metal_visualizer")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MacCardBg)
            .border(1.dp, AppleItunesRed.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "METAL AUDIO DSP SPECTRUM (60 FPS)",
                    color = AppleCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (isPlaying) "STATUS: REAL-TIME RUNNING" else "STATUS: PAUSED",
                    color = if (isPlaying) MacTrafficGreen else MacTextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                val barCount = 32
                val barGap = 6.dp.toPx()
                val totalWidth = size.width
                val barWidth = (totalWidth - (barGap * (barCount - 1))) / barCount
                val maxHeight = size.height

                for (i in 0 until barCount) {
                    val x = i * (barWidth + barGap)
                    val factor = if (isPlaying) {
                        (sin(phase + (i * 0.25f)) * 0.4f + 0.5f) * (0.3f + (i % 5) * 0.15f)
                    } else 0.15f

                    val barHeight = (maxHeight * factor).coerceIn(8.dp.toPx(), maxHeight)
                    val y = maxHeight - barHeight

                    val brush = Brush.verticalGradient(
                        colors = listOf(
                            AppleCyan,
                            AppleItunesRed,
                            ApplePurple
                        )
                    )

                    drawRect(
                        brush = brush,
                        topLeft = Offset(x, y),
                        size = Size(barWidth, barHeight)
                    )
                }
            }
        }
    }
}
