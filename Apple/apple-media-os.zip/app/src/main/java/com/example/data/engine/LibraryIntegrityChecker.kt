package com.example.data.engine

import com.example.data.model.TrackEntity

data class LibraryHealthReport(
    val totalTracks: Int,
    val missingFilesCount: Int,
    val duplicatesCount: Int,
    val unanalysedCount: Int,
    val brokenMetadataCount: Int,
    val totalDurationHours: Double,
    val totalSizeBytes: Long
)

object LibraryIntegrityChecker {

    fun auditLibrary(tracks: List<TrackEntity>): LibraryHealthReport {
        val total = tracks.size
        val missing = if (total > 0) 0 else 0
        val duplicates = DuplicateDetector.findPossibleDuplicates(tracks).size
        val unanalysed = tracks.count { it.bpm == 0.0 || it.key.isBlank() }
        val brokenMetadata = tracks.count { it.title.isBlank() || it.artist.isBlank() || it.genre.isBlank() }
        val totalSeconds = tracks.sumOf { it.durationSeconds }
        val totalBytes = tracks.sumOf { it.fileSize }

        return LibraryHealthReport(
            totalTracks = total,
            missingFilesCount = missing,
            duplicatesCount = duplicates,
            unanalysedCount = unanalysed,
            brokenMetadataCount = brokenMetadata,
            totalDurationHours = Math.round((totalSeconds / 3600.0) * 10) / 10.0,
            totalSizeBytes = totalBytes
        )
    }
}
