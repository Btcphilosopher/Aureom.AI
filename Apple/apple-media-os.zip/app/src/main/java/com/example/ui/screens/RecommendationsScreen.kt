package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Recommendation
import com.example.data.model.TrackEntity
import com.example.ui.theme.*

@Composable
fun RecommendationsScreen(
    recommendations: List<Recommendation>,
    onPlayTrack: (TrackEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MacWindowBg)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Psychology, contentDescription = null, tint = ApplePurple, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text("INTELLIGENT RECOMMENDATION ENGINE", color = MacTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("Contextual suggestions powered by audio descriptor similarity and listening history.", color = MacTextSecondary, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(recommendations) { rec ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPlayTrack(rec.track) },
                    colors = CardDefaults.cardColors(containerColor = MacCardBg),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, MacCardBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(ApplePurple.copy(alpha = 0.3f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = ApplePurple)
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(rec.track.title, color = MacTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("${rec.track.artist} • ${rec.track.album}", color = MacTextSecondary, fontSize = 11.sp)
                                Text(rec.reason, color = AppleCyan, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp))
                            }
                        }

                        Button(
                            onClick = { onPlayTrack(rec.track) },
                            colors = ButtonDefaults.buttonColors(containerColor = AppleItunesRed),
                            modifier = Modifier.testTag("play_recommended_track_button")
                        ) {
                            Text("Play Track", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
