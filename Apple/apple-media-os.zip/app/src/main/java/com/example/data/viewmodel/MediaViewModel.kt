package com.example.data.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.engine.*
import com.example.data.model.*
import com.example.data.repository.MediaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class PlayerState(
    val currentTrack: TrackEntity? = null,
    val isPlaying: Boolean = false,
    val currentPositionSeconds: Long = 0L,
    val durationSeconds: Long = 240L,
    val volume: Float = 0.8f,
    val isMuted: Boolean = false,
    val isShuffle: Boolean = false,
    val isRepeat: Boolean = false,
    val playbackType: String = "MUSIC" // MUSIC, PODCAST, VIDEO, AUDIOBOOK
)

class MediaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application, viewModelScope)
    val repository = MediaRepository(
        db.mediaDao(),
        db.podcastDao(),
        db.audiobookDao(),
        db.videoDao(),
        db.deviceDao()
    )

    // Navigation state
    private val _selectedSection = MutableStateFlow(NavigationSection.MUSIC_SONGS)
    val selectedSection: StateFlow<NavigationSection> = _selectedSection.asStateFlow()

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val allTracks: StateFlow<List<TrackEntity>> = repository.allTracks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val searchResults: StateFlow<List<TrackEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allTracks
            else repository.searchTracks(query)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allPlaylists: StateFlow<List<PlaylistEntity>> = repository.allPlaylists.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allPodcasts: StateFlow<List<PodcastShowEntity>> = repository.allPodcasts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allPodcastEpisodes: StateFlow<List<PodcastEpisodeEntity>> = repository.allPodcastEpisodes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allAudiobooks: StateFlow<List<AudiobookEntity>> = repository.allAudiobooks.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allVideos: StateFlow<List<VideoItemEntity>> = repository.allVideos.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allDevices: StateFlow<List<DeviceEntity>> = repository.allDevices.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Player State
    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    // Queue ("Up Next")
    private val _queue = MutableStateFlow<List<TrackEntity>>(emptyList())
    val queue: StateFlow<List<TrackEntity>> = _queue.asStateFlow()

    // UI overlays & modals
    val isMiniPlayerVisible = MutableStateFlow(false)
    val isFullScreenNowPlayingVisible = MutableStateFlow(false)
    val isQueueDrawerVisible = MutableStateFlow(false)
    val isVisualizerActive = MutableStateFlow(false)
    val isAiAssistantSheetVisible = MutableStateFlow(false)
    val isSyncPreviewVisible = MutableStateFlow(false)
    val editingTrack = MutableStateFlow<TrackEntity?>(null)
    val selectedDeviceForSync = MutableStateFlow<DeviceEntity?>(null)
    val currentSyncPreview = MutableStateFlow<SyncPreviewItem?>(null)

    // AI & Recommendations State
    val aiPromptText = MutableStateFlow("")
    val aiResponseText = MutableStateFlow<String?>(null)
    val aiProposedPlaylist = MutableStateFlow<AiPlaylistProposal?>(null)
    val recommendations = MutableStateFlow<List<Recommendation>>(emptyList())

    // Currently playing media title/artist info for video/podcast/audiobook
    val playingMediaTitle = MutableStateFlow("Midnight City")
    val playingMediaArtist = MutableStateFlow("M83")
    val playingMediaAlbum = MutableStateFlow("Hurry Up, We're Dreaming")

    init {
        // Initialize player with first track when tracks load
        viewModelScope.launch {
            allTracks.collect { tracks ->
                if (tracks.isNotEmpty() && _playerState.value.currentTrack == null) {
                    val first = tracks.first()
                    _playerState.value = _playerState.value.copy(
                        currentTrack = first,
                        durationSeconds = first.durationSeconds
                    )
                    _queue.value = tracks.drop(1)
                    updateRecommendations(first, tracks)
                }
            }
        }
    }

    fun selectNavigationSection(section: NavigationSection) {
        _selectedSection.value = section
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun playTrack(track: TrackEntity) {
        _playerState.value = _playerState.value.copy(
            currentTrack = track,
            isPlaying = true,
            currentPositionSeconds = 0L,
            durationSeconds = track.durationSeconds
        )
        playingMediaTitle.value = track.title
        playingMediaArtist.value = track.artist
        playingMediaAlbum.value = track.album

        viewModelScope.launch(Dispatchers.IO) {
            repository.recordPlayHistory(track.id)
            updateRecommendations(track, allTracks.value)
        }
    }

    fun playPodcastEpisode(episode: PodcastEpisodeEntity, showTitle: String) {
        playingMediaTitle.value = episode.title
        playingMediaArtist.value = showTitle
        playingMediaAlbum.value = "Podcast Episode"
        _playerState.value = _playerState.value.copy(
            isPlaying = true,
            currentPositionSeconds = episode.playbackPositionSeconds,
            durationSeconds = episode.durationSeconds,
            playbackType = "PODCAST"
        )
    }

    fun playAudiobook(audiobook: AudiobookEntity) {
        playingMediaTitle.value = audiobook.title
        playingMediaArtist.value = audiobook.author
        playingMediaAlbum.value = "Audiobook"
        _playerState.value = _playerState.value.copy(
            isPlaying = true,
            currentPositionSeconds = audiobook.playbackPositionSeconds,
            durationSeconds = audiobook.durationSeconds,
            playbackType = "AUDIOBOOK"
        )
    }

    fun playVideo(video: VideoItemEntity) {
        playingMediaTitle.value = video.title
        playingMediaArtist.value = video.genre
        playingMediaAlbum.value = video.category
        _playerState.value = _playerState.value.copy(
            isPlaying = true,
            currentPositionSeconds = 0L,
            durationSeconds = video.durationSeconds,
            playbackType = "VIDEO"
        )
    }

    fun togglePlayPause() {
        _playerState.value = _playerState.value.copy(isPlaying = !_playerState.value.isPlaying)
    }

    fun seekTo(seconds: Long) {
        _playerState.value = _playerState.value.copy(currentPositionSeconds = seconds)
    }

    fun nextTrack() {
        val q = _queue.value
        if (q.isNotEmpty()) {
            val next = q.first()
            _queue.value = q.drop(1)
            playTrack(next)
        }
    }

    fun previousTrack() {
        _playerState.value = _playerState.value.copy(currentPositionSeconds = 0L)
    }

    fun toggleShuffle() {
        _playerState.value = _playerState.value.copy(isShuffle = !_playerState.value.isShuffle)
    }

    fun toggleRepeat() {
        _playerState.value = _playerState.value.copy(isRepeat = !_playerState.value.isRepeat)
    }

    fun setVolume(vol: Float) {
        _playerState.value = _playerState.value.copy(volume = vol, isMuted = vol == 0f)
    }

    fun toggleMute() {
        val currentMuted = _playerState.value.isMuted
        _playerState.value = _playerState.value.copy(isMuted = !currentMuted)
    }

    fun addToQueue(track: TrackEntity) {
        _queue.value = _queue.value + track
    }

    fun removeFromQueue(track: TrackEntity) {
        _queue.value = _queue.value.filter { it.id != track.id }
    }

    fun clearQueue() {
        _queue.value = emptyList()
    }

    fun saveQueueAsPlaylist(playlistName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.createPlaylist(playlistName, isSmart = false, description = "Saved from current Up Next queue")
        }
    }

    fun updateRecommendations(current: TrackEntity, all: List<TrackEntity>) {
        recommendations.value = RecommendationEngine.generateRecommendations(current, all)
    }

    fun saveEditedMetadata(track: TrackEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTrack(track)
            editingTrack.value = null
        }
    }

    fun createNewPlaylist(name: String, isSmart: Boolean, rulesJson: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.createPlaylist(name, isSmart = isSmart, rulesJson = rulesJson)
        }
    }

    fun runAiQuery(prompt: String) {
        val tracks = allTracks.value
        if (prompt.contains("playlist", ignoreCase = true) || prompt.contains("evening", ignoreCase = true)) {
            val proposal = AiMediaAssistant.generateEveningPlaylistProposal(prompt, tracks)
            aiProposedPlaylist.value = proposal
            aiResponseText.value = "Generated a smart energy flow proposal for '${proposal.playlistTitle}'. Review and approve below:"
        } else {
            val (respText, matchingTracks) = AiMediaAssistant.processNaturalLanguageQuery(prompt, tracks)
            aiResponseText.value = respText
            if (matchingTracks.isNotEmpty()) {
                _searchQuery.value = prompt
            }
        }
    }

    fun approveAiPlaylist() {
        val proposal = aiProposedPlaylist.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.createPlaylist(proposal.playlistTitle, isSmart = false, description = proposal.description)
            aiProposedPlaylist.value = null
            aiResponseText.value = "Playlist '${proposal.playlistTitle}' saved successfully to your library!"
        }
    }

    fun prepareDeviceSync(device: DeviceEntity) {
        selectedDeviceForSync.value = device
        val preview = SyncEngine.generateSyncPlan(device, allTracks.value)
        currentSyncPreview.value = preview
        isSyncPreviewVisible.value = true
    }

    fun executeDeviceSync() {
        viewModelScope.launch(Dispatchers.IO) {
            val dev = selectedDeviceForSync.value ?: return@launch
            repository.updateDeviceSyncStatus(dev.id, "SYNCED")
            isSyncPreviewVisible.value = false
        }
    }

    fun toggleFavorite(track: TrackEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTrack(track.copy(isFavorite = !track.isFavorite))
        }
    }

    fun analyzeTrackWithPython(track: TrackEntity): AudioAnalysisResult {
        return PythonAnalysisEngine.analyzeTrack(track)
    }
}
