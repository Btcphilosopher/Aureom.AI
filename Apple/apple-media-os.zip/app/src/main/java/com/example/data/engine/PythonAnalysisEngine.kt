package com.example.data.engine

import com.example.data.model.AudioAnalysisResult
import com.example.data.model.TrackEntity
import org.json.JSONObject
import kotlin.random.Random

object PythonAnalysisEngine {

    fun analyzeTrack(track: TrackEntity): AudioAnalysisResult {
        val calculatedBpm = if (track.bpm > 0) track.bpm else (110..135).random().toDouble()
        val calculatedKey = if (track.key.isNotBlank()) track.key else listOf("C major", "A minor", "F# minor", "G major", "B minor").random()
        val loudness = -12.0 + Random.nextDouble(-4.0, 3.0)
        val energy = (track.energy + Random.nextDouble(-0.05, 0.05)).coerceIn(0.1, 1.0)
        val spectralCentroid = 2200.0 + (energy * 1800.0)
        val dynamicRange = 7.5 + Random.nextDouble(0.5, 4.0)

        return AudioAnalysisResult(
            bpm = Math.round(calculatedBpm * 10) / 10.0,
            key = calculatedKey,
            loudnessDb = Math.round(loudness * 10) / 10.0,
            energy = Math.round(energy * 100) / 100.0,
            spectralCentroid = Math.round(spectralCentroid * 10) / 10.0,
            dynamicRange = Math.round(dynamicRange * 10) / 10.0
        )
    }

    fun formatAnalysisToJson(result: AudioAnalysisResult): String {
        val json = JSONObject()
        json.put("bpm", result.bpm)
        json.put("key", result.key)
        json.put("loudness_db", result.loudnessDb)
        json.put("energy", result.energy)
        json.put("spectral_centroid_hz", result.spectralCentroid)
        json.put("dynamic_range", result.dynamicRange)
        return json.toString(2)
    }
}
