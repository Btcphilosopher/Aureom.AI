package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.engine.AiPlaylistProposal
import com.example.ui.theme.*

@Composable
fun AiAssistantSheet(
    promptText: String,
    onPromptChange: (String) -> Unit,
    responseText: String?,
    playlistProposal: AiPlaylistProposal?,
    onRunQuery: (String) -> Unit,
    onApprovePlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .width(520.dp)
                .heightIn(max = 620.dp)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, AppleBlue.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            color = MacHeaderBg
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Assistant",
                            tint = AppleCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "APPLE MEDIA.OS AI ASSISTANT",
                            color = MacTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MacTextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Prompt Input Box
                OutlinedTextField(
                    value = promptText,
                    onValueChange = onPromptChange,
                    placeholder = {
                        Text(
                            "e.g. 'Create a playlist for a 2-hour drive', 'Find high energy 120 BPM electronic tracks'...",
                            color = MacTextMuted,
                            fontSize = 12.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_prompt_input_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppleBlue,
                        unfocusedBorderColor = MacCardBorder,
                        focusedContainerColor = MacWindowBg,
                        unfocusedContainerColor = MacWindowBg,
                        focusedTextColor = MacTextPrimary,
                        unfocusedTextColor = MacTextPrimary
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = { onRunQuery(promptText) },
                            modifier = Modifier.testTag("submit_ai_prompt")
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Run Query", tint = AppleBlue)
                        }
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Quick Prompt Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SuggestionChip(
                        onClick = { onRunQuery("Create an evening playlist with increasing energy") },
                        label = { Text("Evening Mix", fontSize = 10.sp) }
                    )
                    SuggestionChip(
                        onClick = { onRunQuery("Find music around 120 BPM") },
                        label = { Text("120 BPM", fontSize = 10.sp) }
                    )
                    SuggestionChip(
                        onClick = { onRunQuery("Find my highest-rated electronic tracks") },
                        label = { Text("Top Rated Electronic", fontSize = 10.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // AI Response Text
                if (!responseText.isNullByBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MacWindowBg)
                            .border(0.5.dp, MacCardBorder, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = responseText ?: "",
                            color = MacTextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Playlist Proposal List & User Approval Workflow
                if (playlistProposal != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MacCardBg)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "PROPOSED PLAYLIST: ${playlistProposal.playlistTitle.uppercase()}",
                            color = AppleItunesRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = playlistProposal.description,
                            color = MacTextSecondary,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(playlistProposal.tracksWithReason) { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MacWindowBg)
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.track.title, color = MacTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text("${item.track.artist} • ${item.reason}", color = AppleCyan, fontSize = 10.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = onApprovePlaylist,
                            colors = ButtonDefaults.buttonColors(containerColor = AppleBlue),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("approve_ai_playlist_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Approve & Save Playlist", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

private fun String?.isNullByBlank(): Boolean {
    return this == null || this.isBlank()
}
