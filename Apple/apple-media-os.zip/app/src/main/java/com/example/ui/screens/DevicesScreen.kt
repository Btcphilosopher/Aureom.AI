package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.SyncEngine
import com.example.data.model.DeviceEntity
import com.example.ui.theme.*

@Composable
fun DevicesScreen(
    devices: List<DeviceEntity>,
    onPrepareSync: (DeviceEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MacWindowBg)
            .padding(16.dp)
    ) {
        Text("CONNECTED DEVICES & SYNC ENGINE", color = MacTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Public macOS API device abstraction supporting USB, Wi-Fi, and Mock Devices.", color = MacTextSecondary, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(devices) { dev ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.5.dp, MacCardBorder, RoundedCornerShape(10.dp)),
                    colors = CardDefaults.cardColors(containerColor = MacCardBg)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (dev.type) {
                                        "MAC" -> Icons.Default.Laptop
                                        "IPAD" -> Icons.Default.Tablet
                                        else -> Icons.Default.Smartphone
                                    },
                                    contentDescription = null,
                                    tint = AppleBlue,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(dev.name, color = MacTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Text("Connection: ${dev.connectionType} • Battery: ${dev.batteryLevel}%", color = MacTextSecondary, fontSize = 11.sp)
                                }
                            }

                            Button(
                                onClick = { onPrepareSync(dev) },
                                colors = ButtonDefaults.buttonColors(containerColor = AppleBlue),
                                modifier = Modifier.testTag("device_sync_button_${dev.id}")
                            ) {
                                Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sync Device", color = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Storage Bar Graph
                        val usedGb = SyncEngine.formatBytes(dev.usedStorageBytes)
                        val totalGb = SyncEngine.formatBytes(dev.capacityBytes)
                        val freeGb = SyncEngine.formatBytes(dev.capacityBytes - dev.usedStorageBytes)
                        val ratio = if (dev.capacityBytes > 0) dev.usedStorageBytes.toFloat() / dev.capacityBytes.toFloat() else 0f

                        Column {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Storage Capacity: $totalGb", color = MacTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Used: $usedGb | Free: $freeGb", color = AppleCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            LinearProgressIndicator(
                                progress = { ratio.coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(CircleShape),
                                color = AppleBlue,
                                trackColor = MacCardBorder
                            )
                        }
                    }
                }
            }
        }
    }
}
