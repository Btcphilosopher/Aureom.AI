package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AudiobookEntity
import com.example.ui.components.formatTimeSeconds
import com.example.ui.theme.*

@Composable
fun AudiobooksScreen(
    audiobooks: List<AudiobookEntity>,
    onPlayAudiobook: (AudiobookEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MacWindowBg)
            .padding(16.dp)
    ) {
        Text("AUDIOBOOK LIBRARY", color = MacTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Remembers playback chapter position, bookmarks, and completion percentage.", color = MacTextSecondary, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 220.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(audiobooks) { book ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPlayAudiobook(book) },
                    colors = CardDefaults.cardColors(containerColor = MacCardBg),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, MacCardBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(AppleBlue.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Book, contentDescription = null, tint = AppleBlue, modifier = Modifier.size(48.dp))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(book.title, color = MacTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("Author: ${book.author}", color = MacTextSecondary, fontSize = 11.sp)
                        Text("Narrator: ${book.narrator}", color = MacTextMuted, fontSize = 10.sp)

                        Spacer(modifier = Modifier.height(10.dp))

                        // Completion Progress Bar
                        LinearProgressIndicator(
                            progress = { book.completionPercentage },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(CircleShape),
                            color = AppleBlue,
                            trackColor = MacCardBorder
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Chapter ${book.currentChapterIndex + 1}", color = AppleCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("${(book.completionPercentage * 100).toInt()}% Done", color = MacTextSecondary, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}
