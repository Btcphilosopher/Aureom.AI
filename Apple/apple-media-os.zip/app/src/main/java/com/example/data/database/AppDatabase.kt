package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(
    entities = [
        TrackEntity::class,
        PlaylistEntity::class,
        PlaylistItemEntity::class,
        PodcastShowEntity::class,
        PodcastEpisodeEntity::class,
        AudiobookEntity::class,
        AudiobookChapterEntity::class,
        VideoItemEntity::class,
        DeviceEntity::class,
        PlayHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaDao(): MediaDao
    abstract fun podcastDao(): PodcastDao
    abstract fun audiobookDao(): AudiobookDao
    abstract fun videoDao(): VideoDao
    abstract fun deviceDao(): DeviceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "apple_media_os.db"
                )
                .addCallback(AppDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: AppDatabase) {
            val mediaDao = db.mediaDao()
            val podcastDao = db.podcastDao()
            val audiobookDao = db.audiobookDao()
            val videoDao = db.videoDao()
            val deviceDao = db.deviceDao()

            val now = System.currentTimeMillis()

            // Pre-populate Sample Music Library Tracks
            val sampleTracks = listOf(
                TrackEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Midnight City",
                    artist = "M83",
                    album = "Hurry Up, We're Dreaming",
                    genre = "Synthwave / Electronic",
                    year = 2011,
                    durationSeconds = 243,
                    bpm = 126.0,
                    key = "B minor",
                    rating = 5,
                    playCount = 142,
                    dateAdded = now - 864000000L,
                    lastPlayed = now - 3600000L,
                    artworkUri = null,
                    trackNumber = 1,
                    discNumber = 1,
                    composer = "Anthony Gonzalez",
                    comment = "Classic electronic masterpiece",
                    energy = 0.88,
                    dynamicRange = 9.2,
                    isFavorite = true,
                    lyrics = "Waiting in a car\nWaiting for a ride in the dark\nThe night city is on fire\nWaiting in a car\nWaiting for a ride in the dark"
                ),
                TrackEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Get Lucky (feat. Pharrell Williams)",
                    artist = "Daft Punk",
                    album = "Random Access Memories",
                    genre = "Electronic / Disco",
                    year = 2013,
                    durationSeconds = 248,
                    bpm = 116.0,
                    key = "F# minor",
                    rating = 5,
                    playCount = 289,
                    dateAdded = now - 1200000000L,
                    lastPlayed = now - 7200000L,
                    artworkUri = null,
                    trackNumber = 8,
                    discNumber = 1,
                    composer = "Thomas Bangalter, Guy-Manuel de Homem-Christo",
                    comment = "Grammy award winner",
                    energy = 0.82,
                    dynamicRange = 10.1,
                    isFavorite = true,
                    lyrics = "Like the legend of the phoenix\nAll ends with beginnings\nWhat keeps the planet spinning\nThe force from the beginning"
                ),
                TrackEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Instant Crush (feat. Julian Casablancas)",
                    artist = "Daft Punk",
                    album = "Random Access Memories",
                    genre = "Electronic",
                    year = 2013,
                    durationSeconds = 337,
                    bpm = 110.0,
                    key = "C# minor",
                    rating = 4,
                    playCount = 98,
                    dateAdded = now - 1100000000L,
                    lastPlayed = now - 86400000L,
                    artworkUri = null,
                    trackNumber = 5,
                    discNumber = 1,
                    composer = "Julian Casablancas, Thomas Bangalter",
                    energy = 0.74,
                    dynamicRange = 8.5,
                    isFavorite = false
                ),
                TrackEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Starboy",
                    artist = "The Weeknd",
                    album = "Starboy",
                    genre = "R&B / Pop",
                    year = 2016,
                    durationSeconds = 230,
                    bpm = 186.0,
                    key = "G major",
                    rating = 4,
                    playCount = 76,
                    dateAdded = now - 600000000L,
                    lastPlayed = now - 172800000L,
                    artworkUri = null,
                    trackNumber = 1,
                    discNumber = 1,
                    composer = "Abel Tesfaye",
                    energy = 0.79,
                    dynamicRange = 7.8,
                    isFavorite = true
                ),
                TrackEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Blinding Lights",
                    artist = "The Weeknd",
                    album = "After Hours",
                    genre = "Synthpop",
                    year = 2020,
                    durationSeconds = 200,
                    bpm = 171.0,
                    key = "F# minor",
                    rating = 5,
                    playCount = 310,
                    dateAdded = now - 400000000L,
                    lastPlayed = now - 1800000L,
                    artworkUri = null,
                    trackNumber = 4,
                    discNumber = 1,
                    composer = "Max Martin, Oscar Holter, Abel Tesfaye",
                    energy = 0.92,
                    dynamicRange = 8.0,
                    isFavorite = true,
                    lyrics = "I've been on my own for long enough\nMaybe you can show me how to love, maybe\nI'm going through withdrawals\nYou don't even have to do too much"
                ),
                TrackEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Reckless for My Love",
                    artist = "Tycho",
                    album = "Awake",
                    genre = "Ambient / Chillout",
                    year = 2014,
                    durationSeconds = 275,
                    bpm = 104.0,
                    key = "A major",
                    rating = 4,
                    playCount = 45,
                    dateAdded = now - 300000000L,
                    lastPlayed = now - 432000000L,
                    artworkUri = null,
                    trackNumber = 3,
                    discNumber = 1,
                    composer = "Scott Hansen",
                    energy = 0.45,
                    dynamicRange = 11.2,
                    isFavorite = false
                ),
                TrackEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Strobe",
                    artist = "deadmau5",
                    album = "For Lack of a Better Name",
                    genre = "Progressive House",
                    year = 2009,
                    durationSeconds = 637,
                    bpm = 128.0,
                    key = "G# minor",
                    rating = 5,
                    playCount = 188,
                    dateAdded = now - 1500000000L,
                    lastPlayed = now - 259200000L,
                    artworkUri = null,
                    trackNumber = 10,
                    discNumber = 1,
                    composer = "Joel Zimmerman",
                    energy = 0.85,
                    dynamicRange = 10.5,
                    isFavorite = true
                ),
                TrackEntity(
                    id = UUID.randomUUID().toString(),
                    title = "Opus",
                    artist = "Eric Prydz",
                    album = "Opus",
                    genre = "Progressive House",
                    year = 2016,
                    durationSeconds = 543,
                    bpm = 126.0,
                    key = "F minor",
                    rating = 5,
                    playCount = 120,
                    dateAdded = now - 500000000L,
                    lastPlayed = now - 864000000L,
                    artworkUri = null,
                    trackNumber = 1,
                    discNumber = 1,
                    composer = "Eric Prydz",
                    energy = 0.90,
                    dynamicRange = 9.8,
                    isFavorite = true
                )
            )

            mediaDao.insertTracks(sampleTracks)

            // Pre-populate Playlists & Smart Playlists
            val p1Id = UUID.randomUUID().toString()
            val p2Id = UUID.randomUUID().toString()
            mediaDao.insertPlaylist(
                PlaylistEntity(
                    id = p1Id,
                    name = "Late Night Electronic Drive",
                    isSmart = false,
                    description = "Chilled high-energy synthwave and electronic tracks"
                )
            )
            mediaDao.insertPlaylist(
                PlaylistEntity(
                    id = p2Id,
                    name = "Smart: High BPM Electronic (>= 120)",
                    isSmart = true,
                    rulesJson = """[{"field":"Genre","operator":"CONTAINS","value":"Electronic"},{"field":"BPM","operator":">=","value":"120"},{"field":"Rating","operator":">=","value":"4"}]""",
                    description = "Auto-filtered electronic tracks with BPM >= 120 and Rating >= 4"
                )
            )

            // Add items to standard playlist
            sampleTracks.take(4).forEachIndexed { index, track ->
                mediaDao.insertPlaylistItem(
                    PlaylistItemEntity(
                        playlistId = p1Id,
                        trackId = track.id,
                        orderIndex = index
                    )
                )
            }

            // Pre-populate Podcasts
            val podcast1Id = UUID.randomUUID().toString()
            val podcast2Id = UUID.randomUUID().toString()
            podcastDao.insertPodcastShow(
                PodcastShowEntity(
                    id = podcast1Id,
                    title = "The Mac&iOS Architecture Show",
                    author = "Apple Media.OS Labs",
                    description = "In-depth explorations of modern software engineering, AVFoundation, Metal graphics, and macOS architecture.",
                    artworkUri = null,
                    isSubscribed = true,
                    unplayedCount = 2,
                    category = "Technology"
                )
            )
            podcastDao.insertPodcastShow(
                PodcastShowEntity(
                    id = podcast2Id,
                    title = "Deep Tech & AI Daily",
                    author = "Future Computing Network",
                    description = "Daily digest of neural networks, spatial computing, C++ audio DSP, and edge performance optimization.",
                    artworkUri = null,
                    isSubscribed = true,
                    unplayedCount = 1,
                    category = "Science"
                )
            )

            podcastDao.insertEpisodes(
                listOf(
                    PodcastEpisodeEntity(
                        id = UUID.randomUUID().toString(),
                        showId = podcast1Id,
                        title = "Ep 104: The Future of AVFoundation & Low Latency Audio",
                        publishDate = now - 86400000L,
                        durationSeconds = 3734, // 1:02:14
                        playbackPositionSeconds = 2538, // 42:18
                        isDownloaded = true,
                        isPlayed = false,
                        summary = "Discussion on real-time sample buffers, audio graphs, and macOS CoreAudio integration."
                    ),
                    PodcastEpisodeEntity(
                        id = UUID.randomUUID().toString(),
                        showId = podcast1Id,
                        title = "Ep 103: Metal Shaders & Audio Visualizer Rendering",
                        publishDate = now - 604800000L,
                        durationSeconds = 2840,
                        playbackPositionSeconds = 0L,
                        isDownloaded = true,
                        isPlayed = true,
                        summary = "How to bind audio FFT spectral buffers into Metal compute shaders at 60 FPS."
                    ),
                    PodcastEpisodeEntity(
                        id = UUID.randomUUID().toString(),
                        showId = podcast2Id,
                        title = "Ep 42: On-Device Python AI & Music Recommendation Engines",
                        publishDate = now - 172800000L,
                        durationSeconds = 2410,
                        playbackPositionSeconds = 600,
                        isDownloaded = true,
                        isPlayed = false,
                        summary = "Building privacy-first recommendation models operating locally on music metadata."
                    )
                )
            )

            // Pre-populate Audiobooks
            val book1Id = UUID.randomUUID().toString()
            audiobookDao.insertAudiobook(
                AudiobookEntity(
                    id = book1Id,
                    title = "Steve Jobs: The Exclusive Biography",
                    author = "Walter Isaacson",
                    narrator = "Dylan Baker",
                    durationSeconds = 91800, // 25.5 hours
                    currentChapterIndex = 3,
                    playbackPositionSeconds = 1420,
                    artworkUri = null,
                    completionPercentage = 0.28f
                )
            )
            audiobookDao.insertChapters(
                listOf(
                    AudiobookChapterEntity(
                        id = UUID.randomUUID().toString(),
                        audiobookId = book1Id,
                        title = "Chapter 1: Childhood & Silicon Valley Beginnings",
                        durationSeconds = 3600,
                        chapterIndex = 1
                    ),
                    AudiobookChapterEntity(
                        id = UUID.randomUUID().toString(),
                        audiobookId = book1Id,
                        title = "Chapter 2: The Odd Couple - Jobs and Wozniak",
                        durationSeconds = 4200,
                        chapterIndex = 2
                    ),
                    AudiobookChapterEntity(
                        id = UUID.randomUUID().toString(),
                        audiobookId = book1Id,
                        title = "Chapter 3: The Birth of Apple Computer",
                        durationSeconds = 4800,
                        chapterIndex = 3
                    )
                )
            )

            // Pre-populate Video Library
            videoDao.insertVideos(
                listOf(
                    VideoItemEntity(
                        id = UUID.randomUUID().toString(),
                        title = "Apple Keynote - Spatial Computing & Mac OS",
                        category = "FILM",
                        year = 2024,
                        durationSeconds = 7200,
                        resolution = "4K HDR Dolby Vision",
                        genre = "Technology Documentary",
                        artworkUri = null
                    ),
                    VideoItemEntity(
                        id = UUID.randomUUID().toString(),
                        title = "Daft Punk - Alive 2007 Concert Film",
                        category = "MUSIC_VIDEO",
                        year = 2007,
                        durationSeconds = 5200,
                        resolution = "1080p HD",
                        genre = "Live Music Concert",
                        artworkUri = null
                    ),
                    VideoItemEntity(
                        id = UUID.randomUUID().toString(),
                        title = "Silicon Valley Stories - Season 1 Ep 1",
                        category = "TV_SHOW",
                        year = 2022,
                        durationSeconds = 2700,
                        resolution = "4K HDR",
                        genre = "Drama",
                        artworkUri = null,
                        seasonNumber = 1,
                        episodeNumber = 1
                    )
                )
            )

            // Pre-populate Devices
            deviceDao.insertDevice(
                DeviceEntity(
                    id = "mac_local",
                    name = "MacBook Pro (M3 Max)",
                    type = "MAC",
                    capacityBytes = 1000000000000L, // 1 TB
                    usedStorageBytes = 412000000000L, // 412 GB
                    batteryLevel = 94,
                    connectionType = "SYSTEM",
                    syncStatus = "LOCAL HOST"
                )
            )
            deviceDao.insertDevice(
                DeviceEntity(
                    id = "iphone_15_pro",
                    name = "iPhone 15 Pro",
                    type = "IPHONE",
                    capacityBytes = 128000000000L, // 128 GB
                    usedStorageBytes = 74000000000L, // 74 GB (Free: 54 GB)
                    batteryLevel = 88,
                    connectionType = "USB-C",
                    syncStatus = "READY TO SYNC"
                )
            )
            deviceDao.insertDevice(
                DeviceEntity(
                    id = "ipad_pro_m2",
                    name = "iPad Pro 12.9\"",
                    type = "IPAD",
                    capacityBytes = 256000000000L, // 256 GB
                    usedStorageBytes = 110000000000L, // 110 GB
                    batteryLevel = 76,
                    connectionType = "Wi-Fi 6E",
                    syncStatus = "CONNECTED"
                )
            )
        }
    }
}
