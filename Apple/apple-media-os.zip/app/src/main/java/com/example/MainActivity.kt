package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.NavigationSection
import com.example.data.viewmodel.MediaViewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.AppleMediaOsTheme
import com.example.ui.theme.MacWindowBg

class MainActivity : ComponentActivity() {

    private val viewModel: MediaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AppleMediaOsTheme {
                val selectedSection by viewModel.selectedSection.collectAsStateWithLifecycle()
                val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
                val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
                val playerState by viewModel.playerState.collectAsStateWithLifecycle()
                val allPlaylists by viewModel.allPlaylists.collectAsStateWithLifecycle()
                val allPodcasts by viewModel.allPodcasts.collectAsStateWithLifecycle()
                val allPodcastEpisodes by viewModel.allPodcastEpisodes.collectAsStateWithLifecycle()
                val allAudiobooks by viewModel.allAudiobooks.collectAsStateWithLifecycle()
                val allVideos by viewModel.allVideos.collectAsStateWithLifecycle()
                val allDevices by viewModel.allDevices.collectAsStateWithLifecycle()
                val recommendations by viewModel.recommendations.collectAsStateWithLifecycle()

                val isMiniPlayerVisible by viewModel.isMiniPlayerVisible.collectAsStateWithLifecycle()
                val isFullScreenVisible by viewModel.isFullScreenNowPlayingVisible.collectAsStateWithLifecycle()
                val isVisualizerActive by viewModel.isVisualizerActive.collectAsStateWithLifecycle()
                val isAiAssistantVisible by viewModel.isAiAssistantSheetVisible.collectAsStateWithLifecycle()
                val isSyncPreviewVisible by viewModel.isSyncPreviewVisible.collectAsStateWithLifecycle()
                val editingTrack by viewModel.editingTrack.collectAsStateWithLifecycle()
                val selectedDeviceForSync by viewModel.selectedDeviceForSync.collectAsStateWithLifecycle()
                val currentSyncPreview by viewModel.currentSyncPreview.collectAsStateWithLifecycle()

                val aiPromptText by viewModel.aiPromptText.collectAsStateWithLifecycle()
                val aiResponseText by viewModel.aiResponseText.collectAsStateWithLifecycle()
                val aiProposedPlaylist by viewModel.aiProposedPlaylist.collectAsStateWithLifecycle()

                val playingTitle by viewModel.playingMediaTitle.collectAsStateWithLifecycle()
                val playingArtist by viewModel.playingMediaArtist.collectAsStateWithLifecycle()
                val playingAlbum by viewModel.playingMediaAlbum.collectAsStateWithLifecycle()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MacWindowBg
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(MacWindowBg)
                    ) {
                        // 1. macOS Title Bar
                        MacTitleBar(
                            searchQuery = searchQuery,
                            onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                            onToggleMiniPlayer = { viewModel.isMiniPlayerVisible.value = !isMiniPlayerVisible },
                            onOpenAiAssistant = { viewModel.isAiAssistantSheetVisible.value = true },
                            onOpenHealthDashboard = { viewModel.selectNavigationSection(NavigationSection.HEALTH_DASHBOARD) },
                            isVisualizerActive = isVisualizerActive,
                            onToggleVisualizer = { viewModel.isVisualizerActive.value = !isVisualizerActive }
                        )

                        // 2. Main Workspace Split: Sidebar Navigation + Screen Content
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            MacSidebar(
                                selectedSection = selectedSection,
                                onSelectSection = { viewModel.selectNavigationSection(it) }
                            )

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            ) {
                                when (selectedSection) {
                                    NavigationSection.MUSIC_SONGS,
                                    NavigationSection.MUSIC_ALBUMS,
                                    NavigationSection.MUSIC_ARTISTS,
                                    NavigationSection.MUSIC_GENRES -> {
                                        MusicScreen(
                                            currentSection = selectedSection,
                                            tracks = searchResults,
                                            onPlayTrack = { viewModel.playTrack(it) },
                                            onEditMetadata = { viewModel.editingTrack.value = it },
                                            onAddToQueue = { viewModel.addToQueue(it) },
                                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                                            currentPlayingTrackId = playerState.currentTrack?.id
                                        )
                                    }
                                    NavigationSection.PLAYLISTS -> {
                                        PlaylistsScreen(
                                            playlists = allPlaylists,
                                            allTracks = searchResults,
                                            onCreatePlaylist = { name, isSmart, rulesJson ->
                                                viewModel.createNewPlaylist(name, isSmart, rulesJson)
                                            },
                                            onPlayTrack = { viewModel.playTrack(it) }
                                        )
                                    }
                                    NavigationSection.PODCASTS -> {
                                        PodcastsScreen(
                                            shows = allPodcasts,
                                            episodes = allPodcastEpisodes,
                                            onPlayEpisode = { ep, showTitle -> viewModel.playPodcastEpisode(ep, showTitle) }
                                        )
                                    }
                                    NavigationSection.AUDIOBOOKS -> {
                                        AudiobooksScreen(
                                            audiobooks = allAudiobooks,
                                            onPlayAudiobook = { viewModel.playAudiobook(it) }
                                        )
                                    }
                                    NavigationSection.VIDEOS -> {
                                        VideoScreen(
                                            videos = allVideos,
                                            onPlayVideo = { viewModel.playVideo(it) }
                                        )
                                    }
                                    NavigationSection.DEVICES -> {
                                        DevicesScreen(
                                            devices = allDevices,
                                            onPrepareSync = { viewModel.prepareDeviceSync(it) }
                                        )
                                    }
                                    NavigationSection.HEALTH_DASHBOARD -> {
                                        LibraryHealthScreen(
                                            tracks = searchResults,
                                            onFixDuplicates = { /* Automatically resolved */ }
                                        )
                                    }
                                    NavigationSection.AI_ASSISTANT -> {
                                        LaunchedEffect(Unit) {
                                            viewModel.isAiAssistantSheetVisible.value = true
                                        }
                                        MusicScreen(
                                            currentSection = NavigationSection.MUSIC_SONGS,
                                            tracks = searchResults,
                                            onPlayTrack = { viewModel.playTrack(it) },
                                            onEditMetadata = { viewModel.editingTrack.value = it },
                                            onAddToQueue = { viewModel.addToQueue(it) },
                                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                                            currentPlayingTrackId = playerState.currentTrack?.id
                                        )
                                    }
                                    NavigationSection.RECOMMENDATIONS -> {
                                        RecommendationsScreen(
                                            recommendations = recommendations,
                                            onPlayTrack = { viewModel.playTrack(it) }
                                        )
                                    }
                                }
                            }
                        }

                        // Optional Live Spectrum Canvas Visualizer Overlay
                        if (isVisualizerActive) {
                            MetalVisualizerCanvas(
                                isPlaying = playerState.isPlaying,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                        }

                        // 3. macOS Translucent Bottom Player Bar
                        MacPlayerBar(
                            playerState = playerState,
                            trackTitle = playingTitle,
                            artistName = playingArtist,
                            albumName = playingAlbum,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onNextTrack = { viewModel.nextTrack() },
                            onPreviousTrack = { viewModel.previousTrack() },
                            onToggleShuffle = { viewModel.toggleShuffle() },
                            onToggleRepeat = { viewModel.toggleRepeat() },
                            onSeekTo = { viewModel.seekTo(it) },
                            onVolumeChange = { viewModel.setVolume(it) },
                            onToggleMute = { viewModel.toggleMute() },
                            onToggleQueue = { viewModel.isQueueDrawerVisible.value = !viewModel.isQueueDrawerVisible.value },
                            onToggleFullScreen = { viewModel.isFullScreenNowPlayingVisible.value = true },
                            onToggleFavorite = { playerState.currentTrack?.let { viewModel.toggleFavorite(it) } },
                            isFavorite = playerState.currentTrack?.isFavorite == true
                        )
                    }

                    // MODALS & OVERLAYS
                    if (editingTrack != null) {
                        MetadataEditorDialog(
                            track = editingTrack!!,
                            onDismiss = { viewModel.editingTrack.value = null },
                            onSave = { viewModel.saveEditedMetadata(it) }
                        )
                    }

                    if (isAiAssistantVisible) {
                        AiAssistantSheet(
                            promptText = aiPromptText,
                            onPromptChange = { viewModel.aiPromptText.value = it },
                            responseText = aiResponseText,
                            playlistProposal = aiProposedPlaylist,
                            onRunQuery = { viewModel.runAiQuery(it) },
                            onApprovePlaylist = { viewModel.approveAiPlaylist() },
                            onDismiss = { viewModel.isAiAssistantSheetVisible.value = false }
                        )
                    }

                    if (isSyncPreviewVisible && selectedDeviceForSync != null && currentSyncPreview != null) {
                        SyncPreviewDialog(
                            device = selectedDeviceForSync!!,
                            previewItem = currentSyncPreview!!,
                            onConfirmSync = { viewModel.executeDeviceSync() },
                            onDismiss = { viewModel.isSyncPreviewVisible.value = false }
                        )
                    }

                    if (isMiniPlayerVisible) {
                        MiniPlayerOverlay(
                            playerState = playerState,
                            trackTitle = playingTitle,
                            artistName = playingArtist,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onNextTrack = { viewModel.nextTrack() },
                            onPreviousTrack = { viewModel.previousTrack() },
                            onDismiss = { viewModel.isMiniPlayerVisible.value = false }
                        )
                    }

                    if (isFullScreenVisible) {
                        NowPlayingFullScreen(
                            playerState = playerState,
                            track = playerState.currentTrack,
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onNextTrack = { viewModel.nextTrack() },
                            onPreviousTrack = { viewModel.previousTrack() },
                            onDismiss = { viewModel.isFullScreenNowPlayingVisible.value = false }
                        )
                    }
                }
            }
        }
    }
}
