package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NavigationSection
import com.example.data.model.TrackEntity
import com.example.ui.components.formatTimeSeconds
import com.example.ui.theme.*

@Composable
fun MusicScreen(
    currentSection: NavigationSection,
    tracks: List<TrackEntity>,
    onPlayTrack: (TrackEntity) -> Unit,
    onEditMetadata: (TrackEntity) -> Unit,
    onAddToQueue: (TrackEntity) -> Unit,
    onToggleFavorite: (TrackEntity) -> Unit,
    currentPlayingTrackId: String?
) {
    var viewMode by remember { mutableStateOf("SONGS") } // SONGS, ALBUMS, ARTISTS
    var selectedGenreFilter by remember { mutableStateOf("ALL") }
    var sortColumn by remember { mutableStateOf("TITLE") }
    var sortAscending by remember { mutableStateOf(true) }

    // Multi-select batch operations state
    var selectedTrackIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var isBatchModeActive by remember { mutableStateOf(false) }

    val genres = remember(tracks) {
        listOf("ALL") + tracks.map { it.genre.split("/").first().trim() }.distinct().sorted()
    }

    val filteredTracks = remember(tracks, selectedGenreFilter, currentSection, sortColumn, sortAscending) {
        var list = when (currentSection) {
            NavigationSection.MUSIC_ALBUMS -> tracks
            NavigationSection.MUSIC_ARTISTS -> tracks
            else -> tracks
        }

        if (selectedGenreFilter != "ALL") {
            list = list.filter { it.genre.contains(selectedGenreFilter, ignoreCase = true) }
        }

        when (sortColumn) {
            "TITLE" -> list.sortedWith(if (sortAscending) compareBy { it.title } else compareByDescending { it.title })
            "ARTIST" -> list.sortedWith(if (sortAscending) compareBy { it.artist } else compareByDescending { it.artist })
            "ALBUM" -> list.sortedWith(if (sortAscending) compareBy { it.album } else compareByDescending { it.album })
            "BPM" -> list.sortedWith(if (sortAscending) compareBy { it.bpm } else compareByDescending { it.bpm })
            "RATING" -> list.sortedWith(if (sortAscending) compareBy { it.rating } else compareByDescending { it.rating })
            "PLAY_COUNT" -> list.sortedWith(if (sortAscending) compareBy { it.playCount } else compareByDescending { it.playCount })
            else -> list
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MacWindowBg)
            .padding(16.dp)
    ) {
        // TOP CONTROL HEADER: Tab toggle, Genre Filter, Batch Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // View mode switch buttons
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .border(0.5.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(20.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                listOf("SONGS", "ALBUMS", "ARTISTS").forEach { mode ->
                    val isSel = (currentSection == NavigationSection.MUSIC_SONGS && mode == "SONGS") ||
                            (currentSection == NavigationSection.MUSIC_ALBUMS && mode == "ALBUMS") ||
                            (currentSection == NavigationSection.MUSIC_ARTISTS && mode == "ARTISTS") ||
                            (viewMode == mode)

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (isSel) Color.White.copy(alpha = 0.22f) else Color.Transparent)
                            .then(
                                if (isSel) Modifier.border(0.5.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(18.dp))
                                else Modifier
                            )
                            .clickable { viewMode = mode }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = mode,
                            color = if (isSel) Color.White else MacTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Genre Dropdown / Filter Chips
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Genre:", color = MacTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                genres.take(5).forEach { g ->
                    FilterChip(
                        selected = selectedGenreFilter == g,
                        onClick = { selectedGenreFilter = g },
                        label = { Text(g, fontSize = 11.sp) }
                    )
                }

                if (selectedTrackIds.isNotEmpty()) {
                    Button(
                        onClick = {
                            // Clear selection batch action
                            selectedTrackIds = emptySet()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AppleBlue),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("${selectedTrackIds.size} Selected", fontSize = 11.sp, color = Color.White)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // VIEW CONTENT: ALBUMS GRID vs SONGS TABLE
        if (viewMode == "ALBUMS" || currentSection == NavigationSection.MUSIC_ALBUMS) {
            val albums = remember(filteredTracks) {
                filteredTracks.groupBy { it.album }
            }

            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 140.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(albums.keys.toList()) { albumName ->
                    val albumTracks = albums[albumName] ?: emptyList()
                    val firstTrack = albumTracks.firstOrNull()

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { firstTrack?.let { onPlayTrack(it) } },
                        colors = CardDefaults.cardColors(containerColor = MacCardBg),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, MacCardBorder)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AppleItunesRed.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Album,
                                    contentDescription = null,
                                    tint = AppleItunesRed,
                                    modifier = Modifier.size(48.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = albumName,
                                color = MacTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = firstTrack?.artist ?: "Unknown Artist",
                                color = MacTextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${albumTracks.size} tracks",
                                color = AppleCyan,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        } else {
            // SONGS MULTI-COLUMN TABLE VIEW
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MacCardBg)
                    .border(0.5.dp, MacCardBorder, RoundedCornerShape(8.dp))
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .background(MacHeaderBg)
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TableHeaderCell("Title", Modifier.weight(2.5f)) {
                        if (sortColumn == "TITLE") sortAscending = !sortAscending else { sortColumn = "TITLE"; sortAscending = true }
                    }
                    TableHeaderCell("Artist", Modifier.weight(1.8f)) {
                        if (sortColumn == "ARTIST") sortAscending = !sortAscending else { sortColumn = "ARTIST"; sortAscending = true }
                    }
                    TableHeaderCell("Album", Modifier.weight(2f)) {
                        if (sortColumn == "ALBUM") sortAscending = !sortAscending else { sortColumn = "ALBUM"; sortAscending = true }
                    }
                    TableHeaderCell("Genre", Modifier.weight(1.5f))
                    TableHeaderCell("BPM", Modifier.width(60.dp)) {
                        if (sortColumn == "BPM") sortAscending = !sortAscending else { sortColumn = "BPM"; sortAscending = true }
                    }
                    TableHeaderCell("Key", Modifier.width(70.dp))
                    TableHeaderCell("Rating", Modifier.width(80.dp)) {
                        if (sortColumn == "RATING") sortAscending = !sortAscending else { sortColumn = "RATING"; sortAscending = true }
                    }
                    TableHeaderCell("Duration", Modifier.width(65.dp))
                    TableHeaderCell("Actions", Modifier.width(80.dp))
                }

                Divider(color = MacCardBorder, thickness = 0.5.dp)

                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredTracks) { track ->
                        val isPlaying = track.id == currentPlayingTrackId
                        val isSelected = selectedTrackIds.contains(track.id)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .background(
                                    when {
                                        isPlaying -> AppleItunesRed.copy(alpha = 0.25f)
                                        isSelected -> AppleBlue.copy(alpha = 0.2f)
                                        else -> Color.Transparent
                                    }
                                )
                                .clickable { onPlayTrack(track) }
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Title column with playing icon
                            Row(modifier = Modifier.weight(2.5f), verticalAlignment = Alignment.CenterVertically) {
                                if (isPlaying) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Playing",
                                        tint = AppleItunesRed,
                                        modifier = Modifier.size(16.dp).padding(end = 4.dp)
                                    )
                                }
                                Text(
                                    text = track.title,
                                    color = if (isPlaying) AppleItunesRed else MacTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = if (isPlaying) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Text(track.artist, color = MacTextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.8f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(track.album, color = MacTextSecondary, fontSize = 11.sp, modifier = Modifier.weight(2f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(track.genre, color = MacTextMuted, fontSize = 11.sp, modifier = Modifier.weight(1.5f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${track.bpm.toInt()}", color = AppleCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(60.dp))
                            Text(track.key, color = MacTextSecondary, fontSize = 11.sp, modifier = Modifier.width(70.dp))

                            // Rating stars
                            Row(modifier = Modifier.width(80.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("★".repeat(track.rating), color = Color(0xFFFFD700), fontSize = 11.sp)
                            }

                            Text(formatTimeSeconds(track.durationSeconds), color = MacTextMuted, fontSize = 11.sp, modifier = Modifier.width(65.dp))

                            // Action buttons (Edit Metadata, Queue)
                            Row(modifier = Modifier.width(80.dp), horizontalArrangement = Arrangement.End) {
                                IconButton(
                                    onClick = { onEditMetadata(track) },
                                    modifier = Modifier.size(26.dp).testTag("edit_track_metadata_button")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit Tags", tint = MacTextMuted, modifier = Modifier.size(14.dp))
                                }
                                IconButton(
                                    onClick = { onAddToQueue(track) },
                                    modifier = Modifier.size(26.dp).testTag("add_to_queue_button")
                                ) {
                                    Icon(Icons.Default.PlaylistAdd, contentDescription = "Add to Queue", tint = MacTextMuted, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                        Divider(color = MacCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun TableHeaderCell(
    title: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Box(
        modifier = modifier.then(
            if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
        ),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = title,
            color = MacTextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}
