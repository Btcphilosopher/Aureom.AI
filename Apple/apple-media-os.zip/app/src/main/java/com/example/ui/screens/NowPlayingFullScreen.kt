package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.TrackEntity
import com.example.data.viewmodel.PlayerState
import com.example.ui.components.MetalVisualizerCanvas
import com.example.ui.components.formatTimeSeconds
import com.example.ui.theme.*

@Composable
fun NowPlayingFullScreen(
    playerState: PlayerState,
    track: TrackEntity?,
    onTogglePlayPause: () -> Unit,
    onNextTrack: () -> Unit,
    onPreviousTrack: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(MacWindowBg)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MacWindowBg)
                    .padding(24.dp)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = AppleItunesRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("NOW PLAYING", color = MacTextMuted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("exit_fullscreen_now_playing_button")) {
                        Icon(Icons.Default.Close, contentDescription = "Exit Full Screen", tint = MacTextPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    // LEFT: Giant Album Artwork & Main Details
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(240.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(AppleItunesRed.copy(alpha = 0.3f))
                                .border(1.dp, AppleItunesRed, RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = AppleItunesRed, modifier = Modifier.size(96.dp))
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = track?.title ?: "Midnight City",
                            color = MacTextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "${track?.artist ?: "M83"} • ${track?.album ?: "Hurry Up, We're Dreaming"}",
                            color = MacTextSecondary,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Spectrum Visualizer
                        MetalVisualizerCanvas(
                            isPlaying = playerState.isPlaying,
                            modifier = Modifier.width(320.dp)
                        )
                    }

                    // RIGHT: Synchronized Lyrics Panel
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MacCardBg)
                            .border(0.5.dp, MacCardBorder, RoundedCornerShape(12.dp))
                            .padding(20.dp)
                    ) {
                        Text("SYNCHRONIZED LYRICS", color = AppleCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        val lyricsText = track?.lyrics?.ifBlank { null }
                            ?: "Waiting for the siren sounds\nJust to know that we're all right\nClear the grid, sweep the area\nLooking out across the night\n\nThe city is my church\nIt wraps me in the night\n\nWaiting in a car\nWaiting for a ride in the dark..."

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = lyricsText,
                                color = MacTextPrimary,
                                fontSize = 14.sp,
                                lineHeight = 24.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Full Transport Controls Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MacHeaderBg)
                        .padding(horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(formatTimeSeconds(playerState.currentPositionSeconds), color = MacTextMuted, fontSize = 12.sp)

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        IconButton(onClick = onPreviousTrack) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = null, tint = MacTextPrimary, modifier = Modifier.size(28.dp))
                        }
                        IconButton(
                            onClick = onTogglePlayPause,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(AppleItunesRed)
                        ) {
                            Icon(
                                if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        IconButton(onClick = onNextTrack) {
                            Icon(Icons.Default.SkipNext, contentDescription = null, tint = MacTextPrimary, modifier = Modifier.size(28.dp))
                        }
                    }

                    Text(formatTimeSeconds(playerState.durationSeconds), color = MacTextMuted, fontSize = 12.sp)
                }
            }
        }
    }
}
