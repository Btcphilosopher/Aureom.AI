package com.example.data.engine

import com.example.data.model.Recommendation
import com.example.data.model.TrackEntity
import kotlin.math.abs

object RecommendationEngine {

    fun generateRecommendations(
        currentTrack: TrackEntity?,
        allTracks: List<TrackEntity>
    ): List<Recommendation> {
        if (allTracks.isEmpty()) return emptyList()

        val seed = currentTrack ?: allTracks.first()
        val candidates = allTracks.filter { it.id != seed.id }

        val recommendations = mutableListOf<Recommendation>()

        candidates.forEach { candidate ->
            var score = 0
            var reason = ""

            // Artist match
            if (candidate.artist.equals(seed.artist, ignoreCase = true)) {
                score += 50
                reason = "Same artist (${seed.artist})"
            }
            // Tempo / BPM match
            else if (abs(candidate.bpm - seed.bpm) <= 8.0) {
                score += 40
                reason = "Similar tempo (~${seed.bpm.toInt()} BPM)"
            }
            // Genre match
            else if (candidate.genre.contains(seed.genre.split("/").first(), ignoreCase = true)) {
                score += 35
                reason = "Same genre (${candidate.genre})"
            }
            // High rating or play count match
            else if (candidate.rating >= 4 && candidate.playCount > 50) {
                score += 25
                reason = "Top-rated in your library"
            }
            // Energy match
            else if (abs(candidate.energy - seed.energy) <= 0.15) {
                score += 20
                reason = "Matching energy curve (${(candidate.energy * 100).toInt()}%)"
            } else {
                score += 10
                reason = "Frequently played together"
            }

            if (score > 15) {
                recommendations.add(Recommendation(candidate, "Recommended because: $reason"))
            }
        }

        return recommendations.sortedByDescending { it.track.rating }.take(10)
    }
}
