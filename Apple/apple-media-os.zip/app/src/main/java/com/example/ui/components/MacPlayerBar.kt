package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TrackEntity
import com.example.data.viewmodel.PlayerState
import com.example.ui.theme.*

@Composable
fun MacPlayerBar(
    playerState: PlayerState,
    trackTitle: String,
    artistName: String,
    albumName: String,
    onTogglePlayPause: () -> Unit,
    onNextTrack: () -> Unit,
    onPreviousTrack: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onToggleMute: () -> Unit,
    onToggleQueue: () -> Unit,
    onToggleFullScreen: () -> Unit,
    onToggleFavorite: () -> Unit,
    isFavorite: Boolean
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(76.dp)
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .border(width = 0.5.dp, color = Color.White.copy(alpha = 0.18f), shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)),
        color = Color.White.copy(alpha = 0.08f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // LEFT: Track Artwork & Title / Artist Info
            Row(
                modifier = Modifier.width(220.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(AppleItunesRed.copy(alpha = 0.3f))
                        .border(0.5.dp, MacCardBorder, RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "Track Artwork",
                        tint = AppleItunesRed,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = trackTitle.ifBlank { "No Track Selected" },
                        color = MacTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "$artistName • $albumName",
                        color = MacTextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(32.dp).testTag("favorite_button")
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite Track",
                        tint = if (isFavorite) AppleItunesRed else MacTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // CENTER: Playback Transport Controls & Progress Slider
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Control Buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(
                        onClick = onToggleShuffle,
                        modifier = Modifier.size(28.dp).testTag("shuffle_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shuffle,
                            contentDescription = "Shuffle",
                            tint = if (playerState.isShuffle) AppleItunesRed else MacTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onPreviousTrack,
                        modifier = Modifier.size(32.dp).testTag("prev_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Previous Track",
                            tint = MacTextPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    IconButton(
                        onClick = onTogglePlayPause,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(AppleItunesRed)
                            .testTag("play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    IconButton(
                        onClick = onNextTrack,
                        modifier = Modifier.size(32.dp).testTag("next_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next Track",
                            tint = MacTextPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    IconButton(
                        onClick = onToggleRepeat,
                        modifier = Modifier.size(28.dp).testTag("repeat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Repeat,
                            contentDescription = "Repeat",
                            tint = if (playerState.isRepeat) AppleItunesRed else MacTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Progress Bar & Time Stamps
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatTimeSeconds(playerState.currentPositionSeconds),
                        color = MacTextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )

                    val progressRatio = if (playerState.durationSeconds > 0) {
                        playerState.currentPositionSeconds.toFloat() / playerState.durationSeconds.toFloat()
                    } else 0f

                    Slider(
                        value = progressRatio.coerceIn(0f, 1f),
                        onValueChange = { ratio ->
                            onSeekTo((ratio * playerState.durationSeconds).toLong())
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = AppleItunesRed,
                            activeTrackColor = AppleItunesRed,
                            inactiveTrackColor = MacCardBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(18.dp)
                            .padding(horizontal = 8.dp)
                            .testTag("playback_progress_slider")
                    )

                    Text(
                        text = formatTimeSeconds(playerState.durationSeconds),
                        color = MacTextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // RIGHT: Volume Controls, Queue & Fullscreen Button
            Row(
                modifier = Modifier.width(220.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier.size(28.dp).testTag("mute_button")
                ) {
                    Icon(
                        imageVector = if (playerState.isMuted || playerState.volume == 0f) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Volume Mute",
                        tint = MacTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Slider(
                    value = if (playerState.isMuted) 0f else playerState.volume,
                    onValueChange = onVolumeChange,
                    colors = SliderDefaults.colors(
                        thumbColor = AppleBlue,
                        activeTrackColor = AppleBlue,
                        inactiveTrackColor = MacCardBorder
                    ),
                    modifier = Modifier
                        .width(70.dp)
                        .height(18.dp)
                        .testTag("volume_slider")
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = onToggleQueue,
                    modifier = Modifier.size(32.dp).testTag("queue_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.QueueMusic,
                        contentDescription = "Up Next Queue",
                        tint = MacTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onToggleFullScreen,
                    modifier = Modifier.size(32.dp).testTag("fullscreen_now_playing_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Fullscreen,
                        contentDescription = "Full Screen Now Playing",
                        tint = MacTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

fun formatTimeSeconds(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return "%02d:%02d".format(m, s)
}
