package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NavigationSection
import com.example.ui.theme.*

@Composable
fun MacSidebar(
    selectedSection: NavigationSection,
    onSelectSection: (NavigationSection) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(220.dp)
            .fillMaxHeight()
            .background(MacSidebarBg)
            .border(width = 0.5.dp, color = MacCardBorder)
            .padding(vertical = 12.dp, horizontal = 8.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // LIBRARY SECTION
        SidebarSectionHeader("LIBRARY")

        SidebarNavItem(
            label = "Songs",
            icon = Icons.Default.MusicNote,
            isSelected = selectedSection == NavigationSection.MUSIC_SONGS,
            onClick = { onSelectSection(NavigationSection.MUSIC_SONGS) },
            tag = "nav_songs"
        )
        SidebarNavItem(
            label = "Albums",
            icon = Icons.Default.Album,
            isSelected = selectedSection == NavigationSection.MUSIC_ALBUMS,
            onClick = { onSelectSection(NavigationSection.MUSIC_ALBUMS) },
            tag = "nav_albums"
        )
        SidebarNavItem(
            label = "Artists",
            icon = Icons.Default.Person,
            isSelected = selectedSection == NavigationSection.MUSIC_ARTISTS,
            onClick = { onSelectSection(NavigationSection.MUSIC_ARTISTS) },
            tag = "nav_artists"
        )
        SidebarNavItem(
            label = "Genres",
            icon = Icons.Default.Category,
            isSelected = selectedSection == NavigationSection.MUSIC_GENRES,
            onClick = { onSelectSection(NavigationSection.MUSIC_GENRES) },
            tag = "nav_genres"
        )
        SidebarNavItem(
            label = "Playlists",
            icon = Icons.Default.QueueMusic,
            isSelected = selectedSection == NavigationSection.PLAYLISTS,
            onClick = { onSelectSection(NavigationSection.PLAYLISTS) },
            tag = "nav_playlists"
        )
        SidebarNavItem(
            label = "Podcasts",
            icon = Icons.Default.Podcasts,
            isSelected = selectedSection == NavigationSection.PODCASTS,
            onClick = { onSelectSection(NavigationSection.PODCASTS) },
            tag = "nav_podcasts"
        )
        SidebarNavItem(
            label = "Audiobooks",
            icon = Icons.Default.Book,
            isSelected = selectedSection == NavigationSection.AUDIOBOOKS,
            onClick = { onSelectSection(NavigationSection.AUDIOBOOKS) },
            tag = "nav_audiobooks"
        )
        SidebarNavItem(
            label = "Films & TV",
            icon = Icons.Default.Movie,
            isSelected = selectedSection == NavigationSection.VIDEOS,
            onClick = { onSelectSection(NavigationSection.VIDEOS) },
            tag = "nav_videos"
        )

        Spacer(modifier = Modifier.height(16.dp))

        // DEVICES SECTION
        SidebarSectionHeader("DEVICES")

        SidebarNavItem(
            label = "Devices & Sync",
            icon = Icons.Default.Smartphone,
            isSelected = selectedSection == NavigationSection.DEVICES,
            onClick = { onSelectSection(NavigationSection.DEVICES) },
            tag = "nav_devices"
        )

        Spacer(modifier = Modifier.height(16.dp))

        // INTELLIGENCE & UTILITIES SECTION
        SidebarSectionHeader("INTELLIGENCE")

        SidebarNavItem(
            label = "AI Media Assistant",
            icon = Icons.Default.AutoAwesome,
            isSelected = selectedSection == NavigationSection.AI_ASSISTANT,
            onClick = { onSelectSection(NavigationSection.AI_ASSISTANT) },
            tag = "nav_ai_assistant",
            badgeText = "AI"
        )
        SidebarNavItem(
            label = "Recommendations",
            icon = Icons.Default.Psychology,
            isSelected = selectedSection == NavigationSection.RECOMMENDATIONS,
            onClick = { onSelectSection(NavigationSection.RECOMMENDATIONS) },
            tag = "nav_recommendations"
        )
        SidebarNavItem(
            label = "Library Health",
            icon = Icons.Default.HealthAndSafety,
            isSelected = selectedSection == NavigationSection.HEALTH_DASHBOARD,
            onClick = { onSelectSection(NavigationSection.HEALTH_DASHBOARD) },
            tag = "nav_health"
        )
    }
}

@Composable
private fun SidebarSectionHeader(title: String) {
    Text(
        text = title,
        color = MacTextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.1.sp,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
private fun SidebarNavItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String,
    badgeText: String? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) Color.White.copy(alpha = 0.18f) else Color.Transparent)
            .then(
                if (isSelected) Modifier.border(0.5.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(20.dp))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) Color.White else MacTextSecondary,
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = label,
                color = if (isSelected) Color.White else MacTextSecondary,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
            )
        }

        if (badgeText != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(AppleBlue)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badgeText,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
