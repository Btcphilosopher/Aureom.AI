package com.example.data.engine

import com.example.data.model.TrackEntity

data class AiPlaylistProposal(
    val playlistTitle: String,
    val description: String,
    val tracksWithReason: List<AiTrackReason>
)

data class AiTrackReason(
    val track: TrackEntity,
    val reason: String
)

object AiMediaAssistant {

    fun processNaturalLanguageQuery(
        prompt: String,
        allTracks: List<TrackEntity>
    ): Pair<String, List<TrackEntity>> {
        val p = prompt.lowercase().trim()

        return when {
            p.contains("120 bpm") || p.contains("tempo") || p.contains("bpm") -> {
                val matches = allTracks.filter { it.bpm in 115.0..128.0 }
                Pair("Found ${matches.size} tracks with tempo around 120-128 BPM", matches)
            }
            p.contains("highest-rated") || p.contains("favorite") || p.contains("best") || p.contains("5 star") -> {
                val matches = allTracks.filter { it.rating >= 4 }.sortedByDescending { it.rating }
                Pair("Found ${matches.size} top-rated 4-star and 5-star tracks in your library", matches)
            }
            p.contains("electronic") || p.contains("synth") -> {
                val matches = allTracks.filter { it.genre.lowercase().contains("electronic") || it.genre.lowercase().contains("synth") }
                Pair("Found ${matches.size} electronic & synthwave tracks", matches)
            }
            p.contains("not played recently") || p.contains("unplayed") || p.contains("forgotten") -> {
                val matches = allTracks.filter { it.playCount < 20 || (System.currentTimeMillis() - it.lastPlayed > 604800000L) }
                Pair("Found ${matches.size} tracks not played recently in your library", matches)
            }
            p.contains("1990s") || p.contains("90s") -> {
                val matches = allTracks.filter { it.year in 1990..1999 }
                Pair("Found ${matches.size} tracks from the 1990s", matches)
            }
            p.contains("2000s") || p.contains("2010s") -> {
                val matches = allTracks.filter { it.year >= 2000 }
                Pair("Found ${matches.size} modern tracks (2000+)", matches)
            }
            else -> {
                val matches = allTracks.filter { track ->
                    track.title.lowercase().contains(p) ||
                    track.artist.lowercase().contains(p) ||
                    track.album.lowercase().contains(p) ||
                    track.genre.lowercase().contains(p)
                }
                if (matches.isNotEmpty()) {
                    Pair("Found ${matches.size} tracks matching '$prompt'", matches)
                } else {
                    Pair("No exact matches found. Showing top recommended tracks.", allTracks.take(5))
                }
            }
        }
    }

    fun generateEveningPlaylistProposal(
        prompt: String,
        allTracks: List<TrackEntity>
    ): AiPlaylistProposal {
        val sortedByEnergy = allTracks.sortedBy { it.energy }
        val tracksWithReasons = mutableListOf<AiTrackReason>()

        sortedByEnergy.forEachIndexed { index, track ->
            val phase = when {
                index < sortedByEnergy.size / 3 -> "Start relaxed (${(track.energy * 100).toInt()}% energy)"
                index < (sortedByEnergy.size * 2) / 3 -> "Gradually building energy (${(track.energy * 100).toInt()}% energy)"
                else -> "Finish high-energy climax (${(track.energy * 100).toInt()}% energy)"
            }
            tracksWithReasons.add(AiTrackReason(track, phase))
        }

        val title = if (prompt.contains("drive", ignoreCase = true)) "Two-Hour Drive Mix" else "Evening Energy Arc"

        return AiPlaylistProposal(
            playlistTitle = title,
            description = "AI-generated energy progression: Starts relaxed, builds tempo, finishes with high-energy tracks.",
            tracksWithReason = tracksWithReasons
        )
    }
}
