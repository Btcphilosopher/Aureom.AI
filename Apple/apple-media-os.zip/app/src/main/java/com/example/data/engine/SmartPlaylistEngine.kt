package com.example.data.engine

import com.example.data.model.SmartRule
import com.example.data.model.TrackEntity
import org.json.JSONArray

object SmartPlaylistEngine {

    fun parseRules(json: String): List<SmartRule> {
        if (json.isBlank()) return emptyList()
        val list = mutableListOf<SmartRule>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    SmartRule(
                        field = obj.optString("field"),
                        operator = obj.optString("operator"),
                        value = obj.optString("value")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun serializeRules(rules: List<SmartRule>): String {
        val array = JSONArray()
        rules.forEach { rule ->
            val obj = org.json.JSONObject().apply {
                put("field", rule.field)
                put("operator", rule.operator)
                put("value", rule.value)
            }
            array.put(obj)
        }
        return array.toString()
    }

    fun evaluateTracks(tracks: List<TrackEntity>, rules: List<SmartRule>): List<TrackEntity> {
        if (rules.isEmpty()) return tracks

        return tracks.filter { track ->
            rules.all { rule ->
                evaluateRule(track, rule)
            }
        }
    }

    private fun evaluateRule(track: TrackEntity, rule: SmartRule): Boolean {
        val targetValue = rule.value.trim()
        return when (rule.field.uppercase()) {
            "GENRE" -> matchString(track.genre, rule.operator, targetValue)
            "ARTIST" -> matchString(track.artist, rule.operator, targetValue)
            "ALBUM" -> matchString(track.album, rule.operator, targetValue)
            "BPM" -> matchNumber(track.bpm, rule.operator, targetValue.toDoubleOrNull() ?: 0.0)
            "RATING" -> matchNumber(track.rating.toDouble(), rule.operator, targetValue.toDoubleOrNull() ?: 0.0)
            "PLAYCOUNT", "PLAY COUNT" -> matchNumber(track.playCount.toDouble(), rule.operator, targetValue.toDoubleOrNull() ?: 0.0)
            "YEAR" -> matchNumber(track.year.toDouble(), rule.operator, targetValue.toDoubleOrNull() ?: 0.0)
            else -> true
        }
    }

    private fun matchString(actual: String, operator: String, target: String): Boolean {
        return when (operator.uppercase()) {
            "=", "EQUALS", "IS" -> actual.equals(target, ignoreCase = true)
            "CONTAINS", "LIKE" -> actual.contains(target, ignoreCase = true)
            "NOT EQUALS", "!=" -> !actual.equals(target, ignoreCase = true)
            else -> actual.contains(target, ignoreCase = true)
        }
    }

    private fun matchNumber(actual: Double, operator: String, target: Double): Boolean {
        return when (operator) {
            "=", "==" -> actual == target
            ">" -> actual > target
            ">=" -> actual >= target
            "<" -> actual < target
            "<=" -> actual <= target
            "!=" -> actual != target
            else -> actual >= target
        }
    }
}
