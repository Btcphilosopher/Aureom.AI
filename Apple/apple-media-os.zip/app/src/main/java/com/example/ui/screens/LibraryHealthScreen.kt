package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.DuplicateDetector
import com.example.data.engine.LibraryIntegrityChecker
import com.example.data.engine.PythonAnalysisEngine
import com.example.data.model.TrackEntity
import com.example.ui.theme.*

@Composable
fun LibraryHealthScreen(
    tracks: List<TrackEntity>,
    onFixDuplicates: () -> Unit
) {
    val report = remember(tracks) { LibraryIntegrityChecker.auditLibrary(tracks) }
    val duplicateGroups = remember(tracks) { DuplicateDetector.findPossibleDuplicates(tracks) }
    var selectedTrackForAnalysis by remember(tracks) { mutableStateOf(tracks.firstOrNull()) }
    var analysisJsonOutput by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MacWindowBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("LIBRARY ANALYTICS & HEALTH DASHBOARD", color = MacTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Comprehensive library statistics, duplicate detector, integrity audit, and Python audio metadata analysis.", color = MacTextSecondary, fontSize = 11.sp)

        Spacer(modifier = Modifier.height(16.dp))

        // 4 KPI STAT CARDS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            KpiCard("TOTAL TRACKS", "18,492", "Indexed in SQLite", AppleItunesRed, Modifier.weight(1f))
            KpiCard("TOTAL DURATION", "1,428 Hours", "59.5 Days non-stop", AppleBlue, Modifier.weight(1f))
            KpiCard("STORAGE USED", "412.8 GB", "FLAC / AAC / ALAC", AppleCyan, Modifier.weight(1f))
            KpiCard("HEALTH SCORE", "99.4%", "0 missing files", MacTrafficGreen, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // DUPLICATE DETECTOR CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MacCardBg),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, MacCardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = AppleItunesRed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("DUPLICATE TRACK DETECTOR (${duplicateGroups.size} GROUPS FOUND)", color = MacTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    if (duplicateGroups.isNotEmpty()) {
                        Button(
                            onClick = onFixDuplicates,
                            colors = ButtonDefaults.buttonColors(containerColor = AppleItunesRed),
                            modifier = Modifier.testTag("merge_duplicates_button")
                        ) {
                            Text("Resolve Duplicates", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                duplicateGroups.take(3).forEach { group ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(MacWindowBg)
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("${group.mainTrack.title} - ${group.mainTrack.artist}", color = MacTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("Match 1: ${group.mainTrack.album} | Match 2: ${group.duplicateTrack.album}", color = MacTextSecondary, fontSize = 10.sp)
                        }
                        Surface(color = AppleItunesRed.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                            Text("${group.similarityScore}% Match", color = AppleItunesRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // PYTHON AUDIO METADATA ANALYSIS CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MacCardBg),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, MacCardBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Code, contentDescription = null, tint = AppleCyan, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("PYTHON AUDIO ANALYSIS ENGINE (python/analysis)", color = AppleCyan, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Selected Track: ${selectedTrackForAnalysis?.title ?: "None"}", color = MacTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

                    Button(
                        onClick = {
                            selectedTrackForAnalysis?.let { trk ->
                                val res = PythonAnalysisEngine.analyzeTrack(trk)
                                analysisJsonOutput = PythonAnalysisEngine.formatAnalysisToJson(res)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AppleBlue),
                        modifier = Modifier.testTag("run_python_audio_analysis_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Run Python Analysis", color = Color.White)
                    }
                }

                if (analysisJsonOutput != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = analysisJsonOutput!!,
                            color = AppleCyan,
                            fontSize = 11.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MacCardBg),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, MacCardBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = MacTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = accentColor, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subtitle, color = MacTextSecondary, fontSize = 10.sp)
        }
    }
}
