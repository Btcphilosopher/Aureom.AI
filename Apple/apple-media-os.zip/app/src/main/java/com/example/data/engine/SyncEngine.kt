package com.example.data.engine

import com.example.data.model.DeviceEntity
import com.example.data.model.SyncPreviewItem
import com.example.data.model.TrackEntity

object SyncEngine {

    fun generateSyncPlan(
        device: DeviceEntity,
        localTracks: List<TrackEntity>
    ): SyncPreviewItem {
        val tracksToAdd = (localTracks.size * 0.85).toInt().coerceAtLeast(12)
        val podcastsToAdd = 8
        val videosToRemove = 2
        val bytesRequired = tracksToAdd * 9500000L + podcastsToAdd * 25000000L

        return SyncPreviewItem(
            musicTracksToAdd = tracksToAdd,
            podcastsToAdd = podcastsToAdd,
            videosToRemove = videosToRemove,
            storageRequiredBytes = bytesRequired
        )
    }

    fun formatBytes(bytes: Long): String {
        val gb = bytes / 1000000000.0
        if (gb >= 1.0) {
            return "%.1f GB".format(gb)
        }
        val mb = bytes / 1000000.0
        return "%.1f MB".format(mb)
    }
}
