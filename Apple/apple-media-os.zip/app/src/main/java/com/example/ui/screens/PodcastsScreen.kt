package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PodcastEpisodeEntity
import com.example.data.model.PodcastShowEntity
import com.example.ui.components.formatTimeSeconds
import com.example.ui.theme.*

@Composable
fun PodcastsScreen(
    shows: List<PodcastShowEntity>,
    episodes: List<PodcastEpisodeEntity>,
    onPlayEpisode: (PodcastEpisodeEntity, String) -> Unit
) {
    var selectedShow by remember(shows) { mutableStateOf(shows.firstOrNull()) }
    var filterUnplayedOnly by remember { mutableStateOf(false) }

    val activeEpisodes = remember(episodes, selectedShow, filterUnplayedOnly) {
        var list = if (selectedShow != null) episodes.filter { it.showId == selectedShow!!.id } else episodes
        if (filterUnplayedOnly) {
            list = list.filter { !it.isPlayed }
        }
        list
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(MacWindowBg)
            .padding(16.dp)
    ) {
        // LEFT: Podcast Subscriptions Column
        Column(
            modifier = Modifier
                .width(240.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(8.dp))
                .background(MacCardBg)
                .border(0.5.dp, MacCardBorder, RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Text("PODCAST SHOWS", color = MacTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shows) { show ->
                    val isSel = selectedShow?.id == show.id

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSel) ApplePurple.copy(alpha = 0.25f) else MacWindowBg)
                            .clickable { selectedShow = show }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(ApplePurple.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Podcasts, contentDescription = null, tint = ApplePurple)
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(show.title, color = MacTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(show.author, color = MacTextSecondary, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        // RIGHT: Podcast Episodes & Resume Progress
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(8.dp))
                .background(MacCardBg)
                .border(0.5.dp, MacCardBorder, RoundedCornerShape(8.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(selectedShow?.title ?: "All Podcasts", color = MacTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(selectedShow?.description ?: "Subscribed podcast channels", color = MacTextSecondary, fontSize = 11.sp)
                }

                FilterChip(
                    selected = filterUnplayedOnly,
                    onClick = { filterUnplayedOnly = !filterUnplayedOnly },
                    label = { Text("Unplayed Only", fontSize = 11.sp) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(activeEpisodes) { episode ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { onPlayEpisode(episode, selectedShow?.title ?: "Podcast") },
                        colors = CardDefaults.cardColors(containerColor = MacWindowBg),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, MacCardBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(episode.title, color = MacTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                if (episode.isDownloaded) {
                                    Icon(Icons.Default.DownloadDone, contentDescription = "Downloaded", tint = AppleCyan, modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(episode.summary, color = MacTextSecondary, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val progress = if (episode.durationSeconds > 0) episode.playbackPositionSeconds.toFloat() / episode.durationSeconds.toFloat() else 0f

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PlayCircle, contentDescription = "Resume", tint = AppleItunesRed, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (episode.playbackPositionSeconds > 0) "Progress: ${formatTimeSeconds(episode.playbackPositionSeconds)} / ${formatTimeSeconds(episode.durationSeconds)}" else "Duration: ${formatTimeSeconds(episode.durationSeconds)}",
                                        color = AppleCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Text(if (episode.isPlayed) "PLAYED" else "UNPLAYED", color = if (episode.isPlayed) MacTextMuted else AppleItunesRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
