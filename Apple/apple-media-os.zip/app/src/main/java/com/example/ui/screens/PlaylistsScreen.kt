package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.engine.SmartPlaylistEngine
import com.example.data.model.PlaylistEntity
import com.example.data.model.SmartRule
import com.example.data.model.TrackEntity
import com.example.ui.theme.*

@Composable
fun PlaylistsScreen(
    playlists: List<PlaylistEntity>,
    allTracks: List<TrackEntity>,
    onCreatePlaylist: (String, Boolean, String) -> Unit,
    onPlayTrack: (TrackEntity) -> Unit
) {
    var selectedPlaylist by remember(playlists) { mutableStateOf(playlists.firstOrNull()) }
    var isCreatingNewPlaylist by remember { mutableStateOf(false) }

    val activePlaylistTracks = remember(selectedPlaylist, allTracks) {
        val p = selectedPlaylist ?: return@remember emptyList()
        if (p.isSmart) {
            val rules = SmartPlaylistEngine.parseRules(p.rulesJson)
            SmartPlaylistEngine.evaluateTracks(allTracks, rules)
        } else {
            allTracks.take(4) // Sample tracks for standard playlist
        }
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(MacWindowBg)
            .padding(16.dp)
    ) {
        // LEFT: Playlist Navigation Column
        Column(
            modifier = Modifier
                .width(220.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(8.dp))
                .background(MacCardBg)
                .border(0.5.dp, MacCardBorder, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("PLAYLISTS", color = MacTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                IconButton(
                    onClick = { isCreatingNewPlaylist = true },
                    modifier = Modifier.size(24.dp).testTag("create_new_playlist_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New Playlist", tint = AppleItunesRed)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn {
                items(playlists) { playlist ->
                    val isSelected = selectedPlaylist?.id == playlist.id

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) AppleItunesRed.copy(alpha = 0.25f) else Color.Transparent)
                            .clickable { selectedPlaylist = playlist }
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (playlist.isSmart) Icons.Default.AutoAwesome else Icons.Default.QueueMusic,
                            contentDescription = null,
                            tint = if (playlist.isSmart) AppleCyan else AppleItunesRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = playlist.name,
                            color = if (isSelected) MacTextPrimary else MacTextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(14.dp))

        // RIGHT: Selected Playlist Tracks
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(8.dp))
                .background(MacCardBg)
                .border(0.5.dp, MacCardBorder, RoundedCornerShape(8.dp))
                .padding(16.dp)
        ) {
            if (selectedPlaylist != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(selectedPlaylist!!.name, color = MacTextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            if (selectedPlaylist!!.isSmart) {
                                Surface(color = AppleCyan.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp), modifier = Modifier.padding(start = 8.dp)) {
                                    Text("SMART ENGINE", color = AppleCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                        }
                        Text("${activePlaylistTracks.size} items • ${selectedPlaylist!!.description}", color = MacTextSecondary, fontSize = 11.sp)
                    }

                    Button(
                        onClick = { activePlaylistTracks.firstOrNull()?.let { onPlayTrack(it) } },
                        colors = ButtonDefaults.buttonColors(containerColor = AppleItunesRed),
                        modifier = Modifier.testTag("play_all_playlist_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Play All", color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(activePlaylistTracks) { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .clickable { onPlayTrack(track) }
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = AppleItunesRed, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(track.title, color = MacTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("${track.artist} • ${track.album}", color = MacTextSecondary, fontSize = 10.sp)
                                }
                            }
                            Text(track.genre, color = MacTextMuted, fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(16.dp))
                            Text("${track.bpm.toInt()} BPM", color = AppleCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Divider(color = MacCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Select or Create a Playlist", color = MacTextMuted)
                }
            }
        }
    }

    if (isCreatingNewPlaylist) {
        CreatePlaylistDialog(
            onDismiss = { isCreatingNewPlaylist = false },
            onCreate = { name, isSmart, rulesJson ->
                onCreatePlaylist(name, isSmart, rulesJson)
                isCreatingNewPlaylist = false
            }
        )
    }
}

@Composable
private fun CreatePlaylistDialog(
    onDismiss: () -> Unit,
    onCreate: (String, Boolean, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var isSmart by remember { mutableStateOf(true) }
    var ruleField by remember { mutableStateOf("BPM") }
    var ruleOp by remember { mutableStateOf(">=") }
    var ruleVal by remember { mutableStateOf("120") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .width(400.dp)
                .wrapContentHeight()
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, MacCardBorder, RoundedCornerShape(12.dp)),
            color = MacHeaderBg
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("NEW PLAYLIST ENGINE", color = AppleItunesRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Playlist Name") },
                    modifier = Modifier.fillMaxWidth().testTag("playlist_name_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isSmart, onCheckedChange = { isSmart = it })
                    Text("Enable Smart Playlist Rule Engine", color = MacTextPrimary, fontSize = 12.sp)
                }

                if (isSmart) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(MacWindowBg)
                            .padding(10.dp)
                    ) {
                        Text("SMART RULE CONDITION:", color = AppleCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(value = ruleField, onValueChange = { ruleField = it }, label = { Text("Field") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = ruleOp, onValueChange = { ruleOp = it }, label = { Text("Op") }, modifier = Modifier.width(60.dp))
                            OutlinedTextField(value = ruleVal, onValueChange = { ruleVal = it }, label = { Text("Value") }, modifier = Modifier.weight(1f))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel", color = MacTextSecondary) }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val rules = if (isSmart) SmartPlaylistEngine.serializeRules(listOf(SmartRule(ruleField, ruleOp, ruleVal))) else ""
                            onCreate(name.ifBlank { "My Playlist" }, isSmart, rules)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AppleItunesRed),
                        modifier = Modifier.testTag("save_new_playlist_button")
                    ) {
                        Text("Create Playlist", color = Color.White)
                    }
                }
            }
        }
    }
}
