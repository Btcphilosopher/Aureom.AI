package com.example.data.engine

import com.example.data.model.DuplicateGroup
import com.example.data.model.TrackEntity

object DuplicateDetector {

    fun findPossibleDuplicates(tracks: List<TrackEntity>): List<DuplicateGroup> {
        val duplicates = mutableListOf<DuplicateGroup>()

        for (i in tracks.indices) {
            for (j in i + 1 until tracks.size) {
                val t1 = tracks[i]
                val t2 = tracks[j]

                // Title match or high similarity
                val titleMatch = t1.title.equals(t2.title, ignoreCase = true)
                val artistMatch = t1.artist.equals(t2.artist, ignoreCase = true)
                val durationMatch = kotlin.math.abs(t1.durationSeconds - t2.durationSeconds) <= 3

                if (titleMatch && artistMatch) {
                    val score = if (durationMatch) 98 else 88
                    duplicates.add(DuplicateGroup(t1, t2, score))
                } else if (titleMatch && durationMatch) {
                    duplicates.add(DuplicateGroup(t1, t2, 78))
                }
            }
        }
        return duplicates
    }
}
