package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun MacTitleBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onToggleMiniPlayer: () -> Unit,
    onOpenAiAssistant: () -> Unit,
    onOpenHealthDashboard: () -> Unit,
    isVisualizerActive: Boolean,
    onToggleVisualizer: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .background(MacHeaderBg)
            .border(width = 0.5.dp, color = MacCardBorder)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left: macOS Window Traffic Light Controls
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(MacTrafficRed)
            )
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(MacTrafficYellow)
            )
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(MacTrafficGreen)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = "APPLE MEDIA.OS",
                color = MacTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                letterSpacing = 1.2.sp
            )

            Surface(
                color = AppleItunesRed.copy(alpha = 0.15f),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.padding(start = 6.dp)
            ) {
                Text(
                    text = "PRO 2026",
                    color = AppleItunesRed,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }

        // Center: Global Search Input Field
        Row(
            modifier = Modifier
                .width(320.dp)
                .height(34.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = 0.08f))
                .border(0.5.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search Media",
                tint = MacTextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = {
                    Text(
                        text = "Search Media (Tracks, Artists, Podcasts...)",
                        color = MacTextMuted,
                        fontSize = 12.sp
                    )
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = MacTextPrimary,
                    unfocusedTextColor = MacTextPrimary,
                    cursorColor = AppleItunesRed
                ),
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("global_search_input")
            )
        }

        // Right: macOS Tool Icons
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // AI Assistant Button
            IconButton(
                onClick = onOpenAiAssistant,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(AppleBlue.copy(alpha = 0.2f))
                    .testTag("ai_assistant_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI Media Assistant",
                    tint = AppleCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Visualizer Toggle
            IconButton(
                onClick = onToggleVisualizer,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (isVisualizerActive) AppleItunesRed.copy(alpha = 0.3f) else MacCardBg)
                    .testTag("visualizer_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = "Audio Spectrum Visualizer",
                    tint = if (isVisualizerActive) AppleItunesRed else MacTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Health Dashboard Button
            IconButton(
                onClick = onOpenHealthDashboard,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MacCardBg)
                    .testTag("health_dashboard_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Equalizer,
                    contentDescription = "Library Health Dashboard",
                    tint = MacTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Mini Player Floating Window
            IconButton(
                onClick = onToggleMiniPlayer,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MacCardBg)
                    .testTag("mini_player_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PictureInPicture,
                    contentDescription = "Mini Player Window",
                    tint = MacTextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
