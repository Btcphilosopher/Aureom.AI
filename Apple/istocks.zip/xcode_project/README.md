# iStocks — Financial Research & Portfolio Application

**iStocks** is an independent, native mobile application designed for tracking global stock markets, researching companies, and monitoring an investment portfolio with decimal accounting and FIFO cost basis.

---

## 1. Overview & Architecture

### Five Core Tabs
1. **Today**: Editorial daily market overview, real-time market session status (NYSE/NASDAQ/LSE/Euronext/TSE), major index carousel, interactive hero benchmark chart, watchlist preview, portfolio movement, market movers, and source-linked editorial briefings.
2. **Watchlists**: Multi-watchlist tabs (e.g. *Core Tech*, *Global & Dividend*, *Biotech & ETFs*), sorting (Name, Price Change %, Price, Market Cap), sparkline trend charts, exchange badges, and local price alerts.
3. **Markets**: Dedicated sections for Equities, Benchmark Indices (clearly distinguished from tradable instruments), ETFs, Sector Heatmaps, Market Movers, and an Economic Events Calendar (FOMC, CPI, NFP, ECB, BoE).
4. **Portfolio**: Decimal arithmetic accounting supporting multi-account management, cash balances (deposits/withdrawals), fractional purchases/sales, dividends received, realized & unrealized gains, asset allocation donut charts, and CSV import/export with duplicate validation.
5. **Search**: Instant ticker/company/exchange lookup with filter chips (Stocks, ETFs, Indices, Crypto) and recent search recall.

### AI Research Assistant
An Apple Intelligence-styled modal interface delivering:
- Corporate Announcement & SEC filing summaries
- Plain-English financial term explainers (P/E, FCF yield, Beta)
- Side-by-side metric comparisons
- Portfolio concentration audits
- Missing information & risk factor identification
*All outputs strictly separate reported facts, calculated metrics, and generated interpretations with cited sources.*

---

## 2. Platforms & Dual Execution

- **Android (Live in AI Studio Emulator)**: Full Kotlin + Jetpack Compose + Room database implementation ready to run and test in the streaming emulator right now.
- **iOS / Xcode (`/xcode_project`)**: Complete Swift / SwiftUI / Swift Charts / WidgetKit source tree for building on macOS Xcode 15/16.

---

## 3. iOS Xcode Build & Simulator Instructions

### Requirements
- macOS Sonoma (14.0+) or Sequoia (15.0+)
- Xcode 15.4 or 16.0+
- iOS 17.0+ deployment target

### Setup Steps
1. Open Xcode and create a new project:
   - Template: **App** (SwiftUI, Swift).
   - Product Name: `iStocks`
   - Organization Identifier: `com.aistudio.istocks`
2. Drag and drop the files from `/xcode_project/iStocks/` into your Xcode project navigator:
   - `iStocksApp.swift`
   - `Models/`
   - `Services/`
   - `Views/`
   - `Widget/`
3. Add a Widget Extension target:
   - File → New → Target → **Widget Extension**
   - Name: `iStocksWidget`
   - Embed `WatchlistWidget.swift`.
4. Select an iPhone 15/16 Pro Simulator from the scheme dropdown.
5. Press `Cmd + R` to Build & Run.

---

## 4. Provider Integration & Real Market Feeds

The app decouples data sources using modular protocols defined in `Services/Protocols.swift`:
- `MarketDataProvider`
- `InstrumentSearchProvider`
- `HistoricalPriceProvider`
- `CompanyFundamentalsProvider`
- `NewsProvider`
- `ExchangeCalendarProvider`
- `FXRateProvider`
- `PriceAlertService`

### Connecting Live Endpoints
To connect a commercial market data provider (e.g. Polygon.io, IEX Cloud, or Financial Modeling Prep):
1. Create a class adopting `MarketDataProvider` and `HistoricalPriceProvider`.
2. Implement URLSession requests using your API key injected via `ProcessInfo.processInfo.environment["API_KEY"]` or Keychain.
3. Replace `MockMarketDataService` with your live provider in `iStocksApp.swift`:

```swift
@StateObject private var marketDataService = LiveMarketDataService(apiKey: secureKey)
```

---

## 5. Accounting & Compliance Rules
- **FIFO Matching**: Oldest acquired shares are liquidated first to compute realized gain/loss.
- **Monetary Precision**: Uses Decimal arithmetic (`java.math.BigDecimal` on Android / `Foundation.Decimal` on Swift) to avoid floating-point rounding errors.
- **Multi-Currency**: Explicit foreign exchange conversion factors are applied and labelled (e.g. London equities traded in GBP converted to USD portfolio base).
- **Missing Fundamentals**: Negative net income or non-reporting entities display `"N/A"` rather than fabricated figures.
- **Data Provenance**: Every quote displays exchange, currency, timestamp, and feed freshness (`Live`, `Delayed 15m`, or `Simulated Demo`).
