import WidgetKit
import SwiftUI

struct WatchlistWidgetEntry: TimelineEntry {
    let date: Date
    let items: [(symbol: String, price: String, change: String, isGain: Bool)]
}

struct WatchlistWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> WatchlistWidgetEntry {
        WatchlistWidgetEntry(
            date: Date(),
            items: [
                ("AAPL", "$224.23", "+1.21%", true),
                ("NVDA", "$142.80", "+3.29%", true),
                ("MSFT", "$418.15", "-0.98%", false)
            ]
        )
    }

    func getSnapshot(in context: Context, completion: @escaping (WatchlistWidgetEntry) -> Void) {
        let entry = placeholder(in: context)
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<WatchlistWidgetEntry>) -> Void) {
        let entry = placeholder(in: context)
        let nextUpdate = Calendar.current.date(byAdding: .minute, value: 15, to: Date())!
        let timeline = Timeline(entries: [entry], policy: .after(nextUpdate))
        completion(timeline)
    }
}

struct WatchlistWidgetEntryView: View {
    var entry: WatchlistWidgetProvider.Entry

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("iStocks")
                    .font(.caption2.bold())
                    .foregroundStyle(.secondary)
                Spacer()
                Circle()
                    .fill(Color.green)
                    .frame(width: 5, height: 5)
                Text("LIVE")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(.green)
            }

            Divider()

            ForEach(entry.items, id: \.symbol) { item in
                HStack {
                    Text(item.symbol)
                        .font(.subheadline.bold())
                    Spacer()
                    Text(item.price)
                        .font(.system(.caption, design: .monospaced).bold())
                    Text(item.change)
                        .font(.system(.caption2, design: .monospaced).weight(.semibold))
                        .foregroundStyle(item.isGain ? Color.green : Color.red)
                        .padding(.horizontal, 4)
                        .padding(.vertical, 2)
                        .background((item.isGain ? Color.green : Color.red).opacity(0.15))
                        .clipShape(RoundedRectangle(cornerRadius: 4))
                }
            }
        }
        .padding(8)
        .containerBackground(for: .widget) {
            Color(red: 0.08, green: 0.10, blue: 0.14)
        }
    }
}

@main
struct WatchlistWidget: Widget {
    let kind: String = "WatchlistWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: WatchlistWidgetProvider()) { entry in
            WatchlistWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("iStocks Watchlist")
        .description("Quick glance at your market quotes and daily changes.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
