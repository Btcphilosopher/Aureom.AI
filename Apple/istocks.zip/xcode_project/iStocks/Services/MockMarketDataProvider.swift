import Foundation
import Combine

public final class MockMarketDataService: ObservableObject, @unchecked Sendable {
    @Published public var quotes: [StockQuote] = []
    @Published public var economicEvents: [EconomicCalendarItem] = []
    @Published public var news: [NewsArticle] = []

    public init() {
        loadDeterministicMockData()
    }

    private func loadDeterministicMockData() {
        quotes = [
            StockQuote(
                id: "AAPL.NASDAQ", symbol: "AAPL", name: "Apple Inc.", exchange: "NASDAQ", currency: "USD",
                type: .equity, currentPrice: 224.23, previousClose: 221.55, marketCap: 3420.5, peRatio: 33.8,
                forwardPe: 29.4, dividendYield: 0.45, eps: 6.63, volume: 48291000, avgVolume: 51200000,
                beta: 1.08, high52: 237.23, low52: 164.08,
                description: "Apple Inc. designs, manufactures, and markets smartphones, personal computers, tablets, wearables, and accessories.",
                sector: "Technology", dataSource: "Consolidated Tape Association (Delayed 15m)", isMarketOpen: true,
                sparklinePoints: [221.55, 222.10, 223.40, 222.80, 224.10, 223.90, 224.23]
            ),
            StockQuote(
                id: "NVDA.NASDAQ", symbol: "NVDA", name: "NVIDIA Corporation", exchange: "NASDAQ", currency: "USD",
                type: .equity, currentPrice: 142.80, previousClose: 138.25, marketCap: 3510.2, peRatio: 64.2,
                forwardPe: 38.5, dividendYield: 0.03, eps: 2.22, volume: 68420000, avgVolume: 62100000,
                beta: 1.68, high52: 149.77, low52: 45.60,
                description: "NVIDIA Corporation provides graphics, computing and networking solutions. Its GPU architectures drive AI acceleration.",
                sector: "Technology", dataSource: "NASDAQ Real-Time (Simulated)", isMarketOpen: true,
                sparklinePoints: [138.25, 139.50, 140.20, 141.80, 141.50, 143.20, 142.80]
            ),
            StockQuote(
                id: "AZN.LSE", symbol: "AZN", name: "AstraZeneca PLC", exchange: "LSE", currency: "GBP",
                type: .equity, currentPrice: 118.50, previousClose: 116.20, marketCap: 183.4, peRatio: 38.6,
                forwardPe: 18.2, dividendYield: 2.15, eps: 3.07, volume: 3800000, avgVolume: 4100000,
                beta: 0.55, high52: 134.00, low52: 97.60,
                description: "Biopharmaceutical company focusing on discovery, development, and commercialization of prescription medicines.",
                sector: "Healthcare", dataSource: "London Stock Exchange Level 1", isMarketOpen: false, // Closed market demonstration
                sparklinePoints: [116.20, 116.80, 117.50, 118.00, 118.80, 118.30, 118.50]
            ),
            StockQuote(
                id: "BIOX.NASDAQ", symbol: "BIOX", name: "BioNext Genomics", exchange: "NASDAQ", currency: "USD",
                type: .equity, currentPrice: 18.45, previousClose: 19.80, marketCap: 1.45, peRatio: nil, // Missing fundamentals demonstration
                forwardPe: nil, dividendYield: nil, eps: -1.24, volume: 8200000, avgVolume: 5400000,
                beta: 2.15, high52: 34.20, low52: 9.80,
                description: "Clinical-stage biotechnology firm researching targeted mRNA therapeutics. Currently non-profitable.",
                sector: "Healthcare", dataSource: "Simulated Demo Feed", isMarketOpen: true,
                sparklinePoints: [19.80, 19.50, 18.90, 18.10, 18.60, 18.20, 18.45]
            ),
            StockQuote(
                id: "SPX.INDEX", symbol: "^GSPC", name: "S&P 500", exchange: "INDEX", currency: "USD",
                type: .index, currentPrice: 5983.25, previousClose: 5962.10, marketCap: 48500.0, peRatio: 27.8,
                forwardPe: nil, dividendYield: 1.32, eps: nil, volume: 0, avgVolume: 0,
                beta: 1.00, high52: 6025.00, low52: 4700.00,
                description: "Standard & Poor's 500 benchmark index of large-cap US equities.",
                sector = "Benchmark Index", dataSource: "Cboe Global Indices (Delayed 15m)", isMarketOpen: true,
                sparklinePoints: [5962.1, 5970.0, 5978.4, 5974.1, 5988.2, 5980.5, 5983.25]
            )
        ]

        economicEvents = [
            EconomicCalendarItem(id: "1", title: "FOMC Rate Decision", country: "United States", flag: "🇺🇸", dateStr: "Nov 12, 2026", timeStr: "14:00 EST", impact: "HIGH", forecast: "4.50%", prior: "4.75%", commentary: "78% cut probability priced in."),
            EconomicCalendarItem(id: "2", title: "Consumer Price Index (CPI)", country: "United States", flag: "🇺🇸", dateStr: "Nov 13, 2026", timeStr: "08:30 EST", impact: "HIGH", forecast: "2.6%", prior: "2.4%", commentary: "Core inflation expected steady."),
            EconomicCalendarItem(id: "3", title: "ECB Rate Decision", country: "Eurozone", flag: "🇪🇺", dateStr: "Dec 12, 2026", timeStr: "13:15 CET", impact: "MED", forecast: "3.00%", prior: "3.25%", commentary: "Governing council expected to ease.")
        ]

        news = [
            NewsArticle(id: "1", title: "Semiconductor Surge Drives NASDAQ to New Highs as Enterprise AI Spending Expands", source: "Financial Chronicle", timeAgo: "18m ago", summary: "Chipmakers led broad technology gains as major cloud hyperscalers reaffirmed multi-billion capital expenditure targets.", relatedSymbol: "NVDA", category: "Technology"),
            NewsArticle(id: "2", title: "Apple Reports Record Services Revenue Alongside Robust iPhone Pro Upgrade Cycle", source: "Dow Jones Newswires", timeAgo: "1h ago", summary: "Services gross margins reached an all-time peak of 74.2%, offsetting subdued regional hardware headwinds.", relatedSymbol: "AAPL", category: "Earnings")
        ]
    }
}

public final class PortfolioService: ObservableObject, @unchecked Sendable {
    @Published public var transactions: [TxRecord] = []
    @Published public var cashBalance: Decimal = 15000.00
    @Published public var baseCurrency: String = "USD"

    public init() {
        // Seed sample portfolio transactions
        transactions = [
            TxRecord(symbol: "AAPL", type: .buy, quantity: 15.0, pricePerShare: 212.50, fee: 4.95, currency: "USD", timestamp: Date().addingTimeInterval(-86400 * 45), notes: "Core tech accumulation"),
            TxRecord(symbol: "NVDA", type: .buy, quantity: 25.0, pricePerShare: 118.00, fee: 4.95, currency: "USD", timestamp: Date().addingTimeInterval(-86400 * 30), notes: "Data center position"),
            TxRecord(symbol: "NVDA", type: .sell, quantity: 5.0, pricePerShare: 144.50, fee: 4.95, currency: "USD", timestamp: Date().addingTimeInterval(-86400 * 5), notes: "Profit taking"),
            TxRecord(symbol: "AZN", type: .buy, quantity: 20.0, pricePerShare: 112.40, fee: 5.00, currency: "GBP", timestamp: Date().addingTimeInterval(-86400 * 20), notes: "London pharmaceutical position"),
            TxRecord(symbol: "AAPL", type: .dividend, quantity: 0.0, pricePerShare: 3.75, fee: 0.0, currency: "USD", timestamp: Date().addingTimeInterval(-86400 * 10), notes: "Cash dividend")
        ]
    }
}
