import Foundation

public enum InstrumentType: String, Codable, Sendable {
    case equity
    case etf
    case index
    case crypto
}

public struct InstrumentQuote: Identifiable, Sendable {
    public let id: String
    public let symbol: String
    public let name: String
    public let exchange: String
    public let currency: String
    public let type: InstrumentType
    public let currentPrice: Decimal
    public let previousClose: Decimal
    public let timestamp: Date
    public let dataSource: String
    public let isLive: Bool

    public var change: Decimal { currentPrice - previousClose }
    public var changePercent: Double {
        guard previousClose > 0 else { return 0 }
        return NSDecimalNumber(decimal: (change / previousClose) * 100).doubleValue
    }
}

public struct HistoricalDataPoint: Identifiable, Sendable {
    public let id = UUID()
    public let timestamp: Date
    public let price: Decimal
    public let adjustedPrice: Decimal
    public let volume: Int64
    public let isSplit: Bool
    public let splitRatio: String?
    public let isDividend: Bool
    public let dividendAmount: Decimal?
}

public protocol MarketDataProvider: Sendable {
    func fetchQuote(for symbol: String) async throws -> InstrumentQuote
    func fetchQuotes(for symbols: [String]) async throws -> [InstrumentQuote]
}

public protocol InstrumentSearchProvider: Sendable {
    func search(query: String, filter: InstrumentType?) async throws -> [InstrumentQuote]
}

public protocol HistoricalPriceProvider: Sendable {
    func fetchHistory(symbol: String, range: String, adjusted: Bool) async throws -> [HistoricalDataPoint]
}

public protocol CompanyFundamentalsProvider: Sendable {
    func fetchFundamentals(symbol: String) async throws -> [String: String]
}

public protocol NewsProvider: Sendable {
    func fetchMarketNews(symbol: String?) async throws -> [(title: String, source: String, date: Date, summary: String)]
}

public protocol ExchangeCalendarProvider: Sendable {
    func isMarketOpen(exchange: String, at date: Date) -> (isOpen: Bool, statusText: String)
}

public protocol FXRateProvider: Sendable {
    func convert(amount: Decimal, from: String, to: String) -> Decimal
}

public protocol PriceAlertService: Sendable {
    func scheduleAlert(symbol: String, targetPrice: Decimal, isAbove: Bool) async throws
    func removeAlert(id: UUID) async throws
}
