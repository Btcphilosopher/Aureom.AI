import Foundation

public enum TxType: String, Codable, Sendable {
    case buy = "BUY"
    case sell = "SELL"
    case dividend = "DIVIDEND"
    case deposit = "DEPOSIT"
    case withdrawal = "WITHDRAWAL"
}

public struct TxRecord: Identifiable, Sendable {
    public let id: UUID
    public let accountId: String
    public let symbol: String
    public let type: TxType
    public let quantity: Decimal
    public let pricePerShare: Decimal
    public let fee: Decimal
    public let currency: String
    public let timestamp: Date
    public let notes: String

    public init(
        id: UUID = UUID(),
        accountId: String = "default",
        symbol: String,
        type: TxType,
        quantity: Decimal,
        pricePerShare: Decimal,
        fee: Decimal = 0,
        currency: String = "USD",
        timestamp: Date = Date(),
        notes: String = ""
    ) {
        self.id = id
        self.accountId = accountId
        self.symbol = symbol
        self.type = type
        self.quantity = quantity
        self.pricePerShare = pricePerShare
        self.fee = fee
        self.currency = currency
        self.timestamp = timestamp
        self.notes = notes
    }
}

public struct PositionHolding: Identifiable, Sendable {
    public var id: String { symbol }
    public let symbol: String
    public let name: String
    public let exchange: String
    public let currency: String
    public let quantity: Decimal
    public let averageCostBasis: Decimal
    public let totalCost: Decimal
    public let currentPrice: Decimal
    public let currentValue: Decimal
    public let unrealizedGain: Decimal
    public let unrealizedGainPercent: Double
    public let realizedGain: Decimal
    public let totalDividends: Decimal
    public let sector: String
}

public struct PortfolioSnapshot: Sendable {
    public let totalEquity: Decimal
    public let investedValue: Decimal
    public let cashBalance: Decimal
    public let totalCost: Decimal
    public let unrealizedGain: Decimal
    public let unrealizedGainPercent: Double
    public let realizedGain: Decimal
    public let dailyGain: Decimal
    public let dailyGainPercent: Double
    public let baseCurrency: String
}
