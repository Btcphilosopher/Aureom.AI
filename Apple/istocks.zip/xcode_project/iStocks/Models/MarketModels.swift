import Foundation

public struct StockQuote: Identifiable, Sendable {
    public let id: String
    public let symbol: String
    public let name: String
    public let exchange: String
    public let currency: String
    public let type: InstrumentType
    public let currentPrice: Decimal
    public let previousClose: Decimal
    public let marketCap: Decimal?
    public let peRatio: Double?
    public let forwardPe: Double?
    public let dividendYield: Double?
    public let eps: Decimal?
    public let volume: Int64
    public let avgVolume: Int64
    public let beta: Double?
    public let high52: Decimal
    public let low52: Decimal
    public let description: String
    public let sector: String
    public let dataSource: String
    public let isMarketOpen: Bool
    public let sparklinePoints: [Double]

    public var change: Decimal { currentPrice - previousClose }
    public var changePercent: Double {
        guard previousClose > 0 else { return 0.0 }
        return NSDecimalNumber(decimal: (change / previousClose) * 100).doubleValue
    }
    public var isGain: Bool { change >= 0 }
}

public struct EconomicCalendarItem: Identifiable, Sendable {
    public let id: String
    public let title: String
    public let country: String
    public let flag: String
    public let dateStr: String
    public let timeStr: String
    public let impact: String // "HIGH", "MED", "LOW"
    public let forecast: String
    public let prior: String
    public let commentary: String
}

public struct NewsArticle: Identifiable, Sendable {
    public let id: String
    public let title: String
    public let source: String
    public let timeAgo: String
    public let summary: String
    public let relatedSymbol: String
    public let category: String
}
