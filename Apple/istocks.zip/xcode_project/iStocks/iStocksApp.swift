import SwiftUI
import SwiftData

@main
struct iStocksApp: App {
    @StateObject private var marketDataService = MockMarketDataService()
    @StateObject private var portfolioService = PortfolioService()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(marketDataService)
                .environmentObject(portfolioService)
                .preferredColorScheme(.dark)
        }
    }
}

struct ContentView: View {
    @EnvironmentObject var marketData: MockMarketDataService
    @EnvironmentObject var portfolio: PortfolioService
    @State private var selectedTab: Tab = .today
    @State private var presentedSymbol: String? = nil
    @State private var isAiSheetPresented: Bool = false

    enum Tab {
        case today, watchlist, markets, portfolio, search
    }

    var body: some View {
        TabView(selection: $selectedTab) {
            TodayView(onSelectSymbol: { presentedSymbol = $0 }, onOpenAi: { isAiSheetPresented = true })
                .tabItem {
                    Label("Today", systemImage: "newspaper")
                }
                .tag(Tab.today)

            WatchlistView(onSelectSymbol: { presentedSymbol = $0 })
                .tabItem {
                    Label("Watchlist", systemImage: "list.bullet")
                }
                .tag(Tab.watchlist)

            MarketsView(onSelectSymbol: { presentedSymbol = $0 })
                .tabItem {
                    Label("Markets", systemImage: "globe")
                }
                .tag(Tab.markets)

            PortfolioView(onSelectSymbol: { presentedSymbol = $0 })
                .tabItem {
                    Label("Portfolio", systemImage: "chart.pie")
                }
                .tag(Tab.portfolio)

            SearchView(onSelectSymbol: { presentedSymbol = $0 })
                .tabItem {
                    Label("Search", systemImage: "magnifyingglass")
                }
                .tag(Tab.search)
        }
        .tint(Color.blue)
        .sheet(item: Binding<IdentifiableString?>(
            get: { presentedSymbol.map { IdentifiableString(id: $0) } },
            set: { presentedSymbol = $0?.id }
        )) { ident in
            CompanyDetailView(symbol: ident.id)
                .environmentObject(marketData)
                .environmentObject(portfolio)
        }
        .sheet(isPresented: $isAiSheetPresented) {
            AiAssistantView(initialSymbol: "AAPL")
                .environmentObject(marketData)
                .environmentObject(portfolio)
        }
    }
}

struct IdentifiableString: Identifiable {
    let id: String
}
