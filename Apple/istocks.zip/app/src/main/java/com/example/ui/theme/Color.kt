package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// Brand Accents
val AppleBlue = Color(0xFF0A84FF)
val AppleBlueLight = Color(0xFF007AFF)

// Financial Gains & Losses
val StockGainDark = Color(0xFF30D158)
val StockGainLight = Color(0xFF28CD41)
val StockGainSoftDark = Color(0x2230D158)
val StockGainSoftLight = Color(0x1F28CD41)

val StockLossDark = Color(0xFFFF453A)
val StockLossLight = Color(0xFFFF3B30)
val StockLossSoftDark = Color(0x22FF453A)
val StockLossSoftLight = Color(0x1FFF3B30)

val StockNeutral = Color(0xFF8E8E93)

// Dark Theme Surfaces (iOS Dark Mode aesthetic)
val DarkBackground = Color(0xFF07090E)
val DarkSurface = Color(0xFF12151E)
val DarkSurfaceElevated = Color(0xFF1B202D)
val DarkSurfaceHighlight = Color(0xFF262C3D)
val DarkBorder = Color(0x1AFFFFFF)
val DarkTextPrimary = Color(0xFFF5F5F7)
val DarkTextSecondary = Color(0xFF98989F)
val DarkTextMuted = Color(0xFF636366)

// Light Theme Surfaces (iOS Light Mode aesthetic)
val LightBackground = Color(0xFFF2F2F7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF8F9FA)
val LightSurfaceHighlight = Color(0xFFE5E5EA)
val LightBorder = Color(0x14000000)
val LightTextPrimary = Color(0xFF1C1C1E)
val LightTextSecondary = Color(0xFF6E6E73)
val LightTextMuted = Color(0xFF8E8E93)

// AI Assistant glow palette
val AiGlowViolet = Color(0xFFBF5AF2)
val AiGlowIndigo = Color(0xFF5E5CE6)
val AiGlowCyan = Color(0xFF64D2FF)

@Immutable
data class ExtendedStocksColors(
    val gain: Color,
    val loss: Color,
    val gainSoft: Color,
    val lossSoft: Color,
    val neutral: Color,
    val surfaceElevated: Color,
    val surfaceHighlight: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val aiAccent: Color
)

val LocalStocksColors = staticCompositionLocalOf {
    ExtendedStocksColors(
        gain = StockGainDark,
        loss = StockLossDark,
        gainSoft = StockGainSoftDark,
        lossSoft = StockLossSoftDark,
        neutral = StockNeutral,
        surfaceElevated = DarkSurfaceElevated,
        surfaceHighlight = DarkSurfaceHighlight,
        border = DarkBorder,
        textPrimary = DarkTextPrimary,
        textSecondary = DarkTextSecondary,
        textMuted = DarkTextMuted,
        aiAccent = AppleBlue
    )
}
