package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Badge
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssetType
import com.example.model.Instrument
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.SparklineChart
import com.example.ui.theme.AppleBlue
import com.example.ui.theme.StocksTheme
import com.example.ui.theme.TabularNumberStyle
import java.util.Locale

enum class MarketSection(val label: String) {
    EQUITIES("Equities"),
    INDICES("Indices"),
    ETFS("ETFs"),
    SECTORS("Sectors"),
    MOVERS("Movers"),
    CALENDAR("Economic Events")
}

@Composable
fun MarketsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val instruments by viewModel.instruments.collectAsState()
    var selectedSection by remember { mutableStateOf(MarketSection.EQUITIES) }
    var selectedRegion by remember { mutableStateOf("ALL") } // ALL, US, EUROPE, ASIA

    // Filter instruments by region
    val regionFiltered = remember(instruments, selectedRegion) {
        when (selectedRegion) {
            "US" -> instruments.filter { it.exchange in listOf("NYSE", "NASDAQ", "INDEX") && it.currency == "USD" }
            "EUROPE" -> instruments.filter { it.exchange in listOf("LSE", "EURONEXT") }
            "ASIA" -> instruments.filter { it.exchange == "TSE" }
            else -> instruments
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 16.dp)
            .testTag("markets_screen")
    ) {
        // Screen Header
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = "DISCOVER & RESEARCH",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = StocksTheme.colors.textMuted,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Markets",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = StocksTheme.colors.textPrimary
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Region / Exchange Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ALL" to "All Markets", "US" to "🇺🇸 United States", "EUROPE" to "🇪🇺 Europe", "ASIA" to "🇯🇵 Japan / Asia").forEach { (code, label) ->
                val isSelected = selectedRegion == code
                Surface(
                    onClick = { selectedRegion = code },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) StocksTheme.colors.surfaceHighlight else StocksTheme.colors.surfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) AppleBlue else StocksTheme.colors.border
                    ),
                    modifier = Modifier.testTag("market_region_${code}")
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) StocksTheme.colors.textPrimary else StocksTheme.colors.textSecondary
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Main Market Category Pills (Equities, Indices, ETFs, Sectors, Movers, Calendar)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MarketSection.values().forEach { sec ->
                val isSelected = sec == selectedSection
                Surface(
                    onClick = { selectedSection = sec },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) AppleBlue else StocksTheme.colors.surfaceElevated,
                    modifier = Modifier.testTag("market_section_${sec.name}")
                ) {
                    Text(
                        text = sec.label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else StocksTheme.colors.textSecondary
                        ),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Section Content
        when (selectedSection) {
            MarketSection.EQUITIES -> {
                val equities = regionFiltered.filter { it.assetType == AssetType.EQUITY }
                InstrumentListSection(
                    instruments = equities,
                    categoryTitle = "Public Equities (${equities.size})",
                    onSelect = { viewModel.openCompanyDetail(it) }
                )
            }

            MarketSection.INDICES -> {
                val indices = regionFiltered.filter { it.assetType == AssetType.INDEX }
                Column(modifier = Modifier.fillMaxSize()) {
                    // Explanatory note distinguishing indices from exchange-traded instruments
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .background(StocksTheme.colors.surfaceElevated, RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ℹ️ Benchmark indices are indicative reference calculation series, not directly tradable instruments.",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StocksTheme.colors.textMuted,
                                fontSize = 11.sp
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    InstrumentListSection(
                        instruments = indices,
                        categoryTitle = "Benchmark & Reference Indices",
                        onSelect = { viewModel.openCompanyDetail(it) }
                    )
                }
            }

            MarketSection.ETFS -> {
                val etfs = regionFiltered.filter { it.assetType == AssetType.ETF }
                InstrumentListSection(
                    instruments = etfs,
                    categoryTitle = "Exchange-Traded Funds (ETFs)",
                    onSelect = { viewModel.openCompanyDetail(it) }
                )
            }

            MarketSection.SECTORS -> {
                SectorPerformanceSection(viewModel = viewModel)
            }

            MarketSection.MOVERS -> {
                MoversSection(
                    equities = regionFiltered.filter { it.assetType == AssetType.EQUITY },
                    onSelect = { viewModel.openCompanyDetail(it) }
                )
            }

            MarketSection.CALENDAR -> {
                EconomicCalendarSection(viewModel = viewModel)
            }
        }
    }
}

@Composable
private fun InstrumentListSection(
    instruments: List<Instrument>,
    categoryTitle: String,
    onSelect: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = categoryTitle.uppercase(Locale.US),
                style = MaterialTheme.typography.labelSmall.copy(
                    color = StocksTheme.colors.textMuted,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
        }

        items(instruments, key = { it.id }) { inst ->
            GlassCard(
                onClick = { onSelect(inst.symbol) },
                modifier = Modifier.testTag("instrument_row_${inst.symbol}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.3f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = inst.symbol,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StocksTheme.colors.textPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = StocksTheme.colors.surfaceHighlight
                            ) {
                                Text(
                                    text = inst.exchange,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.sp,
                                        color = StocksTheme.colors.textSecondary
                                    ),
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = inst.name,
                            style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textSecondary),
                            maxLines = 1
                        )
                        Text(
                            text = if (inst.peRatio != null) "P/E: ${inst.peRatio} • Cap: \$${inst.marketCap}B" else "Cap: \$${inst.marketCap}B (P/E N/A)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StocksTheme.colors.textMuted,
                                fontSize = 10.sp
                            )
                        )
                    }

                    SparklineChart(
                        points = inst.sparklinePoints,
                        isGain = inst.isGain,
                        modifier = Modifier.weight(1f)
                    )

                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.weight(1.2f)
                    ) {
                        val curr = if (inst.currency == "GBP") "£" else if (inst.currency == "EUR") "€" else if (inst.currency == "JPY") "¥" else "$"
                        Text(
                            text = String.format(Locale.US, "%s%.2f", curr, inst.currentPrice),
                            style = TabularNumberStyle.copy(
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = StocksTheme.colors.textPrimary
                            )
                        )
                        val sign = if (inst.changePercent >= 0) "+" else ""
                        Text(
                            text = String.format(Locale.US, "%s%.2f%%", sign, inst.changePercent),
                            style = TabularNumberStyle.copy(
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (inst.isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectorPerformanceSection(viewModel: MainViewModel) {
    val sectors = viewModel.marketRepo.sectorPerformance

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "S&P 500 SECTORS RELATIVE PERFORMANCE",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = StocksTheme.colors.textMuted,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
        }

        items(sectors) { (sector, pct) ->
            val isGain = pct >= 0
            GlassCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = sector,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = StocksTheme.colors.textPrimary
                            )
                        )
                        val sign = if (isGain) "+" else ""
                        Text(
                            text = String.format(Locale.US, "%s%.2f%%", sign, pct),
                            style = TabularNumberStyle.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Relative visual bar
                    val barRatio = (Math.abs(pct) / 3.0).coerceIn(0.05, 1.0).toFloat()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .background(StocksTheme.colors.surfaceHighlight, RoundedCornerShape(3.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(barRatio)
                                .height(6.dp)
                                .background(
                                    if (isGain) StocksTheme.colors.gain else StocksTheme.colors.loss,
                                    RoundedCornerShape(3.dp)
                                )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MoversSection(
    equities: List<Instrument>,
    onSelect: (String) -> Unit
) {
    val gainers = equities.sortedByDescending { it.changePercent }
    val losers = equities.sortedBy { it.changePercent }
    val active = equities.sortedByDescending { it.volume }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "TOP GAINERS",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = StocksTheme.colors.gain,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
        }
        items(gainers.take(3)) { inst ->
            MoversCard(inst, onSelect)
        }

        item {
            Text(
                text = "TOP LOSERS",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = StocksTheme.colors.loss,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
        }
        items(losers.take(3)) { inst ->
            MoversCard(inst, onSelect)
        }

        item {
            Text(
                text = "MOST ACTIVE BY VOLUME",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = StocksTheme.colors.textMuted,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
        }
        items(active.take(3)) { inst ->
            MoversCard(inst, onSelect)
        }
    }
}

@Composable
private fun MoversCard(inst: Instrument, onSelect: (String) -> Unit) {
    GlassCard(onClick = { onSelect(inst.symbol) }) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.3f)) {
                Text(
                    text = "${inst.symbol} • ${inst.exchange}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = StocksTheme.colors.textPrimary
                    )
                )
                Text(
                    text = "Vol: ${String.format(Locale.US, "%,d", inst.volume)}",
                    style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                )
            }
            SparklineChart(points = inst.sparklinePoints, isGain = inst.isGain, modifier = Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1.2f)) {
                Text(
                    text = String.format(Locale.US, "$%.2f", inst.currentPrice),
                    style = TabularNumberStyle.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = StocksTheme.colors.textPrimary
                    )
                )
                val sign = if (inst.changePercent >= 0) "+" else ""
                Text(
                    text = String.format(Locale.US, "%s%.2f%%", sign, inst.changePercent),
                    style = TabularNumberStyle.copy(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (inst.isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                    )
                )
            }
        }
    }
}

@Composable
private fun EconomicCalendarSection(viewModel: MainViewModel) {
    val events = viewModel.marketRepo.economicEvents
    val exchanges = viewModel.marketRepo.exchanges

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Exchange Operating Hours Card
        item {
            GlassCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Exchange hours",
                            tint = AppleBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "GLOBAL EXCHANGE SESSIONS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = StocksTheme.colors.textMuted,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    exchanges.forEachIndexed { i, ex ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${ex.code} (${ex.name})",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = StocksTheme.colors.textPrimary
                                    )
                                )
                                Text(
                                    text = "${ex.city} • Local: ${ex.openTime} - ${ex.closeTime} ${ex.timezone}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (ex.isOpen) StocksTheme.colors.gainSoft else StocksTheme.colors.surfaceHighlight
                            ) {
                                Text(
                                    text = if (ex.isOpen) "OPEN" else "CLOSED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (ex.isOpen) StocksTheme.colors.gain else StocksTheme.colors.textMuted
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        if (i < exchanges.size - 1) {
                            HorizontalDivider(color = StocksTheme.colors.border, thickness = 0.5.dp)
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "UPCOMING ECONOMIC RELEASES",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = StocksTheme.colors.textMuted,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
        }

        items(events) { ev ->
            GlassCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = ev.flagEmoji, fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${ev.country} • ${ev.dateStr}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = StocksTheme.colors.textMuted
                                )
                            )
                        }

                        val impactColor = if (ev.impact == "HIGH") StocksTheme.colors.loss else Color(0xFFFF9F0A)
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = impactColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${ev.impact} IMPACT",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = impactColor,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = ev.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = StocksTheme.colors.textPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Forecast: ${ev.forecast}",
                            style = TabularNumberStyle.copy(fontSize = 12.sp, color = StocksTheme.colors.textSecondary)
                        )
                        Text(
                            text = "Prior: ${ev.prior}",
                            style = TabularNumberStyle.copy(fontSize = 12.sp, color = StocksTheme.colors.textMuted)
                        )
                        Text(
                            text = "Time: ${ev.timeStr}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp, color = AppleBlue)
                        )
                    }

                    if (ev.commentary.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = ev.commentary,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = StocksTheme.colors.textMuted,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
        }
    }
}
