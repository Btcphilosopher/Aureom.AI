package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Instrument
import com.example.model.PriceAlert
import com.example.model.WatchlistGroup
import com.example.model.WatchlistSortOrder
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.components.SparklineChart
import com.example.ui.theme.AppleBlue
import com.example.ui.theme.StocksTheme
import com.example.ui.theme.TabularNumberStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WatchlistScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val watchlists by viewModel.watchlists.collectAsState()
    val allInstruments by viewModel.instruments.collectAsState()
    val alerts by viewModel.alerts.collectAsState()
    var sortOrder by remember { mutableStateOf(WatchlistSortOrder.CUSTOM) }
    var selectedWatchlistIndex by remember { mutableStateOf(0) }
    var queryText by remember { mutableStateOf("") }

    var showCreateWatchlistDialog by remember { mutableStateOf(false) }
    var showAddSymbolDialog by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var targetAlertSymbol by remember { mutableStateOf<String?>(null) }
    var showAlertsSummaryDialog by remember { mutableStateOf(false) }

    val activeWatchlist: WatchlistGroup? = watchlists.getOrNull(selectedWatchlistIndex) ?: watchlists.firstOrNull()

    // Resolve instruments for active watchlist
    val activeInstruments = remember(activeWatchlist, allInstruments, sortOrder, queryText) {
        val list = (activeWatchlist?.symbols ?: emptyList()).mapNotNull { sym ->
            allInstruments.find { it.symbol.equals(sym, ignoreCase = true) }
        }.filter {
            queryText.isEmpty() || it.symbol.contains(queryText, ignoreCase = true) || it.name.contains(queryText, ignoreCase = true)
        }

        when (sortOrder) {
            WatchlistSortOrder.NAME -> list.sortedBy { it.name }
            WatchlistSortOrder.PRICE_CHANGE -> list.sortedByDescending { it.changePercent }
            WatchlistSortOrder.PRICE -> list.sortedByDescending { it.currentPrice }
            WatchlistSortOrder.MARKET_CAP -> list.sortedByDescending { it.marketCap }
            WatchlistSortOrder.CUSTOM -> list
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 16.dp)
            .testTag("watchlist_screen")
    ) {
        // Screen Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "WATCHLISTS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = StocksTheme.colors.textMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = activeWatchlist?.name ?: "Watchlist",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = StocksTheme.colors.textPrimary
                    )
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Price Alerts Indicator
                IconButton(
                    onClick = { showAlertsSummaryDialog = true },
                    modifier = Modifier.testTag("watchlist_alerts_btn")
                ) {
                    val hasActiveAlerts = alerts.any { it.isActive }
                    Icon(
                        imageVector = if (hasActiveAlerts) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                        contentDescription = "Price Alerts",
                        tint = if (hasActiveAlerts) AppleBlue else StocksTheme.colors.textMuted
                    )
                }

                // Sort Action
                Box {
                    IconButton(
                        onClick = { showSortMenu = true },
                        modifier = Modifier.testTag("watchlist_sort_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sort,
                            contentDescription = "Sort Watchlist",
                            tint = StocksTheme.colors.textPrimary
                        )
                    }

                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false },
                        modifier = Modifier.background(StocksTheme.colors.surfaceElevated)
                    ) {
                        WatchlistSortOrder.values().forEach { order ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        order.label,
                                        color = if (order == sortOrder) AppleBlue else StocksTheme.colors.textPrimary
                                    )
                                },
                                onClick = {
                                    sortOrder = order
                                    showSortMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Multiple Named Watchlist Segmented Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            watchlists.forEachIndexed { index, group ->
                val isSelected = index == selectedWatchlistIndex
                Surface(
                    onClick = { selectedWatchlistIndex = index },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) StocksTheme.colors.surfaceHighlight else StocksTheme.colors.surfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) AppleBlue else StocksTheme.colors.border
                    ),
                    modifier = Modifier.testTag("watchlist_tab_${group.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = group.name,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) StocksTheme.colors.textPrimary else StocksTheme.colors.textSecondary
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${group.symbols.size}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StocksTheme.colors.textMuted
                            )
                        )
                    }
                }
            }

            // Add New Watchlist Button
            Surface(
                onClick = { showCreateWatchlistDialog = true },
                shape = RoundedCornerShape(12.dp),
                color = StocksTheme.colors.surfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, StocksTheme.colors.border),
                modifier = Modifier.testTag("watchlist_create_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Watchlist",
                        tint = AppleBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "New List",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = AppleBlue,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search in current watchlist & Add Symbol action
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = queryText,
                onValueChange = { queryText = it },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("watchlist_search_input"),
                placeholder = { Text("Filter ${activeWatchlist?.name ?: "list"}...", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Search",
                        tint = StocksTheme.colors.textMuted,
                        modifier = Modifier.size(18.dp)
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AppleBlue,
                    unfocusedBorderColor = StocksTheme.colors.border,
                    focusedContainerColor = StocksTheme.colors.surfaceElevated,
                    unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                )
            )

            FilledTonalButton(
                onClick = { showAddSymbolDialog = true },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .height(50.dp)
                    .testTag("watchlist_add_symbol_btn"),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = StocksTheme.colors.surfaceElevated
                )
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add symbol",
                    tint = AppleBlue,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add", color = AppleBlue, fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Watchlist Items
        if (activeInstruments.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (queryText.isNotEmpty()) "No matching symbols" else "Watchlist is empty",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = StocksTheme.colors.textPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Add instruments from search or explore markets",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = StocksTheme.colors.textMuted
                        )
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(activeInstruments, key = { it.symbol }) { inst ->
                    val hasAlert = alerts.any { it.symbol.equals(inst.symbol, ignoreCase = true) && it.isActive }

                    GlassCard(
                        onClick = { viewModel.openCompanyDetail(inst.symbol) },
                        modifier = Modifier.testTag("watchlist_item_${inst.symbol}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left: Symbol & Exchange
                            Column(modifier = Modifier.weight(1.3f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = inst.symbol,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    if (hasAlert) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.NotificationsActive,
                                            contentDescription = "Active alert",
                                            tint = AppleBlue,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${inst.exchange} • ${inst.currency}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = StocksTheme.colors.textMuted,
                                        fontSize = 11.sp
                                    )
                                )
                                Text(
                                    text = inst.name,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = StocksTheme.colors.textSecondary
                                    ),
                                    maxLines = 1
                                )
                            }

                            // Center: Sparkline
                            SparklineChart(
                                points = inst.sparklinePoints,
                                isGain = inst.isGain,
                                modifier = Modifier.weight(1f)
                            )

                            // Right: Price & Change Pill
                            Column(
                                horizontalAlignment = Alignment.End,
                                modifier = Modifier.weight(1.2f)
                            ) {
                                val currSymbol = if (inst.currency == "GBP") "£" else if (inst.currency == "EUR") "€" else "$"
                                Text(
                                    text = String.format(Locale.US, "%s%.2f", currSymbol, inst.currentPrice),
                                    style = TabularNumberStyle.copy(
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.textPrimary
                                    )
                                )

                                Spacer(modifier = Modifier.height(2.dp))

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (inst.isGain) StocksTheme.colors.gainSoft else StocksTheme.colors.lossSoft
                                ) {
                                    val sign = if (inst.changePercent >= 0) "+" else ""
                                    Text(
                                        text = String.format(Locale.US, "%s%.2f%%", sign, inst.changePercent),
                                        style = TabularNumberStyle.copy(
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (inst.isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            // Remove Action
                            IconButton(
                                onClick = {
                                    activeWatchlist?.let { wl ->
                                        viewModel.toggleSymbolInWatchlist(wl.id, inst.symbol)
                                    }
                                },
                                modifier = Modifier
                                    .size(32.dp)
                                    .padding(start = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Remove from watchlist",
                                    tint = StocksTheme.colors.textMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Create New Watchlist Dialog
    if (showCreateWatchlistDialog) {
        var newListName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateWatchlistDialog = false },
            title = { Text("New Watchlist", color = StocksTheme.colors.textPrimary) },
            text = {
                OutlinedTextField(
                    value = newListName,
                    onValueChange = { newListName = it },
                    placeholder = { Text("List Name (e.g. Semiconductors)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppleBlue,
                        focusedContainerColor = StocksTheme.colors.surfaceElevated,
                        unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newListName.isNotBlank()) {
                            viewModel.createWatchlist(newListName.trim())
                            showCreateWatchlistDialog = false
                        }
                    }
                ) {
                    Text("Create", color = AppleBlue)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateWatchlistDialog = false }) {
                    Text("Cancel", color = StocksTheme.colors.textMuted)
                }
            },
            containerColor = StocksTheme.colors.surfaceElevated
        )
    }

    // Add Symbol to Watchlist Dialog
    if (showAddSymbolDialog) {
        var pickerQuery by remember { mutableStateOf("") }
        val availableToAdd = allInstruments.filter { inst ->
            activeWatchlist?.symbols?.contains(inst.symbol) != true &&
                    (pickerQuery.isEmpty() || inst.symbol.contains(pickerQuery, ignoreCase = true) || inst.name.contains(pickerQuery, ignoreCase = true))
        }

        AlertDialog(
            onDismissRequest = { showAddSymbolDialog = false },
            title = { Text("Add to ${activeWatchlist?.name}", color = StocksTheme.colors.textPrimary) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = pickerQuery,
                        onValueChange = { pickerQuery = it },
                        placeholder = { Text("Search symbol or company...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AppleBlue,
                            focusedContainerColor = StocksTheme.colors.surfaceElevated,
                            unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn(modifier = Modifier.height(240.dp)) {
                        items(availableToAdd) { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        activeWatchlist?.let { wl ->
                                            viewModel.toggleSymbolInWatchlist(wl.id, item.symbol)
                                        }
                                        showAddSymbolDialog = false
                                    }
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${item.symbol} • ${item.name}",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    Text(
                                        text = "${item.exchange} • ${item.currency}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = StocksTheme.colors.textMuted
                                        )
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add",
                                    tint = AppleBlue
                                )
                            }
                            HorizontalDivider(color = StocksTheme.colors.border)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddSymbolDialog = false }) {
                    Text("Done", color = AppleBlue)
                }
            },
            containerColor = StocksTheme.colors.surfaceElevated
        )
    }

    // Price Alerts Summary Modal
    if (showAlertsSummaryDialog) {
        AlertDialog(
            onDismissRequest = { showAlertsSummaryDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "Alerts",
                        tint = AppleBlue
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Price Alerts", color = StocksTheme.colors.textPrimary)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Local alert engine active. In demonstration mode, alerts are evaluated upon market feed ticks. Server push alerts require remote provider configuration.",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.textMuted,
                            lineHeight = 15.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (alerts.isEmpty()) {
                        Text(
                            text = "No active price alerts set.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = StocksTheme.colors.textSecondary)
                        )
                    } else {
                        LazyColumn(modifier = Modifier.height(200.dp)) {
                            items(alerts) { alert ->
                                val inst = allInstruments.find { it.symbol == alert.symbol }
                                val isTriggered = if (alert.isAbove) {
                                    (inst?.currentPrice ?: 0.0) >= alert.targetPrice
                                } else {
                                    (inst?.currentPrice ?: 999999.0) <= alert.targetPrice
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${alert.symbol} ${if (alert.isAbove) "≥" else "≤"} \$${alert.targetPrice}",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = StocksTheme.colors.textPrimary
                                            )
                                        )
                                        if (alert.note.isNotEmpty()) {
                                            Text(
                                                text = alert.note,
                                                style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                                            )
                                        }
                                        Text(
                                            text = if (isTriggered) "Status: TRIGGERED" else "Status: Monitoring",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (isTriggered) StocksTheme.colors.gain else AppleBlue,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        )
                                    }

                                    IconButton(
                                        onClick = { viewModel.deletePriceAlert(alert.id) }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Delete alert",
                                            tint = StocksTheme.colors.loss
                                        )
                                    }
                                }
                                HorizontalDivider(color = StocksTheme.colors.border)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAlertsSummaryDialog = false }) {
                    Text("Close", color = AppleBlue)
                }
            },
            containerColor = StocksTheme.colors.surfaceElevated
        )
    }
}
