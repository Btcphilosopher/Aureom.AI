package com.example.data

import com.example.model.AssetType
import com.example.model.ChartRange
import com.example.model.EconomicEvent
import com.example.model.ExchangeInfo
import com.example.model.HistoricalPoint
import com.example.model.Instrument
import com.example.model.MarketNews
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MarketDataRepository {

    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.US)

    // Pre-populated market instruments with varied currencies, exchanges, and fundamentals
    private val initialInstruments = listOf(
        Instrument(
            id = "AAPL.NASDAQ",
            symbol = "AAPL",
            name = "Apple Inc.",
            exchange = "NASDAQ",
            currency = "USD",
            assetType = AssetType.EQUITY,
            currentPrice = 224.23,
            previousClose = 221.55,
            openPrice = 222.10,
            dayHigh = 225.80,
            dayLow = 221.90,
            marketCap = 3420.5,
            peRatio = 33.8,
            forwardPe = 29.4,
            eps = 6.63,
            dividendYield = 0.45,
            exDividendDate = "Nov 10, 2026",
            volume = 48291000L,
            avgVolume = 51200000L,
            beta = 1.08,
            high52 = 237.23,
            low52 = 164.08,
            description = "Apple Inc. designs, manufactures, and markets smartphones, personal computers, tablets, wearables, and accessories, and sells a variety of related services.",
            sector = "Technology",
            dataSource = "Consolidated Tape Association (Delayed 15m)",
            quoteFreshness = "Delayed 15m",
            isMarketOpen = true,
            sparklinePoints = listOf(221.55, 222.10, 223.40, 222.80, 224.10, 223.90, 224.23)
        ),
        Instrument(
            id = "NVDA.NASDAQ",
            symbol = "NVDA",
            name = "NVIDIA Corporation",
            exchange = "NASDAQ",
            currency = "USD",
            assetType = AssetType.EQUITY,
            currentPrice = 142.80,
            previousClose = 138.25,
            openPrice = 139.50,
            dayHigh = 144.10,
            dayLow = 139.10,
            marketCap = 3510.2,
            peRatio = 64.2,
            forwardPe = 38.5,
            eps = 2.22,
            dividendYield = 0.03,
            exDividendDate = "Dec 04, 2026",
            volume = 68420000L,
            avgVolume = 62100000L,
            beta = 1.68,
            high52 = 149.77,
            low52 = 45.60,
            description = "NVIDIA Corporation provides graphics, computing and networking solutions. Its GPU architectures drive AI acceleration, data centers, and gaming.",
            sector = "Technology",
            dataSource = "NASDAQ Real-Time (Simulated Feed)",
            quoteFreshness = "Live (Simulated)",
            isMarketOpen = true,
            sparklinePoints = listOf(138.25, 139.50, 140.20, 141.80, 141.50, 143.20, 142.80)
        ),
        Instrument(
            id = "MSFT.NASDAQ",
            symbol = "MSFT",
            name = "Microsoft Corporation",
            exchange = "NASDAQ",
            currency = "USD",
            assetType = AssetType.EQUITY,
            currentPrice = 418.15,
            previousClose = 422.30,
            openPrice = 421.00,
            dayHigh = 422.50,
            dayLow = 416.80,
            marketCap = 3105.8,
            peRatio = 35.1,
            forwardPe = 30.2,
            eps = 11.91,
            dividendYield = 0.78,
            exDividendDate = "Nov 20, 2026",
            volume = 21400000L,
            avgVolume = 23100000L,
            beta = 0.92,
            high52 = 468.35,
            low52 = 366.50,
            description = "Microsoft develops and supports software, services, devices and solutions including Azure Cloud, Office 365, Windows, and gaming.",
            sector = "Technology",
            dataSource = "Consolidated Tape Association (Delayed 15m)",
            quoteFreshness = "Delayed 15m",
            isMarketOpen = true,
            sparklinePoints = listOf(422.30, 421.00, 420.50, 419.20, 417.80, 418.50, 418.15)
        ),
        Instrument(
            id = "BIOX.NASDAQ",
            symbol = "BIOX",
            name = "BioNext Genomics",
            exchange = "NASDAQ",
            currency = "USD",
            assetType = AssetType.EQUITY,
            currentPrice = 18.45,
            previousClose = 19.80,
            openPrice = 19.50,
            dayHigh = 19.90,
            dayLow = 17.90,
            marketCap = 1.45,
            peRatio = null, // Missing fundamentals (pre-profit growth)
            forwardPe = null,
            eps = -1.24,
            dividendYield = null, // No dividend
            exDividendDate = null,
            volume = 8200000L,
            avgVolume = 5400000L,
            beta = 2.15,
            high52 = 34.20,
            low52 = 9.80,
            description = "Clinical-stage biotechnology firm researching targeted mRNA therapeutics for rare metabolic disorders. Currently non-profitable.",
            sector = "Healthcare",
            dataSource = "Simulated Market Feed (Demo)",
            quoteFreshness = "Simulated Demo",
            isMarketOpen = true,
            sparklinePoints = listOf(19.80, 19.50, 18.90, 18.10, 18.60, 18.20, 18.45)
        ),
        Instrument(
            id = "AZN.LSE",
            symbol = "AZN",
            name = "AstraZeneca PLC",
            exchange = "LSE",
            currency = "GBP",
            assetType = AssetType.EQUITY,
            currentPrice = 118.50, // in GBP (£)
            previousClose = 116.20,
            openPrice = 116.80,
            dayHigh = 119.10,
            dayLow = 116.50,
            marketCap = 183.4,
            peRatio = 38.6,
            forwardPe = 18.2,
            eps = 3.07,
            dividendYield = 2.15,
            exDividendDate = "Aug 08, 2026",
            volume = 3800000L,
            avgVolume = 4100000L,
            beta = 0.55,
            high52 = 134.00,
            low52 = 97.60,
            description = "Biopharmaceutical company focusing on discovery, development, and commercialization of prescription medicines in oncology and rare diseases.",
            sector = "Healthcare",
            dataSource = "London Stock Exchange Level 1",
            quoteFreshness = "Delayed 15m",
            isMarketOpen = false, // Closed market demonstration
            sparklinePoints = listOf(116.20, 116.80, 117.50, 118.00, 118.80, 118.30, 118.50)
        ),
        Instrument(
            id = "MC.EURONEXT",
            symbol = "MC",
            name = "LVMH Moët Hennessy",
            exchange = "EURONEXT",
            currency = "EUR",
            assetType = AssetType.EQUITY,
            currentPrice = 642.80, // in EUR (€)
            previousClose = 654.10,
            openPrice = 650.00,
            dayHigh = 652.50,
            dayLow = 638.00,
            marketCap = 321.8,
            peRatio = 22.4,
            forwardPe = 21.1,
            eps = 28.70,
            dividendYield = 2.02,
            exDividendDate = "Dec 02, 2026",
            volume = 680000L,
            avgVolume = 740000L,
            beta = 1.05,
            high52 = 886.00,
            low52 = 582.00,
            description = "World leader in luxury goods comprising Wines & Spirits, Fashion & Leather Goods, Perfumes & Cosmetics, and Watches & Jewelry.",
            sector = "Consumer Discretionary",
            dataSource = "Euronext Paris Level 1",
            quoteFreshness = "Delayed 15m",
            isMarketOpen = false,
            sparklinePoints = listOf(654.10, 650.00, 646.00, 641.50, 644.20, 640.10, 642.80)
        ),
        Instrument(
            id = "7203.TSE",
            symbol = "7203",
            name = "Toyota Motor Corp.",
            exchange = "TSE",
            currency = "JPY",
            assetType = AssetType.EQUITY,
            currentPrice = 2780.0, // in JPY (¥)
            previousClose = 2745.0,
            openPrice = 2750.0,
            dayHigh = 2795.0,
            dayLow = 2740.0,
            marketCap = 43200.0,
            peRatio = 9.8,
            forwardPe = 8.9,
            eps = 283.6,
            dividendYield = 3.20,
            exDividendDate = "Sep 28, 2026",
            volume = 28400000L,
            avgVolume = 31200000L,
            beta = 0.72,
            high52 = 3870.0,
            low52 = 2390.0,
            description = "Japanese multinational automotive manufacturer headquartered in Toyota City, Aichi, Japan. Leading hybrid vehicle pioneer.",
            sector = "Consumer Discretionary",
            dataSource = "Tokyo Stock Exchange (Closed)",
            quoteFreshness = "EOD (Closed)",
            isMarketOpen = false,
            sparklinePoints = listOf(2745.0, 2750.0, 2762.0, 2775.0, 2770.0, 2790.0, 2780.0)
        ),
        // Indices & Benchmarks
        Instrument(
            id = "SPX.INDEX",
            symbol = "^GSPC",
            name = "S&P 500",
            exchange = "INDEX",
            currency = "USD",
            assetType = AssetType.INDEX,
            currentPrice = 5983.25,
            previousClose = 5962.10,
            openPrice = 5970.00,
            dayHigh = 5995.10,
            dayLow = 5965.40,
            marketCap = 48500.0,
            peRatio = 27.8,
            dividendYield = 1.32,
            description = "Standard & Poor's 500 Index representing the 500 largest publicly traded US corporations.",
            sector = "Benchmark Index",
            dataSource = "Cboe Global Indices (Delayed 15m)",
            quoteFreshness = "Delayed 15m",
            isMarketOpen = true,
            sparklinePoints = listOf(5962.1, 5970.0, 5978.4, 5974.1, 5988.2, 5980.5, 5983.25)
        ),
        Instrument(
            id = "IXIC.INDEX",
            symbol = "^IXIC",
            name = "NASDAQ Composite",
            exchange = "INDEX",
            currency = "USD",
            assetType = AssetType.INDEX,
            currentPrice = 19281.40,
            previousClose = 19165.20,
            openPrice = 19200.00,
            dayHigh = 19320.50,
            dayLow = 19180.20,
            marketCap = 28900.0,
            peRatio = 34.5,
            dividendYield = 0.85,
            description = "Market capitalization-weighted index of more than 3,000 common equities listed on NASDAQ.",
            sector = "Benchmark Index",
            dataSource = "NASDAQ Indices (Delayed 15m)",
            quoteFreshness = "Delayed 15m",
            isMarketOpen = true,
            sparklinePoints = listOf(19165.2, 19200.0, 19230.1, 19220.4, 19290.0, 19270.8, 19281.4)
        ),
        Instrument(
            id = "DJI.INDEX",
            symbol = "^DJI",
            name = "Dow Jones Industrial",
            exchange = "INDEX",
            currency = "USD",
            assetType = AssetType.INDEX,
            currentPrice = 43988.99,
            previousClose = 44210.40,
            openPrice = 44150.00,
            dayHigh = 44220.00,
            dayLow = 43920.00,
            marketCap = 14200.0,
            peRatio = 22.1,
            dividendYield = 1.82,
            description = "Price-weighted measurement stock market index of 30 prominent companies listed on stock exchanges in the US.",
            sector = "Benchmark Index",
            dataSource = "S&P Dow Jones Indices",
            quoteFreshness = "Delayed 15m",
            isMarketOpen = true,
            sparklinePoints = listOf(44210.4, 44150.0, 44100.2, 44020.5, 43950.0, 43970.0, 43988.99)
        ),
        Instrument(
            id = "FTSE.INDEX",
            symbol = "^FTSE",
            name = "FTSE 100",
            exchange = "LSE",
            currency = "GBP",
            assetType = AssetType.INDEX,
            currentPrice = 8072.39,
            previousClose = 8055.10,
            openPrice = 8060.00,
            dayHigh = 8090.20,
            dayLow = 8045.00,
            marketCap = 2100.0,
            peRatio = 14.2,
            dividendYield = 3.85,
            description = "Share index of the 100 companies listed on the London Stock Exchange with the highest market capitalization.",
            sector = "Benchmark Index",
            dataSource = "FTSE Russell (Closed)",
            quoteFreshness = "EOD (Closed)",
            isMarketOpen = false,
            sparklinePoints = listOf(8055.1, 8060.0, 8068.4, 8075.0, 8065.2, 8070.1, 8072.39)
        ),
        // ETFs
        Instrument(
            id = "SPY.NYSE",
            symbol = "SPY",
            name = "SPDR S&P 500 ETF Trust",
            exchange = "NYSE",
            currency = "USD",
            assetType = AssetType.ETF,
            currentPrice = 597.45,
            previousClose = 595.10,
            openPrice = 595.90,
            dayHigh = 598.20,
            dayLow = 595.50,
            marketCap = 580.2,
            peRatio = 27.5,
            dividendYield = 1.25,
            volume = 42100000L,
            avgVolume = 54000000L,
            beta = 1.00,
            high52 = 599.10,
            low52 = 468.20,
            description = "Tracks the performance of the S&P 500 Index. The oldest and largest exchange-traded fund.",
            sector = "Broad Market ETF",
            dataSource = "Consolidated Tape Association",
            quoteFreshness = "Delayed 15m",
            isMarketOpen = true,
            sparklinePoints = listOf(595.1, 595.9, 596.5, 596.2, 597.8, 597.1, 597.45)
        ),
        Instrument(
            id = "QQQ.NASDAQ",
            symbol = "QQQ",
            name = "Invesco QQQ Trust",
            exchange = "NASDAQ",
            currency = "USD",
            assetType = AssetType.ETF,
            currentPrice = 514.80,
            previousClose = 510.40,
            openPrice = 511.50,
            dayHigh = 516.20,
            dayLow = 511.00,
            marketCap = 295.4,
            peRatio = 32.1,
            dividendYield = 0.58,
            volume = 36800000L,
            avgVolume = 41200000L,
            beta = 1.18,
            high52 = 518.50,
            low52 = 382.40,
            description = "Tracks the NASDAQ-100 Index with heavy exposure to technology, communications, and consumer discretionary.",
            sector = "Tech ETF",
            dataSource = "NASDAQ Real-Time (Simulated)",
            quoteFreshness = "Live (Simulated)",
            isMarketOpen = true,
            sparklinePoints = listOf(510.4, 511.5, 512.8, 512.2, 515.1, 514.2, 514.8)
        )
    )

    private val _instruments = MutableStateFlow<List<Instrument>>(initialInstruments)
    val instruments: StateFlow<List<Instrument>> = _instruments.asStateFlow()

    // Economic Events Calendar
    val economicEvents = listOf(
        EconomicEvent(
            id = "EVT-01",
            title = "FOMC Interest Rate Decision",
            country = "United States",
            flagEmoji = "🇺🇸",
            dateStr = "Nov 12, 2026",
            timeStr = "14:00 EST",
            impact = "HIGH",
            actual = null,
            forecast = "4.50%",
            prior = "4.75%",
            commentary = "Markets price a 78% probability of a 25bps rate cut."
        ),
        EconomicEvent(
            id = "EVT-02",
            title = "Consumer Price Index (CPI YoY)",
            country = "United States",
            flagEmoji = "🇺🇸",
            dateStr = "Nov 13, 2026",
            timeStr = "08:30 EST",
            impact = "HIGH",
            actual = null,
            forecast = "2.6%",
            prior = "2.4%",
            commentary = "Core inflation expected to hold steady at 3.3%."
        ),
        EconomicEvent(
            id = "EVT-03",
            title = "Nonfarm Payrolls (NFP)",
            country = "United States",
            flagEmoji = "🇺🇸",
            dateStr = "Dec 04, 2026",
            timeStr = "08:30 EST",
            impact = "HIGH",
            actual = null,
            forecast = "+145K",
            prior = "+12K",
            commentary = "Rebound anticipated following prior month hurricane distortions."
        ),
        EconomicEvent(
            id = "EVT-04",
            title = "ECB Monetary Policy Statement",
            country = "Eurozone",
            flagEmoji = "🇪🇺",
            dateStr = "Dec 12, 2026",
            timeStr = "13:15 CET",
            impact = "MED",
            actual = null,
            forecast = "3.00%",
            prior = "3.25%",
            commentary = "Governing council expected to ease deposit rate."
        ),
        EconomicEvent(
            id = "EVT-05",
            title = "BoE Official Bank Rate",
            country = "United Kingdom",
            flagEmoji = "🇬🇧",
            dateStr = "Dec 18, 2026",
            timeStr = "12:00 GMT",
            impact = "MED",
            actual = null,
            forecast = "4.75%",
            prior = "4.75%",
            commentary = "Bank of England expected to pause amidst persistent service inflation."
        )
    )

    // Curated Market News & Editorial Briefing
    val marketNews = listOf(
        MarketNews(
            id = "NEWS-1",
            title = "Semiconductor Surge Drives NASDAQ to New Highs as Enterprise AI Spending Expands",
            source = "Financial Chronicle",
            timeAgo = "18m ago",
            summary = "Chipmakers led broad technology gains as major cloud hyperscalers reaffirmed multi-billion capital expenditure targets for data center infrastructure.",
            content = "Global equities advanced in early trading, led by semiconductor manufacturers and infrastructure suppliers. Investors weighed robust earnings revisions against upcoming Federal Reserve policy remarks. Volume remained elevated in tech mega-caps, with market breadth showing notable improvement across mid-cap industrials.",
            relatedSymbol = "NVDA",
            category = "Technology"
        ),
        MarketNews(
            id = "NEWS-2",
            title = "Apple Reports Record Services Revenue Alongside Robust iPhone Pro Upgrade Cycle",
            source = "Dow Jones Newswires",
            timeAgo = "1h ago",
            summary = "Services margins reached an all-time peak of 74.2%, offsetting subdued regional hardware headwinds and supporting strong buyback execution.",
            content = "Apple's latest quarterly filing highlighted steady consumer migration toward premium tier devices. Operating cash flow surpassed consensus expectations by 4.2%, allowing the Cupertino firm to maintain its steady capital return cadence of quarterly dividends and share retirements.",
            relatedSymbol = "AAPL",
            category = "Earnings"
        ),
        MarketNews(
            id = "NEWS-3",
            title = "European Luxury Shares Consolidate as Chinese Retail Sales Exhibit Early Stabilization",
            source = "Reuters Business",
            timeAgo = "2h ago",
            summary = "LVMH and Kering traded in narrow ranges while analysts debated whether recent fiscal stimulus in Beijing will bolster high-end consumer discretionary demand.",
            content = "Trading on Euronext Paris closed slightly lower for luxury conglomerates. Management noted steady travel retail resilience across Japan and Europe, though domestic department store traffic remains subject to consumer caution.",
            relatedSymbol = "MC",
            category = "Retail & Luxury"
        ),
        MarketNews(
            id = "NEWS-4",
            title = "AstraZeneca Advances Oncology Pipeline with Phase III Trial Endpoint Milestone",
            source = "London Market Report",
            timeAgo = "3h ago",
            summary = "Dual-antibody ADC conjugate demonstrated statistically significant progression-free survival in metastatic breast cancer trials.",
            content = "AstraZeneca reported encouraging phase III trial results for its next-generation antibody-drug conjugate. Regulatory submission packages are scheduled for review with the FDA and EMA early next quarter.",
            relatedSymbol = "AZN",
            category = "Healthcare"
        )
    )

    // Global Exchanges
    val exchanges = listOf(
        ExchangeInfo("NYSE", "New York Stock Exchange", "New York", "EST", "09:30", "16:00", "Open • Closes 16:00 EST", true),
        ExchangeInfo("NASDAQ", "NASDAQ Stock Market", "New York", "EST", "09:30", "16:00", "Open • Closes 16:00 EST", true),
        ExchangeInfo("LSE", "London Stock Exchange", "London", "GMT", "08:00", "16:30", "Closed • Reopens 08:00 GMT", false),
        ExchangeInfo("EURONEXT", "Euronext Paris", "Paris", "CET", "09:00", "17:30", "Closed • Reopens 09:00 CET", false),
        ExchangeInfo("TSE", "Tokyo Stock Exchange", "Tokyo", "JST", "09:00", "15:30", "Closed • Reopens 09:00 JST", false)
    )

    // Sector performance
    val sectorPerformance = listOf(
        Pair("Technology", +2.14),
        Pair("Communication Services", +1.45),
        Pair("Consumer Discretionary", +0.82),
        Pair("Financials", +0.35),
        Pair("Industrials", -0.12),
        Pair("Healthcare", -0.48),
        Pair("Materials", -0.76),
        Pair("Energy", -1.25),
        Pair("Utilities", -0.92)
    )

    fun getInstrumentBySymbol(symbol: String): Instrument? {
        return _instruments.value.find { it.symbol.equals(symbol, ignoreCase = true) }
    }

    // Historical price generator with Split & Dividend annotations
    fun getHistoricalSeries(symbol: String, range: ChartRange, isAdjusted: Boolean = true): List<HistoricalPoint> {
        val instrument = getInstrumentBySymbol(symbol) ?: initialInstruments.first()
        val basePrice = instrument.currentPrice
        val points = mutableListOf<HistoricalPoint>()
        val count = when (range) {
            ChartRange.DAY -> 35
            ChartRange.WEEK -> 40
            ChartRange.MONTH -> 45
            ChartRange.YEAR -> 52
            ChartRange.ALL -> 60
        }

        val stepMillis = when (range) {
            ChartRange.DAY -> 10 * 60 * 1000L // 10 min
            ChartRange.WEEK -> 4 * 3600 * 1000L // 4 hours
            ChartRange.MONTH -> 24 * 3600 * 1000L // 1 day
            ChartRange.YEAR -> 7 * 24 * 3600 * 1000L // 1 week
            ChartRange.ALL -> 30 * 24 * 3600 * 1000L // 1 month
        }

        val now = System.currentTimeMillis()
        var currentP = when (range) {
            ChartRange.DAY -> instrument.openPrice
            ChartRange.WEEK -> basePrice * 0.96
            ChartRange.MONTH -> basePrice * 0.92
            ChartRange.YEAR -> basePrice * 0.78
            ChartRange.ALL -> basePrice * 0.35
        }

        val random = Random(symbol.hashCode() + range.ordinal)

        for (i in 0 until count) {
            val ts = now - (count - 1 - i) * stepMillis
            val drift = (basePrice - currentP) / (count - i).coerceAtLeast(1)
            val noise = (random.nextDouble() - 0.48) * (basePrice * 0.02)
            currentP = (currentP + drift + noise).coerceAtLeast(1.0)

            val label = when (range) {
                ChartRange.DAY -> timeFormat.format(Date(ts))
                ChartRange.WEEK, ChartRange.MONTH -> SimpleDateFormat("MMM dd", Locale.US).format(Date(ts))
                ChartRange.YEAR, ChartRange.ALL -> SimpleDateFormat("MMM yyyy", Locale.US).format(Date(ts))
            }

            // Split and Dividend markers on specific points
            val isSplitPoint = (range == ChartRange.ALL && i == 20 && symbol == "NVDA") || (range == ChartRange.YEAR && i == 25 && symbol == "AAPL")
            val splitRatio = if (isSplitPoint) (if (symbol == "NVDA") "10:1 Split" else "4:1 Split") else null

            val isDivPoint = (range == ChartRange.MONTH && i == 15) || (range == ChartRange.YEAR && i == 30)
            val divAmt = if (isDivPoint) (if (symbol == "AAPL") 0.25 else 0.45) else null

            // If not adjusted and prior to split, unadjusted price was 10x or 4x higher
            val unadjustedMultiplier = if (!isAdjusted && isSplitPoint) 4.0 else 1.0
            val recordedPrice = currentP * unadjustedMultiplier

            points.add(
                HistoricalPoint(
                    timestamp = ts,
                    label = label,
                    price = Math.round(recordedPrice * 100.0) / 100.0,
                    adjustedPrice = Math.round(currentP * 100.0) / 100.0,
                    volume = (random.nextLong(1000000L, 5000000L)),
                    isSplit = isSplitPoint,
                    splitRatio = splitRatio,
                    isDividend = isDivPoint,
                    dividendAmount = divAmt
                )
            )
        }

        // Ensure final point matches currentPrice exactly
        if (points.isNotEmpty()) {
            val last = points.last()
            points[points.size - 1] = last.copy(price = basePrice, adjustedPrice = basePrice)
        }

        return points
    }

    // Ticks market prices slightly to simulate live feed
    fun simulateLiveTick() {
        val updated = _instruments.value.map { inst ->
            if (!inst.isMarketOpen) return@map inst
            val deltaPct = (Random.nextDouble() - 0.49) * 0.003 // +/- 0.15%
            val newPrice = Math.round((inst.currentPrice * (1.0 + deltaPct)) * 100.0) / 100.0
            val newPoints = inst.sparklinePoints.toMutableList()
            if (newPoints.isNotEmpty()) {
                newPoints[newPoints.size - 1] = newPrice
            }
            inst.copy(
                currentPrice = newPrice,
                sparklinePoints = newPoints,
                quoteTimestamp = System.currentTimeMillis()
            )
        }
        _instruments.value = updated
    }
}
