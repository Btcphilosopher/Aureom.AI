package com.example.accounting

import com.example.model.CostBasisMethod
import com.example.model.Instrument
import com.example.model.PortfolioHolding
import com.example.model.PortfolioSummary
import com.example.model.TransactionRecord
import com.example.model.TransactionType
import java.math.BigDecimal
import java.math.RoundingMode

object FxRates {
    // Deterministic FX Rates relative to USD base
    private val ratesToUsd = mapOf(
        "USD" to BigDecimal("1.0"),
        "EUR" to BigDecimal("1.0850"),
        "GBP" to BigDecimal("1.2820"),
        "JPY" to BigDecimal("0.0066")
    )

    fun convert(amount: BigDecimal, fromCurrency: String, toCurrency: String = "USD"): BigDecimal {
        if (fromCurrency.equals(toCurrency, ignoreCase = true)) return amount
        val fromRate = ratesToUsd[fromCurrency.uppercase()] ?: BigDecimal.ONE
        val toRate = ratesToUsd[toCurrency.uppercase()] ?: BigDecimal.ONE
        // amount in USD = amount * fromRate
        // amount in target = (amount * fromRate) / toRate
        val inUsd = amount.multiply(fromRate)
        return inUsd.divide(toRate, 4, RoundingMode.HALF_UP)
    }

    fun getRateToUsd(currency: String): BigDecimal {
        return ratesToUsd[currency.uppercase()] ?: BigDecimal.ONE
    }
}

data class FifoLot(
    var remainingQty: BigDecimal,
    val pricePerShareInUsd: BigDecimal,
    val timestamp: Long
)

class PortfolioCalculator {

    fun calculateHoldingsAndSummary(
        transactions: List<TransactionRecord>,
        instrumentsMap: Map<String, Instrument>,
        initialCash: BigDecimal,
        baseCurrency: String = "USD",
        method: CostBasisMethod = CostBasisMethod.FIFO
    ): Pair<List<PortfolioHolding>, PortfolioSummary> {
        // Sort transactions chronologically
        val sortedTx = transactions.sortedBy { it.timestamp }

        // Track per-symbol buy lots for FIFO, and accumulated stats
        val lotsBySymbol = mutableMapOf<String, MutableList<FifoLot>>()
        val totalDividendsBySymbol = mutableMapOf<String, BigDecimal>()
        val realizedGainBySymbol = mutableMapOf<String, BigDecimal>()
        val totalBoughtQty = mutableMapOf<String, BigDecimal>()
        val totalBoughtCostUsd = mutableMapOf<String, BigDecimal>()
        val totalSoldQty = mutableMapOf<String, BigDecimal>()

        var cash = initialCash

        for (tx in sortedTx) {
            val symbol = tx.symbol.uppercase()
            val txCurrency = tx.currency.ifEmpty { "USD" }
            val priceInUsd = FxRates.convert(tx.pricePerShare, txCurrency, baseCurrency)
            val feeInUsd = FxRates.convert(tx.fee, txCurrency, baseCurrency)

            when (tx.type) {
                TransactionType.DEPOSIT -> {
                    val amountInUsd = FxRates.convert(tx.pricePerShare, txCurrency, baseCurrency)
                    cash = cash.add(amountInUsd).subtract(feeInUsd)
                }
                TransactionType.WITHDRAWAL -> {
                    val amountInUsd = FxRates.convert(tx.pricePerShare, txCurrency, baseCurrency)
                    cash = cash.subtract(amountInUsd).subtract(feeInUsd)
                }
                TransactionType.DIVIDEND -> {
                    // pricePerShare is the dividend payout amount
                    val divAmountInUsd = FxRates.convert(tx.pricePerShare, txCurrency, baseCurrency)
                    cash = cash.add(divAmountInUsd).subtract(feeInUsd)
                    totalDividendsBySymbol[symbol] = (totalDividendsBySymbol[symbol] ?: BigDecimal.ZERO).add(divAmountInUsd)
                }
                TransactionType.BUY -> {
                    val tradeCostUsd = tx.quantity.multiply(priceInUsd).add(feeInUsd)
                    cash = cash.subtract(tradeCostUsd)

                    val lots = lotsBySymbol.getOrPut(symbol) { mutableListOf() }
                    lots.add(FifoLot(tx.quantity, priceInUsd, tx.timestamp))

                    totalBoughtQty[symbol] = (totalBoughtQty[symbol] ?: BigDecimal.ZERO).add(tx.quantity)
                    totalBoughtCostUsd[symbol] = (totalBoughtCostUsd[symbol] ?: BigDecimal.ZERO).add(tradeCostUsd)
                }
                TransactionType.SELL -> {
                    val grossProceedsUsd = tx.quantity.multiply(priceInUsd)
                    val netProceedsUsd = grossProceedsUsd.subtract(feeInUsd)
                    cash = cash.add(netProceedsUsd)

                    totalSoldQty[symbol] = (totalSoldQty[symbol] ?: BigDecimal.ZERO).add(tx.quantity)

                    // Calculate realized gain using selected method
                    var qtyToSell = tx.quantity
                    var matchedCostBasis = BigDecimal.ZERO

                    if (method == CostBasisMethod.FIFO) {
                        val lots = lotsBySymbol.getOrPut(symbol) { mutableListOf() }
                        val it = lots.iterator()
                        while (it.hasNext() && qtyToSell > BigDecimal.ZERO) {
                            val lot = it.next()
                            if (lot.remainingQty <= qtyToSell) {
                                matchedCostBasis = matchedCostBasis.add(lot.remainingQty.multiply(lot.pricePerShareInUsd))
                                qtyToSell = qtyToSell.subtract(lot.remainingQty)
                                it.remove()
                            } else {
                                matchedCostBasis = matchedCostBasis.add(qtyToSell.multiply(lot.pricePerShareInUsd))
                                lot.remainingQty = lot.remainingQty.subtract(qtyToSell)
                                qtyToSell = BigDecimal.ZERO
                            }
                        }
                    } else {
                        // Weighted average method
                        val totalBought = totalBoughtQty[symbol] ?: BigDecimal.ONE
                        val totalCost = totalBoughtCostUsd[symbol] ?: BigDecimal.ZERO
                        val avgPrice = if (totalBought > BigDecimal.ZERO) totalCost.divide(totalBought, 6, RoundingMode.HALF_UP) else BigDecimal.ZERO
                        matchedCostBasis = tx.quantity.multiply(avgPrice)
                    }

                    val realizedGain = netProceedsUsd.subtract(matchedCostBasis)
                    realizedGainBySymbol[symbol] = (realizedGainBySymbol[symbol] ?: BigDecimal.ZERO).add(realizedGain)
                }
            }
        }

        // Build active holdings
        val holdings = mutableListOf<PortfolioHolding>()
        var totalInvestedValue = BigDecimal.ZERO
        var totalCostBasis = BigDecimal.ZERO
        var totalRealized = BigDecimal.ZERO
        var dailyPortfolioDollarChange = BigDecimal.ZERO

        val allSymbols = (lotsBySymbol.keys + totalDividendsBySymbol.keys + realizedGainBySymbol.keys).distinct()

        for (symbol in allSymbols) {
            val instrument = instrumentsMap[symbol]
            val instCurrency = instrument?.currency ?: "USD"
            val currentPriceInst = BigDecimal.valueOf(instrument?.currentPrice ?: 0.0)
            val currentPriceUsd = FxRates.convert(currentPriceInst, instCurrency, baseCurrency)
            val prevCloseInst = BigDecimal.valueOf(instrument?.previousClose ?: instrument?.currentPrice ?: 0.0)
            val prevCloseUsd = FxRates.convert(prevCloseInst, instCurrency, baseCurrency)

            val lots = lotsBySymbol[symbol] ?: emptyList()
            val remainingQty = lots.map { it.remainingQty }.fold(BigDecimal.ZERO) { a, b -> a.add(b) }

            val totalRealizedGain = realizedGainBySymbol[symbol] ?: BigDecimal.ZERO
            totalRealized = totalRealized.add(totalRealizedGain)

            if (remainingQty > BigDecimal.ZERO) {
                val totalCostUsd = lots.map { it.remainingQty.multiply(it.pricePerShareInUsd) }.fold(BigDecimal.ZERO) { a, b -> a.add(b) }
                val avgCostPerShare = if (remainingQty > BigDecimal.ZERO) totalCostUsd.divide(remainingQty, 4, RoundingMode.HALF_UP) else BigDecimal.ZERO
                val currentValue = remainingQty.multiply(currentPriceUsd)
                val unrealizedGain = currentValue.subtract(totalCostUsd)
                val unrealizedGainPercent = if (totalCostUsd > BigDecimal.ZERO) {
                    unrealizedGain.divide(totalCostUsd, 6, RoundingMode.HALF_UP).multiply(BigDecimal("100")).setScale(2, RoundingMode.HALF_UP)
                } else BigDecimal.ZERO

                val dayChangeUsd = currentPriceUsd.subtract(prevCloseUsd)
                val dailyGainForHolding = remainingQty.multiply(dayChangeUsd)
                dailyPortfolioDollarChange = dailyPortfolioDollarChange.add(dailyGainForHolding)

                totalInvestedValue = totalInvestedValue.add(currentValue)
                totalCostBasis = totalCostBasis.add(totalCostUsd)

                holdings.add(
                    PortfolioHolding(
                        symbol = symbol,
                        name = instrument?.name ?: symbol,
                        exchange = instrument?.exchange ?: "NYSE",
                        currency = instCurrency,
                        quantity = remainingQty.setScale(3, RoundingMode.HALF_UP),
                        averageCostBasis = avgCostPerShare.setScale(2, RoundingMode.HALF_UP),
                        totalCost = totalCostUsd.setScale(2, RoundingMode.HALF_UP),
                        currentPrice = currentPriceUsd.setScale(2, RoundingMode.HALF_UP),
                        currentValue = currentValue.setScale(2, RoundingMode.HALF_UP),
                        unrealizedGain = unrealizedGain.setScale(2, RoundingMode.HALF_UP),
                        unrealizedGainPercent = unrealizedGainPercent,
                        realizedGain = totalRealizedGain.setScale(2, RoundingMode.HALF_UP),
                        totalDividendsReceived = (totalDividendsBySymbol[symbol] ?: BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP),
                        sector = instrument?.sector ?: "General"
                    )
                )
            }
        }

        val totalEquity = totalInvestedValue.add(cash)
        val totalUnrealizedGain = totalInvestedValue.subtract(totalCostBasis)
        val totalUnrealizedGainPercent = if (totalCostBasis > BigDecimal.ZERO) {
            totalUnrealizedGain.divide(totalCostBasis, 6, RoundingMode.HALF_UP).multiply(BigDecimal("100")).setScale(2, RoundingMode.HALF_UP)
        } else BigDecimal.ZERO

        val dailyGainPercent = if (totalInvestedValue > BigDecimal.ZERO) {
            dailyPortfolioDollarChange.divide(totalInvestedValue, 6, RoundingMode.HALF_UP).multiply(BigDecimal("100")).setScale(2, RoundingMode.HALF_UP)
        } else BigDecimal.ZERO

        val summary = PortfolioSummary(
            totalInvestedValue = totalInvestedValue.setScale(2, RoundingMode.HALF_UP),
            cashBalance = cash.setScale(2, RoundingMode.HALF_UP),
            totalEquity = totalEquity.setScale(2, RoundingMode.HALF_UP),
            totalCostBasis = totalCostBasis.setScale(2, RoundingMode.HALF_UP),
            totalUnrealizedGain = totalUnrealizedGain.setScale(2, RoundingMode.HALF_UP),
            totalUnrealizedGainPercent = totalUnrealizedGainPercent,
            totalRealizedGain = totalRealized.setScale(2, RoundingMode.HALF_UP),
            dailyGain = dailyPortfolioDollarChange.setScale(2, RoundingMode.HALF_UP),
            dailyGainPercent = dailyGainPercent,
            baseCurrency = baseCurrency
        )

        return Pair(holdings.sortedByDescending { it.currentValue }, summary)
    }
}
