package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StocksTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProvenanceBadge(
    currency: String,
    exchange: String,
    dataSource: String,
    quoteFreshness: String,
    timestamp: Long,
    isMarketOpen: Boolean,
    modifier: Modifier = Modifier
) {
    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(timestamp))

    val statusDotColor = if (isMarketOpen) {
        if (quoteFreshness.contains("Live", ignoreCase = true)) StocksTheme.colors.gain else Color(0xFFFF9F0A)
    } else {
        StocksTheme.colors.textMuted
    }

    Row(
        modifier = modifier
            .background(StocksTheme.colors.surfaceElevated, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Status dot
        Box(
            modifier = Modifier
                .size(6.dp)
                .background(statusDotColor, CircleShape)
        )

        Text(
            text = "$currency • $exchange • $quoteFreshness",
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                color = StocksTheme.colors.textSecondary
            )
        )

        Text(
            text = "• $timeStr",
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                color = StocksTheme.colors.textMuted
            )
        )
    }
}
