package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChartRange
import com.example.model.HistoricalPoint
import com.example.ui.theme.StocksTheme
import com.example.ui.theme.TabularNumberStyle
import java.util.Locale

@Composable
fun InteractiveStockChart(
    points: List<HistoricalPoint>,
    selectedRange: ChartRange,
    onRangeSelected: (ChartRange) -> Unit,
    modifier: Modifier = Modifier,
    currencySymbol: String = "$",
    isAdjusted: Boolean = true,
    onToggleAdjusted: (() -> Unit)? = null,
    hasSplitOrDividend: Boolean = false
) {
    if (points.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(240.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Loading historical data...",
                color = StocksTheme.colors.textMuted,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        return
    }

    val haptic = LocalHapticFeedback.current
    val firstPrice = points.first().let { if (isAdjusted) it.adjustedPrice else it.price }
    val lastPrice = points.last().let { if (isAdjusted) it.adjustedPrice else it.price }
    val isOverallGain = lastPrice >= firstPrice

    val chartLineColor by animateColorAsState(
        targetValue = if (isOverallGain) StocksTheme.colors.gain else StocksTheme.colors.loss,
        animationSpec = tween(300),
        label = "chartColor"
    )

    // Touch scrubbing state
    var activeIndex by remember(points, selectedRange) { mutableStateOf<Int?>(null) }
    val activePoint = activeIndex?.let { points.getOrNull(it) }

    val displayPrice = activePoint?.let { if (isAdjusted) it.adjustedPrice else it.price } ?: lastPrice
    val periodDiff = displayPrice - firstPrice
    val periodDiffPct = if (firstPrice > 0) (periodDiff / firstPrice) * 100.0 else 0.0

    Column(modifier = modifier.fillMaxWidth()) {
        // Scrubber readout header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = String.format(Locale.US, "%s%.2f", currencySymbol, displayPrice),
                    style = TabularNumberStyle.copy(
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = StocksTheme.colors.textPrimary
                    )
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val sign = if (periodDiff >= 0) "+" else ""
                    Text(
                        text = String.format(Locale.US, "%s%s%.2f (%s%.2f%%)", sign, currencySymbol, periodDiff, sign, periodDiffPct),
                        style = TabularNumberStyle.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (periodDiff >= 0) StocksTheme.colors.gain else StocksTheme.colors.loss
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = activePoint?.label ?: selectedRange.title,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = StocksTheme.colors.textMuted
                        )
                    )
                }
            }

            // Annotation or Adjusted toggle
            if (hasSplitOrDividend && onToggleAdjusted != null) {
                Surface(
                    onClick = onToggleAdjusted,
                    shape = RoundedCornerShape(12.dp),
                    color = StocksTheme.colors.surfaceElevated,
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Text(
                        text = if (isAdjusted) "Adjusted" else "Unadjusted",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.aiAccent,
                            fontWeight = FontWeight.Medium
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Canvas Chart
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .pointerInput(points) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val idx = calculateIndex(offset.x, size.width.toFloat(), points.size)
                            if (idx != activeIndex) {
                                activeIndex = idx
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                        },
                        onDrag = { change, _ ->
                            val idx = calculateIndex(change.position.x, size.width.toFloat(), points.size)
                            if (idx != activeIndex) {
                                activeIndex = idx
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            }
                        },
                        onDragEnd = { activeIndex = null },
                        onDragCancel = { activeIndex = null }
                    )
                }
                .pointerInput(points) {
                    detectTapGestures(
                        onPress = { offset ->
                            val idx = calculateIndex(offset.x, size.width.toFloat(), points.size)
                            activeIndex = idx
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            tryAwaitRelease()
                            activeIndex = null
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                val prices = points.map { if (isAdjusted) it.adjustedPrice else it.price }
                val minP = prices.minOrNull() ?: 1.0
                val maxP = prices.maxOrNull() ?: 2.0
                val priceRange = if (maxP > minP) maxP - minP else 1.0

                val horizontalStep = width / (points.size - 1).coerceAtLeast(1)

                // Build line path
                val path = Path()
                val areaPath = Path()
                areaPath.moveTo(0f, height)

                val pointsCoords = mutableListOf<Offset>()

                points.forEachIndexed { i, pt ->
                    val p = if (isAdjusted) pt.adjustedPrice else pt.price
                    val x = i * horizontalStep
                    val y = (height - ((p - minP) / priceRange) * (height * 0.85f) - (height * 0.08f)).toFloat()
                    val pointOffset = Offset(x, y)
                    pointsCoords.add(pointOffset)

                    if (i == 0) {
                        path.moveTo(x, y)
                        areaPath.lineTo(x, y)
                    } else {
                        // Smooth cubic bezier segment
                        val prev = pointsCoords[i - 1]
                        val cx = (prev.x + x) / 2f
                        path.cubicTo(cx, prev.y, cx, y, x, y)
                        areaPath.cubicTo(cx, prev.y, cx, y, x, y)
                    }
                }

                areaPath.lineTo(width, height)
                areaPath.close()

                // Draw gradient fill below curve
                drawPath(
                    path = areaPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            chartLineColor.copy(alpha = 0.25f),
                            chartLineColor.copy(alpha = 0.02f),
                            Color.Transparent
                        ),
                        startY = 0f,
                        endY = height
                    )
                )

                // Draw main curve
                drawPath(
                    path = path,
                    color = chartLineColor,
                    style = Stroke(
                        width = 2.4.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )

                // Draw Split & Dividend pins on the timeline
                points.forEachIndexed { idx, pt ->
                    if (pt.isSplit || pt.isDividend) {
                        val coord = pointsCoords[idx]
                        // Draw badge circle
                        val badgeColor = if (pt.isSplit) Color(0xFFBF5AF2) else Color(0xFFFF9F0A)
                        drawCircle(
                            color = badgeColor,
                            radius = 4.5.dp.toPx(),
                            center = coord
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 2.dp.toPx(),
                            center = coord
                        )
                    }
                }

                // If active scrubber index, draw crosshair
                activeIndex?.let { idx ->
                    if (idx in pointsCoords.indices) {
                        val activeCoord = pointsCoords[idx]

                        // Vertical dashed/thin crosshair line
                        drawLine(
                            color = Color.White.copy(alpha = 0.4f),
                            start = Offset(activeCoord.x, 0f),
                            end = Offset(activeCoord.x, height),
                            strokeWidth = 1.2.dp.toPx()
                        )

                        // Outer glowing pulse ring
                        drawCircle(
                            color = chartLineColor.copy(alpha = 0.35f),
                            radius = 8.dp.toPx(),
                            center = activeCoord
                        )
                        // Inner solid dot
                        drawCircle(
                            color = Color.White,
                            radius = 4.5.dp.toPx(),
                            center = activeCoord
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Segmented Range Selector (Apple-style pill buttons)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(StocksTheme.colors.surfaceElevated, RoundedCornerShape(12.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            ChartRange.values().forEach { range ->
                val isSelected = range == selectedRange
                Surface(
                    onClick = {
                        onRangeSelected(range)
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp),
                    shape = RoundedCornerShape(9.dp),
                    color = if (isSelected) StocksTheme.colors.surfaceHighlight else Color.Transparent
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = range.label,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) StocksTheme.colors.textPrimary else StocksTheme.colors.textSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}

private fun calculateIndex(xPos: Float, width: Float, count: Int): Int {
    if (count <= 1 || width <= 0f) return 0
    val ratio = (xPos / width).coerceIn(0f, 1f)
    return (ratio * (count - 1)).toInt().coerceIn(0, count - 1)
}
