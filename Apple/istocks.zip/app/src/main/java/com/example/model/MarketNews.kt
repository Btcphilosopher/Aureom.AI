package com.example.model

data class EconomicEvent(
    val id: String,
    val title: String,
    val country: String,
    val flagEmoji: String,
    val dateStr: String,
    val timeStr: String,
    val impact: String, // "HIGH", "MED", "LOW"
    val actual: String?,
    val forecast: String,
    val prior: String,
    val commentary: String = ""
)

data class MarketNews(
    val id: String,
    val title: String,
    val source: String,
    val timeAgo: String,
    val summary: String,
    val content: String,
    val relatedSymbol: String = "",
    val category: String = "Market News",
    val url: String = "https://example.com/news",
    val provenanceBadge: String = "Curated Editorial Feed"
)

data class ExchangeInfo(
    val code: String, // "NYSE", "NASDAQ", "LSE", "EURONEXT", "TSE"
    val name: String,
    val city: String,
    val timezone: String,
    val openTime: String,
    val closeTime: String,
    val statusText: String,
    val isOpen: Boolean
)
