package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.StocksTheme

@Composable
fun SparklineChart(
    points: List<Double>,
    isGain: Boolean,
    modifier: Modifier = Modifier,
    width: Dp = 68.dp,
    height: Dp = 32.dp
) {
    val lineColor = if (isGain) StocksTheme.colors.gain else StocksTheme.colors.loss

    Canvas(
        modifier = modifier
            .width(width)
            .height(height)
    ) {
        if (points.size < 2) return@Canvas

        val w = size.width
        val h = size.height
        val minP = points.minOrNull() ?: 0.0
        val maxP = points.maxOrNull() ?: 1.0
        val range = if (maxP > minP) maxP - minP else 1.0

        val step = w / (points.size - 1)

        val path = Path()
        val areaPath = Path()
        areaPath.moveTo(0f, h)

        points.forEachIndexed { i, p ->
            val x = i * step
            val y = (h - ((p - minP) / range) * (h * 0.8f) - (h * 0.1f)).toFloat()

            if (i == 0) {
                path.moveTo(x, y)
                areaPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                areaPath.lineTo(x, y)
            }
        }

        areaPath.lineTo(w, h)
        areaPath.close()

        // Gradient under fill
        drawPath(
            path = areaPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    lineColor.copy(alpha = 0.20f),
                    Color.Transparent
                ),
                startY = 0f,
                endY = h
            )
        )

        // Line
        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(
                width = 1.6.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}
