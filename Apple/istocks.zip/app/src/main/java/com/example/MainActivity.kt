package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppTab
import com.example.ui.MainViewModel
import com.example.ui.screens.AiAssistantSheet
import com.example.ui.screens.CompanyDetailSheet
import com.example.ui.screens.MarketsScreen
import com.example.ui.screens.PortfolioScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.TodayScreen
import com.example.ui.screens.WatchlistScreen
import com.example.ui.theme.AppleBlue
import com.example.ui.theme.IStocksTheme
import com.example.ui.theme.StocksTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IStocksTheme {
                val mainViewModel: MainViewModel = viewModel()
                IStocksApp(viewModel = mainViewModel)
            }
        }
    }
}

data class TabItem(
    val tab: AppTab,
    val icon: ImageVector,
    val testTag: String
)

@Composable
fun IStocksApp(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val selectedSymbol by viewModel.selectedInstrumentSymbol.collectAsState()
    val isAiSheetOpen by viewModel.isAiSheetOpen.collectAsState()

    // Handle back button gracefully
    BackHandler(enabled = selectedSymbol != null || isAiSheetOpen || currentTab != AppTab.TODAY) {
        when {
            selectedSymbol != null -> viewModel.closeCompanyDetail()
            isAiSheetOpen -> viewModel.closeAiAssistant()
            currentTab != AppTab.TODAY -> viewModel.selectTab(AppTab.TODAY)
        }
    }

    val tabs = listOf(
        TabItem(AppTab.TODAY, Icons.Default.Today, "tab_today"),
        TabItem(AppTab.WATCHLIST, Icons.Default.FormatListBulleted, "tab_watchlist"),
        TabItem(AppTab.MARKETS, Icons.Default.Public, "tab_markets"),
        TabItem(AppTab.PORTFOLIO, Icons.Default.PieChart, "tab_portfolio"),
        TabItem(AppTab.SEARCH, Icons.Default.Search, "tab_search")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = StocksTheme.colors.surfaceElevated,
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("bottom_nav_bar"),
                containerColor = StocksTheme.colors.surfaceElevated,
                tonalElevation = 8.dp
            ) {
                tabs.forEach { item ->
                    val isSelected = currentTab == item.tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(item.tab) },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.tab.title
                            )
                        },
                        label = {
                            Text(
                                text = item.tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AppleBlue,
                            selectedTextColor = AppleBlue,
                            indicatorColor = StocksTheme.colors.surfaceHighlight,
                            unselectedIconColor = StocksTheme.colors.textMuted,
                            unselectedTextColor = StocksTheme.colors.textMuted
                        ),
                        modifier = Modifier.testTag(item.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.TODAY -> TodayScreen(viewModel = viewModel)
                AppTab.WATCHLIST -> WatchlistScreen(viewModel = viewModel)
                AppTab.MARKETS -> MarketsScreen(viewModel = viewModel)
                AppTab.PORTFOLIO -> PortfolioScreen(viewModel = viewModel)
                AppTab.SEARCH -> SearchScreen(viewModel = viewModel)
            }
        }
    }

    // Company Detail Research Modal Sheet
    selectedSymbol?.let { symbol ->
        CompanyDetailSheet(
            symbol = symbol,
            viewModel = viewModel,
            onDismiss = { viewModel.closeCompanyDetail() }
        )
    }

    // AI Research Assistant Modal Sheet
    if (isAiSheetOpen) {
        AiAssistantSheet(
            viewModel = viewModel,
            onDismiss = { viewModel.closeAiAssistant() }
        )
    }
}
