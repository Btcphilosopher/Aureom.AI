package com.example.model

data class HistoricalPoint(
    val timestamp: Long,
    val label: String,
    val price: Double,
    val adjustedPrice: Double,
    val volume: Long = 0L,
    val isSplit: Boolean = false,
    val splitRatio: String? = null, // e.g. "4:1 Split"
    val isDividend: Boolean = false,
    val dividendAmount: Double? = null // e.g. "$0.25 Dividend"
)

enum class ChartRange(val label: String, val title: String) {
    DAY("1D", "Past Day"),
    WEEK("1W", "Past Week"),
    MONTH("1M", "Past Month"),
    YEAR("1Y", "Past Year"),
    ALL("ALL", "All Available")
}
