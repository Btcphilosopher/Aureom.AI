package com.example.model

data class PriceAlert(
    val id: Long = 0L,
    val symbol: String,
    val targetPrice: Double,
    val isAbove: Boolean, // true = notify if price >= targetPrice; false = notify if price <= targetPrice
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val triggeredAt: Long? = null,
    val note: String = ""
)

data class WatchlistGroup(
    val id: Long = 0L,
    val name: String,
    val symbols: List<String>,
    val isDefault: Boolean = false
)

enum class WatchlistSortOrder(val label: String) {
    CUSTOM("Custom Order"),
    NAME("Name (A-Z)"),
    PRICE_CHANGE("Day Change %"),
    PRICE("Price"),
    MARKET_CAP("Market Cap")
}
