package com.example.model

enum class AiPromptType(val title: String, val subtitle: String) {
    ANNOUNCEMENTS_SUMMARY("Summarise Announcements", "Digest recent earnings & corporate filings"),
    TERM_EXPLAINER("Financial Term Explainer", "Plain English breakdown of key ratios & metrics"),
    METRIC_COMPARISON("Compare Metrics", "Side-by-side valuation & profitability check"),
    PORTFOLIO_CONCENTRATION("Concentration Audit", "Detect sector tilt, single-stock and currency risks"),
    RISK_ANALYSIS("Identify Missing Information", "Highlight data gaps, volatility, and downside factors")
}

data class AiResearchResponse(
    val queryTitle: String,
    val queryInput: String,
    val summary: String,
    val reportedFacts: List<String>,
    val calculatedMetrics: List<String>,
    val generatedInterpretation: String,
    val citedSources: List<String>,
    val disclaimer: String = "Informational research assistant only. Not financial, investment, or tax advice. Facts and calculated metrics derived from public financial filings. Interpretation is AI-generated."
)
