package com.example.model

import java.math.BigDecimal
import java.math.RoundingMode

enum class TransactionType(val label: String) {
    BUY("Buy"),
    SELL("Sell"),
    DIVIDEND("Dividend"),
    DEPOSIT("Cash Deposit"),
    WITHDRAWAL("Cash Withdrawal")
}

data class TransactionRecord(
    val id: Long = 0L,
    val accountId: Long = 1L,
    val symbol: String, // e.g. "AAPL"
    val type: TransactionType,
    val quantity: BigDecimal, // supports fractional quantities, e.g. 1.250
    val pricePerShare: BigDecimal, // in trade currency
    val fee: BigDecimal = BigDecimal.ZERO,
    val currency: String = "USD",
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)

data class PortfolioAccount(
    val id: Long = 1L,
    val name: String = "Individual Brokerage",
    val cashBalance: BigDecimal = BigDecimal("10000.00"),
    val currency: String = "USD",
    val isDefault: Boolean = true
)

data class PortfolioHolding(
    val symbol: String,
    val name: String,
    val exchange: String,
    val currency: String,
    val quantity: BigDecimal,
    val averageCostBasis: BigDecimal, // FIFO or weighted
    val totalCost: BigDecimal,
    val currentPrice: BigDecimal,
    val currentValue: BigDecimal,
    val unrealizedGain: BigDecimal,
    val unrealizedGainPercent: BigDecimal,
    val realizedGain: BigDecimal = BigDecimal.ZERO,
    val totalDividendsReceived: BigDecimal = BigDecimal.ZERO,
    val sector: String = "General"
)

data class PortfolioSummary(
    val totalInvestedValue: BigDecimal = BigDecimal.ZERO,
    val cashBalance: BigDecimal = BigDecimal.ZERO,
    val totalEquity: BigDecimal = BigDecimal.ZERO, // invested + cash
    val totalCostBasis: BigDecimal = BigDecimal.ZERO,
    val totalUnrealizedGain: BigDecimal = BigDecimal.ZERO,
    val totalUnrealizedGainPercent: BigDecimal = BigDecimal.ZERO,
    val totalRealizedGain: BigDecimal = BigDecimal.ZERO,
    val dailyGain: BigDecimal = BigDecimal.ZERO,
    val dailyGainPercent: BigDecimal = BigDecimal.ZERO,
    val baseCurrency: String = "USD"
)

enum class CostBasisMethod(val title: String, val description: String) {
    FIFO(
        "First-In, First-Out (FIFO)",
        "The oldest acquired shares are treated as sold first. Default standard for tax reporting in major jurisdictions."
    ),
    WEIGHTED_AVERAGE(
        "Weighted Average Cost",
        "Calculates cost basis as total purchase amount divided by total units held across all buy transactions."
    )
}
