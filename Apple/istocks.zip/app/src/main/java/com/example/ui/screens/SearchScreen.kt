package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssetType
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.components.SparklineChart
import com.example.ui.theme.AppleBlue
import com.example.ui.theme.StocksTheme
import com.example.ui.theme.TabularNumberStyle
import java.util.Locale

@Composable
fun SearchScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val instruments by viewModel.instruments.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filterType by viewModel.searchFilterType.collectAsState()
    val recentSearches by viewModel.recentSearches.collectAsState()

    // Filter instruments
    val searchResults = remember(instruments, searchQuery, filterType) {
        instruments.filter { inst ->
            val matchesFilter = when (filterType) {
                "STOCKS" -> inst.assetType == AssetType.EQUITY
                "ETFS" -> inst.assetType == AssetType.ETF
                "INDICES" -> inst.assetType == AssetType.INDEX
                "CRYPTO" -> inst.assetType == AssetType.CRYPTO
                else -> true
            }

            val q = searchQuery.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                    inst.symbol.lowercase().contains(q) ||
                    inst.name.lowercase().contains(q) ||
                    inst.exchange.lowercase().contains(q) ||
                    inst.sector.lowercase().contains(q)

            matchesFilter && matchesQuery
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 16.dp)
            .testTag("search_screen")
    ) {
        // Screen Header
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
                text = "GLOBAL LOOKUP",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = StocksTheme.colors.textMuted,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = "Search",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = StocksTheme.colors.textPrimary
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Input Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.searchQuery.value = it },
            placeholder = { Text("Search company, ticker, exchange, or sector...", fontSize = 14.sp) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search icon",
                    tint = StocksTheme.colors.textMuted
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear search",
                            tint = StocksTheme.colors.textMuted
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("search_query_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AppleBlue,
                unfocusedBorderColor = StocksTheme.colors.border,
                focusedContainerColor = StocksTheme.colors.surfaceElevated,
                unfocusedContainerColor = StocksTheme.colors.surfaceElevated
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Instrument Type Filters (All, Stocks, ETFs, Indices, Crypto)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ALL" to "All", "STOCKS" to "Stocks", "ETFS" to "ETFs", "INDICES" to "Indices", "CRYPTO" to "Crypto").forEach { (typeKey, label) ->
                val isSelected = filterType == typeKey
                Surface(
                    onClick = { viewModel.searchFilterType.value = typeKey },
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) AppleBlue else StocksTheme.colors.surfaceElevated,
                    modifier = Modifier.testTag("search_filter_$typeKey")
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else StocksTheme.colors.textSecondary
                        ),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Recent Searches (if search query is empty)
            if (searchQuery.isEmpty() && recentSearches.isNotEmpty()) {
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = "Recent searches",
                                    tint = StocksTheme.colors.textMuted,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "RECENT SEARCHES",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = StocksTheme.colors.textMuted,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                )
                            }
                            Text(
                                text = "Clear",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppleBlue,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                modifier = Modifier.clickable { viewModel.clearRecentSearches() }
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            recentSearches.forEach { sym ->
                                Surface(
                                    onClick = {
                                        viewModel.openCompanyDetail(sym)
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    color = StocksTheme.colors.surfaceElevated,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, StocksTheme.colors.border)
                                ) {
                                    Text(
                                        text = sym,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        ),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Trending Market Suggestions
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = "Trending",
                                tint = StocksTheme.colors.gain,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "TRENDING ON MARKETS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = StocksTheme.colors.textMuted,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                    }
                }
            }

            // Results count header
            if (searchQuery.isNotEmpty()) {
                item {
                    Text(
                        text = "SEARCH RESULTS (${searchResults.size})",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.textMuted,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }

            if (searchResults.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "No instruments found",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StocksTheme.colors.textPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Try searching by symbol (e.g. AAPL), name, or exchange",
                                style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textMuted)
                            )
                        }
                    }
                }
            } else {
                items(searchResults, key = { it.id }) { inst ->
                    GlassCard(
                        onClick = {
                            viewModel.addRecentSearch(inst.symbol)
                            viewModel.openCompanyDetail(inst.symbol)
                        },
                        modifier = Modifier.testTag("search_result_${inst.symbol}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.3f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = inst.symbol,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = StocksTheme.colors.surfaceHighlight
                                    ) {
                                        Text(
                                            text = "${inst.exchange} • ${inst.currency}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontSize = 10.sp,
                                                color = StocksTheme.colors.textSecondary
                                            ),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = inst.name,
                                    style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textSecondary),
                                    maxLines = 1
                                )
                                Text(
                                    text = "${inst.assetType.label} • ${inst.sector}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = StocksTheme.colors.textMuted,
                                        fontSize = 11.sp
                                    )
                                )
                            }

                            SparklineChart(
                                points = inst.sparklinePoints,
                                isGain = inst.isGain,
                                modifier = Modifier.weight(1f)
                            )

                            Column(
                                horizontalAlignment = Alignment.End,
                                modifier = Modifier.weight(1.2f)
                            ) {
                                val curr = if (inst.currency == "GBP") "£" else if (inst.currency == "EUR") "€" else if (inst.currency == "JPY") "¥" else "$"
                                Text(
                                    text = String.format(Locale.US, "%s%.2f", curr, inst.currentPrice),
                                    style = TabularNumberStyle.copy(
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.textPrimary
                                    )
                                )
                                val sign = if (inst.changePercent >= 0) "+" else ""
                                Text(
                                    text = String.format(Locale.US, "%s%.2f%%", sign, inst.changePercent),
                                    style = TabularNumberStyle.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (inst.isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
