package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChartRange
import com.example.model.Instrument
import com.example.model.MarketNews
import com.example.model.TransactionType
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.components.InteractiveStockChart
import com.example.ui.components.ProvenanceBadge
import com.example.ui.theme.AiGlowCyan
import com.example.ui.theme.AiGlowViolet
import com.example.ui.theme.AppleBlue
import com.example.ui.theme.StocksTheme
import com.example.ui.theme.TabularNumberStyle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanyDetailSheet(
    symbol: String,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val instruments by viewModel.instruments.collectAsState()
    val watchlists by viewModel.watchlists.collectAsState()
    val alerts by viewModel.alerts.collectAsState()

    val instrument = instruments.find { it.symbol.equals(symbol, ignoreCase = true) } ?: return

    var selectedRange by remember { mutableStateOf(ChartRange.DAY) }
    var isAdjusted by remember { mutableStateOf(true) }
    var showTradeDialog by remember { mutableStateOf(false) }
    var showAlertModal by remember { mutableStateOf(false) }

    val activeWatchlist = watchlists.firstOrNull()
    val isInWatchlist = activeWatchlist?.symbols?.contains(instrument.symbol) == true
    val hasAlert = alerts.any { it.symbol.equals(instrument.symbol, ignoreCase = true) && it.isActive }

    val chartPoints = remember(instrument.symbol, selectedRange, isAdjusted, instruments) {
        viewModel.marketRepo.getHistoricalSeries(instrument.symbol, selectedRange, isAdjusted)
    }

    val relatedNews = viewModel.marketRepo.marketNews.filter {
        it.relatedSymbol.equals(instrument.symbol, ignoreCase = true)
    }

    val currSymbol = if (instrument.currency == "GBP") "£" else if (instrument.currency == "EUR") "€" else if (instrument.currency == "JPY") "¥" else "$"

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = StocksTheme.colors.surfaceElevated,
        modifier = Modifier.testTag("company_detail_sheet_${instrument.symbol}")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Sheet Navigation Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("company_detail_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close sheet",
                            tint = StocksTheme.colors.textPrimary
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // AI Assistant shortcut button
                        Surface(
                            onClick = { viewModel.openAiAssistant(instrument.symbol) },
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Transparent,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                Brush.horizontalGradient(listOf(AiGlowCyan, AiGlowViolet))
                            ),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .background(StocksTheme.colors.surfaceHighlight)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI Assistant",
                                    tint = AiGlowCyan,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Ask AI",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.textPrimary
                                    )
                                )
                            }
                        }

                        // Watchlist Bookmark toggle
                        IconButton(
                            onClick = {
                                activeWatchlist?.let { wl ->
                                    viewModel.toggleSymbolInWatchlist(wl.id, instrument.symbol)
                                }
                            },
                            modifier = Modifier.testTag("company_detail_watchlist_toggle")
                        ) {
                            Icon(
                                imageVector = if (isInWatchlist) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = "Toggle Watchlist",
                                tint = if (isInWatchlist) AppleBlue else StocksTheme.colors.textMuted
                            )
                        }
                    }
                }
            }

            // Title & Current Quote Header
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = instrument.symbol,
                                style = MaterialTheme.typography.displayMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StocksTheme.colors.textPrimary
                                )
                            )
                            Text(
                                text = instrument.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = StocksTheme.colors.textSecondary
                                )
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = StocksTheme.colors.surfaceHighlight
                        ) {
                            Text(
                                text = "${instrument.exchange} • ${instrument.currency}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StocksTheme.colors.textSecondary
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    ProvenanceBadge(
                        currency = instrument.currency,
                        exchange = instrument.exchange,
                        dataSource = instrument.dataSource,
                        quoteFreshness = instrument.quoteFreshness,
                        timestamp = instrument.quoteTimestamp,
                        isMarketOpen = instrument.isMarketOpen
                    )
                }
            }

            // Interactive Stock Chart
            item {
                GlassCard {
                    InteractiveStockChart(
                        points = chartPoints,
                        selectedRange = selectedRange,
                        onRangeSelected = { selectedRange = it },
                        currencySymbol = currSymbol,
                        isAdjusted = isAdjusted,
                        onToggleAdjusted = { isAdjusted = !isAdjusted },
                        hasSplitOrDividend = instrument.symbol in listOf("AAPL", "NVDA")
                    )
                }
            }

            // Quick Actions: Buy/Sell & Set Alert
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = { showTradeDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("detail_record_trade_btn"),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = AppleBlue)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Trade",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Trade / Position", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    FilledTonalButton(
                        onClick = { showAlertModal = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("detail_set_alert_btn"),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = StocksTheme.colors.surfaceHighlight)
                    ) {
                        Icon(
                            imageVector = if (hasAlert) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                            contentDescription = "Alert",
                            tint = AppleBlue,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Set Alert", color = StocksTheme.colors.textPrimary, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // Key Fundamentals & Stats Grid
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "KEY STATISTICS & FUNDAMENTALS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.textMuted,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    GlassCard {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Row 1: Market Cap & P/E Ratio
                            StatGridRow(
                                label1 = "Market Cap",
                                value1 = "\$${String.format(Locale.US, "%.1fB", instrument.marketCap)}",
                                label2 = "P/E Ratio (TTM)",
                                value2 = instrument.peRatio?.let { String.format(Locale.US, "%.1fx", it) } ?: "N/A"
                            )

                            HorizontalDivider(color = StocksTheme.colors.border, thickness = 0.5.dp)

                            // Row 2: Forward P/E & EPS
                            StatGridRow(
                                label1 = "Forward P/E",
                                value1 = instrument.forwardPe?.let { String.format(Locale.US, "%.1fx", it) } ?: "N/A",
                                label2 = "Diluted EPS",
                                value2 = instrument.eps?.let { String.format(Locale.US, "$%.2f", it) } ?: "N/A"
                            )

                            HorizontalDivider(color = StocksTheme.colors.border, thickness = 0.5.dp)

                            // Row 3: Dividend Yield & Ex-Div Date
                            StatGridRow(
                                label1 = "Dividend Yield",
                                value1 = instrument.dividendYield?.let { String.format(Locale.US, "%.2f%%", it) } ?: "None",
                                label2 = "Ex-Dividend Date",
                                value2 = instrument.exDividendDate ?: "N/A"
                            )

                            HorizontalDivider(color = StocksTheme.colors.border, thickness = 0.5.dp)

                            // Row 4: 52-Week Range & Beta
                            StatGridRow(
                                label1 = "52-Week Range",
                                value1 = "\$${instrument.low52} - \$${instrument.high52}",
                                label2 = "Beta (Volatility)",
                                value2 = instrument.beta?.let { String.format(Locale.US, "%.2f", it) } ?: "N/A"
                            )

                            HorizontalDivider(color = StocksTheme.colors.border, thickness = 0.5.dp)

                            // Row 5: Volume & Avg Volume
                            StatGridRow(
                                label1 = "Today's Volume",
                                value1 = String.format(Locale.US, "%,d", instrument.volume),
                                label2 = "Avg Volume (30D)",
                                value2 = String.format(Locale.US, "%,d", instrument.avgVolume)
                            )
                        }
                    }
                }
            }

            // Company Profile & Description
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "COMPANY PROFILE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.textMuted,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    GlassCard {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Sector: ${instrument.sector}",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = AppleBlue,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                                Text(
                                    text = "Class: ${instrument.assetType.label}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = instrument.description.ifEmpty { "Publicly traded corporation with ongoing continuous financial disclosures and regulatory reporting." },
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = StocksTheme.colors.textSecondary,
                                    lineHeight = 20.sp
                                )
                            )
                        }
                    }
                }
            }

            // Announcements & News for this Company
            if (relatedNews.isNotEmpty()) {
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "COMPANY ANNOUNCEMENTS & FILINGS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StocksTheme.colors.textMuted,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        relatedNews.forEach { news ->
                            GlassCard(modifier = Modifier.padding(bottom = 8.dp)) {
                                Column {
                                    Text(
                                        text = "${news.source} • ${news.timeAgo}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = AppleBlue)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = news.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = news.summary,
                                        style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textSecondary)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(30.dp)) }
        }
    }

    // Modal dialogs inside CompanyDetailSheet
    if (showTradeDialog) {
        QuickTradeModal(
            instrument = instrument,
            viewModel = viewModel,
            onDismiss = { showTradeDialog = false }
        )
    }

    if (showAlertModal) {
        QuickAlertModal(
            instrument = instrument,
            viewModel = viewModel,
            onDismiss = { showAlertModal = false }
        )
    }
}

@Composable
private fun StatGridRow(
    label1: String,
    value1: String,
    label2: String,
    value2: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label1, style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted))
            Text(
                text = value1,
                style = TabularNumberStyle.copy(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = StocksTheme.colors.textPrimary
                )
            )
        }
        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text(text = label2, style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted))
            Text(
                text = value2,
                style = TabularNumberStyle.copy(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = StocksTheme.colors.textPrimary
                )
            )
        }
    }
}

@Composable
private fun QuickTradeModal(
    instrument: Instrument,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var qtyText by remember { mutableStateOf("10.0") }
    var priceText by remember { mutableStateOf(String.format(Locale.US, "%.2f", instrument.currentPrice)) }
    var txType by remember { mutableStateOf(TransactionType.BUY) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Trade ${instrument.symbol}", color = StocksTheme.colors.textPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StocksTheme.colors.surfaceHighlight, RoundedCornerShape(8.dp))
                        .padding(2.dp)
                ) {
                    listOf(TransactionType.BUY to "Buy", TransactionType.SELL to "Sell").forEach { (type, lbl) ->
                        val isSel = txType == type
                        Surface(
                            onClick = { txType = type },
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSel) AppleBlue else Color.Transparent
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    lbl,
                                    color = if (isSel) Color.White else StocksTheme.colors.textSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                androidx.compose.material3.OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it },
                    label = { Text("Quantity (Shares)") },
                    singleLine = true
                )

                androidx.compose.material3.OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Price (${instrument.currency})") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(
                onClick = {
                    val q = qtyText.toDoubleOrNull() ?: 1.0
                    val p = priceText.toDoubleOrNull() ?: instrument.currentPrice
                    viewModel.addTransaction(
                        symbol = instrument.symbol,
                        type = txType,
                        quantity = q,
                        pricePerShare = p,
                        fee = 1.99,
                        currency = instrument.currency,
                        notes = "Logged from research screen"
                    )
                    onDismiss()
                }
            ) {
                Text("Confirm", color = AppleBlue, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                Text("Cancel", color = StocksTheme.colors.textMuted)
            }
        },
        containerColor = StocksTheme.colors.surfaceElevated
    )
}

@Composable
private fun QuickAlertModal(
    instrument: Instrument,
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var targetText by remember { mutableStateOf(String.format(Locale.US, "%.2f", instrument.currentPrice * 1.05)) }
    var isAbove by remember { mutableStateOf(true) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set Alert for ${instrument.symbol}", color = StocksTheme.colors.textPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Notify when price reaches your target threshold:",
                    style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textMuted)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StocksTheme.colors.surfaceHighlight, RoundedCornerShape(8.dp))
                        .padding(2.dp)
                ) {
                    listOf(true to "Rises Above (≥)", false to "Falls Below (≤)").forEach { (above, lbl) ->
                        val isSel = isAbove == above
                        Surface(
                            onClick = { isAbove = above },
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSel) AppleBlue else Color.Transparent
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    lbl,
                                    fontSize = 11.sp,
                                    color = if (isSel) Color.White else StocksTheme.colors.textSecondary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                androidx.compose.material3.OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it },
                    label = { Text("Target Price (${instrument.currency})") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(
                onClick = {
                    val targetP = targetText.toDoubleOrNull() ?: instrument.currentPrice
                    viewModel.addPriceAlert(
                        symbol = instrument.symbol,
                        targetPrice = targetP,
                        isAbove = isAbove,
                        note = "Target threshold alert"
                    )
                    onDismiss()
                }
            ) {
                Text("Set Alert", color = AppleBlue, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                Text("Cancel", color = StocksTheme.colors.textMuted)
            }
        },
        containerColor = StocksTheme.colors.surfaceElevated
    )
}
