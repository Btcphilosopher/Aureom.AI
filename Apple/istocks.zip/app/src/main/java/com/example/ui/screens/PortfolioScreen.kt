package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.accounting.CsvParseResult
import com.example.accounting.FxRates
import com.example.model.CostBasisMethod
import com.example.model.PortfolioHolding
import com.example.model.TransactionRecord
import com.example.model.TransactionType
import com.example.ui.MainViewModel
import com.example.ui.components.AllocationDonutChart
import com.example.ui.components.AllocationSlice
import com.example.ui.components.GlassCard
import com.example.ui.theme.AppleBlue
import com.example.ui.theme.StocksTheme
import com.example.ui.theme.TabularNumberStyle
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class PortfolioViewTab(val label: String) {
    HOLDINGS("Holdings"),
    ALLOCATION("Allocation"),
    HISTORY("Transactions")
}

@Composable
fun PortfolioScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val accounts by viewModel.accounts.collectAsState()
    val (holdings, summary) = viewModel.portfolioState.collectAsState().value
    val transactions by viewModel.transactions.collectAsState()
    val costMethod by viewModel.costBasisMethod.collectAsState()

    var selectedViewTab by remember { mutableStateOf(PortfolioViewTab.HOLDINGS) }
    var allocationMode by remember { mutableStateOf("HOLDING") } // HOLDING, SECTOR, CURRENCY

    // Dialog flags
    var showAddTxDialog by remember { mutableStateOf(false) }
    var showCashDialog by remember { mutableStateOf(false) }
    var showCostBasisDialog by remember { mutableStateOf(false) }
    var showCsvImportDialog by remember { mutableStateOf(false) }
    var showCsvExportDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(top = 16.dp)
            .testTag("portfolio_screen")
    ) {
        // Accounts Segmented Switcher & Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "INVESTMENT PORTFOLIO",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = StocksTheme.colors.textMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
                Text(
                    text = "Portfolio",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = StocksTheme.colors.textPrimary
                    )
                )
            }

            // CSV Export / Import Buttons
            Row {
                IconButton(
                    onClick = { showCsvImportDialog = true },
                    modifier = Modifier.testTag("portfolio_import_csv_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "Import CSV",
                        tint = AppleBlue
                    )
                }
                IconButton(
                    onClick = { showCsvExportDialog = true },
                    modifier = Modifier.testTag("portfolio_export_csv_btn")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FileDownload,
                        contentDescription = "Export CSV",
                        tint = AppleBlue
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Multiple Accounts Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            accounts.forEach { acc ->
                val isSelected = acc.id == viewModel.portfolioRepo.selectedAccountId.collectAsState().value
                Surface(
                    onClick = { viewModel.portfolioRepo.selectedAccountId.value = acc.id },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) StocksTheme.colors.surfaceHighlight else StocksTheme.colors.surfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) AppleBlue else StocksTheme.colors.border
                    ),
                    modifier = Modifier.testTag("account_tab_${acc.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = acc.name,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) StocksTheme.colors.textPrimary else StocksTheme.colors.textSecondary
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = acc.currency,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StocksTheme.colors.textMuted
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Portfolio Summary Performance Card
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("portfolio_summary_card")
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL NET EQUITY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.textMuted,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )

                    // Cost Basis Method Explainer pill
                    Surface(
                        onClick = { showCostBasisDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        color = StocksTheme.colors.surfaceHighlight
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Basis: ${costMethod.name}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    color = AppleBlue,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Cost basis explanation",
                                tint = AppleBlue,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = String.format(Locale.US, "$%,.2f", summary.totalEquity.toDouble()),
                    style = TabularNumberStyle.copy(
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = StocksTheme.colors.textPrimary
                    )
                )

                // Overall Unrealized Gain / Loss
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isGain = summary.totalUnrealizedGain >= BigDecimal.ZERO
                    val sign = if (isGain) "+" else ""
                    Text(
                        text = String.format(
                            Locale.US,
                            "%s$%,.2f (%s%.2f%%) Overall",
                            sign,
                            summary.totalUnrealizedGain.toDouble(),
                            sign,
                            summary.totalUnrealizedGainPercent.toDouble()
                        ),
                        style = TabularNumberStyle.copy(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = StocksTheme.colors.border, thickness = 0.5.dp)
                Spacer(modifier = Modifier.height(12.dp))

                // Stats row: Invested, Cash, Realized Gain
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Invested Value",
                            style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                        )
                        Text(
                            text = String.format(Locale.US, "$%,.2f", summary.totalInvestedValue.toDouble()),
                            style = TabularNumberStyle.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = StocksTheme.colors.textPrimary
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Cash Balance",
                                style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "[Edit]",
                                style = MaterialTheme.typography.labelSmall.copy(color = AppleBlue),
                                modifier = Modifier.clickable { showCashDialog = true }
                            )
                        }
                        Text(
                            text = String.format(Locale.US, "$%,.2f", summary.cashBalance.toDouble()),
                            style = TabularNumberStyle.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = StocksTheme.colors.textPrimary
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Realized Gain",
                            style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                        )
                        val rGain = summary.totalRealizedGain.toDouble()
                        val rSign = if (rGain >= 0) "+" else ""
                        Text(
                            text = String.format(Locale.US, "%s$%,.2f", rSign, rGain),
                            style = TabularNumberStyle.copy(
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (rGain >= 0) StocksTheme.colors.gain else StocksTheme.colors.loss
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Action Buttons: + Record Trade
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FilledTonalButton(
                onClick = { showAddTxDialog = true },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("portfolio_record_trade_btn"),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = AppleBlue)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Record trade",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Record Transaction", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Segmented Tabs: Holdings | Allocation | History
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .background(StocksTheme.colors.surfaceElevated, RoundedCornerShape(10.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            PortfolioViewTab.values().forEach { tab ->
                val isSel = tab == selectedViewTab
                Surface(
                    onClick = { selectedViewTab = tab },
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSel) StocksTheme.colors.surfaceHighlight else Color.Transparent
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = tab.label,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) StocksTheme.colors.textPrimary else StocksTheme.colors.textSecondary
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // View Content
        when (selectedViewTab) {
            PortfolioViewTab.HOLDINGS -> {
                HoldingsList(holdings = holdings, onSelect = { viewModel.openCompanyDetail(it) })
            }
            PortfolioViewTab.ALLOCATION -> {
                AllocationView(
                    holdings = holdings,
                    cashBalance = summary.cashBalance.toDouble(),
                    totalEquity = summary.totalEquity.toDouble(),
                    mode = allocationMode,
                    onModeChange = { allocationMode = it }
                )
            }
            PortfolioViewTab.HISTORY -> {
                TransactionHistoryList(
                    transactions = transactions,
                    onDelete = { viewModel.deleteTransaction(it) }
                )
            }
        }
    }

    // Dialogs
    if (showAddTxDialog) {
        AddTransactionModal(
            viewModel = viewModel,
            onDismiss = { showAddTxDialog = false }
        )
    }

    if (showCashDialog) {
        CashAdjustmentModal(
            currentCash = summary.cashBalance.toDouble(),
            onConfirm = { newCash ->
                viewModel.updateCashBalance(newCash)
                showCashDialog = false
            },
            onDismiss = { showCashDialog = false }
        )
    }

    if (showCostBasisDialog) {
        CostBasisDialog(
            currentMethod = costMethod,
            onSelectMethod = {
                viewModel.costBasisMethod.value = it
                showCostBasisDialog = false
            },
            onDismiss = { showCostBasisDialog = false }
        )
    }

    if (showCsvImportDialog) {
        CsvImportModal(
            viewModel = viewModel,
            onDismiss = { showCsvImportDialog = false }
        )
    }

    if (showCsvExportDialog) {
        CsvExportModal(
            csvContent = viewModel.getExportedCsv(),
            onDismiss = { showCsvExportDialog = false }
        )
    }
}

@Composable
private fun HoldingsList(
    holdings: List<PortfolioHolding>,
    onSelect: (String) -> Unit
) {
    if (holdings.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "No open positions",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = StocksTheme.colors.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Record a buy transaction or import your trade CSV",
                    style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textMuted)
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(holdings, key = { it.symbol }) { h ->
                val isGain = h.unrealizedGain >= BigDecimal.ZERO
                val isForeignCurrency = h.currency != "USD"

                GlassCard(onClick = { onSelect(h.symbol) }) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1.3f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = h.symbol,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = StocksTheme.colors.surfaceHighlight
                                    ) {
                                        Text(
                                            text = "${h.quantity} shs",
                                            style = TabularNumberStyle.copy(
                                                fontSize = 11.sp,
                                                color = StocksTheme.colors.textSecondary
                                            ),
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "${h.exchange} • ${h.sector}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = String.format(Locale.US, "$%,.2f", h.currentValue.toDouble()),
                                    style = TabularNumberStyle.copy(
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.textPrimary
                                    )
                                )
                                val sign = if (isGain) "+" else ""
                                Text(
                                    text = String.format(
                                        Locale.US,
                                        "%s$%,.2f (%s%.2f%%)",
                                        sign,
                                        h.unrealizedGain.toDouble(),
                                        sign,
                                        h.unrealizedGainPercent.toDouble()
                                    ),
                                    style = TabularNumberStyle.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = StocksTheme.colors.border, thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Stats: Avg Cost, Current Price, Dividends Received
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Avg Cost: $${h.averageCostBasis}",
                                style = TabularNumberStyle.copy(fontSize = 11.sp, color = StocksTheme.colors.textMuted)
                            )
                            Text(
                                text = "Price: $${h.currentPrice}",
                                style = TabularNumberStyle.copy(fontSize = 11.sp, color = StocksTheme.colors.textSecondary)
                            )
                            if (h.totalDividendsReceived > BigDecimal.ZERO) {
                                Text(
                                    text = "Divs: +$${h.totalDividendsReceived}",
                                    style = TabularNumberStyle.copy(fontSize = 11.sp, color = StocksTheme.colors.gain)
                                )
                            }
                        }

                        // Transparent Currency footnote if foreign exchange
                        if (isForeignCurrency) {
                            Spacer(modifier = Modifier.height(4.dp))
                            val fxRate = FxRates.getRateToUsd(h.currency)
                            Text(
                                text = "Traded in ${h.currency} • Converted at 1 ${h.currency} = \$${fxRate} USD",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    color = StocksTheme.colors.textMuted
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AllocationView(
    holdings: List<PortfolioHolding>,
    cashBalance: Double,
    totalEquity: Double,
    mode: String,
    onModeChange: (String) -> Unit
) {
    val colors = listOf(
        Color(0xFF0A84FF), Color(0xFF30D158), Color(0xFFFF9F0A),
        Color(0xFFBF5AF2), Color(0xFF64D2FF), Color(0xFFFF375F),
        Color(0xFFFFD60A), Color(0xFF5E5CE6), Color(0xFF8E8E93)
    )

    val slices = when (mode) {
        "SECTOR" -> {
            val sectorMap = mutableMapOf<String, Double>()
            holdings.forEach { h ->
                sectorMap[h.sector] = (sectorMap[h.sector] ?: 0.0) + h.currentValue.toDouble()
            }
            if (cashBalance > 0) sectorMap["Cash"] = cashBalance
            sectorMap.entries.mapIndexed { idx, entry ->
                AllocationSlice(entry.key, entry.value, colors[idx % colors.size])
            }
        }
        "CURRENCY" -> {
            val currMap = mutableMapOf<String, Double>()
            holdings.forEach { h ->
                currMap[h.currency] = (currMap[h.currency] ?: 0.0) + h.currentValue.toDouble()
            }
            currMap["USD"] = (currMap["USD"] ?: 0.0) + cashBalance
            currMap.entries.mapIndexed { idx, entry ->
                AllocationSlice(entry.key, entry.value, colors[idx % colors.size])
            }
        }
        else -> {
            // Holding
            val list = holdings.mapIndexed { idx, h ->
                AllocationSlice(h.symbol, h.currentValue.toDouble(), colors[idx % colors.size])
            }.toMutableList()
            if (cashBalance > 0) {
                list.add(AllocationSlice("Cash", cashBalance, Color(0xFF8E8E93)))
            }
            list
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            // Slices mode toggle
            Row(
                modifier = Modifier
                    .background(StocksTheme.colors.surfaceElevated, RoundedCornerShape(10.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("HOLDING" to "By Holding", "SECTOR" to "By Sector", "CURRENCY" to "By Currency").forEach { (m, lbl) ->
                    val isSel = mode == m
                    Surface(
                        onClick = { onModeChange(m) },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) StocksTheme.colors.surfaceHighlight else Color.Transparent
                    ) {
                        Text(
                            text = lbl,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSel) StocksTheme.colors.textPrimary else StocksTheme.colors.textSecondary
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
            AllocationDonutChart(
                slices = slices,
                totalValueLabel = String.format(Locale.US, "$%,.0f", totalEquity),
                subTitle = "Portfolio Assets"
            )
        }
    }
}

@Composable
private fun TransactionHistoryList(
    transactions: List<TransactionRecord>,
    onDelete: (Long) -> Unit
) {
    if (transactions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No transactions logged yet", color = StocksTheme.colors.textMuted)
        }
    } else {
        val dateFmt = SimpleDateFormat("MMM dd, yyyy", Locale.US)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(transactions, key = { it.id }) { tx ->
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val isBuy = tx.type == TransactionType.BUY
                            val isSell = tx.type == TransactionType.SELL
                            val isDiv = tx.type == TransactionType.DIVIDEND
                            val badgeColor = if (isBuy) AppleBlue else if (isSell) StocksTheme.colors.loss else StocksTheme.colors.gain

                            Surface(
                                shape = CircleShape,
                                color = badgeColor.copy(alpha = 0.15f),
                                modifier = Modifier.size(34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isBuy) Icons.Default.ArrowDownward else if (isSell) Icons.Default.ArrowUpward else Icons.Default.Add,
                                        contentDescription = tx.type.label,
                                        tint = badgeColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = "${tx.type.label} ${tx.symbol}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.textPrimary
                                    )
                                )
                                Text(
                                    text = "${dateFmt.format(Date(tx.timestamp))} • ${tx.quantity} shs @ \$${tx.pricePerShare}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                                )
                                if (tx.notes.isNotEmpty()) {
                                    Text(
                                        text = tx.notes,
                                        style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textSecondary)
                                    )
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val totalTradeCost = tx.quantity.multiply(tx.pricePerShare).toDouble()
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = String.format(Locale.US, "$%,.2f", totalTradeCost),
                                    style = TabularNumberStyle.copy(
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.textPrimary
                                    )
                                )
                                if (tx.fee > BigDecimal.ZERO) {
                                    Text(
                                        text = "Fee: \$${tx.fee}",
                                        style = TabularNumberStyle.copy(fontSize = 10.sp, color = StocksTheme.colors.textMuted)
                                    )
                                }
                            }

                            IconButton(
                                onClick = { onDelete(tx.id) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete transaction",
                                    tint = StocksTheme.colors.textMuted,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddTransactionModal(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var symbol by remember { mutableStateOf("AAPL") }
    var txType by remember { mutableStateOf(TransactionType.BUY) }
    var quantityText by remember { mutableStateOf("10.0") }
    var priceText by remember { mutableStateOf("220.00") }
    var feeText by remember { mutableStateOf("0.00") }
    var currency by remember { mutableStateOf("USD") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Transaction", color = StocksTheme.colors.textPrimary) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Type selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StocksTheme.colors.surfaceHighlight, RoundedCornerShape(8.dp))
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(TransactionType.BUY, TransactionType.SELL, TransactionType.DIVIDEND).forEach { t ->
                        val isSel = txType == t
                        Surface(
                            onClick = { txType = t },
                            modifier = Modifier
                                .weight(1f)
                                .height(30.dp),
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSel) AppleBlue else Color.Transparent
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = t.label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSel) Color.White else StocksTheme.colors.textSecondary
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = symbol,
                    onValueChange = { symbol = it.uppercase() },
                    label = { Text("Ticker Symbol") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppleBlue,
                        focusedContainerColor = StocksTheme.colors.surfaceElevated,
                        unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Quantity (Fractional OK)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AppleBlue,
                            focusedContainerColor = StocksTheme.colors.surfaceElevated,
                            unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                        )
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Price Per Share") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AppleBlue,
                            focusedContainerColor = StocksTheme.colors.surfaceElevated,
                            unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                        )
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = feeText,
                        onValueChange = { feeText = it },
                        label = { Text("Broker Fee ($)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AppleBlue,
                            focusedContainerColor = StocksTheme.colors.surfaceElevated,
                            unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                        )
                    )
                    OutlinedTextField(
                        value = currency,
                        onValueChange = { currency = it.uppercase() },
                        label = { Text("Currency") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AppleBlue,
                            focusedContainerColor = StocksTheme.colors.surfaceElevated,
                            unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                        )
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppleBlue,
                        focusedContainerColor = StocksTheme.colors.surfaceElevated,
                        unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                    )
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val qty = quantityText.toDoubleOrNull() ?: 1.0
                    val pr = priceText.toDoubleOrNull() ?: 100.0
                    val fee = feeText.toDoubleOrNull() ?: 0.0
                    viewModel.addTransaction(
                        symbol = symbol.trim(),
                        type = txType,
                        quantity = qty,
                        pricePerShare = pr,
                        fee = fee,
                        currency = currency.trim(),
                        notes = notes.trim()
                    )
                    onDismiss()
                }
            ) {
                Text("Save", color = AppleBlue, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = StocksTheme.colors.textMuted)
            }
        },
        containerColor = StocksTheme.colors.surfaceElevated
    )
}

@Composable
private fun CashAdjustmentModal(
    currentCash: Double,
    onConfirm: (Double) -> Unit,
    onDismiss: () -> Unit
) {
    var cashText by remember { mutableStateOf(String.format(Locale.US, "%.2f", currentCash)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Update Cash Balance", color = StocksTheme.colors.textPrimary) },
        text = {
            Column {
                Text(
                    text = "Adjust available cash for this account. Cash is automatically updated on buys, sells, dividends, deposits, and withdrawals.",
                    style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textMuted)
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = cashText,
                    onValueChange = { cashText = it },
                    label = { Text("Cash Balance (USD)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppleBlue,
                        focusedContainerColor = StocksTheme.colors.surfaceElevated,
                        unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                    )
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val newAmt = cashText.toDoubleOrNull() ?: currentCash
                    onConfirm(newAmt)
                }
            ) {
                Text("Update", color = AppleBlue)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = StocksTheme.colors.textMuted)
            }
        },
        containerColor = StocksTheme.colors.surfaceElevated
    )
}

@Composable
private fun CostBasisDialog(
    currentMethod: CostBasisMethod,
    onSelectMethod: (CostBasisMethod) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cost Basis Method", color = StocksTheme.colors.textPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = "Selected method determines how realized gains are matched when positions are partially sold:",
                    style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textMuted)
                )

                CostBasisMethod.values().forEach { method ->
                    val isSel = method == currentMethod
                    Surface(
                        onClick = { onSelectMethod(method) },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSel) StocksTheme.colors.surfaceHighlight else Color.Transparent,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSel) AppleBlue else StocksTheme.colors.border
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = method.title,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSel) AppleBlue else StocksTheme.colors.textPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = method.description,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = StocksTheme.colors.textMuted,
                                    lineHeight = 14.sp
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = AppleBlue)
            }
        },
        containerColor = StocksTheme.colors.surfaceElevated
    )
}

@Composable
private fun CsvImportModal(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    var rawCsvText by remember {
        mutableStateOf(
            """
            Date,Type,Symbol,Quantity,Price,Fee,Currency,Notes
            2026-10-15,BUY,AAPL,5.0,224.50,1.99,USD,Sample Import Lot
            2026-10-20,BUY,NVDA,10.0,135.00,1.99,USD,Pre-earnings add
            2026-10-25,DIVIDEND,AAPL,0.0,1.25,0.00,USD,Quarterly dividend
            """.trimIndent()
        )
    }

    var parseResult by remember { mutableStateOf<CsvParseResult?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import Transactions CSV", color = StocksTheme.colors.textPrimary) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Paste standard trade CSV or edit the sample template below. Validates duplicates and column syntax:",
                    style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = rawCsvText,
                    onValueChange = {
                        rawCsvText = it
                        parseResult = null
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppleBlue,
                        focusedContainerColor = StocksTheme.colors.surfaceElevated,
                        unfocusedContainerColor = StocksTheme.colors.surfaceElevated
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                FilledTonalButton(
                    onClick = {
                        parseResult = viewModel.parseCsv(rawCsvText)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Validate & Preview CSV")
                }

                parseResult?.let { res ->
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Validation: ${res.validTransactions.size} valid rows, ${res.duplicates.size} duplicates detected, ${res.errors.size} errors.",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (res.errors.isEmpty()) StocksTheme.colors.gain else StocksTheme.colors.loss,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    if (res.errors.isNotEmpty()) {
                        Text(
                            text = res.errors.first(),
                            style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.loss)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val result = parseResult ?: viewModel.parseCsv(rawCsvText)
                    if (result.validTransactions.isNotEmpty()) {
                        viewModel.commitCsvImport(result.validTransactions)
                    }
                    onDismiss()
                }
            ) {
                Text("Commit Import", color = AppleBlue, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = StocksTheme.colors.textMuted)
            }
        },
        containerColor = StocksTheme.colors.surfaceElevated
    )
}

@Composable
private fun CsvExportModal(
    csvContent: String,
    onDismiss: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Export Portfolio CSV", color = StocksTheme.colors.textPrimary) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Standard CSV export of transaction ledgers including dates, quantities, prices, fees, and multi-currency identifiers:",
                    style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StocksTheme.colors.surfaceHighlight,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                ) {
                    Text(
                        text = csvContent,
                        style = TabularNumberStyle.copy(fontSize = 11.sp, color = StocksTheme.colors.textPrimary),
                        modifier = Modifier.padding(10.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                FilledTonalButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(csvContent))
                        copied = true
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (copied) "Copied to Clipboard!" else "Copy to Clipboard")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = AppleBlue)
            }
        },
        containerColor = StocksTheme.colors.surfaceElevated
    )
}
