package com.example.model

enum class AssetType(val label: String) {
    EQUITY("Stock"),
    ETF("ETF"),
    INDEX("Index"),
    CRYPTO("Crypto")
}

data class Instrument(
    val id: String, // e.g. "AAPL.NASDAQ"
    val symbol: String, // e.g. "AAPL"
    val name: String, // e.g. "Apple Inc."
    val exchange: String, // e.g. "NASDAQ"
    val currency: String = "USD", // "USD", "EUR", "GBP"
    val assetType: AssetType = AssetType.EQUITY,
    val currentPrice: Double,
    val previousClose: Double,
    val openPrice: Double = previousClose,
    val dayHigh: Double = maxOf(currentPrice, previousClose * 1.01),
    val dayLow: Double = minOf(currentPrice, previousClose * 0.99),
    val marketCap: Double = 0.0, // in Billions
    val peRatio: Double? = null, // nullable to reflect missing fundamentals
    val forwardPe: Double? = null,
    val eps: Double? = null,
    val dividendYield: Double? = null, // e.g. 0.52 for 0.52%
    val exDividendDate: String? = null,
    val volume: Long = 0L,
    val avgVolume: Long = 0L,
    val beta: Double? = null,
    val high52: Double = currentPrice * 1.15,
    val low52: Double = currentPrice * 0.85,
    val description: String = "",
    val sector: String = "General",
    val dataSource: String = "Simulated Exchange Feed",
    val quoteFreshness: String = "Live (Simulated)", // "Live", "Delayed 15m", "EOD", "Simulated"
    val quoteTimestamp: Long = System.currentTimeMillis(),
    val isMarketOpen: Boolean = true,
    val sparklinePoints: List<Double> = emptyList()
) {
    val change: Double get() = currentPrice - previousClose
    val changePercent: Double get() = if (previousClose > 0) ((currentPrice - previousClose) / previousClose) * 100.0 else 0.0
    val isGain: Boolean get() = change >= 0
}
