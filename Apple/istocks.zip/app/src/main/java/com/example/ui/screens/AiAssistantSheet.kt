package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiPromptType
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.AiGlowCyan
import com.example.ui.theme.AiGlowIndigo
import com.example.ui.theme.AiGlowViolet
import com.example.ui.theme.AppleBlue
import com.example.ui.theme.StocksTheme
import com.example.ui.theme.TabularNumberStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantSheet(
    viewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val targetSymbol by viewModel.aiTargetSymbol.collectAsState()
    val aiResponse by viewModel.aiResponse.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()
    var customQuery by remember { mutableStateOf("") }

    val glowGradient = Brush.horizontalGradient(
        listOf(AiGlowCyan, AiGlowIndigo, AiGlowViolet)
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = StocksTheme.colors.surfaceElevated,
        modifier = Modifier.testTag("ai_assistant_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header with Apple Intelligence glowing brand accent
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Transparent,
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, glowGradient),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Assistant",
                                tint = AiGlowCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = "iStocks Research Assistant",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = StocksTheme.colors.textPrimary
                            )
                        )
                        Text(
                            text = "Audited facts • Citations • Analytical models",
                            style = MaterialTheme.typography.labelSmall.copy(color = StocksTheme.colors.textMuted)
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = StocksTheme.colors.textPrimary
                    )
                }
            }

            // Quick Prompt Modes Pills Carousel
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AiPromptType.values().forEach { promptType ->
                    Surface(
                        onClick = { viewModel.runAiQuery(promptType, targetSymbol) },
                        shape = RoundedCornerShape(12.dp),
                        color = StocksTheme.colors.surfaceHighlight,
                        border = androidx.compose.foundation.BorderStroke(1.dp, StocksTheme.colors.border)
                    ) {
                        Text(
                            text = promptType.title,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = StocksTheme.colors.textPrimary
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            // Custom Question Input Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = customQuery,
                    onValueChange = { customQuery = it },
                    placeholder = { Text("Ask about ratios, filings, or terms...", fontSize = 13.sp) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppleBlue,
                        focusedContainerColor = StocksTheme.colors.surfaceHighlight,
                        unfocusedContainerColor = StocksTheme.colors.surfaceHighlight
                    )
                )

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (customQuery.isNotBlank()) {
                            viewModel.runAiQuery(AiPromptType.TERM_EXPLAINER, targetSymbol, customQuery)
                            customQuery = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .background(AppleBlue, RoundedCornerShape(12.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send prompt",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Result Content / Loading State
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(
                            color = AiGlowCyan,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Synthesizing filings and market telemetry...",
                            style = MaterialTheme.typography.bodySmall.copy(color = StocksTheme.colors.textMuted)
                        )
                    }
                }
            } else if (aiResponse != null) {
                val resp = aiResponse!!
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Title & Executive Summary
                    item {
                        GlassCard {
                            Column {
                                Text(
                                    text = resp.queryTitle,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.textPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = resp.summary,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = StocksTheme.colors.textSecondary,
                                        lineHeight = 20.sp
                                    )
                                )
                            }
                        }
                    }

                    // Section 1: Verified Reported Facts
                    item {
                        GlassCard {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "1. VERIFIED FACTS & REGULATORY DISCLOSURES",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.gain,
                                        letterSpacing = 1.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                resp.reportedFacts.forEach { fact ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "Fact",
                                            tint = StocksTheme.colors.gain,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .padding(top = 2.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = fact,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = StocksTheme.colors.textPrimary,
                                                lineHeight = 18.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Section 2: Calculated Metrics
                    item {
                        GlassCard {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "2. DERIVED FINANCIAL CALCULATIONS",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = AppleBlue,
                                        letterSpacing = 1.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                resp.calculatedMetrics.forEach { metric ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = "• $metric",
                                            style = TabularNumberStyle.copy(
                                                fontSize = 13.sp,
                                                color = StocksTheme.colors.textPrimary
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Section 3: Generated Interpretation
                    item {
                        GlassCard {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "3. GENERATED ANALYTICAL INTERPRETATION",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = AiGlowViolet,
                                        letterSpacing = 1.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = resp.generatedInterpretation,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = StocksTheme.colors.textSecondary,
                                        lineHeight = 20.sp
                                    )
                                )
                            }
                        }
                    }

                    // Section 4: Cited Sources & Dates
                    item {
                        GlassCard {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "4. CITED PRIMARY SOURCES",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = StocksTheme.colors.textMuted,
                                        letterSpacing = 1.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                resp.citedSources.forEach { src ->
                                    Text(
                                        text = "📍 $src",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = StocksTheme.colors.textMuted,
                                            fontSize = 11.sp
                                        ),
                                        modifier = Modifier.padding(vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Compliance disclaimer
                    item {
                        Text(
                            text = resp.disclaimer,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StocksTheme.colors.textMuted,
                                fontSize = 10.sp,
                                lineHeight = 13.sp
                            ),
                            modifier = Modifier.padding(bottom = 24.dp)
                        )
                    }
                }
            }
        }
    }
}
