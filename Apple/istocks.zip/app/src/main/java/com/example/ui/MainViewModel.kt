package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.accounting.CsvParseResult
import com.example.accounting.CsvProcessor
import com.example.data.AiResearchService
import com.example.data.MarketDataRepository
import com.example.data.PortfolioRepository
import com.example.data.local.StocksDatabase
import com.example.model.AiPromptType
import com.example.model.AiResearchResponse
import com.example.model.ChartRange
import com.example.model.CostBasisMethod
import com.example.model.HistoricalPoint
import com.example.model.Instrument
import com.example.model.PortfolioAccount
import com.example.model.PortfolioHolding
import com.example.model.PortfolioSummary
import com.example.model.PriceAlert
import com.example.model.TransactionRecord
import com.example.model.TransactionType
import com.example.model.WatchlistGroup
import com.example.model.WatchlistSortOrder
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.math.BigDecimal

enum class AppTab(val title: String) {
    TODAY("Today"),
    WATCHLIST("Watchlist"),
    MARKETS("Markets"),
    PORTFOLIO("Portfolio"),
    SEARCH("Search")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        StocksDatabase::class.java,
        "istocks_local.db"
    ).fallbackToDestructiveMigration().build()

    val marketRepo = MarketDataRepository()
    val portfolioRepo = PortfolioRepository(db.stocksDao(), marketRepo, viewModelScope)
    val aiService = AiResearchService(marketRepo)

    // Navigation & Selected Tab
    private val _currentTab = MutableStateFlow(AppTab.TODAY)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    fun selectTab(tab: AppTab) {
        _currentTab.value = tab
    }

    // Detail Sheet for active instrument
    private val _selectedInstrumentSymbol = MutableStateFlow<String?>(null)
    val selectedInstrumentSymbol: StateFlow<String?> = _selectedInstrumentSymbol.asStateFlow()

    fun openCompanyDetail(symbol: String) {
        _selectedInstrumentSymbol.value = symbol
    }

    fun closeCompanyDetail() {
        _selectedInstrumentSymbol.value = null
    }

    // AI Assistant Sheet
    private val _isAiSheetOpen = MutableStateFlow(false)
    val isAiSheetOpen: StateFlow<Boolean> = _isAiSheetOpen.asStateFlow()

    private val _aiTargetSymbol = MutableStateFlow("AAPL")
    val aiTargetSymbol: StateFlow<String> = _aiTargetSymbol.asStateFlow()

    private val _aiResponse = MutableStateFlow<AiResearchResponse?>(null)
    val aiResponse: StateFlow<AiResearchResponse?> = _aiResponse.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    fun openAiAssistant(symbol: String = "AAPL") {
        _aiTargetSymbol.value = symbol
        _isAiSheetOpen.value = true
        // Default initial research query
        runAiQuery(AiPromptType.ANNOUNCEMENTS_SUMMARY, symbol)
    }

    fun closeAiAssistant() {
        _isAiSheetOpen.value = false
    }

    fun runAiQuery(promptType: AiPromptType, symbol: String = _aiTargetSymbol.value, customText: String = "") {
        _isAiLoading.value = true
        viewModelScope.launch {
            delay(400) // Realistic processing duration
            val (holdings, summary) = portfolioRepo.portfolioState.value
            val result = aiService.processQuery(
                promptType = promptType,
                targetSymbol = symbol,
                holdings = holdings,
                summary = summary,
                customInput = customText
            )
            _aiResponse.value = result
            _isAiLoading.value = false
        }
    }

    // Market Instruments
    val instruments: StateFlow<List<Instrument>> = marketRepo.instruments

    // Selected Benchmark for Today screen
    val selectedBenchmarkSymbol = MutableStateFlow("^GSPC")

    // Watchlists & Active Watchlist
    val watchlists: FlowState<List<WatchlistGroup>> = portfolioRepo.watchlists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedWatchlistId = MutableStateFlow<Long?>(null)
    val watchlistSortOrder = MutableStateFlow(WatchlistSortOrder.CUSTOM)

    // Portfolio Data
    val accounts: StateFlow<List<PortfolioAccount>> = portfolioRepo.accounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val portfolioState: StateFlow<Pair<List<PortfolioHolding>, PortfolioSummary>> = portfolioRepo.portfolioState
    val transactions: StateFlow<List<TransactionRecord>> = portfolioRepo.currentTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<PriceAlert>> = portfolioRepo.alerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val costBasisMethod: MutableStateFlow<CostBasisMethod> = portfolioRepo.costBasisMethod

    // Search & Recent Queries
    val searchQuery = MutableStateFlow("")
    val searchFilterType = MutableStateFlow<String>("ALL")
    val recentSearches = MutableStateFlow(listOf("AAPL", "NVDA", "SPY", "AZN", "MC"))

    fun addRecentSearch(symbol: String) {
        val current = recentSearches.value.toMutableList()
        current.remove(symbol)
        current.add(0, symbol)
        recentSearches.value = current.take(8)
    }

    fun clearRecentSearches() {
        recentSearches.value = emptyList()
    }

    // Actions
    fun addTransaction(
        symbol: String,
        type: TransactionType,
        quantity: Double,
        pricePerShare: Double,
        fee: Double,
        currency: String = "USD",
        notes: String = ""
    ) {
        viewModelScope.launch {
            val record = TransactionRecord(
                accountId = portfolioRepo.selectedAccountId.value,
                symbol = symbol.uppercase(),
                type = type,
                quantity = BigDecimal.valueOf(quantity),
                pricePerShare = BigDecimal.valueOf(pricePerShare),
                fee = BigDecimal.valueOf(fee),
                currency = currency,
                timestamp = System.currentTimeMillis(),
                notes = notes
            )
            portfolioRepo.addTransaction(record)
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch {
            portfolioRepo.deleteTransaction(id)
        }
    }

    fun addPriceAlert(symbol: String, targetPrice: Double, isAbove: Boolean, note: String) {
        viewModelScope.launch {
            portfolioRepo.addPriceAlert(symbol, targetPrice, isAbove, note)
        }
    }

    fun deletePriceAlert(id: Long) {
        viewModelScope.launch {
            portfolioRepo.deletePriceAlert(id)
        }
    }

    fun toggleSymbolInWatchlist(watchlistId: Long, symbol: String) {
        viewModelScope.launch {
            portfolioRepo.toggleSymbolInWatchlist(watchlistId, symbol)
        }
    }

    fun createWatchlist(name: String, symbols: List<String> = emptyList()) {
        viewModelScope.launch {
            portfolioRepo.addWatchlist(name, symbols)
        }
    }

    fun deleteWatchlist(id: Long) {
        viewModelScope.launch {
            portfolioRepo.deleteWatchlist(id)
        }
    }

    fun updateCashBalance(newBalance: Double) {
        viewModelScope.launch {
            portfolioRepo.updateCashBalance(portfolioRepo.selectedAccountId.value, newBalance)
        }
    }

    // CSV Import / Export
    fun parseCsv(csvText: String): CsvParseResult {
        return CsvProcessor.parseAndValidateCsv(
            csvContent = csvText,
            existingTransactions = transactions.value,
            targetAccountId = portfolioRepo.selectedAccountId.value
        )
    }

    fun commitCsvImport(validTransactions: List<TransactionRecord>) {
        viewModelScope.launch {
            portfolioRepo.importTransactions(validTransactions)
        }
    }

    fun getExportedCsv(): String {
        return CsvProcessor.exportToCsv(transactions.value)
    }

    // Live tick periodic updater
    init {
        viewModelScope.launch {
            while (true) {
                delay(6000) // periodic simulated price tick
                marketRepo.simulateLiveTick()
            }
        }
    }
}

typealias FlowState<T> = StateFlow<T>
