package com.example.accounting

import com.example.model.TransactionRecord
import com.example.model.TransactionType
import java.math.BigDecimal
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CsvParseResult(
    val validTransactions: List<TransactionRecord>,
    val duplicates: List<TransactionRecord>,
    val errors: List<String>
)

object CsvProcessor {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    private val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun exportToCsv(transactions: List<TransactionRecord>): String {
        val sb = StringBuilder()
        sb.append("Date,Type,Symbol,Quantity,Price,Fee,Currency,Notes\n")
        for (tx in transactions) {
            val dateStr = dateFormat.format(Date(tx.timestamp))
            sb.append("\"$dateStr\",")
            sb.append("\"${tx.type.name}\",")
            sb.append("\"${tx.symbol}\",")
            sb.append("${tx.quantity},")
            sb.append("${tx.pricePerShare},")
            sb.append("${tx.fee},")
            sb.append("\"${tx.currency}\",")
            sb.append("\"${tx.notes.replace("\"", "\"\"")}\"\n")
        }
        return sb.toString()
    }

    fun parseAndValidateCsv(
        csvContent: String,
        existingTransactions: List<TransactionRecord>,
        targetAccountId: Long = 1L
    ): CsvParseResult {
        val lines = csvContent.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) {
            return CsvParseResult(emptyList(), emptyList(), listOf("CSV content is empty"))
        }

        val validList = mutableListOf<TransactionRecord>()
        val duplicatesList = mutableListOf<TransactionRecord>()
        val errorsList = mutableListOf<String>()

        // Check header
        val header = lines.first().lowercase()
        val startIndex = if (header.contains("date") || header.contains("symbol")) 1 else 0

        for (i in startIndex until lines.size) {
            val line = lines[i]
            val tokens = parseCsvLine(line)
            if (tokens.size < 5) {
                errorsList.add("Row ${i + 1}: Insufficient columns (found ${tokens.size}, expected at least 5)")
                continue
            }

            try {
                val dateStr = tokens[0].trim()
                val typeStr = tokens[1].trim().uppercase()
                val symbol = tokens[2].trim().uppercase()
                val qtyStr = tokens[3].trim()
                val priceStr = tokens[4].trim()
                val feeStr = if (tokens.size > 5) tokens[5].trim() else "0.0"
                val currency = if (tokens.size > 6 && tokens[6].isNotBlank()) tokens[6].trim().uppercase() else "USD"
                val notes = if (tokens.size > 7) tokens[7].trim() else ""

                val type = try {
                    TransactionType.valueOf(typeStr)
                } catch (e: Exception) {
                    when (typeStr) {
                        "BUY", "B" -> TransactionType.BUY
                        "SELL", "S" -> TransactionType.SELL
                        "DIV", "DIVIDEND" -> TransactionType.DIVIDEND
                        "DEP", "DEPOSIT" -> TransactionType.DEPOSIT
                        "WITHDRAW", "WITHDRAWAL" -> TransactionType.WITHDRAWAL
                        else -> throw IllegalArgumentException("Unknown transaction type: $typeStr")
                    }
                }

                val timestamp = try {
                    dateFormat.parse(dateStr)?.time
                        ?: simpleDateFormat.parse(dateStr)?.time
                        ?: System.currentTimeMillis()
                } catch (e: Exception) {
                    try {
                        simpleDateFormat.parse(dateStr)?.time ?: System.currentTimeMillis()
                    } catch (e2: Exception) {
                        System.currentTimeMillis()
                    }
                }

                val qty = BigDecimal(qtyStr)
                val price = BigDecimal(priceStr)
                val fee = BigDecimal(feeStr.ifEmpty { "0.0" })

                if (qty <= BigDecimal.ZERO && type != TransactionType.DEPOSIT && type != TransactionType.WITHDRAWAL && type != TransactionType.DIVIDEND) {
                    errorsList.add("Row ${i + 1}: Quantity must be greater than zero")
                    continue
                }

                val record = TransactionRecord(
                    id = 0L,
                    accountId = targetAccountId,
                    symbol = symbol,
                    type = type,
                    quantity = qty,
                    pricePerShare = price,
                    fee = fee,
                    currency = currency,
                    timestamp = timestamp,
                    notes = notes
                )

                // Check for duplicate against existing list and current batch
                val isDuplicate = existingTransactions.any { existing ->
                    existing.symbol == record.symbol &&
                            existing.type == record.type &&
                            existing.quantity.compareTo(record.quantity) == 0 &&
                            existing.pricePerShare.compareTo(record.pricePerShare) == 0 &&
                            Math.abs(existing.timestamp - record.timestamp) < 60_000 // within 1 minute
                } || validList.any { prev ->
                    prev.symbol == record.symbol &&
                            prev.type == record.type &&
                            prev.quantity.compareTo(record.quantity) == 0 &&
                            prev.pricePerShare.compareTo(record.pricePerShare) == 0 &&
                            Math.abs(prev.timestamp - record.timestamp) < 60_000
                }

                if (isDuplicate) {
                    duplicatesList.add(record)
                } else {
                    validList.add(record)
                }
            } catch (e: Exception) {
                errorsList.add("Row ${i + 1}: ${e.message ?: "Invalid data format"}")
            }
        }

        return CsvParseResult(validList, duplicatesList, errorsList)
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false

        for (ch in line) {
            when {
                ch == '\"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> {
                    result.add(current.toString().trim())
                    current.setLength(0)
                }
                else -> current.append(ch)
            }
        }
        result.add(current.toString().trim())
        return result
    }
}
