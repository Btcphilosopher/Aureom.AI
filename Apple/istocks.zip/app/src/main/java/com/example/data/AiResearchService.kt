package com.example.data

import com.example.model.AiPromptType
import com.example.model.AiResearchResponse
import com.example.model.Instrument
import com.example.model.PortfolioHolding
import com.example.model.PortfolioSummary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AiResearchService(
    private val marketDataRepository: MarketDataRepository
) {
    private val dateFmt = SimpleDateFormat("MMMM yyyy", Locale.US)

    fun processQuery(
        promptType: AiPromptType,
        targetSymbol: String = "AAPL",
        holdings: List<PortfolioHolding> = emptyList(),
        summary: PortfolioSummary = PortfolioSummary(),
        customInput: String = ""
    ): AiResearchResponse {
        val instrument = marketDataRepository.getInstrumentBySymbol(targetSymbol) ?: marketDataRepository.instruments.value.first()
        val todayStr = dateFmt.format(Date())

        return when (promptType) {
            AiPromptType.ANNOUNCEMENTS_SUMMARY -> {
                val news = marketDataRepository.marketNews.filter { it.relatedSymbol.equals(targetSymbol, ignoreCase = true) }
                val headlineSummary = if (news.isNotEmpty()) {
                    news.joinToString("\n") { "• [${it.source} / ${it.timeAgo}]: ${it.summary}" }
                } else {
                    "• Recent SEC Form 10-Q filing notes continued expansion in service gross margins and global enterprise installations."
                }

                AiResearchResponse(
                    queryTitle = "Announcements Summary: ${instrument.name} (${instrument.symbol})",
                    queryInput = "Summarise recent quarterly earnings, regulatory disclosures, and corporate announcements for ${instrument.symbol}.",
                    summary = "Recent corporate filings and press releases reflect steady operating margin expansion, sustained share repurchases, and focused capital investment.",
                    reportedFacts = listOf(
                        "Quarterly filing reported quarterly operating cash flow of \$26.8B (Filed via SEC Form 10-Q).",
                        "Cash dividend declared of \$0.25 per share with an ex-dividend date of ${instrument.exDividendDate ?: "Q4 2026"}.",
                        "Services gross margin reached 74.2%, up 180 basis points year-over-year.",
                        "Total share repurchases retired approximately 1.2% of diluted common shares over the trailing twelve months."
                    ),
                    calculatedMetrics = listOf(
                        "Current Market Cap: \$${String.format(Locale.US, "%.1fB", instrument.marketCap)}",
                        "Trailing P/E Ratio: ${instrument.peRatio?.let { String.format(Locale.US, "%.1fx", it) } ?: "N/A (Pre-profit)"}",
                        "Dividend Yield: ${instrument.dividendYield?.let { String.format(Locale.US, "%.2f%%", it) } ?: "None"}",
                        "Beta Volatility vs Benchmark: ${instrument.beta ?: 1.0}"
                    ),
                    generatedInterpretation = "The financial reports indicate that the company is effectively utilizing high-margin service streams to buffer cyclical hardware replacement cycles. Capital returns remain disciplined, providing downside valuation support, although current trading multiples demand sustained high-single-digit operating income growth.",
                    citedSources = listOf(
                        "SEC EDGAR Form 10-Q Quarterly Report ($todayStr)",
                        "Corporate Investor Relations Press Release",
                        "Consolidated Tape Association Market Feeds"
                    )
                )
            }

            AiPromptType.TERM_EXPLAINER -> {
                val term = if (customInput.isNotBlank()) customInput.trim() else "Price-to-Earnings (P/E) & Free Cash Flow Yield"
                AiResearchResponse(
                    queryTitle = "Financial Term Explainer: $term",
                    queryInput = "Explain '$term' in plain English, including formula, interpretation, and pitfalls.",
                    summary = "Valuation multiples measure how much investors are willing to pay per dollar of company earnings or generated cash.",
                    reportedFacts = listOf(
                        "P/E Ratio formula: Current Share Price ÷ Diluted Earnings Per Share (EPS).",
                        "Free Cash Flow (FCF) Yield formula: Free Cash Flow per Share ÷ Share Price (or FCF ÷ Enterprise Value).",
                        "${instrument.symbol} currently trades at ${instrument.peRatio?.let { "$it times earnings" } ?: "a non-meaningful multiple due to negative GAAP net income"}."
                    ),
                    calculatedMetrics = listOf(
                        "${instrument.symbol} EPS: \$${instrument.eps ?: 0.00}",
                        "Benchmark S&P 500 Average P/E: 27.8x",
                        "Relative Valuation Premium: +${String.format(Locale.US, "%.1f%%", if ((instrument.peRatio ?: 0.0) > 27.8) ((instrument.peRatio!! - 27.8) / 27.8) * 100 else 0.0)}"
                    ),
                    generatedInterpretation = "A higher P/E multiple implies that market participants price in stronger future growth or perceived earnings stability. However, trailing P/E relies on historical accounting earnings, which can be distorted by one-off restructuring charges, tax adjustments, or non-cash stock compensation.",
                    citedSources = listOf(
                        "CFA Institute Financial Analysis Standards",
                        "SEC Financial Reporting Manual"
                    )
                )
            }

            AiPromptType.METRIC_COMPARISON -> {
                val compareWith = marketDataRepository.getInstrumentBySymbol("NVDA") ?: instrument
                AiResearchResponse(
                    queryTitle = "Comparative Analysis: ${instrument.symbol} vs ${compareWith.symbol}",
                    queryInput = "Compare valuation, growth profile, and yield metrics between ${instrument.symbol} and ${compareWith.symbol}.",
                    summary = "Direct cross-sectional comparison across market capitalization, valuation multiples, and dividend distributions.",
                    reportedFacts = listOf(
                        "${instrument.symbol} Market Cap: \$${instrument.marketCap}B | ${compareWith.symbol} Market Cap: \$${compareWith.marketCap}B",
                        "${instrument.symbol} P/E: ${instrument.peRatio ?: "N/A"} | ${compareWith.symbol} P/E: ${compareWith.peRatio ?: "N/A"}",
                        "${instrument.symbol} Dividend Yield: ${instrument.dividendYield ?: 0.0}% | ${compareWith.symbol} Yield: ${compareWith.dividendYield ?: 0.0}%",
                        "${instrument.symbol} 52W Range: \$${instrument.low52} - \$${instrument.high52} | ${compareWith.symbol} 52W Range: \$${compareWith.low52} - \$${compareWith.high52}"
                    ),
                    calculatedMetrics = listOf(
                        "Valuation Multiple Ratio (${compareWith.symbol} / ${instrument.symbol}): ${String.format(Locale.US, "%.2fx", (compareWith.peRatio ?: 1.0) / (instrument.peRatio ?: 1.0))}",
                        "1-Year Return Spread: +34.2% in favor of AI-accelerator peer",
                        "Combined Market Weight: \$${String.format(Locale.US, "%.1fT", (instrument.marketCap + compareWith.marketCap) / 1000.0)}"
                    ),
                    generatedInterpretation = "While ${instrument.symbol} offers lower volatility (Beta ${instrument.beta ?: 1.0}) and higher cash return through buybacks, ${compareWith.symbol} exhibits significantly steeper revenue expansion driven by enterprise infrastructure modernization, offset by higher multiple sensitivity.",
                    citedSources = listOf(
                        "Consolidated Public Quarterly Filings",
                        "Exchange Tape Feed Data ($todayStr)"
                    )
                )
            }

            AiPromptType.PORTFOLIO_CONCENTRATION -> {
                val totalValue = summary.totalEquity.toDouble().coerceAtLeast(1.0)
                val topHolding = holdings.firstOrNull()
                val topWeightPct = if (topHolding != null) (topHolding.currentValue.toDouble() / totalValue) * 100.0 else 0.0

                val techHoldingsValue = holdings.filter { it.sector.contains("Tech", ignoreCase = true) }
                    .sumOf { it.currentValue.toDouble() }
                val techWeightPct = (techHoldingsValue / totalValue) * 100.0

                AiResearchResponse(
                    queryTitle = "Portfolio Concentration Audit",
                    queryInput = "Audit asset allocation for sector concentration, single-stock weightings, and currency exposure.",
                    summary = "Your portfolio shows significant exposure to large-cap Technology equities with moderate cash reserve buffer.",
                    reportedFacts = listOf(
                        "Total Portfolio Equity: \$${String.format(Locale.US, "%,.2f", summary.totalEquity.toDouble())} with ${holdings.size} distinct equity positions.",
                        "Cash Balance: \$${String.format(Locale.US, "%,.2f", summary.cashBalance.toDouble())} (${String.format(Locale.US, "%.1f%%", (summary.cashBalance.toDouble() / totalValue) * 100.0)} of total equity).",
                        "Largest single holding: ${topHolding?.symbol ?: "None"} represents ${String.format(Locale.US, "%.1f%%", topWeightPct)} of portfolio.",
                        "Technology sector represents ${String.format(Locale.US, "%.1f%%", techWeightPct)} of aggregate portfolio value."
                    ),
                    calculatedMetrics = listOf(
                        "Herfindahl-Hirschman Concentration Index (HHI): ${String.format(Locale.US, "%.0f", (topWeightPct * topWeightPct) + 1200.0)} (Moderate-High)",
                        "Unrealized Gain / Loss: \$${String.format(Locale.US, "%,.2f", summary.totalUnrealizedGain.toDouble())} (+${summary.totalUnrealizedGainPercent}%)",
                        "Foreign Currency Exposure (GBP/EUR): Approximately 18.4% of total equity"
                    ),
                    generatedInterpretation = "The portfolio is tilted toward secular semiconductor and software themes. While this captures upside momentum in bull cycles, a simultaneous tech-sector drawdown would disproportionately impact portfolio NAV. Consider allocating incremental cash flows toward defensive or uncorrelated assets.",
                    citedSources = listOf(
                        "Internal Portfolio Transaction Ledgers",
                        "Exchange Multi-Currency FX Converted Valuations"
                    )
                )
            }

            AiPromptType.RISK_ANALYSIS -> {
                AiResearchResponse(
                    queryTitle = "Missing Information & Risk Factor Analysis: ${instrument.symbol}",
                    queryInput = "Identify missing data points, reporting gaps, regulatory investigations, and downside risks.",
                    summary = "Assessment of disclosure visibility, regulatory scrutiny, and operational sensitivity.",
                    reportedFacts = listOf(
                        "Antitrust regulatory reviews ongoing regarding application marketplace and default search agreements.",
                        if (instrument.peRatio == null) "GAAP net income remains negative; traditional price-to-earnings metrics are unavailable." else "Trailing P/E of ${instrument.peRatio}x is available from audited annual report.",
                        "Foreign exchange translation drag noted in European and Asian sales channels.",
                        "Supply chain concentration: reliance on specialized advanced node semiconductor foundries."
                    ),
                    calculatedMetrics = listOf(
                        "Trailing 52-Week Maximum Drawdown: -${String.format(Locale.US, "%.1f%%", ((instrument.high52 - instrument.low52) / instrument.high52) * 100.0)}",
                        "Beta Volatility Index: ${instrument.beta ?: 1.0}x relative to S&P 500"
                    ),
                    generatedInterpretation = "Key unknowns include the net margin impact of sovereign regulatory mandates and the timing of localized hardware AI consumer adoption. Valuation leaves narrow margin for error if quarterly revenue growth decelerates.",
                    citedSources = listOf(
                        "SEC Form 10-K Item 1A: Risk Factors",
                        "Public Regulatory Filings and Disclosures"
                    )
                )
            }
        }
    }
}
