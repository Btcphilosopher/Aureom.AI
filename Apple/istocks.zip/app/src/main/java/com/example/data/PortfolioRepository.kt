package com.example.data

import com.example.accounting.PortfolioCalculator
import com.example.data.local.AccountEntity
import com.example.data.local.PriceAlertEntity
import com.example.data.local.StocksDao
import com.example.data.local.TransactionEntity
import com.example.data.local.WatchlistEntity
import com.example.model.CostBasisMethod
import com.example.model.PortfolioAccount
import com.example.model.PortfolioHolding
import com.example.model.PortfolioSummary
import com.example.model.PriceAlert
import com.example.model.TransactionRecord
import com.example.model.TransactionType
import com.example.model.WatchlistGroup
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.math.BigDecimal

class PortfolioRepository(
    private val dao: StocksDao,
    private val marketDataRepository: MarketDataRepository,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val calculator = PortfolioCalculator()

    val costBasisMethod = MutableStateFlow(CostBasisMethod.FIFO)
    val selectedAccountId = MutableStateFlow(1L)

    val watchlists: Flow<List<WatchlistGroup>> = dao.getAllWatchlists().map { entities ->
        entities.map { entity ->
            WatchlistGroup(
                id = entity.id,
                name = entity.name,
                symbols = entity.symbolsCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() },
                isDefault = entity.isDefault
            )
        }
    }

    val accounts: Flow<List<PortfolioAccount>> = dao.getAllAccounts().map { entities ->
        entities.map { entity ->
            PortfolioAccount(
                id = entity.id,
                name = entity.name,
                cashBalance = BigDecimal.valueOf(entity.cashBalance),
                currency = entity.currency,
                isDefault = entity.isDefault
            )
        }
    }

    val alerts: Flow<List<PriceAlert>> = dao.getAllAlerts().map { entities ->
        entities.map { entity ->
            PriceAlert(
                id = entity.id,
                symbol = entity.symbol,
                targetPrice = entity.targetPrice,
                isAbove = entity.isAbove,
                isActive = entity.isActive,
                createdAt = entity.createdAt,
                triggeredAt = entity.triggeredAt,
                note = entity.note
            )
        }
    }

    val currentTransactions: Flow<List<TransactionRecord>> = combine(
        selectedAccountId,
        dao.getAllTransactions()
    ) { accountId, allTx ->
        allTx.filter { it.accountId == accountId }.map { entity ->
            TransactionRecord(
                id = entity.id,
                accountId = entity.accountId,
                symbol = entity.symbol,
                type = TransactionType.valueOf(entity.type),
                quantity = BigDecimal.valueOf(entity.quantity),
                pricePerShare = BigDecimal.valueOf(entity.pricePerShare),
                fee = BigDecimal.valueOf(entity.fee),
                currency = entity.currency,
                timestamp = entity.timestamp,
                notes = entity.notes
            )
        }
    }

    // Reactive computation of holdings and total summary
    val portfolioState: StateFlow<Pair<List<PortfolioHolding>, PortfolioSummary>> = combine(
        currentTransactions,
        marketDataRepository.instruments,
        accounts,
        selectedAccountId,
        costBasisMethod
    ) { txs, instruments, accountList, accId, method ->
        val currentAccount = accountList.find { it.id == accId }
        val initialCash = currentAccount?.cashBalance ?: BigDecimal("10000.00")
        val baseCurrency = currentAccount?.currency ?: "USD"
        val instrumentsMap = instruments.associateBy { it.symbol.uppercase() }

        calculator.calculateHoldingsAndSummary(
            transactions = txs,
            instrumentsMap = instrumentsMap,
            initialCash = initialCash,
            baseCurrency = baseCurrency,
            method = method
        )
    }.stateIn(
        scope = scope,
        started = SharingStarted.Eagerly,
        initialValue = Pair(emptyList(), PortfolioSummary())
    )

    init {
        scope.launch {
            seedDefaultDataIfEmpty()
        }
    }

    private suspend fun seedDefaultDataIfEmpty() {
        val existingWatchlists = dao.getAllWatchlists().first()
        if (existingWatchlists.isEmpty()) {
            dao.insertWatchlist(
                WatchlistEntity(
                    name = "Core Tech",
                    symbolsCsv = "AAPL,NVDA,MSFT",
                    isDefault = true
                )
            )
            dao.insertWatchlist(
                WatchlistEntity(
                    name = "Global & Dividend",
                    symbolsCsv = "AZN,MC,7203,SPY",
                    isDefault = false
                )
            )
            dao.insertWatchlist(
                WatchlistEntity(
                    name = "Biotech & ETFs",
                    symbolsCsv = "BIOX,QQQ,SPX.INDEX",
                    isDefault = false
                )
            )
        }

        val existingAccounts = dao.getAllAccounts().first()
        if (existingAccounts.isEmpty()) {
            val mainAccId = dao.insertAccount(
                AccountEntity(
                    name = "Taxable Brokerage",
                    cashBalance = 15000.00,
                    currency = "USD",
                    isDefault = true
                )
            )
            dao.insertAccount(
                AccountEntity(
                    name = "Retirement Roth IRA",
                    cashBalance = 25000.00,
                    currency = "USD",
                    isDefault = false
                )
            )

            // Seed realistic sample transactions
            val now = System.currentTimeMillis()
            val day = 86400000L
            dao.insertTransactions(
                listOf(
                    TransactionEntity(
                        accountId = mainAccId,
                        symbol = "AAPL",
                        type = "BUY",
                        quantity = 15.0,
                        pricePerShare = 212.50,
                        fee = 4.95,
                        currency = "USD",
                        timestamp = now - 45 * day,
                        notes = "Initial tech core accumulation"
                    ),
                    TransactionEntity(
                        accountId = mainAccId,
                        symbol = "NVDA",
                        type = "BUY",
                        quantity = 25.0,
                        pricePerShare = 118.00,
                        fee = 4.95,
                        currency = "USD",
                        timestamp = now - 30 * day,
                        notes = "GPU data center expansion position"
                    ),
                    TransactionEntity(
                        accountId = mainAccId,
                        symbol = "NVDA",
                        type = "SELL",
                        quantity = 5.0,
                        pricePerShare = 144.50,
                        fee = 4.95,
                        currency = "USD",
                        timestamp = now - 5 * day,
                        notes = "Partial profit taking"
                    ),
                    TransactionEntity(
                        accountId = mainAccId,
                        symbol = "AZN",
                        type = "BUY",
                        quantity = 20.0,
                        pricePerShare = 112.40,
                        fee = 5.00,
                        currency = "GBP", // multi-currency transaction!
                        timestamp = now - 20 * day,
                        notes = "London pharmaceutical exposure"
                    ),
                    TransactionEntity(
                        accountId = mainAccId,
                        symbol = "AAPL",
                        type = "DIVIDEND",
                        quantity = 0.0,
                        pricePerShare = 3.75,
                        fee = 0.0,
                        currency = "USD",
                        timestamp = now - 10 * day,
                        notes = "Q3 cash dividend payout"
                    )
                )
            )

            // Seed sample alert
            dao.insertAlert(
                PriceAlertEntity(
                    symbol = "AAPL",
                    targetPrice = 230.00,
                    isAbove = true,
                    isActive = true,
                    createdAt = now - 2 * day,
                    note = "Breakout resistance level"
                )
            )
            dao.insertAlert(
                PriceAlertEntity(
                    symbol = "NVDA",
                    targetPrice = 135.00,
                    isAbove = false,
                    isActive = true,
                    createdAt = now - 1 * day,
                    note = "Dip buy consideration"
                )
            )
        }
    }

    suspend fun addWatchlist(name: String, symbols: List<String>) {
        dao.insertWatchlist(
            WatchlistEntity(
                name = name,
                symbolsCsv = symbols.joinToString(","),
                isDefault = false
            )
        )
    }

    suspend fun updateWatchlistSymbols(watchlistId: Long, name: String, symbols: List<String>) {
        dao.updateWatchlist(
            WatchlistEntity(
                id = watchlistId,
                name = name,
                symbolsCsv = symbols.joinToString(","),
                isDefault = false
            )
        )
    }

    suspend fun deleteWatchlist(watchlistId: Long) {
        dao.deleteWatchlist(watchlistId)
    }

    suspend fun toggleSymbolInWatchlist(watchlistId: Long, symbol: String) {
        val allWl = dao.getAllWatchlists().first()
        val target = allWl.find { it.id == watchlistId } ?: allWl.firstOrNull() ?: return
        val currentList = target.symbolsCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
        if (currentList.contains(symbol)) {
            currentList.remove(symbol)
        } else {
            currentList.add(symbol)
        }
        dao.updateWatchlist(target.copy(symbolsCsv = currentList.joinToString(",")))
    }

    suspend fun addTransaction(tx: TransactionRecord) {
        dao.insertTransaction(
            TransactionEntity(
                accountId = tx.accountId,
                symbol = tx.symbol.uppercase(),
                type = tx.type.name,
                quantity = tx.quantity.toDouble(),
                pricePerShare = tx.pricePerShare.toDouble(),
                fee = tx.fee.toDouble(),
                currency = tx.currency,
                timestamp = tx.timestamp,
                notes = tx.notes
            )
        )
    }

    suspend fun deleteTransaction(id: Long) {
        dao.deleteTransaction(id)
    }

    suspend fun addPriceAlert(symbol: String, targetPrice: Double, isAbove: Boolean, note: String) {
        dao.insertAlert(
            PriceAlertEntity(
                symbol = symbol.uppercase(),
                targetPrice = targetPrice,
                isAbove = isAbove,
                isActive = true,
                createdAt = System.currentTimeMillis(),
                note = note
            )
        )
    }

    suspend fun deletePriceAlert(id: Long) {
        dao.deleteAlert(id)
    }

    suspend fun updateCashBalance(accountId: Long, newBalance: Double) {
        val accounts = dao.getAllAccounts().first()
        val acc = accounts.find { it.id == accountId } ?: return
        dao.updateAccount(acc.copy(cashBalance = newBalance))
    }

    suspend fun importTransactions(transactions: List<TransactionRecord>) {
        val entities = transactions.map { tx ->
            TransactionEntity(
                accountId = tx.accountId,
                symbol = tx.symbol.uppercase(),
                type = tx.type.name,
                quantity = tx.quantity.toDouble(),
                pricePerShare = tx.pricePerShare.toDouble(),
                fee = tx.fee.toDouble(),
                currency = tx.currency,
                timestamp = tx.timestamp,
                notes = tx.notes
            )
        }
        dao.insertTransactions(entities)
    }
}
