package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChartRange
import com.example.model.Instrument
import com.example.model.MarketNews
import com.example.ui.AppTab
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.components.InteractiveStockChart
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.SparklineChart
import com.example.ui.theme.AiGlowCyan
import com.example.ui.theme.AiGlowViolet
import com.example.ui.theme.AppleBlue
import com.example.ui.theme.StocksTheme
import com.example.ui.theme.TabularNumberStyle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val instruments by viewModel.instruments.collectAsState()
    val benchmarkSymbol by viewModel.selectedBenchmarkSymbol.collectAsState()
    val (holdings, summary) = viewModel.portfolioState.collectAsState().value
    val watchlists by viewModel.watchlists.collectAsState()

    var heroChartRange by remember { mutableStateOf(ChartRange.DAY) }
    var selectedNewsArticle by remember { mutableStateOf<MarketNews?>(null) }
    var moverFilter by remember { mutableStateOf("GAINERS") } // GAINERS, LOSERS, ACTIVE

    val benchmarkInstrument = instruments.find { it.symbol == benchmarkSymbol } ?: instruments.first()
    val heroPoints = remember(benchmarkSymbol, heroChartRange, instruments) {
        viewModel.marketRepo.getHistoricalSeries(benchmarkSymbol, heroChartRange, true)
    }

    val indices = instruments.filter { it.exchange == "INDEX" || it.symbol in listOf("^GSPC", "^IXIC", "^DJI", "^FTSE") }
    val equities = instruments.filter { it.assetType.name == "EQUITY" }

    val gainers = equities.sortedByDescending { it.changePercent }.take(4)
    val losers = equities.sortedBy { it.changePercent }.take(4)
    val mostActive = equities.sortedByDescending { it.volume }.take(4)

    val currentMovers = when (moverFilter) {
        "LOSERS" -> losers
        "ACTIVE" -> mostActive
        else -> gainers
    }

    val todayDateStr = remember {
        SimpleDateFormat("EEEE, MMMM d", Locale.US).format(Date())
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("today_screen_scroll"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Top Apple-style editorial header with brand mark
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = todayDateStr.uppercase(Locale.US),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StocksTheme.colors.textMuted,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Today",
                                style = MaterialTheme.typography.displayLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StocksTheme.colors.textPrimary
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            // Minimal brand mark: stylized 'i' with upward curve
                            Surface(
                                shape = CircleShape,
                                color = StocksTheme.colors.surfaceElevated,
                                border = androidx.compose.foundation.BorderStroke(1.dp, StocksTheme.colors.border),
                                modifier = Modifier.size(28.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.TrendingUp,
                                        contentDescription = "iStocks brand",
                                        tint = StocksTheme.colors.gain,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    // AI Research Button (Iridescent gradient pill)
                    Surface(
                        onClick = { viewModel.openAiAssistant(benchmarkInstrument.symbol) },
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Transparent,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            Brush.horizontalGradient(listOf(AiGlowCyan, AiGlowViolet))
                        ),
                        modifier = Modifier.testTag("today_ai_assistant_btn")
                    ) {
                        Row(
                            modifier = Modifier
                                .background(StocksTheme.colors.surfaceElevated.copy(alpha = 0.8f))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Assistant",
                                tint = AiGlowCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Research",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = StocksTheme.colors.textPrimary
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Market Session status bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StocksTheme.colors.surfaceElevated, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(StocksTheme.colors.gain, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "US Markets Open • Closes 16:00 EST",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = StocksTheme.colors.textPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                    Text(
                        text = "NYSE / NASDAQ",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.textMuted
                        )
                    )
                }
            }
        }

        // Major Indices Horizontal Carousel
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "MAJOR INDICES",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = StocksTheme.colors.textMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    indices.forEach { index ->
                        val isSelected = index.symbol == benchmarkSymbol
                        Surface(
                            onClick = { viewModel.selectedBenchmarkSymbol.value = index.symbol },
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) StocksTheme.colors.surfaceHighlight else StocksTheme.colors.surfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) AppleBlue else StocksTheme.colors.border
                            ),
                            modifier = Modifier
                                .width(155.dp)
                                .height(95.dp)
                                .testTag("index_card_${index.symbol}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = index.name.take(12),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = StocksTheme.colors.textPrimary
                                        ),
                                        maxLines = 1
                                    )
                                    SparklineChart(
                                        points = index.sparklinePoints,
                                        isGain = index.isGain,
                                        width = 38.dp,
                                        height = 18.dp
                                    )
                                }

                                Column {
                                    Text(
                                        text = String.format(Locale.US, "%,.2f", index.currentPrice),
                                        style = TabularNumberStyle.copy(
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    val sign = if (index.changePercent >= 0) "+" else ""
                                    Text(
                                        text = String.format(Locale.US, "%s%.2f%%", sign, index.changePercent),
                                        style = TabularNumberStyle.copy(
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (index.changePercent >= 0) StocksTheme.colors.gain else StocksTheme.colors.loss
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Prominent Interactive Benchmark Hero Chart
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("today_hero_chart_card")
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${benchmarkInstrument.name} (${benchmarkInstrument.symbol})",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StocksTheme.colors.textPrimary
                                )
                            )
                            Text(
                                text = "Benchmark Performance",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = StocksTheme.colors.textMuted
                                )
                            )
                        }

                        ProvenanceBadge(
                            currency = benchmarkInstrument.currency,
                            exchange = benchmarkInstrument.exchange,
                            dataSource = benchmarkInstrument.dataSource,
                            quoteFreshness = benchmarkInstrument.quoteFreshness,
                            timestamp = benchmarkInstrument.quoteTimestamp,
                            isMarketOpen = benchmarkInstrument.isMarketOpen
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    InteractiveStockChart(
                        points = heroPoints,
                        selectedRange = heroChartRange,
                        onRangeSelected = { heroChartRange = it },
                        currencySymbol = if (benchmarkInstrument.currency == "GBP") "£" else "$"
                    )
                }
            }
        }

        // Portfolio Daily Movement Preview Widget
        item {
            GlassCard(
                onClick = { viewModel.selectTab(AppTab.PORTFOLIO) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("today_portfolio_preview_card")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PORTFOLIO TODAY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = StocksTheme.colors.textMuted,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format(Locale.US, "$%,.2f", summary.totalEquity.toDouble()),
                            style = TabularNumberStyle.copy(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = StocksTheme.colors.textPrimary
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val sign = if (summary.dailyGain.toDouble() >= 0) "+" else ""
                            Text(
                                text = String.format(Locale.US, "%s$%,.2f (%s%.2f%%) Today", sign, summary.dailyGain.toDouble(), sign, summary.dailyGainPercent.toDouble()),
                                style = TabularNumberStyle.copy(
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (summary.dailyGain.toDouble() >= 0) StocksTheme.colors.gain else StocksTheme.colors.loss
                                )
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = { viewModel.selectTab(AppTab.PORTFOLIO) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = StocksTheme.colors.surfaceHighlight
                        )
                    ) {
                        Text(
                            text = "View Portfolio",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = AppleBlue,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }
            }
        }

        // Watchlist Highlights
        item {
            val firstWl = watchlists.firstOrNull()
            val highlightSymbols = firstWl?.symbols?.take(3) ?: listOf("AAPL", "NVDA", "MSFT")
            val highlightInstruments = highlightSymbols.mapNotNull { viewModel.marketRepo.getInstrumentBySymbol(it) }

            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "WATCHLIST HIGHLIGHTS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.textMuted,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "See All",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = AppleBlue,
                            fontWeight = FontWeight.SemiBold
                        ),
                        modifier = Modifier.clickable { viewModel.selectTab(AppTab.WATCHLIST) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                GlassCard {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        highlightInstruments.forEachIndexed { idx, inst ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.openCompanyDetail(inst.symbol) }
                                    .testTag("watchlist_highlight_${inst.symbol}"),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.2f)) {
                                    Text(
                                        text = inst.symbol,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    Text(
                                        text = inst.name,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = StocksTheme.colors.textSecondary
                                        ),
                                        maxLines = 1
                                    )
                                }

                                SparklineChart(
                                    points = inst.sparklinePoints,
                                    isGain = inst.isGain,
                                    modifier = Modifier.weight(1f)
                                )

                                Column(
                                    horizontalAlignment = Alignment.End,
                                    modifier = Modifier.weight(1.2f)
                                ) {
                                    val currSymbol = if (inst.currency == "GBP") "£" else if (inst.currency == "EUR") "€" else "$"
                                    Text(
                                        text = String.format(Locale.US, "%s%.2f", currSymbol, inst.currentPrice),
                                        style = TabularNumberStyle.copy(
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    val sign = if (inst.changePercent >= 0) "+" else ""
                                    Text(
                                        text = String.format(Locale.US, "%s%.2f%%", sign, inst.changePercent),
                                        style = TabularNumberStyle.copy(
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (inst.isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                                        )
                                    )
                                }
                            }

                            if (idx < highlightInstruments.size - 1) {
                                HorizontalDivider(
                                    color = StocksTheme.colors.border,
                                    thickness = 0.5.dp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Market Movers Segmented
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "MARKET MOVERS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = StocksTheme.colors.textMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Segmented Pills: Gainers, Losers, Most Active
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StocksTheme.colors.surfaceElevated, RoundedCornerShape(10.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf("GAINERS" to "Gainers", "LOSERS" to "Losers", "ACTIVE" to "Most Active").forEach { (key, label) ->
                        val isSel = moverFilter == key
                        Surface(
                            onClick = { moverFilter = key },
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) StocksTheme.colors.surfaceHighlight else Color.Transparent
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSel) StocksTheme.colors.textPrimary else StocksTheme.colors.textSecondary
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                GlassCard {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        currentMovers.forEachIndexed { i, inst ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.openCompanyDetail(inst.symbol) }
                                    .testTag("mover_item_${inst.symbol}"),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1.5f)) {
                                    Text(
                                        text = inst.symbol,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    Text(
                                        text = "${inst.exchange} • ${inst.name}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = StocksTheme.colors.textMuted
                                        ),
                                        maxLines = 1
                                    )
                                }

                                SparklineChart(
                                    points = inst.sparklinePoints,
                                    isGain = inst.isGain,
                                    modifier = Modifier.weight(1f)
                                )

                                Column(
                                    horizontalAlignment = Alignment.End,
                                    modifier = Modifier.weight(1.2f)
                                ) {
                                    Text(
                                        text = String.format(Locale.US, "$%.2f", inst.currentPrice),
                                        style = TabularNumberStyle.copy(
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = StocksTheme.colors.textPrimary
                                        )
                                    )
                                    val sign = if (inst.changePercent >= 0) "+" else ""
                                    Text(
                                        text = String.format(Locale.US, "%s%.2f%%", sign, inst.changePercent),
                                        style = TabularNumberStyle.copy(
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (inst.isGain) StocksTheme.colors.gain else StocksTheme.colors.loss
                                        )
                                    )
                                }
                            }

                            if (i < currentMovers.size - 1) {
                                HorizontalDivider(color = StocksTheme.colors.border, thickness = 0.5.dp)
                            }
                        }
                    }
                }
            }
        }

        // Market News & Source-Linked Editorial Briefing
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "MARKET BRIEFING & NEWS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = StocksTheme.colors.textMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    ),
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                viewModel.marketRepo.marketNews.forEach { news ->
                    GlassCard(
                        onClick = { selectedNewsArticle = news },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .testTag("news_card_${news.id}")
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${news.source} • ${news.timeAgo}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = AppleBlue,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = StocksTheme.colors.surfaceHighlight
                                ) {
                                    Text(
                                        text = news.category,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 10.sp,
                                            color = StocksTheme.colors.textSecondary
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = news.title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = StocksTheme.colors.textPrimary,
                                    lineHeight = 20.sp
                                )
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = news.summary,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = StocksTheme.colors.textSecondary,
                                    lineHeight = 17.sp
                                ),
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }

        // Provenance & Transparency Disclosure Footer
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Data Transparency & Provenance",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = StocksTheme.colors.textMuted
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Quotes delayed 15 minutes or generated via deterministic simulation engine for demonstration. Financial metrics comply with GAAP reporting. Not investment advice.",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = StocksTheme.colors.textMuted,
                        lineHeight = 14.sp
                    ),
                    modifier = Modifier.padding(horizontal = 20.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }

    // Modal sheet for full news article reading
    selectedNewsArticle?.let { article ->
        ModalBottomSheet(
            onDismissRequest = { selectedNewsArticle = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = StocksTheme.colors.surfaceElevated
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${article.source} • ${article.timeAgo}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = AppleBlue,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = article.provenanceBadge,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = StocksTheme.colors.textMuted
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = article.title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = StocksTheme.colors.textPrimary
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = article.content,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = StocksTheme.colors.textSecondary,
                        lineHeight = 22.sp
                    )
                )

                Spacer(modifier = Modifier.height(24.dp))

                if (article.relatedSymbol.isNotEmpty()) {
                    FilledTonalButton(
                        onClick = {
                            selectedNewsArticle = null
                            viewModel.openCompanyDetail(article.relatedSymbol)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Research ${article.relatedSymbol} in Detail")
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
