package com.example

import com.example.accounting.CsvProcessor
import com.example.accounting.FxRates
import com.example.accounting.PortfolioCalculator
import com.example.data.MarketDataRepository
import com.example.model.AssetType
import com.example.model.CostBasisMethod
import com.example.model.Instrument
import com.example.model.TransactionRecord
import com.example.model.TransactionType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.math.RoundingMode

class IStocksCoreTests {

    private val calculator = PortfolioCalculator()

    // 1. Tests for Accounting & FIFO Cost-Basis
    @Test
    fun testFifoCostBasisAndRealizedGain() {
        val instrumentsMap = mapOf(
            "AAPL" to Instrument(
                id = "AAPL.NASDAQ",
                symbol = "AAPL",
                name = "Apple Inc.",
                exchange = "NASDAQ",
                currency = "USD",
                assetType = AssetType.EQUITY,
                currentPrice = 200.00,
                previousClose = 195.00
            )
        )

        // Buy 10 @ $100 (Lot 1)
        // Buy 10 @ $150 (Lot 2)
        // Sell 12 @ $180
        // FIFO should consume 10 @ $100 and 2 @ $150 = Cost basis $1000 + $300 = $1300
        // Gross proceeds = 12 * $180 = $2160. Realized gain = $2160 - $1300 = $860
        // Remaining lot: 8 @ $150 = Cost basis $1200. Current value @ $200 = $1600. Unrealized gain = $400.
        val transactions = listOf(
            TransactionRecord(
                id = 1L,
                accountId = 1L,
                symbol = "AAPL",
                type = TransactionType.BUY,
                quantity = BigDecimal("10.0"),
                pricePerShare = BigDecimal("100.00"),
                fee = BigDecimal.ZERO,
                timestamp = 1000L
            ),
            TransactionRecord(
                id = 2L,
                accountId = 1L,
                symbol = "AAPL",
                type = TransactionType.BUY,
                quantity = BigDecimal("10.0"),
                pricePerShare = BigDecimal("150.00"),
                fee = BigDecimal.ZERO,
                timestamp = 2000L
            ),
            TransactionRecord(
                id = 3L,
                accountId = 1L,
                symbol = "AAPL",
                type = TransactionType.SELL,
                quantity = BigDecimal("12.0"),
                pricePerShare = BigDecimal("180.00"),
                fee = BigDecimal.ZERO,
                timestamp = 3000L
            )
        )

        val (holdings, summary) = calculator.calculateHoldingsAndSummary(
            transactions = transactions,
            instrumentsMap = instrumentsMap,
            initialCash = BigDecimal("5000.00"),
            baseCurrency = "USD",
            method = CostBasisMethod.FIFO
        )

        assertEquals(1, holdings.size)
        val holding = holdings.first()
        assertEquals(BigDecimal("8.000"), holding.quantity)
        assertEquals(BigDecimal("150.00"), holding.averageCostBasis)
        assertEquals(BigDecimal("1200.00"), holding.totalCost)
        assertEquals(BigDecimal("1600.00"), holding.currentValue)
        assertEquals(BigDecimal("400.00"), holding.unrealizedGain)
        assertEquals(BigDecimal("860.00"), holding.realizedGain)
    }

    // 2. Tests for Multi-Currency Conversion
    @Test
    fun testCurrencyConversion() {
        val amountInGbp = BigDecimal("100.00")
        val inUsd = FxRates.convert(amountInGbp, "GBP", "USD")
        // GBP rate is 1.2820 -> 100 GBP = 128.2000 USD
        assertEquals(BigDecimal("128.2000"), inUsd)

        val amountInEur = BigDecimal("200.00")
        val eurInUsd = FxRates.convert(amountInEur, "EUR", "USD")
        // EUR rate is 1.0850 -> 200 EUR = 217.0000 USD
        assertEquals(BigDecimal("217.0000"), eurInUsd)

        // Same currency returns unchanged
        val usdInUsd = FxRates.convert(BigDecimal("50.00"), "USD", "USD")
        assertEquals(BigDecimal("50.00"), usdInUsd)
    }

    // 3. Tests for Quote Freshness & Data Provenance
    @Test
    fun testQuoteProvenanceAndMissingFundamentals() {
        val repo = MarketDataRepository()
        val biox = repo.getInstrumentBySymbol("BIOX")
        assertNotNull(biox)
        // Verify missing fundamentals are properly null (not fabricated)
        assertNull(biox?.peRatio)
        assertNull(biox?.dividendYield)
        assertEquals("Simulated Demo", biox?.quoteFreshness)

        val azn = repo.getInstrumentBySymbol("AZN")
        assertNotNull(azn)
        assertEquals("GBP", azn?.currency)
        assertEquals("LSE", azn?.exchange)
        // Closed market demonstration
        assertEquals(false, azn?.isMarketOpen)
    }

    // 4. Tests for CSV Import & Export with Duplicate Detection
    @Test
    fun testCsvProcessingAndDuplicateDetection() {
        val originalTransactions = listOf(
            TransactionRecord(
                id = 1L,
                accountId = 1L,
                symbol = "AAPL",
                type = TransactionType.BUY,
                quantity = BigDecimal("10.000"),
                pricePerShare = BigDecimal("210.00"),
                fee = BigDecimal("1.99"),
                currency = "USD",
                timestamp = 1700000000000L,
                notes = "Core holding"
            )
        )

        val csvString = CsvProcessor.exportToCsv(originalTransactions)
        assertTrue(csvString.contains("AAPL"))
        assertTrue(csvString.contains("BUY"))
        assertTrue(csvString.contains("210.00"))

        // Parsing the exact same transaction should flag duplicate
        val parseResult = CsvProcessor.parseAndValidateCsv(
            csvContent = csvString,
            existingTransactions = originalTransactions,
            targetAccountId = 1L
        )

        assertEquals(1, parseResult.duplicates.size)
        assertEquals(0, parseResult.validTransactions.size)
        assertEquals(0, parseResult.errors.size)

        // Parsing a new transaction should succeed
        val newCsv = """
            Date,Type,Symbol,Quantity,Price,Fee,Currency,Notes
            2026-11-01 10:00,BUY,NVDA,15.5,140.00,0.00,USD,New allocation
        """.trimIndent()

        val parseResult2 = CsvProcessor.parseAndValidateCsv(
            csvContent = newCsv,
            existingTransactions = originalTransactions,
            targetAccountId = 1L
        )

        assertEquals(1, parseResult2.validTransactions.size)
        val validTx = parseResult2.validTransactions.first()
        assertEquals("NVDA", validTx.symbol)
        assertEquals(BigDecimal("15.5"), validTx.quantity)
        assertEquals(BigDecimal("140.00"), validTx.pricePerShare)
        assertEquals(0, parseResult2.errors.size)
    }
}
