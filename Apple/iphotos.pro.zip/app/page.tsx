'use client';

import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  INITIAL_ASSETS,
  INITIAL_ALBUMS,
  INITIAL_JOBS,
  INITIAL_LIBRARY_STATS,
  INITIAL_DOCTOR_REPORT,
  INITIAL_DUPLICATE_GROUPS,
} from '@/lib/store';
import {
  PhotoAsset,
  Album,
  Job,
  LibraryStats,
  LibraryDoctorReport,
  DuplicateGroup,
  SidebarSectionId,
  EditState,
} from '@/lib/types';
import {
  Image as ImageIcon,
  Star,
  Clock,
  Video,
  Layers,
  Sparkles,
  Search,
  Sliders,
  Maximize2,
  Minimize2,
  Trash2,
  Folder,
  FolderPlus,
  Info,
  Activity,
  HardDrive,
  ShieldCheck,
  RotateCw,
  Crop,
  Sun,
  Contrast,
  Palette,
  Check,
  X,
  Play,
  Pause,
  RefreshCw,
  Plus,
  Download,
  Upload,
  Cpu,
  Terminal,
  Grid,
  MapPin,
  Camera,
  Eye,
  EyeOff,
  ChevronRight,
  ChevronDown,
  FileText,
  AlertTriangle,
  HelpCircle,
  Copy,
  Zap,
} from 'lucide-react';

export default function IPhotosProApp() {
  // --- Core State ---
  const [assets, setAssets] = useState<PhotoAsset[]>(INITIAL_ASSETS);
  const [albums, setAlbums] = useState<Album[]>(INITIAL_ALBUMS);
  const [jobs, setJobs] = useState<Job[]>(INITIAL_JOBS);
  const [stats, setStats] = useState<LibraryStats>(INITIAL_LIBRARY_STATS);
  const [doctorReport, setDoctorReport] = useState<LibraryDoctorReport>(INITIAL_DOCTOR_REPORT);
  const [duplicateGroups, setDuplicateGroups] = useState<DuplicateGroup[]>(INITIAL_DUPLICATE_GROUPS);

  // --- Navigation & View State ---
  const [activeSection, setActiveSection] = useState<SidebarSectionId>('photos');
  const [selectedAlbumId, setSelectedAlbumId] = useState<string | null>(null);
  const [selectedAssetIds, setSelectedAssetIds] = useState<Set<string>>(new Set(['asset-001']));
  const [viewingAssetId, setViewingAssetId] = useState<string | null>(null);
  const [inspectorOpen, setInspectorOpen] = useState<boolean>(true);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showImportModal, setShowImportModal] = useState<boolean>(false);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [showSmartAlbumModal, setShowSmartAlbumModal] = useState<boolean>(false);

  // --- Grid & Zoom Settings ---
  const [gridColumns, setGridColumns] = useState<number>(4);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTagsFilter, setSelectedTagsFilter] = useState<string[]>([]);
  const [cameraFilter, setCameraFilter] = useState<string>('ALL');
  const [ratingFilter, setRatingFilter] = useState<number>(0);
  const [rawOnlyFilter, setRawOnlyFilter] = useState<boolean>(false);

  // --- Active Edit State for Single Photo / Viewer ---
  const [activeEditState, setActiveEditState] = useState<EditState>({
    exposure: 0,
    brightness: 0,
    contrast: 0,
    saturation: 0,
    temperature: 0,
    tint: 0,
    highlights: 0,
    shadows: 0,
    clarity: 0,
    vignette: 0,
    rotation: 0,
    crop_aspect: 'original',
  });
  const [isEditingMode, setIsEditingMode] = useState<boolean>(false);
  const [viewerZoom, setViewerZoom] = useState<number>(1);
  const [viewerFit, setViewerFit] = useState<'fit' | 'fill' | 'actual'>('fit');
  const [liveRustLatencyMs, setLiveRustLatencyMs] = useState<number>(1.84);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Toast helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Currently focused asset for Inspector / Viewer
  const activeAsset = useMemo(() => {
    if (viewingAssetId) {
      return assets.find((a) => a.id === viewingAssetId) || null;
    }
    const firstSelectedId = Array.from(selectedAssetIds)[0];
    return assets.find((a) => a.id === firstSelectedId) || assets[0] || null;
  }, [viewingAssetId, selectedAssetIds, assets]);

  // --- Filtered Asset Set ---
  const displayedAssets = useMemo(() => {
    return assets.filter((asset) => {
      // Section constraints
      if (activeSection === 'favorites' && !asset.favorite) return false;
      if (activeSection === 'videos' && !asset.is_video) return false;
      if (activeSection === 'raw' && !asset.is_raw) return false;
      if (activeSection === 'hidden' && !asset.hidden) return false;
      if (activeSection !== 'hidden' && asset.hidden) return false;
      if (activeSection === 'album' && selectedAlbumId) {
        const album = albums.find((a) => a.id === selectedAlbumId);
        if (album?.is_smart && album.smart_rules) {
          // evaluate smart rule
          const matches = album.smart_rules.rules.every((rule) => {
            if (rule.field === 'rating') {
              if (rule.operator === 'gte') return asset.rating >= Number(rule.value);
            }
            if (rule.field === 'type' && rule.value === 'RAW') {
              return !!asset.is_raw;
            }
            if (rule.field === 'camera' && typeof rule.value === 'string') {
              return asset.metadata?.make.toLowerCase().includes(rule.value.toLowerCase());
            }
            if (rule.field === 'favorite') {
              return asset.favorite === true;
            }
            return true;
          });
          if (!matches) return false;
        } else {
          if (!asset.album_ids?.includes(selectedAlbumId)) return false;
        }
      }

      // Quick filter chips
      if (rawOnlyFilter && !asset.is_raw) return false;
      if (ratingFilter > 0 && asset.rating < ratingFilter) return false;
      if (cameraFilter !== 'ALL' && asset.metadata?.make !== cameraFilter) return false;
      if (selectedTagsFilter.length > 0) {
        const hasTag = selectedTagsFilter.some((t) => asset.tags?.includes(t));
        if (!hasTag) return false;
      }

      // Text Query Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = asset.metadata?.title?.toLowerCase().includes(q);
        const matchFile = asset.filename.toLowerCase().includes(q);
        const matchLoc = asset.metadata?.location_name?.toLowerCase().includes(q);
        const matchCamera = `${asset.metadata?.make} ${asset.metadata?.model}`.toLowerCase().includes(q);
        const matchTags = asset.tags?.some((t) => t.toLowerCase().includes(q));
        if (!matchTitle && !matchFile && !matchLoc && !matchCamera && !matchTags) {
          return false;
        }
      }

      return true;
    });
  }, [
    assets,
    activeSection,
    selectedAlbumId,
    albums,
    rawOnlyFilter,
    ratingFilter,
    cameraFilter,
    selectedTagsFilter,
    searchQuery,
  ]);

  // --- Keyboard Shortcuts Handling ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If typing in input, ignore
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        if (viewingAssetId) {
          setViewingAssetId(null);
        } else if (activeAsset) {
          setViewingAssetId(activeAsset.id);
        }
      } else if (e.key === 'Escape') {
        if (viewingAssetId) {
          setViewingAssetId(null);
          setIsEditingMode(false);
        }
      } else if (e.key.toLowerCase() === 'f' && activeAsset) {
        e.preventDefault();
        toggleFavorite(activeAsset.id);
      } else if (['1', '2', '3', '4', '5'].includes(e.key) && activeAsset) {
        e.preventDefault();
        setRating(activeAsset.id, parseInt(e.key, 10));
      } else if (e.key === '0' && activeAsset) {
        e.preventDefault();
        setRating(activeAsset.id, 0);
      } else if (e.key === 'ArrowRight' && displayedAssets.length > 0) {
        e.preventDefault();
        navigateNextPhoto();
      } else if (e.key === 'ArrowLeft' && displayedAssets.length > 0) {
        e.preventDefault();
        navigatePrevPhoto();
      } else if (e.key.toLowerCase() === 'i') {
        e.preventDefault();
        setInspectorOpen((prev) => !prev);
      } else if (e.key.toLowerCase() === 'e' && viewingAssetId) {
        e.preventDefault();
        setIsEditingMode((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeAsset, viewingAssetId, displayedAssets]);

  // --- Operations & Mutations ---
  const toggleFavorite = (assetId: string) => {
    setAssets((prev) =>
      prev.map((a) => (a.id === assetId ? { ...a, favorite: !a.favorite } : a))
    );
    showToast('Rust SQLite: Updated asset favorite flag in 0.42ms');
  };

  const setRating = (assetId: string, rating: number) => {
    setAssets((prev) =>
      prev.map((a) => (a.id === assetId ? { ...a, rating } : a))
    );
    showToast(`Rust SQLite: Rating updated to ${rating}★`);
  };

  const toggleHidden = (assetId: string) => {
    setAssets((prev) =>
      prev.map((a) => (a.id === assetId ? { ...a, hidden: !a.hidden } : a))
    );
    showToast('Asset visibility toggled in local index');
  };

  const navigateNextPhoto = () => {
    if (!activeAsset || displayedAssets.length === 0) return;
    const currentIndex = displayedAssets.findIndex((a) => a.id === activeAsset.id);
    const nextIndex = (currentIndex + 1) % displayedAssets.length;
    const nextAsset = displayedAssets[nextIndex];
    setSelectedAssetIds(new Set([nextAsset.id]));
    if (viewingAssetId) setViewingAssetId(nextAsset.id);
  };

  const navigatePrevPhoto = () => {
    if (!activeAsset || displayedAssets.length === 0) return;
    const currentIndex = displayedAssets.findIndex((a) => a.id === activeAsset.id);
    const prevIndex = (currentIndex - 1 + displayedAssets.length) % displayedAssets.length;
    const prevAsset = displayedAssets[prevIndex];
    setSelectedAssetIds(new Set([prevAsset.id]));
    if (viewingAssetId) setViewingAssetId(prevAsset.id);
  };

  const handleAssetClick = (assetId: string, e: React.MouseEvent) => {
    if (e.metaKey || e.ctrlKey) {
      const next = new Set(selectedAssetIds);
      if (next.has(assetId)) {
        next.delete(assetId);
      } else {
        next.add(assetId);
      }
      setSelectedAssetIds(next);
    } else if (e.shiftKey && activeAsset) {
      const currentIndex = displayedAssets.findIndex((a) => a.id === activeAsset.id);
      const clickedIndex = displayedAssets.findIndex((a) => a.id === assetId);
      const [start, end] = [Math.min(currentIndex, clickedIndex), Math.max(currentIndex, clickedIndex)];
      const rangeIds = displayedAssets.slice(start, end + 1).map((a) => a.id);
      setSelectedAssetIds(new Set(rangeIds));
    } else {
      setSelectedAssetIds(new Set([assetId]));
    }
  };

  // Simulate background worker progress
  useEffect(() => {
    const interval = setInterval(() => {
      setJobs((prevJobs) =>
        prevJobs.map((j) => {
          if (j.status === 'RUNNING' && j.progress < 1.0) {
            const nextProgress = Math.min(1.0, j.progress + 0.04);
            const nextProcessed = Math.min(j.total_items, Math.round(j.total_items * nextProgress));
            const nextStatus = nextProgress >= 1.0 ? 'COMPLETED' : 'RUNNING';
            return {
              ...j,
              progress: nextProgress,
              items_processed: nextProcessed,
              status: nextStatus,
              message: nextStatus === 'COMPLETED' ? 'Task finished with zero errors' : j.message,
            };
          }
          return j;
        })
      );
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  // Compute CSS filter for live non-destructive preview
  const liveFilterStyle = useMemo(() => {
    const exp = 1 + activeEditState.exposure * 0.25;
    const bri = 100 + activeEditState.brightness;
    const con = 100 + activeEditState.contrast;
    const sat = 100 + activeEditState.saturation;
    const hue = activeEditState.temperature * 0.4;
    return {
      filter: `brightness(${bri * exp}%) contrast(${con}%) saturate(${sat}%) hue-rotate(${hue}deg)`,
      transform: `rotate(${activeEditState.rotation}deg)`,
      transition: 'filter 0.08s ease-out, transform 0.2s ease-out',
    };
  }, [activeEditState]);

  return (
    <div
      id="iphotos-pro-root"
      className="flex flex-col h-screen w-screen bg-[#121212] text-[#E0E0E0] font-sans overflow-hidden select-none"
    >
      {/* ========================================================================= */}
      {/* 1. TOP macOS NATIVE APP HEADER & TOOLBAR */}
      {/* ========================================================================= */}
      <header
        id="app-header"
        className="flex items-center justify-between px-4 py-2 bg-[#1E1E1E] border-b border-[#333] shrink-0 h-12 z-20"
      >
        {/* macOS Traffic Lights + Branding */}
        <div className="flex items-center space-x-4">
          <div className="flex space-x-2 mr-2">
            <div className="w-3 h-3 rounded-full bg-[#FF5F56] border border-[#E0443E] hover:opacity-80 cursor-pointer shadow-xs" />
            <div className="w-3 h-3 rounded-full bg-[#FFBD2E] border border-[#DEA123] hover:opacity-80 cursor-pointer shadow-xs" />
            <div className="w-3 h-3 rounded-full bg-[#27C93F] border border-[#1AAB29] hover:opacity-80 cursor-pointer shadow-xs" />
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-sm font-semibold tracking-tight text-white font-mono flex items-center">
              <span className="text-[#007AFF] mr-1.5 font-bold">i</span>PHOTOS.PRO
            </span>
            <span className="text-[9px] text-[#007AFF] px-1.5 py-0.5 border border-[#007AFF]/40 bg-[#007AFF]/10 rounded font-mono font-medium">
              KOTLIN + RUST v1.0
            </span>
            <span className="text-[10px] text-[#27C93F] bg-[#27C93F]/10 px-1.5 py-0.5 rounded flex items-center font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-[#27C93F] mr-1 animate-pulse" />
              Metal / Apple Silicon
            </span>
          </div>
        </div>

        {/* Search Bar & Fast Filters */}
        <div className="flex items-center space-x-3">
          <div className="relative flex items-center">
            <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-[#888]" />
            <input
              id="library-search-input"
              type="text"
              placeholder="Search 148,221 photos (e.g. Sony, Norway, 2026, RAW)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#2A2A2A] text-xs pl-8 pr-7 py-1.5 rounded-md border border-[#3D3D3D] w-80 text-[#E0E0E0] placeholder-[#777] focus:outline-hidden focus:border-[#007AFF] transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 text-[#888] hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Filter Buttons */}
          <div className="flex items-center space-x-1 border-l border-[#333] pl-3">
            <button
              onClick={() => setRawOnlyFilter(!rawOnlyFilter)}
              className={`px-2 py-1 text-[10px] font-mono rounded border transition-colors cursor-pointer ${
                rawOnlyFilter
                  ? 'bg-orange-500/20 text-orange-400 border-orange-500/50'
                  : 'bg-[#2A2A2A] text-[#888] border-[#3D3D3D] hover:text-white'
              }`}
            >
              RAW
            </button>
            <button
              onClick={() => setRatingFilter(ratingFilter === 5 ? 0 : 5)}
              className={`px-2 py-1 text-[10px] font-mono rounded border flex items-center space-x-1 transition-colors cursor-pointer ${
                ratingFilter === 5
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/50'
                  : 'bg-[#2A2A2A] text-[#888] border-[#3D3D3D] hover:text-white'
              }`}
            >
              <Star className="w-2.5 h-2.5 fill-current" />
              <span>5★</span>
            </button>
          </div>
        </div>

        {/* Global Toolbar Controls */}
        <div className="flex items-center space-x-3 text-[#AAA]">
          {/* Grid Scale Controls */}
          <div className="flex items-center space-x-1.5 bg-[#252525] px-2 py-1 rounded border border-[#333]">
            <Grid className="w-3.5 h-3.5 text-[#888]" />
            <input
              type="range"
              min="2"
              max="6"
              value={gridColumns}
              onChange={(e) => setGridColumns(parseInt(e.target.value, 10))}
              className="w-16 h-1 bg-[#444] rounded-lg appearance-none cursor-pointer accent-[#007AFF]"
            />
            <span className="text-[10px] font-mono text-[#888] w-4 text-center">
              {gridColumns}
            </span>
          </div>

          <button
            onClick={() => setShowImportModal(true)}
            className="flex items-center space-x-1.5 bg-[#007AFF] hover:bg-[#0069D9] text-white text-xs px-2.5 py-1.5 rounded font-medium cursor-pointer transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import</span>
          </button>

          <button
            onClick={() => setShowExportModal(true)}
            className="p-1.5 hover:bg-[#2A2A2A] hover:text-white rounded cursor-pointer transition-colors"
            title="Export Assets"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={() => setInspectorOpen(!inspectorOpen)}
            className={`p-1.5 rounded cursor-pointer transition-colors ${
              inspectorOpen ? 'bg-[#007AFF]/20 text-[#007AFF]' : 'hover:bg-[#2A2A2A] hover:text-white'
            }`}
            title="Toggle Metadata Inspector (I)"
          >
            <Info className="w-4 h-4" />
          </button>

          <button
            onClick={() => setShowSettingsModal(true)}
            className="p-1.5 hover:bg-[#2A2A2A] hover:text-white rounded cursor-pointer transition-colors"
            title="Preferences (⌘,)"
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* 2. MAIN APPLICATION WORKSPACE (Sidebar + Center Content + Inspector) */}
      {/* ========================================================================= */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* --- LEFT SIDEBAR (Navigation & Subsystems) --- */}
        <aside
          id="library-sidebar"
          className="w-60 bg-[#1A1A1A] border-r border-[#333] flex flex-col justify-between shrink-0 overflow-y-auto"
        >
          <div className="p-3 space-y-5">
            {/* Library Section */}
            <div>
              <h3 className="text-[10px] uppercase tracking-widest text-[#666] font-bold mb-2 px-2">
                Library
              </h3>
              <nav className="space-y-0.5">
                <button
                  onClick={() => {
                    setActiveSection('photos');
                    setSelectedAlbumId(null);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'photos'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>All Photos</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#666]">148.2k</span>
                </button>

                <button
                  onClick={() => {
                    setActiveSection('favorites');
                    setSelectedAlbumId(null);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'favorites'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Star className="w-3.5 h-3.5 text-amber-400" />
                    <span>Favorites</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#666]">8,421</span>
                </button>

                <button
                  onClick={() => {
                    setActiveSection('raw');
                    setSelectedAlbumId(null);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'raw'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Layers className="w-3.5 h-3.5 text-orange-400" />
                    <span>RAW Masters</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#666]">24,812</span>
                </button>

                <button
                  onClick={() => {
                    setActiveSection('videos');
                    setSelectedAlbumId(null);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'videos'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Video className="w-3.5 h-3.5 text-blue-400" />
                    <span>Videos & Drone</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#666]">3,140</span>
                </button>

                <button
                  onClick={() => {
                    setActiveSection('hidden');
                    setSelectedAlbumId(null);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'hidden'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <EyeOff className="w-3.5 h-3.5 text-[#777]" />
                    <span>Hidden Vault</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#666]">14</span>
                </button>
              </nav>
            </div>

            {/* Albums & Smart Albums */}
            <div>
              <div className="flex items-center justify-between px-2 mb-2">
                <h3 className="text-[10px] uppercase tracking-widest text-[#666] font-bold">
                  Albums
                </h3>
                <button
                  onClick={() => setShowSmartAlbumModal(true)}
                  className="text-[#888] hover:text-[#007AFF] cursor-pointer"
                  title="Create Smart Album"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
              <nav className="space-y-0.5">
                {albums.map((album) => {
                  const isSelected = activeSection === 'album' && selectedAlbumId === album.id;
                  return (
                    <button
                      key={album.id}
                      onClick={() => {
                        setActiveSection('album');
                        setSelectedAlbumId(album.id);
                      }}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                        isSelected
                          ? 'bg-[#007AFF]/15 text-[#007AFF]'
                          : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5 truncate">
                        {album.is_smart ? (
                          <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                        ) : (
                          <Folder className="w-3.5 h-3.5 text-[#007AFF] shrink-0" />
                        )}
                        <span className="truncate">{album.name}</span>
                      </div>
                      <span className="text-[10px] font-mono text-[#666] ml-2">
                        {album.asset_count}
                      </span>
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Engine Tools & Utilities */}
            <div>
              <h3 className="text-[10px] uppercase tracking-widest text-[#666] font-bold mb-2 px-2">
                Systems & Analysis
              </h3>
              <nav className="space-y-0.5">
                <button
                  onClick={() => setActiveSection('duplicates')}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'duplicates'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Copy className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Duplicate Engine</span>
                  </div>
                  <span className="text-[9px] bg-cyan-950 text-cyan-400 border border-cyan-800 px-1 rounded">
                    pHash
                  </span>
                </button>

                <button
                  onClick={() => setActiveSection('stats')}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'stats'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Activity className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Statistics & Analytics</span>
                  </div>
                </button>

                <button
                  onClick={() => setActiveSection('storage')}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'storage'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <HardDrive className="w-3.5 h-3.5 text-amber-400" />
                    <span>Storage Manager</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#666]">2.81 TB</span>
                </button>

                <button
                  onClick={() => setActiveSection('doctor')}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'doctor'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-green-400" />
                    <span>Library Doctor</span>
                  </div>
                  <span className="text-[9px] text-[#27C93F]">Healthy</span>
                </button>

                <button
                  onClick={() => setActiveSection('jobs')}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                    activeSection === 'jobs'
                      ? 'bg-[#007AFF]/15 text-[#007AFF]'
                      : 'text-[#AAA] hover:bg-[#252525] hover:text-white'
                  }`}
                >
                  <div className="flex items-center space-x-2.5">
                    <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Background Workers</span>
                  </div>
                  <span className="text-[9px] bg-indigo-950 text-indigo-300 border border-indigo-800 px-1 rounded">
                    8 Rayon
                  </span>
                </button>
              </nav>
            </div>
          </div>

          {/* Engine Real-time Status Card in Sidebar Bottom */}
          <div className="p-3 border-t border-[#2A2A2A] bg-[#161616]">
            <div className="bg-[#202020] p-2.5 rounded-md border border-[#333] space-y-2">
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-[#888] flex items-center">
                  <Zap className="w-3 h-3 text-[#007AFF] mr-1" />
                  Rust Workers
                </span>
                <span className="text-[#27C93F] font-mono font-medium">8 Cores Active</span>
              </div>
              <div className="flex justify-between text-[10px]">
                <span className="text-[#888]">Job:</span>
                <span className="text-[#DDD] truncate font-mono text-[9px]">
                  {jobs.find((j) => j.status === 'RUNNING')?.job_type || 'IDLE'}
                </span>
              </div>
              <div className="w-full bg-[#111] h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-[#007AFF] h-full transition-all duration-300"
                  style={{
                    width: `${
                      (jobs.find((j) => j.status === 'RUNNING')?.progress || 1.0) * 100
                    }%`,
                  }}
                />
              </div>
            </div>
          </div>
        </aside>

        {/* --- CENTER WORKSPACE --- */}
        <main id="center-workspace" className="flex-1 flex flex-col bg-[#0D0D0D] overflow-hidden relative">
          {/* Active View Title & Filter Chips Bar */}
          <div className="flex items-center justify-between px-4 py-2 bg-[#171717] border-b border-[#2A2A2A] text-xs">
            <div className="flex items-center space-x-3">
              <h2 className="font-semibold text-white tracking-wide flex items-center capitalize">
                {activeSection === 'album' && selectedAlbumId
                  ? albums.find((a) => a.id === selectedAlbumId)?.name
                  : activeSection.replace('_', ' ')}
              </h2>
              <span className="text-[11px] text-[#888] font-mono">
                {displayedAssets.length} of {assets.length} items
              </span>
            </div>

            {/* Selection Status */}
            <div className="flex items-center space-x-3 text-[11px] text-[#888]">
              {selectedAssetIds.size > 0 && (
                <span className="text-[#007AFF] font-medium font-mono">
                  {selectedAssetIds.size} selected
                </span>
              )}
              <span className="text-[#444]">|</span>
              <span>Space: Quick Look</span>
              <span>1-5: Rate</span>
              <span>F: Fav</span>
            </div>
          </div>

          {/* VIEW SWITCHER */}
          {activeSection === 'stats' ? (
            <StatisticsDashboard stats={stats} />
          ) : activeSection === 'storage' ? (
            <StorageManagerDashboard stats={stats} />
          ) : activeSection === 'doctor' ? (
            <LibraryDoctorView
              report={doctorReport}
              onRunCheck={() => {
                showToast('Rust SQLite: PRAGMA integrity_check completed in 4.12ms');
              }}
            />
          ) : activeSection === 'duplicates' ? (
            <DuplicateReviewWorkbench
              groups={duplicateGroups}
              onResolve={(groupId, keeperId) => {
                setDuplicateGroups((prev) => prev.filter((g) => g.id !== groupId));
                showToast(`Resolved duplicate cluster ${groupId}. Master preserved.`);
              }}
            />
          ) : activeSection === 'jobs' ? (
            <JobMonitorView
              jobs={jobs}
              onCancelJob={(jobId) => {
                setJobs((prev) =>
                  prev.map((j) => (j.id === jobId ? { ...j, status: 'CANCELLED' } : j))
                );
                showToast(`Rust Worker: Job ${jobId} cancellation requested`);
              }}
            />
          ) : (
            /* Standard Virtualized Photo Grid */
            <div className="flex-1 overflow-y-auto p-2 scrollbar-thin">
              {displayedAssets.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center p-8 text-[#666]">
                  <ImageIcon className="w-12 h-12 mb-3 text-[#444]" />
                  <p className="text-sm font-medium text-[#AAA]">No photos match your filter</p>
                  <p className="text-xs mt-1">Try resetting search or adjusting rating filters</p>
                </div>
              ) : (
                <div
                  className="grid gap-2"
                  style={{
                    gridTemplateColumns: `repeat(${gridColumns}, minmax(0, 1fr))`,
                  }}
                >
                  {displayedAssets.map((asset) => {
                    const isSelected = selectedAssetIds.has(asset.id);
                    return (
                      <div
                        key={asset.id}
                        id={`photo-cell-${asset.id}`}
                        onClick={(e) => handleAssetClick(asset.id, e)}
                        onDoubleClick={() => setViewingAssetId(asset.id)}
                        className={`group relative aspect-4/3 rounded bg-[#1A1A1A] overflow-hidden border transition-all cursor-pointer ${
                          isSelected
                            ? 'border-[#007AFF] ring-2 ring-[#007AFF]/60 shadow-lg shadow-[#007AFF]/20'
                            : 'border-[#262626] hover:border-[#444]'
                        }`}
                      >
                        {/* Thumbnail Image */}
                        <img
                          src={asset.thumbnail_url}
                          alt={asset.filename}
                          className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-200"
                          loading="lazy"
                        />

                        {/* Top Badges (RAW, 4K Video, Fav) */}
                        <div className="absolute top-1.5 left-1.5 right-1.5 flex items-center justify-between pointer-events-none">
                          <div className="flex items-center space-x-1">
                            {asset.is_raw && (
                              <span className="bg-black/80 backdrop-blur-xs text-[8px] font-mono px-1.5 py-0.5 rounded text-orange-400 font-bold border border-orange-500/30">
                                RAW
                              </span>
                            )}
                            {asset.is_video && (
                              <span className="bg-black/80 backdrop-blur-xs text-[8px] font-mono px-1.5 py-0.5 rounded text-blue-400 font-bold border border-blue-500/30 flex items-center">
                                <Play className="w-2 h-2 mr-0.5 fill-current" />
                                4K
                              </span>
                            )}
                          </div>

                          <div className="flex items-center space-x-1">
                            {asset.favorite && (
                              <span className="bg-black/80 p-1 rounded text-amber-400">
                                <Star className="w-2.5 h-2.5 fill-current" />
                              </span>
                            )}
                            {asset.rating > 0 && (
                              <span className="bg-black/80 text-[9px] font-mono px-1 rounded text-amber-400 font-bold">
                                {asset.rating}★
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Bottom Metadata Overlay on Hover */}
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-2 flex flex-col justify-end">
                          <span className="text-[10px] font-mono text-white truncate font-medium">
                            {asset.filename}
                          </span>
                          <span className="text-[9px] text-[#AAA] truncate">
                            {asset.metadata?.make} {asset.metadata?.model} • {asset.metadata?.lens}
                          </span>
                        </div>

                        {/* Selected Indicator Checkmark */}
                        {isSelected && (
                          <div className="absolute bottom-2 right-2 bg-[#007AFF] text-white p-0.5 rounded-full shadow-md">
                            <Check className="w-3 h-3" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ========================================================================= */}
          {/* IMMERSIVE PHOTO VIEWER / QUICK LOOK / EDITOR MODAL */}
          {/* ========================================================================= */}
          {viewingAssetId && activeAsset && (
            <div
              id="photo-viewer-modal"
              className="absolute inset-0 bg-[#0C0C0C]/98 z-30 flex flex-col animate-in fade-in duration-150 backdrop-blur-md"
            >
              {/* Viewer Top Bar */}
              <div className="h-11 px-4 bg-[#181818] border-b border-[#2A2A2A] flex items-center justify-between shrink-0">
                <div className="flex items-center space-x-3 truncate">
                  <button
                    onClick={() => {
                      setViewingAssetId(null);
                      setIsEditingMode(false);
                    }}
                    className="p-1 hover:bg-[#2A2A2A] rounded text-[#AAA] hover:text-white cursor-pointer"
                    title="Back to Grid (Esc)"
                  >
                    <X className="w-4 h-4" />
                  </button>
                  <span className="text-xs font-mono font-medium text-white truncate">
                    {activeAsset.filename}
                  </span>
                  <span className="text-[10px] text-[#888] font-mono">
                    ({activeAsset.width} × {activeAsset.height} • {(activeAsset.file_size / 1_000_000).toFixed(1)} MB)
                  </span>
                </div>

                {/* Viewer Navigation & Controls */}
                <div className="flex items-center space-x-2">
                  <button
                    onClick={navigatePrevPhoto}
                    className="px-2 py-1 bg-[#252525] hover:bg-[#333] text-xs rounded text-[#AAA] hover:text-white cursor-pointer"
                    title="Previous (←)"
                  >
                    Prev
                  </button>
                  <button
                    onClick={navigateNextPhoto}
                    className="px-2 py-1 bg-[#252525] hover:bg-[#333] text-xs rounded text-[#AAA] hover:text-white cursor-pointer"
                    title="Next (→)"
                  >
                    Next
                  </button>

                  <div className="h-4 w-px bg-[#333] mx-1" />

                  <button
                    onClick={() => toggleFavorite(activeAsset.id)}
                    className={`p-1.5 rounded cursor-pointer ${
                      activeAsset.favorite
                        ? 'text-amber-400 bg-amber-400/15'
                        : 'text-[#888] hover:bg-[#252525] hover:text-white'
                    }`}
                    title="Favorite (F)"
                  >
                    <Star className="w-4 h-4 fill-current" />
                  </button>

                  <button
                    onClick={() => setIsEditingMode(!isEditingMode)}
                    className={`flex items-center space-x-1 px-2.5 py-1 text-xs rounded font-medium cursor-pointer transition-colors ${
                      isEditingMode
                        ? 'bg-[#007AFF] text-white'
                        : 'bg-[#252525] text-[#AAA] hover:text-white'
                    }`}
                    title="Edit Photo (E)"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>{isEditingMode ? 'Done' : 'Edit'}</span>
                  </button>
                </div>
              </div>

              {/* Viewer Main Body (Canvas + Edit Drawer) */}
              <div className="flex-1 flex overflow-hidden relative">
                {/* Image Stage */}
                <div className="flex-1 flex items-center justify-center p-6 bg-[#080808] overflow-hidden relative">
                  <img
                    src={activeAsset.preview_url}
                    alt={activeAsset.filename}
                    style={liveFilterStyle}
                    className="max-h-full max-w-full object-contain rounded shadow-2xl transition-all select-none"
                  />

                  {/* Rust Render Engine Live Watermark */}
                  <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded border border-white/10 text-[10px] font-mono text-[#AAA] flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-[#27C93F] animate-pulse" />
                    <span>Rust Rayon Render: {liveRustLatencyMs}ms</span>
                    <span className="text-[#666]">|</span>
                    <span>16-bit float pipeline</span>
                  </div>
                </div>

                {/* Live Non-Destructive Edit Panel */}
                {isEditingMode && (
                  <div
                    id="edit-controls-sidebar"
                    className="w-80 bg-[#161616] border-l border-[#2E2E2E] p-4 flex flex-col justify-between overflow-y-auto"
                  >
                    <div className="space-y-5">
                      <div className="flex items-center justify-between border-b border-[#2E2E2E] pb-2">
                        <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
                          Non-Destructive Adjustments
                        </h3>
                        <button
                          onClick={() => {
                            setActiveEditState({
                              exposure: 0,
                              brightness: 0,
                              contrast: 0,
                              saturation: 0,
                              temperature: 0,
                              tint: 0,
                              highlights: 0,
                              shadows: 0,
                              clarity: 0,
                              vignette: 0,
                              rotation: 0,
                              crop_aspect: 'original',
                            });
                            showToast('Rust Core: Reset all edit instructions to original state');
                          }}
                          className="text-[10px] text-[#007AFF] hover:underline cursor-pointer"
                        >
                          Reset
                        </button>
                      </div>

                      {/* Sliders Group */}
                      <div className="space-y-4 text-xs">
                        {/* Exposure */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[11px]">
                            <span className="text-[#AAA] flex items-center">
                              <Sun className="w-3 h-3 mr-1 text-amber-400" /> Exposure
                            </span>
                            <span className="font-mono text-[#DDD]">
                              {activeEditState.exposure > 0 ? `+${activeEditState.exposure}` : activeEditState.exposure} EV
                            </span>
                          </div>
                          <input
                            type="range"
                            min="-2.0"
                            max="2.0"
                            step="0.05"
                            value={activeEditState.exposure}
                            onChange={(e) => {
                              setActiveEditState({
                                ...activeEditState,
                                exposure: parseFloat(e.target.value),
                              });
                              setLiveRustLatencyMs(parseFloat((Math.random() * 0.8 + 1.2).toFixed(2)));
                            }}
                            className="w-full h-1 bg-[#333] rounded appearance-none cursor-pointer accent-[#007AFF]"
                          />
                        </div>

                        {/* Contrast */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[11px]">
                            <span className="text-[#AAA] flex items-center">
                              <Contrast className="w-3 h-3 mr-1 text-blue-400" /> Contrast
                            </span>
                            <span className="font-mono text-[#DDD]">
                              {activeEditState.contrast > 0 ? `+${activeEditState.contrast}` : activeEditState.contrast}
                            </span>
                          </div>
                          <input
                            type="range"
                            min="-50"
                            max="50"
                            value={activeEditState.contrast}
                            onChange={(e) =>
                              setActiveEditState({
                                ...activeEditState,
                                contrast: parseInt(e.target.value, 10),
                              })
                            }
                            className="w-full h-1 bg-[#333] rounded appearance-none cursor-pointer accent-[#007AFF]"
                          />
                        </div>

                        {/* Saturation */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[11px]">
                            <span className="text-[#AAA] flex items-center">
                              <Palette className="w-3 h-3 mr-1 text-pink-400" /> Saturation
                            </span>
                            <span className="font-mono text-[#DDD]">
                              {activeEditState.saturation > 0 ? `+${activeEditState.saturation}` : activeEditState.saturation}
                            </span>
                          </div>
                          <input
                            type="range"
                            min="-60"
                            max="60"
                            value={activeEditState.saturation}
                            onChange={(e) =>
                              setActiveEditState({
                                ...activeEditState,
                                saturation: parseInt(e.target.value, 10),
                              })
                            }
                            className="w-full h-1 bg-[#333] rounded appearance-none cursor-pointer accent-[#007AFF]"
                          />
                        </div>

                        {/* Temperature (Kelvin shift) */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[11px]">
                            <span className="text-[#AAA]">Temperature (WB)</span>
                            <span className="font-mono text-[#DDD]">
                              {activeEditState.temperature > 0 ? `+${activeEditState.temperature}K` : `${activeEditState.temperature}K`}
                            </span>
                          </div>
                          <input
                            type="range"
                            min="-50"
                            max="50"
                            value={activeEditState.temperature}
                            onChange={(e) =>
                              setActiveEditState({
                                ...activeEditState,
                                temperature: parseInt(e.target.value, 10),
                              })
                            }
                            className="w-full h-1 bg-gradient-to-r from-blue-500 via-gray-400 to-amber-500 rounded appearance-none cursor-pointer accent-[#007AFF]"
                          />
                        </div>

                        {/* Orientation Tools */}
                        <div className="pt-2 border-t border-[#2E2E2E]">
                          <span className="text-[11px] text-[#888] block mb-2">Transform</span>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              onClick={() =>
                                setActiveEditState({
                                  ...activeEditState,
                                  rotation: (activeEditState.rotation + 90) % 360,
                                })
                              }
                              className="flex items-center justify-center space-x-1.5 py-1.5 bg-[#252525] hover:bg-[#333] text-xs rounded text-[#DDD] cursor-pointer"
                            >
                              <RotateCw className="w-3.5 h-3.5" />
                              <span>Rotate 90°</span>
                            </button>
                            <button
                              onClick={() => showToast('Crop aspect locked to 3:2 Full Frame')}
                              className="flex items-center justify-center space-x-1.5 py-1.5 bg-[#252525] hover:bg-[#333] text-xs rounded text-[#DDD] cursor-pointer"
                            >
                              <Crop className="w-3.5 h-3.5" />
                              <span>Crop 3:2</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Commit Edit Button */}
                    <div className="pt-4 border-t border-[#2E2E2E]">
                      <button
                        onClick={() => {
                          setIsEditingMode(false);
                          showToast('Rust Core: Non-destructive edit instruction committed to SQLite');
                        }}
                        className="w-full py-2 bg-[#007AFF] hover:bg-[#0069D9] text-white text-xs font-semibold rounded cursor-pointer transition-colors shadow-md"
                      >
                        Save Non-Destructive Version
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </main>

        {/* --- RIGHT SIDEBAR (Metadata Inspector) --- */}
        {inspectorOpen && activeAsset && (
          <aside
            id="metadata-inspector"
            className="w-72 bg-[#1A1A1A] border-l border-[#333] flex flex-col shrink-0 overflow-y-auto text-xs"
          >
            {/* Inspector Header */}
            <div className="p-3.5 border-b border-[#333] flex items-center justify-between">
              <div>
                <h3 className="text-xs font-semibold text-white">Metadata Inspector</h3>
                <p className="text-[10px] text-[#666] font-mono truncate">
                  SHA-256: {activeAsset.sha256.substring(0, 16)}...
                </p>
              </div>
              <button
                onClick={() => setInspectorOpen(false)}
                className="text-[#888] hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Quick Star Rating & Fav Controls */}
            <div className="p-3 bg-[#161616] border-b border-[#2A2A2A] flex items-center justify-between">
              <div className="flex items-center space-x-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setRating(activeAsset.id, star)}
                    className="p-1 text-[#444] hover:text-amber-400 cursor-pointer transition-colors"
                  >
                    <Star
                      className={`w-3.5 h-3.5 ${
                        activeAsset.rating >= star
                          ? 'text-amber-400 fill-current'
                          : 'text-[#444]'
                      }`}
                    />
                  </button>
                ))}
              </div>

              <button
                onClick={() => toggleFavorite(activeAsset.id)}
                className={`flex items-center space-x-1 px-2 py-1 rounded text-[11px] cursor-pointer ${
                  activeAsset.favorite
                    ? 'bg-amber-400/20 text-amber-400'
                    : 'bg-[#252525] text-[#888] hover:text-white'
                }`}
              >
                <Star className="w-3 h-3 fill-current" />
                <span>Fav</span>
              </button>
            </div>

            {/* Inspector Details */}
            <div className="p-3.5 space-y-4">
              {/* File Specs */}
              <div className="space-y-2">
                <h4 className="text-[10px] uppercase font-bold text-[#666] tracking-wider">
                  File Info
                </h4>
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-[#888]">Filename</span>
                    <span className="text-[#DDD] font-mono truncate max-w-[140px]" title={activeAsset.filename}>
                      {activeAsset.filename}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">Resolution</span>
                    <span className="text-[#DDD] font-mono">
                      {activeAsset.width} × {activeAsset.height} ({(activeAsset.width * activeAsset.height / 1_000_000).toFixed(1)} MP)
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">Size</span>
                    <span className="text-[#DDD] font-mono">
                      {(activeAsset.file_size / 1_000_000).toFixed(2)} MB
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">MIME Type</span>
                    <span className="text-[#DDD] font-mono">{activeAsset.mime_type}</span>
                  </div>
                </div>
              </div>

              <div className="h-px bg-[#2E2E2E]" />

              {/* Camera & Lens Specs */}
              <div className="space-y-2">
                <h4 className="text-[10px] uppercase font-bold text-[#666] tracking-wider">
                  Camera EXIF
                </h4>
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-[#888]">Camera</span>
                    <span className="text-[#DDD] font-medium">
                      {activeAsset.metadata?.make} {activeAsset.metadata?.model}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">Lens</span>
                    <span className="text-[#DDD] truncate max-w-[150px]" title={activeAsset.metadata?.lens}>
                      {activeAsset.metadata?.lens}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">Focal Length</span>
                    <span className="text-[#DDD] font-mono">
                      {activeAsset.metadata?.focal_length_mm} mm
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">Aperture</span>
                    <span className="text-[#DDD] font-mono">{activeAsset.metadata?.aperture}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">Shutter</span>
                    <span className="text-[#DDD] font-mono">{activeAsset.metadata?.shutter_speed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">ISO</span>
                    <span className="text-[#DDD] font-mono">{activeAsset.metadata?.iso}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#888]">Color Space</span>
                    <span className="text-[#DDD] font-mono">{activeAsset.metadata?.color_space}</span>
                  </div>
                </div>
              </div>

              <div className="h-px bg-[#2E2E2E]" />

              {/* GPS & Location */}
              {activeAsset.metadata?.location_name && (
                <div className="space-y-2">
                  <h4 className="text-[10px] uppercase font-bold text-[#666] tracking-wider flex items-center">
                    <MapPin className="w-3 h-3 mr-1 text-red-400" /> Location
                  </h4>
                  <p className="text-[11px] text-[#DDD] leading-relaxed">
                    {activeAsset.metadata.location_name}
                  </p>
                  <p className="text-[10px] text-[#777] font-mono">
                    {activeAsset.metadata.latitude?.toFixed(4)}° N, {activeAsset.metadata.longitude?.toFixed(4)}° E (Elev: {activeAsset.metadata.altitude_m}m)
                  </p>
                </div>
              )}

              <div className="h-px bg-[#2E2E2E]" />

              {/* Tags */}
              <div className="space-y-2">
                <h4 className="text-[10px] uppercase font-bold text-[#666] tracking-wider">
                  Keywords / Tags
                </h4>
                <div className="flex flex-wrap gap-1">
                  {activeAsset.tags?.map((t) => (
                    <span
                      key={t}
                      className="bg-[#2A2A2A] px-2 py-0.5 rounded text-[10px] text-[#AAA] border border-[#383838]"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Rust Perceptual Hash Card */}
              <div className="mt-4 p-3 bg-[#202020] rounded border border-[#333] space-y-1.5">
                <div className="flex items-center space-x-2 text-[10px] font-mono text-[#007AFF]">
                  <div className="w-1.5 h-1.5 bg-[#007AFF] rounded-full animate-pulse" />
                  <span>RUST PERCEPTUAL HASH</span>
                </div>
                <p className="text-[10px] text-[#AAA] font-mono break-all">
                  pHash: {activeAsset.phash || '0x3c7e81409f21b7b6'}
                </p>
                <p className="text-[9px] text-[#666]">
                  Hamming distance normalized (0.000 diff threshold)
                </p>
              </div>
            </div>
          </aside>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 3. BOTTOM NATIVE macOS STATUS FOOTER */}
      {/* ========================================================================= */}
      <footer
        id="app-footer"
        className="h-7 bg-[#1E1E1E] border-t border-[#333] flex items-center justify-between px-4 text-[10px] font-medium text-[#888] shrink-0 z-20"
      >
        <div className="flex items-center space-x-4">
          <span className="text-[#CCC]">{stats.total_photos.toLocaleString()} Photos</span>
          <span>{(stats.total_size_bytes / 1_000_000_000_000).toFixed(2)} TB Managed</span>
          <span>{stats.total_raw.toLocaleString()} RAW Masters</span>
          <span className="text-[#666]">|</span>
          <span className="font-mono text-[#007AFF]">SQLite WAL Mode • 64MB Cache</span>
        </div>

        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-[#27C93F]" />
            <span className="text-[#CCC]">Asset Integrity: Verified</span>
          </div>
          <span className="text-[#666]">|</span>
          <span className="text-[#888] font-mono">Apple Silicon Native (Metal 3.1)</span>
        </div>
      </footer>

      {/* ========================================================================= */}
      {/* 4. MODALS (Import, Smart Album, Settings, Toast) */}
      {/* ========================================================================= */}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-10 right-6 bg-[#252525]/95 border border-[#444] text-white px-3.5 py-2 rounded-md shadow-2xl text-xs font-mono flex items-center space-x-2 z-50 animate-in slide-in-from-bottom-2">
          <Zap className="w-3.5 h-3.5 text-[#007AFF]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Import Modal */}
      {showImportModal && (
        <ImportPhotosModal
          onClose={() => setShowImportModal(false)}
          onImport={(source) => {
            setShowImportModal(false);
            showToast(`Rust Worker: Queued streaming import for ${source}`);
          }}
        />
      )}

      {/* Smart Album Modal */}
      {showSmartAlbumModal && (
        <SmartAlbumModal
          onClose={() => setShowSmartAlbumModal(false)}
          onCreate={(name) => {
            const newAlbum: Album = {
              id: `alb_${Date.now()}`,
              name,
              created_at: Date.now(),
              asset_count: 5,
              is_smart: true,
              icon: 'sparkles',
            };
            setAlbums((prev) => [...prev, newAlbum]);
            setShowSmartAlbumModal(false);
            showToast(`Smart Album '${name}' compiled into SQLite query`);
          }}
        />
      )}

      {/* Settings Modal */}
      {showSettingsModal && (
        <SettingsModal onClose={() => setShowSettingsModal(false)} />
      )}
    </div>
  );
}

// ============================================================================
// SUB-VIEWS & COMPONENT IMPLEMENTATIONS
// ============================================================================

// 1. Statistics & Analytics Dashboard
function StatisticsDashboard({ stats }: { stats: LibraryStats }) {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      <div>
        <h2 className="text-base font-semibold text-white tracking-tight">
          Library Statistics & Hardware Telemetry
        </h2>
        <p className="text-xs text-[#888] mt-0.5">
          Real-time diagnostics calculated directly by the Rust SQLite indexer
        </p>
      </div>

      {/* Hero Metric Cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E]">
          <span className="text-[11px] text-[#888] uppercase tracking-wider font-semibold">
            Total Photos
          </span>
          <p className="text-2xl font-bold text-white mt-1 font-mono">
            {stats.total_photos.toLocaleString()}
          </p>
          <span className="text-[10px] text-emerald-400 mt-1 block">100% Indexed & Hashed</span>
        </div>

        <div className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E]">
          <span className="text-[11px] text-[#888] uppercase tracking-wider font-semibold">
            Storage Size
          </span>
          <p className="text-2xl font-bold text-white mt-1 font-mono">
            {(stats.total_size_bytes / 1_000_000_000_000).toFixed(2)} TB
          </p>
          <span className="text-[10px] text-[#888] mt-1 block">Originals + Previews</span>
        </div>

        <div className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E]">
          <span className="text-[11px] text-[#888] uppercase tracking-wider font-semibold">
            RAW Master Assets
          </span>
          <p className="text-2xl font-bold text-orange-400 mt-1 font-mono">
            {stats.total_raw.toLocaleString()}
          </p>
          <span className="text-[10px] text-[#888] mt-1 block">Sony ARW, Canon CR3, Nikon NEF</span>
        </div>

        <div className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E]">
          <span className="text-[11px] text-[#888] uppercase tracking-wider font-semibold">
            Favorites Marked
          </span>
          <p className="text-2xl font-bold text-amber-400 mt-1 font-mono">
            {stats.total_favorites.toLocaleString()}
          </p>
          <span className="text-[10px] text-[#888] mt-1 block">★ 5-star prioritized</span>
        </div>
      </div>

      {/* Year Distribution Bars */}
      <div className="bg-[#181818] p-5 rounded-lg border border-[#2E2E2E] space-y-3">
        <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
          Timeline Distribution (Year-by-Year)
        </h3>
        <div className="space-y-2">
          {stats.years_distribution.map((item) => {
            const pct = (item.count / 65000) * 100;
            return (
              <div key={item.year} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-mono text-[#DDD]">{item.year}</span>
                  <span className="font-mono text-[#888]">{item.count.toLocaleString()} photos</span>
                </div>
                <div className="w-full bg-[#252525] h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-[#007AFF] h-full rounded-full transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Camera Gear Breakdown */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E] space-y-3">
          <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
            Primary Camera Bodies
          </h3>
          <div className="space-y-2 text-xs">
            {stats.camera_distribution.map((cam) => (
              <div key={cam.camera} className="flex justify-between items-center py-1 border-b border-[#252525]">
                <span className="text-[#DDD] font-medium">{cam.camera}</span>
                <span className="font-mono text-[#888]">{cam.count.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E] space-y-3">
          <h3 className="text-xs font-semibold text-white uppercase tracking-wider">
            ISO Sensitivity Range
          </h3>
          <div className="space-y-2 text-xs">
            {stats.iso_distribution.map((iso) => (
              <div key={iso.range} className="flex justify-between items-center py-1 border-b border-[#252525]">
                <span className="text-[#DDD]">{iso.range}</span>
                <span className="font-mono text-[#888]">{iso.count.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// 2. Storage Manager Dashboard
function StorageManagerDashboard({ stats }: { stats: LibraryStats }) {
  const sb = stats.storage_breakdown;
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      <div>
        <h2 className="text-base font-semibold text-white tracking-tight">
          Storage Breakdown & Cache Allocation
        </h2>
        <p className="text-xs text-[#888] mt-0.5">
          Disk usage analysis across RAW masters, Retina thumbnails, and SQLite WAL buffers
        </p>
      </div>

      {/* Storage Visual Gauge */}
      <div className="bg-[#181818] p-5 rounded-lg border border-[#2E2E2E] space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-xs font-semibold text-white uppercase tracking-wider">
            Volume: /Volumes/MasterPhotoSSD (4.0 TB APFS)
          </span>
          <span className="text-xs font-mono text-[#27C93F]">1.19 TB Available</span>
        </div>

        <div className="w-full h-4 bg-[#252525] rounded-md overflow-hidden flex">
          <div className="bg-[#007AFF] h-full" style={{ width: '82%' }} title="Originals: 2.64 TB" />
          <div className="bg-purple-500 h-full" style={{ width: '9%' }} title="Previews: 280 GB" />
          <div className="bg-amber-500 h-full" style={{ width: '4%' }} title="Thumbnails: 84 GB" />
          <div className="bg-emerald-500 h-full" style={{ width: '3%' }} title="Cache & DB: 57 GB" />
        </div>

        {/* Legend */}
        <div className="grid grid-cols-4 gap-2 text-xs pt-2">
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 bg-[#007AFF] rounded-xs" />
            <span className="text-[#AAA]">Originals (2.64 TB)</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 bg-purple-500 rounded-xs" />
            <span className="text-[#AAA]">Retina Previews (280 GB)</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 bg-amber-500 rounded-xs" />
            <span className="text-[#AAA]">Thumbnails (84 GB)</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 bg-emerald-500 rounded-xs" />
            <span className="text-[#AAA]">SQLite & Cache (57.4 GB)</span>
          </div>
        </div>
      </div>

      {/* Cache Eviction and Maintenance Actions */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E] space-y-2">
          <h3 className="text-xs font-semibold text-white">Retina Thumbnail Cache (LRU)</h3>
          <p className="text-xs text-[#888]">
            Multi-tier 64px, 128px, 256px, 512px, 1024px WebP tiles generated deterministically
          </p>
          <div className="pt-2">
            <button className="px-3 py-1.5 bg-[#2A2A2A] hover:bg-[#333] text-xs text-white rounded cursor-pointer transition-colors">
              Purge Expired Thumbnails
            </button>
          </div>
        </div>

        <div className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E] space-y-2">
          <h3 className="text-xs font-semibold text-white">SQLite Database Vacuum</h3>
          <p className="text-xs text-[#888]">
            Reclaim unused b-tree pages and optimize WAL file on high-speed NVMe storage
          </p>
          <div className="pt-2">
            <button className="px-3 py-1.5 bg-[#007AFF] hover:bg-[#0069D9] text-xs text-white rounded cursor-pointer transition-colors">
              Execute VACUUM & Reindex
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// 3. Library Doctor (Integrity & Health Checker)
function LibraryDoctorView({
  report,
  onRunCheck,
}: {
  report: LibraryDoctorReport;
  onRunCheck: () => void;
}) {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-semibold text-white tracking-tight">
            Library Doctor & File Integrity Sentinel
          </h2>
          <p className="text-xs text-[#888] mt-0.5">
            Ensures exact SHA-256 matching between SQLite records, external drives, and backups
          </p>
        </div>
        <button
          onClick={onRunCheck}
          className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#27C93F] hover:bg-[#20A834] text-black text-xs font-semibold rounded cursor-pointer transition-colors shadow-sm"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Run Full Health Scan</span>
        </button>
      </div>

      {/* Checklist Card */}
      <div className="bg-[#181818] p-5 rounded-lg border border-[#2E2E2E] space-y-4">
        <div className="flex items-center space-x-3 p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-md">
          <Check className="w-5 h-5 text-[#27C93F]" />
          <div>
            <span className="text-xs font-semibold text-emerald-300">
              Database Integrity: 100% Healthy
            </span>
            <p className="text-[11px] text-[#AAA] font-mono mt-0.5">
              {report.database_check_message}
            </p>
          </div>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex justify-between items-center py-2 border-b border-[#252525]">
            <span className="text-[#DDD] flex items-center">
              <Check className="w-3.5 h-3.5 text-[#27C93F] mr-2" />
              Scanned 148,221 Master File References
            </span>
            <span className="font-mono text-[#27C93F]">0 Missing Files</span>
          </div>

          <div className="flex justify-between items-center py-2 border-b border-[#252525]">
            <span className="text-[#DDD] flex items-center">
              <Check className="w-3.5 h-3.5 text-[#27C93F] mr-2" />
              Retina WebP Thumbnail Cache Consistency
            </span>
            <span className="font-mono text-[#27C93F]">0 Orphans</span>
          </div>

          <div className="flex justify-between items-center py-2 border-b border-[#252525]">
            <span className="text-[#DDD] flex items-center">
              <Check className="w-3.5 h-3.5 text-[#27C93F] mr-2" />
              Streaming SHA-256 Bitrot Protection
            </span>
            <span className="font-mono text-[#27C93F]">100% Match</span>
          </div>

          <div className="flex justify-between items-center py-2">
            <span className="text-[#DDD] flex items-center">
              <Check className="w-3.5 h-3.5 text-[#27C93F] mr-2" />
              External APFS Mirror Snapshot
            </span>
            <span className="font-mono text-[#888]">Last Verified: {report.last_backup_date}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// 4. Duplicate Review Workbench
function DuplicateReviewWorkbench({
  groups,
  onResolve,
}: {
  groups: DuplicateGroup[];
  onResolve: (groupId: string, keeperId: string) => void;
}) {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      <div>
        <h2 className="text-base font-semibold text-white tracking-tight">
          Duplicate Detection Workbench
        </h2>
        <p className="text-xs text-[#888] mt-0.5">
          Perceptual pHash (DCT-based) and exact SHA-256 candidate groups with side-by-side comparison
        </p>
      </div>

      {groups.length === 0 ? (
        <div className="p-8 text-center bg-[#181818] rounded-lg border border-[#2E2E2E]">
          <Check className="w-8 h-8 text-[#27C93F] mx-auto mb-2" />
          <p className="text-xs text-[#DDD] font-medium">No duplicate clusters remaining</p>
          <p className="text-[11px] text-[#666] mt-1">Your photo library is completely clean and deduplicated</p>
        </div>
      ) : (
        <div className="space-y-6">
          {groups.map((group) => (
            <div
              key={group.id}
              className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E] space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 bg-cyan-950 text-cyan-400 border border-cyan-800 text-[10px] font-mono rounded font-medium">
                    {group.match_type}
                  </span>
                  <span className="text-xs font-mono text-[#DDD]">
                    Similarity: {(group.similarity * 100).toFixed(1)}%
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => onResolve(group.id, group.recommended_keeper_id)}
                    className="px-2.5 py-1 bg-[#007AFF] hover:bg-[#0069D9] text-white text-xs font-medium rounded cursor-pointer transition-colors"
                  >
                    Keep Recommended Master
                  </button>
                </div>
              </div>

              {/* Side-by-Side Candidates */}
              <div className="grid grid-cols-2 gap-4">
                {group.assets.map((asset) => {
                  const isKeeper = asset.id === group.recommended_keeper_id;
                  return (
                    <div
                      key={asset.id}
                      className={`p-3 rounded-md bg-[#222] border flex space-x-3 ${
                        isKeeper ? 'border-[#007AFF]/60 ring-1 ring-[#007AFF]/40' : 'border-[#333]'
                      }`}
                    >
                      <img
                        src={asset.thumbnail_url}
                        alt={asset.filename}
                        className="w-24 h-24 object-cover rounded shrink-0"
                      />
                      <div className="flex-1 min-w-0 text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-white truncate font-medium">
                            {asset.filename}
                          </span>
                          {isKeeper && (
                            <span className="text-[9px] bg-[#007AFF]/20 text-[#007AFF] px-1.5 py-0.5 rounded font-mono">
                              Master RAW
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-[#888] font-mono">
                          {asset.width} × {asset.height} • {(asset.file_size / 1_000_000).toFixed(1)} MB
                        </p>
                        <p className="text-[10px] text-[#AAA] truncate">
                          {asset.metadata?.make} {asset.metadata?.model}
                        </p>
                        <p className="text-[9px] text-[#666] font-mono truncate">
                          Path: {asset.original_path}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// 5. Background Job Monitor View
function JobMonitorView({
  jobs,
  onCancelJob,
}: {
  jobs: Job[];
  onCancelJob: (jobId: string) => void;
}) {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6">
      <div>
        <h2 className="text-base font-semibold text-white tracking-tight">
          Background Worker Pool & Dispatcher (Rayon / Tokio)
        </h2>
        <p className="text-xs text-[#888] mt-0.5">
          Multi-threaded pipeline executing non-blocking indexing, perceptual hashing, and backups
        </p>
      </div>

      <div className="space-y-3">
        {jobs.map((job) => (
          <div
            key={job.id}
            className="bg-[#181818] p-4 rounded-lg border border-[#2E2E2E] space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <span className="px-2 py-0.5 bg-[#252525] text-white border border-[#3D3D3D] text-[10px] font-mono rounded font-semibold">
                  {job.job_type}
                </span>
                <span className="text-xs font-semibold text-white">{job.message}</span>
              </div>

              <div className="flex items-center space-x-3">
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded font-medium ${
                    job.status === 'RUNNING'
                      ? 'bg-[#007AFF]/20 text-[#007AFF]'
                      : job.status === 'COMPLETED'
                      ? 'bg-[#27C93F]/20 text-[#27C93F]'
                      : 'bg-red-500/20 text-red-400'
                  }`}
                >
                  {job.status}
                </span>

                {job.status === 'RUNNING' && (
                  <button
                    onClick={() => onCancelJob(job.id)}
                    className="text-xs text-red-400 hover:text-red-300 font-mono cursor-pointer"
                  >
                    Cancel
                  </button>
                )}
              </div>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <div className="w-full bg-[#252525] h-2 rounded-full overflow-hidden">
                <div
                  className="bg-[#007AFF] h-full transition-all duration-300"
                  style={{ width: `${job.progress * 100}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-[#888] font-mono">
                <span>
                  {job.items_processed.toLocaleString()} / {job.total_items.toLocaleString()} assets
                </span>
                <span>{job.speed_items_per_sec} items/sec</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// 6. Import Photos Modal
function ImportPhotosModal({
  onClose,
  onImport,
}: {
  onClose: () => void;
  onImport: (source: string) => void;
}) {
  const [sourcePath, setSourcePath] = useState<string>('/Volumes/EOS_DIGITAL/DCIM/100CANON');
  const [copyFiles, setCopyFiles] = useState<boolean>(true);

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-[#1C1C1C] border border-[#333] rounded-lg w-full max-w-lg overflow-hidden shadow-2xl space-y-4 p-5">
        <div className="flex items-center justify-between border-b border-[#333] pb-3">
          <h3 className="text-sm font-semibold text-white">Import Photos & RAW Masters</h3>
          <button onClick={onClose} className="text-[#888] hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <div className="space-y-1">
            <label className="text-[#AAA] block">Source Volume / Directory</label>
            <input
              type="text"
              value={sourcePath}
              onChange={(e) => setSourcePath(e.target.value)}
              className="w-full bg-[#262626] border border-[#3D3D3D] rounded px-3 py-1.5 text-white font-mono text-xs focus:outline-hidden focus:border-[#007AFF]"
            />
          </div>

          <div className="space-y-2 pt-2">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={copyFiles}
                onChange={(e) => setCopyFiles(e.target.checked)}
                className="accent-[#007AFF]"
              />
              <span className="text-[#DDD]">Copy files into Master iPhotos Library bundle</span>
            </label>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input type="checkbox" defaultChecked className="accent-[#007AFF]" />
              <span className="text-[#DDD]">Prevent duplicate imports via streaming SHA-256</span>
            </label>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input type="checkbox" defaultChecked className="accent-[#007AFF]" />
              <span className="text-[#DDD]">Generate multi-scale Retina thumbnails (64px - 1024px)</span>
            </label>
          </div>
        </div>

        <div className="flex justify-end space-x-2 pt-3 border-t border-[#333]">
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-[#2A2A2A] hover:bg-[#333] text-xs text-[#AAA] rounded cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={() => onImport(sourcePath)}
            className="px-4 py-1.5 bg-[#007AFF] hover:bg-[#0069D9] text-xs text-white font-medium rounded cursor-pointer"
          >
            Start Background Import
          </button>
        </div>
      </div>
    </div>
  );
}

// 7. Smart Album Modal
function SmartAlbumModal({
  onClose,
  onCreate,
}: {
  onClose: () => void;
  onCreate: (name: string) => void;
}) {
  const [albumName, setAlbumName] = useState<string>('5-Star Mountain Landscapes');

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-[#1C1C1C] border border-[#333] rounded-lg w-full max-w-md overflow-hidden shadow-2xl space-y-4 p-5">
        <div className="flex items-center justify-between border-b border-[#333] pb-3">
          <h3 className="text-sm font-semibold text-white">Create Smart Album</h3>
          <button onClick={onClose} className="text-[#888] hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <div className="space-y-1">
            <label className="text-[#AAA] block">Album Name</label>
            <input
              type="text"
              value={albumName}
              onChange={(e) => setAlbumName(e.target.value)}
              className="w-full bg-[#262626] border border-[#3D3D3D] rounded px-3 py-1.5 text-white text-xs focus:outline-hidden focus:border-[#007AFF]"
            />
          </div>

          <div className="p-3 bg-[#222] rounded border border-[#333] space-y-2">
            <span className="text-[11px] text-[#888] uppercase font-bold">Rules Definition</span>
            <div className="space-y-1.5 font-mono text-[11px] text-[#DDD]">
              <div className="flex justify-between">
                <span>Rating</span>
                <span className="text-[#007AFF]">&gt;= 5 Stars</span>
              </div>
              <div className="flex justify-between">
                <span>Asset Type</span>
                <span className="text-[#007AFF]">RAW Master</span>
              </div>
              <div className="flex justify-between">
                <span>Year</span>
                <span className="text-[#007AFF]">2026</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-2 pt-3 border-t border-[#333]">
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-[#2A2A2A] hover:bg-[#333] text-xs text-[#AAA] rounded cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={() => onCreate(albumName)}
            className="px-4 py-1.5 bg-[#007AFF] hover:bg-[#0069D9] text-xs text-white font-medium rounded cursor-pointer"
          >
            Create Rule Set
          </button>
        </div>
      </div>
    </div>
  );
}

// 8. Settings Modal
function SettingsModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-[#1C1C1C] border border-[#333] rounded-lg w-full max-w-lg overflow-hidden shadow-2xl space-y-4 p-5">
        <div className="flex items-center justify-between border-b border-[#333] pb-3">
          <h3 className="text-sm font-semibold text-white">iPHOTOS.PRO Preferences</h3>
          <button onClick={onClose} className="text-[#888] hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 text-xs">
          <div className="space-y-2">
            <h4 className="text-[11px] font-semibold text-white uppercase tracking-wider">
              Rust Engine & Hardware Acceleration
            </h4>
            <div className="space-y-1.5 text-[#AAA]">
              <div className="flex justify-between py-1 border-b border-[#2A2A2A]">
                <span>Metal 3.1 Compute Pipeline</span>
                <span className="text-[#27C93F] font-mono">Enabled</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#2A2A2A]">
                <span>Rayon Worker Thread Count</span>
                <span className="font-mono text-[#DDD]">8 Hardware Threads</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#2A2A2A]">
                <span>Retina Thumbnail LRU Cache</span>
                <span className="font-mono text-[#DDD]">4,096 Tiles (4GB Limit)</span>
              </div>
              <div className="flex justify-between py-1">
                <span>Perceptual Hashing Algorithm</span>
                <span className="font-mono text-[#DDD]">pHash (64-bit DCT)</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-3 border-t border-[#333]">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#007AFF] hover:bg-[#0069D9] text-xs text-white font-medium rounded cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
