import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'iPHOTOS.PRO - Native macOS Photo Library & Asset Management Engine',
  description: 'Native macOS Photo Library, Digital Asset Management & High-Performance Image Engine with Kotlin UI and Rust Core.',
  openGraph: {
    title: 'iPHOTOS.PRO - Native macOS Photo Library & Asset Management Engine',
    description: 'Native macOS Photo Library, Digital Asset Management & High-Performance Image Engine with Kotlin UI and Rust Core.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'iPHOTOS.PRO - Native macOS Photo Library & Asset Management Engine',
    description: 'Native macOS Photo Library, Digital Asset Management & High-Performance Image Engine with Kotlin UI and Rust Core.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
