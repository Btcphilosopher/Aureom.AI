// iPHOTOS.PRO - System Types and Data Contracts
// Stable FFI and Domain Structures matching Kotlin <-> Rust Specification

export interface PhotoAsset {
  id: string;
  filename: string;
  original_path: string;
  file_size: number; // bytes
  width: number;
  height: number;
  mime_type: string;
  created_at: number; // Unix timestamp
  modified_at: number;
  sha256: string;
  phash: string | null;
  rating: number; // 0-5
  favorite: boolean;
  hidden: boolean;
  is_raw?: boolean;
  is_video?: boolean;
  duration?: number; // seconds if video
  preview_url: string;
  thumbnail_url: string;
  metadata?: PhotoMetadata;
  edits?: EditInstruction[];
  album_ids?: string[];
  tags?: string[];
}

export interface PhotoMetadata {
  make: string;
  model: string;
  lens: string;
  focal_length_mm: number;
  aperture: string; // e.g. "f/1.8"
  shutter_speed: string; // e.g. "1/2000s"
  iso: number;
  exposure_compensation: string;
  metering_mode: string;
  flash: string;
  color_space: string;
  white_balance: string;
  latitude: number | null;
  longitude: number | null;
  altitude_m: number | null;
  location_name: string | null;
  title: string;
  caption: string;
  copyright: string;
  software: string;
}

export interface EditInstruction {
  operation: 'exposure' | 'brightness' | 'contrast' | 'saturation' | 'temperature' | 'tint' | 'highlights' | 'shadows' | 'clarity' | 'vignette' | 'rotate' | 'crop';
  parameters: Record<string, number | string | boolean>;
}

export interface EditState {
  exposure: number; // -3.0 to +3.0
  brightness: number; // -100 to 100
  contrast: number; // -100 to 100
  saturation: number; // -100 to 100
  temperature: number; // 2000K to 10000K or -100 to 100
  tint: number; // -100 to 100
  highlights: number; // -100 to 100
  shadows: number; // -100 to 100
  clarity: number; // 0 to 100
  vignette: number; // 0 to 100
  rotation: number; // degrees 0, 90, 180, 270
  crop_aspect: 'original' | '1:1' | '16:9' | '4:3' | '3:2' | 'free';
}

export interface Album {
  id: string;
  name: string;
  created_at: number;
  asset_count: number;
  cover_asset_id?: string;
  is_smart: boolean;
  smart_rules?: SmartRuleGroup;
  icon?: string;
}

export interface SmartRuleGroup {
  match: 'all' | 'any';
  rules: SmartRule[];
}

export interface SmartRule {
  field: 'rating' | 'year' | 'type' | 'camera' | 'tag' | 'favorite' | 'iso';
  operator: 'equals' | 'gte' | 'lte' | 'contains' | 'not_equals';
  value: string | number | boolean;
}

export interface Job {
  id: string;
  job_type: 'IMPORT' | 'THUMBNAIL' | 'PREVIEW' | 'HASH' | 'ANALYSIS' | 'DUPLICATE' | 'BACKUP' | 'EXPORT';
  progress: number; // 0.0 to 1.0
  status: 'QUEUED' | 'RUNNING' | 'COMPLETED' | 'FAILED' | 'CANCELLED';
  message: string;
  items_processed: number;
  total_items: number;
  speed_items_per_sec: number;
  started_at: number;
}

export interface DuplicateGroup {
  id: string;
  similarity: number; // 0.0 to 1.0 (1.0 = exact SHA-256 match)
  match_type: 'EXACT_SHA256' | 'PERCEPTUAL_PHASH' | 'METADATA_TIMESTAMP';
  assets: PhotoAsset[];
  recommended_keeper_id: string;
}

export interface LibraryStats {
  total_photos: number;
  total_raw: number;
  total_videos: number;
  total_favorites: number;
  total_size_bytes: number;
  years_distribution: { year: number; count: number }[];
  camera_distribution: { camera: string; count: number }[];
  lens_distribution: { lens: string; count: number }[];
  iso_distribution: { range: string; count: number }[];
  storage_breakdown: {
    originals_bytes: number;
    previews_bytes: number;
    thumbnails_bytes: number;
    cache_bytes: number;
    exports_bytes: number;
    sqlite_db_bytes: number;
  };
}

export interface LibraryDoctorReport {
  database_status: 'HEALTHY' | 'WARNING' | 'CORRUPT';
  database_check_message: string;
  total_scanned_assets: number;
  missing_files_count: number;
  missing_files: string[];
  orphan_thumbnails_count: number;
  hash_mismatches_count: number;
  backup_status: 'VERIFIED' | 'OUTDATED' | 'NONE';
  last_backup_date: string;
  last_check_timestamp: number;
}

export type SidebarSectionId = 
  | 'photos'
  | 'favorites'
  | 'recent'
  | 'videos'
  | 'raw'
  | 'panoramas'
  | 'hidden'
  | 'trash'
  | 'album'
  | 'duplicates'
  | 'map'
  | 'stats'
  | 'storage'
  | 'jobs'
  | 'doctor'
  | 'code_browser';
