// iPHOTOS.PRO - Engine Configuration
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EngineConfig {
    pub library_path: PathBuf,
    pub cache_path: PathBuf,
    pub database_path: PathBuf,
    pub thumbnail_lru_capacity: usize,
    pub preview_lru_capacity: usize,
    pub worker_threads: usize,
    pub enable_perceptual_hash: bool,
    pub enable_ai_analysis: bool,
    pub watch_filesystem: bool,
}

impl Default for EngineConfig {
    fn default() -> Self {
        let home = std::env::var("HOME").unwrap_or_else(|_| ".".into());
        let library_dir = PathBuf::from(home).join("Pictures/iPhotosLibrary.iphotos");
        Self {
            cache_path: library_dir.join("Cache"),
            database_path: library_dir.join("Database/photos.db"),
            library_path: library_dir,
            thumbnail_lru_capacity: 4096,
            preview_lru_capacity: 256,
            worker_threads: num_cpus::get().max(4),
            enable_perceptual_hash: true,
            enable_ai_analysis: false,
            watch_filesystem: true,
        }
    }
}
