// iPHOTOS.PRO - Rust Core Engine
// C-ABI FFI Entry point and Modular Core Architecture

pub mod error;
pub mod config;
pub mod library;
pub mod assets;
pub mod database;
pub mod import;
pub mod image;
pub mod metadata;
pub mod search;
pub mod albums;
pub mod duplicates;
pub mod editing;
pub mod export;
pub mod backup;
pub mod workers;
pub mod cache;
pub mod watcher;
pub mod ffi;

pub use error::{PhotoError, Result};
pub use assets::asset::PhotoAsset;
pub use config::EngineConfig;
pub use library::library::PhotoLibrary;

/// Engine version metadata
pub const ENGINE_VERSION: &str = "1.0.0-macos-apple-silicon";
pub const API_VERSION: &str = "1.0";
