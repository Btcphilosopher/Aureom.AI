// iPHOTOS.PRO - Central Error Architecture
use thiserror::Error;

pub type Result<T> = std::result::Result<T, PhotoError>;

#[derive(Error, Debug)]
pub enum PhotoError {
    #[error("I/O subsystem error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Database error: {0}")]
    Database(String),

    #[error("Image decode error: {0}")]
    Decode(String),

    #[error("Metadata extraction error: {0}")]
    Metadata(String),

    #[error("Invalid asset error: {0}")]
    InvalidAsset(String),

    #[error("Export pipeline failure: {0}")]
    Export(String),

    #[error("Backup verification failure: {0}")]
    Backup(String),

    #[error("Asset or entity not found: {0}")]
    NotFound(String),

    #[error("JSON serialization error: {0}")]
    Serialization(#[from] serde_json::Error),

    #[error("Operation cancelled by user")]
    Cancelled,

    #[error("Feature not implemented: {0}")]
    NotImplemented(String),
}

impl From<rusqlite::Error> for PhotoError {
    fn from(err: rusqlite::Error) -> Self {
        PhotoError::Database(err.to_string())
    }
}
