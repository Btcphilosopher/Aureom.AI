// iPHOTOS.PRO - Database-Accelerated Search Engine
use crate::assets::PhotoAsset;
use crate::database::Database;
use crate::error::Result;
use crate::search::parser::SearchQuery;
use rusqlite::types::ToSql;

pub struct SearchResult {
    pub assets: Vec<PhotoAsset>,
    pub total_matched: usize,
}

pub struct SearchEngine<'a> {
    db: &'a Database,
}

impl<'a> SearchEngine<'a> {
    pub fn new(db: &'a Database) -> Self {
        Self { db }
    }

    pub fn execute(&self, query: &SearchQuery) -> Result<SearchResult> {
        self.db.with_conn(|conn| {
            let mut sql = String::from(
                "SELECT a.id, a.filename, a.original_path, a.file_size, a.width, a.height,
                        a.mime_type, a.created_at, a.modified_at, a.sha256, a.phash,
                        a.rating, a.favorite, a.hidden
                 FROM assets a
                 LEFT JOIN metadata m ON a.id = m.asset_id
                 WHERE a.hidden = 0",
            );

            let mut params_vec: Vec<Box<dyn ToSql>> = Vec::new();

            if let Some(r) = query.min_rating {
                sql.push_str(" AND a.rating >= ?");
                params_vec.push(Box::new(r as i64));
            }

            if let Some(fav) = query.is_favorite {
                sql.push_str(" AND a.favorite = ?");
                params_vec.push(Box::new(if fav { 1i64 } else { 0i64 }));
            }

            if let Some(ref cam) = query.camera {
                sql.push_str(" AND (m.make LIKE ? OR m.model LIKE ?)");
                let pattern = format!("%{}%", cam);
                params_vec.push(Box::new(pattern.clone()));
                params_vec.push(Box::new(pattern));
            }

            for kw in &query.keywords {
                sql.push_str(" AND (a.filename LIKE ? OR m.title LIKE ? OR m.caption LIKE ? OR m.location_name LIKE ?)");
                let pattern = format!("%{}%", kw);
                params_vec.push(Box::new(pattern.clone()));
                params_vec.push(Box::new(pattern.clone()));
                params_vec.push(Box::new(pattern.clone()));
                params_vec.push(Box::new(pattern));
            }

            sql.push_str(" ORDER BY a.created_at DESC LIMIT ? OFFSET ?");
            params_vec.push(Box::new(query.limit as i64));
            params_vec.push(Box::new(query.offset as i64));

            let params_slice: Vec<&dyn ToSql> = params_vec.iter().map(|b| b.as_ref()).collect();

            let mut stmt = conn.prepare(&sql)?;
            let rows = stmt.query_map(params_slice.as_slice(), |row| {
                let favorite_int: i64 = row.get(12)?;
                let hidden_int: i64 = row.get(13)?;
                Ok(PhotoAsset {
                    id: row.get(0)?,
                    filename: row.get(1)?,
                    original_path: row.get(2)?,
                    file_size: row.get::<_, i64>(3)? as u64,
                    width: row.get::<_, i64>(4)? as u32,
                    height: row.get::<_, i64>(5)? as u32,
                    mime_type: row.get(6)?,
                    created_at: row.get(7)?,
                    modified_at: row.get(8)?,
                    sha256: row.get(9)?,
                    phash: row.get(10)?,
                    rating: row.get::<_, i64>(11)? as u8,
                    favorite: favorite_int != 0,
                    hidden: hidden_int != 0,
                })
            })?;

            let mut assets = Vec::new();
            for r in rows {
                assets.push(r?);
            }

            let total_matched = assets.len(); // Simplified query count

            Ok(SearchResult {
                assets,
                total_matched,
            })
        })
    }
}
