// iPHOTOS.PRO - Structured Search Query Parser (Section 20 & 22 of spec)
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct SearchQuery {
    pub raw_text: String,
    pub keywords: Vec<String>,
    pub year: Option<i32>,
    pub min_rating: Option<u8>,
    pub camera: Option<String>,
    pub lens: Option<String>,
    pub is_raw: Option<bool>,
    pub is_favorite: Option<bool>,
    pub tag: Option<String>,
    pub limit: usize,
    pub offset: usize,
}

pub struct QueryParser;

impl QueryParser {
    pub fn parse(input: &str) -> SearchQuery {
        let mut query = SearchQuery {
            raw_text: input.to_string(),
            limit: 100,
            offset: 0,
            ..Default::default()
        };

        for token in input.split_whitespace() {
            if let Some(val) = token.strip_prefix("year:") {
                if let Ok(y) = val.parse::<i32>() {
                    query.year = Some(y);
                }
            } else if let Some(val) = token.strip_prefix("rating:") {
                if let Ok(r) = val.parse::<u8>() {
                    query.min_rating = Some(r);
                }
            } else if let Some(val) = token.strip_prefix("camera:") {
                query.camera = Some(val.to_string());
            } else if let Some(val) = token.strip_prefix("tag:") {
                query.tag = Some(val.to_string());
            } else if token.eq_ignore_ascii_case("raw") {
                query.is_raw = Some(true);
            } else if token.eq_ignore_ascii_case("favorite") || token.eq_ignore_ascii_case("fav") {
                query.is_favorite = Some(true);
            } else {
                query.keywords.push(token.to_string());
            }
        }

        query
    }
}
