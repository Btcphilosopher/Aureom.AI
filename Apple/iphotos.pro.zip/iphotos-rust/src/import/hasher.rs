// iPHOTOS.PRO - Streaming Hash Engine (Section 15 of spec)
use crate::error::Result;
use sha2::{Digest, Sha256};
use std::fs::File;
use std::io::{BufReader, Read};
use std::path::Path;

pub struct StreamingHasher;

impl StreamingHasher {
    /// Streams 64KB chunks to hash gigabyte-scale RAW/Video files without memory spikes
    pub fn sha256_file<P: AsRef<Path>>(path: P) -> Result<String> {
        let file = File::open(path)?;
        let mut reader = BufReader::with_capacity(65536, file);
        let mut hasher = Sha256::new();
        let mut buffer = [0u8; 65536];

        loop {
            let bytes_read = reader.read(&mut buffer)?;
            if bytes_read == 0 {
                break;
            }
            hasher.update(&buffer[..bytes_read]);
        }

        let hash_bytes = hasher.finalize();
        Ok(hex::encode(hash_bytes))
    }
}
