// iPHOTOS.PRO - High-Performance RGB and Luma Histogram Calculator
use image::{DynamicImage, GenericImageView, Pixel};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImageHistogram {
    pub r: Vec<u32>,     // 256 bins
    pub g: Vec<u32>,     // 256 bins
    pub b: Vec<u32>,     // 256 bins
    pub luma: Vec<u32>,  // 256 bins
    pub peak_count: u32,
}

pub struct HistogramCalculator;

impl HistogramCalculator {
    pub fn compute(img: &DynamicImage) -> ImageHistogram {
        let mut r = vec![0u32; 256];
        let mut g = vec![0u32; 256];
        let mut b = vec![0u32; 256];
        let mut luma = vec![0u32; 256];
        let mut peak_count = 0;

        for (_x, _y, pixel) in img.pixels() {
            let rgb = pixel.to_rgb();
            let rv = rgb[0] as usize;
            let gv = rgb[1] as usize;
            let bv = rgb[2] as usize;
            let lv = ((0.2126 * rv as f32) + (0.7152 * gv as f32) + (0.0722 * bv as f32)) as usize;

            r[rv] += 1;
            g[gv] += 1;
            b[bv] += 1;
            luma[lv.min(255)] += 1;

            peak_count = peak_count.max(r[rv]).max(g[gv]).max(b[bv]);
        }

        ImageHistogram {
            r,
            g,
            b,
            luma,
            peak_count,
        }
    }
}
