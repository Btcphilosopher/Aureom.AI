// iPHOTOS.PRO - Deterministic Thumbnail Engine (Section 17 of spec)
use crate::error::{PhotoError, Result};
use image::{imageops::FilterType, DynamicImage, GenericImageView};
use std::fs;
use std::path::{Path, PathBuf};

pub const RENDERING_VERSION: u32 = 1;
pub const THUMBNAIL_SIZES: [u32; 5] = [64, 128, 256, 512, 1024];

pub struct ThumbnailEngine {
    cache_dir: PathBuf,
}

impl ThumbnailEngine {
    pub fn new<P: AsRef<Path>>(cache_dir: P) -> Self {
        let dir = cache_dir.as_ref().to_path_buf();
        let _ = fs::create_dir_all(&dir);
        Self { cache_dir: dir }
    }

    /// Deterministic Cache Key: asset_hash + size + rendering_version
    pub fn cache_key(asset_hash: &str, size: u32) -> String {
        format!("{}_s{}_v{}.webp", asset_hash, size, RENDERING_VERSION)
    }

    pub fn get_thumbnail_path(&self, asset_hash: &str, size: u32) -> PathBuf {
        let key = Self::cache_key(asset_hash, size);
        self.cache_dir.join(key)
    }

    pub fn thumbnail_exists(&self, asset_hash: &str, size: u32) -> bool {
        self.get_thumbnail_path(asset_hash, size).exists()
    }

    /// Generates thumbnail only when requested, saving as WebP
    pub fn generate_from_image(
        &self,
        img: &DynamicImage,
        asset_hash: &str,
        target_size: u32,
    ) -> Result<PathBuf> {
        let target_path = self.get_thumbnail_path(asset_hash, target_size);
        if target_path.exists() {
            return Ok(target_path);
        }

        let (orig_w, orig_h) = img.dimensions();
        let thumbnail = if orig_w > target_size || orig_h > target_size {
            img.resize(target_size, target_size, FilterType::Lanczos3)
        } else {
            img.clone()
        };

        thumbnail
            .save(&target_path)
            .map_err(|e| PhotoError::Decode(format!("Failed to save thumbnail: {}", e)))?;

        Ok(target_path)
    }
}
