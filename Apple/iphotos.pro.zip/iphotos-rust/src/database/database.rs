// iPHOTOS.PRO - SQLite Database Engine with Versioned Migrations
use crate::error::{PhotoError, Result};
use rusqlite::{params, Connection};
use std::path::Path;
use std::sync::Mutex;
use tracing::info;

pub struct Database {
    conn: Mutex<Connection>,
}

impl Database {
    pub fn open<P: AsRef<Path>>(path: P) -> Result<Self> {
        let conn = Connection::open(path)?;
        
        // High-performance SQLite pragmas for macOS
        conn.execute_batch(
            "PRAGMA journal_mode = WAL;
             PRAGMA synchronous = NORMAL;
             PRAGMA foreign_keys = ON;
             PRAGMA temp_store = MEMORY;
             PRAGMA mmap_size = 268435456; -- 256MB memory map
             PRAGMA cache_size = -64000;   -- 64MB page cache",
        )?;

        let db = Self {
            conn: Mutex::new(conn),
        };
        db.run_migrations()?;
        Ok(db)
    }

    pub fn open_in_memory() -> Result<Self> {
        let conn = Connection::open_in_memory()?;
        let db = Self {
            conn: Mutex::new(conn),
        };
        db.run_migrations()?;
        Ok(db)
    }

    fn run_migrations(&self) -> Result<()> {
        let conn = self.conn.lock().unwrap();
        
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at INTEGER NOT NULL
            );",
            [],
        )?;

        let current_version: i64 = conn.query_row(
            "SELECT COALESCE(MAX(version), 0) FROM schema_migrations",
            [],
            |r| r.get(0),
        ).unwrap_or(0);

        // 001_initial
        if current_version < 1 {
            info!("Applying migration 001_initial");
            conn.execute_batch(
                "CREATE TABLE assets (
                    id TEXT PRIMARY KEY,
                    filename TEXT NOT NULL,
                    original_path TEXT NOT NULL UNIQUE,
                    file_size INTEGER NOT NULL,
                    width INTEGER NOT NULL,
                    height INTEGER NOT NULL,
                    mime_type TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    modified_at INTEGER NOT NULL,
                    sha256 TEXT NOT NULL,
                    phash TEXT,
                    rating INTEGER NOT NULL DEFAULT 0,
                    favorite INTEGER NOT NULL DEFAULT 0,
                    hidden INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX idx_assets_created ON assets(created_at);
                CREATE INDEX idx_assets_rating ON assets(rating);
                CREATE INDEX idx_assets_favorite ON assets(favorite);
                CREATE INDEX idx_assets_sha256 ON assets(sha256);
                CREATE INDEX idx_assets_phash ON assets(phash);
                
                CREATE TABLE asset_files (
                    id TEXT PRIMARY KEY,
                    asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
                    file_type TEXT NOT NULL, -- ORIGINAL, SIDECAR_XMP, RAW_TIFF
                    file_path TEXT NOT NULL,
                    file_size INTEGER NOT NULL,
                    sha256 TEXT NOT NULL
                );",
            )?;
            conn.execute("INSERT INTO schema_migrations (version, applied_at) VALUES (1, unixepoch())", [])?;
        }

        // 002_metadata
        if current_version < 2 {
            info!("Applying migration 002_metadata");
            conn.execute_batch(
                "CREATE TABLE metadata (
                    asset_id TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
                    make TEXT,
                    model TEXT,
                    lens TEXT,
                    focal_length_mm REAL,
                    aperture TEXT,
                    shutter_speed TEXT,
                    iso INTEGER,
                    exposure_bias TEXT,
                    latitude REAL,
                    longitude REAL,
                    altitude_m REAL,
                    location_name TEXT,
                    title TEXT,
                    caption TEXT,
                    copyright TEXT
                );
                CREATE INDEX idx_meta_camera ON metadata(make, model);
                CREATE INDEX idx_meta_lens ON metadata(lens);
                CREATE INDEX idx_meta_iso ON metadata(iso);
                CREATE INDEX idx_meta_gps ON metadata(latitude, longitude);",
            )?;
            conn.execute("INSERT INTO schema_migrations (version, applied_at) VALUES (2, unixepoch())", [])?;
        }

        // 003_albums
        if current_version < 3 {
            info!("Applying migration 003_albums");
            conn.execute_batch(
                "CREATE TABLE albums (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    is_smart INTEGER NOT NULL DEFAULT 0,
                    smart_rules_json TEXT
                );
                CREATE TABLE album_assets (
                    album_id TEXT NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
                    asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
                    position INTEGER NOT NULL DEFAULT 0,
                    PRIMARY KEY (album_id, asset_id)
                );
                CREATE TABLE tags (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL UNIQUE
                );
                CREATE TABLE asset_tags (
                    asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
                    tag_id TEXT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
                    PRIMARY KEY (asset_id, tag_id)
                );",
            )?;
            conn.execute("INSERT INTO schema_migrations (version, applied_at) VALUES (3, unixepoch())", [])?;
        }

        // 004_edits
        if current_version < 4 {
            info!("Applying migration 004_edits");
            conn.execute_batch(
                "CREATE TABLE edits (
                    id TEXT PRIMARY KEY,
                    asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
                    instructions_json TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    active INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE versions (
                    id TEXT PRIMARY KEY,
                    asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
                    version_number INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    created_at INTEGER NOT NULL
                );",
            )?;
            conn.execute("INSERT INTO schema_migrations (version, applied_at) VALUES (4, unixepoch())", [])?;
        }

        // 005_jobs
        if current_version < 5 {
            info!("Applying migration 005_jobs");
            conn.execute_batch(
                "CREATE TABLE jobs (
                    id TEXT PRIMARY KEY,
                    job_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    progress REAL NOT NULL DEFAULT 0.0,
                    message TEXT,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL
                );
                CREATE TABLE duplicates (
                    id TEXT PRIMARY KEY,
                    group_id TEXT NOT NULL,
                    asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
                    similarity REAL NOT NULL,
                    match_type TEXT NOT NULL
                );
                CREATE TABLE events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    created_at INTEGER NOT NULL
                );",
            )?;
            conn.execute("INSERT INTO schema_migrations (version, applied_at) VALUES (5, unixepoch())", [])?;
        }

        Ok(())
    }

    pub fn execute_integrity_check(&self) -> Result<String> {
        let conn = self.conn.lock().unwrap();
        let result: String = conn.query_row("PRAGMA integrity_check;", [], |r| r.get(0))?;
        Ok(result)
    }

    pub fn with_conn<F, R>(&self, f: F) -> Result<R>
    where
        F: FnOnce(&Connection) -> Result<R>,
    {
        let conn = self.conn.lock().map_err(|e| PhotoError::Database(e.to_string()))?;
        f(&conn)
    }
}
