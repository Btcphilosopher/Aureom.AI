// iPHOTOS.PRO - Database Models
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DbAsset {
    pub id: String,
    pub filename: String,
    pub original_path: String,
    pub file_size: i64,
    pub width: i64,
    pub height: i64,
    pub mime_type: String,
    pub created_at: i64,
    pub modified_at: i64,
    pub sha256: String,
    pub phash: Option<String>,
    pub rating: i64,
    pub favorite: i64,
    pub hidden: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DbMetadata {
    pub asset_id: String,
    pub make: Option<String>,
    pub model: Option<String>,
    pub lens: Option<String>,
    pub focal_length_mm: Option<f64>,
    pub aperture: Option<String>,
    pub shutter_speed: Option<String>,
    pub iso: Option<i64>,
    pub exposure_bias: Option<String>,
    pub latitude: Option<f64>,
    pub longitude: Option<f64>,
    pub altitude_m: Option<f64>,
    pub location_name: Option<String>,
    pub title: Option<String>,
    pub caption: Option<String>,
    pub copyright: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DbAlbum {
    pub id: String,
    pub name: String,
    pub created_at: i64,
    pub is_smart: i64,
    pub smart_rules_json: Option<String>,
}
