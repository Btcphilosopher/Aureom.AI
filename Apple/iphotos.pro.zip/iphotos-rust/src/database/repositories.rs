// iPHOTOS.PRO - Database Repositories with Parameterized Queries
use crate::assets::PhotoAsset;
use crate::database::Database;
use crate::error::Result;
use rusqlite::params;

pub struct AssetRepository<'a> {
    db: &'a Database,
}

impl<'a> AssetRepository<'a> {
    pub fn new(db: &'a Database) -> Self {
        Self { db }
    }

    pub fn insert(&self, asset: &PhotoAsset) -> Result<()> {
        self.db.with_conn(|conn| {
            conn.execute(
                "INSERT INTO assets (
                    id, filename, original_path, file_size, width, height, mime_type,
                    created_at, modified_at, sha256, phash, rating, favorite, hidden
                ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14);",
                params![
                    asset.id,
                    asset.filename,
                    asset.original_path,
                    asset.file_size as i64,
                    asset.width as i64,
                    asset.height as i64,
                    asset.mime_type,
                    asset.created_at,
                    asset.modified_at,
                    asset.sha256,
                    asset.phash,
                    asset.rating as i64,
                    if asset.favorite { 1 } else { 0 },
                    if asset.hidden { 1 } else { 0 },
                ],
            )?;
            Ok(())
        })
    }

    pub fn get_by_id(&self, id: &str) -> Result<Option<PhotoAsset>> {
        self.db.with_conn(|conn| {
            let mut stmt = conn.prepare(
                "SELECT id, filename, original_path, file_size, width, height, mime_type,
                        created_at, modified_at, sha256, phash, rating, favorite, hidden
                 FROM assets WHERE id = ?1",
            )?;
            let mut rows = stmt.query(params![id])?;
            if let Some(row) = rows.next()? {
                let favorite_int: i64 = row.get(12)?;
                let hidden_int: i64 = row.get(13)?;
                Ok(Some(PhotoAsset {
                    id: row.get(0)?,
                    filename: row.get(1)?,
                    original_path: row.get(2)?,
                    file_size: row.get::<_, i64>(3)? as u64,
                    width: row.get::<_, i64>(4)? as u32,
                    height: row.get::<_, i64>(5)? as u32,
                    mime_type: row.get(6)?,
                    created_at: row.get(7)?,
                    modified_at: row.get(8)?,
                    sha256: row.get(9)?,
                    phash: row.get(10)?,
                    rating: row.get::<_, i64>(11)? as u8,
                    favorite: favorite_int != 0,
                    hidden: hidden_int != 0,
                }))
            } else {
                Ok(None)
            }
        })
    }

    pub fn update_rating(&self, id: &str, rating: u8) -> Result<()> {
        self.db.with_conn(|conn| {
            conn.execute("UPDATE assets SET rating = ?1 WHERE id = ?2", params![rating as i64, id])?;
            Ok(())
        })
    }

    pub fn toggle_favorite(&self, id: &str, favorite: bool) -> Result<()> {
        self.db.with_conn(|conn| {
            conn.execute(
                "UPDATE assets SET favorite = ?1 WHERE id = ?2",
                params![if favorite { 1 } else { 0 }, id],
            )?;
            Ok(())
        })
    }

    pub fn list_paginated(&self, offset: usize, limit: usize) -> Result<Vec<PhotoAsset>> {
        self.db.with_conn(|conn| {
            let mut stmt = conn.prepare(
                "SELECT id, filename, original_path, file_size, width, height, mime_type,
                        created_at, modified_at, sha256, phash, rating, favorite, hidden
                 FROM assets WHERE hidden = 0
                 ORDER BY created_at DESC
                 LIMIT ?1 OFFSET ?2",
            )?;
            let rows = stmt.query_map(params![limit as i64, offset as i64], |row| {
                let favorite_int: i64 = row.get(12)?;
                let hidden_int: i64 = row.get(13)?;
                Ok(PhotoAsset {
                    id: row.get(0)?,
                    filename: row.get(1)?,
                    original_path: row.get(2)?,
                    file_size: row.get::<_, i64>(3)? as u64,
                    width: row.get::<_, i64>(4)? as u32,
                    height: row.get::<_, i64>(5)? as u32,
                    mime_type: row.get(6)?,
                    created_at: row.get(7)?,
                    modified_at: row.get(8)?,
                    sha256: row.get(9)?,
                    phash: row.get(10)?,
                    rating: row.get::<_, i64>(11)? as u8,
                    favorite: favorite_int != 0,
                    hidden: hidden_int != 0,
                })
            })?;

            let mut assets = Vec::new();
            for r in rows {
                assets.push(r?);
            }
            Ok(assets)
        })
    }

    pub fn total_count(&self) -> Result<usize> {
        self.db.with_conn(|conn| {
            let count: i64 = conn.query_row("SELECT COUNT(*) FROM assets WHERE hidden = 0", [], |r| r.get(0))?;
            Ok(count as usize)
        })
    }
}
