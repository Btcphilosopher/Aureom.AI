// iPHOTOS.PRO - Exact SHA-256 Duplicate Detector
use crate::assets::PhotoAsset;
use crate::database::Database;
use crate::error::Result;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DuplicateGroup {
    pub group_id: String,
    pub similarity: f32,
    pub match_type: String,
    pub asset_ids: Vec<String>,
}

pub struct ExactDuplicateDetector;

impl ExactDuplicateDetector {
    pub fn find_exact_duplicates(db: &Database) -> Result<Vec<DuplicateGroup>> {
        db.with_conn(|conn| {
            let mut stmt = conn.prepare(
                "SELECT sha256, GROUP_CONCAT(id) as ids, COUNT(*) as cnt
                 FROM assets
                 GROUP BY sha256
                 HAVING cnt > 1",
            )?;

            let rows = stmt.query_map([], |row| {
                let sha256: String = row.get(0)?;
                let ids_str: String = row.get(1)?;
                let asset_ids: Vec<String> = ids_str.split(',').map(|s| s.to_string()).collect();
                Ok(DuplicateGroup {
                    group_id: format!("exact-{}", &sha256[..8]),
                    similarity: 1.0,
                    match_type: "EXACT_SHA256".into(),
                    asset_ids,
                })
            })?;

            let mut groups = Vec::new();
            for r in rows {
                groups.push(r?);
            }
            Ok(groups)
        })
    }
}
