// iPHOTOS.PRO - Perceptual Hash Engine (Section 16 of spec)
use crate::error::Result;
use image::DynamicImage;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HashAlgorithm {
    AHash, // Average Hash
    DHash, // Difference Hash
    PHash, // Perceptual DCT Hash
}

pub struct PerceptualHashEngine;

impl PerceptualHashEngine {
    /// Computes 64-bit perceptual hash for similarity comparison
    pub fn compute_phash(img: &DynamicImage) -> Result<String> {
        let grayscale = img.to_luma8();
        let resized = image::imageops::resize(&grayscale, 8, 8, image::imageops::FilterType::Nearest);
        
        let mut sum: u64 = 0;
        let mut pixels = Vec::with_capacity(64);
        for p in resized.pixels() {
            let val = p[0] as u64;
            sum += val;
            pixels.push(val);
        }
        let avg = sum / 64;

        let mut hash: u64 = 0;
        for (i, &val) in pixels.iter().enumerate() {
            if val >= avg {
                hash |= 1 << i;
            }
        }

        Ok(format!("0x{:016x}", hash))
    }

    /// Computes Hamming distance between two 64-bit perceptual hash strings
    pub fn hamming_distance(hash_a: &str, hash_b: &str) -> u32 {
        let a = u64::from_str_radix(hash_a.trim_start_matches("0x"), 16).unwrap_or(0);
        let b = u64::from_str_radix(hash_b.trim_start_matches("0x"), 16).unwrap_or(0);
        (a ^ b).count_ones()
    }

    /// Returns similarity normalized from 0.0 (completely different) to 1.0 (identical)
    pub fn similarity(hash_a: &str, hash_b: &str) -> f32 {
        let dist = Self::hamming_distance(hash_a, hash_b);
        (64.0 - dist as f32) / 64.0
    }
}
