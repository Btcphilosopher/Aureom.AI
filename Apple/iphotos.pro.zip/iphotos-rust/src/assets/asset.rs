// iPHOTOS.PRO - Rust Asset Struct (Section 12 of spec)
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PhotoAsset {
    pub id: String,
    pub filename: String,
    pub original_path: String,
    pub file_size: u64,
    pub width: u32,
    pub height: u32,
    pub mime_type: String,
    pub created_at: i64,
    pub modified_at: i64,
    pub sha256: String,
    pub phash: Option<String>,
    pub rating: u8,
    pub favorite: bool,
    pub hidden: bool,
}

impl PhotoAsset {
    pub fn is_raw(&self) -> bool {
        let ext = self.filename.split('.').last().unwrap_or("").to_lowercase();
        matches!(
            ext.as_str(),
            "arw" | "cr2" | "cr3" | "nef" | "dng" | "raf" | "orf" | "rw2" | "pef" | "3fr"
        )
    }

    pub fn is_video(&self) -> bool {
        self.mime_type.starts_with("video/")
    }

    pub fn megapixels(&self) -> f32 {
        (self.width as f32 * self.height as f32) / 1_000_000.0
    }
}
