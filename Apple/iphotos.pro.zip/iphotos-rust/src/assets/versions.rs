// iPHOTOS.PRO - Non-destructive Versions and Edits
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AssetVersion {
    pub id: String,
    pub asset_id: String,
    pub version_number: u32,
    pub name: String,
    pub created_at: i64,
    pub edit_instructions: Vec<EditInstruction>,
    pub preview_cache_key: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EditInstruction {
    pub operation: String,
    pub parameters: serde_json::Value,
}
