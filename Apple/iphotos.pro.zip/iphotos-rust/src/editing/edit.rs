// iPHOTOS.PRO - Non-Destructive Edit Pipeline
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct EditState {
    pub exposure: f32,    // -3.0 to +3.0
    pub brightness: f32,  // -100.0 to +100.0
    pub contrast: f32,    // -100.0 to +100.0
    pub saturation: f32,  // -100.0 to +100.0
    pub temperature: f32, // -100.0 to +100.0 (Kelvin shift)
    pub tint: f32,        // -100.0 to +100.0
    pub highlights: f32,  // -100.0 to +100.0
    pub shadows: f32,     // -100.0 to +100.0
    pub clarity: f32,     // 0.0 to 100.0
    pub vignette: f32,    // 0.0 to 100.0
    pub rotation: i32,    // 0, 90, 180, 270
}

impl Default for EditState {
    fn default() -> Self {
        Self {
            exposure: 0.0,
            brightness: 0.0,
            contrast: 0.0,
            saturation: 0.0,
            temperature: 0.0,
            tint: 0.0,
            highlights: 0.0,
            shadows: 0.0,
            clarity: 0.0,
            vignette: 0.0,
            rotation: 0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum EditOperation {
    Exposure(f32),
    Brightness(f32),
    Contrast(f32),
    Saturation(f32),
    Temperature(f32),
    Rotate(i32),
    Crop { x: u32, y: u32, width: u32, height: u32 },
}
