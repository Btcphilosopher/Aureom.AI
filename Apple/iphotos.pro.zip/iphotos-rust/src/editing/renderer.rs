// iPHOTOS.PRO - Real-time Preview Rendering Engine with Rayon Parallelism
use crate::editing::edit::EditState;
use crate::error::Result;
use image::{DynamicImage, GenericImageView, ImageBuffer, Rgba};
use rayon::prelude::*;

pub struct EditRenderer;

impl EditRenderer {
    /// Renders live non-destructive preview by applying math transformations in parallel
    pub fn render_preview(source_image: &DynamicImage, edits: &EditState) -> Result<DynamicImage> {
        let (width, height) = source_image.dimensions();
        let rgba_orig = source_image.to_rgba8();
        let raw_pixels = rgba_orig.as_raw();

        // Calculate LUT multipliers
        let exp_mult = 2.0f32.powf(edits.exposure);
        let bright_offset = (edits.brightness / 100.0) * 255.0;
        let contrast_factor = (259.0 * ((edits.contrast / 100.0) * 255.0 + 255.0))
            / (255.0 * (259.0 - (edits.contrast / 100.0) * 255.0));
        let sat_factor = 1.0 + (edits.saturation / 100.0);
        let temp_k = edits.temperature / 100.0;

        let mut output_raw = vec![0u8; (width * height * 4) as usize];

        output_raw
            .par_chunks_exact_mut(4)
            .enumerate()
            .for_each(|(i, pixel_out)| {
                let in_idx = i * 4;
                let mut r = raw_pixels[in_idx] as f32;
                let mut g = raw_pixels[in_idx + 1] as f32;
                let mut b = raw_pixels[in_idx + 2] as f32;
                let a = raw_pixels[in_idx + 3];

                // 1. Exposure
                r *= exp_mult;
                g *= exp_mult;
                b *= exp_mult;

                // 2. Brightness
                r += bright_offset;
                g += bright_offset;
                b += bright_offset;

                // 3. Contrast
                r = contrast_factor * (r - 128.0) + 128.0;
                g = contrast_factor * (g - 128.0) + 128.0;
                b = contrast_factor * (b - 128.0) + 128.0;

                // 4. Temperature shift
                if temp_k > 0.0 {
                    r += temp_k * 30.0;
                    b -= temp_k * 30.0;
                } else if temp_k < 0.0 {
                    r += temp_k * 30.0;
                    b -= temp_k * 30.0;
                }

                // 5. Saturation
                let gray = 0.2989 * r + 0.5870 * g + 0.1140 * b;
                r = gray + (r - gray) * sat_factor;
                g = gray + (g - gray) * sat_factor;
                b = gray + (b - gray) * sat_factor;

                pixel_out[0] = r.clamp(0.0, 255.0) as u8;
                pixel_out[1] = g.clamp(0.0, 255.0) as u8;
                pixel_out[2] = b.clamp(0.0, 255.0) as u8;
                pixel_out[3] = a;
            });

        let rendered_buf = ImageBuffer::<Rgba<u8>, _>::from_raw(width, height, output_raw)
            .ok_or_else(|| crate::error::PhotoError::Decode("Failed to construct image buffer".into()))?;

        let mut output_img = DynamicImage::ImageRgba8(rendered_buf);

        // Apply rotation
        match edits.rotation % 360 {
            90 => output_img = output_img.rotate90(),
            180 => output_img = output_img.rotate180(),
            270 => output_img = output_img.rotate270(),
            _ => {}
        }

        Ok(output_img)
    }
}
