'use client';

import React from 'react';
import { MediaItem } from '@/types/media';
import { mediaDatabase } from '@/lib/media-database';
import { formatDuration, formatFileSize } from '@/lib/timecode';
import {
  BarChart3,
  PieChart,
  HardDrive,
  Cpu,
  Tv,
  Music,
  CheckCircle2,
  Layers,
  Activity,
  Zap,
} from 'lucide-react';

interface AnalyticsDashboardViewProps {
  mediaLibrary: MediaItem[];
}

export const AnalyticsDashboardView: React.FC<AnalyticsDashboardViewProps> = ({
  mediaLibrary,
}) => {
  const report = mediaDatabase.generateHealthReport();

  return (
    <div id="analytics-dashboard-view" className="flex flex-col h-full bg-slate-950 text-slate-200 select-none p-6 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-sky-950/60 border border-sky-800 text-sky-400 rounded-lg">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">PRODUCTION ANALYTICS & HEALTH MONITOR</h1>
            <p className="text-xs text-slate-400">
              Media Stream Quality, Storage Capacity & macOS Hardware Acceleration
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-emerald-400">
          <CheckCircle2 className="w-4 h-4" />
          <span>System Engine Status: Optimal</span>
        </div>
      </div>

      {/* KPI Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Total Media Assets</span>
          <p className="text-2xl font-bold font-mono text-sky-400">{report.totalFiles} Videos</p>
          <span className="text-[10px] text-slate-500">Indexed in SQLite schema</span>
        </div>

        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Total Footage Runtime</span>
          <p className="text-2xl font-bold font-mono text-emerald-400">{formatDuration(report.totalDurationSec)}</p>
          <span className="text-[10px] text-slate-500">Continuous playback</span>
        </div>

        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Storage Footprint</span>
          <p className="text-2xl font-bold font-mono text-amber-400">{formatFileSize(report.totalStorageBytes)}</p>
          <span className="text-[10px] text-slate-500">APFS disk capacity</span>
        </div>

        <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400">Asset Health Score</span>
          <p className="text-2xl font-bold font-mono text-emerald-400">
            {Math.round((report.healthyCount / Math.max(1, report.totalFiles)) * 100)}%
          </p>
          <span className="text-[10px] text-slate-500">{report.healthyCount} verified online</span>
        </div>
      </div>

      {/* Distribution Charts & Hardware Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
        {/* Codec & Resolution Distribution */}
        <div className="p-5 bg-slate-900 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-200 border-b border-slate-800 pb-2">
            <PieChart className="w-4 h-4 text-sky-400" />
            <span>FORMAT & RESOLUTION COMPOSITION</span>
          </div>

          {/* Resolution Breakdown */}
          <div className="space-y-2 text-xs">
            <span className="text-slate-400 font-semibold block">Resolution Distribution</span>
            {Object.entries(report.resolutionBreakdown).map(([res, count]) => {
              const pct = Math.round((count / report.totalFiles) * 100);
              return (
                <div key={res} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-300">{res}</span>
                    <span className="font-mono text-sky-400">{count} files ({pct}%)</span>
                  </div>
                  <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden">
                    <div className="h-full bg-sky-500 rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Codec Breakdown */}
          <div className="space-y-2 text-xs pt-2 border-t border-slate-800">
            <span className="text-slate-400 font-semibold block">Codec Distribution</span>
            {Object.entries(report.codecBreakdown).map(([codec, count]) => {
              const pct = Math.round((count / report.totalFiles) * 100);
              return (
                <div key={codec} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-slate-300">{codec}</span>
                    <span className="font-mono text-amber-400">{count} files ({pct}%)</span>
                  </div>
                  <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden">
                    <div className="h-full bg-amber-500 rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* macOS Native Hardware Acceleration Readiness */}
        <div className="p-5 bg-slate-900 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center space-x-2 text-xs font-bold text-slate-200 border-b border-slate-800 pb-2">
            <Cpu className="w-4 h-4 text-emerald-400" />
            <span>NATIVE HARDWARE ACCELERATION ENGINE</span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-bold text-slate-200 block">Apple VideoToolbox Hardware Decoder</span>
                <span className="text-[11px] text-slate-400">ProRes RAW, HEVC 10-bit, H.264 Acceleration</span>
              </div>
              <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-400 text-[10px] font-mono rounded font-bold">
                ENGAGED
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-bold text-slate-200 block">Metal 3 GPU Shaders & Video Scopes</span>
                <span className="text-[11px] text-slate-400">Real-time Waveform, Vectorscope & Histogram</span>
              </div>
              <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-400 text-[10px] font-mono rounded font-bold">
                ENGAGED
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-bold text-slate-200 block">ScreenCaptureKit Native Framework</span>
                <span className="text-[11px] text-slate-400">Ultra low latency display & window streaming</span>
              </div>
              <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-400 text-[10px] font-mono rounded font-bold">
                READY
              </span>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="font-bold text-slate-200 block">Core Audio Multi-Channel Graph</span>
                <span className="text-[11px] text-slate-400">Sample-accurate stereo metering & calibration</span>
              </div>
              <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-400 text-[10px] font-mono rounded font-bold">
                ACTIVE
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
