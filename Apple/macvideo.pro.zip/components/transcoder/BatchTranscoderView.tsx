'use client';

import React, { useState, useEffect } from 'react';
import { MediaItem, TranscodeJob, TranscodePreset, VideoCodec } from '@/types/media';
import { calculateEstimatedSize, formatDuration, formatFileSize } from '@/lib/timecode';
import {
  RefreshCw,
  Plus,
  Play,
  Pause,
  Trash2,
  CheckCircle2,
  HardDrive,
  Cpu,
  Layers,
  Download,
  AlertCircle,
  FileVideo,
  Sliders,
} from 'lucide-react';

interface BatchTranscoderViewProps {
  mediaLibrary: MediaItem[];
  jobs: TranscodeJob[];
  setJobs: React.Dispatch<React.SetStateAction<TranscodeJob[]>>;
  activeMedia: MediaItem | null;
}

export const BatchTranscoderView: React.FC<BatchTranscoderViewProps> = ({
  mediaLibrary,
  jobs,
  setJobs,
  activeMedia,
}) => {
  const [selectedMediaId, setSelectedMediaId] = useState<string>(activeMedia?.id || mediaLibrary[0]?.id || '');
  const [selectedPreset, setSelectedPreset] = useState<TranscodePreset['name']>('Apple ProRes 422 HQ (Broadcast Master)');
  const [targetCodec, setTargetCodec] = useState<'ProRes 422 HQ' | 'ProRes 4444' | 'HEVC (H.265)' | 'H.264 / AVC' | 'VP9'>('ProRes 422 HQ');
  const [targetResolution, setTargetResolution] = useState<'3840x2160' | '1920x1080' | '1280x720' | '1080x1920'>('3840x2160');
  const [targetBitrateMbps, setTargetBitrateMbps] = useState<number>(45);
  const [targetFps, setTargetFps] = useState<number>(60);
  const [hardwareAcceleration, setHardwareAcceleration] = useState<boolean>(true);

  const selectedItem = mediaLibrary.find((m) => m.id === selectedMediaId) || mediaLibrary[0];
  const durationSec = selectedItem?.duration || 60;
  const estimatedSizeMb = calculateEstimatedSize(durationSec, targetBitrateMbps);

  // Auto-progress transcode simulator
  useEffect(() => {
    const interval = setInterval(() => {
      setJobs((prevJobs) =>
        prevJobs.map((job) => {
          if (job.status === 'transcoding') {
            const nextProg = job.progress + 4;
            if (nextProg >= 100) {
              return { ...job, progress: 100, status: 'completed', estimatedTimeSec: 0 };
            }
            return {
              ...job,
              progress: nextProg,
              estimatedTimeSec: Math.max(0, Math.round((100 - nextProg) * 0.3)),
            };
          }
          return job;
        })
      );
    }, 500);

    return () => clearInterval(interval);
  }, [setJobs]);

  // Add Job to Queue
  const handleAddJob = () => {
    if (!selectedItem) return;

    let resCategory: TranscodeJob['targetResolution'] = '1080p (1920x1080)';
    if (targetResolution === '3840x2160') resCategory = '4K (3840x2160)';
    else if (targetResolution === '1280x720') resCategory = '720p (1280x720)';

    let mappedCodec: VideoCodec = 'H.264 / AVC';
    if (targetCodec === 'ProRes 422 HQ') mappedCodec = 'Apple ProRes 422 HQ';
    else if (targetCodec === 'ProRes 4444') mappedCodec = 'Apple ProRes 4444';
    else if (targetCodec === 'HEVC (H.265)') mappedCodec = 'HEVC / H.265';
    else if (targetCodec === 'VP9') mappedCodec = 'VP9';

    const newJob: TranscodeJob = {
      id: `job-${selectedItem.id}-${jobs.length + 1}`,
      sourceMediaId: selectedItem.id,
      sourceName: selectedItem.name,
      destinationName: `${selectedItem.name.replace(/\.[^/.]+$/, '')}_${mappedCodec.replace(/\s+/g, '_')}.${mappedCodec.includes('ProRes') ? 'mov' : 'mp4'}`,
      targetFormat: mappedCodec.includes('ProRes') ? 'QuickTime MOV (.mov)' : 'MPEG-4 (.mp4)',
      targetCodec: mappedCodec,
      targetResolution: resCategory,
      targetFps,
      targetBitrateMbps,
      targetAudioCodec: 'AAC',
      progress: 0,
      status: 'queued',
      estimatedSizeMB: estimatedSizeMb,
      estimatedTimeSec: Math.round(durationSec * 0.4),
      createdAt: 'Queued',
    };

    setJobs([newJob, ...jobs]);
  };

  // Start job
  const handleStartJob = (id: string) => {
    setJobs(jobs.map((j) => (j.id === id ? { ...j, status: 'transcoding' } : j)));
  };

  // Pause job
  const handlePauseJob = (id: string) => {
    setJobs(jobs.map((j) => (j.id === id ? { ...j, status: 'paused' } : j)));
  };

  // Delete job
  const handleDeleteJob = (id: string) => {
    setJobs(jobs.filter((j) => j.id !== id));
  };

  return (
    <div id="batch-transcoder-view" className="flex flex-col h-full bg-[#121212] text-[#E0E0E0] select-none p-6 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-center pb-4 border-b border-[#2A2A2A]">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-[#2A2A2A] border border-[#333333] text-[#007AFF] rounded-lg">
            <RefreshCw className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-[#E0E0E0]">BATCH TRANSCODER & HARDWARE EXPORTER</h1>
            <p className="text-xs text-[#888888]">
              Apple VideoToolbox Native Acceleration & Pro Codec Profiles
            </p>
          </div>
        </div>

        {/* Available disk space indicator */}
        <div className="flex items-center space-x-2 text-xs bg-[#1E1E1E] border border-[#2A2A2A] px-3 py-1.5 rounded-lg">
          <HardDrive className="w-4 h-4 text-[#27C93F]" />
          <span>Available Storage: <strong className="text-[#E0E0E0]">482.4 GB APFS</strong></span>
        </div>
      </div>

      {/* Main 2-Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6 flex-1">
        {/* Left Column: Job Configuration & Presets */}
        <div className="p-5 bg-[#181818] rounded-xl border border-[#2A2A2A] space-y-4">
          <div className="flex items-center space-x-2 text-xs font-bold text-[#E0E0E0] pb-2 border-b border-[#2A2A2A]">
            <Sliders className="w-4 h-4 text-[#007AFF]" />
            <span>EXPORT CONFIGURATION</span>
          </div>

          {/* Source Media Selection */}
          <div>
            <label className="text-[11px] text-[#888888] block mb-1">Source Video Asset</label>
            <select
              value={selectedMediaId}
              onChange={(e) => setSelectedMediaId(e.target.value)}
              className="w-full bg-[#2A2A2A] border border-[#333333] rounded px-2.5 py-1.5 text-xs text-[#E0E0E0] focus:border-[#007AFF]"
            >
              {mediaLibrary.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} ({formatDuration(m.duration)})
                </option>
              ))}
            </select>
          </div>

          {/* Transcode Preset Picker */}
          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Mastering Preset</label>
            <select
              value={selectedPreset}
              onChange={(e) => {
                const name = e.target.value as TranscodePreset['name'];
                setSelectedPreset(name);
                if (name.includes('ProRes 422')) {
                  setTargetCodec('ProRes 422 HQ');
                  setTargetBitrateMbps(45);
                  setTargetResolution('3840x2160');
                } else if (name.includes('4K Master')) {
                  setTargetCodec('HEVC (H.265)');
                  setTargetBitrateMbps(28);
                  setTargetResolution('3840x2160');
                } else if (name.includes('Social 9:16')) {
                  setTargetCodec('H.264 / AVC');
                  setTargetBitrateMbps(14);
                  setTargetResolution('1080x1920');
                } else {
                  setTargetCodec('H.264 / AVC');
                  setTargetBitrateMbps(12);
                  setTargetResolution('1920x1080');
                }
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500"
            >
              <option value="Apple ProRes 422 HQ (Broadcast Master)">Apple ProRes 422 HQ (Broadcast Master)</option>
              <option value="HEVC 4K Master 10-bit HDR">HEVC 4K Master 10-bit HDR</option>
              <option value="H.264 Web 1080p High Profile">H.264 Web 1080p High Profile</option>
              <option value="Social 9:16 Vertical 1080p 60fps">Social 9:16 Vertical 1080p 60fps</option>
            </select>
          </div>

          {/* Target Codec */}
          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Video Codec Engine</label>
            <select
              value={targetCodec}
              onChange={(e) => setTargetCodec(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500"
            >
              <option value="ProRes 422 HQ">Apple ProRes 422 HQ</option>
              <option value="ProRes 4444">Apple ProRes 4444 (RGBA)</option>
              <option value="HEVC (H.265)">HEVC / H.265 10-bit</option>
              <option value="H.264 / AVC">H.264 / AVC (Standard)</option>
              <option value="VP9">VP9 (Open Source)</option>
            </select>
          </div>

          {/* Resolution & FPS */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Resolution</label>
              <select
                value={targetResolution}
                onChange={(e) => setTargetResolution(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500"
              >
                <option value="3840x2160">3840 × 2160 (4K)</option>
                <option value="1920x1080">1920 × 1080 (1080p)</option>
                <option value="1280x720">1280 × 720 (720p)</option>
                <option value="1080x1920">1080 × 1920 (9:16)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Frame Rate</label>
              <select
                value={targetFps}
                onChange={(e) => setTargetFps(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500"
              >
                <option value={60}>60 fps</option>
                <option value={30}>30 fps</option>
                <option value={24}>24 fps</option>
              </select>
            </div>
          </div>

          {/* Target Bitrate Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px]">
              <span className="text-slate-400">Target Bitrate</span>
              <span className="font-mono text-sky-400 font-bold">{targetBitrateMbps} Mbps</span>
            </div>
            <input
              type="range"
              min="2"
              max="100"
              step="1"
              value={targetBitrateMbps}
              onChange={(e) => setTargetBitrateMbps(Number(e.target.value))}
              className="w-full h-1 bg-slate-800 rounded accent-sky-500 cursor-pointer"
            />
          </div>

          {/* Hardware acceleration */}
          <label className="flex items-center space-x-2 text-xs text-slate-300 pt-1 cursor-pointer">
            <input
              type="checkbox"
              checked={hardwareAcceleration}
              onChange={(e) => setHardwareAcceleration(e.target.checked)}
              className="rounded border-slate-700 text-sky-500"
            />
            <span>Enable VideoToolbox Hardware Encoder</span>
          </label>

          {/* Estimated Output Size Banner */}
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1">
            <div className="flex justify-between">
              <span className="text-slate-400">Duration</span>
              <span className="font-mono">{formatDuration(durationSec)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Est. Output File Size</span>
              <span className="font-mono text-emerald-400 font-bold">
                {estimatedSizeMb > 1024 ? `${(estimatedSizeMb / 1024).toFixed(2)} GB` : `${Math.round(estimatedSizeMb)} MB`}
              </span>
            </div>
          </div>

          {/* Add to Queue Button */}
          <button
            onClick={handleAddJob}
            className="w-full py-2.5 bg-gradient-to-r from-sky-600 to-sky-500 hover:from-sky-500 hover:to-sky-400 text-white font-bold rounded-xl shadow-lg transition flex items-center justify-center space-x-2 text-xs"
          >
            <Plus className="w-4 h-4" />
            <span>ADD TO TRANSCODE QUEUE</span>
          </button>
        </div>

        {/* Right 2 Columns: Live Transcode Queue */}
        <div className="lg:col-span-2 flex flex-col space-y-4">
          <div className="flex justify-between items-center text-xs font-bold text-slate-300">
            <span>ACTIVE TRANSCODE QUEUE ({jobs.length} jobs)</span>
            <span className="text-slate-400 font-normal">VideoToolbox Hardware Dec/Enc</span>
          </div>

          {jobs.length === 0 ? (
            <div className="flex-1 bg-slate-900/40 rounded-2xl border border-slate-800 flex flex-col items-center justify-center p-8 text-slate-500 space-y-2 min-h-[300px]">
              <RefreshCw className="w-8 h-8 opacity-40" />
              <p className="text-sm">Queue is empty. Add a transcode job to begin processing.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {jobs.map((job) => (
                <div
                  key={job.id}
                  className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-3 shadow-md"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-xs text-slate-200">{job.sourceName}</span>
                        <span className="text-[10px] px-1.5 py-0.5 bg-slate-800 rounded text-sky-400 font-mono">
                          {job.targetCodec}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Target: {job.targetResolution} @ {job.targetFps}fps ({job.targetBitrateMbps} Mbps) • Est. {Math.round(job.estimatedSizeMB)} MB
                      </p>
                    </div>

                    <div className="flex items-center space-x-2">
                      {job.status === 'queued' && (
                        <button
                          onClick={() => handleStartJob(job.id)}
                          className="p-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded shadow transition"
                          title="Start Encoding"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                        </button>
                      )}

                      {job.status === 'transcoding' && (
                        <button
                          onClick={() => handlePauseJob(job.id)}
                          className="p-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded shadow transition"
                          title="Pause Encoding"
                        >
                          <Pause className="w-3.5 h-3.5 fill-current" />
                        </button>
                      )}

                      <button
                        onClick={() => handleDeleteJob(job.id)}
                        className="p-1.5 bg-slate-800 hover:bg-red-900/60 border border-slate-700 text-slate-400 hover:text-red-300 rounded transition"
                        title="Remove Job"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Progress Bar & Status */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-mono">
                      <span className={`${job.status === 'completed' ? 'text-emerald-400' : job.status === 'transcoding' ? 'text-sky-400' : 'text-slate-400'}`}>
                        {job.status.toUpperCase()} {job.status === 'transcoding' ? `(${job.progress}%)` : ''}
                      </span>
                      {job.status === 'transcoding' && (
                        <span className="text-slate-400">ETA: {job.estimatedTimeSec}s</span>
                      )}
                      {job.status === 'completed' && (
                        <span className="text-emerald-400 flex items-center space-x-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>100% Ready</span>
                        </span>
                      )}
                    </div>

                    <div className="h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      <div
                        className={`h-full transition-all duration-300 ${
                          job.status === 'completed'
                            ? 'bg-emerald-500'
                            : 'bg-gradient-to-r from-sky-500 to-sky-400'
                        }`}
                        style={{ width: `${job.progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
