'use client';

import React, { useState, useEffect, useRef } from 'react';
import { MediaItem } from '@/types/media';
import { recorderEngine, RecorderOptions } from '@/lib/recorder-engine';
import { formatSMPTETimecode, formatDuration } from '@/lib/timecode';
import {
  Disc,
  Video,
  Mic,
  Monitor,
  Camera,
  Square,
  Play,
  CheckCircle2,
  AlertCircle,
  Activity,
  HardDrive,
  Settings2,
} from 'lucide-react';

interface StudioRecorderViewProps {
  onRecordingComplete: (item: MediaItem) => void;
  onOpenInPlayer: (item: MediaItem) => void;
}

export const StudioRecorderView: React.FC<StudioRecorderViewProps> = ({
  onRecordingComplete,
  onOpenInPlayer,
}) => {
  const [recordType, setRecordType] = useState<'screen' | 'camera' | 'audio'>('screen');
  const [isRecording, setIsRecording] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);
  const [liveAudioDb, setLiveAudioDb] = useState(-60);

  // Settings
  const [includeMic, setIncludeMic] = useState(true);
  const [includeSystemAudio, setIncludeSystemAudio] = useState(true);
  const [resolution, setResolution] = useState<'4K' | '1080p' | '720p'>('1080p');
  const [frameRate, setFrameRate] = useState<60 | 30 | 24>(60);
  const [videoCodec, setVideoCodec] = useState<'vp9' | 'h264' | 'vp8'>('vp9');

  // Device lists
  const [audioDevices, setAudioDevices] = useState<MediaDeviceInfo[]>([]);
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedAudioId, setSelectedAudioId] = useState<string>('');
  const [selectedVideoId, setSelectedVideoId] = useState<string>('');

  // Last finished recording
  const [lastRecording, setLastRecording] = useState<MediaItem | null>(null);
  const [recordError, setRecordError] = useState<string | null>(null);

  // Live video preview ref
  const livePreviewRef = useRef<HTMLVideoElement | null>(null);

  // Load available devices
  useEffect(() => {
    recorderEngine.getAvailableDevices().then(({ audioInputs, videoInputs }) => {
      setAudioDevices(audioInputs);
      setVideoDevices(videoInputs);
      if (audioInputs.length > 0) setSelectedAudioId(audioInputs[0].deviceId);
      if (videoInputs.length > 0) setSelectedVideoId(videoInputs[0].deviceId);
    });
  }, []);

  // Duration timer & audio level polling during recording
  useEffect(() => {
    let interval: NodeJS.Timeout;
    let audioPoller: NodeJS.Timeout;

    if (isRecording) {
      interval = setInterval(() => {
        setRecordDuration((d) => d + 1);
      }, 1000);

      audioPoller = setInterval(() => {
        const db = recorderEngine.getLiveAudioDb();
        setLiveAudioDb(db);
      }, 100);
    }

    return () => {
      clearInterval(interval);
      clearInterval(audioPoller);
    };
  }, [isRecording]);

  // Start recording handler
  const handleStart = async () => {
    setRecordError(null);
    try {
      const options: RecorderOptions = {
        type: recordType,
        includeMic,
        includeSystemAudio,
        videoResolution: resolution,
        frameRate,
        videoCodec,
        selectedAudioDeviceId: selectedAudioId,
        selectedVideoDeviceId: selectedVideoId,
      };

      const stream = await recorderEngine.startRecording(options);

      if (livePreviewRef.current && recordType !== 'audio') {
        livePreviewRef.current.srcObject = stream;
        livePreviewRef.current.play().catch(() => {});
      }

      setIsRecording(true);
      setRecordDuration(0);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Permission denied or capture failed';
      setRecordError(msg);
      setIsRecording(false);
    }
  };

  // Stop recording handler
  const handleStop = async () => {
    try {
      const options: RecorderOptions = {
        type: recordType,
        includeMic,
        includeSystemAudio,
        videoResolution: resolution,
        frameRate,
        videoCodec,
      };

      const { mediaItem } = await recorderEngine.stopRecording(options);
      mediaItem.duration = recordDuration || 5;

      if (livePreviewRef.current) {
        livePreviewRef.current.srcObject = null;
      }

      setIsRecording(false);
      setLastRecording(mediaItem);
      onRecordingComplete(mediaItem);
    } catch (err: unknown) {
      setRecordError('Failed to finalize recording container');
      setIsRecording(false);
    }
  };

  return (
    <div id="studio-recorder-view" className="flex flex-col h-full bg-slate-950 text-slate-200 select-none p-6 overflow-y-auto">
      {/* Top Header */}
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-red-950/60 border border-red-800 text-red-400 rounded-lg">
            <Disc className={`w-5 h-5 ${isRecording ? 'animate-pulse' : ''}`} />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">STUDIO RECORDER</h1>
            <p className="text-xs text-slate-400">
              ScreenCaptureKit & Core Audio Hardware Recording
            </p>
          </div>
        </div>

        {/* Recording Status Banner */}
        {isRecording ? (
          <div className="flex items-center space-x-3 px-3 py-1.5 bg-red-950/80 border border-red-600 rounded-lg shadow-lg">
            <div className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
            <span className="text-xs font-mono font-bold text-red-200">
              REC ● {formatSMPTETimecode(recordDuration, frameRate)}
            </span>
          </div>
        ) : (
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <HardDrive className="w-4 h-4 text-sky-400" />
            <span>Direct to SQLite Library</span>
          </div>
        )}
      </div>

      {recordError && (
        <div className="my-3 p-3 bg-red-950/80 border border-red-800 text-red-300 rounded-lg text-xs flex items-center space-x-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{recordError}</span>
        </div>
      )}

      {/* Main Studio Body */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6 flex-1">
        {/* Left 2 Cols: Live Monitor & Mode Selector */}
        <div className="lg:col-span-2 flex flex-col space-y-4">
          {/* Mode Selector Tabs */}
          <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
            <button
              disabled={isRecording}
              onClick={() => setRecordType('screen')}
              className={`flex-1 py-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-2 transition ${
                recordType === 'screen' ? 'bg-sky-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Monitor className="w-4 h-4" />
              <span>Screen Recording (ScreenCaptureKit)</span>
            </button>

            <button
              disabled={isRecording}
              onClick={() => setRecordType('camera')}
              className={`flex-1 py-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-2 transition ${
                recordType === 'camera' ? 'bg-sky-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>FaceTime / Camera</span>
            </button>

            <button
              disabled={isRecording}
              onClick={() => setRecordType('audio')}
              className={`flex-1 py-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-2 transition ${
                recordType === 'audio' ? 'bg-sky-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Mic className="w-4 h-4" />
              <span>Core Audio Only</span>
            </button>
          </div>

          {/* Live Studio Monitor Viewport */}
          <div className="flex-1 min-h-[300px] bg-slate-900/60 rounded-2xl border border-slate-800 relative flex items-center justify-center overflow-hidden p-2">
            {recordType !== 'audio' ? (
              <video
                ref={livePreviewRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full max-h-[360px] object-contain rounded-lg bg-black"
              />
            ) : (
              <div className="flex flex-col items-center justify-center space-y-4 text-slate-400">
                <Mic className={`w-16 h-16 ${isRecording ? 'text-red-400 animate-bounce' : 'text-slate-600'}`} />
                <p className="text-sm font-semibold">Studio Microphone Channel Ready</p>
              </div>
            )}

            {/* Live Audio Level Overlay Bar */}
            {isRecording && (
              <div className="absolute bottom-4 left-4 right-4 bg-slate-950/90 border border-slate-800 rounded-lg p-2 flex items-center space-x-3 backdrop-blur-md">
                <span className="text-[11px] font-mono text-slate-400">MIC LEVEL</span>
                <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-75 ${liveAudioDb > -6 ? 'bg-red-500' : liveAudioDb > -18 ? 'bg-amber-400' : 'bg-emerald-400'}`}
                    style={{ width: `${Math.max(0, ((liveAudioDb + 60) / 60) * 100)}%` }}
                  />
                </div>
                <span className="text-[11px] font-mono text-slate-300 w-12 text-right">{Math.round(liveAudioDb)} dB</span>
              </div>
            )}
          </div>

          {/* Record Control Bar */}
          <div className="flex items-center justify-center space-x-4 pt-2">
            {!isRecording ? (
              <button
                id="btn-start-record"
                onClick={handleStart}
                className="flex items-center space-x-2 px-6 py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow-lg transition active:scale-95"
              >
                <div className="w-3.5 h-3.5 rounded-full bg-white animate-pulse" />
                <span>START RECORDING</span>
              </button>
            ) : (
              <button
                id="btn-stop-record"
                onClick={handleStop}
                className="flex items-center space-x-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 font-bold rounded-xl shadow-lg transition active:scale-95"
              >
                <Square className="w-4 h-4 fill-current text-red-500" />
                <span>STOP & SAVE TO DATABASE</span>
              </button>
            )}
          </div>
        </div>

        {/* Right Col: Recording Parameter Config & Last Recording Card */}
        <div className="flex flex-col space-y-4">
          {/* Hardware & Parameter Settings */}
          <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-4">
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-300 pb-2 border-b border-slate-800">
              <Settings2 className="w-4 h-4 text-sky-400" />
              <span>RECORDING PARAMETERS</span>
            </div>

            {/* Target Resolution */}
            {recordType !== 'audio' && (
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Target Resolution</label>
                <select
                  disabled={isRecording}
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value as '4K' | '1080p' | '720p')}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500"
                >
                  <option value="4K">4K Ultra HD (3840 × 2160)</option>
                  <option value="1080p">1080p Full HD (1920 × 1080)</option>
                  <option value="720p">720p HD (1280 × 720)</option>
                </select>
              </div>
            )}

            {/* Target Frame Rate */}
            {recordType !== 'audio' && (
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Capture Frame Rate</label>
                <select
                  disabled={isRecording}
                  value={frameRate}
                  onChange={(e) => setFrameRate(Number(e.target.value) as 60 | 30 | 24)}
                  className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500"
                >
                  <option value={60}>60 fps (Smooth Motion)</option>
                  <option value={30}>30 fps (Standard Web)</option>
                  <option value={24}>24 fps (Cinematic)</option>
                </select>
              </div>
            )}

            {/* Audio Source */}
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Microphone Input</label>
              <select
                disabled={isRecording}
                value={selectedAudioId}
                onChange={(e) => setSelectedAudioId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500 truncate"
              >
                {audioDevices.length > 0 ? (
                  audioDevices.map((d) => (
                    <option key={d.deviceId} value={d.deviceId}>
                      {d.label || `Microphone ${d.deviceId.slice(0, 6)}`}
                    </option>
                  ))
                ) : (
                  <option value="">Default macOS Built-in Mic</option>
                )}
              </select>
            </div>

            {/* Checkboxes */}
            <div className="space-y-2 pt-2 text-xs">
              <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeMic}
                  onChange={(e) => setIncludeMic(e.target.checked)}
                  disabled={isRecording}
                  className="rounded border-slate-700 text-sky-500"
                />
                <span>Include Voice Commentary</span>
              </label>

              {recordType === 'screen' && (
                <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeSystemAudio}
                    onChange={(e) => setIncludeSystemAudio(e.target.checked)}
                    disabled={isRecording}
                    className="rounded border-slate-700 text-sky-500"
                  />
                  <span>Capture macOS System Audio</span>
                </label>
              )}
            </div>
          </div>

          {/* Last Recording Completion Box */}
          {lastRecording && (
            <div className="p-4 bg-emerald-950/40 border border-emerald-800/80 rounded-xl space-y-3">
              <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>RECORDING SAVED TO DATABASE</span>
              </div>
              <p className="text-xs text-slate-300 font-mono truncate">{lastRecording.name}</p>
              <div className="flex space-x-2">
                <button
                  onClick={() => onOpenInPlayer(lastRecording)}
                  className="flex-1 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold flex items-center justify-center space-x-1"
                >
                  <Play className="w-3 h-3" />
                  <span>Open in Player</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
