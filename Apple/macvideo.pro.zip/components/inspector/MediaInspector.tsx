'use client';

import React, { useState } from 'react';
import { MediaItem, VideoColorGrading, PerformanceTelemetry } from '@/types/media';
import { formatFileSize, formatBitrate, formatDuration } from '@/lib/timecode';
import {
  Sliders,
  Tv,
  Music,
  FileCode,
  Tag,
  Gauge,
  Palette,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  Layers,
} from 'lucide-react';

interface MediaInspectorProps {
  media: MediaItem | null;
  onUpdateMetadata: (id: string, metadata: MediaItem['metadata']) => void;
  colorGrading: VideoColorGrading;
  setColorGrading: React.Dispatch<React.SetStateAction<VideoColorGrading>>;
}

export const MediaInspector: React.FC<MediaInspectorProps> = ({
  media,
  onUpdateMetadata,
  colorGrading,
  setColorGrading,
}) => {
  const [activeTab, setActiveTab] = useState<'video' | 'audio' | 'container' | 'metadata' | 'telemetry' | 'color'>('video');
  const [editableMeta, setEditableMeta] = useState(media?.metadata || {
    title: '',
    description: '',
    creator: '',
    copyright: '',
    creationDate: '',
    modificationDate: '',
    keywords: [],
    genre: '',
  });

  const [isSavedBanner, setIsSavedBanner] = useState(false);

  // Default color grading reset
  const resetColorGrading = () => {
    setColorGrading({
      exposure: 0,
      brightness: 0,
      contrast: 0,
      saturation: 0,
      gamma: 1.0,
      temperature: 6500,
      tint: 0,
      vignette: 0,
      blur: 0,
      sharpen: 0,
      highlights: 0,
      shadows: 0,
    });
  };

  const handleSaveMeta = (e: React.FormEvent) => {
    e.preventDefault();
    if (media) {
      onUpdateMetadata(media.id, editableMeta);
      setIsSavedBanner(true);
      setTimeout(() => setIsSavedBanner(false), 2000);
    }
  };

  if (!media) {
    return (
      <div id="media-inspector" className="w-80 bg-slate-900 border-l border-slate-800 p-4 text-slate-500 text-xs flex flex-col items-center justify-center">
        <Sliders className="w-8 h-8 opacity-30 mb-2" />
        <p>No media item selected</p>
      </div>
    );
  }

  const v = media.videoStream;
  const a = media.audioStream;

  return (
    <div
      id="media-inspector"
      className="w-80 lg:w-88 bg-[#181818] border-l border-[#2A2A2A] flex flex-col h-full text-[#E0E0E0] select-none overflow-hidden"
    >
      {/* Header */}
      <div className="h-10 bg-[#1E1E1E] px-3 flex items-center justify-between border-b border-[#2A2A2A]">
        <div className="flex items-center space-x-2">
          <Sliders className="w-3.5 h-3.5 text-[#007AFF]" />
          <span className="font-bold text-xs tracking-wide text-[#E0E0E0]">INSPECTOR</span>
        </div>
        <span className="text-[10px] px-1.5 py-0.5 bg-[#2A2A2A] rounded font-mono text-[#27C93F]">
          {media.healthStatus.toUpperCase()}
        </span>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#2A2A2A] bg-[#151515] overflow-x-auto text-[11px] p-1 gap-1">
        <button
          onClick={() => setActiveTab('video')}
          className={`px-2 py-1 rounded transition flex items-center space-x-1 ${
            activeTab === 'video' ? 'bg-[#007AFF] text-white font-semibold' : 'text-[#AAAAAA] hover:text-[#E0E0E0] hover:bg-[#2A2A2A]'
          }`}
        >
          <Tv className="w-3 h-3" />
          <span>Video</span>
        </button>

        <button
          onClick={() => setActiveTab('audio')}
          className={`px-2 py-1 rounded transition flex items-center space-x-1 ${
            activeTab === 'audio' ? 'bg-[#007AFF] text-white font-semibold' : 'text-[#AAAAAA] hover:text-[#E0E0E0] hover:bg-[#2A2A2A]'
          }`}
        >
          <Music className="w-3 h-3" />
          <span>Audio</span>
        </button>

        <button
          onClick={() => setActiveTab('color')}
          className={`px-2 py-1 rounded transition flex items-center space-x-1 ${
            activeTab === 'color' ? 'bg-[#007AFF] text-white font-semibold' : 'text-[#AAAAAA] hover:text-[#E0E0E0] hover:bg-[#2A2A2A]'
          }`}
        >
          <Palette className="w-3 h-3" />
          <span>Color</span>
        </button>

        <button
          onClick={() => setActiveTab('container')}
          className={`px-2 py-1 rounded transition flex items-center space-x-1 ${
            activeTab === 'container' ? 'bg-[#007AFF] text-white font-semibold' : 'text-[#AAAAAA] hover:text-[#E0E0E0] hover:bg-[#2A2A2A]'
          }`}
        >
          <FileCode className="w-3 h-3" />
          <span>File</span>
        </button>

        <button
          onClick={() => setActiveTab('metadata')}
          className={`px-2 py-1 rounded transition flex items-center space-x-1 ${
            activeTab === 'metadata' ? 'bg-[#007AFF] text-white font-semibold' : 'text-[#AAAAAA] hover:text-[#E0E0E0] hover:bg-[#2A2A2A]'
          }`}
        >
          <Tag className="w-3 h-3" />
          <span>Tags</span>
        </button>

        <button
          onClick={() => setActiveTab('telemetry')}
          className={`px-2 py-1 rounded transition flex items-center space-x-1 ${
            activeTab === 'telemetry' ? 'bg-[#007AFF] text-white font-semibold' : 'text-[#AAAAAA] hover:text-[#E0E0E0] hover:bg-[#2A2A2A]'
          }`}
        >
          <Gauge className="w-3 h-3" />
          <span>Metal</span>
        </button>
      </div>

      {/* Tab Content */}
      <div className="flex-1 p-3 overflow-y-auto text-xs space-y-4">
        {/* VIDEO TAB */}
        {activeTab === 'video' && (
          <div className="space-y-3">
            <div className="p-2.5 bg-[#151515] rounded-lg border border-[#2A2A2A] space-y-2">
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#777777]">Codec</span>
                <span className="font-mono font-semibold text-[#007AFF]">{v?.codec}</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#777777]">Resolution</span>
                <span className="font-mono text-[#E0E0E0]">{v?.width} × {v?.height} ({v?.width && v.width >= 3840 ? '4K UHD' : '1080p'})</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#777777]">Frame Rate</span>
                <span className="font-mono text-[#27C93F]">{v?.fps} fps</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#777777]">Bit Depth</span>
                <span className="font-mono text-[#007AFF]">{v?.bitDepth}-bit</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#777777]">Color Space</span>
                <span className="font-mono text-[#E0E0E0]">{v?.colorSpace}</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#777777]">High Dynamic Range</span>
                <span className="font-mono text-[#E0E0E0]">{v?.hdr ? 'HDR10 / Dolby Vision' : 'SDR (Standard)'}</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2A2A] pb-1">
                <span className="text-[#777777]">Pixel Format</span>
                <span className="font-mono text-[#AAAAAA]">{v?.pixelFormat}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Hardware Acceleration</span>
                <span className="font-mono text-sky-400">VideoToolbox Native</span>
              </div>
            </div>
          </div>
        )}

        {/* AUDIO TAB */}
        {activeTab === 'audio' && (
          <div className="space-y-3">
            <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Audio Codec</span>
                <span className="font-mono font-semibold text-amber-400">{a?.codec}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Sample Rate</span>
                <span className="font-mono">{(a?.sampleRateHz || 48000) / 1000} kHz</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Channels</span>
                <span className="font-mono">{a?.channels} Channels ({a?.channelLayout})</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Bit Depth</span>
                <span className="font-mono">{a?.bitDepth}-bit Integer</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Nominal Bitrate</span>
                <span className="font-mono">{a?.bitrateKbps} kbps</span>
              </div>
            </div>
          </div>
        )}

        {/* CONTAINER & FILE TAB */}
        {activeTab === 'container' && (
          <div className="space-y-3">
            <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">File Name</span>
                <span className="font-mono text-slate-200 truncate max-w-xs">{media.name}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Container Format</span>
                <span className="font-mono text-sky-400">{media.container}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">File Size</span>
                <span className="font-mono">{formatFileSize(media.fileSize)}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Total Duration</span>
                <span className="font-mono">{formatDuration(media.duration)}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Created</span>
                <span className="font-mono text-[10px]">{media.metadata?.creationDate || 'Unknown'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Security Sandbox</span>
                <span className="font-mono text-emerald-400">Security-Scoped Bookmark OK</span>
              </div>
            </div>
          </div>
        )}

        {/* COLOR GRADING & SHADERS TAB */}
        {activeTab === 'color' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center pb-1">
              <span className="font-bold text-slate-300">Metal Real-time Shaders</span>
              <button
                onClick={resetColorGrading}
                className="flex items-center space-x-1 text-[10px] text-slate-400 hover:text-sky-400"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset All</span>
              </button>
            </div>

            {/* Exposure */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Exposure (EV)</span>
                <span className="font-mono">{colorGrading.exposure > 0 ? `+${colorGrading.exposure}` : colorGrading.exposure}</span>
              </div>
              <input
                type="range"
                min="-2"
                max="2"
                step="0.1"
                value={colorGrading.exposure}
                onChange={(e) => setColorGrading((g) => ({ ...g, exposure: Number(e.target.value) }))}
                className="w-full h-1 bg-slate-800 rounded cursor-pointer accent-sky-500"
              />
            </div>

            {/* Brightness */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Brightness</span>
                <span className="font-mono">{colorGrading.brightness}%</span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                step="1"
                value={colorGrading.brightness}
                onChange={(e) => setColorGrading((g) => ({ ...g, brightness: Number(e.target.value) }))}
                className="w-full h-1 bg-slate-800 rounded cursor-pointer accent-sky-500"
              />
            </div>

            {/* Contrast */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Contrast</span>
                <span className="font-mono">{colorGrading.contrast}%</span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                step="1"
                value={colorGrading.contrast}
                onChange={(e) => setColorGrading((g) => ({ ...g, contrast: Number(e.target.value) }))}
                className="w-full h-1 bg-slate-800 rounded cursor-pointer accent-sky-500"
              />
            </div>

            {/* Saturation */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Saturation</span>
                <span className="font-mono">{colorGrading.saturation}%</span>
              </div>
              <input
                type="range"
                min="-100"
                max="100"
                step="1"
                value={colorGrading.saturation}
                onChange={(e) => setColorGrading((g) => ({ ...g, saturation: Number(e.target.value) }))}
                className="w-full h-1 bg-slate-800 rounded cursor-pointer accent-sky-500"
              />
            </div>

            {/* Temperature Kelvin */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Color Temperature</span>
                <span className="font-mono text-amber-400">{colorGrading.temperature} K</span>
              </div>
              <input
                type="range"
                min="3000"
                max="10000"
                step="100"
                value={colorGrading.temperature}
                onChange={(e) => setColorGrading((g) => ({ ...g, temperature: Number(e.target.value) }))}
                className="w-full h-1 bg-slate-800 rounded cursor-pointer accent-amber-500"
              />
            </div>

            {/* Vignette */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Lens Vignette</span>
                <span className="font-mono">{colorGrading.vignette}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="1"
                value={colorGrading.vignette}
                onChange={(e) => setColorGrading((g) => ({ ...g, vignette: Number(e.target.value) }))}
                className="w-full h-1 bg-slate-800 rounded cursor-pointer accent-sky-500"
              />
            </div>

            {/* Blur */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400">Gaussian Blur</span>
                <span className="font-mono">{colorGrading.blur} px</span>
              </div>
              <input
                type="range"
                min="0"
                max="20"
                step="0.5"
                value={colorGrading.blur}
                onChange={(e) => setColorGrading((g) => ({ ...g, blur: Number(e.target.value) }))}
                className="w-full h-1 bg-slate-800 rounded cursor-pointer accent-sky-500"
              />
            </div>
          </div>
        )}

        {/* METADATA EDITOR TAB */}
        {activeTab === 'metadata' && (
          <form onSubmit={handleSaveMeta} className="space-y-3">
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Asset Title</label>
              <input
                type="text"
                value={editableMeta.title}
                onChange={(e) => setEditableMeta({ ...editableMeta, title: e.target.value })}
                className="w-full px-2 py-1 bg-slate-950 border border-slate-800 rounded text-slate-200 text-xs focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Description / Logline</label>
              <textarea
                rows={2}
                value={editableMeta.description}
                onChange={(e) => setEditableMeta({ ...editableMeta, description: e.target.value })}
                className="w-full px-2 py-1 bg-slate-950 border border-slate-800 rounded text-slate-200 text-xs focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Director / Creator</label>
              <input
                type="text"
                value={editableMeta.creator}
                onChange={(e) => setEditableMeta({ ...editableMeta, creator: e.target.value })}
                className="w-full px-2 py-1 bg-slate-950 border border-slate-800 rounded text-slate-200 text-xs focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Genre</label>
              <input
                type="text"
                value={editableMeta.genre || ''}
                onChange={(e) => setEditableMeta({ ...editableMeta, genre: e.target.value })}
                className="w-full px-2 py-1 bg-slate-950 border border-slate-800 rounded text-slate-200 text-xs focus:outline-none focus:border-sky-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded transition text-xs flex items-center justify-center space-x-1"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Save SQLite Metadata</span>
            </button>

            {isSavedBanner && (
              <div className="p-2 bg-emerald-950 border border-emerald-800 text-emerald-300 rounded text-[11px] text-center">
                Metadata updated in SQLite store!
              </div>
            )}
          </form>
        )}

        {/* PERFORMANCE & METAL TELEMETRY TAB */}
        {activeTab === 'telemetry' && (
          <div className="space-y-3">
            <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
              <div className="flex items-center space-x-2 pb-1 border-b border-slate-800 text-sky-400 font-bold">
                <Cpu className="w-4 h-4" />
                <span>Metal 3 GPU Engine</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Live Framerate</span>
                <span className="font-mono text-emerald-400 font-bold">{v?.fps || 60}.0 fps</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Dropped Frames</span>
                <span className="font-mono text-emerald-400">0 (0.00%)</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Decode Latency</span>
                <span className="font-mono">1.2 ms (VideoToolbox)</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Render Latency</span>
                <span className="font-mono">1.8 ms (Metal Compute)</span>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-1">
                <span className="text-slate-400">Streaming RAM Cache</span>
                <span className="font-mono text-sky-400">128 MB (Buffered)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Color Primaries Space</span>
                <span className="font-mono">Wide Color Display P3</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
