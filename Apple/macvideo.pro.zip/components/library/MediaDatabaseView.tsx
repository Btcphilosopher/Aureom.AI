'use client';

import React, { useState } from 'react';
import { MediaItem } from '@/types/media';
import { mediaDatabase } from '@/lib/media-database';
import { formatDuration, formatFileSize } from '@/lib/timecode';
import {
  Database,
  UploadCloud,
  FolderOpen,
  Search,
  Filter,
  Play,
  Copy,
  AlertTriangle,
  CheckCircle2,
  Trash2,
  FileVideo,
  Layers,
  Sparkles,
  Link2,
} from 'lucide-react';

interface MediaDatabaseViewProps {
  mediaList: MediaItem[];
  onSelectMedia: (item: MediaItem) => void;
  onImportFiles: (files: FileList) => void;
  onDeleteMedia: (id: string) => void;
  onRelinkMedia: (id: string, newFile: File) => void;
}

export const MediaDatabaseView: React.FC<MediaDatabaseViewProps> = ({
  mediaList,
  onSelectMedia,
  onImportFiles,
  onDeleteMedia,
  onRelinkMedia,
}) => {
  const [filterCodec, setFilterCodec] = useState<string>('all');
  const [filterHealth, setFilterHealth] = useState<string>('all');
  const [search, setSearch] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'catalog' | 'duplicates' | 'health'>('catalog');
  const [relinkingMediaId, setRelinkingMediaId] = useState<string | null>(null);

  const report = mediaDatabase.generateHealthReport();

  // Filtered media items
  const filteredList = mediaList.filter((item) => {
    if (search && !item.name.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    if (filterCodec !== 'all') {
      const c = item.videoStream?.codec?.toLowerCase() || '';
      if (!c.includes(filterCodec.toLowerCase())) return false;
    }
    if (filterHealth !== 'all' && item.healthStatus !== filterHealth) {
      return false;
    }
    return true;
  });

  // Handle Drag & Drop
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onImportFiles(e.dataTransfer.files);
    }
  };

  return (
    <div id="media-database-view" className="flex flex-col h-full bg-[#121212] text-[#E0E0E0] select-none p-6 overflow-y-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-4 border-b border-[#2A2A2A] gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-[#2A2A2A] border border-[#333333] text-[#007AFF] rounded-lg">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-[#E0E0E0]">MEDIA DATABASE & CATALOG</h1>
            <p className="text-xs text-[#888888]">
              Relational Media Catalog, Duplicate Detection & Health Monitor
            </p>
          </div>
        </div>

        {/* Import Drag / Browse button */}
        <label
          id="btn-import-files-label"
          className="flex items-center space-x-2 px-4 py-2 bg-[#007AFF] hover:bg-[#0069D9] text-white font-semibold rounded-lg shadow cursor-pointer text-xs transition"
        >
          <UploadCloud className="w-4 h-4" />
          <span>Import Videos to Database</span>
          <input
            type="file"
            multiple
            accept="video/*,audio/*"
            onChange={(e) => {
              if (e.target.files) onImportFiles(e.target.files);
            }}
            className="hidden"
          />
        </label>
      </div>

      {/* Database View Tabs */}
      <div className="flex border-b border-[#2A2A2A] space-x-6 mt-4 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('catalog')}
          className={`pb-2.5 transition border-b-2 flex items-center space-x-1.5 ${
            activeTab === 'catalog' ? 'border-[#007AFF] text-[#007AFF]' : 'border-transparent text-[#AAAAAA] hover:text-[#E0E0E0]'
          }`}
        >
          <FileVideo className="w-4 h-4" />
          <span>Catalog ({mediaList.length} items)</span>
        </button>

        <button
          onClick={() => setActiveTab('duplicates')}
          className={`pb-2.5 transition border-b-2 flex items-center space-x-1.5 ${
            activeTab === 'duplicates' ? 'border-[#FFBD2E] text-[#FFBD2E]' : 'border-transparent text-[#AAAAAA] hover:text-[#E0E0E0]'
          }`}
        >
          <Copy className="w-4 h-4" />
          <span>Duplicate Detection ({report.duplicates.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('health')}
          className={`pb-2 transition border-b-2 flex items-center space-x-1.5 ${
            activeTab === 'health' ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Health & Relink Status</span>
        </button>
      </div>

      {/* TAB 1: MAIN CATALOG GRID */}
      {activeTab === 'catalog' && (
        <div className="mt-4 flex flex-col space-y-4">
          {/* Search & Filter Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800">
            <div className="flex items-center space-x-2">
              <Search className="w-4 h-4 text-slate-500" />
              <input
                type="text"
                placeholder="Search by title, keyword..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-sky-500 w-48"
              />
            </div>

            <div className="flex items-center space-x-3 text-xs">
              <div className="flex items-center space-x-1">
                <span className="text-slate-400">Codec:</span>
                <select
                  value={filterCodec}
                  onChange={(e) => setFilterCodec(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-200 focus:border-sky-500"
                >
                  <option value="all">All Codecs</option>
                  <option value="prores">Apple ProRes</option>
                  <option value="hevc">HEVC / H.265</option>
                  <option value="avc">H.264 / AVC</option>
                  <option value="vp9">VP9 / WebM</option>
                </select>
              </div>

              <div className="flex items-center space-x-1">
                <span className="text-slate-400">Health:</span>
                <select
                  value={filterHealth}
                  onChange={(e) => setFilterHealth(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-slate-200 focus:border-sky-500"
                >
                  <option value="all">All Status</option>
                  <option value="healthy">Healthy</option>
                  <option value="warning">Warning</option>
                  <option value="missing">Missing / Offline</option>
                </select>
              </div>
            </div>
          </div>

          {/* Drag & Drop Import Dropzone */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            className="border-2 border-dashed border-slate-800 hover:border-sky-500/60 rounded-xl p-4 flex flex-col items-center justify-center text-slate-500 hover:text-sky-400 transition bg-slate-900/40 cursor-pointer text-xs"
          >
            <FolderOpen className="w-6 h-6 mb-1" />
            <p>Drag & drop videos, recordings, or folders here to ingest into SQLite store</p>
          </div>

          {/* Media Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredList.map((item) => (
              <div
                key={item.id}
                className="bg-slate-900 rounded-xl border border-slate-800 hover:border-slate-700 p-3 flex flex-col justify-between space-y-3 shadow-md group transition"
              >
                {/* Thumbnail */}
                <div className="relative aspect-video bg-black rounded-lg overflow-hidden border border-slate-800">
                  <img
                    src={item.thumbnailUrl}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                  <div className="absolute top-2 left-2 px-1.5 py-0.5 bg-slate-900/80 rounded font-mono text-[10px] text-sky-400">
                    {item.videoStream?.codec?.split(' ')[0] || 'HEVC'}
                  </div>
                  <div className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/80 rounded font-mono text-[10px] text-slate-200">
                    {formatDuration(item.duration)}
                  </div>
                </div>

                {/* Title & Metadata */}
                <div>
                  <h3 className="font-semibold text-xs text-slate-200 truncate" title={item.name}>
                    {item.name}
                  </h3>
                  <div className="flex justify-between items-center text-[11px] text-slate-400 font-mono mt-1">
                    <span>{item.videoStream?.width}x{item.videoStream?.height}</span>
                    <span>{formatFileSize(item.fileSize)}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center space-x-2 pt-1">
                  <button
                    onClick={() => onSelectMedia(item)}
                    className="flex-1 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold flex items-center justify-center space-x-1 transition"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Open in Player</span>
                  </button>

                  <button
                    onClick={() => onDeleteMedia(item.id)}
                    className="p-1.5 bg-slate-800 hover:bg-red-900/60 border border-slate-700 text-slate-400 hover:text-red-300 rounded transition"
                    title="Delete Asset"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: DUPLICATE DETECTION ENGINE */}
      {activeTab === 'duplicates' && (
        <div className="mt-4 space-y-4">
          <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs">
            <h2 className="font-bold text-slate-200 text-sm mb-1">SQLite Duplicate Detection Analyzer</h2>
            <p className="text-slate-400">
              Scans media streams, durations, audio hash signatures, and container payloads to detect identical or redundant assets.
            </p>
          </div>

          {report.duplicates.length === 0 ? (
            <div className="p-8 bg-slate-900/60 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-slate-400 space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-400" />
              <p className="text-sm font-semibold">No redundant duplicates detected in library</p>
            </div>
          ) : (
            <div className="space-y-3">
              {report.duplicates.map((dup, idx) => (
                <div key={idx} className="p-4 bg-slate-900 rounded-xl border border-amber-900/60 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="px-2 py-0.5 bg-amber-950 border border-amber-800 text-amber-300 text-[10px] font-mono rounded">
                        {dup.matchScore}% Match
                      </span>
                      <span className="font-bold text-xs text-slate-200">{dup.original.name}</span>
                    </div>
                    <p className="text-xs text-slate-400">Conflict with: <span className="font-mono text-slate-300">{dup.duplicate.name}</span></p>
                    <p className="text-[11px] text-amber-400">{dup.reason}</p>
                  </div>

                  <div className="flex space-x-2">
                    <button
                      onClick={() => onDeleteMedia(dup.duplicate.id)}
                      className="px-3 py-1.5 bg-red-950 hover:bg-red-900 border border-red-800 text-red-300 rounded text-xs font-semibold"
                    >
                      Delete Duplicate
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: MEDIA HEALTH & RELINKING */}
      {activeTab === 'health' && (
        <div className="mt-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Total Catalog Items</span>
              <p className="text-xl font-bold font-mono text-sky-400 mt-1">{report.totalFiles}</p>
            </div>
            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Healthy Verified</span>
              <p className="text-xl font-bold font-mono text-emerald-400 mt-1">{report.healthyCount}</p>
            </div>
            <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
              <span className="text-xs text-slate-400">Offline / Missing Media</span>
              <p className="text-xl font-bold font-mono text-red-400 mt-1">{report.missingCount}</p>
            </div>
          </div>

          <div className="space-y-2">
            {mediaList.map((item) => (
              <div
                key={item.id}
                className="p-3 bg-slate-900 rounded-lg border border-slate-800 flex justify-between items-center text-xs"
              >
                <div className="flex items-center space-x-3 truncate">
                  <div
                    className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                      item.healthStatus === 'healthy' ? 'bg-emerald-500' : item.healthStatus === 'warning' ? 'bg-amber-500' : 'bg-red-500'
                    }`}
                  />
                  <span className="font-semibold text-slate-200 truncate">{item.name}</span>
                  <span className="text-[10px] text-slate-400 font-mono">({item.container})</span>
                </div>

                <div className="flex items-center space-x-2">
                  <label className="px-2 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 cursor-pointer flex items-center space-x-1 text-[11px]">
                    <Link2 className="w-3 h-3 text-sky-400" />
                    <span>Relink File</span>
                    <input
                      type="file"
                      accept="video/*"
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          onRelinkMedia(item.id, e.target.files[0]);
                        }
                      }}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
