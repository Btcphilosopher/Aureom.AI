'use client';

import React, { useState } from 'react';
import { AppWorkspace, LanguageCode } from '@/types/media';
import { STRINGS } from '@/lib/localisation';
import { coreAudioEngine } from '@/lib/audio-engine';

interface MenuBarProps {
  currentWorkspace: AppWorkspace;
  setWorkspace: (ws: AppWorkspace) => void;
  lang: LanguageCode;
  onOpenLocalFile: () => void;
  onSaveProject: () => void;
  onExportProject: () => void;
  onCaptureFrame: () => void;
  onTogglePlay: () => void;
  isPlaying: boolean;
  onStepFrame: (forward: boolean) => void;
  onToggleMute: () => void;
  isMuted: boolean;
  onOpenSettings: () => void;
}

export const MenuBar: React.FC<MenuBarProps> = ({
  currentWorkspace,
  setWorkspace,
  lang,
  onOpenLocalFile,
  onSaveProject,
  onExportProject,
  onCaptureFrame,
  onTogglePlay,
  isPlaying,
  onStepFrame,
  onToggleMute,
  isMuted,
  onOpenSettings,
}) => {
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const t = STRINGS[lang] || STRINGS.en;

  const closeMenu = () => setOpenMenu(null);

  return (
    <div
      id="macos-menubar"
      className="h-7 bg-[#1E1E1E] border-b border-[#2A2A2A] text-[#E0E0E0] text-xs flex items-center px-3 select-none z-50 relative backdrop-blur-md"
    >
      {/* Apple / App Logo */}
      <div className="flex items-center space-x-1.5 pr-3 border-r border-[#2A2A2A] font-bold tracking-tight text-xs text-[#888888]">
        <span className="text-sm text-[#AAAAAA]"></span>
        <span className="text-[#E0E0E0]">MACVIDEO.PRO</span>
      </div>

      {/* Menu items */}
      <div className="flex items-center space-x-1 pl-2">
        {/* FILE MENU */}
        <div className="relative">
          <button
            id="menu-file-btn"
            onClick={() => setOpenMenu(openMenu === 'file' ? null : 'file')}
            className={`px-2 py-0.5 rounded transition ${openMenu === 'file' ? 'bg-[#007AFF] text-white' : 'hover:bg-[#2A2A2A] text-[#AAAAAA] hover:text-[#E0E0E0]'}`}
          >
            File
          </button>
          {openMenu === 'file' && (
            <div className="absolute left-0 top-6 w-56 bg-[#1E1E1E] border border-[#2A2A2A] rounded-lg shadow-2xl py-1 z-50 text-[#E0E0E0] backdrop-blur-lg">
              <button
                onClick={() => { onOpenLocalFile(); closeMenu(); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between items-center text-xs"
              >
                <span>Open Video...</span>
                <span className="text-[#888888] text-[10px]">⌘O</span>
              </button>
              <button
                onClick={() => { onSaveProject(); closeMenu(); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between items-center text-xs"
              >
                <span>Save Project</span>
                <span className="text-[#888888] text-[10px]">⌘S</span>
              </button>
              <button
                onClick={() => { onExportProject(); closeMenu(); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between items-center text-xs"
              >
                <span>Export Media Master...</span>
                <span className="text-[#888888] text-[10px]">⌘E</span>
              </button>
              <div className="my-1 border-t border-[#2A2A2A]" />
              <button
                onClick={() => { setWorkspace('recorder'); closeMenu(); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs"
              >
                New Screen Recording (ScreenCaptureKit)
              </button>
              <button
                onClick={() => { setWorkspace('recorder'); closeMenu(); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs"
              >
                New Camera / FaceTime Recording
              </button>
              <button
                onClick={() => { setWorkspace('recorder'); closeMenu(); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs"
              >
                New Core Audio Recording
              </button>
            </div>
          )}
        </div>

        {/* EDIT MENU */}
        <div className="relative">
          <button
            id="menu-edit-btn"
            onClick={() => setOpenMenu(openMenu === 'edit' ? null : 'edit')}
            className={`px-2 py-0.5 rounded transition ${openMenu === 'edit' ? 'bg-[#007AFF] text-white' : 'hover:bg-[#2A2A2A] text-[#AAAAAA] hover:text-[#E0E0E0]'}`}
          >
            Edit
          </button>
          {openMenu === 'edit' && (
            <div className="absolute left-0 top-6 w-52 bg-[#1E1E1E] border border-[#2A2A2A] rounded-lg shadow-2xl py-1 z-50 text-[#E0E0E0]">
              <button onClick={closeMenu} className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between text-xs">
                <span>Undo Edit</span>
                <span className="text-[#888888] text-[10px]">⌘Z</span>
              </button>
              <button onClick={closeMenu} className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between text-xs">
                <span>Redo Edit</span>
                <span className="text-[#888888] text-[10px]">⇧⌘Z</span>
              </button>
              <div className="my-1 border-t border-[#2A2A2A]" />
              <button onClick={() => { onCaptureFrame(); closeMenu(); }} className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between text-xs">
                <span>Capture Frame Image</span>
                <span className="text-[#888888] text-[10px]">⌥⌘C</span>
              </button>
            </div>
          )}
        </div>

        {/* VIEW / WORKSPACE MENU */}
        <div className="relative">
          <button
            id="menu-view-btn"
            onClick={() => setOpenMenu(openMenu === 'view' ? null : 'view')}
            className={`px-2 py-0.5 rounded transition ${openMenu === 'view' ? 'bg-[#007AFF] text-white' : 'hover:bg-[#2A2A2A] text-[#AAAAAA] hover:text-[#E0E0E0]'}`}
          >
            View
          </button>
          {openMenu === 'view' && (
            <div className="absolute left-0 top-6 w-56 bg-[#1E1E1E] border border-[#2A2A2A] rounded-lg shadow-2xl py-1 z-50 text-[#E0E0E0]">
              <button onClick={() => { setWorkspace('player'); closeMenu(); }} className={`w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs ${currentWorkspace === 'player' ? 'font-bold text-[#007AFF]' : ''}`}>
                ✓ Player & Video Scopes
              </button>
              <button onClick={() => { setWorkspace('editor'); closeMenu(); }} className={`w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs ${currentWorkspace === 'editor' ? 'font-bold text-[#007AFF]' : ''}`}>
                ✓ Timeline Multi-Track Editor
              </button>
              <button onClick={() => { setWorkspace('recorder'); closeMenu(); }} className={`w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs ${currentWorkspace === 'recorder' ? 'font-bold text-[#007AFF]' : ''}`}>
                ✓ Studio Recording Suite
              </button>
              <button onClick={() => { setWorkspace('library'); closeMenu(); }} className={`w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs ${currentWorkspace === 'library' ? 'font-bold text-[#007AFF]' : ''}`}>
                ✓ Media Database (SQLite)
              </button>
              <button onClick={() => { setWorkspace('transcoder'); closeMenu(); }} className={`w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs ${currentWorkspace === 'transcoder' ? 'font-bold text-[#007AFF]' : ''}`}>
                ✓ Batch Transcoder & Queue
              </button>
              <button onClick={() => { setWorkspace('ai'); closeMenu(); }} className={`w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs ${currentWorkspace === 'ai' ? 'font-bold text-[#007AFF]' : ''}`}>
                ✓ AI Video Intelligence
              </button>
              <button onClick={() => { setWorkspace('analytics'); closeMenu(); }} className={`w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs ${currentWorkspace === 'analytics' ? 'font-bold text-[#007AFF]' : ''}`}>
                ✓ Analytics & Quality Monitor
              </button>
            </div>
          )}
        </div>

        {/* PLAYBACK MENU */}
        <div className="relative">
          <button
            id="menu-playback-btn"
            onClick={() => setOpenMenu(openMenu === 'playback' ? null : 'playback')}
            className={`px-2 py-0.5 rounded transition ${openMenu === 'playback' ? 'bg-[#007AFF] text-white' : 'hover:bg-[#2A2A2A] text-[#AAAAAA] hover:text-[#E0E0E0]'}`}
          >
            Playback
          </button>
          {openMenu === 'playback' && (
            <div className="absolute left-0 top-6 w-56 bg-[#1E1E1E] border border-[#2A2A2A] rounded-lg shadow-2xl py-1 z-50 text-[#E0E0E0]">
              <button onClick={() => { onTogglePlay(); closeMenu(); }} className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between text-xs">
                <span>{isPlaying ? 'Pause' : 'Play'}</span>
                <span className="text-[#888888] text-[10px]">Space</span>
              </button>
              <button onClick={() => { onStepFrame(false); closeMenu(); }} className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between text-xs">
                <span>Previous Frame</span>
                <span className="text-[#888888] text-[10px]">←</span>
              </button>
              <button onClick={() => { onStepFrame(true); closeMenu(); }} className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between text-xs">
                <span>Next Frame</span>
                <span className="text-[#888888] text-[10px]">→</span>
              </button>
              <div className="my-1 border-t border-[#2A2A2A]" />
              <button onClick={() => { onToggleMute(); closeMenu(); }} className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white flex justify-between text-xs">
                <span>{isMuted ? 'Unmute Audio' : 'Mute Audio'}</span>
                <span className="text-[#888888] text-[10px]">M</span>
              </button>
            </div>
          )}
        </div>

        {/* AUDIO MENU */}
        <div className="relative">
          <button
            id="menu-audio-btn"
            onClick={() => setOpenMenu(openMenu === 'audio' ? null : 'audio')}
            className={`px-2 py-0.5 rounded transition ${openMenu === 'audio' ? 'bg-[#007AFF] text-white' : 'hover:bg-[#2A2A2A] text-[#AAAAAA] hover:text-[#E0E0E0]'}`}
          >
            Audio
          </button>
          {openMenu === 'audio' && (
            <div className="absolute left-0 top-6 w-60 bg-[#1E1E1E] border border-[#2A2A2A] rounded-lg shadow-2xl py-1 z-50 text-[#E0E0E0]">
              <button
                onClick={() => { coreAudioEngine.playCalibrationTone(2); closeMenu(); }}
                className="w-full text-left px-3 py-1.5 hover:bg-[#007AFF] hover:text-white text-xs"
              >
                Play 1kHz -20dBFS Calibration Tone
              </button>
            </div>
          )}
        </div>

        {/* SETTINGS / HELP */}
        <div className="relative">
          <button
            id="menu-settings-btn"
            onClick={() => { onOpenSettings(); closeMenu(); }}
            className="px-2 py-0.5 rounded hover:bg-[#2A2A2A] text-[#AAAAAA] hover:text-[#E0E0E0] transition"
          >
            Settings
          </button>
        </div>
      </div>

      {/* Right status info */}
      <div className="ml-auto flex items-center space-x-3 text-[11px] text-[#888888]">
        <span className="bg-[#2A2A2A] px-2 py-0.5 rounded border border-[#333333] text-[#AAAAAA] font-mono">
          Metal: <span className="text-[#27C93F]">Active</span>
        </span>
        <span className="text-[#666666]">macOS Native Engine</span>
      </div>
    </div>
  );
};
