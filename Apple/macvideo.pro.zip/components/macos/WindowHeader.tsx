'use client';

import React from 'react';
import { AppWorkspace, LanguageCode, MediaItem } from '@/types/media';
import { LOCALES, STRINGS } from '@/lib/localisation';
import {
  Play,
  Film,
  Disc,
  Database,
  RefreshCw,
  Sparkles,
  BarChart3,
  Settings,
  Search,
  Maximize2,
  Minimize2,
  FolderOpen,
} from 'lucide-react';

interface WindowHeaderProps {
  currentWorkspace: AppWorkspace;
  setWorkspace: (ws: AppWorkspace) => void;
  activeMedia: MediaItem | null;
  lang: LanguageCode;
  setLang: (lang: LanguageCode) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onOpenSettings: () => void;
  onOpenLocalFile: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
}

export const WindowHeader: React.FC<WindowHeaderProps> = ({
  currentWorkspace,
  setWorkspace,
  activeMedia,
  lang,
  setLang,
  searchQuery,
  setSearchQuery,
  onOpenSettings,
  onOpenLocalFile,
  isFullscreen,
  onToggleFullscreen,
}) => {
  const t = STRINGS[lang] || STRINGS.en;

  const workspaceButtons: { id: AppWorkspace; label: string; icon: React.ReactNode }[] = [
    { id: 'player', label: t.workspacePlayer, icon: <Play className="w-3.5 h-3.5" /> },
    { id: 'editor', label: t.workspaceEditor, icon: <Film className="w-3.5 h-3.5" /> },
    { id: 'recorder', label: t.workspaceRecorder, icon: <Disc className="w-3.5 h-3.5" /> },
    { id: 'library', label: t.workspaceLibrary, icon: <Database className="w-3.5 h-3.5" /> },
    { id: 'transcoder', label: t.workspaceTranscoder, icon: <RefreshCw className="w-3.5 h-3.5" /> },
    { id: 'ai', label: t.workspaceAI, icon: <Sparkles className="w-3.5 h-3.5 text-amber-400" /> },
    { id: 'analytics', label: t.workspaceAnalytics, icon: <BarChart3 className="w-3.5 h-3.5" /> },
  ];

  return (
    <div
      id="macos-window-header"
      className="h-12 bg-[#1E1E1E] border-b border-[#2A2A2A] flex items-center justify-between px-4 gap-3 select-none shrink-0"
    >
      {/* Left: macOS Traffic Lights & Title */}
      <div className="flex items-center space-x-3 shrink-0">
        <div className="flex items-center space-x-2 mr-2">
          <div
            id="traffic-close"
            className="w-3 h-3 rounded-full bg-[#FF5F56] hover:opacity-90 cursor-pointer shadow-sm transition"
            title="Close"
          />
          <div
            id="traffic-min"
            className="w-3 h-3 rounded-full bg-[#FFBD2E] hover:opacity-90 cursor-pointer shadow-sm transition"
            title="Minimize"
          />
          <div
            id="traffic-zoom"
            onClick={onToggleFullscreen}
            className="w-3 h-3 rounded-full bg-[#27C93F] hover:opacity-90 cursor-pointer shadow-sm transition"
            title="Toggle Fullscreen"
          />
        </div>

        <button
          id="btn-open-file-quick"
          onClick={onOpenLocalFile}
          className="flex items-center space-x-1.5 px-2.5 py-1 bg-[#2A2A2A] hover:bg-[#333333] text-[#E0E0E0] rounded border border-[#333333] text-xs transition font-medium"
          title="Open Video File (Cmd+O)"
        >
          <FolderOpen className="w-3.5 h-3.5 text-[#007AFF]" />
          <span>Open</span>
        </button>

        {activeMedia && (
          <div className="hidden lg:flex items-center space-x-2 text-xs text-[#AAAAAA] truncate max-w-xs">
            <span className="text-[#555555]">/</span>
            <span className="font-semibold text-[#E0E0E0] truncate">{activeMedia.name}</span>
            <span className="text-[10px] px-1.5 py-0.5 bg-[#2A2A2A] border border-[#333333] rounded text-[#007AFF] font-mono">
              {activeMedia.videoStream?.codec?.split(' ')[0] || 'HEVC'}
            </span>
          </div>
        )}
      </div>

      {/* Center: Segmented Workspace Switcher */}
      <div
        id="workspace-switcher"
        className="flex items-center bg-[#151515] p-0.5 rounded-lg border border-[#2A2A2A] overflow-x-auto shadow-inner"
      >
        {workspaceButtons.map((btn) => {
          const isActive = currentWorkspace === btn.id;
          return (
            <button
              key={btn.id}
              id={`tab-${btn.id}`}
              onClick={() => setWorkspace(btn.id)}
              className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-md text-xs transition whitespace-nowrap ${
                isActive
                  ? 'bg-[#007AFF] text-white font-semibold shadow-sm'
                  : 'text-[#AAAAAA] hover:text-[#E0E0E0] hover:bg-[#2A2A2A]'
              }`}
            >
              {btn.icon}
              <span>{btn.label}</span>
            </button>
          );
        })}
      </div>

      {/* Right: Search, Language & Settings */}
      <div className="flex items-center space-x-2 shrink-0">
        {/* Quick Search */}
        <div className="relative hidden md:block">
          <Search className="w-3.5 h-3.5 text-[#666666] absolute left-2.5 top-2" />
          <input
            id="global-search-input"
            type="text"
            placeholder="Search project media..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-40 lg:w-48 pl-8 pr-2 py-1 bg-[#2A2A2A] border border-[#333333] rounded-md text-xs text-[#E0E0E0] placeholder-[#666666] focus:outline-none focus:border-[#007AFF]"
          />
        </div>

        {/* Language selector */}
        <select
          id="language-select"
          value={lang}
          onChange={(e) => setLang(e.target.value as LanguageCode)}
          className="bg-[#2A2A2A] border border-[#333333] text-[#E0E0E0] text-xs rounded px-2 py-1 focus:outline-none focus:border-[#007AFF] cursor-pointer"
        >
          {Object.entries(LOCALES).map(([code, item]) => (
            <option key={code} value={code}>
              {item.flag} {code.toUpperCase()}
            </option>
          ))}
        </select>

        {/* Fullscreen toggle */}
        <button
          id="btn-toggle-fullscreen"
          onClick={onToggleFullscreen}
          className="p-1.5 bg-[#2A2A2A] hover:bg-[#333333] text-[#AAAAAA] hover:text-white rounded border border-[#333333] transition"
          title="Toggle Fullscreen"
        >
          {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
        </button>

        {/* Settings button */}
        <button
          id="btn-open-settings"
          onClick={onOpenSettings}
          className="p-1.5 bg-[#2A2A2A] hover:bg-[#333333] text-[#AAAAAA] hover:text-white rounded border border-[#333333] transition"
          title="Preferences & Settings"
        >
          <Settings className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
