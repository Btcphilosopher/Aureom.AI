'use client';

import React, { useState } from 'react';
import { MediaItem } from '@/types/media';
import { metalPipeline } from '@/lib/metal-engine';
import { Grid3X3, Download, X, Loader2, Image as ImageIcon } from 'lucide-react';

interface ContactSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  media: MediaItem | null;
}

export const ContactSheetModal: React.FC<ContactSheetModalProps> = ({
  isOpen,
  onClose,
  videoRef,
  media,
}) => {
  const [columns, setColumns] = useState(4);
  const [rows, setRows] = useState(3);
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewDataUrl, setPreviewDataUrl] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!videoRef.current || !media) return;
    setIsGenerating(true);
    try {
      const url = await metalPipeline.generateContactSheet(
        videoRef.current,
        columns,
        rows,
        media.name
      );
      setPreviewDataUrl(url);
    } catch {
      //
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!previewDataUrl) return;
    const a = document.createElement('a');
    a.href = previewDataUrl;
    a.download = `ContactSheet_${media?.name || 'video'}.jpg`;
    a.click();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none">
      <div
        id="contact-sheet-modal"
        className="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden text-slate-200"
      >
        {/* Header */}
        <div className="h-12 bg-slate-950 px-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Grid3X3 className="w-4 h-4 text-amber-400" />
            <span className="font-bold text-sm">GENERATE VIDEO CONTACT SHEET</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 rounded-md text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4 text-xs">
          {/* Controls row */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-slate-400">Columns:</span>
                <select
                  value={columns}
                  onChange={(e) => setColumns(Number(e.target.value))}
                  className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-200"
                >
                  <option value={3}>3 Columns</option>
                  <option value={4}>4 Columns</option>
                  <option value={5}>5 Columns</option>
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-slate-400">Rows:</span>
                <select
                  value={rows}
                  onChange={(e) => setRows(Number(e.target.value))}
                  className="bg-slate-900 border border-slate-700 rounded px-2 py-1 text-slate-200"
                >
                  <option value={2}>2 Rows (6 Frames)</option>
                  <option value={3}>3 Rows (12 Frames)</option>
                  <option value={4}>4 Rows (16-20 Frames)</option>
                </select>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating}
              className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-bold rounded-lg shadow flex items-center space-x-2 transition text-xs"
            >
              {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Grid3X3 className="w-4 h-4" />}
              <span>{isGenerating ? 'Sampling Video Frames...' : 'Generate Contact Sheet'}</span>
            </button>
          </div>

          {/* Preview canvas / image */}
          <div className="min-h-[280px] bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-center p-2 overflow-auto">
            {previewDataUrl ? (
              <img
                src={previewDataUrl}
                alt="Generated Contact Sheet"
                className="max-h-[500px] w-auto rounded border border-slate-800 shadow-xl"
              />
            ) : (
              <div className="flex flex-col items-center justify-center text-slate-500 space-y-2">
                <ImageIcon className="w-12 h-12 opacity-30" />
                <p>Click Generate to sample timestamps across the video into a storyboard sheet.</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-14 bg-slate-950 px-5 flex items-center justify-between border-t border-slate-800">
          <span className="text-slate-400 text-xs">
            Format: High Quality JPEG with Timecode Header & SMPTE Badges
          </span>

          <div className="flex space-x-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs"
            >
              Cancel
            </button>

            {previewDataUrl && (
              <button
                onClick={handleDownload}
                className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-xs flex items-center space-x-1.5 shadow"
              >
                <Download className="w-4 h-4" />
                <span>Save Contact Sheet Image</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
