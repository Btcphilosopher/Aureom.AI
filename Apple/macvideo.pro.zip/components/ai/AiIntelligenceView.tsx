'use client';

import React, { useState } from 'react';
import { MediaItem, VideoProject } from '@/types/media';
import { formatDuration } from '@/lib/timecode';
import {
  Sparkles,
  FileText,
  BookmarkPlus,
  Play,
  CheckCircle2,
  ShieldCheck,
  Cpu,
  Clock,
  Tag,
  Sliders,
  Send,
  Loader2,
} from 'lucide-react';

interface AiIntelligenceViewProps {
  activeMedia: MediaItem | null;
  onSeek: (time: number) => void;
  project: VideoProject;
  setProject: (p: VideoProject) => void;
  onOpenInPlayer: () => void;
}

export const AiIntelligenceView: React.FC<AiIntelligenceViewProps> = ({
  activeMedia,
  onSeek,
  project,
  setProject,
  onOpenInPlayer,
}) => {
  const [activeAiTab, setActiveAiTab] = useState<'summary' | 'transcript' | 'chapters'>('summary');
  const [isLoading, setIsLoading] = useState(false);
  const [userPrompt, setUserPrompt] = useState('');

  // AI Generated States
  const [analysisResult, setAnalysisResult] = useState<{
    summary?: string;
    keyMoments?: { time: string; label: string }[];
    technicalInsights?: {
      colorGradingRecommendation: string;
      audioRecommendation: string;
      transcodeRecommendation: string;
    };
    suggestedTags?: string[];
  } | null>(null);

  const [transcriptSegments, setTranscriptSegments] = useState<
    { startTime: number; endTime: number; speaker: string; text: string; confidence: number }[] | null
  >(null);

  const [aiChapters, setAiChapters] = useState<
    { timestamp: number; label: string; color: string; notes: string }[] | null
  >(null);

  // Request AI Summary & Technical Analysis
  const handleAnalyze = async () => {
    if (!activeMedia) return;
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoTitle: activeMedia.name,
          durationSec: activeMedia.duration,
          resolution: `${activeMedia.videoStream?.width}x${activeMedia.videoStream?.height}`,
          codec: activeMedia.videoStream?.codec,
          genre: activeMedia.metadata?.genre,
          userPrompt,
        }),
      });
      const data = await res.json();
      setAnalysisResult(data);
    } catch {
      // Fallback
    } finally {
      setIsLoading(false);
    }
  };

  // Request Speech Transcription
  const handleTranscribe = async () => {
    if (!activeMedia) return;
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoTitle: activeMedia.name,
          durationSec: activeMedia.duration,
          genre: activeMedia.metadata?.genre,
        }),
      });
      const data = await res.json();
      setTranscriptSegments(data.segments);
    } catch {
      // Fallback
    } finally {
      setIsLoading(false);
    }
  };

  // Request Chapter Generation
  const handleGenerateChapters = async () => {
    if (!activeMedia) return;
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/chapters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          videoTitle: activeMedia.name,
          durationSec: activeMedia.duration,
          genre: activeMedia.metadata?.genre,
        }),
      });
      const data = await res.json();
      setAiChapters(data.chapters);
    } catch {
      // Fallback
    } finally {
      setIsLoading(false);
    }
  };

  // Add Generated Chapters to Timeline Markers
  const applyChaptersToTimeline = () => {
    if (!aiChapters) return;
    const newMarkers = aiChapters.map((c, i) => ({
      id: `ai-chap-${Date.now()}-${i}`,
      timestamp: c.timestamp,
      label: c.label,
      color: c.color,
      category: 'chapter' as const,
    }));

    setProject({ ...project, markers: [...project.markers, ...newMarkers] });
  };

  if (!activeMedia) {
    return (
      <div id="ai-intelligence-view" className="flex flex-col items-center justify-center h-full bg-slate-950 text-slate-500 text-xs">
        <Sparkles className="w-12 h-12 opacity-30 mb-2" />
        <p>No media asset selected. Open a file to use AI Video Intelligence.</p>
      </div>
    );
  }

  return (
    <div id="ai-intelligence-view" className="flex flex-col h-full bg-slate-950 text-slate-200 select-none p-6 overflow-y-auto">
      {/* Header */}
      <div className="flex justify-between items-center pb-4 border-b border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-amber-950/60 border border-amber-800 text-amber-400 rounded-lg">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-100">AI VIDEO INTELLIGENCE</h1>
            <p className="text-xs text-slate-400">
              Summarization, Speech Transcription & Smart Scene Chaptering
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-emerald-400">
          <ShieldCheck className="w-4 h-4" />
          <span>Local & Cloud Privacy Guard Active</span>
        </div>
      </div>

      {/* Mode Sub-tabs */}
      <div className="flex border-b border-slate-800 space-x-4 mt-4 text-xs font-semibold">
        <button
          onClick={() => setActiveAiTab('summary')}
          className={`pb-2 transition border-b-2 flex items-center space-x-1.5 ${
            activeAiTab === 'summary' ? 'border-amber-500 text-amber-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Analysis & Summary</span>
        </button>

        <button
          onClick={() => setActiveAiTab('transcript')}
          className={`pb-2 transition border-b-2 flex items-center space-x-1.5 ${
            activeAiTab === 'transcript' ? 'border-sky-500 text-sky-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Speech-to-Text Transcript</span>
        </button>

        <button
          onClick={() => setActiveAiTab('chapters')}
          className={`pb-2 transition border-b-2 flex items-center space-x-1.5 ${
            activeAiTab === 'chapters' ? 'border-emerald-500 text-emerald-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookmarkPlus className="w-4 h-4" />
          <span>Smart Chapter Markers</span>
        </button>
      </div>

      {/* TAB 1: SUMMARY & TECHNICAL INSIGHTS */}
      {activeAiTab === 'summary' && (
        <div className="mt-4 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800">
            <input
              type="text"
              placeholder="Optional prompt: Focus on color grading, pacing, audio mixing..."
              value={userPrompt}
              onChange={(e) => setUserPrompt(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={handleAnalyze}
              disabled={isLoading}
              className="px-4 py-1.5 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white font-bold rounded-lg shadow transition flex items-center justify-center space-x-1.5 text-xs"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>Run AI Video Analysis</span>
            </button>
          </div>

          {analysisResult && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Summary Card */}
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Executive Video Summary</h3>
                <p className="text-xs text-slate-300 leading-relaxed">{analysisResult.summary}</p>

                {/* Key Moments */}
                {analysisResult.keyMoments && (
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <span className="text-[11px] font-bold text-amber-400">Key Production Moments</span>
                    {analysisResult.keyMoments.map((m, idx) => (
                      <div key={idx} className="flex items-center space-x-2 text-xs">
                        <span className="px-1.5 py-0.5 bg-slate-950 border border-slate-800 rounded font-mono text-sky-400 text-[10px]">
                          {m.time}
                        </span>
                        <span className="text-slate-300">{m.label}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Technical Recommendations */}
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Technical Broadcast Recommendations</h3>
                
                {analysisResult.technicalInsights && (
                  <div className="space-y-3 text-xs">
                    <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80">
                      <span className="text-amber-400 font-semibold block mb-0.5">Color Grading & Gamut</span>
                      <p className="text-slate-300">{analysisResult.technicalInsights.colorGradingRecommendation}</p>
                    </div>

                    <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80">
                      <span className="text-emerald-400 font-semibold block mb-0.5">Audio & Loudness Normalization</span>
                      <p className="text-slate-300">{analysisResult.technicalInsights.audioRecommendation}</p>
                    </div>

                    <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80">
                      <span className="text-sky-400 font-semibold block mb-0.5">Hardware Transcode Profile</span>
                      <p className="text-slate-300">{analysisResult.technicalInsights.transcodeRecommendation}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: SPEECH-TO-TEXT TRANSCRIPT */}
      {activeAiTab === 'transcript' && (
        <div className="mt-4 space-y-4">
          <div className="flex justify-between items-center bg-slate-900 p-3 rounded-xl border border-slate-800">
            <span className="text-xs text-slate-400">Click any dialogue line to seek video player directly to timestamp.</span>
            <button
              onClick={handleTranscribe}
              disabled={isLoading}
              className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded-lg text-xs flex items-center space-x-1.5"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
              <span>Generate Timecoded Transcript</span>
            </button>
          </div>

          {transcriptSegments && (
            <div className="space-y-2 bg-slate-900 p-4 rounded-xl border border-slate-800 max-h-96 overflow-y-auto">
              {transcriptSegments.map((seg, i) => (
                <div
                  key={i}
                  onClick={() => {
                    onSeek(seg.startTime);
                    onOpenInPlayer();
                  }}
                  className="p-2.5 hover:bg-slate-800 rounded-lg cursor-pointer transition flex items-start space-x-3 text-xs border border-transparent hover:border-slate-700"
                >
                  <span className="px-2 py-0.5 bg-slate-950 text-sky-400 font-mono rounded text-[10px] shrink-0">
                    {formatDuration(seg.startTime)}
                  </span>
                  <div>
                    <span className="font-bold text-slate-200">{seg.speaker}: </span>
                    <span className="text-slate-300">{seg.text}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: SMART CHAPTER MARKERS */}
      {activeAiTab === 'chapters' && (
        <div className="mt-4 space-y-4">
          <div className="flex justify-between items-center bg-slate-900 p-3 rounded-xl border border-slate-800">
            <span className="text-xs text-slate-400">Automatically identify semantic scene changes and milestones.</span>
            <button
              onClick={handleGenerateChapters}
              disabled={isLoading}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg text-xs flex items-center space-x-1.5"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>Detect Scene Chapters</span>
            </button>
          </div>

          {aiChapters && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-300">Generated {aiChapters.length} Chapter Markers</span>
                <button
                  onClick={applyChaptersToTimeline}
                  className="px-3 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded text-xs font-semibold flex items-center space-x-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Apply All to Timeline Track</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {aiChapters.map((ch, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      onSeek(ch.timestamp);
                      onOpenInPlayer();
                    }}
                    className="p-3 bg-slate-900 rounded-xl border border-slate-800 hover:border-sky-500/60 cursor-pointer transition space-y-1"
                  >
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: ch.color }} />
                      <span className="font-mono text-sky-400 text-xs font-bold">{formatDuration(ch.timestamp)}</span>
                      <span className="font-semibold text-slate-200 text-xs truncate">{ch.label}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 pl-5">{ch.notes}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
