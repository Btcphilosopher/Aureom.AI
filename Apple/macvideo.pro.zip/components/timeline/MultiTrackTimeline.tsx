'use client';

import React, { useState } from 'react';
import { VideoProject, MediaClip, TimelineTrack, MediaItem } from '@/types/media';
import { formatSMPTETimecode, formatDuration } from '@/lib/timecode';
import {
  Scissors,
  BookmarkPlus,
  ZoomIn,
  ZoomOut,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Volume2,
  VolumeX,
  Trash2,
  Download,
} from 'lucide-react';

interface MultiTrackTimelineProps {
  project: VideoProject;
  setProject: (p: VideoProject) => void;
  currentTime: number;
  onSeek: (time: number) => void;
  mediaLibrary: MediaItem[];
  fps: number;
  onExportTimeline: () => void;
}

export const MultiTrackTimeline: React.FC<MultiTrackTimelineProps> = ({
  project,
  setProject,
  currentTime,
  onSeek,
  mediaLibrary,
  fps,
  onExportTimeline,
}) => {
  const [zoomLevel, setZoomLevel] = useState(1.0); // 0.5 to 3.0
  const [selectedClipId, setSelectedClipId] = useState<string | null>(null);
  const [activeTool, setActiveTool] = useState<'select' | 'razor'>('select');

  const pxPerSecond = 40 * zoomLevel;
  const totalTimelineDuration = project.duration || 60;
  const totalWidthPx = Math.max(1000, totalTimelineDuration * pxPerSecond);

  // Razor split selected clip at playhead
  const handleSplitClipAtPlayhead = () => {
    if (!selectedClipId) return;

    const clipIndex = project.clips.findIndex((c) => c.id === selectedClipId);
    if (clipIndex === -1) return;

    const clip = project.clips[clipIndex];
    const clipStart = clip.timelineStart;
    const clipEnd = clipStart + clip.timelineDuration;

    if (currentTime > clipStart && currentTime < clipEnd) {
      const firstDuration = currentTime - clipStart;
      const secondDuration = clipEnd - currentTime;

      const firstHalf: MediaClip = {
        ...clip,
        timelineDuration: firstDuration,
        sourceDuration: firstDuration,
      };

      const secondHalf: MediaClip = {
        ...clip,
        id: `clip-${Date.now()}`,
        timelineStart: currentTime,
        sourceStart: clip.sourceStart + firstDuration,
        timelineDuration: secondDuration,
        sourceDuration: secondDuration,
      };

      const updatedClips = [...project.clips];
      updatedClips.splice(clipIndex, 1, firstHalf, secondHalf);

      setProject({ ...project, clips: updatedClips });
    }
  };

  // Add marker at current playhead
  const handleAddMarker = () => {
    const newMarker = {
      id: `m-${Date.now()}`,
      timestamp: currentTime,
      label: `Marker ${project.markers.length + 1} (${formatDuration(currentTime)})`,
      color: '#38bdf8',
      category: 'note' as const,
    };
    setProject({ ...project, markers: [...project.markers, newMarker] });
  };

  // Toggle track lock
  const toggleTrackLock = (trackId: string) => {
    const newTracks = project.tracks.map((t) => (t.id === trackId ? { ...t, isLocked: !t.isLocked } : t));
    setProject({ ...project, tracks: newTracks });
  };

  // Toggle track mute
  const toggleTrackMute = (trackId: string) => {
    const newTracks = project.tracks.map((t) => (t.id === trackId ? { ...t, isMuted: !t.isMuted } : t));
    setProject({ ...project, tracks: newTracks });
  };

  // Toggle track visibility
  const toggleTrackVisible = (trackId: string) => {
    const newTracks = project.tracks.map((t) => (t.id === trackId ? { ...t, isHidden: !t.isHidden } : t));
    setProject({ ...project, tracks: newTracks });
  };

  // Delete selected clip
  const handleDeleteClip = () => {
    if (!selectedClipId) return;
    setProject({
      ...project,
      clips: project.clips.filter((c) => c.id !== selectedClipId),
    });
    setSelectedClipId(null);
  };

  // Add new track
  const handleAddTrack = (type: 'video' | 'audio') => {
    const count = project.tracks.filter((t) => t.type === type).length + 1;
    const newTrack: TimelineTrack = {
      id: `tr-${Date.now()}`,
      name: `${type === 'video' ? 'V' : 'A'}${count}`,
      type,
      index: project.tracks.length,
      isLocked: false,
      isMuted: false,
      isSolo: false,
      isHidden: false,
      height: 64,
    };
    setProject({ ...project, tracks: [...project.tracks, newTrack] });
  };

  return (
    <div id="multitrack-timeline" className="flex flex-col h-full bg-[#181818] text-[#E0E0E0] select-none">
      {/* Timeline Control Toolbar */}
      <div className="h-10 bg-[#1E1E1E] border-b border-[#2A2A2A] flex items-center justify-between px-4 text-xs">
        {/* Left Tools: Selection, Razor Split, Markers */}
        <div className="flex items-center space-x-2">
          <div className="flex items-center bg-[#151515] p-0.5 rounded border border-[#2A2A2A]">
            <button
              onClick={() => setActiveTool('select')}
              className={`px-2 py-0.5 rounded ${activeTool === 'select' ? 'bg-[#007AFF] text-white font-semibold' : 'text-[#AAAAAA] hover:text-[#E0E0E0]'}`}
              title="Selection Tool (V)"
            >
              Select (V)
            </button>
            <button
              onClick={() => {
                setActiveTool('razor');
                handleSplitClipAtPlayhead();
              }}
              className={`px-2 py-0.5 rounded flex items-center space-x-1 ${
                activeTool === 'razor' ? 'bg-[#007AFF] text-white font-semibold' : 'text-[#AAAAAA] hover:text-[#E0E0E0]'
              }`}
              title="Razor Blade Tool (Cmd+B)"
            >
              <Scissors className="w-3 h-3" />
              <span>Razor (⌘B)</span>
            </button>
          </div>

          <button
            onClick={handleAddMarker}
            className="flex items-center space-x-1 px-2.5 py-1 bg-[#2A2A2A] hover:bg-[#333333] border border-[#333333] rounded text-[#E0E0E0] transition"
            title="Add Timeline Marker (M)"
          >
            <BookmarkPlus className="w-3.5 h-3.5 text-[#007AFF]" />
            <span>Add Marker (M)</span>
          </button>

          {selectedClipId && (
            <button
              onClick={handleDeleteClip}
              className="flex items-center space-x-1 px-2 py-1 bg-red-950/60 hover:bg-red-900/80 border border-red-800 rounded text-red-300 transition"
              title="Delete Selected Clip"
            >
              <Trash2 className="w-3 h-3" />
              <span>Delete Clip</span>
            </button>
          )}
        </div>

        {/* Right Tools: Track Add, Zoom Slider & Export */}
        <div className="flex items-center space-x-3">
          {/* Add Track */}
          <div className="flex items-center space-x-1">
            <button
              onClick={() => handleAddTrack('video')}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 text-[11px]"
            >
              + Video Track
            </button>
            <button
              onClick={() => handleAddTrack('audio')}
              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 text-[11px]"
            >
              + Audio Track
            </button>
          </div>

          {/* Zoom Slider */}
          <div className="flex items-center space-x-1">
            <ZoomOut className="w-3 h-3 text-slate-400" />
            <input
              type="range"
              min="0.5"
              max="2.5"
              step="0.1"
              value={zoomLevel}
              onChange={(e) => setZoomLevel(Number(e.target.value))}
              className="w-20 h-1 bg-slate-700 rounded accent-sky-500 cursor-pointer"
            />
            <ZoomIn className="w-3 h-3 text-slate-400" />
          </div>

          {/* Export Project Master */}
          <button
            onClick={onExportTimeline}
            className="flex items-center space-x-1 px-3 py-1 bg-gradient-to-r from-sky-600 to-sky-500 hover:from-sky-500 hover:to-sky-400 text-white font-semibold rounded shadow transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Project</span>
          </button>
        </div>
      </div>

      {/* Main Timeline Workspace */}
      <div className="flex-1 flex overflow-hidden">
        {/* Track Headers (Fixed Left Column) */}
        <div className="w-48 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
          {/* Ruler Corner Header */}
          <div className="h-7 bg-slate-950 border-b border-slate-800 flex items-center px-3 font-mono text-[10px] text-slate-400">
            TRACKS & ROUTING
          </div>

          {/* Track Control Rows */}
          <div className="flex-1 overflow-y-auto">
            {project.tracks.map((track) => (
              <div
                key={track.id}
                className={`h-16 border-b border-slate-800/80 px-2 flex flex-col justify-center space-y-1 ${
                  track.type === 'video' ? 'bg-slate-900/60' : 'bg-slate-950/60'
                }`}
              >
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold font-mono text-slate-300">{track.name}</span>
                  <span className="text-[10px] px-1 py-0.2 bg-slate-800 rounded font-mono text-slate-400 uppercase">
                    {track.type}
                  </span>
                </div>

                <div className="flex items-center space-x-2 text-slate-400">
                  <button
                    onClick={() => toggleTrackLock(track.id)}
                    className={`hover:text-white ${track.isLocked ? 'text-amber-400' : ''}`}
                    title="Lock Track"
                  >
                    {track.isLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                  </button>

                  <button
                    onClick={() => toggleTrackVisible(track.id)}
                    className={`hover:text-white ${track.isHidden ? 'text-slate-600' : ''}`}
                    title="Toggle Visibility"
                  >
                    {!track.isHidden ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  </button>

                  <button
                    onClick={() => toggleTrackMute(track.id)}
                    className={`hover:text-white ${track.isMuted ? 'text-red-400' : ''}`}
                    title="Mute Track"
                  >
                    {track.isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Timeline Tracks & Ruler Canvas (Scrollable Horizontal Area) */}
        <div className="flex-1 flex flex-col overflow-x-auto overflow-y-hidden relative bg-slate-950">
          {/* SMPTE Timecode Ruler Header */}
          <div
            className="h-7 bg-slate-950 border-b border-slate-800 relative cursor-pointer"
            style={{ width: `${totalWidthPx}px` }}
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const clickX = e.clientX - rect.left;
              const newTime = Math.max(0, clickX / pxPerSecond);
              onSeek(newTime);
            }}
          >
            {/* Seconds ticks & labels */}
            {Array.from({ length: Math.ceil(totalTimelineDuration / 5) + 1 }).map((_, i) => {
              const sec = i * 5;
              const leftPx = sec * pxPerSecond;
              return (
                <div key={sec} className="absolute top-0 bottom-0 flex flex-col justify-end" style={{ left: `${leftPx}px` }}>
                  <span className="font-mono text-[9px] text-slate-400 pl-1">{formatSMPTETimecode(sec, fps)}</span>
                  <div className="w-px h-2 bg-slate-700" />
                </div>
              );
            })}

            {/* Timeline Markers */}
            {project.markers.map((m) => (
              <div
                key={m.id}
                className="absolute top-0 z-20 flex flex-col items-center cursor-pointer group"
                style={{ left: `${m.timestamp * pxPerSecond}px` }}
                onClick={(e) => {
                  e.stopPropagation();
                  onSeek(m.timestamp);
                }}
              >
                <div
                  className="w-2.5 h-2.5 transform rotate-45 shadow-sm"
                  style={{ backgroundColor: m.color || '#38bdf8' }}
                />
                <div className="hidden group-hover:block absolute top-4 bg-slate-900 border border-slate-700 px-1.5 py-0.5 rounded text-[10px] text-slate-200 whitespace-nowrap shadow-lg z-30">
                  {m.label} ({formatDuration(m.timestamp)})
                </div>
              </div>
            ))}
          </div>

          {/* Tracks Area */}
          <div className="flex-1 relative overflow-y-auto" style={{ width: `${totalWidthPx}px` }}>
            {/* Playhead Red Needle Indicator */}
            <div
              id="timeline-playhead"
              className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-30 pointer-events-none shadow-md"
              style={{ left: `${currentTime * pxPerSecond}px` }}
            >
              <div className="w-3 h-3 bg-red-500 transform -translate-x-1.5 -translate-y-1 rotate-45 shadow" />
            </div>

            {/* Track Lanes */}
            {project.tracks.map((track) => {
              const trackClips = project.clips.filter((c) => c.trackId === track.id);

              return (
                <div
                  key={track.id}
                  className={`h-16 border-b border-slate-800/80 relative transition ${
                    track.type === 'video' ? 'bg-slate-900/30' : 'bg-slate-950/40'
                  }`}
                >
                  {/* Clips inside track */}
                  {trackClips.map((clip) => {
                    const clipLeft = clip.timelineStart * pxPerSecond;
                    const clipWidth = Math.max(20, clip.timelineDuration * pxPerSecond);
                    const isSelected = selectedClipId === clip.id;
                    const sourceMedia = mediaLibrary.find((m) => m.id === clip.sourceMediaId);
                    const clipTitle = sourceMedia?.name || `Clip ${clip.id.slice(0, 6)}`;

                    return (
                      <div
                        key={clip.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedClipId(clip.id);
                        }}
                        className={`absolute top-1.5 bottom-1.5 rounded-md px-2 flex flex-col justify-between overflow-hidden cursor-move border transition shadow-sm ${
                          track.type === 'video'
                            ? isSelected
                              ? 'bg-sky-600 border-sky-300 text-white ring-2 ring-sky-400'
                              : 'bg-sky-950/80 border-sky-700/80 text-sky-200 hover:border-sky-500'
                            : isSelected
                            ? 'bg-emerald-600 border-emerald-300 text-white ring-2 ring-emerald-400'
                            : 'bg-emerald-950/80 border-emerald-700/80 text-emerald-200 hover:border-emerald-500'
                        }`}
                        style={{ left: `${clipLeft}px`, width: `${clipWidth}px` }}
                      >
                        {/* Clip Title & Duration */}
                        <div className="flex justify-between items-center text-[10px] font-semibold truncate pt-0.5">
                          <span className="truncate">{clipTitle}</span>
                          <span className="text-[9px] font-mono opacity-80 pl-1">{formatDuration(clip.timelineDuration)}</span>
                        </div>

                        {/* Waveform / Video graphic simulation */}
                        <div className="h-3 w-full opacity-40 flex items-center space-x-0.5">
                          {Array.from({ length: Math.min(24, Math.floor(clipWidth / 6)) }).map((_, i) => (
                            <div
                              key={i}
                              className={`w-1 rounded-sm ${track.type === 'video' ? 'bg-sky-300' : 'bg-emerald-300'}`}
                              style={{ height: `${20 + ((i * 17) % 80)}%` }}
                            />
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
