'use client';

import React, { useState, useRef, useEffect, useCallback, useSyncExternalStore } from 'react';

const subscribeToMount = () => () => {};
const getClientSnapshot = () => true;
const getServerSnapshot = () => false;
import { MediaItem, VideoColorGrading, ScopeHistogramData } from '@/types/media';
import { formatSMPTETimecode, formatDuration, formatPTS, secondsToFrameNumber } from '@/lib/timecode';
import { metalPipeline } from '@/lib/metal-engine';
import { coreAudioEngine } from '@/lib/audio-engine';
import {
  Play,
  Pause,
  RotateCcw,
  SkipBack,
  SkipForward,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  Repeat,
  Camera,
  Layers,
  Sliders,
  Maximize,
  PictureInPicture2,
  Activity,
  Grid3X3,
  SplitSquareVertical,
} from 'lucide-react';

interface VideoPlayerViewProps {
  media: MediaItem | null;
  colorGrading: VideoColorGrading;
  setColorGrading: React.Dispatch<React.SetStateAction<VideoColorGrading>>;
  inPoint: number | null;
  outPoint: number | null;
  setInPoint: (t: number | null) => void;
  setOutPoint: (t: number | null) => void;
  onCaptureFrame: (format?: 'png' | 'jpeg') => void;
  onOpenContactSheet: () => void;
  onAddMarkerAtCurrentTime: (time: number) => void;
  videoRef: React.RefObject<HTMLVideoElement | null>;
  onTimeUpdate?: (time: number) => void;
}

export const VideoPlayerView: React.FC<VideoPlayerViewProps> = ({
  media,
  colorGrading,
  setColorGrading,
  inPoint,
  outPoint,
  setInPoint,
  setOutPoint,
  onCaptureFrame,
  onOpenContactSheet,
  onAddMarkerAtCurrentTime,
  videoRef,
  onTimeUpdate,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const isMounted = useSyncExternalStore(subscribeToMount, getClientSnapshot, getServerSnapshot);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(media?.duration || 0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [volume, setVolume] = useState(1.0);
  const [isMuted, setIsMuted] = useState(false);
  const [loopMode, setLoopMode] = useState<'off' | 'media' | 'ab'>('off');

  // Scopes & Comparison modes
  const [showScopes, setShowScopes] = useState(false);
  const [scopeType, setScopeType] = useState<'histogram' | 'waveform' | 'vectorscope'>('histogram');
  const [comparisonMode, setComparisonMode] = useState<'normal' | 'wipe' | 'split'>('normal');
  const [wipePosition, setWipePosition] = useState(50); // percentage 0-100

  // Scope analyzed data
  const [histogramData, setHistogramData] = useState<ScopeHistogramData | null>(null);
  const [waveformCols, setWaveformCols] = useState<Float32Array[] | null>(null);
  const [vectorscopePoints, setVectorscopePoints] = useState<{ u: number; v: number }[] | null>(null);
  const [lumaStats, setLumaStats] = useState({ avg: 0, min: 0, max: 0 });

  // Audio VU Meter levels
  const [audioLevels, setAudioLevels] = useState({ leftDb: -60, rightDb: -60, leftPeak: 0, rightPeak: 0, isClipping: false });

  // Canvas refs for drawing scopes
  const histogramCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const waveformCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const vectorscopeCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const wipeContainerRef = useRef<HTMLDivElement | null>(null);

  const fps = media?.videoStream?.fps || 24;

  // Toggle Play / Pause
  const togglePlay = useCallback(() => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      coreAudioEngine.init(videoRef.current);
      coreAudioEngine.resume();
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  }, [videoRef]);

  // Frame Step Forward / Reverse
  const stepFrame = useCallback((forward: boolean) => {
    if (!videoRef.current) return;
    videoRef.current.pause();
    setIsPlaying(false);
    const frameDuration = 1 / fps;
    const newTime = forward ? videoRef.current.currentTime + frameDuration : videoRef.current.currentTime - frameDuration;
    videoRef.current.currentTime = Math.max(0, Math.min(videoRef.current.duration || 100, newTime));
    setCurrentTime(videoRef.current.currentTime);
  }, [fps, videoRef]);

  // Jump by seconds
  const jumpSeconds = useCallback((sec: number) => {
    if (!videoRef.current) return;
    videoRef.current.currentTime = Math.max(0, Math.min(videoRef.current.duration || 100, videoRef.current.currentTime + sec));
    setCurrentTime(videoRef.current.currentTime);
  }, [videoRef]);

  // Speed change
  const handleSpeedChange = (spd: number) => {
    setPlaybackSpeed(spd);
    if (videoRef.current) {
      videoRef.current.playbackRate = spd;
    }
  };

  // Video time update event
  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const t = videoRef.current.currentTime;
    setCurrentTime(t);
    if (onTimeUpdate) onTimeUpdate(t);

    // A-B loop check
    if (loopMode === 'ab' && inPoint !== null && outPoint !== null && outPoint > inPoint) {
      if (t >= outPoint || t < inPoint) {
        videoRef.current.currentTime = inPoint;
      }
    }
  };

  // Video ended event
  const handleEnded = () => {
    if (loopMode === 'media' && videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    } else {
      setIsPlaying(false);
    }
  };

  // Audio VU meter update loop & Metal scope analysis
  useEffect(() => {
    let animFrame: number;
    let frameCount = 0;

    const updateLoop = () => {
      // Audio metering
      const levels = coreAudioEngine.getLevels();
      setAudioLevels(levels);

      // Scope frame analysis every 4 frames (for high GPU efficiency)
      frameCount++;
      if (frameCount % 4 === 0 && showScopes && videoRef.current) {
        const analysis = metalPipeline.analyzeFrame(videoRef.current, 160, 90);
        if (analysis) {
          setHistogramData(analysis.histogram);
          setWaveformCols(analysis.waveform);
          setVectorscopePoints(analysis.vectorscopeData);
          setLumaStats({ avg: analysis.avgLuma, min: analysis.minLuma, max: analysis.maxLuma });
        }
      }

      animFrame = requestAnimationFrame(updateLoop);
    };

    animFrame = requestAnimationFrame(updateLoop);
    return () => cancelAnimationFrame(animFrame);
  }, [showScopes, videoRef]);

  // Draw Histogram Canvas
  useEffect(() => {
    if (!histogramCanvasRef.current || !histogramData || scopeType !== 'histogram') return;
    const canvas = histogramCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const maxVal = Math.max(...histogramData.luma, 1);
    const w = canvas.width / 256;
    const h = canvas.height;

    // Draw Luma
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    for (let i = 0; i < 256; i++) {
      const barH = (histogramData.luma[i] / maxVal) * (h - 10);
      ctx.fillRect(i * w, h - barH, w, barH);
    }

    // Draw RGB overlay
    ctx.fillStyle = 'rgba(239, 68, 68, 0.4)';
    for (let i = 0; i < 256; i++) {
      const barH = (histogramData.red[i] / maxVal) * (h - 10);
      ctx.fillRect(i * w, h - barH, w, barH);
    }
    ctx.fillStyle = 'rgba(34, 197, 94, 0.4)';
    for (let i = 0; i < 256; i++) {
      const barH = (histogramData.green[i] / maxVal) * (h - 10);
      ctx.fillRect(i * w, h - barH, w, barH);
    }
    ctx.fillStyle = 'rgba(59, 130, 246, 0.4)';
    for (let i = 0; i < 256; i++) {
      const barH = (histogramData.blue[i] / maxVal) * (h - 10);
      ctx.fillRect(i * w, h - barH, w, barH);
    }

    // Grid lines (0, 64, 128, 192, 255)
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    [0, 64, 128, 192, 255].forEach((v) => {
      ctx.beginPath();
      ctx.moveTo(v * w, 0);
      ctx.lineTo(v * w, h);
      ctx.stroke();
    });
  }, [histogramData, scopeType]);

  // Draw Waveform Monitor (0-100 IRE)
  useEffect(() => {
    if (!waveformCanvasRef.current || !waveformCols || scopeType !== 'waveform') return;
    const canvas = waveformCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const cols = waveformCols.length;
    const stepX = canvas.width / cols;

    for (let x = 0; x < cols; x++) {
      const column = waveformCols[x];
      for (let ire = 0; ire <= 100; ire++) {
        const count = column[ire];
        if (count > 0) {
          const y = canvas.height - (ire / 100) * (canvas.height - 12) - 6;
          const alpha = Math.min(1.0, 0.2 + count * 0.15);
          ctx.fillStyle = `rgba(56, 189, 248, ${alpha})`;
          ctx.fillRect(x * stepX, y, stepX + 0.5, 1.5);
        }
      }
    }

    // IRE Reference Grid lines (0 IRE, 50 IRE, 100 IRE)
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.25)';
    ctx.lineWidth = 1;
    [0, 25, 50, 75, 100].forEach((ire) => {
      const y = canvas.height - (ire / 100) * (canvas.height - 12) - 6;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();

      ctx.fillStyle = '#64748b';
      ctx.font = '9px monospace';
      ctx.fillText(`${ire}`, 4, y - 2);
    });
  }, [waveformCols, scopeType]);

  // Draw Vectorscope Canvas
  useEffect(() => {
    if (!vectorscopeCanvasRef.current || !vectorscopePoints || scopeType !== 'vectorscope') return;
    const canvas = vectorscopeCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    const cx = w / 2;
    const cy = h / 2;
    const radius = Math.min(cx, cy) - 16;

    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, w, h);

    // Outer circle
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.stroke();

    // Crosshairs
    ctx.beginPath();
    ctx.moveTo(cx, cy - radius);
    ctx.lineTo(cx, cy + radius);
    ctx.moveTo(cx - radius, cy);
    ctx.lineTo(cx + radius, cy);
    ctx.stroke();

    // Standard SMPTE Broadcast Target Boxes (R, Mg, B, Cy, G, Yl)
    const targets = [
      { label: 'R', u: 0.615 * 0.5, v: -0.558 * 0.5, color: '#ef4444' },
      { label: 'Mg', u: 0.4 * 0.5, v: 0.4 * 0.5, color: '#ec4899' },
      { label: 'B', u: -0.15 * 0.5, v: 0.5 * 0.5, color: '#3b82f6' },
      { label: 'Cy', u: -0.6 * 0.5, v: 0.1 * 0.5, color: '#06b6d4' },
      { label: 'G', u: -0.4 * 0.5, v: -0.4 * 0.5, color: '#22c55e' },
      { label: 'Yl', u: 0.15 * 0.5, v: -0.5 * 0.5, color: '#eab308' },
    ];

    targets.forEach((t) => {
      const tx = cx + t.u * radius * 1.6;
      const ty = cy + t.v * radius * 1.6;
      ctx.strokeStyle = t.color;
      ctx.strokeRect(tx - 4, ty - 4, 8, 8);
      ctx.fillStyle = t.color;
      ctx.font = '8px monospace';
      ctx.fillText(t.label, tx + 6, ty + 3);
    });

    // Draw Chroma point cloud
    ctx.fillStyle = 'rgba(56, 189, 248, 0.4)';
    vectorscopePoints.forEach((p) => {
      const px = cx + (p.u / 128) * radius;
      const py = cy + (p.v / 128) * radius;
      ctx.fillRect(px, py, 1.5, 1.5);
    });
  }, [vectorscopePoints, scopeType]);

  // CSS Filter string from color grading parameters
  const cssFilter = metalPipeline.generateCssFilter(colorGrading);

  return (
    <div id="video-player-view" className="flex flex-col h-full bg-slate-950 text-slate-200 select-none">
      {/* Top Toolbar: Scopes, Wipe Comparison, PiP, Fullscreen */}
      <div className="h-10 bg-slate-900 border-b border-slate-800 flex items-center justify-between px-4 text-xs">
        {/* Left: Comparison & Scopes buttons */}
        <div className="flex items-center space-x-2">
          {/* Comparison Mode Toggle */}
          <div className="flex items-center bg-slate-950 p-0.5 rounded border border-slate-800">
            <button
              onClick={() => setComparisonMode('normal')}
              className={`px-2 py-0.5 rounded ${comparisonMode === 'normal' ? 'bg-slate-800 text-sky-400 font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Normal
            </button>
            <button
              onClick={() => setComparisonMode('wipe')}
              className={`px-2 py-0.5 rounded flex items-center space-x-1 ${comparisonMode === 'wipe' ? 'bg-sky-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
              title="Before / After Wipe Slider"
            >
              <SplitSquareVertical className="w-3 h-3" />
              <span>Wipe</span>
            </button>
            <button
              onClick={() => setComparisonMode('split')}
              className={`px-2 py-0.5 rounded ${comparisonMode === 'split' ? 'bg-sky-600 text-white font-semibold' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Split Screen
            </button>
          </div>

          {/* Video Scopes Toggle */}
          <button
            onClick={() => setShowScopes(!showScopes)}
            className={`flex items-center space-x-1 px-2.5 py-1 rounded border text-xs transition ${
              showScopes ? 'bg-sky-600 border-sky-500 text-white font-semibold' : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Video Scopes</span>
          </button>

          {showScopes && (
            <div className="flex items-center bg-slate-950 p-0.5 rounded border border-slate-800">
              <button
                onClick={() => setScopeType('histogram')}
                className={`px-2 py-0.5 rounded text-[11px] ${scopeType === 'histogram' ? 'bg-slate-800 text-sky-400 font-bold' : 'text-slate-400'}`}
              >
                Histogram
              </button>
              <button
                onClick={() => setScopeType('waveform')}
                className={`px-2 py-0.5 rounded text-[11px] ${scopeType === 'waveform' ? 'bg-slate-800 text-sky-400 font-bold' : 'text-slate-400'}`}
              >
                Waveform (IRE)
              </button>
              <button
                onClick={() => setScopeType('vectorscope')}
                className={`px-2 py-0.5 rounded text-[11px] ${scopeType === 'vectorscope' ? 'bg-slate-800 text-sky-400 font-bold' : 'text-slate-400'}`}
              >
                Vectorscope
              </button>
            </div>
          )}
        </div>

        {/* Right Tools: Capture, Contact Sheet, PiP */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onCaptureFrame('png')}
            className="flex items-center space-x-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 hover:text-white transition text-xs"
            title="Capture Native Frame (⌥⌘C)"
          >
            <Camera className="w-3.5 h-3.5 text-sky-400" />
            <span>Capture Frame</span>
          </button>

          <button
            onClick={onOpenContactSheet}
            className="flex items-center space-x-1 px-2 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-slate-300 hover:text-white transition text-xs"
            title="Generate Contact Sheet Grid"
          >
            <Grid3X3 className="w-3.5 h-3.5 text-amber-400" />
            <span>Contact Sheet</span>
          </button>

          {isMounted && typeof document !== 'undefined' && document.pictureInPictureEnabled && (
            <button
              onClick={async () => {
                if (!videoRef.current) return;
                try {
                  if (document.pictureInPictureElement) {
                    await document.exitPictureInPicture();
                  } else {
                    await videoRef.current.requestPictureInPicture();
                  }
                } catch {}
              }}
              className="p-1 bg-[#2A2A2A] hover:bg-[#333333] border border-[#333333] rounded text-[#E0E0E0] hover:text-white"
              title="Picture in Picture"
            >
              <PictureInPicture2 className="w-3.5 h-3.5 text-[#007AFF]" />
            </button>
          )}
        </div>
      </div>

      {/* Main Center Video Area & Scopes */}
      <div className="flex-1 relative flex overflow-hidden bg-black items-center justify-center">
        {/* Video Canvas Container */}
        <div ref={wipeContainerRef} className="relative w-full h-full flex items-center justify-center p-2">
          {media ? (
            comparisonMode === 'normal' ? (
              <video
                ref={videoRef}
                src={media.url}
                className="max-h-full max-w-full rounded shadow-2xl object-contain"
                style={{ filter: cssFilter }}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={() => {
                  if (videoRef.current) {
                    setDuration(videoRef.current.duration);
                  }
                }}
                onEnded={handleEnded}
                playsInline
                crossOrigin="anonymous"
              />
            ) : comparisonMode === 'wipe' ? (
              /* Before / After Wipe Slider */
              <div className="relative max-h-full max-w-full flex items-center justify-center overflow-hidden">
                {/* Processed video (Graded) */}
                <video
                  ref={videoRef}
                  src={media.url}
                  className="max-h-full max-w-full rounded object-contain"
                  style={{ filter: cssFilter }}
                  onTimeUpdate={handleTimeUpdate}
                  onEnded={handleEnded}
                  playsInline
                  crossOrigin="anonymous"
                />

                {/* Original video clipped via wipe slider position */}
                <div
                  className="absolute inset-0 overflow-hidden pointer-events-none"
                  style={{ width: `${wipePosition}%`, borderRight: '2px solid #38bdf8' }}
                >
                  <video
                    src={media.url}
                    className="max-h-full max-w-full object-contain"
                    style={{ filter: 'none' }}
                    playsInline
                    muted
                  />
                  <span className="absolute top-2 left-2 bg-slate-900/80 px-2 py-0.5 rounded text-[10px] text-slate-300 font-mono">
                    ORIGINAL (RAW)
                  </span>
                </div>

                <span className="absolute top-2 right-2 bg-sky-950/80 border border-sky-600 px-2 py-0.5 rounded text-[10px] text-sky-300 font-mono">
                  PROCESSED (GRADED)
                </span>

                {/* Wipe Position Range Bar */}
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={wipePosition}
                  onChange={(e) => setWipePosition(Number(e.target.value))}
                  className="absolute bottom-4 left-1/4 right-1/4 h-1 bg-sky-500/50 rounded cursor-ew-resize z-20"
                />
              </div>
            ) : (
              /* Split Screen Comparison */
              <div className="grid grid-cols-2 gap-2 w-full h-full max-h-full p-2">
                <div className="relative flex flex-col items-center justify-center bg-slate-900/60 rounded border border-slate-800 p-1">
                  <span className="absolute top-2 left-2 bg-slate-950/90 text-slate-300 text-[10px] px-2 py-0.5 rounded font-mono z-10">
                    ORIGINAL SOURCE
                  </span>
                  <video
                    src={media.url}
                    className="max-h-full max-w-full object-contain"
                    style={{ filter: 'none' }}
                    muted
                  />
                </div>
                <div className="relative flex flex-col items-center justify-center bg-slate-900/60 rounded border border-sky-900/60 p-1">
                  <span className="absolute top-2 left-2 bg-sky-950/90 text-sky-300 text-[10px] px-2 py-0.5 rounded font-mono z-10">
                    METAL GRADED
                  </span>
                  <video
                    ref={videoRef}
                    src={media.url}
                    className="max-h-full max-w-full object-contain"
                    style={{ filter: cssFilter }}
                    onTimeUpdate={handleTimeUpdate}
                    onEnded={handleEnded}
                    playsInline
                    crossOrigin="anonymous"
                  />
                </div>
              </div>
            )
          ) : (
            <div className="flex flex-col items-center justify-center text-slate-500 space-y-2">
              <Play className="w-12 h-12 opacity-30" />
              <p className="text-sm">No media loaded. Open a file to begin.</p>
            </div>
          )}
        </div>

        {/* Floating Real-time Scope Panel */}
        {showScopes && (
          <div
            id="scope-overlay"
            className="absolute top-3 right-3 w-72 bg-slate-900/95 border border-slate-700/80 rounded-xl p-3 shadow-2xl backdrop-blur-md z-30 flex flex-col space-y-2"
          >
            <div className="flex justify-between items-center text-xs pb-1 border-b border-slate-800 font-semibold text-slate-300">
              <span>{scopeType === 'histogram' ? 'RGB & Luma Histogram' : scopeType === 'waveform' ? 'Luminance Waveform (IRE)' : 'Chroma Vectorscope'}</span>
              <span className="text-[10px] text-sky-400 font-mono">GPU Real-time</span>
            </div>

            {scopeType === 'histogram' && (
              <div>
                <canvas ref={histogramCanvasRef} width={256} height={110} className="w-full h-28 rounded border border-slate-800 bg-slate-950" />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1 px-1">
                  <span>0 (Blacks)</span>
                  <span>128 (Mids)</span>
                  <span>255 (Highlights)</span>
                </div>
              </div>
            )}

            {scopeType === 'waveform' && (
              <div>
                <canvas ref={waveformCanvasRef} width={240} height={120} className="w-full h-32 rounded border border-slate-800 bg-slate-950" />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1 px-1">
                  <span>Avg Luma: {Math.round(lumaStats.avg)}</span>
                  <span>Min: {lumaStats.min}</span>
                  <span>Max: {lumaStats.max}</span>
                </div>
              </div>
            )}

            {scopeType === 'vectorscope' && (
              <div>
                <canvas ref={vectorscopeCanvasRef} width={200} height={200} className="w-48 h-48 mx-auto rounded border border-slate-800 bg-slate-950" />
                <div className="text-center text-[10px] text-slate-400 font-mono mt-1">
                  BT.709 75% Color Bars Target
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Scrubbing Timeline Bar with In/Out markers */}
      <div className="h-10 bg-slate-900 border-t border-slate-800 px-4 flex items-center space-x-3 text-xs">
        {/* Current Timecode */}
        <div className="flex items-center space-x-2 font-mono shrink-0">
          <span className="text-sky-400 font-bold tracking-wider text-sm">
            {formatSMPTETimecode(currentTime, fps)}
          </span>
          <span className="text-slate-500 text-[10px]">
            / {formatSMPTETimecode(duration, fps)}
          </span>
        </div>

        {/* Main scrubber bar with In/Out markers */}
        <div className="relative flex-1 flex items-center h-6 group">
          {/* Background rail */}
          <div className="absolute inset-x-0 h-1.5 bg-slate-800 rounded-full overflow-hidden">
            {/* Progress */}
            <div
              className="h-full bg-gradient-to-r from-sky-500 to-sky-400 rounded-full"
              style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
            />
          </div>

          {/* In/Out highlight range */}
          {inPoint !== null && outPoint !== null && (
            <div
              className="absolute h-2.5 bg-sky-500/25 border-l-2 border-r-2 border-sky-400 pointer-events-none"
              style={{
                left: `${(inPoint / (duration || 1)) * 100}%`,
                width: `${Math.max(0, ((outPoint - inPoint) / (duration || 1)) * 100)}%`,
              }}
            />
          )}

          {/* Interactive range input */}
          <input
            id="video-scrubber-slider"
            type="range"
            min={0}
            max={duration || 100}
            step={1 / fps}
            value={currentTime}
            onChange={(e) => {
              const t = Number(e.target.value);
              setCurrentTime(t);
              if (videoRef.current) {
                videoRef.current.currentTime = t;
              }
            }}
            className="absolute inset-x-0 w-full h-full opacity-0 cursor-pointer z-10"
          />

          {/* Playhead thumb handle */}
          <div
            className="absolute w-3 h-3 bg-white border border-sky-500 rounded-full shadow-md pointer-events-none transform -translate-x-1/2"
            style={{ left: `${(currentTime / (duration || 1)) * 100}%` }}
          />
        </div>

        {/* Frame & PTS specs */}
        <div className="hidden sm:flex items-center space-x-3 text-[11px] font-mono text-slate-400 shrink-0">
          <span>FR: {secondsToFrameNumber(currentTime, fps)}</span>
          <span>PTS: {formatPTS(currentTime)}</span>
          <span className="text-sky-400">{fps} fps</span>
        </div>
      </div>

      {/* Main Transport Control Panel */}
      <div
        id="player-transport-controls"
        className="h-16 bg-slate-900/90 border-t border-slate-800 flex items-center justify-between px-6 select-none"
      >
        {/* Left: Shuttle & Frame step */}
        <div className="flex items-center space-x-1.5">
          <button
            id="btn-prev-frame"
            onClick={() => stepFrame(false)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700 transition"
            title="Previous Frame (←)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            id="btn-jump-back"
            onClick={() => jumpSeconds(-5)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700 transition"
            title="Jump 5s Back (J)"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          {/* Primary Play/Pause Button */}
          <button
            id="btn-play-pause-main"
            onClick={togglePlay}
            className="p-3 bg-gradient-to-b from-sky-500 to-sky-600 hover:from-sky-400 hover:to-sky-500 text-white rounded-full shadow-lg transition active:scale-95"
            title="Play / Pause (Space)"
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
          </button>

          <button
            id="btn-jump-forward"
            onClick={() => jumpSeconds(5)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700 transition"
            title="Jump 5s Forward (L)"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          <button
            id="btn-next-frame"
            onClick={() => stepFrame(true)}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded border border-slate-700 transition"
            title="Next Frame (→)"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Center: In / Out points & Loop mode */}
        <div className="flex items-center space-x-2">
          {/* In Point */}
          <button
            id="btn-set-in-point"
            onClick={() => setInPoint(currentTime)}
            className={`px-2.5 py-1 rounded text-xs border transition ${
              inPoint !== null ? 'bg-sky-950 border-sky-600 text-sky-300 font-bold' : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title="Mark In Point (I)"
          >
            IN {inPoint !== null ? formatDuration(inPoint) : '--:--'}
          </button>

          {/* Out Point */}
          <button
            id="btn-set-out-point"
            onClick={() => setOutPoint(currentTime)}
            className={`px-2.5 py-1 rounded text-xs border transition ${
              outPoint !== null ? 'bg-sky-950 border-sky-600 text-sky-300 font-bold' : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title="Mark Out Point (O)"
          >
            OUT {outPoint !== null ? formatDuration(outPoint) : '--:--'}
          </button>

          {(inPoint !== null || outPoint !== null) && (
            <button
              onClick={() => { setInPoint(null); setOutPoint(null); }}
              className="text-[10px] text-slate-500 hover:text-slate-300 underline px-1"
            >
              Clear
            </button>
          )}

          {/* Loop Mode Toggle */}
          <button
            id="btn-toggle-loop"
            onClick={() => {
              if (loopMode === 'off') setLoopMode('media');
              else if (loopMode === 'media') setLoopMode('ab');
              else setLoopMode('off');
            }}
            className={`flex items-center space-x-1 px-2 py-1 rounded text-xs border transition ${
              loopMode !== 'off' ? 'bg-sky-600 border-sky-500 text-white font-semibold' : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700'
            }`}
            title="Toggle Loop Mode"
          >
            <Repeat className="w-3.5 h-3.5" />
            <span className="uppercase text-[10px]">{loopMode === 'ab' ? 'A-B Loop' : loopMode === 'media' ? 'Media Loop' : 'Loop Off'}</span>
          </button>
        </div>

        {/* Right: Playback Speed, Stereo VU Meters & Volume */}
        <div className="flex items-center space-x-4">
          {/* Speed Selector */}
          <div className="flex items-center space-x-1 text-xs">
            <span className="text-slate-400 text-[10px]">Speed:</span>
            <select
              id="playback-speed-select"
              value={playbackSpeed}
              onChange={(e) => handleSpeedChange(Number(e.target.value))}
              className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded px-2 py-1 focus:outline-none focus:border-sky-500 font-mono cursor-pointer"
            >
              <option value={0.25}>0.25x</option>
              <option value={0.5}>0.5x</option>
              <option value={0.75}>0.75x</option>
              <option value={1.0}>1.0x (Normal)</option>
              <option value={1.25}>1.25x</option>
              <option value={1.5}>1.5x</option>
              <option value={2.0}>2.0x</option>
              <option value={4.0}>4.0x</option>
              <option value={8.0}>8.0x</option>
            </select>
          </div>

          {/* Real-time Stereo Audio Level Meters (L & R) */}
          <div className="flex flex-col space-y-1 w-24 bg-slate-950 p-1.5 rounded border border-slate-800" title="Core Audio Stereo Peak Meter">
            {/* Left channel */}
            <div className="flex items-center space-x-1 text-[9px] font-mono">
              <span className="text-slate-500 w-2">L</span>
              <div className="flex-1 h-1.5 bg-slate-800 rounded-sm overflow-hidden flex">
                <div
                  className={`h-full transition-all duration-75 ${audioLevels.leftDb > -3 ? 'bg-red-500' : audioLevels.leftDb > -12 ? 'bg-amber-400' : 'bg-emerald-400'}`}
                  style={{ width: `${Math.max(0, ((audioLevels.leftDb + 60) / 60) * 100)}%` }}
                />
              </div>
            </div>
            {/* Right channel */}
            <div className="flex items-center space-x-1 text-[9px] font-mono">
              <span className="text-slate-500 w-2">R</span>
              <div className="flex-1 h-1.5 bg-slate-800 rounded-sm overflow-hidden flex">
                <div
                  className={`h-full transition-all duration-75 ${audioLevels.rightDb > -3 ? 'bg-red-500' : audioLevels.rightDb > -12 ? 'bg-amber-400' : 'bg-emerald-400'}`}
                  style={{ width: `${Math.max(0, ((audioLevels.rightDb + 60) / 60) * 100)}%` }}
                />
              </div>
            </div>
          </div>

          {/* Volume Control */}
          <div className="flex items-center space-x-1.5">
            <button
              id="btn-volume-mute"
              onClick={() => {
                const nextMuted = !isMuted;
                setIsMuted(nextMuted);
                if (videoRef.current) {
                  videoRef.current.muted = nextMuted;
                }
                coreAudioEngine.setVolume(nextMuted ? 0 : volume);
              }}
              className="text-slate-400 hover:text-slate-200"
            >
              {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-slate-300" />}
            </button>
            <input
              id="player-volume-slider"
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : volume}
              onChange={(e) => {
                const v = Number(e.target.value);
                setVolume(v);
                setIsMuted(false);
                if (videoRef.current) {
                  videoRef.current.volume = v;
                  videoRef.current.muted = false;
                }
                coreAudioEngine.setVolume(v);
              }}
              className="w-16 h-1 bg-slate-700 rounded cursor-pointer accent-sky-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
