'use client';

import React, { useState } from 'react';
import { LanguageCode } from '@/types/media';
import { LOCALES } from '@/lib/localisation';
import {
  Settings,
  X,
  Play,
  Disc,
  Film,
  RefreshCw,
  Gauge,
  Music,
  Tv,
  Palette,
  HardDrive,
  ShieldCheck,
  Keyboard,
  Globe,
  Sliders,
  Check,
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: LanguageCode;
  setLang: (l: LanguageCode) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  lang,
  setLang,
}) => {
  const [activeTab, setActiveTab] = useState<string>('general');

  // General settings state
  const [autoSaveInterval, setAutoSaveInterval] = useState(60);
  const [hardwareDecodeEnabled, setHardwareDecodeEnabled] = useState(true);
  const [defaultFps, setDefaultFps] = useState(24);
  const [colorPrimaries, setColorPrimaries] = useState('Rec.709');
  const [aiLocalOnly, setAiLocalOnly] = useState(false);
  const [showSaveAlert, setShowSaveAlert] = useState(false);

  if (!isOpen) return null;

  const tabs = [
    { id: 'general', label: 'General', icon: <Settings className="w-4 h-4" /> },
    { id: 'playback', label: 'Playback Engine', icon: <Play className="w-4 h-4" /> },
    { id: 'recording', label: 'Recording Suite', icon: <Disc className="w-4 h-4" /> },
    { id: 'editing', label: 'Timeline Editing', icon: <Film className="w-4 h-4" /> },
    { id: 'export', label: 'Export & Codecs', icon: <RefreshCw className="w-4 h-4" /> },
    { id: 'performance', label: 'Metal Performance', icon: <Gauge className="w-4 h-4" /> },
    { id: 'audio', label: 'Core Audio', icon: <Music className="w-4 h-4" /> },
    { id: 'video', label: 'Video Scopes', icon: <Tv className="w-4 h-4" /> },
    { id: 'colour', label: 'Color Management', icon: <Palette className="w-4 h-4" /> },
    { id: 'storage', label: 'Storage & DB', icon: <HardDrive className="w-4 h-4" /> },
    { id: 'ai', label: 'AI & Privacy', icon: <ShieldCheck className="w-4 h-4" /> },
    { id: 'shortcuts', label: 'Keyboard Shortcuts', icon: <Keyboard className="w-4 h-4" /> },
    { id: 'localisation', label: 'Language & Region', icon: <Globe className="w-4 h-4" /> },
    { id: 'advanced', label: 'Advanced Engine', icon: <Sliders className="w-4 h-4" /> },
  ];

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4 select-none">
      <div
        id="settings-modal"
        className="w-full max-w-3xl bg-[#1E1E1E] border border-[#2A2A2A] rounded-xl shadow-2xl flex flex-col h-[560px] overflow-hidden text-[#E0E0E0]"
      >
        {/* Modal Header */}
        <div className="h-12 bg-[#181818] px-5 flex items-center justify-between border-b border-[#2A2A2A]">
          <div className="flex items-center space-x-2">
            <Settings className="w-4 h-4 text-[#007AFF]" />
            <span className="font-bold text-sm text-[#E0E0E0]">PREFERENCES & ENGINE SETTINGS</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#2A2A2A] rounded-md text-[#888888] hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Layout: Left Sidebar + Right Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Tab List */}
          <div className="w-52 bg-[#151515] border-r border-[#2A2A2A] p-2 overflow-y-auto space-y-0.5 text-xs">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center space-x-2 px-3 py-2 rounded-lg text-left transition font-medium ${
                  activeTab === tab.id
                    ? 'bg-[#007AFF] text-white font-semibold shadow-sm'
                    : 'text-[#AAAAAA] hover:text-[#E0E0E0] hover:bg-[#2A2A2A]'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Right Content Area */}
          <div className="flex-1 p-6 overflow-y-auto text-xs space-y-4">
            {/* GENERAL TAB */}
            {activeTab === 'general' && (
              <div className="space-y-4">
                <h3 className="font-bold text-sm text-slate-100">General Workspace Preferences</h3>

                <div className="space-y-1">
                  <label className="text-slate-400 block">Project Auto-Save Interval (Seconds)</label>
                  <input
                    type="number"
                    value={autoSaveInterval}
                    onChange={(e) => setAutoSaveInterval(Number(e.target.value))}
                    className="w-40 bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200 font-mono"
                  />
                  <p className="text-[11px] text-slate-500">Auto-saves state to SQLite recovery store on crash.</p>
                </div>

                <div className="space-y-2 pt-2">
                  <label className="flex items-center space-x-2 text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={hardwareDecodeEnabled}
                      onChange={(e) => setHardwareDecodeEnabled(e.target.checked)}
                      className="rounded border-slate-700 text-sky-500"
                    />
                    <span>Hardware VideoToolbox Decode by Default</span>
                  </label>
                </div>
              </div>
            )}

            {/* PLAYBACK TAB */}
            {activeTab === 'playback' && (
              <div className="space-y-4">
                <h3 className="font-bold text-sm text-slate-100">Playback Engine Settings</h3>
                <div className="space-y-1">
                  <label className="text-slate-400 block">Default Project Frame Rate</label>
                  <select
                    value={defaultFps}
                    onChange={(e) => setDefaultFps(Number(e.target.value))}
                    className="w-48 bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-slate-200"
                  >
                    <option value={24}>24.000 fps (Cinematic Film)</option>
                    <option value={30}>30.000 fps (Broadcast NTSC)</option>
                    <option value={60}>60.000 fps (High Motion)</option>
                  </select>
                </div>
              </div>
            )}

            {/* SHORTCUTS TAB */}
            {activeTab === 'shortcuts' && (
              <div className="space-y-3">
                <h3 className="font-bold text-sm text-slate-100">macOS Native Keyboard Shortcuts</h3>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>Play / Pause</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px]">Space</kbd>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>Previous Frame</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px]">←</kbd>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>Next Frame</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px]">→</kbd>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>Mark In Point</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px]">I</kbd>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>Mark Out Point</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px]">O</kbd>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>Split Clip at Playhead</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px]">⌘B</kbd>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>Add Marker</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px]">M</kbd>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                    <span>Capture Frame</span>
                    <kbd className="px-1.5 py-0.5 bg-slate-800 rounded font-mono text-[10px]">⌥⌘C</kbd>
                  </div>
                </div>
              </div>
            )}

            {/* LOCALISATION TAB */}
            {activeTab === 'localisation' && (
              <div className="space-y-4">
                <h3 className="font-bold text-sm text-slate-100">Language & Region Selection</h3>
                <div className="space-y-2">
                  {Object.entries(LOCALES).map(([code, item]) => (
                    <button
                      key={code}
                      onClick={() => setLang(code as LanguageCode)}
                      className={`w-full p-2.5 rounded-lg border text-left flex justify-between items-center transition ${
                        lang === code
                          ? 'bg-sky-950/80 border-sky-600 text-white font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <span className="text-base">{item.flag}</span>
                        <span>{item.label}</span>
                      </div>
                      {lang === code && <Check className="w-4 h-4 text-sky-400" />}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* AI & PRIVACY TAB */}
            {activeTab === 'ai' && (
              <div className="space-y-4">
                <h3 className="font-bold text-sm text-slate-100">AI Privacy & Security Guard</h3>
                <div className="p-3 bg-emerald-950/40 border border-emerald-800 rounded-xl space-y-2">
                  <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Local-First Media Architecture</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Your raw video files, screen recordings, and audio streams never leave your device. All video decoding, playback, color grading, and transcoding happen 100% locally on your macOS hardware.
                  </p>
                </div>

                <label className="flex items-center space-x-2 text-slate-300 cursor-pointer pt-2">
                  <input
                    type="checkbox"
                    checked={aiLocalOnly}
                    onChange={(e) => setAiLocalOnly(e.target.checked)}
                    className="rounded border-slate-700 text-sky-500"
                  />
                  <span>Strict Local AI Only (Disable Cloud Gemini Invocations)</span>
                </label>
              </div>
            )}

            {/* DEFAULT FALLBACK TAB */}
            {!['general', 'playback', 'shortcuts', 'localisation', 'ai'].includes(activeTab) && (
              <div className="space-y-4">
                <h3 className="font-bold text-sm text-slate-100 capitalize">{activeTab} Configuration</h3>
                <p className="text-slate-400">
                  Settings are stored in the local SQLite preference key-value store. All modifications take effect immediately without requiring application restart.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="h-12 bg-slate-950 px-5 flex items-center justify-between border-t border-slate-800">
          <span className="text-[11px] text-slate-500 font-mono">MACVIDEO.PRO Build 2026.3.8-Darwin</span>
          <button
            onClick={() => {
              setShowSaveAlert(true);
              setTimeout(() => {
                setShowSaveAlert(false);
                onClose();
              }, 600);
            }}
            className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold rounded-lg text-xs transition"
          >
            {showSaveAlert ? 'Saved!' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};
