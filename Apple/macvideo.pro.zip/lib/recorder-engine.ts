import { MediaItem } from '@/types/media';

export interface RecorderOptions {
  type: 'screen' | 'camera' | 'audio';
  includeMic: boolean;
  includeSystemAudio: boolean;
  videoResolution: '4K' | '1080p' | '720p';
  frameRate: 60 | 30 | 24;
  videoCodec: 'vp9' | 'h264' | 'vp8';
  selectedAudioDeviceId?: string;
  selectedVideoDeviceId?: string;
}

export class RecorderEngine {
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  private activeStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;

  public async getAvailableDevices(): Promise<{ audioInputs: MediaDeviceInfo[]; videoInputs: MediaDeviceInfo[] }> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.enumerateDevices) {
      return { audioInputs: [], videoInputs: [] };
    }
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      return {
        audioInputs: devices.filter((d) => d.kind === 'audioinput'),
        videoInputs: devices.filter((d) => d.kind === 'videoinput'),
      };
    } catch {
      return { audioInputs: [], videoInputs: [] };
    }
  }

  public async startRecording(options: RecorderOptions): Promise<MediaStream> {
    this.recordedChunks = [];
    let combinedStream: MediaStream;

    if (options.type === 'screen') {
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          frameRate: { ideal: options.frameRate },
          width: options.videoResolution === '4K' ? 3840 : options.videoResolution === '1080p' ? 1920 : 1280,
          height: options.videoResolution === '4K' ? 2160 : options.videoResolution === '1080p' ? 1080 : 720,
        },
        audio: options.includeSystemAudio,
      });

      if (options.includeMic) {
        try {
          const micStream = await navigator.mediaDevices.getUserMedia({
            audio: options.selectedAudioDeviceId ? { deviceId: { exact: options.selectedAudioDeviceId } } : true,
          });
          // Mix mic and display audio
          combinedStream = new MediaStream([
            ...displayStream.getVideoTracks(),
            ...displayStream.getAudioTracks(),
            ...micStream.getAudioTracks(),
          ]);
        } catch {
          combinedStream = displayStream;
        }
      } else {
        combinedStream = displayStream;
      }
    } else if (options.type === 'camera') {
      combinedStream = await navigator.mediaDevices.getUserMedia({
        video: {
          deviceId: options.selectedVideoDeviceId ? { exact: options.selectedVideoDeviceId } : undefined,
          width: options.videoResolution === '1080p' ? 1920 : 1280,
          height: options.videoResolution === '1080p' ? 1080 : 720,
          frameRate: { ideal: options.frameRate },
        },
        audio: options.includeMic
          ? options.selectedAudioDeviceId ? { deviceId: { exact: options.selectedAudioDeviceId } } : true
          : false,
      });
    } else {
      // Audio only
      combinedStream = await navigator.mediaDevices.getUserMedia({
        audio: options.selectedAudioDeviceId ? { deviceId: { exact: options.selectedAudioDeviceId } } : true,
        video: false,
      });
    }

    this.activeStream = combinedStream;

    // Hook audio analyser for telemetry
    if (combinedStream.getAudioTracks().length > 0) {
      try {
        const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.audioContext = new AudioCtxClass();
        const src = this.audioContext.createMediaStreamSource(combinedStream);
        this.analyser = this.audioContext.createAnalyser();
        src.connect(this.analyser);
      } catch {
        // Audio analysis not critical
      }
    }

    // Determine MIME type supported by browser
    let mimeType = 'video/webm;codecs=vp9,opus';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/webm;codecs=vp8,opus';
    }
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/webm';
    }
    if (options.type === 'audio') {
      mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm';
    }

    this.mediaRecorder = new MediaRecorder(combinedStream, {
      mimeType,
      videoBitsPerSecond: options.videoResolution === '4K' ? 25000000 : 8000000,
    });

    this.mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        this.recordedChunks.push(e.data);
      }
    };

    this.mediaRecorder.start(1000); // Record chunks every 1 second
    return combinedStream;
  }

  public getLiveAudioDb(): number {
    if (!this.analyser) return -60;
    const data = new Float32Array(this.analyser.fftSize);
    this.analyser.getFloatTimeDomainData(data);
    let sum = 0;
    for (let i = 0; i < data.length; i++) {
      sum += data[i] * data[i];
    }
    const rms = Math.sqrt(sum / data.length);
    if (rms < 0.00001) return -60;
    const db = 20 * Math.log10(rms);
    return Math.max(-60, Math.min(0, db));
  }

  public async stopRecording(options: RecorderOptions): Promise<{ blob: Blob; mediaItem: MediaItem; url: string }> {
    return new Promise((resolve) => {
      if (!this.mediaRecorder) {
        throw new Error('No active recording');
      }

      this.mediaRecorder.onstop = () => {
        const mime = options.type === 'audio' ? 'audio/webm' : 'video/webm';
        const blob = new Blob(this.recordedChunks, { type: mime });
        const url = URL.createObjectURL(blob);

        const now = new Date();
        const dateStr = now.toISOString().replace(/[:.]/g, '-').slice(0, 19);
        const name = `Recording_${options.type.toUpperCase()}_${dateStr}.webm`;

        const mediaItem: MediaItem = {
          id: `rec-${Date.now()}`,
          name,
          url,
          blob,
          duration: 10, // will update on loadedmetadata
          fileSize: blob.size,
          container: 'WebM (.webm)',
          videoStream: {
            id: 1,
            codec: 'VP9',
            width: options.videoResolution === '4K' ? 3840 : options.videoResolution === '1080p' ? 1920 : 1280,
            height: options.videoResolution === '4K' ? 2160 : options.videoResolution === '1080p' ? 1080 : 720,
            fps: options.frameRate,
            bitDepth: 8,
            colorSpace: 'Rec.709',
            hdr: false,
            bitrateKbps: 8000,
            pixelFormat: 'YUV420p',
            hardwareDecoded: true,
          },
          audioStream: {
            id: 2,
            codec: 'Opus',
            sampleRateHz: 48000,
            channels: 2,
            channelLayout: 'Stereo',
            bitDepth: 16,
            bitrateKbps: 192,
          },
          metadata: {
            title: `Live ${options.type.toUpperCase()} Capture`,
            description: `Recorded natively via MACVIDEO.PRO ScreenCaptureKit on macOS`,
            creator: 'MACVIDEO.PRO Recording Engine',
            copyright: 'Local User Asset',
            creationDate: now.toLocaleString(),
            modificationDate: now.toLocaleString(),
            keywords: ['ScreenCapture', options.type, 'WebM', 'Live Capture'],
            genre: 'Recording',
          },
          thumbnailUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80',
          markers: [{ id: 'rm1', timestamp: 0, label: 'Recording Start', color: '#ef4444', category: 'scene' }],
          healthStatus: 'healthy',
          isRecording: true,
        };

        // Stop all tracks
        if (this.activeStream) {
          this.activeStream.getTracks().forEach((t) => t.stop());
          this.activeStream = null;
        }

        if (this.audioContext) {
          this.audioContext.close();
          this.audioContext = null;
        }

        resolve({ blob, mediaItem, url });
      };

      this.mediaRecorder.stop();
    });
  }
}

export const recorderEngine = new RecorderEngine();
