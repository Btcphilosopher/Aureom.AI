/**
 * Core Audio Engine for Real-Time Level Metering, EQ, Tone Generation and Channel Analysis.
 */

export class CoreAudioEngine {
  private audioCtx: AudioContext | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private analyserL: AnalyserNode | null = null;
  private analyserR: AnalyserNode | null = null;
  private splitter: ChannelSplitterNode | null = null;
  private gainNode: GainNode | null = null;
  private pannerNode: StereoPannerNode | null = null;
  private isInitialized = false;

  public init(videoElement: HTMLVideoElement): boolean {
    if (this.isInitialized || typeof window === 'undefined') return true;

    try {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtxClass) return false;

      this.audioCtx = new AudioCtxClass();
      this.sourceNode = this.audioCtx.createMediaElementSource(videoElement);
      this.splitter = this.audioCtx.createChannelSplitter(2);
      this.analyserL = this.audioCtx.createAnalyser();
      this.analyserR = this.audioCtx.createAnalyser();
      this.gainNode = this.audioCtx.createGain();

      this.analyserL.fftSize = 512;
      this.analyserR.fftSize = 512;

      // Check stereo panner support
      if (this.audioCtx.createStereoPanner) {
        this.pannerNode = this.audioCtx.createStereoPanner();
      }

      // Graph wiring: source -> gain -> (panner) -> destination & splitters
      this.sourceNode.connect(this.gainNode);
      
      if (this.pannerNode) {
        this.gainNode.connect(this.pannerNode);
        this.pannerNode.connect(this.audioCtx.destination);
        this.pannerNode.connect(this.splitter);
      } else {
        this.gainNode.connect(this.audioCtx.destination);
        this.gainNode.connect(this.splitter);
      }

      this.splitter.connect(this.analyserL, 0);
      this.splitter.connect(this.analyserR, 1);

      this.isInitialized = true;
      return true;
    } catch {
      return false;
    }
  }

  public resume(): void {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  public setVolume(volume: number): void {
    if (this.gainNode) {
      this.gainNode.gain.setValueAtTime(Math.max(0, volume), this.audioCtx?.currentTime || 0);
    }
  }

  public setPan(pan: number): void {
    if (this.pannerNode) {
      this.pannerNode.pan.setValueAtTime(Math.max(-1, Math.min(1, pan)), this.audioCtx?.currentTime || 0);
    }
  }

  public getLevels(): {
    leftDb: number;
    rightDb: number;
    leftPeak: number;
    rightPeak: number;
    isClipping: boolean;
  } {
    if (!this.analyserL || !this.analyserR) {
      return { leftDb: -60, rightDb: -60, leftPeak: 0, rightPeak: 0, isClipping: false };
    }

    const dataL = new Float32Array(this.analyserL.fftSize);
    const dataR = new Float32Array(this.analyserR.fftSize);

    this.analyserL.getFloatTimeDomainData(dataL);
    this.analyserR.getFloatTimeDomainData(dataR);

    let sumL = 0;
    let sumR = 0;
    let peakL = 0;
    let peakR = 0;

    for (let i = 0; i < dataL.length; i++) {
      const valL = Math.abs(dataL[i]);
      const valR = Math.abs(dataR[i]);
      sumL += valL * valL;
      sumR += valR * valR;
      if (valL > peakL) peakL = valL;
      if (valR > peakR) peakR = valR;
    }

    const rmsL = Math.sqrt(sumL / dataL.length);
    const rmsR = Math.sqrt(sumR / dataR.length);

    // Convert to dBFS (0 dB is full scale)
    const leftDb = rmsL > 0.00001 ? 20 * Math.log10(rmsL) : -60;
    const rightDb = rmsR > 0.00001 ? 20 * Math.log10(rmsR) : -60;

    const isClipping = peakL >= 0.99 || peakR >= 0.99;

    return {
      leftDb: Math.max(-60, Math.min(6, leftDb)),
      rightDb: Math.max(-60, Math.min(6, rightDb)),
      leftPeak: peakL,
      rightPeak: peakR,
      isClipping,
    };
  }

  /**
   * Plays a 1kHz -20dBFS SMPTE calibration reference tone.
   */
  public playCalibrationTone(durationSec = 2): void {
    if (!this.audioCtx) return;
    this.resume();

    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1000, this.audioCtx.currentTime); // 1 kHz
    gain.gain.setValueAtTime(0.1, this.audioCtx.currentTime); // -20 dBFS

    osc.connect(gain);
    gain.connect(this.audioCtx.destination);

    osc.start();
    osc.stop(this.audioCtx.currentTime + durationSec);
  }
}

export const coreAudioEngine = new CoreAudioEngine();
