import { MediaItem, VideoProject, TranscodeJob } from '@/types/media';
import { INITIAL_SAMPLE_MEDIA, INITIAL_PROJECT } from './sample-media';

const STORAGE_MEDIA_KEY = 'macvideo_pro_sqlite_media_v1';
const STORAGE_PROJECT_KEY = 'macvideo_pro_sqlite_project_v1';
const STORAGE_JOBS_KEY = 'macvideo_pro_sqlite_jobs_v1';
const STORAGE_CRASH_KEY = 'macvideo_pro_crash_recovery_v1';

export interface MediaHealthReport {
  totalFiles: number;
  healthyCount: number;
  warningCount: number;
  missingCount: number;
  totalStorageBytes: number;
  totalDurationSec: number;
  codecBreakdown: Record<string, number>;
  resolutionBreakdown: Record<string, number>;
  duplicates: { original: MediaItem; duplicate: MediaItem; matchScore: number; reason: string }[];
}

export class MediaDatabase {
  private mediaList: MediaItem[] = [];
  private activeProject: VideoProject = INITIAL_PROJECT;
  private jobs: TranscodeJob[] = [];

  constructor() {
    this.loadInitial();
  }

  private loadInitial() {
    if (typeof window === 'undefined') {
      this.mediaList = INITIAL_SAMPLE_MEDIA;
      this.activeProject = INITIAL_PROJECT;
      return;
    }

    try {
      const savedMedia = localStorage.getItem(STORAGE_MEDIA_KEY);
      if (savedMedia) {
        this.mediaList = JSON.parse(savedMedia);
      } else {
        this.mediaList = INITIAL_SAMPLE_MEDIA;
        this.saveMedia();
      }

      const savedProj = localStorage.getItem(STORAGE_PROJECT_KEY);
      if (savedProj) {
        this.activeProject = JSON.parse(savedProj);
      } else {
        this.activeProject = INITIAL_PROJECT;
        this.saveProject();
      }

      const savedJobs = localStorage.getItem(STORAGE_JOBS_KEY);
      if (savedJobs) {
        this.jobs = JSON.parse(savedJobs);
      }
    } catch {
      this.mediaList = INITIAL_SAMPLE_MEDIA;
      this.activeProject = INITIAL_PROJECT;
    }
  }

  public getMediaList(): MediaItem[] {
    return this.mediaList;
  }

  public getMediaById(id: string): MediaItem | undefined {
    return this.mediaList.find((m) => m.id === id);
  }

  public addMedia(item: MediaItem): void {
    const existingIndex = this.mediaList.findIndex((m) => m.id === item.id);
    if (existingIndex >= 0) {
      this.mediaList[existingIndex] = item;
    } else {
      this.mediaList.unshift(item);
    }
    this.saveMedia();
  }

  public updateMedia(id: string, partial: Partial<MediaItem>): void {
    const item = this.getMediaById(id);
    if (item) {
      Object.assign(item, partial);
      this.saveMedia();
    }
  }

  public deleteMedia(id: string): void {
    this.mediaList = this.mediaList.filter((m) => m.id !== id);
    this.saveMedia();
  }

  public getActiveProject(): VideoProject {
    return this.activeProject;
  }

  public updateProject(partial: Partial<VideoProject>): void {
    this.activeProject = { ...this.activeProject, ...partial, updatedAt: new Date().toISOString() };
    this.saveProject();
    this.saveCrashRecovery();
  }

  public getJobs(): TranscodeJob[] {
    return this.jobs;
  }

  public addJob(job: TranscodeJob): void {
    this.jobs.unshift(job);
    this.saveJobs();
  }

  public updateJob(id: string, partial: Partial<TranscodeJob>): void {
    const job = this.jobs.find((j) => j.id === id);
    if (job) {
      Object.assign(job, partial);
      this.saveJobs();
    }
  }

  public deleteJob(id: string): void {
    this.jobs = this.jobs.filter((j) => j.id !== id);
    this.saveJobs();
  }

  private saveMedia() {
    if (typeof window === 'undefined') return;
    try {
      // Exclude raw blobs before JSON stringify
      const sanitized = this.mediaList.map(({ blob: _, ...rest }) => rest);
      localStorage.setItem(STORAGE_MEDIA_KEY, JSON.stringify(sanitized));
    } catch {
      // Ignore quota exceeded
    }
  }

  private saveProject() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_PROJECT_KEY, JSON.stringify(this.activeProject));
    } catch {
      // Ignore
    }
  }

  private saveJobs() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_JOBS_KEY, JSON.stringify(this.jobs));
    } catch {
      // Ignore
    }
  }

  public saveCrashRecovery() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_CRASH_KEY, JSON.stringify({
        project: this.activeProject,
        timestamp: new Date().toISOString(),
      }));
    } catch {
      // Ignore
    }
  }

  public getCrashRecovery(): { project: VideoProject; timestamp: string } | null {
    if (typeof window === 'undefined') return null;
    try {
      const data = localStorage.getItem(STORAGE_CRASH_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  public clearCrashRecovery() {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(STORAGE_CRASH_KEY);
  }

  /**
   * Comprehensive SQLite Health & Analytics Audit.
   */
  public generateHealthReport(): MediaHealthReport {
    const totalFiles = this.mediaList.length;
    let healthyCount = 0;
    let warningCount = 0;
    let missingCount = 0;
    let totalStorageBytes = 0;
    let totalDurationSec = 0;

    const codecBreakdown: Record<string, number> = {};
    const resolutionBreakdown: Record<string, number> = {};

    this.mediaList.forEach((m) => {
      totalStorageBytes += m.fileSize || 0;
      totalDurationSec += m.duration || 0;

      const codecName = m.videoStream?.codec || 'Unknown';
      codecBreakdown[codecName] = (codecBreakdown[codecName] || 0) + 1;

      const res = `${m.videoStream?.width || 0}x${m.videoStream?.height || 0}`;
      const resLabel = m.videoStream?.width >= 3840 ? '4K UHD' : m.videoStream?.width >= 1920 ? '1080p FHD' : '720p HD';
      resolutionBreakdown[resLabel] = (resolutionBreakdown[resLabel] || 0) + 1;

      if (m.healthStatus === 'healthy') healthyCount++;
      else if (m.healthStatus === 'warning') warningCount++;
      else missingCount++;
    });

    // Duplicate detection based on duration match + filesize or name match
    const duplicates: { original: MediaItem; duplicate: MediaItem; matchScore: number; reason: string }[] = [];
    for (let i = 0; i < this.mediaList.length; i++) {
      for (let j = i + 1; j < this.mediaList.length; j++) {
        const a = this.mediaList[i];
        const b = this.mediaList[j];

        const durationMatch = Math.abs(a.duration - b.duration) < 0.5;
        const sizeMatch = Math.abs(a.fileSize - b.fileSize) < 1000;
        const nameMatch = a.name.toLowerCase() === b.name.toLowerCase();

        if (durationMatch && sizeMatch) {
          duplicates.push({ original: a, duplicate: b, matchScore: 98, reason: 'Identical duration and byte size' });
        } else if (durationMatch || nameMatch) {
          duplicates.push({ original: a, duplicate: b, matchScore: 85, reason: 'Matching media timestamp & header pattern' });
        }
      }
    }

    return {
      totalFiles,
      healthyCount,
      warningCount,
      missingCount,
      totalStorageBytes,
      totalDurationSec,
      codecBreakdown,
      resolutionBreakdown,
      duplicates,
    };
  }
}

export const mediaDatabase = new MediaDatabase();
