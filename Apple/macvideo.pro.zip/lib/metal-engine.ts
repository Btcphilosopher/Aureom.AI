import { VideoColorGrading, ScopeHistogramData } from '@/types/media';

/**
 * Metal / GPU Emulation Engine for real-time video scopes, shaders, and frame analysis.
 */

export interface WaveformColumn {
  // array of 101 IRE levels (0 to 100) with density
  density: Float32Array;
}

export interface VectorscopePoint {
  u: number; // -128 to 127
  v: number; // -128 to 127
  intensity: number;
}

export class MetalVideoPipeline {
  private offscreenCanvas: HTMLCanvasElement | null = null;
  private offscreenCtx: CanvasRenderingContext2D | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.offscreenCanvas = document.createElement('canvas');
      this.offscreenCtx = this.offscreenCanvas.getContext('2d', { willReadFrequently: true });
    }
  }

  /**
   * Samples a video element or canvas, extracts raw pixel data for real-time scopes.
   */
  public analyzeFrame(
    videoElement: HTMLVideoElement | HTMLCanvasElement,
    sampleWidth: number = 240,
    sampleHeight: number = 135
  ): {
    histogram: ScopeHistogramData;
    waveform: Float32Array[]; // 100 IRE bins for each horizontal column
    vectorscopeData: { u: number; v: number }[];
    avgLuma: number;
    maxLuma: number;
    minLuma: number;
  } | null {
    if (!this.offscreenCanvas || !this.offscreenCtx) return null;

    this.offscreenCanvas.width = sampleWidth;
    this.offscreenCanvas.height = sampleHeight;

    try {
      this.offscreenCtx.drawImage(videoElement, 0, 0, sampleWidth, sampleHeight);
      const imgData = this.offscreenCtx.getImageData(0, 0, sampleWidth, sampleHeight);
      const data = imgData.data;

      const lumaHist = new Array(256).fill(0);
      const rHist = new Array(256).fill(0);
      const gHist = new Array(256).fill(0);
      const bHist = new Array(256).fill(0);

      // Waveform matrix: sampleWidth columns x 100 IRE bins
      const waveformColumns: Float32Array[] = [];
      for (let x = 0; x < sampleWidth; x++) {
        waveformColumns.push(new Float32Array(101));
      }

      const vectorscopeSamples: { u: number; v: number }[] = [];
      let totalLuma = 0;
      let minLuma = 255;
      let maxLuma = 0;
      const totalPixels = sampleWidth * sampleHeight;

      for (let y = 0; y < sampleHeight; y++) {
        for (let x = 0; x < sampleWidth; x++) {
          const idx = (y * sampleWidth + x) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];

          // ITU-R BT.709 Luma
          const yLuma = Math.round(0.2126 * r + 0.7152 * g + 0.0722 * b);
          
          lumaHist[yLuma]++;
          rHist[r]++;
          gHist[g]++;
          bHist[b]++;

          totalLuma += yLuma;
          if (yLuma < minLuma) minLuma = yLuma;
          if (yLuma > maxLuma) maxLuma = yLuma;

          // Waveform IRE (0 to 100)
          const ire = Math.min(100, Math.max(0, Math.round((yLuma / 255) * 100)));
          waveformColumns[x][ire] += 1;

          // Vectorscope chroma U & V (BT.709)
          if ((x + y) % 4 === 0) { // Subsample for performance
            const u = -0.1146 * r - 0.3854 * g + 0.5 * b;
            const v = 0.5 * r - 0.4542 * g - 0.0458 * b;
            vectorscopeSamples.push({ u, v });
          }
        }
      }

      return {
        histogram: {
          luma: lumaHist,
          red: rHist,
          green: gHist,
          blue: bHist,
        },
        waveform: waveformColumns,
        vectorscopeData: vectorscopeSamples,
        avgLuma: totalLuma / totalPixels,
        minLuma,
        maxLuma,
      };
    } catch {
      return null;
    }
  }

  /**
   * Applies video color grading transforms via CSS filter or Canvas shader
   */
  public generateCssFilter(g: VideoColorGrading): string {
    const brightnessPct = 100 + g.brightness + (g.exposure * 25);
    const contrastPct = 100 + g.contrast;
    const saturatePct = 100 + g.saturation;
    const blurPx = g.blur;
    
    // Convert temperature (6500K is neutral) to sepia/hue rotation approximation
    const tempDiff = (g.temperature - 6500) / 3000;
    const sepiaPct = tempDiff > 0 ? Math.min(50, tempDiff * 30) : 0;
    const hueRotateDeg = g.tint * 0.8 + (tempDiff < 0 ? tempDiff * 25 : 0);

    return `brightness(${Math.max(0, brightnessPct)}%) contrast(${Math.max(0, contrastPct)}%) saturate(${Math.max(0, saturatePct)}%) sepia(${sepiaPct}%) hue-rotate(${hueRotateDeg}deg) blur(${blurPx}px)`;
  }

  /**
   * Captures a high-resolution frame from the video element and downloads it.
   */
  public captureFrame(
    video: HTMLVideoElement,
    format: 'png' | 'jpeg' | 'webp' = 'png',
    colorGrading?: VideoColorGrading,
    nativeResolution: boolean = true
  ): string | null {
    if (!video) return null;
    const canvas = document.createElement('canvas');
    canvas.width = nativeResolution ? (video.videoWidth || 1920) : video.clientWidth;
    canvas.height = nativeResolution ? (video.videoHeight || 1080) : video.clientHeight;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    if (colorGrading) {
      ctx.filter = this.generateCssFilter(colorGrading);
    }

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Apply vignette if configured
    if (colorGrading && colorGrading.vignette > 0) {
      const gradient = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, canvas.width * 0.2,
        canvas.width / 2, canvas.height / 2, canvas.width * 0.7
      );
      gradient.addColorStop(0, 'rgba(0,0,0,0)');
      gradient.addColorStop(1, `rgba(0,0,0,${colorGrading.vignette / 120})`);
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    const mime = format === 'png' ? 'image/png' : format === 'jpeg' ? 'image/jpeg' : 'image/webp';
    return canvas.toDataURL(mime, 0.95);
  }

  /**
   * Generates a contact sheet grid from sampled timestamps across the video.
   */
  public async generateContactSheet(
    video: HTMLVideoElement,
    columns: number = 4,
    rows: number = 3,
    title: string = 'MACVIDEO.PRO Contact Sheet'
  ): Promise<string | null> {
    const totalFrames = columns * rows;
    const duration = video.duration || 60;
    const interval = duration / (totalFrames + 1);

    const cellW = 320;
    const cellH = 180;
    const headerH = 80;
    const padding = 12;

    const sheetW = columns * cellW + (columns + 1) * padding;
    const sheetH = rows * cellH + (rows + 1) * padding + headerH;

    const canvas = document.createElement('canvas');
    canvas.width = sheetW;
    canvas.height = sheetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, sheetW, sheetH);

    // Header metadata banner
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(padding, padding, sheetW - padding * 2, headerH - padding);

    ctx.fillStyle = '#38bdf8';
    ctx.font = 'bold 18px -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif';
    ctx.fillText('MACVIDEO.PRO CONTACT SHEET', padding + 16, padding + 28);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '12px -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif';
    ctx.fillText(
      `File: ${title} | Resolution: ${video.videoWidth || 1920}x${video.videoHeight || 1080} | Duration: ${Math.round(duration)}s | Sampling: ${totalFrames} frames`,
      padding + 16,
      padding + 52
    );

    const originalTime = video.currentTime;

    // Draw cells
    for (let i = 0; i < totalFrames; i++) {
      const sampleTime = (i + 1) * interval;
      const col = i % columns;
      const row = Math.floor(i / columns);
      const x = padding + col * (cellW + padding);
      const y = headerH + padding + row * (cellH + padding);

      // Seek and wait briefly
      video.currentTime = sampleTime;
      await new Promise((res) => setTimeout(res, 80));

      // Draw thumbnail box
      ctx.fillStyle = '#000000';
      ctx.fillRect(x, y, cellW, cellH);

      try {
        ctx.drawImage(video, x, y, cellW, cellH);
      } catch {
        ctx.fillStyle = '#334155';
        ctx.fillRect(x, y, cellW, cellH);
      }

      // Border
      ctx.strokeStyle = '#334155';
      ctx.lineWidth = 1;
      ctx.strokeRect(x, y, cellW, cellH);

      // Timestamp tag badge
      const mins = Math.floor(sampleTime / 60);
      const secs = Math.floor(sampleTime % 60);
      const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

      ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
      ctx.fillRect(x + 6, y + cellH - 24, 60, 18);
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 11px monospace';
      ctx.fillText(timeStr, x + 12, y + cellH - 10);
    }

    video.currentTime = originalTime;
    return canvas.toDataURL('image/jpeg', 0.92);
  }
}

export const metalPipeline = new MetalVideoPipeline();
