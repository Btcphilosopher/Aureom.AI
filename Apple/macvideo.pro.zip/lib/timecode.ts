/**
 * Frame-accurate SMPTE Timecode and media formatting utilities.
 */

export function formatSMPTETimecode(seconds: number, fps: number = 24): string {
  if (isNaN(seconds) || seconds < 0) seconds = 0;
  
  const totalFrames = Math.floor(seconds * fps);
  const frames = totalFrames % Math.round(fps);
  const totalSeconds = Math.floor(seconds);
  const s = totalSeconds % 60;
  const m = Math.floor((totalSeconds / 60) % 60);
  const h = Math.floor(totalSeconds / 3600);

  const pad = (n: number, z = 2) => String(n).padStart(z, '0');
  return `${pad(h)}:${pad(m)}:${pad(s)}:${pad(frames)}`;
}

export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) seconds = 0;
  const s = Math.floor(seconds % 60);
  const m = Math.floor((seconds / 60) % 60);
  const h = Math.floor(seconds / 3600);
  const pad = (n: number) => String(n).padStart(2, '0');
  
  if (h > 0) {
    return `${pad(h)}:${pad(m)}:${pad(s)}`;
  }
  return `${pad(m)}:${pad(s)}`;
}

export function formatPTS(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) seconds = 0;
  return seconds.toFixed(3) + 's';
}

export function secondsToFrameNumber(seconds: number, fps: number = 24): number {
  return Math.floor(seconds * fps);
}

export function frameNumberToSeconds(frame: number, fps: number = 24): number {
  return frame / fps;
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function formatBitrate(kbps: number): string {
  if (kbps >= 1000) {
    return (kbps / 1000).toFixed(1) + ' Mbps';
  }
  return `${Math.round(kbps)} kbps`;
}

export function calculateEstimatedSize(durationSec: number, videoBitrateMbps: number, audioBitrateKbps: number = 320): number {
  const totalBitrateBps = (videoBitrateMbps * 1000000) + (audioBitrateKbps * 1000);
  // Container overhead ~ 2%
  const totalBytes = (totalBitrateBps / 8) * durationSec * 1.02;
  return totalBytes / (1024 * 1024); // Return in MB
}
