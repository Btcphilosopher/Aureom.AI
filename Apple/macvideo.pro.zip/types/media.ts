export type ColorSpace = 'Rec.709' | 'Rec.2020' | 'Display P3' | 'sRGB';
export type VideoCodec = 'HEVC / H.265' | 'H.264 / AVC' | 'Apple ProRes 422 HQ' | 'Apple ProRes 4444' | 'AV1' | 'VP9' | 'Motion JPEG';
export type AudioCodec = 'AAC' | 'LPCM 24-bit' | 'ALAC (Apple Lossless)' | 'FLAC' | 'MP3' | 'Opus';
export type ContainerFormat = 'QuickTime MOV (.mov)' | 'MPEG-4 (.mp4)' | 'M4V (.m4v)' | 'Matroska (.mkv)' | 'WebM (.webm)' | 'WAV (.wav)';

export interface VideoStreamInfo {
  id: number;
  codec: VideoCodec;
  width: number;
  height: number;
  fps: number;
  bitDepth: 8 | 10 | 12;
  colorSpace: ColorSpace;
  hdr: boolean;
  hdrFormat?: 'HDR10' | 'Dolby Vision' | 'HLG';
  bitrateKbps: number;
  pixelFormat: string;
  hardwareDecoded: boolean;
}

export interface AudioStreamInfo {
  id: number;
  codec: AudioCodec;
  sampleRateHz: number;
  channels: number;
  channelLayout: 'Mono' | 'Stereo' | '5.1 Surround' | '7.1.4 Spatial';
  bitDepth: 16 | 24 | 32;
  bitrateKbps: number;
}

export interface MediaMetadata {
  title: string;
  description: string;
  creator: string;
  copyright: string;
  creationDate: string;
  modificationDate: string;
  location?: string;
  keywords: string[];
  genre: string;
  encoder?: string;
  isCustomMetadata?: boolean;
}

export interface ChapterMarker {
  id: string;
  timestamp: number; // in seconds
  label: string;
  color: string;
  category: 'chapter' | 'edit' | 'note' | 'bookmark' | 'scene';
  notes?: string;
}

export interface TranscriptSegment {
  id: string;
  startTime: number;
  endTime: number;
  speaker: string;
  text: string;
  confidence: number;
  isAiGenerated: boolean;
}

export interface SceneCut {
  id: string;
  timestamp: number;
  confidence: number;
  thumbnailUrl?: string;
  label: string;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  blob?: Blob;
  duration: number; // seconds
  fileSize: number; // bytes
  container: ContainerFormat;
  videoStream: VideoStreamInfo;
  audioStream: AudioStreamInfo;
  metadata: MediaMetadata;
  thumbnailUrl: string;
  waveformData?: number[];
  markers: ChapterMarker[];
  transcript?: TranscriptSegment[];
  scenes?: SceneCut[];
  isSampleMedia?: boolean;
  isRecording?: boolean;
  isFavorite?: boolean;
  healthStatus: 'healthy' | 'warning' | 'missing' | 'unsupported_codec';
  sourceFilePath?: string;
}

export interface VideoTransform {
  posX: number; // -100 to 100%
  posY: number;
  scale: number; // 0.1 to 3.0
  rotation: number; // -180 to 180 deg
  opacity: number; // 0 to 1.0
  cropTop: number; // 0 to 50%
  cropBottom: number;
  cropLeft: number;
  cropRight: number;
}

export interface VideoColorGrading {
  brightness: number; // -100 to +100
  contrast: number; // -100 to +100
  saturation: number; // -100 to +100
  exposure: number; // -3 to +3 EV
  gamma: number; // 0.2 to 2.5
  temperature: number; // 2500K to 9500K (0 is neutral 6500K)
  tint: number; // -100 (magenta) to +100 (green)
  highlights: number; // -100 to +100
  shadows: number; // -100 to +100
  sharpen: number; // 0 to 100
  blur: number; // 0 to 50 px
  vignette: number; // 0 to 100
  presetName?: string;
}

export interface MediaClip {
  id: string;
  trackId: string;
  sourceMediaId: string;
  sourceStart: number; // seconds into original file
  sourceDuration: number;
  timelineStart: number; // seconds on project timeline
  timelineDuration: number;
  playbackSpeed: number;
  isReversed: boolean;
  transform: VideoTransform;
  colorGrading: VideoColorGrading;
  audioVolume: number; // 0.0 to 2.0 (1.0 = 100%)
  audioPan: number; // -1.0 to 1.0
  audioMuted: boolean;
  fadeInDuration: number;
  fadeOutDuration: number;
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: 'video' | 'audio';
  index: number;
  isLocked: boolean;
  isHidden: boolean;
  isMuted: boolean;
  isSolo: boolean;
  height: number;
}

export interface VideoProject {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  fps: number;
  width: number;
  height: number;
  duration: number;
  tracks: TimelineTrack[];
  clips: MediaClip[];
  markers: ChapterMarker[];
  inPoint: number | null;
  outPoint: number | null;
  activeMediaId: string;
}

export interface TranscodeJob {
  id: string;
  sourceMediaId: string;
  sourceName: string;
  destinationName: string;
  targetFormat: ContainerFormat;
  targetCodec: VideoCodec;
  targetResolution: '4K (3840x2160)' | '1080p (1920x1080)' | '720p (1280x720)' | 'Original';
  targetFps: number;
  targetBitrateMbps: number;
  targetAudioCodec: AudioCodec;
  progress: number; // 0 to 100
  status: 'queued' | 'transcoding' | 'paused' | 'completed' | 'failed';
  estimatedSizeMB: number;
  estimatedTimeSec: number;
  createdAt: string;
  completedAt?: string;
  error?: string;
}

export interface PerformanceTelemetry {
  fps: number;
  targetFps: number;
  droppedFrames: number;
  decodeLatencyMs: number;
  renderLatencyMs: number;
  audioBufferMs: number;
  cpuLoadPercent: number;
  gpuLoadPercent: number;
  ramUsageMB: number;
  isHardwareAccelerated: boolean;
  metalPipelineStatus: 'Active (Direct GPU)' | 'CoreVideo Surface' | 'Fallback';
}

export interface ScopeHistogramData {
  luma: number[];
  red: number[];
  green: number[];
  blue: number[];
}

export interface TranscodePreset {
  id: string;
  name: string;
  targetFormat: ContainerFormat;
  targetCodec: VideoCodec;
  targetResolution: '4K (3840x2160)' | '1080p (1920x1080)' | '720p (1280x720)' | 'Original';
  targetFps: number;
  targetBitrateMbps: number;
  hardwareAccelerated: boolean;
}

export type AppWorkspace =
  | 'player'
  | 'editor'
  | 'recorder'
  | 'library'
  | 'transcoder'
  | 'analytics'
  | 'ai'
  | 'settings';

export type LanguageCode = 'en' | 'zh-TW' | 'zh-CN' | 'ja' | 'ko' | 'fr' | 'de' | 'es';
