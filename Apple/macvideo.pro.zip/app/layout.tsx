import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'MACVIDEO.PRO - Professional Native macOS Video Platform',
  description: 'Professional-grade native macOS video platform combining video playback, frame-accurate inspection, multi-track timeline editing, screen & audio recording, GPU video scopes, batch transcoding, and AI video intelligence.',
  openGraph: {
    title: 'MACVIDEO.PRO - Professional Native macOS Video Platform',
    description: 'Professional-grade native macOS video platform combining video playback, frame-accurate inspection, multi-track timeline editing, screen & audio recording, GPU video scopes, batch transcoding, and AI video intelligence.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MACVIDEO.PRO - Professional Native macOS Video Platform',
    description: 'Professional-grade native macOS video platform combining video playback, frame-accurate inspection, multi-track timeline editing, screen & audio recording, GPU video scopes, batch transcoding, and AI video intelligence.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
