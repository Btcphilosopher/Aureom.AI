'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  AppWorkspace,
  LanguageCode,
  MediaItem,
  VideoProject,
  VideoColorGrading,
  TranscodeJob,
} from '@/types/media';
import { INITIAL_SAMPLE_MEDIA, INITIAL_PROJECT } from '@/lib/sample-media';
import { mediaDatabase } from '@/lib/media-database';
import { metalPipeline } from '@/lib/metal-engine';
import { coreAudioEngine } from '@/lib/audio-engine';
import { MenuBar } from '@/components/macos/MenuBar';
import { WindowHeader } from '@/components/macos/WindowHeader';
import { VideoPlayerView } from '@/components/player/VideoPlayerView';
import { MediaInspector } from '@/components/inspector/MediaInspector';
import { MultiTrackTimeline } from '@/components/timeline/MultiTrackTimeline';
import { StudioRecorderView } from '@/components/recorder/StudioRecorderView';
import { MediaDatabaseView } from '@/components/library/MediaDatabaseView';
import { BatchTranscoderView } from '@/components/transcoder/BatchTranscoderView';
import { AiIntelligenceView } from '@/components/ai/AiIntelligenceView';
import { AnalyticsDashboardView } from '@/components/analytics/AnalyticsDashboardView';
import { SettingsModal } from '@/components/settings/SettingsModal';
import { ContactSheetModal } from '@/components/modals/ContactSheetModal';

export default function MacVideoProPage() {
  // App state
  const [workspace, setWorkspace] = useState<AppWorkspace>('player');
  const [lang, setLang] = useState<LanguageCode>('en');
  const [searchQuery, setSearchQuery] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Media & Project state initialized deterministically to prevent hydration mismatches
  const [mediaList, setMediaList] = useState<MediaItem[]>(INITIAL_SAMPLE_MEDIA);
  const [activeMedia, setActiveMedia] = useState<MediaItem | null>(INITIAL_SAMPLE_MEDIA[0] || null);
  const [project, setProject] = useState<VideoProject>(INITIAL_PROJECT);
  const [jobs, setJobs] = useState<TranscodeJob[]>([]);

  useEffect(() => {
    // Re-sync with client SQLite storage after hydration
    const handle = requestAnimationFrame(() => {
      const list = mediaDatabase.getMediaList();
      setMediaList(list);
      if (list.length > 0) {
        setActiveMedia(list[0]);
      }
      setProject(mediaDatabase.getActiveProject());
      setJobs(mediaDatabase.getJobs());
    });
    return () => cancelAnimationFrame(handle);
  }, []);

  // Player in/out points & playback state
  const [inPoint, setInPoint] = useState<number | null>(null);
  const [outPoint, setOutPoint] = useState<number | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Color grading state
  const [colorGrading, setColorGrading] = useState<VideoColorGrading>({
    exposure: 0,
    brightness: 0,
    contrast: 0,
    saturation: 0,
    gamma: 1.0,
    temperature: 6500,
    tint: 0,
    vignette: 0,
    blur: 0,
    sharpen: 0,
    highlights: 0,
    shadows: 0,
  });

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isContactSheetOpen, setIsContactSheetOpen] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Video element ref
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Show temporary toast notification
  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  // Capture Frame Handler
  const handleCaptureFrame = (format: 'png' | 'jpeg' = 'png') => {
    if (!videoRef.current) return;
    const dataUrl = metalPipeline.captureFrame(videoRef.current, format, colorGrading);
    if (dataUrl) {
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `FrameCapture_${activeMedia?.name || 'video'}_${Math.round(currentTime)}s.${format}`;
      a.click();
      showToast('High-Resolution Frame Captured & Saved!');
    }
  };

  // Import local video files
  const handleImportFiles = (files: FileList) => {
    Array.from(files).forEach((file) => {
      const url = URL.createObjectURL(file);
      const isAudio = file.type.startsWith('audio');
      
      const ext = file.name.split('.').pop()?.toLowerCase();
      let containerFormat: MediaItem['container'] = 'MPEG-4 (.mp4)';
      if (ext === 'mov') containerFormat = 'QuickTime MOV (.mov)';
      else if (ext === 'webm') containerFormat = 'WebM (.webm)';
      else if (ext === 'mkv') containerFormat = 'Matroska (.mkv)';
      else if (ext === 'wav') containerFormat = 'WAV (.wav)';

      const newItem: MediaItem = {
        id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: file.name,
        url,
        fileSize: file.size,
        duration: 60, // will update on loadedmetadata
        container: containerFormat,
        videoStream: {
          id: 1,
          codec: 'Apple ProRes 422 HQ',
          width: 1920,
          height: 1080,
          fps: 24,
          bitDepth: 10,
          colorSpace: 'Rec.709',
          hdr: false,
          bitrateKbps: 24000,
          pixelFormat: 'YUV422p10le',
          hardwareDecoded: true,
        },
        audioStream: {
          id: 2,
          codec: isAudio ? 'FLAC' : 'AAC',
          sampleRateHz: 48000,
          channels: 2,
          channelLayout: 'Stereo',
          bitDepth: 24,
          bitrateKbps: 320,
        },
        metadata: {
          title: file.name.replace(/\.[^/.]+$/, ''),
          description: 'Locally imported media asset',
          creator: 'macOS Local User',
          copyright: 'Local Production Asset',
          creationDate: new Date().toLocaleDateString(),
          modificationDate: new Date().toLocaleDateString(),
          keywords: ['Imported', 'Local Asset', file.type],
          genre: 'Production',
        },
        thumbnailUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=600&auto=format&fit=crop&q=80',
        markers: [],
        healthStatus: 'healthy',
      };

      mediaDatabase.addMedia(newItem);
      setMediaList((prev) => [newItem, ...prev]);
      setActiveMedia(newItem);
    });

    showToast(`Ingested ${files.length} file(s) into SQLite database`);
  };

  // Delete media
  const handleDeleteMedia = (id: string) => {
    mediaDatabase.deleteMedia(id);
    const updated = mediaList.filter((m) => m.id !== id);
    setMediaList(updated);
    if (activeMedia?.id === id) {
      setActiveMedia(updated[0] || null);
    }
    showToast('Asset removed from database');
  };

  // Relink media
  const handleRelinkMedia = (id: string, file: File) => {
    const url = URL.createObjectURL(file);
    mediaDatabase.updateMedia(id, { url, healthStatus: 'healthy', fileSize: file.size });
    setMediaList((prev) =>
      prev.map((m) => (m.id === id ? { ...m, url, healthStatus: 'healthy', fileSize: file.size } : m))
    );
    showToast(`Relinked ${file.name} successfully!`);
  };

  // Update metadata in SQLite
  const handleUpdateMetadata = (id: string, metadata: MediaItem['metadata']) => {
    mediaDatabase.updateMedia(id, { metadata });
    setMediaList((prev) => prev.map((m) => (m.id === id ? { ...m, metadata } : m)));
    if (activeMedia?.id === id) {
      setActiveMedia((prev) => (prev ? { ...prev, metadata } : null));
    }
    showToast('Metadata saved to SQLite database');
  };

  // Handle Recording complete
  const handleRecordingComplete = (item: MediaItem) => {
    mediaDatabase.addMedia(item);
    setMediaList((prev) => [item, ...prev]);
    setActiveMedia(item);
    showToast('Recording added to Media Database');
  };

  // Global Keyboard Shortcuts (macOS)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't intercept if inside an input or textarea
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      // Space: Toggle Play/Pause
      if (e.code === 'Space') {
        e.preventDefault();
        if (videoRef.current) {
          if (videoRef.current.paused) {
            coreAudioEngine.init(videoRef.current);
            coreAudioEngine.resume();
            videoRef.current.play().catch(() => {});
          } else {
            videoRef.current.pause();
          }
        }
      }

      // Left Arrow: Step 1 frame back
      if (e.code === 'ArrowLeft') {
        e.preventDefault();
        if (videoRef.current) {
          videoRef.current.pause();
          videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 1 / 24);
        }
      }

      // Right Arrow: Step 1 frame forward
      if (e.code === 'ArrowRight') {
        e.preventDefault();
        if (videoRef.current) {
          videoRef.current.pause();
          videoRef.current.currentTime = Math.min(
            videoRef.current.duration || 100,
            videoRef.current.currentTime + 1 / 24
          );
        }
      }

      // I: In Point
      if (e.key.toLowerCase() === 'i' && !e.metaKey) {
        setInPoint(currentTime);
        showToast(`In Point set: ${currentTime.toFixed(2)}s`);
      }

      // O: Out Point
      if (e.key.toLowerCase() === 'o' && !e.metaKey) {
        setOutPoint(currentTime);
        showToast(`Out Point set: ${currentTime.toFixed(2)}s`);
      }

      // M: Add Marker
      if (e.key.toLowerCase() === 'm' && !e.metaKey) {
        const newMarker = {
          id: `mk-${Date.now()}`,
          timestamp: currentTime,
          label: `Marker (${currentTime.toFixed(1)}s)`,
          color: '#38bdf8',
          category: 'note' as const,
        };
        setProject((p) => ({ ...p, markers: [...p.markers, newMarker] }));
        showToast('Marker added at current frame');
      }

      // Cmd+O: Open file
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        fileInputRef.current?.click();
      }

      // Cmd+S: Save
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        mediaDatabase.updateProject(project);
        showToast('Project saved to SQLite repository');
      }

      // Workspace Quick Switch (1..7)
      if (e.key === '1') setWorkspace('player');
      if (e.key === '2') setWorkspace('editor');
      if (e.key === '3') setWorkspace('recorder');
      if (e.key === '4') setWorkspace('library');
      if (e.key === '5') setWorkspace('transcoder');
      if (e.key === '6') setWorkspace('ai');
      if (e.key === '7') setWorkspace('analytics');
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentTime, project]);

  return (
    <div className="h-screen w-screen flex flex-col bg-[#121212] text-[#E0E0E0] overflow-hidden font-sans select-none">
      {/* Hidden File Input for Native Open File */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="video/*,audio/*"
        onChange={(e) => {
          if (e.target.files) handleImportFiles(e.target.files);
        }}
        className="hidden"
      />

      {/* Top macOS Menu Bar */}
      <MenuBar
        currentWorkspace={workspace}
        setWorkspace={setWorkspace}
        lang={lang}
        onOpenLocalFile={() => fileInputRef.current?.click()}
        onSaveProject={() => {
          mediaDatabase.updateProject(project);
          showToast('Project saved');
        }}
        onExportProject={() => setWorkspace('transcoder')}
        onCaptureFrame={() => handleCaptureFrame('png')}
        onTogglePlay={() => {
          if (videoRef.current) {
            if (videoRef.current.paused) {
              videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
            } else {
              videoRef.current.pause();
              setIsPlaying(false);
            }
          }
        }}
        isPlaying={isPlaying}
        onStepFrame={(forward) => {
          if (videoRef.current) {
            videoRef.current.pause();
            setIsPlaying(false);
            videoRef.current.currentTime += forward ? 1 / 24 : -1 / 24;
          }
        }}
        onToggleMute={() => {
          if (videoRef.current) {
            videoRef.current.muted = !videoRef.current.muted;
            setIsMuted(videoRef.current.muted);
          }
        }}
        isMuted={isMuted}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* macOS Window Toolbar Header */}
      <WindowHeader
        currentWorkspace={workspace}
        setWorkspace={setWorkspace}
        activeMedia={activeMedia}
        lang={lang}
        setLang={setLang}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenLocalFile={() => fileInputRef.current?.click()}
        isFullscreen={isFullscreen}
        onToggleFullscreen={() => {
          if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(() => {});
            setIsFullscreen(true);
          } else {
            document.exitFullscreen().catch(() => {});
            setIsFullscreen(false);
          }
        }}
      />

      {/* Central Application Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* WORKSPACE 1: PLAYER & SCOPES */}
        {workspace === 'player' && (
          <div className="flex-1 flex overflow-hidden">
            <div className="flex-1 flex flex-col overflow-hidden">
              <VideoPlayerView
                media={activeMedia}
                colorGrading={colorGrading}
                setColorGrading={setColorGrading}
                inPoint={inPoint}
                outPoint={outPoint}
                setInPoint={setInPoint}
                setOutPoint={setOutPoint}
                onCaptureFrame={handleCaptureFrame}
                onOpenContactSheet={() => setIsContactSheetOpen(true)}
                onAddMarkerAtCurrentTime={(t) => {
                  const m = {
                    id: `m-${Date.now()}`,
                    timestamp: t,
                    label: `Marker (${t.toFixed(1)}s)`,
                    color: '#38bdf8',
                    category: 'note' as const,
                  };
                  setProject({ ...project, markers: [...project.markers, m] });
                }}
                videoRef={videoRef}
                onTimeUpdate={(t) => setCurrentTime(t)}
              />
            </div>
            {/* Right Media Inspector */}
            <MediaInspector
              media={activeMedia}
              onUpdateMetadata={handleUpdateMetadata}
              colorGrading={colorGrading}
              setColorGrading={setColorGrading}
            />
          </div>
        )}

        {/* WORKSPACE 2: MULTI-TRACK TIMELINE EDITOR */}
        {workspace === 'editor' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Mini Player on Top */}
            <div className="h-2/5 border-b border-slate-800 flex overflow-hidden bg-black">
              <div className="flex-1 flex items-center justify-center p-2">
                <video
                  ref={videoRef}
                  src={activeMedia?.url}
                  className="max-h-full max-w-full rounded object-contain shadow-xl"
                  style={{ filter: metalPipeline.generateCssFilter(colorGrading) }}
                  onTimeUpdate={() => {
                    if (videoRef.current) setCurrentTime(videoRef.current.currentTime);
                  }}
                  playsInline
                  crossOrigin="anonymous"
                />
              </div>
              <MediaInspector
                media={activeMedia}
                onUpdateMetadata={handleUpdateMetadata}
                colorGrading={colorGrading}
                setColorGrading={setColorGrading}
              />
            </div>

            {/* Main Multi-track Timeline on Bottom */}
            <div className="h-3/5 flex overflow-hidden">
              <MultiTrackTimeline
                project={project}
                setProject={setProject}
                currentTime={currentTime}
                onSeek={(t) => {
                  setCurrentTime(t);
                  if (videoRef.current) videoRef.current.currentTime = t;
                }}
                mediaLibrary={mediaList}
                fps={activeMedia?.videoStream?.fps || 24}
                onExportTimeline={() => setWorkspace('transcoder')}
              />
            </div>
          </div>
        )}

        {/* WORKSPACE 3: STUDIO RECORDER */}
        {workspace === 'recorder' && (
          <StudioRecorderView
            onRecordingComplete={handleRecordingComplete}
            onOpenInPlayer={(item) => {
              setActiveMedia(item);
              setWorkspace('player');
            }}
          />
        )}

        {/* WORKSPACE 4: MEDIA DATABASE */}
        {workspace === 'library' && (
          <MediaDatabaseView
            mediaList={mediaList}
            onSelectMedia={(item) => {
              setActiveMedia(item);
              setWorkspace('player');
            }}
            onImportFiles={handleImportFiles}
            onDeleteMedia={handleDeleteMedia}
            onRelinkMedia={handleRelinkMedia}
          />
        )}

        {/* WORKSPACE 5: BATCH TRANSCODER */}
        {workspace === 'transcoder' && (
          <BatchTranscoderView
            mediaLibrary={mediaList}
            jobs={jobs}
            setJobs={setJobs}
            activeMedia={activeMedia}
          />
        )}

        {/* WORKSPACE 6: AI INTELLIGENCE */}
        {workspace === 'ai' && (
          <AiIntelligenceView
            activeMedia={activeMedia}
            onSeek={(t) => {
              setCurrentTime(t);
              if (videoRef.current) videoRef.current.currentTime = t;
            }}
            project={project}
            setProject={setProject}
            onOpenInPlayer={() => setWorkspace('player')}
          />
        )}

        {/* WORKSPACE 7: ANALYTICS & PRODUCTION QUALITY */}
        {workspace === 'analytics' && (
          <AnalyticsDashboardView mediaLibrary={mediaList} />
        )}
      </div>

      {/* Floating Notification Toast */}
      {notification && (
        <div className="fixed bottom-8 right-4 bg-[#1E1E1E] border border-[#007AFF] text-[#E0E0E0] px-4 py-2 rounded-lg shadow-2xl backdrop-blur-md text-xs z-50 animate-fade-in font-medium flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-[#007AFF]"></span>
          <span>{notification}</span>
        </div>
      )}

      {/* macOS Native Status Footer Bar */}
      <footer className="h-6 bg-[#1E1E1E] border-t border-[#2A2A2A] px-4 flex items-center justify-between text-[10px] text-[#888888] shrink-0 select-none">
        <div className="flex items-center space-x-4">
          <span>Status: <span className="text-[#27C93F] font-semibold">Ready</span></span>
          <span>Metal API: <span className="text-[#AAAAAA] font-mono">Active (v3.0)</span></span>
          {activeMedia && (
            <span className="hidden sm:inline text-[#666666]">
              Target: <span className="text-[#AAAAAA]">{activeMedia.videoStream?.width}×{activeMedia.videoStream?.height} @ {activeMedia.videoStream?.fps}fps</span>
            </span>
          )}
        </div>
        <div className="flex items-center space-x-4 font-mono text-[9px] text-[#AAAAAA]">
          <span>CPU: <span className="text-[#E0E0E0]">18%</span></span>
          <span>GPU: <span className="text-[#007AFF]">31%</span></span>
          <span>RAM: <span className="text-[#E0E0E0]">1.8 GB</span></span>
        </div>
      </footer>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        lang={lang}
        setLang={setLang}
      />

      {/* Contact Sheet Storyboard Modal */}
      <ContactSheetModal
        isOpen={isContactSheetOpen}
        onClose={() => setIsContactSheetOpen(false)}
        videoRef={videoRef}
        media={activeMedia}
      />
    </div>
  );
}
