#!/usr/bin/env bash
set -e
echo "Building Apple Terminal OS Rust workspace..."
if command -v cargo >/dev/null 2>&1; then
    cargo check --workspace
    cargo test --workspace
else
    echo "Cargo not installed in PATH, running node dev environment..."
fi
npm run dev
