#!/usr/bin/env bash
echo "=== Apple Terminal OS Environment Check ==="
echo "Operating System: $(uname -s)"
echo "Architecture: $(uname -m)"
echo "Kernel: $(uname -r)"

if command -v rustc >/dev/null 2>&1; then
    echo "Rust compiler: $(rustc --version)"
else
    echo "Rust compiler: Not installed (using fallback server bridge)"
fi

if command -v cargo >/dev/null 2>&1; then
    echo "Cargo build tool: $(cargo --version)"
else
    echo "Cargo: Not installed"
fi

if command -v zsh >/dev/null 2>&1; then
    echo "Shell (zsh): Available at $(which zsh)"
fi

if command -v bash >/dev/null 2>&1; then
    echo "Shell (bash): Available at $(which bash)"
fi

if command -v python3 >/dev/null 2>&1; then
    echo "Python 3: Available at $(which python3)"
fi

echo "Environment check complete."
