import React, { useState, useEffect, useCallback } from 'react';
import { TabItem, PaneNode, ThemeName, SystemInfo, CommandPaletteAction } from './types';
import { THEMES } from './themes';
import { MacTitleBar } from './components/MacTitleBar';
import { TerminalPane } from './components/TerminalPane';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import { ProcessObservatoryModal } from './components/ProcessObservatoryModal';
import { DevInspectorModal } from './components/DevInspectorModal';
import { FileSystemExplorerPanel } from './components/FileSystemExplorerPanel';
import { WorkspaceManagerModal } from './components/WorkspaceManagerModal';
import { StatusBar } from './components/StatusBar';

export default function App() {
  const [themeName, setThemeName] = useState<ThemeName>('Obsidian');
  const [activeWorkspaceName, setActiveWorkspaceName] = useState<string>('Terminal OS Engine (Rust)');
  const [activeWorkspaceId, setActiveWorkspaceId] = useState<string>('ws_rust_terminal');

  const [systemInfo, setSystemInfo] = useState<SystemInfo | null>(null);

  // Tabs state
  const [tabs, setTabs] = useState<TabItem[]>([]);
  const [activeTabId, setActiveTabId] = useState<string>('');

  // Modals state
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isObservatoryOpen, setIsObservatoryOpen] = useState(false);
  const [isDevInspectorOpen, setIsDevInspectorOpen] = useState(false);
  const [isExplorerOpen, setIsExplorerOpen] = useState(false);
  const [isWorkspaceModalOpen, setIsWorkspaceModalOpen] = useState(false);

  const fetchSystemInfo = async () => {
    try {
      const res = await fetch('/api/system-info');
      const data = await res.json();
      setSystemInfo(data);
    } catch {
      // ignore
    }
  };

  // Helper to spawn a new backend session and create a pane
  const createNewSessionAndPane = async (shell?: string, cwd?: string) => {
    try {
      const res = await fetch('/api/terminal/spawn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ shell, cwd, cols: 80, rows: 24 }),
      });
      const data = await res.json();
      const paneId = `pane_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;
      return {
        paneId,
        sessionId: data.session_id as string,
        shell: (data.shell as string) || shell || '/bin/bash',
        cwd: (data.cwd as string) || cwd || '/',
      };
    } catch {
      const fallbackSessionId = `sess_fallback_${Date.now()}`;
      const paneId = `pane_${Date.now()}`;
      return {
        paneId,
        sessionId: fallbackSessionId,
        shell: shell || '/bin/bash',
        cwd: cwd || '/',
      };
    }
  };

  // Create initial default tab on mount
  useEffect(() => {
    fetchSystemInfo();

    const init = async () => {
      const session = await createNewSessionAndPane();
      const newTab: TabItem = {
        id: `tab_${Date.now()}`,
        title: session.shell.split('/').pop() || 'terminal',
        rootPane: {
          id: session.paneId,
          sessionId: session.sessionId,
        },
        activePaneId: session.paneId,
        cwd: session.cwd,
        shell: session.shell,
      };
      setTabs([newTab]);
      setActiveTabId(newTab.id);
    };

    init();
  }, []);

  const handleNewTab = async (customShell?: string, customCwd?: string) => {
    const session = await createNewSessionAndPane(customShell, customCwd);
    const newTab: TabItem = {
      id: `tab_${Date.now()}`,
      title: session.shell.split('/').pop() || 'terminal',
      rootPane: {
        id: session.paneId,
        sessionId: session.sessionId,
      },
      activePaneId: session.paneId,
      cwd: session.cwd,
      shell: session.shell,
    };
    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newTab.id);
  };

  const handleCloseTab = (tabId: string) => {
    setTabs((prev) => {
      const filtered = prev.filter((t) => t.id !== tabId);
      if (activeTabId === tabId && filtered.length > 0) {
        setActiveTabId(filtered[filtered.length - 1].id);
      }
      return filtered;
    });
  };

  const handleSplitPane = async (splitType: 'horizontal' | 'vertical') => {
    const activeTab = tabs.find((t) => t.id === activeTabId);
    if (!activeTab) return;

    const { paneId: newPaneId, sessionId: newSessionId } = await createNewSessionAndPane(
      activeTab.shell,
      activeTab.cwd
    );

    const newPaneNode: PaneNode = { id: newPaneId, sessionId: newSessionId };

    const splitNodeInTree = (node: PaneNode, targetId: string): PaneNode => {
      if (node.id === targetId) {
        return {
          id: `parent_${Date.now()}`,
          sessionId: '',
          splitType,
          children: [{ ...node }, newPaneNode],
          size: 50,
        };
      }
      if (node.children) {
        return {
          ...node,
          children: [
            splitNodeInTree(node.children[0], targetId),
            splitNodeInTree(node.children[1], targetId),
          ],
        };
      }
      return node;
    };

    setTabs((prev) =>
      prev.map((t) => {
        if (t.id === activeTabId) {
          const updatedRoot = splitNodeInTree(t.rootPane, t.activePaneId);
          return {
            ...t,
            rootPane: updatedRoot,
            activePaneId: newPaneId,
          };
        }
        return t;
      })
    );
  };

  // Keyboard shortcut listener for macOS gestures
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ⌘T = New Tab
      if (e.metaKey && !e.shiftKey && e.key === 't') {
        e.preventDefault();
        handleNewTab();
      }
      // ⌘W = Close Tab
      else if (e.metaKey && !e.shiftKey && e.key === 'w') {
        e.preventDefault();
        if (activeTabId) handleCloseTab(activeTabId);
      }
      // ⌘D = Split Right
      else if (e.metaKey && !e.shiftKey && e.key === 'd') {
        e.preventDefault();
        handleSplitPane('horizontal');
      }
      // ⌘⇧D = Split Down
      else if (e.metaKey && e.shiftKey && e.key === 'D') {
        e.preventDefault();
        handleSplitPane('vertical');
      }
      // ⌘⇧P = Command Palette
      else if (e.metaKey && e.shiftKey && e.key === 'P') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
      // ⌘I = Inspector
      else if (e.metaKey && !e.shiftKey && e.key === 'i') {
        e.preventDefault();
        setIsDevInspectorOpen((prev) => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTabId, tabs]);

  const activeTab = tabs.find((t) => t.id === activeTabId);
  const currentTheme = THEMES[themeName];

  // Render pane tree recursively
  const renderPaneTree = (node: PaneNode): React.ReactNode => {
    if (!node.children) {
      return (
        <TerminalPane
          key={node.id}
          paneId={node.id}
          sessionId={node.sessionId}
          theme={currentTheme}
          isActive={activeTab?.activePaneId === node.id}
          cwd={activeTab?.cwd || '/Users/apple'}
          shell={activeTab?.shell || '/bin/zsh'}
          onFocus={() => {
            setTabs((prev) =>
              prev.map((t) => (t.id === activeTabId ? { ...t, activePaneId: node.id } : t))
            );
          }}
        />
      );
    }

    const isHorizontal = node.splitType === 'horizontal';

    return (
      <div className={`flex w-full h-full gap-1.5 ${isHorizontal ? 'flex-row' : 'flex-col'}`}>
        <div className="flex-1 w-full h-full overflow-hidden">{renderPaneTree(node.children[0])}</div>
        <div className="flex-1 w-full h-full overflow-hidden">{renderPaneTree(node.children[1])}</div>
      </div>
    );
  };

  // Actions registered for Command Palette
  const commandActions: CommandPaletteAction[] = [
    {
      id: 'cmd_new_tab',
      title: 'New Terminal Tab',
      description: 'Open a new terminal tab with zsh',
      shortcut: '⌘T',
      category: 'Terminal',
      handler: () => handleNewTab(),
    },
    {
      id: 'cmd_close_tab',
      title: 'Close Active Tab',
      description: 'Close the currently selected tab session',
      shortcut: '⌘W',
      category: 'Terminal',
      handler: () => handleCloseTab(activeTabId),
    },
    {
      id: 'cmd_split_right',
      title: 'Split Pane Right',
      description: 'Split active pane horizontally',
      shortcut: '⌘D',
      category: 'Pane',
      handler: () => handleSplitPane('horizontal'),
    },
    {
      id: 'cmd_split_down',
      title: 'Split Pane Down',
      description: 'Split active pane vertically',
      shortcut: '⌘⇧D',
      category: 'Pane',
      handler: () => handleSplitPane('vertical'),
    },
    {
      id: 'cmd_observatory',
      title: 'Open Process Observatory',
      description: 'Inspect live PTY processes, PID, CPU and memory stats',
      category: 'Developer',
      handler: () => setIsObservatoryOpen(true),
    },
    {
      id: 'cmd_inspector',
      title: 'Open Terminal Inspector',
      description: 'Inspect PTY master, FPS, glyph cache, and system info',
      shortcut: '⌘I',
      category: 'Developer',
      handler: () => setIsDevInspectorOpen(true),
    },
    {
      id: 'cmd_cargo_check',
      title: 'Run cargo check',
      description: 'Check Rust workspace syntax and type health',
      category: 'Developer',
      handler: () => {
        // Triggered via pane toolbar button or terminal command
      },
    },
    {
      id: 'cmd_theme_obsidian',
      title: 'Switch Theme: Obsidian',
      description: 'Dark obsidian background with neon blue accents',
      category: 'Theme',
      handler: () => setThemeName('Obsidian'),
    },
    {
      id: 'cmd_theme_graphite',
      title: 'Switch Theme: Graphite',
      description: 'Clean graphite dark gray technical aesthetic',
      category: 'Theme',
      handler: () => setThemeName('Graphite'),
    },
    {
      id: 'cmd_theme_archive',
      title: 'Switch Theme: Archive',
      description: 'Warm dark retro amber terminal aesthetic',
      category: 'Theme',
      handler: () => setThemeName('Archive'),
    },
    {
      id: 'cmd_theme_light',
      title: 'Switch Theme: Light',
      description: 'High legibility slate light background',
      category: 'Theme',
      handler: () => setThemeName('Light'),
    },
  ];

  return (
    <div
      className="flex flex-col h-screen w-screen overflow-hidden select-none font-sans"
      style={{ backgroundColor: currentTheme.background, color: currentTheme.foreground }}
    >
      {/* Native macOS Title Bar */}
      <MacTitleBar
        tabs={tabs}
        activeTabId={activeTabId}
        themeName={themeName}
        onSelectTab={setActiveTabId}
        onNewTab={handleNewTab}
        onCloseTab={handleCloseTab}
        onSplitRight={() => handleSplitPane('horizontal')}
        onSplitDown={() => handleSplitPane('vertical')}
        onToggleCommandPalette={() => setIsCommandPaletteOpen(true)}
        onToggleObservatory={() => setIsObservatoryOpen(true)}
        onToggleDevInspector={() => setIsDevInspectorOpen(true)}
        onToggleExplorer={() => setIsExplorerOpen(!isExplorerOpen)}
        onSelectTheme={setThemeName}
        activeWorkspaceName={activeWorkspaceName}
        onOpenWorkspaceModal={() => setIsWorkspaceModalOpen(true)}
      />

      {/* Main Container with optional Explorer Sidebar */}
      <div className="flex-1 flex w-full overflow-hidden">
        {/* File System Explorer Drawer */}
        <FileSystemExplorerPanel
          isOpen={isExplorerOpen}
          onClose={() => setIsExplorerOpen(false)}
          currentPath={activeTab?.cwd || '/Users/apple'}
          onNavigatePath={(newPath) => {
            setTabs((prev) =>
              prev.map((t) => (t.id === activeTabId ? { ...t, cwd: newPath } : t))
            );
          }}
          onOpenTerminalAtFolder={(pathStr) => handleNewTab(undefined, pathStr)}
        />

        {/* Terminal Tab Workspaces */}
        <div className="flex-1 h-full w-full p-2 overflow-hidden bg-slate-950/40">
          {activeTab ? (
            renderPaneTree(activeTab.rootPane)
          ) : (
            <div className="flex flex-col items-center justify-center h-full gap-3 text-slate-500 font-mono">
              <p>No active terminal tab.</p>
              <button
                onClick={() => handleNewTab()}
                className="px-4 py-2 rounded-lg bg-sky-500 text-slate-950 font-bold hover:bg-sky-400 transition-all"
              >
                Create Terminal Tab (⌘T)
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Sleek macOS Status Bar */}
      <StatusBar
        shell={activeTab?.shell || '/bin/zsh'}
        cwd={activeTab?.cwd || '/Users/apple'}
        themeName={themeName}
        systemInfo={systemInfo}
      />

      {/* Modals */}
      <CommandPaletteModal
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        actions={commandActions}
      />

      <ProcessObservatoryModal
        isOpen={isObservatoryOpen}
        onClose={() => setIsObservatoryOpen(false)}
      />

      <DevInspectorModal
        isOpen={isDevInspectorOpen}
        onClose={() => setIsDevInspectorOpen(false)}
        systemInfo={systemInfo}
        onRefreshSystemInfo={fetchSystemInfo}
      />

      <WorkspaceManagerModal
        isOpen={isWorkspaceModalOpen}
        onClose={() => setIsWorkspaceModalOpen(false)}
        activeWorkspaceId={activeWorkspaceId}
        onSelectWorkspace={(ws) => {
          setActiveWorkspaceId(ws.id);
          setActiveWorkspaceName(ws.name);
          handleNewTab(ws.shell, ws.projectPath);
        }}
      />
    </div>
  );
}
