export type ThemeName = 'Obsidian' | 'Graphite' | 'Archive' | 'Light' | 'High Contrast';

export interface ThemePalette {
  name: ThemeName;
  background: string;
  foreground: string;
  cursor: string;
  selection: string;
  black: string;
  red: string;
  green: string;
  yellow: string;
  blue: string;
  magenta: string;
  cyan: string;
  white: string;
  brightBlack: string;
  brightRed: string;
  brightGreen: string;
  brightYellow: string;
  brightBlue: string;
  brightMagenta: string;
  brightCyan: string;
  brightWhite: string;
}

export interface TerminalSessionInfo {
  id: string;
  shell: string;
  cwd: string;
  title: string;
  pid?: number;
  cols: number;
  rows: number;
  historyCount: number;
  status: 'RUNNING' | 'EXITED' | 'STARTING';
}

export interface PaneNode {
  id: string;
  sessionId: string;
  splitType?: 'horizontal' | 'vertical';
  children?: [PaneNode, PaneNode];
  size?: number; // split ratio e.g. 50
}

export interface TabItem {
  id: string;
  title: string;
  rootPane: PaneNode;
  activePaneId: string;
  cwd: string;
  shell: string;
}

export interface SystemInfo {
  app_name: string;
  internal_name: string;
  version: string;
  platform: string;
  host_os: string;
  arch: string;
  cpus: number;
  model: string;
  total_mem_mb: number;
  free_mem_mb: number;
  default_shell: string;
  available_shells: string[];
  active_sessions: number;
  dev_tools: Record<string, { installed: boolean; path?: string; version?: string }>;
  rust_status: string;
}

export interface ProcessItem {
  id: number;
  user: string;
  pid: string;
  cpu: string;
  mem: string;
  stat: string;
  time: string;
  command: string;
}

export interface FileItem {
  name: string;
  path: string;
  is_dir: boolean;
  size: number;
}

export interface GitInfo {
  is_repo: boolean;
  branch?: string;
  dirty?: boolean;
  untracked_count?: number;
}

export interface CommandPaletteAction {
  id: string;
  title: string;
  description: string;
  shortcut?: string;
  category: 'Terminal' | 'Pane' | 'Search' | 'Developer' | 'Theme' | 'Workspace';
  handler: () => void;
}
