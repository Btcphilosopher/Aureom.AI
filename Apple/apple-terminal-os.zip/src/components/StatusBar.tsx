import React from 'react';
import { SystemInfo } from '../types';
import { Terminal, GitBranch, Cpu, HardDrive, CheckCircle2, ShieldCheck, Activity } from 'lucide-react';

interface StatusBarProps {
  shell: string;
  cwd: string;
  themeName: string;
  systemInfo: SystemInfo | null;
}

export const StatusBar: React.FC<StatusBarProps> = ({ shell, cwd, themeName, systemInfo }) => {
  return (
    <div className="h-6 px-3 bg-slate-950 border-t border-white/10 flex items-center justify-between text-[11px] font-mono text-slate-400 select-none shrink-0">
      {/* Left items */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 text-sky-400 font-semibold">
          <Terminal className="w-3 h-3" />
          <span>{shell.split('/').pop()}</span>
        </div>

        <span className="opacity-30">•</span>

        <span className="truncate max-w-[250px] text-slate-300" title={cwd}>
          {cwd.replace(/^\/Users\/[^\/]+/, '~')}
        </span>

        <span className="opacity-30">•</span>

        <div className="flex items-center gap-1 text-emerald-400 font-semibold">
          <GitBranch className="w-3 h-3" />
          <span>main</span>
          <span className="text-[9px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300">✓ clean</span>
        </div>
      </div>

      {/* Right items */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 text-amber-300">
          <Activity className="w-3 h-3 text-amber-400" />
          <span>PTY Active</span>
        </div>

        <span className="opacity-30">•</span>

        <div className="flex items-center gap-1.5 text-purple-300">
          <ShieldCheck className="w-3 h-3 text-purple-400" />
          <span>terminal_os (Rust 1.80+)</span>
        </div>

        <span className="opacity-30">•</span>

        <span className="text-slate-400 font-semibold">{themeName}</span>
      </div>
    </div>
  );
};
