import React, { useState } from 'react';
import { Layers, Plus, X, Folder, Terminal, Check, Trash2 } from 'lucide-react';

interface WorkspaceItem {
  id: string;
  name: string;
  projectPath: string;
  tabsCount: number;
  shell: string;
}

interface WorkspaceManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeWorkspaceId: string;
  onSelectWorkspace: (ws: WorkspaceItem) => void;
}

export const WorkspaceManagerModal: React.FC<WorkspaceManagerModalProps> = ({
  isOpen,
  onClose,
  activeWorkspaceId,
  onSelectWorkspace,
}) => {
  const [workspaces, setWorkspaces] = useState<WorkspaceItem[]>([
    {
      id: 'ws_silicaflux',
      name: 'SilicaFlux',
      projectPath: '/Users/apple/Projects/SilicaFlux',
      tabsCount: 3,
      shell: '/bin/zsh',
    },
    {
      id: 'ws_rust_terminal',
      name: 'Terminal OS Engine (Rust)',
      projectPath: '/Users/apple/terminal-os',
      tabsCount: 4,
      shell: '/bin/zsh',
    },
    {
      id: 'ws_python_research',
      name: 'Python Research Lab',
      projectPath: '/Users/apple/Research/Python',
      tabsCount: 2,
      shell: '/usr/bin/python3',
    },
    {
      id: 'ws_devops',
      name: 'DevOps & Cloud Cluster',
      projectPath: '/Users/apple/DevOps',
      tabsCount: 3,
      shell: '/bin/bash',
    },
  ]);

  const [newWsName, setNewWsName] = useState('');

  if (!isOpen) return null;

  const handleCreateWorkspace = () => {
    if (!newWsName.trim()) return;
    const newWs: WorkspaceItem = {
      id: `ws_${Date.now()}`,
      name: newWsName.trim(),
      projectPath: `/Users/apple/Projects/${newWsName.trim().replace(/\s+/g, '_')}`,
      tabsCount: 1,
      shell: '/bin/zsh',
    };
    setWorkspaces([...workspaces, newWs]);
    setNewWsName('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md" onClick={onClose}>
      <div
        className="w-full max-w-xl bg-slate-900/95 border border-sky-500/30 rounded-xl shadow-2xl overflow-hidden backdrop-blur-2xl flex flex-col max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-slate-950/80">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-sky-400" />
            <h2 className="text-sm font-semibold font-mono text-sky-200">WORKSPACE & SESSION MANAGER</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-rose-500/20 text-slate-400 hover:text-rose-300">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Create new workspace input */}
        <div className="p-3 border-b border-white/10 bg-slate-950/40 flex items-center gap-2">
          <input
            type="text"
            placeholder="New Workspace Name (e.g. 'Aardvark', 'Housebuilder')..."
            value={newWsName}
            onChange={(e) => setNewWsName(e.target.value)}
            className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-xs font-mono text-slate-100 placeholder:text-slate-500 outline-none focus:border-sky-500/50"
          />
          <button
            onClick={handleCreateWorkspace}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-mono text-xs font-bold transition-all shadow-md"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create</span>
          </button>
        </div>

        {/* Workspaces List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {workspaces.map((ws) => {
            const isActive = ws.id === activeWorkspaceId;
            return (
              <div
                key={ws.id}
                onClick={() => {
                  onSelectWorkspace(ws);
                  onClose();
                }}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer font-mono text-xs ${
                  isActive
                    ? 'bg-sky-500/15 border-sky-500/50 text-sky-200 shadow-md'
                    : 'bg-slate-950/40 border-white/5 text-slate-300 hover:bg-white/5'
                }`}
              >
                <div className="flex flex-col gap-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-slate-100">{ws.name}</span>
                    {isActive && (
                      <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-sky-500/20 text-sky-300 border border-sky-500/30">
                        <Check className="w-3 h-3" /> ACTIVE
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Folder className="w-3 h-3 text-sky-400" />
                      {ws.projectPath}
                    </span>
                    <span className="flex items-center gap-1">
                      <Terminal className="w-3 h-3 text-slate-500" />
                      {ws.tabsCount} Tabs
                    </span>
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setWorkspaces(workspaces.filter((w) => w.id !== ws.id));
                  }}
                  className="p-1.5 rounded hover:bg-rose-500/20 text-slate-500 hover:text-rose-300 transition-colors"
                  title="Remove Workspace"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-white/10 bg-slate-950/80 text-[11px] font-mono text-slate-400 flex justify-between">
          <span>Saved Workspaces: {workspaces.length}</span>
          <span className="text-sky-400 font-semibold">APPLE TERMINAL OS</span>
        </div>
      </div>
    </div>
  );
};
