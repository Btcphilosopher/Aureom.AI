import React from 'react';
import { TabItem, ThemeName } from '../types';
import {
  Plus,
  X,
  Columns,
  Rows,
  Command,
  Activity,
  Cpu,
  Layers,
  Palette,
  FolderTree,
  Terminal as TermIcon,
  Maximize2,
} from 'lucide-react';

interface MacTitleBarProps {
  tabs: TabItem[];
  activeTabId: string;
  themeName: ThemeName;
  onSelectTab: (id: string) => void;
  onNewTab: () => void;
  onCloseTab: (id: string) => void;
  onSplitRight: () => void;
  onSplitDown: () => void;
  onToggleCommandPalette: () => void;
  onToggleObservatory: () => void;
  onToggleDevInspector: () => void;
  onToggleExplorer: () => void;
  onSelectTheme: (theme: ThemeName) => void;
  activeWorkspaceName: string;
  onOpenWorkspaceModal: () => void;
}

export const MacTitleBar: React.FC<MacTitleBarProps> = ({
  tabs,
  activeTabId,
  themeName,
  onSelectTab,
  onNewTab,
  onCloseTab,
  onSplitRight,
  onSplitDown,
  onToggleCommandPalette,
  onToggleObservatory,
  onToggleDevInspector,
  onToggleExplorer,
  onSelectTheme,
  activeWorkspaceName,
  onOpenWorkspaceModal,
}) => {
  return (
    <div className="flex items-center justify-between h-11 px-3 bg-slate-950/80 border-b border-white/10 select-none backdrop-blur-xl shrink-0">
      {/* Left: Window Traffic Lights & Tab Bar */}
      <div className="flex items-center gap-3 overflow-x-auto no-scrollbar max-w-[65%]">
        {/* Traffic Lights */}
        <div className="flex items-center gap-2 pr-2 shrink-0">
          <button className="w-3 h-3 rounded-full bg-rose-500/90 hover:bg-rose-600 shadow-[0_0_8px_rgba(244,63,94,0.4)] transition-all flex items-center justify-center group">
            <X className="w-2 h-2 text-rose-950 opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
          <button className="w-3 h-3 rounded-full bg-amber-500/90 hover:bg-amber-600 shadow-[0_0_8px_rgba(245,158,11,0.4)] transition-all" />
          <button className="w-3 h-3 rounded-full bg-emerald-500/90 hover:bg-emerald-600 shadow-[0_0_8px_rgba(16,185,129,0.4)] transition-all" />
        </div>

        {/* Tab Items */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {tabs.map((tab) => {
            const isActive = tab.id === activeTabId;
            return (
              <div
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono transition-all cursor-pointer border shrink-0 ${
                  isActive
                    ? 'bg-slate-800/90 text-sky-200 border-sky-500/40 shadow-sm'
                    : 'bg-slate-900/40 text-slate-400 border-transparent hover:bg-slate-800/40 hover:text-slate-200'
                }`}
              >
                <TermIcon className={`w-3.5 h-3.5 ${isActive ? 'text-sky-400' : 'text-slate-500'}`} />
                <span className="truncate max-w-[120px] font-medium">{tab.title}</span>
                {tabs.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCloseTab(tab.id);
                    }}
                    className="p-0.5 rounded hover:bg-rose-500/20 hover:text-rose-300 transition-colors opacity-60 hover:opacity-100"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}

          <button
            onClick={onNewTab}
            className="p-1.5 rounded-lg bg-slate-900/50 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-white/5 transition-all shrink-0"
            title="New Tab (⌘T)"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Right: Controls & Tools */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Workspace Switcher */}
        <button
          onClick={onOpenWorkspaceModal}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono bg-slate-900/80 hover:bg-slate-800 text-sky-300 border border-sky-500/30 transition-all shadow-sm"
          title="Switch Active Workspace / Session"
        >
          <Layers className="w-3.5 h-3.5 text-sky-400" />
          <span className="font-semibold">{activeWorkspaceName}</span>
        </button>

        {/* Split Panes */}
        <div className="flex items-center bg-slate-900/80 rounded-md p-0.5 border border-white/10">
          <button
            onClick={onSplitRight}
            className="p-1 rounded hover:bg-slate-800 text-slate-300 transition-colors"
            title="Split Right (⌘D)"
          >
            <Columns className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onSplitDown}
            className="p-1 rounded hover:bg-slate-800 text-slate-300 transition-colors"
            title="Split Down (⌘⇧D)"
          >
            <Rows className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Explorer Panel Toggle */}
        <button
          onClick={onToggleExplorer}
          className="p-1.5 rounded-md bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-white/10 transition-all"
          title="Toggle File System Explorer"
        >
          <FolderTree className="w-3.5 h-3.5" />
        </button>

        {/* Command Palette */}
        <button
          onClick={onToggleCommandPalette}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 border border-sky-500/30 transition-all"
          title="Command Palette (⌘⇧P)"
        >
          <Command className="w-3.5 h-3.5" />
          <span className="hidden md:inline font-semibold">⌘⇧P</span>
        </button>

        {/* Process Observatory */}
        <button
          onClick={onToggleObservatory}
          className="p-1.5 rounded-md bg-slate-900/80 hover:bg-slate-800 text-amber-300 border border-amber-500/30 transition-all"
          title="Process Observatory"
        >
          <Activity className="w-3.5 h-3.5" />
        </button>

        {/* Developer Debug Inspector */}
        <button
          onClick={onToggleDevInspector}
          className="p-1.5 rounded-md bg-slate-900/80 hover:bg-slate-800 text-emerald-300 border border-emerald-500/30 transition-all"
          title="Terminal Debug Inspector"
        >
          <Cpu className="w-3.5 h-3.5" />
        </button>

        {/* Theme Picker Dropdown */}
        <div className="relative group">
          <button
            className="flex items-center gap-1 px-2 py-1 rounded-md text-xs font-mono bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-white/10 transition-all"
            title="Terminal Theme"
          >
            <Palette className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">{themeName}</span>
          </button>

          <div className="absolute right-0 top-full mt-1 hidden group-hover:flex flex-col w-36 py-1 bg-slate-900/95 border border-white/15 rounded-lg shadow-2xl backdrop-blur-xl z-50">
            {(['Obsidian', 'Graphite', 'Archive', 'Light', 'High Contrast'] as ThemeName[]).map((t) => (
              <button
                key={t}
                onClick={() => onSelectTheme(t)}
                className={`px-3 py-1.5 text-left text-xs font-mono hover:bg-sky-500/20 transition-colors ${
                  themeName === t ? 'text-sky-400 font-bold' : 'text-slate-300'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
