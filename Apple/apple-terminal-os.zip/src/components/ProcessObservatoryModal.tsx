import React, { useState, useEffect } from 'react';
import { ProcessItem } from '../types';
import { Activity, RefreshCw, X, ShieldAlert, Cpu, HardDrive } from 'lucide-react';

interface ProcessObservatoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProcessObservatoryModal: React.FC<ProcessObservatoryModalProps> = ({ isOpen, onClose }) => {
  const [processes, setProcesses] = useState<ProcessItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('');

  const fetchProcesses = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/processes');
      const data = await res.json();
      setProcesses(data.processes || []);
    } catch {
      // fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchProcesses();
      const interval = setInterval(fetchProcesses, 3000);
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const filtered = processes.filter(
    (p) => p.command.toLowerCase().includes(filter.toLowerCase()) || p.pid.includes(filter) || p.user.includes(filter)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md" onClick={onClose}>
      <div
        className="w-full max-w-4xl bg-slate-900/95 border border-amber-500/30 rounded-xl shadow-2xl overflow-hidden backdrop-blur-2xl flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-slate-950/80">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-amber-400" />
            <h2 className="text-sm font-semibold font-mono text-amber-200">PROCESS OBSERVATORY (macOS / PTY)</h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchProcesses}
              className={`p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-all ${
                loading ? 'animate-spin' : ''
              }`}
              title="Refresh Process List"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-rose-500/20 text-slate-400 hover:text-rose-300">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="p-3 border-b border-white/10 bg-slate-950/40">
          <input
            type="text"
            placeholder="Filter processes by command or PID (e.g. 'zsh', 'cargo', 'node')..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-white/10 text-xs font-mono text-slate-100 placeholder:text-slate-500 outline-none focus:border-amber-500/50"
          />
        </div>

        {/* Table */}
        <div className="flex-1 overflow-y-auto p-2">
          <table className="w-full text-left font-mono text-xs text-slate-300 border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 text-[11px] uppercase bg-slate-950/30">
                <th className="p-2">PID</th>
                <th className="p-2">USER</th>
                <th className="p-2">CPU %</th>
                <th className="p-2">MEM %</th>
                <th className="p-2">STAT</th>
                <th className="p-2">TIME</th>
                <th className="p-2">COMMAND</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filtered.map((proc) => (
                <tr key={proc.id} className="hover:bg-amber-500/10 transition-colors">
                  <td className="p-2 font-semibold text-amber-300">{proc.pid}</td>
                  <td className="p-2 text-slate-400">{proc.user}</td>
                  <td className="p-2 font-mono text-emerald-400">{proc.cpu}</td>
                  <td className="p-2 font-mono text-sky-400">{proc.mem}</td>
                  <td className="p-2 text-slate-400">{proc.stat}</td>
                  <td className="p-2 text-slate-400">{proc.time}</td>
                  <td className="p-2 font-mono text-slate-200 truncate max-w-md">{proc.command}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-white/10 bg-slate-950/80 text-[11px] font-mono text-slate-400 flex items-center justify-between">
          <span>Active Tracked Processes: {filtered.length}</span>
          <span className="text-amber-400">SIGINT / SIGTERM protection active</span>
        </div>
      </div>
    </div>
  );
};
