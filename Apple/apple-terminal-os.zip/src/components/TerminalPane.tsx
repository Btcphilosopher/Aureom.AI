import React, { useEffect, useRef, useState } from 'react';
import { Terminal as XTerm } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import { SearchAddon } from '@xterm/addon-search';
import { WebglAddon } from '@xterm/addon-webgl';
import '@xterm/xterm/css/xterm.css';
import { ThemePalette } from '../types';
import { Play, Terminal as TermIcon, RotateCcw, Search, Sparkles, ShieldCheck, Folder } from 'lucide-react';

interface TerminalPaneProps {
  paneId: string;
  sessionId: string;
  theme: ThemePalette;
  isActive: boolean;
  cwd: string;
  shell: string;
  onFocus: () => void;
  onCwdChange?: (newCwd: string) => void;
  onTitleChange?: (title: string) => void;
}

export const TerminalPane: React.FC<TerminalPaneProps> = ({
  paneId,
  sessionId,
  theme,
  isActive,
  cwd,
  shell,
  onFocus,
  onCwdChange,
  onTitleChange,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const xtermRef = useRef<XTerm | null>(null);
  const fitAddonRef = useRef<FitAddon | null>(null);
  const searchAddonRef = useRef<SearchAddon | null>(null);
  const wsRef = useRef<WebSocket | null>(null);

  const [connected, setConnected] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isBuilding, setIsBuilding] = useState(false);

  // Initialize xterm instance
  useEffect(() => {
    if (!containerRef.current) return;

    const term = new XTerm({
      cursorBlink: true,
      cursorStyle: 'block',
      fontSize: 13,
      fontFamily: '"SF Mono", "Menlo", "Consolas", "JetBrains Mono", monospace',
      letterSpacing: 0.5,
      lineHeight: 1.2,
      theme: {
        background: theme.background,
        foreground: theme.foreground,
        cursor: theme.cursor,
        selectionBackground: theme.selection,
        black: theme.black,
        red: theme.red,
        green: theme.green,
        yellow: theme.yellow,
        blue: theme.blue,
        magenta: theme.magenta,
        cyan: theme.cyan,
        white: theme.white,
        brightBlack: theme.brightBlack,
        brightRed: theme.brightRed,
        brightGreen: theme.brightGreen,
        brightYellow: theme.brightYellow,
        brightBlue: theme.brightBlue,
        brightMagenta: theme.brightMagenta,
        brightCyan: theme.brightCyan,
        brightWhite: theme.brightWhite,
      },
      allowProposedApi: true,
      scrollback: 50000,
    });

    const fitAddon = new FitAddon();
    const searchAddon = new SearchAddon();

    term.loadAddon(fitAddon);
    term.loadAddon(searchAddon);

    term.open(containerRef.current);
    fitAddon.fit();

    xtermRef.current = term;
    fitAddonRef.current = fitAddon;
    searchAddonRef.current = searchAddon;

    // Try webgl renderer for high FPS hardware acceleration
    try {
      const webglAddon = new WebglAddon();
      term.loadAddon(webglAddon);
    } catch {
      // Fallback to DOM renderer
    }

    // Connect to Backend PTY WebSocket
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/pty?session_id=${sessionId}`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      setConnected(true);
      term.writeln('\x1b[32m Apple Terminal OS v0.1.0 (aarch64-apple-darwin)\x1b[0m');
      term.writeln(`\x1b[90mSession: ${sessionId} | PTY: posix_openpt | Shell: ${shell}\x1b[0m\r\n`);
    };

    socket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'output') {
          term.write(msg.data);
        } else if (msg.type === 'exit') {
          term.writeln(`\r\n\x1b[33m[Process exited with code ${msg.code}]\x1b[0m`);
        }
      } catch {
        term.write(event.data);
      }
    };

    socket.onerror = () => {
      setConnected(false);
    };

    socket.onclose = () => {
      setConnected(false);
    };

    wsRef.current = socket;

    // Handle user input
    term.onData((data) => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: 'input', data }));
      } else {
        // Fallback HTTP write if socket re-connecting
        fetch('/api/terminal/write', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: sessionId, data }),
        });
      }
    });

    // Handle window resize
    const handleResize = () => {
      if (fitAddonRef.current) {
        fitAddonRef.current.fit();
        if (xtermRef.current && socket.readyState === WebSocket.OPEN) {
          socket.send(
            JSON.stringify({
              type: 'resize',
              cols: xtermRef.current.cols,
              rows: xtermRef.current.rows,
            })
          );
        }
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      socket.close();
      term.dispose();
    };
  }, [sessionId]);

  // Update theme dynamically
  useEffect(() => {
    if (xtermRef.current) {
      xtermRef.current.options.theme = {
        background: theme.background,
        foreground: theme.foreground,
        cursor: theme.cursor,
        selectionBackground: theme.selection,
        black: theme.black,
        red: theme.red,
        green: theme.green,
        yellow: theme.yellow,
        blue: theme.blue,
        magenta: theme.magenta,
        cyan: theme.cyan,
        white: theme.white,
        brightBlack: theme.brightBlack,
        brightRed: theme.brightRed,
        brightGreen: theme.brightGreen,
        brightYellow: theme.brightYellow,
        brightBlue: theme.brightBlue,
        brightMagenta: theme.brightMagenta,
        brightCyan: theme.brightCyan,
        brightWhite: theme.brightWhite,
      };
    }
  }, [theme]);

  // Focus terminal when pane becomes active
  useEffect(() => {
    if (isActive && xtermRef.current) {
      xtermRef.current.focus();
      if (fitAddonRef.current) {
        fitAddonRef.current.fit();
      }
    }
  }, [isActive]);

  const runCommandDirect = (cmd: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'input', data: `${cmd}\r` }));
    }
  };

  const handleSearchNext = () => {
    if (searchAddonRef.current && searchQuery) {
      searchAddonRef.current.findNext(searchQuery);
    }
  };

  const handleSearchPrev = () => {
    if (searchAddonRef.current && searchQuery) {
      searchAddonRef.current.findPrevious(searchQuery);
    }
  };

  return (
    <div
      onClick={onFocus}
      className={`relative flex flex-col h-full w-full overflow-hidden transition-all border ${
        isActive
          ? 'border-sky-500/60 shadow-[0_0_15px_rgba(56,189,248,0.15)] ring-1 ring-sky-500/30'
          : 'border-white/10 hover:border-white/20'
      }`}
      style={{ backgroundColor: theme.background }}
    >
      {/* Pane Toolbar Header */}
      <div
        className="flex items-center justify-between px-3 py-1.5 text-xs select-none border-b border-white/10 bg-black/30 backdrop-blur-md"
        style={{ color: theme.foreground }}
      >
        <div className="flex items-center gap-2 font-mono text-[11px] opacity-80">
          <TermIcon className="w-3.5 h-3.5 text-sky-400" />
          <span className="font-semibold text-sky-300">{shell.split('/').pop()}</span>
          <span className="opacity-40">•</span>
          <span className="truncate max-w-[200px]" title={cwd}>
            {cwd.replace(/^\/Users\/[^\/]+/, '~')}
          </span>
          <span
            className={`w-2 h-2 rounded-full ${
              connected ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]' : 'bg-amber-400'
            }`}
            title={connected ? 'PTY Session Active' : 'Connecting...'}
          />
        </div>

        {/* Action Shortcuts Toolbar */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => runCommandDirect('cargo check')}
            className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-colors"
            title="Run cargo check in workspace"
          >
            <Sparkles className="w-3 h-3" />
            <span>cargo check</span>
          </button>

          <button
            onClick={() => runCommandDirect('cargo test')}
            className="flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 transition-colors"
            title="Run cargo test in workspace"
          >
            <Play className="w-3 h-3" />
            <span>cargo test</span>
          </button>

          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className={`p-1 rounded transition-colors ${
              searchOpen ? 'bg-sky-500/20 text-sky-300' : 'hover:bg-white/10 opacity-70'
            }`}
            title="Search scrollback (⌘F)"
          >
            <Search className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => runCommandDirect('clear')}
            className="p-1 rounded hover:bg-white/10 opacity-70 transition-colors"
            title="Clear Terminal Output"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Floating Scrollback Search Bar */}
      {searchOpen && (
        <div className="absolute top-9 right-3 z-30 flex items-center gap-2 p-2 rounded-lg bg-slate-900/90 border border-sky-500/40 shadow-2xl backdrop-blur-xl">
          <Search className="w-4 h-4 text-sky-400" />
          <input
            type="text"
            placeholder="Search terminal..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSearchNext();
              if (e.key === 'Escape') setSearchOpen(false);
            }}
            className="bg-transparent text-xs text-white outline-none w-44 font-mono placeholder:text-slate-500"
            autoFocus
          />
          <button
            onClick={handleSearchPrev}
            className="px-1.5 py-0.5 text-[10px] rounded bg-white/10 hover:bg-white/20 text-slate-200 font-mono"
          >
            Prev
          </button>
          <button
            onClick={handleSearchNext}
            className="px-1.5 py-0.5 text-[10px] rounded bg-sky-500/30 hover:bg-sky-500/50 text-sky-200 font-mono"
          >
            Next
          </button>
        </div>
      )}

      {/* Terminal Viewport */}
      <div className="flex-1 w-full h-full p-2 overflow-hidden" ref={containerRef} />
    </div>
  );
};
