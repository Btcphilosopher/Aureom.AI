import React, { useState, useEffect } from 'react';
import { CommandPaletteAction } from '../types';
import { Command as CmdIcon, Search, Sparkles, Terminal, Shield, ArrowRight } from 'lucide-react';

interface CommandPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  actions: CommandPaletteAction[];
}

export const CommandPaletteModal: React.FC<CommandPaletteModalProps> = ({ isOpen, onClose, actions }) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    setQuery('');
    setSelectedIndex(0);
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredActions = actions.filter(
    (a) =>
      a.title.toLowerCase().includes(query.toLowerCase()) ||
      a.description.toLowerCase().includes(query.toLowerCase()) ||
      a.category.toLowerCase().includes(query.toLowerCase())
  );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(1, filteredActions.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + filteredActions.length) % Math.max(1, filteredActions.length));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredActions[selectedIndex]) {
        filteredActions[selectedIndex].handler();
        onClose();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 bg-black/60 backdrop-blur-md"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl bg-slate-900/95 border border-sky-500/30 rounded-xl shadow-2xl overflow-hidden backdrop-blur-2xl flex flex-col max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search Header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-white/10 bg-slate-950/60">
          <CmdIcon className="w-5 h-5 text-sky-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Type a command or search (e.g. 'Cargo', 'New Tab', 'Split')..."
            className="w-full bg-transparent text-sm text-slate-100 placeholder:text-slate-500 outline-none font-mono"
            autoFocus
          />
          <span className="px-2 py-0.5 text-[10px] font-mono text-slate-400 bg-white/5 rounded border border-white/10">
            ESC
          </span>
        </div>

        {/* Action List */}
        <div className="flex-1 overflow-y-auto p-2 divide-y divide-white/5">
          {filteredActions.length === 0 ? (
            <div className="py-8 text-center text-xs font-mono text-slate-400">No matching commands found.</div>
          ) : (
            filteredActions.map((action, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={action.id}
                  onClick={() => {
                    action.handler();
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between p-2.5 rounded-lg transition-all cursor-pointer font-mono text-xs ${
                    isSelected ? 'bg-sky-500/20 text-sky-200 border border-sky-500/40 shadow-sm' : 'text-slate-300 hover:bg-white/5'
                  }`}
                >
                  <div className="flex flex-col gap-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-100">{action.title}</span>
                      <span className="px-1.5 py-0.2 text-[9px] rounded bg-white/10 text-slate-400 font-sans uppercase">
                        {action.category}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 font-sans">{action.description}</span>
                  </div>

                  {action.shortcut && (
                    <div className="flex items-center gap-1">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-sky-300 border border-white/10">
                        {action.shortcut}
                      </span>
                      {isSelected && <ArrowRight className="w-3.5 h-3.5 text-sky-400" />}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="flex items-center justify-between px-4 py-2 border-t border-white/10 bg-slate-950/80 text-[11px] font-mono text-slate-400">
          <span>Navigate with ↑ ↓ • Press Enter to select</span>
          <span className="text-sky-400 font-semibold">APPLE TERMINAL OS</span>
        </div>
      </div>
    </div>
  );
};
