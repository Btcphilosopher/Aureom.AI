import React, { useState, useEffect } from 'react';
import { FileItem, GitInfo } from '../types';
import { FolderTree, Folder, FileText, GitBranch, ArrowLeft, RefreshCw, Terminal, ExternalLink, HardDrive } from 'lucide-react';

interface FileSystemExplorerPanelProps {
  isOpen: boolean;
  onClose: () => void;
  currentPath: string;
  onNavigatePath: (newPath: string) => void;
  onOpenTerminalAtFolder: (path: string) => void;
}

export const FileSystemExplorerPanel: React.FC<FileSystemExplorerPanelProps> = ({
  isOpen,
  onClose,
  currentPath,
  onNavigatePath,
  onOpenTerminalAtFolder,
}) => {
  const [items, setItems] = useState<FileItem[]>([]);
  const [parentPath, setParentPath] = useState<string>('');
  const [gitInfo, setGitInfo] = useState<GitInfo | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchFiles = async (pathStr: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/filesystem/list?path=${encodeURIComponent(pathStr)}`);
      const data = await res.json();
      if (data.items) {
        setItems(data.items);
        setParentPath(data.parent_path);
        setGitInfo(data.git);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchFiles(currentPath);
    }
  }, [isOpen, currentPath]);

  if (!isOpen) return null;

  return (
    <div className="w-72 bg-slate-950/90 border-r border-white/10 flex flex-col h-full select-none shrink-0 font-mono text-xs backdrop-blur-xl">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-white/10 bg-black/40">
        <div className="flex items-center gap-2 text-sky-400">
          <FolderTree className="w-4 h-4" />
          <span className="font-semibold text-slate-200">Filesystem</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => fetchFiles(currentPath)}
            className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-slate-200 transition-colors"
            title="Refresh Directory"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-white/10 text-slate-400 hover:text-slate-200 transition-colors"
          >
            ✕
          </button>
        </div>
      </div>

      {/* Path Breadcrumbs */}
      <div className="flex items-center gap-1.5 p-2 bg-slate-900/60 border-b border-white/5 text-[11px] text-slate-300">
        {parentPath && (
          <button
            onClick={() => onNavigatePath(parentPath)}
            className="p-1 rounded bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
            title="Up Parent Directory"
          >
            <ArrowLeft className="w-3 h-3" />
          </button>
        )}
        <span className="truncate font-semibold text-sky-300" title={currentPath}>
          {currentPath.replace(/^\/Users\/[^\/]+/, '~')}
        </span>
      </div>

      {/* Git Indicator if available */}
      {gitInfo?.is_repo && (
        <div className="flex items-center justify-between px-3 py-1.5 bg-emerald-500/10 border-b border-emerald-500/20 text-emerald-300 text-[11px]">
          <div className="flex items-center gap-1.5">
            <GitBranch className="w-3.5 h-3.5" />
            <span className="font-bold">{gitInfo.branch}</span>
          </div>
          {gitInfo.dirty && <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px]">DIRTY</span>}
        </div>
      )}

      {/* File List */}
      <div className="flex-1 overflow-y-auto p-1 divide-y divide-white/5">
        {items.map((item) => (
          <div
            key={item.path}
            onClick={() => {
              if (item.is_dir) {
                onNavigatePath(item.path);
              }
            }}
            className="flex items-center justify-between p-1.5 rounded hover:bg-white/5 transition-colors cursor-pointer group text-slate-300"
          >
            <div className="flex items-center gap-2 truncate">
              {item.is_dir ? (
                <Folder className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              ) : (
                <FileText className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              )}
              <span className={`truncate ${item.is_dir ? 'font-semibold text-slate-100' : 'text-slate-300'}`}>
                {item.name}
              </span>
            </div>

            {item.is_dir && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenTerminalAtFolder(item.path);
                }}
                className="p-1 rounded hover:bg-sky-500/20 text-sky-400 opacity-0 group-hover:opacity-100 transition-opacity"
                title="Open Terminal at Folder"
              >
                <Terminal className="w-3 h-3" />
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Shortcuts Footer */}
      <div className="p-2 border-t border-white/10 bg-black/40 text-[10px] text-slate-400 flex flex-col gap-1">
        <button
          onClick={() => onOpenTerminalAtFolder(currentPath)}
          className="flex items-center justify-center gap-1.5 py-1 rounded bg-sky-500/20 hover:bg-sky-500/30 text-sky-300 font-semibold border border-sky-500/30 transition-all"
        >
          <Terminal className="w-3 h-3" />
          <span>Open Terminal Here</span>
        </button>
      </div>
    </div>
  );
};
