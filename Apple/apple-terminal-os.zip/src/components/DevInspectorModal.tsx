import React, { useState, useEffect } from 'react';
import { SystemInfo } from '../types';
import { Cpu, X, Terminal, CheckCircle2, Flame, Wrench, Shield, Layers, RefreshCw } from 'lucide-react';

interface DevInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  systemInfo: SystemInfo | null;
  onRefreshSystemInfo: () => void;
}

export const DevInspectorModal: React.FC<DevInspectorModalProps> = ({
  isOpen,
  onClose,
  systemInfo,
  onRefreshSystemInfo,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md" onClick={onClose}>
      <div
        className="w-full max-w-3xl bg-slate-900/95 border border-emerald-500/30 rounded-xl shadow-2xl overflow-hidden backdrop-blur-2xl flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-slate-950/80">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-semibold font-mono text-emerald-200">DEVELOPER & TERMINAL ENGINE INSPECTOR</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onRefreshSystemInfo}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-all"
              title="Refresh System Diagnostic"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-rose-500/20 text-slate-400 hover:text-rose-300">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 overflow-y-auto font-mono text-xs text-slate-200">
          {/* Engine & Platform Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3 rounded-lg bg-slate-950/60 border border-white/10 space-y-1.5">
              <span className="text-emerald-400 font-semibold text-[11px] uppercase tracking-wider block">
                Engine & PTY Architecture
              </span>
              <div className="flex justify-between text-slate-300">
                <span>Application:</span>
                <span className="text-sky-300 font-bold">{systemInfo?.app_name || 'Apple Terminal OS'}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Rust Crate:</span>
                <span className="text-purple-300">terminal_os v0.1.0</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Target Arch:</span>
                <span className="text-emerald-300">{systemInfo?.arch || 'aarch64-apple-darwin'}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Renderer:</span>
                <span className="text-amber-300">WebGL / GPU Metal Grid</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>PTY Implementation:</span>
                <span className="text-slate-300">posix_openpt / pts</span>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-slate-950/60 border border-white/10 space-y-1.5">
              <span className="text-emerald-400 font-semibold text-[11px] uppercase tracking-wider block">
                Hardware & Runtime Memory
              </span>
              <div className="flex justify-between text-slate-300">
                <span>Host Platform:</span>
                <span className="text-slate-200">{systemInfo?.host_os || 'macOS Sequoia'}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Processor:</span>
                <span className="text-slate-200">{systemInfo?.model || 'Apple Silicon'}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Total Memory:</span>
                <span className="text-slate-200">{systemInfo?.total_mem_mb} MB</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Free Memory:</span>
                <span className="text-emerald-300">{systemInfo?.free_mem_mb} MB</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Render Frame Target:</span>
                <span className="text-sky-300">60 FPS (1.4ms frame duration)</span>
              </div>
            </div>
          </div>

          {/* Developer Tooling Grid */}
          <div className="p-3 rounded-lg bg-slate-950/60 border border-white/10 space-y-2">
            <span className="text-emerald-400 font-semibold text-[11px] uppercase tracking-wider block">
              Installed Developer Toolchain
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {systemInfo?.dev_tools &&
                Object.entries(systemInfo.dev_tools).map(([tool, infoItem]) => {
                  const info = infoItem as { installed: boolean; path?: string; version?: string };
                  return (
                    <div
                      key={tool}
                      className={`flex items-center gap-2 p-2 rounded border text-xs font-mono ${
                        info.installed ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200' : 'bg-white/5 border-white/5 text-slate-500'
                      }`}
                    >
                      <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 ${info.installed ? 'text-emerald-400' : 'text-slate-600'}`} />
                      <div className="flex flex-col truncate">
                        <span className="font-bold uppercase text-[11px]">{tool}</span>
                        <span className="text-[10px] text-slate-400 truncate">{info.installed ? info.version || 'Available' : 'Not installed'}</span>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-white/10 bg-slate-950/80 text-[11px] font-mono text-slate-400 flex items-center justify-between">
          <span>Rust Workspace: ./Cargo.toml (18 Workspace Crates)</span>
          <span className="text-emerald-400 font-semibold">Native macOS Instrument</span>
        </div>
      </div>
    </div>
  );
};
