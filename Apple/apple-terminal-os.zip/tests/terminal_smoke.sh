#!/usr/bin/env bash
echo "=== TERMINAL OS SMOKE TEST ==="
echo "1. Basic Echo and Printf:"
printf "   \033[32m[PASS]\033[0m Green text verification\n"
printf "   \033[34m[PASS]\033[0m Blue text verification\n"
printf "   \033[38;2;255;165;0m[PASS]\033[0m Truecolor RGB verification\n"

echo "2. Unicode & Symbol Rendering:"
echo "    macOS Silicon | ⚡ High Performance | 🚀 Rust Engine | 💻 PTY Master"

echo "3. Cursor Positioning & Clear Operations:"
printf "\033[2K\r   [PASS] Line erase and cursor reset OK\n"

echo "Smoke test complete."
