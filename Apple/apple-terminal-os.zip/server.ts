import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn, ChildProcessWithoutNullStreams, execSync } from 'child_process';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import os from 'os';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface TerminalSession {
  id: string;
  shell: string;
  cwd: string;
  pid: number | undefined;
  process: ChildProcessWithoutNullStreams;
  created_at: number;
  cols: number;
  rows: number;
  history: string[];
}

const sessions = new Map<string, TerminalSession>();

function getAvailableShells(): string[] {
  const candidates = ['/bin/zsh', '/bin/bash', '/usr/bin/zsh', '/usr/bin/bash', '/bin/sh'];
  const available: string[] = [];
  for (const sh of candidates) {
    if (fs.existsSync(sh)) {
      available.push(sh);
    }
  }
  return available.length > 0 ? available : ['/bin/sh'];
}

function detectDeveloperTools() {
  const tools = ['rustc', 'cargo', 'python3', 'node', 'npm', 'git', 'clang', 'swift', 'docker', 'brew', 'make', 'cmake'];
  const results: Record<string, { installed: boolean; path?: string; version?: string }> = {};

  for (const tool of tools) {
    try {
      const toolPath = execSync(`which ${tool} 2>/dev/null`, { encoding: 'utf-8' }).trim();
      let version = '';
      try {
        version = execSync(`${tool} --version 2>/dev/null || ${tool} -v 2>/dev/null`, { encoding: 'utf-8' }).trim();
        // keep version short
        version = version.split('\n')[0].substring(0, 40);
      } catch {
        version = 'Available';
      }
      results[tool] = { installed: true, path: toolPath, version };
    } catch {
      results[tool] = { installed: false };
    }
  }
  return results;
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });

  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', app: 'Apple Terminal OS', version: '0.1.0' });
  });

  app.get('/api/system-info', (_req, res) => {
    const defaultShell = getAvailableShells()[0];
    const devTools = detectDeveloperTools();
    
    res.json({
      app_name: 'APPLE TERMINAL OS',
      internal_name: 'terminal_os',
      version: '0.1.0',
      platform: 'macOS Sequoia 15.0 (Emulated/Native)',
      host_os: `${os.type()} ${os.release()}`,
      arch: os.arch() === 'arm64' ? 'aarch64-apple-darwin' : 'x86_64-apple-darwin',
      cpus: os.cpus().length,
      model: os.cpus()[0]?.model || 'Apple M3 Max',
      total_mem_mb: Math.round(os.totalmem() / (1024 * 1024)),
      free_mem_mb: Math.round(os.freemem() / (1024 * 1024)),
      default_shell: defaultShell,
      available_shells: getAvailableShells(),
      active_sessions: sessions.size,
      dev_tools: devTools,
      rust_status: devTools.rustc?.installed ? 'Installed' : 'Built-in Workspace Ready',
    });
  });

  app.get('/api/processes', (_req, res) => {
    try {
      const output = execSync('ps aux | head -n 30', { encoding: 'utf-8' });
      const lines = output.trim().split('\n');
      const header = lines[0];
      const items = lines.slice(1).map((line, idx) => {
        const parts = line.split(/\s+/);
        return {
          id: idx,
          user: parts[0],
          pid: parts[1],
          cpu: parts[2],
          mem: parts[3],
          stat: parts[7] || 'R',
          time: parts[9] || '0:00',
          command: parts.slice(10).join(' '),
        };
      });
      res.json({ header, processes: items });
    } catch {
      res.json({ header: '', processes: [] });
    }
  });

  app.get('/api/filesystem/list', (req, res) => {
    const reqPath = (req.query.path as string) || process.cwd();
    const targetPath = path.resolve(reqPath);

    try {
      if (!fs.existsSync(targetPath)) {
        res.status(404).json({ error: 'Path does not exist' });
        return;
      }

      const stats = fs.statSync(targetPath);
      if (!stats.isDirectory()) {
        res.json({ is_file: true, path: targetPath, size: stats.size });
        return;
      }

      const entries = fs.readdirSync(targetPath, { withFileTypes: true });
      const items = entries.map((e) => {
        const itemPath = path.join(targetPath, e.name);
        let isDir = e.isDirectory();
        let size = 0;
        try {
          if (!isDir) size = fs.statSync(itemPath).size;
        } catch {
          // ignore
        }
        return {
          name: e.name,
          path: itemPath,
          is_dir: isDir,
          size,
        };
      });

      // Check git repository status
      let gitStatus = null;
      try {
        const gitBranch = execSync('git rev-parse --abbrev-ref HEAD 2>/dev/null', { cwd: targetPath, encoding: 'utf-8' }).trim();
        const gitChanges = execSync('git status --porcelain 2>/dev/null', { cwd: targetPath, encoding: 'utf-8' }).trim();
        gitStatus = {
          is_repo: true,
          branch: gitBranch || 'main',
          dirty: gitChanges.length > 0,
          untracked_count: gitChanges.split('\n').filter((l) => l.startsWith('??')).length,
        };
      } catch {
        gitStatus = { is_repo: false };
      }

      res.json({
        current_path: targetPath,
        parent_path: path.dirname(targetPath),
        items,
        git: gitStatus,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/terminal/spawn', (req, res) => {
    const { shell, cwd, cols, rows } = req.body;
    const sessionId = `sess_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    
    const availableShells = getAvailableShells();
    let targetShell = (shell && fs.existsSync(shell)) ? shell : availableShells[0];
    let targetCwd = (cwd && fs.existsSync(cwd)) ? cwd : process.cwd();

    const env = {
      ...process.env,
      TERM: 'xterm-256color',
      COLORTERM: 'truecolor',
      TERM_PROGRAM: 'AppleTerminalOS',
      TERM_PROGRAM_VERSION: '0.1.0',
      PWD: targetCwd,
    };

    // Spawn shell process with interactive flag
    let proc: ChildProcessWithoutNullStreams;
    try {
      proc = spawn(targetShell, ['-i'], {
        cwd: targetCwd,
        env,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
    } catch {
      // Fallback if spawn throws synchronously
      targetShell = '/bin/sh';
      proc = spawn('/bin/sh', [], {
        cwd: process.cwd(),
        env,
        stdio: ['pipe', 'pipe', 'pipe'],
      });
    }

    // Always attach error listener to prevent unhandled 'error' event crashes
    proc.on('error', (err) => {
      console.error(`[Terminal Spawn Error] ${targetShell}:`, err);
    });

    const session: TerminalSession = {
      id: sessionId,
      shell: targetShell,
      cwd: targetCwd,
      pid: proc.pid,
      process: proc,
      created_at: Date.now(),
      cols: cols || 80,
      rows: rows || 24,
      history: [],
    };

    sessions.set(sessionId, session);

    res.json({
      session_id: sessionId,
      pid: proc.pid,
      shell: targetShell,
      cwd: targetCwd,
      cols: session.cols,
      rows: session.rows,
    });
  });

  app.post('/api/terminal/write', (req, res) => {
    const { session_id, data } = req.body;
    const sess = sessions.get(session_id);
    if (!sess) {
      res.status(404).json({ error: 'Session not found' });
      return;
    }

    try {
      sess.process.stdin.write(data);
      res.json({ status: 'ok' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/terminal/kill', (req, res) => {
    const { session_id } = req.body;
    const sess = sessions.get(session_id);
    if (sess) {
      try {
        sess.process.kill('SIGTERM');
      } catch {
        // ignore
      }
      sessions.delete(session_id);
    }
    res.json({ status: 'ok' });
  });

  // Handle WebSocket upgrades on /ws/pty
  server.on('upgrade', (request, socket, head) => {
    const url = new URL(request.url || '', `http://${request.headers.host}`);
    if (url.pathname === '/ws/pty') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else {
      socket.destroy();
    }
  });

  wss.on('connection', (ws: WebSocket, request) => {
    const url = new URL(request.url || '', `http://${request.headers.host}`);
    const sessionId = url.searchParams.get('session_id');

    if (!sessionId || !sessions.has(sessionId)) {
      ws.send(JSON.stringify({ type: 'error', message: 'Session not found or invalid' }));
      ws.close();
      return;
    }

    const session = sessions.get(sessionId)!;

    // Stream PTY stdout and stderr to WebSocket
    const onStdout = (data: Buffer) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'output', data: data.toString('utf-8') }));
      }
    };

    const onStderr = (data: Buffer) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'output', data: data.toString('utf-8') }));
      }
    };

    session.process.stdout.on('data', onStdout);
    session.process.stderr.on('data', onStderr);

    session.process.on('exit', (code) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'exit', code }));
      }
    });

    ws.on('message', (message: string) => {
      try {
        const msg = JSON.parse(message.toString());
        if (msg.type === 'input') {
          session.process.stdin.write(msg.data);
        } else if (msg.type === 'resize') {
          session.cols = msg.cols;
          session.rows = msg.rows;
        } else if (msg.type === 'signal') {
          if (msg.signal === 'SIGINT') session.process.kill('SIGINT');
          if (msg.signal === 'SIGTERM') session.process.kill('SIGTERM');
        }
      } catch (e) {
        // Raw byte fallback
        session.process.stdin.write(message);
      }
    });

    ws.on('close', () => {
      session.process.stdout.removeListener('data', onStdout);
      session.process.stderr.removeListener('data', onStderr);
    });
  });

  // Serve Vite in development / production static fallback
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Apple Terminal OS Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
