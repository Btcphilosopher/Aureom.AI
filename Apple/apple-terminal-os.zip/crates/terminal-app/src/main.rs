use terminal_config::TerminalConfig;
use terminal_macos::MacOSIntegration;
use terminal_session::TerminalSession;

fn main() {
    println!("Initializing Apple Terminal OS...");
    let sys = MacOSIntegration::detect_system();
    println!("Detected system: {} ({})", sys.os_version, sys.architecture);

    let config = TerminalConfig::default();
    println!("Loaded theme: {}", config.theme);

    let session = TerminalSession::new("sess_init".into(), config.shell.clone(), "/Users/apple".into());
    println!("Created PTY session {} on {}", session.session_id, session.pty.shell);

    println!("Apple Terminal OS Core Ready.");
}
