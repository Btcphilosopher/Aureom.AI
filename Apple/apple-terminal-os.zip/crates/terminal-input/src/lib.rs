#[derive(Debug, Clone)]
pub enum KeyShortcut {
    NewTab,
    CloseTab,
    SplitRight,
    SplitDown,
    Search,
    CommandPalette,
    ZoomIn,
    ZoomOut,
    ResetZoom,
}

pub struct KeyboardDispatcher;

impl KeyboardDispatcher {
    pub fn parse_macos_shortcut(key: &str, meta: bool, shift: bool) -> Option<KeyShortcut> {
        if meta && !shift && key == "t" {
            Some(KeyShortcut::NewTab)
        } else if meta && !shift && key == "w" {
            Some(KeyShortcut::CloseTab)
        } else if meta && shift && key == "p" {
            Some(KeyShortcut::CommandPalette)
        } else if meta && !shift && key == "f" {
            Some(KeyShortcut::Search)
        } else if meta && !shift && key == "d" {
            Some(KeyShortcut::SplitRight)
        } else if meta && shift && key == "d" {
            Some(KeyShortcut::SplitDown)
        } else {
            None
        }
    }
}
