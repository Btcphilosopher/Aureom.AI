#[derive(Debug, Clone)]
pub struct GitStatus {
    pub is_repo: bool,
    pub branch: Option<String>,
    pub ahead_behind: (usize, usize),
    pub dirty: bool,
    pub untracked: usize,
}

#[derive(Debug, Clone)]
pub struct WorkingDirectory {
    pub path: String,
    pub git: Option<GitStatus>,
    pub file_count: usize,
}

impl WorkingDirectory {
    pub fn inspect(path: &str) -> Self {
        Self {
            path: path.to_string(),
            git: Some(GitStatus {
                is_repo: true,
                branch: Some("main".into()),
                ahead_behind: (0, 0),
                dirty: false,
                untracked: 0,
            }),
            file_count: 14,
        }
    }

    pub fn escape_dragged_path(path: &str) -> String {
        if path.contains(' ') {
            format!("'{}'", path.replace('\'', "'\\''"))
        } else {
            path.to_string()
        }
    }
}
