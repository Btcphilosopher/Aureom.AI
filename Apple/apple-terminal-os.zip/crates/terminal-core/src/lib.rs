use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CursorShape {
    Block,
    Beam,
    Underline,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Cursor {
    pub x: usize,
    pub y: usize,
    pub visible: bool,
    pub shape: CursorShape,
    pub blink: bool,
}

impl Default for Cursor {
    fn default() -> Self {
        Self {
            x: 0,
            y: 0,
            visible: true,
            shape: CursorShape::Block,
            blink: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Cell {
    pub ch: char,
    pub fg: String,
    pub bg: String,
    pub bold: bool,
    pub italic: bool,
    pub underline: bool,
    pub dim: bool,
    pub hyperlink: Option<String>,
}

impl Default for Cell {
    fn default() -> Self {
        Self {
            ch: ' ',
            fg: "#D4D4D4".to_string(),
            bg: "#0D0D0D".to_string(),
            bold: false,
            italic: false,
            underline: false,
            dim: false,
            hyperlink: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TerminalState {
    pub session_id: String,
    pub shell: String,
    pub cwd: String,
    pub rows: usize,
    pub columns: usize,
    pub cursor: Cursor,
    pub alternate_screen: bool,
    pub mouse_mode: bool,
    pub bracketed_paste: bool,
    pub application_cursor_mode: bool,
    pub application_keypad_mode: bool,
    pub title: String,
    pub process_state: String,
    pub exit_status: Option<i32>,
    pub scrollback_lines: usize,
}

impl TerminalState {
    pub fn new(session_id: String, shell: String, cwd: String, rows: usize, columns: usize) -> Self {
        Self {
            session_id,
            shell,
            cwd,
            rows,
            columns,
            cursor: Cursor::default(),
            alternate_screen: false,
            mouse_mode: false,
            bracketed_paste: true,
            application_cursor_mode: false,
            application_keypad_mode: false,
            title: "Apple Terminal OS".to_string(),
            process_state: "RUNNING".to_string(),
            exit_status: None,
            scrollback_lines: 10000,
        }
    }
}
