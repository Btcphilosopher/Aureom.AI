#[derive(Debug, Clone)]
pub struct HistoryEntry {
    pub command: String,
    pub timestamp: u64,
    pub exit_code: Option<i32>,
    pub cwd: String,
}

pub struct HistoryManager {
    pub entries: Vec<HistoryEntry>,
}

impl HistoryManager {
    pub fn new() -> Self {
        Self { entries: Vec::new() }
    }

    pub fn search(&self, query: &str) -> Vec<&HistoryEntry> {
        self.entries
            .iter()
            .filter(|e| e.command.contains(query))
            .collect()
    }
}
