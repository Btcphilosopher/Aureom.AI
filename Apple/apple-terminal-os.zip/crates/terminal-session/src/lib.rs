use terminal_pty::PtySession;

#[derive(Debug, Clone)]
pub enum PaneLayout {
    Single(String),
    HorizontalSplit(Box<PaneLayout>, Box<PaneLayout>),
    VerticalSplit(Box<PaneLayout>, Box<PaneLayout>),
}

pub struct TerminalSession {
    pub session_id: String,
    pub title: String,
    pub cwd: String,
    pub pty: PtySession,
}

impl TerminalSession {
    pub fn new(session_id: String, shell: String, cwd: String) -> Self {
        let pty = PtySession::new(shell, cwd.clone(), 24, 80);
        Self {
            session_id,
            title: "zsh".into(),
            cwd,
            pty,
        }
    }
}
