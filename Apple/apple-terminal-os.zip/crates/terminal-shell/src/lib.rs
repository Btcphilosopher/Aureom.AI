use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct ShellEnvironment {
    pub vars: HashMap<String, String>,
}

impl ShellEnvironment {
    pub fn default_macos() -> Self {
        let mut vars = HashMap::new();
        vars.insert("TERM".into(), "xterm-256color".into());
        vars.insert("TERM_PROGRAM".into(), "AppleTerminalOS".into());
        vars.insert("TERM_PROGRAM_VERSION".into(), "0.1.0".into());
        vars.insert("COLORTERM".into(), "truecolor".into());
        vars.insert("SHELL".into(), "/bin/zsh".into());
        vars.insert("PATH".into(), "/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin".into());
        Self { vars }
    }

    pub fn detect_shells() -> Vec<String> {
        vec!["/bin/zsh".into(), "/bin/bash".into(), "/usr/local/bin/fish".into()]
    }
}
