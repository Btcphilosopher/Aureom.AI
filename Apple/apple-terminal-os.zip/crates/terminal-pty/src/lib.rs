use terminal_core::TerminalState;

pub struct PtySession {
    pub master_fd: i32,
    pub child_pid: u32,
    pub rows: u16,
    pub columns: u16,
    pub shell: String,
    pub cwd: String,
    pub state: TerminalState,
}

impl PtySession {
    pub fn new(shell: String, cwd: String, rows: u16, columns: u16) -> Self {
        let state = TerminalState::new("sess_1".into(), shell.clone(), cwd.clone(), rows as usize, columns as usize);
        Self {
            master_fd: 0,
            child_pid: 1001,
            rows,
            columns,
            shell,
            cwd,
            state,
        }
    }

    pub fn resize(&mut self, rows: u16, columns: u16) {
        self.rows = rows;
        self.columns = columns;
        self.state.rows = rows as usize;
        self.state.columns = columns as usize;
    }

    pub fn send_signal(&mut self, signal: &str) {
        println!("Signal {} sent to child PID {}", signal, self.child_pid);
    }
}
