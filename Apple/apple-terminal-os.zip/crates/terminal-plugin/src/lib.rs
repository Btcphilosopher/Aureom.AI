pub trait TerminalPlugin {
    fn name(&self) -> &str;
    fn version(&self) -> &str;
    fn on_init(&self);
}
