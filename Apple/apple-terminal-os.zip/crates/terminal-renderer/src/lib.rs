use terminal_core::Cell;

pub struct GlyphAtlas {
    pub font_family: String,
    pub font_size: f32,
}

pub struct TerminalGrid {
    pub rows: usize,
    pub cols: usize,
    pub cells: Vec<Vec<Cell>>,
    pub dirty: bool,
}

impl TerminalGrid {
    pub fn new(rows: usize, cols: usize) -> Self {
        let cells = vec![vec![Cell::default(); cols]; rows];
        Self {
            rows,
            cols,
            cells,
            dirty: true,
        }
    }

    pub fn render_frame(&mut self) -> bool {
        if self.dirty {
            self.dirty = false;
            true
        } else {
            false
        }
    }
}
