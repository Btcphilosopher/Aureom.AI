pub struct SecurityPolicy;

impl SecurityPolicy {
    pub fn sanitize_log(input: &str) -> String {
        let sensitive_keywords = ["sudo", "password", "token", "key", "secret"];
        let mut clean = input.to_string();
        for kw in sensitive_keywords {
            if clean.to_lowercase().contains(kw) {
                // mask output
                clean = clean.replace(kw, "[PROTECTED]");
            }
        }
        clean
    }
}
