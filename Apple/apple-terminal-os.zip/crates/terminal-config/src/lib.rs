use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThemeConfig {
    pub name: String,
    pub background: String,
    pub foreground: String,
    pub cursor: String,
    pub selection: String,
    pub black: String,
    pub red: String,
    pub green: String,
    pub yellow: String,
    pub blue: String,
    pub magenta: String,
    pub cyan: String,
    pub white: String,
}

impl ThemeConfig {
    pub fn obsidian() -> Self {
        Self {
            name: "Obsidian".into(),
            background: "#0a0a0c".into(),
            foreground: "#f0f0f4".into(),
            cursor: "#38bdf8".into(),
            selection: "#1e293b".into(),
            black: "#18181b".into(),
            red: "#f87171".into(),
            green: "#4ade80".into(),
            yellow: "#facc15".into(),
            blue: "#60a5fa".into(),
            magenta: "#c084fc".into(),
            cyan: "#38bdf8".into(),
            white: "#f4f4f5".into(),
        }
    }

    pub fn graphite() -> Self {
        Self {
            name: "Graphite".into(),
            background: "#121214".into(),
            foreground: "#e4e4e7".into(),
            cursor: "#a1a1aa".into(),
            selection: "#27272a".into(),
            black: "#27272a".into(),
            red: "#ef4444".into(),
            green: "#22c55e".into(),
            yellow: "#eab308".into(),
            blue: "#3b82f6".into(),
            magenta: "#a855f7".into(),
            cyan: "#06b6d4".into(),
            white: "#f4f4f5".into(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TerminalConfig {
    pub theme: String,
    pub font_family: String,
    pub font_size: f32,
    pub shell: String,
    pub scrollback: usize,
    pub cursor_blink: bool,
    pub opacity: f32,
}

impl Default for TerminalConfig {
    fn default() -> Self {
        Self {
            theme: "Obsidian".into(),
            font_family: "SF Mono, Menio, JetBrains Mono".into(),
            font_size: 13.5,
            shell: "/bin/zsh".into(),
            scrollback: 100000,
            cursor_blink: true,
            opacity: 1.0,
        }
    }
}
