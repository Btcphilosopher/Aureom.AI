#[derive(Debug, Clone)]
pub struct ProcessInfo {
    pub pid: u32,
    pub ppid: u32,
    pub command: String,
    pub arguments: Vec<String>,
    pub cwd: String,
    pub start_time: u64,
    pub runtime_secs: u64,
    pub cpu_percentage: f32,
    pub memory_mb: f32,
    pub state: String,
}

pub struct ProcessManager {
    pub processes: Vec<ProcessInfo>,
}

impl ProcessManager {
    pub fn new() -> Self {
        Self { processes: Vec::new() }
    }

    pub fn spawn(&mut self, cmd: &str, args: &[&str], cwd: &str) -> ProcessInfo {
        let proc = ProcessInfo {
            pid: 2048,
            ppid: 1,
            command: cmd.to_string(),
            arguments: args.iter().map(|s| s.to_string()).collect(),
            cwd: cwd.to_string(),
            start_time: 1000000,
            runtime_secs: 12,
            cpu_percentage: 0.8,
            memory_mb: 24.5,
            state: "RUNNING".to_string(),
        };
        self.processes.push(proc.clone());
        proc
    }
}
