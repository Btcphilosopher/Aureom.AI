#[derive(Debug, Clone)]
pub struct SearchMatch {
    pub line_idx: usize,
    pub start_col: usize,
    pub end_col: usize,
    pub text: String,
}

pub struct ScrollbackSearch {
    pub query: String,
    pub case_sensitive: bool,
    pub regex: bool,
}

impl ScrollbackSearch {
    pub fn new(query: String) -> Self {
        Self {
            query,
            case_sensitive: false,
            regex: false,
        }
    }

    pub fn find_matches(&self, lines: &[String]) -> Vec<SearchMatch> {
        let mut matches = Vec::new();
        let q = if self.case_sensitive {
            self.query.clone()
        } else {
            self.query.to_lowercase()
        };

        for (idx, line) in lines.iter().enumerate() {
            let line_cmp = if self.case_sensitive {
                line.clone()
            } else {
                line.to_lowercase()
            };

            if let Some(pos) = line_cmp.find(&q) {
                matches.push(SearchMatch {
                    line_idx: idx,
                    start_col: pos,
                    end_col: pos + q.len(),
                    text: line[pos..pos + q.len()].to_string(),
                });
            }
        }
        matches
    }
}
