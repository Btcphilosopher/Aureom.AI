pub enum AutomationTrigger {
    CommandCompleted { exit_code: i32, command: String },
    SessionOpened { cwd: String },
}

pub struct AutomationEngine;

impl AutomationEngine {
    pub fn handle_trigger(trigger: AutomationTrigger) {
        match trigger {
            AutomationTrigger::CommandCompleted { exit_code, command } => {
                if exit_code != 0 {
                    println!("[Automation] Command '{}' exited with code {}", command, exit_code);
                }
            }
            AutomationTrigger::SessionOpened { cwd } => {
                println!("[Automation] Session started at {}", cwd);
            }
        }
    }
}
