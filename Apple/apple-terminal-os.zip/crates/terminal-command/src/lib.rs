#[derive(Debug, Clone)]
pub struct CommandItem {
    pub id: String,
    pub title: String,
    pub description: String,
    pub shortcut: Option<String>,
    pub category: String,
}

pub struct CommandRegistry {
    pub commands: Vec<CommandItem>,
}

impl CommandRegistry {
    pub fn default_mac_commands() -> Self {
        let commands = vec![
            CommandItem {
                id: "new_tab".into(),
                title: "New Tab".into(),
                description: "Open a new terminal tab".into(),
                shortcut: Some("⌘T".into()),
                category: "Terminal".into(),
            },
            CommandItem {
                id: "split_right".into(),
                title: "Split Pane Right".into(),
                description: "Split active pane horizontally".into(),
                shortcut: Some("⌘D".into()),
                category: "Pane".into(),
            },
            CommandItem {
                id: "split_down".into(),
                title: "Split Pane Down".into(),
                description: "Split active pane vertically".into(),
                shortcut: Some("⌘⇧D".into()),
                category: "Pane".into(),
            },
            CommandItem {
                id: "open_search".into(),
                title: "Search Scrollback".into(),
                description: "Find text in terminal buffer".into(),
                shortcut: Some("⌘F".into()),
                category: "Search".into(),
            },
            CommandItem {
                id: "toggle_inspector".into(),
                title: "Terminal Observatory Inspector".into(),
                description: "Inspect PTY state, FPS, memory, escape codes".into(),
                shortcut: Some("⌘I".into()),
                category: "Developer".into(),
            },
        ];
        Self { commands }
    }
}
