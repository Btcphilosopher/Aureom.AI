import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {spawn} from 'node:child_process';
import {readdir} from 'node:fs/promises';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Helper to run python grabedit CLI
function runGrabedit(args: string[]): Promise<{stdout: string; stderr: string; code: number}> {
  return new Promise((resolve) => {
    const proc = spawn('python3', ['-m', 'grabedit.cli.main', ...args], {
      cwd: process.cwd(),
      env: {...process.env, PYTHONUNBUFFERED: '1'},
    });
    let stdout = '';
    let stderr = '';
    proc.stdout.on('data', (d) => (stdout += d.toString()));
    proc.stderr.on('data', (d) => (stderr += d.toString()));
    proc.on('close', (code) => {
      resolve({stdout, stderr, code: code ?? 0});
    });
  });
}

// API: Terminal Command Runner
app.post('/api/terminal', async (req, res) => {
  const {command} = req.body;
  if (!command || typeof command !== 'string') {
    res.status(400).json({error: 'Command string required'});
    return;
  }

  // Parse command line safely into arguments
  const trimmed = command.trim();
  const rawParts = trimmed.startsWith('grab ') ? trimmed.slice(5) : trimmed;
  
  // Split arguments honoring quotes
  const matches = rawParts.match(/(?:[^\s"']+|"[^"]*"|'[^']*')+/g) || [];
  const args = matches.map((m) => m.replace(/^["']|["']$/g, ''));

  const result = await runGrabedit(args);
  res.json({
    command: trimmed,
    output: (result.stdout + (result.stderr ? '\n' + result.stderr : '')).trimEnd(),
    exitCode: result.code,
  });
});

// API: Grab Target and return structured object
app.post('/api/grab', async (req, res) => {
  const {target} = req.body;
  if (!target) {
    res.status(400).json({error: 'target required'});
    return;
  }
  const result = await runGrabedit(['--json', target]);
  try {
    const data = JSON.parse(result.stdout);
    res.json(data);
  } catch {
    res.json({
      id: 'grab_out',
      target,
      output: result.stdout || result.stderr,
      exitCode: result.code,
    });
  }
});

// API: Inspect
app.post('/api/inspect', async (req, res) => {
  const {target} = req.body;
  const result = await runGrabedit(['inspect', '--json', target]);
  try {
    const data = JSON.parse(result.stdout);
    res.json(data);
  } catch {
    res.json({output: result.stdout || result.stderr});
  }
});

// API: Validate
app.post('/api/validate', async (req, res) => {
  const {target} = req.body;
  const result = await runGrabedit(['validate', '--json', target]);
  try {
    const data = JSON.parse(result.stdout);
    res.json(data);
  } catch {
    res.json({output: result.stdout || result.stderr});
  }
});

// API: Diff
app.post('/api/diff', async (req, res) => {
  const {target} = req.body;
  const result = await runGrabedit(['diff', target]);
  res.json({diff: result.stdout});
});

// API: Snapshots list
app.get('/api/snapshots', async (req, res) => {
  const result = await runGrabedit(['restore']);
  res.json({output: result.stdout});
});

// API: History / Audit
app.get('/api/history', async (req, res) => {
  const result = await runGrabedit(['history', '--json']);
  try {
    const data = JSON.parse(result.stdout);
    res.json(data);
  } catch {
    res.json([]);
  }
});

// API: Search
app.post('/api/search', async (req, res) => {
  const {query, dir = '.', glob = '*'} = req.body;
  const result = await runGrabedit(['search', '--json', '--dir', dir, '--glob', glob, query]);
  try {
    const data = JSON.parse(result.stdout);
    res.json(data);
  } catch {
    res.json([]);
  }
});

// API: Demo files
app.get('/api/demo-files', async (req, res) => {
  try {
    const files = await readdir(join(process.cwd(), 'workspace_demo'));
    res.json(files.map((f) => `workspace_demo/${f}`));
  } catch {
    res.json([]);
  }
});

// API: Restore snapshot
app.post('/api/restore', async (req, res) => {
  const {snapshotId} = req.body;
  const result = await runGrabedit(['restore', '-y', snapshotId]);
  res.json({output: result.stdout || result.stderr, code: result.code});
});

// API: Run script
app.post('/api/run-script', async (req, res) => {
  const {scriptPath} = req.body;
  const result = await runGrabedit(['run', scriptPath]);
  res.json({output: result.stdout + (result.stderr ? '\n' + result.stderr : ''), code: result.code});
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
