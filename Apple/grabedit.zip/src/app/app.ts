import {CommonModule} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {ChangeDetectionStrategy, Component, OnInit, inject, signal} from '@angular/core';
import {FormControl, FormGroup, ReactiveFormsModule} from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';

export interface TerminalEntry {
  command: string;
  output: string;
  exitCode: number;
  timestamp: string;
}

export interface GrabbedTarget {
  id?: string;
  source?: string;
  type?: string;
  path?: string;
  size?: number;
  hash?: string;
  content?: string;
  metadata?: Record<string, unknown>;
  snapshot_id?: string;
}

export interface AuditRecord {
  timestamp: string;
  user_action: string;
  target: string;
  operation: string;
  original_hash: string;
  new_hash: string;
  status: string;
  details: Record<string, unknown>;
}

export interface ValidationStatus {
  valid: boolean;
  format: string;
  errors: string[];
  warnings: string[];
}

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private http = inject(HttpClient);

  // Current active view tab
  activeTab = signal<'terminal' | 'workspace' | 'diff' | 'snapshots' | 'audit'>('terminal');

  // Terminal state
  terminalHistory = signal<TerminalEntry[]>([]);
  commandInput = new FormControl('');
  isExecuting = signal<boolean>(false);
  commandHistoryList = signal<string[]>([]);
  historyIndex = signal<number>(-1);

  // Active Target State
  currentTarget = signal<GrabbedTarget | null>(null);
  currentDiff = signal<string>('');
  validationStatus = signal<ValidationStatus | null>(null);
  
  // Edit form controls
  replaceForm = new FormGroup({
    oldText: new FormControl(''),
    newText: new FormControl(''),
  });

  jsonSetForm = new FormGroup({
    keyPath: new FormControl('database.host'),
    value: new FormControl('127.0.0.1'),
  });

  // Snapshots & Audit
  snapshotsList = signal<string>('');
  auditRecords = signal<AuditRecord[]>([]);
  demoFiles = signal<string[]>([]);

  // Confirmation modal state
  pendingPlan = signal<{planId: string; summary: string; diff: string; warnings: string[]} | null>(null);
  statusMessage = signal<string>('');

  ngOnInit() {
    this.fetchDemoFiles();
    this.fetchAuditLogs();
    // Pre-populate with initial welcoming terminal greeting
    this.terminalHistory.set([
      {
        command: 'grab --version',
        output: 'GrabEdit v1.0.0 — Industrial-grade Grab/Edit Command System for macOS Terminal\nDeterministic command grammar • Structured Execution Plans • Immutable Snapshots • SIP Safety',
        exitCode: 0,
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);

    // Initial grab demo
    this.executeCommand('grab workspace_demo/config.json');
  }

  fetchDemoFiles() {
    this.http.get<string[]>('/api/demo-files').subscribe({
      next: (files) => this.demoFiles.set(files),
      error: (err) => {
        console.error('Failed to fetch demo files', err);
        this.demoFiles.set(['workspace_demo/config.json', 'workspace_demo/server.py', 'workspace_demo/data.csv', 'workspace_demo/app.log']);
      },
    });
  }

  fetchAuditLogs() {
    this.http.get<AuditRecord[]>('/api/history').subscribe({
      next: (logs) => this.auditRecords.set(logs),
      error: (err) => console.error('Failed to fetch audit logs', err),
    });
  }

  fetchSnapshots() {
    this.http.get<{output: string}>('/api/snapshots').subscribe({
      next: (res) => this.snapshotsList.set(res.output),
      error: (err) => console.error('Failed to fetch snapshots', err),
    });
  }

  executeCommand(cmdToRun?: string) {
    const rawCmd = (cmdToRun || this.commandInput.value || '').trim();
    if (!rawCmd) return;

    this.isExecuting.set(true);
    this.commandInput.setValue('');

    // Update command history for up/down arrow navigation
    this.commandHistoryList.update((list) => [rawCmd, ...list.filter((c) => c !== rawCmd)]);
    this.historyIndex.set(-1);

    this.http.post<{command: string; output: string; exitCode: number}>('/api/terminal', {command: rawCmd}).subscribe({
      next: (res) => {
        this.isExecuting.set(false);
        this.terminalHistory.update((hist) => [
          ...hist,
          {
            command: res.command,
            output: res.output,
            exitCode: res.exitCode,
            timestamp: new Date().toLocaleTimeString(),
          },
        ]);

        // Auto-refresh grabbed target or logs if relevant
        if (rawCmd.startsWith('grab ') && !rawCmd.includes('history') && !rawCmd.includes('search') && !rawCmd.includes('restore') && !rawCmd.includes('do ')) {
          const parts = rawCmd.split(' ');
          const target = parts[1];
          if (target && !target.startsWith('-')) {
            this.inspectTarget(target);
          }
        }

        this.fetchAuditLogs();
        this.fetchSnapshots();
      },
      error: (err) => {
        this.isExecuting.set(false);
        this.terminalHistory.update((hist) => [
          ...hist,
          {
            command: rawCmd,
            output: `Terminal Error: ${err.message || 'Execution failed'}`,
            exitCode: 1,
            timestamp: new Date().toLocaleTimeString(),
          },
        ]);
      },
    });
  }

  inspectTarget(targetPath: string) {
    this.http.post<GrabbedTarget>('/api/grab', {target: targetPath}).subscribe({
      next: (obj) => {
        if (obj && obj.type) {
          this.currentTarget.set(obj);
          this.validateTarget(targetPath);
          this.fetchDiff(targetPath);
        }
      },
    });
  }

  validateTarget(targetPath: string) {
    this.http.post<ValidationStatus>('/api/validate', {target: targetPath}).subscribe({
      next: (res) => {
        this.validationStatus.set(res);
      },
    });
  }

  fetchDiff(targetPath: string) {
    this.http.post<{diff: string}>('/api/diff', {target: targetPath}).subscribe({
      next: (res) => {
        this.currentDiff.set(res.diff);
      },
    });
  }

  refreshCurrentDiff() {
    const p = this.currentTarget()?.path;
    if (p) {
      this.fetchDiff(p);
    }
  }

  applyTextReplace() {
    const oldT = this.replaceForm.get('oldText')?.value;
    const target = this.currentTarget()?.path;
    if (!target || !oldT) return;

    this.executeCommand(`grab edit ${target}`);
  }

  runPipelineTransform(action: string) {
    const target = this.currentTarget()?.path;
    if (!target) return;
    this.statusMessage.set(`Executing transform: ${action}`);
    this.executeCommand(`grab run workspace_demo/update_config.grab`);
  }

  restoreSnapshotById(snapshotId: string) {
    if (!snapshotId) return;
    this.http.post<{output: string; code: number}>('/api/restore', {snapshotId}).subscribe({
      next: (res) => {
        this.statusMessage.set(res.output);
        this.fetchSnapshots();
        this.fetchAuditLogs();
        if (this.currentTarget()?.path) {
          this.inspectTarget(this.currentTarget()!.path!);
        }
      },
    });
  }

  clearTerminal() {
    this.terminalHistory.set([]);
  }

  formatBytes(bytes?: number): string {
    if (!bytes && bytes !== 0) return '0 B';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  }
}
