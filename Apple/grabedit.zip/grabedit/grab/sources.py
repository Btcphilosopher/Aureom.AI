"""
Source Adapters for GrabEdit.
Fetches, streams, and structures data from targets without unconstrained memory usage.
"""

from __future__ import annotations

import datetime
import json
import os
import platform
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Generator, List, Optional, Tuple

from grabedit.grab.detectors import GrabTargetType
from grabedit.storage.atomic import calculate_hash


class SourceAdapter:
    """Base class for all GrabEdit target sources."""

    @staticmethod
    def read_file_safely(path: Path, max_bytes: int = 10 * 1024 * 1024) -> Tuple[str, bool]:
        """Reads file safely with size check and UTF-8 handling."""
        size = path.stat().st_size
        is_truncated = size > max_bytes
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read(max_bytes)
        return content, is_truncated


class DirectorySource:
    """Provides memory-efficient directory tree, size, and manifest generation."""

    @staticmethod
    def get_tree(
        root_path: Path,
        max_depth: int = 3,
        max_entries: int = 200,
    ) -> Tuple[str, Dict[str, Any]]:
        """Generates formatted ASCII directory tree and metadata stats."""
        root = root_path.resolve()
        lines: List[str] = [f"{root.name}/"]
        total_files = 0
        total_dirs = 0
        total_size = 0
        entry_count = 0

        def walk(curr: Path, prefix: str, depth: int):
            nonlocal total_files, total_dirs, total_size, entry_count
            if depth > max_depth or entry_count >= max_entries:
                return

            try:
                entries = sorted(list(curr.iterdir()), key=lambda e: (not e.is_dir(), e.name.lower()))
            except PermissionError:
                lines.append(f"{prefix}└── [Permission Denied]")
                return

            count = len(entries)
            for i, entry in enumerate(entries):
                if entry.name.startswith(".") and entry.name != ".grab":
                    continue
                entry_count += 1
                if entry_count > max_entries:
                    lines.append(f"{prefix}... (truncated after {max_entries} items)")
                    return

                is_last = (i == count - 1)
                connector = "└── " if is_last else "├── "
                sub_prefix = "    " if is_last else "│   "

                if entry.is_dir():
                    total_dirs += 1
                    lines.append(f"{prefix}{connector}{entry.name}/")
                    walk(entry, prefix + sub_prefix, depth + 1)
                else:
                    total_files += 1
                    try:
                        sz = entry.stat().st_size
                        total_size += sz
                        lines.append(f"{prefix}{connector}{entry.name}")
                    except Exception:
                        lines.append(f"{prefix}{connector}{entry.name}")

        walk(root, "", 1)
        tree_text = "\n".join(lines)
        meta = {
            "total_files": total_files,
            "total_dirs": total_dirs,
            "total_size": total_size,
            "depth_limit": max_depth,
            "truncated": entry_count > max_entries,
        }
        return tree_text, meta


class CommandSource:
    """Safely executes explicitly supplied commands and captures stdout/stderr."""

    # Policy list of banned non-deterministic or malicious commands
    FORBIDDEN_PATTERNS = ["rm -rf /", "mkfs", "dd if=", ":(){ :|:& };:"]

    @staticmethod
    def capture(command: str, timeout_sec: float = 15.0) -> Dict[str, Any]:
        for pattern in CommandSource.FORBIDDEN_PATTERNS:
            if pattern in command:
                return {
                    "stdout": "",
                    "stderr": f"SECURITY ERROR: Command matches forbidden policy pattern: '{pattern}'",
                    "exit_code": -1,
                    "duration_ms": 0,
                    "command": command,
                }

        start = time.perf_counter()
        try:
            # We use shlex or run strictly in controlled subshell
            proc = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout_sec,
            )
            duration_ms = round((time.perf_counter() - start) * 1000, 2)
            return {
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "exit_code": proc.returncode,
                "duration_ms": duration_ms,
                "command": command,
            }
        except subprocess.TimeoutExpired:
            duration_ms = round((time.perf_counter() - start) * 1000, 2)
            return {
                "stdout": "",
                "stderr": f"Execution timed out after {timeout_sec}s",
                "exit_code": 124,
                "duration_ms": duration_ms,
                "command": command,
            }
        except Exception as e:
            duration_ms = round((time.perf_counter() - start) * 1000, 2)
            return {
                "stdout": "",
                "stderr": str(e),
                "exit_code": 1,
                "duration_ms": duration_ms,
                "command": command,
            }


class ProcessSource:
    """Inspects processes via macOS/Linux standard APIs."""

    @staticmethod
    def inspect(pid_str: str) -> Dict[str, Any]:
        try:
            pid = int(pid_str)
        except ValueError:
            return {"error": f"Invalid PID: '{pid_str}'"}

        # Query ps command for cross-platform macOS/Linux compatibility
        cmd = f"ps -p {pid} -o pid,ppid,%cpu,%mem,stat,time,command"
        try:
            out = subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL)
            lines = [l.strip() for l in out.strip().splitlines() if l.strip()]
            if len(lines) >= 2:
                header = lines[0].split()
                data_line = lines[1]
                parts = data_line.split(maxsplit=len(header) - 1)
                info: Dict[str, Any] = {"pid": pid, "status": "Running"}
                for h, val in zip(header, parts):
                    info[h.lower()] = val
                info["command"] = parts[-1] if len(parts) >= len(header) else "N/A"
                info["name"] = Path(info["command"].split()[0]).name if "command" in info else str(pid)
                return info
            else:
                return {"pid": pid, "status": "Not Found / Terminated", "error": f"PID {pid} does not exist"}
        except subprocess.CalledProcessError:
            return {"pid": pid, "status": "Not Found", "error": f"PID {pid} is not active"}


class LogSource:
    """Parses, filters, and extracts severities from log files."""

    SEVERITY_PATTERN = re.compile(r"\b(FATAL|CRITICAL|ERROR|WARNING|WARN|INFO|DEBUG|TRACE)\b", re.IGNORECASE)
    TIMESTAMP_PATTERN = re.compile(
        r"(\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?|\b[A-Z][a-z]{2}\s+\d+\s+\d{2}:\d{2}:\d{2}\b)"
    )

    @staticmethod
    def parse_log(
        path: Path | str,
        max_lines: int = 1000,
        filter_level: Optional[str] = None,
    ) -> Dict[str, Any]:
        target = Path(path).resolve()
        if not target.is_file():
            return {"error": f"File not found: {path}"}

        stats = {"ERROR": 0, "WARNING": 0, "INFO": 0, "DEBUG": 0, "OTHER": 0}
        parsed_entries = []

        with open(target, "r", encoding="utf-8", errors="replace") as f:
            for idx, line in enumerate(f):
                line_clean = line.rstrip("\r\n")
                # Severity
                sev_match = LogSource.SEVERITY_PATTERN.search(line_clean)
                sev = sev_match.group(1).upper() if sev_match else "OTHER"
                if sev in ("WARN", "WARNING"):
                    stats["WARNING"] += 1
                elif sev in ("ERROR", "CRITICAL", "FATAL"):
                    stats["ERROR"] += 1
                elif sev == "INFO":
                    stats["INFO"] += 1
                elif sev in ("DEBUG", "TRACE"):
                    stats["DEBUG"] += 1
                else:
                    stats["OTHER"] += 1

                # Filter if requested
                if filter_level and filter_level.upper() not in (sev, "ALL"):
                    continue

                if len(parsed_entries) < max_lines:
                    # Timestamp
                    ts_match = LogSource.TIMESTAMP_PATTERN.search(line_clean)
                    ts = ts_match.group(1) if ts_match else ""
                    parsed_entries.append({
                        "line": idx + 1,
                        "timestamp": ts,
                        "severity": sev,
                        "message": line_clean,
                    })

        return {
            "path": str(target),
            "stats": stats,
            "total_lines": sum(stats.values()),
            "entries": parsed_entries,
        }


class EnvironmentSource:
    """Collects macOS / system environment diagnostics."""

    @staticmethod
    def inspect() -> Dict[str, Any]:
        return {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python_version": sys.version.split()[0],
            "terminal": os.environ.get("TERM", "unknown"),
            "shell": os.environ.get("SHELL", "unknown"),
            "user": os.environ.get("USER", os.environ.get("USERNAME", "unknown")),
            "cwd": str(Path.cwd()),
            "macos_darwin": platform.system() == "Darwin",
            "timestamp": datetime.datetime.now().isoformat(),
        }


class ApplicationBundleSource:
    """Inspects macOS .app Application Bundles."""

    @staticmethod
    def inspect(bundle_path: Path | str) -> Dict[str, Any]:
        path = Path(bundle_path).resolve()
        info_plist = path / "Contents" / "Info.plist"
        macos_dir = path / "Contents" / "MacOS"

        executables = []
        if macos_dir.is_dir():
            executables = [e.name for e in macos_dir.iterdir() if os.access(e, os.X_OK)]

        plist_data = {}
        if info_plist.is_file():
            try:
                # Use plistlib if available
                import plistlib
                with open(info_plist, "rb") as fp:
                    raw_dict = plistlib.load(fp)
                    for key in ["CFBundleIdentifier", "CFBundleShortVersionString", "CFBundleVersion", "CFBundleExecutable", "LSMinimumSystemVersion"]:
                        if key in raw_dict:
                            plist_data[key] = str(raw_dict[key])
            except Exception as e:
                plist_data["error"] = str(e)

        return {
            "bundle_name": path.name,
            "bundle_path": str(path),
            "info_plist_present": info_plist.exists(),
            "bundle_id": plist_data.get("CFBundleIdentifier", "unknown"),
            "version": plist_data.get("CFBundleShortVersionString", "unknown"),
            "executables": executables,
            "details": plist_data,
        }
