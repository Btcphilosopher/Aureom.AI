"""
Target Type Detector for GrabEdit.
Deterministically classifies targets into one of the core GrabTargetTypes.
"""

from __future__ import annotations

import enum
import json
import os
from pathlib import Path
from typing import Optional, Tuple


class GrabTargetType(str, enum.Enum):
    FILE = "FILE"
    DIRECTORY = "DIRECTORY"
    TEXT = "TEXT"
    JSON = "JSON"
    CSV = "CSV"
    XML = "XML"
    YAML = "YAML"
    LOG = "LOG"
    PROCESS = "PROCESS"
    COMMAND_OUTPUT = "COMMAND OUTPUT"
    ENVIRONMENT_INFORMATION = "ENVIRONMENT INFORMATION"
    APPLICATION_BUNDLE = "APPLICATION BUNDLE"


class TargetDetector:
    """Detects target category based on URI, path, content, and metadata."""

    @staticmethod
    def detect(raw_target: str) -> Tuple[GrabTargetType, str]:
        """
        Returns (GrabTargetType, normalized_target_string)
        """
        s = raw_target.strip()

        # 1. Command output
        if s.startswith("--output ") or s.startswith("cmd:"):
            cmd = s[9:].strip() if s.startswith("--output ") else s[4:].strip()
            # Strip outer quotes if provided
            if (cmd.startswith('"') and cmd.endswith('"')) or (cmd.startswith("'") and cmd.endswith("'")):
                cmd = cmd[1:-1]
            return GrabTargetType.COMMAND_OUTPUT, cmd

        # 2. Process
        if s.startswith("process ") or s.startswith("pid:"):
            pid_str = s.split(maxsplit=1)[1].strip() if s.startswith("process ") else s[4:].strip()
            return GrabTargetType.PROCESS, pid_str
        if s.isdigit() and int(s) > 0:
            return GrabTargetType.PROCESS, s

        # 3. Environment Information
        if s.lower() in ("env", "environment", "system", "sysinfo"):
            return GrabTargetType.ENVIRONMENT_INFORMATION, s

        # 4. Explicit Log command: grab log /path/to/log
        if s.startswith("log "):
            log_path = s[4:].strip()
            return GrabTargetType.LOG, log_path

        # 5. Filesystem path inspection
        path = Path(s).expanduser()

        # macOS Application Bundle (.app is a directory)
        if path.suffix == ".app" and path.is_dir():
            return GrabTargetType.APPLICATION_BUNDLE, str(path)

        if path.is_dir():
            return GrabTargetType.DIRECTORY, str(path)

        # File classification
        if path.suffix.lower() == ".log":
            return GrabTargetType.LOG, str(path)

        ext = path.suffix.lower()
        if ext == ".json":
            return GrabTargetType.JSON, str(path)
        if ext == ".csv":
            return GrabTargetType.CSV, str(path)
        if ext in (".xml", ".plist", ".svg"):
            return GrabTargetType.XML, str(path)
        if ext in (".yaml", ".yml"):
            return GrabTargetType.YAML, str(path)

        # Text vs Binary
        text_extensions = {
            ".txt", ".md", ".py", ".ts", ".js", ".html", ".css", ".sh",
            ".zsh", ".bash", ".conf", ".ini", ".toml", ".env", ".sql",
            ".rs", ".go", ".c", ".cpp", ".h", ".swift", ".kt", ".grab"
        }
        if ext in text_extensions:
            return GrabTargetType.TEXT, str(path)

        # If file exists, check content sniffing
        if path.is_file():
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    chunk = f.read(1024).strip()
                if chunk.startswith("{") or chunk.startswith("["):
                    try:
                        json.loads(chunk)
                        return GrabTargetType.JSON, str(path)
                    except Exception:
                        pass
                return GrabTargetType.TEXT, str(path)
            except Exception:
                return GrabTargetType.FILE, str(path)

        # Default fallback
        return GrabTargetType.FILE, str(path)
