"""
GrabEngine and GrabObject structured target representations.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

from grabedit.grab.detectors import GrabTargetType, TargetDetector
from grabedit.grab.sources import (
    ApplicationBundleSource,
    CommandSource,
    DirectorySource,
    EnvironmentSource,
    LogSource,
    ProcessSource,
    SourceAdapter,
)
from grabedit.snapshots.store import SnapshotEngine, SnapshotMetadata
from grabedit.storage.atomic import calculate_hash


@dataclass
class GrabObject:
    """Structured representation of a grabbed target."""

    id: str
    source: str
    type: GrabTargetType
    path: Optional[str] = None
    size: Optional[int] = None
    created: Optional[str] = None
    modified: Optional[str] = None
    permissions: Optional[str] = None
    content: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    hash: Optional[str] = None
    snapshot_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["type"] = self.type.value
        return d


class GrabEngine:
    """Core GrabEngine responsible for capturing targets into GrabObjects."""

    def __init__(self, snapshot_engine: Optional[SnapshotEngine] = None):
        self.snapshots = snapshot_engine or SnapshotEngine()

    def capture(self, target: str, make_snapshot: bool = True) -> GrabObject:
        """Captures any target into a strongly-typed GrabObject."""
        target_type, normalized = TargetDetector.detect(target)
        obj_id = f"grab_{uuid.uuid4().hex[:8]}"
        now = datetime.datetime.now().isoformat()

        # Handle different targets
        if target_type == GrabTargetType.COMMAND_OUTPUT:
            cmd_res = CommandSource.capture(normalized)
            content = cmd_res["stdout"] if cmd_res["exit_code"] == 0 else f"STDOUT:\n{cmd_res['stdout']}\nSTDERR:\n{cmd_res['stderr']}"
            h = hashlib.sha256(content.encode("utf-8")).hexdigest()
            return GrabObject(
                id=obj_id,
                source=target,
                type=target_type,
                path=None,
                size=len(content.encode("utf-8")),
                created=now,
                modified=now,
                permissions=None,
                content=content,
                metadata=cmd_res,
                hash=h,
            )

        if target_type == GrabTargetType.PROCESS:
            proc_info = ProcessSource.inspect(normalized)
            content = json.dumps(proc_info, indent=2)
            h = hashlib.sha256(content.encode("utf-8")).hexdigest()
            return GrabObject(
                id=obj_id,
                source=target,
                type=target_type,
                path=f"/proc/{normalized}" if Path(f"/proc/{normalized}").exists() else None,
                size=len(content.encode("utf-8")),
                created=now,
                modified=now,
                permissions=None,
                content=content,
                metadata=proc_info,
                hash=h,
            )

        if target_type == GrabTargetType.ENVIRONMENT_INFORMATION:
            env_info = EnvironmentSource.inspect()
            content = json.dumps(env_info, indent=2)
            h = hashlib.sha256(content.encode("utf-8")).hexdigest()
            return GrabObject(
                id=obj_id,
                source=target,
                type=target_type,
                path=None,
                size=len(content.encode("utf-8")),
                created=now,
                modified=now,
                permissions=None,
                content=content,
                metadata=env_info,
                hash=h,
            )

        if target_type == GrabTargetType.APPLICATION_BUNDLE:
            bundle_info = ApplicationBundleSource.inspect(normalized)
            content = json.dumps(bundle_info, indent=2)
            h = hashlib.sha256(content.encode("utf-8")).hexdigest()
            return GrabObject(
                id=obj_id,
                source=target,
                type=target_type,
                path=normalized,
                size=None,
                created=now,
                modified=now,
                permissions=oct(Path(normalized).stat().st_mode)[-3:] if Path(normalized).exists() else None,
                content=content,
                metadata=bundle_info,
                hash=h,
            )

        if target_type == GrabTargetType.DIRECTORY:
            path_obj = Path(normalized).resolve()
            tree_text, dir_meta = DirectorySource.get_tree(path_obj)
            h = hashlib.sha256(tree_text.encode("utf-8")).hexdigest()
            snap_meta = None
            if make_snapshot and path_obj.exists():
                snap_meta = self.snapshots.create_snapshot(path_obj, content=tree_text, target_type="DIRECTORY")

            return GrabObject(
                id=obj_id,
                source=target,
                type=target_type,
                path=str(path_obj),
                size=dir_meta.get("total_size"),
                created=datetime.datetime.fromtimestamp(path_obj.stat().st_ctime).isoformat() if path_obj.exists() else now,
                modified=datetime.datetime.fromtimestamp(path_obj.stat().st_mtime).isoformat() if path_obj.exists() else now,
                permissions=oct(path_obj.stat().st_mode)[-3:] if path_obj.exists() else None,
                content=tree_text,
                metadata=dir_meta,
                hash=h,
                snapshot_id=snap_meta.snapshot_id if snap_meta else None,
            )

        if target_type == GrabTargetType.LOG and not Path(normalized).exists():
            # If path doesn't exist directly, treat as normal file capture attempt
            pass

        # Filesystem File / Log / JSON / CSV / Text
        path_obj = Path(normalized).resolve()
        if not path_obj.exists():
            # Brand new file or missing path
            return GrabObject(
                id=obj_id,
                source=target,
                type=target_type,
                path=str(path_obj),
                size=0,
                created=now,
                modified=now,
                permissions="644",
                content="",
                metadata={"status": "New file (does not exist yet)"},
                hash=hashlib.sha256(b"").hexdigest(),
            )

        # Existing file
        stat = path_obj.stat()
        file_size = stat.st_size
        perms = oct(stat.st_mode)[-3:]
        ctime = datetime.datetime.fromtimestamp(stat.st_ctime).isoformat()
        mtime = datetime.datetime.fromtimestamp(stat.st_mtime).isoformat()
        h = calculate_hash(path_obj)

        content, truncated = SourceAdapter.read_file_safely(path_obj)
        meta: Dict[str, Any] = {
            "truncated": truncated,
            "readable": os.access(path_obj, os.R_OK),
            "writable": os.access(path_obj, os.W_OK),
        }

        # Extra metadata for specialized file types
        if target_type == GrabTargetType.LOG:
            log_data = LogSource.parse_log(path_obj)
            meta["log_stats"] = log_data.get("stats", {})
            meta["total_log_lines"] = log_data.get("total_lines", 0)

        snap_meta = None
        if make_snapshot:
            snap_meta = self.snapshots.create_snapshot(path_obj, content=content, target_type=target_type.value)

        return GrabObject(
            id=obj_id,
            source=target,
            type=target_type,
            path=str(path_obj),
            size=file_size,
            created=ctime,
            modified=mtime,
            permissions=perms,
            content=content,
            metadata=meta,
            hash=h,
            snapshot_id=snap_meta.snapshot_id if snap_meta else None,
        )
