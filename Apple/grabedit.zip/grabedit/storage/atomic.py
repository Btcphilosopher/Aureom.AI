"""
Atomic filesystem storage operations.
Ensures safe writes: ORIGINAL -> TEMPORARY FILE -> VALIDATE -> HASH -> ATOMIC REPLACE.
Preserves POSIX permissions and creates safety backups.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import tempfile
from pathlib import Path
from typing import Optional, Tuple


def calculate_hash(path: Path | str, algorithm: str = "sha256") -> str:
    """Calculate hash of file with streaming chunks for large files."""
    path = Path(path)
    if not path.is_file():
        return ""

    hasher = hashlib.sha256() if algorithm == "sha256" else hashlib.sha512()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest()


def calculate_content_hash(content: str | bytes, algorithm: str = "sha256") -> str:
    """Calculate hash from string or bytes in memory."""
    data = content.encode("utf-8") if isinstance(content, str) else content
    hasher = hashlib.sha256() if algorithm == "sha256" else hashlib.sha512()
    hasher.update(data)
    return hasher.hexdigest()


class AtomicStorage:
    """Handles atomic writes and backup management."""

    @staticmethod
    def atomic_write(
        target_path: Path | str,
        content: str | bytes,
        make_backup: bool = True,
        backup_suffix: str = ".grabedit.bak",
    ) -> Tuple[bool, str, str]:
        """
        Atomically writes content to target_path.
        Returns: (success, new_sha256, message)
        """
        target = Path(target_path).resolve()
        parent = target.parent
        parent.mkdir(parents=True, exist_ok=True)

        original_mode = None
        if target.exists():
            original_mode = target.stat().st_mode

        # 1. Create temporary file in the same directory to guarantee same filesystem (for atomic os.replace)
        temp_file = None
        try:
            with tempfile.NamedTemporaryFile(
                dir=parent,
                prefix=".grabedit_tmp_",
                delete=False,
                mode="wb" if isinstance(content, bytes) else "w",
                encoding=None if isinstance(content, bytes) else "utf-8",
            ) as f:
                temp_file = Path(f.name)
                f.write(content)
                f.flush()
                os.fsync(f.fileno())

            # 2. Preserve permissions
            if original_mode is not None:
                try:
                    os.chmod(temp_file, original_mode)
                except Exception:
                    pass

            # 3. Create backup if requested and original exists
            if make_backup and target.exists():
                backup_path = target.with_suffix(target.suffix + backup_suffix)
                shutil.copy2(target, backup_path)

            # 4. Atomic replace
            os.replace(temp_file, target)
            new_hash = calculate_hash(target)
            return True, new_hash, f"Atomically saved '{target.name}' (SHA256: {new_hash[:12]}...)"
        except Exception as e:
            if temp_file and temp_file.exists():
                try:
                    temp_file.unlink()
                except Exception:
                    pass
            return False, "", f"Atomic write failed: {e}"
