"""
Snapshot System for GrabEdit.
Maintains immutable snapshots in .grabedit/snapshots/YYYY-MM-DD/<hash>/
Allows 3-way inspection: ORIGINAL, CURRENT, PROPOSED with SHA-256 verification.
"""

from __future__ import annotations

import datetime
import json
import os
import shutil
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from grabedit.storage.atomic import AtomicStorage, calculate_hash


@dataclass
class SnapshotMetadata:
    snapshot_id: str
    target_path: str
    timestamp: str
    target_type: str
    size: int
    sha256: str
    permissions: int
    custom_metadata: Dict[str, Any]


class SnapshotEngine:
    """Manages creation, verification, and restoration of immutable target snapshots."""

    def __init__(self, base_dir: Optional[Path | str] = None):
        if base_dir:
            self.root = Path(base_dir)
        else:
            self.root = Path.cwd() / ".grabedit" / "snapshots"
        self.root.mkdir(parents=True, exist_ok=True)

    def create_snapshot(
        self,
        target_path: Path | str,
        content: Optional[str | bytes] = None,
        target_type: str = "FILE",
        custom_metadata: Optional[Dict[str, Any]] = None,
    ) -> Optional[SnapshotMetadata]:
        """Creates an immutable snapshot of target."""
        target = Path(target_path).resolve()
        now = datetime.datetime.now()
        date_folder = now.strftime("%Y-%m-%d")

        # Determine sha256 and content
        if content is not None:
            if isinstance(content, str):
                raw_bytes = content.encode("utf-8")
            else:
                raw_bytes = content
        elif target.is_file():
            raw_bytes = target.read_bytes()
        else:
            raw_bytes = b""

        import hashlib
        h = hashlib.sha256(raw_bytes).hexdigest()
        snap_id = h[:12]

        snap_dir = self.root / date_folder / snap_id
        snap_dir.mkdir(parents=True, exist_ok=True)

        original_file = snap_dir / "original"
        sha_file = snap_dir / "sha256"
        meta_file = snap_dir / "metadata.json"

        # Write immutable original
        if target.is_dir():
            # For directories, store file list and directory tree representation
            manifest = []
            for item in sorted(target.rglob("*")):
                if ".grabedit" in item.parts:
                    continue
                rel = item.relative_to(target)
                if item.is_file():
                    try:
                        manifest.append({"path": str(rel), "size": item.stat().st_size, "hash": calculate_hash(item)})
                    except Exception:
                        pass
            original_file.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        else:
            original_file.write_bytes(raw_bytes)

        sha_file.write_text(h, encoding="utf-8")

        meta = SnapshotMetadata(
            snapshot_id=snap_id,
            target_path=str(target),
            timestamp=now.isoformat(),
            target_type=target_type,
            size=len(raw_bytes),
            sha256=h,
            permissions=target.stat().st_mode if target.exists() else 0o644,
            custom_metadata=custom_metadata or {},
        )

        meta_file.write_text(json.dumps(asdict(meta), indent=2), encoding="utf-8")
        return meta

    def list_snapshots(self, target_path: Optional[Path | str] = None) -> List[SnapshotMetadata]:
        """List snapshots, optionally filtered by target path."""
        results: List[SnapshotMetadata] = []
        target_filter = str(Path(target_path).resolve()) if target_path else None

        if not self.root.exists():
            return results

        for meta_file in sorted(self.root.rglob("metadata.json"), reverse=True):
            try:
                data = json.loads(meta_file.read_text(encoding="utf-8"))
                meta = SnapshotMetadata(**data)
                if target_filter is None or meta.target_path == target_filter:
                    results.append(meta)
            except Exception:
                continue

        return results

    def get_snapshot(self, snapshot_id: str) -> Optional[Tuple[SnapshotMetadata, bytes]]:
        """Get snapshot metadata and raw original content by ID."""
        for snap_dir in self.root.rglob(snapshot_id):
            if snap_dir.is_dir() and (snap_dir / "metadata.json").exists():
                meta_data = json.loads((snap_dir / "metadata.json").read_text(encoding="utf-8"))
                meta = SnapshotMetadata(**meta_data)
                original_bytes = (snap_dir / "original").read_bytes()
                # Verify SHA256 integrity
                import hashlib
                verified_hash = hashlib.sha256(original_bytes).hexdigest()
                if (snap_dir / "sha256").exists():
                    expected_hash = (snap_dir / "sha256").read_text(encoding="utf-8").strip()
                    if verified_hash != expected_hash:
                        raise ValueError(f"Snapshot integrity failure for {snapshot_id}: hash mismatch!")
                return meta, original_bytes
        return None

    def restore_snapshot(self, snapshot_id: str, force_yes: bool = False) -> Tuple[bool, str]:
        """Restores a snapshot to its original target location with SHA-256 verification."""
        found = self.get_snapshot(snapshot_id)
        if not found:
            return False, f"Snapshot '{snapshot_id}' not found."

        meta, original_bytes = found
        target_path = Path(meta.target_path)

        current_hash = calculate_hash(target_path) if target_path.exists() else "(none)"
        snapshot_hash = meta.sha256

        if not force_yes:
            # Requires interactive or explicit confirmation
            return False, (
                f"CONFIRMATION_REQUIRED:\n"
                f"Target: {target_path}\n"
                f"Current SHA256:  {current_hash}\n"
                f"Snapshot SHA256: {snapshot_hash}\n"
                f"Timestamp:       {meta.timestamp}\n"
                f"Proceed with restore? Pass confirmation."
            )

        success, new_hash, msg = AtomicStorage.atomic_write(
            target_path=target_path,
            content=original_bytes,
            make_backup=True,
        )

        if success:
            return True, f"Successfully restored '{target_path.name}' from snapshot {snapshot_id} (SHA256: {new_hash[:12]}...)"
        return False, msg
