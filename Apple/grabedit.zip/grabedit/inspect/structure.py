"""
Structural analysis for structured formats (JSON, CSV, XML, YAML).
"""

from __future__ import annotations

import csv
import io
import json
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional


class StructureAnalyzer:
    """Analyzes structure, schema, columns, and key hierarchies."""

    @staticmethod
    def analyze_json(content: str) -> Dict[str, Any]:
        try:
            data = json.loads(content)
        except Exception as e:
            return {"valid": False, "error": str(e)}

        def get_keys_and_depth(obj: Any, depth: int = 0) -> Tuple[List[str], int]:
            max_d = depth
            keys = []
            if isinstance(obj, dict):
                for k, v in obj.items():
                    keys.append(str(k))
                    sub_keys, sub_d = get_keys_and_depth(v, depth + 1)
                    max_d = max(max_d, sub_d)
            elif isinstance(obj, list):
                for item in obj[:10]:
                    sub_keys, sub_d = get_keys_and_depth(item, depth + 1)
                    max_d = max(max_d, sub_d)
            return keys, max_d

        keys, max_depth = get_keys_and_depth(data)
        top_keys = list(data.keys()) if isinstance(data, dict) else [f"[{len(data)} items]"]

        return {
            "valid": True,
            "root_type": type(data).__name__,
            "top_level_keys": top_keys[:30],
            "total_keys_sample": len(keys),
            "max_depth": max_depth,
            "entry_count": len(data) if isinstance(data, (dict, list)) else 1,
        }

    @staticmethod
    def analyze_csv(content: str) -> Dict[str, Any]:
        try:
            sample = io.StringIO(content[:4096])
            reader = csv.reader(sample)
            header = next(reader, [])
            row_count = sum(1 for _ in io.StringIO(content)) - (1 if header else 0)
            return {
                "valid": True,
                "columns": header,
                "column_count": len(header),
                "estimated_rows": max(0, row_count),
            }
        except Exception as e:
            return {"valid": False, "error": str(e)}

    @staticmethod
    def analyze_xml(content: str) -> Dict[str, Any]:
        try:
            root = ET.fromstring(content)
            tag_count = len(list(root.iter()))
            return {
                "valid": True,
                "root_tag": root.tag,
                "total_tags": tag_count,
                "child_count": len(root),
                "attributes": list(root.attrib.keys()),
            }
        except Exception as e:
            return {"valid": False, "error": str(e)}
