"""
Syntax and Code-Aware Analysis for GrabEdit.
Parses AST, extracts classes, functions, imports, TODOs, FIXMEs, and complexity estimates.
Does not execute code.
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class CodeAnalysis:
    language: str
    lines: int
    functions: int = 0
    classes: int = 0
    imports: int = 0
    todos: int = 0
    fixmes: int = 0
    syntax_status: str = "VALID"
    syntax_error: Optional[str] = None
    estimated_complexity: str = "Low"
    import_list: List[str] = field(default_factory=list)
    function_list: List[str] = field(default_factory=list)
    class_list: List[str] = field(default_factory=list)

    def format_summary(self) -> str:
        lines = [
            f"Language:   {self.language}",
            f"Lines:      {self.lines}",
            f"Functions:  {self.functions}",
            f"Classes:    {self.classes}",
            f"Imports:    {self.imports}",
            f"TODOs:      {self.todos}",
            f"FIXMEs:     {self.fixmes}",
            f"Syntax:     {self.syntax_status}",
        ]
        if self.syntax_error:
            lines.append(f"Error:      {self.syntax_error}")
        lines.append(f"Complexity: {self.estimated_complexity}")
        return "\n".join(lines)


class SyntaxAnalyzer:
    """Performs static code inspection and syntax validation without execution."""

    TODO_PATTERN = re.compile(r"#\s*TODO\b|//\s*TODO\b|/\*\s*TODO\b", re.IGNORECASE)
    FIXME_PATTERN = re.compile(r"#\s*FIXME\b|//\s*FIXME\b|/\*\s*FIXME\b", re.IGNORECASE)

    @classmethod
    def analyze_python(cls, code: str) -> CodeAnalysis:
        raw_lines = code.splitlines()
        total_lines = len(raw_lines)

        todos = sum(1 for line in raw_lines if cls.TODO_PATTERN.search(line))
        fixmes = sum(1 for line in raw_lines if cls.FIXME_PATTERN.search(line))

        try:
            tree = ast.parse(code)
            syntax_status = "VALID"
            syntax_error = None
        except SyntaxError as e:
            return CodeAnalysis(
                language="Python",
                lines=total_lines,
                todos=todos,
                fixmes=fixmes,
                syntax_status="SYNTAX_ERROR",
                syntax_error=f"Line {e.lineno}: {e.msg}",
                estimated_complexity="Unknown (Unparseable)",
            )

        functions = []
        classes = []
        imports = []
        branching_nodes = 0

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                functions.append(node.name)
            elif isinstance(node, ast.ClassDef):
                classes.append(node.name)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    imports.append(f"{module}.{alias.name}")
            elif isinstance(node, (ast.If, ast.For, ast.While, ast.ExceptHandler, ast.With)):
                branching_nodes += 1

        # Complexity estimate based on cyclomatic decision points
        if branching_nodes < 10:
            complexity = "Low (Simple)"
        elif branching_nodes < 30:
            complexity = "Moderate"
        else:
            complexity = "High (Dense branching)"

        return CodeAnalysis(
            language="Python",
            lines=total_lines,
            functions=len(functions),
            classes=len(classes),
            imports=len(imports),
            todos=todos,
            fixmes=fixmes,
            syntax_status=syntax_status,
            syntax_error=syntax_error,
            estimated_complexity=complexity,
            import_list=imports[:20],
            function_list=functions[:30],
            class_list=classes[:20],
        )

    @classmethod
    def analyze_generic_text(cls, code: str, extension: str) -> CodeAnalysis:
        raw_lines = code.splitlines()
        total_lines = len(raw_lines)
        todos = sum(1 for line in raw_lines if cls.TODO_PATTERN.search(line))
        fixmes = sum(1 for line in raw_lines if cls.FIXME_PATTERN.search(line))

        # Basic regex heuristics for JavaScript / TypeScript / C
        fn_pattern = re.compile(r"\bfunction\s+([a-zA-Z0-9_]+)|\b([a-zA-Z0-9_]+)\s*=\s*(?:\([^)]*\)|[a-zA-Z0-9_]+)\s*=>")
        class_pattern = re.compile(r"\bclass\s+([a-zA-Z0-9_]+)")
        import_pattern = re.compile(r"\bimport\s+.*?(?:from\s+['\"][^'\"]+['\"]|['\"][^'\"]+['\"])")

        functions = len(fn_pattern.findall(code))
        classes = len(class_pattern.findall(code))
        imports = len(import_pattern.findall(code))

        lang_map = {
            ".js": "JavaScript",
            ".ts": "TypeScript",
            ".sh": "Shell Script",
            ".zsh": "Zsh Script",
            ".md": "Markdown",
            ".html": "HTML",
            ".css": "CSS",
            ".json": "JSON",
        }
        language = lang_map.get(extension.lower(), "Text")

        return CodeAnalysis(
            language=language,
            lines=total_lines,
            functions=functions,
            classes=classes,
            imports=imports,
            todos=todos,
            fixmes=fixmes,
            syntax_status="CHECKED",
            estimated_complexity="Normal",
        )
