"""
Core Inspector for GrabEdit.
Generates comprehensive human and machine-readable inspection views.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

from grabedit.grab.detectors import GrabTargetType
from grabedit.grab.grabber import GrabObject
from grabedit.inspect.metadata import MetadataExtractor
from grabedit.inspect.structure import StructureAnalyzer
from grabedit.inspect.syntax import CodeAnalysis, SyntaxAnalyzer


class Inspector:
    """Combines metadata, syntax, and structural inspection for any GrabObject."""

    @staticmethod
    def inspect(obj: GrabObject) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "id": obj.id,
            "source": obj.source,
            "type": obj.type.value if hasattr(obj.type, "value") else str(obj.type),
            "path": obj.path,
            "size": obj.size,
            "size_formatted": MetadataExtractor.format_size(obj.size or 0),
            "hash": obj.hash,
            "permissions": obj.permissions,
            "created": obj.created,
            "modified": obj.modified,
        }

        content = obj.content or ""

        # Syntax / Code-aware inspection
        if obj.path and obj.path.endswith(".py"):
            code_res = SyntaxAnalyzer.analyze_python(content)
            result["code_analysis"] = code_res.__dict__
        elif obj.path and Path(obj.path).suffix in (".js", ".ts", ".sh", ".md", ".html", ".css"):
            code_res = SyntaxAnalyzer.analyze_generic_text(content, Path(obj.path).suffix)
            result["code_analysis"] = code_res.__dict__

        # Structural inspection
        if obj.type == GrabTargetType.JSON or (obj.path and obj.path.endswith(".json")):
            result["structure"] = StructureAnalyzer.analyze_json(content)
        elif obj.type == GrabTargetType.CSV or (obj.path and obj.path.endswith(".csv")):
            result["structure"] = StructureAnalyzer.analyze_csv(content)
        elif obj.type == GrabTargetType.XML or (obj.path and obj.path.endswith((".xml", ".plist"))):
            result["structure"] = StructureAnalyzer.analyze_xml(content)
        elif obj.type == GrabTargetType.LOG:
            result["log_analysis"] = obj.metadata.get("log_stats", {})
        elif obj.type == GrabTargetType.DIRECTORY:
            result["directory_stats"] = obj.metadata
        elif obj.type == GrabTargetType.PROCESS:
            result["process_info"] = obj.metadata
        elif obj.type == GrabTargetType.COMMAND_OUTPUT:
            result["command_info"] = obj.metadata

        return result

    @staticmethod
    def format_terminal_card(obj: GrabObject) -> str:
        """Renders the official GrabEdit terminal inspection view."""
        data = Inspector.inspect(obj)
        target_display = obj.path or obj.source
        type_str = data["type"]
        size_str = data["size_formatted"]

        # Status indicators
        status_items = ["✓ Captured"]
        if obj.permissions:
            status_items.append(f"✓ Permissions: {obj.permissions}")
        if obj.type in (GrabTargetType.FILE, GrabTargetType.JSON, GrabTargetType.CSV, GrabTargetType.TEXT, GrabTargetType.LOG):
            status_items.append("✓ Editable")
        if "code_analysis" in data:
            syntax_val = data["code_analysis"].get("syntax_status", "VALID")
            status_items.append(f"✓ Syntax: {syntax_val}")
        if "structure" in data and data["structure"].get("valid"):
            status_items.append(f"✓ Valid {type_str}")

        lines = [
            "GRABEDIT",
            "",
            "Target:",
            f"  {target_display}",
            "",
            "Type:",
            f"  {type_str}",
            "",
            "Size:",
            f"  {size_str}",
            "",
            "Status:",
        ]
        for item in status_items:
            lines.append(f"  {item}")

        # Code-aware summary if present
        if "code_analysis" in data:
            c = data["code_analysis"]
            lines.extend([
                "",
                "Code Metrics:",
                f"  Lines:     {c.get('lines', 0)}",
                f"  Functions: {c.get('functions', 0)}",
                f"  Classes:   {c.get('classes', 0)}",
                f"  Imports:   {c.get('imports', 0)}",
                f"  TODOs:     {c.get('todos', 0)}",
            ])

        lines.extend([
            "",
            "Commands:",
            "",
            "  [e] Edit",
            "  [d] Diff",
            "  [v] Validate",
            "  [h] Hash",
            "  [s] Save",
            "  [r] Restore",
            "  [x] Execute",
            "  [q] Quit",
        ])
        return "\n".join(lines)
