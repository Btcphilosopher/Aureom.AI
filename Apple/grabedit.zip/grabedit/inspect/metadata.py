"""
Metadata and hashing extractor for GrabEdit.
Calculates SHA256, SHA512, permissions, timestamps, and POSIX stats.
"""

from __future__ import annotations

import datetime
import hashlib
import os
from pathlib import Path
from typing import Any, Dict, Optional

from grabedit.storage.atomic import calculate_hash


class MetadataExtractor:
    """Extracts filesystem, POSIX, and cryptographic metadata."""

    @staticmethod
    def extract_file_metadata(path: Path | str) -> Dict[str, Any]:
        p = Path(path).resolve()
        if not p.exists():
            return {"exists": False, "path": str(p)}

        stat = p.stat()
        sha256 = calculate_hash(p, "sha256") if p.is_file() else ""
        sha512 = calculate_hash(p, "sha512") if p.is_file() else ""

        return {
            "exists": True,
            "path": str(p),
            "name": p.name,
            "extension": p.suffix,
            "is_file": p.is_file(),
            "is_dir": p.is_dir(),
            "is_symlink": p.is_symlink(),
            "size_bytes": stat.st_size,
            "size_formatted": MetadataExtractor.format_size(stat.st_size),
            "created": datetime.datetime.fromtimestamp(stat.st_ctime).isoformat(),
            "modified": datetime.datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "permissions_octal": oct(stat.st_mode)[-3:],
            "owner_uid": stat.st_uid,
            "group_gid": stat.st_gid,
            "sha256": sha256,
            "sha512": sha512,
            "readable": os.access(p, os.R_OK),
            "writable": os.access(p, os.W_OK),
            "executable": os.access(p, os.X_OK),
        }

    @staticmethod
    def format_size(num_bytes: int) -> str:
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if num_bytes < 1024.0:
                return f"{num_bytes:.1f} {unit}" if unit != "B" else f"{num_bytes} B"
            num_bytes /= 1024.0
        return f"{num_bytes:.1f} PB"
