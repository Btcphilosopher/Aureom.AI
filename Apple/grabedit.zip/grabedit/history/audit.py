"""
Audit log subsystem for GrabEdit.
Maintains forensic trail of all inspected, modified, patched, and restored targets.
"""

from __future__ import annotations

import datetime
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class AuditEntry:
    timestamp: str
    user_action: str
    target: str
    operation: str
    original_hash: str
    new_hash: str
    status: str
    details: Optional[Dict[str, Any]] = None

    def format_text(self) -> str:
        return (
            f"────────────────────────────────────────\n"
            f"{self.timestamp}\n\n"
            f"ACTION:    {self.user_action}\n"
            f"TARGET:    {self.target}\n"
            f"OPERATION: {self.operation}\n"
            f"ORIGINAL:  SHA256: {self.original_hash}\n"
            f"NEW:       SHA256: {self.new_hash}\n"
            f"STATUS:    {self.status}\n"
        )


class AuditLogger:
    """Manages audit log recording and historical querying."""

    def __init__(self, log_dir: Optional[Path | str] = None):
        if log_dir:
            self.root = Path(log_dir)
        else:
            self.root = Path.cwd() / ".grabedit"
        self.root.mkdir(parents=True, exist_ok=True)
        self.json_log_path = self.root / "audit.jsonl"
        self.text_log_path = self.root / "audit.log"

    def record(
        self,
        user_action: str,
        target: str,
        operation: str,
        original_hash: str,
        new_hash: str,
        status: str,
        details: Optional[Dict[str, Any]] = None,
    ) -> AuditEntry:
        """Records an audit event to both structured JSONL and formatted text log."""
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = AuditEntry(
            timestamp=now,
            user_action=user_action,
            target=str(target),
            operation=operation,
            original_hash=original_hash or "N/A",
            new_hash=new_hash or "N/A",
            status=status,
            details=details,
        )

        try:
            with open(self.json_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(asdict(entry)) + "\n")
            with open(self.text_log_path, "a", encoding="utf-8") as f:
                f.write(entry.format_text())
        except Exception:
            pass

        return entry

    def read_entries(self, limit: int = 50) -> List[AuditEntry]:
        """Reads the latest audit log entries."""
        if not self.json_log_path.exists():
            return []
        entries: List[AuditEntry] = []
        try:
            with open(self.json_log_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
                for line in reversed(lines[-limit:]):
                    if line.strip():
                        entries.append(AuditEntry(**json.loads(line.strip())))
        except Exception:
            pass
        return entries
