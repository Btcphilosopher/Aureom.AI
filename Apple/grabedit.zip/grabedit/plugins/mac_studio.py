"""
Mac Utility Studio Integration Architecture for GrabEdit.
Provides IPC bridge, EventBus, JobEngine, AutomationEngine, and ReportEngine hooks for Kotlin/Swift frontends.
"""

from __future__ import annotations

import datetime
import json
import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Dict, List, Optional

from grabedit.execution.planner import ExecutionPlan


@dataclass
class StudioEvent:
    event_id: str
    topic: str
    timestamp: str
    payload: Dict[str, Any]


class EventBus:
    """Pub/Sub event bus for Mac Utility Studio integration."""

    def __init__(self):
        self._subscribers: Dict[str, List[Callable[[StudioEvent], None]]] = {}

    def subscribe(self, topic: str, handler: Callable[[StudioEvent], None]):
        self._subscribers.setdefault(topic, []).append(handler)

    def publish(self, topic: str, payload: Dict[str, Any]) -> StudioEvent:
        event = StudioEvent(
            event_id=f"evt_{uuid.uuid4().hex[:8]}",
            topic=topic,
            timestamp=datetime.datetime.now().isoformat(),
            payload=payload,
        )
        for handler in self._subscribers.get(topic, []):
            try:
                handler(event)
            except Exception:
                pass
        return event


class JobEngine:
    """Queues and executes GrabEdit plans inside Mac Utility Studio background workers."""

    def __init__(self, event_bus: Optional[EventBus] = None):
        self.bus = event_bus or EventBus()
        self._jobs: Dict[str, Dict[str, Any]] = {}

    def submit_plan(self, plan: ExecutionPlan, job_name: str = "GrabEdit Task") -> str:
        job_id = f"job_{uuid.uuid4().hex[:8]}"
        job_record = {
            "job_id": job_id,
            "name": job_name,
            "target": plan.target,
            "plan_id": plan.plan_id,
            "status": "QUEUED",
            "created_at": datetime.datetime.now().isoformat(),
            "operations_count": len(plan.patch.operations),
        }
        self._jobs[job_id] = job_record
        self.bus.publish("job.submitted", job_record)
        return job_id

    def get_job_status(self, job_id: str) -> Optional[Dict[str, Any]]:
        return self._jobs.get(job_id)


class ReportEngine:
    """Generates structured execution summaries formatted for Kotlin / Swift GUI consumption."""

    @staticmethod
    def generate_json_report(plan: ExecutionPlan) -> str:
        return json.dumps({
            "plan_id": plan.plan_id,
            "target": plan.target,
            "valid": plan.validation.is_valid,
            "format": plan.validation.format_name,
            "warnings": plan.warnings,
            "requires_confirmation": plan.requires_confirmation,
            "diff": plan.patch.unified_diff,
            "operations": [op.to_dict() for op in plan.patch.operations],
        }, indent=2)


class AutomationEngine:
    """Handles automated recurring rules or macro triggers."""

    def __init__(self, job_engine: JobEngine):
        self.job_engine = job_engine
        self._recipes: Dict[str, Any] = {}

    def register_recipe(self, name: str, pipeline_config: Dict[str, Any]):
        self._recipes[name] = pipeline_config


class MacUtilityStudioBridge:
    """Main bridge interfacing GrabEdit with Mac Utility Studio ecosystem."""

    def __init__(self):
        self.event_bus = EventBus()
        self.jobs = JobEngine(self.event_bus)
        self.reports = ReportEngine()
        self.automation = AutomationEngine(self.jobs)
