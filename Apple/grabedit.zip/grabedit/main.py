"""
Top-level script runner for grabedit.
"""

import sys
from grabedit.cli.main import main

if __name__ == "__main__":
    sys.exit(main())
