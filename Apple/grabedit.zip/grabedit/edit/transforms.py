"""
Text Transformation Pipelines and AST Nodes for GrabEdit.
Every operation is represented as an AST node forming a deterministic pipeline.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from grabedit.edit.patch import PatchOperation, PatchOperationType


class TransformNode(ABC):
    """Abstract base AST node for all text transformations."""

    @abstractmethod
    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        """Applies transformation and returns (new_text, patch_operation)."""
        pass

    @abstractmethod
    def describe(self) -> str:
        """Returns human-readable description of this transformation."""
        pass


@dataclass
class TrimWhitespace(TransformNode):
    strip_trailing_only: bool = False

    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        lines = text.splitlines(keepends=True)
        new_lines = []
        for line in lines:
            if self.strip_trailing_only:
                new_lines.append(line.rstrip(" \t") if not line.endswith("\n") else line[:-1].rstrip(" \t") + "\n")
            else:
                ending = "\n" if line.endswith("\n") else ""
                new_lines.append(line.strip() + ending)
        new_text = "".join(new_lines)
        op = PatchOperation(
            op_type=PatchOperationType.REPLACE,
            target_selector="all lines",
            old_value="(whitespace unstripped)",
            new_value="(whitespace trimmed)",
            metadata={"node": "TrimWhitespace"},
        )
        return new_text, op

    def describe(self) -> str:
        return "Trim whitespace on all lines"


@dataclass
class RemoveBlankLines(TransformNode):
    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        lines = text.splitlines(keepends=True)
        new_lines = [l for l in lines if l.strip()]
        new_text = "".join(new_lines)
        op = PatchOperation(
            op_type=PatchOperationType.DELETE,
            target_selector="blank lines",
            old_value=None,
            new_value=None,
            metadata={"node": "RemoveBlankLines", "removed_count": len(lines) - len(new_lines)},
        )
        return new_text, op

    def describe(self) -> str:
        return "Remove blank lines"


@dataclass
class SortLines(TransformNode):
    reverse: bool = False
    ignore_case: bool = False

    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        lines = text.splitlines()
        key_fn = (lambda s: s.lower()) if self.ignore_case else None
        sorted_lines = sorted(lines, key=key_fn, reverse=self.reverse)
        new_text = "\n".join(sorted_lines) + ("\n" if text.endswith("\n") else "")
        op = PatchOperation(
            op_type=PatchOperationType.MOVE,
            target_selector="all lines",
            old_value="unsorted",
            new_value="sorted",
            metadata={"node": "SortLines", "reverse": self.reverse},
        )
        return new_text, op

    def describe(self) -> str:
        return f"Sort lines ({'descending' if self.reverse else 'ascending'})"


@dataclass
class RemoveDuplicates(TransformNode):
    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        lines = text.splitlines()
        seen = set()
        deduped = []
        for line in lines:
            if line not in seen:
                seen.add(line)
                deduped.append(line)
        new_text = "\n".join(deduped) + ("\n" if text.endswith("\n") else "")
        op = PatchOperation(
            op_type=PatchOperationType.DELETE,
            target_selector="duplicate lines",
            old_value=None,
            new_value=None,
            metadata={"node": "RemoveDuplicates", "duplicates_removed": len(lines) - len(deduped)},
        )
        return new_text, op

    def describe(self) -> str:
        return "Remove duplicate lines (deduplicate)"


@dataclass
class ReplaceText(TransformNode):
    old_str: str
    new_str: str
    count: int = -1

    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        occ = text.count(self.old_str)
        if self.count > 0:
            new_text = text.replace(self.old_str, self.new_str, self.count)
        else:
            new_text = text.replace(self.old_str, self.new_str)
        op = PatchOperation(
            op_type=PatchOperationType.REPLACE,
            target_selector=f'text: "{self.old_str}"',
            old_value=self.old_str,
            new_value=self.new_str,
            metadata={"node": "ReplaceText", "occurrences": occ},
        )
        return new_text, op

    def describe(self) -> str:
        return f'Replace "{self.old_str}" with "{self.new_str}"'


@dataclass
class ReplaceRegex(TransformNode):
    pattern: str
    replacement: str
    flags: int = 0

    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        # Protect against pathological regex compilation errors
        try:
            compiled = re.compile(self.pattern, self.flags)
        except re.error as e:
            raise ValueError(f"Invalid regex pattern '{self.pattern}': {e}")

        matches = list(compiled.finditer(text))
        new_text = compiled.sub(self.replacement, text)
        op = PatchOperation(
            op_type=PatchOperationType.REPLACE,
            target_selector=f"regex: /{self.pattern}/",
            old_value=f"{len(matches)} match(es)",
            new_value=self.replacement,
            metadata={"node": "ReplaceRegex", "matches_count": len(matches)},
        )
        return new_text, op

    def describe(self) -> str:
        return f'Replace regex /{self.pattern}/ with "{self.replacement}"'


@dataclass
class DeleteLines(TransformNode):
    start_line: int  # 1-indexed
    end_line: int    # 1-indexed inclusive

    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        lines = text.splitlines(keepends=True)
        start_idx = max(0, self.start_line - 1)
        end_idx = min(len(lines), self.end_line)
        deleted_chunk = "".join(lines[start_idx:end_idx])
        new_lines = lines[:start_idx] + lines[end_idx:]
        new_text = "".join(new_lines)
        op = PatchOperation(
            op_type=PatchOperationType.DELETE,
            target_selector=f"lines {self.start_line}-{self.end_line}",
            old_value=deleted_chunk.strip(),
            new_value=None,
            metadata={"node": "DeleteLines", "lines": f"{self.start_line}-{self.end_line}"},
        )
        return new_text, op

    def describe(self) -> str:
        return f"Delete lines {self.start_line}-{self.end_line}"


@dataclass
class InsertAtLine(TransformNode):
    line_number: int  # 1-indexed
    insertion: str

    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        lines = text.splitlines(keepends=True)
        idx = max(0, min(len(lines), self.line_number - 1))
        insert_text = self.insertion if self.insertion.endswith("\n") else self.insertion + "\n"
        lines.insert(idx, insert_text)
        new_text = "".join(lines)
        op = PatchOperation(
            op_type=PatchOperationType.INSERT,
            target_selector=f"line {self.line_number}",
            old_value=None,
            new_value=self.insertion,
            metadata={"node": "InsertAtLine", "line": self.line_number},
        )
        return new_text, op

    def describe(self) -> str:
        return f'Insert text at line {self.line_number}: "{self.insertion}"'


@dataclass
class PrependText(TransformNode):
    text_to_prepend: str

    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        p = self.text_to_prepend if self.text_to_prepend.endswith("\n") else self.text_to_prepend + "\n"
        new_text = p + text
        op = PatchOperation(
            op_type=PatchOperationType.ADD,
            target_selector="start of file",
            old_value=None,
            new_value=self.text_to_prepend,
            metadata={"node": "PrependText"},
        )
        return new_text, op

    def describe(self) -> str:
        return f'Prepend "{self.text_to_prepend}"'


@dataclass
class AppendText(TransformNode):
    text_to_append: str

    def apply(self, text: str) -> Tuple[str, Optional[PatchOperation]]:
        prefix = "\n" if text and not text.endswith("\n") else ""
        new_text = text + prefix + self.text_to_append + "\n"
        op = PatchOperation(
            op_type=PatchOperationType.ADD,
            target_selector="end of file",
            old_value=None,
            new_value=self.text_to_append,
            metadata={"node": "AppendText"},
        )
        return new_text, op

    def describe(self) -> str:
        return f'Append "{self.text_to_append}"'


@dataclass
class TransformPipeline:
    """Represents a sequential AST pipeline of transformations."""

    operations: List[TransformNode] = field(default_factory=list)

    def add(self, node: TransformNode) -> TransformPipeline:
        self.operations.append(node)
        return self

    def execute(self, text: str) -> Tuple[str, List[PatchOperation]]:
        current_text = text
        patch_ops: List[PatchOperation] = []
        for op in self.operations:
            current_text, patch_op = op.apply(current_text)
            if patch_op:
                patch_ops.append(patch_op)
        return current_text, patch_ops
