"""
Core EditEngine for GrabEdit.
Coordinates structured mutations, AST pipelines, patch generation, and atomic commits.
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from grabedit.edit.operations import CsvOperations, JsonOperations
from grabedit.edit.patch import Patch, PatchOperation, PatchOperationType
from grabedit.edit.transforms import (
    AppendText,
    DeleteLines,
    InsertAtLine,
    PrependText,
    RemoveBlankLines,
    RemoveDuplicates,
    ReplaceRegex,
    ReplaceText,
    SortLines,
    TransformNode,
    TransformPipeline,
    TrimWhitespace,
)
from grabedit.execution.executor import Executor
from grabedit.execution.planner import ExecutionPlan, ExecutionPlanner
from grabedit.grab.grabber import GrabObject
from grabedit.storage.atomic import calculate_content_hash
from grabedit.validate.validator import ValidationEngine


class EditEngine:
    """Provides high-level editing APIs for text, JSON, and CSV targets."""

    def __init__(self, grab_obj: GrabObject):
        self.target_obj = grab_obj
        self.original_text = grab_obj.content or ""
        self.current_text = self.original_text
        self.operations: List[PatchOperation] = []
        self.planner = ExecutionPlanner()
        self.executor = Executor()

    def replace(self, old_str: str, new_str: str, count: int = -1) -> EditEngine:
        """Replaces text occurrences."""
        node = ReplaceText(old_str=old_str, new_str=new_str, count=count)
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def replace_regex(self, pattern: str, replacement: str, flags: int = 0) -> EditEngine:
        """Replaces matching regex pattern."""
        node = ReplaceRegex(pattern=pattern, replacement=replacement, flags=flags)
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def delete_lines(self, start_line: int, end_line: int) -> EditEngine:
        """Deletes lines from start_line to end_line (1-indexed inclusive)."""
        node = DeleteLines(start_line=start_line, end_line=end_line)
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def insert_line(self, line_number: int, text: str) -> EditEngine:
        """Inserts text at specified 1-indexed line."""
        node = InsertAtLine(line_number=line_number, insertion=text)
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def append(self, text: str) -> EditEngine:
        """Appends text to the end of target."""
        node = AppendText(text_to_append=text)
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def prepend(self, text: str) -> EditEngine:
        """Prepends text to the beginning of target."""
        node = PrependText(text_to_prepend=text)
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def sort_lines(self, reverse: bool = False, ignore_case: bool = False) -> EditEngine:
        node = SortLines(reverse=reverse, ignore_case=ignore_case)
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def remove_duplicates(self) -> EditEngine:
        node = RemoveDuplicates()
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def trim_whitespace(self, trailing_only: bool = False) -> EditEngine:
        node = TrimWhitespace(strip_trailing_only=trailing_only)
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    def remove_blank_lines(self) -> EditEngine:
        node = RemoveBlankLines()
        self.current_text, op = node.apply(self.current_text)
        if op:
            self.operations.append(op)
        return self

    # JSON Operations
    def json_set(self, key_path: str, value: Any) -> EditEngine:
        self.current_text, op = JsonOperations.set_value(self.current_text, key_path, value)
        self.operations.append(op)
        return self

    def json_delete(self, key_path: str) -> EditEngine:
        self.current_text, op = JsonOperations.delete_key(self.current_text, key_path)
        self.operations.append(op)
        return self

    # CSV Operations
    def csv_rename_column(self, old_name: str, new_name: str) -> EditEngine:
        self.current_text, op = CsvOperations.rename_column(self.current_text, old_name, new_name)
        self.operations.append(op)
        return self

    def csv_add_column(self, col_name: str, default_val: str = "") -> EditEngine:
        self.current_text, op = CsvOperations.add_column(self.current_text, col_name, default_val)
        self.operations.append(op)
        return self

    def csv_remove_column(self, col_name: str) -> EditEngine:
        self.current_text, op = CsvOperations.remove_column(self.current_text, col_name)
        self.operations.append(op)
        return self

    def csv_filter_rows(self, col_name: str, condition: str, value: str) -> EditEngine:
        self.current_text, op = CsvOperations.filter_rows(self.current_text, col_name, condition, value)
        self.operations.append(op)
        return self

    def csv_sort(self, col_name: str, reverse: bool = False) -> EditEngine:
        self.current_text, op = CsvOperations.sort_rows(self.current_text, col_name, reverse)
        self.operations.append(op)
        return self

    def csv_deduplicate(self) -> EditEngine:
        self.current_text, op = CsvOperations.deduplicate(self.current_text)
        self.operations.append(op)
        return self

    # Pipeline execution
    def apply_pipeline(self, pipeline: TransformPipeline) -> EditEngine:
        self.current_text, ops = pipeline.execute(self.current_text)
        self.operations.extend(ops)
        return self

    def get_patch(self) -> Patch:
        """Produces a formal, reversible Patch object."""
        target_name = self.target_obj.path or self.target_obj.source
        return Patch(
            target=target_name,
            original_text=self.original_text,
            proposed_text=self.current_text,
            operations=list(self.operations),
        )

    def plan(self) -> ExecutionPlan:
        """Constructs an ExecutionPlan without writing to disk."""
        target_name = self.target_obj.path or self.target_obj.source
        patch = self.get_patch()
        return self.planner.plan(
            target_path=target_name,
            patch=patch,
            rollback_snapshot_id=self.target_obj.snapshot_id,
        )

    def commit(self, plan: Optional[ExecutionPlan] = None, force: bool = False) -> Tuple[bool, str, Dict[str, Any]]:
        """Commits the plan atomically to disk with validation and audit logging."""
        active_plan = plan or self.plan()
        return self.executor.execute(active_plan, force_confirm=force)

    def launch_external_editor(self) -> Tuple[bool, str, Optional[ExecutionPlan]]:
        """
        Supports $EDITOR integration:
        EDITOR -> RELOAD -> VALIDATE -> DIFF -> CONFIRM -> SAVE
        """
        editor_cmd = os.environ.get("EDITOR", "nano" if os.name != "nt" else "notepad")
        target_name = self.target_obj.path or "grabedit_temp.txt"

        with tempfile.NamedTemporaryFile(suffix="_" + Path(target_name).name, mode="w", encoding="utf-8", delete=False) as tf:
            tf.write(self.current_text)
            temp_path = tf.name

        try:
            subprocess.run([editor_cmd, temp_path], check=True)
            with open(temp_path, "r", encoding="utf-8") as f:
                edited_text = f.read()

            if edited_text == self.original_text:
                return True, "No changes made in external editor.", None

            self.current_text = edited_text
            self.operations.append(PatchOperation(
                op_type=PatchOperationType.REPLACE,
                target_selector="external $EDITOR session",
                old_value=None,
                new_value=None,
            ))

            plan = self.plan()
            return True, "External edits reloaded and validated. Ready for preview/commit.", plan
        except Exception as e:
            return False, f"External editor failed: {e}", None
        finally:
            if os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except Exception:
                    pass
