"""
Patch Engine for GrabEdit.
Provides structured patch representations: Patch, PatchOperation, PatchSet, PatchValidator.
Supports ADD, DELETE, REPLACE, MOVE, INSERT with reversibility checking and unified diffs.
"""

from __future__ import annotations

import difflib
import enum
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from grabedit.storage.atomic import calculate_content_hash


class PatchOperationType(str, enum.Enum):
    ADD = "ADD"
    DELETE = "DELETE"
    REPLACE = "REPLACE"
    MOVE = "MOVE"
    INSERT = "INSERT"


@dataclass
class PatchOperation:
    op_type: PatchOperationType
    target_selector: str  # e.g. "line 42", "lines 20-30", "json:database.host", "csv:column:telephone"
    old_value: Optional[str] = None
    new_value: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["op_type"] = self.op_type.value
        return d


@dataclass
class Patch:
    target: str
    original_text: str
    proposed_text: str
    operations: List[PatchOperation] = field(default_factory=list)
    unified_diff: str = ""
    original_hash: str = ""
    proposed_hash: str = ""
    is_reversible: bool = True
    reversibility_notes: str = ""

    def __post_init__(self):
        if not self.original_hash:
            self.original_hash = calculate_content_hash(self.original_text)
        if not self.proposed_hash:
            self.proposed_hash = calculate_content_hash(self.proposed_text)
        if not self.unified_diff:
            self.unified_diff = self._generate_unified_diff()

    def _generate_unified_diff(self) -> str:
        orig_lines = self.original_text.splitlines(keepends=True)
        prop_lines = self.proposed_text.splitlines(keepends=True)
        diff = difflib.unified_diff(
            orig_lines,
            prop_lines,
            fromfile=f"a/{self.target} (ORIGINAL)",
            tofile=f"b/{self.target} (PROPOSED)",
            n=3,
        )
        return "".join(diff)

    def reverse(self) -> Optional[Patch]:
        """Generates an inverted reversible patch if possible."""
        if not self.is_reversible:
            return None

        rev_ops = []
        for op in reversed(self.operations):
            if op.op_type == PatchOperationType.ADD:
                rev_ops.append(PatchOperation(
                    op_type=PatchOperationType.DELETE,
                    target_selector=op.target_selector,
                    old_value=op.new_value,
                    new_value=None,
                ))
            elif op.op_type == PatchOperationType.DELETE:
                rev_ops.append(PatchOperation(
                    op_type=PatchOperationType.ADD,
                    target_selector=op.target_selector,
                    old_value=None,
                    new_value=op.old_value,
                ))
            elif op.op_type == PatchOperationType.REPLACE:
                rev_ops.append(PatchOperation(
                    op_type=PatchOperationType.REPLACE,
                    target_selector=op.target_selector,
                    old_value=op.new_value,
                    new_value=op.old_value,
                ))
            elif op.op_type == PatchOperationType.INSERT:
                rev_ops.append(PatchOperation(
                    op_type=PatchOperationType.DELETE,
                    target_selector=op.target_selector,
                    old_value=op.new_value,
                    new_value=None,
                ))
            else:
                rev_ops.append(PatchOperation(
                    op_type=op.op_type,
                    target_selector=op.target_selector,
                    old_value=op.new_value,
                    new_value=op.old_value,
                ))

        return Patch(
            target=self.target,
            original_text=self.proposed_text,
            proposed_text=self.original_text,
            operations=rev_ops,
            is_reversible=True,
            reversibility_notes="Inverted from forward patch",
        )


@dataclass
class PatchSet:
    patches: List[Patch] = field(default_factory=list)
    description: str = ""

    def add(self, patch: Patch):
        self.patches.append(patch)

    @property
    def has_changes(self) -> bool:
        return any(p.original_hash != p.proposed_hash for p in self.patches)


class PatchValidator:
    """Validates that a patch can be safely applied without ambiguity or corruption."""

    @staticmethod
    def validate(patch: Patch, current_text: str) -> Tuple[bool, List[str]]:
        errors: List[str] = []
        current_hash = calculate_content_hash(current_text)

        if current_hash != patch.original_hash:
            errors.append(
                f"Base Hash Conflict: Target '{patch.target}' current SHA256 ({current_hash[:10]}...) "
                f"does not match patch base SHA256 ({patch.original_hash[:10]}...). File has changed!"
            )

        # Check for empty replacement
        if not patch.operations and patch.original_text == patch.proposed_text:
            return True, ["No modifications detected in patch."]

        return len(errors) == 0, errors
