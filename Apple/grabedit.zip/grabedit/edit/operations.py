"""
Structured JSON and CSV editing operations for GrabEdit.
Deterministically manipulates nested JSON paths and tabular CSV records without arbitrary eval.
"""

from __future__ import annotations

import csv
import io
import json
from typing import Any, Dict, List, Optional, Tuple, Union

from grabedit.edit.patch import PatchOperation, PatchOperationType


class JsonOperations:
    """Safe, structured JSON manipulator using dot-notation paths."""

    @staticmethod
    def parse_path(path_str: str) -> List[Union[str, int]]:
        """Parses 'database.host' or 'users.0.name' into keys/indexes."""
        tokens: List[Union[str, int]] = []
        for part in path_str.strip().split("."):
            if not part:
                continue
            if part.isdigit():
                tokens.append(int(part))
            else:
                tokens.append(part)
        return tokens

    @staticmethod
    def set_value(json_str: str, path_str: str, raw_val: Any) -> Tuple[str, PatchOperation]:
        """Sets nested JSON value without arbitrary eval."""
        data = json.loads(json_str)
        tokens = JsonOperations.parse_path(path_str)
        if not tokens:
            raise ValueError("Empty JSON path")

        # Parse raw_val safely if it's a string representing bool, number, null, or JSON
        parsed_val = raw_val
        if isinstance(raw_val, str):
            val_s = raw_val.strip()
            if val_s.lower() == "true":
                parsed_val = True
            elif val_s.lower() == "false":
                parsed_val = False
            elif val_s.lower() == "null":
                parsed_val = None
            elif (val_s.startswith('"') and val_s.endswith('"')) or (val_s.startswith("'") and val_s.endswith("'")):
                parsed_val = val_s[1:-1]
            elif val_s.isdigit() or (val_s.startswith("-") and val_s[1:].isdigit()):
                parsed_val = int(val_s)
            else:
                try:
                    parsed_val = float(val_s)
                except ValueError:
                    parsed_val = val_s

        curr = data
        for i, token in enumerate(tokens[:-1]):
            if isinstance(curr, dict):
                if token not in curr:
                    # Look ahead to see if next token is int
                    curr[token] = [] if isinstance(tokens[i + 1], int) else {}
                curr = curr[token]
            elif isinstance(curr, list) and isinstance(token, int):
                while len(curr) <= token:
                    curr.append({})
                curr = curr[token]
            else:
                raise TypeError(f"Cannot traverse path segment '{token}' on {type(curr).__name__}")

        last = tokens[-1]
        old_val = None
        if isinstance(curr, dict):
            old_val = curr.get(last)
            curr[last] = parsed_val
        elif isinstance(curr, list) and isinstance(last, int):
            while len(curr) <= last:
                curr.append(None)
            old_val = curr[last]
            curr[last] = parsed_val

        new_json = json.dumps(data, indent=2)
        op = PatchOperation(
            op_type=PatchOperationType.REPLACE if old_val is not None else PatchOperationType.ADD,
            target_selector=f"json:{path_str}",
            old_value=json.dumps(old_val),
            new_value=json.dumps(parsed_val),
            metadata={"path": path_str},
        )
        return new_json, op

    @staticmethod
    def delete_key(json_str: str, path_str: str) -> Tuple[str, PatchOperation]:
        """Deletes a key at nested JSON path."""
        data = json.loads(json_str)
        tokens = JsonOperations.parse_path(path_str)
        if not tokens:
            raise ValueError("Empty JSON path")

        curr = data
        for token in tokens[:-1]:
            if isinstance(curr, dict) and token in curr:
                curr = curr[token]
            elif isinstance(curr, list) and isinstance(token, int) and token < len(curr):
                curr = curr[token]
            else:
                # Key doesn't exist
                return json_str, PatchOperation(PatchOperationType.DELETE, f"json:{path_str}", None, None)

        last = tokens[-1]
        old_val = None
        if isinstance(curr, dict) and last in curr:
            old_val = curr.pop(last)
        elif isinstance(curr, list) and isinstance(last, int) and last < len(curr):
            old_val = curr.pop(last)

        new_json = json.dumps(data, indent=2)
        op = PatchOperation(
            op_type=PatchOperationType.DELETE,
            target_selector=f"json:{path_str}",
            old_value=json.dumps(old_val),
            new_value=None,
            metadata={"path": path_str},
        )
        return new_json, op


class CsvOperations:
    """Safe, structured CSV manipulator."""

    @staticmethod
    def rename_column(csv_str: str, old_name: str, new_name: str) -> Tuple[str, PatchOperation]:
        reader = csv.reader(io.StringIO(csv_str))
        rows = list(reader)
        if not rows:
            return csv_str, PatchOperation(PatchOperationType.REPLACE, "csv", None, None)

        header = rows[0]
        if old_name in header:
            idx = header.index(old_name)
            header[idx] = new_name

        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerows(rows)
        new_csv = out.getvalue()

        op = PatchOperation(
            op_type=PatchOperationType.REPLACE,
            target_selector=f'csv:column:"{old_name}"',
            old_value=old_name,
            new_value=new_name,
            metadata={"action": "rename_column"},
        )
        return new_csv, op

    @staticmethod
    def add_column(csv_str: str, col_name: str, default_val: str = "") -> Tuple[str, PatchOperation]:
        reader = csv.reader(io.StringIO(csv_str))
        rows = list(reader)
        if not rows:
            return f"{col_name}\n", PatchOperation(PatchOperationType.ADD, f"csv:column:{col_name}", None, col_name)

        rows[0].append(col_name)
        for row in rows[1:]:
            row.append(default_val)

        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerows(rows)
        new_csv = out.getvalue()

        op = PatchOperation(
            op_type=PatchOperationType.ADD,
            target_selector=f'csv:column:"{col_name}"',
            old_value=None,
            new_value=col_name,
        )
        return new_csv, op

    @staticmethod
    def remove_column(csv_str: str, col_name: str) -> Tuple[str, PatchOperation]:
        reader = csv.reader(io.StringIO(csv_str))
        rows = list(reader)
        if not rows or col_name not in rows[0]:
            return csv_str, PatchOperation(PatchOperationType.DELETE, f"csv:column:{col_name}", None, None)

        idx = rows[0].index(col_name)
        new_rows = [[c for i, c in enumerate(r) if i != idx] for r in rows]

        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerows(new_rows)
        new_csv = out.getvalue()

        op = PatchOperation(
            op_type=PatchOperationType.DELETE,
            target_selector=f'csv:column:"{col_name}"',
            old_value=col_name,
            new_value=None,
        )
        return new_csv, op

    @staticmethod
    def filter_rows(csv_str: str, col_name: str, condition: str, value: str) -> Tuple[str, PatchOperation]:
        """Filters rows where condition matches (e.g., != or == or contains)."""
        reader = csv.reader(io.StringIO(csv_str))
        rows = list(reader)
        if len(rows) <= 1 or col_name not in rows[0]:
            return csv_str, PatchOperation(PatchOperationType.DELETE, "csv:rows", None, None)

        header = rows[0]
        col_idx = header.index(col_name)
        val_clean = value.strip('\'"')

        filtered = [header]
        removed_count = 0
        for r in rows[1:]:
            if col_idx >= len(r):
                filtered.append(r)
                continue
            cell_val = r[col_idx]
            match = False
            if condition in ("==", "="):
                match = (cell_val == val_clean)
            elif condition in ("!=", "<>"):
                match = (cell_val != val_clean)
            elif condition == "contains":
                match = (val_clean in cell_val)

            # If condition is e.g. remove rows where country == "Unknown"
            if match:
                removed_count += 1
            else:
                filtered.append(r)

        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerows(filtered)
        new_csv = out.getvalue()

        op = PatchOperation(
            op_type=PatchOperationType.DELETE,
            target_selector=f'csv:rows where {col_name} {condition} "{val_clean}"',
            old_value=f"{removed_count} row(s)",
            new_value=None,
            metadata={"removed_count": removed_count},
        )
        return new_csv, op

    @staticmethod
    def sort_rows(csv_str: str, col_name: str, reverse: bool = False) -> Tuple[str, PatchOperation]:
        reader = csv.reader(io.StringIO(csv_str))
        rows = list(reader)
        if len(rows) <= 2 or col_name not in rows[0]:
            return csv_str, PatchOperation(PatchOperationType.MOVE, "csv:rows", None, None)

        header = rows[0]
        col_idx = header.index(col_name)

        def sort_key(row):
            val = row[col_idx] if col_idx < len(row) else ""
            try:
                return (0, float(val))
            except ValueError:
                return (1, val.lower())

        sorted_rows = [header] + sorted(rows[1:], key=sort_key, reverse=reverse)

        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerows(sorted_rows)
        new_csv = out.getvalue()

        op = PatchOperation(
            op_type=PatchOperationType.MOVE,
            target_selector=f'csv:sort by "{col_name}"',
            old_value="unsorted",
            new_value=f"sorted ({'desc' if reverse else 'asc'})",
        )
        return new_csv, op

    @staticmethod
    def deduplicate(csv_str: str) -> Tuple[str, PatchOperation]:
        reader = csv.reader(io.StringIO(csv_str))
        rows = list(reader)
        if len(rows) <= 1:
            return csv_str, PatchOperation(PatchOperationType.DELETE, "csv:duplicates", None, None)

        header = rows[0]
        seen = set()
        deduped = [header]
        removed_count = 0
        for r in rows[1:]:
            t = tuple(r)
            if t not in seen:
                seen.add(t)
                deduped.append(r)
            else:
                removed_count += 1

        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerows(deduped)
        new_csv = out.getvalue()

        op = PatchOperation(
            op_type=PatchOperationType.DELETE,
            target_selector="csv:duplicate rows",
            old_value=f"{removed_count} row(s)",
            new_value=None,
            metadata={"removed_count": removed_count},
        )
        return new_csv, op
