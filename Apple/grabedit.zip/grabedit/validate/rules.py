"""
Validation rules and integrity checks for GrabEdit.
"""

from __future__ import annotations

import ast
import csv
import io
import json
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import List, Optional, Tuple


@dataclass
class ValidationResult:
    is_valid: bool
    format_name: str
    errors: List[str]
    warnings: List[str]

    def summary(self) -> str:
        if self.is_valid:
            warn_msg = f" ({len(self.warnings)} warning(s))" if self.warnings else ""
            return f"✓ Valid {self.format_name}{warn_msg}"
        return f"✗ Invalid {self.format_name}: {'; '.join(self.errors)}"


class ValidationRules:
    """Deterministic format validators without code execution."""

    @staticmethod
    def validate_json(content: str) -> ValidationResult:
        try:
            json.loads(content)
            return ValidationResult(True, "JSON", [], [])
        except Exception as e:
            return ValidationResult(False, "JSON", [str(e)], [])

    @staticmethod
    def validate_xml(content: str) -> ValidationResult:
        try:
            ET.fromstring(content)
            return ValidationResult(True, "XML", [], [])
        except Exception as e:
            return ValidationResult(False, "XML", [str(e)], [])

    @staticmethod
    def validate_csv(content: str) -> ValidationResult:
        try:
            reader = csv.reader(io.StringIO(content))
            rows = list(reader)
            if not rows:
                return ValidationResult(True, "CSV", [], ["Empty CSV"])
            col_count = len(rows[0])
            mismatches = []
            for idx, r in enumerate(rows[1:], start=2):
                if len(r) != col_count:
                    mismatches.append(f"Row {idx} has {len(r)} columns (expected {col_count})")
                    if len(mismatches) >= 5:
                        break
            if mismatches:
                return ValidationResult(False, "CSV", mismatches, [])
            return ValidationResult(True, "CSV", [], [])
        except Exception as e:
            return ValidationResult(False, "CSV", [str(e)], [])

    @staticmethod
    def validate_python(content: str) -> ValidationResult:
        try:
            ast.parse(content)
            return ValidationResult(True, "Python", [], [])
        except SyntaxError as e:
            return ValidationResult(False, "Python", [f"Line {e.lineno}, Col {e.offset}: {e.msg}"], [])
        except Exception as e:
            return ValidationResult(False, "Python", [str(e)], [])

    @staticmethod
    def validate_yaml(content: str) -> ValidationResult:
        # Standard lightweight YAML validation (key-value / indentation checks)
        lines = content.splitlines()
        errors = []
        for idx, line in enumerate(lines, 1):
            if "\t" in line:
                errors.append(f"Line {idx}: Tabs are forbidden in YAML indentation")
        if errors:
            return ValidationResult(False, "YAML", errors, [])
        return ValidationResult(True, "YAML", [], [])

    @staticmethod
    def validate_plain_text(content: str) -> ValidationResult:
        try:
            content.encode("utf-8")
            return ValidationResult(True, "Plain Text", [], [])
        except UnicodeEncodeError as e:
            return ValidationResult(False, "Plain Text", [f"Encoding error: {e}"], [])
