"""
ValidationEngine for GrabEdit.
Coordinates format-specific rules based on file type or extension.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from grabedit.grab.detectors import GrabTargetType
from grabedit.grab.grabber import GrabObject
from grabedit.validate.rules import ValidationResult, ValidationRules


class ValidationEngine:
    """Dispatches validation according to target type and syntax."""

    @staticmethod
    def validate_content(content: str, target_type: Optional[GrabTargetType] = None, file_path: Optional[str] = None) -> ValidationResult:
        ext = Path(file_path).suffix.lower() if file_path else ""

        if target_type == GrabTargetType.JSON or ext == ".json":
            return ValidationRules.validate_json(content)
        elif target_type == GrabTargetType.XML or ext in (".xml", ".plist", ".svg"):
            return ValidationRules.validate_xml(content)
        elif target_type == GrabTargetType.CSV or ext == ".csv":
            return ValidationRules.validate_csv(content)
        elif ext == ".py":
            return ValidationRules.validate_python(content)
        elif target_type == GrabTargetType.YAML or ext in (".yaml", ".yml"):
            return ValidationRules.validate_yaml(content)
        else:
            return ValidationRules.validate_plain_text(content)

    @staticmethod
    def validate_object(obj: GrabObject) -> ValidationResult:
        return ValidationEngine.validate_content(
            content=obj.content or "",
            target_type=obj.type,
            file_path=obj.path,
        )
