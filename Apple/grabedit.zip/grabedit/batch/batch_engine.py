"""
Batch Editing Engine for GrabEdit.
Applies transformations across collections of matched files with independent validation and atomic isolation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from grabedit.edit.editor import EditEngine
from grabedit.execution.planner import ExecutionPlan
from grabedit.grab.grabber import GrabEngine, GrabObject
from grabedit.search.engine import SearchEngine


@dataclass
class BatchFileResult:
    path: str
    success: bool
    plan: Optional[ExecutionPlan] = None
    error: Optional[str] = None
    skipped: bool = False


@dataclass
class BatchExecutionReport:
    total_found: int
    total_processed: int
    successful_commits: int
    failed_validations: int
    results: List[BatchFileResult] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            "BATCH OPERATION REPORT",
            f"  Matched:    {self.total_found}",
            f"  Committed:  {self.successful_commits}",
            f"  Failed:     {self.failed_validations}",
        ]
        for r in self.results:
            status = "✓ Succeeded" if r.success else f"✗ Failed: {r.error}"
            lines.append(f"  {r.path}: {status}")
        return "\n".join(lines)


class BatchEngine:
    """Executes multi-file batch transformations safely."""

    def __init__(self):
        self.grab = GrabEngine()

    def process_pattern(
        self,
        glob_pattern: str,
        transform_fn: Callable[[EditEngine], None],
        root_dir: Path | str = ".",
        dry_run: bool = False,
    ) -> BatchExecutionReport:
        root = Path(root_dir).resolve()
        matched_files = [p for p in root.rglob(glob_pattern) if p.is_file() and ".grabedit" not in p.parts]

        results: List[BatchFileResult] = []
        success_count = 0
        fail_count = 0

        for file_path in matched_files:
            rel_str = str(file_path.relative_to(root))
            try:
                obj = self.grab.capture(str(file_path))
                editor = EditEngine(obj)
                # Apply transformation
                transform_fn(editor)
                plan = editor.plan()

                if not plan.is_safe:
                    fail_count += 1
                    results.append(BatchFileResult(
                        path=rel_str,
                        success=False,
                        plan=plan,
                        error=f"Validation failed: {'; '.join(plan.warnings)}",
                    ))
                    continue

                if dry_run:
                    results.append(BatchFileResult(
                        path=rel_str,
                        success=True,
                        plan=plan,
                    ))
                    success_count += 1
                else:
                    success, msg, _ = editor.commit(plan, force=True)
                    if success:
                        success_count += 1
                        results.append(BatchFileResult(path=rel_str, success=True, plan=plan))
                    else:
                        fail_count += 1
                        results.append(BatchFileResult(path=rel_str, success=False, plan=plan, error=msg))
            except Exception as e:
                fail_count += 1
                results.append(BatchFileResult(path=rel_str, success=False, error=str(e)))

        return BatchExecutionReport(
            total_found=len(matched_files),
            total_processed=len(matched_files),
            successful_commits=success_count,
            failed_validations=fail_count,
            results=results,
        )
