"""
Unit tests for security policies, protected paths, and atomic storage.
"""

import os
import tempfile
import unittest
from pathlib import Path

from grabedit.security.guard import SecurityGuard
from grabedit.storage.atomic import AtomicStorage, calculate_content_hash, calculate_hash


class TestSecurityAndAtomicStorage(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.guard = SecurityGuard()

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_protected_macos_paths(self):
        self.assertTrue(self.guard.is_protected_macos_path("/System/Library/CoreServices"))
        self.assertTrue(self.guard.is_protected_macos_path("/usr/bin/python3"))
        self.assertFalse(self.guard.is_protected_macos_path(self.root / "file.txt"))

    def test_sensitive_path_detection(self):
        is_sens, _ = self.guard.is_sensitive_path("/Users/dev/.ssh/id_ed25519")
        self.assertTrue(is_sens)

        is_sens, _ = self.guard.is_sensitive_path(self.root / ".env")
        self.assertTrue(is_sens)

        is_sens, _ = self.guard.is_sensitive_path(self.root / "normal.json")
        self.assertFalse(is_sens)

    def test_atomic_write_preserves_content_and_creates_backup(self):
        target = self.root / "important.conf"
        target.write_text("ORIGINAL CONFIG", encoding="utf-8")
        orig_hash = calculate_hash(target)

        success, new_hash, msg = AtomicStorage.atomic_write(
            target_path=target,
            content="PROPOSED NEW CONFIG",
            make_backup=True,
            backup_suffix=".bak",
        )

        self.assertTrue(success)
        self.assertEqual(target.read_text(encoding="utf-8"), "PROPOSED NEW CONFIG")

        # Verify backup exists
        backup_file = self.root / "important.conf.bak"
        self.assertTrue(backup_file.is_file())
        self.assertEqual(backup_file.read_text(encoding="utf-8"), "ORIGINAL CONFIG")

    def test_unicode_and_spaces_in_paths(self):
        unicode_target = self.root / "folder with spaces" / "файл_日本語_é.txt"
        unicode_target.parent.mkdir(parents=True, exist_ok=True)

        content = "Unicode content: 日本語, Español, emoji 🚀\n"
        success, new_hash, msg = AtomicStorage.atomic_write(
            target_path=unicode_target,
            content=content,
            make_backup=False,
        )
        self.assertTrue(success)
        self.assertEqual(unicode_target.read_text(encoding="utf-8"), content)


if __name__ == "__main__":
    unittest.main()
