"""
Tests for GrabEdit package.
"""
