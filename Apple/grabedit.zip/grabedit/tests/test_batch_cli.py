"""
Unit tests for batch operations, Mac Utility Studio plugin, and CLI execution.
"""

import tempfile
import unittest
from pathlib import Path

from grabedit.batch.batch_engine import BatchEngine
from grabedit.cli.main import main
from grabedit.edit.editor import EditEngine
from grabedit.plugins.mac_studio import EventBus, JobEngine, MacUtilityStudioBridge


class TestBatchAndPlugins(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_batch_isolation(self):
        # File 1: valid JSON
        f1 = self.root / "app1.json"
        f1.write_text('{"host": "old_val", "active": true}', encoding="utf-8")

        # File 2: valid JSON
        f2 = self.root / "app2.json"
        f2.write_text('{"host": "old_val", "active": false}', encoding="utf-8")

        # File 3: invalid JSON (should fail validation without corrupting 1 and 2)
        f3 = self.root / "broken.json"
        f3.write_text('{"host": "old_val", unclosed syntax: }', encoding="utf-8")

        batch = BatchEngine()

        def transform(editor: EditEngine):
            editor.replace("old_val", "new_val")

        report = batch.process_pattern("*.json", transform, root_dir=self.root, dry_run=False)

        self.assertEqual(report.total_found, 3)
        self.assertEqual(report.successful_commits, 2)
        self.assertEqual(report.failed_validations, 1)

        # Confirm f1 and f2 were updated safely
        self.assertIn("new_val", f1.read_text(encoding="utf-8"))
        self.assertIn("new_val", f2.read_text(encoding="utf-8"))
        # Confirm f3 was NOT corrupted
        self.assertIn("unclosed syntax", f3.read_text(encoding="utf-8"))

    def test_mac_utility_studio_bridge(self):
        bridge = MacUtilityStudioBridge()
        received_events = []

        bridge.event_bus.subscribe("job.submitted", lambda e: received_events.append(e))

        from grabedit.grab.grabber import GrabEngine
        obj = GrabEngine().capture("env")
        plan = EditEngine(obj).plan()

        job_id = bridge.jobs.submit_plan(plan, "Test Environment Task")
        self.assertTrue(job_id.startswith("job_"))
        self.assertEqual(len(received_events), 1)
        self.assertEqual(received_events[0].payload["job_id"], job_id)

    def test_cli_help(self):
        with self.assertRaises(SystemExit) as cm:
            main(["--help"])
        self.assertEqual(cm.exception.code, 0)


if __name__ == "__main__":
    unittest.main()
