"""
Unit tests for structured JSON and CSV mutations.
"""

import json
import unittest
from grabedit.edit.operations import CsvOperations, JsonOperations


class TestJsonCsvOperations(unittest.TestCase):
    def test_json_set_and_delete(self):
        initial = '{\n  "database": {\n    "host": "localhost",\n    "port": 5432\n  }\n}'
        # Set port
        new_json, op = JsonOperations.set_value(initial, "database.port", 5433)
        data = json.loads(new_json)
        self.assertEqual(data["database"]["port"], 5433)

        # Set new nested key
        new_json, op = JsonOperations.set_value(new_json, "features.experimental", False)
        data = json.loads(new_json)
        self.assertFalse(data["features"]["experimental"])

        # Delete key
        new_json, op = JsonOperations.delete_key(new_json, "database.host")
        data = json.loads(new_json)
        self.assertNotIn("host", data["database"])

    def test_csv_rename_column_and_filter(self):
        csv_data = "name,telephone,country\nAlice,123,UK\nBob,456,Unknown\nCharlie,789,US\n"
        # Rename column
        c1, op = CsvOperations.rename_column(csv_data, "telephone", "phone")
        self.assertIn("name,phone,country", c1)

        # Filter rows where country = "Unknown"
        c2, op = CsvOperations.filter_rows(c1, "country", "==", "Unknown")
        self.assertNotIn("Bob", c2)
        self.assertIn("Alice", c2)
        self.assertIn("Charlie", c2)

    def test_csv_sort_and_deduplicate(self):
        csv_data = "name,score\nCharlie,50\nAlice,90\nBob,80\nAlice,90\n"
        # Deduplicate
        deduped, op = CsvOperations.deduplicate(csv_data)
        rows = deduped.strip().splitlines()
        self.assertEqual(len(rows), 4)  # header + 3 unique rows

        # Sort by score reverse
        sorted_csv, op = CsvOperations.sort_rows(deduped, "score", reverse=True)
        self.assertTrue(sorted_csv.splitlines()[1].startswith("Alice,90"))


if __name__ == "__main__":
    unittest.main()
