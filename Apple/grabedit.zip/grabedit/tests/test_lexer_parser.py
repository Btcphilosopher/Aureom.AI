"""
Unit tests for lexer, parser, and AST generation.
"""

import unittest
from grabedit.parser.ast_nodes import (
    DoFindStatement,
    DoRenameStatement,
    GrabStatement,
    ReplaceStatement,
    SaveStatement,
    SetStatement,
    ValidateStatement,
)
from grabedit.parser.lexer import Lexer
from grabedit.parser.parser import parse_script


class TestLexerParser(unittest.TestCase):
    def test_lexer_tokenizes_basic_keywords(self):
        script = 'grab "config.json"\nset database.host = "localhost"\nvalidate json\nsave'
        tokens = Lexer.tokenize(script)
        types = [t.type for t in tokens if t.type != "NEWLINE" and t.type != "EOF"]
        self.assertEqual(types, ["GRAB", "STRING", "SET", "IDENT", "EQUALS", "STRING", "VALIDATE", "IDENT", "SAVE"])

    def test_parser_grab_script_ast(self):
        script = """
        grab ./config.json
        replace:
            "old_host"
        with:
            "new_host"
        set server.port = 8080
        validate json
        show diff
        save
        """
        ast = parse_script(script)
        self.assertEqual(len(ast.statements), 6)
        self.assertIsInstance(ast.statements[0], GrabStatement)
        self.assertEqual(ast.statements[0].target, "./config.json")

        self.assertIsInstance(ast.statements[1], ReplaceStatement)
        self.assertEqual(ast.statements[1].old_value, "old_host")
        self.assertEqual(ast.statements[1].new_value, "new_host")

        self.assertIsInstance(ast.statements[2], SetStatement)
        self.assertEqual(ast.statements[2].key_path, "server.port")
        self.assertEqual(ast.statements[2].value, "8080")

        self.assertIsInstance(ast.statements[3], ValidateStatement)
        self.assertEqual(ast.statements[3].target_format, "json")

        self.assertIsInstance(ast.statements[5], SaveStatement)

    def test_parser_do_find_and_rename(self):
        script = """
        do find all *.log files under ./logs
        do rename *.log to *.old
        """
        ast = parse_script(script)
        self.assertEqual(len(ast.statements), 2)
        self.assertIsInstance(ast.statements[0], DoFindStatement)
        self.assertEqual(ast.statements[0].filter_pattern, "*.log")
        self.assertEqual(ast.statements[0].root_dir, "./logs")

        self.assertIsInstance(ast.statements[1], DoRenameStatement)
        self.assertEqual(ast.statements[1].from_pattern, "*.log")
        self.assertEqual(ast.statements[1].to_pattern, "*.old")


if __name__ == "__main__":
    unittest.main()
