"""
Unit tests for DiffEngine, DirectoryDiffEngine, and Patch reversibility.
"""

import tempfile
import unittest
from pathlib import Path

from grabedit.diff.diff_engine import DiffEngine
from grabedit.diff.directory_diff import DirectoryDiffEngine
from grabedit.edit.patch import Patch, PatchOperation, PatchOperationType, PatchValidator


class TestDiffAndPatch(unittest.TestCase):
    def test_text_diff(self):
        orig = "line 1\nline 2\nline 3\n"
        prop = "line 1\nline 2 modified\nline 3\n"
        diff = DiffEngine.diff_text(orig, prop)
        self.assertIn("-line 2", diff)
        self.assertIn("+line 2 modified", diff)

    def test_json_key_diff(self):
        orig = '{"database": {"host": "localhost", "port": 5432}}'
        prop = '{"database": {"host": "127.0.0.1", "port": 5432, "ssl": true}}'
        unified, changes = DiffEngine.diff_json(orig, prop)
        self.assertTrue(any("host" in c for c in changes))
        self.assertTrue(any("ssl" in c for c in changes))

    def test_csv_diff(self):
        orig = "name,phone\nAlice,123\nBob,456\n"
        prop = "name,telephone\nAlice,123\nBob,456\nCharlie,789\n"
        unified, changes = DiffEngine.diff_csv(orig, prop)
        self.assertTrue(any("telephone" in c for c in changes))
        self.assertTrue(any("ADDED 1 row" in c for c in changes))

    def test_patch_reversibility(self):
        patch = Patch(
            target="test.txt",
            original_text="Old Text",
            proposed_text="New Text",
            operations=[
                PatchOperation(PatchOperationType.REPLACE, "text", "Old Text", "New Text")
            ],
        )
        self.assertTrue(patch.is_reversible)
        rev = patch.reverse()
        self.assertIsNotNone(rev)
        self.assertEqual(rev.original_text, "New Text")
        self.assertEqual(rev.proposed_text, "Old Text")
        self.assertEqual(rev.operations[0].new_value, "Old Text")

    def test_directory_diff(self):
        with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
            p1 = Path(d1)
            p2 = Path(d2)

            (p1 / "shared.txt").write_text("Hello", encoding="utf-8")
            (p2 / "shared.txt").write_text("Hello Modified", encoding="utf-8")

            (p1 / "deleted.txt").write_text("Gone", encoding="utf-8")
            (p2 / "created.txt").write_text("New", encoding="utf-8")

            res = DirectoryDiffEngine.compare_directories(p1, p2)
            self.assertIn("created.txt", res.added)
            self.assertIn("deleted.txt", res.removed)
            self.assertIn("shared.txt", res.modified)


if __name__ == "__main__":
    unittest.main()
