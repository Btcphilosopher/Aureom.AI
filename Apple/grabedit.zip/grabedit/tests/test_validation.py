"""
Unit tests for ValidationEngine: JSON, XML, CSV, Python AST, YAML, and encoding.
"""

import unittest
from grabedit.grab.detectors import GrabTargetType
from grabedit.validate.validator import ValidationEngine


class TestValidation(unittest.TestCase):
    def test_json_validation(self):
        valid = '{"a": 1, "b": [true, null]}'
        res = ValidationEngine.validate_content(valid, GrabTargetType.JSON)
        self.assertTrue(res.is_valid)

        invalid = '{"a": 1, "unclosed": }'
        res_inv = ValidationEngine.validate_content(invalid, GrabTargetType.JSON)
        self.assertFalse(res_inv.is_valid)

    def test_xml_validation(self):
        valid = "<root><child id='1'>Text</child></root>"
        self.assertTrue(ValidationEngine.validate_content(valid, GrabTargetType.XML).is_valid)

        invalid = "<root><unclosed></root>"
        self.assertFalse(ValidationEngine.validate_content(invalid, GrabTargetType.XML).is_valid)

    def test_python_ast_validation(self):
        valid = "def greet(name: str) -> str:\n    return f'Hello, {name}'\n"
        self.assertTrue(ValidationEngine.validate_content(valid, file_path="script.py").is_valid)

        invalid = "def broken(\n    return 42\n"
        res = ValidationEngine.validate_content(invalid, file_path="script.py")
        self.assertFalse(res.is_valid)
        self.assertTrue(len(res.errors) > 0)

    def test_yaml_tab_validation(self):
        # YAML forbids tabs
        invalid = "key:\n\tvalue: 1\n"
        res = ValidationEngine.validate_content(invalid, GrabTargetType.YAML)
        self.assertFalse(res.is_valid)


if __name__ == "__main__":
    unittest.main()
