"""
Unit tests for EditEngine, text transformations, AST pipelines, and regex engine.
"""

import re
import unittest
from grabedit.edit.editor import EditEngine
from grabedit.edit.transforms import (
    RemoveBlankLines,
    RemoveDuplicates,
    SortLines,
    TransformPipeline,
    TrimWhitespace,
)
from grabedit.grab.detectors import GrabTargetType
from grabedit.grab.grabber import GrabObject


class TestEditorTransforms(unittest.TestCase):
    def _make_obj(self, content: str) -> GrabObject:
        return GrabObject(
            id="test_obj",
            source="memory",
            type=GrabTargetType.TEXT,
            content=content,
        )

    def test_text_replacement(self):
        obj = self._make_obj("The quick brown fox jumps over the lazy dog.")
        editor = EditEngine(obj)
        editor.replace("fox", "cat")
        self.assertEqual(editor.current_text, "The quick brown cat jumps over the lazy dog.")
        self.assertEqual(len(editor.operations), 1)

    def test_regex_replacement(self):
        obj = self._make_obj("DEBUG: Initializing\nINFO: Running\nDEBUG: Exiting\n")
        editor = EditEngine(obj)
        editor.replace_regex(r"^DEBUG:.*\n?", "", flags=re.MULTILINE)
        self.assertEqual(editor.current_text, "INFO: Running\n")

    def test_line_operations(self):
        content = "Line 1\nLine 2\nLine 3\nLine 4\n"
        obj = self._make_obj(content)
        editor = EditEngine(obj)
        editor.delete_lines(2, 3)
        self.assertEqual(editor.current_text, "Line 1\nLine 4\n")

        editor.insert_line(2, "Inserted Line")
        self.assertIn("Inserted Line\nLine 4", editor.current_text)

    def test_transform_pipeline_ast(self):
        dirty_text = "  banana  \n\n  apple  \n  banana  \n  cherry  \n"
        obj = self._make_obj(dirty_text)
        editor = EditEngine(obj)

        pipeline = TransformPipeline(operations=[
            TrimWhitespace(),
            RemoveBlankLines(),
            SortLines(),
            RemoveDuplicates(),
        ])
        editor.apply_pipeline(pipeline)

        lines = editor.current_text.strip().splitlines()
        self.assertEqual(lines, ["apple", "banana", "cherry"])


if __name__ == "__main__":
    unittest.main()
