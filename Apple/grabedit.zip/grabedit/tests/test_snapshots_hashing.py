"""
Unit tests for SnapshotEngine, SHA-256 verification, and rollback restore.
"""

import tempfile
import unittest
from pathlib import Path

from grabedit.snapshots.store import SnapshotEngine
from grabedit.storage.atomic import calculate_hash


class TestSnapshotsAndHashing(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.snap_store = self.root / ".snapshots"
        self.engine = SnapshotEngine(base_dir=self.snap_store)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_create_and_restore_snapshot(self):
        target_file = self.root / "config.json"
        original_content = '{\n  "version": "1.0"\n}\n'
        target_file.write_text(original_content, encoding="utf-8")
        orig_hash = calculate_hash(target_file)

        # 1. Create snapshot
        snap = self.engine.create_snapshot(target_file, target_type="JSON")
        self.assertIsNotNone(snap)
        self.assertEqual(snap.sha256, orig_hash)

        # 2. Corrupt or mutate the file
        target_file.write_text('{\n  "version": "MUTATED"\n}\n', encoding="utf-8")
        mutated_hash = calculate_hash(target_file)
        self.assertNotEqual(orig_hash, mutated_hash)

        # 3. Restore with force_yes=True
        ok, msg = self.engine.restore_snapshot(snap.snapshot_id, force_yes=True)
        self.assertTrue(ok)
        restored_content = target_file.read_text(encoding="utf-8")
        self.assertEqual(restored_content, original_content)
        self.assertEqual(calculate_hash(target_file), orig_hash)

    def test_snapshot_integrity_verification(self):
        target_file = self.root / "data.txt"
        target_file.write_text("Integrity Check Data", encoding="utf-8")
        snap = self.engine.create_snapshot(target_file)

        # Tamper with snapshot original file on disk
        snap_dirs = list(self.snap_store.rglob(snap.snapshot_id))
        self.assertTrue(len(snap_dirs) > 0)
        orig_file = snap_dirs[0] / "original"
        orig_file.write_text("TAMPERED DATA", encoding="utf-8")

        # Expect integrity error
        with self.assertRaises(ValueError):
            self.engine.get_snapshot(snap.snapshot_id)


if __name__ == "__main__":
    unittest.main()
