"""
Unit tests for GrabEngine, target detection, and sources.
"""

import tempfile
import unittest
from pathlib import Path

from grabedit.grab.detectors import GrabTargetType, TargetDetector
from grabedit.grab.grabber import GrabEngine


class TestGrabber(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.root = Path(self.temp_dir.name)
        self.grab = GrabEngine()

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_detector_types(self):
        self.assertEqual(TargetDetector.detect("config.json")[0], GrabTargetType.JSON)
        self.assertEqual(TargetDetector.detect("customers.csv")[0], GrabTargetType.CSV)
        self.assertEqual(TargetDetector.detect("system.log")[0], GrabTargetType.LOG)
        self.assertEqual(TargetDetector.detect("log /var/log/sys")[0], GrabTargetType.LOG)
        self.assertEqual(TargetDetector.detect("--output 'echo 123'")[0], GrabTargetType.COMMAND_OUTPUT)
        self.assertEqual(TargetDetector.detect("process 9999")[0], GrabTargetType.PROCESS)
        self.assertEqual(TargetDetector.detect("env")[0], GrabTargetType.ENVIRONMENT_INFORMATION)

    def test_grab_file_and_snapshot(self):
        test_file = self.root / "sample.txt"
        test_file.write_text("Line 1\nLine 2\nLine 3\n", encoding="utf-8")

        obj = self.grab.capture(str(test_file))
        self.assertEqual(obj.type, GrabTargetType.TEXT)
        self.assertEqual(obj.size, test_file.stat().st_size)
        self.assertIn("Line 1", obj.content)
        self.assertIsNotNone(obj.hash)
        self.assertIsNotNone(obj.snapshot_id)

    def test_grab_command_output(self):
        obj = self.grab.capture("--output 'echo GRABEDIT_TEST_OK'")
        self.assertEqual(obj.type, GrabTargetType.COMMAND_OUTPUT)
        self.assertIn("GRABEDIT_TEST_OK", obj.content)
        self.assertEqual(obj.metadata.get("exit_code"), 0)

    def test_grab_environment_info(self):
        obj = self.grab.capture("env")
        self.assertEqual(obj.type, GrabTargetType.ENVIRONMENT_INFORMATION)
        self.assertIn("python_version", obj.content)


if __name__ == "__main__":
    unittest.main()
