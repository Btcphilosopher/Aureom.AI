"""
Directory Diff Engine for GrabEdit.
Compares two directories or directory snapshots into: ADDED, REMOVED, MODIFIED, UNCHANGED.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

from grabedit.storage.atomic import calculate_hash


@dataclass
class DirectoryDiffResult:
    added: List[str] = field(default_factory=list)
    removed: List[str] = field(default_factory=list)
    modified: List[str] = field(default_factory=list)
    unchanged: List[str] = field(default_factory=list)

    @property
    def has_differences(self) -> bool:
        return bool(self.added or self.removed or self.modified)

    def summary(self) -> str:
        lines = [
            f"DIRECTORY DIFF SUMMARY:",
            f"  [+] Added:     {len(self.added)}",
            f"  [-] Removed:   {len(self.removed)}",
            f"  [~] Modified:  {len(self.modified)}",
            f"  [=] Unchanged: {len(self.unchanged)}",
        ]
        if self.added:
            lines.append("\nAdded items:")
            for p in self.added[:10]:
                lines.append(f"  + {p}")
            if len(self.added) > 10:
                lines.append(f"  ... and {len(self.added) - 10} more")

        if self.removed:
            lines.append("\nRemoved items:")
            for p in self.removed[:10]:
                lines.append(f"  - {p}")
            if len(self.removed) > 10:
                lines.append(f"  ... and {len(self.removed) - 10} more")

        if self.modified:
            lines.append("\nModified items:")
            for p in self.modified[:10]:
                lines.append(f"  ~ {p}")
            if len(self.modified) > 10:
                lines.append(f"  ... and {len(self.modified) - 10} more")

        return "\n".join(lines)


class DirectoryDiffEngine:
    """Computes directory level diffs efficiently."""

    @staticmethod
    def compare_directories(dir_a: Path | str, dir_b: Path | str) -> DirectoryDiffResult:
        path_a = Path(dir_a).resolve()
        path_b = Path(dir_b).resolve()

        def scan_dir(root: Path) -> Dict[str, str]:
            file_map = {}
            if not root.is_dir():
                return file_map
            for item in root.rglob("*"):
                if item.is_file() and ".grabedit" not in item.parts:
                    rel = str(item.relative_to(root))
                    file_map[rel] = calculate_hash(item)
            return file_map

        map_a = scan_dir(path_a)
        map_b = scan_dir(path_b)

        keys_a = set(map_a.keys())
        keys_b = set(map_b.keys())

        added = sorted(list(keys_b - keys_a))
        removed = sorted(list(keys_a - keys_b))
        common = sorted(list(keys_a & keys_b))

        modified = []
        unchanged = []
        for k in common:
            if map_a[k] != map_b[k]:
                modified.append(k)
            else:
                unchanged.append(k)

        return DirectoryDiffResult(
            added=added,
            removed=removed,
            modified=modified,
            unchanged=unchanged,
        )
