"""
Diff Engine for GrabEdit.
Provides 3-way diffs: ORIGINAL -> CURRENT -> PROPOSED.
Supports text line-by-line diff, JSON key-level diff, and CSV row/col diff.
"""

from __future__ import annotations

import csv
import difflib
import io
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from grabedit.diff.directory_diff import DirectoryDiffEngine, DirectoryDiffResult


@dataclass
class StructuredDiffResult:
    diff_type: str  # TEXT, JSON, CSV, DIRECTORY
    original_hash: str
    current_hash: str
    proposed_hash: str
    unified_diff: str = ""
    detailed_changes: List[str] = field(default_factory=list)
    has_changes: bool = False

    def format_3way_display(self) -> str:
        lines = [
            "DIFF VIEW",
            "────────────────────────────────────────",
            "ORIGINAL",
            f"  SHA256: {self.original_hash}",
            "    ↓",
            "CURRENT",
            f"  SHA256: {self.current_hash}",
            "    ↓",
            "PROPOSED",
            f"  SHA256: {self.proposed_hash}",
            "────────────────────────────────────────",
        ]
        if self.detailed_changes:
            lines.append("STRUCTURED CHANGES:")
            for c in self.detailed_changes:
                lines.append(f"  • {c}")
            lines.append("────────────────────────────────────────")

        if self.unified_diff:
            lines.append(self.unified_diff)
        elif not self.has_changes:
            lines.append("No changes detected between stages.")

        return "\n".join(lines)


class DiffEngine:
    """Core diff engine supporting text, JSON, CSV, and 3-way stage comparisons."""

    @staticmethod
    def diff_text(original: str, proposed: str, from_name: str = "ORIGINAL", to_name: str = "PROPOSED") -> str:
        """Line-by-line diff."""
        orig_lines = original.splitlines(keepends=True)
        prop_lines = proposed.splitlines(keepends=True)
        diff = difflib.unified_diff(
            orig_lines,
            prop_lines,
            fromfile=from_name,
            tofile=to_name,
            n=3,
        )
        return "".join(diff)

    @staticmethod
    def diff_json(orig_str: str, prop_str: str) -> Tuple[str, List[str]]:
        """Key-level JSON diff."""
        try:
            d_orig = json.loads(orig_str)
            d_prop = json.loads(prop_str)
        except Exception:
            return DiffEngine.diff_text(orig_str, prop_str), ["Invalid JSON: fallback to text diff"]

        changes: List[str] = []

        def compare_dicts(a: Any, b: Any, prefix: str = ""):
            if isinstance(a, dict) and isinstance(b, dict):
                keys_a = set(a.keys())
                keys_b = set(b.keys())
                for k in sorted(keys_a - keys_b):
                    changes.append(f"REMOVED key: {prefix}{k} = {json.dumps(a[k])}")
                for k in sorted(keys_b - keys_a):
                    changes.append(f"ADDED key: {prefix}{k} = {json.dumps(b[k])}")
                for k in sorted(keys_a & keys_b):
                    compare_dicts(a[k], b[k], f"{prefix}{k}.")
            elif isinstance(a, list) and isinstance(b, list):
                if len(a) != len(b):
                    changes.append(f"MODIFIED list {prefix[:-1]}: length changed from {len(a)} to {len(b)}")
                for i, (item_a, item_b) in enumerate(zip(a, b)):
                    compare_dicts(item_a, item_b, f"{prefix}[{i}].")
            else:
                if a != b:
                    changes.append(f"MODIFIED value at {prefix[:-1]}: {json.dumps(a)} → {json.dumps(b)}")

        compare_dicts(d_orig, d_prop)
        unified = DiffEngine.diff_text(
            json.dumps(d_orig, indent=2) + "\n",
            json.dumps(d_prop, indent=2) + "\n",
            "ORIGINAL JSON",
            "PROPOSED JSON",
        )
        return unified, changes

    @staticmethod
    def diff_csv(orig_str: str, prop_str: str) -> Tuple[str, List[str]]:
        """Row/column level CSV diff."""
        r_orig = list(csv.reader(io.StringIO(orig_str)))
        r_prop = list(csv.reader(io.StringIO(prop_str)))
        changes: List[str] = []

        if not r_orig and not r_prop:
            return "", []

        h_orig = r_orig[0] if r_orig else []
        h_prop = r_prop[0] if r_prop else []

        if h_orig != h_prop:
            added_cols = [c for c in h_prop if c not in h_orig]
            removed_cols = [c for c in h_orig if c not in h_prop]
            if added_cols:
                changes.append(f"ADDED columns: {', '.join(added_cols)}")
            if removed_cols:
                changes.append(f"REMOVED columns: {', '.join(removed_cols)}")

        rows_diff = len(r_prop) - len(r_orig)
        if rows_diff > 0:
            changes.append(f"ADDED {rows_diff} row(s)")
        elif rows_diff < 0:
            changes.append(f"REMOVED {abs(rows_diff)} row(s)")

        unified = DiffEngine.diff_text(orig_str, prop_str, "ORIGINAL CSV", "PROPOSED CSV")
        return unified, changes

    @staticmethod
    def three_way_diff(
        original: str,
        current: str,
        proposed: str,
        diff_type: str = "TEXT",
    ) -> StructuredDiffResult:
        """3-way diff between ORIGINAL -> CURRENT -> PROPOSED."""
        import hashlib
        h_orig = hashlib.sha256(original.encode("utf-8")).hexdigest()[:12]
        h_curr = hashlib.sha256(current.encode("utf-8")).hexdigest()[:12]
        h_prop = hashlib.sha256(proposed.encode("utf-8")).hexdigest()[:12]

        changes: List[str] = []
        if diff_type == "JSON":
            unified, changes = DiffEngine.diff_json(original, proposed)
        elif diff_type == "CSV":
            unified, changes = DiffEngine.diff_csv(original, proposed)
        else:
            unified = DiffEngine.diff_text(original, proposed)

        return StructuredDiffResult(
            diff_type=diff_type,
            original_hash=h_orig,
            current_hash=h_curr,
            proposed_hash=h_prop,
            unified_diff=unified,
            detailed_changes=changes,
            has_changes=bool(unified.strip() or changes),
        )
