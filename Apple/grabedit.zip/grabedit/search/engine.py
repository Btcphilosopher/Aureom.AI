"""
Fast streaming local search engine for GrabEdit.
Searches files, lines, columns, and matching text without loading entire files into memory.
"""

from __future__ import annotations

import fnmatch
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Generator, List, Optional


@dataclass
class SearchMatch:
    file_path: str
    line_number: int
    column_number: int
    matched_text: str
    line_content: str

    def format_line(self) -> str:
        return f"{self.file_path}:{self.line_number}:{self.column_number}: {self.line_content}"


class SearchEngine:
    """Streams file searches with line and column accuracy."""

    @staticmethod
    def search(
        query: str,
        target_dir: Path | str = ".",
        file_glob: str = "*",
        is_regex: bool = False,
        case_sensitive: bool = False,
        max_matches: int = 200,
    ) -> List[SearchMatch]:
        root = Path(target_dir).resolve()
        matches: List[SearchMatch] = []

        if is_regex:
            flags = 0 if case_sensitive else re.IGNORECASE
            try:
                pattern = re.compile(query, flags)
            except re.error as e:
                raise ValueError(f"Invalid search regex: {e}")
        else:
            q_lower = query if case_sensitive else query.lower()

        # Iterate files
        for root_dir, dirs, files in os.walk(root):
            # Exclude .git, .grabedit, node_modules
            dirs[:] = [d for d in dirs if d not in (".git", ".grabedit", "node_modules", ".angular", "dist")]

            for fname in files:
                if not fnmatch.fnmatch(fname, file_glob):
                    continue

                full_path = Path(root_dir) / fname
                try:
                    # Stream lines
                    with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
                        for line_idx, line in enumerate(f, start=1):
                            line_clean = line.rstrip("\r\n")

                            if is_regex:
                                for m in pattern.finditer(line_clean):
                                    matches.append(SearchMatch(
                                        file_path=str(full_path.relative_to(root)),
                                        line_number=line_idx,
                                        column_number=m.start() + 1,
                                        matched_text=m.group(),
                                        line_content=line_clean,
                                    ))
                                    if len(matches) >= max_matches:
                                        return matches
                            else:
                                haystack = line_clean if case_sensitive else line_clean.lower()
                                start = 0
                                while True:
                                    pos = haystack.find(q_lower, start)
                                    if pos == -1:
                                        break
                                    matches.append(SearchMatch(
                                        file_path=str(full_path.relative_to(root)),
                                        line_number=line_idx,
                                        column_number=pos + 1,
                                        matched_text=line_clean[pos : pos + len(query)],
                                        line_content=line_clean,
                                    ))
                                    if len(matches) >= max_matches:
                                        return matches
                                    start = pos + max(1, len(query))
                except Exception:
                    continue

        return matches
