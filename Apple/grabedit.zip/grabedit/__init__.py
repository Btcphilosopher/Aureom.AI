"""
GrabEdit — Advanced Grab / Edit Command System for macOS Terminal.
"""

from grabedit.diff.diff_engine import DiffEngine, StructuredDiffResult
from grabedit.diff.directory_diff import DirectoryDiffEngine, DirectoryDiffResult
from grabedit.edit.editor import EditEngine
from grabedit.edit.patch import Patch, PatchOperation, PatchOperationType, PatchSet, PatchValidator
from grabedit.edit.transforms import TransformNode, TransformPipeline
from grabedit.execution.executor import Executor
from grabedit.execution.planner import ExecutionPlan, ExecutionPlanner
from grabedit.grab.detectors import GrabTargetType, TargetDetector
from grabedit.grab.grabber import GrabEngine, GrabObject
from grabedit.history.audit import AuditEntry, AuditLogger
from grabedit.inspect.inspector import Inspector
from grabedit.inspect.syntax import CodeAnalysis, SyntaxAnalyzer
from grabedit.plugins.mac_studio import EventBus, JobEngine, MacUtilityStudioBridge, ReportEngine
from grabedit.snapshots.store import SnapshotEngine, SnapshotMetadata
from grabedit.storage.atomic import AtomicStorage, calculate_content_hash, calculate_hash
from grabedit.validate.validator import ValidationEngine, ValidationResult

__version__ = "1.0.0"

__all__ = [
    "GrabEngine",
    "GrabObject",
    "GrabTargetType",
    "EditEngine",
    "DiffEngine",
    "ValidationEngine",
    "ExecutionPlanner",
    "ExecutionPlan",
    "Executor",
    "SnapshotEngine",
    "SnapshotMetadata",
    "Patch",
    "PatchOperation",
    "PatchOperationType",
    "PatchSet",
    "PatchValidator",
    "TransformPipeline",
    "TransformNode",
    "DirectoryDiffEngine",
    "DirectoryDiffResult",
    "Inspector",
    "SyntaxAnalyzer",
    "CodeAnalysis",
    "AtomicStorage",
    "calculate_hash",
    "calculate_content_hash",
    "AuditLogger",
    "AuditEntry",
    "MacUtilityStudioBridge",
    "JobEngine",
    "EventBus",
    "ReportEngine",
]
