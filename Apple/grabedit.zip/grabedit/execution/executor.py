"""
Executor for GrabEdit.
Executes ExecutionPlans atomically with verification, snapshot creation, and audit logging.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from grabedit.execution.planner import ExecutionPlan
from grabedit.history.audit import AuditLogger
from grabedit.snapshots.store import SnapshotEngine
from grabedit.storage.atomic import AtomicStorage


class Executor:
    """Executes validated plans with guaranteed atomic writes and audit logging."""

    def __init__(
        self,
        snapshot_engine: Optional[SnapshotEngine] = None,
        audit_logger: Optional[AuditLogger] = None,
    ):
        self.snapshots = snapshot_engine or SnapshotEngine()
        self.audit = audit_logger or AuditLogger()

    def execute(self, plan: ExecutionPlan, force_confirm: bool = False) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Executes the plan.
        Returns: (success, message, execution_details)
        """
        if not plan.is_safe:
            return False, f"Execution Blocked: Plan failed safety or validation checks: {'; '.join(plan.warnings)}", {}

        if plan.requires_confirmation and not force_confirm:
            return False, (
                f"CONFIRMATION_REQUIRED:\n"
                f"{plan.summary()}\n\n"
                f"DIFF PREVIEW:\n{plan.patch.unified_diff}\n"
                f"Execute changes? Pass confirmation to proceed."
            ), {"requires_confirmation": True}

        target = Path(plan.target).resolve()

        # 1. Guarantee a pre-mutation snapshot exists
        snap_id = plan.rollback_snapshot_id
        if not snap_id and target.exists():
            snap_meta = self.snapshots.create_snapshot(target, target_type="FILE")
            snap_id = snap_meta.snapshot_id if snap_meta else None

        # 2. Atomic Replace
        success, new_hash, msg = AtomicStorage.atomic_write(
            target_path=target,
            content=plan.patch.proposed_text,
            make_backup=True,
        )

        op_names = ", ".join([op.target_selector for op in plan.patch.operations]) or "text edit"

        # 3. Audit Log
        status_str = "COMPLETED" if success else "FAILED"
        self.audit.record(
            user_action="EDIT_COMMIT",
            target=str(target),
            operation=op_names,
            original_hash=plan.patch.original_hash,
            new_hash=new_hash if success else "N/A",
            status=status_str,
            details={
                "plan_id": plan.plan_id,
                "snapshot_id": snap_id,
                "operations_count": len(plan.patch.operations),
            },
        )

        if not success:
            # Attempt rollback if snapshot exists
            if snap_id:
                self.snapshots.restore_snapshot(snap_id, force_yes=True)
            return False, f"Commit Failed (Rolled back): {msg}", {}

        return True, f"Successfully committed plan {plan.plan_id} to '{target.name}'. New SHA256: {new_hash[:12]}...", {
            "new_hash": new_hash,
            "snapshot_id": snap_id,
            "plan_id": plan.plan_id,
        }
