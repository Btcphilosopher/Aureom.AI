"""
Execution Sandbox and Dry-Run Verification.
"""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any, Callable, Dict, Tuple

from grabedit.edit.patch import Patch
from grabedit.validate.validator import ValidationEngine, ValidationResult


class ExecutionSandbox:
    """Executes transformations in an isolated virtual sandbox for validation."""

    @staticmethod
    def test_patch(patch: Patch, file_path: str) -> Tuple[bool, ValidationResult]:
        """Validates proposed text against format rules before touching disk."""
        validation = ValidationEngine.validate_content(
            content=patch.proposed_text,
            file_path=file_path,
        )
        return validation.is_valid, validation
