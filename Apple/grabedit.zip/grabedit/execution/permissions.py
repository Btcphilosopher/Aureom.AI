"""
Permissions and Confirmation Checker for GrabEdit.
Determines whether an operation is destructive or privileged and requires explicit confirmation.
"""

from __future__ import annotations

from typing import List, Tuple

from grabedit.edit.patch import Patch, PatchOperationType
from grabedit.security.guard import SecurityGuard


class PermissionManager:
    """Manages safety checks, destructive operation warnings, and confirmation gating."""

    def __init__(self):
        self.guard = SecurityGuard()

    def check_operation_safety(
        self,
        target_path: str,
        patch: Patch,
        is_batch: bool = False,
        is_process_kill: bool = False,
    ) -> Tuple[bool, List[str], bool]:
        """
        Returns (is_allowed, warnings, requires_confirmation).
        If is_allowed is False, the operation is strictly forbidden.
        """
        warnings: List[str] = []
        requires_confirmation = False

        # 1. Path permissions
        if target_path:
            is_valid, msg = self.guard.validate_write_permission(target_path)
            if not is_valid:
                return False, [msg], False

            is_sens, sens_msg = self.guard.is_sensitive_path(target_path)
            if is_sens:
                warnings.append(f"WARNING: {sens_msg}")
                requires_confirmation = True

        # 2. Destructive operations (deleting more than 5 lines or deleting files)
        delete_ops = [op for op in patch.operations if op.op_type == PatchOperationType.DELETE]
        if delete_ops:
            requires_confirmation = True
            warnings.append(f"Operation involves {len(delete_ops)} deletion(s).")

        # 3. Batch operations always require explicit preview & confirm
        if is_batch:
            requires_confirmation = True
            warnings.append("Batch operation across multiple files requires confirmation.")

        # 4. Process termination
        if is_process_kill:
            requires_confirmation = True
            warnings.append("Process termination is a privileged destructive action.")

        return True, warnings, requires_confirmation
