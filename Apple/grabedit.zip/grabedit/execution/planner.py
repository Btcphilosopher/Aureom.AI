"""
Execution Planner for GrabEdit.
Constructs deterministic ExecutionPlans with validations, patches, diffs, and confirmation rules.
"""

from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from grabedit.edit.patch import Patch, PatchOperation
from grabedit.execution.permissions import PermissionManager
from grabedit.execution.sandbox import ExecutionSandbox
from grabedit.validate.validator import ValidationResult


@dataclass
class ExecutionPlan:
    plan_id: str
    target: str
    patch: Patch
    validation: ValidationResult
    warnings: List[str] = field(default_factory=list)
    requires_confirmation: bool = False
    is_safe: bool = True
    rollback_snapshot_id: Optional[str] = None

    def summary(self) -> str:
        lines = [
            f"EXECUTION PLAN: [{self.plan_id}]",
            f"Target:   {self.target}",
            f"Valid:    {self.validation.summary()}",
            f"Safe:     {'YES' if self.is_safe else 'NO (BLOCKED)'}",
            f"Changes:  {len(self.patch.operations)} operation(s)",
            f"Base:     {self.patch.original_hash[:10]}... → {self.patch.proposed_hash[:10]}...",
        ]
        if self.warnings:
            lines.append("Warnings:")
            for w in self.warnings:
                lines.append(f"  ! {w}")
        if self.requires_confirmation:
            lines.append("Status:   AWAITING EXPLICIT USER CONFIRMATION")
        else:
            lines.append("Status:   READY TO COMMIT")
        return "\n".join(lines)


class ExecutionPlanner:
    """Plans and evaluates execution safety before disk commit."""

    def __init__(self):
        self.permissions = PermissionManager()

    def plan(
        self,
        target_path: str,
        patch: Patch,
        rollback_snapshot_id: Optional[str] = None,
        is_batch: bool = False,
    ) -> ExecutionPlan:
        plan_id = f"plan_{uuid.uuid4().hex[:8]}"

        # 1. Test in Sandbox
        is_valid, validation = ExecutionSandbox.test_patch(patch, target_path)

        # 2. Check Permissions & Destructive thresholds
        is_allowed, warnings, requires_conf = self.permissions.check_operation_safety(
            target_path=target_path,
            patch=patch,
            is_batch=is_batch,
        )

        if not is_valid:
            warnings.extend(validation.errors)
            is_allowed = False

        return ExecutionPlan(
            plan_id=plan_id,
            target=target_path,
            patch=patch,
            validation=validation,
            warnings=warnings,
            requires_confirmation=requires_conf,
            is_safe=is_allowed and is_valid,
            rollback_snapshot_id=rollback_snapshot_id,
        )
