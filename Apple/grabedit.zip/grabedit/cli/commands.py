"""
CLI Command Implementations for GrabEdit.
Handles commands: grab, edit, inspect, diff, validate, hash, search, batch, restore, history, plan, run, do.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from grabedit.batch.batch_engine import BatchEngine
from grabedit.diff.diff_engine import DiffEngine
from grabedit.edit.editor import EditEngine
from grabedit.execution.planner import ExecutionPlanner
from grabedit.grab.detectors import GrabTargetType
from grabedit.grab.grabber import GrabEngine, GrabObject
from grabedit.history.audit import AuditLogger
from grabedit.inspect.inspector import Inspector
from grabedit.parser.ast_nodes import (
    DeleteStatement,
    DoFindStatement,
    DoRenameStatement,
    GrabStatement,
    ReplaceStatement,
    SaveStatement,
    SetStatement,
    ValidateStatement,
)
from grabedit.parser.parser import parse_script
from grabedit.search.engine import SearchEngine
from grabedit.snapshots.store import SnapshotEngine
from grabedit.storage.atomic import calculate_hash
from grabedit.validate.validator import ValidationEngine


class Commands:
    """Dispatches CLI actions for GrabEdit."""

    def __init__(self, dry_run: bool = False, verbose: bool = False, json_output: bool = False):
        self.dry_run = dry_run
        self.verbose = verbose
        self.json_output = json_output
        self.grab_engine = GrabEngine()
        self.snapshots = SnapshotEngine()
        self.audit = AuditLogger()

    def cmd_grab(self, target: str, interactive: bool = True) -> int:
        obj = self.grab_engine.capture(target)
        if self.json_output:
            print(json.dumps(obj.to_dict(), indent=2))
            return 0

        if interactive and sys.stdin.isatty():
            from grabedit.cli.interactive import InteractiveWorkspace
            ws = InteractiveWorkspace(obj)
            ws.run()
            return 0
        else:
            print(Inspector.format_terminal_card(obj))
            return 0

    def cmd_inspect(self, target: str) -> int:
        obj = self.grab_engine.capture(target, make_snapshot=False)
        report = Inspector.inspect(obj)
        if self.json_output:
            print(json.dumps(report, indent=2))
            return 0

        print(Inspector.format_terminal_card(obj))
        return 0

    def cmd_validate(self, target: str) -> int:
        obj = self.grab_engine.capture(target, make_snapshot=False)
        res = ValidationEngine.validate_object(obj)
        if self.json_output:
            print(json.dumps({"valid": res.is_valid, "format": res.format_name, "errors": res.errors, "warnings": res.warnings}, indent=2))
        else:
            print(res.summary())
        return 0 if res.is_valid else 1

    def cmd_hash(self, target: str, algorithm: str = "sha256") -> int:
        path = Path(target).resolve()
        if not path.is_file():
            print(f"Error: '{target}' is not a regular file.", file=sys.stderr)
            return 1
        h = calculate_hash(path, algorithm)
        if self.json_output:
            print(json.dumps({"target": str(path), "algorithm": algorithm.upper(), "hash": h}, indent=2))
        else:
            print(f"{algorithm.upper()}: {h}  {path.name}")
        return 0

    def cmd_diff(self, target: str) -> int:
        obj = self.grab_engine.capture(target)
        snaps = self.snapshots.list_snapshots(obj.path)
        orig_text = ""
        if snaps:
            _, raw_bytes = self.snapshots.get_snapshot(snaps[0].snapshot_id) or (None, b"")
            orig_text = raw_bytes.decode("utf-8", errors="replace")
        else:
            orig_text = obj.content or ""

        diff_res = DiffEngine.three_way_diff(
            original=orig_text,
            current=obj.content or "",
            proposed=obj.content or "",
            diff_type=obj.type.value if hasattr(obj.type, "value") else "TEXT",
        )

        if self.json_output:
            print(json.dumps({
                "original_hash": diff_res.original_hash,
                "current_hash": diff_res.current_hash,
                "proposed_hash": diff_res.proposed_hash,
                "diff": diff_res.unified_diff,
            }, indent=2))
        else:
            print(diff_res.format_3way_display())
        return 0

    def cmd_search(self, query: str, root_dir: str = ".", glob: str = "*") -> int:
        matches = SearchEngine.search(query, root_dir, glob)
        if self.json_output:
            print(json.dumps([m.__dict__ for m in matches], indent=2))
        else:
            print(f"SEARCH RESULTS for '{query}' (Found {len(matches)} match(es)):")
            for m in matches:
                print(f"  {m.format_line()}")
        return 0

    def cmd_restore(self, snapshot_id: Optional[str] = None, target: Optional[str] = None, force_yes: bool = False) -> int:
        if not snapshot_id:
            # List available
            snaps = self.snapshots.list_snapshots(target)
            if not snaps:
                print("No snapshots found.")
                return 0
            print("AVAILABLE SNAPSHOTS:")
            for s in snaps[:10]:
                print(f"  ID: {s.snapshot_id}  Date: {s.timestamp}  Target: {s.target_path}  SHA256: {s.sha256[:12]}...")
            return 0

        ok, msg = self.snapshots.restore_snapshot(snapshot_id, force_yes=force_yes)
        print(msg)
        return 0 if ok else 1

    def cmd_history(self, limit: int = 20) -> int:
        entries = self.audit.read_entries(limit)
        if self.json_output:
            print(json.dumps([e.__dict__ for e in entries], indent=2))
        else:
            print("AUDIT TRAIL:")
            for e in entries:
                print(e.format_text())
        return 0

    def cmd_run_script(self, script_path: str) -> int:
        path = Path(script_path).resolve()
        if not path.is_file():
            print(f"Script not found: {script_path}", file=sys.stderr)
            return 1

        script_text = path.read_text(encoding="utf-8")
        ast = parse_script(script_text)

        curr_obj = None
        editor = None

        print(f"Executing .grab script: {path.name} ({len(ast.statements)} AST statements)")
        for stmt in ast.statements:
            if isinstance(stmt, GrabStatement):
                curr_obj = self.grab_engine.capture(stmt.target)
                editor = EditEngine(curr_obj)
                print(f"→ GRAB {stmt.target} (Type: {curr_obj.type.value})")

            elif isinstance(stmt, ReplaceStatement):
                if not editor:
                    print("Error: replace statement before grab", file=sys.stderr)
                    return 1
                editor.replace(stmt.old_value, stmt.new_value)
                print(f"→ REPLACE \"{stmt.old_value}\" with \"{stmt.new_value}\"")

            elif isinstance(stmt, SetStatement):
                if not editor:
                    print("Error: set statement before grab", file=sys.stderr)
                    return 1
                editor.json_set(stmt.key_path, stmt.value)
                print(f"→ SET {stmt.key_path} = {stmt.value}")

            elif isinstance(stmt, ValidateStatement):
                if not editor or not curr_obj:
                    return 1
                res = ValidationEngine.validate_content(editor.current_text, curr_obj.type, curr_obj.path)
                print(f"→ VALIDATE: {res.summary()}")
                if not res.is_valid:
                    print(f"Execution halted due to validation failure.", file=sys.stderr)
                    return 1

            elif isinstance(stmt, SaveStatement):
                if not editor:
                    return 1
                plan = editor.plan()
                if self.dry_run:
                    print(f"→ DRY RUN SAVE: Plan {plan.plan_id} valid and ready.")
                else:
                    ok, msg, _ = editor.commit(plan, force=True)
                    print(f"→ SAVE: {msg}")

        return 0

    def cmd_do(self, tokens: List[str], force_yes: bool = False) -> int:
        """Handles 'grab do ...' advanced deterministic commands."""
        raw_cmd = " ".join(tokens).strip()

        # Check for find command: "find all .log files under ~/Projects"
        if raw_cmd.startswith("find all "):
            parts = raw_cmd.split()
            # e.g. find all *.log files under ~/Projects
            pat = parts[2] if len(parts) > 2 else "*"
            root = "."
            if "under" in parts:
                idx = parts.index("under")
                if idx + 1 < len(parts):
                    root = parts[idx + 1]
            root_p = Path(root).expanduser().resolve()
            matched = list(root_p.rglob(pat))
            print("FIND EXECUTION PLAN")
            print(f"ROOT:    {root_p}")
            print(f"FILTER:  {pat}")
            print(f"MATCHES: {len(matched)}")
            print("PLAN READY")
            for m in matched[:10]:
                print(f"  {m.relative_to(root_p)}")
            if len(matched) > 10:
                print(f"  ... and {len(matched) - 10} more")
            return 0

        # Check for rename command: "rename *.log to *.old"
        if raw_cmd.startswith("rename "):
            parts = raw_cmd.split()
            from_pat = parts[1]
            to_pat = parts[3] if len(parts) > 3 and parts[2] == "to" else ""
            root_p = Path(".").resolve()
            matched = [p for p in root_p.rglob(from_pat) if p.is_file()]

            print(f"{len(matched)} files matched")
            print("\nPREVIEW:")
            for p in matched[:10]:
                new_name = p.name.replace(from_pat.replace("*", ""), to_pat.replace("*", ""))
                print(f"{p.name} → {new_name}")

            if not force_yes:
                ans = input("\nExecute? [y/N]: ").strip().lower()
                if ans not in ("y", "yes"):
                    print("Aborted.")
                    return 0

            # Execute renames
            for p in matched:
                new_name = p.name.replace(from_pat.replace("*", ""), to_pat.replace("*", ""))
                p.rename(p.with_name(new_name))
            print("Renamed files successfully.")
            return 0

        print(f"Unrecognized 'grab do' command: '{raw_cmd}'.")
        print("Supported forms:")
        print("  grab do find all <pattern> under <directory>")
        print("  grab do rename <pattern> to <new_pattern>")
        return 1
