"""
Interactive Terminal Workspace for GrabEdit.
Provides interactive menu:
[e] Edit
[d] Diff
[v] Validate
[h] Hash
[s] Save
[r] Restore
[x] Execute
[q] Quit
"""

from __future__ import annotations

import sys
from typing import Optional

from grabedit.diff.diff_engine import DiffEngine
from grabedit.edit.editor import EditEngine
from grabedit.grab.detectors import GrabTargetType
from grabedit.grab.grabber import GrabObject
from grabedit.inspect.inspector import Inspector
from grabedit.snapshots.store import SnapshotEngine
from grabedit.storage.atomic import calculate_hash
from grabedit.validate.validator import ValidationEngine


class InteractiveWorkspace:
    """Provides interactive terminal session for a grabbed object."""

    def __init__(self, grab_obj: GrabObject, no_color: bool = False):
        self.obj = grab_obj
        self.editor = EditEngine(grab_obj)
        self.no_color = no_color
        self.snapshots = SnapshotEngine()

    def run(self):
        while True:
            # Print inspection card
            print("\n" + "=" * 50)
            print(Inspector.format_terminal_card(self.obj))
            print("=" * 50)

            try:
                choice = input("\ngrabedit> ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print("\nExiting GrabEdit.")
                break

            if choice in ("q", "quit", "exit"):
                print("Exiting GrabEdit.")
                break

            elif choice in ("e", "edit"):
                self._handle_edit_prompt()

            elif choice in ("d", "diff"):
                patch = self.editor.get_patch()
                print("\n--- DIFF VIEW ---")
                if patch.unified_diff:
                    print(patch.unified_diff)
                else:
                    print("No modifications currently pending.")

            elif choice in ("v", "validate"):
                res = ValidationEngine.validate_content(
                    self.editor.current_text,
                    self.obj.type,
                    self.obj.path,
                )
                print(f"\nValidation Result: {res.summary()}")

            elif choice in ("h", "hash"):
                cur_h = calculate_hash(self.obj.path) if self.obj.path else "N/A"
                print(f"\nOriginal Hash: SHA256: {self.obj.hash}")
                print(f"Current File:  SHA256: {cur_h}")
                prop_h = self.editor.get_patch().proposed_hash
                print(f"Proposed:      SHA256: {prop_h}")

            elif choice in ("s", "save", "x", "execute"):
                plan = self.editor.plan()
                print("\n" + plan.summary())
                if plan.patch.unified_diff:
                    print("\nDIFF PREVIEW:\n" + plan.patch.unified_diff)
                confirm = input("\nCommit and atomically save changes? [y/N]: ").strip().lower()
                if confirm in ("y", "yes"):
                    success, msg, _ = self.editor.commit(plan, force=True)
                    print(f"\n{'SUCCESS' if success else 'ERROR'}: {msg}")
                    if success:
                        self.obj.content = self.editor.current_text
                        self.obj.hash = plan.patch.proposed_hash
                else:
                    print("\nAborted save.")

            elif choice in ("r", "restore"):
                snaps = self.snapshots.list_snapshots(self.obj.path)
                if not snaps:
                    print("\nNo previous snapshots found for this target.")
                    continue
                print("\nAvailable Snapshots:")
                for s in snaps[:5]:
                    print(f"  [{s.snapshot_id}] {s.timestamp} (SHA256: {s.sha256[:10]}...)")
                s_id = input("Enter snapshot ID to restore (or enter to cancel): ").strip()
                if s_id:
                    ans = input(f"Are you sure you want to restore snapshot '{s_id}'? [y/N]: ").strip().lower()
                    if ans in ("y", "yes"):
                        ok, msg = self.snapshots.restore_snapshot(s_id, force_yes=True)
                        print(f"\n{'SUCCESS' if ok else 'ERROR'}: {msg}")
                        if ok:
                            # reload
                            self.obj.content = Path(self.obj.path).read_text(encoding="utf-8")
                            self.editor = EditEngine(self.obj)

            else:
                print(f"Unknown command: '{choice}'. Type e, d, v, h, s, r, x, or q.")

    def _handle_edit_prompt(self):
        print("\nEDIT OPTIONS:")
        print("  1. Replace text: replace <old> with <new>")
        print("  2. Regex replace: regex /pattern/ with <new>")
        print("  3. JSON set: set <key.path> = <value>")
        print("  4. JSON delete: delete <key.path>")
        print("  5. Line operations: delete lines <start>-<end>, insert at <line>")
        print("  6. Pipeline: trim, sort, unique, blank")
        print("  7. Launch external $EDITOR")

        sub = input("edit> ").strip()
        if not sub:
            return

        if sub.startswith("replace ") and " with " in sub:
            parts = sub[8:].split(" with ", 1)
            old_s = parts[0].strip().strip('"\'')
            new_s = parts[1].strip().strip('"\'')
            self.editor.replace(old_s, new_s)
            print(f"Replaced '{old_s}' with '{new_s}'. View diff with [d].")

        elif sub.startswith("regex ") and " with " in sub:
            parts = sub[6:].split(" with ", 1)
            pattern = parts[0].strip().strip('/')
            replacement = parts[1].strip().strip('"\'')
            try:
                self.editor.replace_regex(pattern, replacement)
                print(f"Regex applied. View diff with [d].")
            except Exception as e:
                print(f"Error: {e}")

        elif sub.startswith("set ") and "=" in sub:
            parts = sub[4:].split("=", 1)
            k = parts[0].strip()
            v = parts[1].strip()
            try:
                self.editor.json_set(k, v)
                print(f"Set JSON '{k}'. View diff with [d].")
            except Exception as e:
                print(f"Error: {e}")

        elif sub.startswith("delete "):
            sel = sub[7:].strip()
            if "lines " in sel:
                # delete lines 20-30
                nums = sel.replace("lines ", "").split("-")
                try:
                    s, e = int(nums[0]), int(nums[1])
                    self.editor.delete_lines(s, e)
                    print(f"Deleted lines {s}-{e}.")
                except Exception as ex:
                    print(f"Error: {ex}")
            else:
                # JSON delete
                try:
                    self.editor.json_delete(sel)
                    print(f"Deleted key '{sel}'.")
                except Exception as ex:
                    print(f"Error: {ex}")

        elif sub in ("trim", "pipeline trim"):
            self.editor.trim_whitespace()
            print("Trimmed whitespace.")

        elif sub in ("sort", "pipeline sort"):
            self.editor.sort_lines()
            print("Sorted lines.")

        elif sub in ("unique", "dedup", "pipeline unique"):
            self.editor.remove_duplicates()
            print("Removed duplicate lines.")

        elif sub in ("7", "editor", "$editor"):
            ok, msg, plan = self.editor.launch_external_editor()
            print(f"\n{msg}")
