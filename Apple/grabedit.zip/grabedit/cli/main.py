"""
CLI Main Entry Point for GrabEdit.
"""

from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from grabedit.cli.commands import Commands


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="grab",
        description="GrabEdit — Advanced Grab/Edit Command System for macOS Terminal",
        formatter_class=argparse.RawTextHelpFormatter,
    )

    # Global options
    parser.add_argument("--dry-run", action="store_true", help="Simulate execution without modifying files")
    parser.add_argument("--plan", action="store_true", help="Generate and show execution plan only")
    parser.add_argument("--json", action="store_true", help="Output results in JSON format")
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose diagnostic logs")
    parser.add_argument("--quiet", "-q", action="store_true", help="Suppress non-essential output")
    parser.add_argument("--no-color", action="store_true", help="Disable colored terminal output")
    parser.add_argument("--backup", action="store_true", default=True, help="Create atomic backups before changes")
    parser.add_argument("-y", "--yes", action="store_true", help="Auto-confirm prompt where safe")

    # Positional target or subcommands
    subparsers = parser.add_subparsers(dest="command", help="Available subcommands")

    # edit
    edit_parser = subparsers.add_parser("edit", help="Edit a target with structured transformations")
    edit_parser.add_argument("target", help="File, config, or object to edit")

    # inspect
    inspect_parser = subparsers.add_parser("inspect", help="Deeply inspect metadata, syntax, and structure")
    inspect_parser.add_argument("target", help="Target to inspect")

    # diff
    diff_parser = subparsers.add_parser("diff", help="Display 3-way stage diff (ORIGINAL -> CURRENT -> PROPOSED)")
    diff_parser.add_argument("target", help="Target to diff")

    # validate
    validate_parser = subparsers.add_parser("validate", help="Validate format integrity (JSON, CSV, Python AST, XML)")
    validate_parser.add_argument("target", help="Target to validate")

    # hash
    hash_parser = subparsers.add_parser("hash", help="Compute and verify cryptographic checksum (SHA256/SHA512)")
    hash_parser.add_argument("target", help="Target file")
    hash_parser.add_argument("--algorithm", choices=["sha256", "sha512"], default="sha256")

    # search
    search_parser = subparsers.add_parser("search", help="Fast local streaming text and pattern search")
    search_parser.add_argument("query", help="Search query or regex")
    search_parser.add_argument("--dir", default=".", help="Root directory to search")
    search_parser.add_argument("--glob", default="*", help="File match pattern (e.g. *.py)")

    # batch
    batch_parser = subparsers.add_parser("batch", help="Batch process and validate collections of targets")
    batch_parser.add_argument("--glob", default="*.json", help="Glob pattern for targets")

    # restore
    restore_parser = subparsers.add_parser("restore", help="Restore target from validated snapshot")
    restore_parser.add_argument("snapshot_id", nargs="?", help="Snapshot ID to restore")
    restore_parser.add_argument("--target", help="Filter snapshots for target file")

    # history
    history_parser = subparsers.add_parser("history", help="Show audit trail of past operations")
    history_parser.add_argument("--limit", type=int, default=20, help="Number of entries")

    # run
    run_parser = subparsers.add_parser("run", help="Execute a .grab automation script")
    run_parser.add_argument("script", help="Path to .grab script")

    # do
    do_parser = subparsers.add_parser("do", help="Advanced deterministic command mode")
    do_parser.add_argument("tokens", nargs=argparse.REMAINDER, help="Deterministic command tokens")

    # Fallback positional target for direct 'grab <target>'
    parser.add_argument("direct_target", nargs="?", help="Direct target to grab and inspect in workspace")
    parser.add_argument("--edit", action="store_true", help="Launch directly into edit mode")
    parser.add_argument("--output", dest="command_output", help="Capture output of supplied command")

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    if argv is None:
        argv = sys.argv[1:]

    parser = create_parser()
    args = parser.parse_args(argv)

    cmd_handler = Commands(
        dry_run=args.dry_run,
        verbose=args.verbose,
        json_output=args.json,
    )

    # Check for --output flag
    if args.command_output:
        return cmd_handler.cmd_grab(f"--output {args.command_output}", interactive=False)

    if args.command == "edit":
        # Launch grab and workspace
        return cmd_handler.cmd_grab(args.target, interactive=True)

    elif args.command == "inspect":
        return cmd_handler.cmd_inspect(args.target)

    elif args.command == "diff":
        return cmd_handler.cmd_diff(args.target)

    elif args.command == "validate":
        return cmd_handler.cmd_validate(args.target)

    elif args.command == "hash":
        return cmd_handler.cmd_hash(args.target, args.algorithm)

    elif args.command == "search":
        return cmd_handler.cmd_search(args.query, root_dir=args.dir, glob=args.glob)

    elif args.command == "restore":
        return cmd_handler.cmd_restore(args.snapshot_id, target=args.target, force_yes=args.yes)

    elif args.command == "history":
        return cmd_handler.cmd_history(args.limit)

    elif args.command == "run":
        return cmd_handler.cmd_run_script(args.script)

    elif args.command == "do":
        return cmd_handler.cmd_do(args.tokens, force_yes=args.yes)

    elif args.direct_target:
        return cmd_handler.cmd_grab(args.direct_target, interactive=not args.json)

    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
