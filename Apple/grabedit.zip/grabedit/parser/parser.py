"""
Parser for .grab scripts and 'grab do' command language.
Constructs deterministic AST representation before execution.
"""

from __future__ import annotations

from typing import List, Optional

from grabedit.parser.ast_nodes import (
    ASTNode,
    DeleteStatement,
    DoFindStatement,
    DoRenameStatement,
    GrabStatement,
    ReplaceStatement,
    SaveStatement,
    ScriptAST,
    SetStatement,
    ShowDiffStatement,
    ValidateStatement,
)
from grabedit.parser.lexer import Lexer, Token


class ParseError(Exception):
    pass


class Parser:
    """Parses token streams into AST nodes."""

    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0

    def current(self) -> Token:
        return self.tokens[self.pos] if self.pos < len(self.tokens) else Token("EOF", "", 0, 0)

    def match(self, *expected_types: str) -> bool:
        if self.current().type in expected_types:
            self.pos += 1
            return True
        return False

    def expect(self, expected_type: str) -> Token:
        tok = self.current()
        if tok.type != expected_type:
            raise ParseError(f"Line {tok.line}, Col {tok.col}: Expected {expected_type}, found {tok.type} ('{tok.value}')")
        self.pos += 1
        return tok

    def skip_newlines(self):
        while self.current().type == "NEWLINE":
            self.pos += 1

    def parse(self) -> ScriptAST:
        statements: List[ASTNode] = []
        self.skip_newlines()

        while self.current().type != "EOF":
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
            self.skip_newlines()

        return ScriptAST(statements=statements)

    def parse_statement(self) -> Optional[ASTNode]:
        tok = self.current()

        if tok.type == "GRAB":
            self.pos += 1
            # Next token is target
            target_tok = self.current()
            if target_tok.type in ("STRING", "IDENT"):
                self.pos += 1
                return GrabStatement(target=target_tok.value)
            raise ParseError(f"Line {tok.line}: Expected target after 'grab'")

        if tok.type == "REPLACE":
            self.pos += 1
            # Optional colon
            self.match("COLON")
            self.skip_newlines()
            old_tok = self.expect("STRING") if self.current().type == "STRING" else self.expect("IDENT")

            self.skip_newlines()
            self.expect("WITH")
            self.match("COLON")
            self.skip_newlines()
            new_tok = self.expect("STRING") if self.current().type == "STRING" else self.expect("IDENT")

            return ReplaceStatement(old_value=old_tok.value, new_value=new_tok.value)

        if tok.type == "SET":
            self.pos += 1
            key_tok = self.expect("IDENT")
            self.expect("EQUALS")
            val_tok = self.current()
            if val_tok.type in ("STRING", "IDENT"):
                self.pos += 1
                return SetStatement(key_path=key_tok.value, value=val_tok.value)
            raise ParseError(f"Line {tok.line}: Expected value after '=' in 'set'")

        if tok.type == "DELETE":
            self.pos += 1
            sel_tok = self.current()
            if sel_tok.type in ("STRING", "IDENT"):
                self.pos += 1
                return DeleteStatement(selector=sel_tok.value)
            raise ParseError(f"Line {tok.line}: Expected selector after 'delete'")

        if tok.type == "VALIDATE":
            self.pos += 1
            fmt = None
            if self.current().type in ("IDENT", "STRING"):
                fmt = self.current().value
                self.pos += 1
            return ValidateStatement(target_format=fmt)

        if tok.type == "SHOW":
            self.pos += 1
            self.expect("DIFF")
            return ShowDiffStatement()

        if tok.type == "SAVE":
            self.pos += 1
            dest = None
            if self.current().type in ("IDENT", "STRING"):
                dest = self.current().value
                self.pos += 1
            return SaveStatement(destination=dest)

        # Grab Do statements
        if tok.type == "DO":
            self.pos += 1
            action = self.current().type
            if action == "FIND":
                self.pos += 1
                self.match("ALL")
                pattern_tok = self.expect("IDENT")
                self.match("FILES")
                self.expect("UNDER")
                root_tok = self.current()
                if root_tok.type in ("IDENT", "STRING"):
                    self.pos += 1
                    return DoFindStatement(filter_pattern=pattern_tok.value, root_dir=root_tok.value)
            elif action == "RENAME":
                self.pos += 1
                from_tok = self.expect("IDENT")
                self.expect("TO")
                to_tok = self.expect("IDENT")
                return DoRenameStatement(from_pattern=from_tok.value, to_pattern=to_tok.value)

        # Advance if unknown token to avoid infinite loop
        self.pos += 1
        return None


def parse_script(text: str) -> ScriptAST:
    tokens = Lexer.tokenize(text)
    parser = Parser(tokens)
    return parser.parse()
