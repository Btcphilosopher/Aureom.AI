"""
Lexer for .grab script files and 'grab do' command language.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Token:
    type: str
    value: str
    line: int
    col: int


class Lexer:
    """Tokenizes .grab script text into clean tokens."""

    TOKEN_SPEC = [
        ("COMMENT", r"#.*"),
        ("GRAB", r"\bgrab\b"),
        ("REPLACE", r"\breplace\b"),
        ("WITH", r"\bwith\b"),
        ("SET", r"\bset\b"),
        ("DELETE", r"\bdelete\b"),
        ("VALIDATE", r"\bvalidate\b"),
        ("SHOW", r"\bshow\b"),
        ("DIFF", r"\bdiff\b"),
        ("SAVE", r"\bsave\b"),
        ("DO", r"\bdo\b"),
        ("FIND", r"\bfind\b"),
        ("RENAME", r"\brename\b"),
        ("TO", r"\bto\b"),
        ("UNDER", r"\bunder\b"),
        ("ALL", r"\ball\b"),
        ("FILES", r"\bfiles\b"),
        ("COLON", r":"),
        ("EQUALS", r"="),
        ("STRING", r'"[^"\\]*(?:\\.[^"\\]*)*"|\'[^\'\\]*(?:\\.[^\'\\]*)*\''),
        ("IDENT", r"[a-zA-Z0-9_\-\.\*\/~]+"),
        ("NEWLINE", r"\n"),
        ("SKIP", r"[ \t]+"),
    ]

    @classmethod
    def tokenize(cls, text: str) -> List[Token]:
        regex_parts = [f"(?P<{name}>{pattern})" for name, pattern in cls.TOKEN_SPEC]
        master_regex = re.compile("|".join(regex_parts))

        tokens: List[Token] = []
        line_num = 1
        line_start = 0

        for mo in master_regex.finditer(text):
            kind = mo.lastgroup
            val = mo.group()
            col = mo.start() - line_start + 1

            if kind == "NEWLINE":
                tokens.append(Token("NEWLINE", "\n", line_num, col))
                line_num += 1
                line_start = mo.end()
            elif kind == "SKIP" or kind == "COMMENT":
                continue
            elif kind == "STRING":
                # strip outer quotes
                tokens.append(Token("STRING", val[1:-1], line_num, col))
            else:
                tokens.append(Token(kind or "IDENT", val, line_num, col))

        tokens.append(Token("EOF", "", line_num, 0))
        return tokens
