"""
AST Nodes for .grab scripts and 'grab do' command language.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ASTNode:
    """Base AST node for GrabEdit DSL."""
    pass


@dataclass
class GrabStatement(ASTNode):
    target: str


@dataclass
class ReplaceStatement(ASTNode):
    old_value: str
    new_value: str
    is_regex: bool = False


@dataclass
class SetStatement(ASTNode):
    key_path: str
    value: Any


@dataclass
class DeleteStatement(ASTNode):
    selector: str  # e.g. "lines 1-10" or "json:logging.debug"


@dataclass
class ValidateStatement(ASTNode):
    target_format: Optional[str] = None


@dataclass
class ShowDiffStatement(ASTNode):
    pass


@dataclass
class SaveStatement(ASTNode):
    destination: Optional[str] = None


@dataclass
class DoFindStatement(ASTNode):
    filter_pattern: str
    root_dir: str


@dataclass
class DoRenameStatement(ASTNode):
    from_pattern: str
    to_pattern: str
    root_dir: Optional[str] = None


@dataclass
class ScriptAST(ASTNode):
    statements: List[ASTNode] = field(default_factory=list)
