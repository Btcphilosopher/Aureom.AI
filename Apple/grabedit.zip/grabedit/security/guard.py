"""
Security policies and permission guards for GrabEdit.
Ensures defensive operations, protects sensitive directories, and blocks unauthorized actions.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import List, Tuple

# macOS protected SIP and system directories
MACOS_PROTECTED_ROOTS: List[str] = [
    "/System",
    "/usr/bin",
    "/usr/sbin",
    "/bin",
    "/sbin",
    "/private/var/db",
    "/Library/Apple",
    "/Volumes/Recovery",
]

# Sensitive files that trigger security warnings
SENSITIVE_PATTERNS: List[str] = [
    ".ssh/id_",
    ".ssh/authorized_keys",
    "/etc/shadow",
    "/etc/sudoers",
    "/etc/master.passwd",
    "keychain",
    ".aws/credentials",
    ".env",
    "id_rsa",
    "id_ed25519",
    ".netrc",
]


class SecurityGuard:
    """Defensive security policy enforcer for GrabEdit."""

    def __init__(self, allow_protected_override: bool = False):
        self.allow_protected_override = allow_protected_override

    def is_protected_macos_path(self, target_path: Path | str) -> bool:
        """Check if target path is in a protected macOS system location."""
        resolved = Path(target_path).resolve()
        for root in MACOS_PROTECTED_ROOTS:
            try:
                if resolved == Path(root) or Path(root) in resolved.parents:
                    return True
            except Exception:
                continue
        return False

    def is_sensitive_path(self, target_path: Path | str) -> Tuple[bool, str]:
        """Check if target file matches sensitive credential or security patterns."""
        str_path = str(Path(target_path).resolve())
        for pattern in SENSITIVE_PATTERNS:
            if pattern in str_path:
                return True, f"Target matches sensitive credential pattern: '{pattern}'"
        return False, ""

    def validate_write_permission(self, target_path: Path | str) -> Tuple[bool, str]:
        """Validate whether the destination is safe to modify."""
        path = Path(target_path).resolve()

        if self.is_protected_macos_path(path) and not self.allow_protected_override:
            return (
                False,
                f"SECURITY VIOLATION: Path '{path}' is a protected macOS system location. Writes are forbidden.",
            )

        # Check if existing file is read-only
        if path.exists() and not os.access(path, os.W_OK):
            return False, f"Permission Denied: '{path}' is not writable by current user."

        # Check if parent directory is writable
        parent = path.parent
        if parent.exists() and not os.access(parent, os.W_OK):
            return (
                False,
                f"Permission Denied: Directory '{parent}' is not writable.",
            )

        return True, "OK"
