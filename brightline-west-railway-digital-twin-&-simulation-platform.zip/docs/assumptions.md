# Brightline West Digital Twin - Data Provenance & Assumptions Ledger

All parameters within the digital twin are strictly classified into five provenance categories:

| Parameter | Value | Provenance Class | Verification Source |
|---|---|---|---|
| Corridor Origin & Terminus | Rancho Cucamonga ↔ Las Vegas (218 mi) | `PUBLIC_REFERENCE` | FRA Final EIS / Public ROW Record |
| Maximum Operating Speed | 200 mph (322 km/h) | `PUBLIC_REFERENCE` | FRA Class 9 High-Speed designation |
| Electrification Standard | 25kV AC 60Hz Catenary | `PUBLIC_REFERENCE` | Project Electrification filings |
| Substations Count | 8 Traction Substations | `PUBLIC_REFERENCE` | Utility interconnection filings |
| Consist Mass (4-car EMU) | 420 metric tons | `SYNTHETIC` | AP220 High-Speed EMU reference |
| Continuous Traction Power | 8,000 kW (8.0 MW) | `SYNTHETIC` | 25kV IGBT Inverter design sizing |
| Regenerative Recovery Rate | 85% motor-to-catenary | `ENGINEERING_ASSUMPTION` | Modern high-speed EMU regenerative benchmark |
| Station Platform Dwell | 120s (Hesperia) / 180s (Victor Valley) | `ENGINEERING_ASSUMPTION` | UIC 406 station dwell planning norms |
| Catenary Impedance | 0.22 $\Omega$/km | `ENGINEERING_ASSUMPTION` | 25kV AC copper contact/messenger conductor |
