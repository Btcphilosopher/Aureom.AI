# Brightline West Digital Twin - Longitudinal Physics Engine

## 1. Governing Equation of Motion
The simulator solves the 1D longitudinal differential equation:

$$F_{\text{net}} = F_{\text{traction}}(v) - F_{\text{brake}}(v) - R_{\text{davis}}(v, \rho) - F_{\text{gradient}}(\theta) - F_{\text{curve}}(R)$$

$$\frac{dv}{dt} = \frac{F_{\text{net}}}{M_{\text{effective}}}, \quad M_{\text{effective}} = M_{\text{consist}} \times (1 + \lambda_{\text{rotational}})$$

## 2. Train Resistance (Modified Davis Equation)
Aerodynamic and rolling resistance are corrected for Mojave Desert ambient temperature and elevation:

$$R_{\text{davis}} = A + B v + C \left(\frac{\rho(h, T)}{\rho_0}\right) (v + v_{\text{wind}} \cos \theta_{\text{wind}})^2$$

- **A (Mechanical Rolling Resistance)**: $3.2\text{ kN}$
- **B (Flange / Momentum Drag)**: $0.052\text{ kN}\cdot\text{s/m}$
- **C (Aerodynamic Drag)**: $0.0078\text{ kN}\cdot\text{s}^2/\text{m}^2$

## 3. Alignment Curvature & Equilibrium Cant
Permitted speed through horizontal curves is calculated via equilibrium cant and cant deficiency:

$$V_{\text{max}} = \sqrt{\frac{(D_{\text{cant}} + I_{\text{deficiency}}) \times R}{11.8}} \quad (\text{km/h})$$
