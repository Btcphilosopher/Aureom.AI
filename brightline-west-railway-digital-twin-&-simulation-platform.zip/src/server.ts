import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// Railway Digital Twin REST API
app.get('/api/v1/corridor', (req, res) => {
  res.json({
    corridor: 'Brightline West',
    origin: 'Rancho Cucamonga, CA (MP 0.0)',
    destination: 'Las Vegas, NV (MP 218.0)',
    length_miles: 218.0,
    length_km: 350.8,
    design_speed_mph: 200,
    electrification: '25kV AC 60Hz Catenary',
    substations_count: 8,
    signalling: 'ETCS Level 2 / PTC',
    stations: ['Rancho Cucamonga', 'Hesperia', 'Victor Valley', 'Las Vegas Warm Springs']
  });
});

app.post('/api/v1/simulation/run', (req, res) => {
  const scenarioId = req.body?.scenario_id || 'sc-baseline';
  res.json({
    simulation_id: `SIM-${Math.floor(1000 + Math.random() * 9000)}`,
    scenario_id: scenarioId,
    status: 'COMPLETED',
    journey_time_minutes: 118.5,
    average_speed_mph: 110.8,
    max_speed_mph: 198.4,
    net_energy_mwh: 12.8,
    practical_capacity_tph: 8
  });
});

app.get('/api/v1/trains/:id/state', (req, res) => {
  const trainId = req.params.id;
  res.json({
    train_id: trainId,
    position_m: 148932,
    milepost: 92.54,
    speed_mps: 88.1,
    speed_mph: 197.1,
    acceleration_mps2: 0.08,
    traction_kw: 8240,
    gradient: -0.002,
    energy_kwh: 4820,
    signal_aspect: 'PROCEED',
    catenary_voltage_kv: 24.8
  });
});

app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'HEALTHY', engine: 'Brightline West Digital Twin v1.0' });
});


/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
