import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  OnDestroy,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from './core/services/digital-twin.service';
import { HeaderComponent } from './components/header/header';
import { CorridorMapComponent } from './components/corridor-map/corridor-map';
import { ThreeViewComponent } from './components/three-view/three-view';
import { InspectorComponent } from './components/inspector/inspector';
import { AlignmentEditorComponent } from './components/designer/alignment-editor';
import { CabViewComponent } from './components/cab-view/cab-view';
import { TimeDistanceGraphComponent } from './components/time-distance-graph/time-distance-graph';
import { ScenarioManagerComponent } from './components/scenarios/scenario-manager';
import { OccViewComponent } from './components/occ/occ-view';
import { ConstructionViewComponent } from './components/construction/construction-view';
import { AnalyticsViewComponent } from './components/analytics/analytics-view';
import { CommandPaletteComponent } from './components/command-palette/command-palette';
import { ReportModalComponent } from './components/report-modal/report-modal';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    CorridorMapComponent,
    ThreeViewComponent,
    InspectorComponent,
    AlignmentEditorComponent,
    CabViewComponent,
    TimeDistanceGraphComponent,
    ScenarioManagerComponent,
    OccViewComponent,
    ConstructionViewComponent,
    AnalyticsViewComponent,
    CommandPaletteComponent,
    ReportModalComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class App implements OnInit, OnDestroy {
  public dt = inject(DigitalTwinService);

  private simulationIntervalId: ReturnType<typeof setInterval> | null = null;

  ngOnInit() {
    if (typeof window !== 'undefined') {
      // Advance physics simulation clock every 100ms
      this.simulationIntervalId = setInterval(() => {
        if (this.dt.isSimulationPlaying()) {
          const deltaSec = 0.1 * this.dt.simulationTimeScale();
          this.dt.advanceSimulationTime(deltaSec);
        }
      }, 100);
    }
  }

  ngOnDestroy() {
    if (this.simulationIntervalId) {
      clearInterval(this.simulationIntervalId);
    }
  }
}
