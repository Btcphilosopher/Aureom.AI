/**
 * BRIGHTLINE WEST DIGITAL TWIN - CORE DOMAIN MODEL
 * Unified engineering data structures for high-speed rail corridor (218 miles / 350.8 km)
 */

export type DataProvenanceType = 
  | 'PUBLIC_REFERENCE' 
  | 'ENGINEERING_ASSUMPTION' 
  | 'SYNTHETIC' 
  | 'USER_DEFINED' 
  | 'SIMULATION_OUTPUT';

export interface ProvenanceValue<T> {
  value: T;
  sourceType: DataProvenanceType;
  sourceDescription: string;
  unit?: string;
  confidence: number; // 0.0 - 1.0
  lastModified?: string;
}

export type TrackDirection = 'UP' | 'DOWN' | 'BIDIRECTIONAL';
export type TrackClass = 'CLASS_6' | 'CLASS_7' | 'CLASS_8' | 'CLASS_9'; // Class 9 = 200+ mph

export interface TrackSegment {
  id: string;
  name: string;
  startChainageM: number; // meters from Rancho Cucamonga
  endChainageM: number;
  startMp: number; // Milepost (miles)
  endMp: number;
  trackClass: TrackClass;
  direction: TrackDirection;
  designSpeedMps: number; // m/s
  permittedSpeedMps: number; // current operational limit
  gradientPercent: number; // e.g. +2.8% or -1.5%
  startElevationM: number;
  endElevationM: number;
  curveRadiusM: number; // 0 = straight, positive = right, negative = left
  cantMm: number; // Actual cant / superelevation in mm (max 150mm)
  cantDeficiencyMm: number; // Cant deficiency in mm (max 100mm)
  catenarySectionId: string;
  signalBlockId: string;
  structureType: 'BALLAST_SURFACE' | 'BALLAST_MEDIAN_I15' | 'SLAB_TRACK' | 'VIADUCT' | 'BRIDGE' | 'CUTTING' | 'EMBANKMENT' | 'TUNNEL';
  maintenanceCondition: number; // 0.0 - 1.0 (1.0 = pristine)
  status: 'ACTIVE' | 'SPEED_RESTRICTED' | 'MAINTENANCE_POSSESSION' | 'OUT_OF_SERVICE';
}

export interface Station {
  id: string;
  name: string;
  chainageM: number;
  mp: number;
  elevationM: number;
  platforms: number;
  platformLengthM: number;
  throughTracks: number;
  platformTracks: number;
  defaultDwellSeconds: number;
  passengerCapacityPerHour: number;
  metrolinkConnection: boolean;
  busConnection: boolean;
  parkingSpaces: number;
  dailyBoardingDemand: number;
  status: 'OPERATIONAL' | 'RESTRICTED' | 'UNDER_CONSTRUCTION';
}

export interface Substation {
  id: string;
  name: string;
  chainageM: number;
  mp: number;
  gridVoltageKv: number; // 230kV utility feed
  catenaryVoltageKv: number; // 25kV 60Hz AC
  ratedPowerMva: number; // e.g. 60 MVA
  transformerCount: number;
  transformerCapacityMva: number;
  feedingSections: string[];
  currentLoadMw: number;
  peakLoadMw: number;
  headroomMw: number;
  breakerState: 'CLOSED' | 'OPEN' | 'TRIPPED';
  status: 'ONLINE' | 'FAULTED' | 'ISOLATED';
  temperatureC: number;
}

export interface CatenarySection {
  id: string;
  name: string;
  startChainageM: number;
  endChainageM: number;
  startMp: number;
  endMp: number;
  substationId: string;
  voltageKv: number;
  maxCurrentAmps: number;
  impedancePerKm: number; // Ohm/km (e.g. 0.22)
  status: 'ENERGIZED' | 'ISOLATED' | 'GROUNDED' | 'OVERLOADED';
  temperatureC: number;
}

export type SignalAspect = 'STOP' | 'CAUTION' | 'ADVANCE_CAUTION' | 'PROCEED' | 'FLASHING_PROCEED';

export interface SignalBlock {
  id: string;
  name: string;
  startChainageM: number;
  endChainageM: number;
  startMp: number;
  endMp: number;
  aspect: SignalAspect;
  occupiedByTrainId: string | null;
  targetSpeedMps: number;
  movementAuthorityM: number;
  interlockingZoneId?: string;
  isInterlocking: boolean;
}

export interface RollingStockConfig {
  id: string;
  modelName: string;
  lengthM: number; // e.g. 200m
  massTons: number; // e.g. 420t empty + passenger payload
  tareMassTons: number; // e.g. 390t
  passengerCapacity: number; // 450 seats
  maxOperatingSpeedMps: number; // 89.4 m/s (200 mph)
  continuousPowerKw: number; // 8,000 kW (8.0 MW)
  maxTractiveEffortKn: number; // 320 kN
  maxRegenerativeBrakePowerKw: number; // 7,500 kW
  maxServiceDecelerationMps2: number; // 1.1 m/s²
  emergencyDecelerationMps2: number; // 1.5 m/s²
  auxiliaryPowerKw: number; // 350 kW (HVAC, lighting, control)
  // Davis Equation coefficients: R = A + B*v + C*v^2
  davisA_kN: number; // Mechanical rolling resistance (kN)
  davisB_kN_s_per_m: number; // Flange and momentum resistance (kN·s/m)
  davisC_kN_s2_per_m2: number; // Aerodynamic drag (kN·s²/m²)
  rotatingMassFactor: number; // e.g. 1.08
}

export interface TrainTelemetry {
  trainId: string;
  serviceId: string;
  timestampSeconds: number;
  chainageM: number;
  mp: number;
  speedMps: number;
  speedMph: number;
  accelerationMps2: number;
  tractiveForceKn: number;
  brakeForceKn: number;
  tractionPowerKw: number;
  regenerativePowerKw: number;
  netPowerKw: number;
  currentGradientPercent: number;
  currentCurveRadiusM: number;
  currentPermittedSpeedMps: number;
  currentSignalBlockId: string;
  currentSignalAspect: SignalAspect;
  distanceToNextSignalM: number;
  distanceToNextStationM: number;
  nextStationName: string;
  motorTemperatureC: number;
  brakeTemperatureC: number;
  catenaryVoltageKv: number;
  currentSubstationId: string;
  cumulativeEnergyKwh: number;
  cumulativeRegenKwh: number;
  passengerCount: number;
  currentDelaySeconds: number;
  state: 'CRUISING' | 'ACCELERATING' | 'BRAKING' | 'STATION_DWELL' | 'SIGNAL_STOP' | 'DEPOT';
}

export interface TimetableStop {
  stationId: string;
  stationName: string;
  scheduledArrivalSeconds: number; // seconds from midnight
  scheduledDepartureSeconds: number;
  actualArrivalSeconds?: number;
  actualDepartureSeconds?: number;
  dwellDurationSeconds: number;
  platformTrack: number;
}

export interface TimetableService {
  id: string;
  serviceCode: string; // e.g. "BW 101"
  direction: 'NORTHBOUND' | 'SOUTHBOUND';
  rollingStockId: string;
  originStationId: string;
  destinationStationId: string;
  scheduledDepartureSeconds: number;
  scheduledArrivalSeconds: number;
  stops: TimetableStop[];
  priority: number;
  status: 'SCHEDULED' | 'RUNNING' | 'COMPLETED' | 'DELAYED' | 'CANCELLED';
  actualDelaySeconds: number;
}

export interface EnvironmentalConditions {
  ambientTemperatureC: number; // e.g. 38°C in Mojave Desert
  windSpeedMps: number;
  windDirectionDegrees: number;
  adhesionFactor: number; // 0.6 - 1.0 (rail friction coefficient)
  solarIrradianceWpm2: number;
  dustLevel: 'LOW' | 'MODERATE' | 'SEVERE';
  scenarioName: 'NOMINAL_SPRING' | 'HOT_DESERT_SUMMER' | 'HIGH_WIND_CAJON' | 'WINTER_FREEZE' | 'DUST_STORM';
}

export interface ScenarioChange {
  targetSubsystem: 'ALIGNMENT' | 'TRACK' | 'ROLLING_STOCK' | 'POWER' | 'TIMETABLE' | 'ENVIRONMENT';
  targetObjectId: string;
  parameterName: string;
  baselineValue: unknown;
  scenarioValue: unknown;
  unit: string;
  description: string;
}

export interface ScenarioResultMetrics {
  journeyTimeNorthboundSeconds: number;
  journeyTimeSouthboundSeconds: number;
  totalTractionEnergyMwh: number;
  totalRegeneratedEnergyMwh: number;
  netEnergyMwh: number;
  energyPerSeatKmWh: number;
  peakSubstationLoadMva: number;
  capacityTrainsPerHour: number;
  peakCapacityTrainsPerHour: number;
  onTimePerformancePercent: number;
  meanDelaySeconds: number;
  p95DelaySeconds: number;
  capitalCostEstimateUsd: number;
  annualOperatingCostUsd: number;
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  modelVersion: string;
  parentScenarioId: string | null;
  createdAt: string;
  author: string;
  changes: ScenarioChange[];
  results?: ScenarioResultMetrics;
}

export interface ConstructionTask {
  id: string;
  name: string;
  wbsCode: string;
  startChainageM: number;
  endChainageM: number;
  category: 'FOUNDATION' | 'EARTHWORK' | 'STRUCTURES' | 'TRACK' | 'ELECTRIFICATION' | 'SIGNALLING' | 'TESTING' | 'COMMISSIONING';
  startQuarter: string; // e.g. "Q1 2026"
  endQuarter: string; // e.g. "Q3 2027"
  progressPercent: number;
  dependencies: string[];
  unitCostUsd: number;
  quantity: number;
  unit: string;
  totalCostUsd: number;
  status: 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED';
}

export interface MonteCarloIteration {
  iterationIndex: number;
  journeyTimeMinutes: number;
  delayMinutes: number;
  energyConsumptionMwh: number;
  peakSubstationLoadMw: number;
  temperatureC: number;
  dwellRandomFactor: number;
}

export interface MonteCarloSummary {
  sampleCount: number;
  journeyTimeP50Min: number;
  journeyTimeP90Min: number;
  journeyTimeP95Min: number;
  journeyTimeP99Min: number;
  delayP90Min: number;
  delayP95Min: number;
  energyMeanMwh: number;
  energyStdDevMwh: number;
  reliabilityPercent: number;
  iterations: MonteCarloIteration[];
}

export interface ParetoPoint {
  scenarioId: string;
  name: string;
  journeyTimeMinutes: number;
  energyConsumptionMwh: number;
  capexMillionUsd: number;
  capacityTph: number;
  isParetoOptimal: boolean;
}
