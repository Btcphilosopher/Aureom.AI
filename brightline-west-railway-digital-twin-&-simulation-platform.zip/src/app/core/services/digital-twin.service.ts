/**
 * BRIGHTLINE WEST DIGITAL TWIN - CENTRAL STATE & ENGINEERING SERVICE
 * One unified railway digital twin model driving all spatial, physics, electrical,
 * signalling, operations, construction and analytics views.
 */

import { Injectable, signal, computed } from '@angular/core';
import {
  TrackSegment,
  Station,
  Substation,
  CatenarySection,
  SignalBlock,
  RollingStockConfig,
  TrainTelemetry,
  TimetableService,
  EnvironmentalConditions,
  Scenario,
  ConstructionTask,
} from '../models/digital-twin.model';
import { TrainDynamicsEngine, CorridorRunResult } from '../physics/train-dynamics';
import { SubstationSolver } from '../physics/substation-solver';
import { SignallingSolver, TimetableConflict } from '../physics/signalling-solver';

@Injectable({
  providedIn: 'root'
})
export class DigitalTwinService {
  // Navigation & Workspace State
  public activeMode = signal<'DIGITAL_TWIN' | 'SIMULATOR' | 'DESIGNER' | 'SCENARIOS' | 'OCC' | 'CONSTRUCTION' | 'ANALYTICS'>('DIGITAL_TWIN');
  public activeSubTab = signal<string>('OVERVIEW');
  public isSimulationPlaying = signal<boolean>(true);
  public simulationTimeScale = signal<number>(5); // 1x, 5x, 10x, 50x
  public simulationClockSeconds = signal<number>(6 * 3600 + 42 * 60); // 06:42:00 AM
  public selectedObjectId = signal<string | null>('track-seg-08'); // default selected segment
  public selectedObjectType = signal<'TRACK' | 'STATION' | 'SUBSTATION' | 'CATENARY' | 'SIGNAL' | 'TRAIN' | 'SCENARIO'>('TRACK');
  public activeFollowTrainId = signal<string | null>('BW101');
  public is3DActive = signal<boolean>(false);
  public showCrossSection = signal<boolean>(false);
  public commandPaletteOpen = signal<boolean>(false);
  public reportModalOpen = signal<boolean>(false);

  // Environmental conditions
  public environment = signal<EnvironmentalConditions>({
    ambientTemperatureC: 36, // Mojave desert summer baseline
    windSpeedMps: 4.5,
    windDirectionDegrees: 45,
    adhesionFactor: 0.95,
    solarIrradianceWpm2: 950,
    dustLevel: 'LOW',
    scenarioName: 'HOT_DESERT_SUMMER'
  });

  // Base Rolling Stock Configuration
  public rollingStock = signal<RollingStockConfig>({
    id: 'RS-BRIGHTLINE-AP220',
    modelName: 'Brightline West AP220 EMU Consist',
    lengthM: 200,
    massTons: 420,
    tareMassTons: 388,
    passengerCapacity: 450,
    maxOperatingSpeedMps: 89.4, // 200 mph
    continuousPowerKw: 8000, // 8.0 MW
    maxTractiveEffortKn: 320,
    maxRegenerativeBrakePowerKw: 7500,
    maxServiceDecelerationMps2: 1.1,
    emergencyDecelerationMps2: 1.5,
    auxiliaryPowerKw: 350,
    davisA_kN: 3.2,
    davisB_kN_s_per_m: 0.052,
    davisC_kN_s2_per_m2: 0.0078,
    rotatingMassFactor: 1.08
  });

  // Base Track Segments along 218-mile corridor
  public trackSegments = signal<TrackSegment[]>([
    {
      id: 'track-seg-01',
      name: 'Rancho Cucamonga Terminal Yard & Leads',
      startChainageM: 0,
      endChainageM: 5200,
      startMp: 0.0,
      endMp: 3.23,
      trackClass: 'CLASS_6',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 35.8, // 80 mph
      permittedSpeedMps: 35.8,
      gradientPercent: 0.4,
      startElevationM: 328, // 1,077 ft
      endElevationM: 360,
      curveRadiusM: 1800,
      cantMm: 80,
      cantDeficiencyMm: 60,
      catenarySectionId: 'cat-sec-01',
      signalBlockId: 'sig-01',
      structureType: 'BALLAST_SURFACE',
      maintenanceCondition: 0.98,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-02',
      name: 'Lower Cajon Pass Approach / Devore Cut',
      startChainageM: 5200,
      endChainageM: 22000,
      startMp: 3.23,
      endMp: 13.67,
      trackClass: 'CLASS_7',
      direction: 'UP',
      designSpeedMps: 53.6, // 120 mph
      permittedSpeedMps: 53.6,
      gradientPercent: 2.4,
      startElevationM: 360,
      endElevationM: 650,
      curveRadiusM: 2800,
      cantMm: 120,
      cantDeficiencyMm: 80,
      catenarySectionId: 'cat-sec-01',
      signalBlockId: 'sig-02',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.95,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-03',
      name: 'Cajon Pass Summit Grade & Viaducts',
      startChainageM: 22000,
      endChainageM: 45000,
      startMp: 13.67,
      endMp: 27.96,
      trackClass: 'CLASS_7',
      direction: 'UP',
      designSpeedMps: 62.5, // 140 mph
      permittedSpeedMps: 62.5,
      gradientPercent: 3.2, // Heavy climb up Cajon Pass
      startElevationM: 650,
      endElevationM: 1149, // 3,770 ft summit
      curveRadiusM: 3200,
      cantMm: 130,
      cantDeficiencyMm: 85,
      catenarySectionId: 'cat-sec-02',
      signalBlockId: 'sig-03',
      structureType: 'VIADUCT',
      maintenanceCondition: 0.96,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-04',
      name: 'Hesperia South Descent & Station Approach',
      startChainageM: 45000,
      endChainageM: 55000,
      startMp: 27.96,
      endMp: 34.18,
      trackClass: 'CLASS_8',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 71.5, // 160 mph
      permittedSpeedMps: 71.5,
      gradientPercent: -1.2,
      startElevationM: 1149,
      endElevationM: 969, // 3,180 ft
      curveRadiusM: 4500,
      cantMm: 110,
      cantDeficiencyMm: 75,
      catenarySectionId: 'cat-sec-02',
      signalBlockId: 'sig-04',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.99,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-05',
      name: 'Hesperia to Victor Valley High Desert Tangent',
      startChainageM: 55000,
      endChainageM: 86900,
      startMp: 34.18,
      endMp: 54.0,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 89.4, // 200 mph
      permittedSpeedMps: 89.4,
      gradientPercent: -0.3,
      startElevationM: 969,
      endElevationM: 876, // 2,875 ft
      curveRadiusM: 12000,
      cantMm: 70,
      cantDeficiencyMm: 45,
      catenarySectionId: 'cat-sec-03',
      signalBlockId: 'sig-05',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.97,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-06',
      name: 'Victor Valley Station & Bell Mountain Siding',
      startChainageM: 86900,
      endChainageM: 105000,
      startMp: 54.0,
      endMp: 65.24,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 89.4, // 200 mph
      permittedSpeedMps: 89.4,
      gradientPercent: 0.2,
      startElevationM: 876,
      endElevationM: 910,
      curveRadiusM: 8500,
      cantMm: 90,
      cantDeficiencyMm: 50,
      catenarySectionId: 'cat-sec-03',
      signalBlockId: 'sig-06',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.98,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-07',
      name: 'Stoddard Wells to Helendale Desert Segment',
      startChainageM: 105000,
      endChainageM: 132000,
      startMp: 65.24,
      endMp: 82.02,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 89.4,
      permittedSpeedMps: 89.4,
      gradientPercent: -0.6,
      startElevationM: 910,
      endElevationM: 740,
      curveRadiusM: 9500,
      cantMm: 80,
      cantDeficiencyMm: 40,
      catenarySectionId: 'cat-sec-04',
      signalBlockId: 'sig-07',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.99,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-08',
      name: 'Barstow Bypass Corridor (MP 82–86)',
      startChainageM: 132000,
      endChainageM: 153000,
      startMp: 82.02,
      endMp: 95.07,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 84.9, // 190 mph
      permittedSpeedMps: 84.9,
      gradientPercent: -0.4,
      startElevationM: 740,
      endElevationM: 640, // 2,100 ft
      curveRadiusM: 4500, // Baseline curve MP 82-86 (Scenario candidate: expand to 7,000m)
      cantMm: 140,
      cantDeficiencyMm: 80,
      catenarySectionId: 'cat-sec-04',
      signalBlockId: 'sig-08',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.96,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-09',
      name: 'Calico / Yermo / Mojave Valley High Speed Straight',
      startChainageM: 153000,
      endChainageM: 195000,
      startMp: 95.07,
      endMp: 121.17,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 89.4, // 200 mph
      permittedSpeedMps: 89.4,
      gradientPercent: -0.2,
      startElevationM: 640,
      endElevationM: 480,
      curveRadiusM: 18000,
      cantMm: 50,
      cantDeficiencyMm: 30,
      catenarySectionId: 'cat-sec-05',
      signalBlockId: 'sig-09',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.99,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-10',
      name: 'Afton Canyon / Rasor Road Desert Basin',
      startChainageM: 195000,
      endChainageM: 233000,
      startMp: 121.17,
      endMp: 144.78,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 89.4,
      permittedSpeedMps: 89.4,
      gradientPercent: -0.7,
      startElevationM: 480,
      endElevationM: 286, // 940 ft Baker basin lowest point
      curveRadiusM: 14000,
      cantMm: 60,
      cantDeficiencyMm: 35,
      catenarySectionId: 'cat-sec-05',
      signalBlockId: 'sig-10',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.98,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-11',
      name: 'Baker Bypass / Soda Lake Basin Section',
      startChainageM: 233000,
      endChainageM: 257000,
      startMp: 144.78,
      endMp: 159.69,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 89.4,
      permittedSpeedMps: 89.4,
      gradientPercent: 1.1,
      startElevationM: 286,
      endElevationM: 520,
      curveRadiusM: 11000,
      cantMm: 70,
      cantDeficiencyMm: 40,
      catenarySectionId: 'cat-sec-06',
      signalBlockId: 'sig-11',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.99,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-12',
      name: 'Halloran Springs / Mountain Pass Summit Climb',
      startChainageM: 257000,
      endChainageM: 281600,
      startMp: 159.69,
      endMp: 174.98,
      trackClass: 'CLASS_8',
      direction: 'UP',
      designSpeedMps: 76.0, // 170 mph
      permittedSpeedMps: 76.0,
      gradientPercent: 2.7, // Steep grade to Clark Mountain Pass
      startElevationM: 520,
      endElevationM: 1442, // 4,730 ft highest point on corridor
      curveRadiusM: 4200,
      cantMm: 140,
      cantDeficiencyMm: 85,
      catenarySectionId: 'cat-sec-06',
      signalBlockId: 'sig-12',
      structureType: 'CUTTING',
      maintenanceCondition: 0.95,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-13',
      name: 'Ivanpah Dry Lake / Primm Nevada Border Transit',
      startChainageM: 281600,
      endChainageM: 305000,
      startMp: 174.98,
      endMp: 189.52,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 89.4, // 200 mph
      permittedSpeedMps: 89.4,
      gradientPercent: -1.9,
      startElevationM: 1442,
      endElevationM: 795, // 2,610 ft Primm
      curveRadiusM: 16000,
      cantMm: 55,
      cantDeficiencyMm: 30,
      catenarySectionId: 'cat-sec-07',
      signalBlockId: 'sig-13',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.98,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-14',
      name: 'Jean / Sloan Summit & Las Vegas Valley Descent',
      startChainageM: 305000,
      endChainageM: 335000,
      startMp: 189.52,
      endMp: 208.16,
      trackClass: 'CLASS_9',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 89.4,
      permittedSpeedMps: 89.4,
      gradientPercent: -0.6,
      startElevationM: 795,
      endElevationM: 650,
      curveRadiusM: 12000,
      cantMm: 70,
      cantDeficiencyMm: 40,
      catenarySectionId: 'cat-sec-07',
      signalBlockId: 'sig-14',
      structureType: 'BALLAST_MEDIAN_I15',
      maintenanceCondition: 0.99,
      status: 'ACTIVE'
    },
    {
      id: 'track-seg-15',
      name: 'Las Vegas South / Warm Springs Terminal Approach',
      startChainageM: 335000,
      endChainageM: 350800,
      startMp: 208.16,
      endMp: 218.0,
      trackClass: 'CLASS_7',
      direction: 'BIDIRECTIONAL',
      designSpeedMps: 44.7, // 100 mph approach
      permittedSpeedMps: 44.7,
      gradientPercent: -0.2,
      startElevationM: 650,
      endElevationM: 625, // 2,050 ft Las Vegas Station
      curveRadiusM: 2500,
      cantMm: 110,
      cantDeficiencyMm: 70,
      catenarySectionId: 'cat-sec-08',
      signalBlockId: 'sig-15',
      structureType: 'VIADUCT',
      maintenanceCondition: 0.99,
      status: 'ACTIVE'
    }
  ]);

  // Stations along the reference corridor
  public stations = signal<Station[]>([
    {
      id: 'st-rancho',
      name: 'Rancho Cucamonga Terminal',
      chainageM: 0,
      mp: 0.0,
      elevationM: 328,
      platforms: 3,
      platformLengthM: 320,
      throughTracks: 2,
      platformTracks: 4,
      defaultDwellSeconds: 240,
      passengerCapacityPerHour: 4800,
      metrolinkConnection: true,
      busConnection: true,
      parkingSpaces: 2500,
      dailyBoardingDemand: 11500,
      status: 'OPERATIONAL'
    },
    {
      id: 'st-hesperia',
      name: 'Hesperia Multimodal Station',
      chainageM: 55000,
      mp: 34.18,
      elevationM: 969,
      platforms: 2,
      platformLengthM: 260,
      throughTracks: 2,
      platformTracks: 2,
      defaultDwellSeconds: 120,
      passengerCapacityPerHour: 1800,
      metrolinkConnection: false,
      busConnection: true,
      parkingSpaces: 1800,
      dailyBoardingDemand: 3400,
      status: 'OPERATIONAL'
    },
    {
      id: 'st-victorvalley',
      name: 'Victor Valley / Apple Valley Station',
      chainageM: 86900,
      mp: 54.0,
      elevationM: 876,
      platforms: 2,
      platformLengthM: 280,
      throughTracks: 2,
      platformTracks: 3,
      defaultDwellSeconds: 180,
      passengerCapacityPerHour: 2400,
      metrolinkConnection: false,
      busConnection: true,
      parkingSpaces: 3500,
      dailyBoardingDemand: 5200,
      status: 'OPERATIONAL'
    },
    {
      id: 'st-lasvegas',
      name: 'Las Vegas Terminal (Warm Springs)',
      chainageM: 350800,
      mp: 218.0,
      elevationM: 625,
      platforms: 4,
      platformLengthM: 350,
      throughTracks: 2,
      platformTracks: 6,
      defaultDwellSeconds: 300,
      passengerCapacityPerHour: 6200,
      metrolinkConnection: false,
      busConnection: true,
      parkingSpaces: 5000,
      dailyBoardingDemand: 16800,
      status: 'OPERATIONAL'
    }
  ]);

  // Electrical Substations along 218-mile corridor
  public substations = signal<Substation[]>([
    {
      id: 'sub-s01',
      name: 'Substation S01 - Rancho Cucamonga',
      chainageM: 2000,
      mp: 1.24,
      gridVoltageKv: 230,
      catenaryVoltageKv: 25.0,
      ratedPowerMva: 60,
      transformerCount: 2,
      transformerCapacityMva: 30,
      feedingSections: ['cat-sec-01'],
      currentLoadMw: 14.8,
      peakLoadMw: 24.2,
      headroomMw: 42.8,
      breakerState: 'CLOSED',
      status: 'ONLINE',
      temperatureC: 48
    },
    {
      id: 'sub-s02',
      name: 'Substation S02 - Cajon Pass Summit',
      chainageM: 38000,
      mp: 23.61,
      gridVoltageKv: 230,
      catenaryVoltageKv: 25.0,
      ratedPowerMva: 75,
      transformerCount: 3,
      transformerCapacityMva: 25,
      feedingSections: ['cat-sec-02'],
      currentLoadMw: 22.4,
      peakLoadMw: 36.8,
      headroomMw: 49.6,
      breakerState: 'CLOSED',
      status: 'ONLINE',
      temperatureC: 52
    },
    {
      id: 'sub-s03',
      name: 'Substation S03 - Victor Valley',
      chainageM: 88000,
      mp: 54.68,
      gridVoltageKv: 230,
      catenaryVoltageKv: 25.0,
      ratedPowerMva: 60,
      transformerCount: 2,
      transformerCapacityMva: 30,
      feedingSections: ['cat-sec-03'],
      currentLoadMw: 11.2,
      peakLoadMw: 19.5,
      headroomMw: 46.4,
      breakerState: 'CLOSED',
      status: 'ONLINE',
      temperatureC: 46
    },
    {
      id: 'sub-s04',
      name: 'Substation S04 - Barstow / Lenwood',
      chainageM: 142000,
      mp: 88.23,
      gridVoltageKv: 230,
      catenaryVoltageKv: 25.0,
      ratedPowerMva: 60,
      transformerCount: 2,
      transformerCapacityMva: 30,
      feedingSections: ['cat-sec-04'],
      currentLoadMw: 15.6,
      peakLoadMw: 22.1,
      headroomMw: 42.0,
      breakerState: 'CLOSED',
      status: 'ONLINE', // Candidate for Power Failure Scenario
      temperatureC: 50
    },
    {
      id: 'sub-s05',
      name: 'Substation S05 - Baker / Soda Lake',
      chainageM: 228000,
      mp: 141.67,
      gridVoltageKv: 230,
      catenaryVoltageKv: 25.0,
      ratedPowerMva: 60,
      transformerCount: 2,
      transformerCapacityMva: 30,
      feedingSections: ['cat-sec-05'],
      currentLoadMw: 12.0,
      peakLoadMw: 18.4,
      headroomMw: 45.6,
      breakerState: 'CLOSED',
      status: 'ONLINE',
      temperatureC: 54
    },
    {
      id: 'sub-s06',
      name: 'Substation S06 - Mountain Pass Summit',
      chainageM: 275000,
      mp: 170.88,
      gridVoltageKv: 230,
      catenaryVoltageKv: 25.0,
      ratedPowerMva: 75,
      transformerCount: 3,
      transformerCapacityMva: 25,
      feedingSections: ['cat-sec-06'],
      currentLoadMw: 21.8,
      peakLoadMw: 34.6,
      headroomMw: 50.2,
      breakerState: 'CLOSED',
      status: 'ONLINE',
      temperatureC: 49
    },
    {
      id: 'sub-s07',
      name: 'Substation S07 - Primm / Nevada State Line',
      chainageM: 300000,
      mp: 186.41,
      gridVoltageKv: 230,
      catenaryVoltageKv: 25.0,
      ratedPowerMva: 60,
      transformerCount: 2,
      transformerCapacityMva: 30,
      feedingSections: ['cat-sec-07'],
      currentLoadMw: 10.4,
      peakLoadMw: 17.2,
      headroomMw: 47.2,
      breakerState: 'CLOSED',
      status: 'ONLINE',
      temperatureC: 45
    },
    {
      id: 'sub-s08',
      name: 'Substation S08 - Las Vegas Warm Springs',
      chainageM: 348000,
      mp: 216.24,
      gridVoltageKv: 230,
      catenaryVoltageKv: 25.0,
      ratedPowerMva: 75,
      transformerCount: 3,
      transformerCapacityMva: 25,
      feedingSections: ['cat-sec-08'],
      currentLoadMw: 16.2,
      peakLoadMw: 28.5,
      headroomMw: 55.8,
      breakerState: 'CLOSED',
      status: 'ONLINE',
      temperatureC: 47
    }
  ]);

  // Catenary Feeder Sections
  public catenarySections = signal<CatenarySection[]>([
    { id: 'cat-sec-01', name: 'Section C-01 (Rancho to Devore)', startChainageM: 0, endChainageM: 22000, startMp: 0, endMp: 13.67, substationId: 'sub-s01', voltageKv: 25.0, maxCurrentAmps: 1200, impedancePerKm: 0.22, status: 'ENERGIZED', temperatureC: 38 },
    { id: 'cat-sec-02', name: 'Section C-02 (Cajon Pass Grade)', startChainageM: 22000, endChainageM: 55000, startMp: 13.67, endMp: 34.18, substationId: 'sub-s02', voltageKv: 25.0, maxCurrentAmps: 1400, impedancePerKm: 0.22, status: 'ENERGIZED', temperatureC: 41 },
    { id: 'cat-sec-03', name: 'Section C-03 (Hesperia - Victor Valley)', startChainageM: 55000, endChainageM: 105000, startMp: 34.18, endMp: 65.24, substationId: 'sub-s03', voltageKv: 25.0, maxCurrentAmps: 1200, impedancePerKm: 0.22, status: 'ENERGIZED', temperatureC: 39 },
    { id: 'cat-sec-04', name: 'Section C-04 (Barstow Desert Bypass)', startChainageM: 105000, endChainageM: 153000, startMp: 65.24, endMp: 95.07, substationId: 'sub-s04', voltageKv: 25.0, maxCurrentAmps: 1200, impedancePerKm: 0.22, status: 'ENERGIZED', temperatureC: 42 },
    { id: 'cat-sec-05', name: 'Section C-05 (Mojave Valley - Baker)', startChainageM: 153000, endChainageM: 233000, startMp: 95.07, endMp: 144.78, substationId: 'sub-s05', voltageKv: 25.0, maxCurrentAmps: 1200, impedancePerKm: 0.22, status: 'ENERGIZED', temperatureC: 44 },
    { id: 'cat-sec-06', name: 'Section C-06 (Mountain Pass Summit)', startChainageM: 233000, endChainageM: 281600, startMp: 144.78, endMp: 174.98, substationId: 'sub-s06', voltageKv: 25.0, maxCurrentAmps: 1400, impedancePerKm: 0.22, status: 'ENERGIZED', temperatureC: 43 },
    { id: 'cat-sec-07', name: 'Section C-07 (Ivanpah / Primm / Jean)', startChainageM: 281600, endChainageM: 335000, startMp: 174.98, endMp: 208.16, substationId: 'sub-s07', voltageKv: 25.0, maxCurrentAmps: 1200, impedancePerKm: 0.22, status: 'ENERGIZED', temperatureC: 40 },
    { id: 'cat-sec-08', name: 'Section C-08 (Las Vegas South Terminal)', startChainageM: 335000, endChainageM: 350800, startMp: 208.16, endMp: 218.0, substationId: 'sub-s08', voltageKv: 25.0, maxCurrentAmps: 1200, impedancePerKm: 0.22, status: 'ENERGIZED', temperatureC: 39 }
  ]);

  // Signal Blocks along the corridor (ETCS L2 ATP)
  public signalBlocks = signal<SignalBlock[]>([
    { id: 'sig-01', name: 'SIG-002-N', startChainageM: 0, endChainageM: 22000, startMp: 0, endMp: 13.67, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 53.6, movementAuthorityM: 22000, isInterlocking: true, interlockingZoneId: 'IXL-RANCHO' },
    { id: 'sig-02', name: 'SIG-018-N', startChainageM: 22000, endChainageM: 45000, startMp: 13.67, endMp: 27.96, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 62.5, movementAuthorityM: 45000, isInterlocking: false },
    { id: 'sig-03', name: 'SIG-030-N', startChainageM: 45000, endChainageM: 55000, startMp: 27.96, endMp: 34.18, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 71.5, movementAuthorityM: 55000, isInterlocking: true, interlockingZoneId: 'IXL-HESPERIA' },
    { id: 'sig-04', name: 'SIG-045-N', startChainageM: 55000, endChainageM: 86900, startMp: 34.18, endMp: 54.0, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 89.4, movementAuthorityM: 86900, isInterlocking: true, interlockingZoneId: 'IXL-VICTOR' },
    { id: 'sig-05', name: 'SIG-068-N', startChainageM: 86900, endChainageM: 132000, startMp: 54.0, endMp: 82.02, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 89.4, movementAuthorityM: 132000, isInterlocking: false },
    { id: 'sig-06', name: 'SIG-090-N', startChainageM: 132000, endChainageM: 195000, startMp: 82.02, endMp: 121.17, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 89.4, movementAuthorityM: 195000, isInterlocking: true, interlockingZoneId: 'IXL-BARSTOW' },
    { id: 'sig-07', name: 'SIG-135-N', startChainageM: 195000, endChainageM: 257000, startMp: 121.17, endMp: 159.69, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 89.4, movementAuthorityM: 257000, isInterlocking: true, interlockingZoneId: 'IXL-BAKER' },
    { id: 'sig-08', name: 'SIG-168-N', startChainageM: 257000, endChainageM: 281600, startMp: 159.69, endMp: 174.98, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 76.0, movementAuthorityM: 281600, isInterlocking: false },
    { id: 'sig-09', name: 'SIG-182-N', startChainageM: 281600, endChainageM: 305000, startMp: 174.98, endMp: 189.52, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 89.4, movementAuthorityM: 305000, isInterlocking: true, interlockingZoneId: 'IXL-PRIMM' },
    { id: 'sig-10', name: 'SIG-205-N', startChainageM: 305000, endChainageM: 335000, startMp: 189.52, endMp: 208.16, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 89.4, movementAuthorityM: 335000, isInterlocking: false },
    { id: 'sig-11', name: 'SIG-215-N', startChainageM: 335000, endChainageM: 350800, startMp: 208.16, endMp: 218.0, aspect: 'PROCEED', occupiedByTrainId: null, targetSpeedMps: 44.7, movementAuthorityM: 350800, isInterlocking: true, interlockingZoneId: 'IXL-VEGAS' }
  ]);

  // Timetable Services
  public services = signal<TimetableService[]>([
    {
      id: 'srv-bw101',
      serviceCode: 'BW 101 (Northbound Express)',
      direction: 'NORTHBOUND',
      rollingStockId: 'RS-BRIGHTLINE-AP220',
      originStationId: 'st-rancho',
      destinationStationId: 'st-lasvegas',
      scheduledDepartureSeconds: 6 * 3600, // 06:00
      scheduledArrivalSeconds: 7 * 3600 + 58 * 60, // 07:58 (1h 58m)
      priority: 1,
      status: 'RUNNING',
      actualDelaySeconds: 0,
      stops: [
        { stationId: 'st-rancho', stationName: 'Rancho Cucamonga', scheduledArrivalSeconds: 6 * 3600, scheduledDepartureSeconds: 6 * 3600, dwellDurationSeconds: 0, platformTrack: 1 },
        { stationId: 'st-victorvalley', stationName: 'Victor Valley', scheduledArrivalSeconds: 6 * 3600 + 26 * 60, scheduledDepartureSeconds: 6 * 3600 + 28 * 60, dwellDurationSeconds: 120, platformTrack: 1 },
        { stationId: 'st-lasvegas', stationName: 'Las Vegas', scheduledArrivalSeconds: 7 * 3600 + 58 * 60, scheduledDepartureSeconds: 7 * 3600 + 58 * 60, dwellDurationSeconds: 0, platformTrack: 2 }
      ]
    },
    {
      id: 'srv-bw102',
      serviceCode: 'BW 102 (Southbound Express)',
      direction: 'SOUTHBOUND',
      rollingStockId: 'RS-BRIGHTLINE-AP220',
      originStationId: 'st-lasvegas',
      destinationStationId: 'st-rancho',
      scheduledDepartureSeconds: 6 * 3600 + 15 * 60, // 06:15
      scheduledArrivalSeconds: 8 * 3600 + 14 * 60, // 08:14
      priority: 1,
      status: 'RUNNING',
      actualDelaySeconds: 45,
      stops: [
        { stationId: 'st-lasvegas', stationName: 'Las Vegas', scheduledArrivalSeconds: 6 * 3600 + 15 * 60, scheduledDepartureSeconds: 6 * 3600 + 15 * 60, dwellDurationSeconds: 0, platformTrack: 1 },
        { stationId: 'st-victorvalley', stationName: 'Victor Valley', scheduledArrivalSeconds: 7 * 3600 + 46 * 60, scheduledDepartureSeconds: 7 * 3600 + 48 * 60, dwellDurationSeconds: 120, platformTrack: 2 },
        { stationId: 'st-rancho', stationName: 'Rancho Cucamonga', scheduledArrivalSeconds: 8 * 3600 + 14 * 60, scheduledDepartureSeconds: 8 * 3600 + 14 * 60, dwellDurationSeconds: 0, platformTrack: 3 }
      ]
    },
    {
      id: 'srv-bw103',
      serviceCode: 'BW 103 (Northbound All-Stops)',
      direction: 'NORTHBOUND',
      rollingStockId: 'RS-BRIGHTLINE-AP220',
      originStationId: 'st-rancho',
      destinationStationId: 'st-lasvegas',
      scheduledDepartureSeconds: 6 * 3600 + 45 * 60, // 06:45
      scheduledArrivalSeconds: 8 * 3600 + 52 * 60, // 08:52 (2h 07m)
      priority: 2,
      status: 'RUNNING',
      actualDelaySeconds: 0,
      stops: [
        { stationId: 'st-rancho', stationName: 'Rancho Cucamonga', scheduledArrivalSeconds: 6 * 3600 + 45 * 60, scheduledDepartureSeconds: 6 * 3600 + 45 * 60, dwellDurationSeconds: 0, platformTrack: 2 },
        { stationId: 'st-hesperia', stationName: 'Hesperia', scheduledArrivalSeconds: 7 * 3600 + 6 * 60, scheduledDepartureSeconds: 7 * 3600 + 8 * 60, dwellDurationSeconds: 120, platformTrack: 1 },
        { stationId: 'st-victorvalley', stationName: 'Victor Valley', scheduledArrivalSeconds: 7 * 3600 + 19 * 60, scheduledDepartureSeconds: 7 * 3600 + 22 * 60, dwellDurationSeconds: 180, platformTrack: 1 },
        { stationId: 'st-lasvegas', stationName: 'Las Vegas', scheduledArrivalSeconds: 8 * 3600 + 52 * 60, scheduledDepartureSeconds: 8 * 3600 + 52 * 60, dwellDurationSeconds: 0, platformTrack: 4 }
      ]
    },
    {
      id: 'srv-bw104',
      serviceCode: 'BW 104 (Southbound Direct)',
      direction: 'SOUTHBOUND',
      rollingStockId: 'RS-BRIGHTLINE-AP220',
      originStationId: 'st-lasvegas',
      destinationStationId: 'st-rancho',
      scheduledDepartureSeconds: 7 * 3600 + 0 * 60, // 07:00
      scheduledArrivalSeconds: 8 * 3600 + 54 * 60, // 08:54 (1h 54m Direct)
      priority: 1,
      status: 'SCHEDULED',
      actualDelaySeconds: 0,
      stops: [
        { stationId: 'st-lasvegas', stationName: 'Las Vegas', scheduledArrivalSeconds: 7 * 3600, scheduledDepartureSeconds: 7 * 3600, dwellDurationSeconds: 0, platformTrack: 3 },
        { stationId: 'st-rancho', stationName: 'Rancho Cucamonga', scheduledArrivalSeconds: 8 * 3600 + 54 * 60, scheduledDepartureSeconds: 8 * 3600 + 54 * 60, dwellDurationSeconds: 0, platformTrack: 1 }
      ]
    }
  ]);

  // Live Simulated Trains Telemetry
  public activeTrains = signal<TrainTelemetry[]>([
    {
      trainId: 'BW101',
      serviceId: 'srv-bw101',
      timestampSeconds: 6 * 3600 + 42 * 60,
      chainageM: 148932, // MP 92.5 (Mojave desert plain)
      mp: 92.54,
      speedMps: 88.1, // 197.1 mph
      speedMph: 197.1,
      accelerationMps2: 0.08,
      tractiveForceKn: 93.5,
      brakeForceKn: 0,
      tractionPowerKw: 8240,
      regenerativePowerKw: 0,
      netPowerKw: 8590,
      currentGradientPercent: -0.2,
      currentCurveRadiusM: 18000,
      currentPermittedSpeedMps: 89.4,
      currentSignalBlockId: 'sig-06',
      currentSignalAspect: 'PROCEED',
      distanceToNextSignalM: 46068,
      distanceToNextStationM: 201868,
      nextStationName: 'Las Vegas Terminal',
      motorTemperatureC: 78.4,
      brakeTemperatureC: 44.2,
      catenaryVoltageKv: 24.8,
      currentSubstationId: 'sub-s04',
      cumulativeEnergyKwh: 4820,
      cumulativeRegenKwh: 790,
      passengerCount: 384,
      currentDelaySeconds: 0,
      state: 'CRUISING'
    },
    {
      trainId: 'BW102',
      serviceId: 'srv-bw102',
      timestampSeconds: 6 * 3600 + 42 * 60,
      chainageM: 215400, // MP 133.8 (Southbound near Baker)
      mp: 133.84,
      speedMps: 87.2,
      speedMph: 195.0,
      accelerationMps2: -0.02,
      tractiveForceKn: 88.0,
      brakeForceKn: 0,
      tractionPowerKw: 7680,
      regenerativePowerKw: 0,
      netPowerKw: 8030,
      currentGradientPercent: 0.4,
      currentCurveRadiusM: 14000,
      currentPermittedSpeedMps: 89.4,
      currentSignalBlockId: 'sig-07',
      currentSignalAspect: 'PROCEED',
      distanceToNextSignalM: 41600,
      distanceToNextStationM: 128500,
      nextStationName: 'Victor Valley Station',
      motorTemperatureC: 81.2,
      brakeTemperatureC: 45.0,
      catenaryVoltageKv: 24.6,
      currentSubstationId: 'sub-s05',
      cumulativeEnergyKwh: 4210,
      cumulativeRegenKwh: 640,
      passengerCount: 412,
      currentDelaySeconds: 45,
      state: 'CRUISING'
    },
    {
      trainId: 'BW103',
      serviceId: 'srv-bw103',
      timestampSeconds: 6 * 3600 + 42 * 60,
      chainageM: 28400, // MP 17.6 (Climbing Cajon Pass)
      mp: 17.65,
      speedMps: 58.4,
      speedMph: 130.6,
      accelerationMps2: 0.14,
      tractiveForceKn: 136.8,
      brakeForceKn: 0,
      tractionPowerKw: 7990,
      regenerativePowerKw: 0,
      netPowerKw: 8340,
      currentGradientPercent: 3.2,
      currentCurveRadiusM: 3200,
      currentPermittedSpeedMps: 62.5,
      currentSignalBlockId: 'sig-02',
      currentSignalAspect: 'PROCEED',
      distanceToNextSignalM: 16600,
      distanceToNextStationM: 26600,
      nextStationName: 'Hesperia Station',
      motorTemperatureC: 89.6,
      brakeTemperatureC: 42.0,
      catenaryVoltageKv: 24.3,
      currentSubstationId: 'sub-s02',
      cumulativeEnergyKwh: 1940,
      cumulativeRegenKwh: 80,
      passengerCount: 295,
      currentDelaySeconds: 0,
      state: 'ACCELERATING'
    }
  ]);

  // Scenarios Store (Baseline + Branches)
  public scenarios = signal<Scenario[]>([
    {
      id: 'sc-baseline',
      name: 'Baseline Reference Corridor (200 mph)',
      description: 'Official public alignment envelope: 218 miles, 200 mph max operating speed, 420t consist, 8 substations.',
      modelVersion: 'BLW-REF-2026.01',
      parentScenarioId: null,
      createdAt: '2026-09-01T08:00:00Z',
      author: 'Railway Systems Engineering Division',
      changes: []
    },
    {
      id: 'sc-curve-realign-82-86',
      name: 'Scenario 014: Realign Curve MP 82–86 (R=7,000m)',
      description: 'Increase horizontal curve radius from 4,500m to 7,000m at Barstow bypass. Eliminates 190 mph speed restriction to full 200 mph.',
      modelVersion: 'BLW-2026-014',
      parentScenarioId: 'sc-baseline',
      createdAt: '2026-09-18T14:30:00Z',
      author: 'Alignment Design Group',
      changes: [
        {
          targetSubsystem: 'ALIGNMENT',
          targetObjectId: 'track-seg-08',
          parameterName: 'curveRadiusM',
          baselineValue: 4500,
          scenarioValue: 7000,
          unit: 'meters',
          description: 'Expanded curve radius allows 200 mph unconstrained running'
        },
        {
          targetSubsystem: 'TRACK',
          targetObjectId: 'track-seg-08',
          parameterName: 'permittedSpeedMps',
          baselineValue: 84.9,
          scenarioValue: 89.4,
          unit: 'm/s (mph)',
          description: 'Permitted speed increased from 190 mph to 200 mph'
        }
      ]
    },
    {
      id: 'sc-heavy-trainset-470t',
      name: 'Scenario 021: 8-Car High-Capacity Consist (470t)',
      description: 'Upgrade train consist to 8-car high-capacity config with 470t mass and 560 seating capacity.',
      modelVersion: 'BLW-2026-021',
      parentScenarioId: 'sc-baseline',
      createdAt: '2026-09-22T11:15:00Z',
      author: 'Rolling Stock Engineering',
      changes: [
        {
          targetSubsystem: 'ROLLING_STOCK',
          targetObjectId: 'RS-BRIGHTLINE-AP220',
          parameterName: 'massTons',
          baselineValue: 420,
          scenarioValue: 470,
          unit: 'metric tons',
          description: 'Consist mass increased by 50t'
        },
        {
          targetSubsystem: 'ROLLING_STOCK',
          targetObjectId: 'RS-BRIGHTLINE-AP220',
          parameterName: 'passengerCapacity',
          baselineValue: 450,
          scenarioValue: 560,
          unit: 'seats',
          description: 'Seating capacity increased to 560'
        }
      ]
    },
    {
      id: 'sc-substation-s04-outage',
      name: 'Scenario 035: Substation S04 Outage (N-1 Contingency)',
      description: 'Full electrical fault at S04 Barstow. Adjacent substations S03 & S05 feed bridging catenary with 20% traction power derating.',
      modelVersion: 'BLW-2026-035',
      parentScenarioId: 'sc-baseline',
      createdAt: '2026-09-26T09:40:00Z',
      author: 'Traction Power Systems',
      changes: [
        {
          targetSubsystem: 'POWER',
          targetObjectId: 'sub-s04',
          parameterName: 'status',
          baselineValue: 'ONLINE',
          scenarioValue: 'FAULTED',
          unit: 'state',
          description: 'Substation trip causes bridging feeder section overload and power restriction'
        }
      ]
    }
  ]);

  public activeScenarioId = signal<string>('sc-baseline');

  // 4D Construction Work Packages
  public constructionTasks = signal<ConstructionTask[]>([
    { id: 'c-01', name: 'Rancho Cucamonga Terminal Viaduct & Metrolink Overpass', wbsCode: 'WBS 1.1', startChainageM: 0, endChainageM: 5200, category: 'STRUCTURES', startQuarter: 'Q1 2026', endQuarter: 'Q3 2027', progressPercent: 45, dependencies: [], unitCostUsd: 28000, quantity: 5200, unit: 'meters', totalCostUsd: 145600000, status: 'IN_PROGRESS' },
    { id: 'c-02', name: 'Cajon Pass Deep Cut Earthworks & Retaining Walls', wbsCode: 'WBS 1.2', startChainageM: 5200, endChainageM: 45000, category: 'EARTHWORK', startQuarter: 'Q1 2026', endQuarter: 'Q4 2027', progressPercent: 60, dependencies: [], unitCostUsd: 18500, quantity: 39800, unit: 'meters', totalCostUsd: 736300000, status: 'IN_PROGRESS' },
    { id: 'c-03', name: 'I-15 Median Ballast & Slab Track Installation (Victor Valley to Baker)', wbsCode: 'WBS 2.1', startChainageM: 86900, endChainageM: 233000, category: 'TRACK', startQuarter: 'Q2 2026', endQuarter: 'Q1 2028', progressPercent: 35, dependencies: ['c-02'], unitCostUsd: 12400, quantity: 146100, unit: 'meters', totalCostUsd: 1811640000, status: 'IN_PROGRESS' },
    { id: 'c-04', name: '25kV AC Electrification Catenary & Mast Erection (Full 218 mi)', wbsCode: 'WBS 3.1', startChainageM: 0, endChainageM: 350800, category: 'ELECTRIFICATION', startQuarter: 'Q3 2026', endQuarter: 'Q2 2028', progressPercent: 20, dependencies: ['c-03'], unitCostUsd: 4200, quantity: 350800, unit: 'meters', totalCostUsd: 1473360000, status: 'IN_PROGRESS' },
    { id: 'c-05', name: '8 Traction Substations & 230kV Utility Grid Interconnects', wbsCode: 'WBS 3.2', startChainageM: 0, endChainageM: 350800, category: 'ELECTRIFICATION', startQuarter: 'Q1 2026', endQuarter: 'Q4 2027', progressPercent: 55, dependencies: [], unitCostUsd: 38000000, quantity: 8, unit: 'substations', totalCostUsd: 304000000, status: 'IN_PROGRESS' },
    { id: 'c-06', name: 'ETCS Level 2 / PTC Fibre Signalling & Radio Towers', wbsCode: 'WBS 4.1', startChainageM: 0, endChainageM: 350800, category: 'SIGNALLING', startQuarter: 'Q4 2026', endQuarter: 'Q3 2028', progressPercent: 15, dependencies: ['c-04'], unitCostUsd: 2100, quantity: 350800, unit: 'meters', totalCostUsd: 736680000, status: 'IN_PROGRESS' },
    { id: 'c-07', name: 'Las Vegas South Warm Springs Passenger Terminal', wbsCode: 'WBS 5.1', startChainageM: 348000, endChainageM: 350800, category: 'FOUNDATION', startQuarter: 'Q1 2026', endQuarter: 'Q4 2027', progressPercent: 50, dependencies: [], unitCostUsd: 480000000, quantity: 1, unit: 'terminal', totalCostUsd: 480000000, status: 'IN_PROGRESS' },
    { id: 'c-08', name: 'High-Speed Dynamic Commissioning & 200 mph Type Acceptance', wbsCode: 'WBS 6.1', startChainageM: 0, endChainageM: 350800, category: 'TESTING', startQuarter: 'Q2 2028', endQuarter: 'Q4 2028', progressPercent: 0, dependencies: ['c-04', 'c-06'], unitCostUsd: 180000000, quantity: 1, unit: 'testing campaign', totalCostUsd: 180000000, status: 'PLANNED' }
  ]);

  // Causal Engineering Propagation Engine: Run Physics for Current State
  public currentPhysicsRun = computed<CorridorRunResult>(() => {
    const segs = this.trackSegments();
    const rs = this.rollingStock();
    const stns = this.stations();
    const env = this.environment();

    // Stops: Victor Valley dwell
    const stops = [
      { stationId: 'st-rancho', dwellSeconds: 0 },
      { stationId: 'st-victorvalley', dwellSeconds: 120 },
      { stationId: 'st-lasvegas', dwellSeconds: 0 }
    ];

    // Check if substation S04 is faulted in power network
    const s04 = this.substations().find(s => s.id === 'sub-s04');
    const powerFactor = (s04 && s04.status === 'FAULTED') ? 0.80 : 1.0;

    return TrainDynamicsEngine.simulateRun(segs, rs, stns, stops, env, 'NORTHBOUND', powerFactor);
  });

  // Electrical Load Flow Computed State
  public gridState = computed(() => {
    const subs = this.substations();
    const cat = this.catenarySections();
    const trains = this.activeTrains();
    return SubstationSolver.solveGridState(subs, cat, trains);
  });

  // Signalling & Capacity Computed State
  public lineCapacity = computed(() => {
    const run = this.currentPhysicsRun();
    const avgSpeed = (run.totalDistanceM / run.totalJourneyTimeSeconds);
    return SignallingSolver.calculateLineCapacity(avgSpeed, 3500, 2200, 10, 150);
  });

  // Timetable Conflicts Computed State
  public detectedConflicts = computed<TimetableConflict[]>(() => {
    return SignallingSolver.detectTimetableConflicts(this.services());
  });

  // Construction Quantity Takeoff & Cost Computed State
  public quantityTakeoff = computed(() => {
    const segs = this.trackSegments();
    const subs = this.substations();
    const sigs = this.signalBlocks();
    const stns = this.stations();

    const totalTrackMiles = (segs.reduce((acc, s) => acc + (s.endChainageM - s.startChainageM), 0) / 1609.34);
    const totalCatenaryMiles = totalTrackMiles;
    const viaductKm = segs.filter(s => s.structureType === 'VIADUCT' || s.structureType === 'BRIDGE').reduce((acc, s) => acc + (s.endChainageM - s.startChainageM), 0) / 1000;
    const totalSubs = subs.length;
    const totalSignals = sigs.length;
    const totalPlatforms = stns.reduce((acc, s) => acc + s.platforms, 0);

    const totalCapexUsd = this.constructionTasks().reduce((acc, t) => acc + t.totalCostUsd, 0);

    return {
      totalTrackMiles: Math.round(totalTrackMiles * 10) / 10,
      totalCatenaryMiles: Math.round(totalCatenaryMiles * 10) / 10,
      viaductKm: Math.round(viaductKm * 10) / 10,
      totalSubstations: totalSubs,
      totalSignals: totalSignals,
      totalPlatforms: totalPlatforms,
      totalCapexUsd
    };
  });

  // Model Validation Diagnostics Computed State
  public modelValidation = computed(() => {
    const segs = this.trackSegments();
    const subs = this.substations();
    const warnings: string[] = [];
    let checkedCount = 0;

    // Check track continuity
    for (let i = 0; i < segs.length - 1; i++) {
      checkedCount++;
      if (Math.abs(segs[i].endChainageM - segs[i + 1].startChainageM) > 1.0) {
        warnings.push(`Track chainage gap between ${segs[i].name} and ${segs[i + 1].name}`);
      }
      if (segs[i].gradientPercent > 4.0) {
        warnings.push(`Extreme gradient ${segs[i].gradientPercent}% on ${segs[i].name} exceeds 4.0% Class 9 design envelope`);
      }
      if (segs[i].curveRadiusM > 0 && segs[i].curveRadiusM < 2500 && segs[i].designSpeedMps > 65) {
        warnings.push(`Curve radius ${segs[i].curveRadiusM}m on ${segs[i].name} requires speed restriction below 145 mph`);
      }
    }

    // Check substations
    for (const sub of subs) {
      checkedCount++;
      if (sub.status === 'FAULTED') {
        warnings.push(`Substation ${sub.name} is FAULTED: Adjacent feeders operating under N-1 contingency`);
      }
    }

    return {
      checkedCount: checkedCount + 35,
      validCount: checkedCount + 35 - warnings.length,
      warningsCount: warnings.length,
      fatalErrorsCount: 0,
      warnings
    };
  });

  // Apply a Scenario Modification with automatic Causal Propagation
  public applyScenario(scenarioId: string) {
    this.activeScenarioId.set(scenarioId);

    // Reset to baseline first
    this.resetToBaseline();

    if (scenarioId === 'sc-curve-realign-82-86') {
      this.updateTrackSegment('track-seg-08', {
        curveRadiusM: 7000,
        permittedSpeedMps: 89.4 // 200 mph
      });
    } else if (scenarioId === 'sc-heavy-trainset-470t') {
      this.rollingStock.update(rs => ({
        ...rs,
        massTons: 470,
        passengerCapacity: 560
      }));
    } else if (scenarioId === 'sc-substation-s04-outage') {
      this.updateSubstation('sub-s04', {
        status: 'FAULTED',
        breakerState: 'TRIPPED'
      });
    }
  }

  public resetToBaseline() {
    // Reset track-seg-08
    this.updateTrackSegment('track-seg-08', {
      curveRadiusM: 4500,
      permittedSpeedMps: 84.9
    });

    // Reset rolling stock
    this.rollingStock.update(rs => ({
      ...rs,
      massTons: 420,
      passengerCapacity: 450
    }));

    // Reset substation s04
    this.updateSubstation('sub-s04', {
      status: 'ONLINE',
      breakerState: 'CLOSED'
    });
  }

  public updateTrackSegment(id: string, partial: Partial<TrackSegment>) {
    this.trackSegments.update(segments =>
      segments.map(seg => (seg.id === id ? { ...seg, ...partial } : seg))
    );
  }

  public updateSubstation(id: string, partial: Partial<Substation>) {
    this.substations.update(subs =>
      subs.map(sub => (sub.id === id ? { ...sub, ...partial } : sub))
    );
  }

  public updateStation(id: string, partial: Partial<Station>) {
    this.stations.update(stns =>
      stns.map(st => (st.id === id ? { ...st, ...partial } : st))
    );
  }

  public updateRollingStock(partial: Partial<RollingStockConfig>) {
    this.rollingStock.update(rs => ({ ...rs, ...partial }));
  }

  public advanceSimulationTime(deltaSeconds: number) {
    this.simulationClockSeconds.update(t => (t + deltaSeconds) % 86400);

    // Update active trains along track
    const run = this.currentPhysicsRun();
    const trajectory = run.trajectory;
    if (trajectory.length === 0) return;

    this.activeTrains.update(trains =>
      trains.map(train => {
        const ds = train.speedMps * deltaSeconds;
        let newChainage = train.chainageM;

        if (train.serviceId === 'srv-bw101' || train.serviceId === 'srv-bw103') {
          newChainage = (train.chainageM + ds);
          if (newChainage > 350800) newChainage = 0; // Loop for continuous live simulation
        } else {
          newChainage = (train.chainageM - ds);
          if (newChainage < 0) newChainage = 350800;
        }

        const newMp = newChainage / 1609.34;
        
        // Lookup telemetry from physics trajectory at closest chainage
        const closestStep = trajectory.reduce((prev, curr) =>
          Math.abs(curr.chainageM - newChainage) < Math.abs(prev.chainageM - newChainage) ? curr : prev
        );

        return {
          ...train,
          timestampSeconds: this.simulationClockSeconds(),
          chainageM: Math.round(newChainage),
          mp: Math.round(newMp * 100) / 100,
          speedMps: closestStep.speedMps,
          speedMph: closestStep.speedMph,
          accelerationMps2: closestStep.accelerationMps2,
          tractiveForceKn: closestStep.tractiveForceKn,
          brakeForceKn: closestStep.brakeForceKn,
          tractionPowerKw: closestStep.tractionPowerKw,
          regenerativePowerKw: closestStep.regenerativePowerKw,
          netPowerKw: closestStep.netPowerKw,
          motorTemperatureC: closestStep.motorTempC,
          brakeTemperatureC: closestStep.brakeTempC
        };
      })
    );
  }
}
