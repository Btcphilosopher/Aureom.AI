/**
 * BRIGHTLINE WEST DIGITAL TWIN - ELECTRICAL GRID & SUBSTATION LOAD SOLVER
 * Models 25kV AC 60Hz catenary feeder sections, substation transformer loads,
 * voltage drop (Z = 0.22 Ohm/km), and multi-train regenerative energy exchanges.
 */

import { Substation, CatenarySection, TrainTelemetry } from '../models/digital-twin.model';

export interface SubstationLoadResult {
  substationId: string;
  name: string;
  loadMva: number;
  capacityMva: number;
  utilizationPercent: number;
  headroomMw: number;
  activeTrainsCount: number;
  voltageKv: number;
  catenaryLossesKw: number;
  status: 'OPTIMAL' | 'LOADED' | 'NEAR_CAPACITY' | 'OVERLOADED' | 'FAULTED';
}

export class SubstationSolver {
  private static readonly NOMINAL_CATENARY_VOLTAGE_KV = 25.0;
  private static readonly POWER_FACTOR = 0.96; // Modern IGBT 4-quadrant converter
  private static readonly CATENARY_IMPEDANCE_OHM_PER_KM = 0.22;

  /**
   * Solves instantaneous power flow across all substations and catenary sections
   */
  public static solveGridState(
    substations: Substation[],
    catenarySections: CatenarySection[],
    activeTrains: TrainTelemetry[]
  ): {
    substationResults: SubstationLoadResult[];
    totalGridDrawMw: number;
    totalRegenRecoveredMw: number;
    totalGridLossesKw: number;
  } {
    let totalDrawKw = 0;
    let totalRegenKw = 0;
    let totalLossesKw = 0;

    const subMap = new Map<string, {
      sub: Substation;
      trains: TrainTelemetry[];
      tractionKw: number;
      regenKw: number;
      lossesKw: number;
    }>();

    for (const sub of substations) {
      subMap.set(sub.id, {
        sub,
        trains: [],
        tractionKw: 0,
        regenKw: 0,
        lossesKw: 0
      });
    }

    // Allocate trains to the nearest catenary section and feeding substation
    for (const train of activeTrains) {
      const catSection = catenarySections.find(
        cs => train.chainageM >= cs.startChainageM && train.chainageM <= cs.endChainageM
      ) || catenarySections[0];

      let subId = catSection ? catSection.substationId : substations[0].id;
      let subEntry = subMap.get(subId);

      // If substation is faulted or isolated, transfer load to adjacent substation
      if (!subEntry || subEntry.sub.status !== 'ONLINE') {
        const onlineSubs = substations.filter(s => s.status === 'ONLINE');
        if (onlineSubs.length > 0) {
          // Find closest online substation by chainage
          const closest = onlineSubs.reduce((prev, curr) => 
            Math.abs(curr.chainageM - train.chainageM) < Math.abs(prev.chainageM - train.chainageM) ? curr : prev
          );
          subId = closest.id;
          subEntry = subMap.get(subId);
        }
      }

      if (subEntry) {
        subEntry.trains.push(train);
        
        if (train.netPowerKw > 0) {
          subEntry.tractionKw += train.netPowerKw;
          totalDrawKw += train.netPowerKw;
        } else {
          const regen = Math.abs(train.netPowerKw);
          subEntry.regenKw += regen;
          totalRegenKw += regen;
        }

        // Calculate I²R transmission loss in catenary feeder line
        const distanceToSubKm = Math.abs(train.chainageM - subEntry.sub.chainageM) / 1000;
        const currentAmps = (Math.abs(train.netPowerKw) * 1000) / (SubstationSolver.NOMINAL_CATENARY_VOLTAGE_KV * 1000 * SubstationSolver.POWER_FACTOR);
        const lineResistance = distanceToSubKm * SubstationSolver.CATENARY_IMPEDANCE_OHM_PER_KM;
        const lossKw = (Math.pow(currentAmps, 2) * lineResistance) / 1000;
        subEntry.lossesKw += lossKw;
        totalLossesKw += lossKw;
      }
    }

    const substationResults: SubstationLoadResult[] = substations.map(sub => {
      const entry = subMap.get(sub.id)!;
      if (sub.status !== 'ONLINE') {
        return {
          substationId: sub.id,
          name: sub.name,
          loadMva: 0,
          capacityMva: sub.ratedPowerMva,
          utilizationPercent: 0,
          headroomMw: 0,
          activeTrainsCount: 0,
          voltageKv: 0,
          catenaryLossesKw: 0,
          status: 'FAULTED'
        };
      }

      // Net active power at substation bus (trains in same feeder section share regen directly)
      const netSubPowerKw = Math.max(0, entry.tractionKw - (entry.regenKw * 0.92) + entry.lossesKw);
      const loadMw = netSubPowerKw / 1000;
      const loadMva = loadMw / SubstationSolver.POWER_FACTOR;
      const utilization = (loadMva / sub.ratedPowerMva) * 100;
      const headroomMw = Math.max(0, (sub.ratedPowerMva * SubstationSolver.POWER_FACTOR) - loadMw);

      let status: 'OPTIMAL' | 'LOADED' | 'NEAR_CAPACITY' | 'OVERLOADED' = 'OPTIMAL';
      if (utilization > 100) status = 'OVERLOADED';
      else if (utilization > 85) status = 'NEAR_CAPACITY';
      else if (utilization > 50) status = 'LOADED';

      // Estimate catenary voltage at bus
      const voltageKv = SubstationSolver.NOMINAL_CATENARY_VOLTAGE_KV * (1 - (utilization / 100) * 0.05);

      return {
        substationId: sub.id,
        name: sub.name,
        loadMva: Math.round(loadMva * 10) / 10,
        capacityMva: sub.ratedPowerMva,
        utilizationPercent: Math.round(utilization * 10) / 10,
        headroomMw: Math.round(headroomMw * 10) / 10,
        activeTrainsCount: entry.trains.length,
        voltageKv: Math.round(voltageKv * 10) / 10,
        catenaryLossesKw: Math.round(entry.lossesKw * 10) / 10,
        status
      };
    });

    return {
      substationResults,
      totalGridDrawMw: Math.round((totalDrawKw / 1000) * 10) / 10,
      totalRegenRecoveredMw: Math.round((totalRegenKw / 1000) * 10) / 10,
      totalGridLossesKw: Math.round(totalLossesKw)
    };
  }
}
