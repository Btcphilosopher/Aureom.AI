/**
 * BRIGHTLINE WEST DIGITAL TWIN - SIGNALLING, INTERLOCKING & HEADWAY SOLVER
 * Abstract high-speed moving / multi-aspect block model with ATP movement authorities,
 * route conflict detection, and theoretical capacity calculations.
 */

import { SignalBlock, SignalAspect, TrainTelemetry, TimetableService } from '../models/digital-twin.model';

export interface RouteLock {
  interlockingZoneId: string;
  lockedForTrainId: string;
  entryBlockId: string;
  exitBlockId: string;
  pointsState: 'NORMAL' | 'REVERSE';
  isClear: boolean;
}

export interface TimetableConflict {
  conflictId: string;
  trainId1: string;
  trainId2: string;
  locationMp: number;
  chainageM: number;
  timeSeconds: number;
  severity: 'HEADWAY_INFRINGEMENT' | 'CROSSOVER_CONFLICT' | 'PLATFORM_CLASH';
  description: string;
}

export class SignallingSolver {
  /**
   * Updates signal block states based on active train positions and route interlocking
   */
  public static updateSignalStates(
    signalBlocks: SignalBlock[],
    activeTrains: TrainTelemetry[]
  ): SignalBlock[] {
    const updatedBlocks = signalBlocks.map(block => ({
      ...block,
      occupiedByTrainId: null as string | null,
      aspect: 'PROCEED' as SignalAspect,
      targetSpeedMps: 89.4
    }));

    // Determine occupancy
    for (const train of activeTrains) {
      const occupiedBlock = updatedBlocks.find(
        b => train.chainageM >= b.startChainageM && train.chainageM < b.endChainageM
      );
      if (occupiedBlock) {
        occupiedBlock.occupiedByTrainId = train.trainId;
        occupiedBlock.aspect = 'STOP';
        occupiedBlock.targetSpeedMps = 0;
      }
    }

    // Apply multi-aspect cascade for safety braking distance
    // STOP (Block N) -> CAUTION (Block N-1) -> ADVANCE_CAUTION (Block N-2) -> PROCEED (Block N-3+)
    const sorted = [...updatedBlocks].sort((a, b) => a.startChainageM - b.startChainageM);

    for (let i = 0; i < sorted.length; i++) {
      if (sorted[i].aspect === 'STOP') {
        // Preceding block in UP direction (towards LV)
        if (i > 0 && sorted[i - 1].aspect !== 'STOP') {
          sorted[i - 1].aspect = 'CAUTION';
          sorted[i - 1].targetSpeedMps = 35.7; // ~80 mph approach
        }
        if (i > 1 && sorted[i - 2].aspect !== 'STOP' && sorted[i - 2].aspect !== 'CAUTION') {
          sorted[i - 2].aspect = 'ADVANCE_CAUTION';
          sorted[i - 2].targetSpeedMps = 62.5; // ~140 mph approach
        }
      }
    }

    return sorted;
  }

  /**
   * Calculates minimum headway and theoretical line capacity (trains/hour)
   */
  public static calculateLineCapacity(
    averageSpeedMps: number,
    averageBlockLengthM: number,
    emergencyBrakeDistanceM: number,
    signalReactionTimeSec = 10,
    stationDwellTimeSec = 180
  ): {
    minimumHeadwaySeconds: number;
    theoreticalCapacityTph: number;
    practicalCapacityTph: number;
  } {
    // Headway = (BlockLength + TrainLength + BrakingDistance) / Speed + SightingTime + StationDwell
    const trainLengthM = 200;
    const safetyBufferSec = 30;

    const runningHeadwaySec = ((averageBlockLengthM * 3) + trainLengthM + emergencyBrakeDistanceM) / averageSpeedMps + signalReactionTimeSec;
    const minHeadwaySec = Math.max(120, runningHeadwaySec + (stationDwellTimeSec * 0.4) + safetyBufferSec);

    const theoreticalTph = Math.floor(3600 / minHeadwaySec);
    const practicalTph = Math.floor(theoreticalTph * 0.75); // 75% UIC 406 stability buffer

    return {
      minimumHeadwaySeconds: Math.round(minHeadwaySec),
      theoreticalCapacityTph: theoreticalTph,
      practicalCapacityTph: practicalTph
    };
  }

  /**
   * Detects timetable conflicts across train path schedules
   */
  public static detectTimetableConflicts(
    services: TimetableService[]
  ): TimetableConflict[] {
    const conflicts: TimetableConflict[] = [];

    // Compare pairs of services
    for (let i = 0; i < services.length; i++) {
      for (let j = i + 1; j < services.length; j++) {
        const s1 = services[i];
        const s2 = services[j];

        // Check same direction headway violation
        if (s1.direction === s2.direction) {
          const departureDiff = Math.abs(s1.scheduledDepartureSeconds - s2.scheduledDepartureSeconds);
          if (departureDiff < 180) { // Under 3 min headway
            conflicts.push({
              conflictId: `CONF-${s1.id}-${s2.id}`,
              trainId1: s1.serviceCode,
              trainId2: s2.serviceCode,
              locationMp: 0,
              chainageM: 0,
              timeSeconds: s1.scheduledDepartureSeconds,
              severity: 'HEADWAY_INFRINGEMENT',
              description: `Headway between ${s1.serviceCode} and ${s2.serviceCode} (${Math.round(departureDiff)}s) is below the minimum safe separation of 180s.`
            });
          }
        }

        // Check station platform clashes
        for (const stop1 of s1.stops) {
          for (const stop2 of s2.stops) {
            if (stop1.stationId === stop2.stationId && stop1.platformTrack === stop2.platformTrack) {
              const overlap = (stop1.scheduledArrivalSeconds < stop2.scheduledDepartureSeconds) &&
                              (stop2.scheduledArrivalSeconds < stop1.scheduledDepartureSeconds);
              if (overlap) {
                conflicts.push({
                  conflictId: `PLAT-${stop1.stationId}-${s1.id}-${s2.id}`,
                  trainId1: s1.serviceCode,
                  trainId2: s2.serviceCode,
                  locationMp: 0,
                  chainageM: 0,
                  timeSeconds: stop1.scheduledArrivalSeconds,
                  severity: 'PLATFORM_CLASH',
                  description: `Platform track ${stop1.platformTrack} at ${stop1.stationName} scheduled for concurrent occupancy by ${s1.serviceCode} and ${s2.serviceCode}.`
                });
              }
            }
          }
        }
      }
    }

    return conflicts;
  }
}
