/**
 * BRIGHTLINE WEST DIGITAL TWIN - MONTE CARLO STOCHASTIC SIMULATION ENGINE
 * Evaluates corridor robustness, delay propagation, desert ambient variations (100–10,000 iterations),
 * and generates empirical percentile distributions (P50, P90, P95, P99).
 */

import { TrackSegment, RollingStockConfig, EnvironmentalConditions, Station, MonteCarloSummary, MonteCarloIteration } from '../models/digital-twin.model';
import { TrainDynamicsEngine } from './train-dynamics';

export class MonteCarloEngine {
  /**
   * Runs N stochastic iterations with varied environmental and operational disturbances
   */
  public static runSimulation(
    segments: TrackSegment[],
    rollingStock: RollingStockConfig,
    stations: Station[],
    stops: { stationId: string; dwellSeconds: number }[],
    baseEnv: EnvironmentalConditions,
    iterationCount = 100
  ): MonteCarloSummary {
    const iterations: MonteCarloIteration[] = [];

    // Deterministic seed PRNG for reproducibility
    let seed = 42;
    const pseudoRandom = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };

    // Box-Muller normal distribution generator
    const randomNormal = (mean: number, stdDev: number) => {
      const u1 = Math.max(1e-6, pseudoRandom());
      const u2 = Math.max(1e-6, pseudoRandom());
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      return mean + z * stdDev;
    };

    // Calculate baseline run
    const baseResult = TrainDynamicsEngine.simulateRun(segments, rollingStock, stations, stops, baseEnv, 'NORTHBOUND');
    const baseJourneyTimeMin = baseResult.totalJourneyTimeSeconds / 60;
    const baseEnergyMwh = baseResult.netEnergyKwh / 1000;

    for (let i = 0; i < iterationCount; i++) {
      // Stochastic variables
      // 1. Ambient temperature in desert (mean ~36°C, stddev ~5°C)
      const ambientTemp = Math.min(48, Math.max(15, randomNormal(baseEnv.ambientTemperatureC, 4.5)));
      // 2. Wind gust speed (mean ~5 m/s, stddev ~3 m/s)
      const windSpeed = Math.max(0, randomNormal(baseEnv.windSpeedMps, 3.0));
      // 3. Adhesion derating factor (dust/heat rail contact)
      const adhesion = Math.min(1.0, Math.max(0.65, randomNormal(baseEnv.adhesionFactor, 0.05)));
      // 4. Passenger dwell variation (crowding factor: +/- 30 seconds)
      const dwellFactor = Math.max(0.8, randomNormal(1.0, 0.15));

      // Random minor signal check or power restriction probability (5% chance)
      const powerFactor = pseudoRandom() < 0.05 ? 0.75 : 1.0;

      // Small sample or analytical delta approximation for high-iteration speed
      const tempDelta = ambientTemp - baseEnv.ambientTemperatureC;
      const windDelta = windSpeed - baseEnv.windSpeedMps;
      const adhesionDelta = (1.0 - adhesion) * 2.0; // Adhesion loss penalty on acceleration
      
      const journeyTimeDeltaMin = (tempDelta * 0.08) + (windDelta * 0.12) + adhesionDelta + ((dwellFactor - 1.0) * 1.5) + (powerFactor < 1.0 ? 3.8 : 0) + Math.max(0, randomNormal(0, 0.6));
      const energyDeltaMwh = (tempDelta * 0.04) + (windDelta * 0.06) + (journeyTimeDeltaMin * 0.02);

      const simJourneyTimeMin = Math.max(baseJourneyTimeMin * 0.95, baseJourneyTimeMin + journeyTimeDeltaMin);
      const delayMin = Math.max(0, simJourneyTimeMin - baseJourneyTimeMin);
      const simEnergyMwh = Math.max(baseEnergyMwh * 0.9, baseEnergyMwh + energyDeltaMwh);
      const peakSubMw = 14.5 + (tempDelta > 5 ? 2.2 : 0) + (simJourneyTimeMin < baseJourneyTimeMin ? 1.8 : 0);

      iterations.push({
        iterationIndex: i + 1,
        journeyTimeMinutes: Math.round(simJourneyTimeMin * 10) / 10,
        delayMinutes: Math.round(delayMin * 10) / 10,
        energyConsumptionMwh: Math.round(simEnergyMwh * 100) / 100,
        peakSubstationLoadMw: Math.round(peakSubMw * 10) / 10,
        temperatureC: Math.round(ambientTemp * 10) / 10,
        dwellRandomFactor: Math.round(dwellFactor * 100) / 100
      });
    }

    // Sort to compute statistical percentiles
    const sortedJourneyTimes = [...iterations.map(it => it.journeyTimeMinutes)].sort((a, b) => a - b);
    const sortedDelays = [...iterations.map(it => it.delayMinutes)].sort((a, b) => a - b);
    const energies = iterations.map(it => it.energyConsumptionMwh);

    const getPercentile = (arr: number[], p: number) => {
      const idx = Math.min(arr.length - 1, Math.floor(arr.length * (p / 100)));
      return arr[idx];
    };

    const energyMean = energies.reduce((a, b) => a + b, 0) / energies.length;
    const energyVariance = energies.reduce((a, b) => a + Math.pow(b - energyMean, 2), 0) / energies.length;
    const energyStdDev = Math.sqrt(energyVariance);

    const onTimeCount = iterations.filter(it => it.delayMinutes <= 5.0).length;
    const reliabilityPct = (onTimeCount / iterations.length) * 100;

    return {
      sampleCount: iterationCount,
      journeyTimeP50Min: getPercentile(sortedJourneyTimes, 50),
      journeyTimeP90Min: getPercentile(sortedJourneyTimes, 90),
      journeyTimeP95Min: getPercentile(sortedJourneyTimes, 95),
      journeyTimeP99Min: getPercentile(sortedJourneyTimes, 99),
      delayP90Min: getPercentile(sortedDelays, 90),
      delayP95Min: getPercentile(sortedDelays, 95),
      energyMeanMwh: Math.round(energyMean * 100) / 100,
      energyStdDevMwh: Math.round(energyStdDev * 100) / 100,
      reliabilityPercent: Math.round(reliabilityPct * 10) / 10,
      iterations: iterations.slice(0, 50) // Top 50 samples for UI table
    };
  }
}
