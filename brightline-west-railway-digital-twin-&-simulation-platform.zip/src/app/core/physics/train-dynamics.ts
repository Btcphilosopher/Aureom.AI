/**
 * BRIGHTLINE WEST DIGITAL TWIN - LONGITUDINAL TRAIN DYNAMICS ENGINE
 * High-fidelity numerical physics solver with Davis equation, gradient resistance,
 * tractive effort curves, regenerative braking envelopes, and energy integration.
 */

import { TrackSegment, RollingStockConfig, EnvironmentalConditions, Station } from '../models/digital-twin.model';

export interface PhysicsStepResult {
  timeSeconds: number;
  chainageM: number;
  speedMps: number;
  speedMph: number;
  accelerationMps2: number;
  tractiveForceKn: number;
  brakeForceKn: number;
  resistanceForceKn: number;
  gradientForceKn: number;
  curveForceKn: number;
  tractionPowerKw: number;
  regenerativePowerKw: number;
  auxiliaryPowerKw: number;
  netPowerKw: number;
  energyKwh: number;
  regenKwh: number;
  motorTempC: number;
  brakeTempC: number;
}

export interface CorridorRunResult {
  totalJourneyTimeSeconds: number;
  totalDistanceM: number;
  averageSpeedMph: number;
  maxSpeedMph: number;
  totalTractionKwh: number;
  totalRegenKwh: number;
  netEnergyKwh: number;
  specificEnergyWhPerSeatKm: number;
  trajectory: PhysicsStepResult[];
  stationArrivals: { stationId: string; arrivalTimeSec: number; departureTimeSec: number }[];
}

export class TrainDynamicsEngine {
  private static readonly GRAVITY = 9.80665; // m/s²
  private static readonly AIR_DENSITY_SEA_LEVEL = 1.225; // kg/m³

  /**
   * Calculates instantaneous Davis rolling and aerodynamic resistance (kN)
   */
  public static calculateDavisResistance(
    rollingStock: RollingStockConfig,
    speedMps: number,
    elevationM: number,
    env: EnvironmentalConditions
  ): number {
    const v = Math.max(0, speedMps);
    // Correct air density for altitude and desert temperature
    // P = P0 * exp(-M*g*h / (R*T))
    const tempKelvin = env.ambientTemperatureC + 273.15;
    const airDensity = TrainDynamicsEngine.AIR_DENSITY_SEA_LEVEL * (288.15 / tempKelvin) * Math.exp(-0.00012 * elevationM);
    const densityRatio = airDensity / 1.225;

    // A (mechanical), B (flange/momentum), C (aero corrected for density & headwind)
    const effectiveSpeed = v + env.windSpeedMps * Math.cos(env.windDirectionDegrees * (Math.PI / 180));
    const effectiveV = Math.max(0, effectiveSpeed);

    const R_A = rollingStock.davisA_kN;
    const R_B = rollingStock.davisB_kN_s_per_m * v;
    const R_C = rollingStock.davisC_kN_s2_per_m2 * densityRatio * Math.pow(effectiveV, 2);

    return R_A + R_B + R_C;
  }

  /**
   * Calculates gradient resistance force in kN
   * F_grad = m * g * sin(theta) = m * g * (gradientPercent / 100)
   */
  public static calculateGradientForce(massTons: number, gradientPercent: number): number {
    const massKg = massTons * 1000;
    // Positive gradient = uphill resistance (opposing motion)
    return (massKg * TrainDynamicsEngine.GRAVITY * (gradientPercent / 100)) / 1000;
  }

  /**
   * Calculates curvature resistance force in kN using dehn formula: F_c = m * g * (650 / (R - 55)) / 1000
   */
  public static calculateCurveForce(massTons: number, radiusM: number): number {
    if (radiusM <= 0 || radiusM > 20000) return 0;
    const massKg = massTons * 1000;
    const specificResistanceNPerKg = 0.0065 / Math.max(100, radiusM);
    return (massKg * specificResistanceNPerKg) / 1000;
  }

  /**
   * Calculates maximum tractive effort available at a given speed (kN)
   */
  public static calculateMaxTractiveForce(
    rollingStock: RollingStockConfig,
    speedMps: number,
    env: EnvironmentalConditions,
    catenaryVoltageFactor = 1.0
  ): number {
    const effectivePowerKw = rollingStock.continuousPowerKw * catenaryVoltageFactor;
    const massKg = rollingStock.massTons * 1000;
    
    // Adhesion limit (kN): F_adh = mu * N
    const mu = 0.35 * env.adhesionFactor * (1 - 0.001 * (speedMps * 3.6));
    const maxAdhesionKn = (mu * massKg * TrainDynamicsEngine.GRAVITY) / 1000;

    if (speedMps < 0.5) {
      return Math.min(rollingStock.maxTractiveEffortKn, maxAdhesionKn);
    }

    // Constant power region: F = P / v
    const powerLimitedForceKn = effectivePowerKw / speedMps;
    return Math.min(rollingStock.maxTractiveEffortKn, powerLimitedForceKn, maxAdhesionKn);
  }

  /**
   * Calculates permitted speed restriction from curvature, cant, and cant deficiency
   */
  public static calculateCurveSpeedLimitMps(
    radiusM: number,
    cantMm: number,
    cantDeficiencyMm: number
  ): number {
    if (radiusM <= 0 || radiusM > 25000) return 89.4; // 200 mph straight track limit
    // Equilibrium cant formula: E_eq = cantMm + cantDeficiencyMm = 11.8 * V² / R (V in km/h, R in m)
    const totalCant = Math.min(250, cantMm + cantDeficiencyMm);
    const maxSpeedKmh = Math.sqrt((totalCant * radiusM) / 11.8);
    return (maxSpeedKmh / 3.6);
  }

  /**
   * Computes the forward and backward speed profile envelope along the corridor
   */
  public static computeSpeedProfile(
    segments: TrackSegment[],
    rollingStock: RollingStockConfig,
    stations: Station[],
    stops: { stationId: string; dwellSeconds: number }[],
    direction: 'NORTHBOUND' | 'SOUTHBOUND' = 'NORTHBOUND'
  ): { chainageM: number; targetSpeedMps: number; segment: TrackSegment }[] {
    const orderedSegments = direction === 'NORTHBOUND'
      ? [...segments].sort((a, b) => a.startChainageM - b.startChainageM)
      : [...segments].sort((a, b) => b.endChainageM - a.endChainageM);

    const stopStationIds = new Set(stops.map(s => s.stationId));

    // Sample track points every 50 meters for numerical integration
    const points: { chainageM: number; targetSpeedMps: number; segment: TrackSegment; isStop: boolean }[] = [];

    for (const seg of orderedSegments) {
      const segStart = direction === 'NORTHBOUND' ? seg.startChainageM : seg.endChainageM;
      const segEnd = direction === 'NORTHBOUND' ? seg.endChainageM : seg.startChainageM;
      const step = 100; // 100m discretization
      const count = Math.max(2, Math.ceil(Math.abs(segEnd - segStart) / step));

      for (let i = 0; i <= count; i++) {
        const fraction = i / count;
        const chainage = segStart + (segEnd - segStart) * fraction;
        
        // Find if this chainage is within 100m of a scheduled stop station
        const nearbyStop = stations.find(st => stopStationIds.has(st.id) && Math.abs(st.chainageM - chainage) < 100);

        // Maximum allowed speed from track geometry, curve and rolling stock
        const curveLimit = TrainDynamicsEngine.calculateCurveSpeedLimitMps(
          seg.curveRadiusM,
          seg.cantMm,
          seg.cantDeficiencyMm
        );
        const segmentLimit = Math.min(seg.permittedSpeedMps, seg.designSpeedMps, curveLimit, rollingStock.maxOperatingSpeedMps);

        points.push({
          chainageM: chainage,
          targetSpeedMps: nearbyStop ? 0 : segmentLimit,
          segment: seg,
          isStop: !!nearbyStop
        });
      }
    }

    // Backward pass for braking envelope (ensure train decelerates in time for lower limits and stops)
    const decelLimit = rollingStock.maxServiceDecelerationMps2 * 0.85; // 85% safety envelope
    for (let i = points.length - 2; i >= 0; i--) {
      const dist = Math.abs(points[i + 1].chainageM - points[i].chainageM);
      const maxNextV = points[i + 1].targetSpeedMps;
      // v_allowable = sqrt(v_next² + 2 * a_decel * d)
      const allowableV = Math.sqrt(Math.pow(maxNextV, 2) + 2 * decelLimit * dist);
      points[i].targetSpeedMps = Math.min(points[i].targetSpeedMps, allowableV);
    }

    return points;
  }

  /**
   * Runs the forward numerical integration physics simulation along the corridor
   */
  public static simulateRun(
    segments: TrackSegment[],
    rollingStock: RollingStockConfig,
    stations: Station[],
    stops: { stationId: string; dwellSeconds: number }[],
    env: EnvironmentalConditions,
    direction: 'NORTHBOUND' | 'SOUTHBOUND' = 'NORTHBOUND',
    powerRestrictionFactor = 1.0
  ): CorridorRunResult {
    const profile = TrainDynamicsEngine.computeSpeedProfile(segments, rollingStock, stations, stops, direction);
    const trajectory: PhysicsStepResult[] = [];
    const stationArrivals: { stationId: string; arrivalTimeSec: number; departureTimeSec: number }[] = [];

    const effectiveMassKg = rollingStock.massTons * 1000 * rollingStock.rotatingMassFactor;

    let timeSec = 0;
    let currentV = 0; // m/s
    let cumulativeEnergyKwh = 0;
    let cumulativeRegenKwh = 0;
    let motorTemp = env.ambientTemperatureC + 10;
    let brakeTemp = env.ambientTemperatureC + 5;

    const stopMap = new Map(stops.map(s => [s.stationId, s.dwellSeconds]));
    const visitedStations = new Set<string>();

    const dt = 0.5; // 0.5s time step for high accuracy

    let profileIdx = 0;
    const maxIdx = profile.length - 1;

    while (profileIdx < maxIdx) {
      const currentPoint = profile[profileIdx];
      const currentSeg = currentPoint.segment;

      // Check if train is stopped at a station
      const currentStation = stations.find(st => Math.abs(st.chainageM - currentPoint.chainageM) < 150 && stopMap.has(st.id));
      if (currentStation && !visitedStations.has(currentStation.id) && currentV < 0.5) {
        const dwellSec = stopMap.get(currentStation.id) || 120;
        const arrivalT = timeSec;
        const departT = timeSec + dwellSec;
        stationArrivals.push({
          stationId: currentStation.id,
          arrivalTimeSec: arrivalT,
          departureTimeSec: departT
        });
        visitedStations.add(currentStation.id);

        // Record dwell telemetry
        const auxKw = rollingStock.auxiliaryPowerKw;
        cumulativeEnergyKwh += (auxKw * dwellSec) / 3600;
        timeSec += dwellSec;
        
        trajectory.push({
          timeSeconds: timeSec,
          chainageM: currentPoint.chainageM,
          speedMps: 0,
          speedMph: 0,
          accelerationMps2: 0,
          tractiveForceKn: 0,
          brakeForceKn: 0,
          resistanceForceKn: 0,
          gradientForceKn: 0,
          curveForceKn: 0,
          tractionPowerKw: 0,
          regenerativePowerKw: 0,
          auxiliaryPowerKw: auxKw,
          netPowerKw: auxKw,
          energyKwh: cumulativeEnergyKwh,
          regenKwh: cumulativeRegenKwh,
          motorTempC: motorTemp,
          brakeTempC: brakeTemp
        });
      }

      // Calculate resistive forces
      const fResistanceKn = TrainDynamicsEngine.calculateDavisResistance(rollingStock, currentV, currentSeg.startElevationM, env);
      const fGradKn = TrainDynamicsEngine.calculateGradientForce(rollingStock.massTons, currentSeg.gradientPercent);
      const fCurveKn = TrainDynamicsEngine.calculateCurveForce(rollingStock.massTons, currentSeg.curveRadiusM);

      const targetV = currentPoint.targetSpeedMps;

      let fTractionKn = 0;
      let fBrakeKn = 0;
      let tractionPowerKw = 0;
      let regenPowerKw = 0;

      if (currentV < targetV - 0.2) {
        // Accelerate
        fTractionKn = TrainDynamicsEngine.calculateMaxTractiveForce(rollingStock, currentV, env, powerRestrictionFactor);
        tractionPowerKw = (fTractionKn * currentV) / 0.88; // 88% inverter/motor efficiency
        tractionPowerKw = Math.min(tractionPowerKw, rollingStock.continuousPowerKw * powerRestrictionFactor);
      } else if (currentV > targetV + 0.2) {
        // Brake
        const requiredDecel = Math.min(rollingStock.maxServiceDecelerationMps2, (currentV - targetV) / 2.0);
        const requiredBrakeKn = (effectiveMassKg * requiredDecel) / 1000;
        
        // Regenerative brake captures kinetic energy up to max regen power
        const potentialRegenKw = requiredBrakeKn * currentV * 0.85; // 85% regeneration efficiency
        regenPowerKw = Math.min(potentialRegenKw, rollingStock.maxRegenerativeBrakePowerKw);
        
        fBrakeKn = requiredBrakeKn;
        fTractionKn = 0;
      } else {
        // Cruising (balance resistance + gradient)
        const balanceForceKn = fResistanceKn + fGradKn + fCurveKn;
        if (balanceForceKn > 0) {
          fTractionKn = Math.min(balanceForceKn, TrainDynamicsEngine.calculateMaxTractiveForce(rollingStock, currentV, env, powerRestrictionFactor));
          tractionPowerKw = (fTractionKn * currentV) / 0.88;
        } else {
          fBrakeKn = Math.abs(balanceForceKn);
          regenPowerKw = Math.min(fBrakeKn * currentV * 0.85, rollingStock.maxRegenerativeBrakePowerKw);
        }
      }

      // Net longitudinal force
      const fNetKn = fTractionKn - fBrakeKn - fResistanceKn - fGradKn - fCurveKn;
      const accelerationMps2 = (fNetKn * 1000) / effectiveMassKg;

      // Integrate velocity and position
      const newV = Math.max(0, currentV + accelerationMps2 * dt);
      const ds = ((currentV + newV) / 2) * dt;
      currentV = newV;
      timeSec += dt;

      // Energy integration
      const auxKw = rollingStock.auxiliaryPowerKw + (env.ambientTemperatureC > 35 ? 120 : 0); // extra HVAC under desert heat
      const netPowerKw = tractionPowerKw - regenPowerKw + auxKw;
      cumulativeEnergyKwh += (tractionPowerKw * dt) / 3600;
      cumulativeRegenKwh += (regenPowerKw * dt) / 3600;

      // Motor & brake thermal modeling
      const motorHeat = (tractionPowerKw * (1 - 0.90)) * 0.0015;
      const motorCool = (motorTemp - env.ambientTemperatureC) * 0.001;
      motorTemp = Math.max(env.ambientTemperatureC, motorTemp + motorHeat - motorCool);

      const brakeHeat = (fBrakeKn * currentV * 0.0008);
      const brakeCool = (brakeTemp - env.ambientTemperatureC) * 0.002;
      brakeTemp = Math.max(env.ambientTemperatureC, brakeTemp + brakeHeat - brakeCool);

      // Advance along chainage profile
      const deltaM = direction === 'NORTHBOUND' ? ds : -ds;
      const currentChainage = profile[profileIdx].chainageM + deltaM;

      // Advance index to match chainage
      while (profileIdx < maxIdx && (
        (direction === 'NORTHBOUND' && profile[profileIdx + 1].chainageM <= currentChainage) ||
        (direction === 'SOUTHBOUND' && profile[profileIdx + 1].chainageM >= currentChainage)
      )) {
        profileIdx++;
      }

      // Record sample every ~2.5 seconds or near stations
      if (trajectory.length === 0 || timeSec - trajectory[trajectory.length - 1].timeSeconds >= 2.5 || profileIdx >= maxIdx) {
        trajectory.push({
          timeSeconds: Math.round(timeSec * 10) / 10,
          chainageM: Math.round(currentPoint.chainageM),
          speedMps: Math.round(currentV * 100) / 100,
          speedMph: Math.round(currentV * 2.23694 * 10) / 10,
          accelerationMps2: Math.round(accelerationMps2 * 1000) / 1000,
          tractiveForceKn: Math.round(fTractionKn * 10) / 10,
          brakeForceKn: Math.round(fBrakeKn * 10) / 10,
          resistanceForceKn: Math.round(fResistanceKn * 10) / 10,
          gradientForceKn: Math.round(fGradKn * 10) / 10,
          curveForceKn: Math.round(fCurveKn * 10) / 10,
          tractionPowerKw: Math.round(tractionPowerKw),
          regenerativePowerKw: Math.round(regenPowerKw),
          auxiliaryPowerKw: Math.round(auxKw),
          netPowerKw: Math.round(netPowerKw),
          energyKwh: Math.round(cumulativeEnergyKwh * 10) / 10,
          regenKwh: Math.round(cumulativeRegenKwh * 10) / 10,
          motorTempC: Math.round(motorTemp * 10) / 10,
          brakeTempC: Math.round(brakeTemp * 10) / 10
        });
      }
    }

    const totalDistanceM = Math.abs(profile[profile.length - 1].chainageM - profile[0].chainageM);
    const totalDistanceKm = totalDistanceM / 1000;
    const totalDistanceMiles = totalDistanceM / 1609.34;
    const avgSpeedMph = totalDistanceMiles / (timeSec / 3600);
    const maxSpeedMph = Math.max(...trajectory.map(t => t.speedMph));
    const netEnergyKwh = cumulativeEnergyKwh - cumulativeRegenKwh;
    const seatKm = totalDistanceKm * rollingStock.passengerCapacity;
    const specificEnergyWhPerSeatKm = (netEnergyKwh * 1000) / seatKm;

    return {
      totalJourneyTimeSeconds: Math.round(timeSec),
      totalDistanceM,
      averageSpeedMph: Math.round(avgSpeedMph * 10) / 10,
      maxSpeedMph: Math.round(maxSpeedMph * 10) / 10,
      totalTractionKwh: Math.round(cumulativeEnergyKwh),
      totalRegenKwh: Math.round(cumulativeRegenKwh),
      netEnergyKwh: Math.round(netEnergyKwh),
      specificEnergyWhPerSeatKm: Math.round(specificEnergyWhPerSeatKm * 100) / 100,
      trajectory,
      stationArrivals
    };
  }
}
