import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-cab-view',
  imports: [CommonModule, MatIconModule],
  templateUrl: './cab-view.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CabViewComponent {
  public dt = inject(DigitalTwinService);

  public selectedTrain = computed(() => {
    return this.dt.activeTrains()[0];
  });
}
