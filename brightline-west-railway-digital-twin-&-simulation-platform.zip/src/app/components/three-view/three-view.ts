import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  inject,
  signal,
  effect
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-three-view',
  imports: [CommonModule, MatIconModule],
  templateUrl: './three-view.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ThreeViewComponent implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true })
  public canvasContainerRef!: ElementRef<HTMLDivElement>;

  public dt = inject(DigitalTwinService);

  public cameraMode = signal<'ORBIT' | 'FOLLOW_TRAIN' | 'CAB_VIEW' | 'CROSS_SECTION'>('FOLLOW_TRAIN');

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;

  // 3D Objects
  private trainMeshGroup!: THREE.Group;
  private trackMeshGroup!: THREE.Group;
  private catenaryMastsGroup!: THREE.Group;
  private terrainMesh!: THREE.Mesh;

  // Follow train physics interpolation
  private trainPosition = new THREE.Vector3(0, 1.2, 0);
  private cameraOffset = new THREE.Vector3(-25, 12, 35);

  constructor() {
    effect(() => {
      // Respond to cross-section toggle from parent
      if (this.dt.showCrossSection()) {
        this.cameraMode.set('CROSS_SECTION');
      }
    });
  }

  ngOnInit() {
    if (typeof window !== 'undefined') {
      this.initThree();
      this.buildCorridorEnvironment();
      this.startAnimationLoop();
    }
  }

  ngOnDestroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  public setCameraMode(mode: 'ORBIT' | 'FOLLOW_TRAIN' | 'CAB_VIEW' | 'CROSS_SECTION') {
    this.cameraMode.set(mode);
    if (mode === 'CROSS_SECTION') {
      this.dt.showCrossSection.set(true);
    } else {
      this.dt.showCrossSection.set(false);
    }
  }

  private initThree() {
    const container = this.canvasContainerRef.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0f131a);
    this.scene.fog = new THREE.FogExp2(0x0f131a, 0.0035);

    this.camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 2000);
    this.camera.position.set(-30, 20, 50);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;

    container.appendChild(this.renderer.domElement);

    // Desert Sunlight & Ambient Lighting
    const ambientLight = new THREE.AmbientLight(0xdbe4f0, 0.6);
    this.scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xfff5e6, 1.4);
    sunLight.position.set(100, 150, 80);
    sunLight.castShadow = true;
    this.scene.add(sunLight);

    window.addEventListener('resize', this.onWindowResize);
  }

  private onWindowResize = () => {
    if (!this.canvasContainerRef || !this.renderer || !this.camera) return;
    const container = this.canvasContainerRef.nativeElement;
    const width = container.clientWidth;
    const height = container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private buildCorridorEnvironment() {
    // 1. Desert Terrain Surface
    const terrainGeo = new THREE.PlaneGeometry(800, 400, 64, 32);
    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0x242933,
      roughness: 0.9,
      metalness: 0.1,
      wireframe: false,
    });
    this.terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    this.terrainMesh.rotation.x = -Math.PI / 2;
    this.terrainMesh.position.y = -0.5;
    this.scene.add(this.terrainMesh);

    // 2. I-15 Highway Corridors (Left & Right of Median)
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x181c24, roughness: 0.8 });
    const roadGeo = new THREE.BoxGeometry(600, 0.2, 14);

    const roadSouth = new THREE.Mesh(roadGeo, roadMat);
    roadSouth.position.set(0, 0, -22);
    this.scene.add(roadSouth);

    const roadNorth = new THREE.Mesh(roadGeo, roadMat);
    roadNorth.position.set(0, 0, 22);
    this.scene.add(roadNorth);

    // 3. High-Speed Rail Trackbed (Ballast & Rails in Median)
    this.trackMeshGroup = new THREE.Group();
    const ballastMat = new THREE.MeshStandardMaterial({ color: 0x3e4554, roughness: 0.95 });
    const ballast = new THREE.Mesh(new THREE.BoxGeometry(600, 0.8, 8), ballastMat);
    ballast.position.y = 0.2;
    this.trackMeshGroup.add(ballast);

    // Steel Rails (Track 1 & Track 2)
    const railMat = new THREE.MeshStandardMaterial({ color: 0xa0aec0, metalness: 0.8, roughness: 0.2 });
    const railGeo = new THREE.BoxGeometry(600, 0.2, 0.15);

    const rail1L = new THREE.Mesh(railGeo, railMat);
    rail1L.position.set(0, 0.7, -1.8);
    const rail1R = new THREE.Mesh(railGeo, railMat);
    rail1R.position.set(0, 0.7, -0.4);

    const rail2L = new THREE.Mesh(railGeo, railMat);
    rail2L.position.set(0, 0.7, 0.4);
    const rail2R = new THREE.Mesh(railGeo, railMat);
    rail2R.position.set(0, 0.7, 1.8);

    this.trackMeshGroup.add(rail1L, rail1R, rail2L, rail2R);
    this.scene.add(this.trackMeshGroup);

    // 4. 25kV Catenary Masts & Contact Wire
    this.catenaryMastsGroup = new THREE.Group();
    const mastMat = new THREE.MeshStandardMaterial({ color: 0x718096, metalness: 0.5 });
    const wireMat = new THREE.MeshBasicMaterial({ color: 0xe2e8f0 });

    for (let x = -280; x <= 280; x += 40) {
      const mastL = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 7), mastMat);
      mastL.position.set(x, 3.5, -4.5);
      const mastR = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 7), mastMat);
      mastR.position.set(x, 3.5, 4.5);
      const portal = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.3, 9.2), mastMat);
      portal.position.set(x, 6.8, 0);

      this.catenaryMastsGroup.add(mastL, mastR, portal);
    }

    // Overhead Contact Wires
    const contactWire1 = new THREE.Mesh(new THREE.BoxGeometry(600, 0.03, 0.03), wireMat);
    contactWire1.position.set(0, 5.8, -1.1);
    const contactWire2 = new THREE.Mesh(new THREE.BoxGeometry(600, 0.03, 0.03), wireMat);
    contactWire2.position.set(0, 5.8, 1.1);

    this.catenaryMastsGroup.add(contactWire1, contactWire2);
    this.scene.add(this.catenaryMastsGroup);

    // 5. Brightline West High-Speed Trainset (EMU)
    this.trainMeshGroup = new THREE.Group();
    const trainBodyMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      metalness: 0.3,
      roughness: 0.3,
    });
    const brightlineYellowMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b, // Brightline signature yellow
      metalness: 0.2,
      roughness: 0.4,
    });
    const windowMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.9,
      roughness: 0.1,
    });

    // 4 Coaches Consist
    for (let c = 0; c < 4; c++) {
      const coach = new THREE.Group();
      const body = new THREE.Mesh(new THREE.BoxGeometry(18, 3.2, 3.0), trainBodyMat);
      body.position.y = 2.0;

      // Yellow aero livery accent stripe
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(18.05, 0.6, 3.05), brightlineYellowMat);
      stripe.position.y = 1.6;

      // Dark panoramic windows
      const windows = new THREE.Mesh(new THREE.BoxGeometry(16, 0.7, 3.08), windowMat);
      windows.position.y = 2.4;

      coach.add(body, stripe, windows);

      // Pantograph on coach 2
      if (c === 1) {
        const pantoMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.8 });
        const pantoArm = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 2.4), pantoMat);
        pantoArm.rotation.z = Math.PI / 4;
        pantoArm.position.set(-2, 4.4, 0);
        const pantoHead = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, 2.0), pantoMat);
        pantoHead.position.set(-1.2, 5.75, 0);
        coach.add(pantoArm, pantoHead);
      }

      coach.position.x = (c - 1.5) * 19;
      this.trainMeshGroup.add(coach);
    }

    this.trainMeshGroup.position.set(0, 0, -1.1);
    this.scene.add(this.trainMeshGroup);
  }

  private startAnimationLoop() {
    let t = 0;

    const animate = () => {
      this.animationFrameId = requestAnimationFrame(animate);
      t += 0.015 * (this.dt.simulationTimeScale() / 5);

      if (this.trainMeshGroup && this.dt.isSimulationPlaying()) {
        // Dynamic longitudinal train movement along tangent
        const speedFactor = (this.dt.activeTrains()[0]?.speedMps || 88) * 0.05;
        this.trainPosition.x = ((t * speedFactor * 10) % 400) - 200;
        this.trainMeshGroup.position.x = this.trainPosition.x;
      }

      // Camera Positioning Modes
      if (this.cameraMode() === 'FOLLOW_TRAIN') {
        const targetPos = new THREE.Vector3(this.trainPosition.x, 2, -1.1);
        this.camera.position.lerp(
          new THREE.Vector3(targetPos.x - 30, targetPos.y + 12, targetPos.z + 24),
          0.05
        );
        this.camera.lookAt(targetPos);
      } else if (this.cameraMode() === 'CAB_VIEW') {
        // Driver's eye view from lead cab
        const cabPos = new THREE.Vector3(this.trainPosition.x + 36, 2.8, -1.1);
        this.camera.position.copy(cabPos);
        this.camera.lookAt(cabPos.x + 80, 2.5, -1.1);
      } else if (this.cameraMode() === 'CROSS_SECTION') {
        // Technical 90° Cross Section CAD View
        this.camera.position.set(this.trainPosition.x, 4, 30);
        this.camera.lookAt(this.trainPosition.x, 3, 0);
      } else {
        // ORBIT rotation
        this.camera.position.x = Math.sin(t * 0.2) * 60;
        this.camera.position.z = Math.cos(t * 0.2) * 60;
        this.camera.position.y = 28;
        this.camera.lookAt(0, 2, 0);
      }

      this.renderer.render(this.scene, this.camera);
    };

    animate();
  }
}
