import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-inspector',
  imports: [CommonModule, MatIconModule],
  templateUrl: './inspector.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InspectorComponent {
  public dt = inject(DigitalTwinService);

  public selectedTrack = computed(() => {
    if (this.dt.selectedObjectType() !== 'TRACK') return null;
    return this.dt.trackSegments().find(s => s.id === this.dt.selectedObjectId()) || this.dt.trackSegments()[7];
  });

  public selectedStation = computed(() => {
    if (this.dt.selectedObjectType() !== 'STATION') return null;
    return this.dt.stations().find(s => s.id === this.dt.selectedObjectId());
  });

  public selectedSubstation = computed(() => {
    if (this.dt.selectedObjectType() !== 'SUBSTATION') return null;
    return this.dt.substations().find(s => s.id === this.dt.selectedObjectId());
  });

  public selectedTrain = computed(() => {
    if (this.dt.selectedObjectType() !== 'TRAIN') return null;
    return this.dt.activeTrains().find(t => t.trainId === this.dt.selectedObjectId()) || this.dt.activeTrains()[0];
  });

  public openDesignerForCurrent() {
    this.dt.activeMode.set('DESIGNER');
  }
}
