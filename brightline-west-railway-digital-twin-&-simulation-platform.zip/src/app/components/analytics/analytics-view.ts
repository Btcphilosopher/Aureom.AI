import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { ParetoOptimizer } from '../../core/physics/pareto-optimizer';
import { ParetoPoint } from '../../core/models/digital-twin.model';

@Component({
  selector: 'app-analytics-view',
  imports: [CommonModule, MatIconModule],
  templateUrl: './analytics-view.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AnalyticsViewComponent {
  public dt = inject(DigitalTwinService);

  public paretoPoints = signal<ParetoPoint[]>(ParetoOptimizer.computeParetoFrontier());
  public selectedParetoPoint = signal<ParetoPoint>(this.paretoPoints()[0]);

  public selectParetoPoint(p: ParetoPoint) {
    this.selectedParetoPoint.set(p);
  }
}
