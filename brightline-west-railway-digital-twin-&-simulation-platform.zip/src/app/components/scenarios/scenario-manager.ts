import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { MonteCarloEngine } from '../../core/physics/monte-carlo';
import { MonteCarloSummary } from '../../core/models/digital-twin.model';

@Component({
  selector: 'app-scenario-manager',
  imports: [CommonModule, MatIconModule],
  templateUrl: './scenario-manager.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ScenarioManagerComponent {
  public dt = inject(DigitalTwinService);

  public isRunningMonteCarlo = signal<boolean>(false);
  public monteCarloResults = signal<MonteCarloSummary | null>(null);
  public selectedIterationCount = signal<number>(100);

  public selectScenario(scenarioId: string) {
    this.dt.applyScenario(scenarioId);
  }

  public runMonteCarlo(iterations: number) {
    this.selectedIterationCount.set(iterations);
    this.isRunningMonteCarlo.set(true);

    setTimeout(() => {
      const segs = this.dt.trackSegments();
      const rs = this.dt.rollingStock();
      const stns = this.dt.stations();
      const env = this.dt.environment();

      const stops = [
        { stationId: 'st-rancho', dwellSeconds: 0 },
        { stationId: 'st-victorvalley', dwellSeconds: 120 },
        { stationId: 'st-lasvegas', dwellSeconds: 0 }
      ];

      const results = MonteCarloEngine.runSimulation(segs, rs, stns, stops, env, iterations);
      this.monteCarloResults.set(results);
      this.isRunningMonteCarlo.set(false);
    }, 150);
  }
}
