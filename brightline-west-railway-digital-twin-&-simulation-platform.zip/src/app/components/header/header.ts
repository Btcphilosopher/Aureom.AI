import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  templateUrl: './header.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderComponent {
  public dt = inject(DigitalTwinService);

  public formatTime(totalSeconds: number): string {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = Math.floor(totalSeconds % 60);
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }

  public togglePlayPause() {
    this.dt.isSimulationPlaying.update(p => !p);
  }

  public setTimeScale(scale: number) {
    this.dt.simulationTimeScale.set(scale);
  }

  public setMode(mode: 'DIGITAL_TWIN' | 'SIMULATOR' | 'DESIGNER' | 'SCENARIOS' | 'OCC' | 'CONSTRUCTION' | 'ANALYTICS') {
    this.dt.activeMode.set(mode);
  }

  public onScenarioChange(event: Event) {
    const select = event.target as HTMLSelectElement;
    this.dt.applyScenario(select.value);
  }

  public openCommandPalette() {
    this.dt.commandPaletteOpen.set(true);
  }

  public openReportModal() {
    this.dt.reportModalOpen.set(true);
  }
}
