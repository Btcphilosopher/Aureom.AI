import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { TrackSegment, Station, Substation, TrainTelemetry } from '../../core/models/digital-twin.model';

@Component({
  selector: 'app-corridor-map',
  imports: [CommonModule, MatIconModule],
  templateUrl: './corridor-map.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CorridorMapComponent {
  public dt = inject(DigitalTwinService);

  // Map Layer Toggles
  public layerTrack = signal<boolean>(true);
  public layerSpeedLimits = signal<boolean>(true);
  public layerGradients = signal<boolean>(true);
  public layerCurvature = signal<boolean>(false);
  public layerPower = signal<boolean>(true);
  public layerSignals = signal<boolean>(true);
  public layerTrains = signal<boolean>(true);
  public layerI15 = signal<boolean>(true);

  // Viewport Zoom & Pan
  public zoomLevel = signal<number>(1.0);
  public panOffsetMp = signal<number>(0); // milepost offset for corridor view

  // Total corridor length in miles
  public totalCorridorMiles = 218.0;

  // Selected item tracking
  public selectTrack(seg: TrackSegment) {
    this.dt.selectedObjectType.set('TRACK');
    this.dt.selectedObjectId.set(seg.id);
  }

  public selectStation(stn: Station) {
    this.dt.selectedObjectType.set('STATION');
    this.dt.selectedObjectId.set(stn.id);
  }

  public selectSubstation(sub: Substation) {
    this.dt.selectedObjectType.set('SUBSTATION');
    this.dt.selectedObjectId.set(sub.id);
  }

  public selectTrain(train: TrainTelemetry) {
    this.dt.selectedObjectType.set('TRAIN');
    this.dt.selectedObjectId.set(train.trainId);
    this.dt.activeFollowTrainId.set(train.trainId);
  }

  public zoomIn() {
    this.zoomLevel.update(z => Math.min(4.0, z + 0.25));
  }

  public zoomOut() {
    this.zoomLevel.update(z => Math.max(0.75, z - 0.25));
  }

  public resetView() {
    this.zoomLevel.set(1.0);
    this.panOffsetMp.set(0);
  }

  public toggle3D() {
    this.dt.is3DActive.update(v => !v);
  }

  public toggleCrossSection() {
    this.dt.showCrossSection.update(v => !v);
  }

  // Convert Milepost to X% on corridor track schematic
  public mpToPercent(mp: number): number {
    return Math.min(100, Math.max(0, (mp / this.totalCorridorMiles) * 100));
  }

  public getGradientColor(grad: number): string {
    if (grad > 2.5) return 'text-red-400 border-red-500/40 bg-red-950/40';
    if (grad > 1.0) return 'text-amber-400 border-amber-500/40 bg-amber-950/40';
    if (grad < -1.0) return 'text-blue-400 border-blue-500/40 bg-blue-950/40';
    return 'text-emerald-400 border-emerald-500/40 bg-emerald-950/40';
  }
}
