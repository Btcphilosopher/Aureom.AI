import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-alignment-editor',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './alignment-editor.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AlignmentEditorComponent {
  public dt = inject(DigitalTwinService);

  public selectedSubsystem = signal<'ALIGNMENT' | 'ROLLING_STOCK' | 'STATIONS' | 'POWER' | 'ENVIRONMENT'>('ALIGNMENT');

  // Track Segment Form Controls
  public selectedSegmentId = signal<string>('track-seg-08');
  public curveRadiusControl = new FormControl<number>(4500);
  public gradientControl = new FormControl<number>(-0.4);
  public permittedSpeedMphControl = new FormControl<number>(190);
  public cantMmControl = new FormControl<number>(140);

  // Rolling Stock Form Controls
  public trainMassControl = new FormControl<number>(420);
  public trainPowerMwControl = new FormControl<number>(8.0);
  public maxSpeedMphControl = new FormControl<number>(200);
  public seatingCapacityControl = new FormControl<number>(450);

  // Station Dwell Form Control
  public stationDwellSecondsControl = new FormControl<number>(120);

  // Environment Form Controls
  public ambientTempControl = new FormControl<number>(36);
  public windSpeedControl = new FormControl<number>(4.5);
  public adhesionControl = new FormControl<number>(0.95);

  public notification = signal<string | null>(null);

  constructor() {
    // Sync initial values with selected segment
    this.syncFromTrackSegment('track-seg-08');
  }

  public setSubsystem(sub: 'ALIGNMENT' | 'ROLLING_STOCK' | 'STATIONS' | 'POWER' | 'ENVIRONMENT') {
    this.selectedSubsystem.set(sub);
  }

  public onTrackSelect(event: Event) {
    const id = (event.target as HTMLSelectElement).value;
    this.selectedSegmentId.set(id);
    this.syncFromTrackSegment(id);
  }

  private syncFromTrackSegment(id: string) {
    const seg = this.dt.trackSegments().find(s => s.id === id);
    if (seg) {
      this.curveRadiusControl.setValue(seg.curveRadiusM);
      this.gradientControl.setValue(seg.gradientPercent);
      this.permittedSpeedMphControl.setValue(Math.round(seg.permittedSpeedMps * 2.23694));
      this.cantMmControl.setValue(seg.cantMm);
    }
  }

  public applyAlignmentChanges() {
    const id = this.selectedSegmentId();
    const radius = Number(this.curveRadiusControl.value) || 4500;
    const grad = Number(this.gradientControl.value) || 0;
    const speedMph = Number(this.permittedSpeedMphControl.value) || 190;
    const cant = Number(this.cantMmControl.value) || 120;

    this.dt.updateTrackSegment(id, {
      curveRadiusM: radius,
      gradientPercent: grad,
      permittedSpeedMps: speedMph / 2.23694,
      cantMm: cant
    });

    this.showNotification('Causal propagation executed: Physics, speed envelope, energy and journey time updated.');
  }

  public applyRollingStockChanges() {
    const mass = Number(this.trainMassControl.value) || 420;
    const powerMw = Number(this.trainPowerMwControl.value) || 8.0;
    const maxMph = Number(this.maxSpeedMphControl.value) || 200;
    const seats = Number(this.seatingCapacityControl.value) || 450;

    this.dt.updateRollingStock({
      massTons: mass,
      continuousPowerKw: powerMw * 1000,
      maxOperatingSpeedMps: maxMph / 2.23694,
      passengerCapacity: seats
    });

    this.showNotification('Rolling stock updated: Tractions curves and Davis resistance recalculated.');
  }

  public toggleSubstationState(subId: string) {
    const sub = this.dt.substations().find(s => s.id === subId);
    if (!sub) return;
    const newStatus = sub.status === 'ONLINE' ? 'FAULTED' : 'ONLINE';
    const newBreaker = newStatus === 'ONLINE' ? 'CLOSED' : 'TRIPPED';

    this.dt.updateSubstation(subId, {
      status: newStatus,
      breakerState: newBreaker
    });

    this.showNotification(`Substation ${sub.name} status set to ${newStatus}. Catenary feeder contingency simulated.`);
  }

  public applyEnvironmentChanges() {
    const temp = Number(this.ambientTempControl.value) || 36;
    const wind = Number(this.windSpeedControl.value) || 4.5;
    const adh = Number(this.adhesionControl.value) || 0.95;

    this.dt.environment.set({
      ...this.dt.environment(),
      ambientTemperatureC: temp,
      windSpeedMps: wind,
      adhesionFactor: adh
    });

    this.showNotification('Desert environmental conditions updated. HVAC load and aerodynamic drag recalculated.');
  }

  public resetAllToBaseline() {
    this.dt.resetToBaseline();
    this.syncFromTrackSegment(this.selectedSegmentId());
    this.trainMassControl.setValue(420);
    this.trainPowerMwControl.setValue(8.0);
    this.showNotification('All parameters reset to Brightline West baseline model.');
  }

  private showNotification(msg: string) {
    this.notification.set(msg);
    setTimeout(() => {
      this.notification.set(null);
    }, 4500);
  }
}
