import { ChangeDetectionStrategy, Component, inject, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

export interface PaletteCommand {
  id: string;
  title: string;
  icon: string;
  action: () => void;
}

@Component({
  selector: 'app-command-palette',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  templateUrl: './command-palette.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CommandPaletteComponent {
  public dt = inject(DigitalTwinService);

  public searchControl = new FormControl('');

  public commands: PaletteCommand[] = [
    { id: 'mode-digital-twin', title: 'Switch to Digital Twin View', icon: 'hub', action: () => this.dt.activeMode.set('DIGITAL_TWIN') },
    { id: 'mode-simulator', title: 'Switch to Cab Simulator HUD', icon: 'speed', action: () => this.dt.activeMode.set('SIMULATOR') },
    { id: 'mode-designer', title: 'Open Infrastructure Alignment Designer', icon: 'tune', action: () => this.dt.activeMode.set('DESIGNER') },
    { id: 'mode-scenarios', title: 'Open Scenarios & Monte Carlo Engine', icon: 'alt_route', action: () => this.dt.activeMode.set('SCENARIOS') },
    { id: 'mode-occ', title: 'Open Operations Control Centre (OCC)', icon: 'grid_view', action: () => this.dt.activeMode.set('OCC') },
    { id: 'mode-construction', title: 'Open 4D Construction Digital Twin', icon: 'view_in_ar', action: () => this.dt.activeMode.set('CONSTRUCTION') },
    { id: 'mode-analytics', title: 'Open Analytics & Pareto Optimization', icon: 'insights', action: () => this.dt.activeMode.set('ANALYTICS') },
    { id: 'toggle-3d', title: 'Toggle 3D Spatial Twin', icon: 'view_in_ar', action: () => this.dt.is3DActive.update(v => !v) },
    { id: 'find-mp-82', title: 'Inspect Barstow Curve (MP 82–86)', icon: 'search', action: () => { this.dt.selectedObjectType.set('TRACK'); this.dt.selectedObjectId.set('track-seg-08'); } },
    { id: 'find-cajon', title: 'Inspect Cajon Pass Summit Grade (MP 28)', icon: 'trending_up', action: () => { this.dt.selectedObjectType.set('TRACK'); this.dt.selectedObjectId.set('track-seg-03'); } },
    { id: 'find-rancho', title: 'Inspect Rancho Cucamonga Station & Metrolink Interchange', icon: 'place', action: () => { this.dt.selectedObjectType.set('STATION'); this.dt.selectedObjectId.set('st-rancho'); } },
    { id: 'export-report', title: 'Export Full Engineering Audit Report', icon: 'description', action: () => this.dt.reportModalOpen.set(true) }
  ];

  @HostListener('window:keydown', ['$event'])
  public handleKeyboardEvent(event: KeyboardEvent) {
    if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
      event.preventDefault();
      this.dt.commandPaletteOpen.update(v => !v);
    } else if (event.key === 'Escape' && this.dt.commandPaletteOpen()) {
      this.dt.commandPaletteOpen.set(false);
    }
  }

  public executeCommand(cmd: PaletteCommand) {
    cmd.action();
    this.dt.commandPaletteOpen.set(false);
  }

  public close() {
    this.dt.commandPaletteOpen.set(false);
  }
}

