import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';
import { TimetableService } from '../../core/models/digital-twin.model';

@Component({
  selector: 'app-time-distance-graph',
  imports: [CommonModule, MatIconModule],
  templateUrl: './time-distance-graph.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TimeDistanceGraphComponent {
  public dt = inject(DigitalTwinService);

  public selectedService = signal<TimetableService | null>(null);

  public selectService(srv: TimetableService) {
    this.selectedService.set(srv);
  }
}
