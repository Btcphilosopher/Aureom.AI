import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-construction-view',
  imports: [CommonModule, MatIconModule],
  templateUrl: './construction-view.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConstructionViewComponent {
  public dt = inject(DigitalTwinService);

  public selectedQuarter = signal<string>('Q4 2027');
  public quarters = ['Q1 2026', 'Q3 2026', 'Q1 2027', 'Q3 2027', 'Q1 2028', 'Q4 2028'];

  public setQuarter(q: string) {
    this.selectedQuarter.set(q);
  }
}
