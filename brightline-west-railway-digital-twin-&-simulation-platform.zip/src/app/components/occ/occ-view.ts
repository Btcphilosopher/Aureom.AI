import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-occ-view',
  imports: [CommonModule, MatIconModule],
  templateUrl: './occ-view.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OccViewComponent {
  public dt = inject(DigitalTwinService);

  public incidentLog = signal<{ time: string; level: string; msg: string }[]>([
    { time: '06:02:15', level: 'INFO', msg: 'Service BW 101 cleared from Rancho Cucamonga Platform 1.' },
    { time: '06:15:30', level: 'INFO', msg: 'Service BW 102 dispatched from Las Vegas Warm Springs Terminal.' },
    { time: '06:34:00', level: 'WARN', msg: 'High Desert ambient temperature approaching 38°C near Barstow.' },
    { time: '06:41:50', level: 'INFO', msg: 'Substation S02 Cajon operating nominal at 22.4 MW peak load.' }
  ]);

  public injectSignalFailure() {
    this.incidentLog.update(log => [
      { time: '06:42:10', level: 'ALERT', msg: 'SIMULATED: Track Circuit TC-08 (MP 82.0) dropped. Signal SIG-090-N dropped to STOP.' },
      ...log
    ]);
  }

  public injectSubstationTrip() {
    this.dt.updateSubstation('sub-s04', { status: 'FAULTED', breakerState: 'TRIPPED' });
    this.incidentLog.update(log => [
      { time: '06:42:25', level: 'CRITICAL', msg: 'FAULT: Substation S04 230kV Feeder Breaker TRIPPED. Adjacent S03 & S05 bridging catenary section.' },
      ...log
    ]);
  }

  public applyRecoveryStrategy(strategyName: string) {
    this.incidentLog.update(log => [
      { time: '06:42:40', level: 'DISPATCH', msg: `EXECUTED: Dispatch Recovery Strategy '${strategyName}' applied across corridor services.` },
      ...log
    ]);
  }
}
