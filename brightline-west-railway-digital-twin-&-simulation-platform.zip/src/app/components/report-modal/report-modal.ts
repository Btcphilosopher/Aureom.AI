import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalTwinService } from '../../core/services/digital-twin.service';

@Component({
  selector: 'app-report-modal',
  imports: [CommonModule, MatIconModule],
  templateUrl: './report-modal.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportModalComponent {
  public dt = inject(DigitalTwinService);

  public close() {
    this.dt.reportModalOpen.set(false);
  }

  public downloadJson() {
    const reportData = {
      project: 'Brightline West Railway Digital Twin',
      corridor: 'Southern California (Rancho Cucamonga) to Las Vegas',
      totalLengthMiles: 218.0,
      timestamp: new Date().toISOString(),
      activeScenario: this.dt.activeScenarioId(),
      physicsMetrics: this.dt.currentPhysicsRun(),
      lineCapacity: this.dt.lineCapacity(),
      substations: this.dt.substations(),
      rollingStock: this.dt.rollingStock(),
      quantityTakeoff: this.dt.quantityTakeoff()
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BrightlineWest_EngineeringReport_${this.dt.activeScenarioId()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  public printReport() {
    if (typeof window !== 'undefined') {
      window.print();
    }
  }
}
