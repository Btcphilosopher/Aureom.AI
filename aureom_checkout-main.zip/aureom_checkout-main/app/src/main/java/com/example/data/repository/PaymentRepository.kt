package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.database.AppDatabase
import com.example.data.database.CheckoutDao
import com.example.data.database.CheckoutSession
import com.example.data.database.MerchantLedgerEntry
import com.example.data.database.WebhookLog
import com.example.data.model.CryptoAsset
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import kotlin.random.Random

class PaymentRepository private constructor(context: Context) {

    private val database: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "aureom_checkout_db"
    ).fallbackToDestructiveMigration().build()

    val checkoutDao: CheckoutDao = database.checkoutDao()

    companion object {
        @Volatile
        private var INSTANCE: PaymentRepository? = null

        fun getInstance(context: Context): PaymentRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = PaymentRepository(context)
                INSTANCE = instance
                instance
            }
        }
    }

    fun getAllSessions(): Flow<List<CheckoutSession>> = checkoutDao.getAllSessionsFlow()
    fun getSessionFlow(id: String): Flow<CheckoutSession?> = checkoutDao.getSessionFlowById(id)
    fun getLedgerEntries(): Flow<List<MerchantLedgerEntry>> = checkoutDao.getLedgerEntries()
    fun getWebhookLogs(): Flow<List<WebhookLog>> = checkoutDao.getWebhookLogs()
    fun getWebhookLogsForSession(sessionId: String): Flow<List<WebhookLog>> = checkoutDao.getWebhookLogsBySessionId(sessionId)

    suspend fun getSessionById(id: String): CheckoutSession? = checkoutDao.getSessionById(id)

    suspend fun createCheckoutSession(
        merchantId: String,
        amountFiat: Double,
        currency: String,
        cryptoAsset: CryptoAsset,
        slippagePct: Double,
        exchangeRate: Double,
        freezeWindowMinutes: Int,
        feePct: Double
    ): CheckoutSession {
        // Stripe style checkout token id
        val sessionId = "ch_" + UUID.randomUUID().toString().replace("-", "").take(12)
        
        // Calculate crypto amount with slippage & fee inclusion buffer:
        // cryptoValue = (fiatAmount / exchangeRate) * (1 + slippagePct/100) * (1 + feePct/100)
        val baseCryptoAmount = amountFiat / exchangeRate
        val multiplier = (1.0 + slippagePct / 100.0) * (1.0 + feePct / 100.0)
        val cryptoAmountRequired = baseCryptoAmount * multiplier

        val paymentAddress = generateMockAddress(cryptoAsset)
        val qrPayload = generateQrPayload(cryptoAsset, paymentAddress, cryptoAmountRequired)
        val expiryTime = System.currentTimeMillis() + (freezeWindowMinutes * 60 * 1000)

        val session = CheckoutSession(
            id = sessionId,
            merchantId = merchantId,
            amountFiat = amountFiat,
            currency = currency,
            cryptoAsset = cryptoAsset.name,
            cryptoAmountRequired = cryptoAmountRequired,
            paymentAddress = paymentAddress,
            qrPayload = qrPayload,
            expiryTime = expiryTime,
            state = "CREATED",
            confirmations = 0,
            transactionHash = null,
            createdTime = System.currentTimeMillis(),
            slippagePct = slippagePct,
            exchangeRateUsed = exchangeRate,
            isSettled = false
        )

        checkoutDao.insertSession(session)
        
        // Log Webhook create event
        triggerSimulatedWebhook(
            sessionId = sessionId,
            eventType = "payment.created",
            state = "CREATED",
            confirmations = 0,
            txHash = null,
            session = session
        )

        return session
    }

    suspend fun updateSessionState(id: String, state: String, confirmations: Int, txHash: String? = null, refundReason: String? = null) {
        val currentSession = checkoutDao.getSessionById(id) ?: return
        
        var isSettlementExecuted = currentSession.isSettled
        if (state == "CONFIRMED" && !currentSession.isSettled) {
            // Trigger Merchant Settlement logic when payment is confirmed!
            // Deduct processing fee & transfer to ledger
            val feeRate = CryptoAsset.values().firstOrNull { it.name == currentSession.cryptoAsset }?.typicalFeePct ?: 0.01
            val feeFiat = currentSession.amountFiat * feeRate
            val netFiatSettled = currentSession.amountFiat - feeFiat

            val ledgerEntry = MerchantLedgerEntry(
                sessionId = id,
                merchantId = currentSession.merchantId,
                amountFiat = currentSession.amountFiat,
                cryptoAmount = currentSession.cryptoAmountRequired,
                cryptoAsset = currentSession.cryptoAsset,
                feeFiat = feeFiat,
                netFiatSettled = netFiatSettled,
                timestamp = System.currentTimeMillis()
            )

            checkoutDao.insertLedgerEntry(ledgerEntry)
            isSettlementExecuted = true
            
            // Also trigger payout settlement webhook log
            triggerSimulatedWebhook(
                sessionId = id,
                eventType = "payment.settled",
                state = "CONFIRMED",
                confirmations = confirmations,
                txHash = txHash,
                session = currentSession,
                ledgEntry = ledgerEntry
            )
        }

        val updatedSession = currentSession.copy(
            state = state,
            confirmations = confirmations,
            transactionHash = txHash ?: currentSession.transactionHash,
            isSettled = isSettlementExecuted,
            refundReason = refundReason ?: currentSession.refundReason
        )

        checkoutDao.insertSession(updatedSession)

        // Webhook log based on state update
        val eventType = when (state) {
            "PENDING_PAYMENT" -> "payment.received"
            "CONFIRMED" -> "payment.confirmed"
            "FAILED" -> "payment.failed"
            "EXPIRED" -> "payment.expired"
            "REFUNDED" -> "payment.refunded"
            else -> "payment.updated"
        }

        triggerSimulatedWebhook(
            sessionId = id,
            eventType = eventType,
            state = state,
            confirmations = confirmations,
            txHash = txHash ?: currentSession.transactionHash,
            session = updatedSession
        )
    }

    suspend fun triggerSimulatedWebhook(
        sessionId: String,
        eventType: String,
        state: String,
        confirmations: Int,
        txHash: String?,
        session: CheckoutSession,
        ledgEntry: MerchantLedgerEntry? = null
    ) {
        val simulatedUrl = "https://merchant.api/v1/webhooks"
        
        // Build JSON representation
        val payload = """
        {
          "id": "evt_${UUID.randomUUID().toString().replace("-", "").take(10)}",
          "object": "event",
          "type": "$eventType",
          "created": ${System.currentTimeMillis() / 1000},
          "data": {
            "checkout_session": {
              "id": "${session.id}",
              "merchant_id": "${session.merchantId}",
              "amount_fiat": ${session.amountFiat},
              "currency": "${session.currency}",
              "crypto_asset": "${session.cryptoAsset}",
              "crypto_amount_required": ${String.format("%.8f", session.cryptoAmountRequired)},
              "payment_address": "${session.paymentAddress}",
              "status": "$state",
              "confirmations": $confirmations,
              "transaction_hash": ${txHash?.let { "\"$it\"" } ?: "null"},
              "expiry_time": ${session.expiryTime / 1000}
            }${ledgEntry?.let { ledg -> """,
            "settlement": {
              "gross_fiat": ${ledg.amountFiat},
              "processing_fee_fiat": ${String.format("%.2f", ledg.feeFiat)},
              "net_settled_fiat": ${String.format("%.2f", ledg.netFiatSettled)},
              "settled_at": ${ledg.timestamp / 1000}
            }""" } ?: ""}
          },
          "livemode": false
        }
        """.trimIndent()

        val log = WebhookLog(
            sessionId = sessionId,
            eventType = eventType,
            url = simulatedUrl,
            payload = payload,
            statusCode = 200, // Simulated network success response
            timestamp = System.currentTimeMillis()
        )

        checkoutDao.insertWebhookLog(log)
    }

    suspend fun clearAllData() {
        checkoutDao.clearSessions()
        checkoutDao.clearLedger()
        checkoutDao.clearWebhookLogs()
    }

    private fun generateMockAddress(asset: CryptoAsset): String {
        val randHex = { len: Int ->
            val chars = "0123456789abcdef"
            (1..len).map { chars[Random.nextInt(chars.length)] }.joinToString("")
        }
        val randBase58 = { len: Int ->
            val chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
            (1..len).map { chars[Random.nextInt(chars.length)] }.joinToString("")
        }

        return when (asset) {
            CryptoAsset.BTC -> "bc1q" + randHex(38) // Bech32 SegWit
            CryptoAsset.BTC_LN -> "lnbc1" + randHex(60) // Lightning Network BOLT11 invoice
            CryptoAsset.USDT_ERC20 -> "0x" + randHex(40) // Ethereum address
            CryptoAsset.USDT_TRC20 -> "T" + randHex(33) // Tron address
            CryptoAsset.ETH -> "0x" + randHex(40) // Ethereum address
            CryptoAsset.XLM -> "G" + randBase58(55).uppercase() // Stellar Address (starts with G)
        }
    }

    private fun generateQrPayload(asset: CryptoAsset, address: String, amount: Double): String {
        return when (asset) {
            CryptoAsset.BTC -> "bitcoin:$address?amount=${String.format("%.8f", amount)}&label=AureomAI"
            CryptoAsset.BTC_LN -> "lightning:$address"
            CryptoAsset.USDT_ERC20 -> "ethereum:$address?amount=$amount&token=USDT_ERC20"
            CryptoAsset.USDT_TRC20 -> "tron:$address?amount=$amount&token=USDT_TRC20"
            CryptoAsset.ETH -> "ethereum:$address?value=${String.format("%.18f", amount)}"
            CryptoAsset.XLM -> "stellar:$address?amount=$amount"
        }
    }
}
