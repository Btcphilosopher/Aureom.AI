package com.example.data.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CheckoutDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: CheckoutSession)

    @Update
    suspend fun updateSession(session: CheckoutSession)

    @Query("SELECT * FROM checkout_sessions WHERE id = :id")
    suspend fun getSessionById(id: String): CheckoutSession?

    @Query("SELECT * FROM checkout_sessions WHERE id = :id")
    fun getSessionFlowById(id: String): Flow<CheckoutSession?>

    @Query("SELECT * FROM checkout_sessions ORDER BY createdTime DESC")
    fun getAllSessionsFlow(): Flow<List<CheckoutSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerEntry(entry: MerchantLedgerEntry)

    @Query("SELECT * FROM merchant_ledger_entries ORDER BY timestamp DESC")
    fun getLedgerEntries(): Flow<List<MerchantLedgerEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWebhookLog(log: WebhookLog)

    @Query("SELECT * FROM webhook_logs ORDER BY timestamp DESC")
    fun getWebhookLogs(): Flow<List<WebhookLog>>

    @Query("SELECT * FROM webhook_logs WHERE sessionId = :sessionId ORDER BY timestamp DESC")
    fun getWebhookLogsBySessionId(sessionId: String): Flow<List<WebhookLog>>

    @Query("DELETE FROM checkout_sessions")
    suspend fun clearSessions()

    @Query("DELETE FROM merchant_ledger_entries")
    suspend fun clearLedger()

    @Query("DELETE FROM webhook_logs")
    suspend fun clearWebhookLogs()
}

@Database(
    entities = [CheckoutSession::class, MerchantLedgerEntry::class, WebhookLog::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun checkoutDao(): CheckoutDao
}
