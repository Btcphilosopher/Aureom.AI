package com.example.domain

import com.example.data.database.CheckoutSession
import com.example.data.model.CryptoAsset
import com.example.data.repository.PaymentRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

class BlockchainEngine(private val repository: PaymentRepository) {
    
    private val scope = CoroutineScope(Dispatchers.Default + Job())
    private var miningJob: Job? = null

    private val _currentBlockHeights = MutableStateFlow(
        mapOf(
            "Bitcoin Network" to 842560L,
            "Ethereum Network" to 19825420L,
            "Tron Network" to 61250310L,
            "Stellar Network" to 51042300L
        )
    )
    val currentBlockHeights: StateFlow<Map<String, Long>> = _currentBlockHeights.asStateFlow()

    private val _blockGenerationTrigger = MutableStateFlow(0L)
    val blockGenerationTrigger: StateFlow<Long> = _blockGenerationTrigger.asStateFlow()

    init {
        startBlockMineSimulator()
    }

    private fun startBlockMineSimulator() {
        miningJob = scope.launch {
            while (isActive) {
                // Every 6 seconds, mine a block on networks
                delay(6000L)
                val current = _currentBlockHeights.value.toMutableMap()
                current["Bitcoin Network"] = current["Bitcoin Network"]!! + 1
                current["Ethereum Network"] = current["Ethereum Network"]!! + Random.nextInt(1, 3)
                current["Tron Network"] = current["Tron Network"]!! + 2
                current["Stellar Network"] = current["Stellar Network"]!! + Random.nextInt(1, 4)
                
                _currentBlockHeights.value = current
                _blockGenerationTrigger.value = System.currentTimeMillis()

                // Go through all sessions in the DB and advance their confirmations!
                scope.launch(Dispatchers.IO) {
                    processPendingSessions()
                }
            }
        }
    }

    private suspend fun processPendingSessions() {
        try {
            val allSessionsFlow = repository.checkoutDao.getAllSessionsFlow()
            val sessionsList = allSessionsFlow.first()
            sessionsList.forEach { session ->
                if (session.state == "PENDING_PAYMENT") {
                    val asset = CryptoAsset.values().firstOrNull { it.name == session.cryptoAsset }
                    if (asset != null) {
                        val nextConfirmations = session.confirmations + 1
                        if (nextConfirmations >= asset.confirmationsRequired) {
                            // Confirmed and fully settled!
                            repository.updateSessionState(
                                id = session.id,
                                state = "CONFIRMED",
                                confirmations = asset.confirmationsRequired,
                                txHash = session.transactionHash
                            )
                        } else {
                            // Increment confirmations index
                            repository.updateSessionState(
                                id = session.id,
                                state = "PENDING_PAYMENT",
                                confirmations = nextConfirmations,
                                txHash = session.transactionHash
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun submitSimulatedPayment(sessionId: String): String {
        val hash = "0x" + UUID.randomUUID().toString().replace("-", "")
        repository.updateSessionState(
            id = sessionId,
            state = "PENDING_PAYMENT",
            confirmations = 0,
            txHash = hash
        )
        // If the asset requires 0 confirmations (like Bitcoin Lightning Network),
        // we instantly transition to CONFIRMED!
        val session = repository.getSessionById(sessionId)
        if (session != null) {
            val asset = CryptoAsset.values().firstOrNull { it.name == session.cryptoAsset }
            if (asset != null && asset.confirmationsRequired == 0) {
                repository.updateSessionState(
                    id = sessionId,
                    state = "CONFIRMED",
                    confirmations = 0,
                    txHash = hash
                )
            }
        }
        return hash
    }
    
    fun stopShutdown() {
        miningJob?.cancel()
    }
}
