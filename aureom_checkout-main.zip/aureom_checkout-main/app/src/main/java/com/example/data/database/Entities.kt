package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "checkout_sessions")
data class CheckoutSession(
    @PrimaryKey val id: String,
    val merchantId: String,
    val amountFiat: Double,
    val currency: String,
    val cryptoAsset: String,
    val cryptoAmountRequired: Double,
    val paymentAddress: String,
    val qrPayload: String,
    val expiryTime: Long,
    val state: String, // CREATED, PENDING_PAYMENT, CONFIRMED, FAILED, EXPIRED, REFUNDED
    val confirmations: Int,
    val transactionHash: String?,
    val createdTime: Long,
    val slippagePct: Double,
    val exchangeRateUsed: Double,
    val isSettled: Boolean,
    val refundReason: String? = null
)

@Entity(tableName = "merchant_ledger_entries")
data class MerchantLedgerEntry(
    @PrimaryKey(autoGenerate = true) val entryId: Int = 0,
    val sessionId: String,
    val merchantId: String,
    val amountFiat: Double,
    val cryptoAmount: Double,
    val cryptoAsset: String,
    val feeFiat: Double,
    val netFiatSettled: Double,
    val timestamp: Long
)

@Entity(tableName = "webhook_logs")
data class WebhookLog(
    @PrimaryKey(autoGenerate = true) val logId: Int = 0,
    val sessionId: String,
    val eventType: String, // payment_created, payment_received, payment_confirmed, payment_settled, payment_refunded
    val url: String,
    val payload: String,
    val statusCode: Int,
    val timestamp: Long
)
