package com.example.data.model

enum class CryptoAsset(
    val assetId: String,
    val displayName: String,
    val rateToUsd: Double,
    val uriScheme: String,
    val networkName: String,
    val typicalFeePct: Double,
    val confirmationsRequired: Int,
    val formatSymbol: String
) {
    BTC("BTC", "Bitcoin (Mainnet)", 68500.0, "bitcoin", "Bitcoin Network", 0.012, 2, "BTC"),
    BTC_LN("BTC_LN", "Bitcoin (Lightning)", 68500.0, "lightning", "Lightning Network", 0.002, 0, "mBTC"),
    USDT_ERC20("USDT_ERC20", "USDT (ERC-20)", 1.0, "ethereum", "Ethereum Network", 0.01, 6, "USDT"),
    USDT_TRC20("USDT_TRC20", "USDT (TRC-20)", 1.0, "tron", "Tron Network", 0.005, 4, "USDT"),
    ETH("ETH", "Ethereum", 3450.0, "ethereum", "Ethereum Network", 0.012, 6, "ETH"),
    XLM("XLM", "Stellar Lumens", 0.12, "stellar", "Stellar Network", 0.001, 1, "XLM")
}
