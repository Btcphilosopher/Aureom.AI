package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp

@Composable
fun StylizedQRCode(payload: String, modifier: Modifier = Modifier) {
    val size = 21 // standard size QR code matrix
    val hash = payload.hashCode()
    
    Box(
        modifier = modifier
            .background(Color.White, shape = RoundedCornerShape(12.dp))
            .padding(14.dp)
            .aspectRatio(1f)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cellWidth = this.size.width / size
            val cellHeight = this.size.height / size
            
            // Draw standard corners finder patterns
            drawFinderPattern(0, 0, cellWidth, cellHeight)
            drawFinderPattern(size - 7, 0, cellWidth, cellHeight)
            drawFinderPattern(0, size - 7, cellWidth, cellHeight)
            
            // Draw matrix cell pixels
            for (r in 0 until size) {
                for (c in 0 until size) {
                    // Skip finder zone pixels to prevent overwriting
                    if ((r < 8 && c < 8) || (r < 8 && c >= size - 8) || (r >= size - 8 && c < 8)) {
                        continue
                    }
                    
                    // Simple deterministic math formula utilizing the string hash code
                    // to render unique pixel grids for varying payment addresses/amounts
                    val pixelSeed = r * 19 + c * 31 + (hash ushr (r % 4))
                    val filled = (pixelSeed % 3 == 0 || (r + c) % 5 == 0 || (r * c) % 7 == 2)
                    
                    if (filled) {
                        drawRect(
                            color = Color(0xFF0F162A), // Dark navy QR dots
                            topLeft = Offset(c * cellWidth, r * cellHeight),
                            size = Size(cellWidth + 0.5f, cellHeight + 0.5f) // overlay pixel blend
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawFinderPattern(startRow: Int, startCol: Int, cw: Float, ch: Float) {
    // 7x7 outer square
    drawRect(
        color = Color(0xFF0F162A),
        topLeft = Offset(startCol * cw, startRow * ch),
        size = Size(7 * cw, 7 * ch)
    )
    // 5x5 inner white spacer
    drawRect(
        color = Color.White,
        topLeft = Offset((startCol + 1) * cw, (startRow + 1) * ch),
        size = Size(5 * cw, 5 * ch)
    )
    // 3x3 core center block
    drawRect(
        color = Color(0xFF0F162A),
        topLeft = Offset((startCol + 2) * cw, (startRow + 2) * ch),
        size = Size(3 * cw, 3 * ch)
    )
}
