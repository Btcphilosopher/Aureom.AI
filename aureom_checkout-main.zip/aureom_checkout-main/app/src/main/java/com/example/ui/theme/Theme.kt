package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = lightColorScheme(
    primary = GoldPrimary,
    secondary = StablecoinTeal,
    tertiary = EthereumPurple,
    background = NavyDeepBg,
    surface = NavySurface,
    onBackground = TextLight,
    onSurface = TextLight,
    surfaceVariant = NavySurfaceLight,
    onSurfaceVariant = TextMuted
)

// We force a high-end clean minimalist light aesthetic for Aureom Checkout POS
private val LightColorScheme = lightColorScheme(
    primary = GoldPrimary,
    secondary = StablecoinTeal,
    tertiary = EthereumPurple,
    background = NavyDeepBg,
    surface = NavySurface,
    onBackground = TextLight,
    onSurface = TextLight,
    surfaceVariant = NavySurfaceLight,
    onSurfaceVariant = TextMuted
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Default to false for light Clean Minimalism theme
    dynamicColor: Boolean = false, // Disable default material wallpaper syncing for strict fintech brand control
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
