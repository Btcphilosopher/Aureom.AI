package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.database.CheckoutSession
import com.example.data.database.MerchantLedgerEntry
import com.example.data.database.WebhookLog
import com.example.data.model.CryptoAsset
import com.example.domain.CryptoPricingEngine
import com.example.ui.components.StylizedQRCode
import com.example.ui.theme.*
import com.example.ui.viewmodel.CheckoutViewModel
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.absoluteValue

class MainActivity : ComponentActivity() {
    private val viewModel: CheckoutViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    MainNavigationLayout(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

enum class NavigationTab(val label: String, val iconSelected: ImageVector, val iconUnselected: ImageVector) {
    POS("POS Terminal", Icons.Filled.Calculate, Icons.Outlined.Calculate),
    CHECKOUT("Customer Pay", Icons.Filled.QrCodeScanner, Icons.Outlined.QrCodeScanner),
    PORTAL("Merchant", Icons.Filled.Storefront, Icons.Outlined.Storefront),
    API_PLAYGROUND("API Playground", Icons.Filled.Terminal, Icons.Outlined.Terminal),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

@Composable
fun MainNavigationLayout(
    viewModel: CheckoutViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(NavigationTab.POS) }
    val activeSession by viewModel.activeSession.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDeepBg)
    ) {
        // App Main Brand Header Box
        HeaderBrandBox(viewModel = viewModel)

        // Active Banner if session is currently pending or creation
        ActiveSessionBanner(
            activeSession = activeSession,
            onBannerTapped = {
                currentTab = NavigationTab.CHECKOUT
            }
        )

        // Dynamic Screen Content Container with transitions
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (currentTab) {
                NavigationTab.POS -> PosTerminalScreen(
                    viewModel = viewModel,
                    onCheckoutCreated = {
                        currentTab = NavigationTab.CHECKOUT
                    }
                )
                NavigationTab.CHECKOUT -> CustomerCheckoutScreen(
                    viewModel = viewModel
                )
                NavigationTab.PORTAL -> MerchantPortalScreen(
                    viewModel = viewModel
                )
                NavigationTab.API_PLAYGROUND -> ApiPlaygroundScreen(
                    viewModel = viewModel
                )
                NavigationTab.SETTINGS -> SettingsScreen(
                    viewModel = viewModel
                )
            }
        }

        // Bottom Navigation Bar
        NavigationBar(
            containerColor = NavySurface,
            tonalElevation = 8.dp,
            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
        ) {
            NavigationTab.values().forEach { tab ->
                val selected = currentTab == tab
                NavigationBarItem(
                    selected = selected,
                    onClick = { currentTab = tab },
                    icon = {
                        Icon(
                            imageVector = if (selected) tab.iconSelected else tab.iconUnselected,
                            contentDescription = tab.label,
                            tint = if (selected) GoldPrimary else TextMuted
                        )
                    },
                    label = {
                        Text(
                            text = tab.label,
                            fontSize = 11.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            color = if (selected) TextLight else TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = NavySurfaceLight
                    )
                )
            }
        }
    }
}

@Composable
fun HeaderBrandBox(viewModel: CheckoutViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(NavySurface)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            color = GoldPrimary.copy(alpha = 0.15f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = "A",
                    color = GoldPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "AUREOM.AI",
                color = TextLight,
                fontSize = 14.sp,
                letterSpacing = 1.8.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = "RETAIL BTC + STABLECOIN INFRASTRUCTURE",
                color = TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
        
        // Oracle Live rate button status
        Surface(
            color = NavySurfaceLight,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.clickable { viewModel.refreshPricingRates() }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(StablecoinTeal, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ORACLE LIVE",
                    color = TextLight,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun ActiveSessionBanner(
    activeSession: CheckoutSession?,
    onBannerTapped: () -> Unit
) {
    if (activeSession != null && activeSession.state != "CONFIRMED" && activeSession.state != "REFUNDED" && activeSession.state != "EXPIRED") {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            GoldPrimary.copy(alpha = 0.9f),
                            StablecoinTeal.copy(alpha = 0.85f)
                        )
                    )
                )
                .clickable { onBannerTapped() }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = "Active Invoice Progress",
                    tint = NavyDeepBg,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Active session ${activeSession.id} is currently ${activeSession.state}",
                    color = NavyDeepBg,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "TAP TO VIEW",
                color = NavyDeepBg,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }
    }
}

// ==========================================
// SCREEN: POS MERCHANT TERMINAL
// ==========================================
@Composable
fun PosTerminalScreen(
    viewModel: CheckoutViewModel,
    onCheckoutCreated: () -> Unit
) {
    var amountInput by remember { mutableStateOf("49.99") }
    val selectedAsset by viewModel.selectedAsset.collectAsStateWithLifecycle()
    val selectedCurrency by viewModel.selectedCurrency.collectAsStateWithLifecycle()
    val rates by viewModel.rates.collectAsStateWithLifecycle()

    val rateForAsset = rates[selectedAsset.assetId] ?: selectedAsset.rateToUsd
    val parsedAmount = amountInput.toDoubleOrNull() ?: 0.0
    val equivalentValue = if (rateForAsset > 0) parsedAmount / rateForAsset else 0.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Amount input panel card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavySurface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "ENTER CHARGE AMOUNT",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                
                // Big numerical input
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = when (selectedCurrency) {
                            "GBP" -> "£"
                            "EUR" -> "€"
                            else -> "$"
                        },
                        color = GoldPrimary,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    
                    BasicTextField(
                        value = amountInput,
                        onValueChange = { input: String ->
                            // Simple sanitization
                            if (input.isEmpty() || input.matches(Regex("^\\d*\\.?\\d{0,2}$"))) {
                                amountInput = input
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = LocalTextStyle.current.copy(
                            color = TextLight,
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier.width(IntrinsicSize.Min)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = NavySurfaceLight, thickness = 1.dp)
                Spacer(modifier = Modifier.height(12.dp))

                // Asset details equivalent breakdown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ESTIMATED PAYMENT VALUE",
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${String.format("%.6f", equivalentValue)} ${selectedAsset.formatSymbol}",
                            color = StablecoinTeal,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "LIVE RATE REFERENCE",
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "1 ${selectedAsset.formatSymbol} ≈ ${selectedCurrency} ${String.format("%,.2f", rateForAsset)}",
                            color = TextLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Coin/Asset Selection grid
        Text(
            text = "SELECT SETTLEMENT CRYPTO ASSET",
            color = TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CryptoAsset.values().forEach { asset ->
                val isSelected = selectedAsset == asset
                Surface(
                    color = if (isSelected) NavySurfaceLight else NavySurface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        width = 1.5.dp,
                        color = if (isSelected) GoldPrimary else Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.selectedAsset.value = asset }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Icon representing cryptocurrency
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(
                                        color = getAssetBrandColor(asset).copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(8.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = asset.formatSymbol.take(1),
                                    color = getAssetBrandColor(asset),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = asset.displayName,
                                    color = TextLight,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Processing fee: ${(asset.typicalFeePct * 100)}% • ${asset.networkName}",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        
                        // Check Circle Indicator
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Selected Asset",
                                tint = GoldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Create Checkout CTA
        Button(
            onClick = {
                if (parsedAmount > 0) {
                    viewModel.createCheckoutSession(parsedAmount, selectedAsset)
                    onCheckoutCreated()
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = GoldPrimary,
                contentColor = NavyDeepBg
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Icon(
                imageVector = Icons.Default.QrCodeScanner,
                contentDescription = "Create Invoice"
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "GENERATE PAYMENT TERMINAL INVOICE",
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )
        }
    }
}

// ==========================================
// SCREEN: CUSTOMER CHECKOUT (INVOICE PORTAL)
// ==========================================
@Composable
fun CustomerCheckoutScreen(viewModel: CheckoutViewModel) {
    val activeSession by viewModel.activeSession.collectAsStateWithLifecycle()
    val timeRemaining by viewModel.timeRemainingSeconds.collectAsStateWithLifecycle()
    val sessionLogs by viewModel.activeSessionLogs.collectAsStateWithLifecycle()
    
    val clipboardManager = LocalClipboardManager.current

    if (activeSession == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Storefront,
                    contentDescription = "Blank Invoices",
                    tint = TextMuted,
                    modifier = Modifier.size(64.dp)
                )
                Text(
                    text = "NO ACTIVE CHECKOUT SESSION",
                    color = TextLight,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Use the POS Terminal tab to input an amount and click generate to launch a live payment checkout screen for the customer.",
                    color = TextMuted,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }
        }
    } else {
        val session = activeSession!!
        val asset = CryptoAsset.values().firstOrNull { it.name == session.cryptoAsset } ?: CryptoAsset.BTC
        
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Status Billboard Card
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when (session.state) {
                            "CONFIRMED" -> AlertGreen.copy(alpha = 0.12f)
                            "PENDING_PAYMENT" -> GoldPrimary.copy(alpha = 0.12f)
                            "REFUNDED" -> EthereumPurple.copy(alpha = 0.12f)
                            "EXPIRED", "FAILED" -> AlertRed.copy(alpha = 0.12f)
                            else -> NavySurface
                        }
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(
                        width = 1.dp,
                        color = when (session.state) {
                            "CONFIRMED" -> AlertGreen
                            "PENDING_PAYMENT" -> GoldPrimary
                            "REFUNDED" -> EthereumPurple
                            "EXPIRED", "FAILED" -> AlertRed
                            else -> NavySurfaceLight
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        color = when (session.state) {
                                            "CONFIRMED" -> AlertGreen
                                            "PENDING_PAYMENT" -> GoldPrimary
                                            "REFUNDED" -> EthereumPurple
                                            "EXPIRED", "FAILED" -> AlertRed
                                            else -> StablecoinTeal
                                        },
                                        shape = CircleShape
                                    )
                            )
                            Text(
                                text = "SESSION STATUS: ${session.state}",
                                color = TextLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${String.format("%.6f", session.cryptoAmountRequired)} ${asset.formatSymbol}",
                            color = when (session.state) {
                                "CONFIRMED" -> AlertGreen
                                else -> TextLight
                            },
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "= ${session.currency} ${String.format("%.2f", session.amountFiat)} fiat invoice",
                            color = TextMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        if (session.state == "CREATED" && timeRemaining > 0) {
                            Spacer(modifier = Modifier.height(10.dp))
                            // Progress bar
                            val totalSecs = (session.slippagePct * 10 * 60).toInt() // freeze length
                            val progress = if (totalSecs > 0) timeRemaining.toFloat() / 600f else 0.5f
                            LinearProgressIndicator(
                                progress = progress.coerceIn(0f, 1f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                color = GoldPrimary,
                                trackColor = NavyDeepBg
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Rate freezes in ${formatTimeRemaining(timeRemaining)}",
                                color = GoldPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else if (session.state == "PENDING_PAYMENT") {
                            Spacer(modifier = Modifier.height(10.dp))
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = GoldPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Mempool Detected! Building Confirmations: ${session.confirmations} / ${asset.confirmationsRequired}",
                                color = GoldPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else if (session.state == "CONFIRMED") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Settled payout directly onto Merchant Ledger!",
                                color = AlertGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // QR code and payment instruction card
            if (session.state == "CREATED" || session.state == "PENDING_PAYMENT") {
                item {
                    val qrCodeThemeColor = getAssetBrandColor(asset)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NavySurface, RoundedCornerShape(16.dp))
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "SCAN QR WITH CRYPTO WALLET",
                            color = TextLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // Beautiful centered custom finder QR Code element
                        Box(
                            modifier = Modifier
                                .width(220.dp)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .border(2.dp, qrCodeThemeColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        ) {
                            StylizedQRCode(
                                payload = session.qrPayload,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // Copyable address box
                        Text(
                            text = "PAYMENT DESTINATION ADDRESS",
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Start)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NavyDeepBg, RoundedCornerShape(8.dp))
                                .clickable { clipboardManager.setText(AnnotatedString(session.paymentAddress)) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = session.paymentAddress,
                                color = TextLight,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = Icons.Default.CopyAll,
                                contentDescription = "Copy address",
                                tint = StablecoinTeal,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // SIMULATOR INJECTOR BUTTON
                item {
                    Surface(
                        color = NavySurface,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, StablecoinTeal.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "AUREOM CHAIN SANDBOX SIMULATOR",
                                color = StablecoinTeal,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Simulate scanning this QR code and broadcasting the transaction details into the blockchain mempool dynamically.",
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            Button(
                                onClick = { viewModel.simulateCustomerPayment() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = StablecoinTeal,
                                    contentColor = NavyDeepBg
                                ),
                                shape = RoundedCornerShape(8.dp),
                                enabled = session.state == "CREATED",
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = "Simulate Pay"
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (session.state == "CREATED") "EXECUTE SIMULATED CUSTOMER TRANSACTION" else "TX BROADCASTED",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            } else {
                // Succeeded checkout overview
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NavySurface, RoundedCornerShape(16.dp))
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (session.state == "CONFIRMED") Icons.Filled.CheckCircle else Icons.Filled.Error,
                            contentDescription = "Receipt Status Icon",
                            tint = if (session.state == "CONFIRMED") AlertGreen else AlertRed,
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = if (session.state == "CONFIRMED") "RECEIPT SETTLED" else "TRANSACTION COMPLETED",
                            color = TextLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                        
                        HorizontalDivider(color = NavySurfaceLight, thickness = 1.dp)
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Checkout ID:", color = TextMuted, fontSize = 11.sp)
                            Text(session.id, color = TextLight, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Transaction Hash:", color = TextMuted, fontSize = 11.sp)
                            Text(
                                text = session.transactionHash?.take(18) ?: "N/A",
                                color = StablecoinTeal,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                        if (session.refundReason != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Refund Reason:", color = TextMuted, fontSize = 11.sp)
                                Text(session.refundReason!!, color = AlertRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Webhook active notifications events
            if (sessionLogs.isNotEmpty()) {
                item {
                    Text(
                        text = "ACTIVE SESSION WEBHOOK DISPATCH",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                items(sessionLogs) { log ->
                    WebhookLogItem(log = log)
                }
            }
        }
    }
}

// ==========================================
// SCREEN: MERCHANT PORTAL (LEDGER & AI ANALYTICS)
// ==========================================
@Composable
fun MerchantPortalScreen(viewModel: CheckoutViewModel) {
    val ledgerEntries by viewModel.ledgerEntries.collectAsStateWithLifecycle()
    val allSessions by viewModel.allSessions.collectAsStateWithLifecycle()
    val aiAdvice by viewModel.aiAdvice.collectAsStateWithLifecycle()
    val isGeneratingAdvice by viewModel.isGeneratingAdvice.collectAsStateWithLifecycle()

    var activeSubTab by remember { mutableStateOf(0) } // 0: Ledger, 1: AI Advisor

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Stats Banner Summary
        MerchantMetricsOverview(ledgerEntries = ledgerEntries, allSessions = allSessions)
        Spacer(modifier = Modifier.height(16.dp))

        // Tab selection (ledger vs advice)
        TabRow(
            selectedTabIndex = activeSubTab,
            containerColor = NavySurface,
            contentColor = GoldPrimary,
            modifier = Modifier.clip(RoundedCornerShape(8.dp))
        ) {
            Tab(
                selected = activeSubTab == 0,
                onClick = { activeSubTab = 0 },
                text = { Text("Settlement Ledger", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = activeSubTab == 1,
                onClick = { activeSubTab = 1 },
                text = { Text("Aureom AI Optimizer", fontWeight = FontWeight.Bold) }
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        Box(modifier = Modifier.weight(1f)) {
            if (activeSubTab == 0) {
                // Ledger screen
                if (ledgerEntries.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.ReceiptLong, "Ledger", tint = TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No settled entries in blockchain ledger.", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ledgerEntries) { entry ->
                            LedgerItemRow(entry = entry, viewModel = viewModel)
                        }
                    }
                }
            } else {
                // AI Advisor Screen
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(NavySurface, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "AUREOM INTEL SYSTEM",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )
                        Button(
                            onClick = { viewModel.runAiLedgerAnalysis() },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = NavyDeepBg),
                            enabled = !isGeneratingAdvice,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.Default.Psychology, "Run AI Analysis", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("RUN OPTIMIZER", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    HorizontalDivider(color = NavySurfaceLight)

                    if (isGeneratingAdvice) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = GoldPrimary)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("Analyzing ledger structures via Gemini API...", color = TextMuted, fontSize = 11.sp)
                            }
                        }
                    } else if (aiAdvice != null) {
                        // Render generated recommendations markdown simply
                        Text(
                            text = aiAdvice!!,
                            color = TextLight,
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            fontFamily = FontFamily.SansSerif
                        )
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        // Warning from Secret management skill guidelines
                        Text(
                            text = "*Dispatched dynamically via Aureom Smart Engine compiler. Dynamic forecasts may fluctuate based on network load & congestion.",
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Click RUN OPTIMIZER to feed cumulative POS transactional histories directly to Gemini for automated fee predictions, slippage warnings, and active channel routing guidelines.",
                                color = TextMuted,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MerchantMetricsOverview(
    ledgerEntries: List<MerchantLedgerEntry>,
    allSessions: List<CheckoutSession>
) {
    // Calculators
    val grossVolume = ledgerEntries.sumOf { it.amountFiat }
    val averageTicket = if (ledgerEntries.isNotEmpty()) grossVolume / ledgerEntries.size else 0.0
    val totalFees = ledgerEntries.sumOf { it.feeFiat }
    val netSettled = grossVolume - totalFees

    Card(
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "CUMULATIVE MERCHANT PORTAL METRICS",
                color = TextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Net Settle", color = TextMuted, fontSize = 11.sp)
                    Text(
                        text = "USD ${String.format("%,.2f", netSettled)}",
                        color = StablecoinTeal,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Box(
                    modifier = Modifier
                        .background(StablecoinTeal.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Icon(Icons.Filled.AccountBalanceWallet, "Wallet Bal", tint = StablecoinTeal, modifier = Modifier.size(24.dp))
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = NavySurfaceLight)
            Spacer(modifier = Modifier.height(12.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Total Volume", color = TextMuted, fontSize = 10.sp)
                    Text("USD ${String.format("%,.2f", grossVolume)}", color = TextLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Processing Fees", color = TextMuted, fontSize = 10.sp)
                    Text("USD ${String.format("%,.2f", totalFees)}", color = AlertRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Avg Invoice Ticket", color = TextMuted, fontSize = 10.sp)
                    Text("USD ${String.format("%,.2f", averageTicket)}", color = TextLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LedgerItemRow(entry: MerchantLedgerEntry, viewModel: CheckoutViewModel) {
    var isExpanded by remember { mutableStateOf(false) }
    
    Card(
        colors = CardDefaults.cardColors(containerColor = NavySurfaceLight),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(StablecoinTeal.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Download, "Receipt Down", tint = StablecoinTeal, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        val simpleFormat = SimpleDateFormat("MMM dd HH:mm", Locale.getDefault())
                        Text(
                            text = "Payout: ${entry.sessionId}",
                            color = TextLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Settled ${simpleFormat.format(Date(entry.timestamp))} • ${entry.cryptoAsset}",
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "+USD ${String.format("%.2f", entry.netFiatSettled)}",
                        color = AlertGreen,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "Fee: USD ${String.format("%.2f", entry.feeFiat)}",
                        color = TextMuted,
                        fontSize = 9.sp
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .background(NavyDeepBg, RoundedCornerShape(6.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Gross payment received:", color = TextMuted, fontSize = 10.sp)
                        Text("USD ${String.format("%.2f", entry.amountFiat)}", color = TextLight, fontSize = 10.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Crypto amount settled:", color = TextMuted, fontSize = 10.sp)
                        Text("${String.format("%.6f", entry.cryptoAmount)} ${entry.cryptoAsset}", color = StablecoinTeal, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    HorizontalDivider(color = NavySurfaceLight)
                    Spacer(modifier = Modifier.height(2.dp))

                    Button(
                        onClick = { viewModel.initiateRefund(entry.sessionId, "Customer requested refund of Checkout PO") },
                        colors = ButtonDefaults.buttonColors(containerColor = AlertRed, contentColor = NavyDeepBg),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp)
                    ) {
                        Icon(Icons.Default.Undo, "Refund Order", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("INITIATE IMMEDIATE FULL REFUND", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN: API PLAYGROUND & REST SIMULATOR
// ==========================================
@Composable
fun ApiPlaygroundScreen(viewModel: CheckoutViewModel) {
    var selectedMethodIndex by remember { mutableStateOf(0) }
    val activeSession by viewModel.activeSession.collectAsStateWithLifecycle()
    val webhookLogs by viewModel.webhookLogs.collectAsStateWithLifecycle()
    
    val currentSessionId = activeSession?.id ?: "ch_demo7864f"
    val assetCode = activeSession?.cryptoAsset ?: "BTC"

    val routes = listOf(
        "POST /api/v1/checkout/create" to "Create Checkout Session",
        "GET /api/v1/checkout/status/{id}" to "Fetch Checkout Status",
        "GET /api/v1/rates" to "Polling Global Forex Rates",
        "POST /api/v1/refund" to "Initiate Session Refund"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Dropdown/Selector route tab
        Text(
            text = "SELECT REST API ROUTE SIMULATOR",
            color = TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        ScrollableTabRow(
            selectedTabIndex = selectedMethodIndex,
            containerColor = NavySurface,
            contentColor = GoldPrimary,
            edgePadding = 0.dp,
            modifier = Modifier.clip(RoundedCornerShape(8.dp))
        ) {
            routes.forEachIndexed { idx, pair ->
                Tab(
                    selected = selectedMethodIndex == idx,
                    onClick = { selectedMethodIndex = idx },
                    text = {
                        Text(
                            text = pair.first,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                )
            }
        }

        // Selected Route raw block view
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                titleForRoute(selectedMethodIndex),
                color = TextLight,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Authorization: Bearer sk_live_...",
                color = TextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        // Code Sandbox Container
        Card(
            colors = CardDefaults.cardColors(containerColor = NavySurface),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, NavySurfaceLight),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Raw Request Mock
                Text("HTTP REQ SPECIFICATION", color = GoldPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Surface(
                    color = NavyDeepBg,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = buildRequestPayload(selectedMethodIndex, currentSessionId, assetCode),
                        color = StablecoinTeal,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                
                // Raw Response Mock
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("API RESPONSE (HTTP JSON)", color = GoldPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        color = AlertGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "200 OK",
                            color = AlertGreen,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                
                Surface(
                    color = NavyDeepBg,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = buildResponseJson(selectedMethodIndex, activeSession, viewModel),
                        color = TextLight,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }

        // Webhook log summary panel
        Text(
            text = "SIMULATED OUTGOING WEBHOOK DISPATCH LOGS",
            color = TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        LazyColumn(
            modifier = Modifier.height(110.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (webhookLogs.isEmpty()) {
                item {
                    Text(
                        "No webhooks dispatched yet. Run a simulated transaction in the Pay tab to see outgoing alerts.",
                        color = TextMuted,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(12.dp)
                    )
                }
            } else {
                items(webhookLogs.take(3)) { log ->
                    WebhookLogItem(log = log)
                }
            }
        }
    }
}

@Composable
fun WebhookLogItem(log: WebhookLog) {
    var expanded by remember { mutableStateOf(false) }
    
    Card(
        colors = CardDefaults.cardColors(containerColor = NavySurface),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Launch,
                        contentDescription = "Webhook Dispatched",
                        tint = StablecoinTeal,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = log.eventType,
                        color = TextLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "HMAC Signed",
                    color = GoldPrimary,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .background(NavyDeepBg, RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "HEADERS:\nContent-Type: application/json\nAureom-Signature-256: t7u8a9b2c3d4f5e6b7d8\n\nPAYLOAD:\n${log.payload}",
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

private fun titleForRoute(routeIdx: Int): String {
    return when (routeIdx) {
        0 -> "POST /api/v1/checkout/create"
        1 -> "GET /api/v1/checkout/status/{id}"
        2 -> "GET /api/v1/rates"
        else -> "POST /api/v1/refund"
    }
}

private fun buildRequestPayload(routeIdx: Int, currentSessionId: String, assetCode: String): String {
    return when (routeIdx) {
        0 -> """
        HEADERS:
          Authorization: Bearer sk_live_aur_84
          Content-Type: application/json
        
        BODY:
        {
          "merchant_id": "m_aureom_84",
          "amount_fiat": 49.99,
          "currency": "USD",
          "crypto_asset": "$assetCode"
        }
        """.trimIndent()
        
        1 -> """
        QUERY PARAMETERS:
          id = "$currentSessionId"
        
        HEADERS:
          Authorization: Bearer sk_live_aur_84
        """.trimIndent()
        
        2 -> """
        QUERY PARAMETERS:
          currency = "USD"
        
        HEADERS:
          Authorization: Bearer sk_live_aur_84
        """.trimIndent()
        
        else -> """
        HEADERS:
          Authorization: Bearer sk_live_aur_84
          Content-Type: application/json
        
        BODY:
        {
          "checkout_id": "$currentSessionId",
          "refund_reason": "Item out of stock"
        }
        """.trimIndent()
    }
}

private fun buildResponseJson(routeIdx: Int, session: CheckoutSession?, viewModel: CheckoutViewModel): String {
    if (session == null && routeIdx != 2) {
        return """
        {
          "error": "resource_not_found",
          "message": "Launch a checkout session on POS terminal first."
        }
        """.trimIndent()
    }
    
    return when (routeIdx) {
        0 -> """
        {
          "id": "${session?.id}",
          "merchant_id": "${session?.merchantId}",
          "amount_fiat": ${session?.amountFiat},
          "currency": "${session?.currency}",
          "crypto_asset": "${session?.cryptoAsset}",
          "crypto_amount_required": ${session?.cryptoAmountRequired},
          "payment_address": "${session?.paymentAddress}",
          "qr_payload": "${session?.qrPayload}",
          "status": "${session?.state}",
          "expiry_time": ${session?.expiryTime?.let { it / 1000 }}
        }
        """.trimIndent()
        
        1 -> """
        {
          "id": "${session?.id}",
          "status": "${session?.state}",
          "confirmations": ${session?.confirmations},
          "required_confirmations": ${if (session?.cryptoAsset == "BTC_LN") 0 else 6},
          "transaction_hash": ${session?.transactionHash?.let { "\"$it\"" } ?: "null"},
          "expiry_time": ${session?.expiryTime?.let { it / 1000 }}
        }
        """.trimIndent()
        
        2 -> {
            val curr = viewModel.selectedCurrency.value
            val btcRate = CryptoPricingEngine.getLiveRate(CryptoAsset.BTC, curr)
            val ethRate = CryptoPricingEngine.getLiveRate(CryptoAsset.ETH, curr)
            val usdtRate = CryptoPricingEngine.getLiveRate(CryptoAsset.USDT_ERC20, curr)
            val xlmRate = CryptoPricingEngine.getLiveRate(CryptoAsset.XLM, curr)
            
            """
            {
              "fiat_reference": "$curr",
              "last_updated": ${System.currentTimeMillis() / 1000},
              "rates": {
                "BTC": $btcRate,
                "BTC_LIGHTNING": $btcRate,
                "USDT_ERC20": $usdtRate,
                "USDT_TRC20": $usdtRate,
                "ETH": $ethRate,
                "XLM": $xlmRate
              }
            }
            """.trimIndent()
        }
        
        else -> """
        {
          "refund_id": "rf_${UUID.randomUUID().toString().replace("-", "").take(10)}",
          "checkout_id": "${session?.id}",
          "status": "REFUND_SUCCESSFUL",
          "amount_refunded": ${session?.amountFiat},
          "currency": "${session?.currency}",
          "timestamp": ${System.currentTimeMillis() / 1000}
        }
        """.trimIndent()
    }
}

// ==========================================
// SCREEN: CONFIGURATION SETTINGS
// ==========================================
@Composable
fun SettingsScreen(viewModel: CheckoutViewModel) {
    var merchantIdInput by remember { mutableStateOf(viewModel.merchantId.value) }
    var slippageInput by remember { mutableStateOf(viewModel.slippagePct.value.toString()) }
    var freezeInput by remember { mutableStateOf(viewModel.freezeWindowMinutes.value.toString()) }
    val selectedCurrency by viewModel.selectedCurrency.collectAsStateWithLifecycle()
    
    var showApiKeyWarning by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "MERCHANT INFRASTRUCTURE CONFIG",
            color = TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // API Security warning from android secret management skill
        if (showApiKeyWarning) {
            Card(
                colors = CardDefaults.cardColors(containerColor = GoldPrimary.copy(alpha = 0.15f)),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AUREOM API KEYS SECRET ISOLATION",
                            color = GoldPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black
                        )
                        IconButton(
                            onClick = { showApiKeyWarning = false },
                            modifier = Modifier.size(16.dp)
                        ) {
                            Icon(Icons.Default.Close, "Close warning", tint = GoldPrimary, modifier = Modifier.size(12.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Security Warning: I have included your API keys in the generated APK file for this prototype. Please be aware that Android APKs can be easily decompiled, and these keys can be extracted by anyone who has access to the file. Do not share this APK file publicly or with unauthorized individuals to prevent potential misuse.",
                        color = TextLight,
                        fontSize = 9.sp,
                        lineHeight = 13.sp
                    )
                }
            }
        }

        // Card Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = NavySurface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Merchant ID input
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("MERCHANT ID", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = merchantIdInput,
                        onValueChange = {
                            merchantIdInput = it
                            viewModel.merchantId.value = it
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextLight,
                            unfocusedTextColor = TextLight,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = NavySurfaceLight,
                            focusedContainerColor = NavyDeepBg,
                            unfocusedContainerColor = NavyDeepBg
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Currency switcher
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("SETTLEMENT ACCCOUNTING FIAT", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("USD", "GBP", "EUR").forEach { fiat ->
                            val isSelected = selectedCurrency == fiat
                            Surface(
                                color = if (isSelected) GoldPrimary else NavySurfaceLight,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        viewModel.selectedCurrency.value = fiat
                                        viewModel.refreshPricingRates()
                                    }
                            ) {
                                Text(
                                    text = fiat,
                                    color = if (isSelected) NavyDeepBg else TextLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 10.dp)
                                )
                            }
                        }
                    }
                }

                // Slippage buffer input
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("VOLATILITY BUFFER / SLIPPAGE TOLERANCE (%)", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = slippageInput,
                        onValueChange = {
                            slippageInput = it
                            it.toDoubleOrNull()?.let { doubleVal ->
                                viewModel.slippagePct.value = doubleVal
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextLight,
                            unfocusedTextColor = TextLight,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = NavySurfaceLight,
                            focusedContainerColor = NavyDeepBg,
                            unfocusedContainerColor = NavyDeepBg
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Rate Freeze Window Minutes
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("LOCK RATE PRICIING WINDOW (MINUTES)", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = freezeInput,
                        onValueChange = {
                            freezeInput = it
                            it.toIntOrNull()?.let { intVal ->
                                viewModel.freezeWindowMinutes.value = intVal
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextLight,
                            unfocusedTextColor = TextLight,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = NavySurfaceLight,
                            focusedContainerColor = NavyDeepBg,
                            unfocusedContainerColor = NavyDeepBg
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Reset Database operations button
        Button(
            onClick = { viewModel.clearAllSimulatedData() },
            colors = ButtonDefaults.buttonColors(
                containerColor = AlertRed,
                contentColor = NavyDeepBg
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.DeleteSweep, "Clear Sandbox DB")
            Spacer(modifier = Modifier.width(8.dp))
            Text("RESET SANDBOX MERCHANT DB LEDGER", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ==========================================
// UTILITY HELPERS
// ==========================================
fun getAssetBrandColor(asset: CryptoAsset): Color {
    return when (asset) {
        CryptoAsset.BTC, CryptoAsset.BTC_LN -> GoldPrimary
        CryptoAsset.USDT_ERC20, CryptoAsset.USDT_TRC20 -> StablecoinTeal
        CryptoAsset.ETH -> EthereumPurple
        CryptoAsset.XLM -> Color(0xFF039FFF)
    }
}

private fun formatTimeRemaining(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format("%02d:%02d", m, s)
}
