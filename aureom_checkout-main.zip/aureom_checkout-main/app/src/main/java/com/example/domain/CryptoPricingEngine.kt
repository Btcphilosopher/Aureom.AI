package com.example.domain

import com.example.data.model.CryptoAsset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.random.Random

object CryptoPricingEngine {
    
    // Live rates of assets relative to USD
    private val baseRates = java.util.concurrent.ConcurrentHashMap<CryptoAsset, Double>().apply {
        put(CryptoAsset.BTC, 68500.0)
        put(CryptoAsset.BTC_LN, 68500.0)
        put(CryptoAsset.USDT_ERC20, 1.00)
        put(CryptoAsset.USDT_TRC20, 1.00)
        put(CryptoAsset.ETH, 3450.0)
        put(CryptoAsset.XLM, 0.125)
    }

    // Fiat forex rates relative to USD (1 USD is how many GBP, EUR, etc.)
    private val fiatRates = mapOf(
        "USD" to 1.0,
        "GBP" to 0.79,
        "EUR" to 0.92
    )

    fun getLiveRate(asset: CryptoAsset, fiatCurrency: String): Double {
        // Dynamic simulated volatility wiggle (-0.1% to +0.1%)
        val shiftFactor = 1.0 + (Random.nextDouble(-0.001, 0.001))
        val usdRate = (baseRates[asset] ?: 1.0) * shiftFactor
        
        val targetFiatConversion = fiatRates[fiatCurrency] ?: 1.0
        
        // Let's return how much 1 Crypto Asset is worth in target fiat
        // Note: crypto_asset_to_fiat = crypto_asset_to_usd * usd_to_fiat
        return usdRate * targetFiatConversion
    }

    // Try to retrieve real rates from a public API. Fallback seamlessly if offline.
    suspend fun refreshRatesFromApi(): Boolean = withContext(Dispatchers.IO) {
        var success = false
        try {
            val url = URL("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,stellar,tether&vs_currencies=usd")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 4000
            connection.readTimeout = 4000
            connection.connect()

            if (connection.responseCode == 200) {
                val responseMsg = connection.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(responseMsg)
                
                val btcPrice = root.optJSONObject("bitcoin")?.optDouble("usd", 68500.0) ?: 68500.0
                val ethPrice = root.optJSONObject("ethereum")?.optDouble("usd", 3450.0) ?: 3450.0
                val xlmPrice = root.optJSONObject("stellar")?.optDouble("usd", 0.125) ?: 0.125
                val tetherPrice = root.optJSONObject("tether")?.optDouble("usd", 1.0) ?: 1.0

                baseRates[CryptoAsset.BTC] = btcPrice
                baseRates[CryptoAsset.BTC_LN] = btcPrice
                baseRates[CryptoAsset.ETH] = ethPrice
                baseRates[CryptoAsset.XLM] = xlmPrice
                baseRates[CryptoAsset.USDT_ERC20] = tetherPrice
                baseRates[CryptoAsset.USDT_TRC20] = tetherPrice
                success = true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return@withContext success
    }

    // Get current asset list pricing for public API rate endpoints
    fun getRatesMap(fiatCurrency: String): Map<String, Double> {
        val mapped = mutableMapOf<String, Double>()
        CryptoAsset.values().forEach { asset ->
            mapped[asset.assetId] = getLiveRate(asset, fiatCurrency)
        }
        return mapped
    }
}
