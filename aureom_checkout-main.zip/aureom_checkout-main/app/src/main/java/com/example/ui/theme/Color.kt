package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFF005AC1)     // Clean Blue as primary accent
val StablecoinTeal = Color(0xFF26A17B)  // Clean Mint/Teal
val EthereumPurple = Color(0xFF627EEA)  // Ethereum Purple
val NavyDeepBg = Color(0xFFFDFBFF)      // Clean light background canvas
val NavySurface = Color(0xFFFFFFFF)     // Clean white cards/surfaces
val NavySurfaceLight = Color(0xFFF3F3FA) // Soft grey background tabs and highlights
val TextLight = Color(0xFF1B1B1F)        // Solid charcoal text for primary elements
val TextMuted = Color(0xFF44474E)        // Neutral medium grey support labels
val AlertGreen = Color(0xFF26A17B)       // Crisp teal success green
val AlertRed = Color(0xFFBA1A1A)         // Clean M3 red warning indicator

