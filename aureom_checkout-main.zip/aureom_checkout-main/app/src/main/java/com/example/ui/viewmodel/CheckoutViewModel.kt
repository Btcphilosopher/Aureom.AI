package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.CheckoutSession
import com.example.data.database.MerchantLedgerEntry
import com.example.data.database.WebhookLog
import com.example.data.model.CryptoAsset
import com.example.data.repository.PaymentRepository
import com.example.domain.BlockchainEngine
import com.example.domain.CryptoPricingEngine
import com.example.domain.GeminiOptimizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CheckoutViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PaymentRepository.getInstance(application)
    private val blockchainEngine = BlockchainEngine(repository)

    // Exposed flows from room database
    val allSessions: StateFlow<List<CheckoutSession>> = repository.getAllSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val ledgerEntries: StateFlow<List<MerchantLedgerEntry>> = repository.getLedgerEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val webhookLogs: StateFlow<List<WebhookLog>> = repository.getWebhookLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active checkout session lookup
    private val _activeSessionId = MutableStateFlow<String?>(null)
    val activeSessionId: StateFlow<String?> = _activeSessionId.asStateFlow()

    val activeSession: StateFlow<CheckoutSession?> = _activeSessionId.flatMapLatest { id ->
        if (id == null) flowOf(null) else repository.getSessionFlow(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeSessionLogs: StateFlow<List<WebhookLog>> = _activeSessionId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else repository.getWebhookLogsForSession(id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Pricing and rates management
    private val _rates = MutableStateFlow<Map<String, Double>>(emptyMap())
    val rates: StateFlow<Map<String, Double>> = _rates.asStateFlow()

    private val _isRefreshingRates = MutableStateFlow(false)
    val isRefreshingRates: StateFlow<Boolean> = _isRefreshingRates.asStateFlow()

    // Blockchain network indicators
    val currentBlocks: StateFlow<Map<String, Long>> = blockchainEngine.currentBlockHeights
    val blockTrigger: StateFlow<Long> = blockchainEngine.blockGenerationTrigger

    // Configuration states (Settings)
    val merchantId = MutableStateFlow("m_aureom_84")
    val selectedCurrency = MutableStateFlow("USD")
    val selectedAsset = MutableStateFlow(CryptoAsset.BTC)
    val slippagePct = MutableStateFlow(1.0)
    val freezeWindowMinutes = MutableStateFlow(10)

    // Ticking session time remaining
    private val _timeRemainingSeconds = MutableStateFlow(0L)
    val timeRemainingSeconds: StateFlow<Long> = _timeRemainingSeconds.asStateFlow()

    // AI Optimization feedback
    private val _aiAdvice = MutableStateFlow<String?>(null)
    val aiAdvice: StateFlow<String?> = _aiAdvice.asStateFlow()

    private val _isGeneratingAdvice = MutableStateFlow(false)
    val isGeneratingAdvice: StateFlow<Boolean> = _isGeneratingAdvice.asStateFlow()

    init {
        refreshPricingRates()
        startActiveSessionTimer()
    }

    // Refresh rates from blockchain pricing oracle
    fun refreshPricingRates() {
        viewModelScope.launch {
            _isRefreshingRates.value = true
            // Attempt remote API rates refresh
            CryptoPricingEngine.refreshRatesFromApi()
            _rates.value = CryptoPricingEngine.getRatesMap(selectedCurrency.value)
            _isRefreshingRates.value = false
        }
    }

    // Timer loop responsible for session expirations and ticking UI Countdown
    private fun startActiveSessionTimer() {
        viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                delay(1000L)
                val session = activeSession.value
                if (session != null) {
                    val now = System.currentTimeMillis()
                    val diff = session.expiryTime - now
                    if (diff <= 0) {
                        _timeRemainingSeconds.value = 0
                        if (session.state == "CREATED") {
                            // Automatically expire in database
                            repository.updateSessionState(
                                id = session.id,
                                state = "EXPIRED",
                                confirmations = 0
                            )
                        }
                    } else {
                        _timeRemainingSeconds.value = diff / 1000
                    }
                }
            }
        }
    }

    // API Creation Call: /api/v1/checkout/create
    fun createCheckoutSession(amountFiat: Double, asset: CryptoAsset) {
        viewModelScope.launch {
            val mId = merchantId.value
            val curr = selectedCurrency.value
            val slip = slippagePct.value
            val freezeMin = freezeWindowMinutes.value
            
            // Fetch correct current live rate for this asset/fiat combo
            val currentRate = CryptoPricingEngine.getLiveRate(asset, curr)
            
            val session = repository.createCheckoutSession(
                merchantId = mId,
                amountFiat = amountFiat,
                currency = curr,
                cryptoAsset = asset,
                slippagePct = slip,
                exchangeRate = currentRate,
                freezeWindowMinutes = freezeMin,
                feePct = asset.typicalFeePct * 100 // fee as percent
            )
            
            _activeSessionId.value = session.id
            _timeRemainingSeconds.value = (freezeMin * 60).toLong()
        }
    }

    // API Payment Event check: Simulate scanning QR and emitting block transaction
    fun simulateCustomerPayment() {
        val session = activeSession.value ?: return
        if (session.state != "CREATED") return

        viewModelScope.launch {
            blockchainEngine.submitSimulatedPayment(session.id)
        }
    }

    // API Refund Action: /api/v1/refund (initiates complete or partial refund processing)
    fun initiateRefund(sessionId: String, reason: String) {
        viewModelScope.launch {
            // Update state to REFUNDED in database
            repository.updateSessionState(
                id = sessionId,
                state = "REFUNDED",
                confirmations = 0,
                refundReason = reason
            )
        }
    }

    // AI audit recommendation triggered on the ledger
    fun runAiLedgerAnalysis() {
        viewModelScope.launch {
            _isGeneratingAdvice.value = true
            _aiAdvice.value = null
            
            val sessionsList = allSessions.value
            val ledgersList = ledgerEntries.value
            
            val recommendation = GeminiOptimizer.generateOptimizedAdvice(sessionsList, ledgersList)
            _aiAdvice.value = recommendation
            _isGeneratingAdvice.value = false
        }
    }

    fun selectActiveSession(id: String?) {
        _activeSessionId.value = id
        if (id != null) {
            viewModelScope.launch {
                val session = repository.getSessionById(id)
                if (session != null) {
                    val now = System.currentTimeMillis()
                    val diff = session.expiryTime - now
                    _timeRemainingSeconds.value = if (diff > 0) diff / 1000 else 0
                }
            }
        } else {
            _timeRemainingSeconds.value = 0
        }
    }

    fun clearAllSimulatedData() {
        viewModelScope.launch {
            repository.clearAllData()
            _activeSessionId.value = null
            _aiAdvice.value = null
        }
    }

    override fun onCleared() {
        super.onCleared()
        blockchainEngine.stopShutdown()
    }
}
