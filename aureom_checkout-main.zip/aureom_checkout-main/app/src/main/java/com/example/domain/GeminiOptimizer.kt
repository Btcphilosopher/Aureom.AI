package com.example.domain

import com.example.BuildConfig
import com.example.data.database.CheckoutSession
import com.example.data.database.MerchantLedgerEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiOptimizer {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateOptimizedAdvice(
        sessions: List<CheckoutSession>,
        ledgers: List<MerchantLedgerEntry>
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "**Aureom AI Engine offline**: Gemini API Key not configured in Secrets panel. Please enter your `GEMINI_API_KEY` into the AI Studio Secrets panel. Let's look at recommended local defaults instead:\n\n" +
                    "- **Slippage recommendation**: Set BTC to 1.5% and ETH to 1.0% to cushion mempool congestion delays. Keep stablecoins locked at 0.25%.\n" +
                    "- **Routing optimization**: Prioritize **Lightning Network** for sub-$50 cart sizes; this reduces typical merchant settlement fees to under 10 sats!"
        }

        // Prepare transaction stats for prompt
        val totalCount = sessions.size
        val confirmedCount = sessions.count { it.state == "CONFIRMED" }
        val failedCount = sessions.count { it.state == "FAILED" }
        val expiredCount = sessions.count { it.state == "EXPIRED" }
        val refundedCount = sessions.count { it.state == "REFUNDED" }
        
        val assetStats = countMap(sessions.map { it.cryptoAsset })
        val successRate = if (totalCount > 0) (confirmedCount.toDouble() / totalCount * 100) else 100.0

        val prompt = """
            You are Aureom.AI, an expert automated fintech systems compiler, crypto payment liquidity auditor, and network routing specialist.
            
            We are providing you with real-time transactional metrics from our retail merchant POS:
            - Total Checkout Sessions: $totalCount
            - Completed / Settled: $confirmedCount
            - Expired / Abandoned: $expiredCount
            - Refunded: $refundedCount
            - Failed Transactions: $failedCount
            - Global Success Rate: ${String.format("%.1f", successRate)}%
            - Crypto Assets Utilized: $assetStats
            
            Based on this transaction ledger, draft an executive cryptocurrency checkout configuration advice for the merchant.
            Your output MUST be concise, professional, beautifully formatted in Markdown bullets, and contain:
            1. **SYSTEM DIAGNOSIS**: Core summary of checkout friction (e.g., success rate vs abandonment).
            2. **VOLATILITY SLIPPAGE FORECAST**: Recommending target slippage (slippage_pct) buffer to lock for BTC (Mainnet) and ERC-20 Tether.
            3. **FEES AND ROUTING CHANNELS**: Suggesting layout adjustments to guide customers to cheaper payment routes (like Stellar XLM or Lightning Network) based on the size of the baskets.
            
            Ensure the response is structured, expert, straightforward, and avoids fluffy promotional text. Keep it strictly to the bullet points listed.
        """.trimIndent()

        try {
            val jsonBody = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                }
                put("contents", contentsArray)
                
                // Set system instruction
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", "You are the primary financial analytics oracle for Aureom.ai merchant portal.")
                        })
                    })
                })
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val responseString = response.body?.string() ?: ""
                val responseJson = JSONObject(responseString)
                val textResponse = responseJson.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")

                return@withContext textResponse ?: "Unparsed AI response. Please check transaction patterns manually."
            } else {
                return@withContext "AI engine temporary connection latency (HTTP ${response.code}). Standard advice: Ensure Lightning network is enabled for standard fast micropayments."
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext "Network delay reading ledger details: ${e.localizedMessage}. Fallback: Prioritize stablecoins (USDT TRC-20) to lock absolute value margins."
        }
    }

    private fun countMap(items: List<String>): Map<String, Int> {
        val counts = mutableMapOf<String, Int>()
        items.forEach { counts[it] = counts.getOrDefault(it, 0) + 1 }
        return counts
    }
}
