import { initDatabase, getDb } from '../src/server/database.js';
import { addAccount } from '../src/server/accounts.js';
import { enqueueJobs } from '../src/server/queue.js';
import { startScheduler, stopScheduler } from '../src/server/scheduler.js';

async function runTest() {
  console.log('Initializing database for test...');
  await initDatabase();
  
  const accountId = 'test_account_01';
  console.log(`Creating test account: ${accountId}`);
  await addAccount(accountId, 'Test Account');

  const jobs = [];
  for (let i = 1; i <= 50; i++) {
    jobs.push({
      accountId,
      targetUsername: `user_follow_${i}`,
      operation: 'FOLLOW'
    });
  }
  for (let i = 1; i <= 50; i++) {
    jobs.push({
      accountId,
      targetUsername: `user_unfollow_${i}`,
      operation: 'UNFOLLOW'
    });
  }

  console.log(`Enqueuing ${jobs.length} jobs...`);
  await enqueueJobs(jobs as any);

  console.log('Starting scheduler...');
  startScheduler();

  // Monitor progress
  const interval = setInterval(async () => {
    const db = getDb();
    const pendingRs = await db.execute("SELECT COUNT(*) as count FROM jobs WHERE status = 'PENDING'");
    const runningRs = await db.execute("SELECT COUNT(*) as count FROM jobs WHERE status = 'RUNNING'");
    const successRs = await db.execute("SELECT COUNT(*) as count FROM jobs WHERE status = 'SUCCESS'");
    const failedRs = await db.execute("SELECT COUNT(*) as count FROM jobs WHERE status = 'FAILED'");
    const pausedRs = await db.execute("SELECT COUNT(*) as count FROM jobs WHERE status = 'REQUIRES_USER_ACTION'");

    const pendingCount = pendingRs.rows[0].count;
    const runningCount = runningRs.rows[0].count;
    const successCount = successRs.rows[0].count;
    const failedCount = failedRs.rows[0].count;
    const pausedCount = pausedRs.rows[0].count;

    console.log(`Progress: Pending=${pendingCount} Running=${runningCount} Success=${successCount} Failed=${failedCount} Paused=${pausedCount}`);

    const accountRs = await db.execute("SELECT status FROM accounts WHERE id = 'test_account_01'");
    if (accountRs.rows[0].status === 'PAUSED') {
      console.log('Account paused by rate limit/captcha. Simulating user resuming...');
      await db.execute("UPDATE accounts SET status = 'READY', lastError = NULL WHERE id = 'test_account_01'");
    }

    if (pendingCount === 0 && runningCount === 0) {
      console.log('Test completed.');
      clearInterval(interval);
      stopScheduler();
      process.exit(0);
    }
  }, 5000);
}

runTest().catch(console.error);
