# TikTok Action Manager

A lightweight, stable Node.js application for managing TikTok follow and unfollow workflows. It prioritizes stability, observability, safe failure handling, and clean architecture over unnecessary complexity.

## Features

- **Queue Engine**: Persistent SQLite-based job queue that survives restarts.
- **Rate Limit & Error Handling**: Gracefully handles temporary errors, CAPTCHA, and rate limits. Pauses processing when user intervention is required.
- **Mock Provider**: Includes a full mock provider to test the application locally without sending real requests.
- **Structured Logging**: Stores application and operation logs in JSON format.
- **Local Dashboard**: A React-based web dashboard to manage accounts, monitor the queue, and import target lists.

## Important Constraint Note

**TikTok does not provide an officially supported API for automated follow or unfollow operations.** 

In accordance with strict security and reliability guidelines, this application does *not* attempt to bypass platform restrictions using undocumented private endpoints, stealth browser automation, proxy rotation, or CAPTCHA solving. 

Instead, the codebase includes a full `MockTikTokAdapter` to demonstrate the architecture and workflow safely. An interface (`ISocialAdapter`) is provided so that if an officially authorized API becomes available, it can be integrated cleanly without rewriting the queue engine.

## Requirements

- Node.js (v18+)
- npm

## Installation

```bash
npm install
```

## Configuration

Copy the example configuration and `.env` files:

```bash
cp config.example.json config.json
cp .env.example .env
```

## Running the Application

To start the full-stack application (backend server + Vite frontend):

```bash
npm run dev
```
The application will be accessible at `http://localhost:3000`.

## Testing

An integration test is included to demonstrate the queue engine processing 50 FOLLOW and 50 UNFOLLOW operations using the mock provider. It verifies that the application processes operations safely, records results, and recovers from mock temporary errors.

```bash
npx tsx tests/integration.test.ts
```

## Importing Target Lists

In the web dashboard, navigate to the **Queue** tab and use the **Import CSV** button.
The expected format is:

```csv
username,operation
user_one,follow
user_two,unfollow
```

## Recovering from Pauses/Crashes

If the platform returns a CAPTCHA or a hard rate limit, the affected account will be marked as `PAUSED`. The queue engine will stop picking up jobs for that account. You must manually resolve the issue (e.g., via the official app), then click **Resume** on the account in the web dashboard. The queue survives application restarts securely.
