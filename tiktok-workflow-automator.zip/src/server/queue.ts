import { getDb } from './database.js';

export interface Job {
  id: string;
  accountId: string;
  targetUsername: string;
  operation: string; // 'FOLLOW' | 'UNFOLLOW'
  status: string; // 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILED' | 'PAUSED' | 'CANCELLED' | 'REQUIRES_USER_ACTION'
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  attempts: number;
  result: string | null;
  errorCode: string | null;
  errorMessage: string | null;
}

export async function enqueueJobs(jobs: Omit<Job, 'id' | 'status' | 'createdAt' | 'startedAt' | 'completedAt' | 'attempts' | 'result' | 'errorCode' | 'errorMessage'>[]) {
  const db = getDb();
  
  const stmts = [];
  for (const job of jobs) {
    const id = crypto.randomUUID();
    const createdAt = new Date().toISOString();
    stmts.push({
      sql: `INSERT INTO jobs (id, accountId, targetUsername, operation, createdAt) VALUES (?, ?, ?, ?, ?)`,
      args: [id, job.accountId, job.targetUsername, job.operation, createdAt]
    });
  }

  await db.batch(stmts, "write");
}

export async function getNextJob(accountId: string): Promise<Job | null> {
  const db = getDb();
  const rs = await db.execute({
    sql: `SELECT * FROM jobs WHERE accountId = ? AND status = 'PENDING' ORDER BY createdAt ASC LIMIT 1`,
    args: [accountId]
  });
  if (rs.rows.length === 0) return null;
  return rs.rows[0] as unknown as Job;
}

export async function updateJobStatus(
  id: string, 
  status: string, 
  updates: Partial<Pick<Job, 'startedAt' | 'completedAt' | 'attempts' | 'result' | 'errorCode' | 'errorMessage'>>
) {
  const db = getDb();
  
  const setClauses: string[] = ['status = ?'];
  const values: any[] = [status];

  for (const [key, value] of Object.entries(updates)) {
    setClauses.push(`${key} = ?`);
    values.push(value !== undefined ? value : null);
  }
  
  values.push(id);

  const sql = `UPDATE jobs SET ${setClauses.join(', ')} WHERE id = ?`;
  await db.execute({ sql, args: values });
}
