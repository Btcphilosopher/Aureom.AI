export class AppError extends Error {
  constructor(public code: string, message: string) {
    super(message);
    this.name = this.constructor.name;
  }
}

export class AuthenticationError extends AppError {
  constructor(message: string) { super('AUTH_ERROR', message); }
}

export class RateLimitError extends AppError {
  constructor(message: string, public retryAfterMs?: number) { 
    super('RATE_LIMIT', message); 
  }
}

export class CaptchaRequiredError extends AppError {
  constructor(message: string) { super('CAPTCHA_REQUIRED', message); }
}

export class PermissionError extends AppError {
  constructor(message: string) { super('PERMISSION_DENIED', message); }
}

export class NetworkError extends AppError {
  constructor(message: string) { super('NETWORK_ERROR', message); }
}

export class TemporaryServiceError extends AppError {
  constructor(message: string) { super('TEMPORARY_SERVICE_ERROR', message); }
}

export class InvalidTargetError extends AppError {
  constructor(message: string) { super('INVALID_TARGET', message); }
}
