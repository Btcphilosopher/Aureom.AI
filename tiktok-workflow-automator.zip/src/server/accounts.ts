import { getDb } from './database.js';

export interface Account {
  id: string;
  displayName: string;
  status: string; // 'READY' | 'PAUSED' | 'RATE_LIMITED' | 'AUTH_ERROR'
  lastActivity: string | null;
  lastError: string | null;
  rateLimitReset: string | null;
}

export async function addAccount(id: string, displayName: string) {
  const db = getDb();
  await db.execute({
    sql: `INSERT INTO accounts (id, displayName) VALUES (?, ?)`,
    args: [id, displayName]
  });
}

export async function getAccounts(): Promise<Account[]> {
  const db = getDb();
  const rs = await db.execute('SELECT * FROM accounts');
  return rs.rows as unknown as Account[];
}

export async function updateAccountStatus(id: string, status: string, options?: {
  lastActivity?: string;
  lastError?: string | null;
  rateLimitReset?: string | null;
}) {
  const db = getDb();
  const setClauses: string[] = ['status = ?'];
  const values: any[] = [status];

  if (options?.lastActivity !== undefined) {
    setClauses.push('lastActivity = ?');
    values.push(options.lastActivity !== undefined ? options.lastActivity : null);
  }
  if (options?.lastError !== undefined) {
    setClauses.push('lastError = ?');
    values.push(options.lastError !== undefined ? options.lastError : null);
  }
  if (options?.rateLimitReset !== undefined) {
    setClauses.push('rateLimitReset = ?');
    values.push(options.rateLimitReset !== undefined ? options.rateLimitReset : null);
  }
  values.push(id);

  await db.execute({
    sql: `UPDATE accounts SET ${setClauses.join(', ')} WHERE id = ?`,
    args: values
  });
}
