import { createClient, Client } from '@libsql/client';
import path from 'path';
import fs from 'fs';

const dataDir = path.join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

let db: Client | null = null;

export async function initDatabase() {
  db = createClient({
    url: `file:${path.join(dataDir, 'app.sqlite')}`
  });

  await db.execute(`
    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY,
      displayName TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'READY',
      lastActivity TEXT,
      lastError TEXT,
      rateLimitReset TEXT
    );
  `);

  await db.execute(`
    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY,
      accountId TEXT,
      targetUsername TEXT NOT NULL,
      operation TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PENDING',
      createdAt TEXT NOT NULL,
      startedAt TEXT,
      completedAt TEXT,
      attempts INTEGER DEFAULT 0,
      result TEXT,
      errorCode TEXT,
      errorMessage TEXT,
      FOREIGN KEY (accountId) REFERENCES accounts (id)
    );
  `);

  await db.execute(`
    CREATE TABLE IF NOT EXISTS logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp TEXT NOT NULL,
      accountId TEXT,
      targetUsername TEXT,
      operation TEXT,
      status TEXT,
      durationMs INTEGER,
      errorCode TEXT,
      errorMessage TEXT
    );
  `);

  return db;
}

export function getDb(): Client {
  if (!db) {
    throw new Error("Database not initialized");
  }
  return db;
}
