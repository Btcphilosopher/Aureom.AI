import { ISocialAdapter, AdapterResult } from './ISocialAdapter.js';
import { AuthenticationError, RateLimitError, CaptchaRequiredError, TemporaryServiceError } from '../errors.js';

export class MockTikTokAdapter implements ISocialAdapter {
  private simulateDelay(): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, Math.random() * 500 + 300));
  }

  private simulateRandomFailure() {
    const rand = Math.random();
    if (rand < 0.05) {
      throw new RateLimitError("Mock rate limit exceeded", 60000); // 1 minute
    }
    if (rand >= 0.05 && rand < 0.07) {
      throw new CaptchaRequiredError("Mock CAPTCHA required");
    }
    if (rand >= 0.07 && rand < 0.09) {
      throw new AuthenticationError("Mock authentication failure");
    }
    if (rand >= 0.09 && rand < 0.12) {
      throw new TemporaryServiceError("Mock 503 service unavailable");
    }
  }

  async follow(accountId: string, username: string): Promise<AdapterResult> {
    await this.simulateDelay();
    this.simulateRandomFailure();
    return { success: true, message: "Followed successfully (Mock)" };
  }

  async unfollow(accountId: string, username: string): Promise<AdapterResult> {
    await this.simulateDelay();
    this.simulateRandomFailure();
    return { success: true, message: "Unfollowed successfully (Mock)" };
  }
}
