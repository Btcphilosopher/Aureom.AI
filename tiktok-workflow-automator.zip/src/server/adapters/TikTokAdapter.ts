import { ISocialAdapter, AdapterResult } from './ISocialAdapter.js';
import { AppError } from '../errors.js';

export class TikTokAdapter implements ISocialAdapter {
  async follow(accountId: string, username: string): Promise<AdapterResult> {
    throw new AppError(
      'UNSUPPORTED_OPERATION', 
      'TikTok does not provide an officially supported API for automated follow operations. ' +
      'Bypassing platform restrictions via undocumented endpoints or browser automation is strictly disabled in this adapter.'
    );
  }

  async unfollow(accountId: string, username: string): Promise<AdapterResult> {
    throw new AppError(
      'UNSUPPORTED_OPERATION',
      'TikTok does not provide an officially supported API for automated unfollow operations. ' +
      'Bypassing platform restrictions via undocumented endpoints or browser automation is strictly disabled in this adapter.'
    );
  }
}
