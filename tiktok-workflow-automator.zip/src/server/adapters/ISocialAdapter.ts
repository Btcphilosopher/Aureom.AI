export interface AdapterResult {
  success: boolean;
  message?: string;
}

export interface ISocialAdapter {
  follow(accountId: string, username: string): Promise<AdapterResult>;
  unfollow(accountId: string, username: string): Promise<AdapterResult>;
}
