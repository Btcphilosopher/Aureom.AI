import { Router } from 'express';
import { getAccounts, addAccount, updateAccountStatus } from './accounts.js';
import { enqueueJobs } from './queue.js';
import { getDb } from './database.js';
import { startScheduler, stopScheduler } from './scheduler.js';

export const apiRouter = Router();

apiRouter.get('/accounts', async (req, res) => {
  try {
    const accounts = await getAccounts();
    res.json(accounts);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

apiRouter.post('/accounts', async (req, res) => {
  try {
    const id = `account_${Math.floor(Math.random()*10000).toString().padStart(4, '0')}`;
    await addAccount(id, req.body.displayName || id);
    res.json({ success: true, id });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

apiRouter.post('/accounts/:id/resume', async (req, res) => {
  try {
    await updateAccountStatus(req.params.id, 'READY', { lastError: null });
    res.json({ success: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

apiRouter.get('/jobs', async (req, res) => {
  try {
    const db = getDb();
    const rs = await db.execute('SELECT * FROM jobs ORDER BY createdAt DESC LIMIT 100');
    res.json(rs.rows);
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

apiRouter.post('/jobs/import', async (req, res) => {
  try {
    const jobs = req.body.jobs;
    if (!Array.isArray(jobs)) {
      return res.status(400).json({ error: 'Jobs must be an array' });
    }
    await enqueueJobs(jobs);
    res.json({ success: true });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});

apiRouter.post('/scheduler/start', (req, res) => {
  startScheduler();
  res.json({ success: true });
});

apiRouter.post('/scheduler/stop', (req, res) => {
  stopScheduler();
  res.json({ success: true });
});
