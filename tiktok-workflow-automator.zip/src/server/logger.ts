import fs from 'fs';
import path from 'path';

const logsDir = path.join(process.cwd(), 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

export function logEvent(event: {
  timestamp: string;
  accountId?: string;
  targetUsername?: string;
  operation?: string;
  status: string;
  durationMs?: number;
  errorCode?: string;
  errorMessage?: string;
}) {
  const logLine = JSON.stringify(event);
  
  // Console logging for observability
  console.log(logLine);

  // Write to daily file
  const dateStr = event.timestamp.split('T')[0];
  const logFile = path.join(logsDir, `operations-${dateStr}.log`);
  fs.appendFileSync(logFile, logLine + '\n');
}
