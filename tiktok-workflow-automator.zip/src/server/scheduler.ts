import { getAccounts, updateAccountStatus } from './accounts.js';
import { getNextJob, updateJobStatus } from './queue.js';
import { MockTikTokAdapter } from './adapters/MockAdapter.js';
import { TikTokAdapter } from './adapters/TikTokAdapter.js';
import { ISocialAdapter } from './adapters/ISocialAdapter.js';
import { logEvent } from './logger.js';
import { RateLimitError, CaptchaRequiredError, AuthenticationError, TemporaryServiceError } from './errors.js';

let isRunning = false;
const adapter: ISocialAdapter = new MockTikTokAdapter(); 
// In a real scenario, could be switchable via env or config.

export async function startScheduler() {
  if (isRunning) return;
  isRunning = true;
  scheduleLoop();
}

export function stopScheduler() {
  isRunning = false;
}

async function scheduleLoop() {
  while (isRunning) {
    try {
      const accounts = await getAccounts();
      const readyAccounts = accounts.filter(a => a.status === 'READY');
      
      let processedAny = false;

      for (const account of readyAccounts) {
        if (!isRunning) break;
        const job = await getNextJob(account.id);
        
        if (job) {
          processedAny = true;
          await processJob(account.id, job);
          // Wait between jobs for the same account or globally
          await new Promise(resolve => setTimeout(resolve, 3000));
        }
      }

      if (!processedAny) {
        // No pending jobs, wait a bit before checking again
        await new Promise(resolve => setTimeout(resolve, 5000));
      }

    } catch (e) {
      console.error("Scheduler error:", e);
      await new Promise(resolve => setTimeout(resolve, 10000));
    }
  }
}

async function processJob(accountId: string, job: any) {
  const startTime = Date.now();
  await updateJobStatus(job.id, 'RUNNING', { startedAt: new Date().toISOString(), attempts: job.attempts + 1 });
  
  try {
    let result;
    if (job.operation === 'FOLLOW') {
      result = await adapter.follow(accountId, job.targetUsername);
    } else if (job.operation === 'UNFOLLOW') {
      result = await adapter.unfollow(accountId, job.targetUsername);
    } else {
      throw new Error(`Unknown operation: ${job.operation}`);
    }

    const durationMs = Date.now() - startTime;
    const completedAt = new Date().toISOString();

    await updateJobStatus(job.id, 'SUCCESS', {
      completedAt,
      result: result.message,
    });
    
    await updateAccountStatus(accountId, 'READY', { lastActivity: completedAt });

    logEvent({
      timestamp: completedAt,
      accountId,
      targetUsername: job.targetUsername,
      operation: job.operation,
      status: 'SUCCESS',
      durationMs
    });

  } catch (error: any) {
    const durationMs = Date.now() - startTime;
    const timestamp = new Date().toISOString();
    
    const isAppError = error.code !== undefined;
    const errorCode = isAppError ? error.code : 'UNKNOWN_ERROR';
    const errorMessage = error.message;

    logEvent({
      timestamp,
      accountId,
      targetUsername: job.targetUsername,
      operation: job.operation,
      status: 'FAILED',
      errorCode,
      errorMessage,
      durationMs
    });

    if (error instanceof RateLimitError) {
      const resetTime = new Date(Date.now() + (error.retryAfterMs || 60000)).toISOString();
      await updateAccountStatus(accountId, 'PAUSED', { 
        lastError: errorMessage,
        rateLimitReset: resetTime
      });
      await updateJobStatus(job.id, 'PENDING', { 
        errorCode, errorMessage 
      });
    } else if (error instanceof CaptchaRequiredError || error instanceof AuthenticationError) {
      await updateAccountStatus(accountId, 'PAUSED', { lastError: errorMessage });
      await updateJobStatus(job.id, 'REQUIRES_USER_ACTION', { 
        errorCode, errorMessage 
      });
    } else if (error instanceof TemporaryServiceError) {
      // Retry logic
      if (job.attempts >= 3) {
        await updateJobStatus(job.id, 'FAILED', { 
          completedAt: timestamp,
          errorCode, errorMessage 
        });
      } else {
        await updateJobStatus(job.id, 'PENDING', { 
          errorCode, errorMessage 
        });
      }
    } else {
      // Permanent failure
      await updateJobStatus(job.id, 'FAILED', { 
        completedAt: timestamp,
        errorCode, errorMessage 
      });
    }
  }
}
