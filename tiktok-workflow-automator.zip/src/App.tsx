import React, { useState, useEffect } from 'react';
import { 
  Play, Square, Settings, Upload, Download, 
  Users, ListOrdered, Activity, RefreshCw 
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'accounts' | 'queue' | 'logs'>('accounts');
  const [accounts, setAccounts] = useState<any[]>([]);
  const [jobs, setJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchAccounts = async () => {
    const res = await fetch('/api/accounts');
    if (res.ok) setAccounts(await res.json());
  };

  const fetchJobs = async () => {
    const res = await fetch('/api/jobs');
    if (res.ok) setJobs(await res.json());
  };

  useEffect(() => {
    fetchAccounts();
    fetchJobs();
    const interval = setInterval(() => {
      fetchAccounts();
      fetchJobs();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleStartQueue = async () => {
    await fetch('/api/scheduler/start', { method: 'POST' });
  };

  const handleStopQueue = async () => {
    await fetch('/api/scheduler/stop', { method: 'POST' });
  };

  const handleAddAccount = async () => {
    const name = prompt("Enter account name:");
    if (name) {
      await fetch('/api/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ displayName: name })
      });
      fetchAccounts();
    }
  };

  const handleResumeAccount = async (id: string) => {
    if (confirm("Are you sure you want to resume this account? Make sure you have resolved any restrictions.")) {
      await fetch(`/api/accounts/${id}/resume`, { method: 'POST' });
      fetchAccounts();
    }
  };

  const handleImportCSV = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const lines = text.split('\\n');
    
    // Quick parse for basic CSV: username,operation
    const newJobs = [];
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      const [username, operation] = line.split(',');
      if (username && operation && accounts.length > 0) {
        newJobs.push({
          accountId: accounts[0].id, // Assigning to first account for simplicity in this demo
          targetUsername: username.trim(),
          operation: operation.trim().toUpperCase()
        });
      }
    }

    if (newJobs.length > 0) {
      await fetch('/api/jobs/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobs: newJobs })
      });
      fetchJobs();
    }
  };

  return (
    <div className="min-h-screen bg-neutral-100 text-neutral-900 font-sans flex flex-col md:flex-row">
      <aside className="w-full md:w-64 bg-white border-r border-neutral-200 flex flex-col">
        <div className="p-4 border-b border-neutral-200 flex items-center space-x-2">
          <Activity className="w-6 h-6 text-blue-600" />
          <h1 className="font-semibold text-lg">Action Manager</h1>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          <button 
            onClick={() => setActiveTab('accounts')}
            className={cn("w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors", activeTab === 'accounts' ? "bg-blue-50 text-blue-700" : "text-neutral-600 hover:bg-neutral-50")}
          >
            <Users className="w-4 h-4" />
            <span>Accounts</span>
          </button>
          <button 
            onClick={() => setActiveTab('queue')}
            className={cn("w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors", activeTab === 'queue' ? "bg-blue-50 text-blue-700" : "text-neutral-600 hover:bg-neutral-50")}
          >
            <ListOrdered className="w-4 h-4" />
            <span>Queue</span>
          </button>
          <button 
            onClick={() => setActiveTab('logs')}
            className={cn("w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm font-medium transition-colors", activeTab === 'logs' ? "bg-blue-50 text-blue-700" : "text-neutral-600 hover:bg-neutral-50")}
          >
            <Activity className="w-4 h-4" />
            <span>Activity Logs</span>
          </button>
        </nav>

        <div className="p-4 border-t border-neutral-200">
          <div className="flex space-x-2">
            <button onClick={handleStartQueue} className="flex-1 flex items-center justify-center space-x-1 bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-md text-sm font-medium transition-colors">
              <Play className="w-4 h-4" />
              <span>Start</span>
            </button>
            <button onClick={handleStopQueue} className="flex-1 flex items-center justify-center space-x-1 bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded-md text-sm font-medium transition-colors">
              <Square className="w-4 h-4" />
              <span>Stop</span>
            </button>
          </div>
        </div>
      </aside>

      <main className="flex-1 p-6 lg:p-8 overflow-auto">
        {activeTab === 'accounts' && (
          <div className="space-y-6 max-w-4xl">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Accounts</h2>
              <button onClick={handleAddAccount} className="bg-white border border-neutral-300 text-neutral-700 px-4 py-2 rounded-md text-sm font-medium hover:bg-neutral-50 transition-colors">
                Add Account
              </button>
            </div>
            <div className="bg-white rounded-lg border border-neutral-200 shadow-sm overflow-hidden">
              <table className="w-full text-left text-sm">
                <thead className="bg-neutral-50 border-b border-neutral-200">
                  <tr>
                    <th className="px-6 py-3 font-medium text-neutral-500">Account</th>
                    <th className="px-6 py-3 font-medium text-neutral-500">Status</th>
                    <th className="px-6 py-3 font-medium text-neutral-500">Last Activity</th>
                    <th className="px-6 py-3 font-medium text-neutral-500">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {accounts.length === 0 && (
                    <tr><td colSpan={4} className="px-6 py-8 text-center text-neutral-500">No accounts configured.</td></tr>
                  )}
                  {accounts.map(acc => (
                    <tr key={acc.id} className="hover:bg-neutral-50">
                      <td className="px-6 py-4 font-medium">{acc.displayName}</td>
                      <td className="px-6 py-4">
                        <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium", 
                          acc.status === 'READY' ? "bg-green-100 text-green-800" :
                          acc.status === 'PAUSED' ? "bg-amber-100 text-amber-800" :
                          "bg-red-100 text-red-800"
                        )}>
                          {acc.status}
                        </span>
                        {acc.lastError && <div className="text-xs text-red-500 mt-1">{acc.lastError}</div>}
                      </td>
                      <td className="px-6 py-4 text-neutral-500">
                        {acc.lastActivity ? new Date(acc.lastActivity).toLocaleTimeString() : 'Never'}
                      </td>
                      <td className="px-6 py-4">
                        {acc.status === 'PAUSED' && (
                          <button onClick={() => handleResumeAccount(acc.id)} className="text-blue-600 hover:text-blue-800 font-medium text-sm">
                            Resume
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'queue' && (
          <div className="space-y-6 max-w-4xl">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">Job Queue</h2>
              <div className="flex space-x-2">
                <label className="bg-white border border-neutral-300 text-neutral-700 px-4 py-2 rounded-md text-sm font-medium hover:bg-neutral-50 transition-colors cursor-pointer flex items-center space-x-2">
                  <Upload className="w-4 h-4" />
                  <span>Import CSV</span>
                  <input type="file" accept=".csv" className="hidden" onChange={handleImportCSV} />
                </label>
              </div>
            </div>
            
            <div className="bg-white rounded-lg border border-neutral-200 shadow-sm overflow-hidden">
              <table className="w-full text-left text-sm">
                <thead className="bg-neutral-50 border-b border-neutral-200">
                  <tr>
                    <th className="px-6 py-3 font-medium text-neutral-500">Target</th>
                    <th className="px-6 py-3 font-medium text-neutral-500">Operation</th>
                    <th className="px-6 py-3 font-medium text-neutral-500">Status</th>
                    <th className="px-6 py-3 font-medium text-neutral-500">Result</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200">
                  {jobs.length === 0 && (
                    <tr><td colSpan={4} className="px-6 py-8 text-center text-neutral-500">Queue is empty.</td></tr>
                  )}
                  {jobs.map(job => (
                    <tr key={job.id} className="hover:bg-neutral-50">
                      <td className="px-6 py-4 font-medium">{job.targetUsername}</td>
                      <td className="px-6 py-4">{job.operation}</td>
                      <td className="px-6 py-4">
                        <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium", 
                          job.status === 'SUCCESS' ? "bg-green-100 text-green-800" :
                          job.status === 'FAILED' ? "bg-red-100 text-red-800" :
                          job.status === 'RUNNING' ? "bg-blue-100 text-blue-800" :
                          job.status === 'REQUIRES_USER_ACTION' ? "bg-amber-100 text-amber-800" :
                          "bg-neutral-100 text-neutral-800"
                        )}>
                          {job.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-neutral-500 max-w-xs truncate">
                        {job.result || job.errorMessage || '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="space-y-6 max-w-4xl">
            <h2 className="text-2xl font-semibold">Activity Logs</h2>
            <div className="bg-neutral-900 rounded-lg p-4 font-mono text-sm text-neutral-300 overflow-x-auto shadow-sm">
              <p className="text-neutral-500 italic mb-2">Logs are written to ./logs directory on disk.</p>
              {jobs.filter(j => j.status !== 'PENDING').slice(0, 10).map(job => (
                <div key={job.id} className="mb-2 whitespace-pre">
                  <span className="text-neutral-500">[{new Date(job.createdAt).toISOString()}]</span> 
                  <span className={job.status === 'SUCCESS' ? 'text-green-400' : 'text-amber-400'}> {job.status} </span> 
                  {job.operation} {job.targetUsername} 
                  {job.errorMessage && <span className="text-red-400"> - {job.errorMessage}</span>}
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
