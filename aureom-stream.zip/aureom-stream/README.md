# AUREOM STREAM — P2P Media Backend

A backend for uploading, publishing, streaming and downloading **authorised** video
through a hybrid delivery network: an origin that can always serve complete playback,
plus authorised peers that may contribute verified segments.

Uploads become immutable, versioned HLS assets. Viewers get short-lived playback
sessions. A deadline-aware scheduler fetches each segment from a peer when there is
time to spare and from the origin when there is not, and every byte is verified
against a signed manifest before it is used.

This repository is a **reproducible single-machine implementation** of interfaces
designed for a larger service. It runs with nothing but Python and FFmpeg (SQLite +
local files), and the same code runs on PostgreSQL + Redis + S3-compatible storage.

- [What is implemented, simulated, integrated, deferred](#status-of-each-capability)
- [Quick start](#quick-start)
- [The demonstration](#the-demonstration)
- [Walk-through with the CLI](#walk-through-with-the-cli)
- [Tests](#tests)
- [API at a glance](#api-at-a-glance)
- [Things this system cannot do](#things-this-system-cannot-do)
- Further reading: [architecture](docs/architecture.md) · [API reference](docs/api.md) ·
  [security & privacy](docs/security-and-privacy.md) · [operations](docs/operations.md) ·
  [verified specs, licences, dependencies](docs/verification.md) ·
  [**actual test and demo results**](docs/RESULTS.md)

## Lifecycle

```
upload ─► validate ─► transcode ─► package ─► ready for review ─► publish
                                                                    │
     play ◄─ verify ◄─ fetch segments from peers or origin ◄─ authorise playback
```

Three layers are kept separate in the code:

| Layer | Packages | Owns |
|---|---|---|
| **Media** | `uploads`, `processing`, `packaging`, `manifests`, `catalogue` | originals, renditions, playlists, segments, subtitles, thumbnails |
| **Delivery** | `origin`, `discovery`, `scheduler`, `transports`, `peer_agent`, `offline` | origin downloads, peer discovery, availability, scheduling, retries, verification |
| **Access** | `access` | visibility, viewing / offline / peer-contribution rights, expiring authorisation |

Uploading an original, downloading a segment and contributing bandwidth are three
separate permissions (`media:upload` scope; `view` / `offline_download` grants;
`peer_contribute` grant plus an explicit opt-in on the device).

## Status of each capability

**Implemented** (real code, exercised by tests and by the demonstration):

- Resumable uploads with bounded parts, idempotency keys, duplicate/conflict detection,
  quotas, expiry of abandoned uploads, byte-level container sniffing.
- Processing pipeline `uploaded → validating → transcoding → packaging →
  ready_for_review` (+ `failed`, `cancelled`) on leased database jobs with restart
  recovery; FFmpeg behind a constrained subprocess adapter.
- HLS with fragmented MP4, at least two renditions, aligned segments, no upscaling,
  explicit initialisation vs media segments, SHA-256 per segment after packaging.
- Logical assets vs immutable versions; publication, withdrawal, grants; signed (JWS /
  EdDSA) version manifest sealed at publication.
- Playback sessions, per-session playlists, session- and token-authenticated segments.
- Origin: authenticated delivery, HTTP ranges, content types, public vs private cache
  policy, bounded client retries, health checks.
- Controlled peer registry: peer sessions, bounded availability, scoped discovery,
  short-lived transfer grants (bound to requester, serving peer, version, segments),
  rate / concurrency / byte limits, self-reported receipts, bounded reliability rules.
- Python peer agent: bounded verified cache, announcements, serving with grant
  verification and replay guard, upload cap, pause / metered handling, expiry clean-up.
- Peer transports: `loopback-http` (local testing only) and `mtls-http` (mutual TLS,
  certificate pinning, RFC 8705 certificate-bound grants) behind one interface.
- Streaming-aware scheduler: deadline ordering, reserved urgent slot, bounded prefetch,
  origin hedge before the deadline, duplicate cancellation, seek handling, retry budgets.
- Offline downloads: separate permission, rendition and subtitle selection, pause /
  resume enforced at the origin, resume after interruption, verified completion,
  server and client storage limits, explicit deletion.
- Alembic migrations, OpenAPI documents, CLI, Docker Compose file, metrics.

**Simulated** (clearly labelled wherever it appears):

- *Playback.* `playback/harness.py` requests segments on a playback clock and measures
  startup delay and stalls. It does not decode or render. Reports say
  `"kind": "simulated"`. The only real decode in the demo is FFmpeg decoding the
  offline copy.
- *Faults.* Corruption and frozen heartbeats in the demo are injected through an
  explicit `--enable-fault-injection` switch on the agent.
- *Scale.* Every measurement comes from one machine on the loopback interface with a
  20-second clip. Nothing here is a production-scale performance figure.

**Externally integrated** (interfaces are here; the other system is not):

- *Identity.* The API accepts EdDSA JWTs from keys in a JWKS file
  (`AUREOM_PRINCIPAL_JWKS_PATH`). `aureom-stream token mint` is a development helper,
  not an identity provider.
- *Peer certificates.* `mtls-http` needs a PKI that issues peer certificates.
  `aureom-stream pki dev` creates a throw-away CA for testing only.
- *PostgreSQL, Redis/Valkey, S3-compatible storage, CDN.* Used through standard
  clients. A CDN in front of the origin (and purging it on withdrawal) is not included.

**Deferred** (not built; the contract leaves room):

- Browser-native peer delivery (needs a WebRTC data-channel adapter — see below).
- Content encryption / DRM (`encryption_metadata_reference` is always `NULL`).
- NAT traversal, relays, and any peer discovery beyond the controlled registry.
- Content moderation, copyright verification, billing-grade usage accounting.
- Audio-only renditions, alternate audio tracks, live streaming, low-latency HLS.
- Offline downloads via peers (they use the origin only).

**Not executed in the environment this release was prepared in:** the Docker image and
the Compose stack (there was no Docker daemon). `compose.yaml` passes
`docker compose config`; the same services were exercised natively instead. See
[docs/RESULTS.md](docs/RESULTS.md) for exactly what ran.

## Quick start

Requirements: Python ≥ 3.11, `ffmpeg` and `ffprobe` on `PATH` (built with libx264 and
AAC — distribution packages are).

```bash
python -m venv .venv
```

```bash
.venv/bin/pip install -e ".[dev]"
```

```bash
PYTHON=.venv/bin/python scripts/run_demo.sh
```

The last command starts a backend, an origin, a worker and three peer agents as
separate processes, runs the twelve demonstration steps (about 90 seconds) and writes
`var/demo/demo-report.json`.

## The demonstration

`aureom-stream demo` (or `scripts/run_demo.sh`) creates one public and one private
asset from a generated test clip and shows, with assertions:

| # | Behaviour | How it is shown |
|---|---|---|
| 1 | Resumable upload | Half the parts are sent, completion is refused, a part is retried (idempotent), a conflicting part is rejected, the upload resumes with exactly the missing parts. |
| 2 | Processing and publication | Pipeline states are observed; two aligned renditions; public listing needs explicit confirmation; the private asset stays unlisted. |
| 3 | Authorised playback | Agent A plays the public asset (simulated playback). |
| 4 | Initial origin retrieval | With no peers yet, every segment comes from the origin. |
| 5 | Peer retrieval | Agent B fetches most media segments from agent A; all verify. |
| 6 | Origin fallback after disconnect | Agent A is killed with `SIGKILL` mid-playback; agent C finishes from the origin. |
| 7 | Corrupted segment rejected | Agent B serves flipped bytes; the hash check fails; nothing corrupt is accepted. |
| 8 | Seek-driven priority | A seek cancels out-of-window requests; only segments at the new position load. |
| 9 | Unauthorised private discovery rejected | A peer of the public swarm asks about private segments: `403`; asset and session: `404`. |
| 10 | Offline pause and resume | Download paused (origin answers `409`), resumed, verified, then decoded with FFmpeg. |
| 11 | Contribution-bandwidth enforcement | Agent A is capped; bytes sent stay within the token-bucket allowance. |
| 12 | Clean-up after session expiry | A frozen agent drops out of discovery and purges its cache. |

Results of the runs performed for this release are in
[docs/RESULTS.md](docs/RESULTS.md) and `docs/results/`.

To run the same demonstration on PostgreSQL + Redis + an S3 API without Docker:

```bash
AUREOM_DATABASE_URL=postgresql+asyncpg://user:pass@127.0.0.1:5432/aureom_demo PYTHON=.venv/bin/python scripts/demo_services_native.sh
```

## Walk-through with the CLI

Start the three services (three terminals, or background them). They use SQLite and
`./var` by default; see [.env.example](.env.example).

```bash
aureom-stream serve-api
```

```bash
aureom-stream serve-origin
```

```bash
aureom-stream worker
```

Then, as a client:

```bash
export AUREOM_TOKEN=$(aureom-stream token mint --user alice --scope media:upload --scope media:publish)
```

```bash
aureom-stream upload fixtures/test-pattern-6s.mp4
```

```bash
aureom-stream asset create --upload-id UPLOAD_ID --title "Test pattern" --rights-basis owner --rights-statement "Generated test pattern" --offline all_viewers
```

```bash
aureom-stream asset publish ASSET_ID VERSION_ID
```

```bash
aureom-stream play ASSET_ID --seek 1:4
```

```bash
aureom-stream offline start ASSET_ID --dir ./offline
```

`upload` is resumable: run it again after an interruption and only missing parts are
sent. `asset create` waits for processing and prints the version id. `play` is
simulated playback through the origin. The offline directory contains a plain HLS
copy (`master.m3u8`) that any HLS-capable player can open.

Peer agents:

```bash
aureom-stream peer-agent --control-url http://127.0.0.1:8080 --cache-dir ./var/agent-a --contribute --upload-kbps 2000
```

Without `--tls-*` options an agent listens on loopback only. `--contribute` is the
explicit opt-in; without it an agent fetches but never serves. `aureom-stream --help`
lists every command.

### Docker Compose

```bash
docker compose up --build
```

PostgreSQL 16, Valkey, SeaweedFS (S3), a migration job, API on `127.0.0.1:8080`,
origin on `127.0.0.1:8081` and a constrained worker. Not executed for this release —
see the note above and [docs/operations.md](docs/operations.md).

## Tests

```bash
PYTHON=.venv/bin/python scripts/run_tests.sh
```

117 tests. By default they need only Python and FFmpeg (SQLite, local files, a
virtual clock). Tests that need `redis-server` or FFmpeg skip themselves when the
binary is missing. Set `AUREOM_TEST_DATABASE_URL` to run the same suite on PostgreSQL.

| Area required by the brief | Where |
|---|---|
| Upload retries and part conflicts, storage quotas | `tests/test_uploads.py` |
| Processing failures, restart recovery | `tests/test_pipeline.py` |
| Manifest versioning, access enforcement, private metadata isolation | `tests/test_access_and_publication.py`, `tests/test_peer_registry.py` |
| Transfer-grant expiry, receipts, reliability | `tests/test_peer_registry.py`, `tests/test_peer_integration.py` |
| Segment corruption, peer failure, origin fallback, seek cancellation | `tests/test_scheduler.py`, `tests/test_peer_integration.py` |
| Offline completion, pause/resume, limits | `tests/test_offline.py` |
| Origin ranges, cache policy, token leakage in logs | `tests/test_playback_and_origin.py` |
| S3 adapter, Redis coordination, tokens, cache, limiter | `tests/test_infrastructure.py` |
| Upload → package → publish → origin playback with real FFmpeg | `tests/test_e2e_origin_playback.py` |

Time-dependent behaviour (expiry, deadlines, timeouts, hedging) is tested on an
injected virtual clock; storage, transports and the origin are injected too.

## API at a glance

Full reference: [docs/api.md](docs/api.md); machine-readable:
[docs/openapi.json](docs/openapi.json), [docs/openapi-origin.json](docs/openapi-origin.json).

```
POST   /v1/uploads                                   GET    /v1/uploads/{id}
PUT    /v1/uploads/{id}/parts/{n}                    POST   /v1/uploads/{id}/complete
DELETE /v1/uploads/{id}

POST   /v1/assets                                    GET    /v1/assets/{id}
GET    /v1/assets/{id}/versions                      POST   /v1/assets/{id}/versions
POST   /v1/assets/{id}/versions/{vid}/publish        POST   /v1/assets/{id}/versions/{vid}/withdraw

POST   /v1/playback-sessions                         GET    /v1/playback-sessions/{sid}
POST   /v1/playback-sessions/{sid}/heartbeat         DELETE /v1/playback-sessions/{sid}
GET    /v1/playback-sessions/{sid}/master.m3u8
GET    /v1/playback-sessions/{sid}/renditions/{rid}/index.m3u8
GET    /v1/playback-sessions/{sid}/segments/{segment_id}

POST   /v1/peer-sessions                             POST   /v1/peer-sessions/{pid}/heartbeat
DELETE /v1/peer-sessions/{pid}                       PUT    /v1/peer-sessions/{pid}/availability
POST   /v1/peer-discovery                            POST   /v1/transfer-authorisations
POST   /v1/transfer-receipts

POST   /v1/offline-downloads                         GET    /v1/offline-downloads/{id}
POST   /v1/offline-downloads/{id}/pause              POST   /v1/offline-downloads/{id}/resume
DELETE /v1/offline-downloads/{id}
```

Additions beyond the brief, each needed to make the listed ones usable: asset
listing, grants, subtitles, thumbnail, processing-job status/cancel, the signed
manifest, offline progress, health, metrics and JWKS.

## Things this system cannot do

These are stated in the API responses and documentation as well.

- **Withdrawal cannot erase copies.** Withdrawing a version stops new playback,
  offline and peer authorisations and removes it from the origin, the registry and
  participating agents. Copies recipients already obtained stay where they are.
- **Offline copies are not revocable.** They are unencrypted. Expiring credentials or
  "deleting" a download on the server does not take back a downloaded file.
  Revocable commercial offline licences need a separate content-protection system.
- **Integrity is not legitimacy.** A matching hash proves the bytes are the ones that
  were published. It says nothing about copyright ownership, safety, or whether the
  viewer was authorised.
- **Peers see each other's addresses.** Direct peer delivery reveals network
  addresses to the other peer. Transport encryption does not make participation
  anonymous.
- **`loopback-http` is not secure P2P.** It is plain HTTP for local testing and
  refuses non-loopback addresses. Use `mtls-http` between machines.
- **No browser P2P.** A Python agent cannot make a browser a peer. That needs a
  browser-compatible adapter (WebRTC data channels) behind the same transport
  interface.
- **No availability guarantee.** If both the origin and every peer are unavailable,
  playback fails (`SegmentUnavailable`); nothing pretends otherwise.
- **Receipts are claims.** Transfer receipts are self-reported by peers and are never
  treated as verified usage.

## Repository layout

```
pyproject.toml  compose.yaml  Dockerfile  alembic.ini  .env.example
src/aureom_stream/
  api/           FastAPI app, routers, request/response contracts
  uploads/       resumable uploads, byte sniffing
  catalogue/     assets, versions, publication, withdrawal, grants
  processing/    FFmpeg adapter, pipeline, leased worker
  packaging/     rendition ladder, HLS/fMP4 arguments, output inspection
  manifests/     signed version manifest, playlist rendering
  access/        access decisions, JWT/JWS tokens
  playback/      sessions, ABR adapters, simulated player
  discovery/     peer registry, reliability rules
  scheduler/     deadline-aware segment scheduler
  transports/    PeerTransport interface, loopback and mTLS transports, test doubles
  origin/        origin app, range/cache delivery, client adapter
  peer_agent/    agent, cache, limiter, control client, admin API, dev PKI
  offline/       offline service (server) and downloader (client)
  persistence/   models, database, object stores, coordination
  observability/ metrics, redacting JSON logs
  cli.py  client.py  demo.py  fixtures.py  maintenance.py  bootstrap.py  config.py
migrations/      Alembic environment and the initial schema
scripts/         run_tests.sh, run_demo.sh, demo_services_native.sh
fixtures/        generated test clip and subtitle
tests/           117 tests
docs/            architecture, API, security & privacy, operations, verification, results
```

## Licence

Apache-2.0 for this code. FFmpeg, x264 and codec patent terms are separate — read
[docs/verification.md](docs/verification.md) before distributing H.264/AAC output.
