# Verified specifications, licences and dependencies

Checked on **2026-11-25**. Each item says how it was checked:

- **read** — the primary text was read directly (official repository, vendor
  documentation, package index API);
- **summary** — only a search-engine summary of the official page was available
  (several standards sites were unreachable from the build environment); treat these
  as likely but re-check before relying on them;
- **unconfirmed** — could not be established from a primary source.

Nothing in this file is legal advice.

## 1. HLS

| Point | Finding | How |
|---|---|---|
| Normative spec | RFC 8216 is the published RFC. `draft-pantos-hls-rfc8216bis` ("HTTP Live Streaming 2nd Edition") is still a draft that would obsolete it. | read (Apple-hosted draft) |
| Latest draft | -22, dated 1 May 2026, on the IETF datatracker; whether a later one exists is unconfirmed. Apple hosts a preliminary June 2026 version describing protocol version 13. | summary / read |
| `EXT-X-MAP` | "Each fMP4 Segment in a Media Playlist MUST have an EXT-X-MAP tag applied to it." | read |
| `EXT-X-VERSION` | 6 or higher when `EXT-X-MAP` is used without I-frames-only playlists. FFmpeg's documentation says fMP4 "may be used in HLS version 7 and above". | read |
| `CODECS` | The draft says SHOULD; Apple's authoring specification says it MUST always be provided. | read |
| `EXT-X-INDEPENDENT-SEGMENTS` | Apple: SHOULD be in the multivariant playlist when video segments start with an IDR frame (which Apple requires). | read |
| MIME types | Playlist `application/vnd.apple.mpegurl`; initialisation section and `.mp4`: `video/mp4`; `.m4s`: `video/iso.segment`. | read |
| Durations | Apple: target duration SHOULD be 6 s; key frames SHOULD be every 2 s. | read |

What this release does: `EXT-X-VERSION:7`, `EXT-X-MAP` in every media playlist,
`CODECS` on every variant, `EXT-X-INDEPENDENT-SEGMENTS` in both playlist kinds, the
MIME types above. Segment duration is configurable (default 4 s; the demonstration
uses 2 s to get more segments from a short clip — shorter than Apple's 6 s
recommendation).

Sources: <https://developer.apple.com/streaming/HLS-draft-pantos.pdf> ·
<https://developer.apple.com/documentation/http-live-streaming/hls-authoring-specification-for-apple-devices> ·
<https://datatracker.ietf.org/doc/draft-pantos-hls-rfc8216bis/>

## 2. FFmpeg

| Point | Finding | How |
|---|---|---|
| hls muxer options | `hls_time`, `hls_playlist_type vod`, `hls_segment_type fmp4`, `hls_fmp4_init_filename`, `hls_segment_filename`, `hls_flags independent_segments` are documented. | read |
| Keyframe control | `-force_key_frames expr:gte(t,n_forced*N)` is a documented example; `-progress` is a global option; `-protocol_whitelist` is a documented input option. | read |
| `-sc_threshold` | An encoder-private option of libx264, not a generic option. Valid with libx264, which is what this release uses. | read |
| Current release | 9.0 was released 2026-08-04; a `n9.0.2` tag exists (2026-09-18). A `n9.1` tag exists but an official announcement is unconfirmed. | summary / read |
| Version used here | **6.1.1** (Ubuntu 24.04 package). Every command line in `packaging/hls.py` was executed with it. Not tested with 7.x–9.x. | run |

Sources: <https://github.com/FFmpeg/FFmpeg/blob/master/doc/muxers.texi> ·
<https://github.com/FFmpeg/FFmpeg/blob/master/doc/ffmpeg.texi> ·
<https://github.com/FFmpeg/FFmpeg/blob/master/doc/protocols.texi> ·
<https://github.com/FFmpeg/FFmpeg/blob/master/doc/encoders.texi>

## 3. Media licences and patents

| Point | Finding | How |
|---|---|---|
| FFmpeg licence | LGPL v2.1 or later by default; with `--enable-gpl` "FFmpeg's license changes to GPL v2+". | read |
| x264 | GPL v2 or later. An FFmpeg build with libx264 is therefore GPL. Distribution packages (and the Docker image here) are such builds. | read |
| H.264 / AAC patents | Licensed through Via LA pools (AVC; AAC is a separate programme). Via LA's summary says free internet broadcast AVC video carries no royalty, while other uses are royalty-bearing. | summary |
| Pool status in 2026 | Trade press reports changes to fee tiers and that many, not all, AVC patents have expired. Not confirmed officially. | unconfirmed |
| Royalty-free alternatives | AV1 (AOMedia patent licence) and Opus (royalty-free licences, BSD reference code). VP9 not confirmed from a primary source. | summary / unconfirmed |

Consequences for this code base: it only *invokes* an FFmpeg binary as a separate
process; it does not link to or redistribute FFmpeg or x264 in source form. Whoever
ships a binary (for example by building the Docker image) takes on FFmpeg's and
x264's licence terms, and whoever distributes H.264/AAC video commercially should
check patent licensing. Adding an AV1/Opus ladder is a change confined to
`packaging/hls.py` and `packaging/ladder.py`.

Sources: <https://github.com/FFmpeg/FFmpeg/blob/master/LICENSE.md> ·
<https://www.via-la.com/licensing-programs/avc-h-264/> · <https://opus-codec.org/license/> ·
<https://aomedia.org/>

## 4. Object storage

| Point | Finding | How |
|---|---|---|
| MinIO community edition | The repository README opens with "THIS REPOSITORY IS NO LONGER MAINTAINED"; licence AGPLv3; source-only distribution; last tag `RELEASE.2025-10-15T17-29-55Z`. | read |
| MinIO image | Docker Hub returns 404 for `minio/minio`. | read |
| MinIO archived | Repository archived read-only on 2026-04-25. | summary |
| SeaweedFS | Apache-2.0; image `chrislusf/seaweedfs`, tag 4.55. | read |
| Garage | AGPL-3.0; `dxflrs/garage` v2.6.0. | read |
| RustFS | Apache-2.0; `rustfs/rustfs` 1.0.6. | read |
| Versity Gateway | Apache-2.0; `versity/versitygw` v1.11.0. | read |

Decision: `compose.yaml` uses **SeaweedFS**. The storage code only needs the S3 API
(boto3, path-style addressing, multipart upload), so any of the above should work;
only an S3 API emulator was actually exercised (see [RESULTS.md](RESULTS.md)).

## 5. Python dependencies

Latest stable versions on PyPI on the check date; all were installed and used for the
recorded test runs on Python 3.13.

| Package | Version | Licence | Used for |
|---|---|---|---|
| fastapi | 0.165.0 | MIT | API and origin |
| starlette | 1.10.0 | BSD-3-Clause | (via FastAPI) |
| uvicorn | 0.54.0 | BSD-3-Clause | ASGI server |
| pydantic | 2.14.4 | MIT | contracts |
| pydantic-settings | 2.16.3 | MIT | configuration |
| SQLAlchemy | 2.1.9 | MIT | persistence |
| alembic | 1.20.1 | MIT | migrations |
| asyncpg | 0.32.0 | Apache-2.0 | PostgreSQL driver |
| aiosqlite | 0.22.1 | MIT | SQLite driver |
| httpx | 0.28.1 | BSD-3-Clause | control-plane, origin and peer client |
| aiohttp | 3.14.5 | Apache-2.0 AND MIT | peer and admin servers |
| redis | 8.2.0 | MIT | coordination client |
| boto3 | 1.44.12 | Apache-2.0 | S3 client |
| PyJWT | 2.15.1 | MIT | JWT / JWS |
| cryptography | 50.0.2 | Apache-2.0 OR BSD-3-Clause | Ed25519, X.509 |
| click | 8.5.1 | BSD-3-Clause | CLI |
| prometheus-client | 0.26.0 | Apache-2.0 AND BSD-2-Clause | metrics |
| pytest / pytest-asyncio | 9.2.0 / 1.5.0 | MIT / Apache-2.0 | tests |
| moto | 5.2.6 | Apache-2.0 | S3 API emulator in tests |

Notes: fastapi, pydantic-settings, SQLAlchemy 2.1 and redis 8.2 require Python ≥ 3.11,
which is why `requires-python` is `>=3.11`. httpx's classifiers stop at 3.12 and its
last release is from December 2024; it is pure Python and ran correctly on 3.13.
`pyproject.toml` declares lower bounds, not pins; pin with a lock file for deployments.
The starlette licence was not part of the check (taken from its package metadata).

## 6. Standards relied upon

| Standard | Use here | How |
|---|---|---|
| RFC 7519 JWT, RFC 7515 JWS | tokens, grants, signed manifest | summary |
| RFC 8037 (`EdDSA`, `OKP` in JOSE), RFC 8032 (Ed25519) | signature algorithm | summary |
| RFC 9864 (Oct 2025) | Deprecates the polymorphic `EdDSA` name in favour of fully-specified names such as `Ed25519`. **This release still emits `alg: EdDSA`.** | summary |
| RFC 8705 §3.1 | `cnf` / `x5t#S256` certificate-bound grants | summary (section body not read) |
| RFC 8446 TLS 1.3 | peer transport (via the platform TLS stack; minimum TLS 1.2 configured). Reported as obsoleted by RFC 9846 (July 2026), same protocol version. | summary |
| RFC 9110 §14 Range Requests (§14.2 `Range`) | origin range handling | read |
| RFC 9111 §3.5 | A shared cache must not reuse a response to a request with `Authorization` unless a directive such as `public` allows it — the basis of the public/private cache policies | read |
| RFC 9457 Problem Details | error format (obsoletes RFC 7807) | summary |
| WebVTT | subtitles. A W3C Candidate Recommendation Draft, not a Recommendation. | summary |

## 7. Browser peer-to-peer

| Point | Finding | How |
|---|---|---|
| WebRTC | W3C Recommendation (2021, updated 2025); data channels in RFC 8831. | summary |
| WebTransport | "sent and received between a browser and server" — client–server, not peer-to-peer. | read |
| Inbound connections | No browser API offers a listening socket. This follows from the absence of such an API in those specifications; no single primary sentence states it. | inference |
| aiortc | Python WebRTC library, 1.17.0 (2026-11-25), BSD-3-Clause, Python ≥ 3.11 — a candidate for a WebRTC transport adapter. Not used in this release. | read |

## 8. BitTorrent as an alternative engine

| Point | Finding | How |
|---|---|---|
| BEP 27 (private torrents) | With `private=1` a client "MUST ONLY announce itself to the private tracker, and MUST ONLY initiate connections to peers returned from the private tracker"; DHT, PEX and LSD must not be used. | read |
| libtorrent (arvidn) | 2.1.3, BSD 3-clause; official cp313 wheels for Linux, macOS and Windows. | read |

Not used: its piece selection is built around swarm health rather than playback
deadlines, and its authorisation model is the tracker, not per-transfer grants. It
could sit behind `PeerTransport` in private mode if a deployment wanted it.

## 9. Demonstration media

| Point | Finding | How |
|---|---|---|
| `testsrc2`, `sine` | Documented as generated test pattern and sine-wave sources. The documentation makes no copyright statement; "no third-party rights" is our reading. | read / inference |
| Big Buck Bunny | CC BY 3.0, © 2008 Blender Foundation, attribution required; the isolated score has a different licence. Not shipped. | summary |

## 10. Services

| Point | Finding | How |
|---|---|---|
| PostgreSQL | 19.0 released November 2026; supported majors 15–19; 16 supported until 2028-11-09. Tested here with **16.15**. | summary / run |
| `SKIP LOCKED` | Documented in the `SELECT` reference. | read |
| Redis | From version 8, tri-licensed (RSALv2, SSPLv1 or AGPLv3); 7.2 and earlier are BSD-3. Tested here with **redis-server 7.0.15**. | read / run |
| Valkey | BSD 3-Clause, 9.2.0, image `valkey/valkey`. Used in `compose.yaml`; not run here. | read |
