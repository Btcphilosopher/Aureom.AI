# Architecture

## 1. Processes

```
                        ┌──────────────────────────── control plane ───────────────────────────┐
 uploader / viewer ───► │ API (FastAPI)   uploads · catalogue · playback · peer registry ·     │
                        │                 offline · JWKS · metrics                              │
                        └───────┬───────────────────────┬─────────────────────────┬────────────┘
                                │ PostgreSQL            │ object store            │ Redis / Valkey
                                │ (assets, permissions, │ (originals, packaged    │ (rate limits,
                                │  jobs, sessions)      │  media, subtitles)      │  slots, claims)
                        ┌───────┴────────┐      ┌───────┴────────┐
                        │ worker         │      │ origin         │ ◄── origin token (short-lived JWT)
                        │ FFmpeg adapter │      │ ranges, cache  │
                        └────────────────┘      └───────▲────────┘
                                                        │ fallback / urgent segments
              ┌──────────────┐   transfer grant   ┌─────┴────────┐
              │ peer agent A │ ◄───────────────── │ peer agent B │   each agent: scheduler,
              │ cache, serve │ ──── segment ────► │ verify, play │   verified cache, limiter
              └──────────────┘  (loopback / mTLS) └──────────────┘
```

| Process | Command | Role |
|---|---|---|
| API | `aureom-stream serve-api` | Every `/v1` endpoint; signs manifests, origin tokens and transfer grants. |
| Origin | `aureom-stream serve-origin` | Serves segments and subtitles to holders of a valid origin token. Verifies only. |
| Worker | `aureom-stream worker` | Claims processing jobs, runs FFmpeg, writes packaged media; periodic clean-up. |
| Peer agent | `aureom-stream peer-agent` | Plays (simulated), fetches, caches, optionally serves. One per device. |

The API also serves segments on `/v1/playback-sessions/{id}/segments/{segment}` (the
path in the brief), using the same delivery code as the origin with session
authentication. So a plain HLS player needs only the API; agents and offline clients
use the origin with a token.

## 2. Data model

`persistence/models.py`; migration in `migrations/versions/0001_initial_schema.py`.

| Entity | Purpose | Notes |
|---|---|---|
| `SourceUpload`, `UploadPart` | A resumable upload and its acknowledged parts | `filename` is display-only. Unique `(owner_id, idempotency_key)`. |
| `Asset` | The **logical title** | title, description, language, rights declaration, visibility, distribution policy |
| `AssetVersion` | The **immutable media** of a title | state machine; sealed `manifest_jws` + digest; unique `(asset_id, version_number)` |
| `Rendition` | One encoded ladder rung | size, RFC 6381 codec string, peak/average bandwidth |
| `MediaSegment` | One initialisation or media segment | every field the brief lists, see below |
| `SubtitleTrack` | A WebVTT track of a version | hashed; included in the manifest |
| `ProcessingJob` | One pipeline run for a version | status, stage, progress, attempt, lease, structured error |
| `Publication` | The act of publishing a version | snapshot of visibility, distribution, rights; withdrawal fields |
| `AccessGrant` | A permission for a principal on an asset | `view`, `offline_download`, `peer_contribute`, `manage`; optional expiry; revocable |
| `PlaybackSession` | Short-lived authorisation to stream one version | hashed token, allowed renditions, delivery modes, idle and hard expiry |
| `OfflineDownload` | Authorisation and state of one offline copy | fixed contents, expected digest, client-reported progress |
| `PeerSession` | One agent's membership of one version's swarm | endpoint, transport, certificate thumbprint, contribution flags, expiry |
| `PeerAvailability` | Segments a peer session announced | only ids of the session's own version |
| `TransferGrant` | An issued grant | `jti`, requester, serving peer, segments, byte allowance, expiry |
| `TransferReceipt` | A self-reported transfer outcome | never treated as verified usage |

`MediaSegment` columns: `segment_id`, `asset_version_id`, `rendition_id`, `kind`
(`init` \| `media`), `sequence_number`, `start_time`, `duration`, `byte_length`,
`content_hash` (SHA-256), `storage_reference`, `encryption_metadata_reference`
(always `NULL` in this release).

### Title vs version, and immutability

- A playback session, an offline download, a peer session and a manifest each refer to
  exactly one `AssetVersion`. New media means a new version (`POST
  /v1/assets/{id}/versions`), never a change to an existing one.
- Each packaging attempt writes under its own prefix
  `media/<version>/<job>-<attempt>/…`. Nothing is overwritten, even on retry. Rows for
  renditions and segments are inserted in the same transaction that moves the version
  to `ready_for_review`, so a failed attempt leaves nothing visible and its objects
  are deleted.
- Publishing seals the manifest. After that: the pipeline refuses to process the
  version (`version_immutable`), subtitles can no longer be attached, and the manifest
  is never rewritten.

## 3. Upload

`uploads/service.py`. Parts go through the API; clients never see storage keys or
credentials.

1. `POST /v1/uploads` checks the `media:upload` scope, size limit and quota, and
   returns part size, part count, limits and expiry. The idempotency key makes the
   call repeatable; the same key with different parameters is `409`.
2. `PUT …/parts/{n}` reads at most one part's worth of bytes, requires the exact
   expected size, hashes the part and verifies an optional `X-Content-SHA256`. An
   identical retry returns `duplicate: true`. Different bytes for an acknowledged part
   are `409 part_conflict`. Part 1 must look like an allowed container (MP4/MOV or
   Matroska/WebM by magic bytes) or the part is refused with `415`.
3. `POST …/complete` lists missing parts (`409 incomplete_upload`) or assembles the
   original, checks total size and optional whole-file digest, and deletes the parts.
4. Abandoned uploads expire; the clean-up sweep deletes their parts and frees quota.

## 4. Processing

`processing/` and `packaging/`.

| Stage | What happens |
|---|---|
| `validating` | Original copied to a private work directory under a fixed name; sniffed again; `ffprobe` with the demuxer forced from the sniff; limits on duration, pixels, codec allow-list. |
| `transcoding` | One FFmpeg run per rendition to an intermediate MP4: fixed GOP, `-force_key_frames expr:gte(t,n_forced*SEG)`, `-sc_threshold 0`, constant frame rate. A poster frame is extracted. |
| `packaging` | Remux (`-c copy`) to HLS with fMP4 segments; FFmpeg's playlist is parsed strictly; every file is hashed; alignment across renditions is checked; objects stored; rows inserted. |
| `ready_for_review` | The owner can preview (origin only) and attach subtitles. |

Ladder (`packaging/ladder.py`): the top rung is the source size (rounded to even),
lower rungs come from a reference ladder at the source aspect ratio, nothing is ever
larger than the source, and there are always at least two rungs (a tiny source gets a
second rung at the same size and half the bitrate).

FFmpeg adapter (`processing/ffmpeg.py`): argument arrays only, no shell; fixed input
and output names (the uploaded filename never reaches a command line);
`-protocol_whitelist file` and a forced demuxer so an input cannot pull in other
files or URLs; wall-clock timeout; `setrlimit` for CPU seconds, address space, file
size and open files; minimal environment; bounded work directory; optional empty
network namespace (`AUREOM_FFMPEG_SANDBOX=unshare-net`); progress from
`-progress pipe:1`; errors as `{code, message, stage, retryable, detail}`.

Jobs (`processing/worker.py`): a worker claims a job with a lease. The claim is a
compare-and-swap `UPDATE` (plus `FOR UPDATE SKIP LOCKED` on PostgreSQL), so two
workers never run the same job. If a worker dies, the lease expires and another
worker re-claims the job; each claim is an attempt and a job that keeps failing this
way is failed with `max_attempts_exceeded`. Media errors are not retried;
infrastructure errors are.

## 5. Publication and the signed manifest

`catalogue/service.py`, `manifests/version_manifest.py`.

Publishing requires the `media:publish` scope, management rights on the asset and a
succeeded job. It builds the version manifest — every rendition, its initialisation
segment and media segments with length and SHA-256, plus subtitle tracks — and seals
it as a JWS (EdDSA). Making an asset `public` additionally requires
`confirm_public: true`; otherwise the asset keeps the visibility it inherited from the
upload (`private` by default).

Withdrawal marks the publication withdrawn and revokes active playback sessions,
offline downloads and peer sessions for that version. The origin re-checks
publication, session and download state on every request, so a still-unexpired token
stops working immediately.

## 6. Access decisions

`access/service.py`. Evaluated on every request; tokens only carry a short-lived
result.

| Right | Granted when |
|---|---|
| manage | owner, `manage` grant, or `admin` scope |
| view | manager; or version published and publication `public`/`unlisted`; or unexpired `view` grant |
| offline download | view **and** (policy `all_viewers`, or policy `granted` + `offline_download` grant) |
| fetch from peers | view, authenticated, and policy `peer_delivery` |
| contribute | fetch-from-peers **and** (policy `all_viewers`, or `granted` + `peer_contribute` grant) **and** the device opted in |

Principals who may not view a private object get `404`, not `403`, so its existence
is not revealed. `GET /v1/assets` lists public publications, the caller's own assets
and assets shared with the caller — nothing else.

## 7. Playback sessions

`playback/service.py`. Creating a session authorises the principal for one version,
filters renditions by the client's codecs and maximum height, and returns:

- an opaque session id and a secret token (stored hashed, shown once);
- `delivery_modes`: always `origin`; `peer` only if the policy allows it, the client
  asked for it and the principal is authenticated;
- whether contribution is enabled (requires the explicit request flag);
- a short-lived origin token; heartbeats return a fresh one;
- idle expiry extended by heartbeats up to a hard lifetime.

Playlists are rendered per session and sent with `Cache-Control: private, no-store`.
A player that cannot set headers may pass the token as `?st=`; the playlists then
carry it on their URIs and the logs redact it.

## 8. Peer coordination

`discovery/registry.py`.

- **Membership.** A peer session can only be created with the token of an active
  playback session that has the `peer` mode. So everyone in a version's swarm was
  authorised for that version. Private swarms are never announced anywhere else.
- **Identifiers.** Peer ids are random per session and carry no user identity.
- **Availability.** Bounded messages (`replace` or `delta`). Every id must belong to
  the session's own version, otherwise the whole message is refused.
- **Discovery.** The request may only name segments of the requester's version; any
  other id (private, foreign or unknown — indistinguishable) rejects the request with
  `403`. The answer contains only contributing, live, non-quarantined peers of the
  same version and only the requested ids they hold.
- **Grants.** A JWT (EdDSA) with `sub` = requester, `aud` = serving peer, `ver`,
  `segs`, `max_bytes`, `jti`, short `exp`, and `cnf.x5t#S256` when the requester
  registered a certificate. Issued only for segments the serving peer announced.
  Per-requester rate, concurrency and byte budgets apply.
- **Serving peer checks** (offline, with the control plane's public key): signature,
  issuer, expiry, audience is one of its own sessions, version, segment in the grant,
  certificate binding (mTLS), one use per segment per grant, byte allowance,
  contribution still active, concurrency and upload cap.
- **Receipts.** Either party of a grant may report an outcome for a granted segment,
  once. Matching reports from both sides are marked `corroborated`; that is still two
  self-reports.
- **Reliability** (`discovery/reliability.py`): receiver reports in a 10-minute
  window; at most 5 counted per reporter; `score = (ok + 2) / (ok + bad + 2)` used
  only for ranking; quarantine only when two distinct reporters report integrity
  failures; a reporter is never offered a peer it reported an integrity failure
  against. A `not_found` report removes that one availability claim.

## 9. The scheduler

`scheduler/scheduler.py` — runs on the client side (agent, player).

```
fetch(session, segment, deadline) -> VerifiedSegment
```

1. **Cache.** A cached segment is re-verified and returned.
2. **De-duplication.** Concurrent requests for the same segment share one transfer.
3. **Priority gate.** Requests are classed `init` < `urgent` (deadline within the
   urgent window) < `prefetch` and ordered by deadline within a class. A bounded
   number run at once and one slot is reserved for non-prefetch work. Rarity is not
   an ordering key, so a rare far-future segment cannot starve an imminent one.
4. **Source choice.**
   - Initialisation and urgent segments go to the origin while it is healthy.
   - Other segments try peers first: candidates from one bounded discovery call,
     ranked by estimated completion time (per-peer EWMA latency and throughput)
     divided by trust (registry score × local success ratio); peers in cooldown or
     banned for the session are skipped; a peer is skipped if its estimate would miss
     the deadline.
5. **Origin fallback before the deadline.** `hedge_at = deadline − max(reserve,
   1.5 × origin estimate)`. A peer transfer still running at `hedge_at` is hedged
   with an origin request. Whichever verifies first wins and the other is cancelled.
6. **Failures.** Timeout, refusal, unreachable, not found, wrong length, hash
   mismatch: each is recorded, reported as a receipt, and puts the peer in a growing
   cooldown; an integrity failure bans it for the session. Retries are limited per
   segment and by a per-session token budget.
7. **Seek.** `seek(session, position)` cancels queued and running requests outside
   `[position, position + prefetch window)`.
8. **Result.** Only bytes whose length and SHA-256 match the signed manifest are
   returned. If neither a peer nor the origin delivers, `SegmentUnavailable` is raised.

`plan_window()` gives the bounded set of segments a player should request. The
scheduler reports `DeliveryObservation`s; rendition choice stays in
`playback/adapter.py` (`FixedRendition`, `ThroughputAbr`) or in a real player.

## 10. Peer agent

`peer_agent/agent.py`.

- Verifies the signed manifest with keys from `/.well-known/jwks.json` and pins it to
  the version it was authorised for.
- Cache (`cache.py`): accepts only `VerifiedSegment`; bounded by bytes (LRU) and age;
  purged when the last session for a version closes, expires or is withdrawn.
- Serving: see "Serving peer checks" above. Upload cap is a token bucket
  (`limiter.py`); bytes are counted as they are written, including abandoned transfers.
- Contribution settings: `enabled` (off by default), upload cap, cache cap, metered
  network, pause, background agent. Without the background agent, sessions close when
  the player closes, so nothing keeps seeding. Process exit always deregisters.
- Local admin API (`admin.py`): loopback only, bearer token; used by a local
  application and by the demo to drive an agent.

## 11. Offline downloads

Server (`offline/service.py`): authorises separately from viewing, fixes the contents
(one rendition, its initialisation segment, chosen subtitles), enforces a per-principal
byte allowance, and issues origin tokens that only work while the download is
`active`. Client (`offline/downloader.py`): fetches from the origin, verifies each
item, writes atomically, re-hashes existing files on resume, and reports completion
with a digest over the verified hashes that the server compares with the manifest.

## 12. Module interfaces

| Interface in the brief | Here |
|---|---|
| `MediaPipeline.process(upload_id) -> ProcessingResult` | `processing/pipeline.py` |
| `AccessService.authorise_playback(principal, asset_version_id) -> PlaybackGrant` | `access/service.py` |
| `PeerRegistry.discover(grant, segment_ids) -> list[PeerCandidate]` | `discovery/registry.py` |
| `SegmentScheduler.fetch(session, segment, deadline) -> VerifiedSegment` | `scheduler/scheduler.py` (`session` is `ClientPlaybackSession`) |
| `OriginAdapter.fetch_segment(segment) -> bytes` | `origin/client.py` (`HttpOriginAdapter`) |
| `PeerTransport.fetch_segment(peer, segment, grant, timeout=…) -> bytes` | `transports/base.py`, `transports/http.py` |

Injected for deterministic tests: `Clock` (`clock.py`; `FakeClock` is virtual time),
`ObjectStore`, `Coordination`, `PeerTransport`, `OriginAdapter`, `PeerDirectory`,
`SegmentStore`. Doubles live in `transports/fake.py`.

## 13. Towards a larger service

What would change, and what would not.

| Concern | This release | At scale |
|---|---|---|
| Database | One PostgreSQL (or SQLite) | Read replicas for the origin; session and availability tables partitioned or moved to a store built for churn |
| Availability index | Rows in PostgreSQL | An in-memory index per region; the API contract stays the same |
| Origin | One process reading the object store | CDN in front; origin tokens become CDN-verifiable signed tokens; purge on withdrawal |
| Workers | Leased jobs in PostgreSQL | Same contract on a queue; GPU or chunked transcoding behind `MediaPipeline` |
| Transport | HTTP/1.1 over mTLS | QUIC or WebRTC adapters behind `PeerTransport` |
| Identity | JWTs from a JWKS file | OIDC provider; key rotation |
| Signing keys | One Ed25519 key file | KMS-held keys, rotation via `kid`, origin and agents holding public keys only |
