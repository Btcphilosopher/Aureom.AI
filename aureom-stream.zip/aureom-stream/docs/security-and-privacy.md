# Security, trust and privacy

## 1. What each check proves — and what it does not

| Check | Proves | Does **not** prove |
|---|---|---|
| Segment SHA-256 and length match the signed manifest | The bytes are exactly what the control plane published for this version | That the uploader owned the rights, that the content is safe, or that the viewer was authorised |
| Manifest JWS signature verifies | The manifest was sealed by the holder of the control-plane signing key | Anything about the content itself |
| Playback session / origin token valid | This principal was authorised for this version at issue time, and the session is still active | That the content is intact |
| Transfer grant valid | The registry authorised this requester to receive these segments from this peer, now | That the serving peer will send correct bytes (the hash check does that) |
| Rights declaration present | The uploader made a statement, recorded with who and when | That the statement is true |
| Transfer receipt | A peer claimed something | That it happened |

Content integrity, copyright ownership, safety and viewing authorisation are four
separate questions. This system answers the first and the fourth. The second and
third need people and processes it does not contain.

## 2. Integrity

- Hashes are computed after final packaging and sealed into a manifest signed with
  EdDSA (Ed25519) as a JWS. Clients get the manifest from the control plane, verify
  it with keys from `/.well-known/jwks.json`, and pin it to the version they were
  authorised for.
- A hash offered by a peer is never used. The serving peer sends bytes only.
- `VerifiedSegment` objects are created only by `verify_segment()`. The scheduler
  returns nothing else, the agent cache accepts nothing else, and so a peer can only
  serve what it verified itself.
- Cached and offline files are re-hashed before use, so on-disk damage is caught too.

Handled failure cases, each with a test:

| Case | Behaviour |
|---|---|
| Corrupted segment | Hash mismatch → discarded, counted, receipt `corrupt`, peer banned for the session, next source used |
| Incorrect content length | Announced length ≠ manifest → refused before reading; too many or too few bytes → refused |
| Misreported availability | `404` from the peer → failure, receipt `not_found`, registry forgets that one claim |
| Slow peer | Origin hedge at `deadline − reserve`; the slow request is cancelled when the origin wins |
| Repeated timeouts | Growing cooldown (2 s, 4 s, … 60 s) |
| Expired grant | Serving peer answers `401` |
| Replayed grant | Serving peer answers `403` (one use per segment per grant) |
| Grant for another peer, version or segment | `401` / `403` |
| Malformed request | Strict request models, bounded lists and bodies, opaque-id patterns; `422` |

## 3. Tokens and cryptography

Only standard constructions, through maintained libraries (PyJWT, `cryptography`,
the platform TLS stack). There is no home-made handshake, cipher or signature scheme.

| Token | Form | Lifetime | Bound to |
|---|---|---|---|
| Principal access token | JWT, `typ: at+jwt`, `aud: aureom-api` | set by issuer | subject, scopes |
| Playback / peer / download secret | 256-bit random, stored as SHA-256 | session lifetime | one session |
| Origin token | JWT, `typ: origin+jwt`, `aud: aureom-origin` | 3 min by default | principal, version, session or download |
| Transfer grant | JWT, `typ: transfer+jwt`, `aud:` serving peer | 30 s by default | requester, serving peer, version, segments, bytes, optional certificate |
| Version manifest | JWS, `typ: aureom-manifest+jws` | permanent | one version |

`typ` and `aud` are checked, so one kind of token cannot be used as another. Expiry is
checked against the injected clock.

Notes:

- The JOSE algorithm name used is `EdDSA` (RFC 8037). RFC 9864 introduces the
  fully-specified name `Ed25519` and deprecates the polymorphic one; switching is a
  small change once the JWT library in use supports it. See
  [verification.md](verification.md).
- In this release the origin loads the same key file as the API. It only verifies.
  Giving the origin and agents public keys only is the intended deployment and is
  listed under hardening below.

## 4. Peer transport

| Transport | Use | Properties |
|---|---|---|
| `loopback-http` | Local testing | Plain HTTP. The registry accepts it only for loopback addresses and only when `AUREOM_ALLOW_LOOPBACK_PEER_TRANSPORT` is on; the client refuses non-loopback hosts; an agent without TLS refuses to listen elsewhere. **Not a secure P2P transport.** |
| `mtls-http` | Between machines | HTTPS with mutual TLS. Both sides present certificates from the deployment's peer CA. The client pins the server certificate to the SHA-256 thumbprint the registry holds for that peer session. The grant carries `cnf.x5t#S256` (RFC 8705) and the serving peer refuses a client whose certificate does not match. |

Both are tested, including the mTLS refusals. The PKI that issues peer certificates
is outside this repository; `aureom-stream pki dev` makes a throw-away CA.

### Browsers

A browser cannot accept inbound connections and cannot present a client certificate
chosen by a web page for arbitrary peers, so neither transport above makes a browser
a peer. Browser-to-browser or browser-to-agent delivery needs a browser-compatible
adapter — in practice WebRTC data channels, with the control plane relaying
signalling — implementing the same `PeerTransport` contract and the same grant and
hash checks. **The Python peer agent does not provide browser-native P2P.** A browser
player today uses the origin path only.

## 5. Privacy

- **Peers see each other's addresses.** When two peers transfer directly, each learns
  the other's network address, and the registry gives a requester the address of each
  candidate. Mutual TLS protects the content of the connection. It does not hide who
  is talking to whom, and participation is not anonymous. The API says so when peer
  delivery is enabled (`notices`).
- **What a peer can infer.** A serving peer learns that some authorised peer session
  asked for specific segments of a version it is also authorised for. Peer ids are
  random per session and carry no account identity, but an address can identify a
  person.
- **Contribution is opt-in.** `peer_contribution_enabled` defaults to `false` in the
  API and `--contribute` defaults to off on the agent. The server never turns it on.
  Even with opt-in, contribution needs the asset's policy to allow it.
- **No silent seeding.** A peer session exists only while its playback session is
  active. Without the explicitly enabled background agent, the session closes when
  the player closes. Sessions have an idle expiry and a hard lifetime. A web page
  cannot turn a visitor into a persistent seed: there is no browser peer at all, and
  a native agent needs the user's own flags.
- **Controls on the device:** upload-bandwidth cap, cache-size cap, metered-network
  restriction (a metered network stops contribution unless explicitly allowed),
  pause, background agent on/off.
- **Viewing history.** Playlists are per session, `private, no-store`, and never
  shared-cacheable. Logs record the route template, not the path or query string.
  Bearer tokens, JWTs, `st=` parameters and signed-URL signatures are redacted from
  log output.
- **Private assets.** Not listed, not revealed by status codes (`404`), not
  discoverable through the registry by non-members, and never announced to a public
  DHT or tracker.

## 6. Withdrawal and offline copies

- Withdrawal stops new authorisations and delivery from infrastructure we control:
  sessions and downloads are revoked, peer sessions are removed, the origin refuses
  the version, agents purge it at their next heartbeat. A shared cache may keep
  serving a public segment for up to `AUREOM_PUBLIC_SEGMENT_MAX_AGE_SECONDS` unless
  it is purged. **It cannot erase copies recipients already obtained.**
- Offline copies are plaintext. **Neither ordinary encryption with a key the client
  holds, nor expiring API credentials, can revoke a file that has already been
  downloaded.** `DELETE /v1/offline-downloads/{id}` ends the server record and the
  client removes its files; a modified client could keep them. Commercial offline
  licences with real expiry need a separately implemented content-protection system
  (DRM), which is deferred.
- For those reasons the demonstration uses only generated, freely reusable content.

## 7. Untrusted uploads

- Filename and declared content type are stored for display and never trusted.
- Only MP4/MOV and Matroska/WebM are accepted, by magic bytes, at the first part.
- FFmpeg is given a fixed file name, a forced demuxer and `-protocol_whitelist file`,
  so a playlist or concat script disguised as a video cannot make it read other files
  or fetch URLs (tested).
- FFmpeg runs with time, CPU, memory, file-size and open-file limits, in its own
  process group, with a minimal environment and a bounded work directory; optionally
  without network. The Compose worker adds a read-only root filesystem, a size-limited
  tmpfs, no capabilities, no route to the internet and CPU/memory/pid limits.

## 8. Known gaps and hardening list

| Gap | Suggested step |
|---|---|
| Origin and agents share the private key file in the single-machine setup | Distribute the JWKS only; keep the private key in a KMS |
| No key rotation procedure | Publish several keys by `kid`; sign with the newest |
| Rate limiting is per principal, not per network | Add an edge rate limiter |
| `InMemoryCoordination` is per process | Use Redis/Valkey whenever more than one API process runs |
| FFmpeg sandbox relies on the container for filesystem isolation | gVisor / Firecracker for the worker; seccomp profile |
| No content moderation or rights verification | Review workflow at `ready_for_review`; this is where it belongs |
| Receipts are unverifiable | Do not bill from them; use signed challenge-response if accounting matters |
| Registry sees addresses of all peers | Regional registries. Retention today: a peer's address and certificate thumbprint are erased by the clean-up sweep once its session is over; availability rows are deleted at expiry; receipts and grants after 7 days |
| `EdDSA` algorithm name | Move to `Ed25519` per RFC 9864 when library support allows |
