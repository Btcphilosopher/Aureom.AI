# API reference

Machine-readable: [openapi.json](openapi.json) (control plane) and
[openapi-origin.json](openapi-origin.json) (origin), exported with
`aureom-stream openapi`. A running API also serves `/docs` and `/openapi.json`.

## Conventions

**Authentication**

| Credential | Sent as | Used for |
|---|---|---|
| Principal access token (JWT) | `Authorization: Bearer <jwt>` | Uploads, catalogue, creating sessions and downloads |
| Session secret (opaque) | `Authorization: Bearer <secret>`, or `X-Session-Token`, or `?st=` | Everything under a playback session, peer session or offline download |
| Origin token (JWT) | `Authorization: Bearer <jwt>` to the origin | Segments and subtitles from the origin |
| Transfer grant (JWT) | `Authorization: Bearer <jwt>` to the serving peer | One peer-to-peer transfer |

Scopes on principal tokens: `media:upload`, `media:publish`, `admin`. Viewing needs
no scope; it is decided by publication visibility and grants.

**Identifiers** are opaque: a short prefix and 26 random base32 characters
(`ast_…`, `ver_…`, `upl_…`, `seg_…`, `rnd_…`, `pbs_…`, `prs_…`, `odl_…`, `tgr_…`).

**Errors** are RFC 9457 problem details (`application/problem+json`):

```json
{
  "type": "about:blank",
  "title": "Conflict",
  "status": 409,
  "detail": "upload is incomplete",
  "code": "incomplete_upload",
  "request_id": "req_…",
  "missing_parts": [2, 4]
}
```

`code` is stable and meant for programs. A private object the caller may not see
answers `404 not_found`, never `403`.

## Uploads

| Method and path | Purpose |
|---|---|
| `POST /v1/uploads` | Start a resumable upload |
| `GET /v1/uploads/{upload_id}` | Status, received parts, missing parts |
| `PUT /v1/uploads/{upload_id}/parts/{part_number}` | Upload one part (raw bytes) |
| `POST /v1/uploads/{upload_id}/complete` | Assemble and finish |
| `DELETE /v1/uploads/{upload_id}` | Abort and release storage and quota |

Create:

```json
{
  "filename": "survey-documentary.mp4",
  "content_type": "video/mp4",
  "size_bytes": 125000000,
  "visibility": "private",
  "idempotency_key": "example-upload-001"
}
```

Response (abridged): `upload_id`, `state`, `part_size_bytes`, `part_count`,
`last_part_size_bytes`, `missing_parts`, `expires_at`, `limits` (`max_upload_bytes`,
`max_part_bytes`, `accepted_containers`, `quota_bytes`, `quota_used_bytes`),
`part_url_template`. `201` on creation, `200` when the same idempotency key is
replayed.

Parts: every part except the last is exactly `part_size_bytes`; the last is the
remainder. Optional `X-Content-SHA256` (hex). Optional body for `complete`:
`{"sha256": "<whole-file digest>"}`.

| Code | Status | Meaning |
|---|---|---|
| `upload_not_permitted` | 403 | Token lacks `media:upload` |
| `upload_too_large` | 413 | Over the per-upload limit |
| `quota_exceeded` | 413 | Owner's quota is exhausted |
| `idempotency_conflict` | 409 | Key reused with different parameters |
| `wrong_part_size` | 413 / 422 | Part is not exactly the expected size |
| `invalid_part_number` | 422 | Outside `1..part_count` |
| `digest_mismatch` | 422 | Supplied digest does not match the bytes |
| `part_conflict` | 409 | Different bytes for an already stored part |
| `unsupported_container` | 415 | Bytes are not MP4/MOV or Matroska/WebM |
| `incomplete_upload` | 409 | Parts missing; `missing_parts` lists them |
| `upload_expired`, `upload_aborted` | 410 | The upload can no longer be used |
| `upload_completed`, `upload_in_use` | 409 | Already finished / attached to a version |

## Catalogue and publication

| Method and path | Purpose |
|---|---|
| `POST /v1/assets` | Create a title and its first version from a completed upload; queues processing |
| `GET /v1/assets` | Discoverable assets: public, own, and shared with the caller |
| `GET /v1/assets/{asset_id}` | Metadata and versions the caller may see |
| `GET /v1/assets/{asset_id}/versions` | Versions (viewers: published only; managers: all, with job state) |
| `POST /v1/assets/{asset_id}/versions` | Add a new immutable version from another upload |
| `POST /v1/assets/{asset_id}/versions/{version_id}/publish` | Publish a processed version |
| `POST /v1/assets/{asset_id}/versions/{version_id}/withdraw` | Withdraw a published version |
| `PUT /v1/assets/{asset_id}/versions/{version_id}/subtitles/{language}` | Attach WebVTT before publication |
| `GET /v1/assets/{asset_id}/versions/{version_id}/thumbnail` | Poster frame (JPEG) |
| `POST` / `GET /v1/assets/{asset_id}/grants`, `DELETE …/grants/{grant_id}` | Grant, list, revoke permissions |
| `GET /v1/processing-jobs/{job_id}`, `POST …/cancel` | Job status; cancel |

Create an asset:

```json
{
  "upload_id": "upl_…",
  "title": "Survey documentary",
  "description": "",
  "language": "en",
  "rights_declaration": {
    "basis": "owner",
    "statement": "I produced this film and hold all distribution rights.",
    "licence": null
  },
  "visibility": null,
  "distribution": {
    "peer_delivery": true,
    "offline_download": "granted",
    "peer_contribution": "all_viewers"
  }
}
```

- `rights_declaration.basis`: `owner` \| `licensed` \| `open_licence` \| `public_domain`.
  It is recorded with who declared it and when. It is not verified.
- `visibility` defaults to the upload's visibility (`private` unless stated).
- `distribution.offline_download` and `peer_contribution`: `none` \| `granted` \|
  `all_viewers`.

Publish (body optional):

```json
{ "visibility": "public", "confirm_public": true, "distribution": null }
```

| Code | Status | Meaning |
|---|---|---|
| `publish_not_permitted` | 403 | Token lacks `media:publish` |
| `processing_not_complete` | 409 | Version is not `ready_for_review` with a succeeded job |
| `public_confirmation_required` | 422 | `public` without `confirm_public: true` |
| `already_published` | 409 | |
| `version_immutable` | 409 | Change attempted on a published version |

Withdraw returns the publication with `withdrawn_at` and a `notice` stating that
withdrawal stops new authorisations and controlled delivery but cannot erase copies
already obtained.

Grant: `{"principal_id": "bob", "permission": "view", "ttl_seconds": 86400}` with
`permission` one of `view`, `offline_download`, `peer_contribute`, `manage`.

Version states: `uploaded`, `validating`, `transcoding`, `packaging`,
`ready_for_review`, `published`, `withdrawn`, `failed`, `cancelled`. A failed job
carries `{code, message, stage, retryable, detail}`; codes include `invalid_media`,
`no_video_stream`, `unsupported_container`, `unsupported_codec`, `source_too_long`,
`source_too_large`, `ffmpeg_timeout`, `ffmpeg_failed`, `ffmpeg_killed`,
`work_dir_quota_exceeded`, `segments_not_aligned`, `max_attempts_exceeded`,
`internal_error`.

## Playback sessions

| Method and path | Purpose |
|---|---|
| `POST /v1/playback-sessions` | Authorise playback of one version |
| `GET /v1/playback-sessions/{session_id}` | Status |
| `POST /v1/playback-sessions/{session_id}/heartbeat` | Keep alive; returns a fresh origin token |
| `DELETE /v1/playback-sessions/{session_id}` | End |
| `GET /v1/playback-sessions/{session_id}/master.m3u8` | HLS multivariant playlist |
| `GET /v1/playback-sessions/{session_id}/renditions/{rendition_id}/index.m3u8` | HLS media playlist |
| `GET` \| `HEAD /v1/playback-sessions/{session_id}/segments/{segment_id}` | Segment; `Range` supported |
| `GET /v1/playback-sessions/{session_id}/manifest` | Signed version manifest (JWS) |
| `GET …/subtitles/{track_id}/index.m3u8`, `…/track.vtt` | Subtitle playlist and track |

Create:

```json
{
  "asset_id": "ast_…",
  "version_id": null,
  "client_capabilities": {
    "supported_codecs": ["avc1"],
    "max_height": 1080,
    "peer_delivery": true
  },
  "peer_contribution_enabled": false
}
```

Without `version_id` the newest published version is used. A manager may name a
`ready_for_review` version to preview it (origin only, no signed manifest).

Response (abridged):

```json
{
  "session_id": "pbs_…",
  "session_token": "<shown once>",
  "asset_id": "ast_…",
  "version_id": "ver_…",
  "state": "active",
  "preview": false,
  "expires_at": "2026-11-25T21:40:00Z",
  "heartbeat_interval_seconds": 30.0,
  "delivery_modes": ["origin", "peer"],
  "peer_contribution_enabled": false,
  "renditions": [
    { "rendition_id": "rnd_…", "name": "360p", "width": 640, "height": 360,
      "codecs": "avc1.4d401e,mp4a.40.2", "bandwidth": 949628,
      "playlist_url": "/v1/playback-sessions/pbs_…/renditions/rnd_…/index.m3u8" }
  ],
  "master_playlist_url": "/v1/playback-sessions/pbs_…/master.m3u8",
  "signed_manifest_url": "/v1/playback-sessions/pbs_…/manifest",
  "origin": { "base_url": "http://127.0.0.1:8081", "token": "<jwt>", "expires_at": 1795640000.0 },
  "notices": ["Peer delivery connects you directly to other authorised viewers. …"]
}
```

- Public assets may be played anonymously; anonymous sessions are origin-only.
- `peer` appears only if the publication allows peer delivery, the client asked for
  it and the caller is authenticated.
- `peer_contribution_enabled` is `true` only if the request asked for it and the
  caller holds the contribution right.

| Code | Status | Meaning |
|---|---|---|
| `no_compatible_rendition` | 422 | No rendition matches the client's codecs |
| `too_many_sessions` | 429 | Concurrent session limit for the principal |
| `session_expired`, `session_ended` | 410 | |
| `withdrawn` | 410 | The version was withdrawn |
| `no_published_version` | 422 | Manager asked without `version_id` and nothing is published |

Playlists: `application/vnd.apple.mpegurl`, `Cache-Control: private, no-store`,
`EXT-X-VERSION:7`, `EXT-X-INDEPENDENT-SEGMENTS`, `EXT-X-MAP` for the initialisation
segment, `CODECS` on every variant.

## Origin

`GET` \| `HEAD /origin/v1/segments/{segment_id}` and
`/origin/v1/subtitles/{track_id}` with an origin token; `/healthz`, `/readyz`,
`/metrics`.

- `Range: bytes=a-b`, `a-`, `-n` → `206` with `Content-Range`; unsatisfiable → `416`;
  multiple ranges are ignored (full `200`). `Accept-Ranges: bytes`.
- `ETag: "sha256-<hash>"`; `If-None-Match` → `304`; `If-Range` honoured.
- `Content-Type`: `video/mp4` (initialisation), `video/iso.segment` (media),
  `text/vtt` (subtitles).
- `Cache-Control`: `public, max-age=<n>, immutable` for publicly published assets,
  `private, max-age=<n>, immutable` otherwise; `Vary: Authorization`.
- On every request the origin re-checks that the version is still published and the
  session or download is still active. `download_paused` is `409`.

## Peer coordination

| Method and path | Auth | Purpose |
|---|---|---|
| `POST /v1/peer-sessions` | playback session secret | Register an agent for the session's version |
| `POST /v1/peer-sessions/{id}/heartbeat` | peer secret | Keep alive; update pause / metered / cap |
| `DELETE /v1/peer-sessions/{id}` | peer secret | Leave |
| `PUT /v1/peer-sessions/{id}/availability` | peer secret | Announce or drop segments |
| `POST /v1/peer-discovery` | peer secret | Find peers for segments |
| `POST /v1/transfer-authorisations` | peer secret | Obtain a transfer grant |
| `POST /v1/transfer-receipts` | peer secret | Report an outcome |

Register:

```json
{
  "playback_session_id": "pbs_…",
  "endpoint": { "host": "198.51.100.7", "port": 9443 },
  "transport": "mtls-http",
  "cert_thumbprint": "<sha256 hex of the peer certificate>",
  "contribution": { "enabled": true, "upload_kbps_cap": 2000, "metered": false }
}
```

`transport` is `loopback-http` (loopback addresses only, testing) or `mtls-http`
(thumbprint required). The response gives `peer_session_id`, `peer_token` (once),
`expires_at`, `heartbeat_interval_seconds`, `contribute`, `limits` and a privacy notice.

Availability: `{"mode": "delta", "have": ["seg_…"], "drop": []}` (or `"replace"`).

Discovery: `{"peer_session_id": "prs_…", "segment_ids": ["seg_…", "seg_…"]}` →

```json
{ "peers": [ { "peer_id": "prs_…", "endpoint": {"host": "198.51.100.9", "port": 9443},
               "transport": "mtls-http", "cert_thumbprint": "…",
               "segment_ids": ["seg_…"], "reliability": 1.0 } ] }
```

Transfer authorisation:
`{"peer_session_id": "prs_…", "serving_peer_id": "prs_…", "segment_ids": ["seg_…"]}` →
`{"grant_id": "tgr_…", "token": "<jwt>", "serving_peer_id": "prs_…", "segment_ids": […], "max_bytes": 229876, "expires_at": 1795640030.0}`.

Receipt:

```json
{ "peer_session_id": "prs_…", "grant_id": "tgr_…", "segment_id": "seg_…",
  "role": "receiver", "outcome": "verified", "bytes_transferred": 229876, "duration_ms": 41 }
```

`outcome`: `verified`, `corrupt`, `length_mismatch`, `timeout`, `refused`,
`not_found`, `error`. The response always has `"independently_verified": false`.

| Code | Status | Meaning |
|---|---|---|
| `peer_not_permitted` | 403 | Playback session has no peer mode |
| `insecure_transport` | 422 | `loopback-http` for a non-loopback address |
| `thumbprint_required` | 422 | `mtls-http` without a certificate thumbprint |
| `contribution_not_enabled` | 403 | Announcing without contribution |
| `segment_out_of_scope` | 403 | A segment id outside the session's version |
| `message_too_large`, `availability_limit` | 422 | Bounds exceeded |
| `transfer_not_permitted` | 403 | Serving peer unknown, other scope, not contributing, or did not announce the segment |
| `grant_rate_limited`, `grant_byte_limited`, `grant_concurrency_limited` | 429 | Per-requester limits |
| `wrong_role`, `segment_not_in_grant`, `bytes_exceed_grant` | 422 | Receipt does not fit the grant |
| `peer_session_expired`, `peer_session_closed`, `peer_session_revoked` | 410 | |

### Between peers

`GET /peer/v1/segments/{segment_id}` on the serving agent with the grant as bearer
token. `200` with `Content-Length` and the bytes; `401` (missing, invalid or expired
grant), `403` (scope, replay, byte limit, certificate mismatch, not contributing),
`404` (not cached), `503` (busy; `Retry-After`). The body is always checked by the
receiver against the signed manifest.

## Offline downloads

| Method and path | Purpose |
|---|---|
| `POST /v1/offline-downloads` | Authorise a download (principal token) |
| `GET /v1/offline-downloads/{download_id}` | Status and a fresh origin token while active |
| `POST /v1/offline-downloads/{download_id}/pause` | Pause |
| `POST /v1/offline-downloads/{download_id}/resume` | Resume (rights are re-checked) |
| `DELETE /v1/offline-downloads/{download_id}` | Delete |
| `POST /v1/offline-downloads/{download_id}/progress` | Report progress or completion |
| `GET /v1/offline-downloads/{download_id}/manifest` | Signed version manifest (JWS) |

Create:

```json
{ "asset_id": "ast_…", "version_id": null, "rendition_id": null,
  "max_height": 720, "subtitle_languages": ["en"] }
```

The response fixes the contents: `rendition_id`, `subtitle_languages`, `total_items`
(initialisation segment + media segments + subtitles), `total_bytes`; plus
`download_token` (once), `origin`, `storage` (`quota_bytes`, `used_bytes`) and a
notice that offline copies are unencrypted and cannot be revoked.

Completion: `{"items_completed": N, "bytes_completed": B, "completion_digest": "<sha256>"}`
where the digest is SHA-256 over the concatenated raw hashes of the items in manifest
order (segments, then subtitles by language). The server compares it with the value
derived from the manifest.

States: `active`, `paused`, `completed`, `deleted`, `expired`, `revoked`.

| Code | Status | Meaning |
|---|---|---|
| `offline_not_permitted` | 403 | May view, may not download |
| `offline_storage_limit_exceeded` | 413 | Per-principal allowance |
| `unknown_rendition`, `unknown_subtitle` | 422 | |
| `completion_mismatch` | 409 | Digest or totals do not match the manifest |
| `download_paused` | 409 | From the origin while paused |
| `download_deleted`, `download_expired`, `withdrawn` | 410 | |

## Meta

`GET /healthz` (liveness), `GET /readyz` (database, object store, coordination),
`GET /metrics` (Prometheus text), `GET /.well-known/jwks.json` (public keys for
manifests, origin tokens and grants).
