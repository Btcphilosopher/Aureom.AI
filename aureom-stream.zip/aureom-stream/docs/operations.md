# Operations

## 1. Requirements

| Component | Needed for | Tested with |
|---|---|---|
| Python ≥ 3.11 | everything | 3.13.18 |
| FFmpeg + ffprobe with libx264 and AAC | worker, fixtures | 6.1.1 (Ubuntu build) |
| PostgreSQL | deployments | 16.15 |
| Redis or Valkey | more than one API process | redis-server 7.0.15 |
| S3-compatible object store | deployments | boto3 against an S3 API emulator (moto); see [RESULTS.md](RESULTS.md) |

SQLite, a local directory and in-process coordination replace the last three for a
single machine. That mode is for development and the demonstration.

## 2. Configuration

Every setting is an `AUREOM_`-prefixed environment variable, also read from `.env`.
[`.env.example`](../.env.example) lists the common ones;
[`src/aureom_stream/config.py`](../src/aureom_stream/config.py) is the complete,
validated list with bounds.

| Group | Key settings |
|---|---|
| Persistence | `AUREOM_DATABASE_URL`, `AUREOM_REDIS_URL`, `AUREOM_STORAGE_BACKEND`, `AUREOM_S3_*` |
| Signing | `AUREOM_SIGNING_KEY_PATH`, `AUREOM_ISSUER`, `AUREOM_PRINCIPAL_JWKS_PATH` |
| URLs | `AUREOM_PUBLIC_BASE_URL`, `AUREOM_ORIGIN_BASE_URL` (what clients are told to use) |
| Uploads | part size, maximum size, TTL, quota |
| Processing | segment duration, maximum renditions, FFmpeg time/CPU/memory/threads, work directory and its size cap, sandbox mode, job lease and attempts |
| Playback | session idle TTL, hard lifetime, heartbeat interval, concurrent sessions, origin token TTL, cache max-ages |
| Peers | peer session TTL, grant TTL and limits, availability and discovery bounds, loopback transport switch, quarantine time |
| Offline | per-principal allowance, download TTL |

With `AUREOM_ENV=prod` the signing key must already exist; it is never generated
automatically.

## 3. First start on PostgreSQL

```bash
export AUREOM_DATABASE_URL=postgresql+asyncpg://aureom:CHANGE-ME@db.internal:5432/aureom
```

```bash
aureom-stream keys init
```

```bash
aureom-stream db upgrade
```

```bash
aureom-stream serve-api --host 0.0.0.0 --port 8080
```

```bash
aureom-stream serve-origin --host 0.0.0.0 --port 8081
```

```bash
aureom-stream worker
```

`db upgrade` runs Alembic (`migrations/`, run it from the repository root or set
`AUREOM_MIGRATIONS_DIR`). The initial migration was applied, checked for drift
against the models (`alembic check`), downgraded and re-applied on PostgreSQL 16.
On SQLite the services create the schema themselves.

Put TLS in front of the API and the origin (reverse proxy or load balancer); they
speak plain HTTP.

## 4. Docker Compose

`compose.yaml` defines: `postgres` (16), `valkey`, `s3` (SeaweedFS), `migrate`
(one-shot: signing key + migrations), `api`, `origin`, `worker`, and — with
`--profile peers` — `pki` and three agents on the mutual-TLS transport.

> **Not executed for this release.** The file passes `docker compose config` (with
> and without the `peers` profile), but no image was built and no container was
> started, because the environment had no Docker daemon. Expect to adjust details —
> in particular the SeaweedFS command line and `deploy/seaweedfs-s3.json` were written
> from documentation, not from a run. Image tags were verified to exist on
> 2026-11-25.

Notes:

- Ports are published on `127.0.0.1` only.
- `backend` is an internal network (no route out). The worker is only on it.
- The worker has a read-only root filesystem, a 4 GiB tmpfs work directory, no
  capabilities, `no-new-privileges`, and CPU, memory and pid limits.
- With the `peers` profile set `AUREOM_ORIGIN_BASE_URL=http://origin:8081` so agents
  inside the Compose network can reach the origin by name.
- MinIO is not used: its community image is no longer published
  ([verification.md](verification.md)).

## 5. Worker isolation

Layers, from the inside out:

1. **Arguments.** Arrays only; fixed file names; forced demuxer;
   `-protocol_whitelist file`.
2. **Process.** Own process group; killed as a group on timeout or cancel; minimal
   environment; `RLIMIT_CPU`, `RLIMIT_AS`, `RLIMIT_FSIZE`, `RLIMIT_NOFILE`,
   `RLIMIT_CORE=0`; wall-clock timeout; work directory size watchdog.
3. **Network.** `AUREOM_FFMPEG_SANDBOX=unshare-net` runs FFmpeg in an empty network
   namespace (needs unprivileged user namespaces; tested where available). The worker
   itself needs the database and object store, so it sits on an internal network.
4. **Container.** Read-only root, tmpfs work directory, non-root user, no
   capabilities (Compose file).

Filesystem isolation of FFmpeg from the rest of the worker container comes from
layer 4, not from the adapter.

## 6. Health, metrics, logs

| Endpoint | Meaning |
|---|---|
| `GET /healthz` | Process is up |
| `GET /readyz` | API: database, object store, coordination. Origin: database, object store. `503` if any fails |
| `GET /metrics` | Prometheus text: requests by route template and status, latency, upload bytes, origin bytes by kind, grants, receipts, access denials, discovery time |

The worker has no HTTP endpoint; watch `processing_jobs` (status, stage, attempt,
lease) and its logs.

Logs are JSON lines on stderr. Request logs contain the route template, method,
status, duration and request id — never the query string. A formatter redacts bearer
tokens, JWTs, `st=`/`token=` parameters and signed-URL signatures from every record.

Client-side measurements (startup delay, deadline misses, origin and peer bytes,
verification failures, cache-hit rate, discovery and transfer latency, process CPU
and memory) come from `DeliveryMetrics` in each agent: `GET /admin/v1/stats` on the
agent's admin port, and inside every playback report.

## 7. Clean-up

`aureom-stream maintenance sweep` (the worker also runs it every few seconds):

- expires abandoned uploads and deletes their parts;
- expires idle playback sessions;
- expires peer sessions whose heartbeat stopped or whose playback session ended,
  deletes their availability rows, and erases the address and certificate thumbprint
  of every ended peer session;
- expires offline downloads past their TTL;
- deletes receipts and grants older than 7 days.

Not automated: deleting originals and packaged media of withdrawn or failed versions
(kept for audit and possible reinstatement), and purging a CDN.

## 8. Caching

| Response | Policy |
|---|---|
| Session playlists, signed manifest | `private, no-store` |
| Segments of publicly published versions | `public, max-age=AUREOM_PUBLIC_SEGMENT_MAX_AGE_SECONDS, immutable` |
| Segments of private / unlisted versions, previews | `private, max-age=AUREOM_PRIVATE_SEGMENT_MAX_AGE_SECONDS, immutable` |
| Peer-to-peer transfers | `no-store` |

Segments are immutable, so long lifetimes are safe for correctness. The public
max-age is also how long a shared cache you do not purge can keep serving a
withdrawn version.

## 9. Running agents

```bash
aureom-stream peer-agent --control-url https://api.example --host 0.0.0.0 --port 9443 --advertise-host 198.51.100.7 --cache-dir /var/cache/aureom --cache-bytes 2147483648 --contribute --upload-kbps 4000 --tls-ca ca.pem --tls-cert agent.pem --tls-key agent.key
```

- No `--tls-*`: loopback only (testing).
- `--contribute`: explicit opt-in to serve. `--background-agent`: keep serving after
  the player closes. `--metered`: treat the network as metered (no contribution
  unless `--allow-on-metered`).
- The admin API is on `127.0.0.1` with a bearer token (`AUREOM_AGENT_ADMIN_TOKEN` or
  generated; written to `--ready-file`).
- `--enable-fault-injection` is for tests and the demonstration only.

## 10. Backups and keys

- Back up PostgreSQL and the object store together; segments are referenced by key
  and verified by hash, so a mismatch is detected at read time by clients.
- The signing key signs manifests. Losing it means existing manifests can no longer
  be verified by new clients unless its public key is still published; keep old
  public keys in the JWKS when rotating.
