#!/usr/bin/env bash
# Run the demonstration against real services WITHOUT Docker:
#   PostgreSQL (must already be running), a throw-away redis-server, and a local S3 API.
#
# The S3 API here is `moto` (an S3 emulator from the dev dependencies). It stands in
# for the S3-compatible store used by compose.yaml (SeaweedFS). It exercises the same
# boto3 code path, but it is an emulator - not a storage system.
#
# Usage:
#   AUREOM_DATABASE_URL=postgresql+asyncpg://user:pass@127.0.0.1:5432/db \
#     scripts/demo_services_native.sh [report.json]
set -euo pipefail
cd "$(dirname "$0")/.."

: "${AUREOM_DATABASE_URL:?set AUREOM_DATABASE_URL to a PostgreSQL URL (postgresql+asyncpg://...)}"
PYTHON="${PYTHON:-python}"
REPORT="${1:-var/demo-services/demo-report.json}"
WORK="${WORK_DIR:-var/demo-services}"
mkdir -p "$WORK"

free_port() { "$PYTHON" -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1])'; }
REDIS_PORT="$(free_port)"
S3_PORT="$(free_port)"

redis-server --port "$REDIS_PORT" --bind 127.0.0.1 --save "" --appendonly no >"$WORK/redis.log" 2>&1 &
REDIS_PID=$!
"$PYTHON" -m moto.server -H 127.0.0.1 -p "$S3_PORT" >"$WORK/s3.log" 2>&1 &
S3_PID=$!
trap 'kill "$REDIS_PID" "$S3_PID" 2>/dev/null || true' EXIT
sleep 2

export AUREOM_REDIS_URL="redis://127.0.0.1:${REDIS_PORT}/0"
export AUREOM_STORAGE_BACKEND=s3
export AUREOM_S3_ENDPOINT_URL="http://127.0.0.1:${S3_PORT}"
export AUREOM_S3_BUCKET="aureom-demo"
export AUREOM_S3_ACCESS_KEY_ID="demo-access-key"
export AUREOM_S3_SECRET_ACCESS_KEY="demo-secret-key"
export AUREOM_MIGRATIONS_DIR="$PWD/migrations"

"$PYTHON" -m aureom_stream.demo --work-dir "$WORK" --stack services --report "$REPORT"
