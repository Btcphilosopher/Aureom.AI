#!/usr/bin/env bash
# Run the test-suite. With AUREOM_TEST_DATABASE_URL set, the same suite runs against
# PostgreSQL (the schema is dropped and recreated per test - use a scratch database).
#
#   scripts/run_tests.sh                     # SQLite, local files, in-process coordination
#   AUREOM_TEST_DATABASE_URL=postgresql+asyncpg://user:pass@127.0.0.1:5432/aureom_test \
#     scripts/run_tests.sh
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-python}"
"$PYTHON" -m ruff check src tests migrations scripts
"$PYTHON" -m mypy src
"$PYTHON" -m pytest tests "$@"
