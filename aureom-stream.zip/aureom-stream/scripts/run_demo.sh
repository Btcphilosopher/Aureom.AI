#!/usr/bin/env bash
# End-to-end demonstration on one machine with no external services:
# SQLite + local object files + in-process coordination, one backend, one origin,
# one worker and three peer-agent processes. Needs Python >= 3.11 and FFmpeg.
#
#   scripts/run_demo.sh [report.json]
set -euo pipefail
cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-python}"
REPORT="${1:-var/demo/demo-report.json}"
"$PYTHON" -m aureom_stream.demo --work-dir "${WORK_DIR:-var/demo}" --stack local --report "$REPORT"
