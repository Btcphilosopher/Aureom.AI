"""HLS playlist rendering (RFC 8216 / draft-pantos-hls-rfc8216bis).

Playlists are generated per playback session from the database - FFmpeg's own
playlists are only parsed during packaging. Media playlists use fragmented MP4
(``EXT-X-MAP``), declare ``EXT-X-VERSION:7`` and ``EXT-X-INDEPENDENT-SEGMENTS``, and
every variant carries ``CODECS``.
"""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import dataclass

from ..persistence.models import MediaSegment, Rendition, SegmentKind, SubtitleTrack

PLAYLIST_CONTENT_TYPE = "application/vnd.apple.mpegurl"
INIT_CONTENT_TYPE = "video/mp4"
SEGMENT_CONTENT_TYPE = "video/iso.segment"
WEBVTT_CONTENT_TYPE = "text/vtt; charset=utf-8"


def _quote(value: str) -> str:
    if any(ch in value for ch in '"\r\n'):
        raise ValueError("illegal character in quoted attribute")
    return f'"{value}"'


def render_master(
    renditions: list[Rendition],
    subtitles: list[SubtitleTrack],
    *,
    rendition_uri: Callable[[Rendition], str],
    subtitle_uri: Callable[[SubtitleTrack], str],
) -> str:
    lines = ["#EXTM3U", "#EXT-X-VERSION:7", "#EXT-X-INDEPENDENT-SEGMENTS"]
    group = ""
    if subtitles:
        group = ',SUBTITLES="subs"'
        for index, track in enumerate(sorted(subtitles, key=lambda s: s.language)):
            lines.append(
                '#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",'
                f"NAME={_quote(track.label)},LANGUAGE={_quote(track.language)},"
                f"DEFAULT={'YES' if index == 0 else 'NO'},AUTOSELECT=YES,FORCED=NO,"
                f"URI={_quote(subtitle_uri(track))}"
            )
    for rendition in sorted(renditions, key=lambda r: -r.bandwidth):
        lines.append(
            f"#EXT-X-STREAM-INF:BANDWIDTH={rendition.bandwidth},"
            f"AVERAGE-BANDWIDTH={rendition.average_bandwidth},"
            f"CODECS={_quote(rendition.codecs)},"
            f"RESOLUTION={rendition.width}x{rendition.height},"
            f"FRAME-RATE={rendition.frame_rate:.3f}{group}"
        )
        lines.append(rendition_uri(rendition))
    return "\n".join(lines) + "\n"


def render_media(segments: list[MediaSegment], *, segment_uri: Callable[[MediaSegment], str]) -> str:
    inits = [s for s in segments if s.kind == SegmentKind.INIT.value]
    media = sorted(
        (s for s in segments if s.kind == SegmentKind.MEDIA.value), key=lambda s: s.sequence_number
    )
    if len(inits) != 1 or not media:
        raise ValueError("a media playlist needs exactly one init segment and media segments")
    target = max(1, math.ceil(max(s.duration for s in media) - 1e-6))
    lines = [
        "#EXTM3U",
        "#EXT-X-VERSION:7",
        f"#EXT-X-TARGETDURATION:{target}",
        f"#EXT-X-MEDIA-SEQUENCE:{media[0].sequence_number}",
        "#EXT-X-PLAYLIST-TYPE:VOD",
        "#EXT-X-INDEPENDENT-SEGMENTS",
        f"#EXT-X-MAP:URI={_quote(segment_uri(inits[0]))}",
    ]
    for seg in media:
        lines.append(f"#EXTINF:{seg.duration:.6f},")
        lines.append(segment_uri(seg))
    lines.append("#EXT-X-ENDLIST")
    return "\n".join(lines) + "\n"


def render_subtitle_playlist(duration: float, *, vtt_uri: str) -> str:
    return (
        "#EXTM3U\n#EXT-X-VERSION:7\n"
        f"#EXT-X-TARGETDURATION:{max(1, math.ceil(duration))}\n"
        "#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-PLAYLIST-TYPE:VOD\n"
        f"#EXTINF:{duration:.6f},\n{vtt_uri}\n#EXT-X-ENDLIST\n"
    )


@dataclass(frozen=True)
class ParsedPlaylist:
    init_uri: str
    segments: list[tuple[str, float]]  # (uri, duration)
    target_duration: int


def parse_media_playlist(text: str) -> ParsedPlaylist:
    """Minimal strict parser for the VOD fMP4 playlists our own packaging step emits."""
    init_uri: str | None = None
    target = 0
    pending: float | None = None
    segments: list[tuple[str, float]] = []
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines or lines[0] != "#EXTM3U":
        raise ValueError("not an M3U8 playlist")
    for line in lines[1:]:
        if line.startswith("#EXT-X-MAP:"):
            attr = line.split(":", 1)[1]
            if not attr.startswith('URI="') or '"' not in attr[5:]:
                raise ValueError("unsupported EXT-X-MAP")
            init_uri = attr[5:].split('"', 1)[0]
        elif line.startswith("#EXT-X-TARGETDURATION:"):
            target = int(line.split(":", 1)[1])
        elif line.startswith("#EXTINF:"):
            pending = float(line.split(":", 1)[1].split(",", 1)[0])
        elif line.startswith("#EXT-X-KEY") or line.startswith("#EXT-X-BYTERANGE"):
            raise ValueError(f"unexpected tag in packaged playlist: {line.split(':', 1)[0]}")
        elif not line.startswith("#"):
            if pending is None:
                raise ValueError("segment URI without EXTINF")
            segments.append((line, pending))
            pending = None
    if init_uri is None or not segments:
        raise ValueError("playlist has no EXT-X-MAP or no segments")
    return ParsedPlaylist(init_uri=init_uri, segments=segments, target_duration=target)
