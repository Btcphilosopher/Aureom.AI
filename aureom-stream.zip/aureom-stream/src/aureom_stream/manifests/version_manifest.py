"""The authenticated, versioned manifest of one immutable asset version.

The manifest lists every initialisation and media segment with its length and SHA-256.
It is sealed as a JWS (EdDSA) when the version is published and never changes
afterwards. Clients verify the signature with the control plane's public key and then
verify every segment against it - a hash supplied by the peer that also supplied the
bytes would prove nothing.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

from ..access.tokens import TYP_MANIFEST, TokenError, TokenService, TokenVerifier
from ..domain import SegmentDescriptor
from ..persistence.models import (
    Asset,
    AssetVersion,
    MediaSegment,
    Rendition,
    SegmentKind,
    SubtitleTrack,
)

MANIFEST_SCHEMA = 1


class ManifestSegment(BaseModel):
    model_config = ConfigDict(extra="forbid")
    segment_id: str
    kind: Literal["init", "media"]
    sequence_number: int
    start_time: float
    duration: float
    byte_length: int
    sha256: str


class ManifestRendition(BaseModel):
    model_config = ConfigDict(extra="forbid")
    rendition_id: str
    name: str
    width: int
    height: int
    codecs: str
    bandwidth: int
    average_bandwidth: int
    frame_rate: float
    init: ManifestSegment
    segments: list[ManifestSegment]


class ManifestSubtitle(BaseModel):
    model_config = ConfigDict(extra="forbid")
    track_id: str
    language: str
    label: str
    format: str
    byte_length: int
    sha256: str


class VersionManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schema_version: int
    asset_id: str
    asset_version_id: str
    version_number: int
    duration_seconds: float
    segment_duration_seconds: float
    hash_algorithm: Literal["sha256"]
    encryption: None = None  # no content encryption in release 1
    sealed_at: float
    renditions: list[ManifestRendition]
    subtitles: list[ManifestSubtitle]

    # ------------------------------------------------------------------ lookups
    def rendition(self, rendition_id: str) -> ManifestRendition:
        for rendition in self.renditions:
            if rendition.rendition_id == rendition_id:
                return rendition
        raise KeyError(rendition_id)

    def _descriptor(self, rendition_id: str, seg: ManifestSegment) -> SegmentDescriptor:
        return SegmentDescriptor(
            segment_id=seg.segment_id,
            asset_version_id=self.asset_version_id,
            rendition_id=rendition_id,
            kind=seg.kind,
            sequence_number=seg.sequence_number,
            start_time=seg.start_time,
            duration=seg.duration,
            byte_length=seg.byte_length,
            content_hash=seg.sha256,
        )

    def init_segment(self, rendition_id: str) -> SegmentDescriptor:
        return self._descriptor(rendition_id, self.rendition(rendition_id).init)

    def media_segments(self, rendition_id: str) -> list[SegmentDescriptor]:
        return [self._descriptor(rendition_id, s) for s in self.rendition(rendition_id).segments]

    def find(self, segment_id: str) -> SegmentDescriptor | None:
        for rendition in self.renditions:
            for seg in (rendition.init, *rendition.segments):
                if seg.segment_id == segment_id:
                    return self._descriptor(rendition.rendition_id, seg)
        return None

    def offline_items(
        self, rendition_id: str, subtitle_languages: list[str]
    ) -> tuple[list[SegmentDescriptor], list[ManifestSubtitle]]:
        subs = [s for s in self.subtitles if s.language in subtitle_languages]
        return [self.init_segment(rendition_id), *self.media_segments(rendition_id)], subs

    def offline_digest(self, rendition_id: str, subtitle_languages: list[str]) -> str:
        """Digest over the ordered hashes of everything an offline copy must contain."""
        segments, subs = self.offline_items(rendition_id, sorted(subtitle_languages))
        digest = hashlib.sha256()
        for seg in segments:
            digest.update(bytes.fromhex(seg.content_hash))
        for sub in sorted(subs, key=lambda s: s.language):
            digest.update(bytes.fromhex(sub.sha256))
        return digest.hexdigest()


def _segment(seg: MediaSegment) -> dict[str, Any]:
    return {
        "segment_id": seg.id,
        "kind": seg.kind,
        "sequence_number": seg.sequence_number,
        "start_time": round(seg.start_time, 6),
        "duration": round(seg.duration, 6),
        "byte_length": seg.byte_length,
        "sha256": seg.content_hash,
    }


def build_manifest_document(
    asset: Asset,
    version: AssetVersion,
    renditions: list[Rendition],
    segments: list[MediaSegment],
    subtitles: list[SubtitleTrack],
    *,
    segment_duration: float,
    sealed_at: float,
) -> dict[str, Any]:
    by_rendition: dict[str, list[MediaSegment]] = {}
    for seg in segments:
        by_rendition.setdefault(seg.rendition_id, []).append(seg)
    out_renditions = []
    for rendition in sorted(renditions, key=lambda r: (-r.bandwidth, r.id)):
        segs = sorted(by_rendition.get(rendition.id, []), key=lambda s: s.sequence_number)
        inits = [s for s in segs if s.kind == SegmentKind.INIT.value]
        media = [s for s in segs if s.kind == SegmentKind.MEDIA.value]
        if len(inits) != 1 or not media:
            raise ValueError(f"rendition {rendition.id} lacks an init or media segments")
        out_renditions.append(
            {
                "rendition_id": rendition.id,
                "name": rendition.name,
                "width": rendition.width,
                "height": rendition.height,
                "codecs": rendition.codecs,
                "bandwidth": rendition.bandwidth,
                "average_bandwidth": rendition.average_bandwidth,
                "frame_rate": rendition.frame_rate,
                "init": _segment(inits[0]),
                "segments": [_segment(s) for s in media],
            }
        )
    return {
        "schema_version": MANIFEST_SCHEMA,
        "asset_id": asset.id,
        "asset_version_id": version.id,
        "version_number": version.version_number,
        "duration_seconds": round(version.duration_seconds or 0.0, 6),
        "segment_duration_seconds": segment_duration,
        "hash_algorithm": "sha256",
        "encryption": None,
        "sealed_at": sealed_at,
        "renditions": out_renditions,
        "subtitles": [
            {
                "track_id": s.id,
                "language": s.language,
                "label": s.label,
                "format": s.format,
                "byte_length": s.byte_length,
                "sha256": s.content_hash,
            }
            for s in sorted(subtitles, key=lambda s: s.language)
        ],
    }


def seal_manifest(tokens: TokenService, document: dict[str, Any]) -> tuple[str, str]:
    """Returns ``(jws, sha256 of the canonical payload)``."""
    VersionManifest.model_validate(document)  # refuse to sign a malformed manifest
    payload = json.dumps(document, separators=(",", ":"), sort_keys=True).encode()
    return tokens.sign_jws(payload, typ=TYP_MANIFEST), hashlib.sha256(payload).hexdigest()


class ManifestError(Exception):
    pass


def verify_manifest(verifier: TokenVerifier, jws: str, *, expected_version_id: str) -> VersionManifest:
    """Authenticate a manifest and pin it to the version the caller was authorised for."""
    try:
        payload = verifier.verify_jws(jws, typ=TYP_MANIFEST)
    except TokenError as exc:
        raise ManifestError(f"manifest signature rejected: {exc.reason}") from exc
    try:
        manifest = VersionManifest.model_validate_json(payload)
    except ValueError as exc:
        raise ManifestError("manifest payload is malformed") from exc
    if manifest.schema_version != MANIFEST_SCHEMA:
        raise ManifestError(f"unsupported manifest schema {manifest.schema_version}")
    if manifest.asset_version_id != expected_version_id:
        raise ManifestError("manifest belongs to a different asset version")
    return manifest
