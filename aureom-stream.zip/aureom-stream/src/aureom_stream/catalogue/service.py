"""Catalogue: logical titles, immutable versions, publication and withdrawal."""

from __future__ import annotations

import re
from dataclasses import dataclass

from sqlalchemy import ColumnElement, delete, func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from ..access.service import SCOPE_PUBLISH, SCOPE_UPLOAD, AccessService
from ..bootstrap import AppContext
from ..clock import to_datetime
from ..domain import DistributionPolicy, Principal, RightsDeclaration
from ..errors import Conflict, Forbidden, NotFound, PayloadTooLarge, ValidationFailed
from ..ids import new_id, sha256_hex
from ..manifests.version_manifest import build_manifest_document, seal_manifest
from ..persistence.models import (
    AccessGrant,
    Asset,
    AssetVersion,
    DownloadState,
    JobStatus,
    MediaSegment,
    OfflineDownload,
    PeerAvailability,
    PeerSession,
    PeerState,
    Permission,
    PlaybackSession,
    ProcessingJob,
    Publication,
    Rendition,
    SessionState,
    SourceUpload,
    SubtitleTrack,
    UploadState,
    VersionState,
    Visibility,
)
from ..uploads.sniff import looks_like_webvtt

WITHDRAWAL_NOTICE = (
    "Withdrawal stops new playback, offline and peer authorisations and removes the "
    "version from delivery by infrastructure we control (origin, registry, participating "
    "peer agents). It cannot erase copies that recipients already obtained."
)
MAX_SUBTITLE_BYTES = 2 * 1024 * 1024
_LANG_RE = re.compile(r"^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8}){0,3}$")


@dataclass(frozen=True)
class NewAsset:
    upload_id: str
    title: str
    description: str
    language: str
    rights_declaration: RightsDeclaration
    visibility: str | None
    distribution: DistributionPolicy


class CatalogueService:
    def __init__(self, ctx: AppContext, session: AsyncSession) -> None:
        self._ctx = ctx
        self._db = session
        self.access = AccessService(session, ctx.clock, grant_ttl=ctx.settings.origin_token_ttl_seconds)

    def _now(self):  # noqa: ANN202
        return to_datetime(self._ctx.clock.now())

    # ------------------------------------------------------------------ loading
    async def load_asset(self, principal: Principal, asset_id: str, *, manage: bool = False) -> Asset:
        asset = await self._db.get(Asset, asset_id)
        if asset is None:
            raise NotFound("asset not found")
        if manage:
            if not await self.access.can_manage(principal, asset):
                # Viewers learn they lack the right; strangers learn nothing.
                if await self.access.can_view_asset(principal, asset):
                    raise Forbidden("managing this asset is not permitted")
                raise NotFound("asset not found")
        elif not await self.access.can_view_asset(principal, asset):
            raise NotFound("asset not found")
        return asset

    async def _load_version(self, asset: Asset, version_id: str) -> AssetVersion:
        version = await self._db.get(AssetVersion, version_id)
        if version is None or version.asset_id != asset.id:
            raise NotFound("asset version not found")
        return version

    async def _claim_upload(self, principal: Principal, upload_id: str) -> SourceUpload:
        upload = await self._db.get(SourceUpload, upload_id)
        if upload is None or upload.owner_id != principal.id:
            raise NotFound("upload not found")
        if upload.state != UploadState.COMPLETED.value:
            raise Conflict("upload is not completed", code="upload_not_completed")
        used = await self._db.scalar(
            select(AssetVersion.id).where(AssetVersion.source_upload_id == upload_id)
        )
        if used is not None:
            raise Conflict("upload is already attached to an asset version", code="upload_in_use")
        return upload

    async def _new_version(
        self, asset: Asset, upload: SourceUpload, number: int
    ) -> tuple[AssetVersion, ProcessingJob]:
        now = self._now()
        version = AssetVersion(
            id=new_id("ver"),
            asset_id=asset.id,
            version_number=number,
            source_upload_id=upload.id,
            state=VersionState.UPLOADED.value,
            created_at=now,
        )
        self._db.add(version)
        await self._db.flush()
        job = ProcessingJob(
            id=new_id("job"),
            asset_version_id=version.id,
            upload_id=upload.id,
            status=JobStatus.QUEUED.value,
            stage=VersionState.UPLOADED.value,
            progress=0.0,
            attempt=0,
            max_attempts=self._ctx.settings.job_max_attempts,
            cancel_requested=False,
            created_at=now,
            updated_at=now,
        )
        self._db.add(job)
        await self._db.flush()
        return version, job

    # ------------------------------------------------------------------ assets & versions
    async def create_asset(
        self, principal: Principal, req: NewAsset
    ) -> tuple[Asset, AssetVersion, ProcessingJob]:
        if principal.anonymous or not principal.has_scope(SCOPE_UPLOAD):
            raise Forbidden("the media:upload permission is required", code="upload_not_permitted")
        upload = await self._claim_upload(principal, req.upload_id)
        # The asset is never more visible than the upload unless the caller says so
        # explicitly - and even then nothing is public before an explicit publish.
        visibility = Visibility(req.visibility or upload.visibility).value
        now = self._now()
        asset = Asset(
            id=new_id("ast"),
            owner_id=principal.id,
            title=req.title,
            description=req.description,
            language=req.language,
            rights_declaration={
                **req.rights_declaration.model_dump(),
                "declared_by": principal.id,
                "declared_at": now.isoformat(),
            },
            visibility=visibility,
            distribution=req.distribution.model_dump(),
            created_at=now,
            updated_at=now,
        )
        self._db.add(asset)
        await self._db.flush()
        version, job = await self._new_version(asset, upload, 1)
        return asset, version, job

    async def add_version(
        self, principal: Principal, asset_id: str, upload_id: str
    ) -> tuple[AssetVersion, ProcessingJob]:
        asset = await self.load_asset(principal, asset_id, manage=True)
        if not principal.has_scope(SCOPE_UPLOAD):
            raise Forbidden("the media:upload permission is required", code="upload_not_permitted")
        upload = await self._claim_upload(principal, upload_id)
        latest = await self._db.scalar(
            select(func.max(AssetVersion.version_number)).where(AssetVersion.asset_id == asset.id)
        )
        return await self._new_version(asset, upload, int(latest or 0) + 1)

    async def list_versions(
        self, principal: Principal, asset_id: str
    ) -> tuple[Asset, list[AssetVersion], bool]:
        asset = await self.load_asset(principal, asset_id)
        manager = await self.access.can_manage(principal, asset)
        rows = list(
            await self._db.scalars(
                select(AssetVersion)
                .where(AssetVersion.asset_id == asset.id)
                .order_by(AssetVersion.version_number)
            )
        )
        if not manager:  # viewers only ever see what is currently published
            rows = [v for v in rows if v.state == VersionState.PUBLISHED.value]
        return asset, rows, manager

    async def list_assets(self, principal: Principal, *, limit: int = 50) -> list[Asset]:
        """Discoverable assets: publicly published ones, plus the caller's own and the
        ones explicitly shared with the caller. Private and unlisted assets of other
        people never appear."""
        public_ids = select(Publication.asset_id).where(
            Publication.withdrawn_at.is_(None), Publication.visibility == Visibility.PUBLIC.value
        )
        conditions: list[ColumnElement[bool]] = [Asset.id.in_(public_ids)]
        if not principal.anonymous:
            now = self._now()
            granted = select(AccessGrant.asset_id).where(
                AccessGrant.principal_id == principal.id,
                AccessGrant.revoked_at.is_(None),
                (AccessGrant.expires_at.is_(None)) | (AccessGrant.expires_at > now),
            )
            published = select(Publication.asset_id).where(Publication.withdrawn_at.is_(None))
            conditions.append(Asset.owner_id == principal.id)
            conditions.append(Asset.id.in_(granted) & Asset.id.in_(published))
        rows = await self._db.scalars(
            select(Asset).where(or_(*conditions)).order_by(Asset.created_at.desc()).limit(limit)
        )
        return list(rows)

    async def renditions(self, version_id: str) -> list[Rendition]:
        rows = await self._db.scalars(select(Rendition).where(Rendition.asset_version_id == version_id))
        return sorted(rows, key=lambda r: -r.bandwidth)

    async def subtitles(self, version_id: str) -> list[SubtitleTrack]:
        rows = await self._db.scalars(
            select(SubtitleTrack).where(SubtitleTrack.asset_version_id == version_id)
        )
        return sorted(rows, key=lambda s: s.language)

    # ------------------------------------------------------------------ jobs
    async def get_job(self, principal: Principal, job_id: str) -> ProcessingJob:
        job = await self._db.get(ProcessingJob, job_id)
        if job is None:
            raise NotFound("job not found")
        version = await self._db.get(AssetVersion, job.asset_version_id)
        assert version is not None
        await self.load_asset(principal, version.asset_id, manage=True)
        return job

    async def cancel_job(self, principal: Principal, job_id: str) -> ProcessingJob:
        job = await self.get_job(principal, job_id)
        if job.status == JobStatus.QUEUED.value:
            version = await self._db.get(AssetVersion, job.asset_version_id)
            assert version is not None
            job.status = JobStatus.CANCELLED.value
            job.finished_at = self._now()
            version.state = VersionState.CANCELLED.value
        elif job.status == JobStatus.RUNNING.value:
            job.cancel_requested = True  # the worker stops FFmpeg at its next check
        else:
            raise Conflict(f"job is already {job.status}", code="job_finished")
        job.updated_at = self._now()
        return job

    # ------------------------------------------------------------------ subtitles
    async def add_subtitle(
        self,
        principal: Principal,
        asset_id: str,
        version_id: str,
        language: str,
        label: str | None,
        data: bytes,
    ) -> SubtitleTrack:
        asset = await self.load_asset(principal, asset_id, manage=True)
        version = await self._load_version(asset, version_id)
        if version.state != VersionState.READY_FOR_REVIEW.value:
            raise Conflict(
                "subtitles can only be attached while a version is ready for review; "
                "a published version is immutable",
                code="version_immutable",
            )
        if not _LANG_RE.match(language):
            raise ValidationFailed("language must be a BCP 47 tag", code="invalid_language")
        if len(data) > MAX_SUBTITLE_BYTES:
            raise PayloadTooLarge("subtitle file is too large")
        if not looks_like_webvtt(data):
            raise ValidationFailed("subtitle bytes are not WebVTT", code="invalid_subtitle")
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValidationFailed("WebVTT must be UTF-8", code="invalid_subtitle") from exc
        await self._db.execute(
            delete(SubtitleTrack).where(
                SubtitleTrack.asset_version_id == version.id, SubtitleTrack.language == language
            )
        )
        track_id = new_id("sub")
        key = f"media/{version.id}/subtitles/{track_id}.vtt"
        await self._ctx.store.put(key, data, content_type="text/vtt")
        track = SubtitleTrack(
            id=track_id,
            asset_version_id=version.id,
            language=language,
            label=(label or language)[:100],
            format="webvtt",
            byte_length=len(data),
            content_hash=sha256_hex(data),
            storage_reference=key,
            created_at=self._now(),
        )
        self._db.add(track)
        await self._db.flush()
        return track

    # ------------------------------------------------------------------ publication
    async def publish(
        self,
        principal: Principal,
        asset_id: str,
        version_id: str,
        *,
        visibility: str | None,
        confirm_public: bool,
        distribution: DistributionPolicy | None,
    ) -> Publication:
        asset = await self.load_asset(principal, asset_id, manage=True)
        if not principal.has_scope(SCOPE_PUBLISH):
            raise Forbidden("the media:publish permission is required", code="publish_not_permitted")
        version = await self._load_version(asset, version_id)
        job = await self._db.scalar(select(ProcessingJob).where(ProcessingJob.asset_version_id == version.id))
        if version.state == VersionState.PUBLISHED.value:
            raise Conflict("version is already published", code="already_published")
        if (
            version.state != VersionState.READY_FOR_REVIEW.value
            or job is None
            or job.status != JobStatus.SUCCEEDED.value
        ):
            raise Conflict(
                f"publishing requires a completed processing job (version is {version.state})",
                code="processing_not_complete",
            )
        target = Visibility(visibility or asset.visibility).value
        if target == Visibility.PUBLIC.value and not confirm_public:
            raise ValidationFailed(
                "making an asset publicly discoverable requires confirm_public=true",
                code="public_confirmation_required",
            )
        policy = distribution or DistributionPolicy.model_validate(asset.distribution)
        renditions = await self.renditions(version.id)
        segments = list(
            await self._db.scalars(select(MediaSegment).where(MediaSegment.asset_version_id == version.id))
        )
        subtitles = await self.subtitles(version.id)
        now = self._ctx.clock.now()
        document = build_manifest_document(
            asset, version, renditions, segments, subtitles,
            segment_duration=self._ctx.settings.segment_duration_seconds, sealed_at=now,
        )  # fmt: skip
        version.manifest_jws, version.manifest_digest = seal_manifest(self._ctx.tokens, document)
        version.state = VersionState.PUBLISHED.value
        version.published_at = to_datetime(now)
        asset.visibility = target
        asset.distribution = policy.model_dump()
        asset.updated_at = to_datetime(now)
        publication = Publication(
            id=new_id("pub"),
            asset_id=asset.id,
            asset_version_id=version.id,
            visibility=target,
            distribution=policy.model_dump(),
            rights_declaration=asset.rights_declaration,
            published_by=principal.id,
            published_at=to_datetime(now),
        )
        self._db.add(publication)
        await self._db.flush()
        return publication

    async def withdraw(
        self, principal: Principal, asset_id: str, version_id: str, reason: str | None
    ) -> Publication:
        asset = await self.load_asset(principal, asset_id, manage=True)
        if not principal.has_scope(SCOPE_PUBLISH):
            raise Forbidden("the media:publish permission is required", code="publish_not_permitted")
        version = await self._load_version(asset, version_id)
        publication = await self._db.scalar(
            select(Publication).where(Publication.asset_version_id == version.id)
        )
        if publication is None:
            raise Conflict("version was never published", code="not_published")
        if publication.withdrawn_at is not None:
            return publication  # idempotent
        now = self._now()
        publication.withdrawn_at = now
        publication.withdrawn_by = principal.id
        publication.withdrawal_reason = (reason or "")[:500] or None
        version.state = VersionState.WITHDRAWN.value
        version.withdrawn_at = now
        # Stop everything we control: sessions, downloads, registry entries.
        await self._db.execute(
            update(PlaybackSession)
            .where(
                PlaybackSession.asset_version_id == version.id,
                PlaybackSession.state == SessionState.ACTIVE.value,
            )
            .values(state=SessionState.REVOKED.value, ended_at=now)
        )
        await self._db.execute(
            update(OfflineDownload)
            .where(
                OfflineDownload.asset_version_id == version.id,
                OfflineDownload.state.in_([DownloadState.ACTIVE.value, DownloadState.PAUSED.value]),
            )
            .values(state=DownloadState.REVOKED.value, updated_at=now)
        )
        peer_ids = list(
            await self._db.scalars(
                select(PeerSession.id).where(
                    PeerSession.asset_version_id == version.id,
                    PeerSession.state == PeerState.ACTIVE.value,
                )
            )
        )
        if peer_ids:
            await self._db.execute(
                update(PeerSession)
                .where(PeerSession.id.in_(peer_ids))
                .values(state=PeerState.REVOKED.value, closed_at=now)
            )
            await self._db.execute(
                delete(PeerAvailability).where(PeerAvailability.peer_session_id.in_(peer_ids))
            )
        return publication

    # ------------------------------------------------------------------ grants
    async def grant(
        self,
        principal: Principal,
        asset_id: str,
        *,
        grantee: str,
        permission: Permission,
        ttl_seconds: float | None,
    ) -> AccessGrant:
        asset = await self.load_asset(principal, asset_id, manage=True)
        now = self._ctx.clock.now()
        grant = AccessGrant(
            id=new_id("grt"),
            asset_id=asset.id,
            principal_id=grantee,
            permission=permission.value,
            granted_by=principal.id,
            created_at=to_datetime(now),
            expires_at=to_datetime(now + ttl_seconds) if ttl_seconds else None,
        )
        self._db.add(grant)
        await self._db.flush()
        return grant

    async def list_grants(self, principal: Principal, asset_id: str) -> list[AccessGrant]:
        asset = await self.load_asset(principal, asset_id, manage=True)
        rows = await self._db.scalars(
            select(AccessGrant)
            .where(AccessGrant.asset_id == asset.id, AccessGrant.revoked_at.is_(None))
            .order_by(AccessGrant.created_at)
        )
        return list(rows)

    async def revoke_grant(self, principal: Principal, asset_id: str, grant_id: str) -> None:
        asset = await self.load_asset(principal, asset_id, manage=True)
        grant = await self._db.get(AccessGrant, grant_id)
        if grant is None or grant.asset_id != asset.id:
            raise NotFound("grant not found")
        grant.revoked_at = grant.revoked_at or self._now()
