"""Validated runtime configuration.

Every knob is an ``AUREOM_``-prefixed environment variable (see ``.env.example``).
Secrets are held as ``SecretStr`` so they do not appear in ``repr`` or logs.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

MIB = 1024 * 1024
GIB = 1024 * MIB


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AUREOM_", env_file=".env", extra="ignore")

    env: Literal["dev", "test", "prod"] = "dev"
    log_level: str = "INFO"

    # --- persistence -------------------------------------------------------
    database_url: str = "sqlite+aiosqlite:///./var/aureom.db"
    redis_url: str | None = None  # None -> in-process coordination (single process only)

    storage_backend: Literal["local", "s3"] = "local"
    storage_local_root: Path = Path("./var/objects")
    s3_endpoint_url: str | None = None
    s3_bucket: str = "aureom-media"
    s3_region: str = "us-east-1"
    s3_access_key_id: SecretStr | None = None
    s3_secret_access_key: SecretStr | None = None

    # --- signing -----------------------------------------------------------
    # Ed25519 private key (PKCS#8 PEM). In dev a key is generated at this path if missing.
    signing_key_path: Path = Path("./var/keys/signing-ed25519.pem")
    issuer: str = "aureom-stream"
    # Optional JWKS file with additional *public* keys trusted for principal tokens
    # (an external identity provider). Local dev mints tokens with the signing key.
    principal_jwks_path: Path | None = None

    public_base_url: str = "http://127.0.0.1:8080"
    origin_base_url: str = "http://127.0.0.1:8081"

    # --- uploads -----------------------------------------------------------
    upload_part_size_bytes: int = Field(default=8 * MIB, ge=64 * 1024, le=64 * MIB)
    upload_max_bytes: int = Field(default=5 * GIB, ge=1)
    upload_ttl_seconds: int = Field(default=24 * 3600, ge=60)
    upload_quota_bytes: int = Field(default=20 * GIB, ge=1)

    # --- processing --------------------------------------------------------
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    work_dir: Path = Path("./var/work")
    work_dir_max_bytes: int = Field(default=8 * GIB, ge=MIB)
    segment_duration_seconds: float = Field(default=4.0, ge=1.0, le=10.0)
    max_renditions: int = Field(default=4, ge=2, le=6)
    ffmpeg_timeout_seconds: float = Field(default=1800.0, gt=0)
    ffmpeg_cpu_seconds: int = Field(default=3600, gt=0)
    ffmpeg_memory_bytes: int = Field(default=4 * GIB, ge=256 * MIB)
    ffmpeg_threads: int = Field(default=2, ge=1, le=64)
    # "unshare-net" runs FFmpeg in an empty network namespace (Linux, needs userns).
    ffmpeg_sandbox: Literal["none", "unshare-net"] = "none"
    max_source_duration_seconds: float = Field(default=4 * 3600.0, gt=0)
    max_source_pixels: int = Field(default=4096 * 2304, gt=0)
    job_lease_seconds: float = Field(default=60.0, gt=1)
    job_max_attempts: int = Field(default=3, ge=1)
    worker_poll_seconds: float = Field(default=0.5, gt=0)

    # --- playback ----------------------------------------------------------
    playback_session_ttl_seconds: float = Field(default=120.0, gt=1)  # idle TTL
    playback_session_max_lifetime_seconds: float = Field(default=6 * 3600.0, gt=1)
    playback_heartbeat_seconds: float = Field(default=30.0, gt=0)
    max_sessions_per_principal: int = Field(default=8, ge=1)
    origin_token_ttl_seconds: float = Field(default=180.0, gt=1)
    public_segment_max_age_seconds: int = Field(default=3600, ge=0)
    private_segment_max_age_seconds: int = Field(default=600, ge=0)

    # --- peers -------------------------------------------------------------
    peer_session_ttl_seconds: float = Field(default=45.0, gt=1)
    transfer_grant_ttl_seconds: float = Field(default=30.0, gt=1)
    transfer_grant_max_segments: int = Field(default=16, ge=1, le=64)
    transfer_grants_per_minute: int = Field(default=240, ge=1)
    transfer_grant_max_concurrent: int = Field(default=8, ge=1)
    transfer_grant_bytes_per_minute: int = Field(default=512 * MIB, ge=1)
    availability_max_ids_per_message: int = Field(default=512, ge=1, le=4096)
    availability_max_per_peer: int = Field(default=4096, ge=1)
    discovery_max_segments: int = Field(default=64, ge=1, le=512)
    discovery_max_candidates: int = Field(default=8, ge=1, le=64)
    # Plain-HTTP peer endpoints are accepted only on loopback addresses and only
    # when this is enabled. It is a development aid, not a secure transport.
    allow_loopback_peer_transport: bool = True
    peer_quarantine_seconds: float = Field(default=600.0, gt=0)

    # --- offline -----------------------------------------------------------
    offline_quota_bytes: int = Field(default=10 * GIB, ge=1)
    offline_download_ttl_seconds: float = Field(default=30 * 24 * 3600.0, gt=1)

    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
