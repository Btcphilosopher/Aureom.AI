"""Origin delivery: authenticated, range-aware, cache-policy-aware segment responses.

Used by the standalone origin application (token-authenticated, for peer agents,
offline clients and players that fetch directly) and by the playback-session segment
route of the API (session-authenticated).

Range handling follows RFC 9110 section 14: a single satisfiable ``bytes`` range gets
``206`` with ``Content-Range``; an unsatisfiable one gets ``416``; multiple ranges are
ignored (full ``200`` response), which the RFC permits.
"""

from __future__ import annotations

import re
from collections.abc import Mapping

from sqlalchemy.ext.asyncio import AsyncSession
from starlette.responses import Response, StreamingResponse

from ..bootstrap import AppContext
from ..errors import Conflict, Forbidden, Gone, NotFound
from ..manifests.playlists import INIT_CONTENT_TYPE, SEGMENT_CONTENT_TYPE, WEBVTT_CONTENT_TYPE
from ..persistence.models import (
    AssetVersion,
    DownloadState,
    MediaSegment,
    OfflineDownload,
    PlaybackSession,
    Publication,
    SegmentKind,
    SessionState,
    SubtitleTrack,
    VersionState,
    Visibility,
)

_RANGE_RE = re.compile(r"^bytes=(\d*)-(\d*)$")
UNSATISFIABLE = "unsatisfiable"


def parse_range(header: str | None, size: int) -> tuple[int, int] | None | str:
    """Returns ``(start, end_inclusive)``, ``None`` (serve everything) or UNSATISFIABLE."""
    if not header:
        return None
    header = header.strip()
    if "," in header:
        return None  # multiple ranges: ignore the header
    match = _RANGE_RE.match(header)
    if not match:
        return None  # unknown unit or malformed: ignore, per RFC 9110 14.2
    first, last = match.groups()
    if first == "" and last == "":
        return None
    if first == "":  # suffix range: last N bytes
        length = int(last)
        if length == 0:
            return UNSATISFIABLE
        return (max(0, size - length), size - 1) if size > 0 else UNSATISFIABLE
    start = int(first)
    if start >= size:
        return UNSATISFIABLE
    end = min(int(last), size - 1) if last else size - 1
    if end < start:
        return None
    return start, end


def cache_control_for(ctx: AppContext, visibility: str, *, preview: bool = False) -> str:
    """Separate public and private caching policies.

    * public assets  - shared caches may store segments for a bounded time; that bound
      is also the longest a CDN we do not purge keeps serving after a withdrawal;
    * private / unlisted / preview - only the requesting client may cache.
    Session playlists are always ``no-store`` (see the playback routes).
    """
    s = ctx.settings
    if visibility == Visibility.PUBLIC.value and not preview:
        return f"public, max-age={s.public_segment_max_age_seconds}, immutable"
    return f"private, max-age={s.private_segment_max_age_seconds}, immutable"


class OriginDelivery:
    def __init__(self, ctx: AppContext) -> None:
        self._ctx = ctx

    async def object_response(
        self,
        *,
        key: str,
        size: int,
        sha256: str,
        content_type: str,
        cache_control: str,
        method: str,
        headers: Mapping[str, str],
        metric_kind: str,
    ) -> Response:
        etag = f'"sha256-{sha256}"'
        base = {
            "ETag": etag,
            "Accept-Ranges": "bytes",
            "Cache-Control": cache_control,
            "Vary": "Authorization",
            "X-Content-Type-Options": "nosniff",
        }
        if_none_match = headers.get("if-none-match")
        if if_none_match and etag in [t.strip() for t in if_none_match.split(",")]:
            return Response(status_code=304, headers=base)
        range_header = headers.get("range")
        if_range = headers.get("if-range")
        if if_range and if_range.strip() != etag:
            range_header = None  # representation changed from the client's view: send all
        parsed = parse_range(range_header, size)
        if parsed == UNSATISFIABLE:
            return Response(status_code=416, headers={**base, "Content-Range": f"bytes */{size}"})
        if isinstance(parsed, tuple):
            start, end = parsed
            status = 206
            base["Content-Range"] = f"bytes {start}-{end}/{size}"
        else:
            start, end, status = 0, size - 1, 200
        length = end - start + 1
        base["Content-Length"] = str(length)
        if method == "HEAD":
            return Response(status_code=status, headers=base, media_type=content_type)
        self._ctx.metrics.origin_bytes.labels(kind=metric_kind).inc(length)
        if length <= 4 * 1024 * 1024:
            data = (
                await self._ctx.store.get(key)
                if status == 200
                else await self._ctx.store.get_range(key, start, end)
            )
            return Response(content=data, status_code=status, headers=base, media_type=content_type)
        return StreamingResponse(
            self._ctx.store.iter_chunks(key, start, end),
            status_code=status,
            headers=base,
            media_type=content_type,
        )

    # ------------------------------------------------------------------ authorisation
    async def check_scope(
        self, db: AsyncSession, claims: Mapping[str, object]
    ) -> tuple[AssetVersion, str, bool]:
        """Validate an origin token's claims against *current* state, so withdrawal,
        session expiry and download pause take effect immediately rather than when the
        token expires. Returns ``(version, visibility, preview)``."""
        version = await db.get(AssetVersion, str(claims.get("ver", "")))
        if version is None:
            raise NotFound("not found")
        preview = bool(claims.get("pv"))
        now = self._ctx.clock.now()
        if sid := claims.get("sid"):
            session = await db.get(PlaybackSession, str(sid))
            if (
                session is None
                or session.state != SessionState.ACTIVE.value
                or session.expires_at.timestamp() <= now
            ):
                raise Forbidden("playback session is no longer active", code="session_inactive")
        elif dl := claims.get("dl"):
            download = await db.get(OfflineDownload, str(dl))
            if download is None:
                raise Forbidden("download is not active", code="download_inactive")
            if download.state == DownloadState.PAUSED.value:
                raise Conflict("download is paused", code="download_paused")
            if download.state != DownloadState.ACTIVE.value:
                raise Forbidden("download is not active", code="download_inactive")
        else:
            raise Forbidden("token has no delivery context", code="invalid_token")
        if preview:
            if version.state != VersionState.READY_FOR_REVIEW.value:
                raise Forbidden("preview is no longer available", code="not_available")
            return version, Visibility.PRIVATE.value, True
        if version.state == VersionState.WITHDRAWN.value:
            raise Gone("this version has been withdrawn", code="withdrawn")
        from sqlalchemy import select

        publication = await db.scalar(select(Publication).where(Publication.asset_version_id == version.id))
        if (
            version.state != VersionState.PUBLISHED.value
            or publication is None
            or publication.withdrawn_at is not None
        ):
            raise Forbidden("version is not available", code="not_available")
        return version, publication.visibility, False

    async def segment_response(
        self,
        db: AsyncSession,
        segment_id: str,
        *,
        version_id: str,
        visibility: str,
        preview: bool,
        method: str,
        headers: Mapping[str, str],
        allowed_renditions: list[str] | None = None,
    ) -> Response:
        segment = await db.get(MediaSegment, segment_id)
        if segment is None or segment.asset_version_id != version_id:
            raise NotFound("segment not found")  # also hides segments of other versions
        if allowed_renditions is not None and segment.rendition_id not in allowed_renditions:
            raise NotFound("segment not found")
        return await self.object_response(
            key=segment.storage_reference,
            size=segment.byte_length,
            sha256=segment.content_hash,
            content_type=(
                INIT_CONTENT_TYPE if segment.kind == SegmentKind.INIT.value else SEGMENT_CONTENT_TYPE
            ),
            cache_control=cache_control_for(self._ctx, visibility, preview=preview),
            method=method,
            headers=headers,
            metric_kind=segment.kind,
        )

    async def subtitle_response(
        self,
        db: AsyncSession,
        track_id: str,
        *,
        version_id: str,
        visibility: str,
        preview: bool,
        method: str,
        headers: Mapping[str, str],
    ) -> Response:
        track = await db.get(SubtitleTrack, track_id)
        if track is None or track.asset_version_id != version_id:
            raise NotFound("subtitle track not found")
        return await self.object_response(
            key=track.storage_reference,
            size=track.byte_length,
            sha256=track.content_hash,
            content_type=WEBVTT_CONTENT_TYPE,
            cache_control=cache_control_for(self._ctx, visibility, preview=preview),
            method=method,
            headers=headers,
            metric_kind="subtitle",
        )
