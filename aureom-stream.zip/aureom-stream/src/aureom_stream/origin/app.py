"""The origin application: authenticated delivery of packaged media.

It only *verifies* short-lived origin tokens (a public-key operation) and re-checks
session / download / publication state on every request. The origin alone can serve
complete playback - peers are an optimisation, never a requirement. If the origin is
down as well, playback fails; nothing here pretends otherwise.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, Response

from .. import __version__
from ..access.tokens import AUD_ORIGIN, TYP_ORIGIN, TokenError
from ..api.app import install_common
from ..api.deps import Ctx, Db
from ..bootstrap import AppContext, build_context
from ..config import Settings, get_settings
from ..errors import Unauthenticated
from .delivery import OriginDelivery


def _claims(request: Request, ctx: AppContext) -> dict[str, object]:
    header = request.headers.get("authorization", "")
    scheme, _, token = header.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise Unauthenticated("an origin token is required")
    try:
        return ctx.tokens.verify(token.strip(), typ=TYP_ORIGIN, audience=AUD_ORIGIN)
    except TokenError as exc:
        raise Unauthenticated(f"origin token rejected ({exc.reason})", code="invalid_token") from exc


def create_origin_app(settings: Settings | None = None, ctx: AppContext | None = None) -> FastAPI:
    settings = settings or (ctx.settings if ctx else get_settings())
    owns_ctx = ctx is None
    context = ctx or build_context(settings)

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        yield
        if owns_ctx:
            await context.close()

    app = FastAPI(
        title="AUREOM STREAM Origin",
        version=__version__,
        description="Authenticated segment delivery with HTTP range support.",
        lifespan=lifespan,
    )
    install_common(app, context)

    @app.get("/healthz", tags=["meta"])
    async def healthz() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/readyz", tags=["meta"])
    async def readyz(ctx: Ctx) -> JSONResponse:
        checks = {"database": await ctx.db.ping(), "object_store": await ctx.store.healthcheck()}
        ready = all(checks.values())
        return JSONResponse({"ready": ready, "checks": checks}, status_code=200 if ready else 503)

    @app.get("/metrics", include_in_schema=False)
    async def metrics(ctx: Ctx) -> Response:
        return Response(ctx.metrics.render(), media_type="text/plain; version=0.0.4")

    @app.head("/origin/v1/segments/{segment_id}", include_in_schema=False)
    @app.get(
        "/origin/v1/segments/{segment_id}", tags=["origin"],
        summary="Initialisation or media segment (GET/HEAD, Bearer origin token, Range supported)",
    )  # fmt: skip
    async def segment(segment_id: str, request: Request, ctx: Ctx, db: Db) -> Response:
        delivery = OriginDelivery(ctx)
        version, visibility, preview = await delivery.check_scope(db, _claims(request, ctx))
        return await delivery.segment_response(
            db, segment_id, version_id=version.id, visibility=visibility, preview=preview,
            method=request.method, headers=request.headers,
        )  # fmt: skip

    @app.head("/origin/v1/subtitles/{track_id}", include_in_schema=False)
    @app.get("/origin/v1/subtitles/{track_id}", tags=["origin"], summary="WebVTT subtitle track")
    async def subtitle(track_id: str, request: Request, ctx: Ctx, db: Db) -> Response:
        delivery = OriginDelivery(ctx)
        version, visibility, preview = await delivery.check_scope(db, _claims(request, ctx))
        return await delivery.subtitle_response(
            db, track_id, version_id=version.id, visibility=visibility, preview=preview,
            method=request.method, headers=request.headers,
        )  # fmt: skip

    return app
