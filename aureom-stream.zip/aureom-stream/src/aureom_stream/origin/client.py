"""Client side of origin delivery: the :class:`OriginAdapter` used by the scheduler.

The HTTP adapter adds bounded retries with backoff, a per-request timeout and a small
circuit breaker so that an unhealthy origin is reported instead of hammered. It never
claims availability it does not have: when retries are exhausted it raises.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Literal, Protocol

import httpx

from ..clock import Clock
from ..domain import SegmentDescriptor


class OriginError(Exception):
    def __init__(
        self,
        kind: Literal["unavailable", "denied", "not_found", "paused"],
        detail: str,
        status: int | None = None,
    ) -> None:
        super().__init__(detail)
        self.kind = kind
        self.status = status


class OriginAdapter(Protocol):
    async def fetch_segment(self, segment: SegmentDescriptor) -> bytes: ...

    @property
    def healthy(self) -> bool: ...


class HttpOriginAdapter:
    def __init__(
        self,
        *,
        base_url: str,
        token_provider: Callable[[], str],
        clock: Clock,
        client: httpx.AsyncClient | None = None,
        max_attempts: int = 3,
        backoff_seconds: float = 0.15,
        request_timeout: float = 10.0,
        failure_threshold: int = 3,
        cooldown_seconds: float = 5.0,
    ) -> None:
        self._base = base_url.rstrip("/")
        self._token = token_provider
        self._clock = clock
        self._client = client or httpx.AsyncClient(timeout=request_timeout)
        self._owns_client = client is None
        self._max_attempts = max_attempts
        self._backoff = backoff_seconds
        self._timeout = request_timeout
        self._threshold = failure_threshold
        self._cooldown = cooldown_seconds
        self._consecutive_failures = 0
        self._open_until = 0.0

    @property
    def healthy(self) -> bool:
        return self._clock.now() >= self._open_until

    def _record(self, ok: bool) -> None:
        if ok:
            self._consecutive_failures = 0
            self._open_until = 0.0
            return
        self._consecutive_failures += 1
        if self._consecutive_failures >= self._threshold:
            self._open_until = self._clock.now() + self._cooldown

    async def _get(self, path: str, *, expected_length: int | None) -> bytes:
        last: OriginError | None = None
        for attempt in range(self._max_attempts):
            if attempt:
                await self._clock.sleep(self._backoff * (2 ** (attempt - 1)))
            try:
                response = await self._client.get(
                    self._base + path,
                    headers={"Authorization": f"Bearer {self._token()}"},
                    timeout=self._timeout,
                )
            except httpx.HTTPError as exc:
                self._record(False)
                last = OriginError("unavailable", f"origin unreachable: {type(exc).__name__}")
                continue
            if response.status_code == 200:
                self._record(True)
                if expected_length is not None and len(response.content) != expected_length:
                    last = OriginError("unavailable", "origin returned a truncated body", 200)
                    continue
                return response.content
            if response.status_code in (401, 403, 410):
                self._record(True)  # the origin is up; the request is not allowed
                raise OriginError("denied", f"origin refused: {response.status_code}", response.status_code)
            if response.status_code == 409:
                self._record(True)
                raise OriginError("paused", "download is paused", 409)
            if response.status_code == 404:
                self._record(True)
                raise OriginError("not_found", "segment not found at origin", 404)
            self._record(False)
            last = OriginError("unavailable", f"origin error {response.status_code}", response.status_code)
        assert last is not None
        raise last

    async def fetch_segment(self, segment: SegmentDescriptor) -> bytes:
        return await self._get(
            f"/origin/v1/segments/{segment.segment_id}", expected_length=segment.byte_length
        )

    async def fetch_subtitle(self, track_id: str) -> bytes:
        return await self._get(f"/origin/v1/subtitles/{track_id}", expected_length=None)

    async def check_health(self) -> bool:
        try:
            response = await self._client.get(self._base + "/readyz", timeout=3.0)
            ok = response.status_code == 200
        except httpx.HTTPError:
            ok = False
        self._record(ok)
        return ok

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()
