"""Opaque identifiers and secret tokens.

Identifiers are random (not sequential, not derived from content or users), so an
identifier reveals nothing about the object and cannot be enumerated.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets

_ID_RE = re.compile(r"^[a-z]{2,4}_[a-z2-7]{26}$")


def new_id(prefix: str) -> str:
    raw = base64.b32encode(secrets.token_bytes(16)).decode("ascii").rstrip("=").lower()
    return f"{prefix}_{raw}"


def is_opaque_id(value: str, prefix: str | None = None) -> bool:
    if not _ID_RE.match(value):
        return False
    return prefix is None or value.startswith(prefix + "_")


def new_secret_token() -> str:
    """A 256-bit bearer secret. Only its SHA-256 digest is persisted."""
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def token_matches(token: str, expected_hash: str) -> bool:
    return hmac.compare_digest(hash_token(token), expected_hash)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
