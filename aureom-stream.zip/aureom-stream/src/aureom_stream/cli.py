"""``aureom-stream`` command line: services, tooling and a small demonstration client."""

from __future__ import annotations

import asyncio
import json
import os
import secrets
import signal
import subprocess
import sys
from pathlib import Path
from typing import Any

import click

from .config import Settings, get_settings


def _run(coro: Any) -> Any:
    return asyncio.run(coro)


def _print(data: Any) -> None:
    click.echo(json.dumps(data, indent=2, default=str))


def _token(value: str | None) -> str | None:
    return value or os.environ.get("AUREOM_TOKEN")


@click.group()
@click.version_option(package_name="aureom-stream")
def main() -> None:
    """AUREOM STREAM - hybrid origin-and-peer media delivery backend."""


# ----------------------------------------------------------------------------- services
def _serve(app_factory: str, host: str, port: int) -> None:
    import uvicorn

    from .observability.logging import configure_logging

    configure_logging(get_settings().log_level)
    uvicorn.run(app_factory, factory=True, host=host, port=port, log_config=None, access_log=False)


@main.command("serve-api")
@click.option("--host", default="127.0.0.1", show_default=True)
@click.option("--port", default=8080, show_default=True)
def serve_api(host: str, port: int) -> None:
    """Run the control-plane API."""
    _serve("aureom_stream.api.app:create_app", host, port)


@main.command("serve-origin")
@click.option("--host", default="127.0.0.1", show_default=True)
@click.option("--port", default=8081, show_default=True)
def serve_origin(host: str, port: int) -> None:
    """Run the origin (authenticated segment delivery)."""
    _serve("aureom_stream.origin.app:create_origin_app", host, port)


@main.command()
def worker() -> None:
    """Run a processing worker (validation, transcoding, packaging, clean-up)."""
    from .bootstrap import build_context
    from .observability.logging import configure_logging
    from .processing.worker import Worker

    async def run() -> None:
        settings = get_settings()
        configure_logging(settings.log_level)
        ctx = build_context(settings)
        if settings.is_sqlite():
            await ctx.db.create_all()
        stop = asyncio.Event()
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, stop.set)
        try:
            await Worker(ctx).run_forever(stop)
        finally:
            await ctx.close()

    _run(run())


@main.command("peer-agent")
@click.option("--control-url", required=True, help="Base URL of the control-plane API.")
@click.option("--name", default="agent", show_default=True)
@click.option("--host", default="127.0.0.1", show_default=True, help="Peer listen address.")
@click.option("--port", default=0, show_default=True, help="Peer listen port (0 = any).")
@click.option("--advertise-host", default=None, help="Address other peers should dial.")
@click.option("--admin-port", default=0, show_default=True, help="Loopback admin port (0 = any).")
@click.option("--cache-dir", type=click.Path(path_type=Path), required=True)
@click.option("--cache-bytes", default=256 * 1024 * 1024, show_default=True)
@click.option("--cache-ttl", default=3600.0, show_default=True)
@click.option(
    "--contribute/--no-contribute",
    default=False,
    show_default=True,
    help="Explicit opt-in to serve verified segments to other authorised viewers.",
)
@click.option("--upload-kbps", type=int, default=None, help="Upload cap in kbit/s.")
@click.option("--metered/--unmetered", default=False, help="Treat the network as metered.")
@click.option("--allow-on-metered", is_flag=True, help="Contribute even on a metered network.")
@click.option(
    "--background-agent", is_flag=True, help="Keep contributing after the player closes (explicit choice)."
)
@click.option("--tls-ca", type=click.Path(path_type=Path, exists=True))
@click.option("--tls-cert", type=click.Path(path_type=Path, exists=True))
@click.option("--tls-key", type=click.Path(path_type=Path, exists=True))
@click.option("--urgent-window", default=3.0, show_default=True)
@click.option("--prefetch-window", default=12.0, show_default=True)
@click.option("--enable-fault-injection", is_flag=True, help="Testing only.")
@click.option(
    "--ready-file",
    type=click.Path(path_type=Path),
    help="Write {port, admin_port, admin_token} here once listening.",
)
def peer_agent(**opts: Any) -> None:  # noqa: PLR0913
    """Run a peer agent. Without TLS options it is loopback-only (testing)."""
    from .observability.logging import configure_logging
    from .peer_agent.admin import AdminServer
    from .peer_agent.agent import AgentConfig, ContributionSettings, PeerAgent, TlsFiles
    from .scheduler.scheduler import SchedulerLimits

    tls = None
    if opts["tls_ca"] or opts["tls_cert"] or opts["tls_key"]:
        if not (opts["tls_ca"] and opts["tls_cert"] and opts["tls_key"]):
            raise click.UsageError("--tls-ca, --tls-cert and --tls-key must be given together")
        tls = TlsFiles(ca=opts["tls_ca"], cert=opts["tls_cert"], key=opts["tls_key"])
    config = AgentConfig(
        control_url=opts["control_url"],
        cache_dir=opts["cache_dir"],
        name=opts["name"],
        issuer=get_settings().issuer,
        listen_host=opts["host"],
        listen_port=opts["port"],
        advertise_host=opts["advertise_host"],
        cache_ttl_seconds=opts["cache_ttl"],
        tls=tls,
        contribution=ContributionSettings(
            enabled=opts["contribute"],
            upload_kbps_cap=opts["upload_kbps"],
            cache_bytes_cap=opts["cache_bytes"],
            metered=opts["metered"],
            allow_on_metered=opts["allow_on_metered"],
            background_agent=opts["background_agent"],
        ),
        limits=SchedulerLimits(
            urgent_window_seconds=opts["urgent_window"],
            prefetch_window_seconds=opts["prefetch_window"],
        ),
        enable_fault_injection=opts["enable_fault_injection"],
    )

    async def run() -> None:
        configure_logging(get_settings().log_level)
        agent = PeerAgent(config)
        await agent.start()
        admin_token = os.environ.get("AUREOM_AGENT_ADMIN_TOKEN") or secrets.token_urlsafe(24)
        admin = AdminServer(agent, token=admin_token, port=opts["admin_port"])
        await admin.start()
        ready = {"name": config.name, "port": agent.port, "admin_port": admin.port, "pid": os.getpid()}
        if opts["ready_file"]:
            path: Path = opts["ready_file"]
            fd = os.open(path.with_suffix(".tmp"), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as fh:
                json.dump({**ready, "admin_token": admin_token}, fh)
            os.replace(path.with_suffix(".tmp"), path)
        click.echo(json.dumps(ready), err=True)
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, admin.shutdown.set)
        await admin.shutdown.wait()
        # Leaving cleanly: deregister from every swarm before the process ends.
        await agent.stop()
        await admin.stop()

    _run(run())


# ----------------------------------------------------------------------------- tooling
@main.group()
def db() -> None:
    """Database schema management."""


@db.command("upgrade")
@click.option("--revision", default="head", show_default=True)
def db_upgrade(revision: str) -> None:
    """Apply Alembic migrations (PostgreSQL deployments)."""
    from alembic import command
    from alembic.config import Config

    root = Path(os.environ.get("AUREOM_MIGRATIONS_DIR", Path.cwd() / "migrations"))
    if not (root / "env.py").exists():
        raise click.ClickException(f"migrations directory not found at {root}")
    cfg = Config()
    cfg.set_main_option("script_location", str(root))
    command.upgrade(cfg, revision)
    click.echo(f"database upgraded to {revision}")


@db.command("create-all")
def db_create_all() -> None:
    """Create tables directly from the models (SQLite demo / tests)."""
    from .persistence.db import Database

    async def run() -> None:
        database = Database(get_settings().database_url)
        await database.create_all()
        await database.dispose()

    _run(run())
    click.echo("schema created")


@main.group()
def keys() -> None:
    """Signing keys."""


@keys.command("init")
def keys_init() -> None:
    """Create the Ed25519 signing key if it does not exist and print the public JWKS."""
    from .access.tokens import load_or_create_signing_key, public_jwk

    key = load_or_create_signing_key(get_settings().signing_key_path, create=True)
    _print({"keys": [public_jwk(key.public_key())]})


@main.group()
def token() -> None:
    """Access tokens (development helper; production uses an identity provider)."""


@token.command("mint")
@click.option("--user", required=True)
@click.option("--scope", "scopes", multiple=True, help="media:upload, media:publish, admin")
@click.option("--ttl", default=3600.0, show_default=True)
def token_mint(user: str, scopes: tuple[str, ...], ttl: float) -> None:
    from .access.tokens import TokenService, load_or_create_signing_key
    from .clock import SystemClock

    settings = get_settings()
    key = load_or_create_signing_key(settings.signing_key_path, create=settings.env != "prod")
    service = TokenService(key, issuer=settings.issuer, clock=SystemClock())
    click.echo(service.mint_principal_token(user, list(scopes), ttl))


@main.group()
def fixture() -> None:
    """Test media."""


@fixture.command("generate")
@click.option("--out", type=click.Path(path_type=Path), default=Path("fixtures/test-pattern.mp4"))
@click.option("--seconds", default=20, show_default=True)
@click.option("--size", default="640x360", show_default=True)
@click.option("--fps", default=24, show_default=True)
def fixture_generate(out: Path, seconds: int, size: str, fps: int) -> None:
    """Generate a synthetic clip (FFmpeg ``testsrc2`` + ``sine``): no third-party content."""
    from .fixtures import generate_test_video

    generate_test_video(out, seconds=seconds, size=size, fps=fps)
    click.echo(f"wrote {out} ({out.stat().st_size} bytes)")


@main.group()
def pki() -> None:
    """Certificates for the mutual-TLS peer transport."""


@pki.command("dev")
@click.option("--out", type=click.Path(path_type=Path), required=True)
@click.option("--name", "names", multiple=True, required=True)
def pki_dev(out: Path, names: tuple[str, ...]) -> None:
    """Create a throw-away CA and peer certificates for local mTLS testing."""
    from .peer_agent.pki import create_dev_pki

    files = create_dev_pki(out, list(names))
    _print({n: {"ca": str(f.ca), "cert": str(f.cert), "key": str(f.key)} for n, f in files.items()})


@main.command("openapi")
@click.option("--out", type=click.Path(path_type=Path), default=Path("docs/openapi.json"))
def openapi(out: Path) -> None:
    """Export the OpenAPI documents of the API and the origin."""
    import tempfile

    from .api.app import create_app
    from .bootstrap import build_context
    from .origin.app import create_origin_app

    with tempfile.TemporaryDirectory() as tmp:
        settings = Settings(  # type: ignore[call-arg]
            _env_file=None, env="test", database_url=f"sqlite+aiosqlite:///{tmp}/x.db",
            storage_local_root=Path(tmp) / "o", signing_key_path=Path(tmp) / "k.pem",
        )  # fmt: skip
        ctx = build_context(settings)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(create_app(ctx=ctx).openapi(), indent=2) + "\n")
        origin_out = out.with_name("openapi-origin.json")
        origin_out.write_text(json.dumps(create_origin_app(ctx=ctx).openapi(), indent=2) + "\n")
    click.echo(f"wrote {out} and {origin_out}")


@main.group()
def maintenance() -> None:
    """Housekeeping."""


@maintenance.command("sweep")
def maintenance_sweep() -> None:
    """Expire abandoned uploads, sessions, peer registrations and downloads."""
    from .bootstrap import build_context
    from .maintenance import sweep

    async def run() -> dict[str, int]:
        ctx = build_context(get_settings())
        try:
            return await sweep(ctx)
        finally:
            await ctx.close()

    _print(_run(run()))


# ----------------------------------------------------------------------------- client
api_option = click.option("--api", default="http://127.0.0.1:8080", show_default=True, envvar="AUREOM_API")
token_option = click.option("--token", default=None, help="Access token (or AUREOM_TOKEN).")


def _api(api: str, token_value: str | None):  # noqa: ANN202
    from .client import ApiClient, ControlClient

    return ApiClient(ControlClient(api), _token(token_value))


def _client_call(coro_factory: Any) -> Any:
    from .client import ControlError

    async def run() -> Any:
        try:
            return await coro_factory()
        except ControlError as exc:
            raise click.ClickException(f"{exc.status} {exc.code}: {exc.detail}") from exc

    return _run(run())


@main.command()
@click.argument("file", type=click.Path(path_type=Path, exists=True, dir_okay=False))
@api_option
@token_option
@click.option("--visibility", type=click.Choice(["private", "unlisted", "public"]), default="private")
@click.option("--key", default=None, help="Idempotency key (re-use to resume).")
def upload(file: Path, api: str, token: str | None, visibility: str, key: str | None) -> None:
    """Resumable upload: sends only the parts the server is missing."""
    client = _api(api, token)

    def progress(number: int, count: int, duplicate: bool) -> None:
        click.echo(f"  part {number}/{count} {'(already stored)' if duplicate else 'ok'}", err=True)

    async def run() -> Any:
        try:
            return await client.upload_file(
                file, visibility=visibility, idempotency_key=key, on_part=progress
            )
        finally:
            await client.control.close()

    _print(_client_call(run))


@main.group()
def asset() -> None:
    """Catalogue operations."""


@asset.command("create")
@click.option("--upload-id", required=True)
@click.option("--title", required=True)
@click.option("--description", default="")
@click.option("--language", default="en")
@click.option(
    "--rights-basis", type=click.Choice(["owner", "licensed", "open_licence", "public_domain"]), required=True
)
@click.option("--rights-statement", required=True)
@click.option("--licence", default=None)
@click.option("--peer-delivery/--no-peer-delivery", default=False)
@click.option("--offline", type=click.Choice(["none", "granted", "all_viewers"]), default="none")
@click.option("--peer-contribution", type=click.Choice(["none", "granted", "all_viewers"]), default="none")
@click.option("--wait/--no-wait", default=True, help="Wait for processing.")
@api_option
@token_option
def asset_create(api: str, token: str | None, wait: bool, **o: Any) -> None:
    client = _api(api, token)

    async def run() -> Any:
        try:
            created = await client.call(
                "POST", "/v1/assets",
                json={
                    "upload_id": o["upload_id"], "title": o["title"], "description": o["description"],
                    "language": o["language"],
                    "rights_declaration": {
                        "basis": o["rights_basis"], "statement": o["rights_statement"], "licence": o["licence"],
                    },
                    "distribution": {
                        "peer_delivery": o["peer_delivery"], "offline_download": o["offline"],
                        "peer_contribution": o["peer_contribution"],
                    },
                },
            )  # fmt: skip
            if wait:
                version = created["versions"][0]
                await client.wait_for_processing(created["asset_id"], version["version_id"])
                created = await client.call("GET", f"/v1/assets/{created['asset_id']}")
            return created
        finally:
            await client.control.close()

    _print(_client_call(run))


@asset.command("show")
@click.argument("asset_id")
@api_option
@token_option
def asset_show(asset_id: str, api: str, token: str | None) -> None:
    client = _api(api, token)
    _print(_client_call(lambda: client.call("GET", f"/v1/assets/{asset_id}")))


@asset.command("publish")
@click.argument("asset_id")
@click.argument("version_id")
@click.option("--visibility", type=click.Choice(["private", "unlisted", "public"]), default=None)
@click.option("--confirm-public", is_flag=True)
@api_option
@token_option
def asset_publish(
    asset_id: str, version_id: str, visibility: str | None, confirm_public: bool, api: str, token: str | None
) -> None:
    client = _api(api, token)
    body = {"visibility": visibility, "confirm_public": confirm_public}
    _print(
        _client_call(
            lambda: client.call("POST", f"/v1/assets/{asset_id}/versions/{version_id}/publish", json=body)
        )
    )


@asset.command("withdraw")
@click.argument("asset_id")
@click.argument("version_id")
@click.option("--reason", default=None)
@api_option
@token_option
def asset_withdraw(asset_id: str, version_id: str, reason: str | None, api: str, token: str | None) -> None:
    client = _api(api, token)
    _print(
        _client_call(
            lambda: client.call(
                "POST", f"/v1/assets/{asset_id}/versions/{version_id}/withdraw", json={"reason": reason}
            )
        )
    )


@asset.command("grant")
@click.argument("asset_id")
@click.option("--to", "principal_id", required=True)
@click.option(
    "--permission",
    type=click.Choice(["view", "offline_download", "peer_contribute", "manage"]),
    required=True,
)
@click.option("--ttl", type=float, default=None)
@api_option
@token_option
def asset_grant(
    asset_id: str, principal_id: str, permission: str, ttl: float | None, api: str, token: str | None
) -> None:
    client = _api(api, token)
    body = {"principal_id": principal_id, "permission": permission, "ttl_seconds": ttl}
    _print(_client_call(lambda: client.call("POST", f"/v1/assets/{asset_id}/grants", json=body)))


@main.command()
@click.argument("asset_id")
@click.option("--speed", default=1.0, show_default=True)
@click.option("--seek", "seeks", multiple=True, help="AT:TO, e.g. 3:14 (after 3 s jump to 14 s).")
@click.option("--rendition", default="best", show_default=True, help="best | lowest | abr")
@api_option
@token_option
def play(
    asset_id: str, speed: float, seeks: tuple[str, ...], rendition: str, api: str, token: str | None
) -> None:
    """SIMULATED playback through the origin only (no peer agent, no decoding)."""
    import tempfile

    from .peer_agent.agent import AgentConfig, PeerAgent
    from .playback.harness import PlaybackScript

    async def run() -> Any:
        with tempfile.TemporaryDirectory() as tmp:
            agent = PeerAgent(AgentConfig(control_url=api, cache_dir=Path(tmp), issuer=get_settings().issuer))
            await agent.start()
            try:
                session = await agent.open_session(_token(token), asset_id, peer_delivery=False)
                script = PlaybackScript(
                    speed=speed,
                    seeks=[tuple(map(float, s.split(":", 1))) for s in seeks],  # type: ignore[misc]
                )
                report = await agent.play(session, script=script, rendition=rendition)
                return report.to_dict()
            finally:
                await agent.stop()

    _print(_client_call(run))


@main.group()
def offline() -> None:
    """Offline downloads (client side)."""


def _downloader(api: str, directory: Path, max_bytes: int, throttle: float | None):  # noqa: ANN202
    from .client import ControlClient
    from .offline.downloader import OfflineDownloader

    return OfflineDownloader(
        ControlClient(api), root=directory, issuer=get_settings().issuer,
        max_store_bytes=max_bytes, throttle_bytes_per_second=throttle,
    )  # fmt: skip


dir_option = click.option("--dir", "directory", type=click.Path(path_type=Path), default=Path("./offline"))


@offline.command("start")
@click.argument("asset_id")
@click.option("--max-height", type=int, default=None)
@click.option("--subtitle", "subtitles", multiple=True)
@click.option("--max-store-bytes", default=5 * 1024**3, show_default=True)
@click.option("--throttle-kbps", type=float, default=None)
@click.option("--run/--no-run", "run_now", default=True)
@dir_option
@api_option
@token_option
def offline_start(
    asset_id: str, max_height: int | None, subtitles: tuple[str, ...], max_store_bytes: int,
    throttle_kbps: float | None, run_now: bool, directory: Path, api: str, token: str | None,
) -> None:  # fmt: skip
    throttle = throttle_kbps * 125 if throttle_kbps else None
    dl = _downloader(api, directory, max_store_bytes, throttle)

    async def run() -> Any:
        info = await dl.start(
            _token(token) or "", asset_id, max_height=max_height, subtitle_languages=list(subtitles)
        )
        out: dict[str, Any] = {"download_id": info["download_id"], "notices": info["notices"]}
        if run_now:
            out["result"] = (await dl.run(info["download_id"])).to_dict()
        return out

    _print(_client_call(run))


@offline.command("run")
@click.argument("download_id")
@click.option("--throttle-kbps", type=float, default=None)
@dir_option
@api_option
def offline_run(download_id: str, throttle_kbps: float | None, directory: Path, api: str) -> None:
    """Continue a download after a pause or an interruption."""
    dl = _downloader(api, directory, 1 << 62, throttle_kbps * 125 if throttle_kbps else None)

    async def run() -> Any:
        return (await dl.run(download_id)).to_dict()

    _print(_client_call(run))


@offline.command("pause")
@click.argument("download_id")
@dir_option
@api_option
def offline_pause(download_id: str, directory: Path, api: str) -> None:
    dl = _downloader(api, directory, 1 << 62, None)
    _print(_client_call(lambda: dl.pause(download_id)))


@offline.command("resume")
@click.argument("download_id")
@dir_option
@api_option
def offline_resume(download_id: str, directory: Path, api: str) -> None:
    dl = _downloader(api, directory, 1 << 62, None)
    _print(_client_call(lambda: dl.resume(download_id)))


@offline.command("delete")
@click.argument("download_id")
@dir_option
@api_option
def offline_delete(download_id: str, directory: Path, api: str) -> None:
    """End the download on the server and remove the local files."""
    dl = _downloader(api, directory, 1 << 62, None)
    _client_call(lambda: dl.delete(download_id))
    click.echo("deleted")


@main.command()
@click.option("--work-dir", type=click.Path(path_type=Path), default=Path("./var/demo"))
@click.option(
    "--stack",
    type=click.Choice(["local", "services"]),
    default="local",
    show_default=True,
    help="local: SQLite + files. services: PostgreSQL + Redis + S3 from AUREOM_* settings.",
)
@click.option("--report", type=click.Path(path_type=Path), default=None)
def demo(work_dir: Path, stack: str, report: Path | None) -> None:
    """Run the end-to-end demonstration (backend, origin, worker, three peer agents)."""
    args = [sys.executable, "-m", "aureom_stream.demo", "--work-dir", str(work_dir), "--stack", stack]
    if report:
        args += ["--report", str(report)]
    raise SystemExit(subprocess.call(args))  # noqa: S603


if __name__ == "__main__":
    main()
