"""Streaming-aware transfer scheduler (client side: player, peer agent).

What it optimises for is *playback*, not swarm health:

* requests are ordered by class and deadline - initialisation segments first, then
  segments close to the playhead, then prefetch. Rarity is never an ordering key, so
  a rare far-future segment cannot starve an imminent one;
* a bounded number of transfers run per session, with a slot reserved for urgent work;
* peers are tried only while there is enough time left to still fall back to the
  origin before the deadline; at ``deadline - origin_reserve`` an unfinished peer
  transfer is hedged with an origin request and the loser is cancelled;
* retries are budgeted per segment and per session;
* a seek cancels requests that the new playhead no longer needs;
* every byte returned was verified against the authenticated manifest.

The scheduler reports :class:`DeliveryObservation` to an observer (the player's ABR
adapter). It never changes the rendition by itself.
"""

from __future__ import annotations

import asyncio
import contextlib
import heapq
import itertools
import math
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Protocol

from ..clock import Clock, wait_first
from ..domain import (
    DeliveryObservation,
    IntegrityError,
    PeerCandidate,
    ReceiptOutcome,
    ReceiptReport,
    SegmentDescriptor,
    TransferGrantToken,
    VerifiedSegment,
    verify_segment,
)
from ..observability.metrics import DeliveryMetrics
from ..origin.client import OriginAdapter, OriginError
from ..transports.base import PeerTransport, TransportError

CLASS_INIT, CLASS_URGENT, CLASS_PREFETCH = 0, 1, 2


class TransferCancelled(Exception):
    """The request was cancelled because playback no longer needs it (e.g. a seek)."""


class SegmentUnavailable(Exception):
    """Neither a peer nor the origin delivered verified bytes. Playback cannot be
    guaranteed when both delivery paths are unavailable."""


class PeerDirectory(Protocol):
    async def discover(self, segment_ids: list[str]) -> list[PeerCandidate]: ...

    async def authorise_transfer(self, peer: PeerCandidate, segment_ids: list[str]) -> TransferGrantToken: ...

    async def report_receipt(self, receipt: ReceiptReport) -> None: ...


class SegmentStore(Protocol):
    async def get(self, segment_id: str) -> bytes | None: ...

    async def put(self, segment: VerifiedSegment) -> None: ...

    async def discard(self, segment_id: str) -> None: ...


@dataclass
class SchedulerLimits:
    """Per-session resource limits and timing policy."""

    max_concurrent_transfers: int = 4
    reserved_urgent_slots: int = 1  # never occupied by prefetch
    max_inflight_bytes: int = 64 * 1024 * 1024
    prefetch_window_seconds: float = 12.0
    urgent_window_seconds: float = 3.0  # closer than this to the deadline: origin first
    origin_reserve_seconds: float = 1.0  # minimum time kept in hand for the origin
    origin_safety_factor: float = 1.5
    peer_attempt_timeout: float = 4.0
    max_peer_attempts_per_segment: int = 2
    session_retry_budget: int = 12
    session_retry_refill_per_second: float = 0.5
    discovery_cache_seconds: float = 2.0
    discovery_batch: int = 32


@dataclass
class ClientPlaybackSession:
    """Client-side view of an authorised playback session."""

    session_id: str
    asset_version_id: str
    peer_delivery: bool = False
    selected_rendition_id: str | None = None
    playhead: float = 0.0
    buffer_seconds: float = 0.0
    limits: SchedulerLimits = field(default_factory=SchedulerLimits)


# --------------------------------------------------------------------------- helpers
class SourceStats:
    """Explainable per-source estimates: EWMA latency/throughput and a failure cooldown."""

    ALPHA = 0.3

    def __init__(self, *, latency: float = 0.1, bytes_per_second: float = 2_500_000.0) -> None:
        self.latency = latency
        self.bytes_per_second = bytes_per_second
        self.successes = 0
        self.failures = 0
        self.consecutive_failures = 0
        self.cooldown_until = 0.0
        self.banned = False  # set after an integrity failure; lasts for the session

    def estimate(self, size: int) -> float:
        return self.latency + size / max(self.bytes_per_second, 1.0)

    def record_success(self, size: int, elapsed: float) -> None:
        elapsed = max(elapsed, 1e-4)
        rate = size / elapsed
        if self.successes == 0:
            self.bytes_per_second = rate
            self.latency = min(self.latency, elapsed)
        else:
            self.bytes_per_second += self.ALPHA * (rate - self.bytes_per_second)
            self.latency += self.ALPHA * (min(elapsed, self.latency * 4) - self.latency)
        self.successes += 1
        self.consecutive_failures = 0

    def record_failure(self, now: float, *, integrity: bool = False) -> None:
        self.failures += 1
        self.consecutive_failures += 1
        if integrity:
            self.banned = True
        # 2 s, 4 s, 8 s ... capped at 60 s.
        self.cooldown_until = now + min(60.0, 2.0**self.consecutive_failures)

    def usable(self, now: float) -> bool:
        return not self.banned and now >= self.cooldown_until

    @property
    def local_reliability(self) -> float:
        return (self.successes + 1.0) / (self.successes + self.failures + 1.0)


class RetryBudget:
    def __init__(self, clock: Clock, capacity: int, refill_per_second: float) -> None:
        self._clock = clock
        self._capacity = float(capacity)
        self._refill = refill_per_second
        self._tokens = float(capacity)
        self._at = clock.now()

    def take(self) -> bool:
        now = self._clock.now()
        self._tokens = min(self._capacity, self._tokens + (now - self._at) * self._refill)
        self._at = now
        if self._tokens >= 1.0:
            self._tokens -= 1.0
            return True
        return False


class PriorityGate:
    """Bounded concurrency with strict priority order among waiters."""

    def __init__(self, limit: int, reserved_urgent: int, max_bytes: int) -> None:
        self._limit = max(1, limit)
        self._prefetch_limit = max(1, self._limit - max(0, reserved_urgent))
        self._max_bytes = max_bytes
        self._active = 0
        self._active_prefetch = 0
        self._bytes = 0
        self._waiters: list[tuple[tuple[int, float], int, bool, int, asyncio.Future[None]]] = []
        self._seq = itertools.count()
        self.start_order: list[tuple[int, float]] = []  # for tests / diagnostics

    def _fits(self, prefetch: bool, cost: int) -> bool:
        if self._active >= self._limit:
            return False
        if prefetch and self._active_prefetch >= self._prefetch_limit:
            return False
        return self._active == 0 or self._bytes + cost <= self._max_bytes

    def _start(self, key: tuple[int, float], prefetch: bool, cost: int) -> None:
        self._active += 1
        self._active_prefetch += int(prefetch)
        self._bytes += cost
        if len(self.start_order) < 10_000:
            self.start_order.append(key)

    def _wake(self) -> None:
        # Strict priority: wake waiters from the best key down. A waiter that does not
        # fit (prefetch quota or byte limit) is skipped, never jumped ahead of.
        skipped = []
        while self._waiters:
            entry = heapq.heappop(self._waiters)
            key, _, prefetch, cost, fut = entry
            if fut.done():
                continue
            if self._fits(prefetch, cost):
                self._start(key, prefetch, cost)
                fut.set_result(None)
            else:
                skipped.append(entry)
                if self._active >= self._limit:
                    break
        for entry in skipped:
            heapq.heappush(self._waiters, entry)

    @contextlib.asynccontextmanager
    async def slot(self, key: tuple[int, float], *, cost: int):  # noqa: ANN201
        prefetch = key[0] == CLASS_PREFETCH
        if not self._waiters and self._fits(prefetch, cost):
            self._start(key, prefetch, cost)
        else:
            fut: asyncio.Future[None] = asyncio.get_running_loop().create_future()
            heapq.heappush(self._waiters, (key, next(self._seq), prefetch, cost, fut))
            self._wake()
            try:
                await fut
            except asyncio.CancelledError:
                if fut.done() and not fut.cancelled():
                    self._release(prefetch, cost)  # granted and cancelled at once
                raise
        try:
            yield
        finally:
            self._release(prefetch, cost)

    def _release(self, prefetch: bool, cost: int) -> None:
        self._active -= 1
        self._active_prefetch -= int(prefetch)
        self._bytes -= cost
        self._wake()


@dataclass
class _Inflight:
    task: asyncio.Future[VerifiedSegment]
    segment: SegmentDescriptor
    deadline: float
    completing: bool = False  # verified bytes in hand; only bookkeeping is left


@dataclass
class _SessionState:
    gate: PriorityGate
    retry_budget: RetryBudget
    inflight: dict[str, _Inflight] = field(default_factory=dict)
    discovery: dict[str, tuple[float, list[PeerCandidate]]] = field(default_factory=dict)


Observer = Callable[[DeliveryObservation], None]
VerifiedHook = Callable[[VerifiedSegment], Awaitable[None]]


def plan_window(
    timeline: list[SegmentDescriptor],
    *,
    playhead: float,
    limits: SchedulerLimits,
    have: set[str],
) -> list[SegmentDescriptor]:
    """The bounded prefetch window: media segments overlapping
    ``[playhead, playhead + prefetch_window)`` that are not buffered yet, nearest first."""
    end = playhead + limits.prefetch_window_seconds
    wanted = [
        s for s in timeline
        if s.kind == "media" and s.end_time > playhead and s.start_time < end and s.segment_id not in have
    ]  # fmt: skip
    return sorted(wanted, key=lambda s: s.start_time)


# --------------------------------------------------------------------------- scheduler
class SegmentScheduler:
    def __init__(
        self,
        *,
        clock: Clock,
        origin: OriginAdapter,
        directory: PeerDirectory | None = None,
        transports: dict[str, PeerTransport] | None = None,
        store: SegmentStore | None = None,
        metrics: DeliveryMetrics | None = None,
        observer: Observer | None = None,
        on_verified: VerifiedHook | None = None,
    ) -> None:
        self._clock = clock
        self._origin = origin
        self._directory = directory
        self._transports = transports or {}
        self._store = store
        self.metrics = metrics or DeliveryMetrics()
        self._observer = observer
        self._on_verified = on_verified
        self._sessions: dict[str, _SessionState] = {}
        self.peer_stats: dict[str, SourceStats] = {}
        self.origin_stats = SourceStats(latency=0.15, bytes_per_second=2_500_000.0)
        self._background: set[asyncio.Future[None]] = set()

    # ------------------------------------------------------------------ session state
    def _state(self, session: ClientPlaybackSession) -> _SessionState:
        state = self._sessions.get(session.session_id)
        if state is None:
            limits = session.limits
            state = _SessionState(
                gate=PriorityGate(
                    limits.max_concurrent_transfers,
                    limits.reserved_urgent_slots,
                    limits.max_inflight_bytes,
                ),
                retry_budget=RetryBudget(
                    self._clock, limits.session_retry_budget, limits.session_retry_refill_per_second
                ),
            )
            self._sessions[session.session_id] = state
        return state

    def gate_order(self, session: ClientPlaybackSession) -> list[tuple[int, float]]:
        return list(self._state(session).gate.start_order)

    def _classify(self, session: ClientPlaybackSession, segment: SegmentDescriptor, deadline: float) -> int:
        if segment.kind == "init":
            return CLASS_INIT
        if deadline - self._clock.now() <= session.limits.urgent_window_seconds:
            return CLASS_URGENT
        return CLASS_PREFETCH

    def _origin_reserve(self, session: ClientPlaybackSession, segment: SegmentDescriptor) -> float:
        estimate = self.origin_stats.estimate(segment.byte_length)
        return max(session.limits.origin_reserve_seconds, estimate * session.limits.origin_safety_factor)

    # ------------------------------------------------------------------ public API
    async def fetch(
        self, session: ClientPlaybackSession, segment: SegmentDescriptor, deadline: float
    ) -> VerifiedSegment:
        """Deliver ``segment`` verified, ideally before ``deadline`` (epoch seconds on
        the injected clock; ``math.inf`` for background work).

        Raises :class:`TransferCancelled` if a seek made the request unnecessary and
        :class:`SegmentUnavailable` if no source could deliver verified bytes."""
        if segment.asset_version_id != session.asset_version_id:
            raise ValueError("segment does not belong to the session's asset version")
        state = self._state(session)
        if self._store is not None:
            cached = await self._store.get(segment.segment_id)
            if cached is not None:
                try:
                    verified = verify_segment(segment, cached, source="cache")
                except IntegrityError:
                    self.metrics.verification_failures += 1
                    await self._store.discard(segment.segment_id)
                else:
                    self.metrics.cache_hits += 1
                    self.metrics.cache_bytes += len(cached)
                    self._observe(verified, deadline, attempts=0)
                    return verified
        existing = state.inflight.get(segment.segment_id)
        if existing is not None:
            self.metrics.duplicate_requests_avoided += 1
            existing.deadline = min(existing.deadline, deadline)
            task = existing.task
        else:
            if self._store is not None:
                self.metrics.cache_misses += 1
            task = asyncio.ensure_future(self._run(session, state, segment, deadline))
            state.inflight[segment.segment_id] = _Inflight(task, segment, deadline)

            def _done(done: asyncio.Future[VerifiedSegment], sid: str = segment.segment_id) -> None:
                current = state.inflight.get(sid)
                if current is not None and current.task is done:
                    del state.inflight[sid]
                if not done.cancelled():
                    done.exception()  # mark retrieved; waiters re-raise it themselves

            task.add_done_callback(_done)
        try:
            return await asyncio.shield(task)
        except asyncio.CancelledError:
            if task.cancelled():
                raise TransferCancelled(segment.segment_id) from None
            raise  # the caller was cancelled; the shared transfer keeps running

    def seek(self, session: ClientPlaybackSession, position: float) -> int:
        """Move the playhead. Cancels queued and running requests that fall outside the
        new prefetch window; returns how many were cancelled."""
        session.playhead = position
        state = self._state(session)
        window_end = position + session.limits.prefetch_window_seconds
        cancelled = 0
        for inflight in list(state.inflight.values()):
            seg = inflight.segment
            if seg.kind == "init" or inflight.completing:
                continue
            if seg.end_time <= position or seg.start_time >= window_end:
                inflight.task.cancel()
                cancelled += 1
                self.metrics.event("seek_cancel", segment_id=seg.segment_id, seq=seg.sequence_number)
        self.metrics.cancelled_requests += cancelled
        return cancelled

    def close_session(self, session: ClientPlaybackSession) -> None:
        state = self._sessions.pop(session.session_id, None)
        if state is not None:
            for inflight in list(state.inflight.values()):
                inflight.task.cancel()

    async def drain(self) -> None:
        """Wait for background bookkeeping (receipts, cache writes) to finish."""
        while self._background:
            await asyncio.gather(*list(self._background), return_exceptions=True)

    # ------------------------------------------------------------------ internals
    def _spawn(self, coro: Awaitable[None]) -> None:
        task = asyncio.ensure_future(coro)
        self._background.add(task)
        task.add_done_callback(self._background.discard)

    async def _run(
        self,
        session: ClientPlaybackSession,
        state: _SessionState,
        segment: SegmentDescriptor,
        deadline: float,
    ) -> VerifiedSegment:
        key = (self._classify(session, segment, deadline), deadline)
        async with state.gate.slot(key, cost=segment.byte_length):
            inflight = state.inflight.get(segment.segment_id)
            if inflight is not None:
                deadline = inflight.deadline  # a duplicate request may have tightened it
            return await self._deliver(session, state, segment, deadline)

    async def _candidates(
        self, session: ClientPlaybackSession, state: _SessionState, segment: SegmentDescriptor
    ) -> list[PeerCandidate]:
        assert self._directory is not None
        now = self._clock.now()
        cached = state.discovery.get(segment.segment_id)
        if cached is None or cached[0] <= now:
            # One bounded discovery for this segment and the others waiting with it.
            batch = [segment.segment_id]
            for other in state.inflight.values():
                sid = other.segment.segment_id
                entry = state.discovery.get(sid)
                if (
                    sid != segment.segment_id
                    and other.segment.kind == "media"
                    and (entry is None or entry[0] <= now)
                ):
                    batch.append(sid)
                if len(batch) >= session.limits.discovery_batch:
                    break
            started = self._clock.now()
            try:
                found = await self._directory.discover(batch)
            except Exception as exc:  # registry down or refusing: peers are optional
                self.metrics.peer_failure("discovery_failed")
                self.metrics.event("discovery_failed", error=type(exc).__name__)
                found = []
            self.metrics.discovery_latency.append(self._clock.now() - started)
            expires = self._clock.now() + session.limits.discovery_cache_seconds
            for sid in batch:
                state.discovery[sid] = (expires, [c for c in found if sid in c.segment_ids])
            if len(state.discovery) > 4096:
                state.discovery = {k: v for k, v in state.discovery.items() if v[0] > now}
        candidates = state.discovery[segment.segment_id][1]
        now = self._clock.now()
        usable = [
            c for c in candidates
            if c.transport in self._transports
            and self.peer_stats.setdefault(c.peer_id, SourceStats()).usable(now)
        ]  # fmt: skip

        def cost(candidate: PeerCandidate) -> float:
            stats = self.peer_stats[candidate.peer_id]
            trust = max(0.05, candidate.reliability * stats.local_reliability)
            return stats.estimate(segment.byte_length) / trust

        return sorted(usable, key=lambda c: (cost(c), c.peer_id))

    async def _deliver(
        self,
        session: ClientPlaybackSession,
        state: _SessionState,
        segment: SegmentDescriptor,
        deadline: float,
    ) -> VerifiedSegment:
        limits = session.limits
        started = self._clock.now()
        reserve = self._origin_reserve(session, segment)
        origin_healthy = self._origin.healthy
        slack = deadline - started
        peers_allowed = (
            session.peer_delivery
            and self._directory is not None
            and bool(self._transports)
            and segment.kind == "media"
        )
        # Initialisation and near-playback segments go straight to the origin while it
        # is healthy; peers are for segments with time to spare.
        peers_first = peers_allowed and (
            slack > max(limits.urgent_window_seconds, reserve) or not origin_healthy
        )
        attempts = 0
        origin_error: Exception | None = None
        if peers_first:
            tried = 0
            for peer in await self._candidates(session, state, segment):
                if tried >= limits.max_peer_attempts_per_segment:
                    break
                hedge_at = deadline - reserve if origin_healthy else None
                now = self._clock.now()
                if hedge_at is not None:
                    estimate = self.peer_stats[peer.peer_id].estimate(segment.byte_length)
                    if hedge_at - now <= 0.05 or now + estimate > deadline:
                        break  # not enough time left for a peer attempt
                if tried > 0:
                    if not state.retry_budget.take():
                        self.metrics.event("retry_budget_exhausted", segment_id=segment.segment_id)
                        break
                    self.metrics.retries += 1
                tried += 1
                attempts += 1
                try:
                    result = await self._try_peer(session, segment, peer, hedge_at)
                except OriginError as exc:  # the hedged origin request failed
                    origin_error = exc
                    origin_healthy = False
                    continue
                if result is not None:
                    return await self._complete(state, result, deadline, attempts, started)
            if tried:
                self.metrics.origin_fallbacks += 1
                self.metrics.event(
                    "origin_fallback", segment_id=segment.segment_id, seq=segment.sequence_number
                )
        if origin_error is None:
            attempts += 1
            try:
                return await self._complete(
                    state, await self._fetch_origin(segment), deadline, attempts, started
                )
            except OriginError as exc:
                origin_error = exc
        self.metrics.unavailable += 1
        self.metrics.event("unavailable", segment_id=segment.segment_id, error=str(origin_error))
        raise SegmentUnavailable(
            f"{segment.segment_id}: no peer delivered and the origin failed ({origin_error})"
        ) from origin_error

    async def _fetch_origin(self, segment: SegmentDescriptor) -> VerifiedSegment:
        started = self._clock.now()
        try:
            data = await self._origin.fetch_segment(segment)
        except OriginError:
            self.origin_stats.record_failure(self._clock.now())
            raise
        elapsed = self._clock.now() - started
        try:
            verified = verify_segment(segment, data, source="origin", elapsed=elapsed)
        except IntegrityError as exc:
            self.metrics.verification_failures += 1
            self.metrics.event("origin_integrity_failure", segment_id=segment.segment_id, reason=exc.reason)
            raise OriginError("unavailable", f"origin returned unverifiable bytes ({exc.reason})") from exc
        self.origin_stats.record_success(len(data), elapsed)
        return verified

    def _receipt(
        self,
        grant: TransferGrantToken,
        segment: SegmentDescriptor,
        outcome: ReceiptOutcome,
        size: int,
        elapsed: float,
    ) -> None:
        directory = self._directory
        if directory is None:
            return

        async def send() -> None:
            with contextlib.suppress(Exception):
                await directory.report_receipt(
                    ReceiptReport(
                        grant_id=grant.grant_id,
                        segment_id=segment.segment_id,
                        role="receiver",
                        outcome=outcome,
                        bytes_transferred=size,
                        duration_ms=int(max(0.0, elapsed) * 1000),
                    )
                )

        self._spawn(send())

    async def _try_peer(
        self,
        session: ClientPlaybackSession,
        segment: SegmentDescriptor,
        peer: PeerCandidate,
        hedge_at: float | None,
    ) -> VerifiedSegment | None:
        """One peer attempt. Returns a verified segment (from the peer, or from the
        origin if the hedge won), or None if the attempt failed. Raises
        :class:`OriginError` only when a hedged origin request failed."""
        assert self._directory is not None
        stats = self.peer_stats.setdefault(peer.peer_id, SourceStats())
        limits = session.limits
        try:
            grant = await self._directory.authorise_transfer(peer, [segment.segment_id])
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            stats.record_failure(self._clock.now())
            self.metrics.peer_failure("grant_denied")
            self.metrics.event("grant_denied", peer_id=peer.peer_id, error=type(exc).__name__)
            return None
        transport = self._transports[peer.transport]
        started = self._clock.now()
        timeout = limits.peer_attempt_timeout
        peer_task: asyncio.Future[bytes] = asyncio.ensure_future(
            transport.fetch_segment(peer, segment, grant, timeout=timeout)
        )
        origin_task: asyncio.Future[VerifiedSegment] | None = None
        try:
            budget = timeout + 0.5 if hedge_at is None else min(timeout + 0.5, hedge_at - started)
            if not await wait_first(self._clock, peer_task, budget):
                if hedge_at is None or self._clock.now() - started >= timeout:
                    self._peer_failed(peer, stats, grant, segment, "timeout", started)
                    return None
                # The deadline is close and the peer is still going: hedge with the origin.
                self.metrics.hedged_requests += 1
                self.metrics.event("hedge", segment_id=segment.segment_id, peer_id=peer.peer_id)
                origin_task = asyncio.ensure_future(self._fetch_origin(segment))
                remaining = max(0.0, timeout - (self._clock.now() - started))
                sleeper = asyncio.ensure_future(self._clock.sleep(remaining))
                try:
                    racing: set[asyncio.Future[Any]] = {peer_task, origin_task, sleeper}
                    await asyncio.wait(racing, return_when=asyncio.FIRST_COMPLETED)
                finally:
                    sleeper.cancel()
                if origin_task.done() and not peer_task.done():
                    if origin_task.exception() is None:
                        # The origin won: drop the now-unnecessary peer request.
                        self.metrics.cancelled_requests += 1
                        self.metrics.event("duplicate_cancelled", loser="peer", segment_id=segment.segment_id)
                        self._peer_failed(peer, stats, grant, segment, "timeout", started)
                        return self._fallback(segment, origin_task.result())
                    # Origin failed; give the peer the rest of its time.
                    if not await wait_first(
                        self._clock, peer_task, max(0.0, timeout - (self._clock.now() - started))
                    ):
                        self._peer_failed(peer, stats, grant, segment, "timeout", started)
                        raise origin_task.exception()  # type: ignore[misc]
                elif not peer_task.done():
                    self._peer_failed(peer, stats, grant, segment, "timeout", started)
                    return self._fallback(segment, await origin_task)
            verified = self._peer_result(peer, stats, grant, segment, peer_task, started)
            if verified is not None:
                if origin_task is not None and not origin_task.done():
                    self.metrics.cancelled_requests += 1
                    self.metrics.event("duplicate_cancelled", loser="origin", segment_id=segment.segment_id)
                return verified
            if origin_task is not None:
                # The peer failed while the hedge was in flight.
                return self._fallback(segment, await origin_task)
            return None
        finally:
            for task in (peer_task, origin_task):
                if task is not None and not task.done():
                    task.cancel()
                elif task is not None and not task.cancelled():
                    task.exception()

    def _fallback(self, segment: SegmentDescriptor, verified: VerifiedSegment) -> VerifiedSegment:
        self.metrics.origin_fallbacks += 1
        self.metrics.event(
            "origin_fallback", segment_id=segment.segment_id, seq=segment.sequence_number, hedged=True
        )
        return verified

    def _peer_failed(
        self,
        peer: PeerCandidate,
        stats: SourceStats,
        grant: TransferGrantToken,
        segment: SegmentDescriptor,
        reason: str,
        started: float,
        *,
        integrity: bool = False,
    ) -> None:
        now = self._clock.now()
        stats.record_failure(now, integrity=integrity)
        self.metrics.peer_failure(reason)
        self.metrics.event(
            "peer_failure", peer_id=peer.peer_id, segment_id=segment.segment_id,
            seq=segment.sequence_number, reason=reason,
        )  # fmt: skip
        outcome: ReceiptOutcome = {
            "hash_mismatch": "corrupt",
            "length_mismatch": "length_mismatch",
            "timeout": "timeout",
            "refused": "refused",
            "not_found": "not_found",
        }.get(reason, "error")  # type: ignore[assignment]
        self._receipt(grant, segment, outcome, 0, now - started)
        return None

    def _peer_result(
        self,
        peer: PeerCandidate,
        stats: SourceStats,
        grant: TransferGrantToken,
        segment: SegmentDescriptor,
        task: asyncio.Future[bytes],
        started: float,
    ) -> VerifiedSegment | None:
        elapsed = self._clock.now() - started
        try:
            data = task.result()
        except TransportError as exc:
            reason = "unreachable" if exc.reason == "unreachable" else exc.reason
            self._peer_failed(peer, stats, grant, segment, reason, started)
            return None
        except asyncio.CancelledError:
            raise
        except Exception:
            self._peer_failed(peer, stats, grant, segment, "error", started)
            return None
        try:
            verified = verify_segment(segment, data, source="peer", source_id=peer.peer_id, elapsed=elapsed)
        except IntegrityError as exc:
            # Corrupted or wrong-length bytes never leave the scheduler.
            self.metrics.verification_failures += 1
            self._peer_failed(peer, stats, grant, segment, exc.reason, started, integrity=True)
            return None
        stats.record_success(len(data), elapsed)
        self._receipt(grant, segment, "verified", len(data), elapsed)
        return verified

    def _observe(self, verified: VerifiedSegment, deadline: float, attempts: int) -> None:
        if self._observer is None:
            return
        size = len(verified.data)
        elapsed = max(verified.elapsed, 1e-4)
        slack = deadline - self._clock.now()
        self._observer(
            DeliveryObservation(
                segment_id=verified.descriptor.segment_id,
                rendition_id=verified.descriptor.rendition_id,
                source=verified.source,
                bytes=size,
                elapsed=verified.elapsed,
                throughput_bps=0.0 if verified.source == "cache" else size * 8 / elapsed,
                deadline_slack=slack if math.isfinite(slack) else math.inf,
                attempts=attempts,
            )
        )

    async def _complete(
        self,
        state: _SessionState,
        verified: VerifiedSegment,
        deadline: float,
        attempts: int,
        started: float,
    ) -> VerifiedSegment:
        inflight = state.inflight.get(verified.descriptor.segment_id)
        if inflight is not None:
            inflight.completing = True  # a seek no longer cancels this request
        metrics = self.metrics
        size = len(verified.data)
        metrics.segments_delivered += 1
        if verified.source == "peer":
            metrics.peer_bytes += size
            metrics.peer_segments += 1
            metrics.transfer_latency_peer.append(verified.elapsed)
        else:
            metrics.origin_bytes += size
            metrics.origin_segments += 1
            metrics.transfer_latency_origin.append(verified.elapsed)
        metrics.event(
            "delivered", segment_id=verified.descriptor.segment_id,
            seq=verified.descriptor.sequence_number, kind=verified.descriptor.kind,
            source=verified.source, source_id=verified.source_id, bytes=size,
            elapsed=round(self._clock.now() - started, 4),
            slack=round(deadline - self._clock.now(), 4) if math.isfinite(deadline) else None,
        )  # fmt: skip
        if self._store is not None:
            await self._store.put(verified)
        if self._on_verified is not None:
            await self._on_verified(verified)
        self._observe(verified, deadline, attempts)
        return verified
