"""Client side of offline downloads.

Pulls one rendition (initialisation segment + media segments) and the selected
subtitles from the origin, verifies every item against the signed manifest, writes it
atomically, and can stop and continue at any item boundary:

* **pause / resume** - the server refuses a paused download's requests; the downloader
  stops cleanly and continues after ``resume``;
* **interruption** - on restart every existing file is re-hashed, so half-written or
  tampered files are fetched again and nothing is trusted from the state file alone;
* **verified completion** - the digest over all verified item hashes must match the
  digest derived from the manifest before the download is reported complete;
* **storage limit** - a local byte cap is checked before anything is fetched;
* **explicit deletion** - removes the local files and ends the server-side record.

The result is a plain, playable HLS directory (unencrypted in this release).
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import httpx

from ..access.tokens import TokenVerifier
from ..clock import Clock, SystemClock
from ..domain import IntegrityError, SegmentDescriptor, verify_segment
from ..manifests.version_manifest import ManifestSubtitle, VersionManifest, verify_manifest
from ..origin.client import HttpOriginAdapter, OriginError
from ..peer_agent.control import ControlClient, ControlError
from ..processing.ffmpeg import dir_size

Status = Literal["completed", "paused", "interrupted", "revoked", "failed"]


@dataclass
class OfflineResult:
    status: Status
    items_done: int
    items_total: int
    bytes_done: int
    bytes_total: int
    fetched_items: int
    reused_items: int
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


class LocalStorageLimit(Exception):
    pass


def _sha256_file(path: Path) -> str | None:
    try:
        digest = hashlib.sha256()
        with open(path, "rb") as fh:
            while chunk := fh.read(1 << 20):
                digest.update(chunk)
        return digest.hexdigest()
    except FileNotFoundError:
        return None


def _write_atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    with open(tmp, "wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, path)


class OfflineDownloader:
    def __init__(
        self,
        control: ControlClient,
        *,
        root: Path,
        issuer: str = "aureom-stream",
        clock: Clock | None = None,
        max_store_bytes: int = 5 * 1024**3,
        origin_http: httpx.AsyncClient | None = None,
        throttle_bytes_per_second: float | None = None,
    ) -> None:
        self._control = control
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)
        self._issuer = issuer
        self._clock = clock or SystemClock()
        self._max_store = max_store_bytes
        self._origin_http = origin_http
        self._throttle = throttle_bytes_per_second
        self._verifier: TokenVerifier | None = None

    # ------------------------------------------------------------------ local state
    def directory(self, download_id: str) -> Path:
        if not download_id.replace("_", "").isalnum():
            raise ValueError("invalid download id")
        return self._root / download_id

    def _state_path(self, download_id: str) -> Path:
        return self.directory(download_id) / "state.json"

    def load_state(self, download_id: str) -> dict[str, Any]:
        return json.loads(self._state_path(download_id).read_text())  # type: ignore[no-any-return]

    def _save_state(self, state: dict[str, Any]) -> None:
        path = self._state_path(state["download_id"])
        _write_atomic(path, json.dumps(state, indent=2).encode())
        path.chmod(0o600)  # contains the download token

    # ------------------------------------------------------------------ server calls
    async def start(
        self,
        principal_token: str,
        asset_id: str,
        *,
        version_id: str | None = None,
        rendition_id: str | None = None,
        max_height: int | None = None,
        subtitle_languages: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"asset_id": asset_id, "subtitle_languages": subtitle_languages or []}
        if version_id:
            body["version_id"] = version_id
        if rendition_id:
            body["rendition_id"] = rendition_id
        if max_height:
            body["max_height"] = max_height
        info = await self._control.request("POST", "/v1/offline-downloads", token=principal_token, json=body)
        if dir_size(self._root) + info["total_bytes"] > self._max_store:
            await self._control.request(
                "DELETE", f"/v1/offline-downloads/{info['download_id']}", token=info["download_token"]
            )
            raise LocalStorageLimit(
                f"needs {info['total_bytes']} bytes but the local offline store "
                f"is capped at {self._max_store}"
            )
        self._save_state(
            {
                "download_id": info["download_id"],
                "token": info["download_token"],
                "asset_id": info["asset_id"],
                "version_id": info["version_id"],
                "rendition_id": info["rendition_id"],
                "subtitle_languages": info["subtitle_languages"],
                "total_items": info["total_items"],
                "total_bytes": info["total_bytes"],
                "status": "active",
            }
        )
        return info  # type: ignore[no-any-return]

    async def _remote(self, state: dict[str, Any], method: str = "GET", suffix: str = "") -> dict[str, Any]:
        return await self._control.request(  # type: ignore[no-any-return]
            method, f"/v1/offline-downloads/{state['download_id']}{suffix}", token=state["token"]
        )

    async def pause(self, download_id: str) -> dict[str, Any]:
        state = self.load_state(download_id)
        info = await self._remote(state, "POST", "/pause")
        state["status"] = "paused"
        self._save_state(state)
        return info

    async def resume(self, download_id: str) -> dict[str, Any]:
        state = self.load_state(download_id)
        info = await self._remote(state, "POST", "/resume")
        state["status"] = "active"
        self._save_state(state)
        return info

    async def delete(self, download_id: str) -> None:
        """Explicit deletion: end the server record, then remove the local copy."""
        state = self.load_state(download_id)
        try:
            await self._control.request(
                "DELETE", f"/v1/offline-downloads/{download_id}", token=state["token"]
            )
        except ControlError as exc:
            if exc.status not in (404, 410):
                raise
        shutil.rmtree(self.directory(download_id), ignore_errors=True)

    # ------------------------------------------------------------------ the transfer
    async def _manifest(self, state: dict[str, Any]) -> VersionManifest:
        if self._verifier is None:
            self._verifier = TokenVerifier.from_jwks(
                await self._control.jwks(), issuer=self._issuer, clock=self._clock
            )
        path = self.directory(state["download_id"]) / "manifest.jws"
        if not path.exists():
            response = await self._control.request(
                "GET", f"/v1/offline-downloads/{state['download_id']}/manifest",
                token=state["token"], raw=True,
            )  # fmt: skip
            _write_atomic(path, response.content)
        return verify_manifest(self._verifier, path.read_text(), expected_version_id=state["version_id"])

    @staticmethod
    def _segment_name(segment: SegmentDescriptor) -> str:
        return "init.mp4" if segment.kind == "init" else f"seg_{segment.sequence_number:05d}.m4s"

    def _write_playlists(
        self, base: Path, manifest: VersionManifest, rendition_id: str, subs: list[ManifestSubtitle]
    ) -> None:
        rendition = manifest.rendition(rendition_id)
        segments = manifest.media_segments(rendition_id)
        target = max(1, round(max(s.duration for s in segments) + 0.499))
        lines = [
            "#EXTM3U", "#EXT-X-VERSION:7", f"#EXT-X-TARGETDURATION:{target}",
            "#EXT-X-MEDIA-SEQUENCE:0", "#EXT-X-PLAYLIST-TYPE:VOD", "#EXT-X-INDEPENDENT-SEGMENTS",
            '#EXT-X-MAP:URI="init.mp4"',
        ]  # fmt: skip
        for seg in segments:
            lines += [f"#EXTINF:{seg.duration:.6f},", self._segment_name(seg)]
        lines.append("#EXT-X-ENDLIST")
        _write_atomic(base / "media" / "index.m3u8", ("\n".join(lines) + "\n").encode())
        master = ["#EXTM3U", "#EXT-X-VERSION:7", "#EXT-X-INDEPENDENT-SEGMENTS"]
        group = ""
        for sub in subs:
            group = ',SUBTITLES="subs"'
            playlist = (
                "#EXTM3U\n#EXT-X-VERSION:7\n"
                f"#EXT-X-TARGETDURATION:{max(1, round(manifest.duration_seconds + 0.499))}\n"
                "#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-PLAYLIST-TYPE:VOD\n"
                f"#EXTINF:{manifest.duration_seconds:.6f},\n{sub.language}.vtt\n#EXT-X-ENDLIST\n"
            )
            _write_atomic(base / "subs" / f"{sub.language}.m3u8", playlist.encode())
            master.append(
                f'#EXT-X-MEDIA:TYPE=SUBTITLES,GROUP-ID="subs",NAME="{sub.language}",'
                f'LANGUAGE="{sub.language}",DEFAULT=NO,AUTOSELECT=YES,URI="subs/{sub.language}.m3u8"'
            )
        master.append(
            f"#EXT-X-STREAM-INF:BANDWIDTH={rendition.bandwidth},"
            f'AVERAGE-BANDWIDTH={rendition.average_bandwidth},CODECS="{rendition.codecs}",'
            f"RESOLUTION={rendition.width}x{rendition.height}{group}"
        )
        master.append("media/index.m3u8")
        _write_atomic(base / "master.m3u8", ("\n".join(master) + "\n").encode())

    async def run(self, download_id: str, *, stop_after_items: int | None = None) -> OfflineResult:
        """Download (or continue downloading) until complete, paused or interrupted.

        ``stop_after_items`` simulates an interruption after N newly fetched items."""
        state = self.load_state(download_id)
        base = self.directory(download_id)
        total_items, total_bytes = state["total_items"], state["total_bytes"]

        def result(
            status: Status, done: int, size: int, fetched: int, reused: int, detail: str = ""
        ) -> OfflineResult:
            state["status"] = status
            self._save_state(state)
            return OfflineResult(status, done, total_items, size, total_bytes, fetched, reused, detail)

        try:
            info = await self._remote(state)
        except ControlError as exc:
            if exc.status in (404, 410):
                return result("revoked", 0, 0, 0, 0, exc.code)
            return result("interrupted", 0, 0, 0, 0, exc.code)
        if info["state"] == "paused":
            return result("paused", info["reported_items"], info["reported_bytes"], 0, 0)
        if info["state"] not in ("active", "completed"):
            return result("revoked", 0, 0, 0, 0, info["state"])

        manifest = await self._manifest(state)
        segments, subs = manifest.offline_items(state["rendition_id"], state["subtitle_languages"])
        token_box = {
            "token": (info.get("origin") or {}).get("token", ""),
            "base": (info.get("origin") or {}).get("base_url", ""),
        }
        if info["state"] == "active" and not token_box["token"]:
            return result("interrupted", 0, 0, 0, 0, "no origin token")
        origin = HttpOriginAdapter(
            base_url=token_box["base"] or "http://origin.invalid",
            token_provider=lambda: token_box["token"],
            clock=self._clock,
            client=self._origin_http,
        )
        refreshed_at = self._clock.now()

        async def refresh() -> str:
            nonlocal refreshed_at
            fresh = await self._remote(state)
            if fresh.get("origin"):
                token_box["token"] = fresh["origin"]["token"]
            refreshed_at = self._clock.now()
            return str(fresh["state"])

        items: list[tuple[str, Path, int, str, SegmentDescriptor | None]] = [
            (s.segment_id, base / "media" / self._segment_name(s), s.byte_length, s.content_hash, s)
            for s in segments
        ] + [(t.track_id, base / "subs" / f"{t.language}.vtt", t.byte_length, t.sha256, None) for t in subs]
        done = size = fetched = reused = 0
        try:
            for item_id, path, length, sha256, descriptor in items:
                existing = await asyncio.to_thread(_sha256_file, path)
                if existing == sha256:
                    done, size, reused = done + 1, size + length, reused + 1
                    continue  # already present and verified: resume skips it
                if info["state"] == "completed":
                    return result(
                        "failed", done, size, fetched, reused,
                        "local copy is incomplete or damaged; start a new download",
                    )  # fmt: skip
                if stop_after_items is not None and fetched >= stop_after_items:
                    await self._report(state, done, size, None)
                    return result("interrupted", done, size, fetched, reused, "stopped by caller")
                if self._clock.now() - refreshed_at > 60:
                    await refresh()
                data: bytes | None = None
                for attempt in (1, 2):
                    try:
                        if descriptor is not None:
                            data = await origin.fetch_segment(descriptor)
                        else:
                            data = await origin.fetch_subtitle(item_id)
                        break
                    except OriginError as exc:
                        if exc.kind == "paused":
                            await self._report(state, done, size, None, tolerate=True)
                            return result("paused", done, size, fetched, reused)
                        if exc.kind == "denied" and attempt == 1:
                            remote_state = await refresh()  # token may simply have expired
                            if remote_state == "active":
                                continue
                            status: Status = "paused" if remote_state == "paused" else "revoked"
                            return result(status, done, size, fetched, reused, remote_state)
                        return result("interrupted", done, size, fetched, reused, str(exc))
                assert data is not None
                try:
                    if descriptor is not None:
                        verify_segment(descriptor, data, source="origin")
                    elif len(data) != length or hashlib.sha256(data).hexdigest() != sha256:
                        raise IntegrityError("hash_mismatch", f"{item_id}: subtitle does not match manifest")
                except IntegrityError as exc:
                    return result("failed", done, size, fetched, reused, f"verification failed: {exc}")
                await asyncio.to_thread(_write_atomic, path, data)
                done, size, fetched = done + 1, size + length, fetched + 1
                if self._throttle:
                    await self._clock.sleep(length / self._throttle)
                if fetched % 5 == 0:
                    await self._report(state, done, size, None, tolerate=True)
        finally:
            await origin.close()

        # Verified completion: recompute the digest from the files on disk.
        digest = hashlib.sha256()
        for _item_id, path, _length, sha256, _descriptor in items:
            if await asyncio.to_thread(_sha256_file, path) != sha256:
                return result("failed", done, size, fetched, reused, "post-download verification failed")
        for seg in segments:
            digest.update(bytes.fromhex(seg.content_hash))
        for sub in sorted(subs, key=lambda s: s.language):
            digest.update(bytes.fromhex(sub.sha256))
        self._write_playlists(base, manifest, state["rendition_id"], subs)
        try:
            await self._report(state, done, size, digest.hexdigest())
        except ControlError as exc:
            return result("failed", done, size, fetched, reused, f"completion rejected: {exc.code}")
        return result("completed", done, size, fetched, reused)

    async def _report(
        self, state: dict[str, Any], items: int, size: int, digest: str | None, *, tolerate: bool = False
    ) -> None:
        try:
            await self._control.request(
                "POST", f"/v1/offline-downloads/{state['download_id']}/progress", token=state["token"],
                json={"items_completed": items, "bytes_completed": size, "completion_digest": digest},
            )  # fmt: skip
        except ControlError:
            if not tolerate:
                raise
