"""Offline downloads (server side): authorisation, state machine and limits.

The server authorises a download, decides exactly what it contains (one rendition,
its initialisation segment, selected subtitles), enforces pause/resume/delete on the
delivery path it controls, and tracks self-reported progress. The bytes are pulled
by the client-side :class:`aureom_stream.offline.downloader.OfflineDownloader`.

Limits of what this can promise: release 1 stores plaintext media. Once a segment has
been downloaded, neither expiring credentials nor "deleting" the download on the
server can take it back. Revocable commercial offline licences need a separate
content-protection (DRM) system, which is out of scope here.
"""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..access.service import AccessService
from ..access.tokens import AUD_ORIGIN, TYP_ORIGIN
from ..bootstrap import AppContext
from ..clock import to_datetime
from ..domain import Principal
from ..errors import Conflict, Gone, NotFound, QuotaExceeded, ValidationFailed
from ..ids import hash_token, new_id, new_secret_token, token_matches
from ..manifests.version_manifest import VersionManifest
from ..persistence.models import (
    AssetVersion,
    DownloadState,
    MediaSegment,
    OfflineDownload,
    Rendition,
    SubtitleTrack,
)

OFFLINE_NOTICE = (
    "Offline copies in this release are unencrypted. Deleting or expiring a download "
    "stops further delivery but cannot revoke bytes already saved on a device."
)
_LIVE = (DownloadState.ACTIVE.value, DownloadState.PAUSED.value, DownloadState.COMPLETED.value)


class OfflineService:
    def __init__(self, ctx: AppContext, session: AsyncSession) -> None:
        self._ctx = ctx
        self._db = session
        self._s = ctx.settings
        self.access = AccessService(session, ctx.clock)

    async def storage_used(self, principal_id: str) -> int:
        used = await self._db.scalar(
            select(func.coalesce(func.sum(OfflineDownload.total_bytes), 0)).where(
                OfflineDownload.principal_id == principal_id, OfflineDownload.state.in_(_LIVE)
            )
        )
        return int(used or 0)

    async def create(
        self,
        principal: Principal,
        *,
        asset_version_id: str,
        rendition_id: str | None,
        max_height: int | None,
        subtitle_languages: list[str],
    ) -> tuple[OfflineDownload, str]:
        # Offline permission is checked separately from (and in addition to) viewing.
        grant = await self.access.authorise_offline(principal, asset_version_id)
        version = await self._db.get(AssetVersion, asset_version_id)
        assert version is not None and version.manifest_jws is not None
        renditions = list(
            await self._db.scalars(select(Rendition).where(Rendition.asset_version_id == asset_version_id))
        )
        if rendition_id is not None:
            chosen = next((r for r in renditions if r.id == rendition_id), None)
            if chosen is None:
                raise ValidationFailed("unknown rendition for this version", code="unknown_rendition")
        else:
            fitting = [r for r in renditions if max_height is None or r.height <= max_height]
            chosen = (
                max(fitting, key=lambda r: r.bandwidth)
                if fitting
                else min(renditions, key=lambda r: r.height)
            )
        tracks = list(
            await self._db.scalars(
                select(SubtitleTrack).where(SubtitleTrack.asset_version_id == asset_version_id)
            )
        )
        by_language = {t.language: t for t in tracks}
        unknown = [lang for lang in subtitle_languages if lang not in by_language]
        if unknown:
            raise ValidationFailed(
                f"no subtitle track for: {', '.join(sorted(unknown))}", code="unknown_subtitle"
            )
        segment_bytes, segment_count = (
            await self._db.execute(
                select(func.coalesce(func.sum(MediaSegment.byte_length), 0), func.count()).where(
                    MediaSegment.rendition_id == chosen.id
                )
            )
        ).one()
        selected = sorted(set(subtitle_languages))
        total_bytes = int(segment_bytes) + sum(by_language[lang].byte_length for lang in selected)
        used = await self.storage_used(principal.id)
        if used + total_bytes > self._s.offline_quota_bytes:
            raise QuotaExceeded(
                "offline storage limit exceeded",
                code="offline_storage_limit_exceeded",
                quota_bytes=self._s.offline_quota_bytes,
                used_bytes=used,
                required_bytes=total_bytes,
            )
        manifest = VersionManifest.model_validate_json(
            self._ctx.tokens.verify_jws(version.manifest_jws, typ="aureom-manifest+jws")
        )
        now = self._ctx.clock.now()
        token = new_secret_token()
        download = OfflineDownload(
            id=new_id("odl"),
            principal_id=principal.id,
            asset_id=grant.asset_id,
            asset_version_id=asset_version_id,
            rendition_id=chosen.id,
            subtitle_languages=selected,
            token_hash=hash_token(token),
            state=DownloadState.ACTIVE.value,
            total_bytes=total_bytes,
            total_items=int(segment_count) + len(selected),
            expected_digest=manifest.offline_digest(chosen.id, selected),
            reported_bytes=0,
            reported_items=0,
            completion_digest_matches=False,
            created_at=to_datetime(now),
            updated_at=to_datetime(now),
            expires_at=to_datetime(now + self._s.offline_download_ttl_seconds),
        )
        self._db.add(download)
        await self._db.flush()
        return download, token

    async def load(self, download_id: str, *, principal: Principal, token: str | None) -> OfflineDownload:
        download = await self._db.get(OfflineDownload, download_id)
        if download is None:
            raise NotFound("offline download not found")
        by_owner = not principal.anonymous and principal.id == download.principal_id
        by_token = token is not None and token_matches(token, download.token_hash)
        if not (by_owner or by_token):
            raise NotFound("offline download not found")
        now = to_datetime(self._ctx.clock.now())
        if download.state in (DownloadState.ACTIVE.value, DownloadState.PAUSED.value):
            if download.expires_at <= now:
                download.state = DownloadState.EXPIRED.value
                download.updated_at = now
        return download

    def _require(self, download: OfflineDownload, *states: DownloadState) -> None:
        if download.state == DownloadState.REVOKED.value:
            raise Gone("this version has been withdrawn", code="withdrawn")
        if download.state in (DownloadState.DELETED.value, DownloadState.EXPIRED.value):
            raise Gone(f"offline download {download.state}", code="download_" + download.state)
        if download.state not in {s.value for s in states}:
            raise Conflict(f"offline download is {download.state}", code="invalid_state")

    async def pause(self, download: OfflineDownload) -> OfflineDownload:
        if download.state == DownloadState.PAUSED.value:
            return download
        self._require(download, DownloadState.ACTIVE)
        download.state = DownloadState.PAUSED.value
        download.updated_at = to_datetime(self._ctx.clock.now())
        return download

    async def resume(self, download: OfflineDownload, principal: Principal) -> OfflineDownload:
        if download.state == DownloadState.ACTIVE.value:
            return download
        self._require(download, DownloadState.PAUSED)
        # Rights may have changed while paused: re-authorise before delivering more.
        if not principal.anonymous:
            await self.access.authorise_offline(principal, download.asset_version_id)
        download.state = DownloadState.ACTIVE.value
        download.updated_at = to_datetime(self._ctx.clock.now())
        return download

    async def delete(self, download: OfflineDownload) -> OfflineDownload:
        if download.state != DownloadState.DELETED.value:
            now = to_datetime(self._ctx.clock.now())
            download.state = DownloadState.DELETED.value
            download.deleted_at = now
            download.updated_at = now
        return download

    async def report_progress(
        self,
        download: OfflineDownload,
        *,
        items: int,
        bytes_done: int,
        completion_digest: str | None,
    ) -> OfflineDownload:
        if download.state == DownloadState.COMPLETED.value:
            return download
        self._require(download, DownloadState.ACTIVE, DownloadState.PAUSED)
        if items > download.total_items or bytes_done > download.total_bytes:
            raise ValidationFailed("progress exceeds the download size", code="invalid_progress")
        download.reported_items = items
        download.reported_bytes = bytes_done
        download.updated_at = to_datetime(self._ctx.clock.now())
        if completion_digest is not None:
            # The client says it verified every item against the signed manifest and
            # sends the digest over the verified hashes. We check it is consistent.
            if (
                completion_digest != download.expected_digest
                or items != download.total_items
                or bytes_done != download.total_bytes
            ):
                raise Conflict("completion digest does not match the manifest", code="completion_mismatch")
            download.completion_digest_matches = True
            download.state = DownloadState.COMPLETED.value
            download.completed_at = download.updated_at
        return download

    def origin_token(self, download: OfflineDownload) -> tuple[str, float]:
        ttl = self._s.origin_token_ttl_seconds
        token = self._ctx.tokens.sign(
            {"sub": download.principal_id, "ver": download.asset_version_id, "dl": download.id},
            typ=TYP_ORIGIN,
            audience=AUD_ORIGIN,
            ttl=ttl,
        )
        return token, self._ctx.clock.now() + ttl

    async def signed_manifest(self, download: OfflineDownload) -> str:
        version = await self._db.get(AssetVersion, download.asset_version_id)
        assert version is not None and version.manifest_jws is not None
        return version.manifest_jws
