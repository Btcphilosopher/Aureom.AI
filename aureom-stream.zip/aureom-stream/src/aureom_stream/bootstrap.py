"""Wiring: build the shared :class:`AppContext` from settings.

Clocks, storage, coordination and signing keys are injected here, so tests can
substitute fakes for any of them.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from .access.tokens import TokenService, TokenVerifier, load_or_create_signing_key
from .clock import Clock, SystemClock
from .config import Settings
from .observability.metrics import ServerMetrics
from .persistence.coordination import Coordination, InMemoryCoordination, RedisCoordination
from .persistence.db import Database
from .persistence.object_store import LocalObjectStore, ObjectStore, S3ObjectStore


@dataclass
class AppContext:
    settings: Settings
    clock: Clock
    db: Database
    store: ObjectStore
    tokens: TokenService
    principal_verifier: TokenVerifier
    coord: Coordination
    metrics: ServerMetrics

    async def close(self) -> None:
        await self.coord.close()
        await self.db.dispose()


def build_store(settings: Settings) -> ObjectStore:
    if settings.storage_backend == "s3":
        return S3ObjectStore(
            bucket=settings.s3_bucket,
            endpoint_url=settings.s3_endpoint_url,
            region=settings.s3_region,
            access_key_id=(
                settings.s3_access_key_id.get_secret_value() if settings.s3_access_key_id else None
            ),
            secret_access_key=(
                settings.s3_secret_access_key.get_secret_value() if settings.s3_secret_access_key else None
            ),
        )
    return LocalObjectStore(settings.storage_local_root)


def build_context(
    settings: Settings,
    *,
    clock: Clock | None = None,
    db: Database | None = None,
    store: ObjectStore | None = None,
    coord: Coordination | None = None,
    tokens: TokenService | None = None,
) -> AppContext:
    clock = clock or SystemClock()
    if tokens is None:
        key = load_or_create_signing_key(settings.signing_key_path, create=settings.env != "prod")
        tokens = TokenService(key, issuer=settings.issuer, clock=clock)
    principal_verifier = TokenVerifier(dict(tokens._keys), issuer=settings.issuer, clock=clock)
    if settings.principal_jwks_path is not None:
        principal_verifier.add_jwks(json.loads(settings.principal_jwks_path.read_text()))
    if coord is None:
        coord = RedisCoordination(settings.redis_url) if settings.redis_url else InMemoryCoordination(clock)
    return AppContext(
        settings=settings,
        clock=clock,
        db=db or Database(settings.database_url),
        store=store or build_store(settings),
        tokens=tokens,
        principal_verifier=principal_verifier,
        coord=coord,
        metrics=ServerMetrics(),
    )
