"""Resumable uploads with bounded chunks.

Clients upload fixed-size parts through the API; they never receive storage
credentials or object keys. Every part is hashed, duplicate parts are idempotent,
conflicting contents are rejected, and the first part must actually look like an
allowed container regardless of the filename or declared content type.
"""

from __future__ import annotations

import hashlib
import math
import re
from collections.abc import AsyncIterator
from dataclasses import dataclass

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError as SAIntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from ..access.service import SCOPE_UPLOAD
from ..bootstrap import AppContext
from ..clock import to_datetime
from ..domain import Principal
from ..errors import (
    Conflict,
    Forbidden,
    Gone,
    NotFound,
    PayloadTooLarge,
    QuotaExceeded,
    UnsupportedMedia,
    ValidationFailed,
)
from ..ids import new_id
from ..persistence.models import AssetVersion, SourceUpload, UploadPart, UploadState, Visibility
from ..persistence.object_store import ObjectExists
from .sniff import ALLOWED, sniff_container

_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_OPEN = (UploadState.INITIATED.value, UploadState.UPLOADING.value)


@dataclass(frozen=True)
class UploadRequest:
    filename: str
    content_type: str
    size_bytes: int
    visibility: str
    idempotency_key: str


@dataclass(frozen=True)
class PartResult:
    part: UploadPart
    duplicate: bool


def clean_filename(name: str) -> str:
    """Keep a display name only. It is never used to build a path or a command."""
    base = name.replace("\\", "/").rsplit("/", 1)[-1]
    base = "".join(ch for ch in base if ch.isprintable()).strip()
    if not base or base in {".", ".."}:
        raise ValidationFailed("filename is empty after sanitising", code="invalid_filename")
    return base[:255]


def part_key(upload_id: str, part_number: int) -> str:
    return f"uploads/{upload_id}/parts/{part_number:05d}"


def original_key(upload_id: str) -> str:
    return f"originals/{upload_id}/source"


class UploadService:
    def __init__(self, ctx: AppContext, session: AsyncSession) -> None:
        self._ctx = ctx
        self._db = session
        self._s = ctx.settings

    # ------------------------------------------------------------------ helpers
    def expected_part_size(self, upload: SourceUpload, part_number: int) -> int:
        if part_number == upload.part_count:
            return upload.declared_size_bytes - (upload.part_count - 1) * upload.part_size_bytes
        return upload.part_size_bytes

    async def _load(self, principal: Principal, upload_id: str) -> SourceUpload:
        upload = await self._db.get(SourceUpload, upload_id)
        if upload is None or (upload.owner_id != principal.id and not principal.has_scope("admin")):
            raise NotFound("upload not found")
        return upload

    async def _check_open(self, upload: SourceUpload) -> None:
        if upload.state in _OPEN and to_datetime(self._ctx.clock.now()) >= upload.expires_at:
            await self._discard(upload, UploadState.EXPIRED)
            await self._db.commit()
        if upload.state == UploadState.EXPIRED.value:
            raise Gone("upload expired; create a new upload", code="upload_expired")
        if upload.state == UploadState.ABORTED.value:
            raise Gone("upload was aborted", code="upload_aborted")

    async def _discard(self, upload: SourceUpload, state: UploadState) -> None:
        await self._ctx.store.delete_prefix(f"uploads/{upload.id}")
        upload.state = state.value

    async def parts(self, upload_id: str) -> list[UploadPart]:
        rows = await self._db.scalars(
            select(UploadPart).where(UploadPart.upload_id == upload_id).order_by(UploadPart.part_number)
        )
        return list(rows)

    async def quota_used(self, owner_id: str) -> int:
        used = await self._db.scalar(
            select(func.coalesce(func.sum(SourceUpload.declared_size_bytes), 0)).where(
                SourceUpload.owner_id == owner_id,
                SourceUpload.state.in_([*_OPEN, UploadState.COMPLETED.value]),
            )
        )
        return int(used or 0)

    # ------------------------------------------------------------------ operations
    async def create(self, principal: Principal, req: UploadRequest) -> tuple[SourceUpload, bool]:
        """Returns ``(upload, created)``. Replays of the same idempotency key return the
        original upload; the same key with different parameters is a conflict."""
        if principal.anonymous or not principal.has_scope(SCOPE_UPLOAD):
            raise Forbidden("the media:upload permission is required", code="upload_not_permitted")
        filename = clean_filename(req.filename)
        if req.size_bytes > self._s.upload_max_bytes:
            raise PayloadTooLarge(
                f"size exceeds the {self._s.upload_max_bytes}-byte upload limit",
                code="upload_too_large",
            )
        existing = await self._db.scalar(
            select(SourceUpload).where(
                SourceUpload.owner_id == principal.id,
                SourceUpload.idempotency_key == req.idempotency_key,
            )
        )
        if existing is not None:
            same = (
                existing.filename == filename
                and existing.declared_size_bytes == req.size_bytes
                and existing.declared_content_type == req.content_type
                and existing.visibility == req.visibility
            )
            if not same:
                raise Conflict(
                    "idempotency key was already used with different parameters",
                    code="idempotency_conflict",
                )
            return existing, False

        used = await self.quota_used(principal.id)
        if used + req.size_bytes > self._s.upload_quota_bytes:
            raise QuotaExceeded(
                "upload quota exhausted",
                quota_bytes=self._s.upload_quota_bytes,
                used_bytes=used,
            )
        now = self._ctx.clock.now()
        upload = SourceUpload(
            id=new_id("upl"),
            owner_id=principal.id,
            filename=filename,
            declared_content_type=req.content_type,
            declared_size_bytes=req.size_bytes,
            visibility=Visibility(req.visibility).value,
            idempotency_key=req.idempotency_key,
            part_size_bytes=self._s.upload_part_size_bytes,
            part_count=max(1, math.ceil(req.size_bytes / self._s.upload_part_size_bytes)),
            state=UploadState.INITIATED.value,
            created_at=to_datetime(now),
            expires_at=to_datetime(now + self._s.upload_ttl_seconds),
        )
        self._db.add(upload)
        try:
            await self._db.flush()
        except SAIntegrityError:  # concurrent create with the same key
            await self._db.rollback()
            return await self.create(principal, req)
        return upload, True

    async def get(self, principal: Principal, upload_id: str) -> tuple[SourceUpload, list[UploadPart]]:
        upload = await self._load(principal, upload_id)
        if upload.state in _OPEN and to_datetime(self._ctx.clock.now()) >= upload.expires_at:
            await self._discard(upload, UploadState.EXPIRED)
        return upload, await self.parts(upload_id)

    async def put_part(
        self,
        principal: Principal,
        upload_id: str,
        part_number: int,
        body: AsyncIterator[bytes],
        *,
        content_length: int | None,
        declared_sha256: str | None,
    ) -> PartResult:
        upload = await self._load(principal, upload_id)
        await self._check_open(upload)
        if upload.state == UploadState.COMPLETED.value:
            raise Conflict("upload is already completed", code="upload_completed")
        if not 1 <= part_number <= upload.part_count:
            raise ValidationFailed(
                f"part_number must be between 1 and {upload.part_count}", code="invalid_part_number"
            )
        if declared_sha256 is not None and not _HEX64.match(declared_sha256):
            raise ValidationFailed("X-Content-SHA256 must be 64 hex characters", code="invalid_digest")
        expected = self.expected_part_size(upload, part_number)
        if content_length is not None and content_length != expected:
            status = PayloadTooLarge if content_length > expected else ValidationFailed
            raise status(f"part {part_number} must be exactly {expected} bytes", code="wrong_part_size")

        # Bounded read: never buffer more than one part, whatever the client sends.
        buffer = bytearray()
        async for chunk in body:
            buffer.extend(chunk)
            if len(buffer) > expected:
                raise PayloadTooLarge(
                    f"part {part_number} must be exactly {expected} bytes", code="wrong_part_size"
                )
        if len(buffer) != expected:
            raise ValidationFailed(
                f"part {part_number} must be exactly {expected} bytes, got {len(buffer)}",
                code="wrong_part_size",
            )
        data = bytes(buffer)
        digest = hashlib.sha256(data).hexdigest()
        if declared_sha256 is not None and declared_sha256 != digest:
            raise ValidationFailed("part digest does not match its bytes", code="digest_mismatch")

        existing = await self._db.get(UploadPart, (upload_id, part_number))
        if existing is not None:
            if existing.sha256 == digest:
                return PartResult(existing, duplicate=True)  # retry of an acknowledged part
            raise Conflict(
                f"part {part_number} was already uploaded with different contents",
                code="part_conflict",
            )

        if part_number == 1:
            container = sniff_container(data[:64])
            if container is None:
                raise UnsupportedMedia(
                    "the uploaded bytes are not a supported media container "
                    f"({', '.join(c.name for c in ALLOWED)}); the filename and declared "
                    "content type are not trusted",
                    code="unsupported_container",
                )
            upload.sniffed_container = container.name

        key = part_key(upload_id, part_number)
        try:
            await self._ctx.store.put(key, data, if_absent=True)
        except ObjectExists:
            # Bytes stored by a request that never recorded the part (crash) or by a
            # concurrent identical retry. Unacknowledged bytes may be replaced.
            if hashlib.sha256(await self._ctx.store.get(key)).hexdigest() != digest:
                await self._ctx.store.put(key, data)
        part = UploadPart(
            upload_id=upload_id,
            part_number=part_number,
            size_bytes=len(data),
            sha256=digest,
            storage_reference=key,
            created_at=to_datetime(self._ctx.clock.now()),
        )
        self._db.add(part)
        upload.state = UploadState.UPLOADING.value
        try:
            await self._db.flush()
        except SAIntegrityError:
            await self._db.rollback()
            winner = await self._db.get(UploadPart, (upload_id, part_number))
            if winner is not None and winner.sha256 == digest:
                return PartResult(winner, duplicate=True)
            raise Conflict(
                f"part {part_number} was already uploaded with different contents",
                code="part_conflict",
            ) from None
        self._ctx.metrics.upload_bytes.inc(len(data))
        return PartResult(part, duplicate=False)

    async def complete(
        self, principal: Principal, upload_id: str, expected_sha256: str | None = None
    ) -> SourceUpload:
        upload = await self._load(principal, upload_id)
        await self._check_open(upload)
        if upload.state == UploadState.COMPLETED.value:
            if expected_sha256 and expected_sha256 != upload.sha256:
                raise Conflict("completed upload has a different digest", code="digest_mismatch")
            return upload  # idempotent
        parts = await self.parts(upload_id)
        have = {p.part_number for p in parts}
        missing = [n for n in range(1, upload.part_count + 1) if n not in have]
        if missing:
            raise Conflict("upload is incomplete", code="incomplete_upload", missing_parts=missing[:1000])
        lock_key = f"upload-complete:{upload_id}"
        if not await self._ctx.coord.acquire_slot(lock_key, "lock", 1, 300):
            raise Conflict("completion already in progress", code="completion_in_progress")
        try:
            result = await self._ctx.store.compose(
                original_key(upload_id), [p.storage_reference for p in parts]
            )
            if result.size != upload.declared_size_bytes:
                await self._ctx.store.delete(original_key(upload_id))
                raise Conflict("assembled size differs from declared size", code="size_mismatch")
            if expected_sha256 and expected_sha256 != result.sha256:
                await self._ctx.store.delete(original_key(upload_id))
                raise ValidationFailed("assembled file digest does not match", code="digest_mismatch")
            upload.storage_reference = original_key(upload_id)
            upload.sha256 = result.sha256
            upload.state = UploadState.COMPLETED.value
            upload.completed_at = to_datetime(self._ctx.clock.now())
            await self._db.flush()
            await self._ctx.store.delete_prefix(f"uploads/{upload_id}")
        finally:
            await self._ctx.coord.release_slot(lock_key, "lock")
        return upload

    async def abort(self, principal: Principal, upload_id: str) -> SourceUpload:
        upload = await self._load(principal, upload_id)
        if upload.state == UploadState.COMPLETED.value:
            bound = await self._db.scalar(
                select(AssetVersion.id).where(AssetVersion.source_upload_id == upload_id)
            )
            if bound is not None:
                raise Conflict("upload is already attached to an asset version", code="upload_in_use")
            await self._ctx.store.delete(original_key(upload_id))
        await self._discard(upload, UploadState.ABORTED)
        return upload

    async def expire_abandoned(self) -> int:
        """Janitor: release storage and quota held by uploads that were never finished."""
        now = to_datetime(self._ctx.clock.now())
        rows = await self._db.scalars(
            select(SourceUpload).where(SourceUpload.state.in_(_OPEN), SourceUpload.expires_at <= now)
        )
        count = 0
        for upload in rows:
            await self._discard(upload, UploadState.EXPIRED)
            count += 1
        return count
