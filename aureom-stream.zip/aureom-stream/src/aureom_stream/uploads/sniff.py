"""Container detection from actual bytes.

The declared ``content_type`` and the filename are recorded for display but are never
trusted. Only containers on this allow-list are accepted, and the detected container
decides which FFmpeg demuxer is forced later - so a text playlist (HLS, concat, ...)
renamed to ``.mp4`` can never make FFmpeg open other files or URLs.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Container:
    name: str
    ffmpeg_demuxer: str


MP4 = Container("mp4", "mov,mp4,m4a,3gp,3g2,mj2")
MATROSKA = Container("matroska", "matroska,webm")

ALLOWED = (MP4, MATROSKA)
_MP4_BOXES = {b"ftyp", b"styp", b"moov", b"free", b"skip", b"wide", b"mdat"}


def sniff_container(head: bytes) -> Container | None:
    """Return the detected container for the first bytes of a file, or None."""
    if len(head) >= 12:
        box_type = head[4:8]
        size = int.from_bytes(head[0:4], "big")
        if box_type == b"ftyp" and (size == 1 or 8 <= size <= 4096):
            return MP4
        if box_type in _MP4_BOXES and box_type != b"ftyp" and size >= 8 and head[8:12].isascii():
            # QuickTime files may start with moov/wide/mdat; require a second sane box check
            # by the validating stage (ffprobe with the forced demuxer).
            return MP4
    if head[:4] == b"\x1a\x45\xdf\xa3":  # EBML
        return MATROSKA
    return None


def looks_like_webvtt(data: bytes) -> bool:
    text = data[:16].lstrip(b"\xef\xbb\xbf")
    return text.startswith(b"WEBVTT") and (len(text) == 6 or text[6:7] in b" \t\r\n")
