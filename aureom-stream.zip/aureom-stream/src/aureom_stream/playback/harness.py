"""A minimal *simulated* player.

It requests segments according to a playback clock, exactly as a player would pull
them, and measures startup delay, stalls (deadline misses) and where bytes came from.
It does **not** decode or render anything: results from this harness are simulated
playback and are labelled as such. Decoding of the delivered media is checked
separately with FFmpeg (see the offline download check in the demo).
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any

from ..clock import Clock
from ..domain import DeliveryObservation, SegmentDescriptor
from ..manifests.version_manifest import VersionManifest
from ..observability.metrics import DeliveryMetrics
from ..scheduler.scheduler import (
    ClientPlaybackSession,
    SegmentScheduler,
    SegmentUnavailable,
    TransferCancelled,
    plan_window,
)
from .adapter import FixedRendition, PlaybackAdapter


@dataclass
class PlaybackScript:
    speed: float = 1.0  # media seconds per clock second
    tick_seconds: float = 0.1
    seeks: list[tuple[float, float]] = field(default_factory=list)  # (after N clock s, to position)
    stop_after_seconds: float | None = None  # stop early (clock seconds)
    stop_at_position: float | None = None
    max_stall_seconds: float = 30.0


@dataclass
class PlaybackReport:
    kind: str  # always "simulated"
    completed: bool
    reason: str
    final_position: float
    duration: float
    wall_seconds: float
    startup_delay_seconds: float | None
    stalls: int
    stall_seconds: float
    seeks: int
    renditions_used: list[str]
    metrics: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


class SimulatedPlayer:
    def __init__(
        self,
        *,
        clock: Clock,
        scheduler: SegmentScheduler,
        session: ClientPlaybackSession,
        manifest: VersionManifest,
        adapter: PlaybackAdapter | None = None,
        script: PlaybackScript | None = None,
        metrics: DeliveryMetrics | None = None,
    ) -> None:
        self._clock = clock
        self._scheduler = scheduler
        self._session = session
        self._manifest = manifest
        self._adapter = adapter or FixedRendition()
        self._script = script or PlaybackScript()
        self.metrics = metrics or scheduler.metrics
        self._timelines = {
            r.rendition_id: manifest.media_segments(r.rendition_id) for r in manifest.renditions
        }
        self._buffered: dict[int, str] = {}  # timeline index -> rendition id delivered
        self._inits: set[str] = set()
        self._tasks: dict[tuple[str, int], asyncio.Future[Any]] = {}
        self._fatal: str | None = None
        self.position = 0.0

    def observe(self, observation: DeliveryObservation) -> None:
        """Hook this up as the scheduler's observer to feed the ABR adapter."""
        self._adapter.observe(observation)

    # ------------------------------------------------------------------ fetching
    def _index_at(self, timeline: list[SegmentDescriptor], position: float) -> int:
        for index, seg in enumerate(timeline):
            if seg.start_time <= position < seg.end_time:
                return index
        return len(timeline) - 1

    async def _fetch(self, key: tuple[str, int], segment: SegmentDescriptor, deadline: float) -> None:
        try:
            await self._scheduler.fetch(self._session, segment, deadline)
        except TransferCancelled:
            return
        except SegmentUnavailable as exc:
            self._fatal = str(exc)
            return
        if segment.kind == "init":
            self._inits.add(segment.rendition_id)
        else:
            self._buffered[key[1]] = segment.rendition_id

    def _request(self, rendition_id: str, playing: bool) -> None:
        now = self._clock.now()
        speed = self._script.speed
        if rendition_id not in self._inits and (rendition_id, -1) not in self._tasks:
            init = self._manifest.init_segment(rendition_id)
            self._tasks[(rendition_id, -1)] = asyncio.ensure_future(
                self._fetch((rendition_id, -1), init, now)
            )
        timeline = self._timelines[rendition_id]
        have = {timeline[i].segment_id for i in self._buffered}
        for seg in plan_window(timeline, playhead=self.position, limits=self._session.limits, have=have):
            index = seg.sequence_number - timeline[0].sequence_number
            if index in self._buffered or any(k[1] == index for k in self._tasks):
                continue
            # Deadline: the moment the playhead reaches the segment (now, if it is
            # the segment playback is waiting for).
            ahead = max(0.0, seg.start_time - self.position)
            deadline = now + (ahead / speed if playing or ahead > 0 else 0.0)
            self._tasks[(rendition_id, index)] = asyncio.ensure_future(
                self._fetch((rendition_id, index), seg, deadline)
            )

    def _reap(self) -> None:
        for key in [k for k, t in self._tasks.items() if t.done()]:
            task = self._tasks.pop(key)
            if not task.cancelled() and task.exception() is not None:
                self._fatal = self._fatal or repr(task.exception())

    def _buffer_ahead(self, timeline: list[SegmentDescriptor]) -> float:
        index = self._index_at(timeline, self.position)
        end = self.position
        while index < len(timeline) and index in self._buffered:
            end = timeline[index].end_time
            index += 1
        return max(0.0, end - self.position)

    # ------------------------------------------------------------------ main loop
    async def run(self) -> PlaybackReport:
        script = self._script
        clock = self._clock
        started = clock.now()
        duration = self._manifest.duration_seconds
        renditions = list(self._manifest.renditions)
        current = self._adapter.select(renditions, None)
        self._session.selected_rendition_id = current
        used = [current]
        pending_seeks = sorted(script.seeks)
        playing = False
        waiting_since = started
        first_frame: float | None = None
        stalls = 0
        stall_seconds = 0.0
        seeks_done = 0
        reason = "ended"
        last_tick = started
        try:
            while True:
                now = clock.now()
                elapsed = now - started
                dt, last_tick = now - last_tick, now
                # 1. scripted seeks
                while pending_seeks and elapsed >= pending_seeks[0][0]:
                    _, target = pending_seeks.pop(0)
                    target = min(max(0.0, target), max(0.0, duration - 0.001))
                    self.position = target
                    seeks_done += 1
                    cancelled = self._scheduler.seek(self._session, target)
                    self.metrics.event("seek", to=target, cancelled=cancelled)
                    if playing:
                        playing = False
                        waiting_since = now
                    await asyncio.sleep(0)  # let cancelled transfers unwind
                self._reap()
                timeline = self._timelines[current]
                # 2. advance the playhead through buffered media only
                if playing:
                    target = self.position + dt * script.speed
                    limit = self.position + self._buffer_ahead(timeline)
                    if target >= duration - 1e-6 and limit >= duration - 1e-6:
                        self.position = duration
                        break
                    if target > limit + 1e-9:
                        self.position = limit
                        playing = False  # the next segment missed its deadline
                        waiting_since = now
                        stalls += 1
                        self.metrics.deadline_misses += 1
                        self.metrics.event("stall", position=round(self.position, 3))
                    else:
                        self.position = target
                # 3. rendition choice for what we request next (the adapter decides)
                choice = self._adapter.select(renditions, current)
                if choice != current:
                    current = choice
                    self._session.selected_rendition_id = current
                    used.append(current)
                    timeline = self._timelines[current]
                self._session.playhead = self.position
                self._session.buffer_seconds = self._buffer_ahead(timeline)
                # 4. request the bounded window
                self._request(current, playing)
                # 5. (re)start once the init segment and the current segment are in
                if not playing:
                    index = self._index_at(timeline, self.position)
                    ready = index in self._buffered and self._buffered[index] in self._inits
                    if ready:
                        playing = True
                        if first_frame is None:
                            first_frame = now - started
                            self.metrics.startup_delay_seconds = round(first_frame, 4)
                        else:
                            stall_seconds += now - waiting_since
                    elif now - waiting_since > script.max_stall_seconds or self._fatal:
                        reason = "unavailable" if self._fatal else "stalled"
                        break
                if script.stop_after_seconds is not None and elapsed >= script.stop_after_seconds:
                    reason = "stopped"
                    break
                if script.stop_at_position is not None and self.position >= script.stop_at_position:
                    reason = "stopped"
                    break
                await clock.sleep(script.tick_seconds)
        finally:
            for task in self._tasks.values():
                task.cancel()
            await asyncio.gather(*self._tasks.values(), return_exceptions=True)
        self.metrics.stall_seconds += stall_seconds
        return PlaybackReport(
            kind="simulated",
            completed=reason == "ended",
            reason=reason if not self._fatal else f"{reason}: {self._fatal}",
            final_position=round(self.position, 3),
            duration=duration,
            wall_seconds=round(clock.now() - started, 3),
            startup_delay_seconds=None if first_frame is None else round(first_frame, 4),
            stalls=stalls,
            stall_seconds=round(stall_seconds, 3),
            seeks=seeks_done,
            renditions_used=used,
            metrics=self.metrics.snapshot(),
        )
