"""Playback sessions: short-lived, per-viewer authorisation to stream one version."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..access.service import AccessService
from ..access.tokens import AUD_ORIGIN, TYP_ORIGIN
from ..bootstrap import AppContext
from ..clock import to_datetime
from ..domain import ANONYMOUS, PlaybackGrant, Principal
from ..errors import Gone, NotFound, RateLimited, Unauthenticated, ValidationFailed
from ..ids import hash_token, new_id, new_secret_token, token_matches
from ..persistence.models import (
    Asset,
    AssetVersion,
    MediaSegment,
    PlaybackSession,
    Publication,
    Rendition,
    SessionState,
    SubtitleTrack,
    VersionState,
)

PEER_PRIVACY_NOTICE = (
    "Peer delivery connects you directly to other authorised viewers. They can see your "
    "network address and you can see theirs. Transport encryption protects the content "
    "of the connection; it does not make participation anonymous."
)


@dataclass(frozen=True)
class ClientCapabilities:
    supported_codecs: list[str]
    max_height: int | None
    peer_delivery: bool


@dataclass(frozen=True)
class CreatedSession:
    session: PlaybackSession
    token: str
    grant: PlaybackGrant
    renditions: list[Rendition]
    notices: list[str]


def compatible_renditions(renditions: list[Rendition], caps: ClientCapabilities) -> list[Rendition]:
    supported = {c.split(".")[0].lower() for c in caps.supported_codecs}
    usable = [r for r in renditions if not supported or r.codecs.split(",")[0].split(".")[0] in supported]
    if not usable:
        return []
    if caps.max_height is not None:
        within = [r for r in usable if r.height <= caps.max_height]
        # Nothing small enough: offer the smallest rather than refusing playback.
        usable = within or [min(usable, key=lambda r: r.height)]
    return sorted(usable, key=lambda r: -r.bandwidth)


class PlaybackService:
    def __init__(self, ctx: AppContext, session: AsyncSession) -> None:
        self._ctx = ctx
        self._db = session
        self._s = ctx.settings
        self.access = AccessService(session, ctx.clock, grant_ttl=ctx.settings.origin_token_ttl_seconds)

    async def _resolve_version(self, principal: Principal, asset_id: str, version_id: str | None) -> str:
        if version_id is not None:
            version = await self._db.get(AssetVersion, version_id)
            if version is None or version.asset_id != asset_id:
                raise NotFound("asset version not found")
            return version_id
        latest = await self._db.scalar(
            select(AssetVersion.id)
            .join(Publication, Publication.asset_version_id == AssetVersion.id)
            .where(
                AssetVersion.asset_id == asset_id,
                AssetVersion.state == VersionState.PUBLISHED.value,
                Publication.withdrawn_at.is_(None),
            )
            .order_by(AssetVersion.version_number.desc())
            .limit(1)
        )
        if latest is None:
            asset = await self._db.get(Asset, asset_id)
            if asset is not None and await self.access.can_manage(principal, asset):
                raise ValidationFailed(
                    "no published version; pass version_id to preview a version under review",
                    code="no_published_version",
                )
            raise NotFound("asset not found")
        return latest

    async def create(
        self,
        principal: Principal,
        *,
        asset_id: str,
        version_id: str | None,
        capabilities: ClientCapabilities,
        peer_contribution_enabled: bool,
        client_key: str,
    ) -> CreatedSession:
        rate_key = f"pbs-create:{'ip:' + client_key if principal.anonymous else principal.id}"
        if not await self._ctx.coord.hit(rate_key, 120, 60):
            raise RateLimited("too many playback sessions requested")
        resolved = await self._resolve_version(principal, asset_id, version_id)
        grant = await self.access.authorise_playback(principal, resolved)  # raises if not allowed
        now = self._ctx.clock.now()
        if not principal.anonymous:
            active = await self._db.scalar(
                select(func.count())
                .select_from(PlaybackSession)
                .where(
                    PlaybackSession.principal_id == principal.id,
                    PlaybackSession.state == SessionState.ACTIVE.value,
                    PlaybackSession.expires_at > to_datetime(now),
                )
            )
            if int(active or 0) >= self._s.max_sessions_per_principal:
                raise RateLimited("too many concurrent playback sessions", code="too_many_sessions")
        all_renditions = list(
            await self._db.scalars(select(Rendition).where(Rendition.asset_version_id == resolved))
        )
        renditions = compatible_renditions(all_renditions, capabilities)
        if not renditions:
            raise ValidationFailed(
                "no rendition matches the client's codec capabilities",
                code="no_compatible_rendition",
            )
        modes = ["origin"]
        notices: list[str] = []
        if grant.peer_delivery and capabilities.peer_delivery:
            modes.append("peer")
            notices.append(PEER_PRIVACY_NOTICE)
        contribute = peer_contribution_enabled and grant.may_contribute and "peer" in modes
        if peer_contribution_enabled and not contribute:
            notices.append("Peer contribution was requested but is not permitted for this session.")
        token = new_secret_token()
        session = PlaybackSession(
            id=new_id("pbs"),
            principal_id=principal.id,
            asset_id=grant.asset_id,
            asset_version_id=grant.asset_version_id,
            token_hash=hash_token(token),
            state=SessionState.ACTIVE.value,
            rendition_ids=[r.id for r in renditions],
            delivery_modes=modes,
            peer_contribution=contribute,
            preview=grant.preview,
            client_capabilities={
                "supported_codecs": capabilities.supported_codecs,
                "max_height": capabilities.max_height,
                "peer_delivery": capabilities.peer_delivery,
            },
            created_at=to_datetime(now),
            last_heartbeat_at=to_datetime(now),
            expires_at=to_datetime(now + self._s.playback_session_ttl_seconds),
            hard_expires_at=to_datetime(now + self._s.playback_session_max_lifetime_seconds),
        )
        self._db.add(session)
        await self._db.flush()
        return CreatedSession(session, token, grant, renditions, notices)

    # ------------------------------------------------------------------ authentication
    async def authenticate(
        self, session_id: str, *, session_token: str | None, principal: Principal = ANONYMOUS
    ) -> PlaybackSession:
        """Accept the session's own token, or the owning (non-anonymous) principal."""
        session = await self._db.get(PlaybackSession, session_id)
        if session is None:
            raise NotFound("playback session not found")
        by_token = session_token is not None and token_matches(session_token, session.token_hash)
        by_owner = not principal.anonymous and principal.id == session.principal_id
        if not (by_token or by_owner):
            if session_token is None and principal.anonymous:
                raise Unauthenticated("a session token is required")
            raise NotFound("playback session not found")
        return session

    async def require_active(self, session: PlaybackSession) -> PlaybackSession:
        now = to_datetime(self._ctx.clock.now())
        if session.state == SessionState.ACTIVE.value and session.expires_at <= now:
            session.state = SessionState.EXPIRED.value
            session.ended_at = now
            await self._db.commit()
        if session.state == SessionState.REVOKED.value:
            raise Gone("this version has been withdrawn", code="withdrawn")
        if session.state != SessionState.ACTIVE.value:
            raise Gone(f"playback session {session.state}", code="session_" + session.state)
        return session

    # ------------------------------------------------------------------ lifecycle
    async def heartbeat(self, session: PlaybackSession, *, position_seconds: float | None) -> PlaybackSession:
        await self.require_active(session)
        now = self._ctx.clock.now()
        new_expiry = min(now + self._s.playback_session_ttl_seconds, session.hard_expires_at.timestamp())
        session.last_heartbeat_at = to_datetime(now)
        session.expires_at = to_datetime(new_expiry)
        if position_seconds is not None:
            session.position_seconds = position_seconds
        return session

    async def end(self, session: PlaybackSession) -> None:
        if session.state == SessionState.ACTIVE.value:
            session.state = SessionState.ENDED.value
            session.ended_at = to_datetime(self._ctx.clock.now())

    def origin_token(self, session: PlaybackSession) -> tuple[str, float]:
        ttl = self._s.origin_token_ttl_seconds
        claims: dict[str, Any] = {
            "sub": session.principal_id,
            "ver": session.asset_version_id,
            "sid": session.id,
        }
        if session.preview:
            claims["pv"] = True
        token = self._ctx.tokens.sign(claims, typ=TYP_ORIGIN, audience=AUD_ORIGIN, ttl=ttl)
        return token, self._ctx.clock.now() + ttl

    # ------------------------------------------------------------------ media lookups
    async def renditions(self, session: PlaybackSession) -> list[Rendition]:
        rows = await self._db.scalars(select(Rendition).where(Rendition.id.in_(session.rendition_ids)))
        return sorted(rows, key=lambda r: -r.bandwidth)

    async def subtitles(self, session: PlaybackSession) -> list[SubtitleTrack]:
        rows = await self._db.scalars(
            select(SubtitleTrack).where(SubtitleTrack.asset_version_id == session.asset_version_id)
        )
        return sorted(rows, key=lambda s: s.language)

    async def rendition_segments(self, session: PlaybackSession, rendition_id: str) -> list[MediaSegment]:
        if rendition_id not in session.rendition_ids:
            raise NotFound("rendition not found")
        rows = await self._db.scalars(
            select(MediaSegment)
            .where(MediaSegment.rendition_id == rendition_id)
            .order_by(MediaSegment.sequence_number)
        )
        return list(rows)

    async def visibility(self, session: PlaybackSession) -> str:
        publication = await self._db.scalar(
            select(Publication).where(Publication.asset_version_id == session.asset_version_id)
        )
        return publication.visibility if publication is not None else "private"

    async def signed_manifest(self, session: PlaybackSession) -> str:
        version = await self._db.get(AssetVersion, session.asset_version_id)
        if version is None or not version.manifest_jws:
            raise NotFound("no sealed manifest (previews are origin-only)", code="no_manifest")
        return version.manifest_jws
