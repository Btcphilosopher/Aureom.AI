"""Playback adapters: where adaptive-bitrate decisions live.

The transfer scheduler only *reports* delivery observations. Choosing a rendition is
the player's job (hls.js, AVPlayer, ExoPlayer ...) or, for the simulated player in
this repository, one of these small adapters.
"""

from __future__ import annotations

from typing import Protocol

from ..domain import DeliveryObservation
from ..manifests.version_manifest import ManifestRendition


class PlaybackAdapter(Protocol):
    def observe(self, observation: DeliveryObservation) -> None: ...

    def select(self, renditions: list[ManifestRendition], current: str | None) -> str: ...


class FixedRendition:
    """Always the same rendition (or the best available when none is named)."""

    def __init__(self, rendition_id: str | None = None) -> None:
        self._rendition_id = rendition_id

    def observe(self, observation: DeliveryObservation) -> None:
        return None

    def select(self, renditions: list[ManifestRendition], current: str | None) -> str:
        if self._rendition_id is not None:
            return self._rendition_id
        return max(renditions, key=lambda r: r.bandwidth).rendition_id


class ThroughputAbr:
    """Conservative throughput rule: start low, then use the best rendition whose peak
    bitrate fits inside ``safety`` x the smoothed measured throughput."""

    def __init__(self, *, safety: float = 0.7, alpha: float = 0.4) -> None:
        self._safety = safety
        self._alpha = alpha
        self.estimate_bps: float | None = None
        self.switches = 0

    def observe(self, observation: DeliveryObservation) -> None:
        if observation.source == "cache" or observation.throughput_bps <= 0:
            return
        if self.estimate_bps is None:
            self.estimate_bps = observation.throughput_bps
        else:
            self.estimate_bps += self._alpha * (observation.throughput_bps - self.estimate_bps)

    def select(self, renditions: list[ManifestRendition], current: str | None) -> str:
        ordered = sorted(renditions, key=lambda r: r.bandwidth)
        choice = ordered[0]
        if self.estimate_bps is not None:
            for rendition in ordered:
                if rendition.bandwidth <= self.estimate_bps * self._safety:
                    choice = rendition
        if current is not None and choice.rendition_id != current:
            self.switches += 1
        return choice.rendition_id
