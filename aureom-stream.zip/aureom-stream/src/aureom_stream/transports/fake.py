"""Deterministic in-memory doubles for the delivery layer (tests and simulations only).

They run on an injected clock, so latency, timeouts, slow peers, corruption and
disconnects can be scripted exactly. Nothing here is used in the real delivery path.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from ..clock import Clock
from ..domain import (
    PeerCandidate,
    ReceiptReport,
    SegmentDescriptor,
    TransferGrantToken,
)
from ..origin.client import OriginError
from .base import TransportError

Behaviour = Literal["ok", "corrupt", "truncate", "hang", "refuse", "not_found", "offline"]


@dataclass
class FakePeer:
    peer_id: str
    segments: dict[str, bytes] = field(default_factory=dict)
    latency: float = 0.02
    bytes_per_second: float = 10_000_000.0
    behaviour: Behaviour = "ok"
    reliability: float = 1.0
    calls: list[str] = field(default_factory=list)

    def candidate(self, wanted: list[str]) -> PeerCandidate:
        return PeerCandidate(
            peer_id=self.peer_id,
            host="127.0.0.1",
            port=1,
            transport="fake",
            segment_ids=frozenset(s for s in wanted if s in self.segments),
            reliability=self.reliability,
        )


class FakePeerTransport:
    name = "fake"

    def __init__(self, clock: Clock, peers: list[FakePeer] | None = None) -> None:
        self._clock = clock
        self.peers = {p.peer_id: p for p in peers or []}
        self.cancelled: list[tuple[str, str]] = []

    async def fetch_segment(
        self,
        peer: PeerCandidate,
        segment: SegmentDescriptor,
        grant: TransferGrantToken,
        *,
        timeout: float,
    ) -> bytes:
        fake = self.peers[peer.peer_id]
        fake.calls.append(segment.segment_id)
        try:
            if fake.behaviour == "offline":
                await self._clock.sleep(min(0.01, timeout))
                raise TransportError("unreachable", "connection refused")
            if fake.behaviour == "hang":
                await self._clock.sleep(timeout)
                raise TransportError("timeout", "peer transfer timed out")
            if fake.behaviour == "refuse":
                await self._clock.sleep(fake.latency)
                raise TransportError("refused", "peer refused")
            data = fake.segments.get(segment.segment_id)
            if data is None or fake.behaviour == "not_found":
                await self._clock.sleep(fake.latency)
                raise TransportError("not_found", "peer does not have the segment")
            duration = fake.latency + len(data) / fake.bytes_per_second
            if duration > timeout:
                await self._clock.sleep(timeout)
                raise TransportError("timeout", "peer transfer timed out")
            await self._clock.sleep(duration)
            if fake.behaviour == "truncate":
                raise TransportError("length_mismatch", "peer sent too few bytes")
            if fake.behaviour == "corrupt":
                return bytes([data[0] ^ 0xFF]) + data[1:]
            return data
        except BaseException as exc:
            if not isinstance(exc, (TransportError, Exception)):
                self.cancelled.append((peer.peer_id, segment.segment_id))
            raise

    async def close(self) -> None:
        return None


class FakeOrigin:
    def __init__(
        self,
        clock: Clock,
        data: dict[str, bytes],
        *,
        latency: float = 0.05,
        bytes_per_second: float = 5_000_000.0,
    ) -> None:
        self._clock = clock
        self.data = data
        self.latency = latency
        self.bytes_per_second = bytes_per_second
        self.online = True
        self.fail_next = 0
        self.calls: list[str] = []
        self.cancelled: list[str] = []

    @property
    def healthy(self) -> bool:
        return self.online

    async def fetch_segment(self, segment: SegmentDescriptor) -> bytes:
        self.calls.append(segment.segment_id)
        try:
            await self._clock.sleep(self.latency + segment.byte_length / self.bytes_per_second)
        except BaseException:
            self.cancelled.append(segment.segment_id)
            raise
        if not self.online:
            raise OriginError("unavailable", "origin unreachable")
        if self.fail_next > 0:
            self.fail_next -= 1
            raise OriginError("unavailable", "origin error 503", 503)
        return self.data[segment.segment_id]


class FakeDirectory:
    """Stands in for the registry: discovery, grants and receipts."""

    def __init__(self, clock: Clock, transport: FakePeerTransport, *, latency: float = 0.005) -> None:
        self._clock = clock
        self._transport = transport
        self.latency = latency
        self.receipts: list[ReceiptReport] = []
        self.discover_calls: list[list[str]] = []
        self.deny_grants = False
        self._counter = 0

    async def discover(self, segment_ids: list[str]) -> list[PeerCandidate]:
        self.discover_calls.append(list(segment_ids))
        await self._clock.sleep(self.latency)
        candidates = [p.candidate(segment_ids) for p in self._transport.peers.values()]
        return [c for c in candidates if c.segment_ids]

    async def authorise_transfer(self, peer: PeerCandidate, segment_ids: list[str]) -> TransferGrantToken:
        await self._clock.sleep(self.latency)
        if self.deny_grants:
            raise PermissionError("grant denied")
        self._counter += 1
        return TransferGrantToken(
            grant_id=f"grant-{self._counter}",
            token="fake",
            serving_peer_id=peer.peer_id,
            segment_ids=frozenset(segment_ids),
            expires_at=self._clock.now() + 30,
        )

    async def report_receipt(self, receipt: ReceiptReport) -> None:
        self.receipts.append(receipt)
