"""The replaceable peer transfer interface.

Everything above this interface (scheduler, peer agent, registry) is independent of
how bytes travel between two peers. Release 1 ships:

* ``loopback-http`` - plain HTTP/1.1 on loopback addresses only. A local test aid.
  It is **not** a secure peer-to-peer transport and refuses non-loopback hosts.
* ``mtls-http`` - HTTPS with mutual TLS (TLS 1.2+/1.3 via the platform TLS stack),
  server-certificate pinning from the registry and RFC 8705 certificate-bound grants.

Both use maintained HTTP engines (httpx to fetch, aiohttp to serve) and standard
protocols only; there is no home-made handshake or cipher. Other engines (QUIC, a WebRTC data-channel adapter
for browsers, libtorrent in private-swarm mode) can be added behind the same
protocol without touching the scheduler.
"""

from __future__ import annotations

from typing import Literal, Protocol

from ..domain import PeerCandidate, SegmentDescriptor, TransferGrantToken

TransportFailure = Literal["timeout", "refused", "not_found", "length_mismatch", "unreachable", "error"]


class TransportError(Exception):
    def __init__(self, reason: TransportFailure, detail: str = "") -> None:
        super().__init__(detail or reason)
        self.reason: TransportFailure = reason


class PeerTransport(Protocol):
    name: str

    async def fetch_segment(
        self,
        peer: PeerCandidate,
        segment: SegmentDescriptor,
        grant: TransferGrantToken,
        *,
        timeout: float,
    ) -> bytes:
        """Fetch one segment from ``peer``. Returns *unverified* bytes of exactly the
        expected length or raises :class:`TransportError`. Integrity is checked by the
        caller against the authenticated manifest - never trusted from the peer."""
        ...

    async def close(self) -> None: ...
