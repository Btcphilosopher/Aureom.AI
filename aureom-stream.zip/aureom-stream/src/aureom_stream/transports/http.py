"""HTTP peer transports (httpx client side; peers serve with aiohttp): loopback-only
plain HTTP and mutual TLS."""

from __future__ import annotations

import asyncio
import hashlib
import ipaddress
import ssl
from pathlib import Path

import httpx

from ..domain import PeerCandidate, SegmentDescriptor, TransferGrantToken
from .base import TransportError

SEGMENT_PATH = "/peer/v1/segments/{segment_id}"


def _is_loopback(host: str) -> bool:
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


class _HttpPeerTransport:
    name = "http"
    scheme = "http"

    def __init__(self) -> None:
        self._http: httpx.AsyncClient | None = None

    def _verify(self) -> ssl.SSLContext | bool:
        return False  # plain HTTP: nothing to verify (loopback only)

    def _client(self) -> httpx.AsyncClient:
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(
                verify=self._verify(),
                trust_env=False,  # never route peer traffic through a proxy from the environment
                follow_redirects=False,
                limits=httpx.Limits(max_connections=32, max_keepalive_connections=8),
            )
        return self._http

    def _check_peer(self, peer: PeerCandidate) -> None:
        if peer.transport != self.name:
            raise TransportError("refused", f"peer speaks {peer.transport}, not {self.name}")

    def _check_connection(self, peer: PeerCandidate, response: httpx.Response) -> None:
        return None

    async def fetch_segment(
        self,
        peer: PeerCandidate,
        segment: SegmentDescriptor,
        grant: TransferGrantToken,
        *,
        timeout: float,
    ) -> bytes:
        self._check_peer(peer)
        host = f"[{peer.host}]" if ":" in peer.host else peer.host
        url = f"{self.scheme}://{host}:{peer.port}" + SEGMENT_PATH.format(segment_id=segment.segment_id)
        expected = segment.byte_length
        try:
            async with asyncio.timeout(timeout):
                async with self._client().stream(
                    "GET",
                    url,
                    headers={"Authorization": f"Bearer {grant.token}", "Accept-Encoding": "identity"},
                    timeout=httpx.Timeout(timeout, connect=min(timeout, 3.0)),
                ) as response:
                    self._check_connection(peer, response)
                    if response.status_code == 404:
                        raise TransportError("not_found", "peer does not have the segment")
                    if response.status_code in (401, 403, 429, 503):
                        raise TransportError("refused", f"peer refused with {response.status_code}")
                    if response.status_code != 200:
                        raise TransportError("error", f"unexpected status {response.status_code}")
                    declared = response.headers.get("Content-Length")
                    if declared is not None and declared != str(expected):
                        raise TransportError(
                            "length_mismatch", f"peer announced {declared} bytes, expected {expected}"
                        )
                    body = bytearray()
                    async for chunk in response.aiter_raw(64 * 1024):
                        body.extend(chunk)
                        if len(body) > expected:  # never buffer more than the manifest allows
                            raise TransportError("length_mismatch", "peer sent too many bytes")
                    if len(body) != expected:
                        raise TransportError("length_mismatch", "peer sent too few bytes")
                    return bytes(body)
        except TransportError:
            raise
        except (TimeoutError, httpx.TimeoutException) as exc:
            raise TransportError("timeout", "peer transfer timed out") from exc
        except httpx.ConnectError as exc:
            if isinstance(exc.__cause__, ssl.SSLError) or "SSL" in str(exc) or "CERTIFICATE" in str(exc):
                raise TransportError("refused", "TLS authentication with the peer failed") from exc
            raise TransportError("unreachable", "could not connect to peer") from exc
        except httpx.RemoteProtocolError as exc:
            raise TransportError("length_mismatch", "peer closed the stream early") from exc
        except (httpx.HTTPError, ssl.SSLError, OSError) as exc:
            raise TransportError("error", type(exc).__name__) from exc

    async def close(self) -> None:
        if self._http is not None and not self._http.is_closed:
            await self._http.aclose()


class LoopbackHttpTransport(_HttpPeerTransport):
    """Plain HTTP for local testing. Refuses to talk to anything but loopback."""

    name = "loopback-http"
    scheme = "http"

    def _check_peer(self, peer: PeerCandidate) -> None:
        super()._check_peer(peer)
        if not _is_loopback(peer.host):
            raise TransportError(
                "refused", "loopback-http is a local test transport and is not used off-host"
            )


def cert_thumbprint_hex(der: bytes) -> str:
    return hashlib.sha256(der).hexdigest()


def certificate_thumbprint(cert_pem_path: Path) -> str:
    """SHA-256 thumbprint (hex) of a PEM certificate, as registered with the registry."""
    return cert_thumbprint_hex(ssl.PEM_cert_to_DER_cert(cert_pem_path.read_text()))


def client_ssl_context(*, ca_path: Path, cert_path: Path, key_path: Path) -> ssl.SSLContext:
    """TLS client context that presents our certificate and trusts only the peer CA.

    Hostname checking is replaced by something stronger for this use: the registry
    tells us the exact certificate (SHA-256 thumbprint) each peer registered with, and
    :class:`MutualTlsHttpTransport` pins it."""
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=str(ca_path))
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.check_hostname = False
    context.verify_mode = ssl.CERT_REQUIRED
    context.load_cert_chain(str(cert_path), str(key_path))
    return context


def server_ssl_context(*, ca_path: Path, cert_path: Path, key_path: Path) -> ssl.SSLContext:
    """TLS server context that *requires* a client certificate issued by the peer CA."""
    context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH, cafile=str(ca_path))
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.verify_mode = ssl.CERT_REQUIRED
    context.load_cert_chain(str(cert_path), str(key_path))
    return context


class MutualTlsHttpTransport(_HttpPeerTransport):
    """HTTPS with mutual TLS and certificate pinning. The transport for remote peers."""

    name = "mtls-http"
    scheme = "https"

    def __init__(self, ssl_context: ssl.SSLContext) -> None:
        super().__init__()
        self._ssl = ssl_context

    def _verify(self) -> ssl.SSLContext | bool:
        return self._ssl

    def _check_peer(self, peer: PeerCandidate) -> None:
        super()._check_peer(peer)
        if not peer.cert_thumbprint:
            raise TransportError("refused", "registry supplied no certificate thumbprint")

    def _check_connection(self, peer: PeerCandidate, response: httpx.Response) -> None:
        # httpx exposes the TLS session of the connection that produced this response.
        stream = response.extensions.get("network_stream")
        ssl_object = stream.get_extra_info("ssl_object") if stream is not None else None
        der = ssl_object.getpeercert(binary_form=True) if ssl_object is not None else None
        if der is None or cert_thumbprint_hex(der) != peer.cert_thumbprint:
            raise TransportError("refused", "peer certificate does not match the registry")
