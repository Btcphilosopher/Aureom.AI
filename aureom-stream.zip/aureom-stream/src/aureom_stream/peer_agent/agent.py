"""The server-side Python peer agent.

One agent process:

* registers with the controlled registry (never a public DHT or tracker), and only for
  asset versions its user holds an authorised playback session for;
* keeps a bounded cache of *verified* segments and announces only those;
* fetches through the :class:`SegmentScheduler` (peers first where time allows,
  origin fallback before the deadline, everything verified against the signed manifest);
* serves authorised requests: a valid, unexpired, unreplayed transfer grant addressed
  to this peer, for a segment of the granted version, within upload limits;
* stops contributing when paused, on a metered network, or when the player closes
  (unless the user explicitly enabled the background agent).

This is a native agent. Browsers cannot accept inbound connections, so browser peer
delivery needs a browser-compatible adapter (WebRTC data channels) implementing the
same ``PeerTransport`` contract - this agent does not provide browser-native P2P.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import ssl
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
from aiohttp import web

from ..access.tokens import TYP_TRANSFER, TokenError, TokenVerifier
from ..clock import Clock, SystemClock
from ..discovery.registry import thumbprint_to_cnf
from ..domain import VerifiedSegment
from ..manifests.version_manifest import VersionManifest, verify_manifest
from ..observability.metrics import DeliveryMetrics
from ..origin.client import HttpOriginAdapter
from ..playback.adapter import FixedRendition, PlaybackAdapter, ThroughputAbr
from ..playback.harness import PlaybackReport, PlaybackScript, SimulatedPlayer
from ..scheduler.scheduler import ClientPlaybackSession, SchedulerLimits, SegmentScheduler
from ..transports.base import PeerTransport
from ..transports.http import (
    LoopbackHttpTransport,
    MutualTlsHttpTransport,
    cert_thumbprint_hex,
    certificate_thumbprint,
    client_ssl_context,
    server_ssl_context,
)
from .cache import CacheEntry, SegmentCache
from .control import ControlClient, ControlError, HttpPeerDirectory
from .limiter import GrantLedger, TokenBucket

logger = logging.getLogger("aureom.peer_agent")
CHUNK = 16 * 1024


@dataclass
class ContributionSettings:
    """User-controlled. Contribution is off unless explicitly enabled."""

    enabled: bool = False
    upload_kbps_cap: int | None = None  # kilobits per second; None = no cap
    cache_bytes_cap: int = 256 * 1024 * 1024
    metered: bool = False  # the current network is metered
    allow_on_metered: bool = False
    paused: bool = False
    background_agent: bool = False  # keep contributing after the player closes
    max_concurrent_uploads: int = 4

    @property
    def restricted_by_metering(self) -> bool:
        return self.metered and not self.allow_on_metered

    @property
    def active(self) -> bool:
        return self.enabled and not self.paused and not self.restricted_by_metering


@dataclass
class TlsFiles:
    ca: Path
    cert: Path
    key: Path


@dataclass
class AgentConfig:
    control_url: str
    cache_dir: Path
    name: str = "agent"
    issuer: str = "aureom-stream"
    listen_host: str = "127.0.0.1"
    listen_port: int = 0
    advertise_host: str | None = None
    cache_ttl_seconds: float = 3600.0
    tls: TlsFiles | None = None  # None -> loopback-only plain HTTP (testing)
    contribution: ContributionSettings = field(default_factory=ContributionSettings)
    limits: SchedulerLimits = field(default_factory=SchedulerLimits)
    tick_seconds: float = 0.5
    enable_fault_injection: bool = False


@dataclass
class AgentSession:
    session_id: str
    session_token: str
    asset_id: str
    version_id: str
    manifest: VersionManifest
    client: ClientPlaybackSession
    scheduler: SegmentScheduler
    origin: HttpOriginAdapter
    metrics: DeliveryMetrics
    origin_token: str
    heartbeat_interval: float
    peer_session_id: str | None = None
    peer_token: str | None = None
    peer_heartbeat_interval: float = 5.0
    contribute: bool = False
    closed: bool = False
    closed_reason: str | None = None
    position: float = 0.0
    next_heartbeat: float = 0.0
    next_peer_heartbeat: float = 0.0
    announce: set[str] = field(default_factory=set)
    withdraw: set[str] = field(default_factory=set)
    availability_limit: int = 512


class PeerAgent:
    def __init__(
        self,
        config: AgentConfig,
        *,
        clock: Clock | None = None,
        control_http: httpx.AsyncClient | None = None,
        origin_http: httpx.AsyncClient | None = None,
    ) -> None:
        self.config = config
        self.clock = clock or SystemClock()
        self.contribution = config.contribution
        self.control = ControlClient(config.control_url, client=control_http)
        self._origin_http = origin_http
        self.cache = SegmentCache(
            config.cache_dir,
            max_bytes=self.contribution.cache_bytes_cap,
            clock=self.clock,
            ttl_seconds=config.cache_ttl_seconds,
            on_evict=self._evicted,
        )
        rate = self._rate_bytes(self.contribution.upload_kbps_cap)
        self.bucket = TokenBucket(self.clock, rate=rate)
        self.ledger = GrantLedger(self.clock)
        self.sessions: dict[str, AgentSession] = {}
        self.verifier: TokenVerifier | None = None
        self.port = config.listen_port
        self.thumbprint: str | None = None
        self.transport: PeerTransport
        self._server_ssl: ssl.SSLContext | None = None
        if config.tls is not None:
            tls = config.tls
            self.thumbprint = certificate_thumbprint(tls.cert)
            self.transport = MutualTlsHttpTransport(
                client_ssl_context(ca_path=tls.ca, cert_path=tls.cert, key_path=tls.key)
            )
            self._server_ssl = server_ssl_context(ca_path=tls.ca, cert_path=tls.cert, key_path=tls.key)
        else:
            self.transport = LoopbackHttpTransport()
        self._runner: web.AppRunner | None = None
        self._loop_task: asyncio.Task[None] | None = None
        self._active_uploads = 0
        self.served_bytes = 0  # bytes of completely served segments
        self.sent_bytes = 0  # every byte written to a peer, including abandoned transfers
        self.served_segments = 0
        self.refused: dict[str, int] = {}
        self.upload_windows: list[tuple[float, float, int]] = []  # (start, end, bytes)
        self.faults: dict[str, bool] = {"corrupt": False, "suspend_heartbeats": False}
        self._background: set[asyncio.Future[Any]] = set()

    # ------------------------------------------------------------------ lifecycle
    @staticmethod
    def _rate_bytes(kbps: int | None) -> float | None:
        return None if kbps is None else kbps * 1000 / 8

    async def start(self) -> None:
        if self.config.tls is None and self.config.listen_host not in ("127.0.0.1", "::1", "localhost"):
            raise ValueError(
                "without TLS the peer agent only listens on loopback; configure mutual TLS "
                "for any other interface"
            )
        self.verifier = TokenVerifier.from_jwks(
            await self.control.jwks(), issuer=self.config.issuer, clock=self.clock
        )
        app = web.Application(client_max_size=4096)
        app.router.add_get("/peer/v1/segments/{segment_id:[a-z0-9_]{1,64}}", self._serve_segment)
        app.router.add_get("/peer/v1/health", self._health)
        self._runner = web.AppRunner(app, access_log=None)
        await self._runner.setup()
        site = web.TCPSite(
            self._runner, self.config.listen_host, self.config.listen_port, ssl_context=self._server_ssl
        )
        await site.start()
        addresses = self._runner.addresses
        self.port = int(addresses[0][1]) if addresses else self.config.listen_port
        self._loop_task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        """Process exit: always leave every swarm and end every session."""
        if self._loop_task is not None:
            self._loop_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._loop_task
        for session in list(self.sessions.values()):
            await self.close_session(session, reason="agent_stopped")
        if self._background:
            await asyncio.gather(*list(self._background), return_exceptions=True)
        if self._runner is not None:
            await self._runner.cleanup()
        await self.transport.close()
        await self.control.close()

    def _spawn(self, coro: Any) -> None:
        task = asyncio.ensure_future(coro)
        self._background.add(task)
        task.add_done_callback(self._background.discard)

    # ------------------------------------------------------------------ sessions
    async def open_session(
        self,
        principal_token: str | None,
        asset_id: str,
        *,
        version_id: str | None = None,
        peer_delivery: bool = True,
        max_height: int | None = None,
    ) -> AgentSession:
        assert self.verifier is not None, "call start() first"
        info = await self.control.create_playback_session(
            principal_token, asset_id=asset_id, version_id=version_id, peer_delivery=peer_delivery,
            contribute=self.contribution.enabled, max_height=max_height,
        )  # fmt: skip
        token = info["session_token"]
        jws = await self.control.signed_manifest(info["signed_manifest_url"], token)
        # Authenticate the manifest and pin it to the version we were authorised for.
        manifest = verify_manifest(self.verifier, jws, expected_version_id=info["version_id"])
        metrics = DeliveryMetrics()
        session_ref: list[AgentSession] = []
        origin = HttpOriginAdapter(
            base_url=info["origin"]["base_url"],
            token_provider=lambda: session_ref[0].origin_token,
            clock=self.clock,
            client=self._origin_http,
        )
        peers_on = "peer" in info["delivery_modes"]
        peer_info: dict[str, Any] | None = None
        if peers_on:
            peer_info = await self.control.request(
                "POST", "/v1/peer-sessions", token=token,
                json={
                    "playback_session_id": info["session_id"],
                    "endpoint": {
                        "host": self.config.advertise_host or self.config.listen_host,
                        "port": self.port,
                    },
                    "transport": self.transport.name,
                    "cert_thumbprint": self.thumbprint,
                    "contribution": {
                        "enabled": self.contribution.enabled and info["peer_contribution_enabled"],
                        "upload_kbps_cap": self.contribution.upload_kbps_cap,
                        "metered": self.contribution.restricted_by_metering,
                    },
                },
            )  # fmt: skip
        directory = (
            HttpPeerDirectory(
                self.control, peer_session_id=peer_info["peer_session_id"], peer_token=peer_info["peer_token"]
            )
            if peer_info
            else None
        )
        client = ClientPlaybackSession(
            session_id=info["session_id"],
            asset_version_id=info["version_id"],
            peer_delivery=peers_on,
            limits=self.config.limits,
        )
        scheduler = SegmentScheduler(
            clock=self.clock,
            origin=origin,
            directory=directory,
            transports={self.transport.name: self.transport} if peers_on else {},
            store=self.cache,
            metrics=metrics,
            on_verified=self._stored,
        )
        now = self.clock.now()
        session = AgentSession(
            session_id=info["session_id"],
            session_token=token,
            asset_id=info["asset_id"],
            version_id=info["version_id"],
            manifest=manifest,
            client=client,
            scheduler=scheduler,
            origin=origin,
            metrics=metrics,
            origin_token=info["origin"]["token"],
            heartbeat_interval=float(info["heartbeat_interval_seconds"]),
            next_heartbeat=now + float(info["heartbeat_interval_seconds"]),
        )
        session_ref.append(session)
        if peer_info:
            session.peer_session_id = peer_info["peer_session_id"]
            session.peer_token = peer_info["peer_token"]
            session.contribute = bool(peer_info["contribute"])
            session.peer_heartbeat_interval = float(peer_info["heartbeat_interval_seconds"])
            session.next_peer_heartbeat = now + session.peer_heartbeat_interval
            session.availability_limit = int(peer_info["limits"]["availability_ids_per_message"])
            if session.contribute:
                # Verified segments already cached for this version may be offered too.
                session.announce.update(self.cache.segment_ids(session.version_id))
        self.sessions[session.session_id] = session
        return session

    async def play(
        self,
        session: AgentSession,
        *,
        script: PlaybackScript | None = None,
        rendition: str = "best",
    ) -> PlaybackReport:
        """Simulated playback (no decoding) driven by a playback clock."""
        renditions = session.manifest.renditions
        adapter: PlaybackAdapter
        if rendition == "abr":
            adapter = ThroughputAbr()
        elif rendition == "lowest":
            adapter = FixedRendition(min(renditions, key=lambda r: r.bandwidth).rendition_id)
        elif rendition == "best":
            adapter = FixedRendition()
        else:
            adapter = FixedRendition(rendition)
        player = SimulatedPlayer(
            clock=self.clock, scheduler=session.scheduler, session=session.client,
            manifest=session.manifest, adapter=adapter, script=script, metrics=session.metrics,
        )  # fmt: skip
        session.scheduler._observer = player.observe

        async def track() -> None:
            while True:
                session.position = player.position
                await self.clock.sleep(0.25)

        tracker = asyncio.ensure_future(track())
        try:
            report = await player.run()
        finally:
            tracker.cancel()
        await session.scheduler.drain()
        await self._flush_availability(session)
        # The player has closed. Without an explicitly enabled background agent,
        # contribution ends here: no silent, lingering seeding.
        if not self.contribution.background_agent:
            await self.close_session(session, reason="player_closed")
        return report

    async def close_session(self, session: AgentSession, *, reason: str, remote: bool = True) -> None:
        if session.closed:
            return
        session.closed = True
        session.closed_reason = reason
        self.sessions.pop(session.session_id, None)
        session.scheduler.close_session(session.client)
        if remote:
            with contextlib.suppress(ControlError):
                if session.peer_session_id and session.peer_token:
                    await self.control.request(
                        "DELETE", f"/v1/peer-sessions/{session.peer_session_id}", token=session.peer_token
                    )
            with contextlib.suppress(ControlError):
                await self.control.request(
                    "DELETE", f"/v1/playback-sessions/{session.session_id}", token=session.session_token
                )
        await session.origin.close()
        # Cached material goes with the last session that justified keeping it.
        if not any(s.version_id == session.version_id for s in self.sessions.values()):
            purged = self.cache.purge_version(session.version_id)
            logger.info("purged %d cached segments of %s (%s)", purged, session.version_id, reason)

    # ------------------------------------------------------------------ contribution
    async def set_contribution(
        self,
        *,
        paused: bool | None = None,
        metered: bool | None = None,
        upload_kbps_cap: int | None = None,
        clear_upload_cap: bool = False,
        cache_bytes_cap: int | None = None,
    ) -> None:
        c = self.contribution
        if paused is not None:
            c.paused = paused
        if metered is not None:
            c.metered = metered
        if upload_kbps_cap is not None or clear_upload_cap:
            c.upload_kbps_cap = upload_kbps_cap
            self.bucket.set_rate(self._rate_bytes(upload_kbps_cap))
        if cache_bytes_cap is not None:
            c.cache_bytes_cap = cache_bytes_cap
            self.cache.set_max_bytes(cache_bytes_cap)
        for session in list(self.sessions.values()):
            await self._peer_heartbeat(session)  # tell the registry now, not at the next tick

    def _stored(self, verified: VerifiedSegment) -> Any:
        async def note() -> None:
            sid = verified.descriptor.segment_id
            for session in self.sessions.values():
                if session.version_id == verified.descriptor.asset_version_id and session.contribute:
                    if sid in self.cache:
                        session.announce.add(sid)

        return note()

    def _evicted(self, entry: CacheEntry) -> None:
        for session in self.sessions.values():
            if session.version_id == entry.asset_version_id:
                session.announce.discard(entry.segment_id)
                if session.contribute:
                    session.withdraw.add(entry.segment_id)

    async def _flush_availability(self, session: AgentSession) -> None:
        if not (session.contribute and session.peer_session_id and session.peer_token):
            session.announce.clear()
            session.withdraw.clear()
            return
        while (session.announce or session.withdraw) and not session.closed:
            limit = max(2, session.availability_limit)
            drop = [session.withdraw.pop() for _ in range(min(len(session.withdraw), limit // 2))]
            have = [session.announce.pop() for _ in range(min(len(session.announce), limit - len(drop)))]
            have = [s for s in have if s in self.cache]
            try:
                await self.control.request(
                    "PUT", f"/v1/peer-sessions/{session.peer_session_id}/availability",
                    token=session.peer_token, json={"mode": "delta", "have": have, "drop": drop},
                )  # fmt: skip
            except ControlError as exc:
                logger.warning("availability announcement failed: %s", exc.code)
                return

    # ------------------------------------------------------------------ background loop
    async def _session_gone(self, session: AgentSession, exc: ControlError) -> None:
        reason = "withdrawn" if exc.code == "withdrawn" else "expired"
        await self.close_session(session, reason=reason, remote=False)

    async def _heartbeat(self, session: AgentSession) -> None:
        try:
            info = await self.control.playback_heartbeat(
                session.session_id, session.session_token, session.position
            )
        except ControlError as exc:
            if exc.status in (404, 410):
                await self._session_gone(session, exc)
            return
        session.origin_token = info["origin"]["token"]

    async def _peer_heartbeat(self, session: AgentSession) -> None:
        if not (session.peer_session_id and session.peer_token) or session.closed:
            return
        c = self.contribution
        try:
            await self.control.request(
                "POST", f"/v1/peer-sessions/{session.peer_session_id}/heartbeat", token=session.peer_token,
                json={
                    "contribution_paused": not c.active,
                    "metered": c.restricted_by_metering,
                    "upload_kbps_cap": c.upload_kbps_cap,
                },
            )  # fmt: skip
        except ControlError as exc:
            if exc.status in (404, 410):
                await self._session_gone(session, exc)

    async def tick(self) -> None:
        now = self.clock.now()
        for session in list(self.sessions.values()):
            if session.closed or self.faults["suspend_heartbeats"]:
                continue
            if now >= session.next_heartbeat:
                session.next_heartbeat = now + session.heartbeat_interval
                await self._heartbeat(session)
            if not session.closed and now >= session.next_peer_heartbeat:
                session.next_peer_heartbeat = now + session.peer_heartbeat_interval
                await self._peer_heartbeat(session)
            if not session.closed:
                await self._flush_availability(session)
        self.cache.purge_expired()

    async def _loop(self) -> None:
        while True:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("agent tick failed")
            await self.clock.sleep(self.config.tick_seconds)

    # ------------------------------------------------------------------ serving peers
    def _refuse(self, status: int, reason: str) -> web.Response:
        self.refused[reason] = self.refused.get(reason, 0) + 1
        headers = {"Retry-After": "1"} if status in (429, 503) else {}
        return web.json_response({"code": reason}, status=status, headers=headers)

    async def _health(self, _request: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})

    async def _serve_segment(self, request: web.Request) -> web.StreamResponse:
        assert self.verifier is not None
        segment_id = request.match_info["segment_id"]
        scheme, _, token = request.headers.get("Authorization", "").partition(" ")
        if scheme.lower() != "bearer" or not token:
            return self._refuse(401, "grant_required")
        serving = {
            s.peer_session_id: s
            for s in self.sessions.values()
            if s.peer_session_id and s.contribute and not s.closed
        }
        if not serving or not self.contribution.active:
            return self._refuse(403, "not_contributing")
        try:
            # Signature, issuer, expiry, and "addressed to one of my peer sessions".
            claims = self.verifier.verify(token.strip(), typ=TYP_TRANSFER, audience=list(serving))
        except TokenError as exc:
            return self._refuse(401, f"grant_{exc.reason}")
        session = serving.get(str(claims.get("aud")))
        segments = claims.get("segs")
        if (
            session is None
            or claims.get("ver") != session.version_id
            or not isinstance(segments, list)
            or segment_id not in segments
        ):
            return self._refuse(403, "grant_scope")
        if self._server_ssl is not None:
            # RFC 8705: the grant is bound to the requester's client certificate.
            ssl_object = request.transport.get_extra_info("ssl_object") if request.transport else None
            der = ssl_object.getpeercert(binary_form=True) if ssl_object is not None else None
            bound = (claims.get("cnf") or {}).get("x5t#S256")
            if der is None or bound != thumbprint_to_cnf(cert_thumbprint_hex(der))["x5t#S256"]:
                return self._refuse(403, "grant_certificate_mismatch")
        descriptor = session.manifest.find(segment_id)
        data = await self.cache.get(segment_id)
        if descriptor is None or data is None:
            session.withdraw.add(segment_id)
            return self._refuse(404, "segment_not_cached")
        reason = self.ledger.admit(
            str(claims.get("jti")),
            segment_id,
            len(data),
            int(claims.get("max_bytes", 0)),
            float(claims["exp"]),
        )
        if reason is not None:
            return self._refuse(403, f"grant_{reason}")
        if self._active_uploads >= self.contribution.max_concurrent_uploads:
            return self._refuse(503, "busy")
        self._active_uploads += 1
        started = self.clock.now()
        written = 0
        try:
            if self.config.enable_fault_injection and self.faults["corrupt"]:
                data = bytes([data[0] ^ 0xFF]) + data[1:]  # demo/test fault: flipped byte
            response = web.StreamResponse(
                status=200,
                headers={
                    "Content-Type": "application/octet-stream",
                    "Content-Length": str(len(data)),
                    "Cache-Control": "no-store",
                },
            )
            await response.prepare(request)
            for offset in range(0, len(data), CHUNK):
                chunk = data[offset : offset + CHUNK]
                await self.bucket.consume(len(chunk))  # upload-bandwidth cap
                if not self.contribution.active:
                    raise ConnectionResetError("contribution paused")
                await response.write(chunk)
                written += len(chunk)
            await response.write_eof()
        finally:
            # Count every byte put on the wire, including transfers the requester
            # abandoned half-way (hedged, cancelled by a seek, disconnected).
            self._active_uploads -= 1
            self.sent_bytes += written
            if len(self.upload_windows) < 10_000:
                self.upload_windows.append((started, self.clock.now(), written))
        ended = self.clock.now()
        self.served_bytes += len(data)
        self.served_segments += 1
        if session.peer_session_id and session.peer_token:
            self._spawn(
                self._sender_receipt(session, str(claims.get("jti")), segment_id, len(data), ended - started)
            )
        return response

    async def _sender_receipt(
        self, session: AgentSession, grant_id: str, segment_id: str, size: int, elapsed: float
    ) -> None:
        with contextlib.suppress(ControlError):
            await self.control.request(
                "POST", "/v1/transfer-receipts", token=session.peer_token,
                json={
                    "peer_session_id": session.peer_session_id, "grant_id": grant_id,
                    "segment_id": segment_id, "role": "sender", "outcome": "verified",
                    "bytes_transferred": size, "duration_ms": int(elapsed * 1000),
                },
            )  # fmt: skip

    # ------------------------------------------------------------------ introspection
    def stats(self) -> dict[str, Any]:
        windows = sorted(self.upload_windows)
        busy = 0.0  # union of the intervals in which at least one upload was running
        cursor = float("-inf")
        for start, end, _size in windows:
            busy += max(0.0, end - max(start, cursor))
            cursor = max(cursor, end)
        return {
            "name": self.config.name,
            "port": self.port,
            "transport": self.transport.name,
            "sessions": [
                {
                    "session_id": s.session_id, "version_id": s.version_id,
                    "peer_session_id": s.peer_session_id, "contribute": s.contribute,
                    "delivery": s.metrics.snapshot(),
                }
                for s in self.sessions.values()
            ],
            "cache": {
                "segments": len(self.cache), "bytes": self.cache.total_bytes,
                "max_bytes": self.cache.max_bytes, "evictions": self.cache.evictions,
            },
            "contribution": {
                "enabled": self.contribution.enabled, "active": self.contribution.active,
                "paused": self.contribution.paused, "metered": self.contribution.metered,
                "upload_kbps_cap": self.contribution.upload_kbps_cap,
                "background_agent": self.contribution.background_agent,
            },
            "upload": {
                "served_bytes": self.served_bytes, "served_segments": self.served_segments,
                "sent_bytes": self.sent_bytes, "refused": dict(self.refused),
                "busy_seconds": round(busy, 4),
                "kbps_while_sending": round(self.sent_bytes * 8 / 1000 / busy, 1) if busy > 0 else None,
            },
        }  # fmt: skip
