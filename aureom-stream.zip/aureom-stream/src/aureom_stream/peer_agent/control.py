"""HTTP client for the control plane, and the scheduler's directory over it."""

from __future__ import annotations

from typing import Any

import httpx

from ..domain import PeerCandidate, ReceiptReport, TransferGrantToken


class ControlError(Exception):
    def __init__(self, status: int, code: str, detail: str) -> None:
        super().__init__(f"{status} {code}: {detail}")
        self.status = status
        self.code = code
        self.detail = detail


def _bearer(token: str | None) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"} if token else {}


class ControlClient:
    def __init__(
        self, base_url: str, *, client: httpx.AsyncClient | None = None, timeout: float = 10.0
    ) -> None:
        self._base = base_url.rstrip("/")
        self._client = client or httpx.AsyncClient(timeout=timeout)
        self._owns = client is None

    async def close(self) -> None:
        if self._owns:
            await self._client.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        token: str | None = None,
        json: Any = None,
        content: bytes | None = None,
        headers: dict[str, str] | None = None,
        raw: bool = False,
    ) -> Any:
        try:
            response = await self._client.request(
                method, self._base + path, json=json, content=content,
                headers={**_bearer(token), **(headers or {})},
            )  # fmt: skip
        except httpx.HTTPError as exc:
            raise ControlError(0, "unreachable", type(exc).__name__) from exc
        if response.status_code >= 400:
            try:
                body = response.json()
            except ValueError:
                body = {}
            raise ControlError(
                response.status_code, str(body.get("code", "error")), str(body.get("detail", ""))
            )
        if raw:
            return response
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    # ---- convenience wrappers used by agents and the CLI --------------------------
    async def jwks(self) -> dict[str, Any]:
        return await self.request("GET", "/.well-known/jwks.json")

    async def create_playback_session(
        self, token: str | None, *, asset_id: str, version_id: str | None = None,
        peer_delivery: bool, contribute: bool, max_height: int | None = None,
    ) -> dict[str, Any]:  # fmt: skip
        body: dict[str, Any] = {
            "asset_id": asset_id,
            "client_capabilities": {
                "supported_codecs": ["avc1"], "max_height": max_height, "peer_delivery": peer_delivery,
            },
            "peer_contribution_enabled": contribute,
        }  # fmt: skip
        if version_id:
            body["version_id"] = version_id
        return await self.request("POST", "/v1/playback-sessions", token=token, json=body)

    async def playback_heartbeat(self, session_id: str, token: str, position: float | None) -> dict[str, Any]:
        return await self.request(
            "POST", f"/v1/playback-sessions/{session_id}/heartbeat", token=token,
            json={"position_seconds": position},
        )  # fmt: skip

    async def signed_manifest(self, path: str, token: str) -> str:
        response = await self.request("GET", path, token=token, raw=True)
        return str(response.text)


class HttpPeerDirectory:
    """The scheduler's :class:`PeerDirectory`, backed by the registry API."""

    def __init__(self, control: ControlClient, *, peer_session_id: str, peer_token: str) -> None:
        self._control = control
        self.peer_session_id = peer_session_id
        self._token = peer_token

    async def discover(self, segment_ids: list[str]) -> list[PeerCandidate]:
        body = await self._control.request(
            "POST", "/v1/peer-discovery", token=self._token,
            json={"peer_session_id": self.peer_session_id, "segment_ids": segment_ids},
        )  # fmt: skip
        return [
            PeerCandidate(
                peer_id=p["peer_id"],
                host=p["endpoint"]["host"],
                port=p["endpoint"]["port"],
                transport=p["transport"],
                segment_ids=frozenset(p["segment_ids"]),
                reliability=p["reliability"],
                cert_thumbprint=p.get("cert_thumbprint"),
            )
            for p in body["peers"]
        ]

    async def authorise_transfer(self, peer: PeerCandidate, segment_ids: list[str]) -> TransferGrantToken:
        body = await self._control.request(
            "POST", "/v1/transfer-authorisations", token=self._token,
            json={
                "peer_session_id": self.peer_session_id,
                "serving_peer_id": peer.peer_id,
                "segment_ids": segment_ids,
            },
        )  # fmt: skip
        return TransferGrantToken(
            grant_id=body["grant_id"],
            token=body["token"],
            serving_peer_id=body["serving_peer_id"],
            segment_ids=frozenset(body["segment_ids"]),
            expires_at=body["expires_at"],
        )

    async def report_receipt(self, receipt: ReceiptReport) -> None:
        await self._control.request(
            "POST", "/v1/transfer-receipts", token=self._token,
            json={
                "peer_session_id": self.peer_session_id,
                "grant_id": receipt.grant_id,
                "segment_id": receipt.segment_id,
                "role": receipt.role,
                "outcome": receipt.outcome,
                "bytes_transferred": receipt.bytes_transferred,
                "duration_ms": receipt.duration_ms,
            },
        )  # fmt: skip
