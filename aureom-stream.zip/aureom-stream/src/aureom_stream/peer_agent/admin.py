"""Local control interface for a running peer agent.

Bound to loopback and protected by a bearer token, this is how a local application
(or the demonstration script) tells its own agent to play, seek, pause contribution or
shut down. It is not part of the peer-to-peer protocol and is never exposed to peers.
"""

from __future__ import annotations

import asyncio
import hmac
import json
from typing import Any

from aiohttp import web

from ..ids import new_id
from ..playback.harness import PlaybackScript
from .agent import PeerAgent
from .control import ControlError


class AdminServer:
    def __init__(self, agent: PeerAgent, *, token: str, port: int = 0) -> None:
        self._agent = agent
        self._token = token
        self._port = port
        self.port = port
        self._runner: web.AppRunner | None = None
        self._plays: dict[str, dict[str, Any]] = {}
        self.shutdown = asyncio.Event()

    async def start(self) -> None:
        @web.middleware
        async def auth(request: web.Request, handler: Any) -> web.StreamResponse:
            supplied = request.headers.get("Authorization", "")
            if not hmac.compare_digest(supplied, f"Bearer {self._token}"):
                return web.json_response({"code": "unauthenticated"}, status=401)
            try:
                return await handler(request)  # type: ignore[no-any-return]
            except ControlError as exc:
                return web.json_response(
                    {"code": exc.code, "detail": exc.detail, "upstream_status": exc.status}, status=502
                )
            except (KeyError, ValueError, json.JSONDecodeError) as exc:
                return web.json_response({"code": "bad_request", "detail": str(exc)}, status=400)

        app = web.Application(middlewares=[auth], client_max_size=64 * 1024)
        app.router.add_get("/admin/v1/stats", self._stats)
        app.router.add_post("/admin/v1/play", self._play)
        app.router.add_get("/admin/v1/plays/{play_id}", self._play_status)
        app.router.add_post("/admin/v1/contribution", self._contribution)
        app.router.add_post("/admin/v1/sessions/close-all", self._close_all)
        app.router.add_post("/admin/v1/faults", self._faults)
        app.router.add_post("/admin/v1/shutdown", self._shutdown)
        self._runner = web.AppRunner(app, access_log=None)
        await self._runner.setup()
        site = web.TCPSite(self._runner, "127.0.0.1", self._port)  # loopback only, always
        await site.start()
        addresses = self._runner.addresses
        self.port = int(addresses[0][1]) if addresses else self._port

    async def stop(self) -> None:
        if self._runner is not None:
            await self._runner.cleanup()

    async def _stats(self, _request: web.Request) -> web.Response:
        return web.json_response(self._agent.stats())

    async def _play(self, request: web.Request) -> web.Response:
        body = await request.json()
        script = PlaybackScript(
            speed=float(body.get("speed", 1.0)),
            seeks=[(float(a), float(b)) for a, b in body.get("seeks", [])],
            stop_after_seconds=body.get("stop_after_seconds"),
            stop_at_position=body.get("stop_at_position"),
        )
        session = await self._agent.open_session(
            body.get("principal_token"), body["asset_id"],
            version_id=body.get("version_id"), peer_delivery=bool(body.get("peer_delivery", True)),
        )  # fmt: skip
        play_id = new_id("ply")
        record: dict[str, Any] = {
            "play_id": play_id, "state": "running", "session_id": session.session_id,
            "peer_session_id": session.peer_session_id, "version_id": session.version_id,
            "contribute": session.contribute, "report": None, "error": None,
        }  # fmt: skip
        self._plays[play_id] = record

        async def run() -> None:
            try:
                report = await self._agent.play(
                    session, script=script, rendition=body.get("rendition", "best")
                )
                record["report"] = report.to_dict()
                record["events"] = session.metrics.events[:500]
                record["state"] = "finished"
            except Exception as exc:  # reported to the caller, not swallowed
                record["error"] = f"{type(exc).__name__}: {exc}"
                record["state"] = "failed"

        task = asyncio.ensure_future(run())
        if body.get("wait", True):
            await task
        return web.json_response(record)

    async def _play_status(self, request: web.Request) -> web.Response:
        record = self._plays.get(request.match_info["play_id"])
        if record is None:
            return web.json_response({"code": "not_found"}, status=404)
        return web.json_response(record)

    async def _contribution(self, request: web.Request) -> web.Response:
        body = await request.json()
        await self._agent.set_contribution(
            paused=body.get("paused"),
            metered=body.get("metered"),
            upload_kbps_cap=body.get("upload_kbps_cap"),
            clear_upload_cap=bool(body.get("clear_upload_cap", False)),
            cache_bytes_cap=body.get("cache_bytes_cap"),
        )
        return web.json_response(self._agent.stats()["contribution"])

    async def _close_all(self, _request: web.Request) -> web.Response:
        sessions = list(self._agent.sessions.values())
        for session in sessions:
            await self._agent.close_session(session, reason="closed_by_user")
        return web.json_response({"closed": len(sessions)})

    async def _faults(self, request: web.Request) -> web.Response:
        if not self._agent.config.enable_fault_injection:
            return web.json_response({"code": "fault_injection_disabled"}, status=403)
        body = await request.json()
        for key in ("corrupt", "suspend_heartbeats"):
            if key in body:
                self._agent.faults[key] = bool(body[key])
        return web.json_response(self._agent.faults)

    async def _shutdown(self, _request: web.Request) -> web.Response:
        self.shutdown.set()
        return web.json_response({"status": "stopping"})
