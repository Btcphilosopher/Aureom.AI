"""Bounded on-disk segment cache for a peer agent.

Only :class:`VerifiedSegment` objects can be stored, so everything a peer can serve
has already matched the signed manifest. The cache is bounded by bytes (LRU eviction)
and by age, and whole versions are purged when their session ends, expires or the
version is withdrawn.
"""

from __future__ import annotations

import asyncio
import os
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from ..clock import Clock
from ..domain import VerifiedSegment


@dataclass
class CacheEntry:
    segment_id: str
    asset_version_id: str
    size: int
    stored_at: float


class SegmentCache:
    def __init__(
        self,
        directory: Path,
        *,
        max_bytes: int,
        clock: Clock,
        ttl_seconds: float = 3600.0,
        on_evict: Callable[[CacheEntry], None] | None = None,
    ) -> None:
        self._dir = Path(directory)
        self._dir.mkdir(parents=True, exist_ok=True)
        for stale in self._dir.iterdir():  # never trust leftovers from an earlier run
            if stale.is_file():
                stale.unlink()
        self.max_bytes = max_bytes
        self._clock = clock
        self._ttl = ttl_seconds
        self._entries: OrderedDict[str, CacheEntry] = OrderedDict()
        self._bytes = 0
        self.on_evict = on_evict
        self.evictions = 0

    @property
    def total_bytes(self) -> int:
        return self._bytes

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, segment_id: str) -> bool:
        return segment_id in self._entries

    def segment_ids(self, asset_version_id: str | None = None) -> list[str]:
        return [
            e.segment_id
            for e in self._entries.values()
            if asset_version_id is None or e.asset_version_id == asset_version_id
        ]

    def _path(self, segment_id: str) -> Path:
        if not segment_id.replace("_", "").isalnum():
            raise ValueError("invalid segment id")
        return self._dir / segment_id

    def _remove(self, segment_id: str, *, notify: bool) -> None:
        entry = self._entries.pop(segment_id, None)
        if entry is None:
            return
        self._bytes -= entry.size
        try:
            os.unlink(self._path(segment_id))
        except FileNotFoundError:
            pass
        if notify:
            self.evictions += 1
            if self.on_evict is not None:
                self.on_evict(entry)

    async def get(self, segment_id: str) -> bytes | None:
        entry = self._entries.get(segment_id)
        if entry is None:
            return None
        if self._clock.now() - entry.stored_at > self._ttl:
            self._remove(segment_id, notify=True)
            return None
        self._entries.move_to_end(segment_id)
        try:
            return await asyncio.to_thread(self._path(segment_id).read_bytes)
        except FileNotFoundError:
            self._remove(segment_id, notify=True)
            return None

    async def put(self, segment: VerifiedSegment) -> None:
        if not isinstance(segment, VerifiedSegment):
            raise TypeError("only verified segments may be cached")
        sid = segment.descriptor.segment_id
        size = len(segment.data)
        if size > self.max_bytes:
            return  # larger than the whole cache: do not keep it
        if sid in self._entries:
            self._entries.move_to_end(sid)
            return
        while self._entries and self._bytes + size > self.max_bytes:
            oldest = next(iter(self._entries))
            self._remove(oldest, notify=True)
        path = self._path(sid)
        tmp = path.with_suffix(".tmp")
        await asyncio.to_thread(tmp.write_bytes, segment.data)
        os.replace(tmp, path)
        self._entries[sid] = CacheEntry(sid, segment.descriptor.asset_version_id, size, self._clock.now())
        self._bytes += size

    async def discard(self, segment_id: str) -> None:
        self._remove(segment_id, notify=True)

    def purge_version(self, asset_version_id: str) -> int:
        ids = self.segment_ids(asset_version_id)
        for sid in ids:
            self._remove(sid, notify=False)
        return len(ids)

    def purge_expired(self) -> int:
        now = self._clock.now()
        ids = [e.segment_id for e in self._entries.values() if now - e.stored_at > self._ttl]
        for sid in ids:
            self._remove(sid, notify=True)
        return len(ids)

    def set_max_bytes(self, max_bytes: int) -> None:
        self.max_bytes = max_bytes
        while self._entries and self._bytes > self.max_bytes:
            self._remove(next(iter(self._entries)), notify=True)
