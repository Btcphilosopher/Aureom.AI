"""Upload limits for a contributing peer: byte-rate cap, concurrency, per-grant ledger."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..clock import Clock


class TokenBucket:
    """Classic token bucket on the injected clock. ``rate`` is bytes per second."""

    def __init__(self, clock: Clock, *, rate: float | None, burst: float | None = None) -> None:
        self._clock = clock
        self._rate = rate
        self._burst = self._default_burst(rate) if burst is None else burst
        self._tokens = self._burst
        self._at = clock.now()
        self.consumed = 0

    @staticmethod
    def _default_burst(rate: float | None) -> float:
        # A quarter second of allowance: enough for smooth sending, small enough that
        # the measured rate stays at the cap.
        return 0.0 if rate is None else max(1024.0, rate * 0.25)

    @property
    def rate(self) -> float | None:
        return self._rate

    def set_rate(self, rate: float | None) -> None:
        self._refill()
        self._rate = rate
        self._burst = self._default_burst(rate)
        self._tokens = min(self._tokens, self._burst)

    def _refill(self) -> None:
        now = self._clock.now()
        if self._rate is not None:
            self._tokens = min(self._burst, self._tokens + (now - self._at) * self._rate)
        self._at = now

    async def consume(self, amount: int) -> None:
        """Block until ``amount`` bytes may be sent."""
        self.consumed += amount
        if self._rate is None:
            return
        self._refill()
        self._tokens -= amount
        if self._tokens < 0:
            await self._clock.sleep(-self._tokens / self._rate)


@dataclass
class _GrantUse:
    expires_at: float
    served: set[str] = field(default_factory=set)
    bytes: int = 0


class GrantLedger:
    """Replay guard on the serving peer: each granted segment is served once per grant
    and a grant never yields more than its byte allowance. Bounded and self-expiring."""

    def __init__(self, clock: Clock, *, max_entries: int = 4096) -> None:
        self._clock = clock
        self._max = max_entries
        self._uses: dict[str, _GrantUse] = {}

    def admit(
        self, grant_id: str, segment_id: str, size: int, max_bytes: int, expires_at: float
    ) -> str | None:
        """Returns None if the request may proceed, otherwise the reason for refusal."""
        now = self._clock.now()
        if len(self._uses) >= self._max:
            self._uses = {k: v for k, v in self._uses.items() if v.expires_at > now}
            if len(self._uses) >= self._max:
                return "ledger_full"
        use = self._uses.setdefault(grant_id, _GrantUse(expires_at=expires_at))
        if segment_id in use.served:
            return "replayed"
        if use.bytes + size > max_bytes:
            return "byte_limit"
        use.served.add(segment_id)
        use.bytes += size
        return None
