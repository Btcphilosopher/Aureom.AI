"""Typed contracts shared between layers (no I/O, no persistence)."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

SegmentKindLiteral = Literal["init", "media"]
SourceLiteral = Literal["origin", "peer", "cache"]


class DistributionPolicy(BaseModel):
    """Upper bounds on how a published version may be delivered.

    Viewing, offline download and peer contribution are three separate permissions.
    """

    model_config = ConfigDict(extra="forbid")

    peer_delivery: bool = False  # may viewers fetch segments from authorised peers?
    offline_download: Literal["none", "granted", "all_viewers"] = "none"
    peer_contribution: Literal["none", "granted", "all_viewers"] = "none"


class RightsDeclaration(BaseModel):
    """The uploader's statement of why they may distribute the work.

    A declaration is recorded, not verified: content integrity (hashes) says nothing
    about copyright ownership or safety.
    """

    model_config = ConfigDict(extra="forbid")

    basis: Literal["owner", "licensed", "open_licence", "public_domain"]
    statement: str = Field(min_length=1, max_length=2000)
    licence: str | None = Field(default=None, max_length=200)  # e.g. "CC0-1.0"


@dataclass(frozen=True)
class Principal:
    id: str
    scopes: frozenset[str] = frozenset()
    anonymous: bool = False

    def has_scope(self, scope: str) -> bool:
        return scope in self.scopes or "admin" in self.scopes


ANONYMOUS = Principal(id="anonymous", anonymous=True)


@dataclass(frozen=True)
class PlaybackGrant:
    """Result of authorising one principal for one immutable asset version."""

    principal_id: str
    asset_id: str
    asset_version_id: str
    visibility: str
    preview: bool  # owner review of an unpublished version (origin only)
    peer_delivery: bool  # may fetch from peers
    may_contribute: bool  # may serve peers if (and only if) the user opts in
    sharing_scope: str  # peers are only ever matched inside one scope
    expires_at: float


@dataclass(frozen=True)
class SegmentDescriptor:
    """A segment as described by the authenticated version manifest."""

    segment_id: str
    asset_version_id: str
    rendition_id: str
    kind: SegmentKindLiteral
    sequence_number: int
    start_time: float
    duration: float
    byte_length: int
    content_hash: str  # SHA-256 hex, from the signed manifest - never from a peer

    @property
    def end_time(self) -> float:
        return self.start_time + self.duration


class IntegrityError(Exception):
    def __init__(self, reason: Literal["length_mismatch", "hash_mismatch"], detail: str) -> None:
        super().__init__(detail)
        self.reason = reason


@dataclass(frozen=True)
class VerifiedSegment:
    """Bytes whose length and SHA-256 matched the authenticated manifest.

    Create instances only through :func:`verify_segment`.
    """

    descriptor: SegmentDescriptor
    data: bytes
    source: SourceLiteral
    source_id: str | None = None
    elapsed: float = 0.0


def verify_segment(
    descriptor: SegmentDescriptor,
    data: bytes,
    *,
    source: SourceLiteral,
    source_id: str | None = None,
    elapsed: float = 0.0,
) -> VerifiedSegment:
    if len(data) != descriptor.byte_length:
        raise IntegrityError(
            "length_mismatch",
            f"{descriptor.segment_id}: got {len(data)} bytes, manifest says {descriptor.byte_length}",
        )
    if hashlib.sha256(data).hexdigest() != descriptor.content_hash:
        raise IntegrityError("hash_mismatch", f"{descriptor.segment_id}: SHA-256 mismatch")
    return VerifiedSegment(descriptor, data, source, source_id, elapsed)


@dataclass(frozen=True)
class PeerCandidate:
    peer_id: str  # opaque peer-session id, rotates with every session
    host: str
    port: int
    transport: str  # "loopback-http" | "mtls-http"
    segment_ids: frozenset[str]  # subset of the *requested* ids only
    reliability: float = 1.0  # registry hint in [0, 1]
    cert_thumbprint: str | None = None


@dataclass(frozen=True)
class TransferGrantToken:
    grant_id: str
    token: str
    serving_peer_id: str
    segment_ids: frozenset[str]
    expires_at: float


ReceiptOutcome = Literal["verified", "corrupt", "length_mismatch", "timeout", "refused", "not_found", "error"]


@dataclass(frozen=True)
class ReceiptReport:
    grant_id: str
    segment_id: str
    role: Literal["receiver", "sender"]
    outcome: ReceiptOutcome
    bytes_transferred: int
    duration_ms: int


@dataclass
class DeliveryObservation:
    """What the transfer scheduler tells the player/ABR adapter. It never switches
    renditions itself."""

    segment_id: str
    rendition_id: str
    source: SourceLiteral
    bytes: int
    elapsed: float
    throughput_bps: float
    deadline_slack: float  # seconds to spare (negative = deadline missed)
    attempts: int = 1
    notes: list[str] = field(default_factory=list)
