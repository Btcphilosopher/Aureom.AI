"""AUREOM STREAM - hybrid origin-and-peer media delivery backend.

The package is split along three layers that are kept deliberately separate:

* media layer     - ``uploads``, ``processing``, ``packaging``, ``manifests``, ``catalogue``
* delivery layer  - ``origin``, ``discovery``, ``scheduler``, ``transports``, ``peer_agent``
* access layer    - ``access`` (visibility, viewing / offline / peer rights, expiring grants)
"""

__version__ = "0.1.0"
