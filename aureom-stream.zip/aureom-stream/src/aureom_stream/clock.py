"""Injectable clocks.

All time-dependent behaviour (expiry, deadlines, timeouts, token validity) reads
time through a :class:`Clock`, so failure behaviour can be tested deterministically
with :class:`FakeClock` instead of real sleeps.
"""

from __future__ import annotations

import asyncio
import heapq
import itertools
import time
from collections.abc import Awaitable, Coroutine
from datetime import UTC, datetime
from typing import Any, Protocol, TypeVar

T = TypeVar("T")


class Clock(Protocol):
    def now(self) -> float:
        """Seconds since the Unix epoch."""
        ...

    async def sleep(self, seconds: float) -> None: ...


def to_datetime(epoch: float) -> datetime:
    return datetime.fromtimestamp(epoch, tz=UTC)


class SystemClock:
    def now(self) -> float:
        return time.time()

    async def sleep(self, seconds: float) -> None:
        await asyncio.sleep(max(0.0, seconds))


class FakeClock:
    """Virtual time. ``sleep`` blocks until a test calls :meth:`advance` / :meth:`run`."""

    def __init__(self, start: float = 1_800_000_000.0) -> None:
        self._now = float(start)
        self._sleepers: list[tuple[float, int, asyncio.Future[None]]] = []
        self._seq = itertools.count()

    def now(self) -> float:
        return self._now

    def set(self, epoch: float) -> None:
        self._now = float(epoch)

    def tick(self, seconds: float) -> None:
        """Move time without waking sleepers (for purely synchronous code)."""
        self._now += seconds

    async def sleep(self, seconds: float) -> None:
        if seconds <= 0:
            await asyncio.sleep(0)
            return
        fut: asyncio.Future[None] = asyncio.get_running_loop().create_future()
        heapq.heappush(self._sleepers, (self._now + seconds, next(self._seq), fut))
        await fut

    @staticmethod
    async def _settle(rounds: int = 25) -> None:
        for _ in range(rounds):
            await asyncio.sleep(0)

    def _next_wake(self) -> float | None:
        while self._sleepers and self._sleepers[0][2].done():
            heapq.heappop(self._sleepers)
        return self._sleepers[0][0] if self._sleepers else None

    async def advance(self, seconds: float) -> None:
        """Advance virtual time, waking sleepers in timestamp order."""
        target = self._now + seconds
        await self._settle()
        while True:
            wake = self._next_wake()
            if wake is None or wake > target:
                break
            _, _, fut = heapq.heappop(self._sleepers)
            self._now = max(self._now, wake)
            if not fut.done():
                fut.set_result(None)
            await self._settle()
        self._now = target
        await self._settle()

    async def run(self, awaitable: Awaitable[T], *, max_virtual_seconds: float = 3600.0) -> T:
        """Run ``awaitable`` to completion, jumping virtual time whenever it is idle."""
        task: asyncio.Future[T] = asyncio.ensure_future(awaitable)
        limit = self._now + max_virtual_seconds
        try:
            while True:
                await self._settle()
                if task.done():
                    return task.result()
                wake = self._next_wake()
                if wake is None:
                    # Not waiting on virtual time: give real I/O a moment.
                    await asyncio.sleep(0.001)
                    continue
                if wake > limit:
                    raise TimeoutError("virtual time limit exceeded")
                _, _, fut = heapq.heappop(self._sleepers)
                self._now = max(self._now, wake)
                if not fut.done():
                    fut.set_result(None)
        finally:
            if not task.done():
                task.cancel()


async def wait_first(clock: Clock, task: asyncio.Future[Any], timeout: float) -> bool:
    """Wait for ``task`` at most ``timeout`` clock-seconds. Returns True if it finished.

    Unlike ``asyncio.wait_for`` the timeout runs on the injected clock and the task is
    *not* cancelled on timeout - the caller decides (hedge, cancel, keep waiting).
    """
    if task.done():
        return True
    if timeout <= 0:
        return False
    sleeper = asyncio.ensure_future(clock.sleep(timeout))
    try:
        await asyncio.wait({task, sleeper}, return_when=asyncio.FIRST_COMPLETED)
    finally:
        if not sleeper.done():
            sleeper.cancel()
    return task.done()


async def run_with_timeout(clock: Clock, coro: Coroutine[Any, Any, T], timeout: float) -> T:
    """Clock-based ``wait_for``: cancels ``coro`` and raises ``TimeoutError`` on expiry."""
    task = asyncio.ensure_future(coro)
    try:
        finished = await wait_first(clock, task, timeout)
    except BaseException:
        task.cancel()
        raise
    if not finished:
        task.cancel()
        try:
            await task
        except (asyncio.CancelledError, Exception):  # noqa: S110
            pass
        raise TimeoutError(f"operation exceeded {timeout:.3f}s")
    return task.result()
