"""Structured JSON logging with secret redaction.

Bearer tokens, JWTs, session tokens passed as query parameters and signed-URL
signatures are scrubbed before a record is written. Request logging records the
*route template* and status, not the query string.
"""

from __future__ import annotations

import json
import logging
import re
import sys
import time
from typing import Any

_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"(?i)(authorization['\"]?\s*[:=]\s*['\"]?)(bearer\s+)?[^\s'\",}]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]{8,}"), "Bearer [REDACTED]"),
    (re.compile(r"\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}"), "[REDACTED_JWT]"),
    (
        re.compile(
            r"(?i)([?&](?:st|token|access_token|session_token|sig|signature|"
            r"X-Amz-Signature|X-Amz-Credential|X-Amz-Security-Token)=)[^&\s'\"]+"
        ),
        r"\1[REDACTED]",
    ),
    (
        re.compile(
            r"(?i)(['\"]?(?:session_token|peer_token|download_token|token|secret|password)"
            r"['\"]?\s*[:=]\s*['\"]?)[^\s'\",}]+"
        ),
        r"\1[REDACTED]",
    ),
]


def redact(text: str) -> str:
    for pattern, replacement in _PATTERNS:
        text = pattern.sub(replacement, text)
    return text


class RedactingJsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created))
            + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "logger": record.name,
            "msg": redact(record.getMessage()),
        }
        extra = getattr(record, "fields", None)
        if isinstance(extra, dict):
            for key, value in extra.items():
                payload[key] = redact(value) if isinstance(value, str) else value
        if record.exc_info:
            payload["exc"] = redact(self.formatException(record.exc_info))
        return json.dumps(payload, default=str)


def configure_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(RedactingJsonFormatter())
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level.upper())
    # The server's own access log would print raw query strings; ours does not.
    logging.getLogger("uvicorn.access").disabled = True
    logging.getLogger("aiohttp.access").disabled = True


def log(logger: logging.Logger, level: int, msg: str, **fields: Any) -> None:
    logger.log(level, msg, extra={"fields": fields})
