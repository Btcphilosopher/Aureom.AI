"""Measurements.

* :class:`ServerMetrics` - Prometheus counters/histograms exposed at ``/metrics``.
* :class:`DeliveryMetrics` - client-side (player / peer agent) delivery measurements:
  startup delay, deadline misses, origin vs peer bytes, verification failures,
  cache-hit rate, discovery and transfer latency, process resource use.

Numbers reported by this module come from the run that produced them. They describe
one machine and one short clip and say nothing about production-scale behaviour.
"""

from __future__ import annotations

import resource
import statistics
from dataclasses import dataclass, field
from typing import Any

from prometheus_client import CollectorRegistry, Counter, Histogram, generate_latest


class ServerMetrics:
    def __init__(self) -> None:
        self.registry = CollectorRegistry()
        self.http_requests = Counter(
            "aureom_http_requests_total",
            "HTTP requests",
            ["route", "method", "status"],
            registry=self.registry,
        )
        self.http_latency = Histogram(
            "aureom_http_request_seconds", "HTTP latency", ["route"], registry=self.registry
        )
        self.upload_bytes = Counter(
            "aureom_upload_bytes_total", "Accepted upload part bytes", registry=self.registry
        )
        self.origin_bytes = Counter(
            "aureom_origin_bytes_total", "Bytes served by the origin", ["kind"], registry=self.registry
        )
        self.jobs = Counter(
            "aureom_processing_jobs_total",
            "Processing jobs by outcome",
            ["outcome"],
            registry=self.registry,
        )
        self.discovery_latency = Histogram(
            "aureom_peer_discovery_seconds", "Peer discovery handling time", registry=self.registry
        )
        self.grants = Counter(
            "aureom_transfer_grants_total", "Transfer grants", ["outcome"], registry=self.registry
        )
        self.receipts = Counter(
            "aureom_transfer_receipts_total",
            "Self-reported receipts",
            ["role", "outcome"],
            registry=self.registry,
        )
        self.denials = Counter(
            "aureom_access_denials_total", "Access denials", ["reason"], registry=self.registry
        )

    def render(self) -> bytes:
        return generate_latest(self.registry)


def _summary(samples: list[float]) -> dict[str, float | int | None]:
    if not samples:
        return {"count": 0, "mean": None, "p50": None, "p95": None, "max": None}
    ordered = sorted(samples)
    p95 = ordered[min(len(ordered) - 1, int(round(0.95 * (len(ordered) - 1))))]
    return {
        "count": len(ordered),
        "mean": round(statistics.fmean(ordered), 6),
        "p50": round(statistics.median(ordered), 6),
        "p95": round(p95, 6),
        "max": round(ordered[-1], 6),
    }


@dataclass
class DeliveryMetrics:
    startup_delay_seconds: float | None = None
    segments_delivered: int = 0
    deadline_misses: int = 0
    stall_seconds: float = 0.0
    origin_bytes: int = 0
    peer_bytes: int = 0
    cache_bytes: int = 0
    origin_segments: int = 0
    peer_segments: int = 0
    verification_failures: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    peer_failures: dict[str, int] = field(default_factory=dict)
    origin_fallbacks: int = 0
    hedged_requests: int = 0
    cancelled_requests: int = 0
    duplicate_requests_avoided: int = 0
    retries: int = 0
    unavailable: int = 0
    discovery_latency: list[float] = field(default_factory=list)
    transfer_latency_origin: list[float] = field(default_factory=list)
    transfer_latency_peer: list[float] = field(default_factory=list)
    events: list[dict[str, Any]] = field(default_factory=list)
    max_events: int = 2000

    def event(self, name: str, /, **fields: Any) -> None:
        if len(self.events) < self.max_events:
            self.events.append({"event": name, **fields})

    def peer_failure(self, reason: str) -> None:
        self.peer_failures[reason] = self.peer_failures.get(reason, 0) + 1

    @property
    def cache_hit_rate(self) -> float | None:
        total = self.cache_hits + self.cache_misses
        return None if total == 0 else self.cache_hits / total

    def snapshot(self, *, include_events: bool = False) -> dict[str, Any]:
        usage = resource.getrusage(resource.RUSAGE_SELF)
        out: dict[str, Any] = {
            "startup_delay_seconds": self.startup_delay_seconds,
            "segments_delivered": self.segments_delivered,
            "deadline_misses": self.deadline_misses,
            "stall_seconds": round(self.stall_seconds, 3),
            "origin_bytes": self.origin_bytes,
            "peer_bytes": self.peer_bytes,
            "origin_segments": self.origin_segments,
            "peer_segments": self.peer_segments,
            "verification_failures": self.verification_failures,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "cache_hit_rate": self.cache_hit_rate,
            "peer_failures": dict(self.peer_failures),
            "origin_fallbacks": self.origin_fallbacks,
            "hedged_requests": self.hedged_requests,
            "cancelled_requests": self.cancelled_requests,
            "duplicate_requests_avoided": self.duplicate_requests_avoided,
            "retries": self.retries,
            "unavailable": self.unavailable,
            "peer_discovery_latency_seconds": _summary(self.discovery_latency),
            "transfer_latency_origin_seconds": _summary(self.transfer_latency_origin),
            "transfer_latency_peer_seconds": _summary(self.transfer_latency_peer),
            "process": {
                "cpu_user_seconds": round(usage.ru_utime, 3),
                "cpu_system_seconds": round(usage.ru_stime, 3),
                "max_rss_kib": usage.ru_maxrss,
            },
        }
        if include_events:
            out["events"] = list(self.events)
        return out
