"""Small API client used by the CLI and the demonstration (resumable upload etc.)."""

from __future__ import annotations

import asyncio
import hashlib
from collections.abc import Callable
from pathlib import Path
from typing import Any

from .peer_agent.control import ControlClient, ControlError


def file_idempotency_key(path: Path) -> str:
    stat = path.stat()
    raw = f"{path.resolve()}:{stat.st_size}:{int(stat.st_mtime)}".encode()
    return "file-" + hashlib.sha256(raw).hexdigest()[:40]


class ApiClient:
    def __init__(self, control: ControlClient, token: str | None) -> None:
        self.control = control
        self.token = token

    async def call(self, method: str, path: str, **kwargs: Any) -> Any:
        return await self.control.request(method, path, token=self.token, **kwargs)

    async def upload_file(
        self,
        path: Path,
        *,
        visibility: str = "private",
        idempotency_key: str | None = None,
        content_type: str = "video/mp4",
        only_parts: Callable[[int], bool] | None = None,
        complete: bool = True,
        on_part: Callable[[int, int, bool], None] | None = None,
    ) -> dict[str, Any]:
        """Resumable upload: asks the server which parts are missing and sends only
        those. Running it again with the same idempotency key resumes."""
        size = path.stat().st_size
        upload = await self.call(
            "POST", "/v1/uploads",
            json={
                "filename": path.name, "content_type": content_type, "size_bytes": size,
                "visibility": visibility,
                "idempotency_key": idempotency_key or file_idempotency_key(path),
            },
        )  # fmt: skip
        if upload["state"] == "completed":
            return upload  # type: ignore[no-any-return]
        part_size = upload["part_size_bytes"]
        with open(path, "rb") as fh:
            for number in upload["missing_parts"]:
                if only_parts is not None and not only_parts(number):
                    continue
                fh.seek((number - 1) * part_size)
                data = fh.read(part_size)
                result = await self.call(
                    "PUT", f"/v1/uploads/{upload['upload_id']}/parts/{number}", content=data,
                    headers={
                        "Content-Type": "application/octet-stream",
                        "X-Content-SHA256": hashlib.sha256(data).hexdigest(),
                    },
                )  # fmt: skip
                if on_part:
                    on_part(number, upload["part_count"], bool(result["duplicate"]))
        if not complete:
            return await self.call("GET", f"/v1/uploads/{upload['upload_id']}")  # type: ignore[no-any-return]
        return await self.call("POST", f"/v1/uploads/{upload['upload_id']}/complete")  # type: ignore[no-any-return]

    async def wait_for_processing(
        self, asset_id: str, version_id: str, *, timeout: float = 600.0, poll: float = 0.5
    ) -> dict[str, Any]:
        deadline = asyncio.get_running_loop().time() + timeout
        while True:
            versions = await self.call("GET", f"/v1/assets/{asset_id}/versions")
            version = next(v for v in versions if v["version_id"] == version_id)
            if version["state"] in ("ready_for_review", "published", "failed", "cancelled"):
                return version  # type: ignore[no-any-return]
            if asyncio.get_running_loop().time() > deadline:
                raise TimeoutError("processing did not finish in time")
            await asyncio.sleep(poll)


__all__ = ["ApiClient", "ControlClient", "ControlError", "file_idempotency_key"]
