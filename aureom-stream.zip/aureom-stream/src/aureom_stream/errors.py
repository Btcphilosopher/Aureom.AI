"""Domain errors, rendered by the API as RFC 9457 problem details."""

from __future__ import annotations

from typing import Any


class DomainError(Exception):
    status = 400
    code = "bad_request"
    title = "Bad request"

    def __init__(self, detail: str = "", *, code: str | None = None, **extra: Any) -> None:
        super().__init__(detail or self.title)
        self.detail = detail or self.title
        if code:
            self.code = code
        self.extra = extra


class ValidationFailed(DomainError):
    status = 422
    code = "validation_failed"
    title = "Validation failed"


class Unauthenticated(DomainError):
    status = 401
    code = "unauthenticated"
    title = "Authentication required"


class Forbidden(DomainError):
    status = 403
    code = "forbidden"
    title = "Forbidden"


class NotFound(DomainError):
    """Also used when the caller is not allowed to know that a private object exists."""

    status = 404
    code = "not_found"
    title = "Not found"


class Conflict(DomainError):
    status = 409
    code = "conflict"
    title = "Conflict"


class Gone(DomainError):
    status = 410
    code = "gone"
    title = "Gone"


class PayloadTooLarge(DomainError):
    status = 413
    code = "payload_too_large"
    title = "Payload too large"


class UnsupportedMedia(DomainError):
    status = 415
    code = "unsupported_media_type"
    title = "Unsupported media type"


class QuotaExceeded(DomainError):
    status = 413
    code = "quota_exceeded"
    title = "Quota exceeded"


class RateLimited(DomainError):
    status = 429
    code = "rate_limited"
    title = "Too many requests"


class ServiceUnavailable(DomainError):
    status = 503
    code = "service_unavailable"
    title = "Service unavailable"
