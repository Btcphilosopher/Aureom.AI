"""Access layer: who may view, download offline, fetch from peers, contribute, manage.

Rules (all evaluated per request, never cached in tokens beyond their short TTL):

* ``manage``            - asset owner, an explicit ``manage`` grant, or the ``admin`` scope.
* ``view``              - a manager; or the version is *published* and its publication is
                          ``public``/``unlisted``; or an unexpired ``view`` grant.
* ``offline_download``  - separate from view: publication policy ``all_viewers`` (+view)
                          or policy ``granted`` plus an ``offline_download`` grant.
* ``peer_contribute``   - separate again: policy ``all_viewers`` (+view) or ``granted``
                          plus a ``peer_contribute`` grant. The user must also opt in.

Callers that may not view a private object get ``NotFound`` so that its existence is
not revealed.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..clock import Clock, to_datetime
from ..domain import DistributionPolicy, PlaybackGrant, Principal
from ..errors import Forbidden, Gone, NotFound
from ..persistence.models import (
    AccessGrant,
    Asset,
    AssetVersion,
    Permission,
    Publication,
    VersionState,
    Visibility,
)

SCOPE_UPLOAD = "media:upload"
SCOPE_PUBLISH = "media:publish"


class AccessService:
    def __init__(self, session: AsyncSession, clock: Clock, *, grant_ttl: float = 120.0) -> None:
        self._db = session
        self._clock = clock
        self._grant_ttl = grant_ttl

    # ------------------------------------------------------------------ primitives
    async def has_grant(self, principal: Principal, asset_id: str, permission: Permission) -> bool:
        if principal.anonymous:
            return False
        now = to_datetime(self._clock.now())
        rows = await self._db.scalars(
            select(AccessGrant).where(
                AccessGrant.asset_id == asset_id,
                AccessGrant.principal_id == principal.id,
                AccessGrant.permission == permission.value,
                AccessGrant.revoked_at.is_(None),
            )
        )
        return any(g.expires_at is None or g.expires_at > now for g in rows)

    async def can_manage(self, principal: Principal, asset: Asset) -> bool:
        if principal.anonymous:
            return False
        if principal.id == asset.owner_id or principal.has_scope("admin"):
            return True
        return await self.has_grant(principal, asset.id, Permission.MANAGE)

    async def active_publication(self, version_id: str) -> Publication | None:
        pub = await self._db.scalar(select(Publication).where(Publication.asset_version_id == version_id))
        return pub if pub is not None and pub.withdrawn_at is None else None

    async def can_view_asset(self, principal: Principal, asset: Asset) -> bool:
        """May the principal learn that this asset exists / read its metadata?"""
        if await self.can_manage(principal, asset):
            return True
        pubs = await self._db.scalars(
            select(Publication).where(Publication.asset_id == asset.id, Publication.withdrawn_at.is_(None))
        )
        active = list(pubs)
        if not active:
            return False
        if any(p.visibility in (Visibility.PUBLIC.value, Visibility.UNLISTED.value) for p in active):
            return True
        return await self.has_grant(principal, asset.id, Permission.VIEW)

    # ------------------------------------------------------------------ decisions
    async def authorise_playback(self, principal: Principal, asset_version_id: str) -> PlaybackGrant:
        version = await self._db.get(AssetVersion, asset_version_id)
        asset = await self._db.get(Asset, version.asset_id) if version else None
        if version is None or asset is None:
            raise NotFound("asset version not found")
        manager = await self.can_manage(principal, asset)
        expires = self._clock.now() + self._grant_ttl

        if version.state == VersionState.READY_FOR_REVIEW.value and manager:
            # Owner review before publication: origin only, never peer-distributed.
            return PlaybackGrant(
                principal_id=principal.id,
                asset_id=asset.id,
                asset_version_id=version.id,
                visibility=asset.visibility,
                preview=True,
                peer_delivery=False,
                may_contribute=False,
                sharing_scope=f"version:{version.id}",
                expires_at=expires,
            )

        pub = await self.active_publication(version.id)
        if pub is None or version.state != VersionState.PUBLISHED.value:
            was_visible = manager or await self.has_grant(principal, asset.id, Permission.VIEW)
            if version.state == VersionState.WITHDRAWN.value and was_visible:
                raise Gone("this version has been withdrawn", code="withdrawn")
            if manager:
                raise Forbidden("version is not published", code="not_published")
            raise NotFound("asset version not found")

        open_visibility = pub.visibility in (Visibility.PUBLIC.value, Visibility.UNLISTED.value)
        if not (manager or open_visibility or await self.has_grant(principal, asset.id, Permission.VIEW)):
            raise NotFound("asset version not found")

        policy = DistributionPolicy.model_validate(pub.distribution)
        peer_delivery = policy.peer_delivery and not principal.anonymous
        may_contribute = False
        if peer_delivery:
            if policy.peer_contribution == "all_viewers":
                may_contribute = True
            elif policy.peer_contribution == "granted":
                may_contribute = await self.has_grant(principal, asset.id, Permission.PEER_CONTRIBUTE)
        return PlaybackGrant(
            principal_id=principal.id,
            asset_id=asset.id,
            asset_version_id=version.id,
            visibility=pub.visibility,
            preview=False,
            peer_delivery=peer_delivery,
            may_contribute=may_contribute,
            sharing_scope=f"version:{version.id}",
            expires_at=expires,
        )

    async def authorise_offline(self, principal: Principal, asset_version_id: str) -> PlaybackGrant:
        """Offline download is checked separately from (and on top of) viewing."""
        grant = await self.authorise_playback(principal, asset_version_id)
        if grant.preview or principal.anonymous:
            raise Forbidden("offline download is not permitted", code="offline_not_permitted")
        pub = await self.active_publication(asset_version_id)
        assert pub is not None  # guaranteed by authorise_playback for non-preview grants
        policy = DistributionPolicy.model_validate(pub.distribution)
        allowed = policy.offline_download == "all_viewers" or (
            policy.offline_download == "granted"
            and await self.has_grant(principal, grant.asset_id, Permission.OFFLINE_DOWNLOAD)
        )
        if not allowed:
            raise Forbidden(
                "viewing is permitted but offline download is not",
                code="offline_not_permitted",
            )
        return grant
