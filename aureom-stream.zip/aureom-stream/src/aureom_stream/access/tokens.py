"""Signed tokens using standard JOSE only: JWT (RFC 7519), JWS (RFC 7515) with
EdDSA / Ed25519 (RFC 8037, RFC 8032), implemented by PyJWT + ``cryptography``.

No bespoke cryptography: this module only chooses claims and checks them against an
injected clock (so expiry is testable without sleeping).
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import jwt
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from ..clock import Clock

ALG = "EdDSA"
TYP_PRINCIPAL = "at+jwt"
TYP_ORIGIN = "origin+jwt"
TYP_TRANSFER = "transfer+jwt"
TYP_MANIFEST = "aureom-manifest+jws"
AUD_API = "aureom-api"
AUD_ORIGIN = "aureom-origin"
CLOCK_SKEW = 5.0


class TokenError(Exception):
    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


def _b64u(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64u_decode(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def public_jwk(key: Ed25519PublicKey) -> dict[str, str]:
    raw = key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    jwk = {"crv": "Ed25519", "kty": "OKP", "x": _b64u(raw)}
    # RFC 7638 thumbprint as key id.
    canonical = json.dumps(jwk, separators=(",", ":"), sort_keys=True).encode()
    return {**jwk, "kid": _b64u(hashlib.sha256(canonical).digest()), "use": "sig", "alg": ALG}


def load_or_create_signing_key(path: Path, *, create: bool) -> Ed25519PrivateKey:
    if path.exists():
        key = serialization.load_pem_private_key(path.read_bytes(), password=None)
        if not isinstance(key, Ed25519PrivateKey):
            raise ValueError("signing key must be Ed25519")
        return key
    if not create:
        raise FileNotFoundError(f"signing key not found: {path}")
    key = Ed25519PrivateKey.generate()
    pem = key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:  # another process won the race
        return load_or_create_signing_key(path, create=False)
    with os.fdopen(fd, "wb") as fh:
        fh.write(pem)
    return key


class TokenVerifier:
    """Verifies tokens with public keys only (origin, peer agents, offline clients)."""

    def __init__(self, keys: dict[str, Ed25519PublicKey], *, issuer: str, clock: Clock) -> None:
        self._keys = dict(keys)
        self.issuer = issuer
        self._clock = clock

    @classmethod
    def from_jwks(cls, jwks: dict[str, Any], *, issuer: str, clock: Clock) -> TokenVerifier:
        keys: dict[str, Ed25519PublicKey] = {}
        for jwk in jwks.get("keys", []):
            if jwk.get("kty") == "OKP" and jwk.get("crv") == "Ed25519" and "kid" in jwk:
                keys[jwk["kid"]] = Ed25519PublicKey.from_public_bytes(_b64u_decode(jwk["x"]))
        if not keys:
            raise TokenError("no usable Ed25519 keys in JWKS")
        return cls(keys, issuer=issuer, clock=clock)

    def add_jwks(self, jwks: dict[str, Any]) -> None:
        other = TokenVerifier.from_jwks(jwks, issuer=self.issuer, clock=self._clock)
        self._keys.update(other._keys)

    def jwks(self) -> dict[str, Any]:
        return {"keys": [public_jwk(k) for k in self._keys.values()]}

    def _key_for(self, token: str, typ: str) -> Ed25519PublicKey:
        try:
            header = jwt.get_unverified_header(token)
        except jwt.PyJWTError as exc:
            raise TokenError("malformed") from exc
        if header.get("alg") != ALG:
            raise TokenError("unsupported_algorithm")
        if header.get("typ") != typ:
            raise TokenError("wrong_token_type")
        key = self._keys.get(header.get("kid", ""))
        if key is None:
            raise TokenError("unknown_key")
        return key

    def verify(self, token: str, *, typ: str, audience: str | list[str]) -> dict[str, Any]:
        """``audience`` may be a list: the token must name one of them."""
        key = self._key_for(token, typ)
        try:
            claims: dict[str, Any] = jwt.decode(
                token,
                key,
                algorithms=[ALG],
                audience=audience,
                issuer=self.issuer,
                options={
                    "verify_exp": False,  # checked below against the injected clock
                    "verify_iat": False,
                    "verify_nbf": False,
                    "require": ["exp", "iat", "sub", "aud", "iss"],
                },
            )
        except jwt.InvalidAudienceError as exc:
            raise TokenError("wrong_audience") from exc
        except jwt.PyJWTError as exc:
            raise TokenError("invalid") from exc
        now = self._clock.now()
        if now >= float(claims["exp"]):
            raise TokenError("expired")
        if float(claims["iat"]) > now + CLOCK_SKEW:
            raise TokenError("not_yet_valid")
        return claims

    def verify_jws(self, jws: str, *, typ: str) -> bytes:
        key = self._key_for(jws, typ)
        try:
            return jwt.api_jws.decode(jws, key, algorithms=[ALG])
        except jwt.PyJWTError as exc:
            raise TokenError("invalid") from exc


class TokenService(TokenVerifier):
    """Signs with the control-plane private key."""

    def __init__(self, private_key: Ed25519PrivateKey, *, issuer: str, clock: Clock) -> None:
        self._private = private_key
        self.kid = public_jwk(private_key.public_key())["kid"]
        super().__init__({self.kid: private_key.public_key()}, issuer=issuer, clock=clock)

    def sign(self, claims: dict[str, Any], *, typ: str, audience: str, ttl: float) -> str:
        now = self._clock.now()
        payload = {**claims, "iss": self.issuer, "aud": audience, "iat": int(now), "exp": now + ttl}
        return jwt.encode(payload, self._private, algorithm=ALG, headers={"kid": self.kid, "typ": typ})

    def sign_jws(self, payload: bytes, *, typ: str) -> str:
        return jwt.api_jws.encode(
            payload, self._private, algorithm=ALG, headers={"kid": self.kid, "typ": typ}
        )

    def mint_principal_token(self, subject: str, scopes: list[str], ttl: float) -> str:
        """Development helper. Deployments normally accept tokens from an external IdP."""
        return self.sign(
            {"sub": subject, "scope": " ".join(sorted(set(scopes)))},
            typ=TYP_PRINCIPAL,
            audience=AUD_API,
            ttl=ttl,
        )
