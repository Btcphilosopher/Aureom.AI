"""The controlled peer registry.

Peers are matched only inside one sharing scope (one asset version) and only among
peer sessions that were created from an *authorised* playback session. Nothing here
is announced to a public DHT or tracker, and a discovery answer only ever mentions
the segment ids the requester asked about.
"""

from __future__ import annotations

import base64
import ipaddress
import re
from datetime import timedelta

from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError as SAIntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from ..access.tokens import TYP_TRANSFER
from ..bootstrap import AppContext
from ..clock import to_datetime
from ..domain import PeerCandidate, PlaybackGrant, ReceiptReport
from ..errors import Conflict, Forbidden, Gone, NotFound, RateLimited, ValidationFailed
from ..ids import hash_token, new_id, new_secret_token, token_matches
from ..persistence.models import (
    MediaSegment,
    PeerAvailability,
    PeerSession,
    PeerState,
    PlaybackSession,
    SessionState,
    TransferGrant,
    TransferReceipt,
)
from . import reliability

TRANSPORT_LOOPBACK = "loopback-http"
TRANSPORT_MTLS = "mtls-http"
_HEX64 = re.compile(r"^[0-9a-f]{64}$")
_HOSTNAME = re.compile(r"^(?=.{1,253}$)[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9-]{1,63})*$")


def is_loopback(host: str) -> bool:
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def thumbprint_to_cnf(hex_thumbprint: str) -> dict[str, str]:
    """RFC 8705 certificate confirmation claim."""
    raw = bytes.fromhex(hex_thumbprint)
    return {"x5t#S256": base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")}


class PeerRegistry:
    def __init__(self, ctx: AppContext, session: AsyncSession) -> None:
        self._ctx = ctx
        self._db = session
        self._s = ctx.settings

    # ------------------------------------------------------------------ sessions
    async def register(
        self,
        playback: PlaybackSession,
        *,
        host: str,
        port: int,
        transport: str,
        cert_thumbprint: str | None,
        contribute: bool,
        upload_kbps_cap: int | None,
        metered: bool,
    ) -> tuple[PeerSession, str]:
        if "peer" not in playback.delivery_modes:
            raise Forbidden(
                "peer delivery is not enabled for this playback session", code="peer_not_permitted"
            )
        if transport == TRANSPORT_LOOPBACK:
            if not self._s.allow_loopback_peer_transport or not is_loopback(host):
                raise ValidationFailed(
                    "the plain-HTTP transport is a local test aid and only accepts loopback "
                    "addresses; use mtls-http for anything else",
                    code="insecure_transport",
                )
        elif transport == TRANSPORT_MTLS:
            if not cert_thumbprint or not _HEX64.match(cert_thumbprint):
                raise ValidationFailed(
                    "mtls-http requires the SHA-256 thumbprint of the peer certificate",
                    code="thumbprint_required",
                )
            try:
                ipaddress.ip_address(host)
            except ValueError:
                if not _HOSTNAME.match(host):
                    raise ValidationFailed("invalid peer host", code="invalid_endpoint") from None
        else:
            raise ValidationFailed("unknown transport", code="unknown_transport")

        now = self._ctx.clock.now()
        # One live registration per playback session.
        previous = await self._db.scalars(
            select(PeerSession).where(
                PeerSession.playback_session_id == playback.id,
                PeerSession.state == PeerState.ACTIVE.value,
            )
        )
        for old in previous:
            await self._close(old, PeerState.CLOSED)
        token = new_secret_token()
        # Contribution needs both the permission (decided at session creation) and
        # the user's explicit choice. A metered connection never contributes.
        allowed = bool(playback.peer_contribution)
        peer = PeerSession(
            id=new_id("prs"),
            principal_id=playback.principal_id,
            asset_version_id=playback.asset_version_id,
            playback_session_id=playback.id,
            token_hash=hash_token(token),
            endpoint_host=host,
            endpoint_port=port,
            transport=transport,
            cert_thumbprint=cert_thumbprint,
            contribute=bool(contribute and allowed),
            contribution_paused=metered,
            metered=metered,
            upload_kbps_cap=upload_kbps_cap,
            state=PeerState.ACTIVE.value,
            created_at=to_datetime(now),
            last_heartbeat_at=to_datetime(now),
            expires_at=to_datetime(now + self._s.peer_session_ttl_seconds),
        )
        self._db.add(peer)
        await self._db.flush()
        return peer, token

    async def authenticate(self, peer_session_id: str, token: str | None) -> PeerSession:
        peer = await self._db.get(PeerSession, peer_session_id)
        if peer is None or token is None or not token_matches(token, peer.token_hash):
            raise NotFound("peer session not found")
        now = to_datetime(self._ctx.clock.now())
        if peer.state == PeerState.ACTIVE.value and peer.expires_at <= now:
            await self._close(peer, PeerState.EXPIRED)
            await self._db.commit()
        if peer.state == PeerState.ACTIVE.value:
            playback = await self._db.get(PlaybackSession, peer.playback_session_id)
            if playback is None or playback.state != SessionState.ACTIVE.value or playback.expires_at <= now:
                revoked = playback is not None and playback.state == SessionState.REVOKED.value
                await self._close(peer, PeerState.REVOKED if revoked else PeerState.EXPIRED)
                await self._db.commit()
        if peer.state != PeerState.ACTIVE.value:
            raise Gone(f"peer session {peer.state}", code="peer_session_" + peer.state)
        return peer

    async def _close(self, peer: PeerSession, state: PeerState) -> None:
        peer.state = state.value
        peer.closed_at = to_datetime(self._ctx.clock.now())
        await self._db.execute(delete(PeerAvailability).where(PeerAvailability.peer_session_id == peer.id))

    async def close(self, peer: PeerSession) -> None:
        await self._close(peer, PeerState.CLOSED)

    async def heartbeat(
        self,
        peer: PeerSession,
        *,
        contribution_paused: bool | None,
        metered: bool | None,
        upload_kbps_cap: int | None,
    ) -> PeerSession:
        now = self._ctx.clock.now()
        peer.last_heartbeat_at = to_datetime(now)
        peer.expires_at = to_datetime(now + self._s.peer_session_ttl_seconds)
        if metered is not None:
            peer.metered = metered
        if contribution_paused is not None:
            peer.contribution_paused = contribution_paused
        if peer.metered:
            peer.contribution_paused = True
        if upload_kbps_cap is not None:
            peer.upload_kbps_cap = upload_kbps_cap
        return peer

    # ------------------------------------------------------------------ availability
    async def _segments_in_version(self, version_id: str, segment_ids: list[str]) -> set[str]:
        if not segment_ids:
            return set()
        rows = await self._db.scalars(
            select(MediaSegment.id).where(
                MediaSegment.asset_version_id == version_id, MediaSegment.id.in_(segment_ids)
            )
        )
        return set(rows)

    async def update_availability(
        self, peer: PeerSession, *, mode: str, have: list[str], drop: list[str]
    ) -> int:
        limit = self._s.availability_max_ids_per_message
        if len(have) + len(drop) > limit:
            raise ValidationFailed(f"at most {limit} segment ids per message", code="message_too_large")
        if not peer.contribute:
            raise Forbidden(
                "this peer session does not contribute, so it has nothing to announce",
                code="contribution_not_enabled",
            )
        have_set = set(have)
        valid = await self._segments_in_version(peer.asset_version_id, list(have_set))
        if valid != have_set:
            # Claims about segments outside the authorised version are refused outright.
            raise Forbidden("segment outside the authorised asset version", code="segment_out_of_scope")
        if mode == "replace":
            await self._db.execute(
                delete(PeerAvailability).where(PeerAvailability.peer_session_id == peer.id)
            )
            existing: set[str] = set()
        else:
            if drop:
                await self._db.execute(
                    delete(PeerAvailability).where(
                        PeerAvailability.peer_session_id == peer.id,
                        PeerAvailability.segment_id.in_(drop),
                    )
                )
            existing = set(
                await self._db.scalars(
                    select(PeerAvailability.segment_id).where(PeerAvailability.peer_session_id == peer.id)
                )
            )
        new = have_set - existing
        if len(existing) + len(new) > self._s.availability_max_per_peer:
            raise ValidationFailed("availability limit for one peer exceeded", code="availability_limit")
        now = to_datetime(self._ctx.clock.now())
        self._db.add_all(
            [PeerAvailability(peer_session_id=peer.id, segment_id=s, announced_at=now) for s in new]
        )
        await self._db.flush()
        return len(existing) + len(new)

    # ------------------------------------------------------------------ discovery
    async def _outcomes(self, serving_ids: list[str]) -> dict[str, list[reliability.Outcome]]:
        if not serving_ids:
            return {}
        cutoff = to_datetime(self._ctx.clock.now() - reliability.WINDOW_SECONDS)
        rows = await self._db.scalars(
            select(TransferReceipt).where(
                TransferReceipt.subject_peer_session_id.in_(serving_ids),
                TransferReceipt.role == "receiver",
                TransferReceipt.created_at >= cutoff,
            )
        )
        out: dict[str, list[reliability.Outcome]] = {}
        for r in rows:
            out.setdefault(r.subject_peer_session_id, []).append(
                reliability.Outcome(r.reporter_peer_session_id, r.outcome, r.created_at.timestamp())
            )
        return out

    async def discover(
        self,
        grant: PlaybackGrant,
        segment_ids: list[str],
        *,
        requester_peer_id: str | None = None,
    ) -> list[PeerCandidate]:
        """Peers that are authorised for ``grant``'s asset version and claim to hold some
        of ``segment_ids``. Only the requested ids are ever mentioned in the answer."""
        if not grant.peer_delivery:
            raise Forbidden("peer delivery is not permitted", code="peer_not_permitted")
        if len(segment_ids) > self._s.discovery_max_segments:
            raise ValidationFailed(
                f"at most {self._s.discovery_max_segments} segment ids per discovery",
                code="message_too_large",
            )
        wanted = set(segment_ids)
        if await self._segments_in_version(grant.asset_version_id, list(wanted)) != wanted:
            self._ctx.metrics.denials.labels(reason="discovery_out_of_scope").inc()
            raise Forbidden("segment outside the authorised asset version", code="segment_out_of_scope")
        if not wanted:
            return []
        now_epoch = self._ctx.clock.now()
        now = to_datetime(now_epoch)
        rows = await self._db.execute(
            select(PeerSession, PeerAvailability.segment_id)
            .join(PeerAvailability, PeerAvailability.peer_session_id == PeerSession.id)
            .where(
                PeerSession.asset_version_id == grant.asset_version_id,  # the sharing scope
                PeerSession.state == PeerState.ACTIVE.value,
                PeerSession.expires_at > now,
                PeerSession.contribute.is_(True),
                PeerSession.contribution_paused.is_(False),
                PeerAvailability.segment_id.in_(wanted),
            )
        )
        peers: dict[str, PeerSession] = {}
        holdings: dict[str, set[str]] = {}
        for peer, segment_id in rows:
            if peer.id == requester_peer_id:
                continue
            if peer.quarantined_until is not None and peer.quarantined_until > now:
                continue
            peers[peer.id] = peer
            holdings.setdefault(peer.id, set()).add(segment_id)
        outcomes = await self._outcomes(list(peers))
        candidates: list[PeerCandidate] = []
        for peer_id, peer in peers.items():
            view = reliability.evaluate(outcomes.get(peer_id, []), now=now_epoch)
            if view.quarantine:
                continue
            if requester_peer_id is not None and requester_peer_id in view.integrity_reporters:
                continue  # pairwise exclusion
            candidates.append(
                PeerCandidate(
                    peer_id=peer_id,
                    host=peer.endpoint_host,
                    port=peer.endpoint_port,
                    transport=peer.transport,
                    segment_ids=frozenset(holdings[peer_id]),
                    reliability=view.score,
                    cert_thumbprint=peer.cert_thumbprint,
                )
            )
        candidates.sort(key=lambda c: (-c.reliability, -len(c.segment_ids), c.peer_id))
        return candidates[: self._s.discovery_max_candidates]

    async def grant_for_peer(self, peer: PeerSession) -> PlaybackGrant:
        playback = await self._db.get(PlaybackSession, peer.playback_session_id)
        assert playback is not None
        return PlaybackGrant(
            principal_id=peer.principal_id,
            asset_id=playback.asset_id,
            asset_version_id=peer.asset_version_id,
            visibility="",
            preview=False,
            peer_delivery="peer" in playback.delivery_modes,
            may_contribute=playback.peer_contribution,
            sharing_scope=f"version:{peer.asset_version_id}",
            expires_at=playback.expires_at.timestamp(),
        )

    # ------------------------------------------------------------------ transfer grants
    async def authorise_transfer(
        self, requester: PeerSession, *, serving_peer_id: str, segment_ids: list[str]
    ) -> tuple[str, TransferGrant]:
        """Issue a short-lived grant bound to requester, serving peer, version and
        segments. Rate, concurrency and byte limits apply per requester."""
        if not segment_ids or len(segment_ids) > self._s.transfer_grant_max_segments:
            raise ValidationFailed(
                f"between 1 and {self._s.transfer_grant_max_segments} segments per grant",
                code="message_too_large",
            )
        if len(set(segment_ids)) != len(segment_ids):
            raise ValidationFailed("duplicate segment ids", code="duplicate_segments")
        now_epoch = self._ctx.clock.now()
        now = to_datetime(now_epoch)
        serving = await self._db.get(PeerSession, serving_peer_id)
        denied = Forbidden("transfer not permitted", code="transfer_not_permitted")
        if (
            serving is None
            or serving.id == requester.id
            or serving.asset_version_id != requester.asset_version_id  # same scope only
            or serving.state != PeerState.ACTIVE.value
            or serving.expires_at <= now
            or not serving.contribute
            or serving.contribution_paused
            or (serving.quarantined_until is not None and serving.quarantined_until > now)
        ):
            self._ctx.metrics.grants.labels(outcome="denied").inc()
            raise denied
        announced = set(
            await self._db.scalars(
                select(PeerAvailability.segment_id).where(
                    PeerAvailability.peer_session_id == serving.id,
                    PeerAvailability.segment_id.in_(segment_ids),
                )
            )
        )
        if announced != set(segment_ids):
            self._ctx.metrics.grants.labels(outcome="denied").inc()
            raise denied
        total = int(
            await self._db.scalar(
                select(func.coalesce(func.sum(MediaSegment.byte_length), 0)).where(
                    MediaSegment.id.in_(segment_ids)
                )
            )
            or 0
        )
        grant_id = new_id("tgr")
        ttl = self._s.transfer_grant_ttl_seconds
        coord = self._ctx.coord
        if not await coord.hit(f"grant-rate:{requester.id}", self._s.transfer_grants_per_minute, 60):
            self._ctx.metrics.grants.labels(outcome="rate_limited").inc()
            raise RateLimited("transfer grant rate limit reached", code="grant_rate_limited")
        if not await coord.hit(
            f"grant-bytes:{requester.id}", self._s.transfer_grant_bytes_per_minute, 60, total
        ):
            self._ctx.metrics.grants.labels(outcome="rate_limited").inc()
            raise RateLimited("transfer byte budget exhausted", code="grant_byte_limited")
        if not await coord.acquire_slot(
            f"grant-conc:{requester.id}", grant_id, self._s.transfer_grant_max_concurrent, ttl
        ):
            self._ctx.metrics.grants.labels(outcome="rate_limited").inc()
            raise RateLimited("too many concurrent transfers", code="grant_concurrency_limited")
        claims: dict[str, object] = {
            "sub": requester.id,
            "jti": grant_id,
            "ver": requester.asset_version_id,
            "segs": list(segment_ids),
            "max_bytes": total,
        }
        if requester.cert_thumbprint:
            claims["cnf"] = thumbprint_to_cnf(requester.cert_thumbprint)
        token = self._ctx.tokens.sign(claims, typ=TYP_TRANSFER, audience=serving.id, ttl=ttl)
        grant = TransferGrant(
            id=grant_id,
            requester_peer_session_id=requester.id,
            serving_peer_session_id=serving.id,
            asset_version_id=requester.asset_version_id,
            segment_ids=list(segment_ids),
            max_bytes=total,
            issued_at=now,
            expires_at=to_datetime(now_epoch + ttl),
        )
        self._db.add(grant)
        await self._db.flush()
        self._ctx.metrics.grants.labels(outcome="issued").inc()
        return token, grant

    # ------------------------------------------------------------------ receipts
    async def record_receipt(self, reporter: PeerSession, report: ReceiptReport) -> TransferReceipt:
        """Store a *self-reported* receipt. It feeds the bounded reliability rules and
        nothing else; it is never billing-grade or proof of delivery."""
        grant = await self._db.get(TransferGrant, report.grant_id)
        if grant is None:
            raise NotFound("grant not found")
        expected_role = {
            grant.requester_peer_session_id: "receiver",
            grant.serving_peer_session_id: "sender",
        }.get(reporter.id)
        if expected_role is None:
            raise NotFound("grant not found")  # not a party: do not confirm it exists
        if report.role != expected_role:
            raise ValidationFailed(f"this peer is the {expected_role} of the grant", code="wrong_role")
        if report.segment_id not in grant.segment_ids:
            raise ValidationFailed("segment is not covered by the grant", code="segment_not_in_grant")
        if report.bytes_transferred > grant.max_bytes:
            raise ValidationFailed("reported bytes exceed the grant", code="bytes_exceed_grant")
        late = to_datetime(self._ctx.clock.now()) > grant.expires_at + timedelta(minutes=5)
        if late:
            raise Conflict("receipt window for this grant has closed", code="receipt_too_late")
        subject = (
            grant.serving_peer_session_id if expected_role == "receiver" else grant.requester_peer_session_id
        )
        existing = await self._db.scalar(
            select(TransferReceipt).where(
                TransferReceipt.grant_id == grant.id,
                TransferReceipt.reporter_peer_session_id == reporter.id,
                TransferReceipt.segment_id == report.segment_id,
            )
        )
        if existing is not None:
            return existing
        receipt = TransferReceipt(
            id=new_id("rcp"),
            grant_id=grant.id,
            reporter_peer_session_id=reporter.id,
            subject_peer_session_id=subject,
            role=expected_role,
            segment_id=report.segment_id,
            bytes_transferred=report.bytes_transferred,
            outcome=report.outcome,
            duration_ms=report.duration_ms,
            corroborated=False,
            created_at=to_datetime(self._ctx.clock.now()),
        )
        self._db.add(receipt)
        try:
            await self._db.flush()
        except SAIntegrityError:
            await self._db.rollback()
            raise Conflict("duplicate receipt", code="duplicate_receipt") from None
        counterpart = await self._db.scalar(
            select(TransferReceipt).where(
                TransferReceipt.grant_id == grant.id,
                TransferReceipt.reporter_peer_session_id == subject,
                TransferReceipt.segment_id == report.segment_id,
            )
        )
        if (
            counterpart is not None
            and counterpart.bytes_transferred == receipt.bytes_transferred
            and {counterpart.outcome, receipt.outcome} == {"verified"}
        ):
            # Both ends agree. Still two self-reports - "corroborated", not "verified".
            counterpart.corroborated = True
            receipt.corroborated = True
        self._ctx.metrics.receipts.labels(role=expected_role, outcome=report.outcome).inc()
        if expected_role == "receiver":
            await self._ctx.coord.release_slot(f"grant-conc:{reporter.id}", grant.id)
            if report.outcome == "not_found":
                # Misreported availability: forget this one claim.
                await self._db.execute(
                    delete(PeerAvailability).where(
                        PeerAvailability.peer_session_id == subject,
                        PeerAvailability.segment_id == report.segment_id,
                    )
                )
            if report.outcome in reliability.INTEGRITY_FAILURES:
                await self._maybe_quarantine(subject)
        return receipt

    async def _maybe_quarantine(self, serving_peer_id: str) -> None:
        outcomes = (await self._outcomes([serving_peer_id])).get(serving_peer_id, [])
        view = reliability.evaluate(outcomes, now=self._ctx.clock.now())
        if view.quarantine:
            peer = await self._db.get(PeerSession, serving_peer_id)
            if peer is not None:
                peer.quarantined_until = to_datetime(self._ctx.clock.now() + self._s.peer_quarantine_seconds)
