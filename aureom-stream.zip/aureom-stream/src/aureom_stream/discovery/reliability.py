"""Peer reliability: bounded, explainable rules over self-reported receipts.

Receipts are claims, not proof, so no single reporter can do much:

1. Only *receiver* receipts about a serving peer inside a sliding window count
   (``WINDOW_SECONDS``, newest ``MAX_OUTCOMES``).
2. Each distinct reporter contributes at most ``PER_REPORTER_CAP`` outcomes, so one
   noisy or malicious reporter cannot dominate a peer's score.
3. ``score = (ok + PRIOR) / (ok + bad + PRIOR)`` - new peers start at 1.0 and the
   score is only used to *rank* candidates.
4. A peer is quarantined (hidden from discovery for a fixed time) only when at least
   ``QUARANTINE_REPORTERS`` distinct reporters reported integrity failures
   (``corrupt`` / ``length_mismatch``) in the window.
5. A reporter is never offered a peer it reported an integrity failure against in the
   window (pairwise exclusion) - that needs no corroboration because it only affects
   the reporter itself.
"""

from __future__ import annotations

from dataclasses import dataclass

WINDOW_SECONDS = 600.0
MAX_OUTCOMES = 50
PER_REPORTER_CAP = 5
PRIOR = 2.0
QUARANTINE_REPORTERS = 2
INTEGRITY_FAILURES = frozenset({"corrupt", "length_mismatch"})
BAD_OUTCOMES = INTEGRITY_FAILURES | {"timeout", "refused", "not_found", "error"}


@dataclass(frozen=True)
class Outcome:
    reporter: str
    outcome: str
    at: float  # epoch seconds


@dataclass(frozen=True)
class ReliabilityView:
    score: float
    ok: int
    bad: int
    integrity_reporters: frozenset[str]
    quarantine: bool
    reasons: tuple[str, ...]


def evaluate(outcomes: list[Outcome], *, now: float) -> ReliabilityView:
    recent = sorted((o for o in outcomes if now - WINDOW_SECONDS <= o.at <= now), key=lambda o: -o.at)[
        :MAX_OUTCOMES
    ]
    per_reporter: dict[str, int] = {}
    ok = bad = 0
    integrity: set[str] = set()
    for outcome in recent:
        if outcome.outcome in INTEGRITY_FAILURES:
            integrity.add(outcome.reporter)  # distinct reporters, not capped away
        used = per_reporter.get(outcome.reporter, 0)
        if used >= PER_REPORTER_CAP:
            continue
        per_reporter[outcome.reporter] = used + 1
        if outcome.outcome == "verified":
            ok += 1
        elif outcome.outcome in BAD_OUTCOMES:
            bad += 1
    score = (ok + PRIOR) / (ok + bad + PRIOR)
    quarantine = len(integrity) >= QUARANTINE_REPORTERS
    reasons = [f"{ok} verified / {bad} failed outcomes counted in the last {int(WINDOW_SECONDS)}s"]
    if quarantine:
        reasons.append(f"integrity failures reported by {len(integrity)} distinct peers")
    return ReliabilityView(
        score=round(score, 4),
        ok=ok,
        bad=bad,
        integrity_reporters=frozenset(integrity),
        quarantine=quarantine,
        reasons=tuple(reasons),
    )
