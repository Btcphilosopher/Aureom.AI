"""Rendition ladder planning: preserve aspect ratio, never upscale, at least two rungs."""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction


@dataclass(frozen=True)
class Rung:
    name: str
    height: int
    video_kbps: int
    audio_kbps: int


# Reference rungs for 16:9 H.264. Bitrates scale with pixel count for other shapes.
LADDER = (
    Rung("1080p", 1080, 5000, 128),
    Rung("720p", 720, 2800, 128),
    Rung("480p", 480, 1400, 96),
    Rung("360p", 360, 800, 96),
    Rung("240p", 240, 400, 64),
    Rung("144p", 144, 200, 48),
)


@dataclass(frozen=True)
class PlannedRendition:
    name: str
    width: int
    height: int
    video_kbps: int
    audio_kbps: int


def _even(value: float) -> int:
    return max(2, int(round(value / 2.0)) * 2)


def _kbps_for(height: int, width: int) -> tuple[int, int]:
    """Bitrate for an arbitrary frame size, scaled from the nearest reference rung."""
    rung = min(LADDER, key=lambda r: abs(r.height - height))
    reference_pixels = rung.height * rung.height * 16 / 9
    scale = (width * height / reference_pixels) ** 0.75
    return max(100, int(rung.video_kbps * scale)), rung.audio_kbps


def plan_renditions(display_width: int, height: int, *, max_renditions: int = 4) -> list[PlannedRendition]:
    """Plan output sizes for a source of ``display_width`` x ``height`` square pixels.

    * the top rung is the source size itself (rounded to even) - never larger;
    * lower rungs come from the reference ladder, keeping the source aspect ratio;
    * if the source is too small for a second size, a second rung is produced at the
      same size and half the bitrate, so adaptive switching still has two choices.
    """
    if display_width < 16 or height < 16:
        raise ValueError("source frame is too small")
    aspect = Fraction(display_width, height)
    top_height = _even(height)
    heights = [top_height] + [r.height for r in LADDER if r.height <= top_height * 0.85]
    heights = heights[:max_renditions]
    planned: list[PlannedRendition] = []
    for h in heights:
        w = _even(float(h * aspect))
        if h == top_height:
            w = min(w, _even(display_width))
        video, audio = _kbps_for(h, w)
        planned.append(PlannedRendition(f"{h}p", w, h, video, audio))
    if len(planned) == 1:
        only = planned[0]
        planned.append(
            PlannedRendition(
                f"{only.height}p-low",
                only.width,
                only.height,
                max(64, only.video_kbps // 2),
                only.audio_kbps,
            )
        )
    return planned
