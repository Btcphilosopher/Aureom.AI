"""FFmpeg argument builders for transcoding and HLS/fMP4 packaging, and inspection of
the packaged output.

Every argument is either a constant, a validated number, or a fixed file name chosen
by this module. Nothing derived from user input reaches the command line.
"""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path

from ..manifests.playlists import parse_media_playlist
from ..processing.errors import ProcessingError
from .ladder import PlannedRendition

SOURCE_NAME = "source.bin"
_SEGMENT_RE = re.compile(r"^seg_\d{5}\.m4s$")
INIT_NAME = "init.mp4"


def output_frame_rate(source: Fraction) -> Fraction:
    """Clamp to 60 fps and snap to a rational FFmpeg handles exactly."""
    rate = min(source, Fraction(60))
    return rate.limit_denominator(1001)


def transcode_args(
    *,
    demuxer: str,
    rendition: PlannedRendition,
    frame_rate: Fraction,
    segment_seconds: float,
    has_audio: bool,
    threads: int,
    output_name: str,
) -> list[str]:
    """Encode one rendition to an intermediate MP4 with keyframes exactly on segment
    boundaries (identical for every rendition, so segments align across the ladder)."""
    if not 1.0 <= segment_seconds <= 10.0:
        raise ValueError("segment duration out of range")
    gop = max(1, math.ceil(float(frame_rate) * segment_seconds))
    video_k = rendition.video_kbps
    args = [
        "-protocol_whitelist", "file", "-f", demuxer, "-i", SOURCE_NAME,
        "-map", "0:v:0",
    ]  # fmt: skip
    if has_audio:
        args += ["-map", "0:a:0"]
    args += [
        "-sn", "-dn", "-map_metadata", "-1", "-map_chapters", "-1",
        "-vf", f"scale={rendition.width}:{rendition.height}:flags=bicubic,setsar=1,format=yuv420p",
        "-fps_mode", "cfr", "-r", f"{frame_rate.numerator}/{frame_rate.denominator}",
        "-c:v", "libx264", "-preset", "veryfast", "-profile:v", "main",
        "-b:v", f"{video_k}k", "-maxrate", f"{int(video_k * 1.1)}k", "-bufsize", f"{video_k * 2}k",
        "-g", str(gop), "-keyint_min", str(gop), "-sc_threshold", "0",
        "-force_key_frames", f"expr:gte(t,n_forced*{segment_seconds:g})",
        "-threads", str(threads),
    ]  # fmt: skip
    if has_audio:
        args += ["-c:a", "aac", "-b:a", f"{rendition.audio_kbps}k", "-ac", "2", "-ar", "48000"]
    args += ["-movflags", "+faststart", "-f", "mp4", output_name]
    return args


def package_args(*, input_name: str, out_dir: str, segment_seconds: float) -> list[str]:
    """Remux (no re-encode) an intermediate MP4 into HLS with fragmented MP4 segments."""
    return [
        "-protocol_whitelist", "file", "-f", "mov,mp4,m4a,3gp,3g2,mj2", "-i", input_name,
        "-map", "0", "-c", "copy",
        "-f", "hls", "-hls_time", f"{segment_seconds:g}", "-hls_playlist_type", "vod",
        "-hls_segment_type", "fmp4", "-hls_flags", "independent_segments",
        "-hls_list_size", "0",
        "-hls_fmp4_init_filename", INIT_NAME,
        "-hls_segment_filename", f"{out_dir}/seg_%05d.m4s",
        f"{out_dir}/index.m3u8",
    ]  # fmt: skip


def thumbnail_args(*, demuxer: str, at_seconds: float, output_name: str) -> list[str]:
    return [
        "-protocol_whitelist", "file", "-f", demuxer, "-ss", f"{max(0.0, at_seconds):.3f}",
        "-i", SOURCE_NAME, "-map", "0:v:0", "-frames:v", "1",
        "-vf", "scale=320:-2:flags=bicubic", "-f", "image2", "-c:v", "mjpeg", "-q:v", "4",
        output_name,
    ]  # fmt: skip


@dataclass(frozen=True)
class PackagedSegment:
    kind: str  # "init" | "media"
    sequence_number: int
    start_time: float
    duration: float
    byte_length: int
    sha256: str
    path: Path


@dataclass(frozen=True)
class PackagedRendition:
    planned: PlannedRendition
    codecs: str
    video_codec: str
    audio_codec: str | None
    bandwidth: int
    average_bandwidth: int
    segments: list[PackagedSegment]  # init first

    @property
    def media(self) -> list[PackagedSegment]:
        return [s for s in self.segments if s.kind == "media"]

    @property
    def total_bytes(self) -> int:
        return sum(s.byte_length for s in self.segments)


def _hash_file(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    with open(path, "rb") as fh:
        while chunk := fh.read(1 << 20):
            digest.update(chunk)
            size += len(chunk)
    return size, digest.hexdigest()


def avc_codec_string(init_bytes: bytes) -> str:
    """RFC 6381 ``avc1.PPCCLL`` from the avcC box of an init segment."""
    at = init_bytes.find(b"avcC")
    if at < 0 or at + 8 > len(init_bytes):
        raise ProcessingError("packaging_invalid", "init segment has no avcC box", retryable=False)
    profile, compat, level = init_bytes[at + 5], init_bytes[at + 6], init_bytes[at + 7]
    return f"avc1.{profile:02x}{compat:02x}{level:02x}"


def inspect_packaged(out_dir: Path, planned: PlannedRendition, *, has_audio: bool) -> PackagedRendition:
    """Read the packaged output and hash every file *after* final packaging."""
    playlist = parse_media_playlist((out_dir / "index.m3u8").read_text("utf-8"))
    if playlist.init_uri != INIT_NAME:
        raise ProcessingError("packaging_invalid", "unexpected init segment name", retryable=False)
    init_path = out_dir / INIT_NAME
    size, digest = _hash_file(init_path)
    segments = [PackagedSegment("init", 0, 0.0, 0.0, size, digest, init_path)]
    cursor = 0.0
    for index, (uri, duration) in enumerate(playlist.segments):
        if not _SEGMENT_RE.match(uri):
            raise ProcessingError("packaging_invalid", "unexpected segment name", retryable=False)
        path = out_dir / uri
        size, digest = _hash_file(path)
        if size == 0 or duration <= 0:
            raise ProcessingError("packaging_invalid", "empty media segment", retryable=False)
        segments.append(PackagedSegment("media", index, cursor, duration, size, digest, path))
        cursor += duration
    media = segments[1:]
    peak = max(int(s.byte_length * 8 / s.duration) for s in media)
    average = int(sum(s.byte_length for s in media) * 8 / max(cursor, 1e-6))
    video_codec = avc_codec_string(init_path.read_bytes())
    codecs = f"{video_codec},mp4a.40.2" if has_audio else video_codec
    return PackagedRendition(
        planned=planned,
        codecs=codecs,
        video_codec="h264",
        audio_codec="aac" if has_audio else None,
        bandwidth=peak,
        average_bandwidth=average,
        segments=segments,
    )


def check_alignment(renditions: list[PackagedRendition], *, tolerance: float) -> None:
    """Segment boundaries must match across renditions or switching would glitch."""
    reference = renditions[0].media
    for other in renditions[1:]:
        media = other.media
        if len(media) != len(reference):
            raise ProcessingError(
                "segments_not_aligned",
                "renditions have different segment counts",
                retryable=False,
                detail={"counts": [len(r.media) for r in renditions]},
            )
        for a, b in zip(reference, media, strict=True):
            if abs(a.start_time - b.start_time) > tolerance or abs(a.duration - b.duration) > tolerance:
                raise ProcessingError(
                    "segments_not_aligned",
                    f"segment {a.sequence_number} boundaries differ between renditions",
                    retryable=False,
                )
