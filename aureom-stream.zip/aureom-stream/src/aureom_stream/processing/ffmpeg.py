"""Constrained FFmpeg / ffprobe subprocess adapter.

Guarantees provided here:

* argument arrays only - there is no shell, and no user-controlled string (filename,
  title, content type) is ever placed in an argument; inputs and outputs are fixed
  names inside a private work directory;
* the demuxer is forced from our own byte sniffing and ``-protocol_whitelist file``
  is set, so an input cannot make FFmpeg fetch URLs or follow playlist references;
* wall-clock timeout, CPU-seconds, address-space, output-file-size and open-file
  limits (``setrlimit``), a minimal environment, a bounded work directory, and
  optionally an empty network namespace;
* structured progress (``-progress pipe:1``) and structured errors.

Filesystem isolation beyond the work directory is the job of the worker container
(read-only root filesystem, tmpfs work dir, non-root user) - see ``compose.yaml``.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import resource
import shutil
import signal
import subprocess
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any

from .errors import ProcessingError

ProgressCallback = Callable[[float], Awaitable[None]]
CancelCheck = Callable[[], Awaitable[bool]]


@dataclass(frozen=True)
class ResourceLimits:
    timeout_seconds: float = 1800.0
    cpu_seconds: int = 3600
    memory_bytes: int = 4 * 1024**3
    max_file_bytes: int = 8 * 1024**3
    work_dir_max_bytes: int = 8 * 1024**3
    max_open_files: int = 256


@dataclass(frozen=True)
class ProbeResult:
    duration: float
    width: int
    height: int
    frame_rate: Fraction
    video_codec: str
    pixel_format: str | None
    sample_aspect_ratio: Fraction
    has_audio: bool
    audio_codec: str | None
    format_name: str

    @property
    def display_width(self) -> int:
        return max(2, round(self.width * self.sample_aspect_ratio))

    def summary(self) -> dict[str, Any]:
        return {
            "duration": self.duration,
            "width": self.width,
            "height": self.height,
            "frame_rate": float(self.frame_rate),
            "video_codec": self.video_codec,
            "audio_codec": self.audio_codec,
            "format_name": self.format_name,
        }


def _fraction(text: str | None, default: Fraction) -> Fraction:
    try:
        if not text or text in {"0/0", "N/A"}:
            return default
        num, _, den = text.replace(":", "/").partition("/")
        value = Fraction(int(num), int(den or 1))
        return value if value > 0 else default
    except (ValueError, ZeroDivisionError):
        return default


def dir_size(path: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            with contextlib.suppress(OSError):
                total += os.lstat(os.path.join(root, name)).st_size
    return total


def sandbox_available() -> bool:
    exe = shutil.which("unshare")
    if exe is None:
        return False
    try:
        return (
            subprocess.run(  # noqa: S603
                [exe, "--net", "--map-root-user", "true"], capture_output=True, timeout=5, check=False
            ).returncode
            == 0
        )
    except (OSError, subprocess.SubprocessError):
        return False


class FfmpegAdapter:
    def __init__(
        self,
        *,
        ffmpeg_path: str = "ffmpeg",
        ffprobe_path: str = "ffprobe",
        limits: ResourceLimits | None = None,
        sandbox: str = "none",
        threads: int = 2,
    ) -> None:
        self.ffmpeg_path = ffmpeg_path
        self.ffprobe_path = ffprobe_path
        self.limits = limits or ResourceLimits()
        self.sandbox = sandbox
        self.threads = threads

    # ------------------------------------------------------------------ process control
    def _preexec(self) -> None:  # runs in the child between fork and exec
        limits = self.limits
        resource.setrlimit(resource.RLIMIT_CPU, (limits.cpu_seconds, limits.cpu_seconds))
        resource.setrlimit(resource.RLIMIT_AS, (limits.memory_bytes, limits.memory_bytes))
        resource.setrlimit(resource.RLIMIT_FSIZE, (limits.max_file_bytes, limits.max_file_bytes))
        resource.setrlimit(resource.RLIMIT_NOFILE, (limits.max_open_files, limits.max_open_files))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    def _argv(self, program: str, args: list[str]) -> list[str]:
        for arg in args:
            if not isinstance(arg, str) or "\x00" in arg:
                raise ValueError("invalid subprocess argument")
        argv = [program, *args]
        if self.sandbox == "unshare-net":
            return ["unshare", "--net", "--map-root-user", "--", *argv]
        return argv

    async def _spawn(self, program: str, args: list[str], cwd: Path) -> asyncio.subprocess.Process:
        try:
            return await asyncio.create_subprocess_exec(
                *self._argv(program, args),
                cwd=str(cwd),
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "LC_ALL": "C", "HOME": str(cwd)},
                start_new_session=True,  # own process group, so the whole tree can be killed
                preexec_fn=self._preexec,
                close_fds=True,
            )
        except FileNotFoundError as exc:
            raise ProcessingError("tool_missing", f"{program} is not installed", retryable=False) from exc

    @staticmethod
    def _kill(proc: asyncio.subprocess.Process) -> None:
        with contextlib.suppress(ProcessLookupError, PermissionError):
            os.killpg(proc.pid, signal.SIGKILL)

    # ------------------------------------------------------------------ ffprobe
    async def probe(self, cwd: Path, filename: str, demuxer: str) -> ProbeResult:
        args = [
            "-v", "error", "-protocol_whitelist", "file", "-f", demuxer,
            "-show_entries",
            "format=duration,format_name:stream=codec_type,codec_name,width,height,"
            "r_frame_rate,avg_frame_rate,sample_aspect_ratio,pix_fmt,duration",
            "-of", "json", "-i", filename,
        ]  # fmt: skip
        proc = await self._spawn(self.ffprobe_path, args, cwd)
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout=60)
        except TimeoutError as exc:
            self._kill(proc)
            await proc.wait()
            raise ProcessingError("probe_timeout", "ffprobe timed out", retryable=False) from exc
        except asyncio.CancelledError:
            self._kill(proc)
            raise
        if proc.returncode != 0:
            raise ProcessingError(
                "invalid_media",
                "the uploaded file could not be read as media",
                retryable=False,
                detail={"stderr": _tail(err)},
            )
        try:
            data = json.loads(out.decode("utf-8", "replace"))
        except json.JSONDecodeError as exc:
            raise ProcessingError("invalid_media", "unreadable probe output", retryable=False) from exc
        streams = data.get("streams", [])
        video = next((s for s in streams if s.get("codec_type") == "video"), None)
        audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
        if video is None or not video.get("width") or not video.get("height"):
            raise ProcessingError("no_video_stream", "no video stream found", retryable=False)
        duration = 0.0
        for candidate in (data.get("format", {}).get("duration"), video.get("duration")):
            with contextlib.suppress(TypeError, ValueError):
                duration = max(duration, float(candidate))
        if duration <= 0:
            raise ProcessingError("invalid_media", "media has no duration", retryable=False)
        rate = _fraction(video.get("avg_frame_rate"), Fraction(0))
        if rate <= 0 or rate > 240:
            rate = _fraction(video.get("r_frame_rate"), Fraction(25))
        return ProbeResult(
            duration=duration,
            width=int(video["width"]),
            height=int(video["height"]),
            frame_rate=rate,
            video_codec=str(video.get("codec_name", "unknown")),
            pixel_format=video.get("pix_fmt"),
            sample_aspect_ratio=_fraction(video.get("sample_aspect_ratio"), Fraction(1)),
            has_audio=audio is not None,
            audio_codec=audio.get("codec_name") if audio else None,
            format_name=str(data.get("format", {}).get("format_name", "")),
        )

    # ------------------------------------------------------------------ ffmpeg
    async def run(
        self,
        args: list[str],
        *,
        cwd: Path,
        duration: float | None = None,
        on_progress: ProgressCallback | None = None,
        should_cancel: CancelCheck | None = None,
    ) -> None:
        """Run FFmpeg with ``args`` (an argument array) inside ``cwd``."""
        base = ["-nostdin", "-hide_banner", "-loglevel", "error", "-y", "-nostats", "-progress", "pipe:1"]
        proc = await self._spawn(self.ffmpeg_path, base + args, cwd)
        assert proc.stdout is not None and proc.stderr is not None
        stderr_tail = bytearray()
        failure: ProcessingError | None = None

        async def read_stderr() -> None:
            assert proc.stderr is not None
            while chunk := await proc.stderr.read(4096):
                stderr_tail.extend(chunk)
                del stderr_tail[:-4096]

        async def read_progress() -> None:
            assert proc.stdout is not None
            while line := await proc.stdout.readline():
                key, _, value = line.decode("ascii", "replace").strip().partition("=")
                if key == "out_time_us" and duration and on_progress and value.lstrip("-").isdigit():
                    await on_progress(min(1.0, max(0.0, int(value) / 1e6 / duration)))

        async def watchdog() -> None:
            nonlocal failure
            while True:
                await asyncio.sleep(0.25)
                if should_cancel is not None and await should_cancel():
                    failure = ProcessingError("cancelled", "job was cancelled", retryable=False)
                elif dir_size(cwd) > self.limits.work_dir_max_bytes:
                    failure = ProcessingError(
                        "work_dir_quota_exceeded", "temporary storage limit exceeded", retryable=False
                    )
                if failure is not None:
                    self._kill(proc)
                    return

        tasks = [asyncio.ensure_future(t) for t in (read_stderr(), read_progress(), watchdog())]
        try:
            await asyncio.wait_for(proc.wait(), timeout=self.limits.timeout_seconds)
            await asyncio.gather(*tasks[:2], return_exceptions=True)
        except TimeoutError as exc:
            self._kill(proc)
            await proc.wait()
            raise ProcessingError(
                "ffmpeg_timeout",
                f"FFmpeg exceeded the {self.limits.timeout_seconds:.0f}s time limit",
                retryable=False,
            ) from exc
        except asyncio.CancelledError:
            self._kill(proc)
            raise
        finally:
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        if failure is not None:
            raise failure
        if proc.returncode != 0:
            code = "ffmpeg_killed" if (proc.returncode or 0) < 0 else "ffmpeg_failed"
            raise ProcessingError(
                code,
                "FFmpeg could not process the media",
                retryable=False,
                detail={"returncode": proc.returncode, "stderr": _tail(bytes(stderr_tail))},
            )


def _tail(data: bytes, limit: int = 1500) -> str:
    return data.decode("utf-8", "replace")[-limit:]
