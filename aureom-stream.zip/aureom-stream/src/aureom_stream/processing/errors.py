"""Structured processing errors (stored on the job, returned by the API)."""

from __future__ import annotations

from typing import Any


class ProcessingError(Exception):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        retryable: bool,
        stage: str | None = None,
        detail: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.retryable = retryable
        self.stage = stage
        self.detail = detail or {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "stage": self.stage,
            "retryable": self.retryable,
            "detail": self.detail,
        }


class JobCancelled(Exception):
    pass
