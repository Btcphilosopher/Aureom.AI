"""Background worker: claims jobs from PostgreSQL with a lease and runs the pipeline.

Restart recovery: a job whose worker died keeps ``status = running`` but its lease
expires; any worker may then re-claim it. Each claim counts as an attempt and a job
that keeps killing its worker is failed after ``job_max_attempts``.
"""

from __future__ import annotations

import asyncio
import logging

from sqlalchemy import and_, or_, select, update

from ..bootstrap import AppContext
from ..clock import to_datetime
from ..ids import new_id
from ..maintenance import sweep
from ..persistence.models import AssetVersion, JobStatus, ProcessingJob, VersionState
from .pipeline import MediaPipeline, ProcessingResult

logger = logging.getLogger("aureom.worker")


class Worker:
    def __init__(
        self, ctx: AppContext, pipeline: MediaPipeline | None = None, worker_id: str | None = None
    ) -> None:
        self._ctx = ctx
        self._pipeline = pipeline or MediaPipeline(ctx)
        self.worker_id = worker_id or new_id("wrk")

    async def claim_next(self) -> str | None:
        """Claim one runnable job; returns its upload id.

        Two layers keep concurrent workers apart: ``FOR UPDATE SKIP LOCKED`` on
        PostgreSQL, and - on every backend - a compare-and-swap ``UPDATE`` that only
        succeeds if the job is still in the state this worker observed."""
        s = self._ctx.settings
        while True:
            async with self._ctx.db.session() as db:
                now = to_datetime(self._ctx.clock.now())
                job = await db.scalar(
                    select(ProcessingJob)
                    .where(
                        or_(
                            ProcessingJob.status == JobStatus.QUEUED.value,
                            and_(
                                ProcessingJob.status == JobStatus.RUNNING.value,
                                ProcessingJob.lease_expires_at < now,
                            ),
                        )
                    )
                    .order_by(ProcessingJob.created_at)
                    .limit(1)
                    .with_for_update(skip_locked=True)
                )
                if job is None:
                    return None
                job_id, upload_id, version_id = job.id, job.upload_id, job.asset_version_id
                seen_status, seen_attempt, stage = job.status, job.attempt, job.stage
                db.expunge(job)
                version_state: str | None = None
                values: dict[str, object]
                if job.cancel_requested:
                    values = {"status": JobStatus.CANCELLED.value, "finished_at": now}
                    version_state = VersionState.CANCELLED.value
                elif seen_attempt >= job.max_attempts:
                    values = {
                        "status": JobStatus.FAILED.value,
                        "finished_at": now,
                        "lease_owner": None,
                        "lease_expires_at": None,
                        "error": {
                            "code": "max_attempts_exceeded",
                            "message": "processing did not complete after repeated attempts",
                            "stage": stage,
                            "retryable": False,
                            "detail": {"attempts": seen_attempt},
                        },
                    }
                    version_state = VersionState.FAILED.value
                else:
                    values = {
                        "status": JobStatus.RUNNING.value,
                        "attempt": seen_attempt + 1,
                        "lease_owner": self.worker_id,
                        "lease_expires_at": to_datetime(self._ctx.clock.now() + s.job_lease_seconds),
                        "started_at": job.started_at or now,
                    }
                result = await db.execute(
                    update(ProcessingJob)
                    .where(
                        ProcessingJob.id == job_id,
                        ProcessingJob.status == seen_status,
                        ProcessingJob.attempt == seen_attempt,
                    )
                    .values(updated_at=now, **values)
                )
                if result.rowcount != 1:  # type: ignore[attr-defined]
                    continue  # another worker got there first
                if version_state is not None:
                    await db.execute(
                        update(AssetVersion).where(AssetVersion.id == version_id).values(state=version_state)
                    )
                    continue
                if seen_status == JobStatus.RUNNING.value:
                    logger.warning(
                        "recovered job %s after lease expiry (attempt %d)", job_id, seen_attempt + 1
                    )
                return upload_id

    async def run_once(self) -> ProcessingResult | None:
        upload_id = await self.claim_next()
        if upload_id is None:
            return None
        return await self._pipeline.process(upload_id, worker_id=self.worker_id)

    async def run_forever(self, stop: asyncio.Event, *, sweep_every: float = 5.0) -> None:
        last_sweep = 0.0
        while not stop.is_set():
            try:
                now = self._ctx.clock.now()
                if now - last_sweep >= sweep_every:
                    last_sweep = now
                    await sweep(self._ctx)
                if await self.run_once() is None:
                    try:
                        await asyncio.wait_for(stop.wait(), self._ctx.settings.worker_poll_seconds)
                    except TimeoutError:
                        pass
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("worker loop error")
                await asyncio.sleep(1.0)
