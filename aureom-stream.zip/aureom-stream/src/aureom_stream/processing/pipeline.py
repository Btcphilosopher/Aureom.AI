"""The processing pipeline.

    Uploaded -> Validating -> Transcoding -> Packaging -> Ready for review

(``Published`` is a separate, authorised action in the catalogue.) Failures and
cancellation are terminal states with a structured error.

Every attempt writes its output under its own storage prefix
(``media/<version>/<job>-<attempt>/``), so bytes are never overwritten; rows for
renditions and segments are inserted in the same transaction that moves the version
to ``ready_for_review``, so a failed attempt leaves nothing half-visible.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from sqlalchemy import select

from ..bootstrap import AppContext
from ..clock import to_datetime
from ..ids import new_id
from ..observability.logging import log
from ..packaging.hls import (
    SOURCE_NAME,
    PackagedRendition,
    check_alignment,
    inspect_packaged,
    output_frame_rate,
    package_args,
    thumbnail_args,
    transcode_args,
)
from ..packaging.ladder import plan_renditions
from ..persistence.models import (
    AssetVersion,
    JobStatus,
    MediaSegment,
    ProcessingJob,
    Rendition,
    SourceUpload,
    UploadState,
    VersionState,
)
from ..uploads.sniff import ALLOWED, sniff_container
from .errors import JobCancelled, ProcessingError
from .ffmpeg import FfmpegAdapter, ProbeResult, ResourceLimits

logger = logging.getLogger("aureom.processing")

_ALLOWED_VIDEO_CODECS = {
    "h264", "hevc", "vp8", "vp9", "av1", "mpeg4", "mpeg2video", "prores", "mjpeg", "theora",
}  # fmt: skip


@dataclass(frozen=True)
class ProcessingResult:
    job_id: str
    asset_version_id: str
    status: str
    stage: str
    renditions: list[dict[str, Any]] = field(default_factory=list)
    error: dict[str, Any] | None = None


def adapter_from_settings(ctx: AppContext) -> FfmpegAdapter:
    s = ctx.settings
    return FfmpegAdapter(
        ffmpeg_path=s.ffmpeg_path,
        ffprobe_path=s.ffprobe_path,
        limits=ResourceLimits(
            timeout_seconds=s.ffmpeg_timeout_seconds,
            cpu_seconds=s.ffmpeg_cpu_seconds,
            memory_bytes=s.ffmpeg_memory_bytes,
            max_file_bytes=s.work_dir_max_bytes,
            work_dir_max_bytes=s.work_dir_max_bytes,
        ),
        sandbox=s.ffmpeg_sandbox,
        threads=s.ffmpeg_threads,
    )


class MediaPipeline:
    def __init__(self, ctx: AppContext, ffmpeg: FfmpegAdapter | None = None) -> None:
        self._ctx = ctx
        self._ffmpeg = ffmpeg or adapter_from_settings(ctx)
        self._s = ctx.settings

    # ------------------------------------------------------------------ job state
    async def _set_stage(self, job_id: str, stage: VersionState, progress: float = 0.0) -> None:
        async with self._ctx.db.session() as db:
            job = await db.get(ProcessingJob, job_id)
            assert job is not None
            if job.cancel_requested:
                raise JobCancelled
            now = to_datetime(self._ctx.clock.now())
            job.stage = stage.value
            job.progress = progress
            job.updated_at = now
            job.lease_expires_at = to_datetime(self._ctx.clock.now() + self._s.job_lease_seconds)
            version = await db.get(AssetVersion, job.asset_version_id)
            assert version is not None
            version.state = stage.value
        log(logger, logging.INFO, "stage", job_id=job_id, stage=stage.value)

    async def _touch(self, job_id: str, progress: float) -> bool:
        """Record progress and renew the lease. Returns True if cancellation was asked."""
        async with self._ctx.db.session() as db:
            job = await db.get(ProcessingJob, job_id)
            if job is None:
                return True
            job.progress = round(progress, 4)
            job.updated_at = to_datetime(self._ctx.clock.now())
            job.lease_expires_at = to_datetime(self._ctx.clock.now() + self._s.job_lease_seconds)
            return bool(job.cancel_requested)

    async def _finish(
        self, job_id: str, status: JobStatus, version_state: VersionState, error: dict[str, Any] | None
    ) -> None:
        async with self._ctx.db.session() as db:
            job = await db.get(ProcessingJob, job_id)
            assert job is not None
            now = to_datetime(self._ctx.clock.now())
            job.status = status.value
            job.error = error
            job.finished_at = now
            job.updated_at = now
            job.lease_owner = None
            job.lease_expires_at = None
            version = await db.get(AssetVersion, job.asset_version_id)
            assert version is not None
            version.state = version_state.value
        self._ctx.metrics.jobs.labels(outcome=status.value).inc()

    # ------------------------------------------------------------------ entry point
    async def process(self, upload_id: str, *, worker_id: str = "inline") -> ProcessingResult:
        """Process the version created from ``upload_id``. Safe to call again after a
        crash: a new attempt starts from the original and writes to a fresh prefix."""
        async with self._ctx.db.session() as db:
            job = await db.scalar(select(ProcessingJob).where(ProcessingJob.upload_id == upload_id))
            if job is None:
                raise LookupError(f"no processing job for upload {upload_id}")
            if job.status in (JobStatus.SUCCEEDED.value, JobStatus.CANCELLED.value):
                return ProcessingResult(job.id, job.asset_version_id, job.status, job.stage)
            version = await db.get(AssetVersion, job.asset_version_id)
            assert version is not None
            if version.state in (VersionState.PUBLISHED.value, VersionState.WITHDRAWN.value):
                raise ProcessingError(
                    "version_immutable", "a published version is never reprocessed", retryable=False
                )
            now = self._ctx.clock.now()
            if job.status == JobStatus.QUEUED.value or job.lease_owner != worker_id:
                job.attempt += 1
            job.status = JobStatus.RUNNING.value
            job.lease_owner = worker_id
            job.lease_expires_at = to_datetime(now + self._s.job_lease_seconds)
            job.started_at = job.started_at or to_datetime(now)
            job.updated_at = to_datetime(now)
            job.error = None
            job_id, version_id, attempt = job.id, job.asset_version_id, job.attempt
            upload = await db.get(SourceUpload, upload_id)
            assert upload is not None
            upload_state, source_key, source_size = (
                upload.state, upload.storage_reference, upload.declared_size_bytes,
            )  # fmt: skip

        prefix = f"media/{version_id}/{job_id}-{attempt}"
        self._s.work_dir.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix=f"{job_id}-", dir=self._s.work_dir))
        stage = VersionState.VALIDATING
        try:
            if upload_state != UploadState.COMPLETED.value or not source_key:
                raise ProcessingError("upload_incomplete", "upload is not completed", retryable=False)
            # ---- Validating --------------------------------------------------
            await self._set_stage(job_id, stage)
            probe, demuxer = await self._validate(work, source_key, source_size)
            # ---- Transcoding -------------------------------------------------
            stage = VersionState.TRANSCODING
            await self._set_stage(job_id, stage)
            plans = plan_renditions(probe.display_width, probe.height, max_renditions=self._s.max_renditions)
            frame_rate = output_frame_rate(probe.frame_rate)
            last_touch = 0.0

            for index, plan in enumerate(plans):

                async def on_progress(fraction: float, index: int = index) -> None:
                    nonlocal last_touch
                    loop_now = asyncio.get_running_loop().time()
                    if loop_now - last_touch >= 0.5:
                        last_touch = loop_now
                        await self._touch(job_id, (index + fraction) / len(plans))

                async def should_cancel() -> bool:
                    return await self._touch_cancel(job_id)

                await self._ffmpeg.run(
                    transcode_args(
                        demuxer=demuxer,
                        rendition=plan,
                        frame_rate=frame_rate,
                        segment_seconds=self._s.segment_duration_seconds,
                        has_audio=probe.has_audio,
                        threads=self._s.ffmpeg_threads,
                        output_name=f"r{index}.mp4",
                    ),
                    cwd=work,
                    duration=probe.duration,
                    on_progress=on_progress,
                    should_cancel=should_cancel,
                )
            thumbnail: Path | None = work / "thumb.jpg"
            try:
                await self._ffmpeg.run(
                    thumbnail_args(
                        demuxer=demuxer, at_seconds=min(1.0, probe.duration / 2), output_name="thumb.jpg"
                    ),
                    cwd=work,
                )
            except ProcessingError:
                thumbnail = None  # a poster frame is optional
            # ---- Packaging ---------------------------------------------------
            stage = VersionState.PACKAGING
            await self._set_stage(job_id, stage)
            packaged: list[PackagedRendition] = []
            for index, plan in enumerate(plans):
                (work / f"out{index}").mkdir()
                await self._ffmpeg.run(
                    package_args(
                        input_name=f"r{index}.mp4",
                        out_dir=f"out{index}",
                        segment_seconds=self._s.segment_duration_seconds,
                    ),
                    cwd=work,
                )
                packaged.append(inspect_packaged(work / f"out{index}", plan, has_audio=probe.has_audio))
                if await self._touch(job_id, (index + 1) / len(plans) * 0.5):
                    raise JobCancelled
            check_alignment(packaged, tolerance=1.5 / float(frame_rate))
            renditions = await self._store_and_record(
                job_id, version_id, prefix, packaged, probe, float(frame_rate), thumbnail
            )
            self._ctx.metrics.jobs.labels(outcome="succeeded").inc()
            return ProcessingResult(
                job_id, version_id, JobStatus.SUCCEEDED.value,
                VersionState.READY_FOR_REVIEW.value, renditions,
            )  # fmt: skip
        except JobCancelled:
            await self._ctx.store.delete_prefix(prefix)
            await self._finish(job_id, JobStatus.CANCELLED, VersionState.CANCELLED, None)
            return ProcessingResult(job_id, version_id, JobStatus.CANCELLED.value, stage.value)
        except ProcessingError as exc:
            await self._ctx.store.delete_prefix(prefix)
            if exc.code == "cancelled":
                await self._finish(job_id, JobStatus.CANCELLED, VersionState.CANCELLED, None)
                return ProcessingResult(job_id, version_id, JobStatus.CANCELLED.value, stage.value)
            exc.stage = exc.stage or stage.value
            log(logger, logging.WARNING, "processing failed", job_id=job_id, code=exc.code)
            return await self._fail_or_requeue(job_id, version_id, attempt, exc)
        except asyncio.CancelledError:
            raise  # worker shutdown: the lease expires and another worker takes over
        except Exception as exc:  # infrastructure trouble (storage, database, disk)
            logger.exception("processing crashed")
            with contextlib.suppress(Exception):
                await self._ctx.store.delete_prefix(prefix)
            error = ProcessingError("internal_error", type(exc).__name__, retryable=True, stage=stage.value)
            return await self._fail_or_requeue(job_id, version_id, attempt, error)
        finally:
            shutil.rmtree(work, ignore_errors=True)

    async def _touch_cancel(self, job_id: str) -> bool:
        async with self._ctx.db.session() as db:
            job = await db.get(ProcessingJob, job_id)
            return job is None or bool(job.cancel_requested)

    async def _fail_or_requeue(
        self, job_id: str, version_id: str, attempt: int, error: ProcessingError
    ) -> ProcessingResult:
        if error.retryable and attempt < self._s.job_max_attempts:
            async with self._ctx.db.session() as db:
                job = await db.get(ProcessingJob, job_id)
                assert job is not None
                job.status = JobStatus.QUEUED.value
                job.error = error.to_dict()
                job.lease_owner = None
                job.lease_expires_at = None
                job.updated_at = to_datetime(self._ctx.clock.now())
                version = await db.get(AssetVersion, version_id)
                assert version is not None
                version.state = VersionState.UPLOADED.value
            return ProcessingResult(
                job_id, version_id, JobStatus.QUEUED.value, error.stage or "", error=error.to_dict()
            )
        await self._finish(job_id, JobStatus.FAILED, VersionState.FAILED, error.to_dict())
        return ProcessingResult(
            job_id, version_id, JobStatus.FAILED.value, error.stage or "", error=error.to_dict()
        )

    # ------------------------------------------------------------------ stages
    async def _validate(self, work: Path, source_key: str, declared: int) -> tuple[ProbeResult, str]:
        source = work / SOURCE_NAME
        try:
            await self._ctx.store.download_to(
                source_key, source, max_bytes=min(self._s.upload_max_bytes, self._s.work_dir_max_bytes)
            )
        except ValueError as exc:
            raise ProcessingError("source_too_large", str(exc), retryable=False) from exc
        with open(source, "rb") as fh:
            container = sniff_container(fh.read(64))
        if container is None:
            raise ProcessingError(
                "unsupported_container",
                f"not a supported container ({', '.join(c.name for c in ALLOWED)})",
                retryable=False,
            )
        probe = await self._ffmpeg.probe(work, SOURCE_NAME, container.ffmpeg_demuxer)
        if probe.video_codec not in _ALLOWED_VIDEO_CODECS:
            raise ProcessingError(
                "unsupported_codec", f"video codec {probe.video_codec!r} is not accepted", retryable=False
            )
        if probe.duration > self._s.max_source_duration_seconds:
            raise ProcessingError("source_too_long", "media exceeds the duration limit", retryable=False)
        if probe.width * probe.height > self._s.max_source_pixels:
            raise ProcessingError("source_too_large", "frame size exceeds the limit", retryable=False)
        if probe.width < 16 or probe.height < 16:
            raise ProcessingError("invalid_media", "frame size is too small", retryable=False)
        return probe, container.ffmpeg_demuxer

    async def _store_and_record(
        self,
        job_id: str,
        version_id: str,
        prefix: str,
        packaged: list[PackagedRendition],
        probe: ProbeResult,
        frame_rate: float,
        thumbnail: Path | None,
    ) -> list[dict[str, Any]]:
        rendition_rows: list[Rendition] = []
        segment_rows: list[MediaSegment] = []
        for index, rendition in enumerate(packaged):
            rendition_id = new_id("rnd")
            rendition_rows.append(
                Rendition(
                    id=rendition_id,
                    asset_version_id=version_id,
                    name=rendition.planned.name,
                    width=rendition.planned.width,
                    height=rendition.planned.height,
                    video_codec=rendition.video_codec,
                    audio_codec=rendition.audio_codec,
                    codecs=rendition.codecs,
                    bandwidth=rendition.bandwidth,
                    average_bandwidth=rendition.average_bandwidth,
                    frame_rate=frame_rate,
                    segment_count=len(rendition.media),
                    total_bytes=rendition.total_bytes,
                )
            )
            for seg in rendition.segments:
                key = f"{prefix}/r{index}/{seg.path.name}"
                await self._ctx.store.put_file(key, seg.path, content_type="video/mp4")
                segment_rows.append(
                    MediaSegment(
                        id=new_id("seg"),
                        asset_version_id=version_id,
                        rendition_id=rendition_id,
                        kind=seg.kind,
                        sequence_number=seg.sequence_number,
                        start_time=seg.start_time,
                        duration=seg.duration,
                        byte_length=seg.byte_length,
                        content_hash=seg.sha256,  # hashed after final packaging
                        storage_reference=key,
                        encryption_metadata_reference=None,
                    )
                )
            if await self._touch(job_id, 0.5 + (index + 1) / len(packaged) * 0.5):
                raise JobCancelled
        thumb_key: str | None = None
        if thumbnail is not None and thumbnail.exists():
            thumb_key = f"{prefix}/thumb.jpg"
            await self._ctx.store.put_file(thumb_key, thumbnail, content_type="image/jpeg")

        async with self._ctx.db.session() as db:
            job = await db.get(ProcessingJob, job_id)
            version = await db.get(AssetVersion, version_id)
            assert job is not None and version is not None
            if job.cancel_requested:
                raise JobCancelled
            db.add_all(rendition_rows)
            await db.flush()
            db.add_all(segment_rows)
            now = to_datetime(self._ctx.clock.now())
            version.state = VersionState.READY_FOR_REVIEW.value
            version.duration_seconds = sum(s.duration for s in packaged[0].media)
            version.source_info = probe.summary()
            version.thumbnail_reference = thumb_key
            version.ready_at = now
            job.status = JobStatus.SUCCEEDED.value
            job.stage = VersionState.READY_FOR_REVIEW.value
            job.progress = 1.0
            job.finished_at = now
            job.updated_at = now
            job.lease_owner = None
            job.lease_expires_at = None
        return [
            {"rendition_id": r.id, "name": r.name, "width": r.width, "height": r.height,
             "bandwidth": r.bandwidth, "segments": r.segment_count}
            for r in rendition_rows
        ]  # fmt: skip
