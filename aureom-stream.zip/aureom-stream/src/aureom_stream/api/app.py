"""The control-plane API application."""

from __future__ import annotations

import logging
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from starlette.exceptions import HTTPException as StarletteHTTPException

from .. import __version__
from ..bootstrap import AppContext, build_context
from ..config import Settings, get_settings
from ..errors import DomainError
from ..ids import new_id
from ..observability.logging import log
from .routers import assets, meta, offline, peers, playback, uploads

logger = logging.getLogger("aureom.api")
MAX_JSON_BODY = 1024 * 1024

DESCRIPTION = """
AUREOM STREAM control plane: resumable uploads, versioned assets, publication,
playback sessions, the controlled peer registry and offline downloads.

**Authentication.** `Authorization: Bearer <JWT>` identifies a principal. Session-scoped
endpoints additionally accept the opaque secret returned when the session was created
(`Authorization: Bearer <secret>`, `X-Session-Token`, or the `st` query parameter).

**Errors** use RFC 9457 problem details with a stable `code` field.
"""


def problem(
    request: Request, status: int, code: str, title: str, detail: str, **extra: object
) -> JSONResponse:
    body = {
        "type": "about:blank",
        "title": title,
        "status": status,
        "detail": detail,
        "code": code,
        "request_id": getattr(request.state, "request_id", None),
        **extra,
    }
    headers = {"WWW-Authenticate": "Bearer"} if status == 401 else None
    return JSONResponse(body, status_code=status, media_type="application/problem+json", headers=headers)


def install_common(app: FastAPI, ctx: AppContext) -> None:
    """Error rendering, request ids, metrics and redacted request logs."""
    app.state.ctx = ctx

    @app.middleware("http")
    async def observe(request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
        request.state.request_id = new_id("req")
        started = time.perf_counter()
        length = request.headers.get("content-length")
        is_part = "/parts/" in request.url.path or "/subtitles/" in request.url.path
        if not is_part and length and length.isdigit() and int(length) > MAX_JSON_BODY:
            return problem(request, 413, "payload_too_large", "Payload too large", "request body too large")
        response = await call_next(request)
        route = request.scope.get("route")
        template = getattr(route, "path", "unmatched")
        elapsed = time.perf_counter() - started
        ctx.metrics.http_requests.labels(template, request.method, str(response.status_code)).inc()
        ctx.metrics.http_latency.labels(template).observe(elapsed)
        # The route template is logged, never the raw path/query (they may carry secrets).
        log(
            logger, logging.INFO, "request",
            request_id=request.state.request_id, method=request.method, route=template,
            status=response.status_code, ms=round(elapsed * 1000, 2),
        )  # fmt: skip
        response.headers["X-Request-Id"] = request.state.request_id
        return response

    @app.exception_handler(DomainError)
    async def domain_error(request: Request, exc: DomainError) -> JSONResponse:
        if exc.status in (401, 403, 404):
            ctx.metrics.denials.labels(reason=exc.code).inc()
        return problem(request, exc.status, exc.code, exc.title, exc.detail, **exc.extra)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError) -> JSONResponse:
        errors = [{"loc": [str(p) for p in e.get("loc", ())], "msg": e.get("msg", "")} for e in exc.errors()][
            :20
        ]
        return problem(
            request, 422, "validation_failed", "Validation failed", "request is malformed", errors=errors
        )

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        return problem(request, exc.status_code, "http_error", "HTTP error", str(exc.detail))

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("unhandled error")
        return problem(request, 500, "internal_error", "Internal error", "unexpected server error")


def create_app(settings: Settings | None = None, ctx: AppContext | None = None) -> FastAPI:
    settings = settings or (ctx.settings if ctx else get_settings())
    owns_ctx = ctx is None
    context = ctx or build_context(settings)

    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        if settings.is_sqlite():
            await context.db.create_all()  # PostgreSQL deployments run Alembic instead
        ensure = getattr(context.store, "ensure_bucket", None)
        if ensure is not None:
            await ensure()
        yield
        if owns_ctx:
            await context.close()

    app = FastAPI(
        title="AUREOM STREAM API",
        version=__version__,
        description=DESCRIPTION,
        lifespan=lifespan,
    )
    install_common(app, context)
    app.include_router(meta.router)
    app.include_router(uploads.router)
    app.include_router(assets.router)
    app.include_router(playback.router)
    app.include_router(peers.router)
    app.include_router(offline.router)
    return app
