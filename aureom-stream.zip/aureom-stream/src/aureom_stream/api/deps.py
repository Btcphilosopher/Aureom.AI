"""FastAPI dependencies: context, unit of work, credentials."""

from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from ..access.tokens import AUD_API, TYP_PRINCIPAL, TokenError
from ..bootstrap import AppContext
from ..domain import ANONYMOUS, Principal
from ..errors import Unauthenticated


def get_ctx(request: Request) -> AppContext:
    return request.app.state.ctx  # type: ignore[no-any-return]


Ctx = Annotated[AppContext, Depends(get_ctx)]


async def get_db(ctx: Ctx) -> AsyncIterator[AsyncSession]:
    async with ctx.db.session() as session:
        yield session


Db = Annotated[AsyncSession, Depends(get_db)]


@dataclass(frozen=True)
class Credentials:
    principal: Principal
    opaque_token: str | None  # playback-session / peer-session / download secret
    client_key: str


def _bearer(request: Request) -> str | None:
    header = request.headers.get("authorization")
    if not header:
        return None
    scheme, _, value = header.partition(" ")
    if scheme.lower() != "bearer" or not value.strip():
        raise Unauthenticated("unsupported Authorization scheme")
    return value.strip()


def get_credentials(request: Request, ctx: Ctx) -> Credentials:
    """A principal token is a JWT; session-scoped secrets are opaque strings. Both may
    arrive as ``Authorization: Bearer``; opaque secrets may also arrive as
    ``X-Session-Token`` or the ``st`` query parameter (for players that cannot set
    headers - the parameter is redacted from logs)."""
    principal = ANONYMOUS
    opaque = request.headers.get("x-session-token") or request.query_params.get("st")
    bearer = _bearer(request)
    if bearer is not None:
        if bearer.count(".") == 2:
            try:
                claims = ctx.principal_verifier.verify(bearer, typ=TYP_PRINCIPAL, audience=AUD_API)
            except TokenError as exc:
                raise Unauthenticated(f"invalid access token ({exc.reason})") from exc
            scopes = frozenset(str(claims.get("scope", "")).split())
            principal = Principal(id=str(claims["sub"]), scopes=scopes)
        else:
            opaque = opaque or bearer
    client = request.client.host if request.client else "unknown"
    return Credentials(principal=principal, opaque_token=opaque, client_key=client)


Creds = Annotated[Credentials, Depends(get_credentials)]


def require_user(creds: Creds) -> Principal:
    if creds.principal.anonymous:
        raise Unauthenticated("an access token is required")
    return creds.principal


User = Annotated[Principal, Depends(require_user)]
