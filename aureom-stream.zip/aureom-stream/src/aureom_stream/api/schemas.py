"""Pydantic request/response contracts for the HTTP API."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from ..domain import DistributionPolicy, RightsDeclaration

OpaqueId = Field(min_length=8, max_length=40, pattern=r"^[a-z]{2,4}_[a-z2-7]{26}$")
SegmentIdList = Field(max_length=512)


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


# --------------------------------------------------------------------------- uploads
class UploadCreate(Strict):
    filename: str = Field(min_length=1, max_length=255)
    content_type: str = Field(min_length=1, max_length=127)
    size_bytes: int = Field(gt=0)
    visibility: Literal["private", "unlisted", "public"] = "private"
    idempotency_key: str = Field(min_length=8, max_length=128, pattern=r"^[A-Za-z0-9._:-]+$")

    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "filename": "survey-documentary.mp4",
                "content_type": "video/mp4",
                "size_bytes": 125000000,
                "visibility": "private",
                "idempotency_key": "example-upload-001",
            }
        },
    )


class UploadLimits(BaseModel):
    max_upload_bytes: int
    part_size_bytes: int
    max_part_bytes: int
    accepted_containers: list[str]
    quota_bytes: int
    quota_used_bytes: int


class UploadPartInfo(BaseModel):
    part_number: int
    size_bytes: int
    sha256: str


class UploadOut(BaseModel):
    upload_id: str
    state: str
    filename: str
    size_bytes: int
    visibility: str
    part_size_bytes: int
    part_count: int
    last_part_size_bytes: int
    parts_received: list[UploadPartInfo]
    missing_parts: list[int]
    expires_at: datetime
    detected_container: str | None
    sha256: str | None
    limits: UploadLimits
    part_url_template: str


class PartOut(BaseModel):
    upload_id: str
    part_number: int
    size_bytes: int
    sha256: str
    duplicate: bool


class UploadComplete(Strict):
    sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")


# --------------------------------------------------------------------------- catalogue
class AssetCreate(Strict):
    upload_id: str = OpaqueId
    title: str = Field(min_length=1, max_length=300)
    description: str = Field(default="", max_length=5000)
    language: str = Field(default="und", pattern=r"^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8}){0,3}$")
    rights_declaration: RightsDeclaration
    visibility: Literal["private", "unlisted", "public"] | None = None
    distribution: DistributionPolicy = DistributionPolicy()


class VersionCreate(Strict):
    upload_id: str = OpaqueId


class JobOut(BaseModel):
    job_id: str
    status: str
    stage: str
    progress: float
    attempt: int
    error: dict[str, Any] | None


class RenditionOut(BaseModel):
    rendition_id: str
    name: str
    width: int
    height: int
    codecs: str
    bandwidth: int
    average_bandwidth: int
    frame_rate: float
    segment_count: int
    total_bytes: int


class SubtitleOut(BaseModel):
    track_id: str
    language: str
    label: str
    byte_length: int


class VersionOut(BaseModel):
    version_id: str
    asset_id: str
    version_number: int
    state: str
    duration_seconds: float | None
    created_at: datetime
    published_at: datetime | None
    withdrawn_at: datetime | None
    manifest_digest: str | None
    renditions: list[RenditionOut]
    subtitles: list[SubtitleOut]
    job: JobOut | None = None  # managers only


class AssetOut(BaseModel):
    asset_id: str
    title: str
    description: str
    language: str
    visibility: str
    rights_declaration: dict[str, Any]
    distribution: DistributionPolicy
    created_at: datetime
    owner_id: str | None = None  # managers only
    latest_published_version_id: str | None
    versions: list[VersionOut]


class AssetList(BaseModel):
    assets: list[AssetOut]


class PublishRequest(Strict):
    visibility: Literal["private", "unlisted", "public"] | None = None
    confirm_public: bool = False
    distribution: DistributionPolicy | None = None


class WithdrawRequest(Strict):
    reason: str | None = Field(default=None, max_length=500)


class PublicationOut(BaseModel):
    publication_id: str
    asset_id: str
    version_id: str
    visibility: str
    distribution: DistributionPolicy
    published_at: datetime
    withdrawn_at: datetime | None
    manifest_digest: str | None
    notice: str | None = None


class GrantCreate(Strict):
    principal_id: str = Field(min_length=1, max_length=128)
    permission: Literal["view", "offline_download", "peer_contribute", "manage"]
    ttl_seconds: float | None = Field(default=None, gt=0)


class GrantOut(BaseModel):
    grant_id: str
    asset_id: str
    principal_id: str
    permission: str
    expires_at: datetime | None


# --------------------------------------------------------------------------- playback
class ClientCapabilitiesIn(Strict):
    supported_codecs: list[str] = Field(default_factory=list, max_length=16)
    max_height: int | None = Field(default=None, ge=1, le=8640)
    peer_delivery: bool = False


class PlaybackCreate(Strict):
    asset_id: str = OpaqueId
    version_id: str | None = Field(default=None, pattern=r"^ver_[a-z2-7]{26}$")
    client_capabilities: ClientCapabilitiesIn = ClientCapabilitiesIn()
    # Contribution is opt-in: it defaults to off and is never switched on by the server.
    peer_contribution_enabled: bool = False


class OriginAccess(BaseModel):
    base_url: str
    token: str
    expires_at: float


class SessionRendition(BaseModel):
    rendition_id: str
    name: str
    width: int
    height: int
    codecs: str
    bandwidth: int
    playlist_url: str


class PlaybackOut(BaseModel):
    session_id: str
    session_token: str | None = None  # returned once, at creation
    asset_id: str
    version_id: str
    state: str
    preview: bool
    expires_at: datetime
    heartbeat_interval_seconds: float
    delivery_modes: list[str]
    peer_contribution_enabled: bool
    renditions: list[SessionRendition]
    master_playlist_url: str
    signed_manifest_url: str | None
    origin: OriginAccess | None = None
    notices: list[str] = []


class HeartbeatIn(Strict):
    position_seconds: float | None = Field(default=None, ge=0)
    buffer_seconds: float | None = Field(default=None, ge=0)


# --------------------------------------------------------------------------- peers
class PeerEndpoint(Strict):
    host: str = Field(min_length=1, max_length=255)
    port: int = Field(ge=1, le=65535)


class ContributionIn(Strict):
    enabled: bool = False  # explicit opt-in
    upload_kbps_cap: int | None = Field(default=None, ge=16, le=10_000_000)
    metered: bool = False


class PeerSessionCreate(Strict):
    playback_session_id: str = OpaqueId
    endpoint: PeerEndpoint
    transport: Literal["loopback-http", "mtls-http"]
    cert_thumbprint: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    contribution: ContributionIn = ContributionIn()


class PeerSessionOut(BaseModel):
    peer_session_id: str
    peer_token: str | None = None
    state: str
    expires_at: datetime
    heartbeat_interval_seconds: float
    contribute: bool
    contribution_paused: bool
    limits: dict[str, int]
    notices: list[str] = []


class PeerHeartbeatIn(Strict):
    contribution_paused: bool | None = None
    metered: bool | None = None
    upload_kbps_cap: int | None = Field(default=None, ge=16, le=10_000_000)


class AvailabilityIn(Strict):
    mode: Literal["replace", "delta"] = "delta"
    have: list[str] = SegmentIdList
    drop: list[str] = Field(default_factory=list, max_length=512)


class AvailabilityOut(BaseModel):
    announced: int


class DiscoveryIn(Strict):
    peer_session_id: str = OpaqueId
    segment_ids: list[str] = Field(min_length=1, max_length=512)


class PeerOut(BaseModel):
    peer_id: str
    endpoint: PeerEndpoint
    transport: str
    cert_thumbprint: str | None
    segment_ids: list[str]
    reliability: float


class DiscoveryOut(BaseModel):
    peers: list[PeerOut]


class TransferAuthIn(Strict):
    peer_session_id: str = OpaqueId
    serving_peer_id: str = OpaqueId
    segment_ids: list[str] = Field(min_length=1, max_length=64)


class TransferAuthOut(BaseModel):
    grant_id: str
    token: str
    serving_peer_id: str
    segment_ids: list[str]
    max_bytes: int
    expires_at: float


class ReceiptIn(Strict):
    peer_session_id: str = OpaqueId
    grant_id: str = OpaqueId
    segment_id: str = OpaqueId
    role: Literal["receiver", "sender"]
    outcome: Literal["verified", "corrupt", "length_mismatch", "timeout", "refused", "not_found", "error"]
    bytes_transferred: int = Field(ge=0)
    duration_ms: int = Field(ge=0, le=3_600_000)


class ReceiptOut(BaseModel):
    receipt_id: str
    corroborated: bool
    independently_verified: Literal[False] = False
    note: str = "Receipts are self-reported by peers and are not verified usage."


# --------------------------------------------------------------------------- offline
class OfflineCreate(Strict):
    asset_id: str = OpaqueId
    version_id: str | None = Field(default=None, pattern=r"^ver_[a-z2-7]{26}$")
    rendition_id: str | None = Field(default=None, pattern=r"^rnd_[a-z2-7]{26}$")
    max_height: int | None = Field(default=None, ge=1, le=8640)
    subtitle_languages: list[str] = Field(default_factory=list, max_length=16)


class OfflineProgressIn(Strict):
    items_completed: int = Field(ge=0)
    bytes_completed: int = Field(ge=0)
    completion_digest: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")


class OfflineOut(BaseModel):
    download_id: str
    download_token: str | None = None
    asset_id: str
    version_id: str
    rendition_id: str
    subtitle_languages: list[str]
    state: str
    total_bytes: int
    total_items: int
    reported_bytes: int
    reported_items: int
    verified_complete: bool
    expires_at: datetime
    signed_manifest_url: str
    origin: OriginAccess | None = None
    storage: dict[str, int]
    notices: list[str] = []


class Problem(BaseModel):
    type: str = "about:blank"
    title: str
    status: int
    detail: str
    code: str
    request_id: str | None = None
