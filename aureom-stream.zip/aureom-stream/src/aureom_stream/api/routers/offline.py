"""Offline downloads."""

from __future__ import annotations

from fastapi import APIRouter, Response

from ...offline.service import OFFLINE_NOTICE, OfflineService
from ...persistence.models import DownloadState, OfflineDownload
from ...playback.service import PlaybackService
from ..deps import Creds, Ctx, Db, User
from ..schemas import OfflineCreate, OfflineOut, OfflineProgressIn, OriginAccess

router = APIRouter(prefix="/v1/offline-downloads", tags=["offline"])


async def _out(
    ctx: Ctx, svc: OfflineService, d: OfflineDownload, *, token: str | None = None, with_origin: bool = True
) -> OfflineOut:
    origin = None
    if with_origin and d.state == DownloadState.ACTIVE.value:
        value, expires = svc.origin_token(d)
        origin = OriginAccess(base_url=ctx.settings.origin_base_url, token=value, expires_at=expires)
    return OfflineOut(
        download_id=d.id,
        download_token=token,
        asset_id=d.asset_id,
        version_id=d.asset_version_id,
        rendition_id=d.rendition_id,
        subtitle_languages=d.subtitle_languages,
        state=d.state,
        total_bytes=d.total_bytes,
        total_items=d.total_items,
        reported_bytes=d.reported_bytes,
        reported_items=d.reported_items,
        verified_complete=d.completion_digest_matches,
        expires_at=d.expires_at,
        signed_manifest_url=f"/v1/offline-downloads/{d.id}/manifest",
        origin=origin,
        storage={
            "quota_bytes": ctx.settings.offline_quota_bytes,
            "used_bytes": await svc.storage_used(d.principal_id),
        },
        notices=[OFFLINE_NOTICE] if token else [],
    )


@router.post("", response_model=OfflineOut, status_code=201, summary="Authorise an offline download")
async def create_download(body: OfflineCreate, ctx: Ctx, db: Db, user: User) -> OfflineOut:
    """Offline permission is checked separately from streaming permission. The response
    fixes what the download contains: one rendition, its initialisation segment and
    the selected subtitle tracks."""
    version_id = await PlaybackService(ctx, db)._resolve_version(user, body.asset_id, body.version_id)
    svc = OfflineService(ctx, db)
    download, token = await svc.create(
        user,
        asset_version_id=version_id,
        rendition_id=body.rendition_id,
        max_height=body.max_height,
        subtitle_languages=body.subtitle_languages,
    )
    await db.commit()
    return await _out(ctx, svc, download, token=token)


@router.get("/{download_id}", response_model=OfflineOut, summary="Download status (and a fresh origin token)")
async def get_download(download_id: str, ctx: Ctx, db: Db, creds: Creds) -> OfflineOut:
    svc = OfflineService(ctx, db)
    download = await svc.load(download_id, principal=creds.principal, token=creds.opaque_token)
    await db.commit()
    return await _out(ctx, svc, download)


@router.post("/{download_id}/pause", response_model=OfflineOut, summary="Pause")
async def pause_download(download_id: str, ctx: Ctx, db: Db, creds: Creds) -> OfflineOut:
    """While paused the origin refuses this download's requests (`409 download_paused`)."""
    svc = OfflineService(ctx, db)
    download = await svc.load(download_id, principal=creds.principal, token=creds.opaque_token)
    await svc.pause(download)
    await db.commit()
    return await _out(ctx, svc, download)


@router.post("/{download_id}/resume", response_model=OfflineOut, summary="Resume")
async def resume_download(download_id: str, ctx: Ctx, db: Db, creds: Creds) -> OfflineOut:
    svc = OfflineService(ctx, db)
    download = await svc.load(download_id, principal=creds.principal, token=creds.opaque_token)
    await svc.resume(download, creds.principal)
    await db.commit()
    return await _out(ctx, svc, download)


@router.delete("/{download_id}", status_code=204, summary="Delete the download")
async def delete_download(download_id: str, ctx: Ctx, db: Db, creds: Creds) -> Response:
    """Ends the server-side authorisation and frees the storage allowance. The client
    removes its local files; the server cannot erase a device's plaintext copy."""
    svc = OfflineService(ctx, db)
    download = await svc.load(download_id, principal=creds.principal, token=creds.opaque_token)
    await svc.delete(download)
    await db.commit()
    return Response(status_code=204)


@router.post("/{download_id}/progress", response_model=OfflineOut, summary="Report progress / completion")
async def report_progress(
    download_id: str, body: OfflineProgressIn, ctx: Ctx, db: Db, creds: Creds
) -> OfflineOut:
    """Client-reported. Completion requires the digest over all verified item hashes
    to match the digest derived from the signed manifest."""
    svc = OfflineService(ctx, db)
    download = await svc.load(download_id, principal=creds.principal, token=creds.opaque_token)
    await svc.report_progress(
        download, items=body.items_completed, bytes_done=body.bytes_completed,
        completion_digest=body.completion_digest,
    )  # fmt: skip
    await db.commit()
    return await _out(ctx, svc, download, with_origin=False)


@router.get("/{download_id}/manifest", summary="Signed version manifest (JWS)")
async def download_manifest(download_id: str, ctx: Ctx, db: Db, creds: Creds) -> Response:
    svc = OfflineService(ctx, db)
    download = await svc.load(download_id, principal=creds.principal, token=creds.opaque_token)
    svc._require(download, DownloadState.ACTIVE, DownloadState.PAUSED, DownloadState.COMPLETED)
    return Response(
        await svc.signed_manifest(download), media_type="application/jose",
        headers={"Cache-Control": "private, no-store"},
    )  # fmt: skip
