"""Playback sessions, per-session playlists and session-authenticated segments."""

from __future__ import annotations

from urllib.parse import quote

from fastapi import APIRouter, Request, Response

from ...errors import NotFound
from ...manifests.playlists import (
    PLAYLIST_CONTENT_TYPE,
    render_master,
    render_media,
    render_subtitle_playlist,
)
from ...origin.delivery import OriginDelivery
from ...persistence.models import AssetVersion, PlaybackSession, Rendition
from ...playback.service import ClientCapabilities, PlaybackService
from ..deps import Creds, Ctx, Db
from ..schemas import HeartbeatIn, OriginAccess, PlaybackCreate, PlaybackOut, SessionRendition

router = APIRouter(prefix="/v1/playback-sessions", tags=["playback"])

# Playlists are per session: never cacheable by anyone but the requesting client, so a
# shared cache cannot become a record of who watched what.
PLAYLIST_HEADERS = {"Cache-Control": "private, no-store", "Vary": "Authorization"}


def _session_out(
    ctx: Ctx,
    session: PlaybackSession,
    renditions: list[Rendition],
    *,
    token: str | None = None,
    origin: tuple[str, float] | None = None,
    notices: list[str] | None = None,
) -> PlaybackOut:
    base = f"/v1/playback-sessions/{session.id}"
    return PlaybackOut(
        session_id=session.id,
        session_token=token,
        asset_id=session.asset_id,
        version_id=session.asset_version_id,
        state=session.state,
        preview=session.preview,
        expires_at=session.expires_at,
        heartbeat_interval_seconds=ctx.settings.playback_heartbeat_seconds,
        delivery_modes=session.delivery_modes,
        peer_contribution_enabled=session.peer_contribution,
        renditions=[
            SessionRendition(
                rendition_id=r.id, name=r.name, width=r.width, height=r.height, codecs=r.codecs,
                bandwidth=r.bandwidth, playlist_url=f"{base}/renditions/{r.id}/index.m3u8",
            )
            for r in renditions
        ],
        master_playlist_url=f"{base}/master.m3u8",
        signed_manifest_url=None if session.preview else f"{base}/manifest",
        origin=(
            OriginAccess(base_url=ctx.settings.origin_base_url, token=origin[0], expires_at=origin[1])
            if origin
            else None
        ),
        notices=notices or [],
    )  # fmt: skip


async def _authenticated(
    svc: PlaybackService, session_id: str, creds: Creds, *, active: bool = True
) -> PlaybackSession:
    session = await svc.authenticate(session_id, session_token=creds.opaque_token, principal=creds.principal)
    return await svc.require_active(session) if active else session


def _suffix(request: Request) -> str:
    """Propagate a query-string session token into playlist URIs for players that
    cannot send headers. Header-authenticated requests get clean URIs."""
    token = request.query_params.get("st")
    return f"?st={quote(token, safe='')}" if token else ""


@router.post("", response_model=PlaybackOut, status_code=201, summary="Authorise playback")
async def create_session(body: PlaybackCreate, ctx: Ctx, db: Db, creds: Creds) -> PlaybackOut:
    """Authorises the caller for one asset version and returns a short-lived session,
    the delivery modes it may use and a short-lived origin token. Public assets may be
    played anonymously; peer delivery always needs an identified principal."""
    svc = PlaybackService(ctx, db)
    created = await svc.create(
        creds.principal,
        asset_id=body.asset_id,
        version_id=body.version_id,
        capabilities=ClientCapabilities(
            supported_codecs=body.client_capabilities.supported_codecs,
            max_height=body.client_capabilities.max_height,
            peer_delivery=body.client_capabilities.peer_delivery,
        ),
        peer_contribution_enabled=body.peer_contribution_enabled,
        client_key=creds.client_key,
    )
    await db.commit()
    return _session_out(
        ctx, created.session, created.renditions, token=created.token,
        origin=svc.origin_token(created.session), notices=created.notices,
    )  # fmt: skip


@router.get("/{session_id}", response_model=PlaybackOut, summary="Session status")
async def get_session(session_id: str, ctx: Ctx, db: Db, creds: Creds) -> PlaybackOut:
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds, active=False)
    return _session_out(ctx, session, await svc.renditions(session))


@router.post("/{session_id}/heartbeat", response_model=PlaybackOut, summary="Keep the session alive")
async def heartbeat(
    session_id: str, ctx: Ctx, db: Db, creds: Creds, body: HeartbeatIn | None = None
) -> PlaybackOut:
    """Extends the idle expiry (up to the hard lifetime) and returns a fresh origin
    token. Fails with `410` once the session ended, expired or the version was withdrawn."""
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds)
    await svc.heartbeat(session, position_seconds=body.position_seconds if body else None)
    await db.commit()
    return _session_out(ctx, session, await svc.renditions(session), origin=svc.origin_token(session))


@router.delete("/{session_id}", status_code=204, summary="End the session")
async def end_session(session_id: str, ctx: Ctx, db: Db, creds: Creds) -> Response:
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds, active=False)
    await svc.end(session)
    await db.commit()
    return Response(status_code=204)


@router.get("/{session_id}/manifest", summary="Signed version manifest (JWS)")
async def signed_manifest(session_id: str, ctx: Ctx, db: Db, creds: Creds) -> Response:
    """The authenticated manifest clients verify segments against, whichever source
    (origin or peer) delivered the bytes."""
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds)
    return Response(
        await svc.signed_manifest(session), media_type="application/jose", headers=PLAYLIST_HEADERS
    )


@router.get("/{session_id}/master.m3u8", summary="HLS multivariant playlist")
async def master_playlist(session_id: str, request: Request, ctx: Ctx, db: Db, creds: Creds) -> Response:
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds)
    suffix = _suffix(request)
    text = render_master(
        await svc.renditions(session),
        await svc.subtitles(session),
        rendition_uri=lambda r: f"renditions/{r.id}/index.m3u8{suffix}",
        subtitle_uri=lambda t: f"subtitles/{t.id}/index.m3u8{suffix}",
    )
    return Response(text, media_type=PLAYLIST_CONTENT_TYPE, headers=PLAYLIST_HEADERS)


@router.get("/{session_id}/renditions/{rendition_id}/index.m3u8", summary="HLS media playlist")
async def media_playlist(
    session_id: str, rendition_id: str, request: Request, ctx: Ctx, db: Db, creds: Creds
) -> Response:
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds)
    suffix = _suffix(request)
    segments = await svc.rendition_segments(session, rendition_id)
    text = render_media(segments, segment_uri=lambda s: f"../../segments/{s.id}{suffix}")
    return Response(text, media_type=PLAYLIST_CONTENT_TYPE, headers=PLAYLIST_HEADERS)


@router.head("/{session_id}/segments/{segment_id}", include_in_schema=False)
@router.get(
    "/{session_id}/segments/{segment_id}",
    summary="Initialisation or media segment (GET/HEAD, supports Range)",
)
async def segment(
    session_id: str, segment_id: str, request: Request, ctx: Ctx, db: Db, creds: Creds
) -> Response:
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds)
    version = await db.get(AssetVersion, session.asset_version_id)
    if version is None:
        raise NotFound("segment not found")
    return await OriginDelivery(ctx).segment_response(
        db, segment_id,
        version_id=session.asset_version_id,
        visibility=await svc.visibility(session),
        preview=session.preview,
        method=request.method,
        headers=request.headers,
        allowed_renditions=session.rendition_ids,
    )  # fmt: skip


@router.get("/{session_id}/subtitles/{track_id}/index.m3u8", summary="Subtitle playlist")
async def subtitle_playlist(
    session_id: str, track_id: str, request: Request, ctx: Ctx, db: Db, creds: Creds
) -> Response:
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds)
    if track_id not in {t.id for t in await svc.subtitles(session)}:
        raise NotFound("subtitle track not found")
    version = await db.get(AssetVersion, session.asset_version_id)
    duration = (version.duration_seconds if version else None) or 1.0
    text = render_subtitle_playlist(duration, vtt_uri=f"track.vtt{_suffix(request)}")
    return Response(text, media_type=PLAYLIST_CONTENT_TYPE, headers=PLAYLIST_HEADERS)


@router.get("/{session_id}/subtitles/{track_id}/track.vtt", summary="WebVTT subtitle track")
async def subtitle_track(
    session_id: str, track_id: str, request: Request, ctx: Ctx, db: Db, creds: Creds
) -> Response:
    svc = PlaybackService(ctx, db)
    session = await _authenticated(svc, session_id, creds)
    return await OriginDelivery(ctx).subtitle_response(
        db, track_id,
        version_id=session.asset_version_id,
        visibility=await svc.visibility(session),
        preview=session.preview,
        method=request.method,
        headers=request.headers,
    )  # fmt: skip
