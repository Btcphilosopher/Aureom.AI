"""Catalogue and publication endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request, Response
from sqlalchemy import select

from ...catalogue.service import WITHDRAWAL_NOTICE, CatalogueService, NewAsset
from ...domain import DistributionPolicy, Principal
from ...errors import NotFound, PayloadTooLarge
from ...persistence.models import (
    AccessGrant,
    Asset,
    AssetVersion,
    Permission,
    ProcessingJob,
    Publication,
    VersionState,
)
from ..deps import Creds, Ctx, Db, User
from ..schemas import (
    AssetCreate,
    AssetList,
    AssetOut,
    GrantCreate,
    GrantOut,
    JobOut,
    PublicationOut,
    PublishRequest,
    RenditionOut,
    SubtitleOut,
    VersionCreate,
    VersionOut,
    WithdrawRequest,
)

router = APIRouter(prefix="/v1", tags=["assets"])


def _job_out(job: ProcessingJob) -> JobOut:
    return JobOut(
        job_id=job.id, status=job.status, stage=job.stage, progress=job.progress,
        attempt=job.attempt, error=job.error,
    )  # fmt: skip


async def _version_out(svc: CatalogueService, db: Db, v: AssetVersion, manager: bool) -> VersionOut:
    job = None
    if manager:
        row = await db.scalar(select(ProcessingJob).where(ProcessingJob.asset_version_id == v.id))
        job = _job_out(row) if row else None
    return VersionOut(
        version_id=v.id,
        asset_id=v.asset_id,
        version_number=v.version_number,
        state=v.state,
        duration_seconds=v.duration_seconds,
        created_at=v.created_at,
        published_at=v.published_at,
        withdrawn_at=v.withdrawn_at,
        manifest_digest=v.manifest_digest,
        renditions=[
            RenditionOut(
                rendition_id=r.id, name=r.name, width=r.width, height=r.height, codecs=r.codecs,
                bandwidth=r.bandwidth, average_bandwidth=r.average_bandwidth,
                frame_rate=r.frame_rate, segment_count=r.segment_count, total_bytes=r.total_bytes,
            )
            for r in await svc.renditions(v.id)
        ],
        subtitles=[
            SubtitleOut(track_id=s.id, language=s.language, label=s.label, byte_length=s.byte_length)
            for s in await svc.subtitles(v.id)
        ],
        job=job,
    )  # fmt: skip


async def _asset_out(svc: CatalogueService, db: Db, principal: Principal, asset: Asset) -> AssetOut:
    _, versions, manager = await svc.list_versions(principal, asset.id)
    published = [v for v in versions if v.state == VersionState.PUBLISHED.value]
    return AssetOut(
        asset_id=asset.id,
        title=asset.title,
        description=asset.description,
        language=asset.language,
        visibility=asset.visibility,
        rights_declaration=asset.rights_declaration,
        distribution=DistributionPolicy.model_validate(asset.distribution),
        created_at=asset.created_at,
        owner_id=asset.owner_id if manager else None,
        latest_published_version_id=published[-1].id if published else None,
        versions=[await _version_out(svc, db, v, manager) for v in versions],
    )


def _publication_out(pub: Publication, digest: str | None, notice: str | None = None) -> PublicationOut:
    return PublicationOut(
        publication_id=pub.id,
        asset_id=pub.asset_id,
        version_id=pub.asset_version_id,
        visibility=pub.visibility,
        distribution=DistributionPolicy.model_validate(pub.distribution),
        published_at=pub.published_at,
        withdrawn_at=pub.withdrawn_at,
        manifest_digest=digest,
        notice=notice,
    )


@router.post("/assets", response_model=AssetOut, status_code=201, summary="Create a title from an upload")
async def create_asset(body: AssetCreate, ctx: Ctx, db: Db, user: User) -> AssetOut:
    """Creates the logical asset, its first immutable version and a processing job.
    The asset inherits the upload's visibility unless stated; nothing is visible to
    anyone else before an explicit publish."""
    svc = CatalogueService(ctx, db)
    asset, _, _ = await svc.create_asset(
        user,
        NewAsset(
            upload_id=body.upload_id,
            title=body.title,
            description=body.description,
            language=body.language,
            rights_declaration=body.rights_declaration,
            visibility=body.visibility,
            distribution=body.distribution,
        ),
    )
    await db.commit()
    return await _asset_out(svc, db, user, asset)


@router.get("/assets", response_model=AssetList, summary="Discoverable assets")
async def list_assets(ctx: Ctx, db: Db, creds: Creds) -> AssetList:
    """Publicly published assets plus the caller's own and those shared with the caller.
    Other people's private or unlisted assets are never listed."""
    svc = CatalogueService(ctx, db)
    assets = await svc.list_assets(creds.principal)
    return AssetList(assets=[await _asset_out(svc, db, creds.principal, a) for a in assets])


@router.get("/assets/{asset_id}", response_model=AssetOut, summary="Asset metadata")
async def get_asset(asset_id: str, ctx: Ctx, db: Db, creds: Creds) -> AssetOut:
    svc = CatalogueService(ctx, db)
    asset = await svc.load_asset(creds.principal, asset_id)
    return await _asset_out(svc, db, creds.principal, asset)


@router.get("/assets/{asset_id}/versions", response_model=list[VersionOut], summary="Versions of an asset")
async def list_versions(asset_id: str, ctx: Ctx, db: Db, creds: Creds) -> list[VersionOut]:
    svc = CatalogueService(ctx, db)
    _, versions, manager = await svc.list_versions(creds.principal, asset_id)
    return [await _version_out(svc, db, v, manager) for v in versions]


@router.post(
    "/assets/{asset_id}/versions", response_model=VersionOut, status_code=201,
    summary="Add a new immutable version from another upload",
)  # fmt: skip
async def add_version(asset_id: str, body: VersionCreate, ctx: Ctx, db: Db, user: User) -> VersionOut:
    svc = CatalogueService(ctx, db)
    version, _ = await svc.add_version(user, asset_id, body.upload_id)
    await db.commit()
    return await _version_out(svc, db, version, True)


@router.post(
    "/assets/{asset_id}/versions/{version_id}/publish", response_model=PublicationOut,
    summary="Publish a processed version",
)  # fmt: skip
async def publish(
    asset_id: str, version_id: str, ctx: Ctx, db: Db, user: User, body: PublishRequest | None = None
) -> PublicationOut:
    """Requires the `media:publish` permission, management rights on the asset and a
    completed processing job. Seals the signed manifest; the version is immutable from
    here on. Public listing additionally requires `confirm_public: true`."""
    body = body or PublishRequest()
    svc = CatalogueService(ctx, db)
    pub = await svc.publish(
        user, asset_id, version_id,
        visibility=body.visibility, confirm_public=body.confirm_public, distribution=body.distribution,
    )  # fmt: skip
    await db.commit()
    version = await db.get(AssetVersion, version_id)
    return _publication_out(pub, version.manifest_digest if version else None)


@router.post(
    "/assets/{asset_id}/versions/{version_id}/withdraw", response_model=PublicationOut,
    summary="Withdraw a published version",
)  # fmt: skip
async def withdraw(
    asset_id: str, version_id: str, ctx: Ctx, db: Db, user: User, body: WithdrawRequest | None = None
) -> PublicationOut:
    """Stops new authorisations and delivery from controlled infrastructure. It cannot
    erase copies recipients already obtained (see the `notice` in the response)."""
    svc = CatalogueService(ctx, db)
    pub = await svc.withdraw(user, asset_id, version_id, body.reason if body else None)
    await db.commit()
    version = await db.get(AssetVersion, version_id)
    return _publication_out(pub, version.manifest_digest if version else None, WITHDRAWAL_NOTICE)


@router.put(
    "/assets/{asset_id}/versions/{version_id}/subtitles/{language}", response_model=SubtitleOut,
    summary="Attach a WebVTT subtitle track (before publication)",
    openapi_extra={
        "requestBody": {"required": True, "content": {"text/vtt": {"schema": {"type": "string"}}}}
    },
)  # fmt: skip
async def put_subtitle(
    asset_id: str, version_id: str, language: str, request: Request, ctx: Ctx, db: Db, user: User
) -> SubtitleOut:
    data = bytearray()
    async for chunk in request.stream():
        data.extend(chunk)
        if len(data) > 2 * 1024 * 1024:
            raise PayloadTooLarge("subtitle file is too large")
    svc = CatalogueService(ctx, db)
    track = await svc.add_subtitle(
        user, asset_id, version_id, language, request.headers.get("x-subtitle-label"), bytes(data)
    )
    await db.commit()
    return SubtitleOut(
        track_id=track.id, language=track.language, label=track.label, byte_length=track.byte_length
    )


@router.get("/assets/{asset_id}/versions/{version_id}/thumbnail", summary="Poster frame (JPEG)")
async def thumbnail(asset_id: str, version_id: str, ctx: Ctx, db: Db, creds: Creds) -> Response:
    svc = CatalogueService(ctx, db)
    asset, versions, _ = await svc.list_versions(creds.principal, asset_id)
    version = next((v for v in versions if v.id == version_id), None)
    if version is None or not version.thumbnail_reference:
        raise NotFound("thumbnail not found")
    data = await ctx.store.get(version.thumbnail_reference)
    cache = "public, max-age=300" if asset.visibility == "public" else "private, no-store"
    return Response(data, media_type="image/jpeg", headers={"Cache-Control": cache})


# ----------------------------------------------------------------------------- grants
def _grant_out(g: AccessGrant) -> GrantOut:
    return GrantOut(
        grant_id=g.id, asset_id=g.asset_id, principal_id=g.principal_id,
        permission=g.permission, expires_at=g.expires_at,
    )  # fmt: skip


@router.post(
    "/assets/{asset_id}/grants", response_model=GrantOut, status_code=201, summary="Grant a permission"
)
async def create_grant(asset_id: str, body: GrantCreate, ctx: Ctx, db: Db, user: User) -> GrantOut:
    """`view`, `offline_download` and `peer_contribute` are separate permissions."""
    grant = await CatalogueService(ctx, db).grant(
        user, asset_id, grantee=body.principal_id,
        permission=Permission(body.permission), ttl_seconds=body.ttl_seconds,
    )  # fmt: skip
    await db.commit()
    return _grant_out(grant)


@router.get("/assets/{asset_id}/grants", response_model=list[GrantOut], summary="List grants")
async def list_grants(asset_id: str, ctx: Ctx, db: Db, user: User) -> list[GrantOut]:
    return [_grant_out(g) for g in await CatalogueService(ctx, db).list_grants(user, asset_id)]


@router.delete("/assets/{asset_id}/grants/{grant_id}", status_code=204, summary="Revoke a grant")
async def revoke_grant(asset_id: str, grant_id: str, ctx: Ctx, db: Db, user: User) -> Response:
    await CatalogueService(ctx, db).revoke_grant(user, asset_id, grant_id)
    await db.commit()
    return Response(status_code=204)


# ----------------------------------------------------------------------------- jobs
@router.get("/processing-jobs/{job_id}", response_model=JobOut, tags=["processing"], summary="Job status")
async def get_job(job_id: str, ctx: Ctx, db: Db, user: User) -> JobOut:
    return _job_out(await CatalogueService(ctx, db).get_job(user, job_id))


@router.post(
    "/processing-jobs/{job_id}/cancel", response_model=JobOut, tags=["processing"], summary="Cancel a job"
)
async def cancel_job(job_id: str, ctx: Ctx, db: Db, user: User) -> JobOut:
    job = await CatalogueService(ctx, db).cancel_job(user, job_id)
    await db.commit()
    return _job_out(job)
