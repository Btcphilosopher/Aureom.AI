"""Peer coordination: sessions, availability, discovery, transfer grants, receipts."""

from __future__ import annotations

import time

from fastapi import APIRouter, Response

from ...discovery.registry import PeerRegistry
from ...domain import ReceiptReport
from ...errors import Unauthenticated
from ...persistence.models import PeerSession
from ...playback.service import PEER_PRIVACY_NOTICE, PlaybackService
from ..deps import Creds, Ctx, Db
from ..schemas import (
    AvailabilityIn,
    AvailabilityOut,
    DiscoveryIn,
    DiscoveryOut,
    PeerEndpoint,
    PeerHeartbeatIn,
    PeerOut,
    PeerSessionCreate,
    PeerSessionOut,
    ReceiptIn,
    ReceiptOut,
    TransferAuthIn,
    TransferAuthOut,
)

router = APIRouter(prefix="/v1", tags=["peers"])


def _peer_out(ctx: Ctx, peer: PeerSession, token: str | None = None) -> PeerSessionOut:
    s = ctx.settings
    return PeerSessionOut(
        peer_session_id=peer.id,
        peer_token=token,
        state=peer.state,
        expires_at=peer.expires_at,
        heartbeat_interval_seconds=max(0.1, s.peer_session_ttl_seconds / 3),
        contribute=peer.contribute,
        contribution_paused=peer.contribution_paused,
        limits={
            "availability_ids_per_message": s.availability_max_ids_per_message,
            "availability_ids_total": s.availability_max_per_peer,
            "discovery_segment_ids": s.discovery_max_segments,
            "grant_segments": s.transfer_grant_max_segments,
            "grants_per_minute": s.transfer_grants_per_minute,
            "concurrent_grants": s.transfer_grant_max_concurrent,
        },
        notices=[PEER_PRIVACY_NOTICE] if token else [],
    )


def _token(creds: Creds) -> str:
    if creds.opaque_token is None:
        raise Unauthenticated("a peer-session token is required")
    return creds.opaque_token


@router.post(
    "/peer-sessions", response_model=PeerSessionOut, status_code=201, summary="Register a peer agent"
)
async def create_peer_session(body: PeerSessionCreate, ctx: Ctx, db: Db, creds: Creds) -> PeerSessionOut:
    """Authenticated with the *playback session* token: only an authorised viewer of
    this asset version can join its swarm. `contribution.enabled` is an explicit
    opt-in and is ignored unless the playback session was granted contribution."""
    playback_svc = PlaybackService(ctx, db)
    playback = await playback_svc.authenticate(
        body.playback_session_id, session_token=creds.opaque_token, principal=creds.principal
    )
    await playback_svc.require_active(playback)
    peer, token = await PeerRegistry(ctx, db).register(
        playback,
        host=body.endpoint.host,
        port=body.endpoint.port,
        transport=body.transport,
        cert_thumbprint=body.cert_thumbprint,
        contribute=body.contribution.enabled,
        upload_kbps_cap=body.contribution.upload_kbps_cap,
        metered=body.contribution.metered,
    )
    await db.commit()
    return _peer_out(ctx, peer, token)


@router.post(
    "/peer-sessions/{peer_session_id}/heartbeat", response_model=PeerSessionOut, summary="Peer heartbeat"
)
async def peer_heartbeat(
    peer_session_id: str, ctx: Ctx, db: Db, creds: Creds, body: PeerHeartbeatIn | None = None
) -> PeerSessionOut:
    registry = PeerRegistry(ctx, db)
    peer = await registry.authenticate(peer_session_id, _token(creds))
    body = body or PeerHeartbeatIn()
    await registry.heartbeat(
        peer, contribution_paused=body.contribution_paused, metered=body.metered,
        upload_kbps_cap=body.upload_kbps_cap,
    )  # fmt: skip
    await db.commit()
    return _peer_out(ctx, peer)


@router.delete("/peer-sessions/{peer_session_id}", status_code=204, summary="Leave the swarm")
async def delete_peer_session(peer_session_id: str, ctx: Ctx, db: Db, creds: Creds) -> Response:
    registry = PeerRegistry(ctx, db)
    peer = await registry.authenticate(peer_session_id, _token(creds))
    await registry.close(peer)
    await db.commit()
    return Response(status_code=204)


@router.put(
    "/peer-sessions/{peer_session_id}/availability", response_model=AvailabilityOut,
    summary="Announce verified segments this peer can serve",
)  # fmt: skip
async def put_availability(
    peer_session_id: str, body: AvailabilityIn, ctx: Ctx, db: Db, creds: Creds
) -> AvailabilityOut:
    """Bounded message (`mode` = `replace` or `delta`). Every id must belong to the
    asset version the peer session is authorised for."""
    registry = PeerRegistry(ctx, db)
    peer = await registry.authenticate(peer_session_id, _token(creds))
    count = await registry.update_availability(peer, mode=body.mode, have=body.have, drop=body.drop)
    await db.commit()
    return AvailabilityOut(announced=count)


@router.post("/peer-discovery", response_model=DiscoveryOut, summary="Find authorised peers for segments")
async def peer_discovery(body: DiscoveryIn, ctx: Ctx, db: Db, creds: Creds) -> DiscoveryOut:
    """Returns only peers authorised for the same asset version, and only mentions the
    segment ids that were asked about. Ids outside the caller's version are refused."""
    started = time.perf_counter()
    registry = PeerRegistry(ctx, db)
    peer = await registry.authenticate(body.peer_session_id, _token(creds))
    grant = await registry.grant_for_peer(peer)
    candidates = await registry.discover(grant, body.segment_ids, requester_peer_id=peer.id)
    ctx.metrics.discovery_latency.observe(time.perf_counter() - started)
    return DiscoveryOut(
        peers=[
            PeerOut(
                peer_id=c.peer_id,
                endpoint=PeerEndpoint(host=c.host, port=c.port),
                transport=c.transport,
                cert_thumbprint=c.cert_thumbprint,
                segment_ids=sorted(c.segment_ids),
                reliability=c.reliability,
            )
            for c in candidates
        ]
    )


@router.post(
    "/transfer-authorisations",
    response_model=TransferAuthOut,
    status_code=201,
    summary="Issue a transfer grant",
)
async def transfer_authorisation(body: TransferAuthIn, ctx: Ctx, db: Db, creds: Creds) -> TransferAuthOut:
    """A short-lived signed grant bound to the requester, the serving peer, the asset
    version and the listed segments. The serving peer verifies it offline."""
    registry = PeerRegistry(ctx, db)
    peer = await registry.authenticate(body.peer_session_id, _token(creds))
    token, grant = await registry.authorise_transfer(
        peer, serving_peer_id=body.serving_peer_id, segment_ids=body.segment_ids
    )
    await db.commit()
    return TransferAuthOut(
        grant_id=grant.id,
        token=token,
        serving_peer_id=grant.serving_peer_session_id,
        segment_ids=grant.segment_ids,
        max_bytes=grant.max_bytes,
        expires_at=grant.expires_at.timestamp(),
    )


@router.post(
    "/transfer-receipts", response_model=ReceiptOut, status_code=201, summary="Report a transfer outcome"
)
async def transfer_receipt(body: ReceiptIn, ctx: Ctx, db: Db, creds: Creds) -> ReceiptOut:
    """Self-reported. Used only by bounded reliability rules; never treated as
    independently verified usage."""
    registry = PeerRegistry(ctx, db)
    peer = await registry.authenticate(body.peer_session_id, _token(creds))
    receipt = await registry.record_receipt(
        peer,
        ReceiptReport(
            grant_id=body.grant_id,
            segment_id=body.segment_id,
            role=body.role,
            outcome=body.outcome,
            bytes_transferred=body.bytes_transferred,
            duration_ms=body.duration_ms,
        ),
    )
    await db.commit()
    return ReceiptOut(receipt_id=receipt.id, corroborated=receipt.corroborated)
