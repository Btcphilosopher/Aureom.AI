"""Resumable upload endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Request, Response

from ...persistence.models import SourceUpload, UploadPart
from ...uploads.service import UploadRequest, UploadService
from ...uploads.sniff import ALLOWED
from ..deps import Ctx, Db, User
from ..schemas import PartOut, UploadComplete, UploadCreate, UploadLimits, UploadOut, UploadPartInfo

router = APIRouter(prefix="/v1/uploads", tags=["uploads"])


async def _out(svc: UploadService, ctx: Ctx, upload: SourceUpload, parts: list[UploadPart]) -> UploadOut:
    have = {p.part_number for p in parts}
    s = ctx.settings
    return UploadOut(
        upload_id=upload.id,
        state=upload.state,
        filename=upload.filename,
        size_bytes=upload.declared_size_bytes,
        visibility=upload.visibility,
        part_size_bytes=upload.part_size_bytes,
        part_count=upload.part_count,
        last_part_size_bytes=svc.expected_part_size(upload, upload.part_count),
        parts_received=[
            UploadPartInfo(part_number=p.part_number, size_bytes=p.size_bytes, sha256=p.sha256) for p in parts
        ],
        missing_parts=(
            [n for n in range(1, upload.part_count + 1) if n not in have][:1000]
            if upload.state in ("initiated", "uploading")
            else []
        ),
        expires_at=upload.expires_at,
        detected_container=upload.sniffed_container,
        sha256=upload.sha256,
        limits=UploadLimits(
            max_upload_bytes=s.upload_max_bytes,
            part_size_bytes=upload.part_size_bytes,
            max_part_bytes=upload.part_size_bytes,
            accepted_containers=[c.name for c in ALLOWED],
            quota_bytes=s.upload_quota_bytes,
            quota_used_bytes=await svc.quota_used(upload.owner_id),
        ),
        part_url_template=f"/v1/uploads/{upload.id}/parts/{{part_number}}",
    )


@router.post("", response_model=UploadOut, status_code=201, summary="Start a resumable upload")
async def create_upload(body: UploadCreate, response: Response, ctx: Ctx, db: Db, user: User) -> UploadOut:
    """Returns the part size, part count, limits and expiry. Repeating the call with the
    same `idempotency_key` returns the same upload (`200`)."""
    svc = UploadService(ctx, db)
    upload, created = await svc.create(
        user,
        UploadRequest(
            filename=body.filename,
            content_type=body.content_type,
            size_bytes=body.size_bytes,
            visibility=body.visibility,
            idempotency_key=body.idempotency_key,
        ),
    )
    await db.commit()
    if not created:
        response.status_code = 200
    return await _out(svc, ctx, upload, await svc.parts(upload.id))


@router.get("/{upload_id}", response_model=UploadOut, summary="Upload status and missing parts")
async def get_upload(upload_id: str, ctx: Ctx, db: Db, user: User) -> UploadOut:
    svc = UploadService(ctx, db)
    upload, parts = await svc.get(user, upload_id)
    await db.commit()
    return await _out(svc, ctx, upload, parts)


@router.put(
    "/{upload_id}/parts/{part_number}",
    response_model=PartOut,
    summary="Upload one part (raw bytes)",
    openapi_extra={
        "requestBody": {
            "required": True,
            "content": {"application/octet-stream": {"schema": {"type": "string", "format": "binary"}}},
        }
    },
)
async def put_part(
    upload_id: str, part_number: int, request: Request, ctx: Ctx, db: Db, user: User
) -> PartOut:
    """The body must be exactly the expected part size. Optional `X-Content-SHA256`
    (hex) is verified. Re-sending identical bytes is idempotent; different bytes for an
    acknowledged part are rejected with `409 part_conflict`."""
    length = request.headers.get("content-length")
    svc = UploadService(ctx, db)
    result = await svc.put_part(
        user,
        upload_id,
        part_number,
        request.stream(),
        content_length=int(length) if length and length.isdigit() else None,
        declared_sha256=request.headers.get("x-content-sha256"),
    )
    await db.commit()
    return PartOut(
        upload_id=upload_id,
        part_number=result.part.part_number,
        size_bytes=result.part.size_bytes,
        sha256=result.part.sha256,
        duplicate=result.duplicate,
    )


@router.post("/{upload_id}/complete", response_model=UploadOut, summary="Assemble the upload")
async def complete_upload(
    upload_id: str, ctx: Ctx, db: Db, user: User, body: UploadComplete | None = None
) -> UploadOut:
    svc = UploadService(ctx, db)
    upload = await svc.complete(user, upload_id, body.sha256 if body else None)
    await db.commit()
    return await _out(svc, ctx, upload, await svc.parts(upload.id))


@router.delete("/{upload_id}", status_code=204, summary="Abort an upload and release its storage")
async def abort_upload(upload_id: str, ctx: Ctx, db: Db, user: User) -> Response:
    await UploadService(ctx, db).abort(user, upload_id)
    await db.commit()
    return Response(status_code=204)
