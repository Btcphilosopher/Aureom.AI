"""Health, readiness, metrics and public keys."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from fastapi.responses import JSONResponse, Response

from ..deps import Ctx

router = APIRouter(tags=["meta"])


@router.get("/healthz", summary="Liveness")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/readyz", summary="Readiness: database, object storage and coordination")
async def readyz(ctx: Ctx) -> JSONResponse:
    checks = {
        "database": await ctx.db.ping(),
        "object_store": await ctx.store.healthcheck(),
        "coordination": await ctx.coord.ping(),
    }
    ready = all(checks.values())
    return JSONResponse({"ready": ready, "checks": checks}, status_code=200 if ready else 503)


@router.get("/metrics", include_in_schema=False)
async def metrics(ctx: Ctx) -> Response:
    return Response(ctx.metrics.render(), media_type="text/plain; version=0.0.4")


@router.get("/.well-known/jwks.json", summary="Public keys for manifests and grants")
async def jwks(ctx: Ctx) -> dict[str, Any]:
    return ctx.tokens.jwks()
