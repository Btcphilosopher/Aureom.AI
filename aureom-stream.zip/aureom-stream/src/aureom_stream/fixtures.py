"""Synthetic test media.

The clip is produced entirely by FFmpeg's built-in generators (``testsrc2`` test
pattern and a ``sine`` tone). It contains no third-party footage or music, so it can
be uploaded, published and downloaded offline freely in demonstrations.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path


def generate_test_video(
    out: Path, *, seconds: int = 20, size: str = "640x360", fps: int = 24, ffmpeg: str = "ffmpeg"
) -> Path:
    if not re.fullmatch(r"\d{2,4}x\d{2,4}", size) or not 1 <= seconds <= 600 or not 1 <= fps <= 60:
        raise ValueError("invalid fixture parameters")
    out.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(  # noqa: S603
        [
            ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", f"testsrc2=size={size}:rate={fps}:duration={seconds}",
            "-f", "lavfi", "-i", f"sine=frequency=440:sample_rate=48000:duration={seconds}",
            "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-b:v", "1500k",
            "-c:a", "aac", "-b:a", "96k", "-shortest", "-movflags", "+faststart",
            "-f", "mp4", str(out),
        ],
        check=True,
    )  # fmt: skip
    return out
