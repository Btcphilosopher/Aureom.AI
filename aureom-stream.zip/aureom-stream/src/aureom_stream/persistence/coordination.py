"""Short-lived coordination: rate limits, byte budgets, concurrency slots, one-shot claims.

Durable facts live in PostgreSQL. Only state that may safely vanish (and should
expire on its own) lives here. ``InMemoryCoordination`` serves tests and a single
process; ``RedisCoordination`` is used when several API processes share limits.
"""

from __future__ import annotations

from typing import Any, Protocol

from ..clock import Clock


class Coordination(Protocol):
    async def hit(self, key: str, limit: int, window_seconds: int, amount: int = 1) -> bool:
        """Add ``amount`` to a fixed-window counter; False (nothing added) if over ``limit``."""
        ...

    async def acquire_slot(self, key: str, member: str, limit: int, ttl_seconds: float) -> bool: ...

    async def release_slot(self, key: str, member: str) -> None: ...

    async def claim_once(self, key: str, ttl_seconds: float) -> bool:
        """True exactly once per key within the TTL (replay / duplicate guard)."""
        ...

    async def ping(self) -> bool: ...

    async def close(self) -> None: ...


class InMemoryCoordination:
    def __init__(self, clock: Clock) -> None:
        self._clock = clock
        self._windows: dict[str, tuple[int, int]] = {}  # key -> (window index, total)
        self._slots: dict[str, dict[str, float]] = {}
        self._claims: dict[str, float] = {}

    async def hit(self, key: str, limit: int, window_seconds: int, amount: int = 1) -> bool:
        index = int(self._clock.now() // window_seconds)
        window, total = self._windows.get(key, (index, 0))
        if window != index:
            total = 0
        if total + amount > limit:
            self._windows[key] = (index, total)
            return False
        self._windows[key] = (index, total + amount)
        return True

    async def acquire_slot(self, key: str, member: str, limit: int, ttl_seconds: float) -> bool:
        now = self._clock.now()
        slots = {m: exp for m, exp in self._slots.get(key, {}).items() if exp > now}
        if member not in slots and len(slots) >= limit:
            self._slots[key] = slots
            return False
        slots[member] = now + ttl_seconds
        self._slots[key] = slots
        return True

    async def release_slot(self, key: str, member: str) -> None:
        self._slots.get(key, {}).pop(member, None)

    async def claim_once(self, key: str, ttl_seconds: float) -> bool:
        now = self._clock.now()
        if len(self._claims) > 10_000:
            self._claims = {k: exp for k, exp in self._claims.items() if exp > now}
        if self._claims.get(key, 0.0) > now:
            return False
        self._claims[key] = now + ttl_seconds
        return True

    async def ping(self) -> bool:
        return True

    async def close(self) -> None:
        return None


_HIT_LUA = """
local current = tonumber(redis.call('GET', KEYS[1]) or '0')
if current + tonumber(ARGV[1]) > tonumber(ARGV[2]) then return 0 end
redis.call('INCRBY', KEYS[1], ARGV[1])
if current == 0 then redis.call('EXPIRE', KEYS[1], ARGV[3]) end
return 1
"""

_SLOT_LUA = """
local now = tonumber(redis.call('TIME')[1])
redis.call('ZREMRANGEBYSCORE', KEYS[1], '-inf', now)
if redis.call('ZSCORE', KEYS[1], ARGV[1]) == false
   and redis.call('ZCARD', KEYS[1]) >= tonumber(ARGV[2]) then
  return 0
end
redis.call('ZADD', KEYS[1], now + tonumber(ARGV[3]), ARGV[1])
redis.call('EXPIRE', KEYS[1], tonumber(ARGV[3]) + 5)
return 1
"""


class RedisCoordination:
    def __init__(self, url: str, *, prefix: str = "aureom:") -> None:
        import redis.asyncio as redis_async

        self._redis: Any = redis_async.from_url(url, decode_responses=True)
        self._prefix = prefix
        self._hit = self._redis.register_script(_HIT_LUA)
        self._slot = self._redis.register_script(_SLOT_LUA)

    async def hit(self, key: str, limit: int, window_seconds: int, amount: int = 1) -> bool:
        ok = await self._hit(keys=[self._prefix + "rl:" + key], args=[amount, limit, window_seconds])
        return bool(ok)

    async def acquire_slot(self, key: str, member: str, limit: int, ttl_seconds: float) -> bool:
        ttl = max(1, int(round(ttl_seconds)))
        return bool(await self._slot(keys=[self._prefix + "slot:" + key], args=[member, limit, ttl]))

    async def release_slot(self, key: str, member: str) -> None:
        await self._redis.zrem(self._prefix + "slot:" + key, member)

    async def claim_once(self, key: str, ttl_seconds: float) -> bool:
        ttl_ms = max(1, int(ttl_seconds * 1000))
        return bool(await self._redis.set(self._prefix + "once:" + key, "1", nx=True, px=ttl_ms))

    async def ping(self) -> bool:
        try:
            return bool(await self._redis.ping())
        except Exception:
            return False

    async def close(self) -> None:
        await self._redis.aclose()
