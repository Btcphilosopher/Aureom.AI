"""Relational model (PostgreSQL in deployment, SQLite for the zero-dependency demo).

A logical title (:class:`Asset`) is distinct from its immutable media
(:class:`AssetVersion`). Published bytes are never rewritten: every packaging attempt
writes under its own storage prefix and a published version is frozen.
"""

from __future__ import annotations

import enum
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.types import TypeDecorator


class UTCDateTime(TypeDecorator[datetime]):
    """Timezone-aware UTC timestamps on every backend (SQLite drops tzinfo)."""

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value: datetime | None, dialect: Any) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            raise ValueError("naive datetime is not allowed")
        return value.astimezone(UTC)

    def process_result_value(self, value: datetime | None, dialect: Any) -> datetime | None:
        if value is None:
            return None
        return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


class Base(DeclarativeBase):
    type_annotation_map = {dict[str, Any]: JSON, list[str]: JSON, datetime: UTCDateTime}


# --------------------------------------------------------------------------- enums
class Visibility(str, enum.Enum):
    PRIVATE = "private"  # only owner and explicitly granted principals
    UNLISTED = "unlisted"  # anyone holding the asset id may view; never listed
    PUBLIC = "public"  # listed and viewable


class UploadState(str, enum.Enum):
    INITIATED = "initiated"
    UPLOADING = "uploading"
    COMPLETED = "completed"
    ABORTED = "aborted"
    EXPIRED = "expired"


class VersionState(str, enum.Enum):
    UPLOADED = "uploaded"
    VALIDATING = "validating"
    TRANSCODING = "transcoding"
    PACKAGING = "packaging"
    READY_FOR_REVIEW = "ready_for_review"
    PUBLISHED = "published"
    WITHDRAWN = "withdrawn"
    FAILED = "failed"
    CANCELLED = "cancelled"


class JobStatus(str, enum.Enum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class SegmentKind(str, enum.Enum):
    INIT = "init"
    MEDIA = "media"


class Permission(str, enum.Enum):
    VIEW = "view"
    OFFLINE_DOWNLOAD = "offline_download"
    PEER_CONTRIBUTE = "peer_contribute"
    MANAGE = "manage"


class SessionState(str, enum.Enum):
    ACTIVE = "active"
    ENDED = "ended"
    EXPIRED = "expired"
    REVOKED = "revoked"


class DownloadState(str, enum.Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    DELETED = "deleted"
    EXPIRED = "expired"
    REVOKED = "revoked"


class PeerState(str, enum.Enum):
    ACTIVE = "active"
    CLOSED = "closed"
    EXPIRED = "expired"
    REVOKED = "revoked"


# --------------------------------------------------------------------------- media layer
class SourceUpload(Base):
    __tablename__ = "source_uploads"
    __table_args__ = (UniqueConstraint("owner_id", "idempotency_key"),)

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    owner_id: Mapped[str] = mapped_column(String(128), index=True)
    filename: Mapped[str] = mapped_column(String(255))  # display only, never used as a path
    declared_content_type: Mapped[str] = mapped_column(String(127))
    declared_size_bytes: Mapped[int] = mapped_column(BigInteger)
    visibility: Mapped[str] = mapped_column(String(16))
    idempotency_key: Mapped[str] = mapped_column(String(128))
    part_size_bytes: Mapped[int] = mapped_column(Integer)
    part_count: Mapped[int] = mapped_column(Integer)
    state: Mapped[str] = mapped_column(String(16), index=True)
    sniffed_container: Mapped[str | None] = mapped_column(String(32))
    sha256: Mapped[str | None] = mapped_column(String(64))
    storage_reference: Mapped[str | None] = mapped_column(String(512))
    created_at: Mapped[datetime]
    expires_at: Mapped[datetime]
    completed_at: Mapped[datetime | None]


class UploadPart(Base):
    __tablename__ = "upload_parts"

    upload_id: Mapped[str] = mapped_column(
        ForeignKey("source_uploads.id", ondelete="CASCADE"), primary_key=True
    )
    part_number: Mapped[int] = mapped_column(Integer, primary_key=True)
    size_bytes: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64))
    storage_reference: Mapped[str] = mapped_column(String(512))
    created_at: Mapped[datetime]


class Asset(Base):
    """A logical title. Its media lives in immutable :class:`AssetVersion` rows."""

    __tablename__ = "assets"

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    owner_id: Mapped[str] = mapped_column(String(128), index=True)
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text, default="")
    language: Mapped[str] = mapped_column(String(35))
    rights_declaration: Mapped[dict[str, Any]]
    visibility: Mapped[str] = mapped_column(String(16), index=True)
    distribution: Mapped[dict[str, Any]]
    created_at: Mapped[datetime]
    updated_at: Mapped[datetime]


class AssetVersion(Base):
    __tablename__ = "asset_versions"
    __table_args__ = (UniqueConstraint("asset_id", "version_number"),)

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id"), index=True)
    version_number: Mapped[int] = mapped_column(Integer)
    source_upload_id: Mapped[str] = mapped_column(ForeignKey("source_uploads.id"), unique=True)
    state: Mapped[str] = mapped_column(String(24), index=True)
    duration_seconds: Mapped[float | None] = mapped_column(Float)
    source_info: Mapped[dict[str, Any] | None]
    thumbnail_reference: Mapped[str | None] = mapped_column(String(512))
    # Signed (JWS) manifest sealed at publication; never modified afterwards.
    manifest_jws: Mapped[str | None] = mapped_column(Text)
    manifest_digest: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime]
    ready_at: Mapped[datetime | None]
    published_at: Mapped[datetime | None]
    withdrawn_at: Mapped[datetime | None]


class Rendition(Base):
    __tablename__ = "renditions"

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    asset_version_id: Mapped[str] = mapped_column(ForeignKey("asset_versions.id"), index=True)
    name: Mapped[str] = mapped_column(String(32))
    width: Mapped[int] = mapped_column(Integer)
    height: Mapped[int] = mapped_column(Integer)
    video_codec: Mapped[str] = mapped_column(String(32))
    audio_codec: Mapped[str | None] = mapped_column(String(32))
    codecs: Mapped[str] = mapped_column(String(96))  # RFC 6381 string for CODECS=
    bandwidth: Mapped[int] = mapped_column(Integer)  # peak bits/s
    average_bandwidth: Mapped[int] = mapped_column(Integer)
    frame_rate: Mapped[float] = mapped_column(Float)
    segment_count: Mapped[int] = mapped_column(Integer)
    total_bytes: Mapped[int] = mapped_column(BigInteger)


class MediaSegment(Base):
    __tablename__ = "media_segments"
    __table_args__ = (
        UniqueConstraint("rendition_id", "kind", "sequence_number"),
        Index("ix_media_segments_version", "asset_version_id"),
    )

    id: Mapped[str] = mapped_column("segment_id", String(40), primary_key=True)
    asset_version_id: Mapped[str] = mapped_column(ForeignKey("asset_versions.id"))
    rendition_id: Mapped[str] = mapped_column(ForeignKey("renditions.id"), index=True)
    kind: Mapped[str] = mapped_column(String(8))  # explicit: "init" or "media"
    sequence_number: Mapped[int] = mapped_column(Integer)  # 0 for the init segment
    start_time: Mapped[float] = mapped_column(Float)
    duration: Mapped[float] = mapped_column(Float)
    byte_length: Mapped[int] = mapped_column(Integer)
    content_hash: Mapped[str] = mapped_column(String(64))  # SHA-256, hex
    storage_reference: Mapped[str] = mapped_column(String(512))
    # No content encryption in release 1; the column keeps the contract stable.
    encryption_metadata_reference: Mapped[str | None] = mapped_column(String(512))


class SubtitleTrack(Base):
    __tablename__ = "subtitle_tracks"
    __table_args__ = (UniqueConstraint("asset_version_id", "language"),)

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    asset_version_id: Mapped[str] = mapped_column(ForeignKey("asset_versions.id"), index=True)
    language: Mapped[str] = mapped_column(String(35))
    label: Mapped[str] = mapped_column(String(100))
    format: Mapped[str] = mapped_column(String(16), default="webvtt")
    byte_length: Mapped[int] = mapped_column(Integer)
    content_hash: Mapped[str] = mapped_column(String(64))
    storage_reference: Mapped[str] = mapped_column(String(512))
    created_at: Mapped[datetime]


class ProcessingJob(Base):
    __tablename__ = "processing_jobs"
    __table_args__ = (Index("ix_processing_jobs_claim", "status", "lease_expires_at"),)

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    asset_version_id: Mapped[str] = mapped_column(ForeignKey("asset_versions.id"), unique=True)
    upload_id: Mapped[str] = mapped_column(ForeignKey("source_uploads.id"), index=True)
    status: Mapped[str] = mapped_column(String(16))
    stage: Mapped[str] = mapped_column(String(24))
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    attempt: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer)
    lease_owner: Mapped[str | None] = mapped_column(String(64))
    lease_expires_at: Mapped[datetime | None]
    cancel_requested: Mapped[bool] = mapped_column(Boolean, default=False)
    error: Mapped[dict[str, Any] | None]
    created_at: Mapped[datetime]
    started_at: Mapped[datetime | None]
    finished_at: Mapped[datetime | None]
    updated_at: Mapped[datetime]


class Publication(Base):
    """The act of publishing one immutable version, with the terms in force."""

    __tablename__ = "publications"

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id"), index=True)
    asset_version_id: Mapped[str] = mapped_column(ForeignKey("asset_versions.id"), unique=True)
    visibility: Mapped[str] = mapped_column(String(16), index=True)
    distribution: Mapped[dict[str, Any]]
    rights_declaration: Mapped[dict[str, Any]]
    published_by: Mapped[str] = mapped_column(String(128))
    published_at: Mapped[datetime]
    withdrawn_by: Mapped[str | None] = mapped_column(String(128))
    withdrawn_at: Mapped[datetime | None]
    withdrawal_reason: Mapped[str | None] = mapped_column(String(500))


# --------------------------------------------------------------------------- access layer
class AccessGrant(Base):
    __tablename__ = "access_grants"
    __table_args__ = (Index("ix_access_grants_lookup", "asset_id", "principal_id", "permission"),)

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id"))
    principal_id: Mapped[str] = mapped_column(String(128))
    permission: Mapped[str] = mapped_column(String(24))
    granted_by: Mapped[str] = mapped_column(String(128))
    created_at: Mapped[datetime]
    expires_at: Mapped[datetime | None]
    revoked_at: Mapped[datetime | None]


class PlaybackSession(Base):
    __tablename__ = "playback_sessions"

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    principal_id: Mapped[str] = mapped_column(String(128), index=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id"))
    asset_version_id: Mapped[str] = mapped_column(ForeignKey("asset_versions.id"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(String(16), index=True)
    rendition_ids: Mapped[list[str]]
    delivery_modes: Mapped[list[str]]
    peer_contribution: Mapped[bool] = mapped_column(Boolean, default=False)
    preview: Mapped[bool] = mapped_column(Boolean, default=False)
    client_capabilities: Mapped[dict[str, Any]]
    position_seconds: Mapped[float | None] = mapped_column(Float)
    created_at: Mapped[datetime]
    last_heartbeat_at: Mapped[datetime]
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime, index=True)
    hard_expires_at: Mapped[datetime]
    ended_at: Mapped[datetime | None]


class OfflineDownload(Base):
    __tablename__ = "offline_downloads"

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    principal_id: Mapped[str] = mapped_column(String(128), index=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id"))
    asset_version_id: Mapped[str] = mapped_column(ForeignKey("asset_versions.id"), index=True)
    rendition_id: Mapped[str] = mapped_column(ForeignKey("renditions.id"))
    subtitle_languages: Mapped[list[str]]
    token_hash: Mapped[str] = mapped_column(String(64))
    state: Mapped[str] = mapped_column(String(16), index=True)
    total_bytes: Mapped[int] = mapped_column(BigInteger)
    total_items: Mapped[int] = mapped_column(Integer)
    expected_digest: Mapped[str] = mapped_column(String(64))
    # Progress is reported by the client and is informational only.
    reported_bytes: Mapped[int] = mapped_column(BigInteger, default=0)
    reported_items: Mapped[int] = mapped_column(Integer, default=0)
    completion_digest_matches: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]
    updated_at: Mapped[datetime]
    expires_at: Mapped[datetime]
    completed_at: Mapped[datetime | None]
    deleted_at: Mapped[datetime | None]


# --------------------------------------------------------------------------- delivery layer
class PeerSession(Base):
    __tablename__ = "peer_sessions"
    __table_args__ = (Index("ix_peer_sessions_scope", "asset_version_id", "state"),)

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    principal_id: Mapped[str] = mapped_column(String(128))
    asset_version_id: Mapped[str] = mapped_column(ForeignKey("asset_versions.id"))
    playback_session_id: Mapped[str] = mapped_column(ForeignKey("playback_sessions.id"), index=True)
    token_hash: Mapped[str] = mapped_column(String(64))
    endpoint_host: Mapped[str] = mapped_column(String(255))
    endpoint_port: Mapped[int] = mapped_column(Integer)
    transport: Mapped[str] = mapped_column(String(24))
    cert_thumbprint: Mapped[str | None] = mapped_column(String(64))
    contribute: Mapped[bool] = mapped_column(Boolean, default=False)
    contribution_paused: Mapped[bool] = mapped_column(Boolean, default=False)
    metered: Mapped[bool] = mapped_column(Boolean, default=False)
    upload_kbps_cap: Mapped[int | None] = mapped_column(Integer)
    state: Mapped[str] = mapped_column(String(16))
    quarantined_until: Mapped[datetime | None]
    created_at: Mapped[datetime]
    last_heartbeat_at: Mapped[datetime]
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime, index=True)
    closed_at: Mapped[datetime | None]


class PeerAvailability(Base):
    __tablename__ = "peer_availability"

    peer_session_id: Mapped[str] = mapped_column(
        ForeignKey("peer_sessions.id", ondelete="CASCADE"), primary_key=True
    )
    segment_id: Mapped[str] = mapped_column(
        ForeignKey("media_segments.segment_id"), primary_key=True, index=True
    )
    announced_at: Mapped[datetime]


class TransferGrant(Base):
    __tablename__ = "transfer_grants"

    id: Mapped[str] = mapped_column(String(40), primary_key=True)  # also the JWT "jti"
    requester_peer_session_id: Mapped[str] = mapped_column(String(40), index=True)
    serving_peer_session_id: Mapped[str] = mapped_column(String(40), index=True)
    asset_version_id: Mapped[str] = mapped_column(String(40))
    segment_ids: Mapped[list[str]]
    max_bytes: Mapped[int] = mapped_column(BigInteger)
    issued_at: Mapped[datetime]
    expires_at: Mapped[datetime]


class TransferReceipt(Base):
    """Self-reported by a peer. Never treated as independently verified usage."""

    __tablename__ = "transfer_receipts"
    __table_args__ = (
        UniqueConstraint("grant_id", "reporter_peer_session_id", "segment_id"),
        Index("ix_transfer_receipts_subject", "subject_peer_session_id", "created_at"),
    )

    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    grant_id: Mapped[str] = mapped_column(ForeignKey("transfer_grants.id"))
    reporter_peer_session_id: Mapped[str] = mapped_column(String(40))
    subject_peer_session_id: Mapped[str] = mapped_column(String(40))  # the other party
    role: Mapped[str] = mapped_column(String(10))  # "receiver" | "sender"
    segment_id: Mapped[str] = mapped_column(String(40))
    bytes_transferred: Mapped[int] = mapped_column(BigInteger)
    outcome: Mapped[str] = mapped_column(String(24))
    duration_ms: Mapped[int] = mapped_column(Integer)
    corroborated: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]
