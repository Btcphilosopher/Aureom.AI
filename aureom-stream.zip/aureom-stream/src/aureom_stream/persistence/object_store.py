"""Object storage behind a small interface.

Two implementations: a local filesystem store (tests, single-machine demo) and an
S3-compatible store (boto3; MinIO, SeaweedFS, Ceph RGW, AWS S3 ...). Callers never see
storage credentials; clients only ever talk to the API or the origin.
"""

from __future__ import annotations

import asyncio
import hashlib
import os
import re
import shutil
import tempfile
from collections.abc import AsyncIterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

_KEY_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-/]{0,500}$")
CHUNK = 256 * 1024


class ObjectNotFound(KeyError):
    pass


class ObjectExists(Exception):
    pass


@dataclass(frozen=True)
class ComposeResult:
    size: int
    sha256: str


def validate_key(key: str) -> str:
    if not _KEY_RE.match(key) or ".." in key or "//" in key or key.endswith("/"):
        raise ValueError(f"invalid object key: {key!r}")
    return key


class ObjectStore(Protocol):
    async def put(
        self, key: str, data: bytes, *, content_type: str | None = None, if_absent: bool = False
    ) -> None: ...

    async def put_file(self, key: str, path: Path, *, content_type: str | None = None) -> None: ...

    async def get(self, key: str) -> bytes: ...

    async def get_range(self, key: str, start: int, end_inclusive: int) -> bytes: ...

    async def size(self, key: str) -> int | None: ...

    async def download_to(self, key: str, path: Path, *, max_bytes: int) -> int: ...

    async def delete(self, key: str) -> None: ...

    async def delete_prefix(self, prefix: str) -> int: ...

    async def compose(self, dest_key: str, part_keys: list[str]) -> ComposeResult: ...

    def iter_chunks(self, key: str, start: int, end_inclusive: int) -> AsyncIterator[bytes]: ...

    async def healthcheck(self) -> bool: ...


class LocalObjectStore:
    def __init__(self, root: Path) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        path = (self.root / validate_key(key)).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("key escapes storage root")
        return path

    def _put_sync(self, key: str, data: bytes, if_absent: bool) -> None:
        path = self._path(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        if if_absent and path.exists():
            raise ObjectExists(key)
        fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".tmp-")
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(data)
            if if_absent:
                try:
                    os.link(tmp, path)  # atomic create-if-absent
                except FileExistsError as exc:
                    raise ObjectExists(key) from exc
            else:
                os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    async def put(
        self, key: str, data: bytes, *, content_type: str | None = None, if_absent: bool = False
    ) -> None:
        await asyncio.to_thread(self._put_sync, key, data, if_absent)

    async def put_file(self, key: str, path: Path, *, content_type: str | None = None) -> None:
        dest = self._path(key)

        def _copy() -> None:
            dest.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=dest.parent, prefix=".tmp-")
            os.close(fd)
            shutil.copyfile(path, tmp)
            os.replace(tmp, dest)

        await asyncio.to_thread(_copy)

    def _read_sync(self, key: str, start: int = 0, length: int | None = None) -> bytes:
        try:
            with open(self._path(key), "rb") as fh:
                fh.seek(start)
                return fh.read() if length is None else fh.read(length)
        except FileNotFoundError as exc:
            raise ObjectNotFound(key) from exc

    async def get(self, key: str) -> bytes:
        return await asyncio.to_thread(self._read_sync, key)

    async def get_range(self, key: str, start: int, end_inclusive: int) -> bytes:
        return await asyncio.to_thread(self._read_sync, key, start, end_inclusive - start + 1)

    async def size(self, key: str) -> int | None:
        try:
            return (await asyncio.to_thread(os.stat, self._path(key))).st_size
        except FileNotFoundError:
            return None

    async def download_to(self, key: str, path: Path, *, max_bytes: int) -> int:
        size = await self.size(key)
        if size is None:
            raise ObjectNotFound(key)
        if size > max_bytes:
            raise ValueError("object exceeds allowed size")
        await asyncio.to_thread(shutil.copyfile, self._path(key), path)
        return size

    async def delete(self, key: str) -> None:
        try:
            await asyncio.to_thread(os.unlink, self._path(key))
        except FileNotFoundError:
            pass

    async def delete_prefix(self, prefix: str) -> int:
        base = self._path(prefix.rstrip("/") + "/x").parent

        def _rm() -> int:
            if not base.is_dir():
                return 0
            count = sum(1 for p in base.rglob("*") if p.is_file())
            shutil.rmtree(base, ignore_errors=True)
            return count

        return await asyncio.to_thread(_rm)

    async def compose(self, dest_key: str, part_keys: list[str]) -> ComposeResult:
        dest = self._path(dest_key)

        def _compose() -> ComposeResult:
            dest.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            size = 0
            fd, tmp = tempfile.mkstemp(dir=dest.parent, prefix=".tmp-")
            try:
                with os.fdopen(fd, "wb") as out:
                    for key in part_keys:
                        with open(self._path(key), "rb") as src:
                            while chunk := src.read(CHUNK):
                                digest.update(chunk)
                                out.write(chunk)
                                size += len(chunk)
                os.replace(tmp, dest)
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            return ComposeResult(size=size, sha256=digest.hexdigest())

        return await asyncio.to_thread(_compose)

    async def iter_chunks(self, key: str, start: int, end_inclusive: int) -> AsyncIterator[bytes]:
        pos = start
        while pos <= end_inclusive:
            n = min(CHUNK, end_inclusive - pos + 1)
            chunk = await asyncio.to_thread(self._read_sync, key, pos, n)
            if not chunk:
                break
            pos += len(chunk)
            yield chunk

    async def healthcheck(self) -> bool:
        return self.root.is_dir() and os.access(self.root, os.W_OK)


class S3ObjectStore:
    """S3-compatible store. boto3 is synchronous, so calls run in worker threads."""

    MIN_PART = 5 * 1024 * 1024  # S3 minimum size of every multipart part but the last

    def __init__(
        self,
        *,
        bucket: str,
        endpoint_url: str | None,
        region: str,
        access_key_id: str | None,
        secret_access_key: str | None,
    ) -> None:
        import boto3
        from botocore.config import Config

        self.bucket = bucket
        self._client: Any = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            region_name=region,
            aws_access_key_id=access_key_id,
            aws_secret_access_key=secret_access_key,
            config=Config(
                signature_version="s3v4",
                s3={"addressing_style": "path"},
                retries={"max_attempts": 3, "mode": "standard"},
                connect_timeout=5,
                read_timeout=30,
            ),
        )

    async def ensure_bucket(self) -> None:
        def _ensure() -> None:
            from botocore.exceptions import ClientError

            try:
                self._client.head_bucket(Bucket=self.bucket)
            except ClientError:
                self._client.create_bucket(Bucket=self.bucket)

        await asyncio.to_thread(_ensure)

    @staticmethod
    def _missing(exc: Exception) -> bool:
        code = getattr(exc, "response", {}).get("Error", {}).get("Code", "")
        return code in {"404", "NoSuchKey", "NotFound"}

    async def put(
        self, key: str, data: bytes, *, content_type: str | None = None, if_absent: bool = False
    ) -> None:
        validate_key(key)
        if if_absent and await self.size(key) is not None:
            raise ObjectExists(key)
        extra = {"ContentType": content_type} if content_type else {}
        await asyncio.to_thread(
            lambda: self._client.put_object(Bucket=self.bucket, Key=key, Body=data, **extra)
        )

    async def put_file(self, key: str, path: Path, *, content_type: str | None = None) -> None:
        validate_key(key)
        extra = {"ExtraArgs": {"ContentType": content_type}} if content_type else {}
        await asyncio.to_thread(lambda: self._client.upload_file(str(path), self.bucket, key, **extra))

    def _get_sync(self, key: str, byte_range: str | None = None) -> bytes:
        from botocore.exceptions import ClientError

        kwargs = {"Range": byte_range} if byte_range else {}
        try:
            return self._client.get_object(Bucket=self.bucket, Key=key, **kwargs)["Body"].read()
        except ClientError as exc:
            if self._missing(exc):
                raise ObjectNotFound(key) from exc
            raise

    async def get(self, key: str) -> bytes:
        return await asyncio.to_thread(self._get_sync, validate_key(key))

    async def get_range(self, key: str, start: int, end_inclusive: int) -> bytes:
        return await asyncio.to_thread(self._get_sync, validate_key(key), f"bytes={start}-{end_inclusive}")

    async def size(self, key: str) -> int | None:
        from botocore.exceptions import ClientError

        def _head() -> int | None:
            try:
                return int(self._client.head_object(Bucket=self.bucket, Key=key)["ContentLength"])
            except ClientError as exc:
                if self._missing(exc):
                    return None
                raise

        return await asyncio.to_thread(_head)

    async def download_to(self, key: str, path: Path, *, max_bytes: int) -> int:
        size = await self.size(validate_key(key))
        if size is None:
            raise ObjectNotFound(key)
        if size > max_bytes:
            raise ValueError("object exceeds allowed size")
        await asyncio.to_thread(self._client.download_file, self.bucket, key, str(path))
        return size

    async def delete(self, key: str) -> None:
        await asyncio.to_thread(lambda: self._client.delete_object(Bucket=self.bucket, Key=validate_key(key)))

    async def delete_prefix(self, prefix: str) -> int:
        prefix = prefix.rstrip("/") + "/"

        def _rm() -> int:
            count = 0
            paginator = self._client.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=self.bucket, Prefix=prefix):
                keys = [{"Key": o["Key"]} for o in page.get("Contents", [])]
                if keys:
                    self._client.delete_objects(Bucket=self.bucket, Delete={"Objects": keys})
                    count += len(keys)
            return count

        return await asyncio.to_thread(_rm)

    async def compose(self, dest_key: str, part_keys: list[str]) -> ComposeResult:
        validate_key(dest_key)

        def _compose() -> ComposeResult:
            digest = hashlib.sha256()
            size = 0
            upload = self._client.create_multipart_upload(Bucket=self.bucket, Key=dest_key)
            upload_id = upload["UploadId"]
            etags: list[dict[str, Any]] = []
            buffer = bytearray()

            def flush() -> None:
                number = len(etags) + 1
                resp = self._client.upload_part(
                    Bucket=self.bucket,
                    Key=dest_key,
                    UploadId=upload_id,
                    PartNumber=number,
                    Body=bytes(buffer),
                )
                etags.append({"PartNumber": number, "ETag": resp["ETag"]})
                buffer.clear()

            try:
                for key in part_keys:
                    data = self._get_sync(key)
                    digest.update(data)
                    size += len(data)
                    buffer.extend(data)
                    if len(buffer) >= self.MIN_PART:
                        flush()
                if buffer or not etags:
                    flush()
                self._client.complete_multipart_upload(
                    Bucket=self.bucket,
                    Key=dest_key,
                    UploadId=upload_id,
                    MultipartUpload={"Parts": etags},
                )
            except Exception:
                self._client.abort_multipart_upload(Bucket=self.bucket, Key=dest_key, UploadId=upload_id)
                raise
            return ComposeResult(size=size, sha256=digest.hexdigest())

        return await asyncio.to_thread(_compose)

    async def iter_chunks(self, key: str, start: int, end_inclusive: int) -> AsyncIterator[bytes]:
        pos = start
        while pos <= end_inclusive:
            last = min(pos + CHUNK - 1, end_inclusive)
            chunk = await self.get_range(key, pos, last)
            if not chunk:
                break
            pos += len(chunk)
            yield chunk

    async def healthcheck(self) -> bool:
        try:
            await asyncio.to_thread(lambda: self._client.head_bucket(Bucket=self.bucket))
            return True
        except Exception:
            return False
