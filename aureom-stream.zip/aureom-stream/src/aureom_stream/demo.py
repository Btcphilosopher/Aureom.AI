"""End-to-end demonstration.

Starts one backend, one origin, one worker and three isolated peer agents as separate
OS processes (own ports, own cache directories), then walks through the twelve
behaviours listed in the README and writes a report with the measurements of *this*
run. Playback here is simulated by the playback harness (no decoder); the offline
copy is additionally decoded with FFmpeg to show the delivered media is real.

    python -m aureom_stream.demo --work-dir var/demo --stack local
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import hashlib
import json
import os
import platform
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import httpx

from .access.tokens import TokenService, load_or_create_signing_key
from .client import ApiClient, ControlClient, ControlError
from .clock import SystemClock
from .fixtures import generate_test_video
from .manifests.version_manifest import VersionManifest
from .offline.downloader import OfflineDownloader

SPEED = 2.0
RIGHTS = {
    "basis": "owner",
    "statement": "Synthetic test pattern generated with FFmpeg (testsrc2 + sine); no third-party content.",
    "licence": "CC0-1.0",
}


class DemoFailure(AssertionError):
    pass


def check(condition: bool, message: str) -> None:
    if not condition:
        raise DemoFailure(message)


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def proc_usage(pid: int) -> dict[str, Any]:
    """CPU seconds and peak resident memory of a child process, from /proc."""
    try:
        stat = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        ticks = os.sysconf("SC_CLK_TCK")
        status = Path(f"/proc/{pid}/status").read_text()
        peak = next((ln.split()[1] for ln in status.splitlines() if ln.startswith("VmHWM:")), None)
        return {
            "cpu_user_seconds": round(int(stat[11]) / ticks, 2),
            "cpu_system_seconds": round(int(stat[12]) / ticks, 2),
            "peak_rss_kib": int(peak) if peak else None,
        }
    except (OSError, ValueError, IndexError):
        return {}


class Agent:
    def __init__(self, name: str, proc: subprocess.Popen[bytes], ready: dict[str, Any]) -> None:
        self.name = name
        self.proc = proc
        self.port = ready["port"]
        self._base = f"http://127.0.0.1:{ready['admin_port']}"
        self._headers = {"Authorization": f"Bearer {ready['admin_token']}"}
        self._http = httpx.AsyncClient(timeout=180.0)

    async def call(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        response = await self._http.request(method, self._base + path, json=body, headers=self._headers)
        if response.status_code >= 400:
            raise DemoFailure(f"agent {self.name} {path}: {response.status_code} {response.text}")
        return response.json()

    async def play(self, token: str, asset_id: str, **options: Any) -> dict[str, Any]:
        record = await self.call(
            "POST", "/admin/v1/play",
            {"principal_token": token, "asset_id": asset_id, "speed": SPEED, **options},
        )  # fmt: skip
        if record.get("state") == "failed":
            raise DemoFailure(f"agent {self.name} playback failed: {record['error']}")
        return record  # type: ignore[no-any-return]

    async def wait_play(self, play_id: str, timeout: float = 120.0) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            record = await self.call("GET", f"/admin/v1/plays/{play_id}")
            if record["state"] != "running":
                if record["state"] == "failed":
                    raise DemoFailure(f"agent {self.name} playback failed: {record['error']}")
                return record  # type: ignore[no-any-return]
            await asyncio.sleep(0.25)
        raise DemoFailure("playback did not finish in time")

    async def stats(self) -> dict[str, Any]:
        return await self.call("GET", "/admin/v1/stats")  # type: ignore[no-any-return]

    async def close(self) -> None:
        await self._http.aclose()


def delivery(record: dict[str, Any]) -> dict[str, Any]:
    """The interesting part of a playback report, flattened for the demo report."""
    report = record["report"]
    m = report["metrics"]
    return {
        "playback": "SIMULATED (playback-clock harness, no decoding)",
        "completed": report["completed"],
        "reason": report["reason"],
        "media_seconds": report["final_position"],
        "wall_seconds": report["wall_seconds"],
        "playback_speed": SPEED,
        "startup_delay_seconds": report["startup_delay_seconds"],
        "deadline_misses": m["deadline_misses"],
        "stall_seconds": report["stall_seconds"],
        "origin_segments": m["origin_segments"],
        "peer_segments": m["peer_segments"],
        "origin_bytes": m["origin_bytes"],
        "peer_bytes": m["peer_bytes"],
        "verification_failures": m["verification_failures"],
        "cache_hit_rate": m["cache_hit_rate"],
        "peer_failures": m["peer_failures"],
        "origin_fallbacks": m["origin_fallbacks"],
        "hedged_requests": m["hedged_requests"],
        "cancelled_requests": m["cancelled_requests"],
        "retries": m["retries"],
        "peer_discovery_latency_seconds": m["peer_discovery_latency_seconds"],
        "transfer_latency_origin_seconds": m["transfer_latency_origin_seconds"],
        "transfer_latency_peer_seconds": m["transfer_latency_peer_seconds"],
        "agent_process": m["process"],
    }


class Demo:
    def __init__(self, work: Path, stack: str) -> None:
        self.work = work.resolve()
        self.stack = stack
        self.work.mkdir(parents=True, exist_ok=True)
        self.procs: dict[str, subprocess.Popen[bytes]] = {}
        self.agents: dict[str, Agent] = {}
        self.api_port = free_port()
        self.origin_port = free_port()
        self.api_url = f"http://127.0.0.1:{self.api_port}"
        self.origin_url = f"http://127.0.0.1:{self.origin_port}"
        self.results: dict[str, Any] = {}
        self.env = dict(os.environ)
        self.env.update(
            {
                "AUREOM_ENV": "dev",
                "AUREOM_LOG_LEVEL": "WARNING",
                "AUREOM_SIGNING_KEY_PATH": str(self.work / "keys" / "signing-ed25519.pem"),
                "AUREOM_WORK_DIR": str(self.work / "work"),
                "AUREOM_PUBLIC_BASE_URL": self.api_url,
                "AUREOM_ORIGIN_BASE_URL": self.origin_url,
                "AUREOM_UPLOAD_PART_SIZE_BYTES": str(256 * 1024),
                "AUREOM_SEGMENT_DURATION_SECONDS": "2",
                "AUREOM_MAX_RENDITIONS": "2",
                "AUREOM_PLAYBACK_SESSION_TTL_SECONDS": "8",
                "AUREOM_PLAYBACK_HEARTBEAT_SECONDS": "2",
                "AUREOM_PEER_SESSION_TTL_SECONDS": "6",
                "AUREOM_MAX_SESSIONS_PER_PRINCIPAL": "50",
            }
        )
        if stack == "local":
            self.env.update(
                {
                    "AUREOM_DATABASE_URL": f"sqlite+aiosqlite:///{self.work / 'aureom.db'}",
                    "AUREOM_STORAGE_BACKEND": "local",
                    "AUREOM_STORAGE_LOCAL_ROOT": str(self.work / "objects"),
                }
            )
            self.env.pop("AUREOM_REDIS_URL", None)
        self.tokens: TokenService | None = None

    # ------------------------------------------------------------------ plumbing
    def token(self, user: str, *scopes: str) -> str:
        assert self.tokens is not None
        return self.tokens.mint_principal_token(user, list(scopes), ttl=3600)

    def api(self, user: str | None, *scopes: str) -> ApiClient:
        return ApiClient(ControlClient(self.api_url), self.token(user, *scopes) if user else None)

    def spawn(self, name: str, args: list[str]) -> subprocess.Popen[bytes]:
        log = open(self.work / f"{name}.log", "wb")  # noqa: SIM115
        proc = subprocess.Popen(  # noqa: S603
            [sys.executable, "-m", "aureom_stream.cli", *args],
            env=self.env, stdout=log, stderr=subprocess.STDOUT, cwd=self.work,
        )  # fmt: skip
        self.procs[name] = proc
        return proc

    async def wait_http(self, url: str, name: str) -> None:
        async with httpx.AsyncClient() as http:
            for _ in range(200):
                if self.procs[name].poll() is not None:
                    raise DemoFailure(f"{name} exited early; see {self.work / (name + '.log')}")
                with contextlib.suppress(httpx.HTTPError):
                    if (await http.get(url, timeout=1.0)).status_code == 200:
                        return
                await asyncio.sleep(0.1)
        raise DemoFailure(f"{name} did not become ready")

    async def start_agent(self, name: str, *extra: str) -> Agent:
        ready_file = self.work / f"{name}.ready.json"
        ready_file.unlink(missing_ok=True)
        proc = self.spawn(
            name,
            [
                "peer-agent", "--control-url", self.api_url, "--name", name,
                "--cache-dir", str(self.work / "agents" / name / "cache"),
                "--cache-bytes", str(64 * 1024 * 1024),
                "--urgent-window", "1.0", "--prefetch-window", "8",
                "--enable-fault-injection", "--ready-file", str(ready_file), *extra,
            ],
        )  # fmt: skip
        for _ in range(200):
            if ready_file.exists():
                break
            if proc.poll() is not None:
                raise DemoFailure(f"{name} exited early; see {self.work / (name + '.log')}")
            await asyncio.sleep(0.1)
        else:
            raise DemoFailure(f"{name} did not become ready")
        agent = Agent(name, proc, json.loads(ready_file.read_text()))
        ready_file.unlink()
        self.agents[name] = agent
        return agent

    async def start_services(self) -> None:
        key = load_or_create_signing_key(Path(self.env["AUREOM_SIGNING_KEY_PATH"]), create=True)
        self.tokens = TokenService(
            key, issuer=self.env.get("AUREOM_ISSUER", "aureom-stream"), clock=SystemClock()
        )
        if self.stack == "services":
            migrations = Path(self.env.get("AUREOM_MIGRATIONS_DIR", Path.cwd() / "migrations"))
            self.env["AUREOM_MIGRATIONS_DIR"] = str(migrations)
            subprocess.run(  # noqa: S603
                [sys.executable, "-m", "aureom_stream.cli", "db", "upgrade"], env=self.env, check=True
            )
        self.spawn("api", ["serve-api", "--port", str(self.api_port)])
        await self.wait_http(self.api_url + "/readyz", "api")
        self.spawn("origin", ["serve-origin", "--port", str(self.origin_port)])
        await self.wait_http(self.origin_url + "/readyz", "origin")
        self.spawn("worker", ["worker"])
        # Three isolated agents. Contribution is an explicit flag on each of them.
        await self.start_agent("agent-a", "--contribute", "--background-agent")
        await self.start_agent("agent-b", "--contribute", "--background-agent")
        await self.start_agent("agent-c", "--contribute")  # no background agent: stops with the player

    async def stop(self) -> None:
        for agent in self.agents.values():
            with contextlib.suppress(Exception):
                await agent.call("POST", "/admin/v1/shutdown")
            await agent.close()
        deadline = time.monotonic() + 8
        for name, proc in self.procs.items():
            if name.startswith("agent"):
                with contextlib.suppress(subprocess.TimeoutExpired):
                    proc.wait(timeout=max(0.1, deadline - time.monotonic()))
        for proc in self.procs.values():
            if proc.poll() is None:
                proc.send_signal(signal.SIGTERM)
        for proc in self.procs.values():
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()

    def step(self, number: int, title: str, data: dict[str, Any]) -> None:
        self.results[f"{number:02d}"] = {"title": title, "result": "passed", **data}
        print(f"[{number:02d}] {title}: passed", flush=True)
        for key, value in data.items():
            if not isinstance(value, (dict, list)) or len(json.dumps(value)) < 150:
                print(f"       {key}: {value}", flush=True)

    # ------------------------------------------------------------------ the scenario
    async def run(self) -> dict[str, Any]:
        started = time.time()
        video = generate_test_video(self.work / "fixtures" / "test-pattern.mp4", seconds=20, size="640x360")
        digest = hashlib.sha256(video.read_bytes()).hexdigest()
        await self.start_services()
        owner = self.api("alice", "media:upload", "media:publish")

        # ---- 1. resumable upload ---------------------------------------------------
        size = video.stat().st_size
        first_pass: list[int] = []
        status = await owner.upload_file(
            video, idempotency_key="demo-public-0001", only_parts=lambda n: n % 2 == 1, complete=False,
            on_part=lambda n, _c, _d: first_pass.append(n),
        )  # fmt: skip
        upload_id = status["upload_id"]
        check(status["state"] == "uploading" and status["missing_parts"], "upload should be incomplete")
        missing_after_interrupt = list(status["missing_parts"])
        part_size = status["part_size_bytes"]
        early = None
        try:
            await owner.call("POST", f"/v1/uploads/{upload_id}/complete")
        except ControlError as exc:
            early = exc.code
        check(early == "incomplete_upload", "completing an incomplete upload must fail")
        with open(video, "rb") as fh:
            part1 = fh.read(part_size)
        retry = await owner.call("PUT", f"/v1/uploads/{upload_id}/parts/1", content=part1)
        check(retry["duplicate"] is True, "re-sending an identical part must be idempotent")
        conflict = None
        try:
            await owner.call(
                "PUT", f"/v1/uploads/{upload_id}/parts/1", content=part1[:-1] + bytes([part1[-1] ^ 1])
            )
        except ControlError as exc:
            conflict = exc.code
        check(conflict == "part_conflict", "different bytes for a stored part must be rejected")
        second_pass: list[int] = []
        done = await owner.upload_file(
            video, idempotency_key="demo-public-0001", on_part=lambda n, _c, _d: second_pass.append(n)
        )
        check(
            done["state"] == "completed" and done["sha256"] == digest, "assembled upload must match the file"
        )
        check(second_pass == missing_after_interrupt, "resume must send exactly the missing parts")
        private_upload = await owner.upload_file(video, idempotency_key="demo-private-0001")
        self.step(1, "Resumable upload", {
            "file_bytes": size, "part_size_bytes": part_size, "part_count": status["part_count"],
            "parts_sent_before_interruption": first_pass, "missing_after_interruption": missing_after_interrupt,
            "complete_while_incomplete": early, "duplicate_part_retry": "idempotent (duplicate=true)",
            "conflicting_part": conflict, "parts_sent_on_resume": second_pass,
            "sha256_matches_source": True, "detected_container": done["detected_container"],
        })  # fmt: skip

        # ---- 2. processing and publication -----------------------------------------
        t0 = time.monotonic()
        public = await owner.call("POST", "/v1/assets", json={
            "upload_id": upload_id, "title": "AUREOM test pattern (public)", "language": "en",
            "description": "Synthetic 20 s test clip.", "rights_declaration": RIGHTS,
            "distribution": {"peer_delivery": True, "offline_download": "granted", "peer_contribution": "all_viewers"},
        })  # fmt: skip
        private = await owner.call("POST", "/v1/assets", json={
            "upload_id": private_upload["upload_id"], "title": "AUREOM test pattern (private)",
            "language": "en", "rights_declaration": RIGHTS,
            "distribution": {"peer_delivery": True, "peer_contribution": "all_viewers"},
        })  # fmt: skip
        pub_id, priv_id = public["asset_id"], private["asset_id"]
        pub_ver, priv_ver = public["versions"][0]["version_id"], private["versions"][0]["version_id"]
        states: list[str] = []
        while True:
            version = (await owner.call("GET", f"/v1/assets/{pub_id}/versions"))[0]
            if not states or states[-1] != version["state"]:
                states.append(version["state"])
            if version["state"] in ("ready_for_review", "failed", "cancelled"):
                break
            await asyncio.sleep(0.05)
        check(version["state"] == "ready_for_review", f"processing failed: {version['job']}")
        private_version = await owner.wait_for_processing(priv_id, priv_ver)
        check(private_version["state"] == "ready_for_review", "private asset processing failed")
        processing_seconds = round(time.monotonic() - t0, 2)
        renditions = version["renditions"]
        check(len(renditions) == 2, "expected two packaged renditions")
        check(len({r["segment_count"] for r in renditions}) == 1, "renditions must have aligned segments")
        check(max(r["height"] for r in renditions) <= 360, "no upscaling")
        await owner.call(
            "PUT", f"/v1/assets/{pub_id}/versions/{pub_ver}/subtitles/en",
            content=b"WEBVTT\n\n00:00:00.000 --> 00:00:04.000\nAUREOM STREAM test pattern\n",
        )  # fmt: skip
        blocked = None
        try:
            await owner.call(
                "POST", f"/v1/assets/{pub_id}/versions/{pub_ver}/publish", json={"visibility": "public"}
            )
        except ControlError as exc:
            blocked = exc.code
        check(blocked == "public_confirmation_required", "public listing must need explicit confirmation")
        publication = await owner.call(
            "POST", f"/v1/assets/{pub_id}/versions/{pub_ver}/publish",
            json={"visibility": "public", "confirm_public": True},
        )  # fmt: skip
        private_publication = await owner.call("POST", f"/v1/assets/{priv_id}/versions/{priv_ver}/publish")
        check(private_publication["visibility"] == "private", "the private asset must stay private")
        for user, asset_id, permission in (
            ("bob", priv_id, "view"), ("ben", pub_id, "offline_download"),
        ):  # fmt: skip
            await owner.call(
                "POST", f"/v1/assets/{asset_id}/grants", json={"principal_id": user, "permission": permission}
            )
        listed = {a["asset_id"] for a in (await self.api(None).call("GET", "/v1/assets"))["assets"]}
        check(pub_id in listed and priv_id not in listed, "only the public asset may be discoverable")
        self.step(2, "Processing and publication", {
            "pipeline_states_observed": states, "processing_wall_seconds_both_assets": processing_seconds,
            "renditions": [
                {k: r[k] for k in ("name", "width", "height", "codecs", "bandwidth", "segment_count", "total_bytes")}
                for r in renditions
            ],
            "public_asset": {"asset_id": pub_id, "visibility": publication["visibility"]},
            "private_asset": {"asset_id": priv_id, "visibility": private_publication["visibility"]},
            "publish_public_without_confirmation": blocked,
            "manifest_digest": publication["manifest_digest"],
            "anonymous_listing_contains_private_asset": False,
        })  # fmt: skip
        segments_total = renditions[0]["segment_count"] + 1  # + initialisation segment

        a, b, c = self.agents["agent-a"], self.agents["agent-b"], self.agents["agent-c"]
        # ---- 3 + 4. authorised playback, initial origin retrieval --------------------
        play_a = await a.play(self.token("ana"), pub_id)
        da = delivery(play_a)
        check(da["completed"] and da["deadline_misses"] == 0, "first playback must complete without stalls")
        check(
            da["peer_segments"] == 0 and da["origin_segments"] == segments_total,
            "first viewer has only the origin",
        )
        self.step(3, "Authorised playback", {
            "viewer": "ana (authenticated, public asset)", "delivery_modes": ["origin", "peer"],
            "contribution_opt_in": play_a["contribute"], **{k: da[k] for k in (
                "playback", "completed", "media_seconds", "wall_seconds", "playback_speed",
                "startup_delay_seconds", "deadline_misses")},
        })  # fmt: skip
        self.step(4, "Initial origin retrieval", {
            "agent": "agent-a", **{k: da[k] for k in (
                "origin_segments", "peer_segments", "origin_bytes", "peer_bytes", "verification_failures",
                "transfer_latency_origin_seconds")},
        })  # fmt: skip

        # ---- 5. a second agent retrieves segments from a peer -----------------------
        play_b = await b.play(self.token("ben"), pub_id)
        db = delivery(play_b)
        stats_a = await a.stats()
        check(db["completed"] and db["deadline_misses"] == 0, "second playback must complete without stalls")
        check(db["peer_segments"] >= 3, f"agent-b should fetch from agent-a: {db}")
        check(db["verification_failures"] == 0, "peer segments must verify")
        check(stats_a["upload"]["served_segments"] == db["peer_segments"], "agent-a's uploads must match")
        # Watching again on the same device: everything comes from its verified cache.
        replay = delivery(await b.play(self.token("ben"), pub_id, speed=4.0))
        check(
            replay["completed"] and replay["cache_hit_rate"] == 1.0, f"replay should hit the cache: {replay}"
        )
        check(replay["origin_bytes"] == 0 and replay["peer_bytes"] == 0, "a cached replay needs no network")
        self.step(5, "Second agent retrieves segments from a peer", {
            "agent": "agent-b", "serving_peer": "agent-a",
            "note": "initialisation and near-playback segments still come from the origin by design",
            **{k: db[k] for k in (
                "origin_segments", "peer_segments", "origin_bytes", "peer_bytes", "verification_failures",
                "deadline_misses", "startup_delay_seconds", "peer_discovery_latency_seconds",
                "transfer_latency_peer_seconds", "transfer_latency_origin_seconds")},
            "agent_a_served_segments": stats_a["upload"]["served_segments"],
            "first_play_cache_hit_rate": db["cache_hit_rate"],
            "replay_on_same_agent": {
                "cache_hit_rate": replay["cache_hit_rate"], "origin_bytes": replay["origin_bytes"],
                "peer_bytes": replay["peer_bytes"], "deadline_misses": replay["deadline_misses"],
                "startup_delay_seconds": replay["startup_delay_seconds"],
            },
        })  # fmt: skip

        # ---- 11. contribution-bandwidth enforcement (done while agent-a is alive) ----
        cap_kbps = 1200
        await b.call("POST", "/admin/v1/contribution", {"paused": True})  # agent-a is the only source
        await a.call("POST", "/admin/v1/contribution", {"upload_kbps_cap": cap_kbps})
        before = (await a.stats())["upload"]
        play_cap = await c.play(self.token("cy"), pub_id)
        dc_cap = delivery(play_cap)
        after = (await a.stats())["upload"]
        sent = after["sent_bytes"] - before["sent_bytes"]
        busy = after["busy_seconds"] - before["busy_seconds"]
        rate_bytes = cap_kbps * 1000 / 8
        allowance = rate_bytes * 0.25 + rate_bytes * busy  # token bucket: burst + rate x time
        check(sent > 0, "agent-a should have served something under the cap")
        check(sent <= allowance * 1.05, f"upload cap exceeded: {sent} bytes in {busy:.2f}s")
        check(dc_cap["completed"], "capped playback must complete")
        await a.call("POST", "/admin/v1/contribution", {"clear_upload_cap": True})
        self.step(11, "Contribution-bandwidth enforcement", {
            "serving_agent": "agent-a", "upload_cap_kbps": cap_kbps,
            "bytes_sent_under_cap": sent, "busy_seconds": round(busy, 3),
            "segments_fully_served": after["served_segments"] - before["served_segments"],
            "measured_kbps_while_sending": round(sent * 8 / 1000 / busy, 1) if busy else None,
            "token_bucket_allowance_bytes": int(allowance),
            "viewer_deadline_misses": dc_cap["deadline_misses"],
            "viewer_hedged_requests": dc_cap["hedged_requests"],
            "viewer_origin_fallbacks": dc_cap["origin_fallbacks"],
            "note": "the capped peer is slower than playback, so the scheduler hedged with the origin",
        })  # fmt: skip

        # ---- 6. origin fallback after a peer disconnects -----------------------------
        running = await c.play(self.token("cy"), pub_id, wait=False)
        await asyncio.sleep(3.0)
        a.proc.kill()  # the only contributing peer vanishes without saying goodbye
        a.proc.wait()
        killed_at_media_seconds = 3.0 * SPEED
        play_c = await c.wait_play(running["play_id"])
        dc = delivery(play_c)
        check(dc["completed"], f"playback must survive the peer loss: {dc}")
        check(dc["origin_fallbacks"] >= 1, "segments after the disconnect must come from the origin")
        check(dc["peer_segments"] >= 1, "peers were used before the disconnect")
        self.step(6, "Origin fallback after a peer disconnects", {
            "viewer_agent": "agent-c", "killed": "agent-a (SIGKILL)",
            "killed_at_about_media_seconds": killed_at_media_seconds,
            **{k: dc[k] for k in (
                "completed", "deadline_misses", "stall_seconds", "peer_segments", "origin_segments",
                "origin_fallbacks", "peer_failures", "hedged_requests")},
        })  # fmt: skip

        # ---- 7. rejection of a corrupted segment -------------------------------------
        await b.call("POST", "/admin/v1/contribution", {"paused": False})
        await b.call("POST", "/admin/v1/faults", {"corrupt": True})  # agent-b now serves flipped bytes
        play_bad = await c.play(self.token("cy"), pub_id)
        dbad = delivery(play_bad)
        await b.call("POST", "/admin/v1/faults", {"corrupt": False})
        check(dbad["verification_failures"] >= 1, "the corrupted segment must be detected")
        check(dbad["peer_segments"] == 0, "no corrupted segment may be accepted")
        check(dbad["completed"], "playback continues from the origin")
        self.step(7, "Rejection of a corrupted segment", {
            "corrupting_peer": "agent-b (fault injection: one flipped byte per segment)",
            **{k: dbad[k] for k in (
                "verification_failures", "peer_failures", "peer_segments", "origin_segments",
                "origin_fallbacks", "completed", "deadline_misses")},
            "check": "every delivered segment matched the SHA-256 in the signed manifest",
        })  # fmt: skip

        # ---- 8. seek-driven priority changes -----------------------------------------
        await b.call("POST", "/admin/v1/contribution", {"upload_kbps_cap": 500})  # keep transfers in flight
        seek_to = 14.0
        play_seek = await c.play(self.token("cy"), pub_id, seeks=[[2.0, seek_to]])
        await b.call("POST", "/admin/v1/contribution", {"clear_upload_cap": True})
        dseek = delivery(play_seek)
        events = play_seek["events"]
        seek_index = next(i for i, e in enumerate(events) if e["event"] == "seek")
        before_seek = [
            e["seq"] for e in events[:seek_index] if e["event"] == "delivered" and e["kind"] == "media"
        ]
        after_seek = [
            e["seq"] for e in events[seek_index:] if e["event"] == "delivered" and e["kind"] == "media"
        ]
        cancelled = [e["seq"] for e in events if e["event"] == "seek_cancel"]
        target_seq = int(seek_to // 2)
        check(dseek["completed"], "playback after the seek must complete")
        check(
            bool(after_seek) and min(after_seek) >= target_seq,
            "after the seek only new-position segments load",
        )
        never = sorted(set(range(segments_total - 1)) - set(before_seek) - set(after_seek))
        self.step(8, "Seek-driven priority changes", {
            "seek": f"after 2.0 s of wall time, jump to {seek_to} s",
            "segments_delivered_before_seek": before_seek,
            "requests_cancelled_by_seek": cancelled,
            "segments_delivered_after_seek": after_seek,
            "segments_never_downloaded": never,
            "cancelled_requests_total": dseek["cancelled_requests"],
            "deadline_misses": dseek["deadline_misses"],
        })  # fmt: skip

        # ---- 9. unauthorised private-asset discovery is rejected ----------------------
        mallory = self.api("mallory")
        outcomes: dict[str, Any] = {}
        for label, call in (
            ("get_private_asset", lambda: mallory.call("GET", f"/v1/assets/{priv_id}")),
            ("playback_session_for_private_asset",
             lambda: mallory.call("POST", "/v1/playback-sessions", json={"asset_id": priv_id})),
        ):  # fmt: skip
            try:
                await call()
                outcomes[label] = "ALLOWED"
            except ControlError as exc:
                outcomes[label] = f"{exc.status} {exc.code}"
        # The owner can see the private version's segment ids (to probe with).
        owner_session = await owner.call("POST", "/v1/playback-sessions", json={"asset_id": priv_id})
        owner_manifest = VersionManifest.model_validate_json(
            _jws_payload(
                await owner.control.signed_manifest(
                    owner_session["signed_manifest_url"], owner_session["session_token"]
                )
            )
        )
        private_ids = [s.segment_id for s in owner_manifest.renditions[0].segments[:3]]
        # Mallory is a legitimate peer in the PUBLIC swarm and tries to look sideways.
        m_session = await mallory.call("POST", "/v1/playback-sessions", json={
            "asset_id": pub_id, "client_capabilities": {"supported_codecs": ["avc1"], "peer_delivery": True},
        })  # fmt: skip
        m_peer = await mallory.control.request("POST", "/v1/peer-sessions", token=m_session["session_token"], json={
            "playback_session_id": m_session["session_id"], "endpoint": {"host": "127.0.0.1", "port": 9},
            "transport": "loopback-http",
        })  # fmt: skip
        try:
            await mallory.control.request("POST", "/v1/peer-discovery", token=m_peer["peer_token"], json={
                "peer_session_id": m_peer["peer_session_id"], "segment_ids": private_ids,
            })  # fmt: skip
            outcomes["peer_discovery_for_private_segments"] = "ALLOWED"
        except ControlError as exc:
            outcomes["peer_discovery_for_private_segments"] = f"{exc.status} {exc.code}"
        check(
            all(v.startswith(("403", "404")) for v in outcomes.values()), f"private asset leaked: {outcomes}"
        )
        mallory_list = {x["asset_id"] for x in (await mallory.call("GET", "/v1/assets"))["assets"]}
        check(priv_id not in mallory_list, "private asset must not be listed to others")
        bob_play = await c.play(self.token("bob"), priv_id)  # bob holds an explicit view grant
        check(
            delivery(bob_play)["completed"], "the authorised viewer of the private asset must be able to play"
        )
        self.step(9, "Unauthorised private-asset discovery rejected", {
            "unauthorised_principal": "mallory (no grant on the private asset)", **outcomes,
            "private_asset_in_mallory_listing": False,
            "authorised_viewer_bob_playback_completed": True,
        })  # fmt: skip

        # ---- 10. pause and resume of an offline download -------------------------------
        offline = OfflineDownloader(
            ControlClient(self.api_url), root=self.work / "offline", throttle_bytes_per_second=600_000
        )
        denied = None
        try:
            await self.api("cy").call("POST", "/v1/offline-downloads", json={"asset_id": pub_id})
        except ControlError as exc:
            denied = f"{exc.status} {exc.code}"
        check(denied == "403 offline_not_permitted", "viewers without the offline grant must be refused")
        info = await offline.start(self.token("ben"), pub_id, subtitle_languages=["en"])
        download_id = info["download_id"]
        task = asyncio.ensure_future(offline.run(download_id))
        await asyncio.sleep(1.2)
        await offline.pause(download_id)
        paused = await task
        check(
            paused.status == "paused" and 0 < paused.items_done < paused.items_total,
            f"pause failed: {paused}",
        )
        probe = VersionManifest.model_validate_json(
            _jws_payload((offline.directory(download_id) / "manifest.jws").read_text())
        )
        last_seg = probe.rendition(info["rendition_id"]).segments[-1].segment_id
        async with httpx.AsyncClient() as http:
            refused = await http.get(
                f"{self.origin_url}/origin/v1/segments/{last_seg}",
                headers={"Authorization": f"Bearer {info['origin']['token']}"},
            )
        check(refused.status_code == 409, "the origin must refuse a paused download")
        files_while_paused = len(list((offline.directory(download_id) / "media").glob("*.m*")))
        await offline.resume(download_id)
        final = await offline.run(download_id)
        check(final.status == "completed", f"offline download did not complete: {final}")
        check(final.reused_items == paused.items_done, "resume must keep what was already verified")
        server_view = await self.api("ben").call("GET", f"/v1/offline-downloads/{download_id}")
        check(server_view["state"] == "completed" and server_view["verified_complete"], "server must agree")
        decoded = _decode_with_ffmpeg(offline.directory(download_id) / "master.m3u8")
        check(decoded["video_frames"] > 0, "the offline copy must decode")
        self.step(10, "Pause and resume of an offline download", {
            "offline_without_grant": denied, "download_id": download_id,
            "items_total": final.items_total, "bytes_total": final.bytes_total,
            "items_done_when_paused": paused.items_done, "media_files_on_disk_while_paused": files_while_paused,
            "origin_status_for_paused_download": refused.status_code,
            "items_reused_after_resume": final.reused_items, "items_fetched_after_resume": final.fetched_items,
            "verified_complete": True,
            "actual_decode_check": {"tool": "FFmpeg (decodes the offline HLS copy to null output)", **decoded},
            "limits": "plaintext copy: deleting or expiring it server-side cannot revoke downloaded bytes",
        })  # fmt: skip
        await offline.delete(download_id)
        check(not offline.directory(download_id).exists(), "explicit deletion must remove local files")

        # ---- 12. cleanup after session expiry ----------------------------------------
        before_b = await b.stats()
        check(
            len(before_b["sessions"]) >= 1 and before_b["cache"]["segments"] > 0, "agent-b should be seeding"
        )
        public_ids = [s.segment_id for s in probe.rendition(info["rendition_id"]).segments[:5]]
        probe_session = await self.api("dana").call("POST", "/v1/playback-sessions", json={
            "asset_id": pub_id, "client_capabilities": {"supported_codecs": ["avc1"], "peer_delivery": True},
        })  # fmt: skip
        dana = ControlClient(self.api_url)
        probe_peer = await dana.request("POST", "/v1/peer-sessions", token=probe_session["session_token"], json={
            "playback_session_id": probe_session["session_id"], "endpoint": {"host": "127.0.0.1", "port": 9},
            "transport": "loopback-http",
        })  # fmt: skip

        async def discover() -> int:
            await dana.request(
                "POST",
                f"/v1/playback-sessions/{probe_session['session_id']}/heartbeat",
                token=probe_session["session_token"],
            )
            await dana.request(
                "POST",
                f"/v1/peer-sessions/{probe_peer['peer_session_id']}/heartbeat",
                token=probe_peer["peer_token"],
            )
            found = await dana.request("POST", "/v1/peer-discovery", token=probe_peer["peer_token"], json={
                "peer_session_id": probe_peer["peer_session_id"], "segment_ids": public_ids,
            })  # fmt: skip
            return len(found["peers"])

        peers_before = await discover()
        check(peers_before >= 1, "agent-b should be discoverable before expiry")
        await b.call("POST", "/admin/v1/faults", {"suspend_heartbeats": True})  # the viewer's app freezes
        waited = 0.0
        peers_after = peers_before
        while waited < 30 and peers_after > 0:
            await asyncio.sleep(1.0)
            waited += 1.0
            peers_after = await discover()
        check(peers_after == 0, "an expired session must disappear from discovery")
        await b.call("POST", "/admin/v1/faults", {"suspend_heartbeats": False})
        after_b = before_b
        for _ in range(40):
            await asyncio.sleep(0.5)
            after_b = await b.stats()
            if not after_b["sessions"] and after_b["cache"]["segments"] == 0:
                break
        check(
            not after_b["sessions"] and after_b["cache"]["segments"] == 0, "agent-b must purge after expiry"
        )
        await dana.close()
        self.step(12, "Cleanup after session expiry", {
            "session_ttl_seconds": 8, "peer_session_ttl_seconds": 6,
            "agent_b_before": {"sessions": len(before_b["sessions"]), "cached_segments": before_b["cache"]["segments"],
                               "cached_bytes": before_b["cache"]["bytes"]},
            "discoverable_peers_before": peers_before,
            "seconds_until_removed_from_discovery": waited,
            "discoverable_peers_after": peers_after,
            "agent_b_after": {"sessions": len(after_b["sessions"]), "cached_segments": after_b["cache"]["segments"],
                              "cached_bytes": after_b["cache"]["bytes"]},
        })  # fmt: skip

        # ---- wrap up: server metrics and resource use ---------------------------------
        async with httpx.AsyncClient() as http:
            api_metrics = (await http.get(self.api_url + "/metrics")).text
            origin_metrics = (await http.get(self.origin_url + "/metrics")).text
        await owner.control.close()
        await mallory.control.close()
        return {
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "stack": self.stack,
            "scope": "single machine, loopback network, one 20-second synthetic clip; "
            "not a production-scale performance measurement",
            "environment": {
                "python": platform.python_version(),
                "platform": platform.platform(),
                "cpu_count": os.cpu_count(),
                "ffmpeg": _ffmpeg_version(),
                "database": self.env["AUREOM_DATABASE_URL"].split("://")[0],
                "storage": self.env.get("AUREOM_STORAGE_BACKEND", "local"),
                "coordination": "redis" if self.env.get("AUREOM_REDIS_URL") else "in-process",
                "peer_transport": "loopback-http (plain HTTP on 127.0.0.1; test transport, not secure P2P)",
            },
            "total_wall_seconds": round(time.time() - started, 1),
            "steps": self.results,
            "server_counters": {
                "origin_bytes_served": _metric_sum(origin_metrics, "aureom_origin_bytes_total"),
                "transfer_grants": _metric_by_label(api_metrics, "aureom_transfer_grants_total", "outcome"),
                "transfer_receipts": _metric_by_label(
                    api_metrics, "aureom_transfer_receipts_total", "outcome"
                ),
                "access_denials": _metric_by_label(api_metrics, "aureom_access_denials_total", "reason"),
                "peer_discovery_requests": _metric_sum(api_metrics, "aureom_peer_discovery_seconds_count"),
                "peer_discovery_server_seconds_mean": _metric_mean(
                    api_metrics, "aureom_peer_discovery_seconds"
                ),
            },
            "resource_consumption": {
                name: proc_usage(proc.pid) for name, proc in self.procs.items() if proc.poll() is None
            },
        }


def _jws_payload(jws: str) -> str:
    """Decode a JWS payload for *display* in the demo (verification happens in the
    agents and the offline downloader, not here)."""
    import base64

    part = jws.split(".")[1]
    return base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)).decode()


def _ffmpeg_version() -> str:
    try:
        out = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, check=True).stdout  # noqa: S603, S607
        return out.splitlines()[0]
    except (OSError, subprocess.CalledProcessError):
        return "unavailable"


def _decode_with_ffmpeg(master: Path) -> dict[str, Any]:
    """Actually decode the downloaded HLS with FFmpeg and count the decoded frames."""
    probe = subprocess.run(  # noqa: S603
        ["ffprobe", "-v", "error", "-allowed_extensions", "ALL", "-count_frames", "-select_streams", "v:0",  # noqa: S607
         "-show_entries", "stream=nb_read_frames,codec_name,width,height", "-of", "json", str(master)],
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    decode = subprocess.run(  # noqa: S603
        ["ffmpeg", "-nostdin", "-v", "error", "-allowed_extensions", "ALL", "-i", str(master), "-f", "null", "-"],  # noqa: S607
        capture_output=True, text=True, check=False,
    )  # fmt: skip
    stream = (json.loads(probe.stdout or "{}").get("streams") or [{}])[0]
    return {
        "video_frames": int(stream.get("nb_read_frames") or 0),
        "codec": stream.get("codec_name"),
        "resolution": f"{stream.get('width')}x{stream.get('height')}",
        "decode_errors": decode.stderr.strip()[:200],
        "decode_exit_code": decode.returncode,
    }


def _metric_lines(text: str, name: str) -> list[tuple[str, float]]:
    out = []
    for line in text.splitlines():
        if line.startswith(name) and not line.startswith("#"):
            key, _, value = line.rpartition(" ")
            if key == name or key.startswith(name + "{"):
                with contextlib.suppress(ValueError):
                    out.append((key, float(value)))
    return out


def _metric_sum(text: str, name: str) -> float:
    return sum(v for _, v in _metric_lines(text, name))


def _metric_by_label(text: str, name: str, label: str) -> dict[str, float]:
    out: dict[str, float] = {}
    for key, value in _metric_lines(text, name):
        marker = f'{label}="'
        if marker in key:
            tag = key.split(marker, 1)[1].split('"', 1)[0]
            out[tag] = out.get(tag, 0.0) + value
    return out


def _metric_mean(text: str, name: str) -> float | None:
    count = _metric_sum(text, name + "_count")
    return round(_metric_sum(text, name + "_sum") / count, 5) if count else None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path, default=Path("var/demo"))
    parser.add_argument("--stack", choices=["local", "services"], default="local")
    parser.add_argument("--report", type=Path, default=None)
    args = parser.parse_args()
    demo = Demo(args.work_dir, args.stack)

    async def run() -> dict[str, Any]:
        try:
            return await demo.run()
        finally:
            await demo.stop()

    try:
        report = asyncio.run(run())
    except DemoFailure as exc:
        print(f"\nDEMO FAILED: {exc}\nlogs: {demo.work}", file=sys.stderr)
        raise SystemExit(1) from exc
    out = args.report or demo.work / "demo-report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n")
    print(f"\nall {len(report['steps'])} demonstration steps passed in {report['total_wall_seconds']} s")
    print(f"report: {out}")


if __name__ == "__main__":
    main()
