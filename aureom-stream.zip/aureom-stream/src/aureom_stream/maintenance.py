"""Periodic clean-up of expired, short-lived state.

Run by the worker loop and by ``aureom-stream maintenance sweep``. Everything here is
idempotent and bounded per run.
"""

from __future__ import annotations

from datetime import timedelta

from sqlalchemy import delete, select, update

from .bootstrap import AppContext
from .clock import to_datetime
from .persistence.models import (
    DownloadState,
    OfflineDownload,
    PeerAvailability,
    PeerSession,
    PeerState,
    PlaybackSession,
    SessionState,
    TransferGrant,
    TransferReceipt,
)
from .uploads.service import UploadService

RECEIPT_RETENTION = timedelta(days=7)


async def sweep(ctx: AppContext) -> dict[str, int]:
    now = to_datetime(ctx.clock.now())
    counts: dict[str, int] = {}
    async with ctx.db.session() as db:
        counts["uploads_expired"] = await UploadService(ctx, db).expire_abandoned()

        expired_sessions = list(
            await db.scalars(
                select(PlaybackSession.id).where(
                    PlaybackSession.state == SessionState.ACTIVE.value,
                    PlaybackSession.expires_at <= now,
                )
            )
        )
        if expired_sessions:
            await db.execute(
                update(PlaybackSession)
                .where(PlaybackSession.id.in_(expired_sessions))
                .values(state=SessionState.EXPIRED.value, ended_at=now)
            )
        counts["playback_sessions_expired"] = len(expired_sessions)

        # A peer session ends with its own heartbeat TTL *or* with its playback session:
        # nobody keeps seeding for a viewer who has gone.
        dead_peers = set(
            await db.scalars(
                select(PeerSession.id).where(
                    PeerSession.state == PeerState.ACTIVE.value, PeerSession.expires_at <= now
                )
            )
        )
        dead_peers |= set(
            await db.scalars(
                select(PeerSession.id)
                .join(PlaybackSession, PlaybackSession.id == PeerSession.playback_session_id)
                .where(
                    PeerSession.state == PeerState.ACTIVE.value,
                    PlaybackSession.state != SessionState.ACTIVE.value,
                )
            )
        )
        if dead_peers:
            await db.execute(
                update(PeerSession)
                .where(PeerSession.id.in_(dead_peers))
                .values(state=PeerState.EXPIRED.value, closed_at=now)
            )
            await db.execute(delete(PeerAvailability).where(PeerAvailability.peer_session_id.in_(dead_peers)))
        counts["peer_sessions_expired"] = len(dead_peers)

        # Data minimisation: once a peer session is over, its network address and
        # certificate thumbprint are no longer needed and are erased.
        await db.execute(
            update(PeerSession)
            .where(PeerSession.state != PeerState.ACTIVE.value, PeerSession.endpoint_host != "")
            .values(endpoint_host="", endpoint_port=0, cert_thumbprint=None)
        )

        result = await db.execute(
            update(OfflineDownload)
            .where(
                OfflineDownload.state.in_([DownloadState.ACTIVE.value, DownloadState.PAUSED.value]),
                OfflineDownload.expires_at <= now,
            )
            .values(state=DownloadState.EXPIRED.value, updated_at=now)
        )
        counts["offline_downloads_expired"] = result.rowcount or 0  # type: ignore[attr-defined]

        cutoff = now - RECEIPT_RETENTION
        await db.execute(delete(TransferReceipt).where(TransferReceipt.created_at < cutoff))
        await db.execute(delete(TransferGrant).where(TransferGrant.expires_at < cutoff))
    return counts
