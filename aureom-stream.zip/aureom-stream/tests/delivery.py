"""Builders for delivery-layer tests: a signed-manifest-shaped timeline with payloads."""

from __future__ import annotations

import hashlib
import os

from aureom_stream.manifests.version_manifest import VersionManifest

VERSION = "ver_" + "a" * 26


def make_manifest(
    *, segments: int = 8, seconds: float = 2.0, size: int = 20_000, renditions: int = 1
) -> tuple[VersionManifest, dict[str, bytes]]:
    data: dict[str, bytes] = {}
    out = []
    for r in range(renditions):
        rid = f"rnd_{r}"
        payload_size = max(1000, size // (r + 1))

        def seg(kind: str, seq: int, nbytes: int, rid: str = rid) -> dict:
            body = os.urandom(nbytes)
            sid = f"{rid}_{kind}_{seq}"
            data[sid] = body
            return {
                "segment_id": sid, "kind": kind, "sequence_number": seq,
                "start_time": 0.0 if kind == "init" else seq * seconds,
                "duration": 0.0 if kind == "init" else seconds,
                "byte_length": nbytes, "sha256": hashlib.sha256(body).hexdigest(),
            }  # fmt: skip

        bandwidth = int(payload_size * 8 / seconds)
        out.append(
            {
                "rendition_id": rid, "name": f"r{r}", "width": 640 // (r + 1), "height": 360 // (r + 1),
                "codecs": "avc1.4d401e,mp4a.40.2", "bandwidth": bandwidth,
                "average_bandwidth": bandwidth, "frame_rate": 24.0,
                "init": seg("init", 0, 700),
                "segments": [seg("media", i, payload_size) for i in range(segments)],
            }
        )  # fmt: skip
    manifest = VersionManifest.model_validate(
        {
            "schema_version": 1, "asset_id": "ast_x", "asset_version_id": VERSION,
            "version_number": 1, "duration_seconds": segments * seconds,
            "segment_duration_seconds": seconds, "hash_algorithm": "sha256", "encryption": None,
            "sealed_at": 0.0, "renditions": out, "subtitles": [],
        }
    )  # fmt: skip
    return manifest, data
