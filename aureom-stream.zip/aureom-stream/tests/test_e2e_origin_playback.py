"""Milestone 1: upload -> validate -> transcode -> package -> publish -> authorised
origin playback, with real FFmpeg and real HLS/fMP4 output."""

from __future__ import annotations

import hashlib
from pathlib import Path

import httpx
import pytest

from aureom_stream.bootstrap import AppContext
from aureom_stream.manifests.version_manifest import verify_manifest
from aureom_stream.processing.worker import Worker

from .helpers import bearer, start_session, upload_bytes

pytestmark = pytest.mark.ffmpeg


async def test_upload_to_origin_playback(
    ctx: AppContext, client: httpx.AsyncClient, origin: httpx.AsyncClient, auth, sample_video: Path
) -> None:
    alice = auth("alice")
    upload = await upload_bytes(client, alice, sample_video.read_bytes(), filename="survey.mp4")
    assert upload["state"] == "completed" and upload["detected_container"] == "mp4"

    created = await client.post(
        "/v1/assets",
        headers=alice,
        json={
            "upload_id": upload["upload_id"],
            "title": "Survey documentary",
            "language": "en",
            "rights_declaration": {"basis": "owner", "statement": "Generated test pattern."},
        },
    )
    assert created.status_code == 201, created.text
    asset = created.json()
    version = asset["versions"][0]
    assert asset["visibility"] == "private" and version["state"] == "uploaded"

    # Publishing before processing finished is refused.
    early = await client.post(
        f"/v1/assets/{asset['asset_id']}/versions/{version['version_id']}/publish", headers=alice
    )
    assert early.status_code == 409 and early.json()["code"] == "processing_not_complete"

    result = await Worker(ctx).run_once()
    assert result is not None and result.status == "succeeded", result
    assert len(result.renditions) == 2

    versions = (await client.get(f"/v1/assets/{asset['asset_id']}/versions", headers=alice)).json()
    assert versions[0]["state"] == "ready_for_review"
    heights = [r["height"] for r in versions[0]["renditions"]]
    assert max(heights) == 180, "no upscaling beyond the 180p source"
    assert len({r["segment_count"] for r in versions[0]["renditions"]}) == 1, "aligned segments"

    # Subtitles can be attached during review.
    vtt = b"WEBVTT\n\n00:00:00.000 --> 00:00:02.000\nHello\n"
    sub = await client.put(
        f"/v1/assets/{asset['asset_id']}/versions/{version['version_id']}/subtitles/en",
        headers=alice, content=vtt,
    )  # fmt: skip
    assert sub.status_code == 200, sub.text

    published = await client.post(
        f"/v1/assets/{asset['asset_id']}/versions/{version['version_id']}/publish", headers=alice
    )
    assert published.status_code == 200, published.text
    assert published.json()["visibility"] == "private"

    session = await start_session(client, alice, asset["asset_id"])
    assert session["delivery_modes"] == ["origin"]
    token = bearer(session["session_token"])

    master = await client.get(session["master_playlist_url"], headers=token)
    assert master.status_code == 200
    assert master.headers["content-type"].startswith("application/vnd.apple.mpegurl")
    assert master.headers["cache-control"] == "private, no-store"
    assert "#EXT-X-STREAM-INF" in master.text and 'CODECS="avc1.' in master.text
    assert "TYPE=SUBTITLES" in master.text

    manifest_jws = (await client.get(session["signed_manifest_url"], headers=token)).text
    manifest = verify_manifest(ctx.tokens, manifest_jws, expected_version_id=session["version_id"])

    for rendition in session["renditions"]:
        playlist = await client.get(rendition["playlist_url"], headers=token)
        assert playlist.status_code == 200
        assert "#EXT-X-MAP:URI=" in playlist.text and "#EXT-X-VERSION:7" in playlist.text
        descriptors = [
            manifest.init_segment(rendition["rendition_id"]),
            *manifest.media_segments(rendition["rendition_id"]),
        ]
        assert descriptors[0].kind == "init" and len(descriptors) == 4  # init + 3 x 2 s
        for seg in descriptors:
            # Through the playback session ...
            via_api = await client.get(
                f"/v1/playback-sessions/{session['session_id']}/segments/{seg.segment_id}", headers=token
            )
            assert via_api.status_code == 200
            assert hashlib.sha256(via_api.content).hexdigest() == seg.content_hash
            # ... and straight from the origin with the short-lived origin token.
            via_origin = await origin.get(
                f"/origin/v1/segments/{seg.segment_id}", headers=bearer(session["origin"]["token"])
            )
            assert via_origin.status_code == 200
            assert via_origin.content == via_api.content
        assert descriptors[0].content_hash != descriptors[1].content_hash
        init = await client.get(
            f"/v1/playback-sessions/{session['session_id']}/segments/{descriptors[0].segment_id}",
            headers=token,
        )
        assert init.headers["content-type"] == "video/mp4"
        assert init.content[4:8] == b"ftyp"

    # Session ends -> its tokens stop working everywhere we control.
    assert (
        await client.delete(f"/v1/playback-sessions/{session['session_id']}", headers=token)
    ).status_code == 204
    gone = await client.get(session["master_playlist_url"], headers=token)
    assert gone.status_code == 410
    seg0 = manifest.renditions[0].init.segment_id
    denied = await origin.get(f"/origin/v1/segments/{seg0}", headers=bearer(session["origin"]["token"]))
    assert denied.status_code == 403
