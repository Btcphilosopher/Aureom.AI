"""Offline downloads: separate permission, limits, pause/resume, interruption, completion."""

from __future__ import annotations

import hashlib
from pathlib import Path

import httpx
import pytest

from aureom_stream.api.app import create_app
from aureom_stream.bootstrap import AppContext
from aureom_stream.clock import FakeClock
from aureom_stream.domain import DistributionPolicy
from aureom_stream.manifests.version_manifest import verify_manifest
from aureom_stream.offline.downloader import LocalStorageLimit, OfflineDownloader
from aureom_stream.origin.app import create_origin_app
from aureom_stream.peer_agent.control import ControlClient
from aureom_stream.persistence.models import AssetVersion

from .helpers import Seeded, bearer, seed_asset

OFFLINE = DistributionPolicy(offline_download="granted")
VTT = b"WEBVTT\n\n00:00:00.000 --> 00:00:02.000\nHello\n"


async def offline_asset(ctx: AppContext, client: httpx.AsyncClient, auth, **kw) -> Seeded:
    asset = await seed_asset(
        ctx, owner="alice", visibility="private", distribution=OFFLINE, publish=False, **kw
    )
    for lang in ("en", "fr"):
        resp = await client.put(
            f"/v1/assets/{asset.asset_id}/versions/{asset.version_id}/subtitles/{lang}",
            headers=auth("alice"), content=VTT + lang.encode(),
        )  # fmt: skip
        assert resp.status_code == 200, resp.text
    pub = await client.post(
        f"/v1/assets/{asset.asset_id}/versions/{asset.version_id}/publish", headers=auth("alice")
    )
    assert pub.status_code == 200, pub.text
    async with ctx.db.session() as db:
        version = await db.get(AssetVersion, asset.version_id)
        assert version is not None and version.manifest_jws
        asset.manifest = verify_manifest(ctx.tokens, version.manifest_jws, expected_version_id=version.id)
    for user, permission in (("bob", "view"), ("bob", "offline_download"), ("carol", "view")):
        await client.post(
            f"/v1/assets/{asset.asset_id}/grants", headers=auth("alice"),
            json={"principal_id": user, "permission": permission},
        )  # fmt: skip
    return asset


def downloader(ctx: AppContext, root: Path, **kw) -> OfflineDownloader:
    control = ControlClient(
        "http://api.test", client=httpx.AsyncClient(transport=httpx.ASGITransport(app=create_app(ctx=ctx)))
    )
    return OfflineDownloader(
        control, root=root, clock=ctx.clock, issuer=ctx.settings.issuer,
        origin_http=httpx.AsyncClient(transport=httpx.ASGITransport(app=create_origin_app(ctx=ctx))), **kw,
    )  # fmt: skip


def token(ctx: AppContext, user: str) -> str:
    return ctx.tokens.mint_principal_token(user, [], ttl=3600)


async def test_offline_permission_is_separate_from_viewing(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await offline_asset(ctx, client, auth)
    body = {"asset_id": asset.asset_id}
    # Carol may stream ...
    assert (await client.post("/v1/playback-sessions", headers=auth("carol"), json=body)).status_code == 201
    # ... but not download.
    denied = await client.post("/v1/offline-downloads", headers=auth("carol"), json=body)
    assert denied.status_code == 403 and denied.json()["code"] == "offline_not_permitted"
    assert (await client.post("/v1/offline-downloads", headers=auth("mallory"), json=body)).status_code == 404
    assert (await client.post("/v1/offline-downloads", json=body)).status_code == 401
    ok = await client.post("/v1/offline-downloads", headers=auth("bob"), json=body)
    assert ok.status_code == 201
    info = ok.json()
    assert info["state"] == "active" and info["download_token"] and info["origin"]["token"]
    assert any("cannot revoke" in n for n in info["notices"])
    # Policy "none": nobody downloads, not even with a grant.
    closed = await seed_asset(ctx, owner="alice", visibility="public")
    no = await client.post("/v1/offline-downloads", headers=auth("bob"), json={"asset_id": closed.asset_id})
    assert no.status_code == 403


async def test_rendition_and_subtitle_selection(ctx: AppContext, client: httpx.AsyncClient, auth) -> None:
    asset = await offline_asset(ctx, client, auth)
    bob = auth("bob")
    low = asset.manifest.renditions[-1]
    chosen = (
        await client.post(
            "/v1/offline-downloads", headers=bob,
            json={"asset_id": asset.asset_id, "max_height": 240, "subtitle_languages": ["fr"]},
        )
    ).json()  # fmt: skip
    assert chosen["rendition_id"] == low.rendition_id and chosen["subtitle_languages"] == ["fr"]
    assert chosen["total_items"] == 1 + len(low.segments) + 1  # init + media + one subtitle
    expected = low.init.byte_length + sum(s.byte_length for s in low.segments) + len(VTT) + 2
    assert chosen["total_bytes"] == expected
    explicit = await client.post(
        "/v1/offline-downloads", headers=bob,
        json={"asset_id": asset.asset_id, "rendition_id": asset.manifest.renditions[0].rendition_id},
    )  # fmt: skip
    assert explicit.json()["rendition_id"] == asset.manifest.renditions[0].rendition_id
    unknown_sub = await client.post(
        "/v1/offline-downloads", headers=bob, json={"asset_id": asset.asset_id, "subtitle_languages": ["de"]}
    )
    assert unknown_sub.status_code == 422 and unknown_sub.json()["code"] == "unknown_subtitle"
    unknown_rendition = await client.post(
        "/v1/offline-downloads", headers=bob,
        json={"asset_id": asset.asset_id, "rendition_id": "rnd_" + "a" * 26},
    )  # fmt: skip
    assert unknown_rendition.status_code == 422


async def test_storage_limits_server_and_client(
    ctx: AppContext, client: httpx.AsyncClient, auth, tmp_path: Path
) -> None:
    asset = await offline_asset(ctx, client, auth, segment_bytes=4000)
    bob = auth("bob")
    first = (
        await client.post("/v1/offline-downloads", headers=bob, json={"asset_id": asset.asset_id})
    ).json()
    ctx.settings.offline_quota_bytes = first["total_bytes"] + 100
    over = await client.post("/v1/offline-downloads", headers=bob, json={"asset_id": asset.asset_id})
    assert over.status_code == 413 and over.json()["code"] == "offline_storage_limit_exceeded"
    assert over.json()["used_bytes"] == first["total_bytes"]
    # Deleting frees the allowance.
    gone = await client.delete(f"/v1/offline-downloads/{first['download_id']}", headers=bob)
    assert gone.status_code == 204
    assert (
        await client.post("/v1/offline-downloads", headers=bob, json={"asset_id": asset.asset_id})
    ).status_code == 201
    ctx.settings.offline_quota_bytes = 10**9
    tiny = downloader(ctx, tmp_path / "tiny", max_store_bytes=1000)
    with pytest.raises(LocalStorageLimit):
        await tiny.start(token(ctx, "bob"), asset.asset_id)


async def test_download_pause_resume_interrupt_and_verified_completion(
    ctx: AppContext, client: httpx.AsyncClient, origin: httpx.AsyncClient, auth, tmp_path: Path
) -> None:
    asset = await offline_asset(ctx, client, auth, segments=8)
    dl = downloader(ctx, tmp_path / "offline")
    info = await dl.start(token(ctx, "bob"), asset.asset_id, subtitle_languages=["en"])
    download_id = info["download_id"]
    rendition = asset.manifest.rendition(info["rendition_id"])
    assert info["total_items"] == 10  # init + 8 media + 1 subtitle

    # Interrupted after three items (e.g. the process was killed).
    part = await ctx.clock.run(dl.run(download_id, stop_after_items=3))
    assert part.status == "interrupted" and part.items_done == 3 and part.fetched_items == 3

    # Pause is enforced by the server: the origin refuses a paused download.
    paused = await dl.pause(download_id)
    assert paused["state"] == "paused" and paused["origin"] is None
    seg = rendition.segments[5].segment_id
    refused = await origin.get(f"/origin/v1/segments/{seg}", headers=bearer(info["origin"]["token"]))
    assert refused.status_code == 409 and refused.json()["code"] == "download_paused"
    while_paused = await ctx.clock.run(dl.run(download_id))
    assert while_paused.status == "paused" and while_paused.fetched_items == 0
    media = dl.directory(download_id) / "media"
    assert len(list(media.glob("*"))) == 3

    # Damage one stored file while paused: resume must notice and fetch it again.
    victim = media / "seg_00000.m4s"
    victim.write_bytes(b"corrupted on disk")

    resumed = await dl.resume(download_id)
    assert resumed["state"] == "active"
    final = await ctx.clock.run(dl.run(download_id))
    assert final.status == "completed", final
    assert final.items_done == 10 and final.reused_items == 2 and final.fetched_items == 8
    assert final.bytes_done == info["total_bytes"]

    # Every file matches the signed manifest.
    assert hashlib.sha256((media / "init.mp4").read_bytes()).hexdigest() == rendition.init.sha256
    for seg_entry in rendition.segments:
        path = media / f"seg_{seg_entry.sequence_number:05d}.m4s"
        assert hashlib.sha256(path.read_bytes()).hexdigest() == seg_entry.sha256
    assert (dl.directory(download_id) / "subs" / "en.vtt").read_bytes() == VTT + b"en"
    playlist = (media / "index.m3u8").read_text()
    assert '#EXT-X-MAP:URI="init.mp4"' in playlist and playlist.count("#EXTINF") == 8
    assert "media/index.m3u8" in (dl.directory(download_id) / "master.m3u8").read_text()

    status = (await client.get(f"/v1/offline-downloads/{download_id}", headers=auth("bob"))).json()
    assert status["state"] == "completed" and status["verified_complete"] is True
    assert status["reported_items"] == 10 and status["origin"] is None
    again = await ctx.clock.run(dl.run(download_id))  # idempotent: nothing to fetch
    assert again.status == "completed" and again.fetched_items == 0

    # Explicit deletion removes local files and ends the server record.
    await dl.delete(download_id)
    assert not dl.directory(download_id).exists()
    after = await client.get(f"/v1/offline-downloads/{download_id}", headers=auth("bob"))
    assert after.json()["state"] == "deleted"
    late = await origin.get(f"/origin/v1/segments/{seg}", headers=bearer(info["origin"]["token"]))
    assert late.status_code in (401, 403)


async def test_completion_requires_the_manifest_digest(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await offline_asset(ctx, client, auth)
    bob = auth("bob")
    info = (await client.post("/v1/offline-downloads", headers=bob, json={"asset_id": asset.asset_id})).json()
    url = f"/v1/offline-downloads/{info['download_id']}/progress"
    token_headers = bearer(info["download_token"])
    partial = await client.post(
        url, headers=token_headers, json={"items_completed": 2, "bytes_completed": 100}
    )
    assert partial.status_code == 200 and partial.json()["state"] == "active"
    fake = await client.post(
        url, headers=token_headers,
        json={"items_completed": info["total_items"], "bytes_completed": info["total_bytes"],
              "completion_digest": "0" * 64},
    )  # fmt: skip
    assert fake.status_code == 409 and fake.json()["code"] == "completion_mismatch"
    too_much = await client.post(
        url, headers=token_headers, json={"items_completed": 999, "bytes_completed": 1}
    )
    assert too_much.status_code == 422
    digest = asset.manifest.offline_digest(info["rendition_id"], [])
    real = await client.post(
        url, headers=token_headers,
        json={"items_completed": info["total_items"], "bytes_completed": info["total_bytes"],
              "completion_digest": digest},
    )  # fmt: skip
    assert real.status_code == 200 and real.json()["verified_complete"] is True
    assert (
        await client.get(f"/v1/offline-downloads/{info['download_id']}", headers=auth("mallory"))
    ).status_code == 404


async def test_withdrawal_and_expiry_stop_downloads(
    ctx: AppContext, client: httpx.AsyncClient, auth, tmp_path: Path, clock: FakeClock
) -> None:
    asset = await offline_asset(ctx, client, auth)
    dl = downloader(ctx, tmp_path / "offline")
    info = await dl.start(token(ctx, "bob"), asset.asset_id)
    await ctx.clock.run(dl.run(info["download_id"], stop_after_items=2))
    await client.post(
        f"/v1/assets/{asset.asset_id}/versions/{asset.version_id}/withdraw", headers=auth("alice")
    )
    stopped = await ctx.clock.run(dl.run(info["download_id"]))
    assert stopped.status == "revoked"
    resume = await client.post(
        f"/v1/offline-downloads/{info['download_id']}/resume", headers=bearer(info["download_token"])
    )
    assert resume.status_code == 410 and resume.json()["code"] == "withdrawn"
    # The two segments already on disk are still there: the server cannot erase them.
    assert len(list((dl.directory(info["download_id"]) / "media").glob("*"))) == 2

    other = await offline_asset(ctx, client, auth)
    second = (
        await client.post("/v1/offline-downloads", headers=auth("bob"), json={"asset_id": other.asset_id})
    ).json()
    clock.tick(ctx.settings.offline_download_ttl_seconds + 1)
    expired = await client.get(
        f"/v1/offline-downloads/{second['download_id']}", headers=bearer(second["download_token"])
    )
    assert expired.json()["state"] == "expired"
