"""Scheduler behaviour on a virtual clock with scripted peers and origin."""

from __future__ import annotations

import asyncio
import math

import pytest

from aureom_stream.clock import FakeClock
from aureom_stream.domain import VerifiedSegment
from aureom_stream.observability.metrics import DeliveryMetrics
from aureom_stream.playback.adapter import FixedRendition, ThroughputAbr
from aureom_stream.playback.harness import PlaybackScript, SimulatedPlayer
from aureom_stream.scheduler.scheduler import (
    ClientPlaybackSession,
    SchedulerLimits,
    SegmentScheduler,
    SegmentUnavailable,
    TransferCancelled,
    plan_window,
)
from aureom_stream.transports.fake import FakeDirectory, FakeOrigin, FakePeer, FakePeerTransport

from .delivery import VERSION, make_manifest


class Rig:
    def __init__(self, *, peers: list[FakePeer] | None = None, limits: SchedulerLimits | None = None, **mk):
        self.clock = FakeClock()
        self.manifest, self.data = make_manifest(**mk)
        self.rid = self.manifest.renditions[0].rendition_id
        self.timeline = self.manifest.media_segments(self.rid)
        self.init = self.manifest.init_segment(self.rid)
        self.origin = FakeOrigin(self.clock, self.data)
        self.transport = FakePeerTransport(self.clock, peers or [])
        self.directory = FakeDirectory(self.clock, self.transport)
        self.metrics = DeliveryMetrics()
        self.observations = []
        self.scheduler = SegmentScheduler(
            clock=self.clock,
            origin=self.origin,
            directory=self.directory,
            transports={"fake": self.transport},
            metrics=self.metrics,
            observer=self.observations.append,
        )
        self.session = ClientPlaybackSession(
            session_id="s1", asset_version_id=VERSION, peer_delivery=True,
            limits=limits or SchedulerLimits(),
        )  # fmt: skip

    def peer(self, peer_id: str = "p1", **kw) -> FakePeer:
        peer = FakePeer(peer_id, {s.segment_id: self.data[s.segment_id] for s in self.timeline}, **kw)
        self.transport.peers[peer_id] = peer
        return peer

    def fetch(self, index: int, *, in_seconds: float = 10.0):
        return self.scheduler.fetch(self.session, self.timeline[index], self.clock.now() + in_seconds)


async def test_origin_only_delivery_is_verified() -> None:
    rig = Rig()
    rig.session.peer_delivery = False
    seg = await rig.clock.run(rig.fetch(0))
    assert isinstance(seg, VerifiedSegment) and seg.source == "origin"
    assert seg.data == rig.data[rig.timeline[0].segment_id]
    assert rig.metrics.origin_segments == 1 and rig.metrics.peer_segments == 0
    assert rig.observations[0].source == "origin" and rig.observations[0].deadline_slack > 0


async def test_prefetch_segment_comes_from_peer_and_receipt_is_reported() -> None:
    rig = Rig()
    peer = rig.peer()
    seg = await rig.clock.run(rig.fetch(3, in_seconds=8))
    await rig.scheduler.drain()
    assert seg.source == "peer" and seg.source_id == "p1"
    assert rig.origin.calls == [] and peer.calls == [rig.timeline[3].segment_id]
    assert rig.metrics.peer_bytes == rig.timeline[3].byte_length
    assert [(r.role, r.outcome) for r in rig.directory.receipts] == [("receiver", "verified")]
    assert rig.metrics.discovery_latency and rig.metrics.transfer_latency_peer


async def test_init_and_near_playback_segments_go_to_origin_first() -> None:
    rig = Rig()
    peer = rig.peer()
    init = await rig.clock.run(rig.scheduler.fetch(rig.session, rig.init, rig.clock.now() + 30))
    urgent = await rig.clock.run(rig.fetch(0, in_seconds=1.0))  # inside the urgent window
    assert init.source == "origin" and urgent.source == "origin"
    assert peer.calls == []


async def test_corrupted_peer_segment_is_rejected_and_origin_used() -> None:
    rig = Rig()
    bad = rig.peer("bad", behaviour="corrupt")
    seg = await rig.clock.run(rig.fetch(4, in_seconds=8))
    await rig.scheduler.drain()
    assert seg.source == "origin", "corrupted bytes must never be returned"
    assert seg.data == rig.data[rig.timeline[4].segment_id]
    assert rig.metrics.verification_failures == 1
    assert rig.metrics.peer_failures == {"hash_mismatch": 1}
    assert rig.metrics.origin_fallbacks == 1
    assert rig.directory.receipts[0].outcome == "corrupt"
    # The peer is not asked again in this session.
    await rig.clock.run(rig.fetch(5, in_seconds=8))
    assert len(bad.calls) == 1


async def test_incorrect_content_length_is_rejected() -> None:
    rig = Rig()
    rig.peer("short", behaviour="truncate")
    seg = await rig.clock.run(rig.fetch(4, in_seconds=8))
    await rig.scheduler.drain()
    assert seg.source == "origin"
    assert rig.metrics.peer_failures == {"length_mismatch": 1}
    assert rig.directory.receipts[0].outcome == "length_mismatch"


async def test_second_peer_is_tried_within_retry_budget() -> None:
    rig = Rig()
    rig.peer("a-flaky", behaviour="refuse")
    good = rig.peer("b-good")
    seg = await rig.clock.run(rig.fetch(4, in_seconds=8))
    assert seg.source == "peer" and seg.source_id == "b-good"
    assert rig.metrics.retries == 1 and good.calls


async def test_misreported_availability_counts_as_failure() -> None:
    rig = Rig()
    rig.peer("liar", behaviour="not_found")
    seg = await rig.clock.run(rig.fetch(2, in_seconds=8))
    await rig.scheduler.drain()
    assert seg.source == "origin"
    assert rig.directory.receipts[0].outcome == "not_found"


async def test_slow_peer_is_hedged_with_origin_before_the_deadline() -> None:
    rig = Rig()
    slow = rig.peer("slow", bytes_per_second=2_000.0)  # 20 kB would take 10 s
    started = rig.clock.now()
    deadline = started + 3.5  # hedge fires at 2.5 s, long before the 4 s peer timeout
    seg = await rig.clock.run(rig.scheduler.fetch(rig.session, rig.timeline[3], deadline))
    assert seg.source == "origin"
    assert rig.clock.now() <= deadline, "origin fallback must land before the playback deadline"
    assert rig.metrics.hedged_requests == 1
    assert rig.metrics.peer_failures.get("timeout") == 1
    # The losing duplicate (the peer request) was cancelled, not left running.
    assert rig.metrics.cancelled_requests == 1
    assert rig.transport.cancelled == [("slow", rig.timeline[3].segment_id)]
    assert slow.calls == [rig.timeline[3].segment_id]


async def test_peer_wins_hedge_and_origin_duplicate_is_cancelled() -> None:
    rig = Rig()
    rig.origin.latency = 5.0  # origin is the slow one this time
    rig.scheduler.origin_stats.latency = 0.1
    rig.peer("steady", latency=2.5)
    deadline = rig.clock.now() + 3.5  # hedge fires at ~2.5 s; peer answers just after
    seg = await rig.clock.run(rig.scheduler.fetch(rig.session, rig.timeline[3], deadline))
    assert seg.source == "peer"
    assert rig.metrics.hedged_requests == 1
    assert rig.origin.cancelled == [rig.timeline[3].segment_id]


async def test_repeated_timeouts_put_peer_in_cooldown() -> None:
    rig = Rig(limits=SchedulerLimits(peer_attempt_timeout=1.0))
    hung = rig.peer("hung", behaviour="hang")
    await rig.clock.run(rig.fetch(3, in_seconds=20))
    await rig.clock.run(rig.fetch(4, in_seconds=20))  # still cooling down -> origin directly
    assert len(hung.calls) == 1
    assert rig.metrics.peer_failures == {"timeout": 1}
    await rig.clock.advance(120)
    await rig.clock.run(rig.fetch(5, in_seconds=20))  # cooldown over: tried once more
    assert len(hung.calls) == 2


async def test_disconnected_peer_falls_back_to_origin() -> None:
    rig = Rig()
    peer = rig.peer()
    first = await rig.clock.run(rig.fetch(2, in_seconds=8))
    peer.behaviour = "offline"  # the peer vanishes
    second = await rig.clock.run(rig.fetch(3, in_seconds=8))
    assert (first.source, second.source) == ("peer", "origin")
    assert rig.metrics.peer_failures == {"unreachable": 1}
    assert rig.metrics.origin_fallbacks == 1


async def test_peers_used_when_origin_is_down_and_no_guarantee_when_both_fail() -> None:
    rig = Rig()
    rig.peer()
    rig.origin.online = False
    seg = await rig.clock.run(rig.fetch(0, in_seconds=1.0))  # urgent, but origin unhealthy
    assert seg.source == "peer"
    rig.transport.peers["p1"].behaviour = "offline"
    with pytest.raises(SegmentUnavailable):
        await rig.clock.run(rig.fetch(1, in_seconds=1.0))
    assert rig.metrics.unavailable == 1


async def test_imminent_segment_is_dispatched_before_queued_prefetch() -> None:
    """Deadline order, not rarity: with one transfer slot busy, an urgent request that
    arrives last still starts before prefetch requests that were queued earlier."""
    limits = SchedulerLimits(max_concurrent_transfers=1, reserved_urgent_slots=0)
    rig = Rig(limits=limits)
    rig.session.peer_delivery = False

    async def scenario() -> list[int]:
        order: list[int] = []

        async def get(index: int, in_seconds: float) -> None:
            await rig.fetch(index, in_seconds=in_seconds)
            order.append(index)

        far = [asyncio.ensure_future(get(i, 30 + i)) for i in (7, 6, 5)]  # "rare", far away
        await asyncio.sleep(0)
        near = asyncio.ensure_future(get(1, 1.0))  # needed in one second
        await asyncio.gather(near, *far)
        return order

    order = await rig.clock.run(scenario())
    assert order[0] == 7, "the transfer already running is not pre-empted"
    assert order[1] == 1, "the imminent segment jumps the prefetch queue"
    assert order[2:] == [5, 6], "remaining prefetch runs nearest-deadline first"


async def test_urgent_slot_is_reserved() -> None:
    limits = SchedulerLimits(max_concurrent_transfers=2, reserved_urgent_slots=1)
    rig = Rig(limits=limits)
    rig.session.peer_delivery = False
    rig.origin.latency = 1.0

    async def scenario() -> float:
        far = [asyncio.ensure_future(rig.fetch(i, in_seconds=30)) for i in (5, 6, 7)]
        await asyncio.sleep(0)
        t0 = rig.clock.now()
        await rig.fetch(0, in_seconds=0.5)
        waited = rig.clock.now() - t0
        await asyncio.gather(*far)
        return waited

    waited = await rig.clock.run(scenario())
    assert waited < 1.2, "an urgent request must not queue behind prefetch transfers"


async def test_seek_cancels_requests_outside_the_new_window() -> None:
    limits = SchedulerLimits(max_concurrent_transfers=2, prefetch_window_seconds=4.0)
    rig = Rig(limits=limits, segments=12)
    rig.session.peer_delivery = False
    rig.origin.latency = 1.0

    async def scenario():
        tasks = {i: asyncio.ensure_future(rig.fetch(i, in_seconds=10 + i)) for i in (0, 1, 2, 8)}
        await asyncio.sleep(0)
        cancelled = rig.scheduler.seek(rig.session, 16.0)  # segment 8 covers 16-18 s
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        return cancelled, dict(zip(tasks, results, strict=True))

    cancelled, results = await rig.clock.run(scenario())
    assert cancelled == 3 and rig.metrics.cancelled_requests == 3
    assert all(isinstance(results[i], TransferCancelled) for i in (0, 1, 2))
    assert isinstance(results[8], VerifiedSegment), "the segment at the new playhead survives"
    assert set(rig.origin.cancelled) <= {rig.timeline[i].segment_id for i in (0, 1, 2)}
    assert rig.timeline[8].segment_id in rig.origin.calls


async def test_duplicate_requests_share_one_transfer() -> None:
    rig = Rig()
    rig.session.peer_delivery = False

    async def scenario():
        return await asyncio.gather(rig.fetch(2), rig.fetch(2), rig.fetch(2))

    results = await rig.clock.run(scenario())
    assert len(rig.origin.calls) == 1 and rig.metrics.duplicate_requests_avoided == 2
    assert all(r.data == results[0].data for r in results)


async def test_session_retry_budget_bounds_peer_retries() -> None:
    limits = SchedulerLimits(session_retry_budget=1, session_retry_refill_per_second=0.0)
    rig = Rig(limits=limits)
    for name in ("a", "b", "c"):
        rig.peer(name, behaviour="refuse")
    await rig.clock.run(rig.fetch(3, in_seconds=20))
    assert rig.metrics.retries == 1  # first attempt is free, one retry from the budget
    # Budget is spent: later segments get one peer attempt and then the origin.
    rig.scheduler.peer_stats.clear()
    await rig.clock.run(rig.fetch(4, in_seconds=20))
    assert rig.metrics.retries == 1
    assert sum(len(p.calls) for p in rig.transport.peers.values()) == 3


async def test_origin_bounded_failure_surfaces_as_unavailable() -> None:
    rig = Rig()
    rig.session.peer_delivery = False
    rig.origin.fail_next = 1
    with pytest.raises(SegmentUnavailable):
        await rig.clock.run(rig.fetch(0))


async def test_cache_hit_skips_network() -> None:
    class Store:
        def __init__(self):
            self.items: dict[str, bytes] = {}

        async def get(self, segment_id):
            return self.items.get(segment_id)

        async def put(self, segment):
            self.items[segment.descriptor.segment_id] = segment.data

        async def discard(self, segment_id):
            self.items.pop(segment_id, None)

    rig = Rig()
    rig.session.peer_delivery = False
    store = Store()
    rig.scheduler._store = store
    first = await rig.clock.run(rig.fetch(1))
    second = await rig.clock.run(rig.fetch(1))
    assert (first.source, second.source) == ("origin", "cache")
    assert rig.metrics.cache_hits == 1 and rig.metrics.cache_misses == 1
    assert rig.metrics.cache_hit_rate == 0.5
    # A cache entry that no longer verifies is discarded and refetched.
    store.items[rig.timeline[1].segment_id] = b"tampered"
    third = await rig.clock.run(rig.fetch(1))
    assert third.source == "origin" and rig.metrics.verification_failures == 1


def test_prefetch_window_is_bounded() -> None:
    manifest, _ = make_manifest(segments=30)
    timeline = manifest.media_segments("rnd_0")
    limits = SchedulerLimits(prefetch_window_seconds=6.0)
    window = plan_window(timeline, playhead=10.0, limits=limits, have=set())
    assert [s.sequence_number for s in window] == [5, 6, 7]
    have = {timeline[5].segment_id}
    assert [s.sequence_number for s in plan_window(timeline, playhead=10.0, limits=limits, have=have)] == [
        6,
        7,
    ]


# --------------------------------------------------------------------------- simulated player
def player(rig: Rig, script: PlaybackScript | None = None, adapter=None) -> SimulatedPlayer:
    sim = SimulatedPlayer(
        clock=rig.clock, scheduler=rig.scheduler, session=rig.session, manifest=rig.manifest,
        adapter=adapter or FixedRendition(rig.rid), script=script,
    )  # fmt: skip
    rig.scheduler._observer = sim.observe
    return sim


async def test_simulated_playback_origin_only_has_no_stalls() -> None:
    rig = Rig(segments=10)
    rig.session.peer_delivery = False
    report = await rig.clock.run(player(rig).run())
    assert report.kind == "simulated" and report.completed
    assert report.stalls == 0 and report.final_position == 20.0
    assert 0 < report.startup_delay_seconds < 1.0
    assert rig.metrics.origin_segments == 11  # init + 10 media
    assert math.isclose(report.wall_seconds, 20.0, abs_tol=1.0)


async def test_simulated_playback_uses_peers_and_survives_peer_loss() -> None:
    rig = Rig(segments=12)
    peer = rig.peer()

    async def kill_peer_midway() -> None:
        await rig.clock.sleep(9.0)
        peer.behaviour = "offline"

    async def scenario():
        killer = asyncio.ensure_future(kill_peer_midway())
        report = await player(rig).run()
        await killer
        return report

    report = await rig.clock.run(scenario())
    assert report.completed and report.stalls == 0, report
    assert rig.metrics.peer_segments > 0, "peers carried part of the title"
    assert rig.metrics.origin_fallbacks >= 1, "origin took over after the peer vanished"
    assert rig.metrics.deadline_misses == 0
    assert rig.metrics.peer_segments + rig.metrics.origin_segments == 13


async def test_simulated_seek_reprioritises() -> None:
    rig = Rig(segments=20, limits=SchedulerLimits(prefetch_window_seconds=8.0))
    rig.session.peer_delivery = False
    rig.origin.latency = 0.6
    script = PlaybackScript(seeks=[(1.0, 30.0)], stop_after_seconds=6.0)
    report = await rig.clock.run(player(rig, script).run())
    assert report.seeks == 1 and report.final_position > 30.0
    order = [e["seq"] for e in rig.metrics.events if e["event"] == "delivered" and e["kind"] == "media"]
    after_seek = order[order.index(15) :]
    assert 15 in order, "the segment at the seek target was fetched"
    assert all(seq >= 15 for seq in after_seek), "nothing from the old position after the seek"
    assert rig.metrics.cancelled_requests >= 1
    assert not {4, 5, 6, 7, 8, 9, 10} & set(order), "no download-everything behaviour"


async def test_scheduler_never_switches_rendition_itself() -> None:
    rig = Rig(segments=8, renditions=2)
    rig.session.peer_delivery = False
    abr = ThroughputAbr()
    report = await rig.clock.run(player(rig, adapter=abr).run())
    assert report.completed
    delivered = [o.rendition_id for o in rig.observations]
    requested_by_player = set(report.renditions_used)
    assert set(delivered) <= requested_by_player
    assert report.renditions_used[0] == "rnd_1", "ABR starts on the lowest rendition"
    assert "rnd_0" in report.renditions_used, "the adapter (not the scheduler) switched up"
