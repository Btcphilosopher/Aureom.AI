"""Storage, coordination, tokens, clock and small parsers."""

from __future__ import annotations

import asyncio
import hashlib
import os
import shutil
import socket
import subprocess
import time
from collections.abc import AsyncIterator, Iterator
from pathlib import Path

import pytest
import pytest_asyncio
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from aureom_stream.access.tokens import (
    AUD_API,
    TYP_ORIGIN,
    TYP_PRINCIPAL,
    TokenError,
    TokenService,
    TokenVerifier,
    load_or_create_signing_key,
)
from aureom_stream.clock import FakeClock, run_with_timeout
from aureom_stream.domain import IntegrityError, SegmentDescriptor, verify_segment
from aureom_stream.manifests.playlists import parse_media_playlist
from aureom_stream.peer_agent.cache import SegmentCache
from aureom_stream.peer_agent.limiter import GrantLedger, TokenBucket
from aureom_stream.persistence.coordination import InMemoryCoordination, RedisCoordination
from aureom_stream.persistence.object_store import (
    LocalObjectStore,
    ObjectExists,
    ObjectNotFound,
    S3ObjectStore,
    validate_key,
)
from aureom_stream.uploads.sniff import looks_like_webvtt, sniff_container


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


# --------------------------------------------------------------------------- object stores
@pytest.fixture
def local_store(tmp_path: Path) -> LocalObjectStore:
    return LocalObjectStore(tmp_path / "objects")


@pytest.fixture(scope="module")
def s3_endpoint() -> Iterator[str]:
    """A real S3 API (moto server) so the boto3 adapter is exercised over HTTP."""
    moto_server = pytest.importorskip("moto.server")
    port = free_port()
    server = moto_server.ThreadedMotoServer(port=port, verbose=False)
    server.start()
    yield f"http://127.0.0.1:{port}"
    server.stop()


@pytest_asyncio.fixture
async def s3_store(s3_endpoint: str) -> S3ObjectStore:
    store = S3ObjectStore(
        bucket=f"test-{os.urandom(4).hex()}", endpoint_url=s3_endpoint, region="us-east-1",
        access_key_id="test", secret_access_key="test",
    )  # fmt: skip
    await store.ensure_bucket()
    return store


async def test_local_object_store_contract(local_store: LocalObjectStore) -> None:
    await _object_store_contract(local_store)


async def test_s3_object_store_contract(s3_store: S3ObjectStore) -> None:
    await _object_store_contract(s3_store)


async def _object_store_contract(store) -> None:  # noqa: ANN001
    assert await store.healthcheck()
    await store.put("a/b/one", b"hello world", content_type="text/plain")
    assert await store.get("a/b/one") == b"hello world"
    assert await store.size("a/b/one") == 11 and await store.size("a/b/none") is None
    assert await store.get_range("a/b/one", 6, 10) == b"world"
    with pytest.raises(ObjectExists):
        await store.put("a/b/one", b"other", if_absent=True)
    assert await store.get("a/b/one") == b"hello world", "create-if-absent never overwrites"
    with pytest.raises(ObjectNotFound):
        await store.get("a/b/missing")

    parts = [os.urandom(70_000) for _ in range(3)]
    for index, part in enumerate(parts):
        await store.put(f"up/x/parts/{index:05d}", part)
    result = await store.compose("orig/x/source", [f"up/x/parts/{i:05d}" for i in range(3)])
    assert result.size == 210_000 and result.sha256 == hashlib.sha256(b"".join(parts)).hexdigest()
    assert await store.get("orig/x/source") == b"".join(parts)
    chunks = [c async for c in store.iter_chunks("orig/x/source", 10, 99_999)]
    assert b"".join(chunks) == b"".join(parts)[10:100_000]

    assert await store.delete_prefix("up/x") == 3
    assert await store.size("up/x/parts/00000") is None
    await store.delete("a/b/one")
    await store.delete("a/b/one")  # idempotent
    assert await store.size("a/b/one") is None


async def test_local_store_file_roundtrip_and_limits(local_store: LocalObjectStore, tmp_path: Path) -> None:
    src = tmp_path / "src.bin"
    src.write_bytes(b"x" * 5000)
    await local_store.put_file("media/v/seg", src)
    out = tmp_path / "out.bin"
    assert await local_store.download_to("media/v/seg", out, max_bytes=5000) == 5000
    with pytest.raises(ValueError):
        await local_store.download_to("media/v/seg", out, max_bytes=4999)
    with pytest.raises(ObjectNotFound):
        await local_store.download_to("media/v/none", out, max_bytes=10)


@pytest.mark.parametrize("key", ["../etc/passwd", "/abs", "a//b", "a/../b", "", "a/b/", "sp ace", "x\x00y"])
def test_object_keys_are_validated(key: str, local_store: LocalObjectStore) -> None:
    with pytest.raises(ValueError):
        validate_key(key)
    with pytest.raises(ValueError):
        local_store._path(key)


# --------------------------------------------------------------------------- coordination
@pytest.fixture(scope="module")
def redis_url() -> Iterator[str]:
    binary = shutil.which("redis-server")
    if binary is None:
        pytest.skip("redis-server not installed")
    port = free_port()
    proc = subprocess.Popen(
        [binary, "--port", str(port), "--save", "", "--appendonly", "no", "--bind", "127.0.0.1"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )  # fmt: skip
    deadline = time.time() + 10
    while time.time() < deadline:
        with socket.socket() as sock:
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                break
        time.sleep(0.05)
    yield f"redis://127.0.0.1:{port}/0"
    proc.terminate()
    proc.wait(timeout=10)


@pytest_asyncio.fixture
async def redis_coord(redis_url: str) -> AsyncIterator[RedisCoordination]:
    coord = RedisCoordination(redis_url, prefix=f"t{os.urandom(4).hex()}:")
    yield coord
    await coord.close()


async def _coordination_contract(coord, advance) -> None:  # noqa: ANN001
    assert await coord.ping()
    assert [await coord.hit("rl", 3, 60) for _ in range(5)] == [True, True, True, False, False]
    assert await coord.hit("bytes", 1000, 60, 700)
    assert not await coord.hit("bytes", 1000, 60, 400), "over budget: refused and not counted"
    assert await coord.hit("bytes", 1000, 60, 300)

    assert await coord.acquire_slot("conc", "a", 2, 2)
    assert await coord.acquire_slot("conc", "b", 2, 2)
    assert not await coord.acquire_slot("conc", "c", 2, 2)
    assert await coord.acquire_slot("conc", "a", 2, 2), "re-acquiring your own slot is fine"
    await coord.release_slot("conc", "a")
    assert await coord.acquire_slot("conc", "c", 2, 2)
    await advance(2.2)
    assert await coord.acquire_slot("conc", "d", 2, 2), "slots expire on their own"

    assert await coord.claim_once("once", 1)
    assert not await coord.claim_once("once", 1)
    await advance(1.2)
    assert await coord.claim_once("once", 1)


async def test_in_memory_coordination() -> None:
    clock = FakeClock()

    async def advance(seconds: float) -> None:
        clock.tick(seconds)

    await _coordination_contract(InMemoryCoordination(clock), advance)
    coord = InMemoryCoordination(clock)
    assert [await coord.hit("w", 1, 60) for _ in range(2)] == [True, False]
    clock.tick(61)
    assert await coord.hit("w", 1, 60), "a new window starts"


@pytest.mark.redis
async def test_redis_coordination(redis_coord: RedisCoordination) -> None:
    await _coordination_contract(redis_coord, asyncio.sleep)


@pytest.mark.redis
async def test_api_runs_on_redis_and_s3(redis_url: str, s3_endpoint: str, tmp_path: Path) -> None:
    """The same API over Redis coordination and S3 storage: resumable upload round trip."""
    import httpx

    from aureom_stream.api.app import create_app
    from aureom_stream.bootstrap import build_context
    from aureom_stream.config import Settings

    from .helpers import auth, fake_media, upload_bytes

    settings = Settings(
        _env_file=None, env="test", database_url=f"sqlite+aiosqlite:///{tmp_path}/t.db",
        redis_url=redis_url, storage_backend="s3", s3_endpoint_url=s3_endpoint,
        s3_bucket=f"api-{os.urandom(4).hex()}", s3_access_key_id="test", s3_secret_access_key="test",
        signing_key_path=tmp_path / "k.pem", upload_part_size_bytes=64 * 1024,
    )  # fmt: skip
    ctx = build_context(settings)
    await ctx.db.create_all()
    await ctx.store.ensure_bucket()  # type: ignore[attr-defined]
    try:
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=create_app(ctx=ctx)), base_url="http://api.test"
        ) as client:
            ready = (await client.get("/readyz")).json()
            assert ready == {
                "ready": True,
                "checks": {"database": True, "object_store": True, "coordination": True},
            }
            data = fake_media(150_000)
            done = await upload_bytes(client, auth(ctx, "alice"), data)
            assert done["state"] == "completed" and done["sha256"] == hashlib.sha256(data).hexdigest()
            assert await ctx.store.get(f"originals/{done['upload_id']}/source") == data
            assert await ctx.store.size(f"uploads/{done['upload_id']}/parts/00001") is None
            assert "s3" not in str(done).lower() and settings.s3_bucket not in str(done)
    finally:
        await ctx.close()


# --------------------------------------------------------------------------- tokens
def test_tokens_expire_on_the_injected_clock_and_are_type_bound(tmp_path: Path) -> None:
    clock = FakeClock()
    key = load_or_create_signing_key(tmp_path / "keys" / "k.pem", create=True)
    assert (tmp_path / "keys" / "k.pem").stat().st_mode & 0o777 == 0o600
    assert load_or_create_signing_key(tmp_path / "keys" / "k.pem", create=False) is not None
    service = TokenService(key, issuer="aureom-stream", clock=clock)
    token = service.mint_principal_token("alice", ["media:upload"], ttl=60)
    claims = service.verify(token, typ=TYP_PRINCIPAL, audience=AUD_API)
    assert claims["sub"] == "alice" and claims["scope"] == "media:upload"

    verifier = TokenVerifier.from_jwks(service.jwks(), issuer="aureom-stream", clock=clock)
    tampered = token[:-10] + ("A" if token[-10] != "A" else "B") + token[-9:]  # one signature char
    assert verifier.verify(token, typ=TYP_PRINCIPAL, audience=AUD_API)["sub"] == "alice"
    for bad_call, reason in (
        (lambda: verifier.verify(token, typ=TYP_ORIGIN, audience=AUD_API), "wrong_token_type"),
        (lambda: verifier.verify(token, typ=TYP_PRINCIPAL, audience="someone-else"), "wrong_audience"),
        (lambda: verifier.verify(tampered, typ=TYP_PRINCIPAL, audience=AUD_API), "invalid"),
        (lambda: verifier.verify("garbage", typ=TYP_PRINCIPAL, audience=AUD_API), "malformed"),
    ):
        with pytest.raises(TokenError) as err:
            bad_call()
        assert err.value.reason == reason
    other = TokenService(Ed25519PrivateKey.generate(), issuer="aureom-stream", clock=clock)
    with pytest.raises(TokenError) as unknown:
        verifier.verify(other.mint_principal_token("eve", [], 60), typ=TYP_PRINCIPAL, audience=AUD_API)
    assert unknown.value.reason == "unknown_key"
    wrong_issuer = TokenVerifier.from_jwks(service.jwks(), issuer="someone", clock=clock)
    with pytest.raises(TokenError):
        wrong_issuer.verify(token, typ=TYP_PRINCIPAL, audience=AUD_API)
    clock.tick(61)
    with pytest.raises(TokenError) as expired:
        verifier.verify(token, typ=TYP_PRINCIPAL, audience=AUD_API)
    assert expired.value.reason == "expired"
    assert "d" not in service.jwks()["keys"][0], "the JWKS never contains private key material"


# --------------------------------------------------------------------------- clock & small parts
async def test_fake_clock_orders_sleepers_and_times_out() -> None:
    clock = FakeClock()
    order: list[str] = []

    async def sleeper(name: str, seconds: float) -> None:
        await clock.sleep(seconds)
        order.append(name)

    tasks = [asyncio.ensure_future(sleeper(n, s)) for n, s in (("c", 3), ("a", 1), ("b", 2))]
    await clock.advance(2.5)
    assert order == ["a", "b"]
    await clock.advance(1)
    await asyncio.gather(*tasks)
    assert order == ["a", "b", "c"]
    with pytest.raises(TimeoutError):
        await clock.run(run_with_timeout(clock, clock.sleep(10), 1.0))


def test_verify_segment_checks_length_and_hash() -> None:
    data = b"segment-bytes"
    descriptor = SegmentDescriptor(
        "seg_1", "ver_1", "rnd_1", "media", 0, 0.0, 2.0, len(data), hashlib.sha256(data).hexdigest()
    )
    assert verify_segment(descriptor, data, source="peer").data == data
    with pytest.raises(IntegrityError) as short:
        verify_segment(descriptor, data[:-1], source="peer")
    assert short.value.reason == "length_mismatch"
    with pytest.raises(IntegrityError) as flipped:
        verify_segment(descriptor, b"S" + data[1:], source="peer")
    assert flipped.value.reason == "hash_mismatch"


def test_sniffing_trusts_bytes_only() -> None:
    assert sniff_container(b"\x00\x00\x00\x18ftypisom\x00\x00\x02\x00") is not None
    assert sniff_container(b"\x1a\x45\xdf\xa3" + b"\x00" * 20).name == "matroska"  # type: ignore[union-attr]
    for bogus in (
        b"#EXTM3U\n#EXT-X-VERSION:3\n",
        b"<html><body>",
        b"MZ\x90\x00" + b"\x00" * 20,
        b"",
        b"ftyp",
    ):
        assert sniff_container(bogus) is None
    assert looks_like_webvtt(b"WEBVTT\n\n") and looks_like_webvtt(b"\xef\xbb\xbfWEBVTT - title\n")
    assert not looks_like_webvtt(b"WEBVTTX") and not looks_like_webvtt(b"1\n00:00:00,000 --> 00:00:01,000\n")


def test_packaged_playlist_parser_is_strict() -> None:
    text = (
        '#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-TARGETDURATION:2\n#EXT-X-MAP:URI="init.mp4"\n'
        "#EXTINF:2.000000,\nseg_00000.m4s\n#EXTINF:1.500000,\nseg_00001.m4s\n#EXT-X-ENDLIST\n"
    )
    parsed = parse_media_playlist(text)
    assert parsed.init_uri == "init.mp4" and parsed.segments == [
        ("seg_00000.m4s", 2.0),
        ("seg_00001.m4s", 1.5),
    ]
    for broken in ("", "not a playlist", "#EXTM3U\n#EXTINF:2,\nseg.m4s\n", text.replace("#EXTINF:2.000000,\n", ""),
                   text + "#EXT-X-KEY:METHOD=AES-128\n"):  # fmt: skip
        with pytest.raises(ValueError):
            parse_media_playlist(broken)


async def test_segment_cache_is_bounded_and_takes_verified_segments_only(tmp_path: Path) -> None:
    clock = FakeClock()
    evicted: list[str] = []
    cache = SegmentCache(
        tmp_path / "cache", max_bytes=2500, clock=clock, ttl_seconds=100,
        on_evict=lambda e: evicted.append(e.segment_id),
    )  # fmt: skip

    def seg(name: str, version: str = "ver_1", size: int = 1000):  # noqa: ANN202
        data = os.urandom(size)
        descriptor = SegmentDescriptor(
            name, version, "rnd", "media", 0, 0, 2, size, hashlib.sha256(data).hexdigest()
        )
        return verify_segment(descriptor, data, source="origin")

    with pytest.raises(TypeError):
        await cache.put(b"raw bytes")  # type: ignore[arg-type]
    a, b, c = seg("seg_a"), seg("seg_b"), seg("seg_c", version="ver_2")
    await cache.put(a)
    await cache.put(b)
    assert await cache.get("seg_a") == a.data  # touch: a is now most recently used
    await cache.put(c)
    assert evicted == ["seg_b"] and cache.total_bytes == 2000 and len(cache) == 2
    await cache.put(seg("seg_huge", size=5000))
    assert "seg_huge" not in cache, "an item larger than the cache is not kept"
    assert cache.purge_version("ver_2") == 1 and cache.segment_ids() == ["seg_a"]
    clock.tick(101)
    assert await cache.get("seg_a") is None and cache.total_bytes == 0  # expired by policy
    await cache.put(seg("seg_d"))
    cache.set_max_bytes(10)
    assert len(cache) == 0
    with pytest.raises(ValueError):
        cache._path("../escape")
    assert list((tmp_path / "cache").iterdir()) == []


async def test_token_bucket_and_grant_ledger() -> None:
    clock = FakeClock()
    bucket = TokenBucket(clock, rate=10_000.0)  # 10 kB/s with a quarter-second (2.5 kB) burst

    async def send() -> float:
        started = clock.now()
        for _ in range(10):
            await bucket.consume(5_000)
        return clock.now() - started

    elapsed = await clock.run(send())
    assert 4.7 <= elapsed <= 5.0, "50 kB at 10 kB/s takes ~5 s (minus the small burst)"
    unlimited = TokenBucket(clock, rate=None)
    await unlimited.consume(10**9)

    ledger = GrantLedger(clock, max_entries=2)
    assert ledger.admit("g1", "s1", 100, 250, clock.now() + 30) is None
    assert ledger.admit("g1", "s1", 100, 250, clock.now() + 30) == "replayed"
    assert ledger.admit("g1", "s2", 100, 250, clock.now() + 30) is None
    assert ledger.admit("g1", "s3", 100, 250, clock.now() + 30) == "byte_limit"
    assert ledger.admit("g2", "s1", 1, 10, clock.now() + 30) is None
    assert ledger.admit("g3", "s1", 1, 10, clock.now() + 30) == "ledger_full"
    clock.tick(31)
    assert ledger.admit("g3", "s1", 1, 10, clock.now() + 30) is None, "expired entries are dropped"
