"""Test helpers: tokens, uploads, and a fast way to seed a packaged asset."""

from __future__ import annotations

import hashlib
import math
import os
from dataclasses import dataclass
from typing import Any

import httpx

from aureom_stream.bootstrap import AppContext
from aureom_stream.catalogue.service import CatalogueService
from aureom_stream.clock import to_datetime
from aureom_stream.domain import DistributionPolicy, Principal
from aureom_stream.ids import new_id
from aureom_stream.manifests.version_manifest import VersionManifest, verify_manifest
from aureom_stream.persistence.models import (
    Asset,
    AssetVersion,
    JobStatus,
    MediaSegment,
    ProcessingJob,
    Rendition,
    SourceUpload,
    UploadState,
    VersionState,
)

ALL_SCOPES = ("media:upload", "media:publish")
# Smallest prefix that passes container sniffing: an MP4 ``ftyp`` box.
MP4_HEAD = b"\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2"


def auth(ctx: AppContext, user: str, *scopes: str) -> dict[str, str]:
    token = ctx.tokens.mint_principal_token(user, list(scopes or ALL_SCOPES), ttl=3600)
    return {"Authorization": f"Bearer {token}"}


def principal(user: str, *scopes: str) -> Principal:
    return Principal(id=user, scopes=frozenset(scopes or ALL_SCOPES))


def fake_media(size: int) -> bytes:
    return MP4_HEAD + os.urandom(size - len(MP4_HEAD))


async def upload_bytes(
    client: httpx.AsyncClient,
    headers: dict[str, str],
    data: bytes,
    *,
    key: str | None = None,
    visibility: str = "private",
    filename: str = "clip.mp4",
) -> dict[str, Any]:
    resp = await client.post(
        "/v1/uploads",
        headers=headers,
        json={
            "filename": filename,
            "content_type": "video/mp4",
            "size_bytes": len(data),
            "visibility": visibility,
            "idempotency_key": key or f"key-{os.urandom(6).hex()}",
        },
    )
    assert resp.status_code in (200, 201), resp.text
    upload = resp.json()
    size = upload["part_size_bytes"]
    for n in range(1, upload["part_count"] + 1):
        part = data[(n - 1) * size : n * size]
        r = await client.put(f"/v1/uploads/{upload['upload_id']}/parts/{n}", headers=headers, content=part)
        assert r.status_code == 200, r.text
    done = await client.post(f"/v1/uploads/{upload['upload_id']}/complete", headers=headers)
    assert done.status_code == 200, done.text
    return done.json()


@dataclass
class Seeded:
    asset_id: str
    version_id: str
    manifest: VersionManifest
    data: dict[str, bytes]  # segment_id -> bytes
    renditions: list[str]


async def seed_asset(
    ctx: AppContext,
    *,
    owner: str = "alice",
    visibility: str = "private",
    distribution: DistributionPolicy | None = None,
    segments: int = 6,
    segment_seconds: float = 2.0,
    segment_bytes: int = 4096,
    publish: bool = True,
    asset_id: str | None = None,
) -> Seeded:
    """Create a packaged (and optionally published) version without running FFmpeg.

    Segment payloads are random bytes: enough for every delivery, access and integrity
    test. Real media goes through the pipeline in ``test_pipeline`` / ``test_e2e``.
    """
    distribution = distribution or DistributionPolicy()
    now = to_datetime(ctx.clock.now())
    data: dict[str, bytes] = {}
    async with ctx.db.session() as db:
        upload = SourceUpload(
            id=new_id("upl"), owner_id=owner, filename="seed.mp4",
            declared_content_type="video/mp4", declared_size_bytes=1024, visibility=visibility,
            idempotency_key=new_id("idk"), part_size_bytes=1024, part_count=1,
            state=UploadState.COMPLETED.value, sniffed_container="mp4", sha256="0" * 64,
            storage_reference=f"originals/{new_id('x')}/source", created_at=now, expires_at=now,
            completed_at=now,
        )  # fmt: skip
        db.add(upload)
        if asset_id is None:
            asset = Asset(
                id=new_id("ast"), owner_id=owner, title="Seeded title", description="",
                language="en",
                rights_declaration={"basis": "owner", "statement": "test fixture", "licence": None},
                visibility=visibility, distribution=distribution.model_dump(),
                created_at=now, updated_at=now,
            )  # fmt: skip
            db.add(asset)
            number = 1
        else:
            asset = await db.get(Asset, asset_id)
            assert asset is not None
            number = 2
        await db.flush()
        version = AssetVersion(
            id=new_id("ver"), asset_id=asset.id, version_number=number,
            source_upload_id=upload.id, state=VersionState.READY_FOR_REVIEW.value,
            duration_seconds=segments * segment_seconds, created_at=now, ready_at=now,
        )  # fmt: skip
        db.add(version)
        await db.flush()
        db.add(
            ProcessingJob(
                id=new_id("job"), asset_version_id=version.id, upload_id=upload.id,
                status=JobStatus.SUCCEEDED.value, stage=VersionState.READY_FOR_REVIEW.value,
                progress=1.0, attempt=1, max_attempts=3, cancel_requested=False,
                created_at=now, updated_at=now, finished_at=now,
            )
        )  # fmt: skip
        rendition_ids: list[str] = []
        for name, height, scale in (("360p", 360, 1.0), ("240p", 240, 0.5)):
            rid = new_id("rnd")
            rendition_ids.append(rid)
            size = max(64, int(segment_bytes * scale))
            db.add(
                Rendition(
                    id=rid, asset_version_id=version.id, name=name,
                    width=math.ceil(height * 16 / 9 / 2) * 2, height=height, video_codec="h264",
                    audio_codec="aac", codecs="avc1.4d401e,mp4a.40.2",
                    bandwidth=int(size * 8 / segment_seconds), average_bandwidth=int(size * 8 / segment_seconds),
                    frame_rate=24.0, segment_count=segments, total_bytes=size * segments + 128,
                )
            )  # fmt: skip
            await db.flush()
            for seq in range(segments + 1):
                kind = "init" if seq == 0 else "media"
                payload = os.urandom(128 if kind == "init" else size)
                sid = new_id("seg")
                key = f"media/{version.id}/seed/{rid}/{seq:05d}"
                await ctx.store.put(key, payload)
                data[sid] = payload
                db.add(
                    MediaSegment(
                        id=sid, asset_version_id=version.id, rendition_id=rid, kind=kind,
                        sequence_number=0 if kind == "init" else seq - 1,
                        start_time=0.0 if kind == "init" else (seq - 1) * segment_seconds,
                        duration=0.0 if kind == "init" else segment_seconds,
                        byte_length=len(payload), content_hash=hashlib.sha256(payload).hexdigest(),
                        storage_reference=key, encryption_metadata_reference=None,
                    )
                )  # fmt: skip
        await db.flush()
        asset_id_out, version_id = asset.id, version.id
        manifest: VersionManifest | None = None
        if publish:
            svc = CatalogueService(ctx, db)
            await svc.publish(
                principal(owner), asset.id, version.id,
                visibility=visibility, confirm_public=True, distribution=distribution,
            )  # fmt: skip
            assert version.manifest_jws is not None
            manifest = verify_manifest(ctx.tokens, version.manifest_jws, expected_version_id=version.id)
    return Seeded(asset_id_out, version_id, manifest, data, rendition_ids)  # type: ignore[arg-type]


async def start_session(
    client: httpx.AsyncClient,
    headers: dict[str, str],
    asset_id: str,
    *,
    peer: bool = False,
    contribute: bool = False,
    version_id: str | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {
        "asset_id": asset_id,
        "client_capabilities": {"supported_codecs": ["avc1"], "max_height": 1080, "peer_delivery": peer},
        "peer_contribution_enabled": contribute,
    }
    if version_id:
        body["version_id"] = version_id
    resp = await client.post("/v1/playback-sessions", headers=headers, json=body)
    assert resp.status_code == 201, resp.text
    return resp.json()


def bearer(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}
