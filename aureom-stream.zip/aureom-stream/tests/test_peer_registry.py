"""Peer coordination API: isolation, bounded messages, grants, receipts, reliability."""

from __future__ import annotations

from typing import Any

import httpx
import jwt

from aureom_stream.bootstrap import AppContext
from aureom_stream.clock import FakeClock
from aureom_stream.discovery import reliability
from aureom_stream.discovery.reliability import Outcome
from aureom_stream.domain import DistributionPolicy

from .helpers import Seeded, bearer, seed_asset, start_session

PEERS = DistributionPolicy(peer_delivery=True, peer_contribution="all_viewers")


class Peer:
    def __init__(self, client: httpx.AsyncClient, info: dict[str, Any], playback: dict[str, Any]) -> None:
        self.client = client
        self.id = info["peer_session_id"]
        self.auth = bearer(info["peer_token"])
        self.info = info
        self.playback = playback

    async def announce(
        self, ids: list[str], mode: str = "delta", drop: list[str] | None = None
    ) -> httpx.Response:
        return await self.client.put(
            f"/v1/peer-sessions/{self.id}/availability", headers=self.auth,
            json={"mode": mode, "have": ids, "drop": drop or []},
        )  # fmt: skip

    async def discover(self, ids: list[str]) -> httpx.Response:
        return await self.client.post(
            "/v1/peer-discovery", headers=self.auth, json={"peer_session_id": self.id, "segment_ids": ids}
        )

    async def grant(self, serving: str, ids: list[str]) -> httpx.Response:
        return await self.client.post(
            "/v1/transfer-authorisations", headers=self.auth,
            json={"peer_session_id": self.id, "serving_peer_id": serving, "segment_ids": ids},
        )  # fmt: skip

    async def receipt(
        self, grant_id: str, segment_id: str, role: str, outcome: str, size: int
    ) -> httpx.Response:
        return await self.client.post(
            "/v1/transfer-receipts", headers=self.auth,
            json={
                "peer_session_id": self.id, "grant_id": grant_id, "segment_id": segment_id, "role": role,
                "outcome": outcome, "bytes_transferred": size, "duration_ms": 12,
            },
        )  # fmt: skip


async def join(
    client: httpx.AsyncClient, auth, user: str, asset: Seeded, *, port: int, contribute: bool = True,
    **contribution: Any,
) -> Peer:  # fmt: skip
    playback = await start_session(client, auth(user), asset.asset_id, peer=True, contribute=contribute)
    resp = await client.post(
        "/v1/peer-sessions", headers=bearer(playback["session_token"]),
        json={
            "playback_session_id": playback["session_id"],
            "endpoint": {"host": "127.0.0.1", "port": port},
            "transport": "loopback-http",
            "contribution": {"enabled": contribute, **contribution},
        },
    )  # fmt: skip
    assert resp.status_code == 201, resp.text
    return Peer(client, resp.json(), playback)


def media_ids(asset: Seeded) -> list[str]:
    return [s.segment_id for s in asset.manifest.renditions[0].segments]


async def test_registration_requires_an_authorised_peer_enabled_playback_session(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS)
    origin_only = await start_session(client, auth("bob"), asset.asset_id)  # peer mode not requested
    body = {
        "playback_session_id": origin_only["session_id"],
        "endpoint": {"host": "127.0.0.1", "port": 9000},
        "transport": "loopback-http",
    }
    refused = await client.post("/v1/peer-sessions", headers=bearer(origin_only["session_token"]), json=body)
    assert refused.status_code == 403 and refused.json()["code"] == "peer_not_permitted"
    assert (await client.post("/v1/peer-sessions", json=body)).status_code == 401
    assert (await client.post("/v1/peer-sessions", headers=bearer("x" * 40), json=body)).status_code == 404

    session = await start_session(client, auth("bob"), asset.asset_id, peer=True)
    token = bearer(session["session_token"])
    body["playback_session_id"] = session["session_id"]
    # The plain-HTTP test transport is never accepted for a routable address.
    remote = await client.post(
        "/v1/peer-sessions", headers=token, json={**body, "endpoint": {"host": "203.0.113.7", "port": 9000}}
    )
    assert remote.status_code == 422 and remote.json()["code"] == "insecure_transport"
    no_cert = await client.post("/v1/peer-sessions", headers=token, json={**body, "transport": "mtls-http"})
    assert no_cert.status_code == 422 and no_cert.json()["code"] == "thumbprint_required"
    made_up = await client.post(
        "/v1/peer-sessions", headers=token, json={**body, "transport": "my-own-protocol"}
    )
    assert made_up.status_code == 422
    ok = await client.post("/v1/peer-sessions", headers=token, json=body)
    assert ok.status_code == 201
    info = ok.json()
    assert info["contribute"] is False, "contribution stays off without an explicit opt-in"
    assert info["peer_session_id"].startswith("prs_") and "bob" not in ok.text  # opaque, no identity
    silent = await client.put(
        f"/v1/peer-sessions/{info['peer_session_id']}/availability", headers=bearer(info["peer_token"]),
        json={"mode": "delta", "have": media_ids(asset)[:1]},
    )  # fmt: skip
    assert silent.status_code == 403 and silent.json()["code"] == "contribution_not_enabled"


async def test_discovery_returns_only_authorised_peers_and_requested_segments(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS)
    ids = media_ids(asset)
    a = await join(client, auth, "alice", asset, port=9001)
    b = await join(client, auth, "bob", asset, port=9002)
    assert (await a.announce(ids[:4])).json() == {"announced": 4}

    found = (await b.discover([ids[1], ids[5]])).json()["peers"]
    assert len(found) == 1 and found[0]["peer_id"] == a.id
    assert found[0]["segment_ids"] == [ids[1]], "only requested ids appear, never the rest of the inventory"
    assert found[0]["endpoint"] == {"host": "127.0.0.1", "port": 9001}
    assert (await a.discover(ids[:2])).json()["peers"] == [], "a peer is never offered itself"
    # Non-contributing, paused and closed peers are not offered.
    await a.client.post(
        f"/v1/peer-sessions/{a.id}/heartbeat", headers=a.auth, json={"contribution_paused": True}
    )
    assert (await b.discover(ids[:2])).json()["peers"] == []
    await a.client.post(
        f"/v1/peer-sessions/{a.id}/heartbeat", headers=a.auth, json={"contribution_paused": False}
    )
    assert len((await b.discover(ids[:2])).json()["peers"]) == 1
    await a.client.post(f"/v1/peer-sessions/{a.id}/heartbeat", headers=a.auth, json={"metered": True})
    assert (await b.discover(ids[:2])).json()["peers"] == [], "metered networks do not contribute"
    await a.client.post(
        f"/v1/peer-sessions/{a.id}/heartbeat",
        headers=a.auth,
        json={"metered": False, "contribution_paused": False},
    )
    assert (await client.delete(f"/v1/peer-sessions/{a.id}", headers=a.auth)).status_code == 204
    assert (await b.discover(ids[:2])).json()["peers"] == []
    assert (await a.discover(ids[:2])).status_code == 410


async def test_private_asset_discovery_is_rejected_for_unauthorised_peers(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    public = await seed_asset(ctx, owner="alice", visibility="public", distribution=PEERS)
    private = await seed_asset(ctx, owner="alice", visibility="private", distribution=PEERS)
    await client.post(
        f"/v1/assets/{private.asset_id}/grants", headers=auth("alice"),
        json={"principal_id": "bob", "permission": "view"},
    )  # fmt: skip
    insider = await join(client, auth, "bob", private, port=9001)
    private_ids = media_ids(private)
    await insider.announce(private_ids)

    # Mallory is an authorised viewer of the *public* asset only.
    mallory = await join(client, auth, "mallory", public, port=9003)
    probe = await mallory.discover(private_ids[:3])
    assert probe.status_code == 403 and probe.json()["code"] == "segment_out_of_scope"
    assert insider.id not in probe.text
    mixed = await mallory.discover([media_ids(public)[0], private_ids[0]])
    assert mixed.status_code == 403, "one out-of-scope id rejects the whole request"
    unknown = await mallory.discover(["seg_" + "a" * 26])
    assert unknown.status_code == 403, "unknown and private ids are indistinguishable"
    # She cannot claim private segments, be granted them, or create a session for the asset.
    claim = await mallory.announce(private_ids[:1])
    assert claim.status_code == 403 and claim.json()["code"] == "segment_out_of_scope"
    grant = await mallory.grant(insider.id, private_ids[:1])
    assert grant.status_code == 403 and grant.json()["code"] == "transfer_not_permitted"
    no_session = await client.post(
        "/v1/playback-sessions", headers=auth("mallory"), json={"asset_id": private.asset_id}
    )
    assert no_session.status_code == 404
    # Another peer's token cannot drive this session.
    stolen = await client.post(
        "/v1/peer-discovery", headers=mallory.auth,
        json={"peer_session_id": insider.id, "segment_ids": private_ids[:1]},
    )  # fmt: skip
    assert stolen.status_code == 404
    # The authorised viewer still discovers nothing from the public swarm either.
    assert (await insider.discover(private_ids[:2])).json()["peers"] == []


async def test_availability_messages_are_bounded(ctx: AppContext, client: httpx.AsyncClient, auth) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS, segments=12)
    ids = media_ids(asset)
    a = await join(client, auth, "alice", asset, port=9001)
    ctx.settings.availability_max_ids_per_message = 5
    too_many = await a.announce(ids[:6])
    assert too_many.status_code == 422 and too_many.json()["code"] == "message_too_large"
    assert (await a.announce(ids[:5])).json()["announced"] == 5
    assert (await a.announce(ids[:5])).json()["announced"] == 5  # idempotent
    ctx.settings.availability_max_per_peer = 6
    over = await a.announce(ids[5:8])
    assert over.status_code == 422 and over.json()["code"] == "availability_limit"
    assert (await a.announce([], drop=ids[:3])).json()["announced"] == 2
    assert (await a.announce(ids[8:9], mode="replace")).json()["announced"] == 1
    oversized = await a.client.put(
        f"/v1/peer-sessions/{a.id}/availability", headers=a.auth, json={"have": ["x"] * 2000}
    )
    assert oversized.status_code == 422
    b = await join(client, auth, "bob", asset, port=9002)
    ctx.settings.discovery_max_segments = 4
    assert (await b.discover(ids[:5])).status_code == 422


async def test_transfer_grants_are_bound_short_lived_and_limited(
    ctx: AppContext, client: httpx.AsyncClient, auth, clock: FakeClock
) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS)
    ids = media_ids(asset)
    a = await join(client, auth, "alice", asset, port=9001)
    b = await join(client, auth, "bob", asset, port=9002)
    await a.announce(ids[:4])

    resp = await b.grant(a.id, ids[:2])
    assert resp.status_code == 201
    grant = resp.json()
    claims = jwt.decode(grant["token"], options={"verify_signature": False})
    header = jwt.get_unverified_header(grant["token"])
    assert header["alg"] == "EdDSA" and header["typ"] == "transfer+jwt"
    assert claims["sub"] == b.id and claims["aud"] == a.id  # requester and serving peer
    assert claims["ver"] == asset.version_id and claims["segs"] == ids[:2]
    assert claims["jti"] == grant["grant_id"]
    assert claims["max_bytes"] == sum(len(asset.data[i]) for i in ids[:2])
    assert 0 < claims["exp"] - clock.now() <= ctx.settings.transfer_grant_ttl_seconds
    # The registry verifies with the same public key peers use; expiry is enforced.
    ctx.tokens.verify(grant["token"], typ="transfer+jwt", audience=a.id)
    clock.tick(ctx.settings.transfer_grant_ttl_seconds + 1)
    try:
        ctx.tokens.verify(grant["token"], typ="transfer+jwt", audience=a.id)
        raise AssertionError("expired grant accepted")
    except Exception as exc:
        assert getattr(exc, "reason", "") == "expired"

    for peer in (a, b):  # sessions outlive the clock jump only with heartbeats
        await client.post(f"/v1/playback-sessions/{peer.playback['session_id']}/heartbeat",
                          headers=bearer(peer.playback["session_token"]))  # fmt: skip
    # Sessions expired while the clock jumped: re-join.
    a = await join(client, auth, "alice", asset, port=9001)
    b = await join(client, auth, "bob", asset, port=9002)
    await a.announce(ids[:4])
    not_announced = await b.grant(a.id, [ids[5]])
    assert not_announced.status_code == 403, "no grant for a segment the peer never announced"
    assert (await b.grant(b.id, ids[:1])).status_code == 403  # not from yourself
    assert (await b.grant("prs_" + "b" * 26, ids[:1])).status_code == 403
    assert (await b.grant(a.id, [ids[0], ids[0]])).status_code == 422

    ctx.settings.transfer_grant_max_concurrent = 2
    g1 = (await b.grant(a.id, ids[:1])).json()
    assert (await b.grant(a.id, ids[1:2])).status_code == 201
    busy = await b.grant(a.id, ids[2:3])
    assert busy.status_code == 429 and busy.json()["code"] == "grant_concurrency_limited"
    # Reporting the outcome of a transfer frees its slot.
    done = await b.receipt(g1["grant_id"], ids[0], "receiver", "verified", len(asset.data[ids[0]]))
    assert done.status_code == 201
    assert (await b.grant(a.id, ids[2:3])).status_code == 201

    ctx.settings.transfer_grant_max_concurrent = 100
    ctx.settings.transfer_grants_per_minute = 5
    codes = [(await b.grant(a.id, ids[:1])).status_code for _ in range(6)]
    assert 429 in codes, "per-requester grant rate limit"
    clock.tick(61)


async def test_byte_budget_limits_grants(ctx: AppContext, client: httpx.AsyncClient, auth) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS, segment_bytes=4000)
    ids = media_ids(asset)
    a = await join(client, auth, "alice", asset, port=9001)
    b = await join(client, auth, "bob", asset, port=9002)
    await a.announce(ids)
    ctx.settings.transfer_grant_bytes_per_minute = 9000
    assert (await b.grant(a.id, ids[:2])).status_code == 201  # 8000 bytes
    over = await b.grant(a.id, ids[2:3])
    assert over.status_code == 429 and over.json()["code"] == "grant_byte_limited"


async def test_receipts_are_self_reported_bounded_and_party_only(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS)
    ids = media_ids(asset)
    size = len(asset.data[ids[0]])
    a = await join(client, auth, "alice", asset, port=9001)
    b = await join(client, auth, "bob", asset, port=9002)
    c = await join(client, auth, "carol", asset, port=9003)
    await a.announce(ids)
    grant = (await b.grant(a.id, ids[:2])).json()

    receiver = await b.receipt(grant["grant_id"], ids[0], "receiver", "verified", size)
    assert receiver.status_code == 201
    body = receiver.json()
    assert body["independently_verified"] is False and body["corroborated"] is False
    assert "self-reported" in body["note"]
    sender = await a.receipt(grant["grant_id"], ids[0], "sender", "verified", size)
    assert sender.json()["corroborated"] is True and sender.json()["independently_verified"] is False
    duplicate = await b.receipt(grant["grant_id"], ids[0], "receiver", "verified", size)
    assert duplicate.json()["receipt_id"] == body["receipt_id"], "one receipt per party and segment"

    outsider = await c.receipt(grant["grant_id"], ids[0], "receiver", "corrupt", 0)
    assert outsider.status_code == 404, "third parties cannot file receipts about a grant"
    wrong_role = await b.receipt(grant["grant_id"], ids[1], "sender", "verified", size)
    assert wrong_role.status_code == 422 and wrong_role.json()["code"] == "wrong_role"
    not_covered = await b.receipt(grant["grant_id"], ids[4], "receiver", "verified", size)
    assert not_covered.status_code == 422 and not_covered.json()["code"] == "segment_not_in_grant"
    inflated = await b.receipt(grant["grant_id"], ids[1], "receiver", "verified", 10**9)
    assert inflated.status_code == 422 and inflated.json()["code"] == "bytes_exceed_grant"


async def test_one_reporter_cannot_get_a_peer_quarantined_but_two_can(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS)
    ids = media_ids(asset)
    a = await join(client, auth, "alice", asset, port=9001)
    b = await join(client, auth, "bob", asset, port=9002)
    c = await join(client, auth, "carol", asset, port=9003)
    d = await join(client, auth, "dave", asset, port=9004)
    await a.announce(ids)

    for index in range(3):  # Bob complains three times
        g = (await b.grant(a.id, [ids[index]])).json()
        await b.receipt(g["grant_id"], ids[index], "receiver", "corrupt", 0)
    assert (await b.discover(ids)).json()["peers"] == [], "Bob is no longer offered that peer"
    still = (await c.discover(ids)).json()["peers"]
    assert len(still) == 1 and still[0]["reliability"] < 1.0, "others still are; the score dropped"

    g = (await c.grant(a.id, [ids[3]])).json()
    await c.receipt(g["grant_id"], ids[3], "receiver", "corrupt", 0)  # a second, distinct reporter
    assert (await d.discover(ids)).json()["peers"] == [], "two independent reports quarantine the peer"
    refused = await d.grant(a.id, [ids[4]])
    assert refused.status_code == 403


async def test_misreported_availability_is_forgotten(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS)
    ids = media_ids(asset)
    a = await join(client, auth, "alice", asset, port=9001)
    b = await join(client, auth, "bob", asset, port=9002)
    await a.announce(ids[:2])
    g = (await b.grant(a.id, [ids[0]])).json()
    await b.receipt(g["grant_id"], ids[0], "receiver", "not_found", 0)
    peers = (await b.discover(ids[:2])).json()["peers"]
    assert peers[0]["segment_ids"] == [ids[1]], "only the disputed claim is dropped"


def test_reliability_rules_are_bounded() -> None:
    now = 10_000.0

    def outcomes(*items: tuple[str, str, float]) -> list[Outcome]:
        return [Outcome(r, o, now - age) for r, o, age in items]

    assert reliability.evaluate([], now=now).score == 1.0
    # One reporter can contribute at most PER_REPORTER_CAP outcomes.
    spam = outcomes(*[("troll", "timeout", i) for i in range(40)])
    view = reliability.evaluate(spam, now=now)
    assert view.bad == reliability.PER_REPORTER_CAP and not view.quarantine
    assert view.score == round(2 / (2 + 5), 4)
    # Integrity failures from a single reporter never quarantine ...
    solo = reliability.evaluate(outcomes(*[("troll", "corrupt", i) for i in range(10)]), now=now)
    assert solo.quarantine is False and solo.integrity_reporters == {"troll"}
    # ... two distinct reporters do.
    pair = reliability.evaluate(outcomes(("x", "corrupt", 1), ("y", "length_mismatch", 2)), now=now)
    assert pair.quarantine is True and any("2 distinct" in r for r in pair.reasons)
    # Old outcomes fall out of the window; successes raise the score.
    old = reliability.evaluate(outcomes(("x", "corrupt", 9999), ("y", "corrupt", 9999)), now=now)
    assert old.quarantine is False and old.score == 1.0
    mixed = reliability.evaluate(
        outcomes(("x", "verified", 1), ("x", "verified", 2), ("y", "verified", 3), ("z", "timeout", 4)),
        now=now,
    )
    assert mixed.ok == 3 and mixed.bad == 1 and mixed.score == round(5 / 6, 4)


async def test_peer_addresses_are_erased_when_the_session_is_over(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    from sqlalchemy import select

    from aureom_stream.maintenance import sweep
    from aureom_stream.persistence.models import PeerSession

    asset = await seed_asset(ctx, visibility="public", distribution=PEERS)
    a = await join(client, auth, "alice", asset, port=9001)
    b = await join(client, auth, "bob", asset, port=9002)
    assert (await client.delete(f"/v1/peer-sessions/{a.id}", headers=a.auth)).status_code == 204
    await sweep(ctx)
    async with ctx.db.session() as db:
        rows = {p.id: p for p in await db.scalars(select(PeerSession))}
    assert rows[a.id].state == "closed" and rows[a.id].endpoint_host == "" and rows[a.id].endpoint_port == 0
    assert rows[b.id].state == "active" and rows[b.id].endpoint_host == "127.0.0.1"
