"""Resumable uploads: retries, duplicates, conflicts, incompleteness, quota, expiry."""

from __future__ import annotations

import hashlib

import httpx

from aureom_stream.bootstrap import AppContext
from aureom_stream.clock import FakeClock
from aureom_stream.maintenance import sweep

from .helpers import MP4_HEAD, fake_media, upload_bytes

PART = 64 * 1024


def body(size: int, key: str = "example-upload-001", **extra) -> dict:
    return {
        "filename": "survey-documentary.mp4", "content_type": "video/mp4", "size_bytes": size,
        "visibility": "private", "idempotency_key": key, **extra,
    }  # fmt: skip


async def test_create_returns_limits_expiry_and_part_configuration(client: httpx.AsyncClient, auth) -> None:
    resp = await client.post("/v1/uploads", headers=auth("alice"), json=body(PART * 2 + 100))
    assert resp.status_code == 201
    upload = resp.json()
    assert upload["part_size_bytes"] == PART and upload["part_count"] == 3
    assert upload["last_part_size_bytes"] == 100
    assert upload["missing_parts"] == [1, 2, 3]
    assert upload["limits"]["accepted_containers"] == ["mp4", "matroska"]
    assert upload["limits"]["max_upload_bytes"] == 64 * 1024 * 1024
    assert upload["expires_at"] and upload["state"] == "initiated"
    text = resp.text
    assert "uploads/" + upload["upload_id"] + "/parts" not in text.replace("/v1/uploads/", "")
    assert "secret" not in text.lower() and "access_key" not in text.lower()


async def test_create_is_idempotent_and_detects_key_reuse(client: httpx.AsyncClient, auth) -> None:
    alice = auth("alice")
    first = await client.post("/v1/uploads", headers=alice, json=body(1000))
    again = await client.post("/v1/uploads", headers=alice, json=body(1000))
    assert first.status_code == 201 and again.status_code == 200
    assert first.json()["upload_id"] == again.json()["upload_id"]
    conflict = await client.post("/v1/uploads", headers=alice, json=body(2000))
    assert conflict.status_code == 409 and conflict.json()["code"] == "idempotency_conflict"
    # Another user may use the same key independently.
    other = await client.post("/v1/uploads", headers=auth("bob"), json=body(1000))
    assert other.status_code == 201 and other.json()["upload_id"] != first.json()["upload_id"]


async def test_upload_requires_the_upload_permission(client: httpx.AsyncClient, auth) -> None:
    assert (await client.post("/v1/uploads", json=body(1000))).status_code == 401
    viewer = await client.post("/v1/uploads", headers=auth("viewer", "something:else"), json=body(1000))
    assert viewer.status_code == 403 and viewer.json()["code"] == "upload_not_permitted"
    bad = await client.post("/v1/uploads", headers={"Authorization": "Bearer a.b.c"}, json=body(1000))
    assert bad.status_code == 401


async def test_retry_of_same_part_is_idempotent_and_conflict_is_rejected(
    client: httpx.AsyncClient, auth
) -> None:
    alice = auth("alice")
    data = fake_media(PART + 500)
    upload = (await client.post("/v1/uploads", headers=alice, json=body(len(data)))).json()
    url = f"/v1/uploads/{upload['upload_id']}/parts/1"
    first = await client.put(url, headers=alice, content=data[:PART])
    retry = await client.put(url, headers=alice, content=data[:PART])
    assert first.status_code == 200 and first.json()["duplicate"] is False
    assert retry.status_code == 200 and retry.json()["duplicate"] is True
    assert first.json()["sha256"] == hashlib.sha256(data[:PART]).hexdigest()

    different = MP4_HEAD + b"\x01" * (PART - len(MP4_HEAD))
    conflict = await client.put(url, headers=alice, content=different)
    assert conflict.status_code == 409 and conflict.json()["code"] == "part_conflict"
    # The acknowledged part is untouched and the upload still completes correctly.
    await client.put(f"/v1/uploads/{upload['upload_id']}/parts/2", headers=alice, content=data[PART:])
    done = await client.post(f"/v1/uploads/{upload['upload_id']}/complete", headers=alice)
    assert done.status_code == 200 and done.json()["sha256"] == hashlib.sha256(data).hexdigest()


async def test_parts_are_bounded_and_digest_checked(client: httpx.AsyncClient, auth) -> None:
    alice = auth("alice")
    data = fake_media(PART + 500)
    upload = (await client.post("/v1/uploads", headers=alice, json=body(len(data)))).json()
    base = f"/v1/uploads/{upload['upload_id']}/parts"
    too_big = await client.put(f"{base}/1", headers=alice, content=data[:PART] + b"x")
    assert too_big.status_code == 413 and too_big.json()["code"] == "wrong_part_size"
    too_small = await client.put(f"{base}/1", headers=alice, content=data[: PART - 1])
    assert too_small.status_code == 422
    out_of_range = await client.put(f"{base}/9", headers=alice, content=b"x")
    assert out_of_range.status_code == 422 and out_of_range.json()["code"] == "invalid_part_number"
    wrong_digest = await client.put(
        f"{base}/1", headers={**alice, "X-Content-SHA256": "0" * 64}, content=data[:PART]
    )
    assert wrong_digest.status_code == 422 and wrong_digest.json()["code"] == "digest_mismatch"
    assert (await client.get(f"/v1/uploads/{upload['upload_id']}", headers=alice)).json()[
        "parts_received"
    ] == []


async def test_actual_bytes_are_validated_not_the_filename(client: httpx.AsyncClient, auth) -> None:
    alice = auth("alice")
    script = b"#!/bin/sh\nrm -rf /\n" + b"A" * 2000
    playlist = b"#EXTM3U\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:10.0,\nfile:///etc/passwd\n" + b" " * 2000
    for index, payload in enumerate((script, playlist)):
        upload = (
            await client.post("/v1/uploads", headers=alice, json=body(len(payload), key=f"evil-key-{index}"))
        ).json()
        resp = await client.put(f"/v1/uploads/{upload['upload_id']}/parts/1", headers=alice, content=payload)
        assert resp.status_code == 415 and resp.json()["code"] == "unsupported_container"


async def test_filename_is_sanitised_for_display_only(client: httpx.AsyncClient, auth) -> None:
    resp = await client.post(
        "/v1/uploads", headers=auth("alice"),
        json=body(1000, filename="../../etc/cron.d/$(reboot);`id`.mp4"),
    )  # fmt: skip
    assert resp.status_code == 201
    assert resp.json()["filename"] == "$(reboot);`id`.mp4"


async def test_incomplete_upload_cannot_be_completed_and_reports_missing_parts(
    client: httpx.AsyncClient, auth
) -> None:
    alice = auth("alice")
    data = fake_media(PART * 3)
    upload = (await client.post("/v1/uploads", headers=alice, json=body(len(data)))).json()
    base = f"/v1/uploads/{upload['upload_id']}"
    await client.put(f"{base}/parts/1", headers=alice, content=data[:PART])
    await client.put(f"{base}/parts/3", headers=alice, content=data[2 * PART :])
    early = await client.post(f"{base}/complete", headers=alice)
    assert early.status_code == 409 and early.json()["code"] == "incomplete_upload"
    assert early.json()["missing_parts"] == [2]
    status = (await client.get(base, headers=alice)).json()
    assert status["state"] == "uploading" and status["missing_parts"] == [2]
    # Resume: send only what is missing, then complete; completing twice is harmless.
    await client.put(f"{base}/parts/2", headers=alice, content=data[PART : 2 * PART])
    done = await client.post(
        f"{base}/complete", headers=alice, json={"sha256": hashlib.sha256(data).hexdigest()}
    )
    assert done.status_code == 200 and done.json()["state"] == "completed"
    assert (await client.post(f"{base}/complete", headers=alice)).status_code == 200
    late = await client.put(f"{base}/parts/1", headers=alice, content=data[:PART])
    assert late.status_code == 409 and late.json()["code"] == "upload_completed"


async def test_whole_file_digest_mismatch_is_rejected(client: httpx.AsyncClient, auth) -> None:
    alice = auth("alice")
    data = fake_media(2000)
    upload = (await client.post("/v1/uploads", headers=alice, json=body(len(data)))).json()
    await client.put(f"/v1/uploads/{upload['upload_id']}/parts/1", headers=alice, content=data)
    resp = await client.post(
        f"/v1/uploads/{upload['upload_id']}/complete", headers=alice, json={"sha256": "f" * 64}
    )
    assert resp.status_code == 422 and resp.json()["code"] == "digest_mismatch"


async def test_quota_exhaustion_and_release_on_abort(
    client: httpx.AsyncClient, auth, ctx: AppContext
) -> None:
    alice = auth("alice")
    ctx.settings.upload_quota_bytes = 10_000
    first = await client.post("/v1/uploads", headers=alice, json=body(8_000, key="quota-key-1"))
    assert first.status_code == 201
    over = await client.post("/v1/uploads", headers=alice, json=body(4_000, key="quota-key-2"))
    assert over.status_code == 413 and over.json()["code"] == "quota_exceeded"
    assert over.json()["used_bytes"] == 8_000
    too_large = await client.post("/v1/uploads", headers=alice, json=body(10**9, key="quota-key-3"))
    assert too_large.status_code == 413 and too_large.json()["code"] == "upload_too_large"
    # Aborting releases quota and storage.
    assert (await client.delete(f"/v1/uploads/{first.json()['upload_id']}", headers=alice)).status_code == 204
    again = await client.post("/v1/uploads", headers=alice, json=body(4_000, key="quota-key-2"))
    assert again.status_code == 201
    gone = await client.put(f"/v1/uploads/{first.json()['upload_id']}/parts/1", headers=alice, content=b"x")
    assert gone.status_code == 410


async def test_abandoned_uploads_expire_and_release_storage(
    client: httpx.AsyncClient, auth, ctx: AppContext, clock: FakeClock
) -> None:
    alice = auth("alice")
    data = fake_media(PART * 2)
    upload = (await client.post("/v1/uploads", headers=alice, json=body(len(data)))).json()
    await client.put(f"/v1/uploads/{upload['upload_id']}/parts/1", headers=alice, content=data[:PART])
    key = f"uploads/{upload['upload_id']}/parts/00001"
    assert await ctx.store.size(key) == PART
    clock.tick(ctx.settings.upload_ttl_seconds + 1)
    counts = await sweep(ctx)
    assert counts["uploads_expired"] == 1
    assert await ctx.store.size(key) is None, "stored parts of an abandoned upload are deleted"
    fresh = auth("alice")  # the old access token expired with the clock jump
    status = (await client.get(f"/v1/uploads/{upload['upload_id']}", headers=fresh)).json()
    assert status["state"] == "expired"
    late = await client.put(f"/v1/uploads/{upload['upload_id']}/parts/2", headers=fresh, content=data[PART:])
    assert late.status_code == 410 and late.json()["code"] == "upload_expired"


async def test_uploads_are_private_to_their_owner(client: httpx.AsyncClient, auth) -> None:
    upload = await upload_bytes(client, auth("alice"), fake_media(3000))
    assert (await client.get(f"/v1/uploads/{upload['upload_id']}", headers=auth("bob"))).status_code == 404
    assert (await client.delete(f"/v1/uploads/{upload['upload_id']}", headers=auth("bob"))).status_code == 404
