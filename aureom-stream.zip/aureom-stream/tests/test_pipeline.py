"""Processing pipeline: constrained FFmpeg, failures, cancellation, restart recovery."""

from __future__ import annotations

import asyncio
import hashlib
from fractions import Fraction
from pathlib import Path

import httpx
import pytest
from sqlalchemy import select

from aureom_stream.bootstrap import AppContext
from aureom_stream.clock import FakeClock
from aureom_stream.packaging.hls import package_args, thumbnail_args, transcode_args
from aureom_stream.packaging.ladder import PlannedRendition, plan_renditions
from aureom_stream.persistence.models import (
    AssetVersion,
    MediaSegment,
    ProcessingJob,
    Rendition,
)
from aureom_stream.processing.errors import ProcessingError
from aureom_stream.processing.ffmpeg import FfmpegAdapter, ResourceLimits, sandbox_available
from aureom_stream.processing.pipeline import MediaPipeline
from aureom_stream.processing.worker import Worker

from .helpers import MP4_HEAD, fake_media, upload_bytes

RIGHTS = {"basis": "owner", "statement": "generated test pattern"}


async def make_asset(client: httpx.AsyncClient, headers: dict, data: bytes) -> dict:
    upload = await upload_bytes(client, headers, data)
    resp = await client.post(
        "/v1/assets", headers=headers,
        json={"upload_id": upload["upload_id"], "title": "Clip", "rights_declaration": RIGHTS},
    )  # fmt: skip
    assert resp.status_code == 201, resp.text
    asset = resp.json()
    asset["upload_id"] = upload["upload_id"]
    asset["version"] = asset["versions"][0]
    return asset


async def job_of(client: httpx.AsyncClient, headers: dict, asset: dict) -> dict:
    versions = (await client.get(f"/v1/assets/{asset['asset_id']}/versions", headers=headers)).json()
    return versions[0]


# --------------------------------------------------------------------------- pure planning
def test_ladder_never_upscales_and_keeps_aspect_ratio() -> None:
    plans = plan_renditions(1920, 1080)
    assert [(p.width, p.height) for p in plans] == [(1920, 1080), (1280, 720), (854, 480), (640, 360)]
    odd = plan_renditions(1000, 562)
    assert odd[0].height == 562 and odd[0].width == 1000, "top rung is the source size"
    assert all(p.height <= 562 and p.width <= 1000 for p in odd)
    assert all(abs(p.width / p.height - 1000 / 562) < 0.02 for p in odd)
    assert all(p.width % 2 == 0 and p.height % 2 == 0 for p in odd)
    portrait = plan_renditions(720, 1280)
    assert portrait[0] == PlannedRendition("1280p", 720, 1280, portrait[0].video_kbps, portrait[0].audio_kbps)
    assert all(p.width < p.height for p in portrait)
    tiny = plan_renditions(160, 120)
    assert len(tiny) == 2 and tiny[0].height == tiny[1].height == 120, "two rungs even when tiny"
    assert tiny[1].video_kbps < tiny[0].video_kbps
    assert len(plan_renditions(3840, 2160, max_renditions=2)) == 2
    with pytest.raises(ValueError):
        plan_renditions(8, 8)


def test_ffmpeg_arguments_are_fixed_arrays_without_user_input() -> None:
    plan = PlannedRendition("360p", 640, 360, 800, 96)
    args = transcode_args(
        demuxer="mov,mp4,m4a,3gp,3g2,mj2", rendition=plan, frame_rate=Fraction(30000, 1001),
        segment_seconds=4.0, has_audio=True, threads=2, output_name="r0.mp4",
    )  # fmt: skip
    assert isinstance(args, list) and all(isinstance(a, str) for a in args)
    assert args[args.index("-i") + 1] == "source.bin", "input is a fixed name, never the uploaded filename"
    assert args[args.index("-protocol_whitelist") + 1] == "file"
    assert args.index("-f") < args.index("-i"), "demuxer is forced before the input"
    assert args[args.index("-force_key_frames") + 1] == "expr:gte(t,n_forced*4)"
    assert args[args.index("-g") + 1] == "120" and args[args.index("-sc_threshold") + 1] == "0"
    silent = transcode_args(
        demuxer="matroska,webm", rendition=plan, frame_rate=Fraction(25), segment_seconds=2.0,
        has_audio=False, threads=1, output_name="r0.mp4",
    )  # fmt: skip
    assert "-c:a" not in silent and "0:a:0" not in silent
    packaged = package_args(input_name="r0.mp4", out_dir="out0", segment_seconds=2.0)
    assert packaged[packaged.index("-hls_segment_type") + 1] == "fmp4"
    assert packaged[packaged.index("-c") + 1] == "copy"
    assert "-protocol_whitelist" in thumbnail_args(
        demuxer="matroska,webm", at_seconds=1.0, output_name="t.jpg"
    )
    with pytest.raises(ValueError):
        transcode_args(demuxer="x", rendition=plan, frame_rate=Fraction(25), segment_seconds=60.0,
                       has_audio=False, threads=1, output_name="r0.mp4")  # fmt: skip
    with pytest.raises(ValueError):
        FfmpegAdapter()._argv("ffmpeg", ["-i", "bad\x00name"])


# --------------------------------------------------------------------------- real FFmpeg
@pytest.mark.ffmpeg
async def test_pipeline_states_segments_and_hashes(
    ctx: AppContext, client: httpx.AsyncClient, auth, sample_video: Path
) -> None:
    alice = auth("alice")
    asset = await make_asset(client, alice, sample_video.read_bytes())
    seen: list[str] = []
    pipeline = MediaPipeline(ctx)
    original = pipeline._set_stage

    async def spy(job_id, stage, progress=0.0):  # noqa: ANN001
        seen.append(stage.value)
        await original(job_id, stage, progress)

    pipeline._set_stage = spy  # type: ignore[method-assign]
    result = await pipeline.process(asset["upload_id"])
    assert result.status == "succeeded" and result.stage == "ready_for_review"
    assert seen == ["validating", "transcoding", "packaging"]

    async with ctx.db.session() as db:
        renditions = list(await db.scalars(select(Rendition)))
        segments = list(await db.scalars(select(MediaSegment)))
        version = await db.get(AssetVersion, asset["version"]["version_id"])
    assert version is not None and version.state == "ready_for_review" and version.thumbnail_reference
    assert len(renditions) == 2 and {r.height for r in renditions} == {180, 144}
    assert all(r.codecs.startswith("avc1.") and "mp4a.40.2" in r.codecs for r in renditions)
    by_rendition: dict[str, list[MediaSegment]] = {}
    for seg in segments:
        by_rendition.setdefault(seg.rendition_id, []).append(seg)
    timelines = []
    for segs in by_rendition.values():
        inits = [s for s in segs if s.kind == "init"]
        media = sorted((s for s in segs if s.kind == "media"), key=lambda s: s.sequence_number)
        assert len(inits) == 1 and len(media) == 3, "init and media segments are explicit"
        assert inits[0].duration == 0 and inits[0].encryption_metadata_reference is None
        timelines.append([(round(s.start_time, 3), round(s.duration, 3)) for s in media])
        for seg in segs:  # hashes describe the final packaged bytes in storage
            stored = await ctx.store.get(seg.storage_reference)
            assert len(stored) == seg.byte_length
            assert hashlib.sha256(stored).hexdigest() == seg.content_hash
            assert seg.asset_version_id == version.id and seg.storage_reference.startswith(
                f"media/{version.id}/"
            )
    assert timelines[0] == timelines[1] == [(0.0, 2.0), (2.0, 2.0), (4.0, 2.0)], "aligned boundaries"
    thumb = await client.get(f"/v1/assets/{asset['asset_id']}/versions/{version.id}/thumbnail", headers=alice)
    assert thumb.status_code == 200 and thumb.content[:2] == b"\xff\xd8"
    assert list(ctx.settings.work_dir.iterdir()) == [], "temporary work directory is removed"


@pytest.mark.ffmpeg
async def test_invalid_media_fails_with_structured_error(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    alice = auth("alice")
    asset = await make_asset(client, alice, fake_media(30_000))  # passes sniffing, is not media
    result = await Worker(ctx).run_once()
    assert result is not None and result.status == "failed"
    assert result.error is not None and result.error["code"] == "invalid_media"
    assert result.error["stage"] == "validating" and result.error["retryable"] is False
    version = await job_of(client, alice, asset)
    assert version["state"] == "failed" and version["job"]["error"]["code"] == "invalid_media"
    assert version["renditions"] == []
    publish = await client.post(
        f"/v1/assets/{asset['asset_id']}/versions/{version['version_id']}/publish", headers=alice
    )
    assert publish.status_code == 409
    assert await Worker(ctx).run_once() is None, "a failed job is not retried forever"


@pytest.mark.ffmpeg
async def test_audio_only_and_playlist_inputs_are_rejected(
    ctx: AppContext, client: httpx.AsyncClient, auth, tmp_path: Path
) -> None:
    import subprocess

    audio = tmp_path / "audio.mp4"
    subprocess.run(
        ["ffmpeg", "-nostdin", "-loglevel", "error", "-y", "-f", "lavfi", "-i",
         "sine=frequency=300:duration=2", "-c:a", "aac", "-f", "mp4", str(audio)],
        check=True,
    )  # fmt: skip
    alice = auth("alice")
    await make_asset(client, alice, audio.read_bytes())
    result = await Worker(ctx).run_once()
    assert result is not None and result.status == "failed" and result.error["code"] == "no_video_stream"

    # An HLS playlist disguised with an MP4 header must not make FFmpeg read other files.
    secret = tmp_path / "secret.txt"
    secret.write_text("TOP-SECRET")
    evil = MP4_HEAD + f"\n#EXTM3U\n#EXTINF:1,\nfile://{secret}\n".encode() + b" " * 4000
    await make_asset(client, alice, evil)
    result = await Worker(ctx).run_once()
    assert result is not None and result.status == "failed"
    assert "TOP-SECRET" not in str(result.error)


@pytest.mark.ffmpeg
async def test_resource_limits_timeout_and_work_dir_bound(
    ctx: AppContext, client: httpx.AsyncClient, auth, sample_video: Path
) -> None:
    alice = auth("alice")
    asset = await make_asset(client, alice, sample_video.read_bytes())
    slow = FfmpegAdapter(limits=ResourceLimits(timeout_seconds=0.05))
    result = await MediaPipeline(ctx, slow).process(asset["upload_id"])
    assert result.status == "failed" and result.error["code"] == "ffmpeg_timeout"
    assert list(ctx.settings.work_dir.iterdir()) == []

    asset2 = await make_asset(client, alice, sample_video.read_bytes())
    small = FfmpegAdapter(limits=ResourceLimits(work_dir_max_bytes=120_000, max_file_bytes=10**9))
    result2 = await MediaPipeline(ctx, small).process(asset2["upload_id"])
    assert result2.status == "failed"
    assert result2.error["code"] in {"work_dir_quota_exceeded", "ffmpeg_failed", "ffmpeg_killed"}

    asset3 = await make_asset(client, alice, sample_video.read_bytes())
    tiny_files = FfmpegAdapter(limits=ResourceLimits(max_file_bytes=20_000))
    result3 = await MediaPipeline(ctx, tiny_files).process(asset3["upload_id"])
    assert result3.status == "failed" and result3.error["code"] in {"ffmpeg_failed", "ffmpeg_killed"}
    async with ctx.db.session() as db:
        assert list(await db.scalars(select(MediaSegment))) == [], "failed attempts leave no segments"


@pytest.mark.ffmpeg
async def test_ffmpeg_can_run_without_network_access(tmp_path: Path, sample_video: Path) -> None:
    if not sandbox_available():
        pytest.skip("network namespaces are not available here")
    import shutil

    shutil.copy(sample_video, tmp_path / "source.bin")
    adapter = FfmpegAdapter(sandbox="unshare-net")
    probe = await adapter.probe(tmp_path, "source.bin", "mov,mp4,m4a,3gp,3g2,mj2")
    assert probe.width == 320 and probe.has_audio
    # Inside the sandbox there is no route anywhere: a network output fails immediately.
    with pytest.raises(ProcessingError):
        await adapter.run(
            ["-f", "lavfi", "-i", "testsrc2=duration=1", "-f", "mpegts", "tcp://192.0.2.1:9"], cwd=tmp_path
        )


@pytest.mark.ffmpeg
async def test_cancellation(ctx: AppContext, client: httpx.AsyncClient, auth, sample_video: Path) -> None:
    alice = auth("alice")
    queued = await make_asset(client, alice, sample_video.read_bytes())
    job_id = (await job_of(client, alice, queued))["job"]["job_id"]
    resp = await client.post(f"/v1/processing-jobs/{job_id}/cancel", headers=alice)
    assert resp.status_code == 200 and resp.json()["status"] == "cancelled"
    assert (await job_of(client, alice, queued))["state"] == "cancelled"
    assert await Worker(ctx).run_once() is None
    assert (await client.post(f"/v1/processing-jobs/{job_id}/cancel", headers=alice)).status_code == 409
    assert (await client.get(f"/v1/processing-jobs/{job_id}", headers=auth("mallory"))).status_code == 404

    running = await make_asset(client, alice, sample_video.read_bytes())
    running_job = (await job_of(client, alice, running))["job"]["job_id"]
    pipeline = MediaPipeline(ctx)
    original = pipeline._set_stage

    async def cancel_during_transcode(job, stage, progress=0.0):  # noqa: ANN001
        await original(job, stage, progress)
        if stage.value == "transcoding":
            await client.post(f"/v1/processing-jobs/{running_job}/cancel", headers=alice)

    pipeline._set_stage = cancel_during_transcode  # type: ignore[method-assign]
    result = await pipeline.process(running["upload_id"])
    assert result.status == "cancelled"
    assert (await job_of(client, alice, running))["state"] == "cancelled"
    async with ctx.db.session() as db:
        assert list(await db.scalars(select(MediaSegment))) == []


@pytest.mark.ffmpeg
async def test_restart_recovery_after_worker_crash(
    ctx: AppContext, client: httpx.AsyncClient, auth, sample_video: Path, clock: FakeClock
) -> None:
    alice = auth("alice")
    asset = await make_asset(client, alice, sample_video.read_bytes())

    # Worker 1 claims the job and "crashes": the job stays 'running' with a lease.
    crashed = Worker(ctx, worker_id="worker-1")
    assert await crashed.claim_next() == asset["upload_id"]
    survivor = Worker(ctx, worker_id="worker-2")
    assert await survivor.claim_next() is None, "a live lease is respected"

    clock.tick(ctx.settings.job_lease_seconds + 1)  # the lease runs out
    result = await survivor.run_once()
    assert result is not None and result.status == "succeeded"
    async with ctx.db.session() as db:
        job = await db.scalar(select(ProcessingJob))
        assert job is not None and job.attempt == 2 and job.status == "succeeded"
        refs = list(await db.scalars(select(MediaSegment.storage_reference)))
        assert all(f"{job.id}-2/" in ref for ref in refs), "each attempt writes to its own prefix"
    version = await job_of(client, auth("alice"), asset)
    assert version["state"] == "ready_for_review"


async def test_job_that_keeps_crashing_is_failed_after_max_attempts(
    ctx: AppContext, client: httpx.AsyncClient, auth, clock: FakeClock
) -> None:
    alice = auth("alice")
    asset = await make_asset(client, alice, fake_media(5000))
    ctx.settings.job_max_attempts = 3
    for attempt in range(1, 4):
        worker = Worker(ctx, worker_id=f"crashy-{attempt}")
        assert await worker.claim_next() == asset["upload_id"]
        clock.tick(ctx.settings.job_lease_seconds + 1)
    assert await Worker(ctx).claim_next() is None
    version = await job_of(client, auth("alice"), asset)
    assert version["state"] == "failed"
    assert version["job"]["error"]["code"] == "max_attempts_exceeded" and version["job"]["attempt"] == 3


async def test_infrastructure_errors_are_retried_then_failed(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    alice = auth("alice")
    asset = await make_asset(client, alice, fake_media(5000))
    ctx.settings.job_max_attempts = 2

    class Boom(FfmpegAdapter):
        async def probe(self, cwd, filename, demuxer):  # noqa: ANN001
            raise OSError("disk went away")

    worker = Worker(ctx, MediaPipeline(ctx, Boom()))
    first = await worker.run_once()
    assert first is not None and first.status == "queued" and first.error["code"] == "internal_error"
    second = await worker.run_once()
    assert second is not None and second.status == "failed"
    assert (await job_of(client, alice, asset))["state"] == "failed"


async def test_two_workers_never_claim_the_same_job(ctx: AppContext, client: httpx.AsyncClient, auth) -> None:
    alice = auth("alice")
    for _ in range(3):
        await make_asset(client, alice, fake_media(5000))
    workers = [Worker(ctx, worker_id=f"w{i}") for i in range(6)]
    claims = await asyncio.gather(*(w.claim_next() for w in workers))
    claimed = [c for c in claims if c is not None]
    assert len(claimed) == 3 and len(set(claimed)) == 3
