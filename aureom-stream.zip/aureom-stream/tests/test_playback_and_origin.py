"""Playback sessions and origin delivery: authorisation, expiry, ranges, caching, logs."""

from __future__ import annotations

import io
import logging

import httpx

from aureom_stream.bootstrap import AppContext
from aureom_stream.clock import FakeClock
from aureom_stream.domain import DistributionPolicy
from aureom_stream.maintenance import sweep
from aureom_stream.observability.logging import RedactingJsonFormatter, redact
from aureom_stream.origin.client import HttpOriginAdapter, OriginError
from aureom_stream.origin.delivery import UNSATISFIABLE, parse_range

from .helpers import bearer, seed_asset, start_session

PEERS = DistributionPolicy(peer_delivery=True, peer_contribution="all_viewers")


async def test_session_reports_delivery_modes_and_contribution_is_opt_in(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=PEERS)
    plain = await start_session(client, auth("bob"), asset.asset_id)
    assert plain["delivery_modes"] == ["origin"] and plain["peer_contribution_enabled"] is False
    peer = await start_session(client, auth("bob"), asset.asset_id, peer=True)
    assert peer["delivery_modes"] == ["origin", "peer"]
    assert peer["peer_contribution_enabled"] is False, "never enabled unless the client asks"
    assert any("network address" in n for n in peer["notices"])
    opted = await start_session(client, auth("bob"), asset.asset_id, peer=True, contribute=True)
    assert opted["peer_contribution_enabled"] is True
    # Anonymous viewers may watch a public asset but never join the swarm.
    anon = await client.post(
        "/v1/playback-sessions",
        json={
            "asset_id": asset.asset_id,
            "client_capabilities": {"supported_codecs": ["avc1"], "peer_delivery": True},
            "peer_contribution_enabled": True,
        },
    )
    assert anon.status_code == 201
    assert anon.json()["delivery_modes"] == ["origin"] and anon.json()["peer_contribution_enabled"] is False
    # No distribution permission -> no peer mode, whatever the client says.
    closed = await seed_asset(ctx, visibility="public")
    session = await start_session(client, auth("bob"), closed.asset_id, peer=True, contribute=True)
    assert session["delivery_modes"] == ["origin"] and session["peer_contribution_enabled"] is False


async def test_capabilities_select_renditions(ctx: AppContext, client: httpx.AsyncClient, auth) -> None:
    asset = await seed_asset(ctx, visibility="public")

    async def create(caps: dict) -> httpx.Response:
        return await client.post(
            "/v1/playback-sessions", headers=auth("bob"),
            json={"asset_id": asset.asset_id, "client_capabilities": caps},
        )  # fmt: skip

    both = (await create({"supported_codecs": ["avc1"], "max_height": 1080})).json()
    assert [r["height"] for r in both["renditions"]] == [360, 240]
    small = (await create({"supported_codecs": ["avc1"], "max_height": 240})).json()
    assert [r["height"] for r in small["renditions"]] == [240]
    master = await client.get(small["master_playlist_url"], headers=bearer(small["session_token"]))
    assert master.text.count("#EXT-X-STREAM-INF") == 1
    hidden = both["renditions"][0]["rendition_id"]
    blocked = await client.get(
        f"/v1/playback-sessions/{small['session_id']}/renditions/{hidden}/index.m3u8",
        headers=bearer(small["session_token"]),
    )
    assert blocked.status_code == 404
    unsupported = await create({"supported_codecs": ["hvc1"]})
    assert unsupported.status_code == 422 and unsupported.json()["code"] == "no_compatible_rendition"
    malformed = await client.post("/v1/playback-sessions", headers=auth("bob"), json={"asset_id": "nope"})
    assert malformed.status_code == 422


async def test_sessions_are_short_lived_and_need_their_token(
    ctx: AppContext, client: httpx.AsyncClient, origin: httpx.AsyncClient, auth, clock: FakeClock
) -> None:
    asset = await seed_asset(ctx, visibility="private")
    session = await start_session(client, auth("alice"), asset.asset_id)
    sid = session["session_id"]
    token = bearer(session["session_token"])
    assert (await client.get(f"/v1/playback-sessions/{sid}/master.m3u8")).status_code == 401
    assert (
        await client.get(f"/v1/playback-sessions/{sid}/master.m3u8", headers=bearer("wrong"))
    ).status_code == 404
    assert (await client.get(f"/v1/playback-sessions/{sid}", headers=auth("mallory"))).status_code == 404
    info = await client.get(f"/v1/playback-sessions/{sid}", headers=token)
    assert info.status_code == 200 and info.json()["session_token"] is None  # shown once only

    clock.tick(ctx.settings.playback_session_ttl_seconds - 10)
    beat = await client.post(
        f"/v1/playback-sessions/{sid}/heartbeat", headers=token, json={"position_seconds": 4.0}
    )
    assert beat.status_code == 200 and beat.json()["origin"]["token"]
    clock.tick(ctx.settings.playback_session_ttl_seconds - 10)  # alive thanks to the heartbeat
    assert (await client.get(f"/v1/playback-sessions/{sid}/master.m3u8", headers=token)).status_code == 200

    clock.tick(ctx.settings.playback_session_ttl_seconds + 1)  # no heartbeat: it expires
    expired = await client.get(f"/v1/playback-sessions/{sid}/master.m3u8", headers=token)
    assert expired.status_code == 410 and expired.json()["code"] == "session_expired"
    seg = asset.manifest.renditions[0].init.segment_id
    late = await origin.get(f"/origin/v1/segments/{seg}", headers=bearer(beat.json()["origin"]["token"]))
    assert late.status_code in (401, 403)
    assert (await sweep(ctx))["playback_sessions_expired"] == 0  # already marked on access


async def test_origin_token_expiry_and_scope(
    ctx: AppContext, client: httpx.AsyncClient, origin: httpx.AsyncClient, auth, clock: FakeClock
) -> None:
    asset = await seed_asset(ctx, visibility="private")
    other = await seed_asset(ctx, visibility="private")
    session = await start_session(client, auth("alice"), asset.asset_id)
    token = bearer(session["origin"]["token"])
    seg = asset.manifest.renditions[0].segments[0].segment_id
    foreign = other.manifest.renditions[0].segments[0].segment_id
    assert (await origin.get(f"/origin/v1/segments/{seg}")).status_code == 401
    assert (await origin.get(f"/origin/v1/segments/{seg}", headers=bearer("garbage"))).status_code == 401
    assert (await origin.get(f"/origin/v1/segments/{seg}", headers=token)).status_code == 200
    # A token for one version cannot read another version's segments.
    assert (await origin.get(f"/origin/v1/segments/{foreign}", headers=token)).status_code == 404
    # A principal access token is not an origin token.
    assert (await origin.get(f"/origin/v1/segments/{seg}", headers=auth("alice"))).status_code == 401
    await client.post(
        f"/v1/playback-sessions/{session['session_id']}/heartbeat", headers=bearer(session["session_token"])
    )
    clock.tick(ctx.settings.origin_token_ttl_seconds + 1)
    expired = await origin.get(f"/origin/v1/segments/{seg}", headers=token)
    assert expired.status_code == 401 and expired.json()["code"] == "invalid_token"


async def test_range_requests_content_types_and_conditional_get(
    ctx: AppContext, client: httpx.AsyncClient, origin: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, visibility="private", segment_bytes=5000)
    session = await start_session(client, auth("alice"), asset.asset_id)
    token = bearer(session["origin"]["token"])
    rendition = asset.manifest.renditions[0]
    seg, init = rendition.segments[0], rendition.init
    data = asset.data[seg.segment_id]
    url = f"/origin/v1/segments/{seg.segment_id}"

    full = await origin.get(url, headers=token)
    assert full.status_code == 200 and full.content == data
    assert full.headers["accept-ranges"] == "bytes" and full.headers["content-length"] == str(len(data))
    assert full.headers["content-type"] == "video/iso.segment"
    assert full.headers["etag"] == f'"sha256-{seg.sha256}"'
    assert (await origin.get(f"/origin/v1/segments/{init.segment_id}", headers=token)).headers[
        "content-type"
    ] == "video/mp4"

    part = await origin.get(url, headers={**token, "Range": "bytes=100-199"})
    assert part.status_code == 206 and part.content == data[100:200]
    assert part.headers["content-range"] == f"bytes 100-199/{len(data)}"
    tail = await origin.get(url, headers={**token, "Range": "bytes=-50"})
    assert tail.status_code == 206 and tail.content == data[-50:]
    open_ended = await origin.get(url, headers={**token, "Range": f"bytes={len(data) - 10}-"})
    assert open_ended.content == data[-10:]
    beyond = await origin.get(url, headers={**token, "Range": f"bytes={len(data)}-"})
    assert beyond.status_code == 416 and beyond.headers["content-range"] == f"bytes */{len(data)}"
    multi = await origin.get(url, headers={**token, "Range": "bytes=0-1,5-6"})
    assert multi.status_code == 200 and multi.content == data  # multiple ranges are ignored
    head = await origin.head(url, headers=token)
    assert (
        head.status_code == 200 and head.headers["content-length"] == str(len(data)) and head.content == b""
    )
    cached = await origin.get(url, headers={**token, "If-None-Match": full.headers["etag"]})
    assert cached.status_code == 304
    stale = await origin.get(url, headers={**token, "Range": "bytes=0-9", "If-Range": '"sha256-other"'})
    assert stale.status_code == 200 and stale.content == data
    via_session = await client.get(
        f"/v1/playback-sessions/{session['session_id']}/segments/{seg.segment_id}",
        headers={**bearer(session["session_token"]), "Range": "bytes=0-9"},
    )
    assert via_session.status_code == 206 and via_session.content == data[:10]


async def test_public_and_private_cache_policies_differ(
    ctx: AppContext, client: httpx.AsyncClient, origin: httpx.AsyncClient, auth
) -> None:
    public = await seed_asset(ctx, visibility="public")
    private = await seed_asset(ctx, visibility="private")
    s_pub = await start_session(client, auth("alice"), public.asset_id)
    s_priv = await start_session(client, auth("alice"), private.asset_id)
    pub = await origin.get(
        f"/origin/v1/segments/{public.manifest.renditions[0].segments[0].segment_id}",
        headers=bearer(s_pub["origin"]["token"]),
    )
    priv = await origin.get(
        f"/origin/v1/segments/{private.manifest.renditions[0].segments[0].segment_id}",
        headers=bearer(s_priv["origin"]["token"]),
    )
    assert pub.headers["cache-control"] == "public, max-age=3600, immutable"
    assert priv.headers["cache-control"] == "private, max-age=600, immutable"
    assert "Authorization" in priv.headers["vary"]
    # Per-session playlists are never cacheable, even for public assets.
    for session in (s_pub, s_priv):
        master = await client.get(session["master_playlist_url"], headers=bearer(session["session_token"]))
        assert master.headers["cache-control"] == "private, no-store"


async def test_query_token_playlists_work_for_header_less_players(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, visibility="private")
    session = await start_session(client, auth("alice"), asset.asset_id)
    st = session["session_token"]
    master = await client.get(session["master_playlist_url"], params={"st": st})
    assert master.status_code == 200 and f"index.m3u8?st={st}" in master.text
    rendition = session["renditions"][0]
    media = await client.get(rendition["playlist_url"], params={"st": st})
    line = next(ln for ln in media.text.splitlines() if ln.startswith("../../segments/"))
    resolved = httpx.URL(f"http://api.test{rendition['playlist_url']}").join(line)
    assert (await client.get(str(resolved))).status_code == 200
    # Header-authenticated playlists carry no token at all.
    clean = await client.get(session["master_playlist_url"], headers=bearer(st))
    assert st not in clean.text


async def test_tokens_and_signed_urls_stay_out_of_logs(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(RedactingJsonFormatter())
    root = logging.getLogger("aureom")
    root.addHandler(handler)
    root.setLevel(logging.DEBUG)
    try:
        asset = await seed_asset(ctx, visibility="private")
        headers = auth("alice")
        session = await start_session(client, headers, asset.asset_id)
        st = session["session_token"]
        await client.get(session["master_playlist_url"], params={"st": st})
        logging.getLogger("aureom.test").info("fetching %s?st=%s with %s", "/x", st, headers["Authorization"])
        logging.getLogger("aureom.test").info("origin token=%s", session["origin"]["token"])
    finally:
        root.removeHandler(handler)
    logged = stream.getvalue()
    assert "/v1/playback-sessions/{session_id}/master.m3u8" in logged  # route template only
    assert st not in logged and session["session_id"] not in logged
    assert headers["Authorization"].split()[1] not in logged
    assert session["origin"]["token"] not in logged
    assert "[REDACTED" in logged
    url = "https://s3.example/b/k?X-Amz-Credential=AKIA123&X-Amz-Signature=deadbeef&partNumber=1"
    cleaned = redact(url)
    assert "deadbeef" not in cleaned and "AKIA123" not in cleaned and "partNumber=1" in cleaned


async def test_concurrent_session_limit(ctx: AppContext, client: httpx.AsyncClient, auth) -> None:
    ctx.settings.max_sessions_per_principal = 2
    asset = await seed_asset(ctx, visibility="public")
    first = await start_session(client, auth("bob"), asset.asset_id)
    await start_session(client, auth("bob"), asset.asset_id)
    third = await client.post("/v1/playback-sessions", headers=auth("bob"), json={"asset_id": asset.asset_id})
    assert third.status_code == 429 and third.json()["code"] == "too_many_sessions"
    await client.delete(
        f"/v1/playback-sessions/{first['session_id']}", headers=bearer(first["session_token"])
    )
    await start_session(client, auth("bob"), asset.asset_id)


async def test_health_endpoints_and_metrics(client: httpx.AsyncClient, origin: httpx.AsyncClient) -> None:
    assert (await client.get("/healthz")).json() == {"status": "ok"}
    ready = (await client.get("/readyz")).json()
    assert ready["ready"] is True and set(ready["checks"]) == {"database", "object_store", "coordination"}
    assert (await origin.get("/readyz")).json()["ready"] is True
    metrics = await client.get("/metrics")
    assert metrics.status_code == 200 and "aureom_http_requests_total" in metrics.text
    jwks = (await client.get("/.well-known/jwks.json")).json()
    assert jwks["keys"][0]["crv"] == "Ed25519" and "d" not in jwks["keys"][0]


async def test_origin_adapter_retries_are_bounded_and_health_is_tracked(
    ctx: AppContext, client: httpx.AsyncClient, auth, clock: FakeClock
) -> None:
    from aureom_stream.origin.app import create_origin_app

    asset = await seed_asset(ctx, visibility="private")
    session = await start_session(client, auth("alice"), asset.asset_id)
    descriptor = asset.manifest.media_segments(asset.manifest.renditions[0].rendition_id)[0]
    app = create_origin_app(ctx=ctx)
    calls = {"n": 0, "fail": 0}

    async def flaky(request: httpx.Request) -> httpx.Response:
        calls["n"] += 1
        if calls["n"] <= calls["fail"]:
            return httpx.Response(503)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app)) as inner:
            return await inner.get(str(request.url), headers=request.headers)

    http = httpx.AsyncClient(transport=httpx.MockTransport(flaky))
    adapter = HttpOriginAdapter(
        base_url="http://origin.test", token_provider=lambda: session["origin"]["token"],
        clock=clock, client=http, max_attempts=3, failure_threshold=3, cooldown_seconds=5,
    )  # fmt: skip
    calls.update(n=0, fail=2)  # two transient failures, then success
    data = await clock.run(adapter.fetch_segment(descriptor))
    assert data == asset.data[descriptor.segment_id] and calls["n"] == 3 and adapter.healthy

    calls.update(n=0, fail=99)
    try:
        await clock.run(adapter.fetch_segment(descriptor))
        raise AssertionError("expected OriginError")
    except OriginError as exc:
        assert exc.kind == "unavailable"
    assert calls["n"] == 3, "retries are bounded"
    assert adapter.healthy is False, "circuit opens after repeated failures"
    await clock.advance(6)
    assert adapter.healthy is True
    calls.update(n=0, fail=0)
    denied = HttpOriginAdapter(
        base_url="http://origin.test", token_provider=lambda: "bad", clock=clock, client=http
    )
    try:
        await clock.run(denied.fetch_segment(descriptor))
        raise AssertionError("expected OriginError")
    except OriginError as exc:
        assert exc.kind == "denied" and calls["n"] == 1, "authorisation failures are not retried"
    await http.aclose()


def test_range_parser() -> None:
    assert parse_range(None, 100) is None
    assert parse_range("bytes=0-9", 100) == (0, 9)
    assert parse_range("bytes=90-", 100) == (90, 99)
    assert parse_range("bytes=90-500", 100) == (90, 99)
    assert parse_range("bytes=-10", 100) == (90, 99)
    assert parse_range("bytes=-500", 100) == (0, 99)
    assert parse_range("bytes=100-", 100) == UNSATISFIABLE
    assert parse_range("bytes=-0", 100) == UNSATISFIABLE
    assert parse_range("items=0-9", 100) is None
    assert parse_range("bytes=9-0", 100) is None
    assert parse_range("bytes=0-1,4-5", 100) is None
    assert parse_range("bytes=abc", 100) is None
