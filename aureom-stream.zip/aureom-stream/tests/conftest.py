"""Shared fixtures.

Default: SQLite (file per test) + local object store + in-memory coordination + a
virtual clock, so the suite needs nothing but Python (and FFmpeg for media tests).
Set ``AUREOM_TEST_DATABASE_URL=postgresql+asyncpg://...`` to run the same suite
against PostgreSQL.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from collections.abc import AsyncIterator
from pathlib import Path

import httpx
import pytest
import pytest_asyncio
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from aureom_stream.access.tokens import TokenService
from aureom_stream.api.app import create_app
from aureom_stream.bootstrap import AppContext, build_context
from aureom_stream.clock import FakeClock
from aureom_stream.config import Settings
from aureom_stream.origin.app import create_origin_app
from aureom_stream.persistence.models import Base

from . import helpers

HAVE_FFMPEG = shutil.which("ffmpeg") is not None and shutil.which("ffprobe") is not None


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    for item in items:
        if "ffmpeg" in item.keywords and not HAVE_FFMPEG:
            item.add_marker(pytest.mark.skip(reason="ffmpeg/ffprobe not installed"))
        if "redis" in item.keywords and shutil.which("redis-server") is None:
            item.add_marker(pytest.mark.skip(reason="redis-server not installed"))


@pytest.fixture
def clock() -> FakeClock:
    return FakeClock()


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    url = os.environ.get("AUREOM_TEST_DATABASE_URL") or f"sqlite+aiosqlite:///{tmp_path}/test.db"
    return Settings(
        _env_file=None,
        env="test",
        database_url=url,
        storage_local_root=tmp_path / "objects",
        work_dir=tmp_path / "work",
        signing_key_path=tmp_path / "keys" / "signing.pem",
        upload_part_size_bytes=64 * 1024,
        upload_max_bytes=64 * 1024 * 1024,
        upload_quota_bytes=128 * 1024 * 1024,
        segment_duration_seconds=2.0,
        max_renditions=2,
        ffmpeg_timeout_seconds=120,
        origin_base_url="http://origin.test",
        public_base_url="http://api.test",
    )


@pytest_asyncio.fixture
async def ctx(settings: Settings, clock: FakeClock) -> AsyncIterator[AppContext]:
    tokens = TokenService(Ed25519PrivateKey.generate(), issuer=settings.issuer, clock=clock)
    context = build_context(settings, clock=clock, tokens=tokens)
    if context.db.is_postgres:
        async with context.db.engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
    await context.db.create_all()
    yield context
    await context.close()


@pytest_asyncio.fixture
async def client(ctx: AppContext) -> AsyncIterator[httpx.AsyncClient]:
    transport = httpx.ASGITransport(app=create_app(ctx=ctx))
    async with httpx.AsyncClient(transport=transport, base_url="http://api.test") as c:
        yield c


@pytest_asyncio.fixture
async def origin(ctx: AppContext) -> AsyncIterator[httpx.AsyncClient]:
    transport = httpx.ASGITransport(app=create_origin_app(ctx=ctx))
    async with httpx.AsyncClient(transport=transport, base_url="http://origin.test") as c:
        yield c


@pytest.fixture
def auth(ctx: AppContext):  # noqa: ANN201
    return lambda user, *scopes: helpers.auth(ctx, user, *scopes)


@pytest.fixture(scope="session")
def sample_video(tmp_path_factory: pytest.TempPathFactory) -> Path:
    """A 6-second synthetic clip (FFmpeg ``testsrc2`` + ``sine``): generated, not
    third-party content."""
    if not HAVE_FFMPEG:
        pytest.skip("ffmpeg not installed")
    path = tmp_path_factory.mktemp("media") / "sample.mp4"
    subprocess.run(
        [
            "ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", "testsrc2=size=320x180:rate=24:duration=6",
            "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000:duration=6",
            "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "64k", "-shortest", "-f", "mp4", str(path),
        ],
        check=True,
    )  # fmt: skip
    return path
