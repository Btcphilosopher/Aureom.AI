"""Peer agents talking over real loopback sockets to each other, with the control
plane and origin mounted in-process. Real time, real HTTP, real hashes."""

from __future__ import annotations

import asyncio
import time
from collections.abc import AsyncIterator
from pathlib import Path

import aiohttp
import httpx
import pytest
import pytest_asyncio
from sqlalchemy import select

from aureom_stream.api.app import create_app
from aureom_stream.bootstrap import AppContext
from aureom_stream.clock import SystemClock
from aureom_stream.domain import DistributionPolicy
from aureom_stream.maintenance import sweep
from aureom_stream.origin.app import create_origin_app
from aureom_stream.peer_agent.agent import AgentConfig, ContributionSettings, PeerAgent
from aureom_stream.peer_agent.pki import create_dev_pki
from aureom_stream.persistence.models import TransferReceipt
from aureom_stream.playback.harness import PlaybackScript
from aureom_stream.scheduler.scheduler import SchedulerLimits

from .helpers import Seeded, seed_asset

pytestmark = pytest.mark.slow
OPEN = DistributionPolicy(peer_delivery=True, peer_contribution="all_viewers")
FAST = PlaybackScript(speed=4.0, tick_seconds=0.05)
LIMITS = SchedulerLimits(urgent_window_seconds=0.6, origin_reserve_seconds=0.3, peer_attempt_timeout=2.0)


@pytest.fixture
def clock() -> SystemClock:  # these tests run in real time
    return SystemClock()


class Net:
    def __init__(self, ctx: AppContext, tmp: Path) -> None:
        self.ctx = ctx
        self.tmp = tmp
        self.api = create_app(ctx=ctx)
        self.origin = create_origin_app(ctx=ctx)
        self.agents: list[PeerAgent] = []
        self._n = 0

    async def agent(
        self, *, contribute: bool = True, tls=None, limits: SchedulerLimits = LIMITS, **contribution
    ) -> PeerAgent:
        self._n += 1
        config = AgentConfig(
            control_url="http://api.test",
            cache_dir=self.tmp / f"agent{self._n}",
            name=f"agent{self._n}",
            tls=tls,
            limits=limits,
            tick_seconds=0.1,
            enable_fault_injection=True,
            contribution=ContributionSettings(
                enabled=contribute,
                background_agent=contribution.pop("background_agent", True),
                **contribution,
            ),
        )
        agent = PeerAgent(
            config,
            clock=self.ctx.clock,
            control_http=httpx.AsyncClient(transport=httpx.ASGITransport(app=self.api)),
            origin_http=httpx.AsyncClient(transport=httpx.ASGITransport(app=self.origin)),
        )
        await agent.start()
        self.agents.append(agent)
        return agent

    def token(self, user: str) -> str:
        return self.ctx.tokens.mint_principal_token(user, [], ttl=600)


@pytest_asyncio.fixture
async def net(ctx: AppContext, tmp_path: Path) -> AsyncIterator[Net]:
    network = Net(ctx, tmp_path)
    yield network
    for agent in network.agents:
        await agent.stop()


async def seeded(ctx: AppContext, **kw) -> Seeded:
    return await seed_asset(
        ctx, visibility="public", distribution=OPEN, segments=6, segment_bytes=24_000, **kw
    )


async def test_second_agent_fetches_verified_segments_from_first(net: Net, ctx: AppContext) -> None:
    asset = await seeded(ctx)
    a, b = await net.agent(), await net.agent()

    sa = await a.open_session(net.token("alice"), asset.asset_id)
    report_a = await a.play(sa, script=FAST)
    assert report_a.completed and report_a.stalls == 0
    assert sa.metrics.peer_bytes == 0 and sa.metrics.origin_segments == 7  # nobody to fetch from
    assert len(a.cache) == 7

    sb = await b.open_session(net.token("bob"), asset.asset_id)
    report_b = await b.play(sb, script=FAST)
    assert report_b.completed and report_b.stalls == 0
    assert sb.metrics.peer_segments >= 3, sb.metrics.snapshot()
    assert sb.metrics.origin_segments >= 1  # init + the first, urgent segment
    assert sb.metrics.peer_segments + sb.metrics.origin_segments == 7
    assert sb.metrics.verification_failures == 0
    assert a.served_segments == sb.metrics.peer_segments
    # Every byte B holds matches the signed manifest.
    best = max(sb.manifest.renditions, key=lambda r: r.bandwidth).rendition_id
    for seg in sb.manifest.media_segments(best):
        assert await b.cache.get(seg.segment_id) == asset.data[seg.segment_id]

    await asyncio.sleep(0.3)  # let both sides post receipts
    async with ctx.db.session() as db:
        receipts = list(await db.scalars(select(TransferReceipt)))
    roles = {r.role for r in receipts}
    assert roles == {"receiver", "sender"}
    assert any(r.corroborated for r in receipts)


async def test_corrupted_segment_from_peer_is_rejected(net: Net, ctx: AppContext) -> None:
    asset = await seeded(ctx)
    a, b = await net.agent(), await net.agent()
    await a.play(await a.open_session(net.token("alice"), asset.asset_id), script=FAST)
    a.faults["corrupt"] = True  # A now serves flipped bytes

    sb = await b.open_session(net.token("bob"), asset.asset_id)
    report = await b.play(sb, script=FAST)
    assert report.completed
    assert sb.metrics.verification_failures >= 1
    assert sb.metrics.peer_segments == 0, "no corrupted segment was accepted"
    assert sb.metrics.peer_failures.get("hash_mismatch", 0) >= 1
    best = max(sb.manifest.renditions, key=lambda r: r.bandwidth).rendition_id
    for seg in sb.manifest.media_segments(best):
        assert await b.cache.get(seg.segment_id) == asset.data[seg.segment_id]
    await asyncio.sleep(0.3)
    async with ctx.db.session() as db:
        outcomes = {r.outcome for r in await db.scalars(select(TransferReceipt)) if r.role == "receiver"}
    assert "corrupt" in outcomes


async def test_origin_fallback_when_serving_peer_disconnects(net: Net, ctx: AppContext) -> None:
    asset = await seed_asset(ctx, visibility="public", distribution=OPEN, segments=10, segment_bytes=24_000)
    short_window = SchedulerLimits(
        urgent_window_seconds=0.6, origin_reserve_seconds=0.3, peer_attempt_timeout=2.0,
        prefetch_window_seconds=4.0,
    )  # fmt: skip
    a, c = await net.agent(), await net.agent(limits=short_window)
    await a.play(await a.open_session(net.token("alice"), asset.asset_id), script=FAST)

    sc = await c.open_session(net.token("carol"), asset.asset_id)

    async def unplug() -> None:
        await asyncio.sleep(1.5)
        assert a._runner is not None
        await a._runner.cleanup()  # the peer's socket disappears without deregistering

    killer = asyncio.ensure_future(unplug())
    report = await c.play(sc, script=PlaybackScript(speed=4.0, tick_seconds=0.05))
    await killer
    assert report.completed, report
    assert report.stalls == 0, "origin fallback kept playback inside its deadlines"
    assert sc.metrics.peer_segments >= 1, "peers were used while the peer was there"
    assert sc.metrics.origin_fallbacks >= 1
    assert sc.metrics.peer_failures.get("unreachable", 0) >= 1
    assert sc.metrics.peer_segments + sc.metrics.origin_segments == 11


async def test_upload_cap_is_enforced(net: Net, ctx: AppContext) -> None:
    asset = await seeded(ctx)
    cap_kbps = 800
    a, b = await net.agent(upload_kbps_cap=cap_kbps), await net.agent()
    await a.play(await a.open_session(net.token("alice"), asset.asset_id), script=FAST)
    sb = await b.open_session(net.token("bob"), asset.asset_id)
    best = max(sb.manifest.renditions, key=lambda r: r.bandwidth).rendition_id
    segments = sb.manifest.media_segments(best)[1:5]
    started = time.monotonic()
    results = await asyncio.gather(*(sb.scheduler.fetch(sb.client, s, time.time() + 30) for s in segments))
    elapsed = time.monotonic() - started
    assert all(r.source == "peer" for r in results)
    sent = sum(len(r.data) for r in results)
    burst = cap_kbps * 1000 / 8 * 0.25
    measured_kbps = (sent - burst) * 8 / 1000 / elapsed
    assert measured_kbps <= cap_kbps * 1.10, f"{measured_kbps:.0f} kbit/s over a {cap_kbps} cap"
    assert a.stats()["upload"]["served_bytes"] == sent


async def test_pause_and_metered_stop_contribution(net: Net, ctx: AppContext) -> None:
    asset = await seeded(ctx)
    a, b = await net.agent(), await net.agent()
    await a.play(await a.open_session(net.token("alice"), asset.asset_id), script=FAST)
    sb = await b.open_session(net.token("bob"), asset.asset_id)
    best = max(sb.manifest.renditions, key=lambda r: r.bandwidth).rendition_id
    ids = [s.segment_id for s in sb.manifest.media_segments(best)]
    directory = sb.scheduler._directory
    assert directory is not None
    assert len(await directory.discover(ids)) == 1

    await a.set_contribution(paused=True)
    assert await directory.discover(ids) == []
    await a.set_contribution(paused=False)
    peers = await directory.discover(ids)
    assert len(peers) == 1

    grant = await directory.authorise_transfer(peers[0], [ids[2]])
    await a.set_contribution(metered=True)  # metered network: stop, even with a live grant
    assert await directory.discover(ids) == []
    async with aiohttp.ClientSession() as http:
        url = f"http://127.0.0.1:{a.port}/peer/v1/segments/{ids[2]}"
        async with http.get(url, headers={"Authorization": f"Bearer {grant.token}"}) as resp:
            assert resp.status == 403


async def test_contribution_stops_when_player_closes_without_background_agent(
    net: Net, ctx: AppContext
) -> None:
    asset = await seeded(ctx)
    a = await net.agent(background_agent=False)
    b = await net.agent()
    sa = await a.open_session(net.token("alice"), asset.asset_id)
    await a.play(sa, script=FAST)
    assert sa.closed and sa.closed_reason == "player_closed"
    assert len(a.cache) == 0 and a.sessions == {}
    sb = await b.open_session(net.token("bob"), asset.asset_id)
    best = max(sb.manifest.renditions, key=lambda r: r.bandwidth).rendition_id
    ids = [s.segment_id for s in sb.manifest.media_segments(best)]
    assert await sb.scheduler._directory.discover(ids) == []  # type: ignore[union-attr]


async def test_non_contributing_agent_is_never_listed_and_serves_nothing(net: Net, ctx: AppContext) -> None:
    asset = await seeded(ctx)
    a = await net.agent(contribute=False)  # the default: opt-in was not given
    b = await net.agent()
    sa = await a.open_session(net.token("alice"), asset.asset_id)
    await a.play(sa, script=FAST)
    assert sa.contribute is False
    sb = await b.open_session(net.token("bob"), asset.asset_id)
    report = await b.play(sb, script=FAST)
    assert report.completed and sb.metrics.peer_segments == 0 and a.served_segments == 0


async def test_grant_replay_expiry_and_scope_are_enforced_by_serving_peer(net: Net, ctx: AppContext) -> None:
    asset = await seeded(ctx)
    a, b = await net.agent(), await net.agent()
    await a.play(await a.open_session(net.token("alice"), asset.asset_id), script=FAST)
    sb = await b.open_session(net.token("bob"), asset.asset_id)
    best = max(sb.manifest.renditions, key=lambda r: r.bandwidth).rendition_id
    ids = [s.segment_id for s in sb.manifest.media_segments(best)]
    directory = sb.scheduler._directory
    assert directory is not None
    peer = (await directory.discover(ids))[0]
    grant = await directory.authorise_transfer(peer, [ids[1]])
    base = f"http://127.0.0.1:{a.port}/peer/v1/segments/"

    async with aiohttp.ClientSession() as http:

        async def get(segment_id: str, token: str | None) -> int:
            headers = {"Authorization": f"Bearer {token}"} if token else {}
            async with http.get(base + segment_id, headers=headers) as resp:
                await resp.read()
                return resp.status

        assert await get(ids[1], None) == 401  # no grant
        assert await get(ids[1], "not-a-token") == 401  # malformed
        assert await get(ids[2], grant.token) == 403  # segment not in the grant
        assert await get(ids[1], grant.token) == 200
        assert await get(ids[1], grant.token) == 403  # replay of a used grant
        # A grant addressed to a different serving peer is useless here.
        other = ctx.tokens.sign(
            {"sub": "prs_x", "jti": "tgr_x", "ver": asset.version_id, "segs": [ids[3]], "max_bytes": 10**6},
            typ="transfer+jwt", audience="prs_someone_else", ttl=30,
        )  # fmt: skip
        assert await get(ids[3], other) == 401
        expired = ctx.tokens.sign(
            {"sub": "prs_x", "jti": "tgr_y", "ver": asset.version_id, "segs": [ids[3]], "max_bytes": 10**6},
            typ="transfer+jwt", audience=peer.peer_id, ttl=-5,
        )  # fmt: skip
        assert await get(ids[3], expired) == 401
        assert await get("../../etc/passwd", grant.token) in (403, 404)
    assert a.refused.get("grant_replayed") == 1 and a.refused.get("grant_expired") == 1


async def test_session_expiry_cleans_up_registry_and_cache(net: Net, ctx: AppContext) -> None:
    asset = await seeded(ctx)
    ctx.settings.playback_session_ttl_seconds = 1.0
    ctx.settings.playback_heartbeat_seconds = 0.25
    ctx.settings.peer_session_ttl_seconds = 1.0
    a, b = await net.agent(), await net.agent()
    sa = await a.open_session(net.token("alice"), asset.asset_id)
    await a.play(sa, script=FAST)
    assert len(a.cache) == 7
    sb = await b.open_session(net.token("bob"), asset.asset_id)
    best = max(sb.manifest.renditions, key=lambda r: r.bandwidth).rendition_id
    ids = [s.segment_id for s in sb.manifest.media_segments(best)]
    directory = sb.scheduler._directory
    assert directory is not None and len(await directory.discover(ids)) == 1

    a.faults["suspend_heartbeats"] = True  # A's app freezes: no more heartbeats
    await asyncio.sleep(1.4)
    counts = await sweep(ctx)
    assert counts["playback_sessions_expired"] >= 1 and counts["peer_sessions_expired"] >= 1
    await b._heartbeat(sb)
    if not sb.closed:
        assert await directory.discover(ids) == []  # A is gone from discovery
    a.faults["suspend_heartbeats"] = False
    await asyncio.sleep(0.5)  # A's next heartbeat learns the session is gone
    assert sa.closed and sa.closed_reason == "expired"
    assert len(a.cache) == 0, "cached material is removed with the session that justified it"


async def test_mutual_tls_transport_with_certificate_bound_grants(net: Net, ctx: AppContext) -> None:
    asset = await seeded(ctx)
    pki = create_dev_pki(net.tmp / "pki", ["a", "b", "mallory"])
    a = await net.agent(tls=pki["a"])
    b = await net.agent(tls=pki["b"])
    assert a.transport.name == "mtls-http"
    await a.play(await a.open_session(net.token("alice"), asset.asset_id), script=FAST)
    sb = await b.open_session(net.token("bob"), asset.asset_id)
    report = await b.play(sb, script=FAST)
    assert report.completed and sb.metrics.peer_segments >= 3
    assert sb.metrics.verification_failures == 0

    # A certificate from the same CA but not the one the grant is bound to is refused.
    sb2 = await b.open_session(net.token("bob"), asset.asset_id)
    best = max(sb2.manifest.renditions, key=lambda r: r.bandwidth).rendition_id
    ids = [s.segment_id for s in sb2.manifest.media_segments(best)]
    directory = sb2.scheduler._directory
    assert directory is not None
    peer = next(p for p in await directory.discover(ids) if p.port == a.port)
    grant = await directory.authorise_transfer(peer, [ids[4]])
    from aureom_stream.transports.http import client_ssl_context

    stolen = client_ssl_context(
        ca_path=pki["mallory"].ca, cert_path=pki["mallory"].cert, key_path=pki["mallory"].key
    )
    async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=stolen)) as http:
        url = f"https://127.0.0.1:{a.port}/peer/v1/segments/{ids[4]}"
        async with http.get(url, headers={"Authorization": f"Bearer {grant.token}"}) as resp:
            assert resp.status == 403
    assert a.refused.get("grant_certificate_mismatch") == 1
    # No client certificate at all: the TLS handshake itself fails.
    import ssl

    anonymous = ssl.create_default_context(cafile=str(pki["a"].ca))
    anonymous.check_hostname = False
    async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=anonymous)) as http:
        with pytest.raises(aiohttp.ClientError):
            async with http.get(f"https://127.0.0.1:{a.port}/peer/v1/health") as resp:
                await resp.read()
