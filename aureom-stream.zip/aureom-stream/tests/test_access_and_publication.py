"""Access enforcement, publication, withdrawal, versioning and metadata isolation."""

from __future__ import annotations

import httpx
import pytest
from sqlalchemy import select

from aureom_stream.access.service import AccessService
from aureom_stream.bootstrap import AppContext
from aureom_stream.clock import FakeClock
from aureom_stream.domain import ANONYMOUS, DistributionPolicy
from aureom_stream.errors import Forbidden, NotFound
from aureom_stream.manifests.version_manifest import ManifestError, verify_manifest
from aureom_stream.persistence.models import AssetVersion, MediaSegment

from .helpers import bearer, fake_media, principal, seed_asset, start_session, upload_bytes


async def test_private_upload_does_not_become_discoverable(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    private = await seed_asset(ctx, owner="alice", visibility="private")
    public = await seed_asset(ctx, owner="alice", visibility="public")
    unlisted = await seed_asset(ctx, owner="alice", visibility="unlisted")

    def ids(resp: httpx.Response) -> set[str]:
        return {a["asset_id"] for a in resp.json()["assets"]}

    assert ids(await client.get("/v1/assets")) == {public.asset_id}  # anonymous
    assert ids(await client.get("/v1/assets", headers=auth("mallory"))) == {public.asset_id}
    assert ids(await client.get("/v1/assets", headers=auth("alice"))) == {
        private.asset_id, public.asset_id, unlisted.asset_id,
    }  # fmt: skip
    # Existence of the private asset is not revealed to others.
    stranger = await client.get(f"/v1/assets/{private.asset_id}", headers=auth("mallory"))
    assert stranger.status_code == 404 and stranger.json()["code"] == "not_found"
    assert (await client.get(f"/v1/assets/{private.asset_id}")).status_code == 404
    assert (
        await client.get(f"/v1/assets/{private.asset_id}/versions", headers=auth("mallory"))
    ).status_code == 404
    # Unlisted: reachable with the id, but never listed.
    assert (await client.get(f"/v1/assets/{unlisted.asset_id}", headers=auth("mallory"))).status_code == 200
    public_view = (await client.get(f"/v1/assets/{public.asset_id}")).json()
    assert public_view["owner_id"] is None and public_view["versions"][0]["job"] is None


async def test_public_listing_needs_explicit_confirmation(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    alice = auth("alice")
    asset = await seed_asset(ctx, owner="alice", visibility="private", publish=False)
    url = f"/v1/assets/{asset.asset_id}/versions/{asset.version_id}/publish"
    refused = await client.post(url, headers=alice, json={"visibility": "public"})
    assert refused.status_code == 422 and refused.json()["code"] == "public_confirmation_required"
    assert (await client.get("/v1/assets")).json()["assets"] == []
    kept_private = await client.post(url, headers=alice)
    assert kept_private.status_code == 200 and kept_private.json()["visibility"] == "private"
    assert (await client.get("/v1/assets")).json()["assets"] == []


async def test_publishing_needs_permission_and_a_completed_job(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    alice = auth("alice")
    upload = await upload_bytes(client, alice, fake_media(5000))
    created = await client.post(
        "/v1/assets", headers=alice,
        json={
            "upload_id": upload["upload_id"], "title": "T",
            "rights_declaration": {"basis": "owner", "statement": "mine"},
        },
    )  # fmt: skip
    assert created.status_code == 201, created.text
    asset = created.json()
    version_id = asset["versions"][0]["version_id"]
    url = f"/v1/assets/{asset['asset_id']}/versions/{version_id}/publish"
    not_ready = await client.post(url, headers=alice)
    assert not_ready.status_code == 409 and not_ready.json()["code"] == "processing_not_complete"

    ready = await seed_asset(ctx, owner="alice", publish=False)
    url = f"/v1/assets/{ready.asset_id}/versions/{ready.version_id}/publish"
    no_scope = await client.post(url, headers=auth("alice", "media:upload"))
    assert no_scope.status_code == 403 and no_scope.json()["code"] == "publish_not_permitted"
    not_owner = await client.post(url, headers=auth("mallory"))
    assert not_owner.status_code == 404
    ok = await client.post(url, headers=alice)
    assert ok.status_code == 200 and ok.json()["manifest_digest"]
    twice = await client.post(url, headers=alice)
    assert twice.status_code == 409 and twice.json()["code"] == "already_published"
    # An upload can back exactly one version; rights declaration is mandatory.
    reuse = await client.post(
        "/v1/assets", headers=alice,
        json={"upload_id": upload["upload_id"], "title": "again",
              "rights_declaration": {"basis": "owner", "statement": "mine"}},
    )  # fmt: skip
    assert reuse.status_code == 409 and reuse.json()["code"] == "upload_in_use"
    missing = await client.post(
        "/v1/assets", headers=alice, json={"upload_id": upload["upload_id"], "title": "x"}
    )
    assert missing.status_code == 422


async def test_view_offline_and_contribution_are_separate_permissions(ctx: AppContext) -> None:
    policy = DistributionPolicy(peer_delivery=True, offline_download="granted", peer_contribution="granted")
    asset = await seed_asset(ctx, owner="alice", visibility="private", distribution=policy)
    bob, carol = principal("bob", "x"), principal("carol", "x")
    async with ctx.db.session() as db:
        from aureom_stream.catalogue.service import CatalogueService
        from aureom_stream.persistence.models import Permission

        svc = CatalogueService(ctx, db)
        await svc.grant(
            principal("alice"), asset.asset_id, grantee="bob", permission=Permission.VIEW, ttl_seconds=None
        )
        await svc.grant(
            principal("alice"), asset.asset_id, grantee="carol", permission=Permission.VIEW, ttl_seconds=None
        )
        await svc.grant(
            principal("alice"), asset.asset_id, grantee="carol", permission=Permission.OFFLINE_DOWNLOAD,
            ttl_seconds=None,
        )  # fmt: skip
    async with ctx.db.session() as db:
        access = AccessService(db, ctx.clock)
        bob_grant = await access.authorise_playback(bob, asset.version_id)
        assert bob_grant.peer_delivery and not bob_grant.may_contribute
        with pytest.raises(Forbidden) as offline_denied:
            await access.authorise_offline(bob, asset.version_id)
        assert offline_denied.value.code == "offline_not_permitted"
        assert (await access.authorise_offline(carol, asset.version_id)).asset_id == asset.asset_id
        assert not (await access.authorise_playback(carol, asset.version_id)).may_contribute
        with pytest.raises(NotFound):
            await access.authorise_playback(principal("mallory", "x"), asset.version_id)
        with pytest.raises(NotFound):
            await access.authorise_playback(ANONYMOUS, asset.version_id)


async def test_grants_expire_and_can_be_revoked(
    ctx: AppContext, client: httpx.AsyncClient, auth, clock: FakeClock
) -> None:
    asset = await seed_asset(ctx, owner="alice", visibility="private")
    alice = auth("alice")
    grant = await client.post(
        f"/v1/assets/{asset.asset_id}/grants", headers=alice,
        json={"principal_id": "bob", "permission": "view", "ttl_seconds": 100},
    )  # fmt: skip
    assert grant.status_code == 201
    await start_session(client, auth("bob"), asset.asset_id)
    clock.tick(101)
    expired = await client.post(
        "/v1/playback-sessions", headers=auth("bob"), json={"asset_id": asset.asset_id}
    )
    assert expired.status_code == 404, "an expired grant authorises nothing"

    second = (
        await client.post(
            f"/v1/assets/{asset.asset_id}/grants", headers=auth("alice"),
            json={"principal_id": "bob", "permission": "view"},
        )
    ).json()  # fmt: skip
    await start_session(client, auth("bob"), asset.asset_id)
    revoke = await client.delete(
        f"/v1/assets/{asset.asset_id}/grants/{second['grant_id']}", headers=auth("alice")
    )
    assert revoke.status_code == 204
    after = await client.post("/v1/playback-sessions", headers=auth("bob"), json={"asset_id": asset.asset_id})
    assert after.status_code == 404
    forbidden = await client.post(
        f"/v1/assets/{asset.asset_id}/grants", headers=auth("mallory"),
        json={"principal_id": "mallory", "permission": "manage"},
    )  # fmt: skip
    assert forbidden.status_code == 404


async def test_withdrawal_stops_new_authorisations_and_controlled_delivery(
    ctx: AppContext, client: httpx.AsyncClient, origin: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, owner="alice", visibility="public")
    session = await start_session(client, auth("bob"), asset.asset_id)
    seg = asset.manifest.renditions[0].segments[0].segment_id
    ok = await origin.get(f"/origin/v1/segments/{seg}", headers=bearer(session["origin"]["token"]))
    assert ok.status_code == 200

    resp = await client.post(
        f"/v1/assets/{asset.asset_id}/versions/{asset.version_id}/withdraw", headers=auth("alice"),
        json={"reason": "rights dispute"},
    )  # fmt: skip
    assert resp.status_code == 200 and resp.json()["withdrawn_at"]
    assert "cannot erase copies" in resp.json()["notice"]

    # Existing session, its still-unexpired origin token and new sessions all stop.
    token = bearer(session["session_token"])
    assert (await client.get(session["master_playlist_url"], headers=token)).status_code == 410
    assert (
        await client.post(f"/v1/playback-sessions/{session['session_id']}/heartbeat", headers=token)
    ).status_code == 410
    after = await origin.get(f"/origin/v1/segments/{seg}", headers=bearer(session["origin"]["token"]))
    assert after.status_code in (403, 410)
    new = await client.post("/v1/playback-sessions", headers=auth("bob"), json={"asset_id": asset.asset_id})
    assert new.status_code == 404
    assert (await client.get("/v1/assets")).json()["assets"] == []
    # Idempotent, and the bytes are retained (immutable version; audit / reinstatement).
    again = await client.post(
        f"/v1/assets/{asset.asset_id}/versions/{asset.version_id}/withdraw", headers=auth("alice")
    )
    assert again.status_code == 200


async def test_versions_are_immutable_and_manifests_are_versioned(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    v1 = await seed_asset(ctx, owner="alice", visibility="public")
    v2 = await seed_asset(ctx, owner="alice", visibility="public", asset_id=v1.asset_id)
    assert v1.asset_id == v2.asset_id and v1.version_id != v2.version_id

    versions = (await client.get(f"/v1/assets/{v1.asset_id}/versions", headers=auth("alice"))).json()
    assert [v["version_number"] for v in versions] == [1, 2]
    digests = {v["manifest_digest"] for v in versions}
    assert len(digests) == 2, "each version has its own sealed manifest"

    # Sessions are pinned to one version; the default is the newest published one.
    default = await start_session(client, auth("bob"), v1.asset_id)
    pinned = await start_session(client, auth("bob"), v1.asset_id, version_id=v1.version_id)
    assert default["version_id"] == v2.version_id and pinned["version_id"] == v1.version_id
    jws_v1 = (await client.get(pinned["signed_manifest_url"], headers=bearer(pinned["session_token"]))).text
    manifest = verify_manifest(ctx.tokens, jws_v1, expected_version_id=v1.version_id)
    assert manifest.version_number == 1
    with pytest.raises(ManifestError):  # a v1 manifest cannot authenticate v2 segments
        verify_manifest(ctx.tokens, jws_v1, expected_version_id=v2.version_id)
    tampered = jws_v1[:-4] + ("AAAA" if not jws_v1.endswith("AAAA") else "BBBB")
    with pytest.raises(ManifestError):
        verify_manifest(ctx.tokens, tampered, expected_version_id=v1.version_id)
    # v2 segments are not reachable through a v1 session.
    v2_seg = v2.manifest.renditions[0].segments[0].segment_id
    cross = await client.get(
        f"/v1/playback-sessions/{pinned['session_id']}/segments/{v2_seg}",
        headers=bearer(pinned["session_token"]),
    )
    assert cross.status_code == 404

    # Published bytes and metadata are frozen under the same version identifier.
    sub = await client.put(
        f"/v1/assets/{v1.asset_id}/versions/{v1.version_id}/subtitles/en", headers=auth("alice"),
        content=b"WEBVTT\n\n00:00.000 --> 00:01.000\nx\n",
    )  # fmt: skip
    assert sub.status_code == 409 and sub.json()["code"] == "version_immutable"
    async with ctx.db.session() as db:
        refs = list(await db.scalars(select(MediaSegment.storage_reference)))
        assert len(refs) == len(set(refs)), "no two segments share (or overwrite) a storage key"
        version = await db.get(AssetVersion, v1.version_id)
        assert version is not None and version.manifest_jws == jws_v1

    from aureom_stream.persistence.models import JobStatus, ProcessingJob
    from aureom_stream.processing.errors import ProcessingError
    from aureom_stream.processing.pipeline import MediaPipeline

    async with ctx.db.session() as db:
        job = await db.scalar(select(ProcessingJob).where(ProcessingJob.asset_version_id == v1.version_id))
        assert job is not None
        job.status = JobStatus.QUEUED.value  # even if someone re-queued the job by hand ...
        upload_id = job.upload_id
    with pytest.raises(ProcessingError) as refused:
        await MediaPipeline(ctx).process(upload_id)
    assert refused.value.code == "version_immutable"  # ... a published version is never reprocessed


async def test_owner_can_preview_before_publication_but_nobody_else(
    ctx: AppContext, client: httpx.AsyncClient, auth
) -> None:
    asset = await seed_asset(ctx, owner="alice", visibility="public", publish=False)
    stranger = await client.post(
        "/v1/playback-sessions", headers=auth("bob"),
        json={"asset_id": asset.asset_id, "version_id": asset.version_id},
    )  # fmt: skip
    assert stranger.status_code == 404
    preview = await start_session(
        client, auth("alice"), asset.asset_id, version_id=asset.version_id, peer=True
    )
    assert preview["preview"] is True and preview["delivery_modes"] == ["origin"]
    assert preview["signed_manifest_url"] is None
    master = await client.get(preview["master_playlist_url"], headers=bearer(preview["session_token"]))
    assert master.status_code == 200
