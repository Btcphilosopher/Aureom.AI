# Fixtures

| File | What it is |
|---|---|
| `test-pattern-6s.mp4` | 6 s, 320x180, 24 fps H.264 + AAC clip. |
| `sample.en.vtt` | A WebVTT subtitle track for the clip. |

The clip is produced entirely by FFmpeg's built-in generators (`testsrc2` video
pattern and a `sine` tone). It contains no third-party footage or music, so it can be
uploaded, published, streamed and downloaded offline freely. FFmpeg's documentation
describes both sources as synthetic generators; it makes no explicit copyright
statement about their output, so "free of third-party rights" is our reading, not a
quotation.

Regenerate (any length or size):

```bash
aureom-stream fixture generate --out fixtures/test-pattern.mp4 --seconds 20 --size 640x360
```

The demonstration (`aureom-stream demo`) generates its own 20-second 640x360 clip in
its work directory; it does not use the file in this folder. The test-suite generates
a clip at session start as well.

For real footage, an openly licensed title such as *Big Buck Bunny* (CC BY 3.0,
Blender Foundation - attribution required) can be used; it is not shipped here.
