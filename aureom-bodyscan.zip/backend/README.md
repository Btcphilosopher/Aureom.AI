# Optional AUREOM BODYSCAN Reconstruction Backend (FastAPI)

This backend is **strictly optional**. Local guided scanning, on-device ML Kit pose tracking, calibrated linear measurements, Room storage, 3D parametric inspection, and simulated force trials work completely offline without running this server.

## Run Locally

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export AUREOM_BACKEND_TOKEN="your-local-dev-token"
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Android Client Setup

1. Open **Privacy** in the Android app.
2. Enable **Cloud Reconstruction Upload** (explicit opt-in, off by default).
3. Enter your endpoint URL (e.g., `http://10.0.2.2:8000` for Android Emulator loopback, or `https://...` in production).
4. Optionally store your Bearer Token (encrypted via AndroidKeyStore AES-256-GCM).
5. Tap **Check Health** to verify `/v1/health`.
