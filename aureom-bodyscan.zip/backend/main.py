from __future__ import annotations

import os
import secrets
import uuid
from typing import Dict, List, Optional

from fastapi import Depends, FastAPI, Header, HTTPException, status
from pydantic import BaseModel, Field

app = FastAPI(
    title="Aureom BodyScan Optional Reconstruction Service",
    version="1.0.0",
    description=(
        "Optional, explicitly consented external reconstruction endpoint for AUREOM BODYSCAN. "
        "Rejects unconsented requests and partial-coverage captures rather than fabricating meshes."
    ),
)

API_TOKEN = os.getenv("AUREOM_BACKEND_TOKEN", "")
JOBS: Dict[str, dict] = {}


def verify_token(authorization: Optional[str] = Header(default=None)) -> None:
    if not API_TOKEN:
        return
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token")
    supplied = authorization.removeprefix("Bearer ").strip()
    if not secrets.compare_digest(supplied, API_TOKEN):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid bearer token")


class ReconstructionJobRequest(BaseModel):
    session_id: str = Field(..., min_length=1, max_length=128)
    consent_verified: bool
    captured_angles: List[str]
    calibration_source: str
    scale_mm_per_px: Optional[float] = None
    stature_mm: Optional[float] = None


class ReconstructionJobResponse(BaseModel):
    job_id: str
    status: str
    message: str
    coverage_percent: int


@app.get("/v1/health")
def health() -> dict:
    return {"status": "ok", "service": "aureom-reconstruction-fastapi"}


@app.post("/v1/jobs", response_model=ReconstructionJobResponse, status_code=status.HTTP_201_CREATED)
def create_job(
    payload: ReconstructionJobRequest,
    _: None = Depends(verify_token),
) -> ReconstructionJobResponse:
    if not payload.consent_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Explicit cloud upload consent is required before reconstruction.",
        )
    required = {"FRONT", "SIDE_LEFT", "REAR"}
    provided = set(payload.captured_angles)
    missing = sorted(required - provided)
    if missing:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Incomplete capture coverage; missing sectors: {', '.join(missing)}.",
        )
    if payload.scale_mm_per_px is None or payload.scale_mm_per_px <= 0:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Calibrated scale_mm_per_px is required for metric reconstruction.",
        )

    job_id = f"recon_{uuid.uuid4().hex[:12]}"
    JOBS[job_id] = {
        "job_id": job_id,
        "session_id": payload.session_id,
        "status": "QUEUED",
        "calibration_source": payload.calibration_source,
        "coverage_percent": 100,
    }
    return ReconstructionJobResponse(
        job_id=job_id,
        status="QUEUED",
        message="Consented multi-view reconstruction job accepted.",
        coverage_percent=100,
    )


@app.get("/v1/jobs/{job_id}")
def get_job(job_id: str, _: None = Depends(verify_token)) -> dict:
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Job not found")
    return job


@app.delete("/v1/jobs/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_job(job_id: str, _: None = Depends(verify_token)) -> None:
    JOBS.pop(job_id, None)
