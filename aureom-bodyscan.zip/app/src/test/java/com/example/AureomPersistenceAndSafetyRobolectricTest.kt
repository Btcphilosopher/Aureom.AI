package com.example

import android.content.Context
import android.graphics.Bitmap
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.adapters.DeviceCapabilityInspector
import com.example.data.local.AureomDatabase
import com.example.data.local.PrivateFileStore
import com.example.data.repository.DemoFixturesFactory
import com.example.data.repository.ScanRepository
import com.example.domain.model.CaptureAngle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AureomPersistenceAndSafetyRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: AureomDatabase
    private lateinit var fileStore: PrivateFileStore
    private lateinit var repository: ScanRepository

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AureomDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        fileStore = PrivateFileStore(context)
        fileStore.purgeAllPrivateFiles()
        repository = ScanRepository(db.aureomDao(), fileStore)
    }

    @After
    fun tearDown() {
        fileStore.purgeAllPrivateFiles()
        db.close()
    }

    @Test
    fun `device capability inspector gates hardware depth and backend reconstruction honestly`() {
        val inspector = DeviceCapabilityInspector(context)
        val report = inspector.inspect(isBackendConfigured = false, isCloudOptInEnabled = false)
        assertFalse(report.hasHardwareDepthOutput)
        val depthCap = report.capabilities.first { it.id == "hardware_depth" }
        assertEquals("UNSUPPORTED", depthCap.supportLevel.name)
        val reconCap = report.capabilities.first { it.id == "reconstruction_3d" }
        assertEquals("UNSUPPORTED", reconCap.supportLevel.name)
    }

    @Test
    fun `session isolation and complete deletion remove database rows and private files`() = runBlocking {
        val demos = DemoFixturesFactory.buildDemoSessions()
        val sessionA = demos[0].copy(id = "session_iso_a", isDemoFixture = false)
        val sessionB = demos[1].copy(id = "session_iso_b", isDemoFixture = false)

        val bmp = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
        val fileA = fileStore.writeBitmapCapture(sessionA.id, CaptureAngle.FRONT.name, bmp)
        assertTrue(fileA.exists())

        val sessionAWithFile = sessionA.copy(
            frames = sessionA.frames.mapIndexed { idx, f ->
                if (idx == 0) f.copy(localFilePath = fileA.absolutePath) else f
            }
        )
        repository.saveSession(sessionAWithFile)
        repository.saveSession(sessionB)

        assertEquals(2, repository.sessionsFlow.first().size)
        assertEquals(1, fileStore.listSessionFiles(sessionA.id).size)

        // Delete A completely
        repository.deleteSessionCompletely(sessionA.id)

        val remaining = repository.sessionsFlow.first()
        assertEquals(1, remaining.size)
        assertEquals(sessionB.id, remaining.first().id)
        assertFalse(fileA.exists())
        assertTrue(fileStore.listSessionFiles(sessionA.id).isEmpty())
        assertTrue(db.aureomDao().getFramesForSession(sessionA.id).isEmpty())
        assertTrue(db.aureomDao().getMeasurementsForSession(sessionA.id).isEmpty())
    }

    @Test
    fun `interrupted processing does not persist partial corrupt session`() = runBlocking {
        val job = launch {
            try {
                delay(150)
                val demo = DemoFixturesFactory.buildDemoSessions().first().copy(id = "interrupted_s")
                repository.saveSession(demo)
            } catch (_: CancellationException) {
                // Expected cancellation before DB write
            }
        }
        delay(30)
        job.cancel()
        job.join()

        assertTrue(repository.sessionsFlow.first().isEmpty())
    }

    @Test
    fun `retention policy deletes expired non-demo sessions while preserving fixtures`() = runBlocking {
        val demos = DemoFixturesFactory.buildDemoSessions()
        repository.seedAllDemoFixtures()

        val oldUserSession = demos.first().copy(
            id = "expired_user_session",
            createdAtMs = System.currentTimeMillis() - (45L * 24 * 60 * 60 * 1000),
            isDemoFixture = false
        )
        repository.saveSession(oldUserSession)

        val purgedCount = repository.enforceRetentionPolicy(retentionDays = 30)
        assertEquals(1, purgedCount)

        val after = repository.sessionsFlow.first()
        assertFalse(after.any { it.id == "expired_user_session" })
        assertTrue(after.all { it.isDemoFixture })
    }
}
