package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToIndex
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `app name matches Aureom Scan`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aureom Scan", appName)
    }

    @Test
    fun `home screen launches with capability summary and navigates to measurements`() {
        composeRule.setContent {
            AureomBodyScanApp()
        }
        composeRule.waitForIdle()
        composeRule.onAllNodesWithText("AUREOM BODYSCAN").onFirst().assertIsDisplayed()
        composeRule.onNodeWithTag("home_start_scan_button").assertIsDisplayed()
        composeRule.onNodeWithTag("home_lazy_column").performScrollToIndex(2)
        composeRule.onNodeWithText("Device Capability Summary").assertIsDisplayed()
        composeRule.onNodeWithTag("home_lazy_column").performScrollToIndex(3)
        composeRule.onNodeWithTag("home_tile_nav_measurements").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("unit_INCHES").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("toggle_manual_form_button").assertIsDisplayed()
    }
}
