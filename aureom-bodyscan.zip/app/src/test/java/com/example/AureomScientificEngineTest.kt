package com.example

import com.example.data.repository.DemoFixturesFactory
import com.example.domain.math.CalibrationSolver
import com.example.domain.math.GeometryMath
import com.example.domain.math.MeshGenerator
import com.example.domain.math.UncertaintyEngine
import com.example.domain.math.UnitConverter
import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.CalibrationSource
import com.example.domain.model.CaptureAngle
import com.example.domain.model.CaptureMode
import com.example.domain.model.CapturedFrameInfo
import com.example.domain.model.ForceUnit
import com.example.domain.model.ImagePointPx
import com.example.domain.model.LengthUnit
import com.example.domain.model.MeasurementQualityStatus
import com.example.domain.model.ModelProvenanceType
import com.example.domain.model.RelativePosePoint
import com.example.domain.model.ScanSession
import com.example.domain.model.SectorCoverageStatus
import com.example.domain.model.SessionProcessingState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AureomScientificEngineTest {

    @Test
    fun `unit conversions preserve millimeter precision across cm and inches`() {
        val mm = 1750.0
        val cm = UnitConverter.mmToUnit(mm, LengthUnit.CENTIMETERS)
        val inches = UnitConverter.mmToUnit(mm, LengthUnit.INCHES)
        assertEquals(175.0, cm, 0.001)
        assertEquals(68.8976, inches, 0.01)
        assertEquals(mm, UnitConverter.unitToMm(inches, LengthUnit.INCHES), 0.01)

        val forceN = 500.0
        val kgf = UnitConverter.newtonsToUnit(forceN, ForceUnit.KGF)
        assertEquals(50.985, kgf, 0.01)
    }

    @Test
    fun `coordinate transformations separate pixels normalized pose and metric mm`() {
        val px = ImagePointPx(540f, 960f, 1080, 1920, 0.95f)
        val (nx, ny) = CalibrationSolver.imagePxToNormalized(px)
        assertEquals(0.5f, nx, 0.001f)
        assertEquals(0.5f, ny, 0.001f)

        val cal = CalibrationSolver.solveFromReferenceSpan(
            source = CalibrationSource.A4_REFERENCE_CARD,
            referencePixelSpan = 297.0,
            referencePhysicalMm = 297.0,
            referenceTolerancePercent = 1.5
        )
        assertTrue(cal.isScaleVerified)
        assertEquals(1.0, cal.scaleMmPerPx!!, 0.001)

        val p1 = RelativePosePoint(AnatomicalLandmark.LEFT_SHOULDER, 0.3f, 0.25f, 0f, 0.95f, 0.95f)
        val p2 = RelativePosePoint(AnatomicalLandmark.RIGHT_SHOULDER, 0.7f, 0.25f, 0f, 0.95f, 0.95f)
        val metric = CalibrationSolver.measureNormalizedDistanceMm(p1, p2, 1000, 1000, cal)
        assertNotNull(metric)
        assertEquals(400.0, metric!!.valueMm, 0.1)
        assertTrue((metric.uncertaintyMm ?: 0.0) > 0.0)
    }

    @Test
    fun `uncalibrated photograph strictly blocks absolute metric output`() {
        val uncal = CalibrationSolver.uncalibrated()
        assertFalse(uncal.isScaleVerified)
        assertNull(uncal.scaleMmPerPx)

        val p1 = RelativePosePoint(AnatomicalLandmark.LEFT_SHOULDER, 0.3f, 0.25f, 0f, 0.95f, 0.95f)
        val p2 = RelativePosePoint(AnatomicalLandmark.RIGHT_SHOULDER, 0.7f, 0.25f, 0f, 0.95f, 0.95f)
        assertNull(CalibrationSolver.measureNormalizedDistanceMm(p1, p2, 1080, 1920, uncal))

        val frame = CapturedFrameInfo(
            id = "f1",
            sessionId = "s_uncal",
            angle = CaptureAngle.FRONT,
            localFilePath = null,
            capturedAtMs = 1L,
            imageWidthPx = 1080,
            imageHeightPx = 1920,
            meanLuma = 140f,
            motionStabilityScore = 0.95f,
            landmarks = DemoFixturesFactory.standardStandingLandmarks(),
            occludedLandmarks = emptyList(),
            qualityIssues = emptyList()
        )
        val metrics = GeometryMath.deriveMeasurementsFromFrames("s_uncal", listOf(frame), uncal, 1L)
        assertTrue(metrics.isNotEmpty())
        assertTrue(metrics.all { it.valueMm == null && it.qualityStatus == MeasurementQualityStatus.BLOCKED_UNCALIBRATED })
    }

    @Test
    fun `single front image does not derive circumferences and missing landmarks flag insufficient input`() {
        val cal = CalibrationSolver.solveFromReferenceSpan(
            CalibrationSource.A4_REFERENCE_CARD,
            referencePixelSpan = 264.0,
            referencePhysicalMm = 297.0
        )
        val partialLandmarks = DemoFixturesFactory.standardStandingLandmarks()
            .filterNot { it.landmarkType == AnatomicalLandmark.LEFT_WRIST }

        val frontOnly = CapturedFrameInfo(
            id = "f1",
            sessionId = "s1",
            angle = CaptureAngle.FRONT,
            localFilePath = null,
            capturedAtMs = 1L,
            imageWidthPx = 1080,
            imageHeightPx = 1920,
            meanLuma = 140f,
            motionStabilityScore = 0.95f,
            landmarks = partialLandmarks,
            occludedLandmarks = listOf(AnatomicalLandmark.LEFT_WRIST),
            qualityIssues = emptyList()
        )
        val metrics = GeometryMath.deriveMeasurementsFromFrames("s1", listOf(frontOnly), cal, 1L)
        assertNull(metrics.firstOrNull { it.metricKey == "hip_circumference_est" })
        val forearm = metrics.first { it.metricKey == "left_forearm" }
        assertEquals(MeasurementQualityStatus.INSUFFICIENT_INPUT, forearm.qualityStatus)
        assertNull(forearm.valueMm)
    }

    @Test
    fun `comparison flags incompatible capture methods and inconclusive deltas within uncertainty`() {
        val demos = DemoFixturesFactory.buildDemoSessions()
        val calibrated = demos.first { it.id == "demo_calibrated_capture" }
        val manual = demos.first { it.id == "demo_manual_session" }

        val cmp = UncertaintyEngine.compareSessions(calibrated, manual)
        assertFalse(cmp.areMethodsCompatible)
        assertTrue(cmp.incompatibilityWarnings.any { it.contains("Capture method mismatch") })

        // Self-comparison with tiny simulated perturbation (within uncertainty) must be inconclusive
        val perturbed = calibrated.copy(
            id = "s_perturbed",
            measurements = calibrated.measurements.map {
                it.copy(valueMm = it.valueMm?.plus(2.0)) // 2mm change << uncertainty (~35mm)
            }
        )
        val selfCmp = UncertaintyEngine.compareSessions(calibrated, perturbed)
        val statureRow = selfCmp.rows.first { it.metricKey == "stature" }
        assertTrue(statureRow.isInconclusiveWithinUncertainty)
    }

    @Test
    fun `partial capture mesh preserves unobserved gap triangles`() {
        val partialSession = DemoFixturesFactory.buildDemoSessions().first { it.id == "demo_partial_failure" }
        val mesh = MeshGenerator.buildModelForSession(partialSession)
        assertEquals(ModelProvenanceType.PARTIAL_COVERAGE_MODEL, mesh.provenanceType)
        assertTrue(mesh.triangles.any { it.coverageStatus == SectorCoverageStatus.UNOBSERVED_GAP })
        assertTrue(mesh.observedCoveragePercent < 50)
    }
}
