package com.example

import com.example.adapters.FastApiReconstructionClient
import com.example.adapters.SoftwareMatrix3DRenderer
import com.example.data.repository.DemoFixturesFactory
import com.example.domain.math.MeshGenerator
import com.example.domain.model.ProjectionMode3D
import com.example.domain.model.ViewPreset3D
import com.example.domain.model.Viewport3DState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FastApiAnd3DRendererTest {

    @Test
    fun `fastapi client enforces https for remote hosts and allows local dev loopbacks`() {
        val client = FastApiReconstructionClient()
        assertTrue(client.isValidEndpointUrl("https://recon.aureom.example.org"))
        assertTrue(client.isValidEndpointUrl("http://10.0.2.2:8000"))
        assertTrue(client.isValidEndpointUrl("http://127.0.0.1:8000"))
        assertFalse(client.isValidEndpointUrl("http://remote-server.example.com:8000"))
        assertFalse(client.isValidEndpointUrl("ftp://recon.example.com"))
        assertFalse(client.isValidEndpointUrl(""))
    }

    @Test
    fun `3d renderer supports perspective orthographic isometric presets and clipping`() {
        val session = DemoFixturesFactory.buildDemoSessions().first { it.id == "demo_3d_isometric" }
        val model = MeshGenerator.buildModelForSession(session)
        val renderer = SoftwareMatrix3DRenderer()

        val fullPerspective = renderer.prepareTriangles(
            model = model,
            viewportWidth = 800f,
            viewportHeight = 1000f,
            state = Viewport3DState(projectionMode = ProjectionMode3D.PERSPECTIVE)
        )
        assertTrue(fullPerspective.isNotEmpty())

        val isometric = renderer.prepareTriangles(
            model = model,
            viewportWidth = 800f,
            viewportHeight = 1000f,
            state = Viewport3DState(
                yawDeg = ViewPreset3D.ISOMETRIC.yawDeg,
                pitchDeg = ViewPreset3D.ISOMETRIC.pitchDeg,
                projectionMode = ProjectionMode3D.ORTHOGRAPHIC
            )
        )
        assertTrue(isometric.isNotEmpty())

        val clipped = renderer.prepareTriangles(
            model = model,
            viewportWidth = 800f,
            viewportHeight = 1000f,
            state = Viewport3DState(clipMinNormalizedY = 0.4f, clipMaxNormalizedY = 0.7f)
        )
        assertTrue(clipped.isNotEmpty())
        assertTrue(clipped.size < fullPerspective.size)
    }

    @Test
    fun `demo fixtures cover calibrated manual movement 3d uncalibrated partial force and deletion`() {
        val sessions = DemoFixturesFactory.buildDemoSessions()
        assertTrue(sessions.any { it.demoScenarioTag == "CALIBRATED_GUIDED" })
        assertTrue(sessions.any { it.demoScenarioTag == "MANUAL_TAPE" })
        assertTrue(sessions.any { it.demoScenarioTag == "ISOMETRIC_3D_DEMO" })
        assertTrue(sessions.any { it.demoScenarioTag == "MISSING_CALIBRATION" })
        assertTrue(sessions.any { it.demoScenarioTag == "PARTIAL_RECON_FAILURE" })
        assertTrue(sessions.any { it.demoScenarioTag == "DELETION_SANDBOX" })

        val movement = DemoFixturesFactory.buildDemoMovementSequence()
        assertEquals(36, movement.frames.size)
        assertTrue(movement.isSyntheticDemo)

        val forceTrial = DemoFixturesFactory.buildDemoForceTrial()
        assertTrue(forceTrial.isSimulated)
        assertTrue(forceTrial.missingSampleCount > 0)
        assertTrue(forceTrial.peakForceNewtons > forceTrial.meanForceNewtons)
    }
}
