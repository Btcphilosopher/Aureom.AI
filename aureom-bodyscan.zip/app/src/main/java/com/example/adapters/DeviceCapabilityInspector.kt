package com.example.adapters

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import com.example.domain.model.CapabilityItem
import com.example.domain.model.CapabilitySupportLevel
import com.example.domain.model.DeviceCapabilityReport

/**
 * Inspects actual Android hardware and runtime configuration to gate capabilities truthfully.
 * Never presents unsupported hardware depth or offline dense reconstruction as available.
 */
class DeviceCapabilityInspector(private val context: Context) {

    fun inspect(
        isBackendConfigured: Boolean,
        isCloudOptInEnabled: Boolean
    ): DeviceCapabilityReport {
        val pm = context.packageManager
        val hasRgbCamera = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        val hasFrontCamera = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)
        val hasArCore = pm.hasSystemFeature("android.hardware.camera.ar")
        val hasBle = pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)

        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val hasAccel = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null

        val hasDepthOutput = detectHardwareDepthOutput()

        val capabilities = listOf(
            CapabilityItem(
                id = "guided_camerax",
                name = "Guided CameraX Image Capture",
                supportLevel = if (hasRgbCamera) CapabilitySupportLevel.IMPLEMENTED else CapabilitySupportLevel.UNSUPPORTED,
                adapterName = "androidx.camera:camera-camera2 (1.5.0)",
                hardwareRequirement = "RGB Camera",
                details = if (hasRgbCamera) "Rear/Front RGB camera detected; supports Front/Side/Rear guided views." else "No camera hardware reported on this device.",
                licenseInfo = "Apache-2.0"
            ),
            CapabilityItem(
                id = "on_device_pose",
                name = "On-Device Pose Landmark Tracking",
                supportLevel = if (hasRgbCamera) CapabilitySupportLevel.IMPLEMENTED else CapabilitySupportLevel.UNSUPPORTED,
                adapterName = "MlKitPoseEstimatorAdapter",
                hardwareRequirement = "RGB Camera or Image Frame",
                details = "Extracts 21–33 2D/relative body landmarks offline. Produces pose skeletons, not surface scans.",
                licenseInfo = "Google ML Kit Terms / Apache-2.0"
            ),
            CapabilityItem(
                id = "calibrated_linear_metrics",
                name = "Calibrated Linear & Breadth Estimates",
                supportLevel = CapabilitySupportLevel.ESTIMATED,
                adapterName = "CalibrationSolver + GeometryMath",
                hardwareRequirement = "Verified Scale Reference (A4 Card / Stature Ref)",
                details = "Computes millimeter-stored segment lengths and propagated ± uncertainty when calibrated.",
                licenseInfo = "Internal Deterministic Math"
            ),
            CapabilityItem(
                id = "hardware_depth",
                name = "Hardware Depth / ToF Capture",
                supportLevel = if (hasDepthOutput) CapabilitySupportLevel.IMPLEMENTED else CapabilitySupportLevel.UNSUPPORTED,
                adapterName = "DepthCapabilityAdapter",
                hardwareRequirement = "Camera2 DEPTH_OUTPUT capability",
                details = if (hasDepthOutput) {
                    "Device advertises Camera2 DEPTH_OUTPUT capability."
                } else {
                    "Unsupported: no certified Camera2 DEPTH_OUTPUT sensor found on ${Build.MODEL}."
                },
                licenseInfo = "Android Camera2 API"
            ),
            CapabilityItem(
                id = "reconstruction_3d",
                name = "Dense 3D Surface Reconstruction",
                supportLevel = when {
                    isBackendConfigured && isCloudOptInEnabled -> CapabilitySupportLevel.IMPLEMENTED
                    hasDepthOutput -> CapabilitySupportLevel.ESTIMATED
                    else -> CapabilitySupportLevel.UNSUPPORTED
                },
                adapterName = "FastApiReconstructionClient",
                hardwareRequirement = "Consented Python/FastAPI Backend or Depth Sensor",
                details = when {
                    isBackendConfigured && isCloudOptInEnabled ->
                        "Opted-in FastAPI endpoint configured for external multi-view reconstruction jobs."
                    else ->
                        "Unsupported locally on RGB-only hardware. Requires explicit cloud opt-in and FastAPI backend URL."
                },
                licenseInfo = "Optional FastAPI Adapter"
            ),
            CapabilityItem(
                id = "interactive_3d_viewer",
                name = "Interactive 3D & Isometric Viewport",
                supportLevel = CapabilitySupportLevel.IMPLEMENTED,
                adapterName = "SoftwareMatrix3DRenderer",
                hardwareRequirement = "Compose Canvas (CPU/GPU)",
                details = "Renders rotatable perspective & orthographic/isometric projections with gap preservation and clipping.",
                licenseInfo = "Apache-2.0"
            ),
            CapabilityItem(
                id = "force_sensor_ble",
                name = "External Force Sensor (Bluetooth LE)",
                supportLevel = if (hasBle) CapabilitySupportLevel.IMPLEMENTED else CapabilitySupportLevel.UNSUPPORTED,
                adapterName = "BleForceSensorAdapter + SimulatedForceSensorAdapter",
                hardwareRequirement = "Bluetooth LE Load Cell (or Simulated Fixture)",
                details = if (hasBle) {
                    "BLE hardware present (requires runtime Bluetooth permissions). Simulated fixture always available."
                } else {
                    "BLE hardware absent; simulated isometric force fixture available."
                },
                licenseInfo = "Android BLE GATT"
            ),
            CapabilityItem(
                id = "demo_fixtures",
                name = "Synthetic Demonstration Fixtures",
                supportLevel = CapabilitySupportLevel.SIMULATED,
                adapterName = "DemoFixturesFactory",
                hardwareRequirement = "None (Pre-bundled)",
                details = "Includes 9 reproducible scenarios (calibrated, uncalibrated, partial failure, force curve, deletion).",
                licenseInfo = "Bundled Test Data"
            )
        )

        return DeviceCapabilityReport(
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidSdkInt = Build.VERSION.SDK_INT,
            hasRgbCamera = hasRgbCamera,
            hasFrontCamera = hasFrontCamera,
            hasHardwareDepthOutput = hasDepthOutput,
            hasArCoreFeature = hasArCore,
            hasAccelerometer = hasAccel,
            hasBluetoothLe = hasBle,
            isBackendConfigured = isBackendConfigured,
            isCloudOptInEnabled = isCloudOptInEnabled,
            capabilities = capabilities
        )
    }

    private fun detectHardwareDepthOutput(): Boolean {
        return runCatching {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: return false
            cameraManager.cameraIdList.any { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                val caps = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
                caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT)
            }
        }.getOrDefault(false)
    }
}
