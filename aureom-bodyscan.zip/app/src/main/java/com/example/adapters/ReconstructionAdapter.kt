package com.example.adapters

import com.example.domain.model.BodyMeshModel
import com.example.domain.model.ScanSession
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import java.net.URI
import java.util.concurrent.TimeUnit

sealed class ReconstructionResult {
    data class Success(val jobId: String, val mesh: BodyMeshModel?, val message: String) : ReconstructionResult()
    data class Unsupported(val reason: String) : ReconstructionResult()
    data class Failure(val reason: String) : ReconstructionResult()
}

interface DepthCapabilityAdapter {
    val isSupported: Boolean
    val sensorName: String
    fun acquireDepthSummary(): String?
}

class StandardDeviceDepthAdapter(
    override val isSupported: Boolean
) : DepthCapabilityAdapter {
    override val sensorName: String = if (isSupported) "Camera2 DEPTH_OUTPUT" else "None Detected"
    override fun acquireDepthSummary(): String? = if (isSupported) {
        "Hardware depth stream available for surface range estimation."
    } else null
}

interface ReconstructionAdapter {
    val adapterName: String
    suspend fun submitReconstruction(
        session: ScanSession,
        cloudUploadOptIn: Boolean,
        endpointUrl: String,
        bearerToken: String?
    ): ReconstructionResult

    suspend fun deleteRemoteJob(
        jobId: String,
        endpointUrl: String,
        bearerToken: String?
    ): Boolean
}

@JsonClass(generateAdapter = true)
data class ReconstructionJobRequest(
    @Json(name = "session_id") val sessionId: String,
    @Json(name = "consent_verified") val consentVerified: Boolean,
    @Json(name = "captured_angles") val capturedAngles: List<String>,
    @Json(name = "calibration_source") val calibrationSource: String,
    @Json(name = "scale_mm_per_px") val scaleMmPerPx: Double?,
    @Json(name = "stature_mm") val statureMm: Double?
)

@JsonClass(generateAdapter = true)
data class ReconstructionJobResponse(
    @Json(name = "job_id") val jobId: String,
    val status: String,
    val message: String,
    @Json(name = "coverage_percent") val coveragePercent: Int? = null
)

@JsonClass(generateAdapter = true)
data class HealthResponse(
    val status: String,
    val service: String
)

interface ReconstructionApiService {
    @GET("v1/health")
    suspend fun health(): Response<HealthResponse>

    @POST("v1/jobs")
    suspend fun createJob(@Body request: ReconstructionJobRequest): Response<ReconstructionJobResponse>

    @DELETE("v1/jobs/{job_id}")
    suspend fun deleteJob(@Path("job_id") jobId: String): Response<Unit>
}

class FastApiReconstructionClient : ReconstructionAdapter {
    override val adapterName: String = "Optional Python/FastAPI Reconstruction Client"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    fun isValidEndpointUrl(url: String): Boolean {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return false
        return runCatching {
            val uri = URI(trimmed)
            val scheme = uri.scheme?.lowercase() ?: return false
            val host = uri.host?.lowercase() ?: return false
            // Require HTTPS for non-local hosts; allow HTTP only for local LAN/emulator loopback dev testing
            when (scheme) {
                "https" -> true
                "http" -> host == "10.0.2.2" || host == "localhost" || host == "127.0.0.1" || host.startsWith("192.168.")
                else -> false
            }
        }.getOrDefault(false)
    }

    private fun buildService(endpointUrl: String, bearerToken: String?): ReconstructionApiService {
        val normalizedBase = if (endpointUrl.endsWith("/")) endpointUrl else "$endpointUrl/"
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
            redactHeader("Authorization")
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val reqBuilder = chain.request().newBuilder()
                if (!bearerToken.isNullOrBlank()) {
                    reqBuilder.addHeader("Authorization", "Bearer $bearerToken")
                }
                chain.proceed(reqBuilder.build())
            }
            .addInterceptor(logging)
            .build()

        return Retrofit.Builder()
            .baseUrl(normalizedBase)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(ReconstructionApiService::class.java)
    }

    suspend fun checkHealth(endpointUrl: String, bearerToken: String?): Result<String> {
        if (!isValidEndpointUrl(endpointUrl)) {
            return Result.failure(IllegalArgumentException("Endpoint must use HTTPS (or local LAN HTTP for dev)."))
        }
        return runCatching {
            val resp = buildService(endpointUrl, bearerToken).health()
            if (resp.isSuccessful) {
                "${resp.body()?.service ?: "FastAPI"} (${resp.body()?.status ?: "ok"})"
            } else {
                throw IllegalStateException("HTTP ${resp.code()}")
            }
        }
    }

    override suspend fun submitReconstruction(
        session: ScanSession,
        cloudUploadOptIn: Boolean,
        endpointUrl: String,
        bearerToken: String?
    ): ReconstructionResult {
        if (!cloudUploadOptIn) {
            return ReconstructionResult.Unsupported(
                "Cloud reconstruction upload is disabled. Enable explicit opt-in under Privacy to submit jobs."
            )
        }
        if (!isValidEndpointUrl(endpointUrl)) {
            return ReconstructionResult.Unsupported(
                "No valid FastAPI reconstruction server URL configured in Devices/Privacy."
            )
        }
        if (session.frames.size < 3) {
            return ReconstructionResult.Failure(
                "Partial capture (${session.frames.size}/3 angles). Full Front, Side, and Rear views are required before reconstruction."
            )
        }

        return runCatching {
            val stature = session.measurements.firstOrNull { it.metricKey == "stature" }?.valueMm
            val req = ReconstructionJobRequest(
                sessionId = session.id,
                consentVerified = cloudUploadOptIn,
                capturedAngles = session.coveredSectors.map { it.name },
                calibrationSource = session.calibration.source.name,
                scaleMmPerPx = session.calibration.scaleMmPerPx,
                statureMm = stature
            )
            val resp = buildService(endpointUrl, bearerToken).createJob(req)
            if (resp.isSuccessful && resp.body() != null) {
                val body = resp.body()!!
                ReconstructionResult.Success(
                    jobId = body.jobId,
                    mesh = null,
                    message = body.message
                )
            } else {
                ReconstructionResult.Failure("Server rejected job: HTTP ${resp.code()}")
            }
        }.getOrElse { ex ->
            ReconstructionResult.Failure(
                "Reconstruction server unreachable (${ex.message ?: "network error"}). Local calibrated measurements remain intact."
            )
        }
    }

    override suspend fun deleteRemoteJob(
        jobId: String,
        endpointUrl: String,
        bearerToken: String?
    ): Boolean {
        if (!isValidEndpointUrl(endpointUrl)) return false
        return runCatching {
            buildService(endpointUrl, bearerToken).deleteJob(jobId).isSuccessful
        }.getOrDefault(false)
    }
}
