package com.example.adapters

import com.example.domain.model.BodyMeshModel
import com.example.domain.model.ProjectionMode3D
import com.example.domain.model.SectorCoverageStatus
import com.example.domain.model.Vec3
import com.example.domain.model.Viewport3DState
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

data class ProjectedVertex(
    val screenX: Float,
    val screenY: Float,
    val depthZ: Float
)

data class RenderableTriangle(
    val p0: ProjectedVertex,
    val p1: ProjectedVertex,
    val p2: ProjectedVertex,
    val avgDepth: Float,
    val lightIntensity: Float,
    val coverageStatus: SectorCoverageStatus
)

/**
 * Adapter abstraction over 3D rendering engines (e.g. Software MVP Matrix Rasterizer, Filament, OpenGL ES).
 */
interface Body3DRendererAdapter {
    val engineName: String
    fun projectPoint(
        point: Vec3,
        viewportWidth: Float,
        viewportHeight: Float,
        state: Viewport3DState
    ): ProjectedVertex

    fun prepareTriangles(
        model: BodyMeshModel,
        viewportWidth: Float,
        viewportHeight: Float,
        state: Viewport3DState
    ): List<RenderableTriangle>
}

/**
 * Deterministic 3D projection & painter's-algorithm mesh renderer supporting both
 * Perspective and Orthographic/Isometric projections, axial external clipping, and
 * explicit gap preservation for unobserved sectors.
 */
class SoftwareMatrix3DRenderer : Body3DRendererAdapter {
    override val engineName: String = "Aureom Matrix3D Pipeline (Perspective + Orthographic/Isometric)"

    private fun rotatePoint(p: Vec3, yawDeg: Float, pitchDeg: Float): Vec3 {
        val yaw = Math.toRadians(yawDeg.toDouble())
        val pitch = Math.toRadians(pitchDeg.toDouble())

        // Rotate around Y (yaw)
        val cosY = cos(yaw).toFloat()
        val sinY = sin(yaw).toFloat()
        val x1 = p.x * cosY + p.z * sinY
        val z1 = -p.x * sinY + p.z * cosY
        val y1 = p.y

        // Rotate around X (pitch)
        val cosP = cos(pitch).toFloat()
        val sinP = sin(pitch).toFloat()
        val y2 = y1 * cosP - z1 * sinP
        val z2 = y1 * sinP + z1 * cosP

        return Vec3(x1, y2, z2)
    }

    override fun projectPoint(
        point: Vec3,
        viewportWidth: Float,
        viewportHeight: Float,
        state: Viewport3DState
    ): ProjectedVertex {
        val rotated = rotatePoint(point, state.yawDeg, state.pitchDeg)
        val baseScale = minOf(viewportWidth, viewportHeight) * 0.44f * state.zoom

        val (nx, ny) = when (state.projectionMode) {
            ProjectionMode3D.ORTHOGRAPHIC -> {
                rotated.x * baseScale to -rotated.y * baseScale
            }
            ProjectionMode3D.PERSPECTIVE -> {
                val cameraDist = 2.8f
                val fovScale = 1.0f / tan(Math.toRadians(22.0)).toFloat() * 0.42f
                val denom = (cameraDist - rotated.z).coerceAtLeast(0.45f)
                val factor = (fovScale * cameraDist) / denom
                (rotated.x * factor * baseScale) to (-rotated.y * factor * baseScale)
            }
        }

        val cx = viewportWidth * 0.5f + state.panX
        val cy = viewportHeight * 0.52f + state.panY

        return ProjectedVertex(
            screenX = cx + nx,
            screenY = cy + ny,
            depthZ = rotated.z
        )
    }

    override fun prepareTriangles(
        model: BodyMeshModel,
        viewportWidth: Float,
        viewportHeight: Float,
        state: Viewport3DState
    ): List<RenderableTriangle> {
        if (viewportWidth <= 1f || viewportHeight <= 1f || model.vertices.isEmpty()) return emptyList()

        // Normalize Y bounds across [-0.86, +0.86] approx for external axial clipping
        val minModelY = model.vertices.minOf { it.y }
        val maxModelY = model.vertices.maxOf { it.y }
        val ySpan = (maxModelY - minModelY).coerceAtLeast(0.01f)
        val clipLowY = minModelY + ySpan * state.clipMinNormalizedY
        val clipHighY = minModelY + ySpan * state.clipMaxNormalizedY

        val rotatedVerts = model.vertices.map { rotatePoint(it, state.yawDeg, state.pitchDeg) }
        val projectedVerts = model.vertices.map { projectPoint(it, viewportWidth, viewportHeight, state) }

        val lightDir = Vec3(0.35f, 0.55f, 0.75f)
        val lightMag = sqrt(lightDir.x * lightDir.x + lightDir.y * lightDir.y + lightDir.z * lightDir.z)

        val renderables = ArrayList<RenderableTriangle>(model.triangles.size)
        for (tri in model.triangles) {
            val w0 = model.vertices[tri.i0]
            val w1 = model.vertices[tri.i1]
            val w2 = model.vertices[tri.i2]
            val avgWorldY = (w0.y + w1.y + w2.y) / 3f
            if (avgWorldY < clipLowY || avgWorldY > clipHighY) continue

            val r0 = rotatedVerts[tri.i0]
            val r1 = rotatedVerts[tri.i1]
            val r2 = rotatedVerts[tri.i2]

            // Face normal in view space
            val ux = r1.x - r0.x
            val uy = r1.y - r0.y
            val uz = r1.z - r0.z
            val vx = r2.x - r0.x
            val vy = r2.y - r0.y
            val vz = r2.z - r0.z

            val nx = uy * vz - uz * vy
            val ny = uz * vx - ux * vz
            val nz = ux * vy - uy * vx

            // Backface culling (in right-handed view space where +Z faces viewer)
            if (nz <= 0f) continue

            val nMag = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-5f)
            val dot = ((nx * lightDir.x + ny * lightDir.y + nz * lightDir.z) / (nMag * lightMag)).coerceIn(0f, 1f)
            val intensity = 0.28f + 0.72f * dot

            val p0 = projectedVerts[tri.i0]
            val p1 = projectedVerts[tri.i1]
            val p2 = projectedVerts[tri.i2]
            val avgDepth = (r0.z + r1.z + r2.z) / 3f

            renderables.add(
                RenderableTriangle(
                    p0 = p0,
                    p1 = p1,
                    p2 = p2,
                    avgDepth = avgDepth,
                    lightIntensity = intensity,
                    coverageStatus = tri.coverageStatus
                )
            )
        }

        // Painter's sort: farthest first (smallest Z first)
        renderables.sortBy { it.avgDepth }
        return renderables
    }
}
