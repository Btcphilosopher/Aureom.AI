package com.example.adapters

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.domain.model.ForceSamplePoint
import com.example.domain.model.ForceSensorTrial
import com.example.domain.model.ForceUnit
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.UUID
import kotlin.math.PI
import kotlin.math.sin

data class DiscoveredForceDevice(
    val id: String,
    val name: String,
    val address: String,
    val isSimulated: Boolean,
    val calibrationDateIso: String,
    val maxRatedNewtons: Double,
    val samplingRateHz: Int
)

interface ForceSensorAdapter {
    val adapterName: String
    val isSimulatedAdapter: Boolean
    fun scanAvailableDevices(): List<DiscoveredForceDevice>
    fun streamTrial(
        device: DiscoveredForceDevice,
        exerciseSetup: String,
        durationSeconds: Int = 5
    ): Flow<ForceSamplePoint>
}

/**
 * Simulated external isometric load-cell adapter used for reproducible evaluation
 * before connecting physical BLE GATT hardware.
 */
class SimulatedForceSensorAdapter : ForceSensorAdapter {
    override val adapterName: String = "Simulated Isometric Load Cell (50 Hz)"
    override val isSimulatedAdapter: Boolean = true

    override fun scanAvailableDevices(): List<DiscoveredForceDevice> = listOf(
        DiscoveredForceDevice(
            id = "SIM-LC-500N",
            name = "Aureom SimCell 500N [SIMULATED]",
            address = "00:SIM:00:00:05:00",
            isSimulated = true,
            calibrationDateIso = "2026-10-15",
            maxRatedNewtons = 1200.0,
            samplingRateHz = 50
        ),
        DiscoveredForceDevice(
            id = "SIM-GRIP-800N",
            name = "Aureom SimGrip Dynamometer [SIMULATED]",
            address = "00:SIM:00:00:08:00",
            isSimulated = true,
            calibrationDateIso = "2026-11-01",
            maxRatedNewtons = 800.0,
            samplingRateHz = 50
        )
    )

    override fun streamTrial(
        device: DiscoveredForceDevice,
        exerciseSetup: String,
        durationSeconds: Int
    ): Flow<ForceSamplePoint> = flow {
        val totalSamples = durationSeconds * device.samplingRateHz
        val dtMs = 1000L / device.samplingRateHz
        for (i in 0 until totalSamples) {
            // Simulate 2 dropped packets around 40% mark to verify missing-sample telemetry
            if (i == (totalSamples * 0.40).toInt() || i == (totalSamples * 0.40).toInt() + 1) {
                delay(dtMs)
                continue
            }
            val t = i.toDouble() / totalSamples.toDouble()
            // Smooth ramp-up, isometric plateau with minor physiological tremor, ramp-down, brief overload spike in SimGrip
            val baseEnvelope = when {
                t < 0.18 -> sin((t / 0.18) * (PI / 2.0))
                t < 0.82 -> 1.0 + 0.04 * sin(t * 28.0)
                else -> cosRamp((t - 0.82) / 0.18)
            }
            val nominalPeak = if (device.id.contains("GRIP")) 840.0 else 640.0
            val forceN = (nominalPeak * baseEnvelope).coerceAtLeast(0.0)
            emit(
                ForceSamplePoint(
                    timestampMs = i * dtMs,
                    forceNewtons = forceN,
                    isOverload = forceN > device.maxRatedNewtons
                )
            )
            delay(dtMs)
        }
    }

    private fun cosRamp(u: Double): Double = ((1.0 + kotlin.math.cos(u * PI)) / 2.0).coerceIn(0.0, 1.0)

    companion object {
        fun buildTrialSummary(
            device: DiscoveredForceDevice,
            exerciseSetup: String,
            samples: List<ForceSamplePoint>,
            expectedSamples: Int,
            durationSec: Double
        ): ForceSensorTrial {
            val peak = samples.maxOfOrNull { it.forceNewtons } ?: 0.0
            val mean = if (samples.isEmpty()) 0.0 else samples.map { it.forceNewtons }.average()
            val overloads = samples.count { it.isOverload }
            val missing = (expectedSamples - samples.size).coerceAtLeast(0)
            return ForceSensorTrial(
                id = UUID.randomUUID().toString(),
                sensorId = device.id,
                sensorName = device.name,
                isSimulated = device.isSimulated,
                calibrationDateIso = device.calibrationDateIso,
                nativeUnit = ForceUnit.NEWTONS,
                samplingRateHz = device.samplingRateHz,
                exerciseSetup = exerciseSetup,
                trialDurationSec = durationSec,
                samples = samples,
                peakForceNewtons = peak,
                meanForceNewtons = mean,
                missingSampleCount = missing,
                overloadCount = overloads,
                recordedAtMs = System.currentTimeMillis()
            )
        }
    }
}

/**
 * Documented Bluetooth Low Energy GATT force sensor adapter.
 * Requires BLUETOOTH_SCAN & BLUETOOTH_CONNECT on Android 12+ and physical BLE hardware.
 */
class BleForceSensorAdapter(private val context: Context) {

    fun hasBleHardware(): Boolean =
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)

    fun hasRequiredPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun isBluetoothEnabled(): Boolean {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        return manager?.adapter?.isEnabled == true
    }

    @SuppressLint("MissingPermission")
    fun startBriefScan(
        onDeviceFound: (DiscoveredForceDevice) -> Unit,
        onError: (String) -> Unit
    ): (() -> Unit)? {
        if (!hasBleHardware()) {
            onError("Device lacks Bluetooth LE hardware.")
            return null
        }
        if (!hasRequiredPermissions()) {
            onError("Bluetooth permissions not granted.")
            return null
        }
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val scanner = manager?.adapter?.bluetoothLeScanner
        if (scanner == null || !isBluetoothEnabled()) {
            onError("Bluetooth adapter is disabled or unavailable.")
            return null
        }

        val seen = mutableSetOf<String>()
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val dev = result.device ?: return
                val addr = dev.address ?: return
                if (seen.add(addr)) {
                    val name = dev.name ?: "BLE Force Sensor ($addr)"
                    onDeviceFound(
                        DiscoveredForceDevice(
                            id = "BLE-$addr",
                            name = name,
                            address = addr,
                            isSimulated = false,
                            calibrationDateIso = "Device EEPROM",
                            maxRatedNewtons = 2000.0,
                            samplingRateHz = 50
                        )
                    )
                }
            }

            override fun onScanFailed(errorCode: Int) {
                onError("BLE scan failed with code $errorCode")
            }
        }

        return runCatching<(() -> Unit)?> {
            scanner.startScan(callback)
            val stopAction: () -> Unit = {
                runCatching { scanner.stopScan(callback) }
            }
            stopAction
        }.getOrElse {
            onError("Unable to start BLE scan: ${it.message}")
            null
        }
    }
}
