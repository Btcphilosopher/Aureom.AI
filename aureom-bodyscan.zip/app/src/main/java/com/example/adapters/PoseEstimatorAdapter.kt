package com.example.adapters

import android.graphics.Bitmap
import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.RelativePosePoint

data class PoseEstimationResult(
    val landmarks: List<RelativePosePoint>,
    val occludedLandmarks: List<AnatomicalLandmark>,
    val imageWidthPx: Int,
    val imageHeightPx: Int,
    val inferenceTimeMs: Long,
    val averageConfidence: Float,
    val modelId: String,
    val modelLicense: String
)

/**
 * Replaceable on-device pose estimation interface.
 * Outputs normalized coordinates; never infers physical scale on its own.
 */
interface PoseEstimatorAdapter {
    val adapterName: String
    val modelId: String
    val modelLicense: String
    val isAvailableOnDevice: Boolean

    suspend fun estimateFromBitmap(bitmap: Bitmap): Result<PoseEstimationResult>
}
