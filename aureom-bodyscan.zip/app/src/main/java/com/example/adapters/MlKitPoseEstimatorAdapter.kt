package com.example.adapters

import android.graphics.Bitmap
import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.RelativePosePoint
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetector
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * On-device ML Kit BlazePose adapter (no cloud account required).
 * License: Google ML Kit Terms of Service / Apache 2.0 SDK wrapper.
 */
class MlKitPoseEstimatorAdapter(
    streamMode: Boolean = false
) : PoseEstimatorAdapter {
    override val adapterName: String = "ML Kit Pose Detection (On-Device)"
    override val modelId: String = "com.google.mlkit:pose-detection:18.0.0-beta5"
    override val modelLicense: String = "Google ML Kit Terms / Apache-2.0"

    private val detector: PoseDetector? by lazy {
        runCatching {
            val mode = if (streamMode) {
                PoseDetectorOptions.STREAM_MODE
            } else {
                PoseDetectorOptions.SINGLE_IMAGE_MODE
            }
            val options = PoseDetectorOptions.Builder()
                .setDetectorMode(mode)
                .build()
            PoseDetection.getClient(options)
        }.getOrNull()
    }

    override val isAvailableOnDevice: Boolean
        get() = detector != null

    override suspend fun estimateFromBitmap(bitmap: Bitmap): Result<PoseEstimationResult> {
        val activeDetector = detector
            ?: return Result.failure(IllegalStateException("ML Kit PoseDetector unavailable in this runtime."))
        val input = InputImage.fromBitmap(bitmap, 0)
        return estimateFromInputImage(activeDetector, input, bitmap.width, bitmap.height)
    }

    suspend fun estimateFromInputImage(
        activeDetector: PoseDetector,
        inputImage: InputImage,
        widthPx: Int,
        heightPx: Int
    ): Result<PoseEstimationResult> = suspendCancellableCoroutine { cont ->
        val startNs = System.nanoTime()
        activeDetector.process(inputImage)
            .addOnSuccessListener { pose ->
                val elapsedMs = (System.nanoTime() - startNs) / 1_000_000L
                val result = mapMlKitPose(pose, widthPx, heightPx, elapsedMs)
                if (cont.isActive) cont.resume(Result.success(result))
            }
            .addOnFailureListener { error ->
                if (cont.isActive) cont.resume(Result.failure(error))
            }
    }

    fun getRawDetector(): PoseDetector? = detector

    fun mapMlKitPose(
        pose: Pose,
        widthPx: Int,
        heightPx: Int,
        elapsedMs: Long
    ): PoseEstimationResult {
        val w = widthPx.coerceAtLeast(1).toFloat()
        val h = heightPx.coerceAtLeast(1).toFloat()
        val mapped = mutableListOf<RelativePosePoint>()
        val occluded = mutableListOf<AnatomicalLandmark>()

        for ((mlKitType, landmarkEnum) in LANDMARK_MAPPING) {
            val lm = pose.getPoseLandmark(mlKitType)
            if (lm != null) {
                val conf = lm.inFrameLikelihood.coerceIn(0f, 1f)
                val xNorm = (lm.position3D.x / w).coerceIn(0f, 1f)
                val yNorm = (lm.position3D.y / h).coerceIn(0f, 1f)
                val zRel = lm.position3D.z / w
                mapped.add(
                    RelativePosePoint(
                        landmarkType = landmarkEnum,
                        xNorm = xNorm,
                        yNorm = yNorm,
                        zRel = zRel,
                        visibility = conf,
                        inFrameLikelihood = conf
                    )
                )
                if (conf < 0.55f) {
                    occluded.add(landmarkEnum)
                }
            } else {
                occluded.add(landmarkEnum)
            }
        }

        val avgConf = if (mapped.isEmpty()) 0f else mapped.map { it.visibility }.average().toFloat()
        return PoseEstimationResult(
            landmarks = mapped,
            occludedLandmarks = occluded,
            imageWidthPx = widthPx,
            imageHeightPx = heightPx,
            inferenceTimeMs = elapsedMs,
            averageConfidence = avgConf,
            modelId = modelId,
            modelLicense = modelLicense
        )
    }

    companion object {
        val LANDMARK_MAPPING = listOf(
            PoseLandmark.NOSE to AnatomicalLandmark.NOSE,
            PoseLandmark.LEFT_EYE to AnatomicalLandmark.LEFT_EYE,
            PoseLandmark.RIGHT_EYE to AnatomicalLandmark.RIGHT_EYE,
            PoseLandmark.LEFT_EAR to AnatomicalLandmark.LEFT_EAR,
            PoseLandmark.RIGHT_EAR to AnatomicalLandmark.RIGHT_EAR,
            PoseLandmark.LEFT_SHOULDER to AnatomicalLandmark.LEFT_SHOULDER,
            PoseLandmark.RIGHT_SHOULDER to AnatomicalLandmark.RIGHT_SHOULDER,
            PoseLandmark.LEFT_ELBOW to AnatomicalLandmark.LEFT_ELBOW,
            PoseLandmark.RIGHT_ELBOW to AnatomicalLandmark.RIGHT_ELBOW,
            PoseLandmark.LEFT_WRIST to AnatomicalLandmark.LEFT_WRIST,
            PoseLandmark.RIGHT_WRIST to AnatomicalLandmark.RIGHT_WRIST,
            PoseLandmark.LEFT_HIP to AnatomicalLandmark.LEFT_HIP,
            PoseLandmark.RIGHT_HIP to AnatomicalLandmark.RIGHT_HIP,
            PoseLandmark.LEFT_KNEE to AnatomicalLandmark.LEFT_KNEE,
            PoseLandmark.RIGHT_KNEE to AnatomicalLandmark.RIGHT_KNEE,
            PoseLandmark.LEFT_ANKLE to AnatomicalLandmark.LEFT_ANKLE,
            PoseLandmark.RIGHT_ANKLE to AnatomicalLandmark.RIGHT_ANKLE,
            PoseLandmark.LEFT_HEEL to AnatomicalLandmark.LEFT_HEEL,
            PoseLandmark.RIGHT_HEEL to AnatomicalLandmark.RIGHT_HEEL,
            PoseLandmark.LEFT_FOOT_INDEX to AnatomicalLandmark.LEFT_FOOT_INDEX,
            PoseLandmark.RIGHT_FOOT_INDEX to AnatomicalLandmark.RIGHT_FOOT_INDEX
        )
    }
}
