package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.AureomAppShell
import com.example.ui.navigation.AureomNavDestination
import com.example.ui.navigation.AureomRoute
import com.example.ui.screens.BodyModelScreen
import com.example.ui.screens.DevicesScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MeasurementsScreen
import com.example.ui.screens.MovementScreen
import com.example.ui.screens.NewScanScreen
import com.example.ui.screens.PostureScreen
import com.example.ui.screens.PrivacyScreen
import com.example.ui.theme.AureomTheme
import com.example.ui.viewmodel.AureomViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AureomBodyScanApp()
        }
    }
}

@Composable
fun AureomBodyScanApp(viewModel: AureomViewModel = viewModel()) {
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val activeSession by viewModel.activeSession.collectAsStateWithLifecycle()
    val activeMesh by viewModel.activeMeshModel.collectAsStateWithLifecycle()
    val viewportState by viewModel.viewportState.collectAsStateWithLifecycle()
    val capabilities by viewModel.capabilities.collectAsStateWithLifecycle()
    val guidedDraft by viewModel.guidedDraft.collectAsStateWithLifecycle()
    val comparisonResult by viewModel.comparisonResult.collectAsStateWithLifecycle()
    val selectedMovement by viewModel.selectedMovement.collectAsStateWithLifecycle()
    val movementFrameIdx by viewModel.movementFrameIdx.collectAsStateWithLifecycle()
    val isMovementPlaying by viewModel.isMovementPlaying.collectAsStateWithLifecycle()
    val showMovementTrails by viewModel.showMovementTrails.collectAsStateWithLifecycle()
    val availableForceDevices by viewModel.availableForceDevices.collectAsStateWithLifecycle()
    val selectedForceDevice by viewModel.selectedForceDevice.collectAsStateWithLifecycle()
    val liveForceSamples by viewModel.liveForceSamples.collectAsStateWithLifecycle()
    val isRecordingForce by viewModel.isRecordingForce.collectAsStateWithLifecycle()
    val forceTrials by viewModel.forceTrials.collectAsStateWithLifecycle()
    val auditEvents by viewModel.auditEvents.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()
    val backendHealth by viewModel.backendHealthStatus.collectAsStateWithLifecycle()

    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusBanner) {
        statusBanner?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    val currentDestination = AureomNavDestination.entries.firstOrNull { dest ->
        backStackEntry?.destination?.hasRoute(dest.route::class) == true
    } ?: AureomNavDestination.HOME

    fun navigateTo(dest: AureomNavDestination) {
        navController.navigate(dest.route) {
            launchSingleTop = true
            restoreState = true
        }
    }

    AureomTheme(darkTheme = prefs.darkLabTheme) {
        AureomAppShell(
            currentDestination = currentDestination,
            onNavigate = ::navigateTo,
            snackbarHostState = snackbarHostState
        ) { isExpandedWidth ->
            NavHost(
                navController = navController,
                startDestination = AureomRoute.Home
            ) {
                composable<AureomRoute.Home> {
                    HomeScreen(
                        sessions = sessions,
                        capabilities = capabilities,
                        lengthUnit = prefs.lengthUnit,
                        isExpandedWidth = isExpandedWidth,
                        onNavigate = ::navigateTo,
                        onStartMode = { mode ->
                            viewModel.startNewScanDraft(mode)
                            navigateTo(AureomNavDestination.NEW_SCAN)
                        },
                        onOpenSessionModel = { id ->
                            viewModel.selectSession(id)
                            navigateTo(AureomNavDestination.BODY_MODEL)
                        },
                        onOpenSessionMeasurements = { id ->
                            viewModel.selectSession(id)
                            navigateTo(AureomNavDestination.MEASUREMENTS)
                        }
                    )
                }

                composable<AureomRoute.NewScan> {
                    val completedSession = sessions.firstOrNull { it.id == guidedDraft.completedSessionId }
                    NewScanScreen(
                        draft = guidedDraft,
                        capabilities = capabilities,
                        lengthUnit = prefs.lengthUnit,
                        liveStreamPoseAdapter = viewModel.liveStreamPoseAdapter,
                        completedSession = completedSession,
                        onSelectMode = viewModel::setDraftMode,
                        onSetStage = viewModel::setDraftStage,
                        onUpdateConsent = viewModel::updateDraftConsent,
                        onUpdateCalibration = viewModel::updateDraftCalibration,
                        onSelectAngle = viewModel::setDraftCaptureAngle,
                        onCreateCaptureFile = viewModel::buildTargetCaptureFile,
                        onImageCaptured = viewModel::attachCapturedImageFile,
                        onImportPhotoUri = viewModel::importPhotoFromPicker,
                        onAddSyntheticFrame = viewModel::addSyntheticTestFrame,
                        onDeleteFrame = viewModel::deleteDraftFrame,
                        onStartProcessing = viewModel::processDraftSession,
                        onCancelProcessing = viewModel::cancelProcessing,
                        onResetDraft = { viewModel.startNewScanDraft() },
                        onSaveManualSession = { title, entries, notes ->
                            viewModel.saveManualMeasurementsSession(title, entries, notes)
                            navigateTo(AureomNavDestination.MEASUREMENTS)
                        },
                        onOpenBodyModel = { id ->
                            viewModel.selectSession(id)
                            navigateTo(AureomNavDestination.BODY_MODEL)
                        },
                        onOpenMeasurements = { id ->
                            viewModel.selectSession(id)
                            navigateTo(AureomNavDestination.MEASUREMENTS)
                        }
                    )
                }

                composable<AureomRoute.BodyModel> {
                    BodyModelScreen(
                        sessions = sessions,
                        activeSession = activeSession,
                        meshModel = activeMesh,
                        viewportState = viewportState,
                        renderer = viewModel.renderer3D,
                        reducedMotion = prefs.reducedMotion,
                        isExpandedWidth = isExpandedWidth,
                        onSelectSession = viewModel::selectSession,
                        onRotate = viewModel::rotateViewport,
                        onPan = viewModel::panViewport,
                        onZoom = viewModel::zoomViewport,
                        onApplyPreset = viewModel::applyViewportPreset,
                        onSetProjection = viewModel::setProjectionMode,
                        onToggleOverlay = viewModel::toggleViewportOverlay,
                        onSetClipping = viewModel::setClippingBounds,
                        onResetCamera = viewModel::resetViewportCamera,
                        onCreateSnapshotUri = viewModel::createSnapshotShareUri
                    )
                }

                composable<AureomRoute.Measurements> {
                    MeasurementsScreen(
                        sessions = sessions,
                        activeSession = activeSession,
                        lengthUnit = prefs.lengthUnit,
                        onSelectSession = viewModel::selectSession,
                        onSetUnit = viewModel::setLengthUnit,
                        onSaveManualEntry = viewModel::saveManualMeasurementsSession
                    )
                }

                composable<AureomRoute.Posture> {
                    val snapshot = activeSession?.let { viewModel.analyzePostureForSession(it) }
                    PostureScreen(
                        sessions = sessions,
                        activeSession = activeSession,
                        postureSnapshot = snapshot,
                        isExpandedWidth = isExpandedWidth,
                        onSelectSession = viewModel::selectSession
                    )
                }

                composable<AureomRoute.Movement> {
                    MovementScreen(
                        sequence = selectedMovement,
                        sessions = sessions,
                        currentFrameIndex = movementFrameIdx,
                        isPlaying = isMovementPlaying,
                        showTrails = showMovementTrails,
                        isExpandedWidth = isExpandedWidth,
                        onTogglePlayback = viewModel::toggleMovementPlayback,
                        onSetFrame = viewModel::setMovementFrame,
                        onToggleTrails = viewModel::toggleMovementTrails
                    )
                }

                composable<AureomRoute.History> {
                    HistoryScreen(
                        sessions = sessions,
                        comparisonResult = comparisonResult,
                        lengthUnit = prefs.lengthUnit,
                        onSelectComparison = viewModel::setComparisonSessions,
                        onUpdateNotes = viewModel::updateSessionNotes,
                        onExportSessionUri = viewModel::createProvenanceShareUri,
                        onDeleteSession = viewModel::deleteSession,
                        onRestoreDemos = viewModel::reseedDemoFixtures,
                        onInspectSession = { id ->
                            viewModel.selectSession(id)
                            navigateTo(AureomNavDestination.BODY_MODEL)
                        }
                    )
                }

                composable<AureomRoute.Devices> {
                    DevicesScreen(
                        capabilities = capabilities,
                        forceUnit = prefs.forceUnit,
                        availableDevices = availableForceDevices,
                        selectedDevice = selectedForceDevice,
                        liveSamples = liveForceSamples,
                        isRecordingForce = isRecordingForce,
                        savedTrials = forceTrials,
                        onSetForceUnit = viewModel::setForceUnit,
                        onSelectDevice = viewModel::selectForceDevice,
                        onScanBleDevices = viewModel::scanBleDevices,
                        onRecordForceTrial = { setup -> viewModel.recordForceTrial(setup) },
                        onDeleteTrial = viewModel::deleteForceTrial
                    )
                }

                composable<AureomRoute.Privacy> {
                    PrivacyScreen(
                        prefs = prefs,
                        auditEvents = auditEvents,
                        storageBytes = viewModel.totalPrivateStorageBytes(),
                        hasStoredToken = viewModel.hasStoredBackendToken(),
                        isKeystoreBacked = viewModel.isKeystoreBacked(),
                        backendHealthStatus = backendHealth,
                        onSetReducedMotion = viewModel::setReducedMotion,
                        onSetDarkTheme = viewModel::setDarkLabTheme,
                        onSetPrivateNotifications = viewModel::setPrivateNotifications,
                        onSetRetentionDays = viewModel::setRetentionDays,
                        onPurgeExpiredNow = viewModel::purgeExpiredNow,
                        onUpdateBackendConfig = viewModel::updateBackendConfiguration,
                        onCheckBackendHealth = viewModel::checkBackendHealth,
                        onWipeAllData = viewModel::wipeAllLocalData
                    )
                }
            }
        }
    }
}
