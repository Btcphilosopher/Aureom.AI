package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BluetoothSearching
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.adapters.DiscoveredForceDevice
import com.example.domain.math.UnitConverter
import com.example.domain.model.DeviceCapabilityReport
import com.example.domain.model.ForceSamplePoint
import com.example.domain.model.ForceSensorTrial
import com.example.domain.model.ForceUnit
import com.example.ui.components.BadgeTone
import com.example.ui.components.ForceTimeChart
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.toBadgeTone
import com.example.ui.theme.MetricReadoutStyle
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.StatusError
import com.example.ui.theme.TealMeasurement

@Composable
fun DevicesScreen(
    capabilities: DeviceCapabilityReport,
    forceUnit: ForceUnit,
    availableDevices: List<DiscoveredForceDevice>,
    selectedDevice: DiscoveredForceDevice,
    liveSamples: List<ForceSamplePoint>,
    isRecordingForce: Boolean,
    savedTrials: List<ForceSensorTrial>,
    onSetForceUnit: (ForceUnit) -> Unit,
    onSelectDevice: (DiscoveredForceDevice) -> Unit,
    onScanBleDevices: () -> Unit,
    onRecordForceTrial: (String) -> Unit,
    onDeleteTrial: (String) -> Unit
) {
    var exerciseSetup by remember { mutableStateOf("Isometric Mid-Thigh Pull") }
    var inspectedTrialId by remember { mutableStateOf<String?>(null) }

    val blePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            onScanBleDevices()
        }
    }

    val chartSamples = when {
        isRecordingForce || liveSamples.isNotEmpty() -> liveSamples
        inspectedTrialId != null -> savedTrials.firstOrNull { it.id == inspectedTrialId }?.samples.orEmpty()
        else -> savedTrials.firstOrNull()?.samples.orEmpty()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Optional Isometric Force Sensor",
                subtitle = "Bluetooth GATT load-cell adapter + reproducible simulated fixture"
            )
        }

        item {
            ScientificDisclaimerBanner(text = stringResource(R.string.force_camera_disclaimer))
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ForceUnit.entries.forEach { u ->
                                FilterChip(
                                    selected = forceUnit == u,
                                    onClick = { onSetForceUnit(u) },
                                    label = { Text(u.symbol) }
                                )
                            }
                        }
                        OutlinedButton(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    blePermissionsLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.BLUETOOTH_SCAN,
                                            Manifest.permission.BLUETOOTH_CONNECT
                                        )
                                    )
                                } else {
                                    onScanBleDevices()
                                }
                            },
                            modifier = Modifier.testTag("scan_ble_button")
                        ) {
                            Icon(Icons.Outlined.BluetoothSearching, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Scan BLE")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        availableDevices.forEach { dev ->
                            FilterChip(
                                selected = selectedDevice.id == dev.id,
                                onClick = { onSelectDevice(dev) },
                                label = { Text(dev.name) }
                            )
                        }
                    }

                    Text(
                        text = "Sensor ID: ${selectedDevice.id} · Calibrated: ${selectedDevice.calibrationDateIso} · Rate: ${selectedDevice.samplingRateHz} Hz · Max Rated: ${UnitConverter.formatForce(selectedDevice.maxRatedNewtons, forceUnit)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = exerciseSetup,
                        onValueChange = { exerciseSetup = it },
                        label = { Text("Exercise Setup") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    ForceTimeChart(
                        samples = chartSamples,
                        unit = forceUnit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .testTag("force_time_chart")
                    )

                    Button(
                        onClick = { onRecordForceTrial(exerciseSetup) },
                        enabled = !isRecordingForce,
                        colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                        modifier = Modifier.fillMaxWidth().testTag("record_force_trial_button")
                    ) {
                        Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isRecordingForce) "Streaming 50 Hz Samples..." else "Run 4s Simulated Isometric Trial")
                    }
                }
            }
        }

        if (savedTrials.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Recorded Force Trials (${savedTrials.size})",
                    subtitle = "No automated strength grading or normative ranking is applied"
                )
            }
            items(savedTrials, key = { it.id }) { trial ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().testTag("force_trial_${trial.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(trial.exerciseSetup, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            ProvenanceBadge(
                                text = if (trial.isSimulated) "SIMULATED SENSOR" else "BLE HARDWARE",
                                tone = if (trial.isSimulated) BadgeTone.WARNING else BadgeTone.TEAL
                            )
                        }
                        Text(
                            text = "Peak: ${UnitConverter.formatForce(trial.peakForceNewtons, forceUnit)} · Mean: ${UnitConverter.formatForce(trial.meanForceNewtons, forceUnit)}",
                            style = MetricReadoutStyle,
                            color = TealMeasurement
                        )
                        Text(
                            text = "Sensor: ${trial.sensorName} (${trial.sensorId}) · Cal: ${trial.calibrationDateIso} · ${trial.samplingRateHz} Hz · Duration ${trial.trialDurationSec}s",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Samples: ${trial.samples.size} · Missing: ${trial.missingSampleCount} · Overload flags: ${trial.overloadCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (trial.overloadCount > 0 || trial.missingSampleCount > 0) StatusError else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { inspectedTrialId = trial.id }) { Text("Plot Series") }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { onDeleteTrial(trial.id) }) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete trial", tint = StatusError)
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "Device Capability Matrix",
                subtitle = "${capabilities.deviceModel} · API ${capabilities.androidSdkInt}"
            )
        }

        items(capabilities.capabilities, key = { it.id }) { cap ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().testTag("capability_${cap.id}")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cap.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        ProvenanceBadge(cap.supportLevel.label, cap.supportLevel.toBadgeTone())
                    }
                    Text(cap.details, style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = "Adapter: ${cap.adapterName} · License: ${cap.licenseInfo}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
