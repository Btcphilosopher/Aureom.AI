package com.example.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.RotateLeft
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ZoomIn
import androidx.compose.material.icons.outlined.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.adapters.Body3DRendererAdapter
import com.example.domain.model.BodyMeshModel
import com.example.domain.model.ModelProvenanceType
import com.example.domain.model.ProjectionMode3D
import com.example.domain.model.ScanSession
import com.example.domain.model.ViewPreset3D
import com.example.domain.model.Viewport3DState
import com.example.ui.components.BadgeTone
import com.example.ui.components.Body3DViewport
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.SessionSelectorBar
import com.example.ui.theme.MidnightBlue

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BodyModelScreen(
    sessions: List<ScanSession>,
    activeSession: ScanSession?,
    meshModel: BodyMeshModel?,
    viewportState: Viewport3DState,
    renderer: Body3DRendererAdapter,
    reducedMotion: Boolean,
    isExpandedWidth: Boolean,
    onSelectSession: (String) -> Unit,
    onRotate: (Float, Float) -> Unit,
    onPan: (Float, Float) -> Unit,
    onZoom: (Float) -> Unit,
    onApplyPreset: (ViewPreset3D) -> Unit,
    onSetProjection: (ProjectionMode3D) -> Unit,
    onToggleOverlay: (Boolean?, Boolean?, Boolean?) -> Unit,
    onSetClipping: (Float, Float) -> Unit,
    onResetCamera: () -> Unit,
    onCreateSnapshotUri: (String, Bitmap) -> android.net.Uri?
) {
    val context = LocalContext.current

    val controlsContent: @Composable () -> Unit = {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (activeSession != null && meshModel != null) {
                // Provenance Banner
                val tone = when (meshModel.provenanceType) {
                    ModelProvenanceType.RECONSTRUCTED_MESH -> BadgeTone.TEAL
                    ModelProvenanceType.ESTIMATED_PARAMETRIC_AVATAR -> BadgeTone.VIOLET
                    ModelProvenanceType.PARTIAL_COVERAGE_MODEL,
                    ModelProvenanceType.POSE_SKELETON_ONLY -> BadgeTone.WARNING
                    ModelProvenanceType.SYNTHETIC_DEMO_MODEL -> BadgeTone.WARNING
                    ModelProvenanceType.MANUAL_RECORD_ONLY -> BadgeTone.NEUTRAL
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ProvenanceBadge(meshModel.provenanceType.badgeLabel, tone)
                            Text(
                                text = "Coverage: ${meshModel.observedCoveragePercent}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        Text(
                            text = meshModel.provenanceType.explanation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            ScientificDisclaimerBanner(
                text = stringResource(R.string.isometric_disclaimer)
            )

            // View Presets
            SectionHeader(title = "Camera Presets & Projection")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ViewPreset3D.entries.forEach { preset ->
                    FilterChip(
                        selected = false,
                        onClick = { onApplyPreset(preset) },
                        modifier = Modifier.testTag("preset_${preset.name}"),
                        label = { Text(preset.label) }
                    )
                }
                OutlinedButton(
                    onClick = onResetCamera,
                    modifier = Modifier.testTag("reset_3d_camera"),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Outlined.Refresh, contentDescription = "Reset camera", modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Reset")
                }
            }

            // Perspective vs Orthographic + Accessible Rotate/Zoom Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProjectionMode3D.entries.forEach { mode ->
                    FilterChip(
                        selected = viewportState.projectionMode == mode,
                        onClick = { onSetProjection(mode) },
                        modifier = Modifier.testTag("projection_${mode.name}"),
                        label = { Text(mode.label) }
                    )
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onRotate(-20f, 0f) }, modifier = Modifier.testTag("btn_rotate_left")) {
                    Icon(Icons.Outlined.RotateLeft, contentDescription = "Rotate model left")
                }
                IconButton(onClick = { onRotate(20f, 0f) }, modifier = Modifier.testTag("btn_rotate_right")) {
                    Icon(Icons.Outlined.RotateRight, contentDescription = "Rotate model right")
                }
                IconButton(onClick = { onZoom(1.15f) }, modifier = Modifier.testTag("btn_zoom_in")) {
                    Icon(Icons.Outlined.ZoomIn, contentDescription = "Zoom in")
                }
                IconButton(onClick = { onZoom(0.87f) }, modifier = Modifier.testTag("btn_zoom_out")) {
                    Icon(Icons.Outlined.ZoomOut, contentDescription = "Zoom out")
                }
            }

            // Overlays
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Inspection Overlays", style = MaterialTheme.typography.titleSmall)
                    OverlayToggleRow("Teal Measurement Callouts", viewportState.showMeasurements) {
                        onToggleOverlay(it, null, null)
                    }
                    OverlayToggleRow("Violet Pose Skeleton Overlay", viewportState.showSkeleton) {
                        onToggleOverlay(null, it, null)
                    }
                    OverlayToggleRow("Capture Coverage & Unobserved Gaps", viewportState.showCoverageMap) {
                        onToggleOverlay(null, null, it)
                    }
                }
            }

            // External Axial Clipping Controls
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("External Surface Axial Clipping", style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = "Inspects external contours between ${(viewportState.clipMinNormalizedY * 100).toInt()}% and ${(viewportState.clipMaxNormalizedY * 100).toInt()}% height. Internal anatomy is not modeled.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    RangeSlider(
                        value = viewportState.clipMinNormalizedY..viewportState.clipMaxNormalizedY,
                        onValueChange = { range -> onSetClipping(range.start, range.endInclusive) },
                        valueRange = 0f..1f,
                        modifier = Modifier.testTag("external_clip_slider")
                    )
                }
            }

            // Export Snapshot
            if (activeSession != null && meshModel != null) {
                Button(
                    onClick = {
                        val bmp = renderExportSnapshotBitmap(activeSession, meshModel, viewportState, renderer)
                        val uri = onCreateSnapshotUri(activeSession.id, bmp)
                        if (uri != null) {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "image/png"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                putExtra(Intent.EXTRA_TEXT, "Aureom BodyScan (${viewportState.projectionMode.label}) — ${activeSession.title}")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Selected View Snapshot"))
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("share_3d_snapshot_button")
                ) {
                    Icon(Icons.Outlined.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Share Selected View Snapshot (Explicit Action)")
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SessionSelectorBar(
            sessions = sessions,
            activeSessionId = activeSession?.id,
            onSelectSession = onSelectSession
        )

        if (meshModel == null) {
            ScientificDisclaimerBanner(
                text = "No session selected or stored. Create a guided scan or load demonstration fixtures from History."
            )
            return@Column
        }

        if (isExpandedWidth) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Body3DViewport(
                    model = meshModel,
                    state = viewportState,
                    renderer = renderer,
                    onRotate = onRotate,
                    onPan = onPan,
                    onZoom = onZoom,
                    modifier = Modifier
                        .weight(1.25f)
                        .fillMaxHeight()
                        .testTag("body_3d_viewport")
                )
                Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    controlsContent()
                }
            }
        } else {
            Body3DViewport(
                model = meshModel,
                state = viewportState,
                renderer = renderer,
                onRotate = onRotate,
                onPan = onPan,
                onZoom = onZoom,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .testTag("body_3d_viewport")
            )
            controlsContent()
        }
    }
}

@Composable
private fun OverlayToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

private fun renderExportSnapshotBitmap(
    session: ScanSession,
    model: BodyMeshModel,
    state: Viewport3DState,
    renderer: Body3DRendererAdapter
): Bitmap {
    val w = 720
    val h = 960
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bmp)
    canvas.drawColor(android.graphics.Color.rgb(247, 248, 250))

    val paint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
    val strokePaint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = android.graphics.Color.rgb(15, 30, 54)
    }

    val triangles = renderer.prepareTriangles(model, w.toFloat(), h.toFloat(), state)
    for (tri in triangles) {
        val path = android.graphics.Path().apply {
            moveTo(tri.p0.screenX, tri.p0.screenY)
            lineTo(tri.p1.screenX, tri.p1.screenY)
            lineTo(tri.p2.screenX, tri.p2.screenY)
            close()
        }
        val shade = (tri.lightIntensity * 200).toInt().coerceIn(50, 230)
        paint.color = android.graphics.Color.argb(210, 18, shade, shade)
        canvas.drawPath(path, paint)
        canvas.drawPath(path, strokePaint)
    }

    val textPaint = Paint().apply {
        isAntiAlias = true
        textSize = 24f
        color = android.graphics.Color.rgb(15, 30, 54)
    }
    canvas.drawText("AUREOM BODYSCAN · ${session.title}", 24f, 40f, textPaint)
    canvas.drawText("${state.projectionMode.label} · ${model.provenanceType.badgeLabel}", 24f, 72f, textPaint)
    return bmp
}
