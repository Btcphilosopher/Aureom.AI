package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.SkipNext
import androidx.compose.material.icons.outlined.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.MovementSequence
import com.example.domain.model.ScanSession
import com.example.ui.components.BadgeTone
import com.example.ui.components.PoseOverlayCanvas
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.theme.MetricReadoutStyle
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.PearlOutline
import com.example.ui.theme.TealMeasurement

@Composable
fun MovementScreen(
    sequence: MovementSequence?,
    sessions: List<ScanSession>,
    currentFrameIndex: Int,
    isPlaying: Boolean,
    showTrails: Boolean,
    isExpandedWidth: Boolean,
    onTogglePlayback: () -> Unit,
    onSetFrame: (Int) -> Unit,
    onToggleTrails: () -> Unit
) {
    var showGhostBaseline by remember { mutableStateOf(false) }

    if (sequence == null || sequence.frames.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            ScientificDisclaimerBanner("No movement sequence loaded. Restore demonstration fixtures in History.")
        }
        return
    }

    val safeIdx = currentFrameIndex.coerceIn(0, sequence.frames.lastIndex)
    val frame = sequence.frames[safeIdx]
    val trailWindow = if (showTrails) sequence.frames.subList(0, safeIdx + 1) else emptyList()
    val baselineGhost = if (showGhostBaseline) {
        sessions.firstOrNull { it.frames.isNotEmpty() }?.frames?.firstOrNull()?.landmarks.orEmpty()
    } else emptyList()

    val viewportBox: @Composable (Modifier) -> Unit = { mod ->
        Box(
            modifier = mod
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, PearlOutline, RoundedCornerShape(16.dp))
        ) {
            PoseOverlayCanvas(
                landmarks = frame.landmarks,
                showAlignmentLines = true,
                trailFrames = trailWindow,
                ghostComparisonLandmarks = baselineGhost,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
                    .testTag("movement_pose_canvas")
            )
            Text(
                text = "FRAME ${safeIdx + 1}/${sequence.frames.size} · ${frame.timestampMs} ms",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(10.dp)
            )
        }
    }

    val controlsPane: @Composable (Modifier) -> Unit = { mod ->
        Column(
            modifier = mod.verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (sequence.isSyntheticDemo) {
                    ProvenanceBadge("SYNTHETIC DEMO SEQUENCE", BadgeTone.WARNING)
                }
                ProvenanceBadge("View: ${sequence.viewpoint.label}", BadgeTone.MIDNIGHT)
            }

            ScientificDisclaimerBanner(text = sequence.provenanceNote)

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(sequence.title, style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = safeIdx.toFloat(),
                        onValueChange = { onSetFrame(it.toInt()) },
                        valueRange = 0f..(sequence.frames.lastIndex.coerceAtLeast(1)).toFloat(),
                        modifier = Modifier.testTag("movement_scrubber")
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { onSetFrame((safeIdx - 1).coerceAtLeast(0)) }) {
                            Icon(Icons.Outlined.SkipPrevious, contentDescription = "Previous frame")
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = onTogglePlayback,
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                            modifier = Modifier.testTag("movement_play_pause_button")
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                                contentDescription = if (isPlaying) "Pause playback" else "Play sequence"
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(if (isPlaying) "Pause" else "Play")
                        }
                        Spacer(Modifier.width(8.dp))
                        IconButton(onClick = { onSetFrame((safeIdx + 1).coerceAtMost(sequence.frames.lastIndex)) }) {
                            Icon(Icons.Outlined.SkipNext, contentDescription = "Next frame")
                        }
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Frame Joint-Angle Telemetry (2D Projection)", style = MaterialTheme.typography.titleSmall)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Left Knee Angle", style = MaterialTheme.typography.bodySmall)
                            Text("${String.format("%.1f", frame.leftKneeAngleDeg)}°", style = MetricReadoutStyle, color = TealMeasurement)
                        }
                        Column {
                            Text("Right Knee Angle", style = MaterialTheme.typography.bodySmall)
                            Text("${String.format("%.1f", frame.rightKneeAngleDeg)}°", style = MetricReadoutStyle, color = TealMeasurement)
                        }
                        Column {
                            Text("Shoulder Tilt", style = MaterialTheme.typography.bodySmall)
                            Text("${String.format("%.1f", frame.shoulderTiltDeg)}°", style = MetricReadoutStyle, color = MaterialTheme.colorScheme.tertiary)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Show Landmark Trails", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = showTrails, onCheckedChange = { onToggleTrails() })
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Overlay Session Ghost Skeleton", style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = showGhostBaseline, onCheckedChange = { showGhostBaseline = it })
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (isExpandedWidth) {
            Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                viewportBox(Modifier.weight(1.1f).fillMaxHeight())
                controlsPane(Modifier.weight(1f).fillMaxHeight())
            }
        } else {
            viewportBox(Modifier.fillMaxWidth().height(290.dp))
            controlsPane(Modifier.fillMaxWidth().weight(1f))
        }
    }
}
