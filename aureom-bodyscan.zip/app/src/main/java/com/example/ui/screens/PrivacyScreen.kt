package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.AppPreferencesState
import com.example.data.local.AuditEventEntity
import com.example.ui.components.BadgeTone
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.components.SectionHeader
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.StatusError
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PrivacyScreen(
    prefs: AppPreferencesState,
    auditEvents: List<AuditEventEntity>,
    storageBytes: Long,
    hasStoredToken: Boolean,
    isKeystoreBacked: Boolean,
    backendHealthStatus: String?,
    onSetReducedMotion: (Boolean) -> Unit,
    onSetDarkTheme: (Boolean) -> Unit,
    onSetPrivateNotifications: (Boolean) -> Unit,
    onSetRetentionDays: (Int) -> Unit,
    onPurgeExpiredNow: () -> Unit,
    onUpdateBackendConfig: (String, Boolean, String?) -> Unit,
    onCheckBackendHealth: () -> Unit,
    onWipeAllData: () -> Unit
) {
    var endpointInput by remember(prefs.backendEndpointUrl) { mutableStateOf(prefs.backendEndpointUrl) }
    var cloudOptIn by remember(prefs.isCloudUploadOptIn) { mutableStateOf(prefs.isCloudUploadOptIn) }
    var tokenInput by remember { mutableStateOf("") }
    var showWipeDialog by remember { mutableStateOf(false) }

    if (showWipeDialog) {
        AlertDialog(
            onDismissRequest = { showWipeDialog = false },
            title = { Text("Erase All Local Data?") },
            text = {
                Text("This permanently deletes all scan sessions, captured frames, derived models, measurements, force trials, and stored credentials.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onWipeAllData()
                        showWipeDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                    modifier = Modifier.testTag("confirm_wipe_all_button")
                ) {
                    Text("Erase Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWipeDialog = false }) { Text("Cancel") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ScientificDisclaimerBanner(
                text = "Body imagery and measurements remain inside app-private storage excluded from cloud backups. Body scans are never used for identity recognition or biometric authentication."
            )
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionHeader("Accessibility & Workspace Preferences")
                    ToggleSettingRow(
                        title = "Reduced Motion",
                        subtitle = "Minimizes UI transitions and disables animated motion effects",
                        checked = prefs.reducedMotion,
                        onCheckedChange = onSetReducedMotion,
                        testTag = "reduced_motion_switch"
                    )
                    ToggleSettingRow(
                        title = "Lab Dark Theme",
                        subtitle = "Switches workspace from pearl-white to low-glare midnight slate",
                        checked = prefs.darkLabTheme,
                        onCheckedChange = onSetDarkTheme,
                        testTag = "dark_theme_switch"
                    )
                    ToggleSettingRow(
                        title = "Privacy-Safe Notifications",
                        subtitle = "Notifies completion without body imagery or metric previews",
                        checked = prefs.privateNotificationsEnabled,
                        onCheckedChange = onSetPrivateNotifications,
                        testTag = "private_notif_switch"
                    )
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionHeader(
                        title = "Local Storage & Retention",
                        subtitle = "Private scan storage footprint: ${String.format(Locale.US, "%.2f", storageBytes / 1024.0)} KB"
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0 to "Keep", 30 to "30 Days", 90 to "90 Days").forEach { (days, label) ->
                            FilterChip(
                                selected = prefs.retentionDays == days,
                                onClick = { onSetRetentionDays(days) },
                                label = { Text(label) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onPurgeExpiredNow,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Purge Expired Now")
                        }
                        Button(
                            onClick = { showWipeDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                            modifier = Modifier.weight(1f).testTag("wipe_all_data_button")
                        ) {
                            Text("Erase All Data")
                        }
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionHeader("Optional FastAPI Backend")
                        ProvenanceBadge(
                            text = if (cloudOptIn) "OPT-IN ENABLED" else "LOCAL ONLY",
                            tone = if (cloudOptIn) BadgeTone.VIOLET else BadgeTone.TEAL
                        )
                    }
                    ToggleSettingRow(
                        title = "Enable Cloud Reconstruction Upload",
                        subtitle = "Off by default. Requires explicit opt-in and HTTPS/LAN FastAPI endpoint.",
                        checked = cloudOptIn,
                        onCheckedChange = { cloudOptIn = it },
                        testTag = "privacy_cloud_opt_in_switch"
                    )
                    OutlinedTextField(
                        value = endpointInput,
                        onValueChange = { endpointInput = it },
                        label = { Text("FastAPI Endpoint URL (e.g. https://recon.example.org)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = tokenInput,
                        onValueChange = { tokenInput = it },
                        label = {
                            Text(
                                if (hasStoredToken) "Bearer Token (Stored · enter to replace)" else "Bearer Token (Optional)"
                            )
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Credential storage: ${if (isKeystoreBacked) "AndroidKeyStore AES-256-GCM" else "Private Encrypted Storage"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                onUpdateBackendConfig(endpointInput, cloudOptIn, tokenInput.ifBlank { null })
                                tokenInput = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Save Endpoint")
                        }
                        OutlinedButton(
                            onClick = onCheckBackendHealth,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Check Health")
                        }
                    }
                    backendHealthStatus?.let { status ->
                        Text(status, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        item {
            SectionHeader("Local Privacy & Deletion Audit Log")
        }

        items(auditEvents, key = { it.id }) { event ->
            val ts = SimpleDateFormat("MMM d HH:mm:ss", Locale.US).format(Date(event.timestampMs))
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(event.summary, style = MaterialTheme.typography.bodySmall)
                        Text(ts, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.width(8.dp))
                    ProvenanceBadge(event.eventType, BadgeTone.NEUTRAL)
                }
            }
        }
    }
}

@Composable
private fun ToggleSettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}
