package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.CapabilitySupportLevel
import com.example.domain.model.CaptureAngle
import com.example.domain.model.ScanSession
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorContainer
import com.example.ui.theme.StatusErrorOnContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.ui.theme.StatusWarningOnContainer
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealMeasurement
import com.example.ui.theme.TealOnContainer
import com.example.ui.theme.VioletContainer
import com.example.ui.theme.VioletHighlight
import com.example.ui.theme.VioletOnContainer

@Composable
fun ProvenanceBadge(
    text: String,
    tone: BadgeTone = BadgeTone.TEAL,
    modifier: Modifier = Modifier
) {
    val (bg, fg, border) = when (tone) {
        BadgeTone.TEAL -> Triple(TealContainer, TealOnContainer, TealMeasurement.copy(alpha = 0.35f))
        BadgeTone.VIOLET -> Triple(VioletContainer, VioletOnContainer, VioletHighlight.copy(alpha = 0.35f))
        BadgeTone.WARNING -> Triple(StatusWarningContainer, StatusWarningOnContainer, StatusWarning.copy(alpha = 0.4f))
        BadgeTone.ERROR -> Triple(StatusErrorContainer, StatusErrorOnContainer, StatusError.copy(alpha = 0.4f))
        BadgeTone.NEUTRAL -> Triple(
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.onSurfaceVariant,
            MaterialTheme.colorScheme.outline
        )
        BadgeTone.MIDNIGHT -> Triple(MidnightBlue, Color.White, MidnightBlue)
    }

    Surface(
        modifier = modifier,
        color = bg,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, border)
    ) {
        Text(
            text = text.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = fg,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

enum class BadgeTone {
    TEAL, VIOLET, WARNING, ERROR, NEUTRAL, MIDNIGHT
}

fun CapabilitySupportLevel.toBadgeTone(): BadgeTone = when (this) {
    CapabilitySupportLevel.IMPLEMENTED -> BadgeTone.TEAL
    CapabilitySupportLevel.ESTIMATED -> BadgeTone.VIOLET
    CapabilitySupportLevel.SIMULATED -> BadgeTone.WARNING
    CapabilitySupportLevel.UNSUPPORTED -> BadgeTone.ERROR
}

@Composable
fun ScientificDisclaimerBanner(
    text: String,
    isWarning: Boolean = false,
    modifier: Modifier = Modifier
) {
    val bg = if (isWarning) StatusWarningContainer.copy(alpha = 0.55f) else VioletContainer.copy(alpha = 0.45f)
    val border = if (isWarning) StatusWarning.copy(alpha = 0.45f) else VioletHighlight.copy(alpha = 0.35f)
    val fg = if (isWarning) StatusWarningOnContainer else VioletOnContainer

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = bg,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, border)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isWarning) Icons.Outlined.WarningAmber else Icons.Outlined.Info,
                contentDescription = if (isWarning) "Warning notice" else "Scientific notice",
                tint = fg,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = fg
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.semantics { heading() }) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        if (!subtitle.isNullOrBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SessionSelectorBar(
    sessions: List<ScanSession>,
    activeSessionId: String?,
    onSelectSession: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (sessions.isEmpty()) return
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        sessions.forEach { s ->
            val selected = s.id == activeSessionId
            FilterChip(
                selected = selected,
                onClick = { onSelectSession(s.id) },
                modifier = Modifier.testTag("session_chip_${s.id}"),
                label = {
                    Text(
                        text = s.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MidnightBlue,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

@Composable
fun AnatomicalGuideSilhouette(
    angle: CaptureAngle,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val cx = size.width * 0.5f
        val top = size.height * 0.08f
        val bottom = size.height * 0.92f
        val h = bottom - top

        val guideColor = Color(0xFF14B8A6).copy(alpha = 0.85f)
        val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
        val stroke = Stroke(width = 3f, pathEffect = dash)

        // Plumb vertical axis
        drawLine(
            color = guideColor.copy(alpha = 0.45f),
            start = Offset(cx, top),
            end = Offset(cx, bottom),
            strokeWidth = 2f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
        )

        // Head circle
        val headR = h * 0.065f
        drawCircle(
            color = guideColor,
            radius = headR,
            center = Offset(cx, top + headR),
            style = stroke
        )

        when (angle) {
            CaptureAngle.FRONT, CaptureAngle.REAR -> {
                val shW = h * 0.145f
                val hipW = h * 0.095f
                val shY = top + h * 0.18f
                val hipY = top + h * 0.48f
                val ankleY = bottom

                // Shoulder-hip-torso box
                drawLine(guideColor, Offset(cx - shW, shY), Offset(cx + shW, shY), strokeWidth = 3f)
                drawLine(guideColor, Offset(cx - shW, shY), Offset(cx - hipW, hipY), strokeWidth = 3f, pathEffect = dash)
                drawLine(guideColor, Offset(cx + shW, shY), Offset(cx + hipW, hipY), strokeWidth = 3f, pathEffect = dash)
                drawLine(guideColor, Offset(cx - hipW, hipY), Offset(cx + hipW, hipY), strokeWidth = 3f)

                // Abducted arms
                drawLine(guideColor, Offset(cx - shW, shY), Offset(cx - shW - h * 0.09f, hipY + h * 0.04f), strokeWidth = 3f, pathEffect = dash)
                drawLine(guideColor, Offset(cx + shW, shY), Offset(cx + shW + h * 0.09f, hipY + h * 0.04f), strokeWidth = 3f, pathEffect = dash)

                // Legs
                drawLine(guideColor, Offset(cx - hipW * 0.65f, hipY), Offset(cx - hipW * 0.72f, ankleY), strokeWidth = 3f, pathEffect = dash)
                drawLine(guideColor, Offset(cx + hipW * 0.65f, hipY), Offset(cx + hipW * 0.72f, ankleY), strokeWidth = 3f, pathEffect = dash)
            }
            CaptureAngle.SIDE_LEFT -> {
                val depthHalf = h * 0.07f
                val shY = top + h * 0.18f
                val hipY = top + h * 0.48f
                drawLine(guideColor, Offset(cx - depthHalf, shY), Offset(cx + depthHalf, shY), strokeWidth = 3f)
                drawLine(guideColor, Offset(cx - depthHalf, shY), Offset(cx - depthHalf * 0.85f, hipY), strokeWidth = 3f, pathEffect = dash)
                drawLine(guideColor, Offset(cx + depthHalf, shY), Offset(cx + depthHalf * 0.85f, hipY), strokeWidth = 3f, pathEffect = dash)
                drawLine(guideColor, Offset(cx, hipY), Offset(cx, bottom), strokeWidth = 3f, pathEffect = dash)
            }
        }

        // Corner calibration reticle
        val pad = 16f
        val arm = 28f
        val reticleColor = Color(0xFF8B7CE8).copy(alpha = 0.85f)
        drawLine(reticleColor, Offset(pad, pad), Offset(pad + arm, pad), 3f)
        drawLine(reticleColor, Offset(pad, pad), Offset(pad, pad + arm), 3f)
        drawLine(reticleColor, Offset(size.width - pad, pad), Offset(size.width - pad - arm, pad), 3f)
        drawLine(reticleColor, Offset(size.width - pad, pad), Offset(size.width - pad, pad + arm), 3f)
        drawLine(reticleColor, Offset(pad, size.height - pad), Offset(pad + arm, size.height - pad), 3f)
        drawLine(reticleColor, Offset(pad, size.height - pad), Offset(pad, size.height - pad - arm), 3f)
        drawLine(reticleColor, Offset(size.width - pad, size.height - pad), Offset(size.width - pad - arm, size.height - pad), 3f)
        drawLine(reticleColor, Offset(size.width - pad, size.height - pad), Offset(size.width - pad, size.height - pad - arm), 3f)
    }
}
