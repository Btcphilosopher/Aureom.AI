package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pearl-White Scientific Workspaces
val PearlBackground = Color(0xFFF7F8FA)
val PearlSurface = Color(0xFFFFFFFF)
val PearlSurfaceVariant = Color(0xFFEEF1F6)
val PearlSurfaceContainer = Color(0xFFF1F4F9)
val PearlOutline = Color(0xFFD5DCE6)
val PearlOutlineSubtle = Color(0xFFE4E9F2)

// Midnight-Blue Navigation & Primary Ink
val MidnightBlue = Color(0xFF0F1E36)
val MidnightBlueElevated = Color(0xFF162B4D)
val MidnightBlueContainer = Color(0xFF1E3A5F)
val SlateInk = Color(0xFF334155)
val MutedSlate = Color(0xFF5B6B82)

// Teal Measurement Lines & Primary Accents
val TealMeasurement = Color(0xFF0D9488)
val TealBright = Color(0xFF14B8A6)
val TealDeep = Color(0xFF0F766E)
val TealContainer = Color(0xFFCCFBF1)
val TealOnContainer = Color(0xFF064E3B)

// Restrained Violet Highlights
val VioletHighlight = Color(0xFF6D5BD0)
val VioletBright = Color(0xFF8B7CE8)
val VioletContainer = Color(0xFFEDE9FE)
val VioletOnContainer = Color(0xFF38249C)

// Semantic Status Colors
val StatusWarning = Color(0xFFD97706)
val StatusWarningContainer = Color(0xFFFEF3C7)
val StatusWarningOnContainer = Color(0xFF78350F)

val StatusError = Color(0xFFDC2626)
val StatusErrorContainer = Color(0xFFFEE2E2)
val StatusErrorOnContainer = Color(0xFF7F1D1D)

// Lab Dark Surface Palette (when system dark mode is active)
val LabDarkBackground = Color(0xFF091220)
val LabDarkSurface = Color(0xFF0F1E36)
val LabDarkSurfaceVariant = Color(0xFF172A47)
val LabDarkOutline = Color(0xFF284166)
val LabDarkTextPrimary = Color(0xFFF1F5F9)
val LabDarkTextSecondary = Color(0xFFA5B4CB)
