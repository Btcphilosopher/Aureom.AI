package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.domain.math.UnitConverter
import com.example.domain.model.ForceSamplePoint
import com.example.domain.model.ForceUnit
import com.example.ui.theme.PearlOutline
import com.example.ui.theme.StatusError
import com.example.ui.theme.TealMeasurement
import com.example.ui.theme.VioletHighlight

@Composable
fun ForceTimeChart(
    samples: List<ForceSamplePoint>,
    unit: ForceUnit,
    modifier: Modifier = Modifier
) {
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val bgColor = MaterialTheme.colorScheme.surface

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(1.dp, PearlOutline, RoundedCornerShape(14.dp))
    ) {
        if (samples.isEmpty()) {
            Text(
                text = "Start a force trial or select a saved recording to plot Force-Time series.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp)
            )
            return@Box
        }

        val maxForce = (samples.maxOfOrNull { it.forceNewtons } ?: 100.0).coerceAtLeast(50.0) * 1.15
        val meanForce = samples.map { it.forceNewtons }.average()
        val maxTime = (samples.lastOrNull()?.timestampMs ?: 1000L).coerceAtLeast(100L).toFloat()

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            // Horizontal grid lines
            for (i in 1..4) {
                val y = size.height * (i / 4f)
                drawLine(gridColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            }

            // Mean force reference line
            val meanY = size.height - ((meanForce / maxForce).toFloat() * size.height)
            drawLine(
                color = VioletHighlight.copy(alpha = 0.7f),
                start = Offset(0f, meanY),
                end = Offset(size.width, meanY),
                strokeWidth = 2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
            )

            // Force-time curve (with breaks where missing samples > 45ms gap)
            val path = Path()
            var lastTs: Long? = null
            samples.forEachIndexed { idx, pt ->
                val x = (pt.timestampMs / maxTime) * size.width
                val y = size.height - ((pt.forceNewtons / maxForce).toFloat() * size.height)
                val prevTs = lastTs
                val isGap = prevTs != null && (pt.timestampMs - prevTs) > 45L
                if (idx == 0 || isGap) {
                    path.moveTo(x, y)
                    if (isGap) {
                        drawCircle(
                            color = StatusError,
                            radius = 5f,
                            center = Offset(x, y)
                        )
                    }
                } else {
                    path.lineTo(x, y)
                }
                if (pt.isOverload) {
                    drawCircle(color = StatusError, radius = 5.5f, center = Offset(x, y))
                }
                lastTs = pt.timestampMs
            }

            drawPath(
                path = path,
                color = TealMeasurement,
                style = Stroke(width = 4f)
            )
        }

        Text(
            text = "Peak: ${UnitConverter.formatForce(samples.maxOf { it.forceNewtons }, unit)} · Mean: ${UnitConverter.formatForce(meanForce, unit)}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
        )
    }
}
