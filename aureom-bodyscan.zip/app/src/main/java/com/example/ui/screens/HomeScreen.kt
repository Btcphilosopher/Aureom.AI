package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material.icons.outlined.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.math.UnitConverter
import com.example.domain.model.CapabilitySupportLevel
import com.example.domain.model.CaptureMode
import com.example.domain.model.DeviceCapabilityReport
import com.example.domain.model.LengthUnit
import com.example.domain.model.ScanSession
import com.example.ui.components.BadgeTone
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.components.SectionHeader
import com.example.ui.navigation.AureomNavDestination
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.PearlBackground
import com.example.ui.theme.TealMeasurement
import com.example.ui.theme.VioletHighlight
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    sessions: List<ScanSession>,
    capabilities: DeviceCapabilityReport,
    lengthUnit: LengthUnit,
    isExpandedWidth: Boolean,
    onNavigate: (AureomNavDestination) -> Unit,
    onStartMode: (CaptureMode) -> Unit,
    onOpenSessionModel: (String) -> Unit,
    onOpenSessionMeasurements: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("home_lazy_column"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Scientific Hero Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(if (isExpandedWidth) 210.dp else 190.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_aureom_hero_1795423654356),
                        contentDescription = "Aureom scientific isometric body model illustration",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        PearlBackground.copy(alpha = 0.96f),
                                        PearlBackground.copy(alpha = 0.85f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.fillMaxWidth(0.72f)) {
                            ProvenanceBadge("LOCAL-FIRST METROLOGY", BadgeTone.MIDNIGHT)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "AUREOM BODYSCAN",
                                style = MaterialTheme.typography.headlineSmall,
                                color = MidnightBlue
                            )
                            Text(
                                text = "Calibrated body capture, uncertainty-aware measurements, posture geometry, and interactive 3D inspection.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { onStartMode(CaptureMode.GUIDED_PHOTOGRAPHS) },
                                colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                                modifier = Modifier.testTag("home_start_scan_button")
                            ) {
                                Icon(Icons.Outlined.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Guided Scan")
                            }
                            OutlinedButton(
                                onClick = { onStartMode(CaptureMode.MANUAL_MEASUREMENTS) },
                                modifier = Modifier.testTag("home_manual_entry_button")
                            ) {
                                Icon(Icons.Outlined.Straighten, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Manual Tape")
                            }
                        }
                    }
                }
            }
        }

        item {
            ScientificDisclaimerBanner(
                text = "Camera-derived dimensions are physical estimates with propagated ± uncertainty. Pose skeletons are not surface scans, and uncalibrated frames never output metric lengths."
            )
        }

        item {
            SectionHeader(
                title = "Device Capability Summary",
                subtitle = "${capabilities.deviceModel} · Android SDK ${capabilities.androidSdkInt}"
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CapabilitySummaryChip(
                    label = "RGB + Pose",
                    status = if (capabilities.hasRgbCamera) "Implemented" else "Unsupported",
                    tone = if (capabilities.hasRgbCamera) BadgeTone.TEAL else BadgeTone.ERROR,
                    modifier = Modifier.weight(1f)
                )
                CapabilitySummaryChip(
                    label = "Depth ToF",
                    status = if (capabilities.hasHardwareDepthOutput) "Implemented" else "Unsupported",
                    tone = if (capabilities.hasHardwareDepthOutput) BadgeTone.TEAL else BadgeTone.ERROR,
                    modifier = Modifier.weight(1f)
                )
                CapabilitySummaryChip(
                    label = "3D Recon",
                    status = if (capabilities.isBackendConfigured && capabilities.isCloudOptInEnabled) "Backend" else "Gated",
                    tone = if (capabilities.isBackendConfigured && capabilities.isCloudOptInEnabled) BadgeTone.VIOLET else BadgeTone.WARNING,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            SectionHeader(
                title = "Workspaces",
                subtitle = "All 9 scientific capture, inspection, and governance modules"
            )
            Spacer(Modifier.height(8.dp))
            val quickDests = AureomNavDestination.entries.filter { it != AureomNavDestination.HOME }
            val cols = if (isExpandedWidth) 4 else 2
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                quickDests.chunked(cols).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowItems.forEach { dest ->
                            WorkspaceTile(
                                dest = dest,
                                onClick = { onNavigate(dest) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(cols - rowItems.size) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "Sessions & Reproducible Fixtures",
                subtitle = "${sessions.size} stored record(s) · Tap to inspect 3D model or measurements"
            )
        }

        items(sessions, key = { it.id }) { session ->
            val stature = session.measurements.firstOrNull { it.metricKey == "stature" }
            val dateStr = SimpleDateFormat("MMM d, HH:mm", Locale.US).format(Date(session.createdAtMs))
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_session_${session.id}")
                    .clickable { onOpenSessionModel(session.id) }
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = session.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.width(8.dp))
                        ProvenanceBadge(
                            text = if (session.isDemoFixture) "DEMO FIXTURE" else session.captureMode.shortBadge,
                            tone = if (session.isDemoFixture) BadgeTone.WARNING else BadgeTone.TEAL
                        )
                    }
                    Text(
                        text = "$dateStr · Calibration: ${session.calibration.source.displayLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Stature: ${UnitConverter.formatLengthWithUncertainty(stature?.valueMm, stature?.uncertaintyMm, lengthUnit)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = TealMeasurement
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onOpenSessionMeasurements(session.id) },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text("Metrics", style = MaterialTheme.typography.labelLarge)
                            }
                            Button(
                                onClick = { onOpenSessionModel(session.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Outlined.ViewInAr, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("3D View", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CapabilitySummaryChip(
    label: String,
    status: String,
    tone: BadgeTone,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurface)
            ProvenanceBadge(status, tone)
        }
    }
}

@Composable
private fun WorkspaceTile(
    dest: AureomNavDestination,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("home_tile_${dest.testTag}"),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = dest.icon,
                        contentDescription = dest.label,
                        tint = VioletHighlight,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Text(
                text = dest.label,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
