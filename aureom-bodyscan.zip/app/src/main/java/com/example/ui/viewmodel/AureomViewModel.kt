package com.example.ui.viewmodel

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.adapters.BleForceSensorAdapter
import com.example.adapters.Body3DRendererAdapter
import com.example.adapters.DeviceCapabilityInspector
import com.example.adapters.DiscoveredForceDevice
import com.example.adapters.FastApiReconstructionClient
import com.example.adapters.MlKitPoseEstimatorAdapter
import com.example.adapters.PoseEstimatorAdapter
import com.example.adapters.ReconstructionResult
import com.example.adapters.SimulatedForceSensorAdapter
import com.example.adapters.SoftwareMatrix3DRenderer
import com.example.data.local.AppPreferencesState
import com.example.data.local.AuditEventEntity
import com.example.data.local.AureomDatabase
import com.example.data.local.PrivacyPreferencesStore
import com.example.data.local.PrivateFileStore
import com.example.data.local.SecureCredentialStore
import com.example.data.repository.DemoFixturesFactory
import com.example.data.repository.ScanRepository
import com.example.domain.math.CalibrationSolver
import com.example.domain.math.GeometryMath
import com.example.domain.math.MeshGenerator
import com.example.domain.math.SessionComparisonResult
import com.example.domain.math.UncertaintyEngine
import com.example.domain.math.UnitConverter
import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.BodyMeasurementRecord
import com.example.domain.model.BodyMeshModel
import com.example.domain.model.CalibrationProvenance
import com.example.domain.model.CalibrationSource
import com.example.domain.model.CaptureAngle
import com.example.domain.model.CaptureMode
import com.example.domain.model.CapturedFrameInfo
import com.example.domain.model.CoordinateSystemType
import com.example.domain.model.DeviceCapabilityReport
import com.example.domain.model.ForceSamplePoint
import com.example.domain.model.ForceSensorTrial
import com.example.domain.model.ForceUnit
import com.example.domain.model.GuidedWorkflowStage
import com.example.domain.model.LengthUnit
import com.example.domain.model.MeasurementCategory
import com.example.domain.model.MeasurementQualityStatus
import com.example.domain.model.MeasurementSource
import com.example.domain.model.ModelProvenanceType
import com.example.domain.model.MovementSequence
import com.example.domain.model.PostureAnalysisSnapshot
import com.example.domain.model.ProjectionMode3D
import com.example.domain.model.QualityIssueType
import com.example.domain.model.ScanSession
import com.example.domain.model.SessionProcessingState
import com.example.domain.model.ViewPreset3D
import com.example.domain.model.Viewport3DState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException

data class GuidedScanDraft(
    val draftSessionId: String = "scan_${UUID.randomUUID().toString().take(8)}",
    val stage: GuidedWorkflowStage = GuidedWorkflowStage.CONSENT,
    val selectedMode: CaptureMode = CaptureMode.GUIDED_PHOTOGRAPHS,
    val sessionTitle: String = "Guided Body Scan",
    val localConsentChecked: Boolean = false,
    val cloudOptInChecked: Boolean = false,
    val calibrationChoice: CalibrationSource = CalibrationSource.A4_REFERENCE_CARD,
    val userHeightInput: String = "174.0",
    val a4PixelSpanEstimate: Double = 264.0,
    val activeAngle: CaptureAngle = CaptureAngle.FRONT,
    val capturedFrames: List<CapturedFrameInfo> = emptyList(),
    val isProcessing: Boolean = false,
    val processingStatusMessage: String = "",
    val processingProgress: Float = 0f,
    val completedSessionId: String? = null,
    val reconstructionFeedback: String? = null
)

class AureomViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context = application.applicationContext
    private val database = AureomDatabase.getInstance(context)
    private val fileStore = PrivateFileStore(context)
    private val prefsStore = PrivacyPreferencesStore(context)
    private val credentialStore = SecureCredentialStore(context)
    private val reconstructionClient = FastApiReconstructionClient()
    private val repository = ScanRepository(database.aureomDao(), fileStore, reconstructionClient)
    private val capabilityInspector = DeviceCapabilityInspector(context)

    val poseEstimator: PoseEstimatorAdapter = MlKitPoseEstimatorAdapter(streamMode = false)
    val liveStreamPoseAdapter: MlKitPoseEstimatorAdapter = MlKitPoseEstimatorAdapter(streamMode = true)
    val renderer3D: Body3DRendererAdapter = SoftwareMatrix3DRenderer()
    private val simulatedForceAdapter = SimulatedForceSensorAdapter()
    private val bleForceAdapter = BleForceSensorAdapter(context)

    val preferences: StateFlow<AppPreferencesState> = prefsStore.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppPreferencesState())

    val sessions: StateFlow<List<ScanSession>> = repository.sessionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val forceTrials: StateFlow<List<ForceSensorTrial>> = repository.forceTrialsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movementSequences: StateFlow<List<MovementSequence>> = repository.movementSequencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditEvents: StateFlow<List<AuditEventEntity>> = repository.auditEventsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeSessionId = MutableStateFlow<String?>(null)
    val activeSessionId: StateFlow<String?> = _activeSessionId.asStateFlow()

    val activeSession: StateFlow<ScanSession?> = combine(sessions, activeSessionId) { list, id ->
        list.firstOrNull { it.id == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeMeshModel: StateFlow<BodyMeshModel?> = combine(activeSession) { arr ->
        arr[0]?.let { MeshGenerator.buildModelForSession(it) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _viewportState = MutableStateFlow(Viewport3DState())
    val viewportState: StateFlow<Viewport3DState> = _viewportState.asStateFlow()

    private val _capabilities = MutableStateFlow(
        capabilityInspector.inspect(isBackendConfigured = false, isCloudOptInEnabled = false)
    )
    val capabilities: StateFlow<DeviceCapabilityReport> = _capabilities.asStateFlow()

    private val _guidedDraft = MutableStateFlow(GuidedScanDraft())
    val guidedDraft: StateFlow<GuidedScanDraft> = _guidedDraft.asStateFlow()

    private val _comparisonBaselineId = MutableStateFlow<String?>(null)
    private val _comparisonTargetId = MutableStateFlow<String?>(null)

    val comparisonResult: StateFlow<SessionComparisonResult?> = combine(
        sessions,
        _comparisonBaselineId,
        _comparisonTargetId
    ) { list, baseId, targetId ->
        val base = list.firstOrNull { it.id == baseId } ?: list.getOrNull(1)
        val target = list.firstOrNull { it.id == targetId } ?: list.firstOrNull()
        if (base != null && target != null && base.id != target.id) {
            UncertaintyEngine.compareSessions(base, target)
        } else null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Movement playback state
    private val _selectedMovementId = MutableStateFlow<String?>(null)
    val selectedMovement: StateFlow<MovementSequence?> = combine(movementSequences, _selectedMovementId) { list, id ->
        list.firstOrNull { it.id == id } ?: list.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _movementFrameIdx = MutableStateFlow(0)
    val movementFrameIdx: StateFlow<Int> = _movementFrameIdx.asStateFlow()

    private val _isMovementPlaying = MutableStateFlow(false)
    val isMovementPlaying: StateFlow<Boolean> = _isMovementPlaying.asStateFlow()

    private val _showMovementTrails = MutableStateFlow(true)
    val showMovementTrails: StateFlow<Boolean> = _showMovementTrails.asStateFlow()

    // Force sensor live state
    private val _availableForceDevices = MutableStateFlow(simulatedForceAdapter.scanAvailableDevices())
    val availableForceDevices: StateFlow<List<DiscoveredForceDevice>> = _availableForceDevices.asStateFlow()

    private val _selectedForceDevice = MutableStateFlow(simulatedForceAdapter.scanAvailableDevices().first())
    val selectedForceDevice: StateFlow<DiscoveredForceDevice> = _selectedForceDevice.asStateFlow()

    private val _liveForceSamples = MutableStateFlow<List<ForceSamplePoint>>(emptyList())
    val liveForceSamples: StateFlow<List<ForceSamplePoint>> = _liveForceSamples.asStateFlow()

    private val _isRecordingForce = MutableStateFlow(false)
    val isRecordingForce: StateFlow<Boolean> = _isRecordingForce.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _backendHealthStatus = MutableStateFlow<String?>(null)
    val backendHealthStatus: StateFlow<String?> = _backendHealthStatus.asStateFlow()

    private var processingJob: Job? = null
    private var movementJob: Job? = null
    private var forceStreamJob: Job? = null
    private var bleStopScan: (() -> Unit)? = null

    init {
        viewModelScope.launch {
            repository.ensureDemoFixturesSeeded()
        }
        viewModelScope.launch {
            preferences.collect { prefs ->
                _capabilities.value = capabilityInspector.inspect(
                    isBackendConfigured = reconstructionClient.isValidEndpointUrl(prefs.backendEndpointUrl),
                    isCloudOptInEnabled = prefs.isCloudUploadOptIn
                )
                _guidedDraft.update { draft ->
                    if (draft.stage == GuidedWorkflowStage.CONSENT) {
                        draft.copy(
                            localConsentChecked = prefs.hasLocalCaptureConsent,
                            cloudOptInChecked = prefs.isCloudUploadOptIn
                        )
                    } else draft
                }
            }
        }
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun selectSession(sessionId: String) {
        _activeSessionId.value = sessionId
    }

    fun setComparisonSessions(baselineId: String, targetId: String) {
        _comparisonBaselineId.value = baselineId
        _comparisonTargetId.value = targetId
    }

    // ---- 3D Viewport Controls ----

    fun rotateViewport(deltaYaw: Float, deltaPitch: Float) {
        _viewportState.update {
            it.copy(
                yawDeg = (it.yawDeg + deltaYaw) % 360f,
                pitchDeg = (it.pitchDeg + deltaPitch).coerceIn(-80f, 80f)
            )
        }
    }

    fun panViewport(dx: Float, dy: Float) {
        _viewportState.update {
            it.copy(
                panX = (it.panX + dx).coerceIn(-320f, 320f),
                panY = (it.panY + dy).coerceIn(-320f, 320f)
            )
        }
    }

    fun zoomViewport(factor: Float) {
        _viewportState.update {
            it.copy(zoom = (it.zoom * factor).coerceIn(0.55f, 2.6f))
        }
    }

    fun applyViewportPreset(preset: ViewPreset3D) {
        _viewportState.update {
            it.copy(
                yawDeg = preset.yawDeg,
                pitchDeg = preset.pitchDeg,
                projectionMode = preset.forceOrthographic?.let { ortho ->
                    if (ortho) ProjectionMode3D.ORTHOGRAPHIC else ProjectionMode3D.PERSPECTIVE
                } ?: it.projectionMode
            )
        }
    }

    fun setProjectionMode(mode: ProjectionMode3D) {
        _viewportState.update { it.copy(projectionMode = mode) }
    }

    fun toggleViewportOverlay(
        measurements: Boolean? = null,
        skeleton: Boolean? = null,
        coverage: Boolean? = null
    ) {
        _viewportState.update {
            it.copy(
                showMeasurements = measurements ?: it.showMeasurements,
                showSkeleton = skeleton ?: it.showSkeleton,
                showCoverageMap = coverage ?: it.showCoverageMap
            )
        }
    }

    fun setClippingBounds(minNormY: Float, maxNormY: Float) {
        val low = minNormY.coerceIn(0f, 0.9f)
        val high = maxNormY.coerceIn(low + 0.1f, 1.0f)
        _viewportState.update { it.copy(clipMinNormalizedY = low, clipMaxNormalizedY = high) }
    }

    fun resetViewportCamera() {
        _viewportState.value = Viewport3DState()
    }

    // ---- Guided Scan Workflow ----

    fun startNewScanDraft(mode: CaptureMode = CaptureMode.GUIDED_PHOTOGRAPHS) {
        val prefs = preferences.value
        _guidedDraft.value = GuidedScanDraft(
            draftSessionId = "scan_${UUID.randomUUID().toString().take(8)}",
            stage = GuidedWorkflowStage.CONSENT,
            selectedMode = mode,
            sessionTitle = "${mode.title} · ${java.text.SimpleDateFormat("MMM d HH:mm", java.util.Locale.US).format(java.util.Date())}",
            localConsentChecked = prefs.hasLocalCaptureConsent,
            cloudOptInChecked = prefs.isCloudUploadOptIn
        )
    }

    fun setDraftStage(stage: GuidedWorkflowStage) {
        _guidedDraft.update { it.copy(stage = stage) }
    }

    fun setDraftMode(mode: CaptureMode) {
        _guidedDraft.update { it.copy(selectedMode = mode) }
    }

    fun updateDraftConsent(localConsent: Boolean, cloudOptIn: Boolean) {
        _guidedDraft.update {
            it.copy(localConsentChecked = localConsent, cloudOptInChecked = cloudOptIn)
        }
        viewModelScope.launch {
            prefsStore.setLocalCaptureConsent(localConsent)
            prefsStore.setCloudUploadOptIn(cloudOptIn)
        }
    }

    fun updateDraftCalibration(source: CalibrationSource, userHeightText: String? = null) {
        _guidedDraft.update {
            it.copy(
                calibrationChoice = source,
                userHeightInput = userHeightText ?: it.userHeightInput
            )
        }
    }

    fun setDraftCaptureAngle(angle: CaptureAngle) {
        _guidedDraft.update { it.copy(activeAngle = angle) }
    }

    fun attachCapturedImageFile(angle: CaptureAngle, imageFile: File, motionStability: Float) {
        viewModelScope.launch {
            val frameInfo = withContext(Dispatchers.Default) {
                val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath)
                if (bitmap == null) {
                    return@withContext CapturedFrameInfo(
                        id = UUID.randomUUID().toString(),
                        sessionId = _guidedDraft.value.draftSessionId,
                        angle = angle,
                        localFilePath = imageFile.absolutePath,
                        capturedAtMs = System.currentTimeMillis(),
                        imageWidthPx = 1080,
                        imageHeightPx = 1920,
                        meanLuma = 0f,
                        motionStabilityScore = motionStability,
                        landmarks = emptyList(),
                        occludedLandmarks = AnatomicalLandmark.entries,
                        qualityIssues = listOf(QualityIssueType.INSUFFICIENT_INPUT),
                        isSynthetic = false
                    )
                }
                analyzeBitmapIntoFrame(
                    sessionId = _guidedDraft.value.draftSessionId,
                    angle = angle,
                    bitmap = bitmap,
                    filePath = imageFile.absolutePath,
                    motionStability = motionStability
                )
            }
            appendDraftFrame(frameInfo)
        }
    }

    fun importPhotoFromPicker(angle: CaptureAngle, uri: Uri) {
        viewModelScope.launch {
            val imported = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        BitmapFactory.decodeStream(stream)
                    }
                }.getOrNull()
            }
            if (imported == null) {
                _statusBanner.value = "Could not decode selected photo."
                return@launch
            }
            val savedFile = withContext(Dispatchers.IO) {
                fileStore.writeBitmapCapture(_guidedDraft.value.draftSessionId, angle.name, imported)
            }
            val frameInfo = withContext(Dispatchers.Default) {
                analyzeBitmapIntoFrame(
                    sessionId = _guidedDraft.value.draftSessionId,
                    angle = angle,
                    bitmap = imported,
                    filePath = savedFile.absolutePath,
                    motionStability = 0.90f
                )
            }
            appendDraftFrame(frameInfo)
        }
    }

    /**
     * Allows reproducible testing on devices/emulators without a physical subject in front of the lens.
     * Explicitly tagged isSynthetic = true.
     */
    fun addSyntheticTestFrame(angle: CaptureAngle) {
        val draft = _guidedDraft.value
        val frame = CapturedFrameInfo(
            id = UUID.randomUUID().toString(),
            sessionId = draft.draftSessionId,
            angle = angle,
            localFilePath = null,
            capturedAtMs = System.currentTimeMillis(),
            imageWidthPx = 1080,
            imageHeightPx = 1920,
            meanLuma = 148f,
            motionStabilityScore = 0.96f,
            landmarks = DemoFixturesFactory.standardStandingLandmarks(),
            occludedLandmarks = emptyList(),
            qualityIssues = emptyList(),
            isSynthetic = true
        )
        appendDraftFrame(frame)
    }

    private fun appendDraftFrame(frame: CapturedFrameInfo) {
        _guidedDraft.update { draft ->
            // Replace existing angle slot if user recaptures that angle
            val oldForAngle = draft.capturedFrames.filter { it.angle == frame.angle }
            oldForAngle.forEach { fileStore.deleteFileAtPath(it.localFilePath) }
            val updated = draft.capturedFrames.filterNot { it.angle == frame.angle } + frame
            val nextAngle = CaptureAngle.entries.firstOrNull { a -> updated.none { it.angle == a } } ?: draft.activeAngle
            draft.copy(capturedFrames = updated, activeAngle = nextAngle)
        }
    }

    fun deleteDraftFrame(frameId: String) {
        val target = _guidedDraft.value.capturedFrames.firstOrNull { it.id == frameId }
        fileStore.deleteFileAtPath(target?.localFilePath)
        _guidedDraft.update { draft ->
            draft.copy(capturedFrames = draft.capturedFrames.filterNot { it.id == frameId })
        }
    }

    fun buildTargetCaptureFile(angle: CaptureAngle): File {
        return fileStore.createTargetImageFile(_guidedDraft.value.draftSessionId, angle.name)
    }

    private suspend fun analyzeBitmapIntoFrame(
        sessionId: String,
        angle: CaptureAngle,
        bitmap: Bitmap,
        filePath: String,
        motionStability: Float
    ): CapturedFrameInfo {
        val luma = computeMeanLuma(bitmap)
        val poseRes = poseEstimator.estimateFromBitmap(bitmap).getOrNull()
        val landmarks = poseRes?.landmarks.orEmpty()
        val occluded = poseRes?.occludedLandmarks ?: listOf(AnatomicalLandmark.LEFT_ANKLE, AnatomicalLandmark.RIGHT_ANKLE)

        val issues = mutableListOf<QualityIssueType>()
        if (luma < 52f) issues.add(QualityIssueType.INSUFFICIENT_INPUT)
        if (motionStability < 0.70f) issues.add(QualityIssueType.EXCESSIVE_MOTION)
        if (landmarks.size < 12 || occluded.size > 4) issues.add(QualityIssueType.OCCLUSION)

        return CapturedFrameInfo(
            id = UUID.randomUUID().toString(),
            sessionId = sessionId,
            angle = angle,
            localFilePath = filePath,
            capturedAtMs = System.currentTimeMillis(),
            imageWidthPx = bitmap.width,
            imageHeightPx = bitmap.height,
            meanLuma = luma,
            motionStabilityScore = motionStability,
            landmarks = landmarks,
            occludedLandmarks = occluded,
            qualityIssues = issues,
            isSynthetic = false
        )
    }

    private fun computeMeanLuma(bitmap: Bitmap): Float {
        val stepX = (bitmap.width / 24).coerceAtLeast(1)
        val stepY = (bitmap.height / 24).coerceAtLeast(1)
        var sum = 0.0
        var count = 0
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val px = bitmap.getPixel(x, y)
                val r = (px shr 16) and 0xFF
                val g = (px shr 8) and 0xFF
                val b = px and 0xFF
                sum += 0.299 * r + 0.587 * g + 0.114 * b
                count++
                x += stepX
            }
            y += stepY
        }
        return if (count == 0) 0f else (sum / count).toFloat()
    }

    fun processDraftSession() {
        val draft = _guidedDraft.value
        if (!draft.localConsentChecked) {
            _statusBanner.value = "Explicit local capture consent is required before processing."
            return
        }
        if (draft.capturedFrames.isEmpty()) {
            _statusBanner.value = "Capture at least one view (Front recommended) before processing."
            return
        }

        processingJob?.cancel()
        processingJob = viewModelScope.launch {
            _guidedDraft.update {
                it.copy(
                    stage = GuidedWorkflowStage.PROCESSING,
                    isProcessing = true,
                    processingProgress = 0.15f,
                    processingStatusMessage = "Verifying calibration provenance..."
                )
            }
            try {
                delay(280)
                val calibration = solveDraftCalibration(draft)

                _guidedDraft.update {
                    it.copy(
                        processingProgress = 0.45f,
                        processingStatusMessage = "Extracting calibrated segment geometry & uncertainty..."
                    )
                }
                delay(280)
                val nowMs = System.currentTimeMillis()
                val measurements = GeometryMath.deriveMeasurementsFromFrames(
                    sessionId = draft.draftSessionId,
                    frames = draft.capturedFrames,
                    calibration = calibration,
                    nowMs = nowMs
                )

                val covered = draft.capturedFrames.map { it.angle }.toSet()
                val hasWarnings = !calibration.isScaleVerified ||
                    covered.size < 3 ||
                    draft.capturedFrames.any { it.qualityIssues.isNotEmpty() }

                var provenance = when {
                    draft.capturedFrames.all { it.isSynthetic } -> ModelProvenanceType.SYNTHETIC_DEMO_MODEL
                    covered.size < 3 -> ModelProvenanceType.PARTIAL_COVERAGE_MODEL
                    calibration.isScaleVerified -> ModelProvenanceType.ESTIMATED_PARAMETRIC_AVATAR
                    else -> ModelProvenanceType.POSE_SKELETON_ONLY
                }
                var procState = if (hasWarnings) {
                    SessionProcessingState.PARTIAL_WITH_WARNINGS
                } else {
                    SessionProcessingState.COMPLETED
                }
                var backendJobId: String? = null
                var reconMessage: String? = null

                if (draft.selectedMode == CaptureMode.RECONSTRUCTION_3D) {
                    _guidedDraft.update {
                        it.copy(
                            processingProgress = 0.72f,
                            processingStatusMessage = "Checking reconstruction capability adapter..."
                        )
                    }
                    val prefs = preferences.value
                    val tempSession = ScanSession(
                        id = draft.draftSessionId,
                        title = draft.sessionTitle,
                        createdAtMs = nowMs,
                        captureMode = draft.selectedMode,
                        processingState = procState,
                        calibration = calibration,
                        frames = draft.capturedFrames,
                        measurements = measurements,
                        modelProvenance = provenance,
                        coveredSectors = covered,
                        equipmentDescription = "Device CameraX + ${poseEstimator.adapterName}",
                        environmentConditions = "Guided capture",
                        isDemoFixture = false
                    )
                    when (val reconRes = reconstructionClient.submitReconstruction(
                        session = tempSession,
                        cloudUploadOptIn = prefs.isCloudUploadOptIn,
                        endpointUrl = prefs.backendEndpointUrl,
                        bearerToken = credentialStore.getBackendToken()
                    )) {
                        is ReconstructionResult.Success -> {
                            backendJobId = reconRes.jobId
                            provenance = ModelProvenanceType.RECONSTRUCTED_MESH
                            reconMessage = reconRes.message
                        }
                        is ReconstructionResult.Unsupported -> {
                            procState = SessionProcessingState.FAILED_RECONSTRUCTION
                            reconMessage = reconRes.reason
                        }
                        is ReconstructionResult.Failure -> {
                            procState = SessionProcessingState.FAILED_RECONSTRUCTION
                            reconMessage = reconRes.reason
                        }
                    }
                }

                _guidedDraft.update {
                    it.copy(
                        processingProgress = 0.92f,
                        processingStatusMessage = "Persisting session metadata & provenance to Room..."
                    )
                }

                val session = ScanSession(
                    id = draft.draftSessionId,
                    title = draft.sessionTitle,
                    createdAtMs = nowMs,
                    captureMode = draft.selectedMode,
                    processingState = procState,
                    calibration = calibration,
                    frames = draft.capturedFrames,
                    measurements = measurements,
                    modelProvenance = provenance,
                    coveredSectors = covered,
                    equipmentDescription = if (draft.capturedFrames.all { it.isSynthetic }) {
                        "Synthetic Guided Frame Fixture"
                    } else {
                        "${Build.MANUFACTURER} ${Build.MODEL} CameraX"
                    },
                    environmentConditions = "Covered: ${covered.joinToString { it.label }}",
                    isDemoFixture = false,
                    backendJobId = backendJobId
                )
                repository.saveSession(session)
                _activeSessionId.value = session.id

                if (preferences.value.privateNotificationsEnabled) {
                    sendPrivacySafeNotification()
                }

                _guidedDraft.update {
                    it.copy(
                        stage = GuidedWorkflowStage.RESULTS,
                        isProcessing = false,
                        processingProgress = 1f,
                        processingStatusMessage = "Completed",
                        completedSessionId = session.id,
                        reconstructionFeedback = reconMessage
                    )
                }
            } catch (_: CancellationException) {
                // Clean rollback: do NOT save partial/corrupt measurement rows on interrupted processing
                _guidedDraft.update {
                    it.copy(
                        stage = GuidedWorkflowStage.QUALITY_REVIEW,
                        isProcessing = false,
                        processingProgress = 0f,
                        processingStatusMessage = "Processing interrupted by user; no partial results saved."
                    )
                }
            }
        }
    }

    fun cancelProcessing() {
        processingJob?.cancel()
    }

    private fun solveDraftCalibration(draft: GuidedScanDraft): CalibrationProvenance {
        return when (draft.calibrationChoice) {
            CalibrationSource.NONE -> CalibrationSolver.uncalibrated()
            CalibrationSource.A4_REFERENCE_CARD -> CalibrationSolver.solveFromReferenceSpan(
                source = CalibrationSource.A4_REFERENCE_CARD,
                referencePixelSpan = draft.a4PixelSpanEstimate,
                referencePhysicalMm = CalibrationSolver.A4_HEIGHT_MM,
                referenceTolerancePercent = 1.6,
                estimatedCameraDistanceMeters = 2.2
            )
            CalibrationSource.ARUCO_MARKER -> CalibrationSolver.solveFromReferenceSpan(
                source = CalibrationSource.ARUCO_MARKER,
                referencePixelSpan = 135.0,
                referencePhysicalMm = CalibrationSolver.ARUCO_150_MM,
                referenceTolerancePercent = 1.3,
                estimatedCameraDistanceMeters = 2.2
            )
            CalibrationSource.USER_HEIGHT_REFERENCE -> {
                val inputVal = draft.userHeightInput.toDoubleOrNull() ?: 0.0
                val userMm = UnitConverter.unitToMm(inputVal, preferences.value.lengthUnit)
                val front = draft.capturedFrames.firstOrNull { it.angle == CaptureAngle.FRONT }
                val noseY = front?.landmarks?.firstOrNull { it.landmarkType == AnatomicalLandmark.NOSE }?.yNorm ?: 0.14f
                val ankleY = front?.landmarks?.firstOrNull { it.landmarkType == AnatomicalLandmark.LEFT_ANKLE }?.yNorm ?: 0.88f
                val spanPx = ((ankleY - noseY) * (front?.imageHeightPx ?: 1920) * 1.08).coerceAtLeast(100.0)
                CalibrationSolver.solveFromUserHeight(userMm, spanPx)
            }
            else -> CalibrationSolver.uncalibrated()
        }
    }

    // ---- Manual Measurements ----

    fun saveManualMeasurementsSession(
        title: String,
        entriesInCurrentUnit: Map<String, Double>,
        notes: String
    ) {
        val unit = preferences.value.lengthUnit
        val sessionId = "manual_${UUID.randomUUID().toString().take(8)}"
        val nowMs = System.currentTimeMillis()
        val labels = mapOf(
            "stature" to Triple("Standing Height (Tape)", "Wall stadiometer / tape height.", MeasurementCategory.LINEAR_LENGTH),
            "shoulder_width" to Triple("Shoulder Breadth (Tape)", "Direct acromial span.", MeasurementCategory.BREADTH_WIDTH),
            "chest_circumference" to Triple("Chest Circumference (Tape)", "Mid-sternum horizontal tape.", MeasurementCategory.CIRCUMFERENCE),
            "waist_circumference" to Triple("Waist Circumference (Tape)", "Narrowest torso level tape.", MeasurementCategory.CIRCUMFERENCE),
            "hip_circumference_est" to Triple("Hip Circumference (Tape)", "Widest gluteal prominence tape.", MeasurementCategory.CIRCUMFERENCE)
        )
        val records = entriesInCurrentUnit.mapNotNull { (key, value) ->
            if (value <= 0.0) return@mapNotNull null
            val meta = labels[key] ?: Triple(key, "User-entered manual tape measurement.", MeasurementCategory.LINEAR_LENGTH)
            BodyMeasurementRecord(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                metricKey = key,
                label = meta.first,
                definition = meta.second,
                category = meta.third,
                valueMm = UnitConverter.unitToMm(value, unit),
                uncertaintyMm = 5.0,
                sourceMethod = MeasurementSource.MANUAL_TAPE,
                calibrationSource = CalibrationSource.MANUAL_TAPE,
                qualityStatus = MeasurementQualityStatus.MANUAL_ENTRY,
                coordinateOrigin = CoordinateSystemType.MANUAL_TAPE_MILLIMETERS,
                captureTimestampMs = nowMs,
                notes = "Entered in ${unit.symbol}"
            )
        }
        if (records.isEmpty()) {
            _statusBanner.value = "Enter at least one positive measurement value."
            return
        }
        val session = ScanSession(
            id = sessionId,
            title = title.ifBlank { "Manual Tape Session" },
            createdAtMs = nowMs,
            captureMode = CaptureMode.MANUAL_MEASUREMENTS,
            processingState = SessionProcessingState.COMPLETED,
            calibration = CalibrationSolver.solveFromReferenceSpan(
                source = CalibrationSource.MANUAL_TAPE,
                referencePixelSpan = 100.0,
                referencePhysicalMm = 100.0,
                referenceTolerancePercent = 0.5
            ),
            frames = emptyList(),
            measurements = records,
            modelProvenance = ModelProvenanceType.MANUAL_RECORD_ONLY,
            coveredSectors = emptySet(),
            equipmentDescription = "Manual Measuring Tape",
            environmentConditions = "User-entered offline",
            personalNotes = notes
        )
        viewModelScope.launch {
            repository.saveSession(session)
            _activeSessionId.value = session.id
            _statusBanner.value = "Saved manual tape session (${records.size} entries)."
        }
    }

    // ---- Posture Helper ----

    fun analyzePostureForSession(session: ScanSession): PostureAnalysisSnapshot? {
        val frame = session.frames.firstOrNull { it.angle == CaptureAngle.FRONT }
            ?: session.frames.firstOrNull()
            ?: return null
        val findings = GeometryMath.analyzePostureGeometry(frame, session.calibration)
        val meanConf = if (frame.landmarks.isEmpty()) 0f else frame.landmarks.map { it.visibility }.average().toFloat()
        return PostureAnalysisSnapshot(
            sessionId = session.id,
            title = session.title,
            viewpoint = frame.angle,
            capturedAtMs = frame.capturedAtMs,
            meanLandmarkConfidence = meanConf,
            occludedLandmarks = frame.occludedLandmarks,
            landmarks = frame.landmarks,
            findings = findings,
            isSyntheticDemo = session.isDemoFixture || frame.isSynthetic
        )
    }

    // ---- Movement Playback ----

    fun selectMovementSequence(id: String) {
        _selectedMovementId.value = id
        _movementFrameIdx.value = 0
        _isMovementPlaying.value = false
    }

    fun setMovementFrame(index: Int) {
        val maxIdx = (selectedMovement.value?.frames?.size ?: 1) - 1
        _movementFrameIdx.value = index.coerceIn(0, maxIdx.coerceAtLeast(0))
    }

    fun toggleMovementPlayback() {
        val next = !_isMovementPlaying.value
        _isMovementPlaying.value = next
        movementJob?.cancel()
        if (next) {
            movementJob = viewModelScope.launch {
                while (_isMovementPlaying.value) {
                    val seq = selectedMovement.value
                    val count = seq?.frames?.size ?: 0
                    if (count > 1) {
                        _movementFrameIdx.update { (it + 1) % count }
                        val delayMs = (1000f / (seq?.fps ?: 15f)).toLong().coerceIn(30L, 250L)
                        delay(delayMs)
                    } else {
                        _isMovementPlaying.value = false
                    }
                }
            }
        }
    }

    fun toggleMovementTrails() {
        _showMovementTrails.update { !it }
    }

    // ---- External Force Sensor Controls ----

    fun selectForceDevice(device: DiscoveredForceDevice) {
        _selectedForceDevice.value = device
    }

    fun scanBleDevices() {
        bleStopScan?.invoke()
        bleStopScan = bleForceAdapter.startBriefScan(
            onDeviceFound = { dev ->
                _availableForceDevices.update { current ->
                    if (current.any { it.id == dev.id }) current else current + dev
                }
            },
            onError = { msg ->
                _statusBanner.value = msg
            }
        )
    }

    fun recordForceTrial(exerciseSetup: String, durationSeconds: Int = 4) {
        if (_isRecordingForce.value) return
        val device = _selectedForceDevice.value
        if (!device.isSimulated) {
            _statusBanner.value = "Physical BLE GATT streaming requires paired load-cell hardware. Select a simulated sensor to run a demo trial."
            return
        }
        forceStreamJob?.cancel()
        forceStreamJob = viewModelScope.launch {
            _isRecordingForce.value = true
            _liveForceSamples.value = emptyList()
            val collected = mutableListOf<ForceSamplePoint>()
            try {
                simulatedForceAdapter.streamTrial(device, exerciseSetup, durationSeconds).collect { pt ->
                    collected.add(pt)
                    _liveForceSamples.value = collected.toList()
                }
                val summary = SimulatedForceSensorAdapter.buildTrialSummary(
                    device = device,
                    exerciseSetup = exerciseSetup,
                    samples = collected,
                    expectedSamples = durationSeconds * device.samplingRateHz,
                    durationSec = durationSeconds.toDouble()
                )
                repository.saveForceTrial(summary)
                _statusBanner.value = "Recorded ${collected.size} samples (${summary.missingSampleCount} dropped)."
            } finally {
                _isRecordingForce.value = false
            }
        }
    }

    fun deleteForceTrial(trialId: String) {
        viewModelScope.launch { repository.deleteForceTrial(trialId) }
    }

    // ---- History, Export, Privacy & Deletion ----

    fun updateSessionNotes(sessionId: String, notes: String) {
        viewModelScope.launch { repository.updateSessionNotes(sessionId, notes) }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            val prefs = preferences.value
            repository.deleteSessionCompletely(
                sessionId = sessionId,
                endpointUrl = prefs.backendEndpointUrl,
                bearerToken = credentialStore.getBackendToken()
            )
            if (_activeSessionId.value == sessionId) {
                _activeSessionId.value = null
            }
            _statusBanner.value = "Session and all derived files deleted."
        }
    }

    fun reseedDemoFixtures() {
        viewModelScope.launch {
            repository.seedAllDemoFixtures()
            _statusBanner.value = "Demonstration fixtures restored."
        }
    }

    fun createProvenanceShareUri(session: ScanSession): Uri? {
        return runCatching {
            val file = repository.exportSessionProvenanceFile(session)
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }.getOrNull()
    }

    fun createSnapshotShareUri(sessionId: String, bitmap: Bitmap): Uri? {
        return runCatching {
            val file = fileStore.saveViewSnapshotPng(sessionId, bitmap)
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }.getOrNull()
    }

    // ---- Preferences & Security ----

    fun setLengthUnit(unit: LengthUnit) {
        viewModelScope.launch { prefsStore.setLengthUnit(unit) }
    }

    fun setForceUnit(unit: ForceUnit) {
        viewModelScope.launch { prefsStore.setForceUnit(unit) }
    }

    fun setReducedMotion(enabled: Boolean) {
        viewModelScope.launch { prefsStore.setReducedMotion(enabled) }
    }

    fun setDarkLabTheme(enabled: Boolean) {
        viewModelScope.launch { prefsStore.setDarkLabTheme(enabled) }
    }

    fun setPrivateNotifications(enabled: Boolean) {
        viewModelScope.launch { prefsStore.setPrivateNotifications(enabled) }
    }

    fun setRetentionDays(days: Int) {
        viewModelScope.launch {
            prefsStore.setRetentionDays(days)
            val purged = repository.enforceRetentionPolicy(days)
            if (purged > 0) {
                _statusBanner.value = "Retention policy removed $purged expired session(s)."
            }
        }
    }

    fun purgeExpiredNow() {
        viewModelScope.launch {
            val days = preferences.value.retentionDays.let { if (it <= 0) 30 else it }
            val purged = repository.enforceRetentionPolicy(days)
            _statusBanner.value = "Purged $purged session(s) older than $days days."
        }
    }

    fun wipeAllLocalData() {
        viewModelScope.launch {
            repository.purgeAllUserAndDemoData()
            credentialStore.clearBackendToken()
            _activeSessionId.value = null
            _statusBanner.value = "All sessions, models, credentials, and private files erased."
        }
    }

    fun updateBackendConfiguration(endpointUrl: String, cloudOptIn: Boolean, token: String?) {
        viewModelScope.launch {
            prefsStore.setBackendEndpointUrl(endpointUrl)
            prefsStore.setCloudUploadOptIn(cloudOptIn)
            if (token != null) {
                credentialStore.saveBackendToken(token)
            }
            _statusBanner.value = "Backend settings saved locally."
        }
    }

    fun checkBackendHealth() {
        val prefs = preferences.value
        viewModelScope.launch {
            _backendHealthStatus.value = "Checking..."
            val res = reconstructionClient.checkHealth(
                endpointUrl = prefs.backendEndpointUrl,
                bearerToken = credentialStore.getBackendToken()
            )
            _backendHealthStatus.value = res.fold(
                onSuccess = { "Online: $it" },
                onFailure = { "Offline / Invalid: ${it.message}" }
            )
        }
    }

    fun hasStoredBackendToken(): Boolean = credentialStore.hasStoredToken()
    fun isKeystoreBacked(): Boolean = credentialStore.isHardwareKeystoreBacked()
    fun totalPrivateStorageBytes(): Long = fileStore.totalPrivateStorageBytes()

    private fun sendPrivacySafeNotification() {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val channelId = "aureom_scan_processing"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                channelId,
                context.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(ch)
        }
        val notif = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(context.getString(R.string.notification_complete_title))
            .setContentText(context.getString(R.string.notification_complete_body))
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .build()
        runCatching { manager.notify(1042, notif) }
    }

    override fun onCleared() {
        super.onCleared()
        bleStopScan?.invoke()
        processingJob?.cancel()
        movementJob?.cancel()
        forceStreamJob?.cancel()
    }
}
