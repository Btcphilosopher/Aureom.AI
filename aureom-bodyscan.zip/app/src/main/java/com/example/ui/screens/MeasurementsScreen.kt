package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.domain.math.UnitConverter
import com.example.domain.model.BodyMeasurementRecord
import com.example.domain.model.LengthUnit
import com.example.domain.model.MeasurementQualityStatus
import com.example.domain.model.ScanSession
import com.example.ui.components.BadgeTone
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.SessionSelectorBar
import com.example.ui.theme.MetricReadoutStyle
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.TealMeasurement
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MeasurementsScreen(
    sessions: List<ScanSession>,
    activeSession: ScanSession?,
    lengthUnit: LengthUnit,
    onSelectSession: (String) -> Unit,
    onSetUnit: (LengthUnit) -> Unit,
    onSaveManualEntry: (String, Map<String, Double>, String) -> Unit
) {
    var showManualForm by remember { mutableStateOf(false) }
    var manualTitle by remember { mutableStateOf("Manual Tape Session") }
    var heightInput by remember { mutableStateOf("") }
    var shoulderInput by remember { mutableStateOf("") }
    var chestInput by remember { mutableStateOf("") }
    var waistInput by remember { mutableStateOf("") }
    var hipInput by remember { mutableStateOf("") }
    var manualNotes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SessionSelectorBar(
                sessions = sessions,
                activeSessionId = activeSession?.id,
                onSelectSession = onSelectSession
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LengthUnit.entries.forEach { unit ->
                        FilterChip(
                            selected = lengthUnit == unit,
                            onClick = { onSetUnit(unit) },
                            modifier = Modifier.testTag("unit_${unit.name}"),
                            label = { Text(unit.symbol) }
                        )
                    }
                }
                OutlinedButton(
                    onClick = { showManualForm = !showManualForm },
                    modifier = Modifier.testTag("toggle_manual_form_button")
                ) {
                    Text(if (showManualForm) "Close Manual Form" else "+ Manual Tape Entry")
                }
            }
        }

        if (showManualForm) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SectionHeader(
                            title = "Manual Tape Entry (${lengthUnit.label})",
                            subtitle = "Stored separately from camera-derived estimates; internal units retained in mm."
                        )
                        OutlinedTextField(
                            value = manualTitle,
                            onValueChange = { manualTitle = it },
                            label = { Text("Session Title") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumericField("Height (${lengthUnit.symbol})", heightInput, { heightInput = it }, Modifier.weight(1f))
                            NumericField("Shoulders (${lengthUnit.symbol})", shoulderInput, { shoulderInput = it }, Modifier.weight(1f))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NumericField("Chest (${lengthUnit.symbol})", chestInput, { chestInput = it }, Modifier.weight(1f))
                            NumericField("Waist (${lengthUnit.symbol})", waistInput, { waistInput = it }, Modifier.weight(1f))
                        }
                        NumericField("Hip (${lengthUnit.symbol})", hipInput, { hipInput = it }, Modifier.fillMaxWidth())
                        OutlinedTextField(
                            value = manualNotes,
                            onValueChange = { manualNotes = it },
                            label = { Text("Measurement Conditions / Notes") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                val entries = buildMap {
                                    heightInput.toDoubleOrNull()?.let { put("stature", it) }
                                    shoulderInput.toDoubleOrNull()?.let { put("shoulder_width", it) }
                                    chestInput.toDoubleOrNull()?.let { put("chest_circumference", it) }
                                    waistInput.toDoubleOrNull()?.let { put("waist_circumference", it) }
                                    hipInput.toDoubleOrNull()?.let { put("hip_circumference_est", it) }
                                }
                                onSaveManualEntry(manualTitle, entries, manualNotes)
                                showManualForm = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_manual_measurements_button")
                        ) {
                            Text("Save Manual Measurement Session")
                        }
                    }
                }
            }
        }

        item {
            ScientificDisclaimerBanner(
                text = "Manual tape measurements and camera estimates remain strictly labeled by source. Single front images never derive circumferences; body composition and medical conditions are never inferred."
            )
        }

        if (activeSession == null) {
            item {
                Text("Select or capture a session to inspect measurement provenance.")
            }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(activeSession.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "Calibration: ${activeSession.calibration.source.displayLabel} · Scale Verified: ${activeSession.calibration.isScaleVerified}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        activeSession.calibration.warningMessage?.let { warn ->
                            Text(warn, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            items(activeSession.measurements, key = { it.id }) { record ->
                MeasurementProvenanceCard(record = record, unit = lengthUnit)
            }
        }
    }
}

@Composable
private fun NumericField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

@Composable
fun MeasurementProvenanceCard(
    record: BodyMeasurementRecord,
    unit: LengthUnit
) {
    val tone = when (record.qualityStatus) {
        MeasurementQualityStatus.CALIBRATED_VERIFIED -> BadgeTone.TEAL
        MeasurementQualityStatus.MANUAL_ENTRY -> BadgeTone.MIDNIGHT
        MeasurementQualityStatus.ESTIMATED_ELEVATED_UNCERTAINTY -> BadgeTone.VIOLET
        MeasurementQualityStatus.UNQUANTIFIED_UNCERTAINTY -> BadgeTone.WARNING
        MeasurementQualityStatus.BLOCKED_UNCALIBRATED,
        MeasurementQualityStatus.INSUFFICIENT_INPUT -> BadgeTone.ERROR
    }
    val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(record.captureTimestampMs))

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("metric_card_${record.metricKey}")
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = record.label,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                ProvenanceBadge(record.qualityStatus.displayLabel, tone)
            }

            Text(
                text = UnitConverter.formatLengthWithUncertainty(record.valueMm, record.uncertaintyMm, unit),
                style = MetricReadoutStyle,
                color = if (record.valueMm != null) TealMeasurement else MaterialTheme.colorScheme.error
            )

            Text(
                text = record.definition,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            Text(
                text = "Method: ${record.sourceMethod.displayLabel} · Calibration: ${record.calibrationSource.displayLabel}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "Captured: $dateStr · Origin: ${record.coordinateOrigin.name}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (record.notes.isNotBlank()) {
                Text(
                    text = record.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
            }
        }
    }
}
