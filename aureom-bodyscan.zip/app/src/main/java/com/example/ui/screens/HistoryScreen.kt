package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.math.SessionComparisonResult
import com.example.domain.math.UnitConverter
import com.example.domain.model.LengthUnit
import com.example.domain.model.ScanSession
import com.example.ui.components.BadgeTone
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.components.SectionHeader
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TealMeasurement
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    sessions: List<ScanSession>,
    comparisonResult: SessionComparisonResult?,
    lengthUnit: LengthUnit,
    onSelectComparison: (String, String) -> Unit,
    onUpdateNotes: (String, String) -> Unit,
    onExportSessionUri: (ScanSession) -> android.net.Uri?,
    onDeleteSession: (String) -> Unit,
    onRestoreDemos: () -> Unit,
    onInspectSession: (String) -> Unit
) {
    val context = LocalContext.current
    var pendingDeleteId by remember { mutableStateOf<String?>(null) }
    var editingNotesSession by remember { mutableStateOf<ScanSession?>(null) }
    var notesDraft by remember { mutableStateOf("") }

    var selectedBaseId by remember(sessions) { mutableStateOf(sessions.getOrNull(1)?.id ?: "") }
    var selectedTargetId by remember(sessions) { mutableStateOf(sessions.firstOrNull()?.id ?: "") }

    if (pendingDeleteId != null) {
        val target = sessions.firstOrNull { it.id == pendingDeleteId }
        AlertDialog(
            onDismissRequest = { pendingDeleteId = null },
            title = { Text("Delete Session & Derived Files?") },
            text = {
                Text("This permanently deletes '${target?.title ?: pendingDeleteId}', its captured frames, 3D model metadata, and derived measurements from local storage.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingDeleteId?.let(onDeleteSession)
                        pendingDeleteId = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                    modifier = Modifier.testTag("confirm_delete_session_button")
                ) {
                    Text("Delete Permanently")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDeleteId = null }) { Text("Cancel") }
            }
        )
    }

    if (editingNotesSession != null) {
        AlertDialog(
            onDismissRequest = { editingNotesSession = null },
            title = { Text("Personal Notes") },
            text = {
                OutlinedTextField(
                    value = notesDraft,
                    onValueChange = { notesDraft = it },
                    label = { Text("Session observations & conditions") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    editingNotesSession?.let { onUpdateNotes(it.id, notesDraft) }
                    editingNotesSession = null
                }) { Text("Save Notes") }
            },
            dismissButton = {
                TextButton(onClick = { editingNotesSession = null }) { Text("Cancel") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader("Session Comparison", "Checks capture method, calibration, and uncertainty")
                OutlinedButton(
                    onClick = onRestoreDemos,
                    modifier = Modifier.testTag("restore_demos_button")
                ) {
                    Text("Restore Demos")
                }
            }
        }

        if (sessions.size >= 2) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Baseline Session (A)", style = MaterialTheme.typography.labelLarge)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            sessions.forEach { s ->
                                FilterChip(
                                    selected = selectedBaseId == s.id,
                                    onClick = {
                                        selectedBaseId = s.id
                                        onSelectComparison(s.id, selectedTargetId)
                                    },
                                    modifier = Modifier.testTag("cmp_base_${s.id}"),
                                    label = { Text(s.title) }
                                )
                            }
                        }

                        Text("Target Session (B)", style = MaterialTheme.typography.labelLarge)
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            sessions.forEach { s ->
                                FilterChip(
                                    selected = selectedTargetId == s.id,
                                    onClick = {
                                        selectedTargetId = s.id
                                        onSelectComparison(selectedBaseId, s.id)
                                    },
                                    modifier = Modifier.testTag("cmp_target_${s.id}"),
                                    label = { Text(s.title) }
                                )
                            }
                        }

                        comparisonResult?.let { cmp ->
                            if (cmp.incompatibilityWarnings.isNotEmpty()) {
                                ScientificDisclaimerBanner(
                                    text = cmp.incompatibilityWarnings.joinToString("\n• ", prefix = "• "),
                                    isWarning = true
                                )
                            }
                            cmp.rows.take(6).forEach { row ->
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(row.label, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                                        ProvenanceBadge(
                                            text = if (row.isInconclusiveWithinUncertainty) "INCONCLUSIVE" else "DELTA",
                                            tone = if (row.isInconclusiveWithinUncertainty) BadgeTone.WARNING else BadgeTone.TEAL
                                        )
                                    }
                                    val deltaTxt = row.deltaMm?.let { UnitConverter.formatDelta(it, lengthUnit) } ?: "N/A"
                                    Text(
                                        text = "A: ${UnitConverter.formatLength(row.baselineValueMm, lengthUnit)} → B: ${UnitConverter.formatLength(row.targetValueMm, lengthUnit)} (Δ $deltaTxt)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TealMeasurement
                                    )
                                    Text(
                                        text = row.interpretationNote,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (row.isInconclusiveWithinUncertainty) StatusWarning else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "Stored Sessions (${sessions.size})",
                subtitle = "Export full provenance JSON or permanently erase individual sessions"
            )
        }

        items(sessions, key = { it.id }) { session ->
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(session.createdAtMs))
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().testTag("history_card_${session.id}")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(session.title, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "$dateStr · ${session.captureMode.title}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        ProvenanceBadge(
                            text = session.processingState.name.replace("_", " "),
                            tone = if (session.processingState.name.contains("FAILED") || session.processingState.name.contains("PARTIAL")) BadgeTone.WARNING else BadgeTone.TEAL
                        )
                    }

                    Text(
                        text = "Equipment: ${session.equipmentDescription} · Calibration: ${session.calibration.source.displayLabel}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (session.personalNotes.isNotBlank()) {
                        Text(
                            text = "Note: ${session.personalNotes}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(onClick = { onInspectSession(session.id) }) {
                            Text("Open")
                        }
                        OutlinedButton(onClick = {
                            editingNotesSession = session
                            notesDraft = session.personalNotes
                        }) {
                            Text("Notes")
                        }
                        OutlinedButton(
                            onClick = {
                                val uri = onExportSessionUri(session)
                                if (uri != null) {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/json"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        putExtra(Intent.EXTRA_SUBJECT, "Aureom Provenance Export: ${session.title}")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Share Provenance JSON"))
                                }
                            },
                            modifier = Modifier.testTag("export_session_${session.id}")
                        ) {
                            Icon(Icons.Outlined.Share, contentDescription = "Share provenance export", modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Export")
                        }
                        Spacer(Modifier.weight(1f))
                        IconButton(
                            onClick = { pendingDeleteId = session.id },
                            modifier = Modifier.testTag("delete_session_${session.id}")
                        ) {
                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete session ${session.title}", tint = StatusError)
                        }
                    }
                }
            }
        }
    }
}
