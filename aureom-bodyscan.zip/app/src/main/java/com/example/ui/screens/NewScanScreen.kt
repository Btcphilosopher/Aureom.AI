package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import com.google.mlkit.vision.common.InputImage
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.adapters.MlKitPoseEstimatorAdapter
import com.example.domain.math.UnitConverter
import com.example.domain.model.CalibrationSource
import com.example.domain.model.CaptureAngle
import com.example.domain.model.CaptureMode
import com.example.domain.model.DeviceCapabilityReport
import com.example.domain.model.GuidedWorkflowStage
import com.example.domain.model.LengthUnit
import com.example.domain.model.QualityIssueType
import com.example.domain.model.RelativePosePoint
import com.example.domain.model.ScanSession
import com.example.ui.components.AnatomicalGuideSilhouette
import com.example.ui.components.BadgeTone
import com.example.ui.components.PoseOverlayCanvas
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.components.SectionHeader
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.PearlOutline
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TealMeasurement
import com.example.ui.viewmodel.GuidedScanDraft
import java.io.File
import kotlin.math.abs
import kotlin.math.sqrt

@Composable
fun NewScanScreen(
    draft: GuidedScanDraft,
    capabilities: DeviceCapabilityReport,
    lengthUnit: LengthUnit,
    liveStreamPoseAdapter: MlKitPoseEstimatorAdapter,
    completedSession: ScanSession?,
    onSelectMode: (CaptureMode) -> Unit,
    onSetStage: (GuidedWorkflowStage) -> Unit,
    onUpdateConsent: (Boolean, Boolean) -> Unit,
    onUpdateCalibration: (CalibrationSource, String?) -> Unit,
    onSelectAngle: (CaptureAngle) -> Unit,
    onCreateCaptureFile: (CaptureAngle) -> File,
    onImageCaptured: (CaptureAngle, File, Float) -> Unit,
    onImportPhotoUri: (CaptureAngle, Uri) -> Unit,
    onAddSyntheticFrame: (CaptureAngle) -> Unit,
    onDeleteFrame: (String) -> Unit,
    onStartProcessing: () -> Unit,
    onCancelProcessing: () -> Unit,
    onResetDraft: () -> Unit,
    onSaveManualSession: (String, Map<String, Double>, String) -> Unit,
    onOpenBodyModel: (String) -> Unit,
    onOpenMeasurements: (String) -> Unit
) {
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { onImportPhotoUri(draft.activeAngle, it) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Mode Selection Strip
        SectionHeader(
            title = "Capture Mode",
            subtitle = "Capabilities gated by verified hardware and backend state"
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                CaptureMode.GUIDED_PHOTOGRAPHS,
                CaptureMode.POSE_TRACKING,
                CaptureMode.DEPTH_CAPTURE,
                CaptureMode.RECONSTRUCTION_3D,
                CaptureMode.MANUAL_MEASUREMENTS
            ).forEach { mode ->
                FilterChip(
                    selected = draft.selectedMode == mode,
                    onClick = { onSelectMode(mode) },
                    modifier = Modifier.testTag("mode_chip_${mode.name}"),
                    label = { Text(mode.title) }
                )
            }
        }

        ScientificDisclaimerBanner(text = draft.selectedMode.disclaimer)

        // Mode-specific capability gating for Depth Capture and Manual Entry
        if (draft.selectedMode == CaptureMode.DEPTH_CAPTURE && !capabilities.hasHardwareDepthOutput) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProvenanceBadge("UNSUPPORTED ON THIS DEVICE", BadgeTone.ERROR)
                    Text(
                        text = "Hardware Depth / ToF Capture is unavailable on ${capabilities.deviceModel}. No Camera2 DEPTH_OUTPUT sensor was reported.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedButton(onClick = { onSelectMode(CaptureMode.GUIDED_PHOTOGRAPHS) }) {
                        Text("Switch to Guided RGB Photographs")
                    }
                }
            }
            return@Column
        }

        if (draft.selectedMode == CaptureMode.MANUAL_MEASUREMENTS) {
            ManualEntryWorkflowCard(
                lengthUnit = lengthUnit,
                onSaveManual = onSaveManualSession
            )
            return@Column
        }

        if (draft.selectedMode == CaptureMode.POSE_TRACKING) {
            LivePoseTrackingPane(
                hasCameraPermission = hasCameraPermission,
                onRequestCameraPermission = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                poseAdapter = liveStreamPoseAdapter
            )
            return@Column
        }

        if (draft.selectedMode == CaptureMode.RECONSTRUCTION_3D && (!capabilities.isBackendConfigured || !capabilities.isCloudOptInEnabled)) {
            ScientificDisclaimerBanner(
                text = "3D Reconstruction Backend is not opted-in or configured. You may still run Guided Capture below — reconstruction will explicitly report unavailability and preserve partial gaps rather than substituting a fake mesh.",
                isWarning = true
            )
        }

        // 8-Stage Guided Workflow Stepper
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            GuidedWorkflowStage.entries.forEach { st ->
                val isCurrent = draft.stage == st
                FilterChip(
                    selected = isCurrent,
                    onClick = { if (!draft.isProcessing) onSetStage(st) },
                    modifier = Modifier.testTag("stage_${st.name}"),
                    label = { Text("${st.stepIndex + 1}. ${st.title}") }
                )
            }
        }

        // Stage Content
        when (draft.stage) {
            GuidedWorkflowStage.CONSENT -> {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionHeader(
                            title = "1. Explicit Capture & Processing Consent",
                            subtitle = "Body imagery and measurements are stored in app-private files only."
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = draft.localConsentChecked,
                                onCheckedChange = { onUpdateConsent(it, draft.cloudOptInChecked) },
                                modifier = Modifier.testTag("consent_local_checkbox")
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "I consent to local body capture, pose landmark processing, and local Room storage on this device.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = draft.cloudOptInChecked,
                                onCheckedChange = { onUpdateConsent(draft.localConsentChecked, it) },
                                modifier = Modifier.testTag("consent_cloud_checkbox")
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Optional: Allow explicit upload to my configured Python/FastAPI reconstruction server (default OFF).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = { onSetStage(GuidedWorkflowStage.INSTRUCTIONS) },
                            enabled = draft.localConsentChecked,
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                            modifier = Modifier.fillMaxWidth().testTag("stage1_next_button")
                        ) {
                            Text("Continue to Capture Instructions")
                        }
                    }
                }
            }

            GuidedWorkflowStage.INSTRUCTIONS -> {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeader("2. Capture Environment & Subject Guidance")
                        GuidanceBullet("Lighting", "Even front-lit room (~300+ lux). Avoid strong backlighting or harsh shadows.")
                        GuidanceBullet("Distance", "Place camera 2.0–2.5 m away at mid-torso height so head to heels fit inside frame.")
                        GuidanceBullet("Visibility", "Keep wrists, shoulders, hips, knees, and ankles unobstructed.")
                        GuidanceBullet("Background", "Stand against a plain, high-contrast wall free of clutter.")
                        GuidanceBullet("Clothing", "Wear fitted athletic attire; loose outerwear inflates width uncertainty.")
                        Spacer(Modifier.height(4.dp))
                        Button(
                            onClick = { onSetStage(GuidedWorkflowStage.DEVICE_CHECKS) },
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                            modifier = Modifier.fillMaxWidth().testTag("stage2_next_button")
                        ) {
                            Text("Run Device Checks")
                        }
                    }
                }
            }

            GuidedWorkflowStage.DEVICE_CHECKS -> {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeader("3. Device Capability & Sensor Checks")
                        DeviceCheckRow("RGB Camera Hardware", capabilities.hasRgbCamera, "Required for live capture")
                        DeviceCheckRow("Camera Runtime Permission", hasCameraPermission, "Needed for CameraX viewfinder")
                        DeviceCheckRow("Accelerometer Stability", capabilities.hasAccelerometer, "Detects handheld motion blur")
                        DeviceCheckRow("Hardware Depth (ToF)", capabilities.hasHardwareDepthOutput, "Optional; unsupported on RGB-only devices")
                        DeviceCheckRow("Consented Reconstruction Server", capabilities.isBackendConfigured && capabilities.isCloudOptInEnabled, "Optional FastAPI mesh backend")

                        if (!hasCameraPermission && capabilities.hasRgbCamera) {
                            OutlinedButton(
                                onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                                modifier = Modifier.fillMaxWidth().testTag("grant_camera_permission_button")
                            ) {
                                Text("Grant Camera Permission")
                            }
                        }
                        Button(
                            onClick = { onSetStage(GuidedWorkflowStage.CALIBRATION) },
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                            modifier = Modifier.fillMaxWidth().testTag("stage3_next_button")
                        ) {
                            Text("Proceed to Scale Calibration")
                        }
                    }
                }
            }

            GuidedWorkflowStage.CALIBRATION -> {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionHeader(
                            title = "4. Scale Calibration Source",
                            subtitle = "Physical metric dimensions require a verified reference scale."
                        )
                        listOf(
                            CalibrationSource.A4_REFERENCE_CARD,
                            CalibrationSource.ARUCO_MARKER,
                            CalibrationSource.USER_HEIGHT_REFERENCE,
                            CalibrationSource.NONE
                        ).forEach { src ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = draft.calibrationChoice == src,
                                    onClick = { onUpdateCalibration(src, null) },
                                    modifier = Modifier.testTag("cal_radio_${src.name}")
                                )
                                Column {
                                    Text(src.displayLabel, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = if (src.isAbsoluteScaleSupported) "Enables calibrated metric dimensions with uncertainty." else "Blocks metric output; records pixel & relative pose only.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        if (draft.calibrationChoice == CalibrationSource.USER_HEIGHT_REFERENCE) {
                            OutlinedTextField(
                                value = draft.userHeightInput,
                                onValueChange = { onUpdateCalibration(CalibrationSource.USER_HEIGHT_REFERENCE, it) },
                                label = { Text("Reference Standing Height (${lengthUnit.symbol})") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("user_height_cal_input")
                            )
                        }

                        Button(
                            onClick = { onSetStage(GuidedWorkflowStage.CAPTURE) },
                            colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                            modifier = Modifier.fillMaxWidth().testTag("stage4_next_button")
                        ) {
                            Text("Open Guided Capture")
                        }
                    }
                }
            }

            GuidedWorkflowStage.CAPTURE -> {
                GuidedCaptureStageCard(
                    draft = draft,
                    hasCameraPermission = hasCameraPermission,
                    hasRgbCamera = capabilities.hasRgbCamera,
                    onRequestPermission = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                    onSelectAngle = onSelectAngle,
                    onCreateCaptureFile = onCreateCaptureFile,
                    onImageCaptured = onImageCaptured,
                    onPickPhoto = {
                        photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    onAddSyntheticFrame = onAddSyntheticFrame,
                    onProceedToReview = { onSetStage(GuidedWorkflowStage.QUALITY_REVIEW) }
                )
            }

            GuidedWorkflowStage.QUALITY_REVIEW -> {
                QualityReviewStageCard(
                    draft = draft,
                    onDeleteFrame = onDeleteFrame,
                    onRecaptureAngle = { angle ->
                        onSelectAngle(angle)
                        onSetStage(GuidedWorkflowStage.CAPTURE)
                    },
                    onProcess = onStartProcessing
                )
            }

            GuidedWorkflowStage.PROCESSING -> {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionHeader("7. Processing Capture")
                        LinearProgressIndicator(
                            progress = { draft.processingProgress },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(draft.processingStatusMessage, style = MaterialTheme.typography.bodyMedium)
                        OutlinedButton(
                            onClick = onCancelProcessing,
                            modifier = Modifier.fillMaxWidth().testTag("cancel_processing_button")
                        ) {
                            Text("Interrupt & Discard Processing")
                        }
                    }
                }
            }

            GuidedWorkflowStage.RESULTS -> {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionHeader(
                            title = "8. Capture & Calibration Results",
                            subtitle = completedSession?.title ?: "Session saved"
                        )
                        draft.reconstructionFeedback?.let { msg ->
                            ScientificDisclaimerBanner(text = msg, isWarning = true)
                        }
                        if (completedSession != null) {
                            completedSession.measurements.take(5).forEach { m ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(m.label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                    Text(
                                        text = UnitConverter.formatLengthWithUncertainty(m.valueMm, m.uncertaintyMm, lengthUnit),
                                        style = MaterialTheme.typography.labelMedium,
                                        color = TealMeasurement
                                    )
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onOpenBodyModel(completedSession.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                                    modifier = Modifier.weight(1f).testTag("results_open_3d_button")
                                ) {
                                    Text("Inspect 3D Model")
                                }
                                OutlinedButton(
                                    onClick = { onOpenMeasurements(completedSession.id) },
                                    modifier = Modifier.weight(1f).testTag("results_open_metrics_button")
                                ) {
                                    Text("All Metrics")
                                }
                            }
                        }
                        OutlinedButton(onClick = onResetDraft, modifier = Modifier.fillMaxWidth()) {
                            Text("Start Another Capture")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuidanceBullet(title: String, detail: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ProvenanceBadge(title, BadgeTone.TEAL)
        Text(detail, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun DeviceCheckRow(label: String, passed: Boolean, note: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Text(note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        ProvenanceBadge(
            text = if (passed) "READY" else "UNAVAILABLE",
            tone = if (passed) BadgeTone.TEAL else BadgeTone.WARNING
        )
    }
}

@Composable
private fun GuidedCaptureStageCard(
    draft: GuidedScanDraft,
    hasCameraPermission: Boolean,
    hasRgbCamera: Boolean,
    onRequestPermission: () -> Unit,
    onSelectAngle: (CaptureAngle) -> Unit,
    onCreateCaptureFile: (CaptureAngle) -> File,
    onImageCaptured: (CaptureAngle, File, Float) -> Unit,
    onPickPhoto: () -> Unit,
    onAddSyntheticFrame: (CaptureAngle) -> Unit,
    onProceedToReview: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Accelerometer stability monitor
    var stabilityScore by remember { mutableFloatStateOf(0.95f) }
    DisposableEffect(context) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accel = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val mag = sqrt(event.values[0] * event.values[0] + event.values[1] * event.values[1] + event.values[2] * event.values[2])
                val dev = abs(mag - SensorManager.GRAVITY_EARTH)
                stabilityScore = (1f - (dev / 4f)).coerceIn(0.2f, 1.0f)
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (accel != null) {
            sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose {
            sm?.unregisterListener(listener)
        }
    }

    val cameraController = remember {
        runCatching {
            LifecycleCameraController(context).apply {
                setEnabledUseCases(CameraController.IMAGE_CAPTURE)
                cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            }
        }.getOrNull()
    }

    DisposableEffect(lifecycleOwner, hasCameraPermission) {
        if (hasCameraPermission && cameraController != null) {
            runCatching { cameraController.bindToLifecycle(lifecycleOwner) }
        }
        onDispose {
            runCatching { cameraController?.unbind() }
        }
    }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionHeader(
                title = "5. Guided Capture (${draft.capturedFrames.size}/3 angles)",
                subtitle = draft.activeAngle.instruction
            )

            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CaptureAngle.entries.forEach { angle ->
                    val captured = draft.capturedFrames.any { it.angle == angle }
                    FilterChip(
                        selected = draft.activeAngle == angle,
                        onClick = { onSelectAngle(angle) },
                        modifier = Modifier.testTag("angle_chip_${angle.name}"),
                        leadingIcon = if (captured) {
                            { Icon(Icons.Outlined.CheckCircle, contentDescription = "Captured", modifier = Modifier.size(16.dp)) }
                        } else null,
                        label = { Text(angle.label) }
                    )
                }
            }

            // CameraX Preview + Anatomical Silhouette Overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(270.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightBlue)
            ) {
                if (hasCameraPermission && hasRgbCamera && cameraController != null) {
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).apply {
                                scaleType = PreviewView.ScaleType.FILL_CENTER
                                controller = cameraController
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        modifier = Modifier.align(Alignment.Center).padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (!hasRgbCamera) "No RGB camera detected." else "Camera permission needed for live CameraX viewfinder.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                        if (hasRgbCamera && !hasCameraPermission) {
                            Button(onClick = onRequestPermission) {
                                Text("Enable CameraX")
                            }
                        }
                    }
                }

                AnatomicalGuideSilhouette(
                    angle = draft.activeAngle,
                    modifier = Modifier.fillMaxSize()
                )

                Text(
                    text = "Stability: ${(stabilityScore * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                        .background(MidnightBlue.copy(alpha = 0.75f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val file = onCreateCaptureFile(draft.activeAngle)
                        val ctrl = cameraController
                        if (hasCameraPermission && ctrl != null) {
                            val opts = ImageCapture.OutputFileOptions.Builder(file).build()
                            ctrl.takePicture(
                                opts,
                                ContextCompat.getMainExecutor(context),
                                object : ImageCapture.OnImageSavedCallback {
                                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                        onImageCaptured(draft.activeAngle, file, stabilityScore)
                                    }
                                    override fun onError(exception: ImageCaptureException) {
                                        // Surface error cleanly via empty/insufficient frame
                                    }
                                }
                            )
                        }
                    },
                    enabled = hasCameraPermission && hasRgbCamera,
                    colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                    modifier = Modifier.weight(1f).testTag("capture_shutter_button")
                ) {
                    Icon(Icons.Outlined.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Capture ${draft.activeAngle.label}")
                }

                OutlinedButton(
                    onClick = onPickPhoto,
                    modifier = Modifier.testTag("pick_photo_button")
                ) {
                    Icon(Icons.Outlined.PhotoLibrary, contentDescription = "Pick photo from Photo Picker", modifier = Modifier.size(18.dp))
                }
            }

            OutlinedButton(
                onClick = { onAddSyntheticFrame(draft.activeAngle) },
                modifier = Modifier.fillMaxWidth().testTag("add_synthetic_frame_button")
            ) {
                Icon(Icons.Outlined.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Insert Synthetic Test Frame (${draft.activeAngle.label}) [SIMULATED]")
            }

            Button(
                onClick = onProceedToReview,
                enabled = draft.capturedFrames.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = TealMeasurement),
                modifier = Modifier.fillMaxWidth().testTag("proceed_quality_review_button")
            ) {
                Text("Review Captures (${draft.capturedFrames.size}/3)")
            }
        }
    }
}

@Composable
private fun QualityReviewStageCard(
    draft: GuidedScanDraft,
    onDeleteFrame: (String) -> Unit,
    onRecaptureAngle: (CaptureAngle) -> Unit,
    onProcess: () -> Unit
) {
    val missingAngles = CaptureAngle.entries.filter { angle -> draft.capturedFrames.none { it.angle == angle } }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionHeader(
                title = "6. Quality Review & Pre-Processing Inspection",
                subtitle = "Review or delete captures before metric derivation."
            )

            if (missingAngles.isNotEmpty()) {
                ScientificDisclaimerBanner(
                    text = "Incomplete coverage: missing ${missingAngles.joinToString { it.label }}. ${QualityIssueType.INCOMPLETE_COVERAGE.recaptureInstruction}",
                    isWarning = true
                )
            }
            if (draft.calibrationChoice == CalibrationSource.NONE) {
                ScientificDisclaimerBanner(
                    text = QualityIssueType.MISSING_CALIBRATION.recaptureInstruction,
                    isWarning = true
                )
            }

            draft.capturedFrames.forEach { frame ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth().testTag("review_frame_${frame.angle.name}")
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(frame.angle.label, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = "${frame.imageWidthPx}×${frame.imageHeightPx} · Luma ${frame.meanLuma.toInt()} · Stability ${(frame.motionStabilityScore * 100).toInt()}% · Landmarks ${frame.landmarks.size}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (frame.isSynthetic) {
                                ProvenanceBadge("SIMULATED FRAME", BadgeTone.WARNING)
                            }
                            IconButton(
                                onClick = { onDeleteFrame(frame.id) },
                                modifier = Modifier.testTag("delete_draft_frame_${frame.angle.name}")
                            ) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete ${frame.angle.label} capture", tint = StatusError)
                            }
                        }

                        if (frame.qualityIssues.isNotEmpty()) {
                            frame.qualityIssues.forEach { issue ->
                                Text(
                                    text = "• ${issue.label}: ${issue.recaptureInstruction}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusWarning
                                )
                            }
                            OutlinedButton(onClick = { onRecaptureAngle(frame.angle) }) {
                                Text("Recapture ${frame.angle.label}")
                            }
                        }
                    }
                }
            }

            Button(
                onClick = onProcess,
                enabled = draft.capturedFrames.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                modifier = Modifier.fillMaxWidth().testTag("process_capture_button")
            ) {
                Text("Process Calibrated Measurements")
            }
        }
    }
}

@OptIn(ExperimentalGetImage::class)
@Composable
private fun LivePoseTrackingPane(
    hasCameraPermission: Boolean,
    onRequestCameraPermission: () -> Unit,
    poseAdapter: MlKitPoseEstimatorAdapter
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var liveLandmarks by remember { mutableStateOf<List<RelativePosePoint>>(emptyList()) }
    var useFrontCamera by remember { mutableStateOf(false) }

    val cameraController = remember {
        runCatching {
            LifecycleCameraController(context).apply {
                setEnabledUseCases(CameraController.IMAGE_ANALYSIS)
                imageAnalysisBackpressureStrategy = ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
                cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            }
        }.getOrNull()
    }

    DisposableEffect(lifecycleOwner, hasCameraPermission, useFrontCamera) {
        if (hasCameraPermission && cameraController != null) {
            cameraController.cameraSelector = if (useFrontCamera) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }
            val detector = poseAdapter.getRawDetector()
            if (detector != null) {
                val mainExecutor = ContextCompat.getMainExecutor(context)
                cameraController.setImageAnalysisAnalyzer(mainExecutor) { imageProxy ->
                    val mediaImage = imageProxy.image
                    if (mediaImage != null) {
                        val rotation = imageProxy.imageInfo.rotationDegrees
                        val rotatedW = if (rotation == 90 || rotation == 270) imageProxy.height else imageProxy.width
                        val rotatedH = if (rotation == 90 || rotation == 270) imageProxy.width else imageProxy.height
                        val input = InputImage.fromMediaImage(mediaImage, rotation)
                        detector.process(input)
                            .addOnSuccessListener { pose ->
                                val mapped = poseAdapter.mapMlKitPose(pose, rotatedW, rotatedH, 0L)
                                liveLandmarks = mapped.landmarks
                            }
                            .addOnCompleteListener {
                                imageProxy.close()
                            }
                    } else {
                        imageProxy.close()
                    }
                }
            }
            runCatching { cameraController.bindToLifecycle(lifecycleOwner) }
        }
        onDispose {
            runCatching {
                cameraController?.clearImageAnalysisAnalyzer()
                cameraController?.unbind()
            }
        }
    }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader("Live On-Device Pose Tracking")
                ProvenanceBadge("NOT A SURFACE SCAN", BadgeTone.VIOLET)
            }
            Text(
                text = stringResource(R.string.pose_not_surface_disclaimer),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightBlue)
                    .border(1.dp, PearlOutline, RoundedCornerShape(14.dp))
            ) {
                if (hasCameraPermission && cameraController != null) {
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).apply {
                                scaleType = PreviewView.ScaleType.FILL_CENTER
                                controller = cameraController
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    PoseOverlayCanvas(
                        landmarks = liveLandmarks,
                        mirrorHorizontal = useFrontCamera,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        modifier = Modifier.align(Alignment.Center).padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Camera permission required for live pose skeleton tracking.", color = Color.White)
                        Button(onClick = onRequestCameraPermission) { Text("Grant Camera Permission") }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Front Camera Mirroring", style = MaterialTheme.typography.bodyMedium)
                Switch(checked = useFrontCamera, onCheckedChange = { useFrontCamera = it })
            }
            Text(
                text = "Adapter: ${poseAdapter.adapterName} (${poseAdapter.modelLicense}) · Detected landmarks: ${liveLandmarks.size}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ManualEntryWorkflowCard(
    lengthUnit: LengthUnit,
    onSaveManual: (String, Map<String, Double>, String) -> Unit
) {
    var title by remember { mutableStateOf("Manual Tape Session") }
    var height by remember { mutableStateOf("") }
    var shoulder by remember { mutableStateOf("") }
    var chest by remember { mutableStateOf("") }
    var waist by remember { mutableStateOf("") }
    var hip by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionHeader(
                title = "Manual Tape Entry (${lengthUnit.label})",
                subtitle = "Distinct from camera estimates; stored internally in mm."
            )
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Session Title") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = height, onValueChange = { height = it }, label = { Text("Height (${lengthUnit.symbol})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = shoulder, onValueChange = { shoulder = it }, label = { Text("Shoulders (${lengthUnit.symbol})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = chest, onValueChange = { chest = it }, label = { Text("Chest (${lengthUnit.symbol})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = waist, onValueChange = { waist = it }, label = { Text("Waist (${lengthUnit.symbol})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)
                )
            }
            OutlinedTextField(
                value = hip, onValueChange = { hip = it }, label = { Text("Hip (${lengthUnit.symbol})") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Conditions / Notes") }, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = {
                    val entries = buildMap {
                        height.toDoubleOrNull()?.let { put("stature", it) }
                        shoulder.toDoubleOrNull()?.let { put("shoulder_width", it) }
                        chest.toDoubleOrNull()?.let { put("chest_circumference", it) }
                        waist.toDoubleOrNull()?.let { put("waist_circumference", it) }
                        hip.toDoubleOrNull()?.let { put("hip_circumference_est", it) }
                    }
                    onSaveManual(title, entries, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MidnightBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save Manual Tape Session")
            }
        }
    }
}
