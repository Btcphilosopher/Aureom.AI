package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val AureomLightColorScheme = lightColorScheme(
    primary = MidnightBlue,
    onPrimary = Color.White,
    primaryContainer = TealContainer,
    onPrimaryContainer = TealOnContainer,
    secondary = TealMeasurement,
    onSecondary = Color.White,
    secondaryContainer = TealContainer,
    onSecondaryContainer = TealOnContainer,
    tertiary = VioletHighlight,
    onTertiary = Color.White,
    tertiaryContainer = VioletContainer,
    onTertiaryContainer = VioletOnContainer,
    background = PearlBackground,
    onBackground = MidnightBlue,
    surface = PearlSurface,
    onSurface = MidnightBlue,
    surfaceVariant = PearlSurfaceVariant,
    onSurfaceVariant = SlateInk,
    surfaceContainerLowest = PearlSurface,
    surfaceContainerLow = PearlBackground,
    surfaceContainer = PearlSurfaceContainer,
    surfaceContainerHigh = PearlSurfaceVariant,
    outline = PearlOutline,
    outlineVariant = PearlOutlineSubtle,
    error = StatusError,
    onError = Color.White,
    errorContainer = StatusErrorContainer,
    onErrorContainer = StatusErrorOnContainer
)

private val AureomDarkColorScheme = darkColorScheme(
    primary = TealBright,
    onPrimary = MidnightBlue,
    primaryContainer = MidnightBlueContainer,
    onPrimaryContainer = TealContainer,
    secondary = TealMeasurement,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF0E3A38),
    onSecondaryContainer = TealContainer,
    tertiary = VioletBright,
    onTertiary = MidnightBlue,
    tertiaryContainer = Color(0xFF2B235A),
    onTertiaryContainer = VioletContainer,
    background = LabDarkBackground,
    onBackground = LabDarkTextPrimary,
    surface = LabDarkSurface,
    onSurface = LabDarkTextPrimary,
    surfaceVariant = LabDarkSurfaceVariant,
    onSurfaceVariant = LabDarkTextSecondary,
    surfaceContainerLowest = LabDarkBackground,
    surfaceContainerLow = LabDarkSurface,
    surfaceContainer = LabDarkSurface,
    surfaceContainerHigh = LabDarkSurfaceVariant,
    outline = LabDarkOutline,
    outlineVariant = Color(0xFF1F3557),
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFEE2E2)
)

val AureomShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun AureomTheme(
    darkTheme: Boolean = false, // Pearl-white scientific workspace default; user/system dark optional
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AureomDarkColorScheme else AureomLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AureomTypography,
        shapes = AureomShapes,
        content = content
    )
}
