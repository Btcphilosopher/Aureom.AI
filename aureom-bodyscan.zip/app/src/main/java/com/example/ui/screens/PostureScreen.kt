package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.PostureAnalysisSnapshot
import com.example.domain.model.ScanSession
import com.example.ui.components.BadgeTone
import com.example.ui.components.PoseOverlayCanvas
import com.example.ui.components.ProvenanceBadge
import com.example.ui.components.ScientificDisclaimerBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.SessionSelectorBar
import com.example.ui.theme.PearlOutline
import com.example.ui.theme.TealMeasurement

@Composable
fun PostureScreen(
    sessions: List<ScanSession>,
    activeSession: ScanSession?,
    postureSnapshot: PostureAnalysisSnapshot?,
    isExpandedWidth: Boolean,
    onSelectSession: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SessionSelectorBar(
            sessions = sessions,
            activeSessionId = activeSession?.id,
            onSelectSession = onSelectSession
        )

        ScientificDisclaimerBanner(
            text = "Geometric landmark relationships only. Findings describe alignment in this capture without medical diagnosis, safety clearance, or exercise prescriptions."
        )

        if (postureSnapshot == null) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Text(
                    text = "This session has no camera pose landmarks (for example, a manual-tape session). Select a camera capture or demonstration session above.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(16.dp)
                )
            }
            return@Column
        }

        val canvasCard: @Composable (Modifier) -> Unit = { mod ->
            Box(
                modifier = mod
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, PearlOutline, RoundedCornerShape(16.dp))
            ) {
                PoseOverlayCanvas(
                    landmarks = postureSnapshot.landmarks,
                    showAlignmentLines = true,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                        .testTag("posture_pose_canvas")
                )
            }
        }

        val findingsList: @Composable (Modifier) -> Unit = { mod ->
            LazyColumn(
                modifier = mod,
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                ProvenanceBadge(
                                    text = "Viewpoint: ${postureSnapshot.viewpoint.label}",
                                    tone = BadgeTone.MIDNIGHT
                                )
                                ProvenanceBadge(
                                    text = if (postureSnapshot.isSyntheticDemo) "SYNTHETIC DEMO" else "POSE LANDMARKS",
                                    tone = if (postureSnapshot.isSyntheticDemo) BadgeTone.WARNING else BadgeTone.TEAL
                                )
                            }
                            Text(
                                text = "Mean Landmark Confidence: ${(postureSnapshot.meanLandmarkConfidence * 100).toInt()}% · Occluded Landmarks: ${postureSnapshot.occludedLandmarks.size}",
                                style = MaterialTheme.typography.labelMedium,
                                color = TealMeasurement
                            )
                            if (postureSnapshot.occludedLandmarks.isNotEmpty()) {
                                Text(
                                    text = "Occluded: ${postureSnapshot.occludedLandmarks.joinToString { it.displayName }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }

                item { SectionHeader("Geometric Relationships") }

                items(postureSnapshot.findings, key = { it.id }) { finding ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(finding.label, style = MaterialTheme.typography.titleSmall)
                            Text(finding.geometricStatement, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = "Estimated uncertainty: ${finding.uncertaintyLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        if (isExpandedWidth) {
            Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                canvasCard(Modifier.weight(1f).fillMaxHeight())
                findingsList(Modifier.weight(1.1f).fillMaxHeight())
            }
        } else {
            canvasCard(Modifier.fillMaxWidth().height(260.dp))
            findingsList(Modifier.fillMaxWidth().weight(1f))
        }
    }
}
