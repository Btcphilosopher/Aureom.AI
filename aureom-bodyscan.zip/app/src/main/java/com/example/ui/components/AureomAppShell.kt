package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.navigation.AureomNavDestination
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.MidnightBlueElevated
import com.example.ui.theme.TealBright
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealOnContainer
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AureomAppShell(
    currentDestination: AureomNavDestination,
    onNavigate: (AureomNavDestination) -> Unit,
    snackbarHostState: SnackbarHostState,
    content: @Composable (isExpandedWidth: Boolean) -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTabletOrLandscape = maxWidth >= 600.dp

        if (isTabletOrLandscape) {
            // Tablet / Landscape: Midnight-blue scrollable NavigationRail with all 9 destinations
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                NavigationRail(
                    containerColor = MidnightBlue,
                    contentColor = Color.White,
                    windowInsets = WindowInsets.safeDrawing,
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(96.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState())
                            .padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "AUREOM",
                            style = MaterialTheme.typography.labelSmall,
                            color = TealBright,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        AureomNavDestination.entries.forEach { dest ->
                            NavigationRailItem(
                                selected = dest == currentDestination,
                                onClick = { onNavigate(dest) },
                                modifier = Modifier.testTag(dest.testTag),
                                icon = {
                                    Icon(
                                        imageVector = dest.icon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = dest.shortLabel,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = TealOnContainer,
                                    selectedTextColor = TealBright,
                                    indicatorColor = TealContainer,
                                    unselectedIconColor = Color.White.copy(alpha = 0.78f),
                                    unselectedTextColor = Color.White.copy(alpha = 0.78f)
                                )
                            )
                        }
                    }
                }

                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Text(
                                        text = currentDestination.label,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "AUREOM BODYSCAN · Precision Anthropometry & Motion",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TealBright
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MidnightBlue,
                                titleContentColor = Color.White
                            )
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        content(true)
                    }
                }
            }
        } else {
            // Phone Portrait: Midnight-blue Drawer (all 9 items) + TopAppBar + 5-item Bottom NavigationBar
            val drawerState = rememberDrawerState(DrawerValue.Closed)
            val scope = rememberCoroutineScope()

            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = MidnightBlue,
                        drawerContentColor = Color.White,
                        modifier = Modifier.width(280.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 12.dp, vertical = 16.dp)
                        ) {
                            Text(
                                text = "AUREOM BODYSCAN",
                                style = MaterialTheme.typography.titleMedium,
                                color = TealBright,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                            Text(
                                text = "Body Measurement & Motion",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.72f),
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )
                            Spacer(Modifier.height(12.dp))
                            HorizontalDivider(color = MidnightBlueElevated)
                            Spacer(Modifier.height(8.dp))

                            AureomNavDestination.entries.forEach { dest ->
                                NavigationDrawerItem(
                                    selected = dest == currentDestination,
                                    onClick = {
                                        scope.launch { drawerState.close() }
                                        onNavigate(dest)
                                    },
                                    modifier = Modifier
                                        .padding(vertical = 2.dp)
                                        .testTag("drawer_${dest.testTag}"),
                                    icon = {
                                        Icon(dest.icon, contentDescription = dest.label)
                                    },
                                    label = { Text(dest.label) },
                                    colors = NavigationDrawerItemDefaults.colors(
                                        selectedContainerColor = TealContainer,
                                        selectedIconColor = TealOnContainer,
                                        selectedTextColor = TealOnContainer,
                                        unselectedContainerColor = Color.Transparent,
                                        unselectedIconColor = Color.White.copy(alpha = 0.85f),
                                        unselectedTextColor = Color.White.copy(alpha = 0.90f)
                                    )
                                )
                            }
                        }
                    }
                }
            ) {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        TopAppBar(
                            navigationIcon = {
                                IconButton(
                                    onClick = { scope.launch { drawerState.open() } },
                                    modifier = Modifier.testTag("open_nav_drawer")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Menu,
                                        contentDescription = "Open all 9 workspaces menu",
                                        tint = Color.White
                                    )
                                }
                            },
                            title = {
                                Column {
                                    Text(
                                        text = currentDestination.label,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "AUREOM BODYSCAN",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TealBright
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MidnightBlue,
                                titleContentColor = Color.White
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MidnightBlue,
                            contentColor = Color.White,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            AureomNavDestination.entries
                                .filter { it.primaryPhoneBar }
                                .forEach { dest ->
                                    NavigationBarItem(
                                        selected = dest == currentDestination,
                                        onClick = { onNavigate(dest) },
                                        modifier = Modifier.testTag(dest.testTag),
                                        icon = {
                                            Icon(dest.icon, contentDescription = dest.label)
                                        },
                                        label = {
                                            Text(
                                                text = dest.shortLabel,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = TealOnContainer,
                                            selectedTextColor = TealBright,
                                            indicatorColor = TealContainer,
                                            unselectedIconColor = Color.White.copy(alpha = 0.78f),
                                            unselectedTextColor = Color.White.copy(alpha = 0.78f)
                                        )
                                    )
                                }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        content(false)
                    }
                }
            }
        }
    }
}
