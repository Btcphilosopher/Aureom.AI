package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.PoseFrameSample
import com.example.domain.model.RelativePosePoint
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TealMeasurement
import com.example.ui.theme.VioletHighlight

private val SKELETON_EDGES = listOf(
    AnatomicalLandmark.LEFT_SHOULDER to AnatomicalLandmark.RIGHT_SHOULDER,
    AnatomicalLandmark.LEFT_SHOULDER to AnatomicalLandmark.LEFT_ELBOW,
    AnatomicalLandmark.LEFT_ELBOW to AnatomicalLandmark.LEFT_WRIST,
    AnatomicalLandmark.RIGHT_SHOULDER to AnatomicalLandmark.RIGHT_ELBOW,
    AnatomicalLandmark.RIGHT_ELBOW to AnatomicalLandmark.RIGHT_WRIST,
    AnatomicalLandmark.LEFT_SHOULDER to AnatomicalLandmark.LEFT_HIP,
    AnatomicalLandmark.RIGHT_SHOULDER to AnatomicalLandmark.RIGHT_HIP,
    AnatomicalLandmark.LEFT_HIP to AnatomicalLandmark.RIGHT_HIP,
    AnatomicalLandmark.LEFT_HIP to AnatomicalLandmark.LEFT_KNEE,
    AnatomicalLandmark.LEFT_KNEE to AnatomicalLandmark.LEFT_ANKLE,
    AnatomicalLandmark.LEFT_ANKLE to AnatomicalLandmark.LEFT_HEEL,
    AnatomicalLandmark.RIGHT_HIP to AnatomicalLandmark.RIGHT_KNEE,
    AnatomicalLandmark.RIGHT_KNEE to AnatomicalLandmark.RIGHT_ANKLE,
    AnatomicalLandmark.RIGHT_ANKLE to AnatomicalLandmark.RIGHT_HEEL
)

@Composable
fun PoseOverlayCanvas(
    landmarks: List<RelativePosePoint>,
    mirrorHorizontal: Boolean = false,
    showAlignmentLines: Boolean = true,
    trailFrames: List<PoseFrameSample> = emptyList(),
    ghostComparisonLandmarks: List<RelativePosePoint> = emptyList(),
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        fun toOffset(pt: RelativePosePoint): Offset {
            val nx = if (mirrorHorizontal) 1f - pt.xNorm else pt.xNorm
            return Offset(nx * size.width, pt.yNorm * size.height)
        }

        // Optional ghost comparison skeleton
        if (ghostComparisonLandmarks.isNotEmpty()) {
            val ghostMap = ghostComparisonLandmarks.associateBy { it.landmarkType }
            for ((a, b) in SKELETON_EDGES) {
                val pA = ghostMap[a]
                val pB = ghostMap[b]
                if (pA != null && pB != null) {
                    drawLine(
                        color = Color.Gray.copy(alpha = 0.45f),
                        start = toOffset(pA),
                        end = toOffset(pB),
                        strokeWidth = 3f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
                    )
                }
            }
        }

        // Optional landmark trails across movement playback frames
        if (trailFrames.size > 1) {
            val tracked = listOf(
                AnatomicalLandmark.LEFT_WRIST,
                AnatomicalLandmark.RIGHT_WRIST,
                AnatomicalLandmark.LEFT_HIP,
                AnatomicalLandmark.LEFT_KNEE
            )
            tracked.forEachIndexed { idx, lm ->
                val trailColor = if (idx % 2 == 0) TealMeasurement.copy(alpha = 0.65f) else VioletHighlight.copy(alpha = 0.65f)
                var prev: Offset? = null
                for (frame in trailFrames) {
                    val pt = frame.landmarks.firstOrNull { it.landmarkType == lm } ?: continue
                    val cur = toOffset(pt)
                    prev?.let { p ->
                        drawLine(trailColor, p, cur, strokeWidth = 3f)
                    }
                    prev = cur
                }
            }
        }

        val map = landmarks.associateBy { it.landmarkType }

        // Optional horizontal alignment reference lines across shoulders & hips
        if (showAlignmentLines) {
            val lSh = map[AnatomicalLandmark.LEFT_SHOULDER]
            val rSh = map[AnatomicalLandmark.RIGHT_SHOULDER]
            if (lSh != null && rSh != null) {
                val oL = toOffset(lSh)
                val oR = toOffset(rSh)
                drawLine(
                    color = TealMeasurement.copy(alpha = 0.45f),
                    start = Offset(0f, oL.y),
                    end = Offset(size.width, oL.y),
                    strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                )
                drawLine(TealMeasurement, oL, oR, strokeWidth = 4f)
            }
            val lHip = map[AnatomicalLandmark.LEFT_HIP]
            val rHip = map[AnatomicalLandmark.RIGHT_HIP]
            if (lHip != null && rHip != null) {
                val oL = toOffset(lHip)
                val oR = toOffset(rHip)
                drawLine(
                    color = VioletHighlight.copy(alpha = 0.45f),
                    start = Offset(0f, oL.y),
                    end = Offset(size.width, oL.y),
                    strokeWidth = 1.5f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                )
                drawLine(VioletHighlight, oL, oR, strokeWidth = 4f)
            }
        }

        // Bones
        for ((a, b) in SKELETON_EDGES) {
            val pA = map[a]
            val pB = map[b]
            if (pA != null && pB != null) {
                val lowConf = minOf(pA.visibility, pB.visibility) < 0.55f
                drawLine(
                    color = if (lowConf) StatusWarning else TealMeasurement,
                    start = toOffset(pA),
                    end = toOffset(pB),
                    strokeWidth = if (lowConf) 3f else 4.5f,
                    pathEffect = if (lowConf) PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f) else null
                )
            }
        }

        // Landmark nodes
        landmarks.forEach { pt ->
            val pos = toOffset(pt)
            val isOccluded = pt.visibility < 0.55f
            if (isOccluded) {
                drawCircle(
                    color = StatusWarning,
                    radius = 10f,
                    center = pos,
                    style = Stroke(width = 2.5f)
                )
            } else {
                drawCircle(color = Color.White, radius = 7f, center = pos)
                drawCircle(color = VioletHighlight, radius = 4.5f, center = pos)
            }
        }
    }
}
