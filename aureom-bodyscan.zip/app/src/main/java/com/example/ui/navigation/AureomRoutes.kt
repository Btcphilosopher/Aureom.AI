package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccessibilityNew
import androidx.compose.material.icons.outlined.Animation
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.Straighten
import androidx.compose.material.icons.outlined.ViewInAr
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.serialization.Serializable

@Serializable
sealed interface AureomRoute {
    @Serializable data object Home : AureomRoute
    @Serializable data object NewScan : AureomRoute
    @Serializable data object BodyModel : AureomRoute
    @Serializable data object Measurements : AureomRoute
    @Serializable data object Posture : AureomRoute
    @Serializable data object Movement : AureomRoute
    @Serializable data object History : AureomRoute
    @Serializable data object Devices : AureomRoute
    @Serializable data object Privacy : AureomRoute
}

enum class AureomNavDestination(
    val route: AureomRoute,
    val label: String,
    val shortLabel: String,
    val icon: ImageVector,
    val testTag: String,
    val primaryPhoneBar: Boolean
) {
    HOME(AureomRoute.Home, "Home", "Home", Icons.Outlined.Home, "nav_home", true),
    NEW_SCAN(AureomRoute.NewScan, "New Scan", "Scan", Icons.Outlined.CameraAlt, "nav_new_scan", true),
    BODY_MODEL(AureomRoute.BodyModel, "Body Model", "Model", Icons.Outlined.ViewInAr, "nav_body_model", true),
    MEASUREMENTS(AureomRoute.Measurements, "Measurements", "Measure", Icons.Outlined.Straighten, "nav_measurements", true),
    POSTURE(AureomRoute.Posture, "Posture", "Posture", Icons.Outlined.AccessibilityNew, "nav_posture", false),
    MOVEMENT(AureomRoute.Movement, "Movement", "Motion", Icons.Outlined.Animation, "nav_movement", false),
    HISTORY(AureomRoute.History, "History", "History", Icons.Outlined.History, "nav_history", true),
    DEVICES(AureomRoute.Devices, "Devices", "Devices", Icons.Outlined.Sensors, "nav_devices", false),
    PRIVACY(AureomRoute.Privacy, "Privacy", "Privacy", Icons.Outlined.Lock, "nav_privacy", false)
}
