package com.example.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.adapters.Body3DRendererAdapter
import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.BodyMeshModel
import com.example.domain.model.SectorCoverageStatus
import com.example.domain.model.Vec3
import com.example.domain.model.Viewport3DState
import com.example.ui.theme.MidnightBlue
import com.example.ui.theme.PearlOutline
import com.example.ui.theme.PearlSurface
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TealMeasurement
import com.example.ui.theme.VioletHighlight

@Composable
fun Body3DViewport(
    model: BodyMeshModel,
    state: Viewport3DState,
    renderer: Body3DRendererAdapter,
    onRotate: (Float, Float) -> Unit,
    onPan: (Float, Float) -> Unit,
    onZoom: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = MaterialTheme.colorScheme.surface
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val isDark = MaterialTheme.colorScheme.surface == MidnightBlue ||
        MaterialTheme.colorScheme.background.red < 0.2f

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bgColor)
            .border(1.dp, PearlOutline, RoundedCornerShape(16.dp))
            .semantics {
                contentDescription = "Interactive 3D body model viewport in ${state.projectionMode.label} projection, ${model.observedCoveragePercent}% sector coverage"
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    if (zoom != 1f) {
                        onZoom(zoom)
                    }
                    // Single/two-finger drag rotates unless zoomed significantly and shifting
                    onRotate(pan.x * 0.35f, -pan.y * 0.28f)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Precision millimeter background grid
            val step = 36f
            var x = step
            while (x < size.width) {
                drawLine(gridColor.copy(alpha = 0.45f), Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                x += step
            }
            var y = step
            while (y < size.height) {
                drawLine(gridColor.copy(alpha = 0.45f), Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
                y += step
            }

            // Reference floor circle projected under feet
            val floorPoints = (0 until 24).map { idx ->
                val theta = (idx / 24.0) * 2.0 * Math.PI
                val pt = Vec3(0.42f * kotlin.math.cos(theta).toFloat(), -0.86f * (model.heightMeters / 1.73f), 0.42f * kotlin.math.sin(theta).toFloat())
                renderer.projectPoint(pt, size.width, size.height, state)
            }
            for (i in floorPoints.indices) {
                val a = floorPoints[i]
                val b = floorPoints[(i + 1) % floorPoints.size]
                drawLine(
                    color = TealMeasurement.copy(alpha = 0.35f),
                    start = Offset(a.screenX, a.screenY),
                    end = Offset(b.screenX, b.screenY),
                    strokeWidth = 1.5f
                )
            }

            // Prepare Z-sorted triangles
            val triangles = renderer.prepareTriangles(model, size.width, size.height, state)
            for (tri in triangles) {
                val path = Path().apply {
                    moveTo(tri.p0.screenX, tri.p0.screenY)
                    lineTo(tri.p1.screenX, tri.p1.screenY)
                    lineTo(tri.p2.screenX, tri.p2.screenY)
                    close()
                }
                when (tri.coverageStatus) {
                    SectorCoverageStatus.MEASURED_CALIBRATED -> {
                        val shade = (0.35f + tri.lightIntensity * 0.65f).coerceIn(0f, 1f)
                        val fill = Color(
                            red = (0.05f + 0.14f * shade),
                            green = (0.45f + 0.32f * shade),
                            blue = (0.44f + 0.30f * shade),
                            alpha = 0.86f
                        )
                        drawPath(path, color = fill)
                        drawPath(
                            path,
                            color = Color(0xFF0F1E36).copy(alpha = 0.18f),
                            style = Stroke(width = 0.9f)
                        )
                    }
                    SectorCoverageStatus.INTERPOLATED_ESTIMATE -> {
                        val shade = (0.35f + tri.lightIntensity * 0.65f).coerceIn(0f, 1f)
                        val fill = if (state.showCoverageMap) {
                            Color(
                                red = (0.28f + 0.25f * shade),
                                green = (0.34f + 0.28f * shade),
                                blue = (0.58f + 0.24f * shade),
                                alpha = 0.62f
                            )
                        } else {
                            Color(
                                red = 0.16f * shade + 0.12f,
                                green = 0.50f * shade + 0.15f,
                                blue = 0.52f * shade + 0.15f,
                                alpha = 0.72f
                            )
                        }
                        drawPath(path, color = fill)
                        drawPath(
                            path,
                            color = VioletHighlight.copy(alpha = 0.28f),
                            style = Stroke(width = 0.8f)
                        )
                    }
                    SectorCoverageStatus.UNOBSERVED_GAP -> {
                        // Preserve gaps visibly: translucent dashed wireframe, never solid filled surface!
                        drawPath(
                            path,
                            color = StatusWarning.copy(alpha = 0.12f)
                        )
                        drawPath(
                            path,
                            color = StatusWarning.copy(alpha = 0.55f),
                            style = Stroke(
                                width = 1.1f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                            )
                        )
                    }
                }
            }

            // Optional 3D Skeleton Overlay
            if (state.showSkeleton && model.skeletonJoints.isNotEmpty()) {
                val projectedJoints = model.skeletonJoints.mapValues { (_, v) ->
                    renderer.projectPoint(v, size.width, size.height, state)
                }
                val bonePairs = listOf(
                    AnatomicalLandmark.LEFT_SHOULDER to AnatomicalLandmark.RIGHT_SHOULDER,
                    AnatomicalLandmark.LEFT_SHOULDER to AnatomicalLandmark.LEFT_ELBOW,
                    AnatomicalLandmark.LEFT_ELBOW to AnatomicalLandmark.LEFT_WRIST,
                    AnatomicalLandmark.RIGHT_SHOULDER to AnatomicalLandmark.RIGHT_ELBOW,
                    AnatomicalLandmark.RIGHT_ELBOW to AnatomicalLandmark.RIGHT_WRIST,
                    AnatomicalLandmark.LEFT_SHOULDER to AnatomicalLandmark.LEFT_HIP,
                    AnatomicalLandmark.RIGHT_SHOULDER to AnatomicalLandmark.RIGHT_HIP,
                    AnatomicalLandmark.LEFT_HIP to AnatomicalLandmark.RIGHT_HIP,
                    AnatomicalLandmark.LEFT_HIP to AnatomicalLandmark.LEFT_KNEE,
                    AnatomicalLandmark.LEFT_KNEE to AnatomicalLandmark.LEFT_ANKLE,
                    AnatomicalLandmark.RIGHT_HIP to AnatomicalLandmark.RIGHT_KNEE,
                    AnatomicalLandmark.RIGHT_KNEE to AnatomicalLandmark.RIGHT_ANKLE
                )
                for ((aKey, bKey) in bonePairs) {
                    val a = projectedJoints[aKey]
                    val b = projectedJoints[bKey]
                    if (a != null && b != null) {
                        drawLine(
                            color = VioletHighlight,
                            start = Offset(a.screenX, a.screenY),
                            end = Offset(b.screenX, b.screenY),
                            strokeWidth = 3.2f
                        )
                    }
                }
                projectedJoints.values.forEach { pt ->
                    drawCircle(color = Color.White, radius = 5.5f, center = Offset(pt.screenX, pt.screenY))
                    drawCircle(color = VioletHighlight, radius = 3.8f, center = Offset(pt.screenX, pt.screenY))
                }
            }

            // Optional Measurement Overlays
            if (state.showMeasurements && model.measurementOverlays.isNotEmpty()) {
                val textPaint = Paint().apply {
                    color = if (isDark) android.graphics.Color.WHITE else android.graphics.Color.rgb(15, 30, 54)
                    textSize = 26f
                    typeface = Typeface.MONOSPACE
                    isAntiAlias = true
                }
                val bgPaint = Paint().apply {
                    color = if (isDark) android.graphics.Color.argb(210, 15, 30, 54) else android.graphics.Color.argb(225, 255, 255, 255)
                    isAntiAlias = true
                }
                for (ov in model.measurementOverlays) {
                    val pA = renderer.projectPoint(ov.start, size.width, size.height, state)
                    val pB = renderer.projectPoint(ov.end, size.width, size.height, state)
                    drawLine(
                        color = TealMeasurement,
                        start = Offset(pA.screenX, pA.screenY),
                        end = Offset(pB.screenX, pB.screenY),
                        strokeWidth = 3f
                    )
                    drawCircle(TealMeasurement, radius = 4.5f, center = Offset(pA.screenX, pA.screenY))
                    drawCircle(TealMeasurement, radius = 4.5f, center = Offset(pB.screenX, pB.screenY))

                    val mx = (pA.screenX + pB.screenX) * 0.5f
                    val my = (pA.screenY + pB.screenY) * 0.5f
                    val labelText = "${ov.label}: ${ov.valueFormatted}"
                    val tw = textPaint.measureText(labelText)
                    drawContext.canvas.nativeCanvas.drawRoundRect(
                        mx - 6f,
                        my - 26f,
                        mx + tw + 10f,
                        my + 8f,
                        8f,
                        8f,
                        bgPaint
                    )
                    drawContext.canvas.nativeCanvas.drawText(labelText, mx + 2f, my, textPaint)
                }
            }

            // Orientation Triad in bottom-left
            val triadCenter = Vec3(0f, 0f, 0f)
            val o = renderer.projectPoint(triadCenter, 120f, 120f, state.copy(panX = 0f, panY = 0f, zoom = 0.6f))
            val ax = renderer.projectPoint(Vec3(0.28f, 0f, 0f), 120f, 120f, state.copy(panX = 0f, panY = 0f, zoom = 0.6f))
            val ay = renderer.projectPoint(Vec3(0f, 0.28f, 0f), 120f, 120f, state.copy(panX = 0f, panY = 0f, zoom = 0.6f))
            val az = renderer.projectPoint(Vec3(0f, 0f, 0.28f), 120f, 120f, state.copy(panX = 0f, panY = 0f, zoom = 0.6f))
            val shiftX = 24f
            val shiftY = size.height - 96f
            drawLine(StatusWarning, Offset(o.screenX + shiftX, o.screenY + shiftY), Offset(ax.screenX + shiftX, ax.screenY + shiftY), 3f)
            drawLine(TealMeasurement, Offset(o.screenX + shiftX, o.screenY + shiftY), Offset(ay.screenX + shiftX, ay.screenY + shiftY), 3f)
            drawLine(VioletHighlight, Offset(o.screenX + shiftX, o.screenY + shiftY), Offset(az.screenX + shiftX, az.screenY + shiftY), 3f)
        }

        // Top-left projection telemetry tag
        Text(
            text = "${state.projectionMode.label.uppercase()} · YAW ${state.yawDeg.toInt()}° · PITCH ${state.pitchDeg.toInt()}°",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .background(PearlSurface.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
