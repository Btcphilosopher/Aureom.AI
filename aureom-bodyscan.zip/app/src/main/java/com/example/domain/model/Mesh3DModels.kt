package com.example.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class Vec3(
    val x: Float,
    val y: Float,
    val z: Float
)

@Serializable
enum class SectorCoverageStatus {
    MEASURED_CALIBRATED,
    INTERPOLATED_ESTIMATE,
    UNOBSERVED_GAP
}

@Serializable
data class MeshTriangle(
    val i0: Int,
    val i1: Int,
    val i2: Int,
    val sector: CaptureAngle,
    val coverageStatus: SectorCoverageStatus
)

@Serializable
data class MeasurementOverlay3D(
    val label: String,
    val valueFormatted: String,
    val start: Vec3,
    val end: Vec3
)

@Serializable
data class BodyMeshModel(
    val sessionId: String,
    val vertices: List<Vec3>, // Coordinates in normalized meters centered around pelvis (y up)
    val triangles: List<MeshTriangle>,
    val skeletonJoints: Map<AnatomicalLandmark, Vec3>,
    val measurementOverlays: List<MeasurementOverlay3D>,
    val provenanceType: ModelProvenanceType,
    val heightMeters: Float,
    val observedCoveragePercent: Int
)

@Serializable
enum class ViewPreset3D(val label: String, val yawDeg: Float, val pitchDeg: Float, val forceOrthographic: Boolean? = null) {
    FRONT("Front", 0f, 0f),
    REAR("Rear", 180f, 0f),
    LEFT_SIDE("Left", -90f, 0f),
    RIGHT_SIDE("Right", 90f, 0f),
    ISOMETRIC("Isometric", 45f, 35.264f, forceOrthographic = true)
}

@Serializable
enum class ProjectionMode3D(val label: String) {
    PERSPECTIVE("Perspective"),
    ORTHOGRAPHIC("Orthographic")
}

data class Viewport3DState(
    val yawDeg: Float = 24f,
    val pitchDeg: Float = 12f,
    val zoom: Float = 1.0f,
    val panX: Float = 0f,
    val panY: Float = 0f,
    val projectionMode: ProjectionMode3D = ProjectionMode3D.PERSPECTIVE,
    val showMeasurements: Boolean = true,
    val showSkeleton: Boolean = true,
    val showCoverageMap: Boolean = true,
    val clipMinNormalizedY: Float = 0.0f, // 0 = ankles/feet, 1 = head crown
    val clipMaxNormalizedY: Float = 1.0f
)
