package com.example.domain.math

import com.example.domain.model.BodyMeasurementRecord
import com.example.domain.model.ScanSession
import kotlin.math.abs
import kotlin.math.sqrt

data class MetricComparisonRow(
    val metricKey: String,
    val label: String,
    val baselineValueMm: Double?,
    val baselineUncertaintyMm: Double?,
    val targetValueMm: Double?,
    val targetUncertaintyMm: Double?,
    val deltaMm: Double?,
    val combinedUncertaintyMm: Double?,
    val isInconclusiveWithinUncertainty: Boolean,
    val sourceMismatch: Boolean,
    val interpretationNote: String
)

data class SessionComparisonResult(
    val baselineSession: ScanSession,
    val targetSession: ScanSession,
    val areMethodsCompatible: Boolean,
    val incompatibilityWarnings: List<String>,
    val rows: List<MetricComparisonRow>
)

object UncertaintyEngine {

    /**
     * Compares two sessions while surfacing differences in capture method, calibration,
     * equipment, and conditions. Flags small deltas that fall within combined measurement
     * uncertainty as inconclusive rather than treating noise as physical change.
     */
    fun compareSessions(
        baseline: ScanSession,
        target: ScanSession
    ): SessionComparisonResult {
        val warnings = mutableListOf<String>()

        if (baseline.captureMode != target.captureMode) {
            warnings.add(
                "Capture method mismatch: '${baseline.captureMode.title}' vs '${target.captureMode.title}'. Direct numerical comparison may reflect systematic method bias."
            )
        }
        if (baseline.calibration.source != target.calibration.source) {
            warnings.add(
                "Calibration mismatch: '${baseline.calibration.source.displayLabel}' vs '${target.calibration.source.displayLabel}'."
            )
        }
        if (!baseline.calibration.isScaleVerified || !target.calibration.isScaleVerified) {
            warnings.add(
                "At least one session is uncalibrated; metric delta cannot be verified."
            )
        }
        if (baseline.equipmentDescription != target.equipmentDescription) {
            warnings.add(
                "Equipment difference: '${baseline.equipmentDescription}' vs '${target.equipmentDescription}'."
            )
        }
        if (baseline.environmentConditions != target.environmentConditions) {
            warnings.add(
                "Conditions differ: '${baseline.environmentConditions}' vs '${target.environmentConditions}'."
            )
        }

        val methodsCompatible = baseline.captureMode == target.captureMode &&
            baseline.calibration.isScaleVerified &&
            target.calibration.isScaleVerified

        val baseMap = baseline.measurements.associateBy { it.metricKey }
        val targetMap = target.measurements.associateBy { it.metricKey }
        val allKeys = (baseMap.keys + targetMap.keys).distinct()

        val rows = allKeys.mapNotNull { key ->
            val a: BodyMeasurementRecord? = baseMap[key]
            val b: BodyMeasurementRecord? = targetMap[key]
            val label = b?.label ?: a?.label ?: return@mapNotNull null

            val vA = a?.valueMm
            val vB = b?.valueMm
            val uA = a?.uncertaintyMm
            val uB = b?.uncertaintyMm
            val sourceMismatch = a != null && b != null && a.sourceMethod != b.sourceMethod

            val delta = if (vA != null && vB != null) vB - vA else null
            val combinedUnc = if (uA != null && uB != null) {
                sqrt(uA * uA + uB * uB)
            } else null

            val inconclusive = when {
                delta == null -> true
                combinedUnc == null -> true
                abs(delta) < 1.5 * combinedUnc -> true
                else -> false
            }

            val note = when {
                vA == null || vB == null -> "Blocked or missing in one session (uncalibrated/unobserved)."
                sourceMismatch -> "Different measurement methods (${a.sourceMethod.displayLabel} vs ${b.sourceMethod.displayLabel}); treat delta cautiously."
                combinedUnc == null -> "Uncertainty unquantified in at least one record; significance unknown."
                abs(delta!!) < 1.5 * combinedUnc ->
                    "Inconclusive: |Δ| (${String.format("%.1f", abs(delta))} mm) is within 1.5× combined uncertainty (±${String.format("%.1f", combinedUnc)} mm)."
                else -> "Exceeds 1.5× combined uncertainty; verify conditions and posture consistency."
            }

            MetricComparisonRow(
                metricKey = key,
                label = label,
                baselineValueMm = vA,
                baselineUncertaintyMm = uA,
                targetValueMm = vB,
                targetUncertaintyMm = uB,
                deltaMm = delta,
                combinedUncertaintyMm = combinedUnc,
                isInconclusiveWithinUncertainty = inconclusive,
                sourceMismatch = sourceMismatch,
                interpretationNote = note
            )
        }

        return SessionComparisonResult(
            baselineSession = baseline,
            targetSession = target,
            areMethodsCompatible = methodsCompatible,
            incompatibilityWarnings = warnings,
            rows = rows
        )
    }
}
