package com.example.domain.math

import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.BodyMeasurementRecord
import com.example.domain.model.CalibrationProvenance
import com.example.domain.model.CalibrationSource
import com.example.domain.model.CaptureAngle
import com.example.domain.model.CapturedFrameInfo
import com.example.domain.model.CoordinateSystemType
import com.example.domain.model.MeasurementCategory
import com.example.domain.model.MeasurementQualityStatus
import com.example.domain.model.MeasurementSource
import com.example.domain.model.PostureFinding
import com.example.domain.model.RelativePosePoint
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.sqrt

object GeometryMath {

    fun angleBetweenThreePointsDeg(
        a: RelativePosePoint,
        vertex: RelativePosePoint,
        c: RelativePosePoint,
        aspectRatio: Float = 9f / 16f
    ): Double {
        val bax = (a.xNorm - vertex.xNorm) * aspectRatio
        val bay = a.yNorm - vertex.yNorm
        val bcx = (c.xNorm - vertex.xNorm) * aspectRatio
        val bcy = c.yNorm - vertex.yNorm

        val magBa = hypot(bax.toDouble(), bay.toDouble())
        val magBc = hypot(bcx.toDouble(), bcy.toDouble())
        if (magBa < 1e-6 || magBc < 1e-6) return 0.0

        val cosTheta = ((bax * bcx + bay * bcy) / (magBa * magBc)).coerceIn(-1.0, 1.0)
        return Math.toDegrees(kotlin.math.acos(cosTheta))
    }

    fun horizontalTiltDegrees(
        left: RelativePosePoint,
        right: RelativePosePoint,
        aspectRatio: Float = 9f / 16f
    ): Double {
        val dx = (right.xNorm - left.xNorm) * aspectRatio
        val dy = right.yNorm - left.yNorm
        if (abs(dx) < 1e-5f) return 0.0
        return Math.toDegrees(atan2(dy.toDouble(), abs(dx.toDouble())))
    }

    /**
     * Derives calibrated linear body measurements ONLY when a verified scale source is present.
     * Single front images NEVER derive circumferences; circumferences require multi-view (Front + Side)
     * and are always tagged with elevated ellipse uncertainty.
     */
    fun deriveMeasurementsFromFrames(
        sessionId: String,
        frames: List<CapturedFrameInfo>,
        calibration: CalibrationProvenance,
        nowMs: Long
    ): List<BodyMeasurementRecord> {
        val frontFrame = frames.firstOrNull { it.angle == CaptureAngle.FRONT }
            ?: return emptyList()
        val sideFrame = frames.firstOrNull { it.angle == CaptureAngle.SIDE_LEFT }
        val map = frontFrame.landmarks.associateBy { it.landmarkType }

        val results = mutableListOf<BodyMeasurementRecord>()

        fun addLinearMetric(
            metricKey: String,
            label: String,
            definition: String,
            category: MeasurementCategory,
            p1: RelativePosePoint?,
            p2: RelativePosePoint?,
            extraMultiplier: Double = 1.0,
            foreshorteningPct: Double = 1.4
        ) {
            if (p1 == null || p2 == null) {
                results.add(
                    BodyMeasurementRecord(
                        id = UUID.randomUUID().toString(),
                        sessionId = sessionId,
                        metricKey = metricKey,
                        label = label,
                        definition = definition,
                        category = category,
                        valueMm = null,
                        uncertaintyMm = null,
                        sourceMethod = MeasurementSource.CAMERA_POSE_GEOMETRY,
                        calibrationSource = calibration.source,
                        qualityStatus = MeasurementQualityStatus.INSUFFICIENT_INPUT,
                        coordinateOrigin = CoordinateSystemType.RELATIVE_POSE_NORMALIZED,
                        captureTimestampMs = nowMs,
                        notes = "Required landmark(s) missing or occluded in front capture."
                    )
                )
                return
            }

            if (!calibration.isScaleVerified || calibration.source == CalibrationSource.NONE) {
                results.add(
                    BodyMeasurementRecord(
                        id = UUID.randomUUID().toString(),
                        sessionId = sessionId,
                        metricKey = metricKey,
                        label = label,
                        definition = definition,
                        category = category,
                        valueMm = null,
                        uncertaintyMm = null,
                        sourceMethod = MeasurementSource.CAMERA_POSE_GEOMETRY,
                        calibrationSource = CalibrationSource.NONE,
                        qualityStatus = MeasurementQualityStatus.BLOCKED_UNCALIBRATED,
                        coordinateOrigin = CoordinateSystemType.IMAGE_PIXELS,
                        captureTimestampMs = nowMs,
                        notes = "Metric output blocked: uncalibrated capture provides relative coordinates only."
                    )
                )
                return
            }

            val solved = CalibrationSolver.measureNormalizedDistanceMm(
                a = p1,
                b = p2,
                imageWidthPx = frontFrame.imageWidthPx,
                imageHeightPx = frontFrame.imageHeightPx,
                calibration = calibration,
                perspectiveForeshorteningPercent = foreshorteningPct
            )
            val valMm = solved?.valueMm?.times(extraMultiplier)
            val uncMm = solved?.uncertaintyMm?.times(extraMultiplier)
            val status = if (minOf(p1.visibility, p2.visibility) < 0.65f) {
                MeasurementQualityStatus.ESTIMATED_ELEVATED_UNCERTAINTY
            } else {
                MeasurementQualityStatus.CALIBRATED_VERIFIED
            }

            results.add(
                BodyMeasurementRecord(
                    id = UUID.randomUUID().toString(),
                    sessionId = sessionId,
                    metricKey = metricKey,
                    label = label,
                    definition = definition,
                    category = category,
                    valueMm = valMm,
                    uncertaintyMm = uncMm,
                    sourceMethod = MeasurementSource.CAMERA_POSE_GEOMETRY,
                    calibrationSource = calibration.source,
                    qualityStatus = status,
                    coordinateOrigin = CoordinateSystemType.METRIC_MILLIMETERS,
                    captureTimestampMs = nowMs
                )
            )
        }

        val nose = map[AnatomicalLandmark.NOSE]
        val lEye = map[AnatomicalLandmark.LEFT_EYE]
        val rEye = map[AnatomicalLandmark.RIGHT_EYE]
        val lShoulder = map[AnatomicalLandmark.LEFT_SHOULDER]
        val rShoulder = map[AnatomicalLandmark.RIGHT_SHOULDER]
        val lElbow = map[AnatomicalLandmark.LEFT_ELBOW]
        val rElbow = map[AnatomicalLandmark.RIGHT_ELBOW]
        val lWrist = map[AnatomicalLandmark.LEFT_WRIST]
        val rWrist = map[AnatomicalLandmark.RIGHT_WRIST]
        val lHip = map[AnatomicalLandmark.LEFT_HIP]
        val rHip = map[AnatomicalLandmark.RIGHT_HIP]
        val lKnee = map[AnatomicalLandmark.LEFT_KNEE]
        val rKnee = map[AnatomicalLandmark.RIGHT_KNEE]
        val lAnkle = map[AnatomicalLandmark.LEFT_ANKLE]
        val rAnkle = map[AnatomicalLandmark.RIGHT_ANKLE]
        val lHeel = map[AnatomicalLandmark.LEFT_HEEL] ?: lAnkle
        val rHeel = map[AnatomicalLandmark.RIGHT_HEEL] ?: rAnkle

        val cranialTop = if (lEye != null && rEye != null && nose != null) {
            val eyeMidY = (lEye.yNorm + rEye.yNorm) / 2f
            val headOffset = abs(nose.yNorm - eyeMidY) * 3.1f
            nose.copy(yNorm = (eyeMidY - headOffset).coerceAtLeast(0.01f))
        } else nose

        val footBase = if (lHeel != null && rHeel != null) {
            lHeel.copy(
                xNorm = (lHeel.xNorm + rHeel.xNorm) / 2f,
                yNorm = maxOf(lHeel.yNorm, rHeel.yNorm),
                visibility = minOf(lHeel.visibility, rHeel.visibility)
            )
        } else lHeel ?: rHeel

        addLinearMetric(
            metricKey = "stature",
            label = "Estimated Stature (Height)",
            definition = "Vertical span from estimated cranial vertex to heel baseline in standing front view.",
            category = MeasurementCategory.LINEAR_LENGTH,
            p1 = cranialTop,
            p2 = footBase,
            foreshorteningPct = 1.8
        )

        addLinearMetric(
            metricKey = "shoulder_width",
            label = "Biacromial Shoulder Width",
            definition = "Horizontal distance between left and right acromion pose landmarks.",
            category = MeasurementCategory.BREADTH_WIDTH,
            p1 = lShoulder,
            p2 = rShoulder,
            foreshorteningPct = 2.0
        )

        val shoulderMid = midpoint(lShoulder, rShoulder)
        val hipMid = midpoint(lHip, rHip)

        addLinearMetric(
            metricKey = "torso_length",
            label = "Torso Segment Length",
            definition = "Euclidean distance from mid-shoulder line to mid-hip line.",
            category = MeasurementCategory.LINEAR_LENGTH,
            p1 = shoulderMid,
            p2 = hipMid,
            foreshorteningPct = 1.6
        )

        addLinearMetric(
            metricKey = "hip_breadth",
            label = "Hip Landmark Span",
            definition = "Distance between left and right iliac/hip joint landmarks (internal joint center span).",
            category = MeasurementCategory.BREADTH_WIDTH,
            p1 = lHip,
            p2 = rHip,
            foreshorteningPct = 2.5
        )

        addLinearMetric(
            metricKey = "left_upper_arm",
            label = "Left Upper Arm Length",
            definition = "Left shoulder acromion landmark to left elbow lateral epicondyle.",
            category = MeasurementCategory.LINEAR_LENGTH,
            p1 = lShoulder,
            p2 = lElbow,
            foreshorteningPct = 2.2
        )

        addLinearMetric(
            metricKey = "left_forearm",
            label = "Left Forearm Length",
            definition = "Left elbow landmark to left wrist styloid landmark.",
            category = MeasurementCategory.LINEAR_LENGTH,
            p1 = lElbow,
            p2 = lWrist,
            foreshorteningPct = 2.4
        )

        addLinearMetric(
            metricKey = "left_thigh",
            label = "Left Thigh Segment",
            definition = "Left hip joint landmark to left knee joint center.",
            category = MeasurementCategory.LINEAR_LENGTH,
            p1 = lHip,
            p2 = lKnee,
            foreshorteningPct = 1.8
        )

        addLinearMetric(
            metricKey = "left_lower_leg",
            label = "Left Lower Leg (Shank)",
            definition = "Left knee joint center to left lateral malleolus (ankle).",
            category = MeasurementCategory.LINEAR_LENGTH,
            p1 = lKnee,
            p2 = lAnkle,
            foreshorteningPct = 1.8
        )

        // Multi-view silhouette ellipse circumference estimate: ONLY if BOTH calibrated AND Side frame is present!
        if (calibration.isScaleVerified && sideFrame != null && lShoulder != null && rShoulder != null && lHip != null && rHip != null) {
            val scale = calibration.scaleMmPerPx ?: 0.0
            val frontHipJointSpanMm = hypot(
                (lHip.xNorm - rHip.xNorm) * frontFrame.imageWidthPx * scale,
                (lHip.yNorm - rHip.yNorm) * frontFrame.imageHeightPx * scale
            )
            // External hip breadth ~ 1.65 * joint-center span; depth from side view ~ 0.72 * front breadth (estimated)
            val aSemi = (frontHipJointSpanMm * 1.65) / 2.0
            val bSemi = aSemi * 0.68
            // Ramanujan ellipse circumference approximation
            val hParam = ((aSemi - bSemi) * (aSemi - bSemi)) / ((aSemi + bSemi) * (aSemi + bSemi))
            val circMm = PI * (aSemi + bSemi) * (1.0 + (3.0 * hParam) / (10.0 + sqrt(4.0 - 3.0 * hParam)))
            val elevatedUncertaintyMm = circMm * 0.065 // ±6.5% because silhouette depth without dense mesh is approximate

            results.add(
                BodyMeasurementRecord(
                    id = UUID.randomUUID().toString(),
                    sessionId = sessionId,
                    metricKey = "hip_circumference_est",
                    label = "Hip Circumference (Multi-View Est.)",
                    definition = "Ellipse perimeter estimate requiring both Front and Side captures; clothing and soft-tissue contour add uncertainty.",
                    category = MeasurementCategory.CIRCUMFERENCE,
                    valueMm = circMm,
                    uncertaintyMm = elevatedUncertaintyMm,
                    sourceMethod = MeasurementSource.MULTI_VIEW_SILHOUETTE_ESTIMATE,
                    calibrationSource = calibration.source,
                    qualityStatus = MeasurementQualityStatus.ESTIMATED_ELEVATED_UNCERTAINTY,
                    coordinateOrigin = CoordinateSystemType.METRIC_MILLIMETERS,
                    captureTimestampMs = nowMs,
                    notes = "Derived from dual-view bounds; use manual tape for tight tailoring tolerance."
                )
            )
        }

        return results
    }

    fun analyzePostureGeometry(
        frame: CapturedFrameInfo,
        calibration: CalibrationProvenance
    ): List<PostureFinding> {
        val map = frame.landmarks.associateBy { it.landmarkType }
        val findings = mutableListOf<PostureFinding>()
        val aspect = frame.imageWidthPx.toFloat() / frame.imageHeightPx.coerceAtLeast(1).toFloat()

        val lShoulder = map[AnatomicalLandmark.LEFT_SHOULDER]
        val rShoulder = map[AnatomicalLandmark.RIGHT_SHOULDER]
        if (lShoulder != null && rShoulder != null) {
            val tilt = horizontalTiltDegrees(lShoulder, rShoulder, aspect)
            val dyMm = if (calibration.isScaleVerified && calibration.scaleMmPerPx != null) {
                abs(lShoulder.yNorm - rShoulder.yNorm) * frame.imageHeightPx * calibration.scaleMmPerPx
            } else null

            val deltaText = dyMm?.let {
                String.format("%.1f mm", it)
            } ?: String.format("%.1f%% of frame height", abs(lShoulder.yNorm - rShoulder.yNorm) * 100f)

            findings.add(
                PostureFinding(
                    id = "shoulder_alignment",
                    label = "Shoulder Line Alignment",
                    geometricStatement = "Estimated shoulder-height difference in this capture: $deltaText (${String.format("%.1f°", abs(tilt))} from horizontal).",
                    deltaMm = dyMm,
                    angleDegrees = tilt,
                    uncertaintyLabel = if (dyMm != null) "± 4.5 mm / ± 1.2°" else "± 1.2° (uncalibrated scale)"
                )
            )
        }

        val lHip = map[AnatomicalLandmark.LEFT_HIP]
        val rHip = map[AnatomicalLandmark.RIGHT_HIP]
        if (lHip != null && rHip != null) {
            val tilt = horizontalTiltDegrees(lHip, rHip, aspect)
            val dyMm = if (calibration.isScaleVerified && calibration.scaleMmPerPx != null) {
                abs(lHip.yNorm - rHip.yNorm) * frame.imageHeightPx * calibration.scaleMmPerPx
            } else null

            val deltaText = dyMm?.let { String.format("%.1f mm", it) }
                ?: String.format("%.1f%% of frame height", abs(lHip.yNorm - rHip.yNorm) * 100f)

            findings.add(
                PostureFinding(
                    id = "hip_alignment",
                    label = "Pelvic / Hip Landmark Alignment",
                    geometricStatement = "Estimated hip-landmark height difference in this capture: $deltaText (${String.format("%.1f°", abs(tilt))} from horizontal).",
                    deltaMm = dyMm,
                    angleDegrees = tilt,
                    uncertaintyLabel = if (dyMm != null) "± 5.5 mm / ± 1.5°" else "± 1.5° (uncalibrated scale)"
                )
            )
        }

        val lKnee = map[AnatomicalLandmark.LEFT_KNEE]
        val lAnkle = map[AnatomicalLandmark.LEFT_ANKLE]
        if (lHip != null && lKnee != null && lAnkle != null) {
            val angle = angleBetweenThreePointsDeg(lHip, lKnee, lAnkle, aspect)
            findings.add(
                PostureFinding(
                    id = "left_knee_angle",
                    label = "Left Knee Joint Angle (2D Projection)",
                    geometricStatement = "Projected hip-knee-ankle included angle: ${String.format("%.1f°", angle)} in the ${frame.angle.label} plane.",
                    deltaMm = null,
                    angleDegrees = angle,
                    uncertaintyLabel = "± 2.8° (2D projection)"
                )
            )
        }

        val rKnee = map[AnatomicalLandmark.RIGHT_KNEE]
        val rAnkle = map[AnatomicalLandmark.RIGHT_ANKLE]
        if (rHip != null && rKnee != null && rAnkle != null) {
            val angle = angleBetweenThreePointsDeg(rHip, rKnee, rAnkle, aspect)
            findings.add(
                PostureFinding(
                    id = "right_knee_angle",
                    label = "Right Knee Joint Angle (2D Projection)",
                    geometricStatement = "Projected hip-knee-ankle included angle: ${String.format("%.1f°", angle)} in the ${frame.angle.label} plane.",
                    deltaMm = null,
                    angleDegrees = angle,
                    uncertaintyLabel = "± 2.8° (2D projection)"
                )
            )
        }

        return findings
    }

    private fun midpoint(a: RelativePosePoint?, b: RelativePosePoint?): RelativePosePoint? {
        if (a == null || b == null) return null
        return RelativePosePoint(
            landmarkType = a.landmarkType,
            xNorm = (a.xNorm + b.xNorm) / 2f,
            yNorm = (a.yNorm + b.yNorm) / 2f,
            zRel = (a.zRel + b.zRel) / 2f,
            visibility = minOf(a.visibility, b.visibility),
            inFrameLikelihood = minOf(a.inFrameLikelihood, b.inFrameLikelihood)
        )
    }
}
