package com.example.domain.math

import com.example.domain.model.ForceUnit
import com.example.domain.model.LengthUnit
import java.util.Locale
import kotlin.math.roundToInt

object UnitConverter {
    const val MM_PER_CM = 10.0
    const val MM_PER_INCH = 25.4
    const val NEWTONS_PER_KGF = 9.80665
    const val NEWTONS_PER_LBF = 4.4482216152605

    fun mmToUnit(valueMm: Double, unit: LengthUnit): Double = when (unit) {
        LengthUnit.CENTIMETERS -> valueMm / MM_PER_CM
        LengthUnit.INCHES -> valueMm / MM_PER_INCH
    }

    fun unitToMm(value: Double, unit: LengthUnit): Double = when (unit) {
        LengthUnit.CENTIMETERS -> value * MM_PER_CM
        LengthUnit.INCHES -> value * MM_PER_INCH
    }

    fun formatLength(valueMm: Double?, unit: LengthUnit, decimals: Int = 1): String {
        if (valueMm == null) return "Blocked"
        val converted = mmToUnit(valueMm, unit)
        return String.format(Locale.US, "%.${decimals}f %s", converted, unit.symbol)
    }

    fun formatLengthWithUncertainty(
        valueMm: Double?,
        uncertaintyMm: Double?,
        unit: LengthUnit,
        decimals: Int = 1
    ): String {
        if (valueMm == null) return "Blocked (Uncalibrated)"
        val v = mmToUnit(valueMm, unit)
        return if (uncertaintyMm != null) {
            val u = mmToUnit(uncertaintyMm, unit)
            String.format(Locale.US, "%.${decimals}f ± %.${decimals}f %s", v, u, unit.symbol)
        } else {
            String.format(Locale.US, "%.${decimals}f %s (Unquantified)", v, unit.symbol)
        }
    }

    fun formatDelta(deltaMm: Double, unit: LengthUnit, decimals: Int = 1): String {
        val converted = mmToUnit(deltaMm, unit)
        val sign = if (converted > 0) "+" else ""
        return String.format(Locale.US, "%s%.${decimals}f %s", sign, converted, unit.symbol)
    }

    fun newtonsToUnit(forceN: Double, unit: ForceUnit): Double = when (unit) {
        ForceUnit.NEWTONS -> forceN
        ForceUnit.KGF -> forceN / NEWTONS_PER_KGF
        ForceUnit.LBF -> forceN / NEWTONS_PER_LBF
    }

    fun formatForce(forceN: Double, unit: ForceUnit): String {
        val value = newtonsToUnit(forceN, unit)
        val decimals = if (unit == ForceUnit.NEWTONS) 0 else 1
        return String.format(Locale.US, "%.${decimals}f %s", value, unit.symbol)
    }

    fun roundToTenths(value: Double): Double = (value * 10.0).roundToInt() / 10.0
}
