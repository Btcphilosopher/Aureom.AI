package com.example.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class CaptureMode(
    val title: String,
    val shortBadge: String,
    val disclaimer: String
) {
    GUIDED_PHOTOGRAPHS(
        title = "Guided Photographs",
        shortBadge = "CAMERA + POSE",
        disclaimer = "Produces estimated linear body dimensions when calibrated. Does not directly capture a dense 3D surface."
    ),
    POSE_TRACKING(
        title = "Pose Tracking",
        shortBadge = "LIVE LANDMARKS",
        disclaimer = "A pose skeleton is not a surface scan. Reports joint landmarks and geometric angles."
    ),
    DEPTH_CAPTURE(
        title = "Depth Capture",
        shortBadge = "HARDWARE DEPTH",
        disclaimer = "Available only on devices with certified hardware depth output."
    ),
    RECONSTRUCTION_3D(
        title = "3D Reconstruction",
        shortBadge = "BACKEND MESH",
        disclaimer = "Available only when an explicitly consented reconstruction backend or depth pipeline is configured."
    ),
    MANUAL_MEASUREMENTS(
        title = "Manual Measurements",
        shortBadge = "MANUAL TAPE",
        disclaimer = "User-entered physical tape measurements stored separately from camera estimates."
    ),
    DEMONSTRATION(
        title = "Demonstration Fixtures",
        shortBadge = "SYNTHETIC DEMO",
        disclaimer = "Synthetic body models, pose sequences, and simulated sensor recordings for evaluation."
    )
}

@Serializable
enum class CaptureAngle(val label: String, val instruction: String) {
    FRONT("Front (0°)", "Stand facing camera, arms slightly abducted (~20°), feet hip-width apart."),
    SIDE_LEFT("Side (90° Left)", "Turn 90° left, stand tall looking straight ahead, hands relaxed at sides."),
    REAR("Rear (180°)", "Face away from camera, maintain neutral posture with heels visible.")
}

@Serializable
enum class QualityIssueType(val label: String, val recaptureInstruction: String) {
    INCOMPLETE_COVERAGE(
        "Incomplete View Coverage",
        "Capture missing angles (Front, Side, and Rear) so unobserved sides are not left unmeasured."
    ),
    EXCESSIVE_MOTION(
        "Excessive Device or Subject Motion",
        "Stabilize phone on a tripod or steady surface and hold still during the 2-second countdown."
    ),
    OCCLUSION(
        "Landmark Occlusion Detected",
        "Ensure ankles, wrists, shoulders, and hips are unobstructed and fully inside the frame."
    ),
    INSUFFICIENT_INPUT(
        "Low Lighting or Poor Contrast",
        "Increase ambient lighting and stand against a plain, contrasting background."
    ),
    MISSING_CALIBRATION(
        "Missing Scale Calibration",
        "Include a flat A4 reference card (210 × 297 mm) in the capture plane or enter reference stature."
    ),
    RECONSTRUCTION_UNAVAILABLE(
        "3D Reconstruction Unavailable",
        "No on-device depth sensor or consented FastAPI reconstruction endpoint is active. Partial gaps are preserved."
    )
}

@Serializable
enum class SessionProcessingState {
    DRAFT,
    READY_FOR_REVIEW,
    COMPLETED,
    PARTIAL_WITH_WARNINGS,
    FAILED_RECONSTRUCTION,
    CANCELLED
}

@Serializable
enum class GuidedWorkflowStage(val stepIndex: Int, val title: String) {
    CONSENT(0, "Consent"),
    INSTRUCTIONS(1, "Guidance"),
    DEVICE_CHECKS(2, "Device Checks"),
    CALIBRATION(3, "Calibration"),
    CAPTURE(4, "Guided Capture"),
    QUALITY_REVIEW(5, "Quality Review"),
    PROCESSING(6, "Processing"),
    RESULTS(7, "Results")
}

@Serializable
data class CapturedFrameInfo(
    val id: String,
    val sessionId: String,
    val angle: CaptureAngle,
    val localFilePath: String?, // Null for synthetic demo fixtures without disk JPEGs
    val capturedAtMs: Long,
    val imageWidthPx: Int,
    val imageHeightPx: Int,
    val meanLuma: Float, // 0..255
    val motionStabilityScore: Float, // 0..1 (1 = rock steady)
    val landmarks: List<RelativePosePoint>,
    val occludedLandmarks: List<AnatomicalLandmark>,
    val qualityIssues: List<QualityIssueType>,
    val isSynthetic: Boolean = false
)

@Serializable
data class ScanSession(
    val id: String,
    val title: String,
    val createdAtMs: Long,
    val captureMode: CaptureMode,
    val processingState: SessionProcessingState,
    val calibration: CalibrationProvenance,
    val frames: List<CapturedFrameInfo>,
    val measurements: List<BodyMeasurementRecord>,
    val modelProvenance: ModelProvenanceType,
    val coveredSectors: Set<CaptureAngle>,
    val equipmentDescription: String,
    val environmentConditions: String,
    val personalNotes: String = "",
    val isDemoFixture: Boolean = false,
    val demoScenarioTag: String? = null,
    val backendJobId: String? = null
)

@Serializable
enum class ModelProvenanceType(val badgeLabel: String, val explanation: String) {
    POSE_SKELETON_ONLY(
        "POSE SKELETON ONLY",
        "Stick-figure landmarks only. A pose skeleton is not a surface scan."
    ),
    ESTIMATED_PARAMETRIC_AVATAR(
        "ESTIMATED AVATAR (CALIBRATED)",
        "Generic anatomical surface fitted to calibrated linear estimates. Not a dense 3D surface scan."
    ),
    PARTIAL_COVERAGE_MODEL(
        "PARTIAL CAPTURE · GAPS PRESERVED",
        "Unobserved sectors remain marked as unmeasured gaps; no anatomy was fabricated."
    ),
    RECONSTRUCTED_MESH(
        "RECONSTRUCTED MESH",
        "3D surface geometry returned by an explicitly consented reconstruction backend or depth sensor."
    ),
    SYNTHETIC_DEMO_MODEL(
        "SYNTHETIC DEMONSTRATION MODEL",
        "Pre-bundled synthetic test geometry for reproducible evaluation."
    ),
    MANUAL_RECORD_ONLY(
        "MANUAL MEASUREMENTS ONLY",
        "Tape measurements recorded without camera surface geometry."
    )
}
