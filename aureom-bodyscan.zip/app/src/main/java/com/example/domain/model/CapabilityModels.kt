package com.example.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class CapabilitySupportLevel(val label: String) {
    IMPLEMENTED("Implemented"),
    ESTIMATED("Estimated"),
    SIMULATED("Simulated"),
    UNSUPPORTED("Unsupported")
}

@Serializable
data class CapabilityItem(
    val id: String,
    val name: String,
    val supportLevel: CapabilitySupportLevel,
    val adapterName: String,
    val hardwareRequirement: String,
    val details: String,
    val licenseInfo: String
)

@Serializable
data class DeviceCapabilityReport(
    val deviceModel: String,
    val androidSdkInt: Int,
    val hasRgbCamera: Boolean,
    val hasFrontCamera: Boolean,
    val hasHardwareDepthOutput: Boolean,
    val hasArCoreFeature: Boolean,
    val hasAccelerometer: Boolean,
    val hasBluetoothLe: Boolean,
    val isBackendConfigured: Boolean,
    val isCloudOptInEnabled: Boolean,
    val capabilities: List<CapabilityItem>
)
