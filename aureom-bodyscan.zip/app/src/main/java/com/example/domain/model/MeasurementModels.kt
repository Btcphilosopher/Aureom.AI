package com.example.domain.model

import kotlinx.serialization.Serializable

/**
 * Display unit preference; internal canonical values are ALWAYS stored in millimeters (mm).
 */
@Serializable
enum class LengthUnit(val symbol: String, val label: String) {
    CENTIMETERS("cm", "Centimetres (cm)"),
    INCHES("in", "Inches (in)")
}

@Serializable
enum class ForceUnit(val symbol: String, val label: String) {
    NEWTONS("N", "Newtons (N)"),
    KGF("kgf", "Kilogram-force (kgf)"),
    LBF("lbf", "Pound-force (lbf)")
}

@Serializable
enum class CoordinateSystemType {
    IMAGE_PIXELS,
    RELATIVE_POSE_NORMALIZED,
    METRIC_MILLIMETERS,
    MANUAL_TAPE_MILLIMETERS,
    DEPTH_SENSOR_MILLIMETERS
}

/**
 * Raw 2D image coordinates in sensor/frame pixel space.
 * Never directly interpreted as physical dimensions without calibration.
 */
@Serializable
data class ImagePointPx(
    val xPx: Float,
    val yPx: Float,
    val imageWidthPx: Int,
    val imageHeightPx: Int,
    val confidence: Float
)

/**
 * Normalized dimensionless pose coordinates (0.0..1.0 in frame X/Y, relative depth Z).
 */
@Serializable
data class RelativePosePoint(
    val landmarkType: AnatomicalLandmark,
    val xNorm: Float,
    val yNorm: Float,
    val zRel: Float,
    val visibility: Float,
    val inFrameLikelihood: Float
)

/**
 * Calibrated metric measurement stored internally in millimeters.
 */
@Serializable
data class MetricMeasurementMm(
    val valueMm: Double,
    val uncertaintyMm: Double?, // null means explicitly unquantified
    val calibrationSource: CalibrationSource
)

/**
 * User-entered tape measurement stored internally in millimeters.
 */
@Serializable
data class ManualMeasurementMm(
    val valueMm: Double,
    val estimatedTapeToleranceMm: Double = 5.0
)

/**
 * Hardware depth-sensor-derived measurement (only valid when a depth sensor adapter provides it).
 */
@Serializable
data class DepthMeasurementMm(
    val valueMm: Double,
    val uncertaintyMm: Double,
    val depthSensorId: String
)

@Serializable
enum class CalibrationSource(val displayLabel: String, val isAbsoluteScaleSupported: Boolean) {
    NONE("Uncalibrated (No Reference Scale)", false),
    A4_REFERENCE_CARD("A4 Calibration Card (210 × 297 mm)", true),
    ARUCO_MARKER("Fiducial Marker Target (150 mm)", true),
    USER_HEIGHT_REFERENCE("User-Entered Stature Reference", true),
    HARDWARE_DEPTH_INTRINSICS("Hardware Depth Camera Intrinsics", true),
    MANUAL_TAPE("Manual Measuring Tape", true),
    SYNTHETIC_DEMO("Synthetic Demonstration Fixture", true)
}

@Serializable
enum class MeasurementSource(val displayLabel: String, val isManual: Boolean) {
    CAMERA_POSE_GEOMETRY("Guided Camera + Pose Geometry", false),
    MULTI_VIEW_SILHOUETTE_ESTIMATE("Multi-View Silhouette Ellipse Estimate", false),
    MANUAL_TAPE("Manual Tape Entry", true),
    HARDWARE_DEPTH_SENSOR("Hardware Depth Sensor", false),
    BACKEND_RECONSTRUCTION("Consented Backend 3D Mesh", false),
    SYNTHETIC_DEMO("Synthetic Demonstration Fixture", false)
}

@Serializable
enum class MeasurementQualityStatus(val displayLabel: String) {
    CALIBRATED_VERIFIED("Calibrated · Quantified"),
    ESTIMATED_ELEVATED_UNCERTAINTY("Estimated · Elevated Uncertainty"),
    MANUAL_ENTRY("Manual Entry"),
    UNQUANTIFIED_UNCERTAINTY("Unquantified Uncertainty"),
    BLOCKED_UNCALIBRATED("Blocked · Missing Calibration"),
    INSUFFICIENT_INPUT("Insufficient Coverage / Occluded")
}

@Serializable
enum class MeasurementCategory {
    LINEAR_LENGTH,
    BREADTH_WIDTH,
    CIRCUMFERENCE,
    POSTURE_GEOMETRY
}

@Serializable
data class BodyMeasurementRecord(
    val id: String,
    val sessionId: String,
    val metricKey: String,
    val label: String,
    val definition: String,
    val category: MeasurementCategory,
    val valueMm: Double?, // Null when blocked (e.g. uncalibrated or unsupported)
    val uncertaintyMm: Double?, // Null when unquantified
    val sourceMethod: MeasurementSource,
    val calibrationSource: CalibrationSource,
    val qualityStatus: MeasurementQualityStatus,
    val coordinateOrigin: CoordinateSystemType,
    val captureTimestampMs: Long,
    val notes: String = ""
)

@Serializable
data class CalibrationProvenance(
    val source: CalibrationSource,
    val scaleMmPerPx: Double?,
    val referencePixelSpan: Double?,
    val referencePhysicalMm: Double?,
    val uncertaintyPercent: Double?,
    val cameraDistanceEstimateMeters: Double?,
    val isScaleVerified: Boolean,
    val warningMessage: String? = null
)

@Serializable
enum class AnatomicalLandmark(val displayName: String) {
    NOSE("Nose / Cranial Ref"),
    LEFT_EYE("Left Eye"),
    RIGHT_EYE("Right Eye"),
    LEFT_EAR("Left Ear"),
    RIGHT_EAR("Right Ear"),
    LEFT_SHOULDER("Left Acromion"),
    RIGHT_SHOULDER("Right Acromion"),
    LEFT_ELBOW("Left Elbow"),
    RIGHT_ELBOW("Right Elbow"),
    LEFT_WRIST("Left Wrist"),
    RIGHT_WRIST("Right Wrist"),
    LEFT_HIP("Left Hip (Iliac)"),
    RIGHT_HIP("Right Hip (Iliac)"),
    LEFT_KNEE("Left Knee"),
    RIGHT_KNEE("Right Knee"),
    LEFT_ANKLE("Left Ankle"),
    RIGHT_ANKLE("Right Ankle"),
    LEFT_HEEL("Left Heel"),
    RIGHT_HEEL("Right Heel"),
    LEFT_FOOT_INDEX("Left Toe"),
    RIGHT_FOOT_INDEX("Right Toe")
}
