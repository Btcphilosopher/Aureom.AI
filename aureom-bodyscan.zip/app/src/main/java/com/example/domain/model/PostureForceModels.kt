package com.example.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class PostureFinding(
    val id: String,
    val label: String,
    val geometricStatement: String,
    val deltaMm: Double?,
    val angleDegrees: Double?,
    val uncertaintyLabel: String
)

@Serializable
data class PostureAnalysisSnapshot(
    val sessionId: String,
    val title: String,
    val viewpoint: CaptureAngle,
    val capturedAtMs: Long,
    val meanLandmarkConfidence: Float,
    val occludedLandmarks: List<AnatomicalLandmark>,
    val landmarks: List<RelativePosePoint>,
    val findings: List<PostureFinding>,
    val isSyntheticDemo: Boolean
)

@Serializable
data class PoseFrameSample(
    val frameIndex: Int,
    val timestampMs: Long,
    val landmarks: List<RelativePosePoint>,
    val leftKneeAngleDeg: Double,
    val rightKneeAngleDeg: Double,
    val shoulderTiltDeg: Double,
    val meanConfidence: Float
)

@Serializable
data class MovementSequence(
    val id: String,
    val title: String,
    val captureDateMs: Long,
    val viewpoint: CaptureAngle,
    val fps: Float,
    val frames: List<PoseFrameSample>,
    val isSyntheticDemo: Boolean,
    val provenanceNote: String
)

@Serializable
data class ForceSamplePoint(
    val timestampMs: Long,
    val forceNewtons: Double,
    val isOverload: Boolean = false
)

@Serializable
data class ForceSensorTrial(
    val id: String,
    val sensorId: String,
    val sensorName: String,
    val isSimulated: Boolean,
    val calibrationDateIso: String,
    val nativeUnit: ForceUnit,
    val samplingRateHz: Int,
    val exerciseSetup: String,
    val trialDurationSec: Double,
    val samples: List<ForceSamplePoint>,
    val peakForceNewtons: Double,
    val meanForceNewtons: Double,
    val missingSampleCount: Int,
    val overloadCount: Int,
    val recordedAtMs: Long
)
