package com.example.domain.math

import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.BodyMeshModel
import com.example.domain.model.CaptureAngle
import com.example.domain.model.MeasurementOverlay3D
import com.example.domain.model.MeshTriangle
import com.example.domain.model.ModelProvenanceType
import com.example.domain.model.ScanSession
import com.example.domain.model.SectorCoverageStatus
import com.example.domain.model.Vec3
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Generates an external anatomical parametric 3D mesh for interactive inspection.
 * Explicitly preserves UNOBSERVED_GAP sectors when Side or Rear captures were not recorded,
 * ensuring unobserved anatomy is never presented as measured.
 */
object MeshGenerator {

    fun buildModelForSession(session: ScanSession): BodyMeshModel {
        val statureMm = session.measurements.firstOrNull { it.metricKey == "stature" }?.valueMm ?: 1730.0
        val shoulderMm = session.measurements.firstOrNull { it.metricKey == "shoulder_width" }?.valueMm ?: 410.0
        val hipMm = session.measurements.firstOrNull { it.metricKey == "hip_breadth" }?.valueMm ?: 290.0

        val hScale = (statureMm / 1730.0).toFloat().coerceIn(0.75f, 1.25f)
        val wScale = (shoulderMm / 410.0).toFloat().coerceIn(0.80f, 1.30f)
        val hipScale = (hipMm / 290.0).toFloat().coerceIn(0.80f, 1.35f)

        val vertices = mutableListOf<Vec3>()
        val triangles = mutableListOf<MeshTriangle>()

        val covered = session.coveredSectors
        fun statusForSector(thetaRad: Double): Pair<CaptureAngle, SectorCoverageStatus> {
            // theta = 0 is +Z (Front), PI/2 is +X (Right/Side), PI is -Z (Rear), 3PI/2 is -X (Left)
            val deg = ((Math.toDegrees(thetaRad) % 360.0) + 360.0) % 360.0
            val sector = when {
                deg < 50.0 || deg >= 310.0 -> CaptureAngle.FRONT
                deg in 130.0..230.0 -> CaptureAngle.REAR
                else -> CaptureAngle.SIDE_LEFT
            }
            val status = when {
                session.modelProvenance == ModelProvenanceType.SYNTHETIC_DEMO_MODEL ||
                    session.modelProvenance == ModelProvenanceType.RECONSTRUCTED_MESH ->
                    if (covered.contains(sector)) SectorCoverageStatus.MEASURED_CALIBRATED else SectorCoverageStatus.UNOBSERVED_GAP
                covered.contains(sector) -> SectorCoverageStatus.INTERPOLATED_ESTIMATE
                else -> SectorCoverageStatus.UNOBSERVED_GAP
            }
            return sector to status
        }

        fun addTube(
            rings: List<Triple<Float, Float, Float>>, // y, rx, rz (or center x offset)
            xOffset: Float = 0f,
            zOffset: Float = 0f,
            segments: Int = 16
        ) {
            val baseIdx = vertices.size
            for ((y, rx, rz) in rings) {
                for (s in 0 until segments) {
                    val theta = (2.0 * PI * s) / segments
                    val vx = xOffset + rx * sin(theta).toFloat()
                    val vz = zOffset + rz * cos(theta).toFloat()
                    vertices.add(Vec3(vx, y * hScale, vz))
                }
            }
            for (r in 0 until rings.size - 1) {
                for (s in 0 until segments) {
                    val nextS = (s + 1) % segments
                    val i0 = baseIdx + r * segments + s
                    val i1 = baseIdx + r * segments + nextS
                    val i2 = baseIdx + (r + 1) * segments + s
                    val i3 = baseIdx + (r + 1) * segments + nextS
                    val midTheta = (2.0 * PI * (s + 0.5)) / segments
                    val (sector, cov) = statusForSector(midTheta)
                    triangles.add(MeshTriangle(i0, i2, i1, sector, cov))
                    triangles.add(MeshTriangle(i1, i2, i3, sector, cov))
                }
            }
        }

        // Torso + Neck + Head (y from -0.02 to +0.86 around pelvis origin; total height ~1.73m => y in -0.86..+0.86)
        val torsoRings = listOf(
            Triple(-0.08f, 0.145f * hipScale, 0.095f * hipScale), // Pelvis base
            Triple(0.02f, 0.160f * hipScale, 0.105f * hipScale),  // Hip crest
            Triple(0.14f, 0.140f * wScale, 0.095f * wScale),      // Waist
            Triple(0.28f, 0.165f * wScale, 0.112f * wScale),      // Chest
            Triple(0.41f, 0.205f * wScale, 0.105f * wScale),      // Shoulders
            Triple(0.47f, 0.062f, 0.062f),                        // Neck base
            Triple(0.55f, 0.056f, 0.058f),                        // Neck top
            Triple(0.61f, 0.088f, 0.102f),                        // Jaw / Cranium
            Triple(0.71f, 0.092f, 0.108f),                        // Forehead
            Triple(0.80f, 0.055f, 0.065f),                        // Crown
            Triple(0.84f, 0.006f, 0.006f)                         // Vertex tip
        )
        addTube(torsoRings, segments = 18)

        // Arms (Left -X, Right +X, slightly abducted 18 deg)
        fun addLimb(
            points: List<Triple<Vec3, Float, Float>>,
            segments: Int = 10
        ) {
            val baseIdx = vertices.size
            for ((center, rx, rz) in points) {
                for (s in 0 until segments) {
                    val theta = (2.0 * PI * s) / segments
                    vertices.add(
                        Vec3(
                            center.x + rx * sin(theta).toFloat(),
                            center.y * hScale,
                            center.z + rz * cos(theta).toFloat()
                        )
                    )
                }
            }
            for (r in 0 until points.size - 1) {
                for (s in 0 until segments) {
                    val nextS = (s + 1) % segments
                    val i0 = baseIdx + r * segments + s
                    val i1 = baseIdx + r * segments + nextS
                    val i2 = baseIdx + (r + 1) * segments + s
                    val i3 = baseIdx + (r + 1) * segments + nextS
                    val midTheta = (2.0 * PI * (s + 0.5)) / segments
                    val (sector, cov) = statusForSector(midTheta)
                    triangles.add(MeshTriangle(i0, i2, i1, sector, cov))
                    triangles.add(MeshTriangle(i1, i2, i3, sector, cov))
                }
            }
        }

        val shX = 0.21f * wScale
        for (sign in listOf(-1f, 1f)) {
            addLimb(
                listOf(
                    Triple(Vec3(sign * shX, 0.40f, 0f), 0.052f, 0.052f),
                    Triple(Vec3(sign * (shX + 0.05f), 0.26f, 0.01f), 0.044f, 0.044f),
                    Triple(Vec3(sign * (shX + 0.08f), 0.13f, 0.02f), 0.038f, 0.038f),
                    Triple(Vec3(sign * (shX + 0.11f), -0.04f, 0.04f), 0.030f, 0.030f),
                    Triple(Vec3(sign * (shX + 0.12f), -0.10f, 0.04f), 0.022f, 0.016f)
                )
            )
            // Legs
            val hipX = 0.095f * hipScale
            addLimb(
                listOf(
                    Triple(Vec3(sign * hipX, -0.02f, 0f), 0.082f, 0.084f),
                    Triple(Vec3(sign * (hipX + 0.005f), -0.22f, 0.005f), 0.072f, 0.074f),
                    Triple(Vec3(sign * (hipX + 0.008f), -0.43f, 0.01f), 0.054f, 0.056f), // Knee
                    Triple(Vec3(sign * (hipX + 0.010f), -0.58f, -0.005f), 0.056f, 0.058f), // Calf
                    Triple(Vec3(sign * (hipX + 0.012f), -0.80f, 0f), 0.036f, 0.038f), // Ankle
                    Triple(Vec3(sign * (hipX + 0.014f), -0.85f, 0.045f), 0.042f, 0.085f) // Foot
                ),
                segments = 12
            )
        }

        val joints = mapOf(
            AnatomicalLandmark.NOSE to Vec3(0f, 0.70f * hScale, 0.09f),
            AnatomicalLandmark.LEFT_SHOULDER to Vec3(-shX, 0.40f * hScale, 0f),
            AnatomicalLandmark.RIGHT_SHOULDER to Vec3(shX, 0.40f * hScale, 0f),
            AnatomicalLandmark.LEFT_ELBOW to Vec3(-(shX + 0.08f), 0.13f * hScale, 0.02f),
            AnatomicalLandmark.RIGHT_ELBOW to Vec3((shX + 0.08f), 0.13f * hScale, 0.02f),
            AnatomicalLandmark.LEFT_WRIST to Vec3(-(shX + 0.11f), -0.04f * hScale, 0.04f),
            AnatomicalLandmark.RIGHT_WRIST to Vec3((shX + 0.11f), -0.04f * hScale, 0.04f),
            AnatomicalLandmark.LEFT_HIP to Vec3(-0.095f * hipScale, 0.0f, 0f),
            AnatomicalLandmark.RIGHT_HIP to Vec3(0.095f * hipScale, 0.0f, 0f),
            AnatomicalLandmark.LEFT_KNEE to Vec3(-0.103f * hipScale, -0.43f * hScale, 0.01f),
            AnatomicalLandmark.RIGHT_KNEE to Vec3(0.103f * hipScale, -0.43f * hScale, 0.01f),
            AnatomicalLandmark.LEFT_ANKLE to Vec3(-0.107f * hipScale, -0.80f * hScale, 0f),
            AnatomicalLandmark.RIGHT_ANKLE to Vec3(0.107f * hipScale, -0.80f * hScale, 0f)
        )

        val overlays = mutableListOf<MeasurementOverlay3D>()
        if (session.calibration.isScaleVerified) {
            overlays.add(
                MeasurementOverlay3D(
                    label = "Stature",
                    valueFormatted = String.format("%.1f cm", statureMm / 10.0),
                    start = Vec3(-0.34f, -0.85f * hScale, 0f),
                    end = Vec3(-0.34f, 0.84f * hScale, 0f)
                )
            )
            overlays.add(
                MeasurementOverlay3D(
                    label = "Shoulders",
                    valueFormatted = String.format("%.1f cm", shoulderMm / 10.0),
                    start = Vec3(-shX, 0.45f * hScale, 0f),
                    end = Vec3(shX, 0.45f * hScale, 0f)
                )
            )
            overlays.add(
                MeasurementOverlay3D(
                    label = "Torso",
                    valueFormatted = String.format("%.1f cm", (statureMm * 0.285) / 10.0),
                    start = Vec3(0.28f, 0.0f, 0f),
                    end = Vec3(0.28f, 0.40f * hScale, 0f)
                )
            )
        }

        val coveragePct = ((covered.size.toFloat() / CaptureAngle.entries.size.toFloat()) * 100f).toInt()
        return BodyMeshModel(
            sessionId = session.id,
            vertices = vertices,
            triangles = triangles,
            skeletonJoints = joints,
            measurementOverlays = overlays,
            provenanceType = session.modelProvenance,
            heightMeters = (statureMm / 1000.0).toFloat(),
            observedCoveragePercent = coveragePct.coerceIn(0, 100)
        )
    }
}
