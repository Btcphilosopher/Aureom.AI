package com.example.domain.math

import com.example.domain.model.CalibrationProvenance
import com.example.domain.model.CalibrationSource
import com.example.domain.model.ImagePointPx
import com.example.domain.model.MetricMeasurementMm
import com.example.domain.model.RelativePosePoint
import kotlin.math.hypot
import kotlin.math.sqrt

/**
 * Separates raw image pixels, normalized pose coordinates, and calibrated physical millimeters.
 * Explicitly blocks physical metric output when calibration source is NONE.
 */
object CalibrationSolver {
    const val A4_HEIGHT_MM = 297.0
    const val A4_WIDTH_MM = 210.0
    const val ARUCO_150_MM = 150.0

    fun solveFromReferenceSpan(
        source: CalibrationSource,
        referencePixelSpan: Double,
        referencePhysicalMm: Double,
        referenceTolerancePercent: Double = 1.5,
        estimatedCameraDistanceMeters: Double? = null
    ): CalibrationProvenance {
        if (!source.isAbsoluteScaleSupported || referencePixelSpan <= 0.0 || referencePhysicalMm <= 0.0) {
            return uncalibrated(
                warning = "Missing or invalid scale reference. Absolute dimensions are blocked."
            )
        }
        val mmPerPx = referencePhysicalMm / referencePixelSpan
        return CalibrationProvenance(
            source = source,
            scaleMmPerPx = mmPerPx,
            referencePixelSpan = referencePixelSpan,
            referencePhysicalMm = referencePhysicalMm,
            uncertaintyPercent = referenceTolerancePercent,
            cameraDistanceEstimateMeters = estimatedCameraDistanceMeters,
            isScaleVerified = true,
            warningMessage = null
        )
    }

    fun solveFromUserHeight(
        userHeightMm: Double,
        pixelCrownToAnkleSpan: Double,
        estimatedCameraDistanceMeters: Double? = 2.2
    ): CalibrationProvenance {
        if (userHeightMm !in 900.0..2400.0 || pixelCrownToAnkleSpan <= 20.0) {
            return uncalibrated(
                warning = "User stature reference requires valid height (90–240 cm) and full-body pose visibility."
            )
        }
        // User-entered stature proxy carries higher uncertainty (~2.8%) due to head-top offset from eye/ear landmarks.
        return solveFromReferenceSpan(
            source = CalibrationSource.USER_HEIGHT_REFERENCE,
            referencePixelSpan = pixelCrownToAnkleSpan,
            referencePhysicalMm = userHeightMm,
            referenceTolerancePercent = 2.8,
            estimatedCameraDistanceMeters = estimatedCameraDistanceMeters
        )
    }

    fun uncalibrated(
        warning: String = "Uncalibrated photograph: pixel & normalized coordinates only."
    ): CalibrationProvenance = CalibrationProvenance(
        source = CalibrationSource.NONE,
        scaleMmPerPx = null,
        referencePixelSpan = null,
        referencePhysicalMm = null,
        uncertaintyPercent = null,
        cameraDistanceEstimateMeters = null,
        isScaleVerified = false,
        warningMessage = warning
    )

    fun imagePxToNormalized(point: ImagePointPx): Pair<Float, Float> {
        val w = point.imageWidthPx.coerceAtLeast(1).toFloat()
        val h = point.imageHeightPx.coerceAtLeast(1).toFloat()
        return (point.xPx / w).coerceIn(0f, 1f) to (point.yPx / h).coerceIn(0f, 1f)
    }

    fun normalizedToImagePx(
        posePoint: RelativePosePoint,
        imageWidthPx: Int,
        imageHeightPx: Int
    ): ImagePointPx = ImagePointPx(
        xPx = posePoint.xNorm * imageWidthPx,
        yPx = posePoint.yNorm * imageHeightPx,
        imageWidthPx = imageWidthPx,
        imageHeightPx = imageHeightPx,
        confidence = posePoint.visibility
    )

    /**
     * Computes physical distance in millimeters between two normalized pose landmarks,
     * returning null if calibration is missing or invalid.
     */
    fun measureNormalizedDistanceMm(
        a: RelativePosePoint,
        b: RelativePosePoint,
        imageWidthPx: Int,
        imageHeightPx: Int,
        calibration: CalibrationProvenance,
        pixelLocalizationSigmaPx: Double = 3.5,
        perspectiveForeshorteningPercent: Double = 1.2
    ): MetricMeasurementMm? {
        val scale = calibration.scaleMmPerPx
        if (!calibration.isScaleVerified || !calibration.source.isAbsoluteScaleSupported || scale == null || scale <= 0.0) {
            return null
        }

        val dxPx = (a.xNorm - b.xNorm) * imageWidthPx.toDouble()
        val dyPx = (a.yNorm - b.yNorm) * imageHeightPx.toDouble()
        val distPx = hypot(dxPx, dyPx)
        val valueMm = distPx * scale

        val refPct = calibration.uncertaintyPercent ?: 2.0
        val sigmaRefMm = valueMm * (refPct / 100.0)
        val sigmaPerspectiveMm = valueMm * (perspectiveForeshorteningPercent / 100.0)
        val sigmaPixelMm = pixelLocalizationSigmaPx * scale * sqrt(2.0)
        val confidencePenalty = if (minOf(a.visibility, b.visibility) < 0.7f) 1.5 else 1.0

        val totalUncertaintyMm = sqrt(
            sigmaRefMm * sigmaRefMm +
                sigmaPerspectiveMm * sigmaPerspectiveMm +
                sigmaPixelMm * sigmaPixelMm
        ) * confidencePenalty

        return MetricMeasurementMm(
            valueMm = valueMm,
            uncertaintyMm = totalUncertaintyMm,
            calibrationSource = calibration.source
        )
    }
}
