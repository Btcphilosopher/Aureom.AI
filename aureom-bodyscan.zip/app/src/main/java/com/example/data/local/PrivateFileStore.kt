package com.example.data.local

import android.content.Context
import android.graphics.Bitmap
import com.example.domain.model.ScanSession
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Manages app-private storage for captured body imagery, exports, and snapshot files.
 * Files live exclusively inside context.filesDir (never written to public MediaStore).
 */
class PrivateFileStore(private val context: Context) {

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    private val scansRootDir: File
        get() = File(context.filesDir, "private_scans").apply { mkdirs() }

    private val exportsDir: File
        get() = File(context.filesDir, "exports").apply { mkdirs() }

    private val snapshotsCacheDir: File
        get() = File(context.cacheDir, "snapshots").apply { mkdirs() }

    fun createTargetImageFile(sessionId: String, angleKey: String): File {
        val safeSession = sanitizeSegment(sessionId)
        val safeAngle = sanitizeSegment(angleKey)
        val sessionDir = File(scansRootDir, safeSession).apply { mkdirs() }
        return File(sessionDir, "${safeAngle}_${System.currentTimeMillis()}.jpg")
    }

    fun writeBitmapCapture(sessionId: String, angleKey: String, bitmap: Bitmap): File {
        val outFile = createTargetImageFile(sessionId, angleKey)
        outFile.outputStream().use { stream ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, stream)
        }
        return outFile
    }

    fun listSessionFiles(sessionId: String): List<File> {
        val dir = File(scansRootDir, sanitizeSegment(sessionId))
        if (!dir.exists() || !dir.isDirectory) return emptyList()
        return dir.listFiles()?.toList() ?: emptyList()
    }

    fun deleteFileAtPath(path: String?): Boolean {
        if (path.isNullOrBlank()) return false
        val target = File(path).canonicalFile
        val rootCanonical = scansRootDir.canonicalFile
        if (!target.path.startsWith(rootCanonical.path + File.separator)) return false
        return if (target.exists()) target.delete() else false
    }

    fun deleteSessionFiles(sessionId: String): Boolean {
        val sessionDir = File(scansRootDir, sanitizeSegment(sessionId))
        val exportFile = File(exportsDir, "aureom_session_${sanitizeSegment(sessionId)}.json")
        if (exportFile.exists()) exportFile.delete()
        return if (sessionDir.exists()) sessionDir.deleteRecursively() else true
    }

    fun exportSessionJson(session: ScanSession): File {
        val safeId = sanitizeSegment(session.id)
        val outFile = File(exportsDir, "aureom_session_${safeId}.json")
        outFile.writeText(json.encodeToString(session))
        return outFile
    }

    fun saveViewSnapshotPng(sessionId: String, bitmap: Bitmap): File {
        val safeId = sanitizeSegment(sessionId)
        val outFile = File(snapshotsCacheDir, "aureom_view_${safeId}_${System.currentTimeMillis()}.png")
        outFile.outputStream().use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        }
        return outFile
    }

    fun totalPrivateStorageBytes(): Long {
        val scansBytes = scansRootDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        val exportsBytes = exportsDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        return scansBytes + exportsBytes
    }

    fun purgeAllPrivateFiles() {
        if (scansRootDir.exists()) scansRootDir.deleteRecursively()
        if (exportsDir.exists()) exportsDir.deleteRecursively()
        if (snapshotsCacheDir.exists()) snapshotsCacheDir.deleteRecursively()
    }

    private fun sanitizeSegment(raw: String): String =
        raw.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(64)
}
