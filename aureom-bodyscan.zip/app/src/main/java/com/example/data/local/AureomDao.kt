package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface AureomDao {

    @Query("SELECT * FROM scan_sessions ORDER BY createdAtMs DESC")
    fun observeAllSessions(): Flow<List<ScanSessionEntity>>

    @Query("SELECT * FROM scan_sessions WHERE id = :sessionId")
    suspend fun getSessionById(sessionId: String): ScanSessionEntity?

    @Query("SELECT * FROM captured_frames ORDER BY capturedAtMs ASC")
    fun observeAllFrames(): Flow<List<CapturedFrameEntity>>

    @Query("SELECT * FROM captured_frames WHERE sessionId = :sessionId")
    suspend fun getFramesForSession(sessionId: String): List<CapturedFrameEntity>

    @Query("SELECT * FROM measurement_records ORDER BY captureTimestampMs DESC")
    fun observeAllMeasurements(): Flow<List<MeasurementRecordEntity>>

    @Query("SELECT * FROM measurement_records WHERE sessionId = :sessionId")
    suspend fun getMeasurementsForSession(sessionId: String): List<MeasurementRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: ScanSessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFrames(frames: List<CapturedFrameEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurements(measurements: List<MeasurementRecordEntity>)

    @Transaction
    suspend fun saveFullSession(
        session: ScanSessionEntity,
        frames: List<CapturedFrameEntity>,
        measurements: List<MeasurementRecordEntity>
    ) {
        insertSession(session)
        if (frames.isNotEmpty()) insertFrames(frames)
        if (measurements.isNotEmpty()) insertMeasurements(measurements)
    }

    @Query("UPDATE scan_sessions SET personalNotes = :notes WHERE id = :sessionId")
    suspend fun updateSessionNotes(sessionId: String, notes: String)

    @Query("DELETE FROM scan_sessions WHERE id = :sessionId")
    suspend fun deleteSessionById(sessionId: String)

    @Query("DELETE FROM scan_sessions WHERE createdAtMs < :cutoffMs AND isDemoFixture = 0")
    suspend fun deleteNonDemoSessionsOlderThan(cutoffMs: Long)

    @Query("SELECT id FROM scan_sessions WHERE createdAtMs < :cutoffMs AND isDemoFixture = 0")
    suspend fun getExpiredSessionIds(cutoffMs: Long): List<String>

    @Query("DELETE FROM scan_sessions")
    suspend fun deleteAllSessions()

    @Query("SELECT * FROM force_trials ORDER BY recordedAtMs DESC")
    fun observeAllForceTrials(): Flow<List<ForceTrialEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForceTrial(trial: ForceTrialEntity)

    @Query("DELETE FROM force_trials WHERE id = :trialId")
    suspend fun deleteForceTrialById(trialId: String)

    @Query("DELETE FROM force_trials")
    suspend fun deleteAllForceTrials()

    @Query("SELECT * FROM movement_sequences ORDER BY captureDateMs DESC")
    fun observeAllMovementSequences(): Flow<List<MovementSequenceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovementSequence(seq: MovementSequenceEntity)

    @Query("DELETE FROM movement_sequences WHERE id = :id")
    suspend fun deleteMovementSequenceById(id: String)

    @Query("DELETE FROM movement_sequences")
    suspend fun deleteAllMovementSequences()

    @Query("SELECT * FROM audit_events ORDER BY timestampMs DESC LIMIT 50")
    fun observeAuditEvents(): Flow<List<AuditEventEntity>>

    @Insert
    suspend fun insertAuditEvent(event: AuditEventEntity)

    @Query("DELETE FROM audit_events")
    suspend fun deleteAllAuditEvents()
}
