package com.example.data.repository

import com.example.adapters.FastApiReconstructionClient
import com.example.data.local.AuditEventEntity
import com.example.data.local.AureomDao
import com.example.data.local.CapturedFrameEntity
import com.example.data.local.ForceTrialEntity
import com.example.data.local.MeasurementRecordEntity
import com.example.data.local.MovementSequenceEntity
import com.example.data.local.PrivateFileStore
import com.example.data.local.ScanSessionEntity
import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.BodyMeasurementRecord
import com.example.domain.model.CalibrationProvenance
import com.example.domain.model.CalibrationSource
import com.example.domain.model.CaptureAngle
import com.example.domain.model.CaptureMode
import com.example.domain.model.CapturedFrameInfo
import com.example.domain.model.CoordinateSystemType
import com.example.domain.model.ForceSamplePoint
import com.example.domain.model.ForceSensorTrial
import com.example.domain.model.ForceUnit
import com.example.domain.model.MeasurementCategory
import com.example.domain.model.MeasurementQualityStatus
import com.example.domain.model.MeasurementSource
import com.example.domain.model.ModelProvenanceType
import com.example.domain.model.MovementSequence
import com.example.domain.model.PoseFrameSample
import com.example.domain.model.QualityIssueType
import com.example.domain.model.RelativePosePoint
import com.example.domain.model.ScanSession
import com.example.domain.model.SessionProcessingState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

class ScanRepository(
    private val dao: AureomDao,
    private val fileStore: PrivateFileStore,
    private val reconstructionClient: FastApiReconstructionClient = FastApiReconstructionClient()
) {
    private val json = Json { ignoreUnknownKeys = true }

    val sessionsFlow: Flow<List<ScanSession>> = combine(
        dao.observeAllSessions(),
        dao.observeAllFrames(),
        dao.observeAllMeasurements()
    ) { sessionRows, frameRows, measurementRows ->
        val framesBySession = frameRows.groupBy { it.sessionId }
        val measurementsBySession = measurementRows.groupBy { it.sessionId }
        sessionRows.map { s ->
            entityToSession(
                entity = s,
                frames = framesBySession[s.id].orEmpty(),
                measurements = measurementsBySession[s.id].orEmpty()
            )
        }
    }

    val forceTrialsFlow: Flow<List<ForceSensorTrial>> = dao.observeAllForceTrials().map { list ->
        list.map { entityToForceTrial(it) }
    }

    val movementSequencesFlow: Flow<List<MovementSequence>> = dao.observeAllMovementSequences().map { list ->
        list.map { entityToMovementSequence(it) }
    }

    val auditEventsFlow: Flow<List<AuditEventEntity>> = dao.observeAuditEvents()

    suspend fun ensureDemoFixturesSeeded() {
        val existing = dao.observeAllSessions().first()
        if (existing.isEmpty()) {
            seedAllDemoFixtures()
        }
    }

    suspend fun seedAllDemoFixtures() {
        val demoSessions = DemoFixturesFactory.buildDemoSessions()
        for (session in demoSessions) {
            saveSession(session, logAudit = false)
        }
        saveMovementSequence(DemoFixturesFactory.buildDemoMovementSequence())
        saveForceTrial(DemoFixturesFactory.buildDemoForceTrial())
        logAudit("DEMO_SEEDED", "Loaded 9 reproducible demonstration fixtures.")
    }

    suspend fun saveSession(session: ScanSession, logAudit: Boolean = true) {
        val entity = sessionToEntity(session)
        val frameEntities = session.frames.map { frameToEntity(it, session.id) }
        val measurementEntities = session.measurements.map { measurementToEntity(it, session.id) }
        dao.saveFullSession(entity, frameEntities, measurementEntities)
        if (logAudit) {
            logAudit("SESSION_SAVED", "Saved '${session.title}' (${session.captureMode.title}).")
        }
    }

    suspend fun updateSessionNotes(sessionId: String, notes: String) {
        dao.updateSessionNotes(sessionId, notes)
    }

    suspend fun saveForceTrial(trial: ForceSensorTrial) {
        dao.insertForceTrial(
            ForceTrialEntity(
                id = trial.id,
                sensorId = trial.sensorId,
                sensorName = trial.sensorName,
                isSimulated = trial.isSimulated,
                calibrationDateIso = trial.calibrationDateIso,
                nativeUnit = trial.nativeUnit.name,
                samplingRateHz = trial.samplingRateHz,
                exerciseSetup = trial.exerciseSetup,
                trialDurationSec = trial.trialDurationSec,
                samplesJson = json.encodeToString(trial.samples),
                peakForceNewtons = trial.peakForceNewtons,
                meanForceNewtons = trial.meanForceNewtons,
                missingSampleCount = trial.missingSampleCount,
                overloadCount = trial.overloadCount,
                recordedAtMs = trial.recordedAtMs
            )
        )
        logAudit("FORCE_TRIAL_SAVED", "Recorded ${trial.sensorName} (${trial.samples.size} samples).")
    }

    suspend fun saveMovementSequence(seq: MovementSequence) {
        dao.insertMovementSequence(
            MovementSequenceEntity(
                id = seq.id,
                title = seq.title,
                captureDateMs = seq.captureDateMs,
                viewpoint = seq.viewpoint.name,
                fps = seq.fps,
                framesJson = json.encodeToString(seq.frames),
                isSyntheticDemo = seq.isSyntheticDemo,
                provenanceNote = seq.provenanceNote
            )
        )
    }

    /**
     * Deletes a session, its cascaded frames & measurement records, its app-private files,
     * and optionally any remote backend job if endpoint & token are configured.
     */
    suspend fun deleteSessionCompletely(
        sessionId: String,
        endpointUrl: String = "",
        bearerToken: String? = null
    ) {
        val existing = dao.getSessionById(sessionId)
        val frames = dao.getFramesForSession(sessionId)
        frames.forEach { frame ->
            fileStore.deleteFileAtPath(frame.localFilePath)
        }
        fileStore.deleteSessionFiles(sessionId)
        dao.deleteSessionById(sessionId)

        val remoteJob = existing?.backendJobId
        if (!remoteJob.isNullOrBlank() && endpointUrl.isNotBlank()) {
            reconstructionClient.deleteRemoteJob(remoteJob, endpointUrl, bearerToken)
        }
        logAudit("SESSION_DELETED", "Deleted session '$sessionId' and all derived local files.")
    }

    suspend fun deleteForceTrial(trialId: String) {
        dao.deleteForceTrialById(trialId)
    }

    suspend fun enforceRetentionPolicy(retentionDays: Int): Int {
        if (retentionDays <= 0) return 0
        val cutoffMs = System.currentTimeMillis() - (retentionDays * 24L * 60L * 60L * 1000L)
        val expiredIds = dao.getExpiredSessionIds(cutoffMs)
        expiredIds.forEach { fileStore.deleteSessionFiles(it) }
        dao.deleteNonDemoSessionsOlderThan(cutoffMs)
        if (expiredIds.isNotEmpty()) {
            logAudit("RETENTION_PURGE", "Purged ${expiredIds.size} expired non-demo session(s) > $retentionDays days.")
        }
        return expiredIds.size
    }

    suspend fun purgeAllUserAndDemoData() {
        dao.deleteAllSessions()
        dao.deleteAllForceTrials()
        dao.deleteAllMovementSequences()
        dao.deleteAllAuditEvents()
        fileStore.purgeAllPrivateFiles()
        logAudit("FULL_WIPE", "Deleted all local sessions, measurements, models, and private captures.")
    }

    fun exportSessionProvenanceFile(session: ScanSession): File {
        return fileStore.exportSessionJson(session)
    }

    private suspend fun logAudit(type: String, summary: String) {
        dao.insertAuditEvent(
            AuditEventEntity(
                timestampMs = System.currentTimeMillis(),
                eventType = type,
                summary = summary
            )
        )
    }

    private fun sessionToEntity(s: ScanSession): ScanSessionEntity = ScanSessionEntity(
        id = s.id,
        title = s.title,
        createdAtMs = s.createdAtMs,
        captureMode = s.captureMode.name,
        processingState = s.processingState.name,
        calibrationJson = json.encodeToString(s.calibration),
        modelProvenance = s.modelProvenance.name,
        coveredSectorsCsv = s.coveredSectors.joinToString(",") { it.name },
        equipmentDescription = s.equipmentDescription,
        environmentConditions = s.environmentConditions,
        personalNotes = s.personalNotes,
        isDemoFixture = s.isDemoFixture,
        demoScenarioTag = s.demoScenarioTag,
        backendJobId = s.backendJobId
    )

    private fun frameToEntity(f: CapturedFrameInfo, parentSessionId: String = f.sessionId): CapturedFrameEntity = CapturedFrameEntity(
        id = f.id,
        sessionId = parentSessionId,
        angle = f.angle.name,
        localFilePath = f.localFilePath,
        capturedAtMs = f.capturedAtMs,
        imageWidthPx = f.imageWidthPx,
        imageHeightPx = f.imageHeightPx,
        meanLuma = f.meanLuma,
        motionStabilityScore = f.motionStabilityScore,
        landmarksJson = json.encodeToString(f.landmarks),
        occludedLandmarksCsv = f.occludedLandmarks.joinToString(",") { it.name },
        qualityIssuesCsv = f.qualityIssues.joinToString(",") { it.name },
        isSynthetic = f.isSynthetic
    )

    private fun measurementToEntity(m: BodyMeasurementRecord, parentSessionId: String = m.sessionId): MeasurementRecordEntity = MeasurementRecordEntity(
        id = m.id,
        sessionId = parentSessionId,
        metricKey = m.metricKey,
        label = m.label,
        definition = m.definition,
        category = m.category.name,
        valueMm = m.valueMm,
        uncertaintyMm = m.uncertaintyMm,
        sourceMethod = m.sourceMethod.name,
        calibrationSource = m.calibrationSource.name,
        qualityStatus = m.qualityStatus.name,
        coordinateOrigin = m.coordinateOrigin.name,
        captureTimestampMs = m.captureTimestampMs,
        notes = m.notes
    )

    private fun entityToSession(
        entity: ScanSessionEntity,
        frames: List<CapturedFrameEntity>,
        measurements: List<MeasurementRecordEntity>
    ): ScanSession {
        val cal = runCatching {
            json.decodeFromString<CalibrationProvenance>(entity.calibrationJson)
        }.getOrElse {
            CalibrationProvenance(CalibrationSource.NONE, null, null, null, null, null, false)
        }
        val sectors = entity.coveredSectorsCsv
            .split(",")
            .filter { it.isNotBlank() }
            .mapNotNull { runCatching { CaptureAngle.valueOf(it) }.getOrNull() }
            .toSet()

        return ScanSession(
            id = entity.id,
            title = entity.title,
            createdAtMs = entity.createdAtMs,
            captureMode = CaptureMode.valueOf(entity.captureMode),
            processingState = SessionProcessingState.valueOf(entity.processingState),
            calibration = cal,
            frames = frames.map { entityToFrame(it) },
            measurements = measurements.map { entityToMeasurement(it) },
            modelProvenance = ModelProvenanceType.valueOf(entity.modelProvenance),
            coveredSectors = sectors,
            equipmentDescription = entity.equipmentDescription,
            environmentConditions = entity.environmentConditions,
            personalNotes = entity.personalNotes,
            isDemoFixture = entity.isDemoFixture,
            demoScenarioTag = entity.demoScenarioTag,
            backendJobId = entity.backendJobId
        )
    }

    private fun entityToFrame(e: CapturedFrameEntity): CapturedFrameInfo {
        val landmarks = runCatching {
            json.decodeFromString<List<RelativePosePoint>>(e.landmarksJson)
        }.getOrDefault(emptyList())
        val occluded = e.occludedLandmarksCsv.split(",")
            .filter { it.isNotBlank() }
            .mapNotNull { runCatching { AnatomicalLandmark.valueOf(it) }.getOrNull() }
        val issues = e.qualityIssuesCsv.split(",")
            .filter { it.isNotBlank() }
            .mapNotNull { runCatching { QualityIssueType.valueOf(it) }.getOrNull() }

        return CapturedFrameInfo(
            id = e.id,
            sessionId = e.sessionId,
            angle = CaptureAngle.valueOf(e.angle),
            localFilePath = e.localFilePath,
            capturedAtMs = e.capturedAtMs,
            imageWidthPx = e.imageWidthPx,
            imageHeightPx = e.imageHeightPx,
            meanLuma = e.meanLuma,
            motionStabilityScore = e.motionStabilityScore,
            landmarks = landmarks,
            occludedLandmarks = occluded,
            qualityIssues = issues,
            isSynthetic = e.isSynthetic
        )
    }

    private fun entityToMeasurement(e: MeasurementRecordEntity): BodyMeasurementRecord = BodyMeasurementRecord(
        id = e.id,
        sessionId = e.sessionId,
        metricKey = e.metricKey,
        label = e.label,
        definition = e.definition,
        category = MeasurementCategory.valueOf(e.category),
        valueMm = e.valueMm,
        uncertaintyMm = e.uncertaintyMm,
        sourceMethod = MeasurementSource.valueOf(e.sourceMethod),
        calibrationSource = CalibrationSource.valueOf(e.calibrationSource),
        qualityStatus = MeasurementQualityStatus.valueOf(e.qualityStatus),
        coordinateOrigin = CoordinateSystemType.valueOf(e.coordinateOrigin),
        captureTimestampMs = e.captureTimestampMs,
        notes = e.notes
    )

    private fun entityToForceTrial(e: ForceTrialEntity): ForceSensorTrial {
        val samples = runCatching {
            json.decodeFromString<List<ForceSamplePoint>>(e.samplesJson)
        }.getOrDefault(emptyList())
        return ForceSensorTrial(
            id = e.id,
            sensorId = e.sensorId,
            sensorName = e.sensorName,
            isSimulated = e.isSimulated,
            calibrationDateIso = e.calibrationDateIso,
            nativeUnit = ForceUnit.valueOf(e.nativeUnit),
            samplingRateHz = e.samplingRateHz,
            exerciseSetup = e.exerciseSetup,
            trialDurationSec = e.trialDurationSec,
            samples = samples,
            peakForceNewtons = e.peakForceNewtons,
            meanForceNewtons = e.meanForceNewtons,
            missingSampleCount = e.missingSampleCount,
            overloadCount = e.overloadCount,
            recordedAtMs = e.recordedAtMs
        )
    }

    private fun entityToMovementSequence(e: MovementSequenceEntity): MovementSequence {
        val frames = runCatching {
            json.decodeFromString<List<PoseFrameSample>>(e.framesJson)
        }.getOrDefault(emptyList())
        return MovementSequence(
            id = e.id,
            title = e.title,
            captureDateMs = e.captureDateMs,
            viewpoint = CaptureAngle.valueOf(e.viewpoint),
            fps = e.fps,
            frames = frames,
            isSyntheticDemo = e.isSyntheticDemo,
            provenanceNote = e.provenanceNote
        )
    }
}
