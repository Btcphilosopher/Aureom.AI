package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "scan_sessions")
data class ScanSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdAtMs: Long,
    val captureMode: String,
    val processingState: String,
    val calibrationJson: String,
    val modelProvenance: String,
    val coveredSectorsCsv: String,
    val equipmentDescription: String,
    val environmentConditions: String,
    val personalNotes: String,
    val isDemoFixture: Boolean,
    val demoScenarioTag: String?,
    val backendJobId: String?
)

@Entity(
    tableName = "captured_frames",
    foreignKeys = [
        ForeignKey(
            entity = ScanSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class CapturedFrameEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val angle: String,
    val localFilePath: String?,
    val capturedAtMs: Long,
    val imageWidthPx: Int,
    val imageHeightPx: Int,
    val meanLuma: Float,
    val motionStabilityScore: Float,
    val landmarksJson: String,
    val occludedLandmarksCsv: String,
    val qualityIssuesCsv: String,
    val isSynthetic: Boolean
)

@Entity(
    tableName = "measurement_records",
    foreignKeys = [
        ForeignKey(
            entity = ScanSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class MeasurementRecordEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val metricKey: String,
    val label: String,
    val definition: String,
    val category: String,
    val valueMm: Double?,
    val uncertaintyMm: Double?,
    val sourceMethod: String,
    val calibrationSource: String,
    val qualityStatus: String,
    val coordinateOrigin: String,
    val captureTimestampMs: Long,
    val notes: String
)

@Entity(tableName = "force_trials")
data class ForceTrialEntity(
    @PrimaryKey val id: String,
    val sensorId: String,
    val sensorName: String,
    val isSimulated: Boolean,
    val calibrationDateIso: String,
    val nativeUnit: String,
    val samplingRateHz: Int,
    val exerciseSetup: String,
    val trialDurationSec: Double,
    val samplesJson: String,
    val peakForceNewtons: Double,
    val meanForceNewtons: Double,
    val missingSampleCount: Int,
    val overloadCount: Int,
    val recordedAtMs: Long
)

@Entity(tableName = "movement_sequences")
data class MovementSequenceEntity(
    @PrimaryKey val id: String,
    val title: String,
    val captureDateMs: Long,
    val viewpoint: String,
    val fps: Float,
    val framesJson: String,
    val isSyntheticDemo: Boolean,
    val provenanceNote: String
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMs: Long,
    val eventType: String,
    val summary: String
)
