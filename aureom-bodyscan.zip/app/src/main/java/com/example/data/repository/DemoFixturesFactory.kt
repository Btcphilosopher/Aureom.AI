package com.example.data.repository

import com.example.adapters.DiscoveredForceDevice
import com.example.adapters.SimulatedForceSensorAdapter
import com.example.domain.math.CalibrationSolver
import com.example.domain.math.GeometryMath
import com.example.domain.model.AnatomicalLandmark
import com.example.domain.model.BodyMeasurementRecord
import com.example.domain.model.CalibrationSource
import com.example.domain.model.CaptureAngle
import com.example.domain.model.CaptureMode
import com.example.domain.model.CapturedFrameInfo
import com.example.domain.model.CoordinateSystemType
import com.example.domain.model.ForceSamplePoint
import com.example.domain.model.ForceSensorTrial
import com.example.domain.model.MeasurementCategory
import com.example.domain.model.MeasurementQualityStatus
import com.example.domain.model.MeasurementSource
import com.example.domain.model.ModelProvenanceType
import com.example.domain.model.MovementSequence
import com.example.domain.model.PoseFrameSample
import com.example.domain.model.QualityIssueType
import com.example.domain.model.RelativePosePoint
import com.example.domain.model.ScanSession
import com.example.domain.model.SessionProcessingState
import kotlin.math.PI
import kotlin.math.sin

object DemoFixturesFactory {

    private const val BASE_TIME_MS = 1763800000000L

    fun standardStandingLandmarks(
        shoulderTiltOffset: Float = 0.004f,
        hipTiltOffset: Float = -0.002f,
        occludeRightAnkle: Boolean = false
    ): List<RelativePosePoint> {
        val pts = listOf(
            RelativePosePoint(AnatomicalLandmark.NOSE, 0.500f, 0.140f, -0.05f, 0.98f, 0.98f),
            RelativePosePoint(AnatomicalLandmark.LEFT_EYE, 0.486f, 0.125f, -0.04f, 0.97f, 0.97f),
            RelativePosePoint(AnatomicalLandmark.RIGHT_EYE, 0.514f, 0.125f, -0.04f, 0.97f, 0.97f),
            RelativePosePoint(AnatomicalLandmark.LEFT_EAR, 0.468f, 0.132f, 0.01f, 0.91f, 0.91f),
            RelativePosePoint(AnatomicalLandmark.RIGHT_EAR, 0.532f, 0.132f, 0.01f, 0.91f, 0.91f),
            RelativePosePoint(AnatomicalLandmark.LEFT_SHOULDER, 0.395f, 0.240f + shoulderTiltOffset, 0.00f, 0.97f, 0.97f),
            RelativePosePoint(AnatomicalLandmark.RIGHT_SHOULDER, 0.605f, 0.240f - shoulderTiltOffset, 0.00f, 0.96f, 0.96f),
            RelativePosePoint(AnatomicalLandmark.LEFT_ELBOW, 0.345f, 0.372f, 0.01f, 0.94f, 0.94f),
            RelativePosePoint(AnatomicalLandmark.RIGHT_ELBOW, 0.655f, 0.370f, 0.01f, 0.94f, 0.94f),
            RelativePosePoint(AnatomicalLandmark.LEFT_WRIST, 0.320f, 0.498f, -0.02f, 0.92f, 0.92f),
            RelativePosePoint(AnatomicalLandmark.RIGHT_WRIST, 0.680f, 0.495f, -0.02f, 0.92f, 0.92f),
            RelativePosePoint(AnatomicalLandmark.LEFT_HIP, 0.440f, 0.495f + hipTiltOffset, 0.00f, 0.96f, 0.96f),
            RelativePosePoint(AnatomicalLandmark.RIGHT_HIP, 0.560f, 0.495f - hipTiltOffset, 0.00f, 0.96f, 0.96f),
            RelativePosePoint(AnatomicalLandmark.LEFT_KNEE, 0.436f, 0.692f, -0.01f, 0.95f, 0.95f),
            RelativePosePoint(AnatomicalLandmark.RIGHT_KNEE, 0.564f, 0.692f, -0.01f, 0.95f, 0.95f),
            RelativePosePoint(AnatomicalLandmark.LEFT_ANKLE, 0.432f, 0.875f, 0.00f, 0.93f, 0.93f),
            RelativePosePoint(
                AnatomicalLandmark.RIGHT_ANKLE,
                0.568f,
                0.875f,
                0.00f,
                if (occludeRightAnkle) 0.24f else 0.93f,
                if (occludeRightAnkle) 0.24f else 0.93f
            ),
            RelativePosePoint(AnatomicalLandmark.LEFT_HEEL, 0.428f, 0.902f, 0.02f, 0.90f, 0.90f),
            RelativePosePoint(
                AnatomicalLandmark.RIGHT_HEEL,
                0.572f,
                0.902f,
                0.02f,
                if (occludeRightAnkle) 0.20f else 0.90f,
                if (occludeRightAnkle) 0.20f else 0.90f
            )
        )
        return pts
    }

    fun buildDemoSessions(): List<ScanSession> {
        val imgW = 1080
        val imgH = 1920
        // Scale so 0.802 * 1920 px = 1540 px ~ 1735 mm => ~1.126 mm/px; A4 card height 297mm = ~264 px
        val a4Calibration = CalibrationSolver.solveFromReferenceSpan(
            source = CalibrationSource.A4_REFERENCE_CARD,
            referencePixelSpan = 264.0,
            referencePhysicalMm = CalibrationSolver.A4_HEIGHT_MM,
            referenceTolerancePercent = 1.4,
            estimatedCameraDistanceMeters = 2.25
        )

        // Fixture 1: Calibrated Guided Capture
        val f1Id = "demo_calibrated_capture"
        val f1Frames = listOf(
            CapturedFrameInfo(
                id = "${f1Id}_front",
                sessionId = f1Id,
                angle = CaptureAngle.FRONT,
                localFilePath = null,
                capturedAtMs = BASE_TIME_MS + 10_000,
                imageWidthPx = imgW,
                imageHeightPx = imgH,
                meanLuma = 148f,
                motionStabilityScore = 0.97f,
                landmarks = standardStandingLandmarks(),
                occludedLandmarks = emptyList(),
                qualityIssues = emptyList(),
                isSynthetic = true
            ),
            CapturedFrameInfo(
                id = "${f1Id}_side",
                sessionId = f1Id,
                angle = CaptureAngle.SIDE_LEFT,
                localFilePath = null,
                capturedAtMs = BASE_TIME_MS + 25_000,
                imageWidthPx = imgW,
                imageHeightPx = imgH,
                meanLuma = 144f,
                motionStabilityScore = 0.95f,
                landmarks = standardStandingLandmarks(shoulderTiltOffset = 0f, hipTiltOffset = 0f),
                occludedLandmarks = emptyList(),
                qualityIssues = emptyList(),
                isSynthetic = true
            ),
            CapturedFrameInfo(
                id = "${f1Id}_rear",
                sessionId = f1Id,
                angle = CaptureAngle.REAR,
                localFilePath = null,
                capturedAtMs = BASE_TIME_MS + 42_000,
                imageWidthPx = imgW,
                imageHeightPx = imgH,
                meanLuma = 146f,
                motionStabilityScore = 0.96f,
                landmarks = standardStandingLandmarks(),
                occludedLandmarks = emptyList(),
                qualityIssues = emptyList(),
                isSynthetic = true
            )
        )
        val f1Measurements = GeometryMath.deriveMeasurementsFromFrames(
            sessionId = f1Id,
            frames = f1Frames,
            calibration = a4Calibration,
            nowMs = BASE_TIME_MS + 45_000
        )
        val session1 = ScanSession(
            id = f1Id,
            title = "Demo 1 · Calibrated Guided Capture (A4)",
            createdAtMs = BASE_TIME_MS + 45_000,
            captureMode = CaptureMode.GUIDED_PHOTOGRAPHS,
            processingState = SessionProcessingState.COMPLETED,
            calibration = a4Calibration,
            frames = f1Frames,
            measurements = f1Measurements,
            modelProvenance = ModelProvenanceType.ESTIMATED_PARAMETRIC_AVATAR,
            coveredSectors = setOf(CaptureAngle.FRONT, CaptureAngle.SIDE_LEFT, CaptureAngle.REAR),
            equipmentDescription = "Rear Wide RGB Camera + A4 Reference Card",
            environmentConditions = "Indoor diffused daylight (~450 lux), 2.25 m distance, tripod-mounted",
            personalNotes = "Synthetic fixture demonstrating full 3-angle guided capture with quantified A4 scale uncertainty.",
            isDemoFixture = true,
            demoScenarioTag = "CALIBRATED_GUIDED"
        )

        // Fixture 2: Manual Measurement Session
        val f2Id = "demo_manual_session"
        val manualCal = CalibrationSolver.solveFromReferenceSpan(
            source = CalibrationSource.MANUAL_TAPE,
            referencePixelSpan = 100.0,
            referencePhysicalMm = 100.0,
            referenceTolerancePercent = 0.5
        )
        val f2Measurements = listOf(
            manualRecord(f2Id, "stature", "Standing Height (Tape)", "Wall-mounted stadiometer / tape.", MeasurementCategory.LINEAR_LENGTH, 1752.0, 4.0, BASE_TIME_MS + 100_000),
            manualRecord(f2Id, "shoulder_width", "Biacromial Breadth (Tape)", "Direct caliper / tape span across acromia.", MeasurementCategory.BREADTH_WIDTH, 418.0, 5.0, BASE_TIME_MS + 100_000),
            manualRecord(f2Id, "chest_circumference", "Chest Circumference (Tape)", "Horizontal tape at mid-sternum.", MeasurementCategory.CIRCUMFERENCE, 984.0, 6.0, BASE_TIME_MS + 100_000),
            manualRecord(f2Id, "waist_circumference", "Waist Circumference (Tape)", "Horizontal tape at narrowest torso level.", MeasurementCategory.CIRCUMFERENCE, 812.0, 6.0, BASE_TIME_MS + 100_000),
            manualRecord(f2Id, "hip_circumference_est", "Hip Circumference (Tape)", "Horizontal tape at widest gluteal prominence.", MeasurementCategory.CIRCUMFERENCE, 968.0, 6.0, BASE_TIME_MS + 100_000)
        )
        val session2 = ScanSession(
            id = f2Id,
            title = "Demo 2 · Manual Tape Session",
            createdAtMs = BASE_TIME_MS + 100_000,
            captureMode = CaptureMode.MANUAL_MEASUREMENTS,
            processingState = SessionProcessingState.COMPLETED,
            calibration = manualCal,
            frames = emptyList(),
            measurements = f2Measurements,
            modelProvenance = ModelProvenanceType.MANUAL_RECORD_ONLY,
            coveredSectors = emptySet(),
            equipmentDescription = "Fiberglass Anthropometric Tape (1 mm ticks)",
            environmentConditions = "Standing relaxed exhalation, light athletic attire",
            personalNotes = "Distinct manual tape entry session for method-compatibility comparison.",
            isDemoFixture = true,
            demoScenarioTag = "MANUAL_TAPE"
        )

        // Fixture 4: Rotatable Sample 3D Model with Isometric View
        val f4Id = "demo_3d_isometric"
        val synthCal = CalibrationSolver.solveFromReferenceSpan(
            source = CalibrationSource.SYNTHETIC_DEMO,
            referencePixelSpan = 264.0,
            referencePhysicalMm = 297.0,
            referenceTolerancePercent = 0.8,
            estimatedCameraDistanceMeters = 2.2
        )
        val f4Measurements = GeometryMath.deriveMeasurementsFromFrames(
            sessionId = f4Id,
            frames = f1Frames.map { it.copy(id = "${f4Id}_${it.angle.name}", sessionId = f4Id) },
            calibration = synthCal,
            nowMs = BASE_TIME_MS + 200_000
        )
        val session4 = ScanSession(
            id = f4Id,
            title = "Demo 4 · Synthetic 3D & Isometric Model",
            createdAtMs = BASE_TIME_MS + 200_000,
            captureMode = CaptureMode.DEMONSTRATION,
            processingState = SessionProcessingState.COMPLETED,
            calibration = synthCal,
            frames = f1Frames.map { it.copy(id = "${f4Id}_${it.angle.name}", sessionId = f4Id) },
            measurements = f4Measurements,
            modelProvenance = ModelProvenanceType.SYNTHETIC_DEMO_MODEL,
            coveredSectors = setOf(CaptureAngle.FRONT, CaptureAngle.SIDE_LEFT, CaptureAngle.REAR),
            equipmentDescription = "Synthetic Multi-Sector Mesh Fixture",
            environmentConditions = "Controlled demonstration geometry (0.8% reference tolerance)",
            personalNotes = "Inspect in Body Model tab using Isometric, Orthographic, Perspective, and axial clipping.",
            isDemoFixture = true,
            demoScenarioTag = "ISOMETRIC_3D_DEMO"
        )

        // Fixture 5: Missing Calibration (Uncalibrated Front Photo)
        val f5Id = "demo_missing_calibration"
        val noCal = CalibrationSolver.uncalibrated(
            "No reference card or stature input provided. Pixel & relative pose coordinates only."
        )
        val f5Frames = listOf(
            CapturedFrameInfo(
                id = "${f5Id}_front",
                sessionId = f5Id,
                angle = CaptureAngle.FRONT,
                localFilePath = null,
                capturedAtMs = BASE_TIME_MS + 300_000,
                imageWidthPx = imgW,
                imageHeightPx = imgH,
                meanLuma = 132f,
                motionStabilityScore = 0.92f,
                landmarks = standardStandingLandmarks(),
                occludedLandmarks = emptyList(),
                qualityIssues = listOf(QualityIssueType.MISSING_CALIBRATION, QualityIssueType.INCOMPLETE_COVERAGE),
                isSynthetic = true
            )
        )
        val f5Measurements = GeometryMath.deriveMeasurementsFromFrames(
            sessionId = f5Id,
            frames = f5Frames,
            calibration = noCal,
            nowMs = BASE_TIME_MS + 305_000
        )
        val session5 = ScanSession(
            id = f5Id,
            title = "Demo 5 · Missing Calibration (Blocked)",
            createdAtMs = BASE_TIME_MS + 305_000,
            captureMode = CaptureMode.GUIDED_PHOTOGRAPHS,
            processingState = SessionProcessingState.PARTIAL_WITH_WARNINGS,
            calibration = noCal,
            frames = f5Frames,
            measurements = f5Measurements,
            modelProvenance = ModelProvenanceType.POSE_SKELETON_ONLY,
            coveredSectors = setOf(CaptureAngle.FRONT),
            equipmentDescription = "Handheld RGB Camera (Uncalibrated)",
            environmentConditions = "Single front view, no scale marker",
            personalNotes = "Demonstrates strict refusal to infer physical mm/cm from an uncalibrated photograph.",
            isDemoFixture = true,
            demoScenarioTag = "MISSING_CALIBRATION"
        )

        // Fixture 6: Partial Capture & Reconstruction Failure
        val f6Id = "demo_partial_failure"
        val f6Frames = listOf(
            CapturedFrameInfo(
                id = "${f6Id}_front",
                sessionId = f6Id,
                angle = CaptureAngle.FRONT,
                localFilePath = null,
                capturedAtMs = BASE_TIME_MS + 400_000,
                imageWidthPx = imgW,
                imageHeightPx = imgH,
                meanLuma = 58f,
                motionStabilityScore = 0.51f,
                landmarks = standardStandingLandmarks(occludeRightAnkle = true),
                occludedLandmarks = listOf(AnatomicalLandmark.RIGHT_ANKLE, AnatomicalLandmark.RIGHT_HEEL),
                qualityIssues = listOf(
                    QualityIssueType.INCOMPLETE_COVERAGE,
                    QualityIssueType.EXCESSIVE_MOTION,
                    QualityIssueType.OCCLUSION,
                    QualityIssueType.INSUFFICIENT_INPUT,
                    QualityIssueType.RECONSTRUCTION_UNAVAILABLE
                ),
                isSynthetic = true
            )
        )
        val f6Measurements = GeometryMath.deriveMeasurementsFromFrames(
            sessionId = f6Id,
            frames = f6Frames,
            calibration = a4Calibration,
            nowMs = BASE_TIME_MS + 405_000
        )
        val session6 = ScanSession(
            id = f6Id,
            title = "Demo 6 · Partial Capture & Recon Failure",
            createdAtMs = BASE_TIME_MS + 405_000,
            captureMode = CaptureMode.RECONSTRUCTION_3D,
            processingState = SessionProcessingState.FAILED_RECONSTRUCTION,
            calibration = a4Calibration,
            frames = f6Frames,
            measurements = f6Measurements,
            modelProvenance = ModelProvenanceType.PARTIAL_COVERAGE_MODEL,
            coveredSectors = setOf(CaptureAngle.FRONT),
            equipmentDescription = "Handheld RGB Camera (No Depth Sensor)",
            environmentConditions = "Low light (58 luma), motion blur, Side & Rear missing",
            personalNotes = "Demonstrates honest failure reporting, occluded ankle flagging, and gap preservation in 3D view.",
            isDemoFixture = true,
            demoScenarioTag = "PARTIAL_RECON_FAILURE"
        )

        // Fixture 9: Complete Deletion Sandbox Session
        val f9Id = "demo_deletion_sandbox"
        val session9 = session1.copy(
            id = f9Id,
            title = "Demo 9 · Deletion Sandbox Session",
            createdAtMs = BASE_TIME_MS + 500_000,
            frames = f1Frames.map { it.copy(id = "${f9Id}_${it.angle.name}", sessionId = f9Id) },
            measurements = f1Measurements.map { it.copy(id = "${it.id}_del", sessionId = f9Id) },
            personalNotes = "Use History -> Delete to verify permanent removal of session metadata, measurements, and private files.",
            demoScenarioTag = "DELETION_SANDBOX"
        )

        return listOf(session1, session2, session4, session5, session6, session9)
    }

    /**
     * Fixture 3: Pose-landmark playback sequence (36-frame standing squat/reach).
     */
    fun buildDemoMovementSequence(): MovementSequence {
        val frames = (0 until 36).map { idx ->
            val phase = (idx.toDouble() / 35.0) * 2.0 * PI
            val squatDepth = ((1.0 - kotlin.math.cos(phase)) * 0.5).toFloat() // 0..1..0
            val base = standardStandingLandmarks(
                shoulderTiltOffset = 0.004f * sin(phase).toFloat(),
                hipTiltOffset = -0.002f * sin(phase).toFloat()
            )
            val animated = base.map { pt ->
                when (pt.landmarkType) {
                    AnatomicalLandmark.NOSE,
                    AnatomicalLandmark.LEFT_EYE,
                    AnatomicalLandmark.RIGHT_EYE,
                    AnatomicalLandmark.LEFT_EAR,
                    AnatomicalLandmark.RIGHT_EAR ->
                        pt.copy(yNorm = pt.yNorm + squatDepth * 0.13f)
                    AnatomicalLandmark.LEFT_SHOULDER,
                    AnatomicalLandmark.RIGHT_SHOULDER ->
                        pt.copy(yNorm = pt.yNorm + squatDepth * 0.14f)
                    AnatomicalLandmark.LEFT_ELBOW,
                    AnatomicalLandmark.RIGHT_ELBOW ->
                        pt.copy(
                            yNorm = pt.yNorm + squatDepth * 0.06f,
                            xNorm = pt.xNorm + (if (pt.xNorm < 0.5f) -0.03f else 0.03f) * squatDepth
                        )
                    AnatomicalLandmark.LEFT_WRIST,
                    AnatomicalLandmark.RIGHT_WRIST ->
                        pt.copy(
                            yNorm = pt.yNorm - squatDepth * 0.16f,
                            xNorm = pt.xNorm + (if (pt.xNorm < 0.5f) -0.05f else 0.05f) * squatDepth
                        )
                    AnatomicalLandmark.LEFT_HIP,
                    AnatomicalLandmark.RIGHT_HIP ->
                        pt.copy(yNorm = pt.yNorm + squatDepth * 0.16f)
                    AnatomicalLandmark.LEFT_KNEE ->
                        pt.copy(xNorm = pt.xNorm - squatDepth * 0.025f, yNorm = pt.yNorm + squatDepth * 0.04f)
                    AnatomicalLandmark.RIGHT_KNEE ->
                        pt.copy(xNorm = pt.xNorm + squatDepth * 0.025f, yNorm = pt.yNorm + squatDepth * 0.04f)
                    else -> pt
                }
            }

            val map = animated.associateBy { it.landmarkType }
            val lKneeAngle = GeometryMath.angleBetweenThreePointsDeg(
                map[AnatomicalLandmark.LEFT_HIP]!!,
                map[AnatomicalLandmark.LEFT_KNEE]!!,
                map[AnatomicalLandmark.LEFT_ANKLE]!!
            )
            val rKneeAngle = GeometryMath.angleBetweenThreePointsDeg(
                map[AnatomicalLandmark.RIGHT_HIP]!!,
                map[AnatomicalLandmark.RIGHT_KNEE]!!,
                map[AnatomicalLandmark.RIGHT_ANKLE]!!
            )
            val shTilt = GeometryMath.horizontalTiltDegrees(
                map[AnatomicalLandmark.LEFT_SHOULDER]!!,
                map[AnatomicalLandmark.RIGHT_SHOULDER]!!
            )
            PoseFrameSample(
                frameIndex = idx,
                timestampMs = idx * 66L,
                landmarks = animated,
                leftKneeAngleDeg = lKneeAngle,
                rightKneeAngleDeg = rKneeAngle,
                shoulderTiltDeg = shTilt,
                meanConfidence = 0.94f
            )
        }

        return MovementSequence(
            id = "demo_pose_playback",
            title = "Demo 3 · Squat & Reach Pose Playback",
            captureDateMs = BASE_TIME_MS + 150_000,
            viewpoint = CaptureAngle.FRONT,
            fps = 15f,
            frames = frames,
            isSyntheticDemo = true,
            provenanceNote = "SYNTHETIC POSE SEQUENCE · Normalized landmark coordinates only; not a 3D surface scan."
        )
    }

    /**
     * Fixture 8: Simulated Force-Sensor Recording.
     */
    fun buildDemoForceTrial(): ForceSensorTrial {
        val device = DiscoveredForceDevice(
            id = "SIM-LC-500N",
            name = "Aureom SimCell 500N [SIMULATED]",
            address = "00:SIM:00:00:05:00",
            isSimulated = true,
            calibrationDateIso = "2026-10-15",
            maxRatedNewtons = 650.0,
            samplingRateHz = 50
        )
        val samples = mutableListOf<ForceSamplePoint>()
        val total = 150 // 3.0s at 50Hz
        for (i in 0 until total) {
            if (i == 62 || i == 63) continue // 2 missing samples
            val t = i.toDouble() / total
            val env = when {
                t < 0.2 -> t / 0.2
                t < 0.8 -> 1.0 + 0.06 * sin(t * 24.0)
                else -> ((1.0 - t) / 0.2).coerceAtLeast(0.0)
            }
            val forceN = (630.0 * env + if (i == 95) 45.0 else 0.0).coerceAtLeast(0.0)
            samples.add(
                ForceSamplePoint(
                    timestampMs = i * 20L,
                    forceNewtons = forceN,
                    isOverload = forceN > device.maxRatedNewtons
                )
            )
        }
        return SimulatedForceSensorAdapter.buildTrialSummary(
            device = device,
            exerciseSetup = "Isometric Mid-Thigh Pull (Demo Fixture)",
            samples = samples,
            expectedSamples = total,
            durationSec = 3.0
        ).copy(id = "demo_force_trial", recordedAtMs = BASE_TIME_MS + 450_000)
    }

    private fun manualRecord(
        sessionId: String,
        key: String,
        label: String,
        definition: String,
        category: MeasurementCategory,
        valueMm: Double,
        uncertaintyMm: Double,
        ts: Long
    ): BodyMeasurementRecord = BodyMeasurementRecord(
        id = "${sessionId}_$key",
        sessionId = sessionId,
        metricKey = key,
        label = label,
        definition = definition,
        category = category,
        valueMm = valueMm,
        uncertaintyMm = uncertaintyMm,
        sourceMethod = MeasurementSource.MANUAL_TAPE,
        calibrationSource = CalibrationSource.MANUAL_TAPE,
        qualityStatus = MeasurementQualityStatus.MANUAL_ENTRY,
        coordinateOrigin = CoordinateSystemType.MANUAL_TAPE_MILLIMETERS,
        captureTimestampMs = ts
    )
}
