package com.example.data.local

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts optional backend bearer tokens using AndroidKeyStore AES-256-GCM.
 * Falls back cleanly in non-Keystore JVM test runners while keeping SharedPreferences separate.
 */
class SecureCredentialStore(context: Context) {

    private val prefs = context.getSharedPreferences("aureom_secure_creds", Context.MODE_PRIVATE)

    fun saveBackendToken(token: String) {
        if (token.isBlank()) {
            clearBackendToken()
            return
        }
        val encrypted = encryptWithKeystore(token)
        if (encrypted != null) {
            prefs.edit()
                .putString(KEY_TOKEN_CIPHERTEXT, encrypted.first)
                .putString(KEY_TOKEN_IV, encrypted.second)
                .putBoolean(KEY_IS_KEYSTORE_BACKED, true)
                .apply()
        } else {
            // Only reached in headless JVM test environments without AndroidKeyStore
            prefs.edit()
                .putString(KEY_TOKEN_CIPHERTEXT, Base64.encodeToString(token.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
                .putBoolean(KEY_IS_KEYSTORE_BACKED, false)
                .apply()
        }
    }

    fun getBackendToken(): String? {
        val payload = prefs.getString(KEY_TOKEN_CIPHERTEXT, null) ?: return null
        val isKeystore = prefs.getBoolean(KEY_IS_KEYSTORE_BACKED, false)
        return if (isKeystore) {
            val iv = prefs.getString(KEY_TOKEN_IV, null) ?: return null
            decryptWithKeystore(payload, iv)
        } else {
            runCatching { String(Base64.decode(payload, Base64.NO_WRAP), Charsets.UTF_8) }.getOrNull()
        }
    }

    fun isHardwareKeystoreBacked(): Boolean = prefs.getBoolean(KEY_IS_KEYSTORE_BACKED, false)

    fun hasStoredToken(): Boolean = !prefs.getString(KEY_TOKEN_CIPHERTEXT, null).isNullOrBlank()

    fun clearBackendToken() {
        prefs.edit().clear().apply()
    }

    private fun getOrCreateKey(): SecretKey? {
        return runCatching {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
            if (existing != null) return@runCatching existing

            val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            keyGen.init(spec)
            keyGen.generateKey()
        }.getOrNull()
    }

    private fun encryptWithKeystore(plainText: String): Pair<String, String>? {
        val key = getOrCreateKey() ?: return null
        return runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val cipherBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            val ivB64 = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
            val ctB64 = Base64.encodeToString(cipherBytes, Base64.NO_WRAP)
            ctB64 to ivB64
        }.getOrNull()
    }

    private fun decryptWithKeystore(cipherB64: String, ivB64: String): String? {
        val key = getOrCreateKey() ?: return null
        return runCatching {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val iv = Base64.decode(ivB64, Base64.NO_WRAP)
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            val plain = cipher.doFinal(Base64.decode(cipherB64, Base64.NO_WRAP))
            String(plain, Charsets.UTF_8)
        }.getOrNull()
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_ALIAS = "aureom_backend_token_aes_key"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val KEY_TOKEN_CIPHERTEXT = "token_ct"
        private const val KEY_TOKEN_IV = "token_iv"
        private const val KEY_IS_KEYSTORE_BACKED = "keystore_backed"
    }
}
