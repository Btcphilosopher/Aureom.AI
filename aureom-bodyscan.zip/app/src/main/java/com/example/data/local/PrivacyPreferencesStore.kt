package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.ForceUnit
import com.example.domain.model.LengthUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.privacyDataStore: DataStore<Preferences> by preferencesDataStore(name = "aureom_privacy_prefs")

data class AppPreferencesState(
    val hasLocalCaptureConsent: Boolean = false,
    val isCloudUploadOptIn: Boolean = false,
    val backendEndpointUrl: String = "",
    val lengthUnit: LengthUnit = LengthUnit.CENTIMETERS,
    val forceUnit: ForceUnit = ForceUnit.NEWTONS,
    val retentionDays: Int = 0, // 0 = Keep until deleted manually
    val reducedMotion: Boolean = false,
    val darkLabTheme: Boolean = false,
    val privateNotificationsEnabled: Boolean = false
)

class PrivacyPreferencesStore(private val context: Context) {

    private object Keys {
        val LOCAL_CONSENT = booleanPreferencesKey("local_capture_consent")
        val CLOUD_OPT_IN = booleanPreferencesKey("cloud_upload_opt_in")
        val BACKEND_URL = stringPreferencesKey("backend_endpoint_url")
        val LENGTH_UNIT = stringPreferencesKey("length_unit")
        val FORCE_UNIT = stringPreferencesKey("force_unit")
        val RETENTION_DAYS = intPreferencesKey("retention_days")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val DARK_THEME = booleanPreferencesKey("dark_lab_theme")
        val NOTIFICATIONS = booleanPreferencesKey("private_notifications")
    }

    val preferencesFlow: Flow<AppPreferencesState> = context.privacyDataStore.data.map { prefs ->
        AppPreferencesState(
            hasLocalCaptureConsent = prefs[Keys.LOCAL_CONSENT] ?: false,
            isCloudUploadOptIn = prefs[Keys.CLOUD_OPT_IN] ?: false,
            backendEndpointUrl = prefs[Keys.BACKEND_URL] ?: "",
            lengthUnit = runCatching {
                LengthUnit.valueOf(prefs[Keys.LENGTH_UNIT] ?: LengthUnit.CENTIMETERS.name)
            }.getOrDefault(LengthUnit.CENTIMETERS),
            forceUnit = runCatching {
                ForceUnit.valueOf(prefs[Keys.FORCE_UNIT] ?: ForceUnit.NEWTONS.name)
            }.getOrDefault(ForceUnit.NEWTONS),
            retentionDays = prefs[Keys.RETENTION_DAYS] ?: 0,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            darkLabTheme = prefs[Keys.DARK_THEME] ?: false,
            privateNotificationsEnabled = prefs[Keys.NOTIFICATIONS] ?: false
        )
    }

    suspend fun setLocalCaptureConsent(granted: Boolean) {
        context.privacyDataStore.edit { it[Keys.LOCAL_CONSENT] = granted }
    }

    suspend fun setCloudUploadOptIn(enabled: Boolean) {
        context.privacyDataStore.edit { it[Keys.CLOUD_OPT_IN] = enabled }
    }

    suspend fun setBackendEndpointUrl(url: String) {
        context.privacyDataStore.edit { it[Keys.BACKEND_URL] = url.trim() }
    }

    suspend fun setLengthUnit(unit: LengthUnit) {
        context.privacyDataStore.edit { it[Keys.LENGTH_UNIT] = unit.name }
    }

    suspend fun setForceUnit(unit: ForceUnit) {
        context.privacyDataStore.edit { it[Keys.FORCE_UNIT] = unit.name }
    }

    suspend fun setRetentionDays(days: Int) {
        context.privacyDataStore.edit { it[Keys.RETENTION_DAYS] = days }
    }

    suspend fun setReducedMotion(enabled: Boolean) {
        context.privacyDataStore.edit { it[Keys.REDUCED_MOTION] = enabled }
    }

    suspend fun setDarkLabTheme(enabled: Boolean) {
        context.privacyDataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun setPrivateNotifications(enabled: Boolean) {
        context.privacyDataStore.edit { it[Keys.NOTIFICATIONS] = enabled }
    }
}
