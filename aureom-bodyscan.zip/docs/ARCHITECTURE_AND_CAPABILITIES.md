# AUREOM BODYSCAN — Architecture, Capabilities, & Build Guide

## 1. Capability Classification Matrix

| Capability | Status | Adapter / Engine | Notes & Scientific Boundaries |
|---|---|---|---|
| Guided RGB Capture (Front / Side / Rear) | **Implemented** | CameraX (`1.5.0`) + `SensorManager` | App-private storage (`filesDir/private_scans`); accelerometer stability & luma checks. |
| On-Device Pose Landmarks | **Implemented** | `MlKitPoseEstimatorAdapter` (`pose-detection:18.0.0-beta5`) | Runs locally with no cloud account. Pose skeleton is not a surface scan. |
| Calibrated Linear & Breadth Metrics | **Estimated** | `CalibrationSolver` + `GeometryMath` | Internal storage in `mm`; requires A4 card, marker, or stature reference. Uncalibrated frames block metric output. |
| Multi-View Silhouette Circumference | **Estimated** | `GeometryMath` | Strictly gated on **both** calibration and Front + Side views; flagged with elevated ± uncertainty. Single front images never derive circumferences. |
| Manual Tape Measurements | **Implemented** | `MeasurementsScreen` + Room | Stored separately (`MANUAL_TAPE`) from camera estimates. |
| Interactive 3D & Isometric Viewport | **Implemented** | `SoftwareMatrix3DRenderer` (`Body3DRendererAdapter`) | Perspective & Orthographic/Isometric projections, axial external clipping, unobserved gap hatching. |
| Hardware Depth / ToF Capture | **Unsupported** (device-gated) | `DeviceCapabilityInspector` (`CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT`) | Enabled only on hardware advertising `DEPTH_OUTPUT`; never simulated as real depth. |
| Dense 3D Mesh Reconstruction | **Unsupported locally** / Optional Backend | `FastApiReconstructionClient` | Requires explicit user opt-in + external Python/FastAPI server; missing views fail explicitly with gap preservation. |
| External Force Sensor (BLE GATT) | **Implemented (Adapter) / Simulated (Fixture)** | `BleForceSensorAdapter` + `SimulatedForceSensorAdapter` | 50 Hz force-time capture; clearly states camera pose alone cannot measure force. |

## 2. Dependencies & Licenses

- **Kotlin** `2.4.21` / **AGP** `9.1.1` / **Compile & Target SDK** `36` / **Min SDK** `24` (Apache-2.0)
- **Jetpack Compose BOM** `2024.09.00` & **Navigation Compose** `2.8.9` (Apache-2.0)
- **CameraX** (`camera-core`, `camera-camera2`, `camera-lifecycle`, `camera-view` `1.5.0`) (Apache-2.0)
- **Google ML Kit Pose Detection** (`com.google.mlkit:pose-detection:18.0.0-beta5`) (Google ML Kit Terms / Apache-2.0 SDK wrapper)
- **Room** (`2.7.0` with KSP) & **DataStore Preferences** (`1.1.7`) (Apache-2.0)
- **Retrofit** (`2.12.0`), **Moshi** (`1.15.2`), **OkHttp** (`4.10.0`) (Apache-2.0)
- **Kotlinx Serialization JSON** (`1.8.0`) & **Coil** (`2.7.0`) (Apache-2.0)

## 3. Build & Test Commands

```bash
# Build Debug APK
gradle assembleDebug

# Build Release APK (requires signing env vars)
gradle assembleRelease

# Run JVM Unit + Robolectric Tests
gradle :app:testDebugUnitTest
```

## 4. Intended Use & Regulatory Boundary

AUREOM BODYSCAN is built for non-medical anthropometry, garment/ergonomic sizing reference, and geometric posture/motion visualization. It does **not** diagnose medical conditions, prescribe corrective exercises, infer body composition/bone density, or provide clinical safety clearance.
