import numpy as np
import pytest
import torch

from aureom_recommend.config import RetrievalConfig
from aureom_recommend.constants import PAD, UNK
from aureom_recommend.retrieval.index import HAVE_FAISS, ExactIndex, FaissIndex, build_index, exact_top_k
from aureom_recommend.retrieval.loss import sampled_softmax_loss
from aureom_recommend.retrieval.model import to_tensors
from aureom_recommend.features.state import tower_inputs
from aureom_recommend.data.histories import UserItems
from aureom_recommend.data.schemas import UserPreferences


def test_loss_masks_accidental_negatives():
    torch.manual_seed(0)
    u = torch.nn.functional.normalize(torch.randn(3, 8), dim=1)
    c = torch.nn.functional.normalize(torch.randn(6, 8), dim=1)
    c[4] = u[0] * 1.0                                   # a perfect match that is NOT row 0's positive
    pos = torch.tensor([0, 1, 2])
    everything = torch.ones(3, 6, dtype=torch.bool)
    masked = everything.clone()
    masked[0, 4] = False                                # declare it a known positive / duplicate
    loss_all = sampled_softmax_loss(u, c, pos, everything, temperature=0.1)
    loss_masked = sampled_softmax_loss(u, c, pos, masked, temperature=0.1)
    assert loss_masked < loss_all
    # masked candidates have no influence at all
    c2 = c.clone()
    c2[4] = -u[0]
    assert sampled_softmax_loss(u[:1], c2, pos[:1], masked[:1], 0.1).item() == pytest.approx(
        sampled_softmax_loss(u[:1], c, pos[:1], masked[:1], 0.1).item())
    # with no negatives left the loss is zero rather than undefined
    none = torch.zeros(3, 6, dtype=torch.bool)
    assert sampled_softmax_loss(u, c, pos, none, 0.1).item() == pytest.approx(0.0, abs=1e-6)


def test_loss_matches_cross_entropy_and_handles_multiple_positives():
    torch.manual_seed(1)
    u, c = torch.randn(4, 5), torch.randn(4, 5)
    pos = torch.arange(4)
    full = torch.ones(4, 4, dtype=torch.bool)
    ours = sampled_softmax_loss(u, c, pos, full, temperature=0.5)
    ref = torch.nn.functional.cross_entropy(u @ c.T / 0.5, pos)
    assert ours.item() == pytest.approx(ref.item(), rel=1e-5)
    # logQ correction changes the logits by -log q
    log_q = torch.log(torch.tensor([0.5, 0.1, 0.2, 0.2]))
    corrected = sampled_softmax_loss(u, c, pos, full, 0.5, log_q=log_q, logq_weight=1.0)
    ref_q = torch.nn.functional.cross_entropy(u @ c.T / 0.5 - log_q[None, :], pos)
    assert corrected.item() == pytest.approx(ref_q.item(), rel=1e-5)
    # "average" mode: an extra positive is averaged in instead of being a negative
    neg = full.clone()
    neg[0, 1] = False
    extra = torch.zeros(4, 4, dtype=torch.bool)
    extra[0, 1] = True
    avg = sampled_softmax_loss(u, c, pos, neg, 0.5, extra_positive_mask=extra, multi_positive="average")
    mask_mode = sampled_softmax_loss(u, c, pos, neg, 0.5, extra_positive_mask=extra, multi_positive="mask")
    assert torch.isfinite(avg) and avg.item() != pytest.approx(mask_mode.item())


def _unit(n, d, seed=0):
    x = np.random.default_rng(seed).normal(size=(n, d)).astype("float32")
    return x / np.linalg.norm(x, axis=1, keepdims=True)


def test_exact_search_respects_eligibility_and_small_supply():
    emb = _unit(200, 16)
    q = emb[3]
    eligible = np.zeros(200, bool)
    eligible[[3, 10, 50]] = True
    rows, scores = exact_top_k(emb, q, 10, eligible)
    assert rows[0] == 3 and set(rows) == {3, 10, 50} and np.all(np.diff(scores) <= 0)   # fewer than k: no padding
    rows, _, _ = ExactIndex(emb).search(q, 5, np.zeros(200, bool))
    assert len(rows) == 0


@pytest.mark.skipif(not HAVE_FAISS, reason="faiss not installed")
def test_faiss_flat_matches_exact_and_hnsw_falls_back_under_heavy_filtering():
    emb = _unit(3000, 16, seed=2)
    cfg = RetrievalConfig()
    q = _unit(1, 16, seed=3)[0]
    all_ok = np.ones(3000, bool)
    exact_rows, _ = exact_top_k(emb, q, 20, all_ok)
    flat_rows, _, info = FaissIndex(emb, "faiss_flat", cfg).search(q, 20, all_ok)
    assert list(flat_rows) == list(exact_rows) and not info["fallback"]
    # very selective filter: oversampling cannot find enough eligible rows -> bounded exact fallback
    eligible = np.zeros(3000, bool)
    eligible[np.random.default_rng(4).choice(3000, 25, replace=False)] = True
    hnsw = FaissIndex(emb, "faiss_hnsw", RetrievalConfig(oversample_factor=2, max_oversample_rounds=2))
    rows, scores, info = hnsw.search(q, 20, eligible)
    assert info["fallback"] and eligible[rows].all() and len(rows) == 20
    assert list(rows) == list(exact_top_k(emb, q, 20, eligible)[0])
    # when the fallback is not allowed, fewer results are returned - never ineligible ones
    strict = FaissIndex(emb, "faiss_hnsw", RetrievalConfig(oversample_factor=2, max_oversample_rounds=1,
                                                         exact_fallback_max_eligible=0))
    rows, _, info = strict.search(q, 20, eligible)
    assert not info["fallback"] and eligible[rows].all() and len(rows) <= 20
    assert build_index(emb, RetrievalConfig(index="auto", exact_max_rows=10)).kind == "faiss_hnsw"
    assert build_index(emb, RetrievalConfig(index="auto")).kind == "exact"


def test_unseen_users_creators_and_videos_use_the_unknown_pathway(prepared, artefacts, config):
    space = artefacts.space
    assert space.encode(space.creator_vocab, ["creator_that_never_existed"], 3).tolist() == [UNK, PAD, PAD]
    assert space.encode(space.topic_vocab, ["brand_new_topic"], 2).tolist() == [UNK, PAD]
    runtime = artefacts.runtime(prepared.catalogue)
    # a user nobody has ever seen: empty history, unknown follows and topics
    prefs = UserPreferences("stranger", selected_topics=("brand_new_topic",), followed_creators=("nobody",))
    inputs = tower_inputs(UserItems.empty(), prefs, 0.0, 0, space, config)
    emb = artefacts.retriever.embed_user(runtime.bank, inputs)
    assert np.all(np.isfinite(emb)) and np.linalg.norm(emb) == pytest.approx(1.0, abs=1e-4)
    # every catalogue row - including videos unseen in training - gets a unit-norm embedding
    v = runtime.video_embeddings
    assert v.shape[0] == prepared.catalogue.n_rows and np.all(np.isfinite(v))
    np.testing.assert_allclose(np.linalg.norm(v, axis=1), 1.0, atol=1e-4)
    unk_rows = runtime.features.video == UNK
    assert unk_rows.any() and np.unique(np.round(v[unk_rows], 4), axis=0).shape[0] > 1    # content still separates them
    assert to_tensors(inputs)["hist_rows"].dtype == torch.long
