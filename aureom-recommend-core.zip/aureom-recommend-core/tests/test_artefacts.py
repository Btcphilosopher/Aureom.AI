import json

import numpy as np
import pytest

from aureom_recommend.artefacts.store import ArtefactCompatibilityError, load_artefacts, save_artefacts, validate_manifest
from aureom_recommend.inference.recommend import recommend


@pytest.fixture(scope="module")
def saved(tmp_path_factory, artefacts):
    return save_artefacts(artefacts, tmp_path_factory.mktemp("artefacts"))


def test_save_load_round_trip_gives_identical_recommendations(saved, prepared, artefacts, test_requests):
    loaded = load_artefacts(saved)
    assert loaded.model_version == artefacts.model_version and loaded.config.config_hash() == artefacts.config.config_hash()
    for req in test_requests.iloc[::12].itertuples():
        kwargs = dict(user_id=req.user_id, context=req.context, as_of=req.as_of, k=15, catalogue=prepared.catalogue,
                      histories=prepared.histories, preferences=prepared.preferences, previously_recommended=set(), seed=1)
        a, b = recommend(artefacts=artefacts, **kwargs), recommend(artefacts=loaded, **kwargs)
        assert a.video_ids == b.video_ids
        np.testing.assert_allclose([i.final_score for i in a], [i.final_score for i in b], rtol=1e-5, atol=1e-6)
        for x, y in zip(a, b):
            assert x.retrieval_sources == y.retrieval_sources and x.exploration == y.exploration
    assert {t: c.to_dict() for t, c in loaded.ranker.calibrators.items()} == \
           {t: c.to_dict() for t, c in artefacts.ranker.calibrators.items()}
    assert loaded.ranker.pos_weights == artefacts.ranker.pos_weights


def test_manifest_records_versions_and_checksums(saved, artefacts):
    manifest = validate_manifest(saved)
    assert manifest["model_version"] == artefacts.model_version
    assert manifest["label_version"] == "labels-v1" and manifest["policy_version"] == "policy-v1"
    assert set(manifest["files"]) >= {"retriever.pt", "ranker.pt", "feature_space.joblib", "config.json"}
    assert manifest["tower_dims"]["n_videos"] == len(artefacts.space.video_vocab) + 2


def _copy(saved, tmp_path):
    import shutil
    target = tmp_path / "copy"
    shutil.copytree(saved, target)
    return target


def test_tampered_or_incompatible_artefacts_are_rejected(saved, tmp_path):
    corrupt = _copy(saved, tmp_path)
    with open(corrupt / "ranker.pt", "ab") as fh:
        fh.write(b"tampered")
    with pytest.raises(ArtefactCompatibilityError, match="checksum"):
        load_artefacts(corrupt)

    def rewrite(name, mutate):
        target = _copy(saved, tmp_path / name)
        manifest = json.loads((target / "manifest.json").read_text())
        mutate(manifest)
        (target / "manifest.json").write_text(json.dumps(manifest))
        return target

    with pytest.raises(ArtefactCompatibilityError, match="format"):
        load_artefacts(rewrite("fmt", lambda m: m.update(format_version=99)))
    with pytest.raises(ArtefactCompatibilityError, match="feature definitions"):
        load_artefacts(rewrite("feat", lambda m: m["dense_features"].append("a_feature_this_code_does_not_know")))
    with pytest.raises(ArtefactCompatibilityError, match="tasks"):
        load_artefacts(rewrite("tasks", lambda m: m.update(tasks=m["tasks"][:-1])))
    with pytest.raises(ArtefactCompatibilityError, match="disagree"):
        load_artefacts(rewrite("dims", lambda m: m["tower_dims"].update(n_videos=m["tower_dims"]["n_videos"] + 5)))
    with pytest.raises(ArtefactCompatibilityError, match="config hash"):
        load_artefacts(rewrite("cfg", lambda m: m.update(config_hash="0" * 12)))
    missing = _copy(saved, tmp_path / "missing")
    (missing / "retriever.pt").unlink()
    with pytest.raises(ArtefactCompatibilityError, match="missing"):
        load_artefacts(missing)
    with pytest.raises(ArtefactCompatibilityError):
        load_artefacts(tmp_path / "does-not-exist")
