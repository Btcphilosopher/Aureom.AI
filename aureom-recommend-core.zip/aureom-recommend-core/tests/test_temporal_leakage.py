"""Nothing computed for time t may depend on information that arrived after t."""
import numpy as np
import pytest

from aureom_recommend.constants import UNK
from aureom_recommend.data.histories import HistoryStore
from aureom_recommend.data.labels import build_examples
from aureom_recommend.inference.recommend import recommend
from aureom_recommend.training.retriever import build_candidate_masks, build_retrieval_data
from aureom_recommend.training.splits import make_temporal_splits, window_examples


def _truncated(prepared, world, config, t):
    """State rebuilt from scratch using only events received before ``t``."""
    ev = prepared.events.loc[prepared.events.t_received.to_numpy() < t]
    examples = build_examples(ev, prepared.catalogue, t, config)
    return HistoryStore(examples, prepared.catalogue, config)


def test_history_never_contains_items_received_after_the_query_time(prepared):
    v = prepared.examples.versions
    rng = np.random.default_rng(0)
    for i in rng.choice(len(v), size=200, replace=False):
        user, t = v.user_id.iloc[i], float(v.t_available.iloc[i])
        items = prepared.histories.items_as_of(user, t)             # strictly before t
        mine = v[(v.user_id == user) & (v.t_available < t)]
        assert len(items) == mine.group.nunique()
        assert (items.t_item <= t).all()


def test_point_in_time_state_equals_state_rebuilt_from_a_truncated_log(prepared, world, config):
    sp = prepared.splits
    t = sp.ranker_train_end
    truncated = _truncated(prepared, world, config, t)
    users = prepared.histories.user_ids()
    rng = np.random.default_rng(1)
    for user in rng.choice(users, size=80, replace=False):
        a, b = prepared.histories.items_as_of(user, t), truncated.items_as_of(user, t)
        for field in ("video_idx", "t_item", "type", "strength"):
            np.testing.assert_array_equal(getattr(a, field), getattr(b, field))
        np.testing.assert_array_equal(prepared.histories.blocks_as_of(user, t), truncated.blocks_as_of(user, t))
    sa, sb = prepared.histories.stats.snapshot(t), truncated.stats.snapshot(t)
    for field in ("popularity", "positives", "negatives", "impressions", "positive_rate", "creator_positive_rate"):
        np.testing.assert_allclose(getattr(sa, field), getattr(sb, field))


def test_recommendations_do_not_change_when_the_future_is_removed(prepared, world, config, artefacts, test_requests):
    for req in test_requests.iloc[::30].itertuples():
        truncated = _truncated(prepared, world, config, req.as_of)
        kwargs = dict(user_id=req.user_id, context=req.context, as_of=req.as_of, k=10, catalogue=prepared.catalogue,
                      preferences=prepared.preferences, artefacts=artefacts, previously_recommended=set(), seed=7)
        full = recommend(histories=prepared.histories, **kwargs)
        cut = recommend(histories=truncated, **kwargs)
        assert full.video_ids == cut.video_ids
        np.testing.assert_allclose([i.final_score for i in full], [i.final_score for i in cut], rtol=1e-6)


def test_statistics_use_only_earlier_observations(prepared):
    imps = prepared.impressions
    t = float(np.quantile(imps.t, 0.6))
    snap = prepared.histories.stats.snapshot(t)
    assert snap.t <= t
    before = imps[imps.t_received < snap.t]
    np.testing.assert_array_equal(snap.impressions, np.bincount(before.video_idx, minlength=prepared.catalogue.n_videos))
    v = prepared.examples.versions
    assert snap.positives.sum() <= v[v.t_available < snap.t].group.nunique()   # only items already received
    later = prepared.histories.stats.snapshot(t + 5 * 86400)
    assert later.impressions.sum() > snap.impressions.sum()


def test_later_metadata_edits_and_uploads_are_invisible_earlier(prepared):
    cat = prepared.catalogue
    edited = np.flatnonzero(np.isfinite(cat.valid_from))                 # version-2 rows
    assert len(edited) > 0
    r = int(edited[0])
    before = cat.valid_from[r] - 1.0
    assert not cat.live_mask(before)[r]
    assert cat.rows_at(np.array([cat.video_index[r]]), np.array([before]))[0] == r - 1
    assert cat.rows_at(np.array([cat.video_index[r]]), np.array([cat.valid_from[r] + 1.0]))[0] == r
    t = float(np.median(cat.published_at))
    assert (cat.published_at[cat.live_mask(t)] <= t).all()
    assert (cat.available_until[cat.live_mask(t)] > t).all()


def test_fitted_transformations_only_see_the_training_snapshot(prepared, artefacts):
    cat, sp, space = prepared.catalogue, prepared.splits, artefacts.space
    cutoff = sp.retrieval_train_end
    assert space.cutoff == cutoff
    late_videos = {str(v) for v, p in zip(cat.video_ids, cat.published_at) if p > cutoff}
    assert late_videos and not (late_videos & set(space.video_vocab))
    features = artefacts.runtime(cat).features
    late_rows = cat.published_at > cutoff
    assert (features.video[late_rows] == UNK).all()                       # post-cutoff uploads use the unknown-ID pathway
    train_pos = window_examples(prepared.impressions, sp.start, cutoff)
    train_pos = train_pos[train_pos.is_positive]
    assert set(space.video_vocab) <= set(train_pos.video_id)


def test_windows_respect_the_label_embargo(prepared, config):
    sp = prepared.splits
    for name in ("retrieval_train", "retrieval_valid", "ranker_train", "ranker_valid", "calibration"):
        a, b = sp.window(name)
        win = window_examples(prepared.impressions, a, b)
        assert len(win) and (win.t >= a).all() and (win.maturity_time <= b).all()
    test = window_examples(prepared.impressions, *sp.window("test"))
    assert test.t.min() >= sp.calibration_end
    assert make_temporal_splits(prepared.impressions, config) == sp        # deterministic
    with pytest.raises(ValueError):
        make_temporal_splits(prepared.impressions, config.copy(**{"splits.ranker_train_end": 0.2}))


def test_negatives_are_restricted_to_videos_available_at_the_example_time(prepared, artefacts, config):
    cat, sp = prepared.catalogue, prepared.splits
    win = window_examples(prepared.impressions, sp.start, sp.retrieval_train_end)
    pos = win[win.is_positive].iloc[:64]
    features = artefacts.runtime(cat).features
    data = build_retrieval_data(pos, cat, prepared.histories, prepared.preferences, artefacts.space, features, config,
                                cutoff=sp.retrieval_train_end)
    idx = np.arange(len(data))
    cand = np.concatenate([data.pos_row, np.arange(cat.n_rows)])
    neg, known = build_candidate_masks(data, idx, cand)
    t = data.t[:, None]
    assert not (neg & (cat.published_at[cand][None, :] > t)).any()        # not yet published at example time
    assert not (neg & (cat.available_until[cand][None, :] <= t)).any()    # already expired
    assert not (neg & (cat.context_index[cand][None, :] != data.context_idx[:, None])).any()
    assert not neg[idx, idx].any() and known[idx, idx].all()              # own positive is never a negative
    same_group = cat.duplicate_group[cand][None, :] == cat.duplicate_group[data.pos_row][:, None]
    assert not (neg & same_group).any()                                   # duplicate copies are masked
