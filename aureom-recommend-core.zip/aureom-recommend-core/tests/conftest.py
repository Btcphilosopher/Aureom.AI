"""Shared fixtures: a tiny seeded synthetic world with trained artefacts, and hand-built event helpers."""
from __future__ import annotations

import itertools
import warnings

import numpy as np
import pandas as pd
import pytest

from aureom_recommend.config import Config
from aureom_recommend.data.schemas import INTERACTION_COLUMNS
from aureom_recommend.data.synthetic import SyntheticConfig, generate_synthetic
from aureom_recommend.training.pipeline import prepare_data, train_pipeline

warnings.filterwarnings("ignore")
T0 = pd.Timestamp("2026-03-01T00:00:00Z")
_ids = itertools.count()


def small_config() -> Config:
    cfg = Config()
    cfg.retrieval.epochs = 3
    cfg.retrieval.batch_size = 128
    cfg.retrieval.n_uniform_negatives = 128
    cfg.ranker.epochs = 4
    cfg.ranker.calibration_min_examples = 100
    cfg.ranker.calibration_min_class_support = 5
    cfg.evaluation.bootstrap_samples = 30
    cfg.evaluation.max_eval_requests = 120
    return cfg


@pytest.fixture(scope="session")
def config() -> Config:
    return small_config()


@pytest.fixture(scope="session")
def world():
    return generate_synthetic(SyntheticConfig(seed=11, n_users=260, n_videos=520, n_creators=50, n_days=16))


@pytest.fixture(scope="session")
def prepared(world, config):
    return prepare_data(world.videos, world.interactions, world.preferences, config)


@pytest.fixture(scope="session")
def artefacts(prepared, config):
    return train_pipeline(prepared, config)


@pytest.fixture(scope="session")
def test_requests(prepared, config):
    from aureom_recommend.training.splits import build_evaluation_requests

    a, b = prepared.splits.window("test")
    return build_evaluation_requests(prepared.impressions, a, b, 120, 0)


# ----------------------------------------------------------------------------- hand-built data
def ts(seconds: float) -> pd.Timestamp:
    return T0 + pd.Timedelta(seconds=seconds)


def event(event_type: str, t: float, user: str = "u1", video: str = "v1", request: str | None = "r1",
          delay: float = 1.0, **kw) -> dict:
    row = {c: None for c in INTERACTION_COLUMNS}
    row.update({"event_id": kw.pop("event_id", f"e{next(_ids)}"), "user_id": user, "video_id": video,
                "event_type": event_type, "occurred_at": ts(t), "received_at": ts(t + delay), "request_id": request,
                "session_id": "s1", "playback_context": kw.pop("ctx", "short_form")})
    for num in ("position", "watched_interval_start", "watched_interval_end", "explicit_feedback", "selection_propensity"):
        row[num] = kw.pop(num, np.nan)
    row.update(kw)
    return row


def progress(t: float, start: float, end: float, playback: str = "p1", fg=True, **kw) -> dict:
    return event("progress", t, playback_id=playback, watched_interval_start=start, watched_interval_end=end,
                 foreground=fg, **kw)


def events_frame(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows, columns=list(INTERACTION_COLUMNS))


def videos_frame(n: int = 6, duration: float = 60.0, **overrides) -> pd.DataFrame:
    rng = np.random.default_rng(0)
    rows = []
    for i in range(n):
        rows.append({
            "video_id": f"v{i + 1}", "creator_id": f"c{i % 3 + 1}", "title": f"title words topic{i % 2} item{i}",
            "description": f"description words topic{i % 2}", "language": "en", "topic_ids": [f"t{i % 2}"],
            "duration_seconds": duration, "published_at": ts(-86400.0 * (i + 1)), "available_from": None,
            "available_until": None, "content_embedding": rng.normal(size=4).astype("float32"),
            "duplicate_group_id": None, "eligibility_labels": ["general"], "metadata_version": 1,
        })
    df = pd.DataFrame(rows)
    for col, values in overrides.items():
        df[col] = values
    return df


def prefs_frame(users=("u1",), **overrides) -> pd.DataFrame:
    df = pd.DataFrame([{"user_id": u, "selected_topics": [], "preferred_languages": [], "followed_creators": [],
                        "blocked_creators": [], "excluded_videos": [], "personalisation_enabled": True,
                        "history_reset_at": None} for u in users])
    for col, values in overrides.items():
        df[col] = values
    return df
