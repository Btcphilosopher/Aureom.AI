import numpy as np
import pytest

from aureom_recommend.baselines.base import baseline_recommender
from aureom_recommend.baselines.models import BASELINE_NAMES
from aureom_recommend.evaluation.bootstrap import user_bootstrap_ci
from aureom_recommend.evaluation.metrics import (auc, brier_score, expected_calibration_error, gini, graded_ndcg_at_k,
                                                 intra_list_diversity, ndcg_at_k, recall_at_k, reciprocal_rank)
from aureom_recommend.evaluation.offline import evaluate_recommender
from aureom_recommend.evaluation.propensity import propensity_weighted_evaluation
from aureom_recommend.evaluation.report import fit_baselines
from aureom_recommend.evaluation.scenarios import VALID_SYNTHETIC_PROPENSITY_POLICIES
from aureom_recommend.features.state import build_request_state
from aureom_recommend.inference.recommend import recommend
from aureom_recommend.training.splits import window_examples


def test_ranking_metric_definitions():
    ranked, rel = ["a", "b", "c", "d"], {"b", "d", "z"}
    assert recall_at_k(ranked, rel, 2) == pytest.approx(1 / 3) and recall_at_k(ranked, rel, 4) == pytest.approx(2 / 3)
    assert reciprocal_rank(ranked, rel) == 0.5 and reciprocal_rank(["x"], rel) == 0.0
    dcg = 1 / np.log2(3) + 1 / np.log2(5)
    ideal = 1 + 1 / np.log2(3) + 1 / np.log2(4)
    assert ndcg_at_k(ranked, rel, 4) == pytest.approx(dcg / ideal)
    assert ndcg_at_k(["b", "d", "z"], rel, 3) == pytest.approx(1.0)
    assert np.isnan(recall_at_k(ranked, set(), 3)) and np.isnan(ndcg_at_k(ranked, set(), 3))
    assert graded_ndcg_at_k(np.array([3.0, 2.0, 1.0]), np.array([1.0, 2.0, 3.0, 0.0]), 3) == pytest.approx(1.0)
    assert graded_ndcg_at_k(np.array([0.0, 0.0]), np.array([1.0, 0.0]), 2) == 0.0


def test_probability_and_list_metrics():
    y = np.array([0, 0, 1, 1.0])
    assert brier_score(y, np.array([0, 0, 1, 1.0])) == 0.0 and brier_score(y, np.full(4, 0.5)) == 0.25
    assert expected_calibration_error(y, np.full(4, 0.5)) == pytest.approx(0.0)
    assert expected_calibration_error(y, np.full(4, 0.9)) == pytest.approx(0.4)
    assert auc(y, np.array([0.1, 0.2, 0.8, 0.9])) == 1.0 and auc(y, np.array([0.5, 0.5, 0.5, 0.5])) == 0.5
    assert np.isnan(auc(np.ones(3), np.ones(3)))
    same = np.tile(np.array([[1.0, 0.0]]), (3, 1))
    assert intra_list_diversity(same) == pytest.approx(0.0)
    assert intra_list_diversity(np.eye(3)) == pytest.approx(1.0)
    assert gini(np.ones(10)) == pytest.approx(0.0) and gini(np.array([0, 0, 0, 10.0])) == pytest.approx(0.75)


def test_user_level_bootstrap_is_deterministic_and_respects_user_clusters():
    rng = np.random.default_rng(0)
    users = np.repeat(np.arange(40), 10)
    values = np.repeat(rng.normal(size=40), 10)             # perfectly correlated within user
    mean, lo, hi = user_bootstrap_ci(values, users, 300, seed=1)
    assert lo < mean < hi and (mean, lo, hi) == user_bootstrap_ci(values, users, 300, seed=1)
    _, lo_iid, hi_iid = user_bootstrap_ci(values, np.arange(400), 300, seed=1)     # pretending requests are independent
    assert (hi - lo) > 2 * (hi_iid - lo_iid)
    assert np.isnan(user_bootstrap_ci(np.array([np.nan]), np.array([1]))[0])
    assert user_bootstrap_ci(np.array([1.0, np.nan, 3.0]), np.array([1, 1, 2]), 50)[0] == 2.0


def test_full_feed_evaluation_runs_without_eligibility_violations(prepared, artefacts, test_requests, world, config):
    res = evaluate_recommender(recommend, test_requests, catalogue=prepared.catalogue, histories=prepared.histories,
                               preferences=prepared.preferences, impressions=prepared.impressions, config=config,
                               artefacts=artefacts, oracle=world.oracle, name="learned")
    m = res.metrics
    assert m["eligibility_violations"] == 0 and m["n_requests"] == len(test_requests)
    assert m["duplicate_rate"]["mean"] == 0.0 and m["repeat_rate"]["mean"] == 0.0
    for key in ("recall@20", "ndcg@20", "mrr", "intra_list_diversity", "creator_concentration", "new_video_exposure",
                "oracle_utility@20", "oracle_ndcg@20"):
        assert 0.0 <= m[key]["mean"] <= 1.0
    assert m["recall@20"]["ci_low"] <= m["recall@20"]["mean"] <= m["recall@20"]["ci_high"]
    assert 0 < m["catalogue_coverage"] <= 1 and 0 < m["creator_coverage"] <= 1 and m["latency_ms"]["p95"] > 0
    assert set(res.slices) == {"context", "user_segment", "history_segment", "video_segment"}
    assert set(res.slices["context"]) <= {"short_form", "long_form"}
    assert "candidate_universe" in res.definitions and "relevance_label" in res.definitions
    assert m["creator_concentration"]["mean"] <= config.composition.max_per_creator / 20 + 0.2


def test_baselines_run_independently_and_handle_unseen_users_and_videos(prepared, config, test_requests):
    sp, cat = prepared.splits, prepared.catalogue
    fitted = fit_baselines(prepared, config)
    assert list(fitted) == BASELINE_NAMES and len(fitted) == 6
    req = test_requests.iloc[0]
    late_rows = np.flatnonzero(cat.published_at > sp.calibration_end)           # videos absent from training
    for name, b in fitted.items():
        for user in (req.user_id, "user-nobody-has-seen"):
            state = build_request_state(user, req.context, req.as_of, cat, prepared.histories, prepared.preferences, None, config)
            rows = np.flatnonzero(cat.live_mask(req.as_of) & cat.context_mask(req.context))
            scores = b.score(state, np.union1d(rows, late_rows[:5]), cat)
            assert np.all(np.isfinite(scores)), name
            feed = baseline_recommender(b, config)(user_id=user, context=req.context, as_of=req.as_of, k=10, catalogue=cat,
                                                 histories=prepared.histories, preferences=prepared.preferences)
            assert 0 < len(feed) <= 10 and len(set(feed.video_ids)) == len(feed)
            assert len(feed) == min(10, feed.diagnostics["n_eligible"]) or len(feed) < feed.diagnostics["n_eligible"]
    # each baseline is fitted on training impressions only
    train = window_examples(prepared.impressions, sp.start, sp.calibration_end)
    assert train.t.max() < sp.calibration_end


def test_smoothed_feedback_rate_shrinks_sparse_counts(prepared, test_requests, config):
    req = test_requests.iloc[-1]
    snap = prepared.histories.stats.snapshot(req.as_of)
    unseen = snap.impressions == 0
    assert unseen.any()
    np.testing.assert_allclose(snap.positive_rate[unseen], snap.global_positive_rate)     # prior, not 0 or 1
    assert snap.positive_rate.min() > 0 and snap.positive_rate.max() < 1
    one = (snap.impressions == 1) & (snap.positives >= 1)
    if one.any():
        assert snap.positive_rate[one].max() < 0.5                                        # a single hit is not "100%"


def test_propensity_evaluation_is_unavailable_without_valid_propensities(prepared, config, test_requests):
    imps = prepared.impressions
    feeds = {r: imps[imps.request_id == r].video_id.tolist() for r in test_requests.request_id}
    none = propensity_weighted_evaluation(feeds, imps, config, valid_policies=None)
    assert none["status"] == "unavailable" and "declared" in none["reason"]
    stripped = imps.assign(selection_propensity=np.nan)
    res = propensity_weighted_evaluation(feeds, stripped, config, VALID_SYNTHETIC_PROPENSITY_POLICIES)
    assert res["status"] == "unavailable" and "ips" not in res
    wrong_policy = propensity_weighted_evaluation(feeds, imps, config, {"some_other_policy": "claimed"})
    assert wrong_policy["status"] == "unavailable"
    # short-form impressions never carry a propensity in the synthetic world
    assert imps.loc[imps.context_idx == 0, "selection_propensity"].isna().all()


def test_propensity_evaluation_recovers_the_logged_mean_for_the_logging_policy_itself(prepared, config):
    imps = prepared.impressions
    logged = imps[imps.selection_propensity.notna() & (imps.m_meaningful > 0)]
    assert len(logged) > 100
    feeds = {r: g.video_id.tolist() for r, g in logged.groupby("request_id")}             # "recommend" what was shown
    cfg = config.copy(**{"evaluation.min_propensity_matches": 10})
    res = propensity_weighted_evaluation(feeds, imps, cfg, VALID_SYNTHETIC_PROPENSITY_POLICIES, k=20)
    assert res["status"] == "available" and res["n_matched_impressions"] == len(logged)
    assert res["snips"] == pytest.approx(np.average(logged.y_meaningful, weights=1 / logged.selection_propensity))
    assert res["snips_ci_low"] <= res["snips"] <= res["snips_ci_high"]
    tiny = propensity_weighted_evaluation(dict(list(feeds.items())[:2]), imps, config, VALID_SYNTHETIC_PROPENSITY_POLICIES)
    assert tiny["status"] == "unavailable" and "overlap" in tiny["reason"]
