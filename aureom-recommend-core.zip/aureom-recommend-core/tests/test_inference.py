"""End-to-end properties of `recommend` on a trained tiny world."""
import numpy as np
import pandas as pd
import pytest

from aureom_recommend.constants import PERSONALISED_SOURCES, SOURCES
from aureom_recommend.data.catalogue import Catalogue
from aureom_recommend.data.histories import PreferenceStore
from aureom_recommend.inference.recommend import recommend
from aureom_recommend.inference.types import FeedItem


def call(prepared, artefacts, user, context="short_form", as_of=None, k=20, seed=42, preferences=None, catalogue=None,
         previously=()):
    return recommend(user_id=user, context=context, as_of=prepared.examples.cutoff if as_of is None else as_of, k=k,
                     catalogue=catalogue or prepared.catalogue, histories=prepared.histories,
                     preferences=preferences or prepared.preferences, artefacts=artefacts,
                     previously_recommended=set(previously), seed=seed)


def _prefs(world, user, **changes):
    df = world.preferences.copy()
    i = df.index[df.user_id == user][0]
    for col, value in changes.items():
        df.at[i, col] = value
    return PreferenceStore(df)


@pytest.fixture(scope="module")
def active_user(prepared):
    counts = prepared.examples.versions.groupby("user_id").size()
    enabled = [u for u in counts.sort_values(ascending=False).index if prepared.preferences.get(u).personalisation_enabled]
    return enabled[0]


def test_feed_items_expose_the_documented_fields_only(prepared, artefacts, active_user):
    feed = call(prepared, artefacts, active_user)
    assert 0 < len(feed) <= 20 and [it.rank for it in feed] == list(range(1, len(feed) + 1))
    item = feed[0]
    assert isinstance(item, FeedItem)
    assert set(item.to_dict()) == {"video_id", "rank", "retrieval_sources", "prediction_heads", "score_contributions",
                                   "final_score", "exploration", "model_version", "policy_version"}
    assert set(item.prediction_heads) == {"meaningful", "duration", "like_or_save", "satisfaction", "negative"}
    assert all(0.0 <= p <= 1.0 for p in item.prediction_heads.values())
    assert set(item.retrieval_sources) <= set(SOURCES) and item.retrieval_sources
    assert item.model_version == artefacts.model_version and item.policy_version == "policy-v1"
    for it in feed:
        assert it.final_score == pytest.approx(sum(it.score_contributions.values()))
        assert it.score_contributions["negative"] <= 0
    blob = str(feed.to_records()) + str(feed.diagnostics)
    assert "embedding" not in blob and "hist" not in blob                # nothing private is exported


def test_inference_is_deterministic(prepared, artefacts, active_user):
    a, b = call(prepared, artefacts, active_user, seed=3), call(prepared, artefacts, active_user, seed=3)
    assert a.to_records() == b.to_records()
    other = call(prepared, artefacts, active_user, seed=4)
    stable = lambda f: [i.video_id for i in f if not i.exploration["is_exploration"]]     # noqa: E731
    assert len(set(stable(a)) & set(stable(other))) >= len(stable(a)) - 4


def test_blocked_creators_are_excluded_never_just_down_weighted(prepared, artefacts, world, active_user):
    cat = prepared.catalogue
    base = call(prepared, artefacts, active_user, k=30)
    creator_of = dict(zip(cat.video_ids, cat.creator_ids))
    top_creators = list(dict.fromkeys(creator_of[v] for v in base.video_ids))[:3]
    blocked = call(prepared, artefacts, active_user, k=30, preferences=_prefs(world, active_user, blocked_creators=top_creators))
    assert len(blocked) > 0 and not ({creator_of[v] for v in blocked.video_ids} & set(top_creators))
    # even a policy that rewards nothing but the blocked creators' best signal cannot bring them back
    boosted = artefacts.with_config(artefacts.config.copy(**{"policy.w_meaningful": 1000.0, "policy.w_negative": 0.0}))
    again = call(prepared, boosted, active_user, k=30, preferences=_prefs(world, active_user, blocked_creators=top_creators))
    assert not ({creator_of[v] for v in again.video_ids} & set(top_creators))
    # blocks that arrived as events are honoured from the moment they were received
    blocks = prepared.examples.blocks
    if len(blocks):
        row = blocks.iloc[0]
        feed = call(prepared, artefacts, row.user_id, as_of=row.t_available + 1.0, k=30)
        ctx_feed = call(prepared, artefacts, row.user_id, context="long_form", as_of=row.t_available + 1.0, k=30)
        shown = {cat.creator_index[cat.video_idx([v])[0] == cat.video_index][0] for v in feed.video_ids + ctx_feed.video_ids}
        assert int(row.creator_idx) not in shown


def test_excluded_previously_recommended_and_consumed_videos_do_not_return(prepared, artefacts, world, active_user):
    base = call(prepared, artefacts, active_user)
    excluded = base.video_ids[:3]
    assert not set(call(prepared, artefacts, active_user, preferences=_prefs(world, active_user, excluded_videos=excluded)).video_ids) & set(excluded)
    second = call(prepared, artefacts, active_user, previously=base.video_ids)
    assert not set(second.video_ids) & set(base.video_ids)
    v = prepared.examples.versions
    consumed_idx = v[(v.user_id == active_user) & v.type.isin([1, 4])].video_idx.unique()
    consumed = set(prepared.catalogue.unique_video_ids[consumed_idx])
    assert consumed and not consumed & set(base.video_ids)


def test_duplicates_are_suppressed_in_feeds(prepared, artefacts, test_requests):
    cat = prepared.catalogue
    for req in test_requests.iloc[::6].itertuples():
        feed = call(prepared, artefacts, req.user_id, req.context, req.as_of)
        ids = feed.video_ids
        assert len(ids) == len(set(ids))
        groups = cat.video_group[cat.video_idx(ids)]
        assert len(groups) == len(set(groups.tolist()))


def test_every_returned_video_is_eligible_at_request_time(prepared, artefacts, test_requests):
    cat = prepared.catalogue
    for req in test_requests.iloc[::5].itertuples():
        feed = call(prepared, artefacts, req.user_id, req.context, req.as_of)
        rows = cat.rows_at(cat.video_idx(feed.video_ids), req.as_of)
        assert cat.live_mask(req.as_of)[rows].all()
        assert (cat.is_short[rows] == (req.context == "short_form")).all()
        assert all("not_recommendable" not in cat.eligibility_labels[r] for r in rows)
        langs = prepared.preferences.get(req.user_id).preferred_languages
        if langs:
            assert all(cat.languages[r] in langs for r in rows)
        assert feed.diagnostics["removed_by_final_eligibility_check"] == 0


def test_unseen_user_and_personalisation_opt_out(prepared, artefacts, world, active_user):
    stranger = call(prepared, artefacts, "user-nobody-has-seen")
    assert len(stranger) > 0 and stranger.diagnostics["personalised"]
    off = call(prepared, artefacts, active_user, preferences=_prefs(world, active_user, personalisation_enabled=False))
    assert len(off) > 0 and not off.diagnostics["personalised"]
    for it in off:
        assert not set(it.retrieval_sources) & set(PERSONALISED_SOURCES)


def test_unseen_videos_get_embeddings_and_can_be_recommended(prepared, artefacts, world):
    videos = world.videos.copy()
    template = videos[videos.duration_seconds <= 120].iloc[0].to_dict()
    cutoff = prepared.examples.cutoff
    new_rows = []
    for i in range(40):
        row = dict(template)
        row.update({"video_id": f"brand_new_{i}", "creator_id": f"brand_new_creator_{i % 4}", "metadata_version": 1,
                    "published_at": pd.Timestamp(cutoff - 3600.0, unit="s", tz="UTC"), "available_from": None,
                    "available_until": None, "duplicate_group_id": None, "eligibility_labels": ["general"],
                    "metadata_valid_from": None})
        new_rows.append(row)
    cat = Catalogue.from_frame(pd.concat([videos, pd.DataFrame(new_rows)], ignore_index=True))
    runtime = artefacts.runtime(cat)
    is_new = np.array([str(v).startswith("brand_new_") for v in cat.video_ids])
    assert np.all(np.isfinite(runtime.video_embeddings[is_new]))
    user = next(u for u in prepared.preferences.user_ids() if template["language"] in (prepared.preferences.get(u).preferred_languages or (template["language"],)))
    with pytest.raises(ValueError, match="rebind"):                       # index spaces must match
        recommend(user_id=user, context="short_form", as_of=cutoff, k=5, catalogue=cat, histories=prepared.histories,
                  preferences=prepared.preferences, artefacts=artefacts)
    histories = prepared.histories.rebind(cat)
    a, b = prepared.histories.items_as_of(user, cutoff), histories.items_as_of(user, cutoff)
    assert list(prepared.catalogue.unique_video_ids[a.video_idx]) == list(cat.unique_video_ids[b.video_idx])
    feeds = [recommend(user_id=user, context="short_form", as_of=cutoff, k=20, catalogue=cat, histories=histories,
                       preferences=prepared.preferences, artefacts=artefacts, previously_recommended=set(), seed=s)
             for s in range(6)]
    shown = [it for f in feeds for it in f if it.video_id.startswith("brand_new_")]
    assert shown, "new videos never received any exposure"
    assert all(len(set(f.video_ids)) == len(f) for f in feeds)


def test_empty_candidate_sets_and_degenerate_requests(prepared, artefacts, world, active_user):
    long_ago = prepared.catalogue.published_at.min() - 86400.0
    empty = call(prepared, artefacts, active_user, as_of=long_ago)
    assert len(empty) == 0 and empty.diagnostics["n_eligible"] == 0 and empty.diagnostics["returned"] == 0
    assert len(call(prepared, artefacts, active_user, k=0)) == 0
    everything = list(prepared.catalogue.unique_video_ids)
    assert len(call(prepared, artefacts, active_user, previously=everything)) == 0
    all_creators = list(prepared.catalogue.unique_creator_ids)
    assert len(call(prepared, artefacts, active_user, preferences=_prefs(world, active_user, blocked_creators=all_creators))) == 0
    few = all_creators[3:]
    short = call(prepared, artefacts, active_user, preferences=_prefs(world, active_user, blocked_creators=few), k=50)
    assert len(short) < 50                                               # insufficient supply: fewer items, no padding
    with pytest.raises(ValueError):
        call(prepared, artefacts, active_user, context="medium_form")


def test_candidate_inspection_and_alternative_indexes(prepared, artefacts, test_requests):
    from aureom_recommend.inference.inspect import score_candidates
    from aureom_recommend.retrieval.index import HAVE_FAISS

    req = test_requests.iloc[3]
    frame = score_candidates(req.user_id, req.context, req.as_of, prepared.catalogue, prepared.histories,
                             prepared.preferences, artefacts)
    feed = call(prepared, artefacts, req.user_id, req.context, req.as_of)
    assert set(feed.video_ids) <= set(frame.video_id) and frame.policy_score.is_monotonic_decreasing
    contrib = frame[[c for c in frame.columns if c.startswith("contribution_")]].sum(axis=1)
    np.testing.assert_allclose(contrib, frame.policy_score)
    if HAVE_FAISS:
        flat = artefacts.with_config(artefacts.config.copy(**{"retrieval.index": "faiss_flat"}))
        hnsw = artefacts.with_config(artefacts.config.copy(**{"retrieval.index": "faiss_hnsw"}))
        assert call(prepared, flat, req.user_id, req.context, req.as_of).video_ids == feed.video_ids
        approx = call(prepared, hnsw, req.user_id, req.context, req.as_of)
        rows = prepared.catalogue.rows_at(prepared.catalogue.video_idx(approx.video_ids), req.as_of)
        assert len(approx) == len(feed) and prepared.catalogue.live_mask(req.as_of)[rows].all()
