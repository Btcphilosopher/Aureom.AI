"""Watch-interval accounting: unique coverage, total playback, re-watching, background, bounds."""
import numpy as np
import pytest

from aureom_recommend.config import Config
from aureom_recommend.data.catalogue import Catalogue
from aureom_recommend.data.events import clean_events
from aureom_recommend.data.intervals import IntervalSet, grouped_union_length, merge_intervals, union_length
from aureom_recommend.data.labels import build_examples
from conftest import event, events_frame, progress, ts, videos_frame

CFG = Config()
CAT = Catalogue.from_frame(videos_frame(duration=60.0))


def labels(rows):
    ev = clean_events(events_frame(rows), CFG, catalogue=CAT)
    return build_examples(ev, CAT, ts(10 * 86400), CFG).impressions.set_index("video_id")


def test_merge_and_union_reference():
    assert merge_intervals([(0, 5), (3, 8), (10, 12), (12, 13), (20, 20)]) == [(0.0, 8.0), (10.0, 13.0)]
    assert union_length([(0, 5), (3, 8), (10, 12)]) == 10.0


def test_incremental_and_vectorised_unions_match_reference():
    rng = np.random.default_rng(0)
    groups, starts, ends = [], [], []
    for g in range(60):
        iv = IntervalSet()
        pairs = []
        for _ in range(int(rng.integers(0, 12))):
            s = float(rng.uniform(0, 100))
            e = s + float(rng.uniform(-2, 30))
            pairs.append((s, e))
            total = iv.add(s, e)
            assert total == pytest.approx(union_length(pairs))
        groups += [g] * len(pairs)
        starts += [p[0] for p in pairs]
        ends += [p[1] for p in pairs]
    got = grouped_union_length(np.array(groups), np.array(starts), np.array(ends), 60)
    for g in range(60):
        ref = union_length([(s, e) for gg, s, e in zip(groups, starts, ends) if gg == g])
        assert got[g] == pytest.approx(ref, abs=1e-6)


def test_overlapping_intervals_are_merged_into_unique_coverage():
    row = labels([event("impression", 0), event("play_start", 1, playback_id="p1"),
                  progress(11, 0, 10), progress(16, 5, 15), progress(26, 15, 25)]).loc["v1"]
    assert row.unique_watched_seconds == pytest.approx(25.0)
    assert row.completion_ratio == pytest.approx(25 / 60)


def test_repeated_and_cumulative_progress_updates_do_not_inflate_playback():
    rows = [event("impression", 0), event("play_start", 1, playback_id="p1"),
            progress(11, 0, 10), progress(21, 0, 20), progress(31, 0, 30),      # cumulative reports
            progress(31, 0, 30), progress(21, 0, 20, delay=40.0)]               # re-sent under new event ids
    row = labels(rows).loc["v1"]
    assert row.unique_watched_seconds == pytest.approx(30.0)
    assert row.total_valid_playback_seconds == pytest.approx(30.0)
    assert row.rewatch_seconds == pytest.approx(0.0)


def test_looping_is_tracked_as_rewatch_not_as_coverage():
    rows = [event("impression", 0, video="v1"), event("play_start", 1, playback_id="p1"),
            progress(61, 0, 60), progress(121, 0, 60), progress(151, 0, 30)]     # 2.5 passes of a 60 s video
    row = labels(rows).loc["v1"]
    assert row.unique_watched_seconds == pytest.approx(60.0)
    assert row.completion_ratio == 1.0                                           # bounded at one
    assert row.total_valid_playback_seconds == pytest.approx(150.0)
    assert row.rewatch_seconds == pytest.approx(90.0)


def test_background_and_unknown_foreground_are_not_valid_viewing():
    rows = [event("impression", 0), event("play_start", 1, playback_id="p1"), progress(11, 0, 10),
            progress(31, 10, 30, fg=False), progress(41, 30, 40, fg=None), event("play_end", 42, playback_id="p1")]
    row = labels(rows).loc["v1"]
    assert row.unique_watched_seconds == pytest.approx(10.0)
    assert row.total_valid_playback_seconds == pytest.approx(10.0)
    assert row.background_seconds == pytest.approx(20.0)
    assert row.unknown_foreground_seconds == pytest.approx(10.0)


def test_invalid_intervals_are_removed_and_small_overruns_clipped():
    rows = [event("impression", 0), event("play_start", 1, playback_id="p1"),
            progress(11, 10, 5),            # reversed
            progress(12, -3, 4),            # negative start
            progress(13, 0, 500),           # far beyond the 60 s video
            progress(62, 50, 61.5)]         # 1.5 s overrun: inside tolerance, clipped to 60
    ev = clean_events(events_frame(rows), CFG, catalogue=CAT)
    assert ev.attrs["report"]["invalid_intervals_removed"] == 3
    assert ev.attrs["report"]["interval_ends_clipped"] == 1
    row = build_examples(ev, CAT, ts(10 * 86400), CFG).impressions.iloc[0]
    assert row.unique_watched_seconds == pytest.approx(10.0)
    assert 0.0 <= row.completion_ratio <= 1.0


def test_meaningful_view_thresholds_depend_on_context():
    # short-form 60 s video: meaningful at >= min(10 s, 50%) = 10 s; early skip below min(2 s, 15%) = 2 s
    rows = [event("impression", 0, video="v1"), event("play_start", 1, video="v1", playback_id="p1"),
            progress(13, 0, 12, video="v1", playback="p1"),
            event("impression", 0, video="v2"), event("play_start", 1, video="v2", playback_id="p2"),
            progress(2.5, 0, 1.5, video="v2", playback="p2"), event("play_end", 3, video="v2", playback_id="p2"),
            event("impression", 0, video="v3"), event("play_start", 1, video="v3", playback_id="p3"),
            progress(7, 0, 6, video="v3", playback="p3"), event("play_end", 8, video="v3", playback_id="p3")]
    out = labels(rows)
    assert bool(out.loc["v1"].meaningful_view) and out.loc["v1"].state == "positive"
    assert bool(out.loc["v2"].early_skip) and out.loc["v2"].state == "early_skip"
    assert out.loc["v3"].state == "partial_view" and not out.loc["v3"].meaningful_view
