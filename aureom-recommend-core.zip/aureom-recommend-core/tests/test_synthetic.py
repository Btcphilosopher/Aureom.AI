import numpy as np
import pandas as pd
import pytest

from aureom_recommend.data.schemas import INTERACTION_COLUMNS, PREFERENCE_COLUMNS, VIDEO_COLUMNS
from aureom_recommend.data.synthetic import (POLICY_UNIFORM, SCENARIOS, Oracle, SyntheticConfig, generate_synthetic,
                                             scenario_config)

TINY = dict(n_users=60, n_videos=150, n_creators=20, n_days=5)


def test_generator_is_deterministic_given_the_seed():
    a, b = generate_synthetic(SyntheticConfig(seed=3, **TINY)), generate_synthetic(SyntheticConfig(seed=3, **TINY))
    pd.testing.assert_frame_equal(a.interactions, b.interactions)
    pd.testing.assert_frame_equal(a.videos.drop(columns="content_embedding"), b.videos.drop(columns="content_embedding"))
    c = generate_synthetic(SyntheticConfig(seed=4, **TINY))
    assert len(c.interactions) != len(a.interactions) or not a.interactions.equals(c.interactions)


def test_latents_stay_out_of_the_contract_tables(world, tmp_path):
    assert set(world.interactions.columns) == set(INTERACTION_COLUMNS)
    assert set(world.preferences.columns) == set(PREFERENCE_COLUMNS)
    assert set(world.videos.columns) == set(VIDEO_COLUMNS) | {"metadata_valid_from"}
    world.save(tmp_path / "data")
    files = {p.name for p in (tmp_path / "data").iterdir()}
    assert {"videos.parquet", "interactions.parquet", "preferences.parquet", "oracle", "SYNTHETIC_DATA.txt"} <= files
    oracle = Oracle.load(tmp_path / "data" / "oracle")
    user, vids = world.oracle.user_ids[0], world.oracle.video_ids[:5]
    np.testing.assert_allclose(oracle.utility(user, vids), world.oracle.utility(user, vids))
    assert np.isnan(oracle.utility("unknown-user", vids)).all() and np.isnan(oracle.utility(user, ["nope"])).all()


def test_no_feature_or_model_module_imports_the_simulator():
    import pathlib

    import aureom_recommend
    root = pathlib.Path(aureom_recommend.__file__).parent
    allowed = {"cli.py", "scenarios.py", "synthetic.py"}
    for path in root.rglob("*.py"):
        if path.name in allowed:
            continue
        text = path.read_text()
        assert "data.synthetic" not in text and "from .synthetic" not in text, path


def test_world_contains_the_phenomena_the_pipeline_must_handle(world, prepared):
    ev = world.interactions
    assert ev.event_id.duplicated().any()                                         # duplicate deliveries
    lateness = (ev.received_at - ev.occurred_at).dt.total_seconds()
    assert (lateness > 3600).any() and (lateness > 48 * 3600).any()               # delayed and too-late events
    assert {"dislike", "block_creator", "survey_response", "not_interested", "like", "save"} <= set(ev.event_type)
    surveys = (ev.event_type == "survey_response").sum() / (ev.event_type == "play_start").sum()
    assert 0.01 < surveys < 0.15                                                  # sparse satisfaction feedback
    prop = ev[ev.selection_propensity.notna()]
    assert set(prop.logging_policy_id) <= {POLICY_UNIFORM, "biased_popularity_v1"}
    valid = prop[prop.selection_propensity > 0]
    assert set(valid.logging_policy_id) == {POLICY_UNIFORM} and set(valid.playback_context) == {"long_form"}
    vids = world.videos
    assert vids.duplicate_group_id.notna().sum() >= 2 and (vids.metadata_version == 2).any()
    assert vids.language.nunique() >= 2 and vids.content_embedding.isna().any()
    assert (vids.duration_seconds <= 120).any() and (vids.duration_seconds > 120).any()
    exposure = prepared.impressions.groupby(prepared.catalogue.creator_index[prepared.impressions.row]).size()
    assert exposure.sort_values(ascending=False).head(5).sum() / exposure.sum() > 0.15    # creator imbalance
    first_seen = pd.Series({u: prepared.histories.first_seen(u) for u in prepared.histories.user_ids()})
    assert (first_seen > prepared.splits.retrieval_train_end).any()               # users who arrive late
    assert (prepared.catalogue.published_at > prepared.splits.calibration_end).any()   # videos published in the test window


def test_scenarios_are_distinct_worlds():
    assert set(SCENARIOS) == {"default", "preference_recovery", "duration_bias", "popularity_bias", "cold_start"}
    assert scenario_config("preference_recovery").uniform_everywhere and scenario_config("duration_bias").duration_bias > 1
    assert scenario_config("cold_start", seed=5).seed == 5
    with pytest.raises(KeyError):
        scenario_config("nonexistent")
    uniform = generate_synthetic(scenario_config("preference_recovery", **TINY))
    imps = uniform.interactions[uniform.interactions.event_type == "impression"]
    assert set(imps.logging_policy_id) <= {POLICY_UNIFORM, "uniform_random_unlogged_v1"}
    assert imps.loc[imps.playback_context == "short_form", "selection_propensity"].isna().all()
