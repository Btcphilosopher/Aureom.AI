import numpy as np
import pandas as pd

from aureom_recommend.config import DurationConfig
from aureom_recommend.features.duration import DurationBaseline
from aureom_recommend.training.splits import window_examples


def _frame(n=6000, seed=0):
    rng = np.random.default_rng(seed)
    ctx = rng.integers(0, 2, n)
    dur = np.where(ctx == 0, rng.uniform(5, 120, n), rng.uniform(180, 3600, n))
    # completion falls with duration: the bias the target has to remove
    comp = np.clip(rng.beta(2, 2, n) * (1.3 - 0.5 * (np.log(dur) - np.log(dur).min()) / np.ptp(np.log(dur))), 0, 1)
    played = rng.random(n) < 0.8
    return pd.DataFrame({"context_idx": ctx, "duration_seconds": dur, "completion_ratio": np.where(played, comp, 0.0),
                         "unique_watched_seconds": np.where(played, comp * dur, 0.0), "has_play": played,
                         "view_observed": True, "m_duration": 1.0})


def test_target_is_bounded_monotone_and_zero_without_play():
    df = _frame()
    base = DurationBaseline.fit(df, DurationConfig(n_buckets=6, min_bucket_count=100))
    out = base.transform(df)
    y = out["duration_adjusted_viewing"].to_numpy()
    assert y.min() >= 0.0 and y.max() <= 1.0
    assert (y[~df.has_play.to_numpy()] == 0).all()
    grid = np.linspace(0, 1, 21)
    vals = base.adjusted(np.zeros(21, int), np.full(21, 30.0), grid, np.ones(21, bool))
    assert np.all(np.diff(vals) >= 0)


def test_target_removes_the_duration_trend_that_raw_measures_have():
    df = _frame()
    out = DurationBaseline.fit(df, DurationConfig(n_buckets=8, min_bucket_count=100)).transform(df)
    played = out[out.has_play & (out.context_idx == 0)]
    buckets = pd.qcut(played.duration_seconds, 5)
    adj = played.groupby(buckets, observed=True)["duration_adjusted_viewing"].mean().to_numpy()
    comp = played.groupby(buckets, observed=True)["completion_ratio"].mean().to_numpy()
    secs = played.groupby(buckets, observed=True)["unique_watched_seconds"].mean().to_numpy()
    assert np.ptp(adj) < 0.05 and abs(adj.mean() - 0.5) < 0.03       # flat and centred
    assert comp[0] - comp[-1] > 0.04                                  # completion favours short videos
    assert secs[-1] / secs[0] > 2                                     # seconds favour long videos


def test_baseline_is_fitted_on_training_rows_only():
    train, later = _frame(seed=1), _frame(seed=2)
    cfg = DurationConfig(n_buckets=5, min_bucket_count=100)
    a = DurationBaseline.fit(train, cfg)
    later_shifted = later.assign(completion_ratio=1.0)                # extreme future data
    y1 = a.transform(later)["y_duration"].to_numpy()
    y2 = a.transform(pd.concat([later, later_shifted]))["y_duration"].to_numpy()[:len(later)]
    np.testing.assert_array_equal(y1, y2)                             # transforming never refits
    b = DurationBaseline.from_dict(a.to_dict())
    np.testing.assert_array_equal(b.transform(later)["y_duration"].to_numpy(), y1)


def test_ablation_targets_and_sparse_buckets():
    df = _frame(n=150)
    base = DurationBaseline.fit(df, DurationConfig(n_buckets=10, min_bucket_count=100))
    assert all(len(ctx) >= 1 for ctx in base.references)              # buckets merged down, never empty
    for target in ("duration_adjusted", "completion_ratio", "capped_watch_seconds"):
        y = base.transform(df, target)["y_duration"].to_numpy()
        assert y.min() >= 0 and y.max() <= 1
    empty = DurationBaseline.fit(df.iloc[:0], DurationConfig())
    assert empty.transform(df)["y_duration"].between(0, 1).all()      # identity fallback still bounded


def test_pipeline_uses_training_windows_for_the_baseline(prepared, artefacts):
    sp = prepared.splits
    train = window_examples(prepared.impressions, sp.start, sp.ranker_train_end)
    played = train[(train.m_duration > 0) & train.has_play]
    assert artefacts.duration_baseline.n_fit == len(played)
    assert train.t.max() < sp.ranker_train_end
