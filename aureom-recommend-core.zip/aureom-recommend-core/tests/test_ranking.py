import numpy as np
import pytest
import torch

from aureom_recommend.config import Config, PolicyConfig
from aureom_recommend.constants import TASKS
from aureom_recommend.ranking.calibration import PlattCalibrator, fit_platt
from aureom_recommend.ranking.features import DENSE_FEATURES, POSITION_FEATURE
from aureom_recommend.ranking.loss import l2_penalty, masked_multitask_loss
from aureom_recommend.ranking.model import MultiTaskRanker, RankerDims
from aureom_recommend.ranking.policy import RankingPolicy
from aureom_recommend.ranking.ranker import Ranker
from aureom_recommend.training.ranker import zero_position


def test_policy_contributions_sum_to_the_score_and_weights_are_configurable():
    preds = {t: np.array([0.2, 0.9]) for t in TASKS}
    policy = RankingPolicy.from_config(PolicyConfig())
    total, contrib = policy.score(preds)
    np.testing.assert_allclose(total, sum(contrib.values()))
    assert (contrib["negative"] < 0).all() and policy.version == "policy-v1"
    zero = RankingPolicy.from_config(PolicyConfig(w_meaningful=0, w_duration=0, w_positive=0, w_satisfaction=0, w_negative=1))
    np.testing.assert_allclose(zero.score(preds)[0], -preds["negative"])


def test_platt_calibration_recovers_a_known_distortion_and_needs_support():
    rng = np.random.default_rng(0)
    z_true = rng.normal(-1.0, 1.5, 20000)
    y = (rng.random(20000) < 1 / (1 + np.exp(-z_true))).astype(float)
    distorted = (z_true - 0.7) / 1.8
    cal = fit_platt(distorted, y, binary=True)
    assert cal.fitted and cal.a == pytest.approx(1.8, rel=0.1) and cal.b == pytest.approx(0.7, abs=0.15)
    p = cal.apply(distorted)
    assert abs(p.mean() - y.mean()) < 0.01
    few = fit_platt(distorted[:50], y[:50], binary=True)
    assert not few.fitted and few.apply(np.array([0.0]))[0] == 0.5 and "identity" in few.status
    one_class = fit_platt(distorted[:500], np.zeros(500), binary=True)
    assert not one_class.fitted and "minority class" in one_class.status
    soft = fit_platt(distorted, 1 / (1 + np.exp(-z_true)), binary=False)             # bounded regression target
    assert soft.fitted and soft.a == pytest.approx(1.8, rel=0.05)
    assert PlattCalibrator.from_dict(cal.to_dict()) == cal


def test_positive_weight_is_undone_by_the_prior_correction():
    cfg = Config()
    dims = RankerDims(n_dense=len(DENSE_FEATURES), tower_dim=4, n_creators=3, n_languages=3)
    torch.manual_seed(0)
    model = MultiTaskRanker(dims, cfg.ranker)
    feats = {"dense": np.zeros((5, dims.n_dense), "float32"), "creator": np.ones(5, "int64"),
             "language": np.ones(5, "int64"), "context": np.zeros(5, "int64"),
             "user_vec": np.zeros((5, 4), "float32"), "video_vec": np.zeros((5, 4), "float32")}
    mean, std = np.zeros(dims.n_dense), np.ones(dims.n_dense)
    plain = Ranker(model, dims, cfg, mean, std).logits(feats)
    weighted = Ranker(model, dims, cfg, mean, std, pos_weights={"negative": 8.0, "duration": 8.0}).logits(feats)
    j = TASKS.index("negative")
    np.testing.assert_allclose(weighted[:, j], plain[:, j] - np.log(8.0), rtol=1e-6)
    np.testing.assert_allclose(np.delete(weighted, j, axis=1), np.delete(plain, j, axis=1))   # bounded heads untouched
    # the weighted loss really is minimised at inflated odds, which is what the correction removes
    y = torch.tensor([[1.0], [0.0], [0.0], [0.0]])
    z = torch.zeros(1, requires_grad=True)
    opt = torch.optim.LBFGS([z], lr=0.5, max_iter=200)

    def closure():
        opt.zero_grad()
        loss, _ = masked_multitask_loss(z.expand(4, 1), y, torch.ones(4, 1), ["negative"], {"negative": 1.0}, {"negative": 3.0})
        loss.backward()
        return loss

    opt.step(closure)
    assert z.item() - np.log(3.0) == pytest.approx(np.log(0.25 / 0.75), abs=1e-3)


def test_l2_penalty_and_position_feature():
    lin = torch.nn.Sequential(torch.nn.Linear(2, 2), torch.nn.Embedding(3, 2))
    assert l2_penalty(lin).item() == pytest.approx((lin[0].weight ** 2).sum().item())
    feats = {"dense": np.ones((3, len(DENSE_FEATURES)), "float32")}
    z = zero_position(feats)
    assert (z["dense"][:, POSITION_FEATURE] == 0).all() and (feats["dense"][:, POSITION_FEATURE] == 1).all()
    assert DENSE_FEATURES[POSITION_FEATURE] == "log_position"


def test_trained_ranker_outputs_probabilities_and_reports_calibration(prepared, artefacts):
    report = artefacts.report["ranker"]
    assert set(report["calibration"]) == set(TASKS)
    assert report["label_support_train"]["satisfaction"] < report["label_support_train"]["meaningful"]
    for task, cal in report["calibration"].items():
        assert cal["fitted"] or cal["status"].startswith("identity")
    assert artefacts.ranker.pos_weights["meaningful"] == 1.0
    assert all(w >= 1.0 for w in artefacts.ranker.pos_weights.values())
