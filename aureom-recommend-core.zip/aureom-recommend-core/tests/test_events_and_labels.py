"""Event cleaning, outcome attribution, observation states and missing-label masking."""
import numpy as np
import pandas as pd
import pytest
import torch

from aureom_recommend.config import Config
from aureom_recommend.constants import TASKS
from aureom_recommend.data.catalogue import Catalogue
from aureom_recommend.data.events import clean_events
from aureom_recommend.data.labels import build_examples
from aureom_recommend.ranking.loss import masked_multitask_loss
from conftest import event, events_frame, prefs_frame, progress, ts, videos_frame

CFG = Config()
CAT = Catalogue.from_frame(videos_frame(duration=60.0))
W, G = CFG.labels.outcome_window_seconds, CFG.labels.late_arrival_grace_seconds


def build(rows, cutoff=10 * 86400, prefs=None):
    ev = clean_events(events_frame(rows), CFG, preferences=prefs, catalogue=CAT)
    return ev, build_examples(ev, CAT, ts(cutoff), CFG)


def test_duplicate_event_ids_keep_the_earliest_delivery_regardless_of_order():
    rows = [event("impression", 0, event_id="dup", delay=50.0), event("impression", 0, event_id="dup", delay=2.0),
            event("like", 5, event_id="x")]
    a = clean_events(events_frame(rows), CFG)
    b = clean_events(events_frame(rows[::-1]), CFG)
    assert a.attrs["report"]["duplicate_event_ids_removed"] == 1
    assert len(a) == 2 and a.event_id.tolist() == b.event_id.tolist()
    assert a.loc[a.event_id == "dup", "t_received"].iloc[0] == b.loc[b.event_id == "dup", "t_received"].iloc[0]
    assert (a.loc[a.event_id == "dup", "t_received"] - a.loc[a.event_id == "dup", "t_occurred"]).iloc[0] == pytest.approx(2.0)


def test_events_are_sorted_and_late_or_clock_broken_events_dropped():
    rows = [event("like", 50), event("impression", 10), event("like", 20, delay=3 * 86400),     # too late
            event("like", 30, delay=-3600)]                                                     # clock error
    ev = clean_events(events_frame(rows), CFG)
    assert ev.t_occurred.is_monotonic_increasing and len(ev) == 2
    assert ev.attrs["report"]["too_late_removed"] == 1 and ev.attrs["report"]["received_before_occurred_removed"] == 1


def test_activity_before_a_personalisation_reset_is_excluded():
    prefs = prefs_frame(users=("u1", "u2"), history_reset_at=[ts(100.0), None])
    rows = [event("impression", 10, user="u1"), event("impression", 200, user="u1", request="r2"),
            event("impression", 10, user="u2", request="r3")]
    ev = clean_events(events_frame(rows), CFG, preferences=prefs)
    assert ev.attrs["report"]["before_history_reset_removed"] == 1
    assert sorted(ev.request_id.tolist()) == ["r2", "r3"]


def test_observation_states_are_distinguished():
    rows = [
        event("impression", 0, video="v1"),                                                         # no play
        event("impression", 0, video="v2"), event("play_start", 1, video="v2", playback_id="p2"),
        progress(2, 0, 1, video="v2", playback="p2"), event("play_end", 3, video="v2", playback_id="p2"),   # early skip
        event("impression", 0, video="v3"), event("play_start", 1, video="v3", playback_id="p3"),
        progress(31, 0, 30, video="v3", playback="p3"),                                             # positive
        event("impression", 0, video="v4"), event("dislike", 5, video="v4"),                        # explicit negative
        event("impression", 0, video="v5"), event("play_start", 1, video="v5", playback_id="p5"),   # play, nothing else
    ]
    _, ex = build(rows)
    out = ex.impressions.set_index("video_id")
    assert out.state.to_dict() == {"v1": "impression_no_play", "v2": "early_skip", "v3": "positive",
                                   "v4": "explicit_negative", "v5": "incomplete"}
    # v6 was never shown: it has no row at all
    assert "v6" not in out.index
    # incomplete observation: the viewing labels are masked, feedback labels are not
    assert out.loc["v5", ["m_meaningful", "m_duration"]].tolist() == [0.0, 0.0]
    assert out.loc["v5", "m_like_or_save"] == 1.0
    # no play is an observed zero for the viewing heads
    assert out.loc["v1", ["m_meaningful", "y_meaningful"]].tolist() == [1.0, 0.0]


def test_missing_satisfaction_is_masked_not_treated_as_dissatisfaction():
    rows = [event("impression", 0, video="v1"), event("survey_response", 30, video="v1", explicit_feedback=5.0),
            event("impression", 0, video="v2"), event("survey_response", 30, video="v2", explicit_feedback=1.0),
            event("impression", 0, video="v3")]
    _, ex = build(rows)
    out = ex.impressions.set_index("video_id")
    assert out.m_satisfaction.to_dict() == {"v1": 1.0, "v2": 1.0, "v3": 0.0}
    assert out.loc["v1", "y_satisfaction"] == 1.0 and out.loc["v2", "y_satisfaction"] == 0.0
    assert np.isnan(out.loc["v3", "satisfaction_rating"])


def test_unmatured_impressions_are_fully_masked_and_labels_freeze_at_maturity():
    rows = [event("impression", 0, video="v1"), event("like", 60, video="v1"),
            event("like", 60, video="v1", delay=W + G + 500),            # arrives after maturity: ignored for the label
            event("impression", 0, video="v2"), event("dislike", W + 100, video="v2")]   # outside the outcome window
    _, early = build(rows, cutoff=W)                                      # window not matured yet
    assert (early.impressions[[f"m_{t}" for t in TASKS]].to_numpy() == 0).all()
    assert (early.impressions.state == "incomplete").all()
    _, at = build(rows, cutoff=W + G + 1)
    _, later = build(rows, cutoff=30 * 86400)
    cols = ["state"] + [f"y_{t}" for t in TASKS] + [f"m_{t}" for t in TASKS]
    pd.testing.assert_frame_equal(at.impressions[cols], later.impressions[cols])
    out = later.impressions.set_index("video_id")
    assert out.loc["v1", "state"] == "positive" and out.loc["v2", "state"] == "impression_no_play"


def test_outcomes_are_associated_with_the_originating_impression():
    rows = [event("impression", 0, video="v1", request="r1"), event("impression", 100, video="v1", request="r2"),
            event("like", 150, video="v1", request=None),               # no request id: latest earlier impression
            event("impression", 0, video="v2", request="r1"), event("like", 20, video="v2", request="r1"),
            event("play_start", 5, video="v3", request=None, playback_id="px"),          # organic, never shown
            progress(40, 0, 30, video="v3", playback="px", request=None)]
    _, ex = build(rows)
    out = ex.impressions.set_index(["request_id", "video_id"])
    assert out.loc[("r2", "v1"), "liked_or_saved"] and not out.loc[("r1", "v1"), "liked_or_saved"]
    assert out.loc[("r1", "v2"), "liked_or_saved"]
    assert ex.report["outcomes_fallback_attribution"] == 1 and ex.report["outcomes_unattributed"] == 2
    assert "v3" not in ex.impressions.video_id.tolist()                  # no impression row is fabricated
    assert CAT.video_idx(["v3"])[0] in ex.versions.video_idx.tolist()     # ...but the organic view is still history


def test_masked_loss_ignores_unobserved_labels_and_skips_empty_tasks():
    torch.manual_seed(0)
    logits = torch.randn(6, len(TASKS), requires_grad=True)
    y = torch.rand(6, len(TASKS))
    m = torch.ones(6, len(TASKS))
    m[:, 3] = 0.0                      # satisfaction: no label in the batch
    m[2:, 0] = 0.0                     # meaningful: only two labels
    weights = {t: 1.0 for t in TASKS}
    loss, per_task = masked_multitask_loss(logits, y, m, TASKS, weights)
    assert "satisfaction" not in per_task and set(per_task) == set(TASKS) - {"satisfaction"}
    loss.backward()
    assert torch.all(logits.grad[:, 3] == 0) and torch.all(logits.grad[2:, 0] == 0)
    assert torch.any(logits.grad[:2, 0] != 0)
    y2 = y.clone()
    y2[:, 3] = 1.0 - y[:, 3]           # changing masked targets must not change the loss
    y2[2:, 0] = 1.0 - y[2:, 0]
    loss2, _ = masked_multitask_loss(logits, y2, m, TASKS, weights)
    assert loss2.item() == pytest.approx(loss.item())
    none, per = masked_multitask_loss(logits, y, torch.zeros_like(m), TASKS, weights)
    assert none.item() == 0.0 and per == {}
