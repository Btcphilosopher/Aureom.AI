import numpy as np

from aureom_recommend.config import CompositionConfig
from aureom_recommend.composition.rerank import compose_feed


def _inputs(n=30, n_creators=6, n_topics=4, seed=0):
    rng = np.random.default_rng(seed)
    vec = rng.normal(size=(n, 8))
    vec /= np.linalg.norm(vec, axis=1, keepdims=True)
    topics = np.zeros((n, n_topics), bool)
    topics[np.arange(n), rng.integers(0, n_topics, n)] = True
    return dict(scores=np.linspace(1.0, 0.1, n), creators=rng.integers(0, n_creators, n), topic_matrix=topics,
                groups=np.arange(n), content_vectors=vec, age_seconds=np.full(n, 86400.0), consumed=np.zeros(n, bool),
                sources=[("two_tower",)] * n, exploration_details=[None] * n)


def run(inputs, k=10, seed=0, **cfg):
    config = CompositionConfig(**{"max_exploration_slots": 0, **cfg})
    return compose_feed(k=k, config=config, rng=np.random.default_rng(seed), **inputs)


def test_creator_cap_and_topic_concentration_are_enforced_when_supply_allows():
    inp = _inputs(n=60)
    out = run(inp, k=10, max_per_creator=2, max_topic_share=0.3)
    creators = inp["creators"][out.order]
    assert np.bincount(creators).max() <= 2
    assert inp["topic_matrix"][out.order].sum(axis=0).max() <= 3
    assert out.relaxations == [] and len(out.order) == 10


def test_exact_duplicates_are_always_suppressed_and_near_duplicates_by_threshold():
    inp = _inputs(n=12)
    inp["groups"] = np.array([0, 0, 0, 1, 1, 2, 3, 4, 5, 6, 7, 8])       # videos 0-2 are copies, 3-4 are copies
    inp["content_vectors"][6] = inp["content_vectors"][5]                # 6 is a near-duplicate of 5 (different group)
    out = run(inp, k=12, max_per_creator=99, max_topic_share=1.0, lambda_diversity=0.0)
    groups = inp["groups"][out.order]
    assert len(groups) == len(set(groups.tolist())) == 9                 # never two items from one duplicate group
    # the near-duplicate is admitted only after the soft rule had to be relaxed, and that is recorded
    assert 6 in out.order and out.order.index(6) == len(out.order) - 1
    assert [r["relaxed"] for r in out.relaxations][-1] == "near_duplicate"
    strict = run(inp, k=8, max_per_creator=99, max_topic_share=1.0, lambda_diversity=0.0)
    assert 6 not in strict.order


def test_soft_constraints_relax_in_the_documented_order_and_hard_ones_never():
    inp = _inputs(n=8)
    inp["creators"] = np.zeros(8, int)                                   # a single creator
    inp["topic_matrix"] = np.ones((8, 1), bool)                          # a single topic
    out = run(inp, k=6, max_per_creator=1, max_topic_share=0.2)
    assert len(out.order) == 6
    assert [r["relaxed"] for r in out.relaxations] == ["topic_concentration", "creator_cap"]
    inp["groups"] = np.zeros(8, int)                                     # everything is one duplicate group
    out = run(inp, k=6, max_per_creator=1, max_topic_share=0.2)
    assert len(out.order) == 1                                           # shorter feed rather than a duplicate


def test_diversity_penalty_and_freshness_change_the_order():
    inp = _inputs(n=6)
    inp["content_vectors"][:] = inp["content_vectors"][0]
    inp["content_vectors"][5] = -inp["content_vectors"][0]               # the lowest-scored item is the only different one
    plain = run(inp, k=3, lambda_diversity=0.0, lambda_freshness=0.0, near_duplicate_similarity=2.0, max_per_creator=99, max_topic_share=1.0)
    diverse = run(inp, k=3, lambda_diversity=2.0, lambda_freshness=0.0, near_duplicate_similarity=2.0, max_per_creator=99, max_topic_share=1.0)
    assert plain.order == [0, 1, 2] and diverse.order[:2] == [0, 5]
    assert diverse.diversity_penalties[0] == 0.0 and diverse.diversity_penalties[2] > 0
    inp["age_seconds"] = np.array([86400.0 * 60] * 5 + [0.0])
    fresh = run(inp, k=1, lambda_diversity=0.0, lambda_freshness=5.0, near_duplicate_similarity=2.0)
    assert fresh.order == [5] and 0 < fresh.freshness_bonuses[0] <= 5.0


def test_consumed_content_can_be_demoted():
    inp = _inputs(n=5)
    inp["consumed"][0] = True
    demote = run(inp, k=5, consumed_handling="demote", consumed_penalty=10.0, lambda_freshness=0.0, lambda_diversity=0.0, max_per_creator=99, max_topic_share=1.0)
    allow = run(inp, k=5, consumed_handling="allow", lambda_freshness=0.0, lambda_diversity=0.0, max_per_creator=99, max_topic_share=1.0)
    assert demote.order[-1] == 0 and allow.order[0] == 0


def test_exploration_is_bounded_seeded_and_reports_sampling_details():
    inp = _inputs(n=40)
    explore = list(range(30, 40))
    for i in explore:
        inp["sources"][i] = ("exploration",)
        inp["exploration_details"][i] = {"pool": "new_videos", "pool_size": 50, "n_drawn": 10, "candidate_draw_probability": 0.2}
    kwargs = dict(k=12, max_exploration_slots=2, exploration_positions=(3, 7, 9), max_per_creator=99, max_topic_share=1.0)
    a, b = run(inp, seed=5, **kwargs), run(inp, seed=5, **kwargs)
    assert a.order == b.order                                            # same seed, same feed
    flagged = [j for j, e in enumerate(a.exploration) if e]
    assert flagged == [3, 7]                                             # at most max_exploration_slots, at configured positions
    for j in flagged:
        info = a.exploration[j]
        assert a.order[j] in explore and info["is_exploration"]
        assert info["slot_choice_probability"] == 1.0 / info["slot_choice_set_size"]
        assert info["candidate_draw_probability"] == 0.2 and info["slate_probability"] is None
    orders = {tuple(run(inp, seed=s, **kwargs).order) for s in range(8)}
    assert len(orders) > 1                                               # the draw really is random across seeds
    none = run(inp, k=12, max_exploration_slots=0)
    assert not any(none.exploration)


def test_empty_and_short_supply():
    inp = _inputs(n=3)
    assert len(run(inp, k=10).order) == 3
    empty = {k: (v[:0] if isinstance(v, np.ndarray) else []) for k, v in inp.items()}
    assert run(empty, k=10).order == []
    assert run(inp, k=0).order == []
