import numpy as np
import pandas as pd
import pytest

from aureom_recommend.data.catalogue import Catalogue
from aureom_recommend.data.schemas import (SchemaError, UserPreferences, validate_interactions, validate_preferences,
                                           validate_videos)
from conftest import event, events_frame, prefs_frame, ts, videos_frame


def test_missing_required_column_is_rejected():
    with pytest.raises(SchemaError):
        validate_videos(videos_frame().drop(columns=["duration_seconds"]))
    with pytest.raises(SchemaError):
        validate_interactions(events_frame([event("impression", 0)]).drop(columns=["received_at"]))


def test_optional_values_may_be_missing():
    vids, report = validate_videos(videos_frame())
    assert report.rows_out == 6 and vids["available_until"].isna().all()
    ev, _ = validate_interactions(events_frame([event("impression", 0, session_id=None, position=np.nan)]))
    assert len(ev) == 1 and ev["session_id"].iloc[0] is None
    prefs, _ = validate_preferences(prefs_frame())
    assert prefs["history_reset_at"].isna().all()
    assert UserPreferences("u").personalisation_enabled is True


def test_propensities_are_never_invented_and_invalid_ones_are_nulled():
    rows = [
        event("impression", 0, video="v1", logging_policy_id="p", selection_propensity=0.25),   # valid
        event("impression", 0, video="v2", logging_policy_id="p", selection_propensity=0.0),    # not a probability > 0
        event("impression", 0, video="v3", logging_policy_id="p", selection_propensity=1.5),    # > 1
        event("impression", 0, video="v4", logging_policy_id=None, selection_propensity=0.5),   # no policy id
        event("impression", 0, video="v5", logging_policy_id="p"),                              # none supplied
        event("like", 1, video="v1", logging_policy_id="p", selection_propensity=0.5),          # not an impression
    ]
    ev, report = validate_interactions(events_frame(rows))
    p = ev.set_index("video_id")["selection_propensity"]
    imp = ev[ev.event_type == "impression"].set_index("video_id")["selection_propensity"]
    assert imp["v1"] == 0.25
    assert imp[["v2", "v3", "v4", "v5"]].isna().all()
    assert ev[ev.event_type == "like"]["selection_propensity"].isna().all()
    assert report.nullified["invalid_selection_propensity"] == 4
    assert p.notna().sum() == 1


def test_invalid_rows_are_dropped_and_counted():
    rows = [event("impression", 0), event("teleport", 1), event("survey_response", 2),
            event("progress", 3, watched_interval_start=0, watched_interval_end=5)]      # progress without playback id
    ev, report = validate_interactions(events_frame(rows))
    assert len(ev) == 1
    assert report.dropped == {"unknown_event_type": 1, "survey_without_rating": 1, "progress_without_playback_id": 1}
    with pytest.raises(SchemaError):
        validate_interactions(events_frame(rows), strict=True)


def test_video_validation_rules():
    vids = videos_frame()
    vids.loc[0, "duration_seconds"] = -1.0
    out, report = validate_videos(pd.concat([vids, vids.iloc[[1]]], ignore_index=True))
    assert report.dropped["non_positive_duration"] == 1 and report.dropped["duplicate_video_version"] == 1
    assert len(out) == 5
    bad = videos_frame()
    bad["content_embedding"] = [np.zeros(4, "float32")] * 5 + [np.zeros(3, "float32")]
    with pytest.raises(SchemaError):
        validate_videos(bad)


def test_later_metadata_versions_need_a_validity_time():
    vids = videos_frame()
    v2 = vids.iloc[[0]].copy()
    v2["metadata_version"] = 2
    with pytest.raises(SchemaError):
        validate_videos(pd.concat([vids, v2], ignore_index=True))
    v2["metadata_valid_from"] = ts(100.0)
    cat = Catalogue.from_frame(pd.concat([vids.assign(metadata_valid_from=pd.NaT), v2], ignore_index=True))
    rows = np.flatnonzero(cat.video_ids == "v1")
    assert cat.version_live_mask(cat.published_at[rows[0]] + 1)[rows].tolist() == [True, False]
    assert cat.version_live_mask(cat.valid_from[rows[1]] + 1)[rows].tolist() == [False, True]


def test_preferences_duplicates_and_defaults():
    prefs, report = validate_preferences(prefs_frame(users=("u1", "u1", "u2")))
    assert len(prefs) == 2 and report.dropped["duplicate_user_id"] == 1
    assert prefs["selected_topics"].iloc[0] == ()
