#!/usr/bin/env python
"""Thin wrapper around ``aureom_recommend.cli.evaluate_main`` (run with --help for options)."""
import sys

from aureom_recommend.cli import evaluate_main

if __name__ == "__main__":
    sys.exit(evaluate_main())
