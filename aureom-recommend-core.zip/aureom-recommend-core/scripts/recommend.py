#!/usr/bin/env python
"""Thin wrapper around ``aureom_recommend.cli.recommend_main`` (run with --help for options)."""
import sys

from aureom_recommend.cli import recommend_main

if __name__ == "__main__":
    sys.exit(recommend_main())
