#!/usr/bin/env python
"""Thin wrapper around ``aureom_recommend.cli.ablations_main`` (run with --help for options)."""
import sys

from aureom_recommend.cli import ablations_main

if __name__ == "__main__":
    sys.exit(ablations_main())
