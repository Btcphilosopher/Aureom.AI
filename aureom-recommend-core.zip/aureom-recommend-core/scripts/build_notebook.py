#!/usr/bin/env python
"""Create (and optionally execute) notebooks/baselines_vs_learned.ipynb.

    python scripts/build_notebook.py --execute

The notebook is generated from this file so that it stays in sync with the package API.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import nbformat
from nbformat.v4 import new_code_cell, new_markdown_cell, new_notebook

CELLS: list[tuple[str, str]] = [
    ("md", """# AUREOM RECOMMEND — baselines vs. learned models

> **Everything in this notebook is SYNTHETIC.** The data comes from the seeded simulator in
> `aureom_recommend.data.synthetic`. The notebook demonstrates that the algorithm runs end to end and
> how its stages behave in a world with known ground truth; it is not evidence about real users.

Stages: generate a world → clean events and build labels → fit baselines → train the two-tower
retriever and the multitask ranker chronologically → evaluate retrieval, ranking and full feeds →
ablations. The world here is smaller than the one behind `docs/results.md` so the notebook runs in a
few minutes on a CPU; numbers therefore differ from that document."""),
    ("code", """import time, warnings
from pathlib import Path

import numpy as np
import pandas as pd
from IPython.display import Image, display

warnings.filterwarnings("ignore")
pd.set_option("display.width", 200, "display.max_columns", 30, "display.float_format", lambda x: f"{x:.3f}")

from aureom_recommend import (Config, build_evaluation_requests, evaluate_recommender, prepare_data, recommend,
                              train_pipeline, window_examples)
from aureom_recommend.data.synthetic import generate_synthetic, scenario_config
from aureom_recommend.evaluation import plots, report
from aureom_recommend.evaluation.propensity import propensity_weighted_evaluation
from aureom_recommend.evaluation.ranking_eval import evaluate_ranking
from aureom_recommend.evaluation.retrieval_eval import evaluate_candidate_generation, evaluate_retrieval, two_tower_scorer
from aureom_recommend.evaluation.scenarios import VALID_SYNTHETIC_PROPENSITY_POLICIES
from aureom_recommend.training.ranker import build_ranking_data

OUT = Path("_out"); OUT.mkdir(exist_ok=True)
config = Config()                       # package defaults == configs/default.toml
config.evaluation.max_eval_requests = 700
print("config hash:", config.config_hash())"""),
    ("md", "## 1. Synthetic world"),
    ("code", """tic = time.time()
world = generate_synthetic(scenario_config("default", n_users=700, n_videos=1500, n_creators=110, n_days=30))
print(f"generated in {time.time() - tic:.1f}s:", world.summary)
display(world.interactions.event_type.value_counts().to_frame("events").T)
world.videos[["video_id", "creator_id", "language", "topic_ids", "duration_seconds", "published_at", "duplicate_group_id", "metadata_version"]].head(4)"""),
    ("md", """## 2. Event cleaning and label construction

`prepare_data` validates the three tables, cleans events, attributes outcomes to impressions, applies
the outcome window and builds point-in-time histories and temporal splits."""),
    ("code", """tic = time.time()
prepared = prepare_data(world.videos, world.interactions, world.preferences, config)
print(f"prepared in {time.time() - tic:.1f}s")
ev = prepared.reports["events"]
display(pd.Series({k: v for k, v in ev.items() if k != "schema"}, name="events").to_frame().T)
display(pd.Series(prepared.reports["examples"]["state_counts"], name="impressions by observation state").to_frame().T)
display(pd.Series(prepared.reports["examples"]["mask_counts"], name="usable labels per task").to_frame().T)
days = lambda a, b: f"{(b - a) / 86400:.1f} d"
sp = prepared.splits
pd.Series({n: days(*sp.window(n)) for n in ("retrieval_train", "retrieval_valid", "ranker_train", "ranker_valid", "calibration", "test")}, name="window length").to_frame().T"""),
    ("md", """### Duration bias and the duration-adjusted target

Raw completion falls with video length while raw watch seconds rise. The duration-adjusted target
(fitted on training windows only) is flat across duration buckets."""),
    ("code", """from aureom_recommend.training.pipeline import fit_duration_targets
baseline = fit_duration_targets(prepared, config)
imps = prepared.impressions
played = imps[imps.has_play & (imps.m_duration > 0)]
rows = []
for c, name in enumerate(("short_form", "long_form")):
    sub = played[played.context_idx == c]
    g = sub.groupby(pd.qcut(sub.duration_seconds, 5, duplicates="drop"), observed=True)
    t = g[["completion_ratio", "unique_watched_seconds", "duration_adjusted_viewing"]].mean()
    t.insert(0, "plays", g.size()); t.insert(0, "surface", name); rows.append(t)
pd.concat(rows)"""),
    ("md", "## 3. Baselines (fitted on data before the test window, evaluated on full feeds)"),
    ("code", """requests = report.test_requests(prepared, config)
baselines = report.fit_baselines(prepared, config)
base_results = report.evaluate_baselines(prepared, config, requests, world.oracle, baselines)
pd.DataFrame({n: report.feed_summary(r) for n, r in base_results.items()}).T[["recall", "ndcg", "mrr", "oracle_utility", "oracle_ndcg", "intra_list_diversity", "creator_concentration"]]"""),
    ("md", """## 4. Chronological training

`train_pipeline` fits training-only transformations, trains the retriever on the earliest window,
freezes it, builds ranking examples with it on a later window, trains the multitask ranker and
calibrates each head on a still later window."""),
    ("code", """tic = time.time()
artefacts = train_pipeline(prepared, config, log=print)
print(f"trained {artefacts.model_version} in {time.time() - tic:.1f}s")
pd.DataFrame(artefacts.report["ranker"]["calibration"]).T[["fitted", "a", "b", "n_examples", "status"]]"""),
    ("md", """## 5. Full-feed comparison

Recall / NDCG use future logged positives as the relevance label over the full eligible catalogue
(biased towards whatever the logging policy showed). The oracle columns use the simulator's ground
truth and exist only for synthetic data. Intervals: 95 % user-level bootstrap."""),
    ("code", """learned = evaluate_recommender(recommend, requests, catalogue=prepared.catalogue, histories=prepared.histories,
                               preferences=prepared.preferences, impressions=prepared.impressions, config=config,
                               artefacts=artefacts, oracle=world.oracle, seed=config.seed, name="learned_system", keep_feeds=True)
results = {"learned_system": learned, **base_results}
k = learned.metrics["k"]
fmt = lambda m: f"{m['mean']:.3f} [{m['ci_low']:.3f}, {m['ci_high']:.3f}]"
table = pd.DataFrame({n: {f"recall@{k}": fmt(r.metrics[f"recall@{k}"]), f"ndcg@{k}": fmt(r.metrics[f"ndcg@{k}"]),
                          f"oracle_ndcg@{k}": fmt(r.metrics[f"oracle_ndcg@{k}"]),
                          "intra_list_diversity": f"{r.metrics['intra_list_diversity']['mean']:.3f}",
                          "creator_concentration": f"{r.metrics['creator_concentration']['mean']:.3f}",
                          "catalogue_coverage": f"{r.metrics['catalogue_coverage']:.3f}",
                          "latency_ms": f"{r.metrics['latency_ms']['mean']:.1f}"} for n, r in results.items()}).T
table"""),
    ("code", """names = list(results)
for metric, title in ((f"recall@{k}", f"Feed Recall@{k} against logged positives (synthetic data)"),
                      (f"oracle_ndcg@{k}", f"Feed oracle NDCG@{k} (synthetic ground truth)")):
    ms = [results[n].metrics[metric] for n in names]
    path = plots.bar_comparison(names, [m["mean"] for m in ms], OUT / f"{metric.replace('@', '_')}.png", title, metric,
                                [m["ci_low"] for m in ms], [m["ci_high"] for m in ms], highlight=("learned_system",))
    display(Image(filename=str(path), width=640))"""),
    ("md", "### Slices of the learned system"),
    ("code", """rows = []
for dim, groups in learned.slices.items():
    for val, ms in groups.items():
        rec = ms.get(f"recall@{k}")
        rows.append({"slice": f"{dim} = {val}", "requests with a label": rec["n_requests"] if rec else None,
                     f"recall@{k}": fmt(rec) if rec else None,
                     f"oracle_ndcg@{k}": fmt(ms[f"oracle_ndcg@{k}"]) if f"oracle_ndcg@{k}" in ms else None})
pd.DataFrame(rows).set_index("slice")"""),
    ("md", """## 6. Retrieval stage

Every scorer ranks the *full eligible catalogue*; the label is the same future-positive label. These
numbers are comparable with each other but not with the logged-slate ranking metrics below."""),
    ("code", """cat = prepared.catalogue
scorers = {"two_tower": two_tower_scorer(artefacts, cat)}
scorers.update({n: (lambda st, rows, b=b: b.score(st, rows, cat)) for n, b in baselines.items()})
retrieval = evaluate_retrieval(scorers, requests, catalogue=cat, histories=prepared.histories, preferences=prepared.preferences,
                               impressions=prepared.impressions, config=config, space=artefacts.space, oracle=world.oracle, seed=config.seed)
display(pd.DataFrame({n: {c: v["mean"] for c, v in s.items() if isinstance(v, dict) and "mean" in v} for n, s in retrieval["scorers"].items()}).T)
ks = list(config.evaluation.retrieval_ks)
ranked = sorted(retrieval["scorers"], key=lambda n: -retrieval["scorers"][n][f"recall@{ks[-1]}"]["mean"])
chosen = ["two_tower"] + [n for n in ranked if n != "two_tower"][:3]
path = plots.recall_curve({n: {kk: retrieval["scorers"][n][f"recall@{kk}"]["mean"] for kk in ks} for n in chosen},
                          OUT / "recall_curve.png", "Retrieval Recall@K over the full eligible catalogue (synthetic data)")
display(Image(filename=str(path), width=600))
cg = evaluate_candidate_generation(artefacts, requests, catalogue=cat, histories=prepared.histories, preferences=prepared.preferences,
                                   impressions=prepared.impressions, oracle=world.oracle, seed=config.seed)
pd.Series({k_: v for k_, v in cg.items() if isinstance(v, float)}, name="hybrid candidate set").to_frame()"""),
    ("md", """## 7. Ranking stage (logged slates)

Candidate universe: the impressions shown in each logged request. Each head is scored only where its
label is observed — satisfaction only where a survey response exists."""),
    ("code", """a, b = prepared.splits.window("test")
runtime = artefacts.runtime(cat)
test_data = build_ranking_data(window_examples(prepared.impressions, a, b), cat, prepared.histories, prepared.preferences,
                               artefacts.space, runtime.features, runtime.video_embeddings, artefacts.retriever, config)
ranking = evaluate_ranking(artefacts, test_data, prepared.impressions, seed=config.seed)
display(pd.DataFrame({t: {c: v for c, v in h.items() if c != "by_context"} for t, h in ranking["heads"].items()}).T)
display(pd.DataFrame({name: {m: ranking["ordering"][f"{name}/{m}"]["mean"] for m in ("ndcg@5", "ndcg@10", "mrr")}
                      for name in ("policy", "logged_order", "random")}).T)
display(Image(filename=str(plots.reliability_plot(ranking["reliability"], OUT / "reliability.png")), width=980))"""),
    ("md", """## 8. Inspecting one feed

Each item exposes its retrieval sources, calibrated head predictions, signed policy and composition
contributions (which sum to the final score), exploration details and versions — and nothing private."""),
    ("code", """req = requests.iloc[len(requests) // 2]
feed = recommend(user_id=req.user_id, context=req.context, as_of=req.as_of, k=10, catalogue=cat, histories=prepared.histories,
                 preferences=prepared.preferences, artefacts=artefacts, previously_recommended=set(), seed=42)
print(feed.diagnostics)
pd.DataFrame([{"rank": it.rank, "video_id": it.video_id, "sources": ", ".join(it.retrieval_sources), "final_score": it.final_score,
               **{f"p_{h}": v for h, v in it.prediction_heads.items()},
               "diversity_penalty": it.score_contributions["diversity_penalty"], "freshness_bonus": it.score_contributions["freshness_bonus"],
               "exploration": it.exploration["is_exploration"]} for it in feed]).set_index("rank")"""),
    ("md", """## 9. Ablations

Retrieval sources, ranking heads and diversity change only serving configuration. The duration
ablation retrains the ranker with a different duration target (the retriever is shared), and the
pooling ablation retrains both models with attention pooling."""),
    ("code", """tic = time.time()
ablations = report.run_ablations(prepared, artefacts, world.oracle, max_requests=350, retrain=True)
print(f"ablations in {time.time() - tic:.1f}s on {ablations['n_requests']} requests")
cols = ["recall", "ndcg", "oracle_utility", "oracle_ndcg", "intra_list_diversity", "creator_concentration", "new_video_exposure"]
for group in ("retrieval_sources", "ranking_heads", "diversity", "history_pooling"):
    extra = [c for c in ("n_candidates", "candidate_recall", "oracle_ideal_coverage") if c in next(iter(ablations[group].values()))]
    print(group); display(pd.DataFrame(ablations[group]).T[cols + extra].astype(float))"""),
    ("code", """dur = pd.DataFrame(ablations["duration_target"]).T
profiles = {n.split("/")[0]: v for n, v in dur["duration_profile"].items() if n.endswith("duration_head_only")}
display(dur[["oracle_utility", "oracle_ndcg", "mean_log_duration"]].astype(float))
path = plots.duration_profile(profiles, ["shortest", "short", "middle", "long", "longest"], OUT / "duration_profile.png",
                              "What each duration target makes the duration head recommend (synthetic data)")
display(Image(filename=str(path), width=640))"""),
    ("md", """## 10. Propensity-weighted evaluation

Only where valid propensities exist. In this world a uniform-random policy served part of the
long-form requests and logged slate-inclusion propensities; short-form has none, so the estimator is
reported as unavailable there rather than approximated."""),
    ("code", """imps = prepared.impressions
in_test = (imps.t >= a) & (imps.t < b)
out = {}
for c, ctx in enumerate(("short_form", "long_form")):
    ids = imps.loc[in_test & (imps.context_idx == c) & imps.selection_propensity.notna(), "request_id"].unique()
    if len(ids) == 0:
        out[ctx] = {"status": "unavailable", "reason": "no valid selection propensities were logged for this surface"}
        continue
    reqs = build_evaluation_requests(imps[imps.request_id.isin(ids)], a, b, None, config.seed)
    feeds = {r.request_id: recommend(user_id=r.user_id, context=r.context, as_of=r.as_of, k=config.evaluation.feed_k, catalogue=cat,
                                     histories=prepared.histories, preferences=prepared.preferences, artefacts=artefacts,
                                     previously_recommended=set(), seed=config.seed).video_ids for r in reqs.itertuples(index=False)}
    out[ctx] = propensity_weighted_evaluation(feeds, imps, config, VALID_SYNTHETIC_PROPENSITY_POLICIES, seed=config.seed)
pd.DataFrame({ctx: {k_: v for k_, v in r.items() if k_ not in ("assumptions", "policies", "contexts_covered")} for ctx, r in out.items()})"""),
    ("md", """## Notes

- Hit metrics against logged positives and oracle metrics can rank recommenders differently; that
  gap is exposure bias, and it is why both are shown.
- Nothing here was tuned to make the learned system win. Where a baseline is ahead, the tables say so.
- The full-size run, the four scenario worlds and the test results are in `docs/results.md`."""),
]


def build(path: Path) -> nbformat.NotebookNode:
    nb = new_notebook(metadata={"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                                "language_info": {"name": "python"}})
    nb.cells = [new_markdown_cell(src) if kind == "md" else new_code_cell(src) for kind, src in CELLS]
    path.parent.mkdir(parents=True, exist_ok=True)
    nbformat.write(nb, path)
    return nb


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="notebooks/baselines_vs_learned.ipynb")
    p.add_argument("--execute", action="store_true")
    p.add_argument("--timeout", type=int, default=3600)
    args = p.parse_args()
    path = Path(args.out)
    nb = build(path)
    if args.execute:
        from nbclient import NotebookClient

        NotebookClient(nb, timeout=args.timeout, kernel_name="python3",
                       resources={"metadata": {"path": str(path.parent)}}).execute()
        nbformat.write(nb, path)
    print(f"wrote {path}" + (" (executed)" if args.execute else ""))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
