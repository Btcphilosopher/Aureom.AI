#!/usr/bin/env python
"""Thin wrapper around ``aureom_recommend.cli.scenarios_main`` (run with --help for options)."""
import sys

from aureom_recommend.cli import scenarios_main

if __name__ == "__main__":
    sys.exit(scenarios_main())
