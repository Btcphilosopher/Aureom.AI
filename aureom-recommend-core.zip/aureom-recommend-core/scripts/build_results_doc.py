#!/usr/bin/env python
"""Render docs/results.md from the JSON files written by the evaluation commands.

Every number in the document comes from ``reports/*.json``; nothing is typed by hand.
Hand-written interpretation lives in ``docs/observations.md`` and is included verbatim.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Iterable


def f(x: Any, nd: int = 3) -> str:
    if x is None:
        return "n/a"
    if isinstance(x, str):
        return x
    if isinstance(x, bool):
        return "yes" if x else "no"
    if isinstance(x, int):
        return f"{x:,}"
    return "n/a" if x != x else f"{x:.{nd}f}"


def ci(m: dict[str, Any] | None, nd: int = 3) -> str:
    if not m or m.get("mean") is None or m["mean"] != m["mean"]:
        return "n/a"
    if m.get("ci_low") is None or m["ci_low"] != m["ci_low"]:
        return f(m["mean"], nd)
    return f"{m['mean']:.{nd}f} [{m['ci_low']:.{nd}f}, {m['ci_high']:.{nd}f}]"


def table(headers: list[str], rows: Iterable[list[Any]]) -> str:
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] + ["---:"] * (len(headers) - 1)) + "|"]
    lines += ["| " + " | ".join(str(c) for c in row) + " |" for row in rows]
    return "\n".join(lines) + "\n"


def feed_section(metrics: dict[str, Any]) -> str:
    feed, k = metrics["feed"], metrics["feed"]["learned_system"]["metrics"]["k"]
    out = [f"## 2. Full-feed evaluation (k = {k})\n",
           f"*Relevance label:* {feed['learned_system']['definitions']['relevance_label']}.  \n"
           f"*Candidate universe:* {feed['learned_system']['definitions']['candidate_universe']}.  \n"
           f"*Intervals:* {feed['learned_system']['definitions']['intervals']}. "
           f"{metrics['n_test_requests']:,} test requests.\n"]
    has_oracle = f"oracle_ndcg@{k}" in feed["learned_system"]["metrics"]
    head = ["recommender", f"Recall@{k}", f"NDCG@{k}", "MRR"] + ([f"oracle utility@{k}", f"oracle NDCG@{k}"] if has_oracle else [])
    rows = []
    for name, res in feed.items():
        m = res["metrics"]
        rows.append([f"**{name}**" if name == "learned_system" else name, ci(m[f"recall@{k}"]), ci(m[f"ndcg@{k}"]),
                     ci(m["mrr"])] + ([ci(m[f"oracle_utility@{k}"]), ci(m[f"oracle_ndcg@{k}"])] if has_oracle else []))
    out.append("### 2.1 Relevance\n\n" + table(head, rows))
    head = ["recommender", "intra-list diversity", "creator concentration", "duplicate rate", "new-video exposure",
            "catalogue coverage", "creator coverage", "creator exposure Gini", "latency mean / p95 (ms)"]
    rows = []
    for name, res in feed.items():
        m = res["metrics"]
        rows.append([f"**{name}**" if name == "learned_system" else name, f(m["intra_list_diversity"]["mean"]),
                     f(m["creator_concentration"]["mean"]), f(m["duplicate_rate"]["mean"]),
                     f(m["new_video_exposure"]["mean"]), f(m["catalogue_coverage"]), f(m["creator_coverage"]),
                     f(m["creator_exposure_gini"]), f"{m['latency_ms']['mean']:.1f} / {m['latency_ms']['p95']:.1f}"])
    out.append("### 2.2 Composition, coverage and latency\n\n"
               "Creator concentration = largest share of one creator in a feed. Duplicate rate = share of items "
               "sharing a duplicate group with another item of the same feed. New-video exposure = share of items "
               "published within the configured new-video window. Latency is single-request, single-process, CPU.\n\n"
               + table(head, rows))
    violations = {n: r["metrics"]["eligibility_violations"] for n, r in feed.items()}
    out.append(f"Hard-eligibility violations across all feeds: {violations}.\n")
    out.append("### 2.3 Slices\n")
    for who in ("learned_system", "popularity", "explicit_preferences", "implicit_cf"):
        if who not in feed:
            continue
        rows = []
        for dim, groups in feed[who]["slices"].items():
            for val, ms in groups.items():
                rec = ms.get(f"recall@{k}")
                rows.append([f"{dim} = {val}", f(rec.get("n_requests")) if rec else "n/a", ci(rec), ci(ms.get(f"ndcg@{k}")),
                             ci(ms.get(f"oracle_ndcg@{k}"))])
        out.append(f"**{who}**\n\n" + table(["slice", "requests with a label", f"Recall@{k}", f"NDCG@{k}", f"oracle NDCG@{k}"], rows))
    out.append("New / established *video* slices restrict the relevant set to videos of that age, so only recall is "
               "defined for them. New users: first observed less than the configured number of days before the "
               "request or no history. Sparse history: fewer than the configured number of items.\n")
    return "\n".join(out)


def retrieval_section(metrics: dict[str, Any]) -> str:
    r = metrics["retrieval"]
    scorers = r["scorers"]
    ks = sorted(int(c.split("@")[1]) for c in next(iter(scorers.values())) if c.startswith("recall@"))
    head = ["scorer"] + [f"Recall@{k}" for k in ks] + [f"NDCG@{ks[-1]}", "MRR"]
    oracle = "oracle_utility@20" in next(iter(scorers.values()))
    if oracle:
        head.append("oracle utility@20")
    rows = []
    for name, s in scorers.items():
        row = [f"**{name}**" if name == "two_tower" else name] + [ci(s[f"recall@{k}"]) for k in ks] + [f(s[f"ndcg@{ks[-1]}"]["mean"]), f(s["mrr"]["mean"])]
        if oracle:
            row.append(f(s["oracle_utility@20"]["mean"]))
        rows.append(row)
    out = ["## 3. Retrieval\n",
           f"*Relevance label:* {r['definitions']['relevance_label']}.  \n*Candidate universe:* "
           f"{r['definitions']['candidate_universe']}.\n", table(head, rows)]
    cg = metrics["candidate_generation"]
    out.append("### 3.1 Hybrid candidate generation\n")
    out.append(f"*Candidate universe:* {cg['definitions']['candidate_universe']}.\n")
    rows = [["mean eligible videos per request", f(cg["n_eligible"], 1)], ["mean candidates per request", f(cg["n_candidates"], 1)],
            ["candidate-set recall of relevant videos", f(cg.get("candidate_recall"))]]
    if "oracle_ideal_coverage" in cg:
        rows.append(["share of oracle-ideal top-20 inside the candidate set", f(cg["oracle_ideal_coverage"])])
    rows += [[f"recall contributed by source `{k.split('/')[1]}`", f(v)] for k, v in cg.items() if k.startswith("recall/")]
    out.append(table(["quantity", "value"], rows))
    return "\n".join(out)


def ranking_section(metrics: dict[str, Any]) -> str:
    r = metrics["ranking"]
    out = ["## 4. Ranking on logged slates\n",
           f"*Candidate universe:* {r['definitions']['candidate_universe']}. {r['definitions']['note']}.  \n"
           f"*Labels:* {r['definitions']['probability_labels']}. {r['n_impressions']:,} test impressions.\n"]
    rows = []
    for task, h in r["heads"].items():
        extra = f"AUC {f(h.get('auc'))}" if "auc" in h else f"MAE {f(h.get('mae'))} / RMSE {f(h.get('rmse'))}"
        rows.append([task, f(h["n_labelled"]), f(h.get("label_mean")), f(h.get("prediction_mean")),
                     f"{f(h.get('brier_uncalibrated'), 4)} / {f(h.get('brier_calibrated'), 4)}",
                     f"{f(h.get('ece_uncalibrated'), 4)} / {f(h.get('ece_calibrated'), 4)}", extra, h["calibration_status"]])
    out.append("### 4.1 Head quality (Brier and ECE: before / after calibration)\n\n" + table(
        ["head", "labelled rows", "label mean", "prediction mean", "Brier", "ECE", "discrimination / error", "calibration"], rows))
    out.append("The `duration` row is the duration-target prediction error (target = duration-adjusted viewing in "
               "[0, 1]); `satisfaction` is scored only on impressions with a survey response.\n")
    rows = []
    for task, h in r["heads"].items():
        for ctx, v in h.get("by_context", {}).items():
            rows.append([f"{task} / {ctx}", f(v["n_labelled"]), f(v["brier_calibrated"], 4), f(v["ece_calibrated"], 4)])
    out.append("By surface (calibrated):\n\n" + table(["head / surface", "labelled rows", "Brier", "ECE"], rows))
    o = r["ordering"]
    if o.get("n_requests"):
        ks = sorted({int(c.split("@")[1]) for c in o if "ndcg@" in c})
        rows = [[name] + [ci(o[f"{name}/ndcg@{k}"]) for k in ks] + [ci(o[f"{name}/mrr"])] for name in ("policy", "logged_order", "random")]
        out.append(f"### 4.2 Ordering of the logged slate ({o['n_requests']:,} requests with both outcomes)\n\n"
                   f"*Relevance label:* {r['definitions']['relevance_label']}.\n\n"
                   + table(["ordering"] + [f"NDCG@{k}" for k in ks] + ["MRR"], rows))
        rows = [[ctx] + [f(v[n]) for n in ("policy", "logged_order", "random")] for ctx, v in o["by_context"].items()]
        out.append(f"NDCG@{ks[-1]} by surface:\n\n" + table(["surface", "policy", "logged order", "random"], rows))
    return "\n".join(out)


def propensity_section(metrics: dict[str, Any]) -> str:
    out = ["## 5. Propensity-weighted evaluation\n",
           "Computed only where the logging policy supplied valid propensities and was declared to have full support; "
           "otherwise reported as unavailable. Reward = meaningful view; estimand = mean reward per recommended item.\n"]
    for ctx, res in metrics["propensity_weighted"].items():
        if res.get("status") == "unavailable":
            out.append(f"**{ctx}: unavailable** - {res['reason']}.\n")
            continue
        rows = []
        for name, r in res.items():
            if r["status"] != "available":
                rows.append([name, "unavailable", "", "", r["reason"]])
            else:
                rows.append([name, f(r["snips"]), f"[{r['snips_ci_low']:.3f}, {r['snips_ci_high']:.3f}]", f(r["ips"]),
                             f"{r['n_matched_impressions']} matched, ESS {r['effective_sample_size']:.0f}"])
        first = next((r for r in res.values() if r["status"] == "available"), None)
        note = ""
        if first:
            note = (f"{first['n_requests']} requests logged by `{', '.join(first['policies'])}`; mean logged reward "
                    f"{first['logged_mean_reward']:.3f}. Assumptions: {'; '.join(first['assumptions'])}.\n")
        out.append(f"**{ctx}: available**\n\n" + table(["recommender", "SNIPS", "95% interval", "IPS", "support"], rows) + "\n" + note)
    return "\n".join(out)


def ablation_section(ab: dict[str, Any]) -> str:
    out = [f"## 6. Ablations ({ab['n_requests']} test requests)\n",
           "Same trained models unless stated; only the named setting changes. Feed metrics as in section 2.\n"]
    oracle = ab.get("synthetic_data")

    def rows_for(group: str, extra: list[tuple[str, str]] = ()) -> str:
        head = ["variant", "Recall@k", "NDCG@k"] + (["oracle utility", "oracle NDCG"] if oracle else []) + \
               ["intra-list diversity", "creator concentration", "new-video exposure"] + [h for h, _ in extra]
        rows = []
        for name, r in ab[group].items():
            row = [name, f(r["recall"]), f(r["ndcg"])] + ([f(r.get("oracle_utility")), f(r.get("oracle_ndcg"))] if oracle else [])
            row += [f(r["intra_list_diversity"]), f(r["creator_concentration"]), f(r["new_video_exposure"])]
            row += [f(r.get(key), 3) if not isinstance(r.get(key), list) else " / ".join(f"{x:.2f}" for x in r[key]) for _, key in extra]
            rows.append(row)
        return table(head, rows)

    out.append("### 6.1 Retrieval sources\n\n" + rows_for("retrieval_sources", [
        ("candidates", "n_candidates"), ("candidate recall", "candidate_recall")] + ([("oracle-ideal coverage", "oracle_ideal_coverage")] if oracle else [])))
    out.append("### 6.2 Ranking heads (policy weights)\n\n`without_x` sets one weight to zero; `only_x` keeps a single head.\n\n" + rows_for("ranking_heads"))
    out.append("### 6.3 Diversity and composition\n\n" + rows_for("diversity"))
    if "duration_target" in ab:
        out.append("### 6.4 Duration adjustment (the ranker is retrained per target; the retriever is shared)\n\n"
                   "`duration_head_only` ranks by the duration head alone with composition switched off, which isolates "
                   "what each target makes the model prefer. The profile is the share of recommended items in five "
                   "within-surface duration buckets, shortest to longest (0.20 each would be duration-neutral).\n\n"
                   + rows_for("duration_target", [("duration profile (short -> long)", "duration_profile")]))
        if "duration_reference" in ab:
            out.append("Reference profiles for the same requests (not models):\n\n" + table(
                ["reference", "duration profile (short -> long)"],
                [[n, " / ".join(f"{x:.2f}" for x in v)] for n, v in ab["duration_reference"].items()]))
    if "history_pooling" in ab:
        key = next(k for k in next(iter(ab["history_pooling"].values())) if k.startswith("best_validation"))
        out.append("### 6.5 History pooling (retriever and ranker retrained)\n\n" + rows_for("history_pooling", [("best validation recall", key)]))
    return "\n".join(out)


def scenario_section(sc: dict[str, Any]) -> str:
    out = ["## 7. Scenarios (separately generated synthetic worlds)\n"]
    for name, s in sc.items():
        out.append(f"### {name}\n\n*Question:* {s['question']}\n\n*World:* {s['world']['n_users']} users, "
                   f"{s['world']['n_videos']} videos, {s['world']['n_events']:,} events; {s['n_requests']} test requests.\n")
        rows = [[f"**{n}**" if n == "learned_system" else n, f(r["recall"]), f(r["ndcg"]), f(r.get("oracle_utility")),
                 f(r.get("oracle_ndcg")), f(r["intra_list_diversity"]), f(r["creator_exposure_gini"]), f(r["new_video_exposure"])]
                for n, r in s["feed_summary"].items()]
        out.append(table(["recommender", "Recall@k", "NDCG@k", "oracle utility", "oracle NDCG", "intra-list diversity",
                          "creator exposure Gini", "new-video exposure"], rows))
        if "duration_targets" in s:
            rows = [[t, " / ".join(f"{x:.2f}" for x in d["duration_profile"]), f(d["profile_imbalance"]), f(d["oracle_utility"]), f(d["oracle_ndcg"])]
                    for t, d in s["duration_targets"].items()]
            out.append("Duration head only, composition off:\n\n" + table(
                ["duration target", "duration profile (short -> long)", "max - min share", "oracle utility", "oracle NDCG"], rows))
            if "duration_reference" in s:
                out.append("Reference profiles (not models):\n\n" + table(
                    ["reference", "duration profile (short -> long)"],
                    [[n, " / ".join(f"{x:.2f}" for x in v)] for n, v in s["duration_reference"].items()]))
        if "slices" in s:
            rows = []
            for who, dims in s["slices"].items():
                for dim, groups in dims.items():
                    for val, ms in groups.items():
                        rec = next((v for k, v in ms.items() if k.startswith("recall@")), None)
                        ond = next((v for k, v in ms.items() if k.startswith("oracle_ndcg@")), None)
                        rows.append([who, f"{dim} = {val}", f(rec.get("n_requests")) if rec else "n/a", ci(rec), ci(ond)])
            out.append(table(["recommender", "slice", "requests with a label", "Recall@k", "oracle NDCG@k"], rows))
    return "\n".join(out)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--reports", default="reports")
    p.add_argument("--out", default="docs/results.md")
    args = p.parse_args()
    reports = Path(args.reports)
    metrics = json.loads((reports / "metrics.json").read_text())
    parts = ["# Results\n",
             "> **All data in this document is SYNTHETIC.** It was produced by the seeded simulator in "
             "`aureom_recommend.data.synthetic`. The numbers show that the algorithm runs end to end and how its parts "
             "behave in a world with known ground truth. They say nothing about performance on real users.\n",
             f"Generated by `scripts/build_results_doc.py` from `reports/*.json` (model `{metrics['model_version']}`, "
             f"policy `{metrics['policy_version']}`). Reproduce with `scripts/reproduce.sh`.\n"]
    obs = Path(args.out).parent / "observations.md"
    if obs.exists():
        parts.append(obs.read_text())
    parts += [feed_section(metrics), retrieval_section(metrics), ranking_section(metrics), propensity_section(metrics)]
    if (reports / "ablations.json").exists():
        parts.append(ablation_section(json.loads((reports / "ablations.json").read_text())))
    if (reports / "scenarios.json").exists():
        parts.append(scenario_section(json.loads((reports / "scenarios.json").read_text())))
    if (reports / "pytest.txt").exists():
        tail = [line for line in (reports / "pytest.txt").read_text().splitlines() if line.strip()][-1]
        parts.append(f"## 8. Tests\n\n`python -m pytest` -> `{tail.strip()}` (full output in `reports/pytest.txt`).\n")
    Path(args.out).write_text("\n".join(parts))
    print(f"wrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
