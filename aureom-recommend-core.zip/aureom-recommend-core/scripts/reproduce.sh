#!/usr/bin/env bash
# Reproduce every reported number from scratch on a CPU (about 10 minutes on 4 cores).
# Usage: scripts/reproduce.sh [WORKDIR]   (default: ./work)
set -euo pipefail
cd "$(dirname "$0")/.."
WORK="${1:-work}"
mkdir -p "$WORK" reports

python scripts/generate_synthetic.py --scenario default --out "$WORK/data"
python scripts/run_baselines.py --data "$WORK/data" --config configs/default.toml --out reports/baselines.json
python scripts/train.py --data "$WORK/data" --config configs/default.toml --out "$WORK/artefacts"
python scripts/evaluate.py --data "$WORK/data" --artefacts "$WORK/artefacts" --out reports
python scripts/run_ablations.py --data "$WORK/data" --artefacts "$WORK/artefacts" --out reports/ablations.json
python scripts/run_scenarios.py --config configs/default.toml --out reports/scenarios.json
python scripts/build_results_doc.py --reports reports --out docs/results.md
python -m pytest | tee reports/pytest.txt
