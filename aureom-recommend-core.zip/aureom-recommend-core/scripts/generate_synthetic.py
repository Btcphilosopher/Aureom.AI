#!/usr/bin/env python
"""Thin wrapper around ``aureom_recommend.cli.generate_main`` (run with --help for options)."""
import sys

from aureom_recommend.cli import generate_main

if __name__ == "__main__":
    sys.exit(generate_main())
