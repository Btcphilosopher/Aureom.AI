"""Chronological training pipeline.

validate data -> construct point-in-time examples -> temporal splits -> fit training-only
transformations -> train retrieval -> generate ranking examples with the frozen retriever ->
train ranker -> calibrate -> (evaluate full feeds) -> save compatible artefacts.

Leakage controls
* future interactions      histories and statistics are "as of" queries on received events
* future popularity        statistics are computed on a grid at or before each request time
* later metadata edits     every lookup uses the metadata version visible at that time
* post-cutoff uploads      vocabularies/TF-IDF are fitted on rows visible before the cutoff;
                           negatives are restricted to videos available at example time
* validation labels        each window only contains impressions matured inside it (embargo)
* evaluation-period history nothing fitted ever touches the test window
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import pandas as pd

from ..artefacts.bundle import RecommenderArtefacts
from ..config import Config
from ..data.catalogue import Catalogue
from ..data.events import clean_events
from ..data.histories import HistoryStore, PreferenceStore
from ..data.labels import ExampleSet, build_examples
from ..data.schemas import validate_preferences, validate_videos
from ..features.duration import DurationBaseline
from ..features.space import FeatureSpace
from .ranker import build_ranking_data, calibrate_ranker, train_ranker
from .retriever import build_retrieval_data, train_retriever
from .splits import TemporalSplits, make_temporal_splits, window_examples


@dataclass
class PreparedData:
    catalogue: Catalogue
    events: pd.DataFrame
    examples: ExampleSet
    histories: HistoryStore
    preferences: PreferenceStore
    splits: TemporalSplits
    reports: dict[str, Any] = field(default_factory=dict)

    @property
    def impressions(self) -> pd.DataFrame:
        return self.examples.impressions


def prepare_data(videos: pd.DataFrame, interactions: pd.DataFrame, preferences: pd.DataFrame, config: Config,
                 cutoff: Optional[float] = None) -> PreparedData:
    """Validate the three tables and build point-in-time examples, histories and splits."""
    vids, video_report = validate_videos(videos)
    prefs, pref_report = validate_preferences(preferences)
    catalogue = Catalogue.from_frame(vids, config.labels.short_form_max_duration_seconds, validated=True)
    events = clean_events(interactions, config, preferences=prefs, catalogue=catalogue)
    cut = float(events["t_received"].max()) if cutoff is None else float(cutoff)
    examples = build_examples(events, catalogue, cut, config)
    histories = HistoryStore(examples, catalogue, config)
    splits = make_temporal_splits(examples.impressions, config)
    reports = {"videos": video_report.to_dict(), "preferences": pref_report.to_dict(),
               "events": events.attrs.get("report", {}), "examples": examples.report, "splits": splits.to_dict()}
    return PreparedData(catalogue, events, examples, histories, PreferenceStore(prefs), splits, reports)


def fit_duration_targets(prepared: PreparedData, config: Config) -> DurationBaseline:
    """Fit the duration baseline on training windows only and write ``y_duration`` for all impressions."""
    sp = prepared.splits
    train = window_examples(prepared.impressions, sp.start, sp.ranker_train_end)
    baseline = DurationBaseline.fit(train, config.duration)
    prepared.examples.impressions = baseline.transform(prepared.impressions, config.ranker.duration_target)
    return baseline


def train_pipeline(prepared: PreparedData, config: Config, log: Callable[[str], None] = lambda s: None,
                   retriever: Any = None, space: Optional[FeatureSpace] = None) -> RecommenderArtefacts:
    """Run the full chronological training sequence and return serving artefacts.

    ``retriever`` / ``space`` may be passed to reuse an already trained retriever (ablations
    that only change the ranker); they must come from the same splits.
    """
    sp, cat = prepared.splits, prepared.catalogue
    report: dict[str, Any] = {"timings": {}}
    tic = time.time()
    baseline = fit_duration_targets(prepared, config)
    imps = prepared.impressions
    report["duration_baseline"] = {"n_fit": baseline.n_fit, "buckets": [len(r) for r in baseline.references]}

    # ---- training-only transformations ------------------------------------------------
    rt_train = window_examples(imps, sp.start, sp.retrieval_train_end)
    rt_pos = rt_train.loc[rt_train["is_positive"].to_numpy()]
    if space is None:
        space = FeatureSpace.fit(cat, sp.retrieval_train_end, rt_pos["video_id"].tolist(), config.features, config.seed)
    features = space.transform_catalogue(cat)
    report["timings"]["features"] = time.time() - tic

    # ---- retrieval ----------------------------------------------------------------------
    tic = time.time()
    if retriever is None:
        train_data = build_retrieval_data(rt_pos, cat, prepared.histories, prepared.preferences, space, features,
                                          config, cutoff=sp.retrieval_train_end)
        rv = window_examples(imps, sp.retrieval_train_end, sp.retrieval_valid_end)
        valid_data = build_retrieval_data(rv.loc[rv["is_positive"].to_numpy()], cat, prepared.histories,
                                          prepared.preferences, space, features, config, cutoff=sp.retrieval_train_end,
                                          user_codes=train_data.user_codes)  # type: ignore[attr-defined]
        log(f"retrieval examples: train={len(train_data)} validation={len(valid_data)}")
        retriever = train_retriever(train_data, valid_data, config)
        report["retrieval"] = {"n_train": len(train_data), "n_validation": len(valid_data), "history": retriever.history}
        for h in retriever.history:
            log(f"  retriever epoch {h['epoch']}: " + ", ".join(f"{k}={v:.4f}" for k, v in h.items() if k != "epoch"))
    report["timings"]["retrieval"] = time.time() - tic

    # ---- ranking examples from the frozen retriever ------------------------------------
    tic = time.time()
    video_emb = retriever.embed_catalogue(features)

    def ranking_window(name: str):
        a, b = sp.window(name)
        return build_ranking_data(window_examples(imps, a, b), cat, prepared.histories, prepared.preferences, space,
                                  features, video_emb, retriever, config)

    rk_train, rk_valid, rk_cal = ranking_window("ranker_train"), ranking_window("ranker_valid"), ranking_window("calibration")
    report["timings"]["ranking_features"] = time.time() - tic
    log(f"ranking examples: train={len(rk_train)} validation={len(rk_valid)} calibration={len(rk_cal)}")
    tic = time.time()
    ranker = train_ranker(rk_train, rk_valid, config)
    for h in ranker.history:
        log(f"  ranker epoch {h['epoch']}: train={h['train_loss']:.4f} validation={h.get('validation_loss', float('nan')):.4f}")
    calibrators = calibrate_ranker(ranker, rk_cal, config)
    report["timings"]["ranker"] = time.time() - tic
    report["ranker"] = {
        "n_train": len(rk_train), "n_validation": len(rk_valid), "n_calibration": len(rk_cal),
        "label_support_train": {t: int(rk_train.masks[:, j].sum()) for j, t in enumerate(("meaningful", "duration", "like_or_save", "satisfaction", "negative"))},
        "pos_weights": ranker.pos_weights, "calibration": {t: c.to_dict() for t, c in calibrators.items()},
        "history": ranker.history,
    }
    artefacts = RecommenderArtefacts(config=config, space=space, duration_baseline=baseline, retriever=retriever,
                                     ranker=ranker, model_version="", splits=sp.to_dict(), report=report)
    artefacts.model_version = artefacts.make_model_version()
    return artefacts
