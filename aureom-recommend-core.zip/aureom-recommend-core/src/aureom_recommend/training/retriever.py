"""Retriever training: point-in-time example construction, negative sampling, early stopping.

Negative sampling
    Each step uses the batch's own positives (in-batch negatives) plus ``n_uniform_negatives``
    rows drawn uniformly from the catalogue rows visible before the training cutoff. A
    candidate only counts as a negative for an example if the video was published and
    available at that example's historical time and belongs to the same surface; copies of
    the positive and known positives of the user are masked (see retrieval/loss.py).
"""
from __future__ import annotations

import copy
import time
from dataclasses import dataclass
from typing import Any, Optional

import numpy as np
import pandas as pd
import torch

from ..config import Config
from ..data.catalogue import Catalogue
from ..data.histories import HistoryStore, PreferenceStore
from ..features.space import FeatureSpace, VideoFeatures
from ..features.state import tower_inputs
from ..retrieval.loss import sampled_softmax_loss
from ..retrieval.model import TowerDims, TwoTower, VideoBank, to_tensors


def resolve_device(name: str) -> torch.device:
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if name == "cuda" and not torch.cuda.is_available():
        return torch.device("cpu")           # GPU is optional; fall back silently to CPU
    return torch.device(name)


@dataclass
class RetrievalData:
    catalogue: Catalogue
    features: VideoFeatures
    inputs: dict[str, np.ndarray]
    pos_row: np.ndarray
    t: np.ndarray
    context_idx: np.ndarray
    user_code: np.ndarray
    known_keys: np.ndarray               # sorted user_code * n_groups + duplicate_group of known positives
    n_groups: int
    video_positive_share: np.ndarray     # p_j per dense video index (training positives)
    negative_pool: np.ndarray            # catalogue rows visible before the cutoff
    dims: TowerDims

    def __len__(self) -> int:
        return len(self.pos_row)


def tower_dims(space: FeatureSpace, config: Config) -> TowerDims:
    return TowerDims(n_dense=space.n_dense, n_topics=len(space.topic_vocab) + 2,
                     n_languages=len(space.language_vocab) + 2, n_creators=len(space.creator_vocab) + 2,
                     n_videos=len(space.video_vocab) + 2, max_history=config.features.max_history)


def build_retrieval_data(positives: pd.DataFrame, catalogue: Catalogue, histories: HistoryStore,
                         preferences: PreferenceStore, space: FeatureSpace, features: VideoFeatures, config: Config,
                         cutoff: float, known_positives: Optional[pd.DataFrame] = None,
                         user_codes: Optional[dict[str, int]] = None) -> RetrievalData:
    """Point-in-time retrieval examples: one per positive impression, user inputs as of the impression."""
    users = positives["user_id"].to_numpy(dtype=object)
    enabled = np.array([preferences.get(u).personalisation_enabled for u in users], dtype=bool)
    positives = positives.loc[enabled]                       # opted-out users are not used for personalised training
    users, ts = positives["user_id"].to_numpy(dtype=object), positives["t"].to_numpy()
    ctx = positives["context_idx"].to_numpy()
    cache: dict[tuple[str, float, int], dict[str, np.ndarray]] = {}
    rows: list[dict[str, np.ndarray]] = []
    for u, t, c in zip(users.tolist(), ts.tolist(), ctx.tolist()):
        key = (u, t, c)
        if key not in cache:
            cache[key] = tower_inputs(histories.items_as_of(u, t), preferences.get(u), t, c, space, config)
        rows.append(cache[key])
    template = tower_inputs(histories.items_as_of("", 0.0), preferences.get(""), 0.0, 0, space, config)
    inputs = {k: (np.stack([r[k] for r in rows]) if rows else np.zeros((0,) + v.shape, dtype=v.dtype))
              for k, v in template.items()}
    codes = dict(user_codes or {})
    for u in users.tolist():
        codes.setdefault(u, len(codes))
    known = positives if known_positives is None else known_positives
    n_groups = int(catalogue.duplicate_group.max()) + 1
    k_users = known["user_id"].to_numpy(dtype=object).tolist()
    k_code = np.array([codes.get(u, -1) for u in k_users], dtype="int64")
    k_group = catalogue.video_group[known["video_idx"].to_numpy()]
    known_keys = np.unique(k_code[k_code >= 0] * n_groups + k_group[k_code >= 0])
    share = np.bincount(known["video_idx"].to_numpy(), minlength=catalogue.n_videos).astype("float64")
    share = share / max(1.0, share.sum())
    data = RetrievalData(
        catalogue=catalogue, features=features, inputs=inputs, pos_row=positives["row"].to_numpy(), t=ts,
        context_idx=ctx, user_code=np.array([codes[u] for u in users.tolist()], dtype="int64"), known_keys=known_keys,
        n_groups=n_groups, video_positive_share=share, negative_pool=catalogue.rows_visible_before(cutoff),
        dims=tower_dims(space, config))
    data.user_codes = codes  # type: ignore[attr-defined]
    return data


def build_candidate_masks(data: RetrievalData, idx: np.ndarray, cand_rows: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """(negative_mask, known_positive_mask) of shape (B, C) for batch examples ``idx``.

    The first ``len(idx)`` candidates are the batch's own positives, in order.
    """
    cat = data.catalogue
    t = data.t[idx][:, None]
    available = (cat.published_at[cand_rows] <= t) & (cat.available_from[cand_rows] <= t) & (t < cat.available_until[cand_rows])
    same_surface = cat.context_index[cand_rows][None, :] == data.context_idx[idx][:, None]
    groups = cat.duplicate_group[cand_rows]
    same_group = groups[None, :] == groups[:len(idx)][:, None]            # the positive itself and its copies
    keys = data.user_code[idx][:, None] * data.n_groups + groups[None, :]
    pos = np.searchsorted(data.known_keys, keys)
    known = data.known_keys[np.minimum(pos, max(len(data.known_keys) - 1, 0))] == keys if len(data.known_keys) else np.zeros_like(same_group)
    return available & same_surface & ~same_group & ~known, known | same_group


class Retriever:
    """Trained two-tower model plus convenience encoders (NumPy in, NumPy out)."""

    def __init__(self, model: TwoTower, dims: TowerDims, config: Config, device: torch.device | str = "cpu",
                 history: Optional[list[dict[str, Any]]] = None) -> None:
        self.model, self.dims, self.config = model.to(device).eval(), dims, config
        self.device = torch.device(device)
        self.history = history or []

    @torch.no_grad()
    def embed_catalogue(self, features: VideoFeatures, batch_size: int = 4096) -> np.ndarray:
        self.model.eval()
        bank = VideoBank(features, self.device)
        out = [self.model.encode_videos(bank, torch.arange(s, min(s + batch_size, bank.n_rows), device=self.device))
               for s in range(0, bank.n_rows, batch_size)]
        d = self.config.retrieval.embedding_dim
        return torch.cat(out).cpu().numpy().astype("float32") if out else np.zeros((0, d), dtype="float32")

    @torch.no_grad()
    def embed_users(self, bank: VideoBank, inputs: dict[str, np.ndarray], batch_size: int = 2048) -> np.ndarray:
        self.model.eval()
        n = len(inputs["context"])
        out = []
        for s in range(0, n, batch_size):
            batch = to_tensors({k: v[s:s + batch_size] for k, v in inputs.items()}, self.device)
            out.append(self.model.encode_users(bank, batch))
        d = self.config.retrieval.embedding_dim
        return torch.cat(out).cpu().numpy().astype("float32") if out else np.zeros((0, d), dtype="float32")

    def embed_user(self, bank: VideoBank, single_inputs: dict[str, np.ndarray]) -> np.ndarray:
        return self.embed_users(bank, {k: np.asarray(v)[None, ...] for k, v in single_inputs.items()})[0]


def retrieval_recall(retriever: Retriever, data: RetrievalData, k: int, max_examples: int, seed: int) -> float:
    """Recall@k of the positive among all rows that were eligible (live, same surface) at example time."""
    if len(data) == 0:
        return float("nan")
    idx = np.arange(len(data))
    if len(idx) > max_examples:
        idx = np.sort(np.random.default_rng(seed).choice(idx, size=max_examples, replace=False))
    video_emb = retriever.embed_catalogue(data.features)
    bank = VideoBank(data.features, retriever.device)
    user_emb = retriever.embed_users(bank, {k_: v[idx] for k_, v in data.inputs.items()})
    cat = data.catalogue
    hits = 0
    for j, i in enumerate(idx.tolist()):
        mask = cat.live_mask(data.t[i]) & (cat.context_index == data.context_idx[i])
        scores = video_emb @ user_emb[j]
        target = scores[data.pos_row[i]]
        hits += int(((scores > target) & mask).sum() < k)
    return hits / len(idx)


def train_retriever(train_data: RetrievalData, validation_data: Optional[RetrievalData], config: Config) -> Retriever:
    """Train the two-tower retriever with early stopping on validation Recall@k."""
    rc = config.retrieval
    device = resolve_device(config.device)
    if config.torch_threads > 0:
        torch.set_num_threads(config.torch_threads)
    torch.manual_seed(config.seed)
    rng = np.random.default_rng(config.seed)
    model = TwoTower(train_data.dims, rc).to(device)
    retriever = Retriever(model, train_data.dims, config, device)
    if len(train_data) == 0:
        return retriever
    opt = torch.optim.Adam(model.parameters(), lr=rc.learning_rate, weight_decay=rc.weight_decay)
    bank = VideoBank(train_data.features, device)
    cat = train_data.catalogue
    pool = train_data.negative_pool
    n, bsz, m = len(train_data), rc.batch_size, min(rc.n_uniform_negatives, len(train_data.negative_pool))
    best, best_state, bad = -np.inf, None, 0
    for epoch in range(rc.epochs):
        tic = time.time()
        model.train()
        perm = rng.permutation(n)
        losses = []
        for s in range(0, n, bsz):
            idx = perm[s:s + bsz]
            neg_rows = rng.choice(pool, size=m, replace=False) if m else np.array([], dtype="int64")
            cand = np.concatenate([train_data.pos_row[idx], neg_rows])
            neg_mask, known = build_candidate_masks(train_data, idx, cand)
            q = len(idx) * train_data.video_positive_share[cat.video_index[cand]] + m / max(1, len(pool))
            batch = to_tensors({k: v[idx] for k, v in train_data.inputs.items()}, device)
            u = model.encode_users(bank, batch)
            v = model.encode_videos(bank, torch.as_tensor(cand, device=device))
            loss = sampled_softmax_loss(
                u, v, torch.arange(len(idx), device=device), torch.as_tensor(neg_mask, device=device),
                temperature=rc.temperature, log_q=torch.as_tensor(np.log(q + 1e-12), dtype=torch.float32, device=device),
                logq_weight=rc.logq_correction, extra_positive_mask=torch.as_tensor(known, device=device),
                multi_positive=rc.multi_positive)
            opt.zero_grad()
            loss.backward()
            opt.step()
            losses.append(float(loss.detach()))
        log: dict[str, Any] = {"epoch": epoch + 1, "train_loss": float(np.mean(losses)), "seconds": time.time() - tic}
        if validation_data is not None and len(validation_data):
            model.eval()
            rec = retrieval_recall(retriever, validation_data, rc.validation_k, rc.max_validation_examples, config.seed)
            log[f"validation_recall@{rc.validation_k}"] = rec
            if rec > best + 1e-6:
                best, best_state, bad = rec, copy.deepcopy(model.state_dict()), 0
            else:
                bad += 1
            retriever.history.append(log)
            if bad >= rc.patience:
                break
        else:
            retriever.history.append(log)
    if best_state is not None:
        model.load_state_dict(best_state)
    model.eval()
    return retriever
