"""Ranker training data, training loop and calibration.

Training examples are *logged impressions* (the only place labels exist), featurised as of
their logged request with the **frozen** retriever that was trained on an earlier period.
The retriever therefore never saw the outcomes it helps to predict.
"""
from __future__ import annotations

import copy
import time
from dataclasses import dataclass
from typing import Any, Optional

import numpy as np
import pandas as pd
import torch

from ..config import Config
from ..constants import BINARY_TASKS, CONTEXTS, TASKS
from ..data.catalogue import Catalogue
from ..data.histories import HistoryStore, PreferenceStore
from ..features.space import FeatureSpace, VideoFeatures
from ..features.state import build_request_state
from ..ranking.calibration import PlattCalibrator, fit_platt
from ..ranking.features import DENSE_FEATURES, POSITION_FEATURE, concat_features, ranking_features
from ..ranking.loss import l2_penalty, masked_multitask_loss
from ..ranking.model import MultiTaskRanker, RankerDims
from ..ranking.ranker import Ranker, feature_tensors
from ..retrieval.model import VideoBank
from .retriever import Retriever, resolve_device


@dataclass
class RankingData:
    features: dict[str, np.ndarray]
    targets: np.ndarray                  # (N, n_tasks)
    masks: np.ndarray                    # (N, n_tasks) 1 = label observed and usable
    frame: pd.DataFrame                  # request_id, user_id, t, context_idx, imp_idx (aligned with rows)
    dims: RankerDims

    def __len__(self) -> int:
        return len(self.targets)


def ranker_dims(space: FeatureSpace, config: Config) -> RankerDims:
    return RankerDims(n_dense=len(DENSE_FEATURES), tower_dim=config.retrieval.embedding_dim,
                      n_creators=len(space.creator_vocab) + 2, n_languages=len(space.language_vocab) + 2)


def build_ranking_data(impressions: pd.DataFrame, catalogue: Catalogue, histories: HistoryStore,
                       preferences: PreferenceStore, space: FeatureSpace, features: VideoFeatures,
                       video_embeddings: np.ndarray, retriever: Retriever, config: Config) -> RankingData:
    """Featurise logged impressions request by request, as of each request's first impression."""
    dims = ranker_dims(space, config)
    imps = impressions.sort_values(["request_id", "position", "imp_idx"], kind="mergesort")
    if len(imps) == 0:
        empty = {"dense": np.zeros((0, dims.n_dense), "float32"), "creator": np.zeros(0, "int64"),
                 "language": np.zeros(0, "int64"), "context": np.zeros(0, "int64"),
                 "user_vec": np.zeros((0, dims.tower_dim), "float32"), "video_vec": np.zeros((0, dims.tower_dim), "float32")}
        return RankingData(empty, np.zeros((0, len(TASKS)), "float32"), np.zeros((0, len(TASKS)), "float32"),
                           imps[["request_id", "user_id", "t", "context_idx", "imp_idx"]].copy(), dims)
    bank = VideoBank(features, retriever.device)
    req = imps["request_id"].to_numpy(dtype=object)
    bounds = np.flatnonzero(np.r_[True, req[1:] != req[:-1], True])
    users, ts = imps["user_id"].to_numpy(dtype=object), imps["t"].to_numpy()
    ctx, rows, pos = imps["context_idx"].to_numpy(), imps["row"].to_numpy(), imps["position"].to_numpy()
    states = []
    for s, e in zip(bounds[:-1], bounds[1:]):
        states.append(build_request_state(users[s], CONTEXTS[ctx[s]], float(ts[s:e].min()), catalogue, histories,
                                          preferences, space, config))
    tower = {k: np.stack([st.tower_inputs[k] for st in states]) for k in states[0].tower_inputs}
    user_emb = retriever.embed_users(bank, tower)
    parts = [ranking_features(st, rows[s:e], catalogue, features, video_embeddings, user_emb[i], config, pos[s:e])
             for i, (st, s, e) in enumerate(zip(states, bounds[:-1], bounds[1:]))]
    targets = np.stack([imps[f"y_{t}"].to_numpy(dtype="float32") for t in TASKS], axis=1)
    masks = np.stack([imps[f"m_{t}"].to_numpy(dtype="float32") for t in TASKS], axis=1)
    frame = imps[["request_id", "user_id", "t", "context_idx", "imp_idx"]].reset_index(drop=True)
    return RankingData(concat_features(parts), targets, masks, frame, dims)


def _positive_weights(data: RankingData, config: Config) -> dict[str, float]:
    rc = config.ranker
    weights = {t: 1.0 for t in TASKS}
    if rc.pos_weight != "auto":
        return weights
    for j, task in enumerate(TASKS):
        if task not in BINARY_TASKS:
            continue
        m = data.masks[:, j] > 0
        rate = float(data.targets[m, j].mean()) if m.any() else 0.0
        if 0.0 < rate < rc.pos_weight_rate_threshold:
            weights[task] = float(min(rc.pos_weight_cap, np.sqrt((1.0 - rate) / rate)))
    return weights


def _epoch_loss(model: MultiTaskRanker, tensors: dict[str, torch.Tensor], y: torch.Tensor, m: torch.Tensor,
                config: Config, pos_weights: dict[str, float], batch_size: int = 8192) -> tuple[float, dict[str, float]]:
    """Mean masked validation loss per task (computed over the whole set, not per batch)."""
    model.eval()
    with torch.no_grad():
        logits = torch.cat([model({k: v[s:s + batch_size] for k, v in tensors.items()})
                            for s in range(0, len(y), batch_size)])
        total, per_task = masked_multitask_loss(logits, y, m, TASKS, config.ranker.task_weights, pos_weights)
    return float(total), per_task


def train_ranker(ranking_train: RankingData, ranking_validation: Optional[RankingData], config: Config) -> Ranker:
    """Train the multitask ranker with early stopping on the masked validation loss."""
    rc = config.ranker
    device = resolve_device(config.device)
    torch.manual_seed(config.seed + 1)
    rng = np.random.default_rng(config.seed + 1)
    dims = ranking_train.dims
    model = MultiTaskRanker(dims, rc).to(device)
    n = len(ranking_train)
    dense = ranking_train.features["dense"]
    mean = dense.mean(axis=0) if n else np.zeros(dims.n_dense, "float32")
    std = np.maximum(dense.std(axis=0), 1e-3) if n else np.ones(dims.n_dense, "float32")
    pos_weights = _positive_weights(ranking_train, config)
    ranker = Ranker(model, dims, config, mean, std, pos_weights, device=device)
    if n == 0:
        return ranker
    tensors = feature_tensors(ranking_train.features, ranker.dense_mean, ranker.dense_std, device)
    y = torch.as_tensor(ranking_train.targets, device=device)
    m = torch.as_tensor(ranking_train.masks, device=device)
    has_val = ranking_validation is not None and len(ranking_validation) > 0
    if has_val:
        v_tensors = feature_tensors(ranking_validation.features, ranker.dense_mean, ranker.dense_std, device)
        v_y = torch.as_tensor(ranking_validation.targets, device=device)
        v_m = torch.as_tensor(ranking_validation.masks, device=device)
    opt = torch.optim.Adam(model.parameters(), lr=rc.learning_rate)
    best, best_state, bad = np.inf, None, 0
    for epoch in range(rc.epochs):
        tic = time.time()
        model.train()
        perm = torch.as_tensor(rng.permutation(n), device=device)
        running: list[float] = []
        skipped = {t: 0 for t in TASKS}
        for s in range(0, n, rc.batch_size):
            idx = perm[s:s + rc.batch_size]
            logits = model({k: v[idx] for k, v in tensors.items()})
            loss, per_task = masked_multitask_loss(logits, y[idx], m[idx], TASKS, rc.task_weights, pos_weights)
            for t in TASKS:
                skipped[t] += t not in per_task
            loss = loss + rc.l2 * l2_penalty(model)
            opt.zero_grad()
            loss.backward()
            opt.step()
            running.append(float(loss.detach()))
        log: dict[str, Any] = {"epoch": epoch + 1, "train_loss": float(np.mean(running)), "seconds": time.time() - tic,
                               "batches_without_labels": {t: c for t, c in skipped.items() if c}}
        if has_val:
            val, per_task = _epoch_loss(model, v_tensors, v_y, v_m, config, pos_weights)
            log.update({"validation_loss": val, "validation_task_losses": per_task})
            if val < best - 1e-5:
                best, best_state, bad = val, copy.deepcopy(model.state_dict()), 0
            else:
                bad += 1
            ranker.history.append(log)
            if bad >= rc.patience:
                break
        else:
            ranker.history.append(log)
    if best_state is not None:
        model.load_state_dict(best_state)
    model.eval()
    return ranker


def calibrate_ranker(ranker: Ranker, calibration: RankingData, config: Config) -> dict[str, PlattCalibrator]:
    """Fit one Platt map per head on the calibration window (identity when support is insufficient)."""
    rc = config.ranker
    z = ranker.logits(calibration.features) if len(calibration) else np.zeros((0, len(TASKS)))
    calibrators: dict[str, PlattCalibrator] = {}
    for j, task in enumerate(TASKS):
        mask = calibration.masks[:, j] > 0 if len(calibration) else np.zeros(0, dtype=bool)
        calibrators[task] = fit_platt(z[mask, j], calibration.targets[mask, j], binary=task in BINARY_TASKS,
                                      min_examples=rc.calibration_min_examples,
                                      min_class_support=rc.calibration_min_class_support)
    ranker.calibrators = calibrators
    return calibrators


def zero_position(features: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    """Copy of ``features`` with the position feature set to its serving value (0)."""
    out = dict(features)
    out["dense"] = features["dense"].copy()
    out["dense"][:, POSITION_FEATURE] = 0.0
    return out
