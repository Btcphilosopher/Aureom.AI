"""Chronological splits with a label embargo.

An impression at time ``t`` belongs to the window ``[a, b)`` iff ``a <= t`` **and** its
outcome window has matured before ``b`` (``maturity_time <= b``). The second condition is
the embargo: no label that needed information from after ``b`` can enter the window, so
nothing from a later window leaks into an earlier one through late outcomes.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd

from ..config import Config
from ..constants import CONTEXTS


@dataclass(frozen=True)
class TemporalSplits:
    start: float
    retrieval_train_end: float
    retrieval_valid_end: float      # the retriever is frozen here
    ranker_train_end: float
    ranker_valid_end: float
    calibration_end: float          # everything fitted is frozen here
    end: float

    def window(self, name: str) -> tuple[float, float]:
        return {
            "retrieval_train": (self.start, self.retrieval_train_end),
            "retrieval_valid": (self.retrieval_train_end, self.retrieval_valid_end),
            "ranker_train": (self.retrieval_valid_end, self.ranker_train_end),
            "ranker_valid": (self.ranker_train_end, self.ranker_valid_end),
            "calibration": (self.ranker_valid_end, self.calibration_end),
            "test": (self.calibration_end, self.end),
        }[name]

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


def make_temporal_splits(impressions: pd.DataFrame, config: Config) -> TemporalSplits:
    t = impressions["t"].to_numpy()
    if len(t) == 0:
        raise ValueError("cannot split an empty impression table")
    start, end = float(t.min()), float(t.max()) + 1.0
    s, span = config.splits, end - start
    fracs = [s.retrieval_train_end, s.retrieval_valid_end, s.ranker_train_end, s.ranker_valid_end, s.calibration_end]
    if any(b <= a for a, b in zip([0.0] + fracs, fracs + [1.0])):
        raise ValueError("split fractions must be strictly increasing inside (0, 1)")
    bounds = [start + f * span for f in fracs]
    return TemporalSplits(start, *bounds, end)


def window_examples(impressions: pd.DataFrame, start: float, end: float) -> pd.DataFrame:
    """Impressions shown in ``[start, end)`` whose labels matured before ``end`` (embargo)."""
    t = impressions["t"].to_numpy()
    keep = (t >= start) & (t < end) & (impressions["maturity_time"].to_numpy() <= end) & impressions["matured"].to_numpy()
    return impressions.loc[keep]


def build_evaluation_requests(impressions: pd.DataFrame, start: float, end: float, max_requests: int | None = None,
                              seed: int = 0) -> pd.DataFrame:
    """One simulated request per logged request in ``[start, end)``: (request_id, user_id, context, as_of).

    ``as_of`` is the time of the request's first impression, so the user's history as of the
    request excludes everything the request itself caused.
    """
    win = impressions.loc[(impressions["t"].to_numpy() >= start) & (impressions["t"].to_numpy() < end)]
    req = win.groupby("request_id", sort=True).agg(
        user_id=("user_id", "first"), context_idx=("context_idx", "first"), as_of=("t", "min"),
        logging_policy_id=("logging_policy_id", "first")).reset_index()
    req["context"] = np.asarray(CONTEXTS, dtype=object)[req["context_idx"].to_numpy()]
    req = req.sort_values(["as_of", "request_id"], kind="mergesort").reset_index(drop=True)
    if max_requests is not None and len(req) > max_requests:
        idx = np.sort(np.random.default_rng(seed).choice(len(req), size=max_requests, replace=False))
        req = req.iloc[idx].reset_index(drop=True)
    return req
