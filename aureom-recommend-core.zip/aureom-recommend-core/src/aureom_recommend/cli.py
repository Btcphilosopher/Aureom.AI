"""Command-line entry points (also exposed as thin wrappers in ``scripts/``).

    generate   write a synthetic dataset (Parquet) for a scenario
    baselines  fit and evaluate one or all baselines
    train      run the chronological training pipeline and save versioned artefacts
    evaluate   retrieval, ranking and full-feed evaluation (+ plots) against all baselines
    recommend  print one feed as JSON
    ablations  retrieval-source, duration-target, ranking-head and diversity ablations
    scenarios  preference-recovery, duration-bias, popularity-bias and cold-start worlds
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import warnings
from pathlib import Path
from typing import Any, Optional, Sequence

import numpy as np

from .config import Config, load_config

warnings.filterwarnings("ignore", message=".*UserWarning.*")


def _log(msg: str) -> None:
    print(msg, flush=True)


def _config(args: argparse.Namespace) -> Config:
    cfg = load_config(args.config) if getattr(args, "config", None) else Config()
    if getattr(args, "seed", None) is not None:
        cfg.seed = int(args.seed)
    return cfg


def _load(data_dir: str, config: Config) -> tuple[Any, Any]:
    """Read the Parquet tables and prepare point-in-time data; the oracle is returned separately (may be None)."""
    from .data.io import read_dataset
    from .training.pipeline import prepare_data

    videos, interactions, preferences = read_dataset(data_dir)
    prepared = prepare_data(videos, interactions, preferences, config)
    oracle = None
    if (Path(data_dir) / "oracle" / "oracle.npz").exists():      # synthetic data only; used for evaluation only
        from .data.synthetic import Oracle
        oracle = Oracle.load(Path(data_dir) / "oracle")
    return prepared, oracle


def generate_main(argv: Optional[Sequence[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Generate a seeded synthetic dataset.")
    p.add_argument("--scenario", default="default")
    p.add_argument("--out", required=True)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--users", type=int, default=None)
    p.add_argument("--videos", type=int, default=None)
    p.add_argument("--days", type=int, default=None)
    args = p.parse_args(argv)
    from .data.synthetic import generate_synthetic, scenario_config

    overrides = {k: v for k, v in {"seed": args.seed, "n_users": args.users, "n_videos": args.videos,
                                   "n_days": args.days}.items() if v is not None}
    tic = time.time()
    ds = generate_synthetic(scenario_config(args.scenario, **overrides))
    ds.save(args.out)
    _log(f"SYNTHETIC dataset written to {args.out} in {time.time() - tic:.1f}s: {json.dumps(ds.summary)}")
    return 0


def baselines_main(argv: Optional[Sequence[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Fit and evaluate baselines on the test window.")
    p.add_argument("--data", required=True)
    p.add_argument("--baseline", default="all")
    p.add_argument("--config", default=None)
    p.add_argument("--out", default=None)
    p.add_argument("--max-requests", type=int, default=None)
    args = p.parse_args(argv)
    from .baselines.models import BASELINE_NAMES
    from .evaluation.report import evaluate_baselines, feed_summary, fit_baselines, test_requests, write_json

    cfg = _config(args)
    prepared, oracle = _load(args.data, cfg)
    fitted = fit_baselines(prepared, cfg)
    if args.baseline != "all":
        if args.baseline not in fitted:
            p.error(f"unknown baseline {args.baseline!r}; choose from {BASELINE_NAMES} or 'all'")
        fitted = {args.baseline: fitted[args.baseline]}
    results = evaluate_baselines(prepared, cfg, test_requests(prepared, cfg, args.max_requests), oracle, fitted, _log)
    if args.out:
        write_json({"synthetic_data": oracle is not None, "feed": {n: r.to_dict() for n, r in results.items()},
                    "feed_summary": {n: feed_summary(r) for n, r in results.items()}}, args.out)
        _log(f"wrote {args.out}")
    return 0


def train_main(argv: Optional[Sequence[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Train retriever and ranker chronologically; save artefacts.")
    p.add_argument("--data", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--config", default=None)
    p.add_argument("--seed", type=int, default=None)
    args = p.parse_args(argv)
    from .artefacts.store import save_artefacts
    from .training.pipeline import train_pipeline

    cfg = _config(args)
    tic = time.time()
    prepared, _ = _load(args.data, cfg)
    _log(f"prepared data in {time.time() - tic:.1f}s: {json.dumps(prepared.reports['examples']['state_counts'])}")
    tic = time.time()
    artefacts = train_pipeline(prepared, cfg, log=_log)
    artefacts.report["data"] = prepared.reports
    save_artefacts(artefacts, args.out)
    _log(f"trained {artefacts.model_version} in {time.time() - tic:.1f}s; artefacts saved to {args.out}")
    return 0


def evaluate_main(argv: Optional[Sequence[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Evaluate retrieval, ranking and full feeds against all baselines.")
    p.add_argument("--data", required=True)
    p.add_argument("--artefacts", required=True)
    p.add_argument("--out", required=True, help="directory for metrics.json and plots")
    p.add_argument("--max-requests", type=int, default=None)
    p.add_argument("--no-plots", action="store_true")
    args = p.parse_args(argv)
    from .artefacts.store import load_artefacts
    from .evaluation.report import evaluate_all, write_json
    from .evaluation.scenarios import VALID_SYNTHETIC_PROPENSITY_POLICIES

    artefacts = load_artefacts(args.artefacts)
    prepared, oracle = _load(args.data, artefacts.config)
    # targets come from the baseline stored with the model - nothing is re-fitted at evaluation time
    prepared.examples.impressions = artefacts.duration_baseline.transform(prepared.impressions,
                                                                          artefacts.config.ranker.duration_target)
    policies = VALID_SYNTHETIC_PROPENSITY_POLICIES if oracle is not None else None
    results = evaluate_all(prepared, artefacts, oracle, policies, _log, args.max_requests)
    out = Path(args.out)
    write_json(results, out / "metrics.json")
    _log(f"wrote {out / 'metrics.json'}")
    if not args.no_plots:
        for path in make_plots(results, out):
            _log(f"wrote {path}")
    return 0


def make_plots(results: dict[str, Any], out: Path) -> list[Path]:
    from .evaluation.plots import bar_comparison, recall_curve, reliability_plot

    paths: list[Path] = []
    tag = " (synthetic data)" if results.get("synthetic_data") else ""
    summary = results["feed_summary"]
    names = list(summary)
    feed = results["feed"]
    k = feed["learned_system"]["metrics"]["k"]
    for metric, title, note in (
            (f"recall@{k}", f"Feed Recall@{k} against logged positives{tag}",
             "Full eligible catalogue; label = future positive impressions. Biased towards the logging policy."),
            (f"oracle_ndcg@{k}", f"Feed oracle NDCG@{k}{tag}", "Graded by simulator ground truth; not available on real data."),
            ("intra_list_diversity", f"Intra-list diversity of the feed{tag}", "1 - mean pairwise content cosine.")):
        if metric not in feed["learned_system"]["metrics"]:
            continue
        ms = [feed[n]["metrics"][metric] for n in names]
        paths.append(bar_comparison(names, [m["mean"] for m in ms], out / f"feed_{metric.replace('@', '_at_')}.png", title,
                                    metric, [m["ci_low"] for m in ms], [m["ci_high"] for m in ms],
                                    highlight=("learned_system",), note=note + " Lines: 95% user-bootstrap intervals."))
    scorers = results["retrieval"]["scorers"]
    ks = sorted(int(c.split("@")[1]) for c in next(iter(scorers.values())) if c.startswith("recall@"))
    if ks:
        ranked = sorted(scorers, key=lambda n: -scorers[n][f"recall@{ks[-1]}"]["mean"])
        chosen = ["two_tower"] + [n for n in ranked if n != "two_tower"][:3]
        paths.append(recall_curve({n: {kk: scorers[n][f"recall@{kk}"]["mean"] for kk in ks} for n in chosen},
                                  out / "retrieval_recall_curve.png",
                                  f"Retrieval Recall@K over the full eligible catalogue{tag}"))
    if results["ranking"].get("reliability"):
        paths.append(reliability_plot(results["ranking"]["reliability"], out / "ranker_reliability.png",
                                      f"Ranker reliability on the test window{tag}"))
    return paths


def recommend_main(argv: Optional[Sequence[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Print one recommended feed as JSON.")
    p.add_argument("--data", required=True)
    p.add_argument("--artefacts", required=True)
    p.add_argument("--user-id", required=True)
    p.add_argument("--context", default="short_form", choices=("short_form", "long_form"))
    p.add_argument("--as-of", default=None, help="ISO timestamp (UTC); defaults to the end of the log")
    p.add_argument("-k", type=int, default=20)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args(argv)
    from .artefacts.store import load_artefacts
    from .data.timeutil import as_epoch
    from .inference.recommend import recommend

    artefacts = load_artefacts(args.artefacts)
    prepared, _ = _load(args.data, artefacts.config)
    as_of = as_epoch(args.as_of) if args.as_of else prepared.examples.cutoff
    feed = recommend(user_id=args.user_id, context=args.context, as_of=as_of, k=args.k, catalogue=prepared.catalogue,
                     histories=prepared.histories, preferences=prepared.preferences, artefacts=artefacts,
                     previously_recommended=set(), seed=args.seed)
    json.dump({"user_id": feed.user_id, "context": feed.context, "as_of": feed.as_of, "diagnostics": feed.diagnostics,
               "items": feed.to_records()}, sys.stdout, indent=2, default=lambda o: o.item() if isinstance(o, np.generic) else str(o))
    sys.stdout.write("\n")
    return 0


def ablations_main(argv: Optional[Sequence[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Run ablations (retrieval sources, duration target, heads, diversity).")
    p.add_argument("--data", required=True)
    p.add_argument("--artefacts", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--max-requests", type=int, default=600)
    p.add_argument("--no-retrain", action="store_true", help="skip ablations that retrain models")
    args = p.parse_args(argv)
    from .artefacts.store import load_artefacts
    from .evaluation.report import run_ablations, write_json
    from .training.pipeline import fit_duration_targets

    artefacts = load_artefacts(args.artefacts)
    prepared, oracle = _load(args.data, artefacts.config)
    fit_duration_targets(prepared, artefacts.config)
    results = run_ablations(prepared, artefacts, oracle, _log, args.max_requests, retrain=not args.no_retrain)
    write_json(results, args.out)
    _log(f"wrote {args.out}")
    return 0


def scenarios_main(argv: Optional[Sequence[str]] = None) -> int:
    p = argparse.ArgumentParser(description="Run the four synthetic scenarios end to end.")
    p.add_argument("--out", required=True)
    p.add_argument("--config", default=None)
    p.add_argument("--scenario", default="all")
    p.add_argument("--max-requests", type=int, default=500)
    args = p.parse_args(argv)
    from .evaluation.report import write_json
    from .evaluation.scenarios import SCENARIO_QUESTIONS, run_scenario

    cfg = _config(args)
    names = list(SCENARIO_QUESTIONS) if args.scenario == "all" else [args.scenario]
    results = {}
    for name in names:
        tic = time.time()
        results[name] = run_scenario(name, cfg, _log, args.max_requests)
        _log(f"scenario {name} finished in {time.time() - tic:.1f}s")
    write_json(results, args.out)
    _log(f"wrote {args.out}")
    return 0
