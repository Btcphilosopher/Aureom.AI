"""AUREOM RECOMMEND - core feed algorithm.

Public interface (see README.md for a walk-through)::

    events    = clean_events(raw_events, config)
    examples  = build_examples(events=events, catalogue=catalogue, cutoff=cutoff, config=config)
    retriever = train_retriever(train_data, validation_data, config)
    ranker    = train_ranker(ranking_train, ranking_validation, config)
    feed      = recommend(user_id=..., context="short_form", as_of=..., k=20, catalogue=catalogue,
                          histories=histories, preferences=preferences, artefacts=artefacts,
                          previously_recommended=set(), seed=42)
    metrics   = evaluate_recommender(recommender=recommend, evaluation_requests=requests, ...)
"""
__version__ = "0.1.0"

from .artefacts.bundle import RecommenderArtefacts  # noqa: E402
from .artefacts.store import ArtefactCompatibilityError, load_artefacts, save_artefacts  # noqa: E402
from .config import Config, load_config  # noqa: E402
from .data.catalogue import Catalogue  # noqa: E402
from .data.events import clean_events  # noqa: E402
from .data.histories import HistoryStore, PreferenceStore  # noqa: E402
from .data.labels import ExampleSet, build_examples  # noqa: E402
from .data.schemas import (InteractionRecord, UserPreferences, VideoRecord, validate_interactions,  # noqa: E402
                           validate_preferences, validate_videos)
from .evaluation.offline import evaluate_recommender  # noqa: E402
from .inference.recommend import recommend  # noqa: E402
from .inference.types import Feed, FeedItem  # noqa: E402
from .training.pipeline import prepare_data, train_pipeline  # noqa: E402
from .training.ranker import build_ranking_data, calibrate_ranker, train_ranker  # noqa: E402
from .training.retriever import build_retrieval_data, train_retriever  # noqa: E402
from .training.splits import build_evaluation_requests, make_temporal_splits, window_examples  # noqa: E402

__all__ = [
    "ArtefactCompatibilityError", "Catalogue", "Config", "ExampleSet", "Feed", "FeedItem", "HistoryStore",
    "InteractionRecord", "PreferenceStore", "RecommenderArtefacts", "UserPreferences", "VideoRecord",
    "build_evaluation_requests", "build_examples", "build_ranking_data", "build_retrieval_data", "calibrate_ranker",
    "clean_events", "evaluate_recommender", "load_artefacts", "load_config", "make_temporal_splits", "prepare_data",
    "recommend", "save_artefacts", "train_pipeline", "train_ranker", "train_retriever", "validate_interactions",
    "validate_preferences", "validate_videos", "window_examples",
]
