"""Metric primitives. Each ranking metric is defined for one ranked list against a relevant set."""
from __future__ import annotations

from typing import Sequence

import numpy as np


def recall_at_k(ranked: Sequence, relevant: set, k: int) -> float:
    """|top-k ∩ relevant| / |relevant| (NaN when there is nothing relevant)."""
    if not relevant:
        return float("nan")
    return len(set(ranked[:k]) & relevant) / len(relevant)


def ndcg_at_k(ranked: Sequence, relevant: set, k: int) -> float:
    """Binary-gain NDCG@k with the ideal DCG computed over min(k, |relevant|) items."""
    if not relevant:
        return float("nan")
    dcg = sum(1.0 / np.log2(i + 2) for i, v in enumerate(ranked[:k]) if v in relevant)
    ideal = sum(1.0 / np.log2(i + 2) for i in range(min(k, len(relevant))))
    return float(dcg / ideal)


def graded_ndcg_at_k(gains_in_rank_order: np.ndarray, all_gains: np.ndarray, k: int) -> float:
    """NDCG@k with graded gains; the ideal ordering is taken over ``all_gains`` (the candidate universe)."""
    gains = np.asarray(gains_in_rank_order, dtype="float64")[:k]
    ideal = np.sort(np.asarray(all_gains, dtype="float64"))[::-1][:k]
    disc = 1.0 / np.log2(np.arange(2, k + 2))
    idcg = float((ideal * disc[:len(ideal)]).sum())
    if idcg <= 0:
        return float("nan")
    return float((gains * disc[:len(gains)]).sum() / idcg)


def reciprocal_rank(ranked: Sequence, relevant: set) -> float:
    """1 / rank of the first relevant item, 0 if none is in the list (NaN when nothing is relevant)."""
    if not relevant:
        return float("nan")
    for i, v in enumerate(ranked):
        if v in relevant:
            return 1.0 / (i + 1)
    return 0.0


def brier_score(y: np.ndarray, p: np.ndarray, w: np.ndarray | None = None) -> float:
    y, p = np.asarray(y, dtype="float64"), np.asarray(p, dtype="float64")
    if len(y) == 0:
        return float("nan")
    return float(np.average((p - y) ** 2, weights=w))


def expected_calibration_error(y: np.ndarray, p: np.ndarray, n_bins: int = 10) -> float:
    """Equal-width-bin ECE: sum_b (n_b / n) * |mean(y_b) - mean(p_b)|. Works for soft labels in [0, 1]."""
    y, p = np.asarray(y, dtype="float64"), np.asarray(p, dtype="float64")
    if len(y) == 0:
        return float("nan")
    bins = np.minimum((p * n_bins).astype(int), n_bins - 1)
    ece = 0.0
    for b in range(n_bins):
        m = bins == b
        if m.any():
            ece += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(ece)


def reliability_curve(y: np.ndarray, p: np.ndarray, n_bins: int = 10,
                      strategy: str = "quantile") -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """(mean prediction, mean outcome, count) per non-empty bin.

    ``"quantile"`` uses equal-count bins, which keeps rare-event heads readable (their predictions
    all fall into the first equal-width bin); ``"uniform"`` uses the equal-width bins of the ECE.
    """
    y, p = np.asarray(y, dtype="float64"), np.asarray(p, dtype="float64")
    if len(y) == 0:
        return np.array([]), np.array([]), np.array([])
    if strategy == "quantile":
        edges = np.unique(np.quantile(p, np.linspace(0, 1, n_bins + 1)))
        bins = np.clip(np.searchsorted(edges, p, side="right") - 1, 0, max(len(edges) - 2, 0))
    else:
        bins = np.minimum((p * n_bins).astype(int), n_bins - 1)
    xs, ys, ns = [], [], []
    for b in np.unique(bins):
        m = bins == b
        xs.append(p[m].mean()), ys.append(y[m].mean()), ns.append(int(m.sum()))
    return np.asarray(xs), np.asarray(ys), np.asarray(ns)


def auc(y: np.ndarray, score: np.ndarray) -> float:
    """Rank-based ROC AUC with tie handling (NaN if only one class is present)."""
    y = np.asarray(y) > 0.5
    n_pos, n_neg = int(y.sum()), int((~y).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    s = np.asarray(score)[order]
    ranks = np.empty(len(s), dtype="float64")
    i = 0
    while i < len(s):
        j = i
        while j + 1 < len(s) and s[j + 1] == s[i]:
            j += 1
        ranks[order[i:j + 1]] = 0.5 * (i + j) + 1.0
        i = j + 1
    return float((ranks[y].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def intra_list_diversity(vectors: np.ndarray) -> float:
    """1 - mean pairwise cosine similarity of the (L2-normalised) item vectors; NaN for < 2 items."""
    n = len(vectors)
    if n < 2:
        return float("nan")
    sim = vectors @ vectors.T
    return float(1.0 - (sim.sum() - np.trace(sim)) / (n * (n - 1)))


def gini(counts: np.ndarray) -> float:
    """Gini coefficient of a non-negative exposure vector (0 = equal, 1 = fully concentrated)."""
    x = np.sort(np.asarray(counts, dtype="float64"))
    if len(x) == 0 or x.sum() == 0:
        return float("nan")
    n = len(x)
    return float((2.0 * np.sum(np.arange(1, n + 1) * x) / (n * x.sum())) - (n + 1.0) / n)
