"""Retrieval-stage evaluation.

``evaluate_retrieval`` - full-catalogue ranking metrics for *scorers*
    Relevance label: matured positive impressions of the user within the horizon after the
    request (same label as the feed metrics). Candidate universe: every row eligible for
    the request (hard eligibility only). Each scorer ranks that whole universe; metrics are
    Recall@K, NDCG@K and MRR. Because all scorers rank the same full universe these numbers
    are comparable with each other - but not with logged-slate ranking metrics.

``evaluate_candidate_generation`` - coverage of the hybrid candidate *set*
    Fraction of relevant videos inside the (unordered) candidate set, per source and for the
    union, plus - on synthetic data - how much of the oracle-ideal top-k the set contains.
"""
from __future__ import annotations

from typing import Any, Callable, Mapping, Optional

import numpy as np
import pandas as pd

from ..artefacts.bundle import RecommenderArtefacts
from ..composition.eligibility import hard_eligibility_mask
from ..config import Config
from ..constants import DAY, SOURCES
from ..data.catalogue import Catalogue
from ..data.histories import HistoryStore, PreferenceStore
from ..features.space import FeatureSpace
from ..features.state import RequestState, build_request_state
from ..inference.recommend import request_rng
from ..retrieval.candidates import generate_candidates
from .bootstrap import user_bootstrap_ci
from .offline import RelevanceIndex

Scorer = Callable[[RequestState, np.ndarray], np.ndarray]

RETRIEVAL_DEFINITIONS = {
    "relevance_label": "matured positive impression of the video by the same user within [as_of, as_of + horizon]",
    "candidate_universe": "full eligible catalogue for the user, context and request time (every scorer ranks all of it)",
    "intervals": "95% percentile bootstrap, users resampled",
}


def two_tower_scorer(artefacts: RecommenderArtefacts, catalogue: Catalogue) -> Scorer:
    runtime = artefacts.runtime(catalogue)

    def score(state: RequestState, rows: np.ndarray) -> np.ndarray:
        return runtime.video_embeddings[rows] @ artefacts.retriever.embed_user(runtime.bank, state.tower_inputs)

    return score


def evaluate_retrieval(scorers: Mapping[str, Scorer], requests: pd.DataFrame, *, catalogue: Catalogue,
                       histories: HistoryStore, preferences: PreferenceStore, impressions: pd.DataFrame,
                       config: Config, space: Optional[FeatureSpace] = None, oracle: Any = None,
                       seed: int = 0) -> dict[str, Any]:
    ec = config.evaluation
    horizon = ec.relevance_horizon_days * DAY
    ks = list(ec.retrieval_ks)
    relevance = RelevanceIndex(impressions, float(requests["as_of"].min()), float(requests["as_of"].max()) + horizon)
    rows_out: dict[str, list[dict[str, Any]]] = {name: [] for name in scorers}
    for req in requests.itertuples(index=False):
        t = float(req.as_of)
        rel = relevance.relevant(req.user_id, t, horizon)
        if not rel:
            continue
        state = build_request_state(req.user_id, req.context, t, catalogue, histories, preferences, space, config)
        el = np.flatnonzero(hard_eligibility_mask(state, catalogue, config))
        if len(el) == 0:
            continue
        is_rel = np.isin(catalogue.video_ids[el].astype(str), list(rel))
        n_rel = len(rel)                                     # relevant videos outside the universe count as misses
        util = oracle.utility(req.user_id, catalogue.video_ids[el]) if oracle is not None else None
        for name, scorer in scorers.items():
            s = np.asarray(scorer(state, el), dtype="float64")
            order = np.lexsort((el, -s))
            ranks = np.flatnonzero(is_rel[order]) + 1        # 1-based ranks of relevant items
            rec: dict[str, Any] = {"user_id": req.user_id, "context": req.context,
                                   "mrr": float(1.0 / ranks[0]) if len(ranks) else 0.0}
            for k in ks:
                hits = ranks[ranks <= k]
                rec[f"recall@{k}"] = len(hits) / n_rel
                ideal = (1.0 / np.log2(np.arange(2, min(k, n_rel) + 2))).sum()
                rec[f"ndcg@{k}"] = float((1.0 / np.log2(hits + 1)).sum() / ideal)
            if util is not None:
                rec["oracle_utility@20"] = float(np.nanmean(util[order[:20]]))
            rows_out[name].append(rec)
    result: dict[str, Any] = {"definitions": RETRIEVAL_DEFINITIONS, "scorers": {}}
    for name, recs in rows_out.items():
        frame = pd.DataFrame(recs)
        summary: dict[str, Any] = {"n_requests": int(len(frame))}
        if len(frame):
            users = frame["user_id"].to_numpy(dtype=object)
            for col in [c for c in frame.columns if c not in ("user_id", "context")]:
                mean, lo, hi = user_bootstrap_ci(frame[col].to_numpy(dtype="float64"), users, ec.bootstrap_samples, seed)
                summary[col] = {"mean": mean, "ci_low": lo, "ci_high": hi}
            main = f"recall@{ks[-1]}"
            summary["by_context"] = {str(c): float(g[main].mean()) for c, g in frame.groupby("context")}
        result["scorers"][name] = summary
    return result


def evaluate_candidate_generation(artefacts: RecommenderArtefacts, requests: pd.DataFrame, *, catalogue: Catalogue,
                                  histories: HistoryStore, preferences: PreferenceStore, impressions: pd.DataFrame,
                                  oracle: Any = None, seed: int = 0, ideal_k: int = 20) -> dict[str, Any]:
    cfg = artefacts.config
    horizon = cfg.evaluation.relevance_horizon_days * DAY
    relevance = RelevanceIndex(impressions, float(requests["as_of"].min()), float(requests["as_of"].max()) + horizon)
    runtime = artefacts.runtime(catalogue)
    recs: list[dict[str, Any]] = []
    for i, req in enumerate(requests.itertuples(index=False)):
        t = float(req.as_of)
        state = build_request_state(req.user_id, req.context, t, catalogue, histories, preferences, artefacts.space, cfg)
        eligible = hard_eligibility_mask(state, catalogue, cfg)
        if not eligible.any():
            continue
        user_emb = artefacts.retriever.embed_user(runtime.bank, state.tower_inputs)
        cands = generate_candidates(state, catalogue, eligible, cfg, request_rng(seed + i, state.user_id, req.context, t),
                                    user_embedding=user_emb, index=runtime.index,
                                    content_vectors=runtime.features.content_vectors)
        rel = relevance.relevant(req.user_id, t, horizon)
        cand_ids = catalogue.video_ids[cands.rows].astype(str)
        rec: dict[str, Any] = {"user_id": req.user_id, "n_candidates": len(cands), "n_eligible": int(eligible.sum())}
        if rel:
            in_set = np.isin(cand_ids, list(rel))
            rec["candidate_recall"] = float(in_set.sum() / len(rel))
            for src in SOURCES:
                member = np.array([src in s for s in cands.sources], dtype=bool)
                rec[f"recall/{src}"] = float((in_set & member).sum() / len(rel))
        if oracle is not None:
            el = np.flatnonzero(eligible)
            util = np.nan_to_num(oracle.utility(req.user_id, catalogue.video_ids[el]))
            top = set(el[np.argsort(-util)[:ideal_k]].tolist())
            rec["oracle_ideal_coverage"] = len(top & set(cands.rows.tolist())) / max(1, len(top))
        recs.append(rec)
    frame = pd.DataFrame(recs)
    out: dict[str, Any] = {
        "definitions": {"relevance_label": RETRIEVAL_DEFINITIONS["relevance_label"],
                        "candidate_universe": "the unordered hybrid candidate set vs. the full eligible catalogue",
                        "oracle_ideal_coverage": f"share of the oracle-ideal top-{ideal_k} eligible videos inside the set (synthetic only)"},
        "n_requests": int(len(frame)),
    }
    for col in [c for c in frame.columns if c != "user_id"]:
        out[col] = float(np.nanmean(frame[col].to_numpy(dtype="float64")))
    return out
