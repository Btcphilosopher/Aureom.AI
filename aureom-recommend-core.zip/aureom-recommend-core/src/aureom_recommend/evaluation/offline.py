"""Full-feed offline evaluation by rolling replay.

For every evaluation request ``(user, context, as_of)`` the recommender is called exactly as
in production; the user's history and all aggregate statistics are whatever had been
received before ``as_of`` (the :class:`HistoryStore` enforces this).

Relevance label (feed metrics)
    A video is *relevant* for a request iff the same user had a matured **positive**
    impression of it (meaningful view, or like/save/share) at a time in
    ``[as_of, as_of + horizon]`` inside the evaluation window.
Candidate universe
    The full catalogue eligible for that user, context and time (hard eligibility only).
    These are full-catalogue metrics and must not be compared with metrics computed on a
    logged slate or on sampled candidates.

Exposure bias
    Relevance is only observed for videos the *logging policy* chose to show. A recommender
    that agrees with the logging policy is rewarded; one that finds good videos the policy
    never showed gets no credit. Offline hit metrics are therefore a biased, usually
    pessimistic, proxy for learned models, and are biased in favour of whatever the logging
    policy favoured (here: popular creators). On synthetic data the *oracle* metrics below
    do not have this problem; on real data use the propensity-weighted estimator when (and
    only when) valid propensities exist - see evaluation/propensity.py.

Oracle metrics (synthetic data only)
    ``oracle_utility@k`` is the mean true relevance of the feed, ``oracle_ndcg@k`` its graded
    NDCG against the ideal ordering of the same eligible universe.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import numpy as np
import pandas as pd

from ..composition.eligibility import hard_eligibility_mask
from ..config import Config
from ..constants import DAY
from ..data.catalogue import Catalogue
from ..data.histories import HistoryStore, PreferenceStore
from ..features.state import build_request_state
from ..inference.types import Feed
from .bootstrap import user_bootstrap_ci
from .metrics import gini, graded_ndcg_at_k, intra_list_diversity, ndcg_at_k, recall_at_k, reciprocal_rank

FEED_DEFINITIONS = {
    "relevance_label": "matured positive impression (meaningful view or like/save/share) of the video by the same "
                       "user within [as_of, as_of + horizon] in the evaluation window",
    "candidate_universe": "full eligible catalogue for the user, context and request time",
    "intervals": "95% percentile bootstrap, users resampled",
    "exposure_bias": "labels exist only for logged exposures; hit metrics favour agreement with the logging policy",
    "oracle": "synthetic ground-truth relevance; available for simulated data only",
}


@dataclass
class EvaluationResult:
    name: str
    metrics: dict[str, Any]
    slices: dict[str, dict[str, dict[str, Any]]]
    per_request: pd.DataFrame
    definitions: dict[str, str] = field(default_factory=lambda: dict(FEED_DEFINITIONS))
    feeds: list[Feed] = field(default_factory=list, repr=False)

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "definitions": self.definitions, "metrics": self.metrics, "slices": self.slices}

    def value(self, metric: str) -> float:
        m = self.metrics[metric]
        return m["mean"] if isinstance(m, dict) else m


class RelevanceIndex:
    """Future positives per user inside an evaluation window."""

    def __init__(self, impressions: pd.DataFrame, start: float, end: float) -> None:
        t = impressions["t"].to_numpy()
        pos = impressions.loc[impressions["is_positive"].to_numpy() & impressions["matured"].to_numpy()
                              & (t >= start) & (t < end)].sort_values("t", kind="mergesort")
        self._by_user: dict[str, tuple[np.ndarray, np.ndarray]] = {
            u: (g["t"].to_numpy(), g["video_id"].to_numpy(dtype=object)) for u, g in pos.groupby("user_id", sort=False)}

    def relevant(self, user_id: str, t: float, horizon: float) -> set[str]:
        hit = self._by_user.get(str(user_id))
        if hit is None:
            return set()
        times, vids = hit
        lo, hi = np.searchsorted(times, t, side="left"), np.searchsorted(times, t + horizon, side="right")
        return set(vids[lo:hi].tolist())


def evaluate_recommender(recommender: Callable[..., Feed], evaluation_requests: pd.DataFrame, *, catalogue: Catalogue,
                         histories: HistoryStore, preferences: PreferenceStore, impressions: pd.DataFrame,
                         config: Config, artefacts: Any = None, k: Optional[int] = None, oracle: Any = None,
                         seed: int = 42, name: str = "recommender", keep_feeds: bool = False) -> EvaluationResult:
    """Replay ``evaluation_requests`` through ``recommender`` and compute feed-level metrics."""
    ec = config.evaluation
    k = int(k or ec.feed_k)
    ks = sorted({kk for kk in ec.ks if kk <= k} | {k})
    horizon = ec.relevance_horizon_days * DAY
    start, end = float(evaluation_requests["as_of"].min()), float(evaluation_requests["as_of"].max()) + horizon
    relevance = RelevanceIndex(impressions, start, end)
    unit = catalogue.content_embedding / np.maximum(np.linalg.norm(catalogue.content_embedding, axis=1, keepdims=True), 1e-12)
    new_age = config.features.new_video_days * DAY

    records: list[dict[str, Any]] = []
    feeds: list[Feed] = []
    recommended_videos: set[int] = set()
    eligible_videos = np.zeros(catalogue.n_videos, dtype=bool)
    creator_exposure = np.zeros(catalogue.n_creators)
    for i, req in enumerate(evaluation_requests.itertuples(index=False)):
        t = float(req.as_of)
        tic = time.perf_counter()
        feed = recommender(user_id=req.user_id, context=req.context, as_of=t, k=k, catalogue=catalogue,
                           histories=histories, preferences=preferences, artefacts=artefacts,
                           previously_recommended=set(), seed=seed + i)
        latency = (time.perf_counter() - tic) * 1e3
        if keep_feeds:
            feeds.append(feed)
        state = build_request_state(req.user_id, req.context, t, catalogue, histories, preferences, None, config)
        eligible = hard_eligibility_mask(state, catalogue, config)
        eligible_videos[catalogue.video_index[eligible]] = True
        ranked = feed.video_ids
        vidx = catalogue.video_idx(ranked)
        rows = catalogue.rows_at(vidx, t)
        rel = relevance.relevant(req.user_id, t, horizon)
        rec: dict[str, Any] = {
            "request_id": req.request_id, "user_id": req.user_id, "context": req.context, "as_of": t,
            "n_items": len(ranked), "n_relevant": len(rel), "latency_ms": latency,
            "user_segment": "new" if state.is_new_user else "established",
            "history_segment": "sparse" if state.history_len < config.features.sparse_history_threshold else "dense",
            "n_eligible": int(eligible.sum()),
            "violations": int((~eligible[rows]).sum()) if len(rows) else 0,
        }
        for kk in ks:
            rec[f"recall@{kk}"] = recall_at_k(ranked, rel, kk)
            rec[f"ndcg@{kk}"] = ndcg_at_k(ranked, rel, kk)
        rec["mrr"] = reciprocal_rank(ranked, rel)
        # relevant videos split by age at request time (new vs established videos)
        if rel:
            rel_idx = catalogue.video_idx(sorted(rel))
            age = t - catalogue.published_at[catalogue.rows_at(rel_idx, t)]
            rel_list = np.array(sorted(rel), dtype=object)
            for seg, m in (("new_video", age < new_age), ("established_video", age >= new_age)):
                rec[f"recall@{k}/{seg}"] = recall_at_k(ranked, set(rel_list[m].tolist()), k)
        if len(rows):
            creators = catalogue.creator_index[rows]
            _, counts = np.unique(creators, return_counts=True)
            groups = catalogue.duplicate_group[rows]
            rec.update({
                "creator_concentration": float(counts.max() / len(rows)),
                "unique_creators": int(len(counts)),
                "intra_list_diversity": intra_list_diversity(unit[rows]),
                "duplicate_rate": float(1.0 - len(np.unique(groups)) / len(rows)),
                "repeat_rate": float(np.isin(vidx, state.consumed_video_idx).mean()),
                "new_video_exposure": float(((t - catalogue.published_at[rows]) < new_age).mean()),
                "mean_log_duration": float(np.log(catalogue.duration[rows]).mean()),
                "exploration_share": float(np.mean([it.exploration.get("is_exploration", False) for it in feed.items])),
            })
            recommended_videos.update(vidx.tolist())
            np.add.at(creator_exposure, creators, 1.0)
        if oracle is not None and eligible.any():
            el_rows = np.flatnonzero(eligible)
            u_all = oracle.utility(req.user_id, catalogue.video_ids[el_rows])
            if len(rows) and not np.all(np.isnan(u_all)):
                u_feed = oracle.utility(req.user_id, ranked)
                rec[f"oracle_utility@{k}"] = float(np.nanmean(u_feed))
                rec[f"oracle_ndcg@{k}"] = graded_ndcg_at_k(np.nan_to_num(u_feed), np.nan_to_num(u_all), k)
        records.append(rec)

    per_request = pd.DataFrame(records)
    users = per_request["user_id"].to_numpy(dtype=object)

    def summarise(frame: pd.DataFrame, columns: list[str]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        u = frame["user_id"].to_numpy(dtype=object)
        for col in columns:
            if col not in frame.columns:
                continue
            vals = frame[col].to_numpy(dtype="float64")
            mean, lo, hi = user_bootstrap_ci(vals, u, ec.bootstrap_samples, seed)
            out[col] = {"mean": mean, "ci_low": lo, "ci_high": hi, "n_requests": int((~np.isnan(vals)).sum())}
        return out

    rank_cols = [f"{m}@{kk}" for kk in ks for m in ("recall", "ndcg")] + ["mrr"]
    seg_cols = [f"recall@{k}/new_video", f"recall@{k}/established_video"]
    list_cols = ["creator_concentration", "unique_creators", "intra_list_diversity", "duplicate_rate", "repeat_rate",
                 "new_video_exposure", "mean_log_duration", "exploration_share", "n_items"]
    oracle_cols = [f"oracle_utility@{k}", f"oracle_ndcg@{k}"]
    metrics = summarise(per_request, rank_cols + seg_cols + list_cols + oracle_cols)
    lat = per_request["latency_ms"].to_numpy()
    creators_with_supply = np.unique(catalogue.video_creator[eligible_videos])
    metrics.update({
        "latency_ms": {"mean": float(lat.mean()), "p50": float(np.median(lat)), "p95": float(np.quantile(lat, 0.95))},
        "catalogue_coverage": len(recommended_videos) / max(1, int(eligible_videos.sum())),
        "creator_coverage": float((creator_exposure > 0).sum() / max(1, len(creators_with_supply))),
        "creator_exposure_gini": gini(creator_exposure[creators_with_supply]) if len(creators_with_supply) else float("nan"),
        "eligibility_violations": int(per_request["violations"].sum()),
        "n_requests": int(len(per_request)), "n_users": int(len(np.unique(users.astype(str)))), "k": k,
    })
    slice_cols = [f"recall@{k}", f"ndcg@{k}", "mrr", "intra_list_diversity", "new_video_exposure"] + oracle_cols
    slices: dict[str, dict[str, dict[str, Any]]] = {}
    for dim in ("context", "user_segment", "history_segment"):
        slices[dim] = {str(val): summarise(sub, slice_cols) for val, sub in per_request.groupby(dim, sort=True)}
    slices["video_segment"] = {
        "new_video": {f"recall@{k}": metrics.get(f"recall@{k}/new_video")},
        "established_video": {f"recall@{k}": metrics.get(f"recall@{k}/established_video")},
    }
    return EvaluationResult(name=name, metrics=metrics, slices=slices, per_request=per_request, feeds=feeds)
