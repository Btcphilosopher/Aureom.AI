"""End-to-end evaluation, ablations and scenario runs (used by the CLI and the notebook)."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Callable, Mapping, Optional

import numpy as np
import pandas as pd

from ..artefacts.bundle import RecommenderArtefacts
from ..baselines.base import BaselineData, baseline_recommender
from ..baselines.models import all_baselines
from ..config import Config
from ..constants import CONTEXTS, SOURCES, SRC_EXPLORATION, SRC_POPULARITY, SRC_RECENT, SRC_TWO_TOWER
from ..inference.recommend import recommend
from ..training.pipeline import PreparedData, fit_duration_targets, train_pipeline
from ..training.ranker import build_ranking_data
from ..training.splits import build_evaluation_requests, window_examples
from .offline import EvaluationResult, evaluate_recommender
from .propensity import propensity_weighted_evaluation
from .ranking_eval import evaluate_ranking
from .retrieval_eval import evaluate_candidate_generation, evaluate_retrieval, two_tower_scorer

Log = Callable[[str], None]


def _json_default(obj: Any) -> Any:
    if isinstance(obj, (np.floating, np.integer, np.bool_)):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError(f"not JSON serialisable: {type(obj)}")


def write_json(obj: Any, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=_json_default))
    return path


def test_requests(prepared: PreparedData, config: Config, max_requests: Optional[int] = None) -> pd.DataFrame:
    a, b = prepared.splits.window("test")
    return build_evaluation_requests(prepared.impressions, a, b, max_requests or config.evaluation.max_eval_requests,
                                     config.seed)


def fit_baselines(prepared: PreparedData, config: Config) -> dict[str, Any]:
    """Fit every baseline on impressions matured before the test window (training + validation windows)."""
    sp = prepared.splits
    train = window_examples(prepared.impressions, sp.start, sp.calibration_end)
    data = BaselineData(prepared.catalogue, train, sp.calibration_end, config, config.seed)
    return {b.name: b.fit(data) for b in all_baselines()}


def _eval_kwargs(prepared: PreparedData, config: Config, oracle: Any) -> dict[str, Any]:
    return dict(catalogue=prepared.catalogue, histories=prepared.histories, preferences=prepared.preferences,
                impressions=prepared.impressions, config=config, oracle=oracle, seed=config.seed)


def evaluate_baselines(prepared: PreparedData, config: Config, requests: pd.DataFrame, oracle: Any = None,
                       baselines: Optional[Mapping[str, Any]] = None, log: Log = lambda s: None) -> dict[str, EvaluationResult]:
    baselines = baselines or fit_baselines(prepared, config)
    out = {}
    for name, b in baselines.items():
        out[name] = evaluate_recommender(baseline_recommender(b, config), requests, name=name,
                                         **_eval_kwargs(prepared, config, oracle))
        log(f"  baseline {name}: " + feed_line(out[name]))
    return out


def feed_line(res: EvaluationResult) -> str:
    m, k = res.metrics, res.metrics["k"]
    parts = [f"recall@{k}={m[f'recall@{k}']['mean']:.3f}", f"ndcg@{k}={m[f'ndcg@{k}']['mean']:.3f}"]
    if f"oracle_utility@{k}" in m:
        parts += [f"oracle_utility@{k}={m[f'oracle_utility@{k}']['mean']:.3f}", f"oracle_ndcg@{k}={m[f'oracle_ndcg@{k}']['mean']:.3f}"]
    parts += [f"ild={m['intra_list_diversity']['mean']:.2f}", f"creator_conc={m['creator_concentration']['mean']:.2f}"]
    return " ".join(parts)


def feed_summary(res: EvaluationResult) -> dict[str, float]:
    """Flat row of headline feed metrics (means) for tables."""
    m, k = res.metrics, res.metrics["k"]
    row = {"recall": m[f"recall@{k}"]["mean"], "ndcg": m[f"ndcg@{k}"]["mean"], "mrr": m["mrr"]["mean"],
           "intra_list_diversity": m["intra_list_diversity"]["mean"],
           "creator_concentration": m["creator_concentration"]["mean"],
           "duplicate_rate": m["duplicate_rate"]["mean"], "new_video_exposure": m["new_video_exposure"]["mean"],
           "catalogue_coverage": m["catalogue_coverage"], "creator_coverage": m["creator_coverage"],
           "creator_exposure_gini": m["creator_exposure_gini"], "latency_ms_mean": m["latency_ms"]["mean"],
           "latency_ms_p95": m["latency_ms"]["p95"], "mean_log_duration": m["mean_log_duration"]["mean"]}
    if f"oracle_utility@{k}" in m:
        row["oracle_utility"] = m[f"oracle_utility@{k}"]["mean"]
        row["oracle_ndcg"] = m[f"oracle_ndcg@{k}"]["mean"]
    return row


# --------------------------------------------------------------------------- full evaluation
def evaluate_all(prepared: PreparedData, artefacts: RecommenderArtefacts, oracle: Any = None,
                 valid_propensity_policies: Optional[Mapping[str, str]] = None, log: Log = lambda s: None,
                 max_requests: Optional[int] = None) -> dict[str, Any]:
    """Retrieval, ranking and full-feed evaluation of the learned system against all baselines."""
    cfg = artefacts.config
    cat = prepared.catalogue
    requests = test_requests(prepared, cfg, max_requests)
    kw = _eval_kwargs(prepared, cfg, oracle)
    out: dict[str, Any] = {"synthetic_data": oracle is not None, "n_test_requests": int(len(requests)),
                           "model_version": artefacts.model_version, "policy_version": cfg.policy.version,
                           "splits": prepared.splits.to_dict()}
    tic = time.time()
    learned = evaluate_recommender(recommend, requests, artefacts=artefacts, name="learned_system", keep_feeds=True, **kw)
    log("  learned system: " + feed_line(learned))
    baselines = fit_baselines(prepared, cfg)
    base_results = evaluate_baselines(prepared, cfg, requests, oracle, baselines, log)
    out["feed"] = {"learned_system": learned.to_dict(), **{n: r.to_dict() for n, r in base_results.items()}}
    out["feed_summary"] = {"learned_system": feed_summary(learned), **{n: feed_summary(r) for n, r in base_results.items()}}
    out["timings"] = {"feed_seconds": time.time() - tic}

    tic = time.time()
    scorers = {"two_tower": two_tower_scorer(artefacts, cat)}
    scorers.update({n: (lambda st, rows, b=b: b.score(st, rows, cat)) for n, b in baselines.items()})
    out["retrieval"] = evaluate_retrieval(scorers, requests, catalogue=cat, histories=prepared.histories,
                                          preferences=prepared.preferences, impressions=prepared.impressions,
                                          config=cfg, space=artefacts.space, oracle=oracle, seed=cfg.seed)
    out["candidate_generation"] = evaluate_candidate_generation(
        artefacts, requests, catalogue=cat, histories=prepared.histories, preferences=prepared.preferences,
        impressions=prepared.impressions, oracle=oracle, seed=cfg.seed)
    out["timings"]["retrieval_seconds"] = time.time() - tic

    tic = time.time()
    a, b = prepared.splits.window("test")
    runtime = artefacts.runtime(cat)
    test_data = build_ranking_data(window_examples(prepared.impressions, a, b), cat, prepared.histories,
                                   prepared.preferences, artefacts.space, runtime.features, runtime.video_embeddings,
                                   artefacts.retriever, cfg)
    out["ranking"] = evaluate_ranking(artefacts, test_data, prepared.impressions, seed=cfg.seed)
    out["timings"]["ranking_seconds"] = time.time() - tic

    # propensity-weighted evaluation: per surface, only where valid propensities exist
    out["propensity_weighted"] = {}
    imps = prepared.impressions
    in_test = (imps["t"].to_numpy() >= a) & (imps["t"].to_numpy() < b)
    for c, ctx in enumerate(CONTEXTS):
        has_p = in_test & (imps["context_idx"].to_numpy() == c) & ~np.isnan(imps["selection_propensity"].to_numpy())
        req_ids = imps.loc[has_p, "request_id"].unique()
        if len(req_ids) == 0:
            out["propensity_weighted"][ctx] = {
                "status": "unavailable",
                "reason": "the logging policy supplied no valid selection propensities for this surface"}
            continue
        reqs = build_evaluation_requests(imps.loc[imps["request_id"].isin(req_ids)], a, b, None, cfg.seed)
        res: dict[str, Any] = {}
        for name, fn, art in [("learned_system", recommend, artefacts)] + [
                (n, baseline_recommender(bl, cfg), None) for n, bl in baselines.items()]:
            feeds = {r.request_id: fn(user_id=r.user_id, context=r.context, as_of=r.as_of, k=cfg.evaluation.feed_k,
                                      catalogue=cat, histories=prepared.histories, preferences=prepared.preferences,
                                      artefacts=art, previously_recommended=set(), seed=cfg.seed).video_ids
                     for r in reqs.itertuples(index=False)}
            res[name] = propensity_weighted_evaluation(feeds, imps, cfg, valid_propensity_policies, seed=cfg.seed)
        out["propensity_weighted"][ctx] = res
    return out


# --------------------------------------------------------------------------- ablations
def _feed_eval(prepared: PreparedData, artefacts: RecommenderArtefacts, requests: pd.DataFrame, oracle: Any,
               name: str, keep_feeds: bool = False) -> EvaluationResult:
    return evaluate_recommender(recommend, requests, artefacts=artefacts, name=name, keep_feeds=keep_feeds,
                                **_eval_kwargs(prepared, artefacts.config, oracle))


def _duration_buckets(prepared: PreparedData, n_buckets: int = 5) -> np.ndarray:
    """Within-surface duration quantile bucket (0 = shortest) of every catalogue row."""
    cat = prepared.catalogue
    out = np.zeros(cat.n_rows, dtype="int64")
    for c in range(len(CONTEXTS)):
        m = cat.context_index == c
        if m.any():
            edges = np.quantile(np.log(cat.duration[m]), np.linspace(0, 1, n_buckets + 1)[1:-1])
            out[m] = np.searchsorted(edges, np.log(cat.duration[m]), side="right")
    return out


def duration_profile_of(res: EvaluationResult, prepared: PreparedData, n_buckets: int = 5) -> list[float]:
    """Share of recommended items per within-surface duration quantile bucket (shortest to longest)."""
    cat = prepared.catalogue
    bucket = _duration_buckets(prepared, n_buckets)
    counts = np.zeros(n_buckets)
    for feed in res.feeds:
        rows = cat.rows_at(cat.video_idx(feed.video_ids), feed.as_of)
        counts += np.bincount(bucket[rows], minlength=n_buckets)
    return (counts / max(1.0, counts.sum())).tolist()


def duration_reference_profiles(prepared: PreparedData, config: Config, requests: pd.DataFrame, oracle: Any = None,
                                k: int = 20, n_buckets: int = 5) -> dict[str, list[float]]:
    """Duration profiles that put the model profiles in context.

    ``eligible_supply``     what a duration-blind uniform draw from the eligible videos would show
    ``logged_popularity``   top-k by time-decayed popularity - what the logged feedback loop favours
    ``oracle_ideal``        top-k by true relevance (synthetic data only)
    """
    from ..composition.eligibility import hard_eligibility_mask
    from ..features.state import build_request_state

    cat = prepared.catalogue
    bucket = _duration_buckets(prepared, n_buckets)
    acc = {name: np.zeros(n_buckets) for name in ("eligible_supply", "logged_popularity", "oracle_ideal")}
    for req in requests.itertuples(index=False):
        state = build_request_state(req.user_id, req.context, float(req.as_of), cat, prepared.histories,
                                    prepared.preferences, None, config)
        el = np.flatnonzero(hard_eligibility_mask(state, cat, config))
        if len(el) < k:
            continue
        acc["eligible_supply"] += np.bincount(bucket[el], minlength=n_buckets) / len(el)
        pop = state.stats.popularity[cat.video_index[el]]
        acc["logged_popularity"] += np.bincount(bucket[el[np.lexsort((el, -pop))[:k]]], minlength=n_buckets) / k
        if oracle is not None:
            util = np.nan_to_num(oracle.utility(req.user_id, cat.video_ids[el]))
            acc["oracle_ideal"] += np.bincount(bucket[el[np.lexsort((el, -util))[:k]]], minlength=n_buckets) / k
    return {name: (v / v.sum()).tolist() for name, v in acc.items() if v.sum() > 0}


def run_ablations(prepared: PreparedData, artefacts: RecommenderArtefacts, oracle: Any = None,
                  log: Log = lambda s: None, max_requests: int = 600, retrain: bool = True) -> dict[str, Any]:
    """Ablations for retrieval sources, duration adjustment, ranking heads and diversity."""
    base = artefacts.config
    requests = test_requests(prepared, base, max_requests)
    out: dict[str, Any] = {"n_requests": int(len(requests)), "synthetic_data": oracle is not None}

    def variant(name: str, overrides: dict[str, Any], group: str, art: RecommenderArtefacts = artefacts,
                extra: Optional[Callable[[EvaluationResult, RecommenderArtefacts], dict[str, Any]]] = None) -> None:
        a = art.with_config(art.config.copy(**overrides))
        res = _feed_eval(prepared, a, requests, oracle, name, keep_feeds=extra is not None)
        row: dict[str, Any] = feed_summary(res)
        if extra is not None:
            row.update(extra(res, a))
        out.setdefault(group, {})[name] = row
        log(f"  [{group}] {name}: " + feed_line(res))

    # ---- retrieval sources ---------------------------------------------------------------
    def cand_stats(_: EvaluationResult, a: RecommenderArtefacts) -> dict[str, Any]:
        cg = evaluate_candidate_generation(a, requests, catalogue=prepared.catalogue, histories=prepared.histories,
                                           preferences=prepared.preferences, impressions=prepared.impressions,
                                           oracle=oracle, seed=base.seed)
        return {k: cg[k] for k in ("candidate_recall", "n_candidates", "oracle_ideal_coverage") if k in cg}

    variant("all_sources", {}, "retrieval_sources", extra=cand_stats)
    for src in SOURCES:
        variant(f"without_{src}", {f"candidates.{src}": 0}, "retrieval_sources", extra=cand_stats)
    variant("two_tower_only", {f"candidates.{s}": 0 for s in SOURCES if s != SRC_TWO_TOWER}, "retrieval_sources", extra=cand_stats)
    variant("non_personalised_only", {f"candidates.{s}": 0 for s in SOURCES if s not in (SRC_RECENT, SRC_POPULARITY, SRC_EXPLORATION)},
            "retrieval_sources", extra=cand_stats)

    # ---- ranking heads (policy weights) -------------------------------------------------
    heads = {"meaningful": "w_meaningful", "duration": "w_duration", "positive": "w_positive",
             "satisfaction": "w_satisfaction", "negative": "w_negative"}
    variant("full_policy", {}, "ranking_heads")
    for head, key in heads.items():
        variant(f"without_{head}", {f"policy.{key}": 0.0}, "ranking_heads")
    for head, key in heads.items():
        if head == "negative":
            continue
        only = {f"policy.{k}": 0.0 for k in heads.values()}
        only[f"policy.{key}"] = 1.0
        variant(f"only_{head}", only, "ranking_heads")

    # ---- diversity and composition --------------------------------------------------------
    variant("default_composition", {}, "diversity")
    variant("no_similarity_penalty", {"composition.lambda_diversity": 0.0}, "diversity")
    variant("no_creator_or_topic_caps", {"composition.max_per_creator": 10_000, "composition.max_topic_share": 1.0}, "diversity")
    variant("no_diversity_controls", {"composition.lambda_diversity": 0.0, "composition.max_per_creator": 10_000,
                                      "composition.max_topic_share": 1.0, "composition.near_duplicate_similarity": 2.0,
                                      "composition.lambda_freshness": 0.0, "composition.max_exploration_slots": 0}, "diversity")
    variant("strong_diversity", {"composition.lambda_diversity": 0.3, "composition.max_per_creator": 2,
                                 "composition.max_topic_share": 0.3}, "diversity")
    variant("no_exploration_slots", {"composition.max_exploration_slots": 0}, "diversity")

    # ---- duration adjustment (retrains the ranker; the retriever is reused) -------------
    if retrain:
        neutral = {"composition.lambda_diversity": 0.0, "composition.max_per_creator": 10_000,
                   "composition.max_topic_share": 1.0, "composition.lambda_freshness": 0.0,
                   "composition.max_exploration_slots": 0}
        only_duration = {**neutral, "policy.w_meaningful": 0.0, "policy.w_positive": 0.0, "policy.w_satisfaction": 0.0,
                         "policy.w_negative": 0.0, "policy.w_duration": 1.0}
        profile = lambda res, _a: {"duration_profile": duration_profile_of(res, prepared)}  # noqa: E731
        for target in ("duration_adjusted", "completion_ratio", "capped_watch_seconds"):
            cfg_t = base.copy(**{"ranker.duration_target": target})
            art_t = artefacts if target == base.ranker.duration_target else train_pipeline(
                prepared, cfg_t, retriever=artefacts.retriever, space=artefacts.space)
            variant(f"{target}/duration_head_only", only_duration, "duration_target", art=art_t, extra=profile)
            variant(f"{target}/full_policy", {}, "duration_target", art=art_t, extra=profile)
        fit_duration_targets(prepared, base)                     # restore the configured target
        out["duration_reference"] = duration_reference_profiles(prepared, base, requests, oracle)

        # ---- history pooling (retrains the retriever and the ranker) ---------------------
        other = "attention" if base.retrieval.history_pooling == "time_decay" else "time_decay"
        art_p = train_pipeline(prepared, base.copy(**{"retrieval.history_pooling": other}))
        rec_key = f"validation_recall@{base.retrieval.validation_k}"
        for name, a in ((base.retrieval.history_pooling, artefacts), (other, art_p)):
            variant(name, {}, "history_pooling", art=a, extra=lambda _r, a_=a: {
                "best_" + rec_key: max((h.get(rec_key, float("nan")) for h in a_.retriever.history), default=float("nan"))})
        fit_duration_targets(prepared, base)
    return out
