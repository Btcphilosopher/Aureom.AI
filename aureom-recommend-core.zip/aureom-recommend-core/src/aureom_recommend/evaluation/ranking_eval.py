"""Ranking-stage evaluation on logged slates.

Candidate universe for every metric in this module: **the impressions that were actually
shown in the logged request** (the logged slate). These metrics are therefore not
comparable with the full-catalogue retrieval and feed metrics.

* Probability quality per head, on the rows where that head's label is observed:
  Brier score and expected calibration error before and after calibration, ROC AUC for
  binary heads, MAE / RMSE for the bounded heads (duration target, satisfaction).
  Predictions use the logged position, because the labels were produced at that position.
* Ordering quality per request: NDCG@K and MRR of the policy score (position feature set to
  its serving value) with the binary gain "impression ended in a positive state", next to
  two anchors - the logged order and a seeded random order.
"""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from ..artefacts.bundle import RecommenderArtefacts
from ..constants import BINARY_TASKS, CONTEXTS, TASKS
from ..training.ranker import RankingData, zero_position
from .bootstrap import user_bootstrap_ci
from .metrics import auc, brier_score, expected_calibration_error, graded_ndcg_at_k, reliability_curve

RANKING_DEFINITIONS = {
    "candidate_universe": "the logged slate: impressions shown in the same logged request",
    "relevance_label": "the impression matured in a positive state (meaningful view or like/save/share)",
    "probability_labels": "each head is scored only on rows where its label is observed (mask = 1)",
    "note": "logged-slate metrics are not comparable with full-catalogue metrics",
}


def evaluate_ranking(artefacts: RecommenderArtefacts, data: RankingData, impressions: pd.DataFrame,
                     seed: int = 0) -> dict[str, Any]:
    cfg = artefacts.config
    ec = cfg.evaluation
    out: dict[str, Any] = {"definitions": RANKING_DEFINITIONS, "heads": {}, "ordering": {}, "n_impressions": len(data)}
    if len(data) == 0:
        return out
    ranker = artefacts.ranker
    raw = ranker.predict(data.features, calibrated=False)
    cal = ranker.predict(data.features, calibrated=True)
    ctx = data.frame["context_idx"].to_numpy()
    curves: dict[str, Any] = {}
    for j, task in enumerate(TASKS):
        m = data.masks[:, j] > 0
        y = data.targets[m, j].astype("float64")
        head: dict[str, Any] = {"n_labelled": int(m.sum()), "calibration_status": ranker.calibrators[task].status}
        if m.sum() > 0:
            head.update({
                "label_mean": float(y.mean()), "prediction_mean": float(cal[task][m].mean()),
                "brier_uncalibrated": brier_score(y, raw[task][m]), "brier_calibrated": brier_score(y, cal[task][m]),
                "ece_uncalibrated": expected_calibration_error(y, raw[task][m], ec.ece_bins),
                "ece_calibrated": expected_calibration_error(y, cal[task][m], ec.ece_bins),
            })
            if task in BINARY_TASKS:
                head["auc"] = auc(y, cal[task][m])
            else:
                err = cal[task][m] - y
                head.update({"mae": float(np.abs(err).mean()), "rmse": float(np.sqrt((err ** 2).mean()))})
            head["by_context"] = {}
            for c, name in enumerate(CONTEXTS):
                mc = m & (ctx == c)
                if mc.sum() > 0:
                    yc = data.targets[mc, j].astype("float64")
                    head["by_context"][name] = {
                        "n_labelled": int(mc.sum()), "brier_calibrated": brier_score(yc, cal[task][mc]),
                        "ece_calibrated": expected_calibration_error(yc, cal[task][mc], ec.ece_bins)}
            x_raw, y_raw, n_raw = reliability_curve(y, raw[task][m], ec.ece_bins)
            x_cal, y_cal, n_cal = reliability_curve(y, cal[task][m], ec.ece_bins)
            curves[task] = {"uncalibrated": [x_raw.tolist(), y_raw.tolist(), n_raw.tolist()],
                            "calibrated": [x_cal.tolist(), y_cal.tolist(), n_cal.tolist()]}
        out["heads"][task] = head
    out["reliability"] = curves

    # ---- ordering quality on logged slates --------------------------------------------
    serving = ranker.predict(zero_position(data.features), calibrated=True)
    score, _ = artefacts.policy.score(serving)
    positive = impressions["is_positive"].to_numpy()[data.frame["imp_idx"].to_numpy()].astype("float64")
    req = data.frame["request_id"].to_numpy(dtype=object)
    users = data.frame["user_id"].to_numpy(dtype=object)
    bounds = np.flatnonzero(np.r_[True, req[1:] != req[:-1], True])
    rng = np.random.default_rng(seed)
    ks = [k for k in ec.ks if k <= 10] or [5]
    recs: list[dict[str, Any]] = []
    for s, e in zip(bounds[:-1], bounds[1:]):
        gains = positive[s:e]
        if e - s < 2 or gains.sum() == 0 or gains.sum() == e - s:
            continue                                         # ordering is undefined without both outcomes
        orders = {"policy": np.argsort(-score[s:e], kind="stable"), "logged_order": np.arange(e - s),
                  "random": rng.permutation(e - s)}
        rec: dict[str, Any] = {"user_id": users[s], "context": CONTEXTS[ctx[s]]}
        for name, order in orders.items():
            for k in ks:
                rec[f"{name}/ndcg@{k}"] = graded_ndcg_at_k(gains[order], gains, k)
            rec[f"{name}/mrr"] = float(1.0 / (np.flatnonzero(gains[order] > 0)[0] + 1))
        recs.append(rec)
    frame = pd.DataFrame(recs)
    out["ordering"]["n_requests"] = int(len(frame))
    if len(frame):
        u = frame["user_id"].to_numpy(dtype=object)
        for col in [c for c in frame.columns if c not in ("user_id", "context")]:
            mean, lo, hi = user_bootstrap_ci(frame[col].to_numpy(dtype="float64"), u, ec.bootstrap_samples, seed)
            out["ordering"][col] = {"mean": mean, "ci_low": lo, "ci_high": hi}
        k0 = ks[-1]
        out["ordering"]["by_context"] = {
            str(c): {name: float(g[f"{name}/ndcg@{k0}"].mean()) for name in ("policy", "logged_order", "random")}
            for c, g in frame.groupby("context")}
    return out
