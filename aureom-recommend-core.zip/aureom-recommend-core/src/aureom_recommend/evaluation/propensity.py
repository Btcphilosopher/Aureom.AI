"""Propensity-weighted (off-policy) evaluation - only when it is valid.

The estimator is computed **only** from impressions that

1. carry a ``selection_propensity`` that passed validation (a probability in (0, 1] supplied
   together with a ``logging_policy_id``), and
2. were logged by a policy that the caller *declares* to have full support over the eligible
   catalogue (``valid_policies``) - support cannot be verified from the log itself, and
3. overlap sufficiently with the evaluated feeds (``min_propensity_matches``).

Otherwise the result is ``{"status": "unavailable", "reason": ...}``. No propensity is ever
imputed, clipped into existence or estimated from frequencies.

Estimand: ``V = E[ (1/k) * sum_{v in feed} reward(u, v) ]`` with reward = meaningful view.
With slate-inclusion propensities ``pi`` of the logging policy::

    IPS    = (1/N) * sum_requests (1/k) * sum_{logged i, v_i in feed} r_i / pi_i
    SNIPS  = sum r_i / pi_i  /  sum 1 / pi_i          (over the same matched impressions)

Assumptions (stated, not tested): the reward of a video does not depend on the slate it is
shown in or on its position; every video the evaluated recommender can return had non-zero
logging propensity for that request.
"""
from __future__ import annotations

from typing import Any, Mapping, Optional, Sequence

import numpy as np
import pandas as pd

from ..config import Config
from ..constants import CONTEXTS


def unavailable(reason: str) -> dict[str, Any]:
    return {"status": "unavailable", "reason": reason}


def propensity_weighted_evaluation(feeds: Mapping[str, Sequence[str]], impressions: pd.DataFrame, config: Config,
                                   valid_policies: Optional[Mapping[str, str]] = None, k: Optional[int] = None,
                                   seed: int = 0) -> dict[str, Any]:
    """``feeds`` maps a logged ``request_id`` to the video ids the evaluated recommender returned for it."""
    k = int(k or config.evaluation.feed_k)
    if not valid_policies:
        return unavailable("no logging policy was declared to supply valid propensities with full support")
    imps = impressions.loc[impressions["request_id"].isin(list(feeds))]
    p = imps["selection_propensity"].to_numpy(dtype="float64")
    usable = (~np.isnan(p) & imps["logging_policy_id"].isin(list(valid_policies)).to_numpy()
              & (imps["m_meaningful"].to_numpy() > 0))
    if not usable.any():
        return unavailable("no evaluated request has impressions with valid propensities from a declared policy")
    imps, p = imps.loc[usable], p[usable]
    in_feed = np.array([v in set(feeds[r][:k]) for r, v in zip(imps["request_id"].to_numpy(dtype=object),
                                                             imps["video_id"].to_numpy(dtype=object))], dtype=bool)
    n_requests = int(imps["request_id"].nunique())
    n_matched = int(in_feed.sum())
    if n_matched < config.evaluation.min_propensity_matches:
        return unavailable(f"only {n_matched} logged impressions overlap the evaluated feeds "
                           f"(< {config.evaluation.min_propensity_matches}); the estimate would be meaningless")
    r = imps["y_meaningful"].to_numpy(dtype="float64")[in_feed]
    w = 1.0 / p[in_feed]
    users = imps["user_id"].to_numpy(dtype=object)[in_feed]
    ips = float((r * w).sum() / (n_requests * k))
    snips = float((r * w).sum() / w.sum())
    # user-level bootstrap of the self-normalised estimate
    _, inv = np.unique(users.astype(str), return_inverse=True)
    num, den = np.bincount(inv, weights=r * w), np.bincount(inv, weights=w)
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, len(num), size=(config.evaluation.bootstrap_samples, len(num)))
    boot = num[draws].sum(axis=1) / den[draws].sum(axis=1)
    ctx = np.asarray(CONTEXTS, dtype=object)[imps["context_idx"].to_numpy()]
    return {
        "status": "available", "reward": "meaningful view", "k": k, "ips": ips, "snips": snips,
        "snips_ci_low": float(np.quantile(boot, 0.025)), "snips_ci_high": float(np.quantile(boot, 0.975)),
        "n_requests": n_requests, "n_matched_impressions": n_matched,
        "effective_sample_size": float(w.sum() ** 2 / (w ** 2).sum()),
        "logged_mean_reward": float(imps["y_meaningful"].mean()),
        "policies": sorted(set(imps["logging_policy_id"].to_numpy(dtype=object).tolist())),
        "contexts_covered": sorted(set(ctx.tolist())),
        "assumptions": ["reward independent of slate and position", "full support declared by the caller: "
                        + "; ".join(f"{pid}: {desc}" for pid, desc in valid_policies.items())],
    }
