"""Evaluation plots (Matplotlib, static PNG).

Conventions: categorical colours in a fixed order (validated for colour-vision-deficiency
separation), thin marks, recessive grid, values printed on the marks so no reading depends
on colour alone, text in neutral ink, one y-axis per panel.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Optional, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

SERIES = ("#257de0", "#f47230", "#00b894", "#f2a600")
INK, INK_2, GRID, AXIS = "#191919", "#666666", "#e7e7e7", "#c2c2c2"


def _style(ax: Any, title: str, xlabel: str = "", ylabel: str = "") -> None:
    ax.set_title(title, loc="left", fontsize=11, color=INK, pad=10)
    ax.set_xlabel(xlabel, fontsize=9, color=INK_2)
    ax.set_ylabel(ylabel, fontsize=9, color=INK_2)
    ax.tick_params(colors=INK_2, labelsize=8, length=0)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(AXIS)
    ax.set_axisbelow(True)


def _save(fig: Any, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


def bar_comparison(names: Sequence[str], values: Sequence[float], path: str | Path, title: str, xlabel: str,
                   lows: Optional[Sequence[float]] = None, highs: Optional[Sequence[float]] = None,
                   highlight: Sequence[str] = (), note: str = "") -> Path:
    """Horizontal bars, sorted by value, with optional bootstrap intervals. Highlighted rows use series 2."""
    order = np.argsort(np.nan_to_num(np.asarray(values, dtype="float64"), nan=-np.inf))
    names = [names[i] for i in order]
    vals = np.asarray(values, dtype="float64")[order]
    fig, ax = plt.subplots(figsize=(7.2, 0.42 * len(names) + 1.3))
    colours = [SERIES[1] if n in highlight else SERIES[0] for n in names]
    ax.barh(names, vals, height=0.55, color=colours)
    if lows is not None and highs is not None:
        lo = np.asarray(lows, dtype="float64")[order]
        hi = np.asarray(highs, dtype="float64")[order]
        ok = ~np.isnan(lo) & ~np.isnan(hi)
        ax.hlines(np.arange(len(names))[ok], lo[ok], hi[ok], color=INK, linewidth=1.0)
    span = np.nanmax(vals) if len(vals) and np.isfinite(np.nanmax(vals)) else 1.0
    ends = np.nan_to_num(np.asarray(highs, dtype="float64")[order], nan=0.0) if highs is not None else vals
    for i, v in enumerate(vals):
        if np.isfinite(v):
            ax.text(max(v, ends[i]) + 0.015 * span, i, f"{v:.3f}", va="center", fontsize=8, color=INK)
    ax.set_xlim(0, span * 1.18)
    ax.xaxis.grid(True, color=GRID, linewidth=1)
    _style(ax, title, xlabel)
    if highlight:
        handles = [plt.Rectangle((0, 0), 1, 1, color=SERIES[1]), plt.Rectangle((0, 0), 1, 1, color=SERIES[0])]
        ax.legend(handles, ["learned system", "baseline"], frameon=False, fontsize=8, loc="lower right", labelcolor=INK_2)
    if note:
        fig.text(0.01, -0.02, note, fontsize=7.5, color=INK_2, ha="left", va="top")
    return _save(fig, path)


def reliability_plot(curves: Mapping[str, Mapping[str, Sequence[Sequence[float]]]], path: str | Path,
                     title: str = "Reliability on the test window (synthetic data)") -> Path:
    """One panel per head: mean outcome against mean prediction, before and after calibration."""
    tasks = list(curves)
    fig, axes = plt.subplots(1, max(1, len(tasks)), figsize=(3.1 * max(1, len(tasks)), 3.2), squeeze=False)
    for ax, task in zip(axes[0], tasks):
        hi = 1e-6
        for (name, colour) in (("uncalibrated", SERIES[0]), ("calibrated", SERIES[1])):
            x, y, _ = curves[task][name]
            ax.plot(x, y, color=colour, linewidth=2, marker="o", markersize=4.5, markeredgecolor="white",
                    markeredgewidth=1, label=name)
            hi = max(hi, max(list(x) + list(y), default=0.0))
        ax.plot([0, hi], [0, hi], color=AXIS, linewidth=1)
        ax.set_xlim(0, hi * 1.05)
        ax.set_ylim(0, hi * 1.05)
        ax.grid(True, color=GRID, linewidth=1)
        _style(ax, task, "mean prediction", "mean outcome" if task == tasks[0] else "")
    if tasks:
        axes[0][0].legend(frameon=False, fontsize=8, labelcolor=INK_2, loc="upper left")
    fig.suptitle(title, x=0.01, ha="left", fontsize=11, color=INK)
    fig.tight_layout()
    return _save(fig, path)


def recall_curve(series: Mapping[str, Mapping[int, float]], path: str | Path, title: str) -> Path:
    """Recall@K against K for up to four scorers (the rest belong in the table)."""
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    for (name, points), colour in zip(list(series.items())[:len(SERIES)], SERIES):
        ks = sorted(points)
        ys = [points[k] for k in ks]
        ax.plot(ks, ys, color=colour, linewidth=2, marker="o", markersize=5, markeredgecolor="white",
                markeredgewidth=1, label=name)
        ax.annotate(name, (ks[-1], ys[-1]), xytext=(6, 0), textcoords="offset points", fontsize=8, color=INK, va="center")
    ax.set_xscale("log")
    ax.set_xticks(sorted({k for pts in series.values() for k in pts}))
    ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    ax.set_ylim(bottom=0)
    ax.margins(x=0.18)
    ax.yaxis.grid(True, color=GRID, linewidth=1)
    ax.legend(frameon=False, fontsize=8, labelcolor=INK_2, loc="upper left")
    _style(ax, title, "K", "Recall@K")
    return _save(fig, path)


def duration_profile(profiles: Mapping[str, Sequence[float]], labels: Sequence[str], path: str | Path,
                     title: str) -> Path:
    """Share of recommended items per duration bucket for up to four variants (grouped columns)."""
    names = list(profiles)[:len(SERIES)]
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    width = 0.8 / max(1, len(names))
    x = np.arange(len(labels))
    for i, name in enumerate(names):
        ax.bar(x + (i - (len(names) - 1) / 2) * width, profiles[name], width=width * 0.86, color=SERIES[i], label=name)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.yaxis.grid(True, color=GRID, linewidth=1)
    ax.legend(frameon=False, fontsize=8, labelcolor=INK_2)
    _style(ax, title, "duration bucket within surface (shortest to longest)", "share of recommended items")
    return _save(fig, path)
