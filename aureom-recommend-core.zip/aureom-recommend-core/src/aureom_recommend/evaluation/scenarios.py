"""Scenario runs on separately generated synthetic worlds.

Each scenario isolates one question and reports the diagnostic designed for it. Results are
whatever the models produce: nothing here tunes a model until it beats a baseline.
"""
from __future__ import annotations

from typing import Any, Callable

import numpy as np

from ..config import Config
from ..data.synthetic import POLICY_UNIFORM, generate_synthetic, scenario_config
from ..training.pipeline import fit_duration_targets, prepare_data, train_pipeline
from .report import (_feed_eval, duration_profile_of, duration_reference_profiles, evaluate_baselines, feed_summary,
                     test_requests)

SCENARIO_QUESTIONS = {
    "preference_recovery": "With unbiased exposure and duration-neutral viewing, does the learned system recover "
                           "the latent preferences (oracle NDCG) better than non-personalised rankings?",
    "duration_bias": "When viewing depends strongly on duration, which duration target keeps recommendations from "
                     "drifting to very short or very long videos, and at what cost in true relevance?",
    "popularity_bias": "When exposure is concentrated on popular creators whose quality is unrelated to their "
                       "popularity, do logged hit metrics and oracle relevance disagree?",
    "cold_start": "How do new users and new videos fare when many of both arrive late?",
}

SMALL_WORLD = {"n_users": 700, "n_videos": 1500, "n_creators": 110, "n_days": 30}


def run_scenario(name: str, config: Config, log: Callable[[str], None] = lambda s: None,
                 max_requests: int = 500, world: dict[str, Any] | None = None) -> dict[str, Any]:
    ds = generate_synthetic(scenario_config(name, **(SMALL_WORLD if world is None else world)))
    prepared = prepare_data(ds.videos, ds.interactions, ds.preferences, config)
    artefacts = train_pipeline(prepared, config)
    requests = test_requests(prepared, config, max_requests)
    learned = _feed_eval(prepared, artefacts, requests, ds.oracle, "learned_system", keep_feeds=True)
    baselines = evaluate_baselines(prepared, config, requests, ds.oracle)
    out: dict[str, Any] = {
        "scenario": name, "synthetic_data": True, "question": SCENARIO_QUESTIONS[name], "world": ds.summary,
        "n_requests": int(len(requests)),
        "feed_summary": {"learned_system": feed_summary(learned), **{n: feed_summary(r) for n, r in baselines.items()}},
    }
    k = learned.metrics["k"]
    if name == "cold_start":
        out["slices"] = {
            "learned_system": {dim: learned.slices[dim] for dim in ("user_segment", "history_segment", "video_segment")},
            "popularity": {dim: baselines["popularity"].slices[dim] for dim in ("user_segment", "history_segment", "video_segment")},
            "explicit_preferences": {dim: baselines["explicit_preferences"].slices[dim] for dim in ("user_segment", "history_segment", "video_segment")},
        }
    if name == "duration_bias":
        neutral = {"composition.lambda_diversity": 0.0, "composition.max_per_creator": 10_000,
                   "composition.max_topic_share": 1.0, "composition.lambda_freshness": 0.0,
                   "composition.max_exploration_slots": 0, "policy.w_meaningful": 0.0, "policy.w_positive": 0.0,
                   "policy.w_satisfaction": 0.0, "policy.w_negative": 0.0, "policy.w_duration": 1.0}
        out["duration_targets"] = {}
        for target in ("duration_adjusted", "completion_ratio", "capped_watch_seconds"):
            art_t = artefacts if target == config.ranker.duration_target else train_pipeline(
                prepared, config.copy(**{"ranker.duration_target": target}), retriever=artefacts.retriever,
                space=artefacts.space)
            a = art_t.with_config(art_t.config.copy(**neutral))
            res = _feed_eval(prepared, a, requests, ds.oracle, target, keep_feeds=True)
            profile = duration_profile_of(res, prepared)
            out["duration_targets"][target] = {
                "duration_profile": profile, "profile_imbalance": float(np.max(profile) - np.min(profile)),
                "oracle_utility": res.metrics[f"oracle_utility@{k}"]["mean"],
                "oracle_ndcg": res.metrics[f"oracle_ndcg@{k}"]["mean"]}
        fit_duration_targets(prepared, config)
        out["duration_reference"] = duration_reference_profiles(prepared, config, requests, ds.oracle)
    log(f"  scenario {name}: learned oracle_ndcg@{k}={out['feed_summary']['learned_system'].get('oracle_ndcg', float('nan')):.3f}")
    return out


def run_scenarios(config: Config, log: Callable[[str], None] = lambda s: None, max_requests: int = 500) -> dict[str, Any]:
    return {name: run_scenario(name, config, log, max_requests) for name in SCENARIO_QUESTIONS}


VALID_SYNTHETIC_PROPENSITY_POLICIES = {
    POLICY_UNIFORM: "uniform sampling without replacement from the eligible long-form pool; propensity = slate size / pool size",
}
