"""User-level bootstrap confidence intervals.

Requests from the same user are correlated, so users - not requests - are resampled.
The statistic is the mean over requests (a ratio of user-level sums), recomputed on each
resample; the interval is the percentile interval.
"""
from __future__ import annotations

import numpy as np


def user_bootstrap_ci(values: np.ndarray, users: np.ndarray, n_boot: int = 200, seed: int = 0,
                      alpha: float = 0.05) -> tuple[float, float, float]:
    """Return (mean, low, high) for the request-level mean of ``values`` (NaNs are ignored)."""
    values = np.asarray(values, dtype="float64")
    ok = ~np.isnan(values)
    if not ok.any():
        return float("nan"), float("nan"), float("nan")
    values, users = values[ok], np.asarray(users)[ok]
    _, inv = np.unique(users.astype(str), return_inverse=True)
    sums = np.bincount(inv, weights=values)
    counts = np.bincount(inv).astype("float64")
    mean = float(sums.sum() / counts.sum())
    n = len(sums)
    if n < 2 or n_boot <= 0:
        return mean, float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    draws = rng.integers(0, n, size=(n_boot, n))
    stats = sums[draws].sum(axis=1) / counts[draws].sum(axis=1)
    lo, hi = np.quantile(stats, [alpha / 2, 1 - alpha / 2])
    return mean, float(lo), float(hi)
