"""Everything a trained recommender needs at serving time."""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..config import Config
from ..data.catalogue import Catalogue
from ..features.duration import DurationBaseline
from ..features.space import FeatureSpace, VideoFeatures
from ..ranking.policy import RankingPolicy
from ..ranking.ranker import Ranker
from ..retrieval.index import build_index
from ..retrieval.model import VideoBank
from ..training.retriever import Retriever


@dataclass
class CatalogueRuntime:
    """Per-catalogue derived state: features, video embeddings and the retrieval index."""

    features: VideoFeatures
    bank: VideoBank
    video_embeddings: np.ndarray
    index: Any


@dataclass
class RecommenderArtefacts:
    config: Config
    space: FeatureSpace
    duration_baseline: DurationBaseline
    retriever: Retriever
    ranker: Ranker
    model_version: str
    splits: dict[str, float] = field(default_factory=dict)
    report: dict[str, Any] = field(default_factory=dict)
    _runtimes: dict[str, CatalogueRuntime] = field(default_factory=dict, repr=False)

    @property
    def policy(self) -> RankingPolicy:
        return RankingPolicy.from_config(self.config.policy)

    def runtime(self, catalogue: Catalogue) -> CatalogueRuntime:
        """Featurise and embed a catalogue once (cached by catalogue fingerprint and index settings).

        Videos that did not exist at training time are embedded from their content features.
        """
        key = f"{catalogue.fingerprint}:{self.config.retrieval.index}"
        if key not in self._runtimes:
            base = next((rt for k, rt in self._runtimes.items() if k.startswith(catalogue.fingerprint + ":")), None)
            if base is None:
                features = self.space.transform_catalogue(catalogue)
                emb = self.retriever.embed_catalogue(features)
                bank = VideoBank(features, self.retriever.device)
            else:
                features, emb, bank = base.features, base.video_embeddings, base.bank
            self._runtimes[key] = CatalogueRuntime(features, bank, emb, build_index(emb, self.config.retrieval))
        return self._runtimes[key]

    def with_config(self, config: Config) -> "RecommenderArtefacts":
        """Same trained models under a different serving configuration (policy, sources, composition)."""
        clone = copy.copy(self)
        clone.config = config
        return clone

    def make_model_version(self) -> str:
        return f"{self.config.model_name}-{self.config.config_hash()}"
