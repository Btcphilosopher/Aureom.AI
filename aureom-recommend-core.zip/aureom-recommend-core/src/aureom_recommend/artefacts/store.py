"""Versioned artefact persistence with compatibility validation.

Layout of an artefact directory::

    manifest.json           versions, dimensions, feature/task lists, sha256 of every file
    config.json             the full configuration used for training
    feature_space.joblib    vocabularies, TF-IDF + SVD, scalers (training-only fits)
    duration_baseline.json  duration-conditioned viewing baseline
    retriever.pt            two-tower state_dict
    ranker.pt               ranker state_dict + standardisation statistics
    ranker_meta.json        prior-correction weights, calibrators, training history
    report.json             splits and training report

``load_artefacts`` refuses to load when the manifest format is unknown, a file's checksum
differs, the feature or task definitions of the installed code differ from those the model
was trained with, or tensor shapes do not match the recorded dimensions.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import sklearn
import torch

from .. import __version__
from ..config import Config
from ..constants import TASKS
from ..features.duration import DurationBaseline
from ..features.space import FeatureSpace
from ..ranking.calibration import PlattCalibrator
from ..ranking.features import DENSE_FEATURES
from ..ranking.model import MultiTaskRanker, RankerDims
from ..ranking.ranker import Ranker
from ..retrieval.model import TowerDims, TwoTower
from ..training.retriever import Retriever, resolve_device
from .bundle import RecommenderArtefacts

FORMAT_VERSION = 1


class ArtefactCompatibilityError(RuntimeError):
    """The artefact on disk cannot be used with the installed code."""


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _json_default(obj: Any) -> Any:
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError(f"not JSON serialisable: {type(obj)}")


def save_artefacts(artefacts: RecommenderArtefacts, directory: str | Path) -> Path:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "config.json").write_text(json.dumps(artefacts.config.to_dict(), indent=2, sort_keys=True))
    joblib.dump(artefacts.space, directory / "feature_space.joblib")
    (directory / "duration_baseline.json").write_text(json.dumps(artefacts.duration_baseline.to_dict()))
    torch.save({k: v.cpu() for k, v in artefacts.retriever.model.state_dict().items()}, directory / "retriever.pt")
    ranker = artefacts.ranker
    torch.save({"state_dict": {k: v.cpu() for k, v in ranker.model.state_dict().items()},
                "dense_mean": torch.as_tensor(ranker.dense_mean), "dense_std": torch.as_tensor(ranker.dense_std)},
               directory / "ranker.pt")
    (directory / "ranker_meta.json").write_text(json.dumps({
        "pos_weights": ranker.pos_weights, "calibrators": {t: c.to_dict() for t, c in ranker.calibrators.items()},
        "history": ranker.history, "retriever_history": artefacts.retriever.history}, indent=2, default=_json_default))
    (directory / "report.json").write_text(json.dumps({"splits": artefacts.splits, "report": artefacts.report},
                                                      indent=2, default=_json_default))
    files = ["config.json", "feature_space.joblib", "duration_baseline.json", "retriever.pt", "ranker.pt",
             "ranker_meta.json", "report.json"]
    manifest = {
        "format_version": FORMAT_VERSION, "package_version": __version__, "model_version": artefacts.model_version,
        "policy_version": artefacts.config.policy.version, "label_version": artefacts.config.labels.version,
        "duration_version": artefacts.duration_baseline.version, "config_hash": artefacts.config.config_hash(),
        "libraries": {"torch": torch.__version__, "numpy": np.__version__, "sklearn": sklearn.__version__},
        "tower_dims": artefacts.retriever.dims.to_dict(), "ranker_dims": ranker.dims.to_dict(),
        "dense_features": list(DENSE_FEATURES), "tasks": list(TASKS),
        "files": {name: _sha256(directory / name) for name in files},
    }
    (directory / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return directory


def validate_manifest(directory: str | Path) -> dict[str, Any]:
    """Check the manifest against the installed code and the files on disk; return the manifest."""
    directory = Path(directory)
    path = directory / "manifest.json"
    if not path.exists():
        raise ArtefactCompatibilityError(f"no manifest.json in {directory}")
    manifest = json.loads(path.read_text())
    if manifest.get("format_version") != FORMAT_VERSION:
        raise ArtefactCompatibilityError(f"artefact format {manifest.get('format_version')} is not supported "
                                         f"(this code reads format {FORMAT_VERSION})")
    if list(manifest.get("tasks", [])) != list(TASKS):
        raise ArtefactCompatibilityError("ranking tasks of the artefact differ from the installed code")
    if list(manifest.get("dense_features", [])) != list(DENSE_FEATURES):
        raise ArtefactCompatibilityError("ranking feature definitions of the artefact differ from the installed code")
    for name, digest in manifest.get("files", {}).items():
        f = directory / name
        if not f.exists():
            raise ArtefactCompatibilityError(f"artefact file {name} is missing")
        if _sha256(f) != digest:
            raise ArtefactCompatibilityError(f"checksum mismatch for {name}: the artefact was modified or is corrupt")
    return manifest


def load_artefacts(directory: str | Path, device: str | None = None) -> RecommenderArtefacts:
    directory = Path(directory)
    manifest = validate_manifest(directory)
    config = Config.from_dict(json.loads((directory / "config.json").read_text()))
    if config.config_hash() != manifest["config_hash"]:
        raise ArtefactCompatibilityError("config.json does not match the manifest's config hash")
    if config.labels.version != manifest["label_version"] or config.policy.version != manifest["policy_version"]:
        raise ArtefactCompatibilityError("label or policy version in config.json disagrees with the manifest")
    dev = resolve_device(device or config.device)
    space: FeatureSpace = joblib.load(directory / "feature_space.joblib")
    duration = DurationBaseline.from_dict(json.loads((directory / "duration_baseline.json").read_text()))
    if duration.version != manifest["duration_version"]:
        raise ArtefactCompatibilityError("duration baseline version disagrees with the manifest")
    tower_dims = TowerDims(**manifest["tower_dims"])
    ranker_dims = RankerDims(**manifest["ranker_dims"])
    expected = {"n_topics": len(space.topic_vocab) + 2, "n_languages": len(space.language_vocab) + 2,
                "n_creators": len(space.creator_vocab) + 2, "n_videos": len(space.video_vocab) + 2,
                "n_dense": space.n_dense}
    for key, value in expected.items():
        if getattr(tower_dims, key) != value:
            raise ArtefactCompatibilityError(f"feature space and model disagree on {key}: {value} vs {getattr(tower_dims, key)}")
    try:
        tower = TwoTower(tower_dims, config.retrieval)
        tower.load_state_dict(torch.load(directory / "retriever.pt", map_location="cpu", weights_only=True), strict=True)
        blob = torch.load(directory / "ranker.pt", map_location="cpu", weights_only=True)
        net = MultiTaskRanker(ranker_dims, config.ranker)
        net.load_state_dict(blob["state_dict"], strict=True)
    except (RuntimeError, KeyError) as exc:
        raise ArtefactCompatibilityError(f"model weights do not fit the recorded architecture: {exc}") from exc
    meta = json.loads((directory / "ranker_meta.json").read_text())
    extra = json.loads((directory / "report.json").read_text())
    retriever = Retriever(tower, tower_dims, config, dev, history=meta.get("retriever_history", []))
    ranker = Ranker(net, ranker_dims, config, blob["dense_mean"].numpy(), blob["dense_std"].numpy(),
                    pos_weights=meta["pos_weights"],
                    calibrators={t: PlattCalibrator.from_dict(c) for t, c in meta["calibrators"].items()},
                    device=dev, history=meta.get("history", []))
    return RecommenderArtefacts(config=config, space=space, duration_baseline=duration, retriever=retriever,
                                ranker=ranker, model_version=manifest["model_version"], splits=extra.get("splits", {}),
                                report=extra.get("report", {}))
