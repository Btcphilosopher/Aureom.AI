"""Versioned, reproducible configuration.

Every knob that changes labels, features, model shape, policy or evaluation lives here so
that an artefact can record exactly which configuration produced it (see ``config_hash``).
Configs load from TOML (``tomllib``) or plain dicts; unknown keys are rejected.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import tomllib
from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any

from .constants import HOUR


@dataclass
class EventConfig:
    """Event cleaning rules (see docs/data_contracts.md)."""

    max_event_lateness_seconds: float = 48 * HOUR      # received_at - occurred_at above this => dropped
    clock_skew_tolerance_seconds: float = 300.0        # received_at may precede occurred_at by this much
    interval_end_tolerance_seconds: float = 2.0        # interval end may exceed duration by this (clipped)
    unknown_foreground_policy: str = "exclude"         # "exclude" | "foreground"


@dataclass
class LabelConfig:
    """Outcome window and versioned label thresholds per playback context."""

    version: str = "labels-v1"
    outcome_window_seconds: float = 6 * HOUR
    late_arrival_grace_seconds: float = 2 * HOUR
    attribution_fallback: bool = True                  # attribute request-less outcomes to latest prior impression
    short_form_max_duration_seconds: float = 120.0     # videos up to this length belong to the short-form surface
    # meaningful view  <=> unique_watched_seconds >= min(min_seconds, min_fraction * duration)
    meaningful_view: dict[str, dict[str, float]] = field(default_factory=lambda: {
        "short_form": {"min_seconds": 10.0, "min_fraction": 0.5},
        "long_form": {"min_seconds": 120.0, "min_fraction": 0.25},
    })
    # early skip  <=> play observed and unique_watched_seconds < min(max_seconds, max_fraction * duration)
    early_skip: dict[str, dict[str, float]] = field(default_factory=lambda: {
        "short_form": {"max_seconds": 2.0, "max_fraction": 0.15},
        "long_form": {"max_seconds": 10.0, "max_fraction": 0.03},
    })
    satisfaction_min: float = 1.0
    satisfaction_max: float = 5.0


@dataclass
class DurationConfig:
    """Duration-conditioned viewing baseline (fitted on training data only)."""

    version: str = "duration-v1"
    n_buckets: int = 10
    min_bucket_count: int = 150
    max_reference_points: int = 2000


@dataclass
class SplitConfig:
    """Chronological boundaries as fractions of the dataset time span.

    retrieval train   [0, a)      retrieval validation [a, b)   -> retriever frozen at b
    ranker train      [b, c)      ranker early stopping [c, d)  calibration [d, e)
    test (rolling)    [e, 1]
    """

    retrieval_train_end: float = 0.50
    retrieval_valid_end: float = 0.57
    ranker_train_end: float = 0.74
    ranker_valid_end: float = 0.79
    calibration_end: float = 0.84


@dataclass
class FeatureConfig:
    text_max_features: int = 4000
    text_svd_dim: int = 24
    max_history: int = 30
    max_selected_topics: int = 8
    max_followed_creators: int = 16
    max_preferred_languages: int = 4
    max_video_topics: int = 4
    min_video_interactions: int = 3      # positives needed before a video gets its own ID embedding
    new_video_days: float = 3.0
    new_user_days: float = 3.0
    sparse_history_threshold: int = 10


@dataclass
class StatsConfig:
    """Point-in-time aggregate statistics (popularity, smoothed feedback rates)."""

    popularity_half_life_days: float = 3.0
    refresh_seconds: float = 3600.0      # statistics are recomputed on this grid; floor(t) <= t so no look-ahead
    prior_strength: float = 20.0         # pseudo-impressions for Bayesian smoothing


@dataclass
class RetrievalConfig:
    embedding_dim: int = 32
    feature_dim: int = 32
    hidden_dim: int = 64
    use_video_id_embedding: bool = True
    use_creator_embedding: bool = True
    id_dropout: float = 0.15
    history_pooling: str = "time_decay"  # "time_decay" | "attention"
    initial_decay_days: float = 5.0
    temperature: float = 0.07
    n_uniform_negatives: int = 512
    logq_correction: float = 1.0         # 0 disables the sampling-bias correction
    multi_positive: str = "mask"         # "mask" | "average"
    batch_size: int = 256
    epochs: int = 12
    learning_rate: float = 2e-3
    weight_decay: float = 1e-5
    patience: int = 3
    validation_k: int = 50
    max_validation_examples: int = 4000
    index: str = "auto"                  # "auto" | "exact" | "faiss_flat" | "faiss_hnsw"
    exact_max_rows: int = 50_000         # "auto" uses exact eligible retrieval at or below this size
    oversample_factor: int = 4
    max_oversample_rounds: int = 3
    exact_fallback_max_eligible: int = 20_000


@dataclass
class CandidateConfig:
    """Per-source candidate quotas. A quota of 0 disables the source."""

    two_tower: int = 150
    content_similarity: int = 60
    followed_creators: int = 40
    selected_topics: int = 60
    recent: int = 30
    popularity: int = 40
    exploration: int = 20
    exploration_new_video_share: float = 0.5
    content_profile_half_life_days: float = 7.0


@dataclass
class EligibilityConfig:
    language_filter: str = "strict"      # "strict": only preferred languages when the user declared any; "off"
    excluded_labels: tuple[str, ...] = ("not_recommendable",)
    required_labels: tuple[str, ...] = ()
    exclude_negative_feedback_videos: bool = True


@dataclass
class RankerConfig:
    hidden_dims: tuple[int, ...] = (128, 64)
    dropout: float = 0.1
    learning_rate: float = 1e-3
    epochs: int = 12
    batch_size: int = 1024
    l2: float = 1e-6
    patience: int = 3
    task_weights: dict[str, float] = field(default_factory=lambda: {
        "meaningful": 1.0, "duration": 1.0, "like_or_save": 1.0, "satisfaction": 0.5, "negative": 1.0,
    })
    use_tower_embeddings: bool = True
    use_position_feature: bool = True
    pos_weight: str = "auto"             # "none" | "auto": sqrt-balanced positive weight with logit prior correction
    pos_weight_cap: float = 10.0
    pos_weight_rate_threshold: float = 0.05
    duration_target: str = "duration_adjusted"   # | "completion_ratio" | "capped_watch_seconds" (ablations)
    calibration_min_examples: int = 200
    calibration_min_class_support: int = 30


@dataclass
class PolicyConfig:
    """Linear value policy over calibrated head outputs (all on a [0, 1] scale)."""

    version: str = "policy-v1"
    w_meaningful: float = 1.0
    w_duration: float = 0.5
    w_positive: float = 1.0
    w_satisfaction: float = 1.0
    w_negative: float = 2.0


@dataclass
class CompositionConfig:
    lambda_diversity: float = 0.1
    lambda_freshness: float = 0.05
    freshness_half_life_days: float = 7.0
    max_per_creator: int = 3
    max_topic_share: float = 0.5
    near_duplicate_similarity: float = 0.97
    consumed_handling: str = "exclude"   # "exclude" | "demote" | "allow"
    consumed_penalty: float = 0.5
    max_exploration_slots: int = 2
    exploration_positions: tuple[int, ...] = (4, 11)   # zero-based feed positions reserved for exploration
    # soft constraints in the order they are relaxed when the feed cannot be filled
    relaxation_order: tuple[str, ...] = ("topic_concentration", "creator_cap", "near_duplicate")


@dataclass
class EvaluationConfig:
    ks: tuple[int, ...] = (5, 10, 20)
    retrieval_ks: tuple[int, ...] = (10, 50, 100)
    feed_k: int = 20
    relevance_horizon_days: float = 3.0
    max_eval_requests: int = 1500
    bootstrap_samples: int = 200
    ece_bins: int = 10
    min_propensity_matches: int = 50


@dataclass
class Config:
    seed: int = 42
    model_name: str = "aureom-core"
    device: str = "cpu"                  # "cpu" | "cuda" | "auto" (GPU is optional)
    torch_threads: int = 0               # 0 leaves the PyTorch default
    events: EventConfig = field(default_factory=EventConfig)
    labels: LabelConfig = field(default_factory=LabelConfig)
    duration: DurationConfig = field(default_factory=DurationConfig)
    splits: SplitConfig = field(default_factory=SplitConfig)
    features: FeatureConfig = field(default_factory=FeatureConfig)
    stats: StatsConfig = field(default_factory=StatsConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    candidates: CandidateConfig = field(default_factory=CandidateConfig)
    eligibility: EligibilityConfig = field(default_factory=EligibilityConfig)
    ranker: RankerConfig = field(default_factory=RankerConfig)
    policy: PolicyConfig = field(default_factory=PolicyConfig)
    composition: CompositionConfig = field(default_factory=CompositionConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)

    # ------------------------------------------------------------------ io
    def to_dict(self) -> dict[str, Any]:
        return _to_plain(dataclasses.asdict(self))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Config":
        return _from_dict(cls, data)

    @classmethod
    def from_toml(cls, path: str | Path) -> "Config":
        with open(path, "rb") as fh:
            return cls.from_dict(tomllib.load(fh))

    def config_hash(self) -> str:
        """Stable hash of the full configuration (used in the model version)."""
        blob = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(blob.encode()).hexdigest()[:12]

    def copy(self, **overrides: Any) -> "Config":
        """Deep copy with dotted overrides, e.g. ``cfg.copy(**{"policy.w_duration": 0.0})``."""
        new = Config.from_dict(self.to_dict())
        for key, value in overrides.items():
            obj: Any = new
            parts = key.split(".")
            for p in parts[:-1]:
                obj = getattr(obj, p)
            if not hasattr(obj, parts[-1]):
                raise KeyError(f"unknown config key {key!r}")
            setattr(obj, parts[-1], value)
        return new


def _to_plain(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _to_plain(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_to_plain(v) for v in value]
    return value


def _from_dict(cls: type, data: dict[str, Any]) -> Any:
    kwargs: dict[str, Any] = {}
    known = {f.name: f for f in fields(cls)}
    unknown = set(data) - set(known)
    if unknown:
        raise KeyError(f"unknown keys for {cls.__name__}: {sorted(unknown)}")
    for name, value in data.items():
        default = getattr(cls(), name)
        if is_dataclass(default):
            kwargs[name] = _from_dict(type(default), value)
        elif isinstance(default, tuple):
            kwargs[name] = tuple(value)
        elif isinstance(default, dict):
            merged = json.loads(json.dumps(default))
            for k, v in value.items():
                merged[k] = {**merged.get(k, {}), **v} if isinstance(v, dict) else v
            kwargs[name] = merged
        elif isinstance(default, bool):
            kwargs[name] = bool(value)
        elif isinstance(default, float):
            kwargs[name] = float(value)
        else:
            kwargs[name] = value
    return cls(**kwargs)


def load_config(path: str | Path | None = None) -> Config:
    """Load a config from TOML, or return defaults when ``path`` is None."""
    return Config() if path is None else Config.from_toml(path)
