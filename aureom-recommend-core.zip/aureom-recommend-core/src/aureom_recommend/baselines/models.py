"""The six reproducible baselines."""
from __future__ import annotations

import numpy as np
import scipy.sparse as sp
from sklearn.feature_extraction.text import TfidfVectorizer

from ..constants import DAY
from ..data.catalogue import Catalogue
from ..features.state import RequestState, history_weights
from .base import Baseline, BaselineData, popularity_fallback


class RecentBaseline(Baseline):
    """1. Eligible recent videos: newest first."""

    name = "recent"

    def score(self, state: RequestState, rows: np.ndarray, catalogue: Catalogue) -> np.ndarray:
        return -(state.t - catalogue.published_at[rows]) / DAY


class PopularityBaseline(Baseline):
    """2. Time-decayed popularity: exponentially decayed count of positives received before the request."""

    name = "popularity"

    def score(self, state: RequestState, rows: np.ndarray, catalogue: Catalogue) -> np.ndarray:
        return state.stats.popularity[catalogue.video_index[rows]]


class FeedbackRateBaseline(Baseline):
    """3. Smoothed positive-feedback rate ``(pos + a * m) / (imp + a)``.

    ``m`` is the global positive rate before the request and ``a`` the prior strength, so a
    video with no impressions scores exactly the global rate instead of 0 or 1.
    """

    name = "feedback_rate"

    def score(self, state: RequestState, rows: np.ndarray, catalogue: Catalogue) -> np.ndarray:
        return state.stats.positive_rate[catalogue.video_index[rows]]


class TfidfBaseline(Baseline):
    """4. TF-IDF content similarity between a video and the user's time-decayed history profile."""

    name = "tfidf_content"

    def __init__(self, half_life_days: float = 7.0, negative_weight: float = 0.5) -> None:
        self.half_life_days = half_life_days
        self.negative_weight = negative_weight

    def fit(self, data: BaselineData) -> "TfidfBaseline":
        cat = data.catalogue
        rows = cat.rows_visible_before(data.cutoff)
        self.vectorizer = TfidfVectorizer(max_features=data.config.features.text_max_features, sublinear_tf=True)
        self.vectorizer.fit(cat.text(rows))
        self.matrix = sp.csr_matrix(self.vectorizer.transform(cat.text()))      # all rows, training vocabulary
        return self

    def score(self, state: RequestState, rows: np.ndarray, catalogue: Catalogue) -> np.ndarray:
        w_pos, w_neg = history_weights(state.items, state.t, self.half_life_days)
        w = w_pos - self.negative_weight * w_neg
        if len(w) == 0 or not np.any(w_pos > 0):
            return popularity_fallback(state, rows, catalogue)
        profile = np.asarray(self.matrix[state.items.row].T @ w).ravel()
        norm = np.linalg.norm(profile)
        if norm == 0:
            return popularity_fallback(state, rows, catalogue)
        return np.asarray(self.matrix[rows] @ (profile / norm)).ravel() + 1e-6 * popularity_fallback(state, rows, catalogue)


class ExplicitPreferenceBaseline(Baseline):
    """5. Explicit-topic and followed-creator matching (popularity breaks ties and covers users with no preferences)."""

    name = "explicit_preferences"

    def __init__(self, follow_weight: float = 2.0, topic_weight: float = 1.0) -> None:
        self.follow_weight = follow_weight
        self.topic_weight = topic_weight

    def score(self, state: RequestState, rows: np.ndarray, catalogue: Catalogue) -> np.ndarray:
        score = 0.25 * popularity_fallback(state, rows, catalogue)
        if len(state.followed_creator_idx):
            score = score + self.follow_weight * np.isin(catalogue.creator_index[rows], state.followed_creator_idx)
        if len(state.selected_topic_cat_idx):
            tm = catalogue.topic_matrix[rows]
            overlap = tm[:, state.selected_topic_cat_idx].sum(axis=1) / np.maximum(tm.sum(axis=1), 1)
            score = score + self.topic_weight * overlap
        return score


class ImplicitCFBaseline(Baseline):
    """6. Implicit-feedback collaborative filtering (ALS, Hu, Koren & Volinsky 2008) with user fold-in.

    Item factors are learned from training positives. At request time the user factor is
    solved in closed form from the user's history *as of the request*, so users unseen in
    training are handled as soon as they have history; users with no usable history and
    videos without factors fall back to popularity.
    """

    name = "implicit_cf"

    def __init__(self, factors: int = 32, regularisation: float = 0.1, alpha: float = 10.0, iterations: int = 10) -> None:
        self.factors, self.reg, self.alpha, self.iterations = factors, regularisation, alpha, iterations

    def fit(self, data: BaselineData) -> "ImplicitCFBaseline":
        pos = data.impressions.loc[data.impressions["is_positive"].to_numpy()]
        n_items = data.catalogue.n_videos
        users, u_idx = np.unique(pos["user_id"].to_numpy(dtype=object).astype(str), return_inverse=True)
        counts = sp.csr_matrix((np.ones(len(pos)), (u_idx, pos["video_idx"].to_numpy())), shape=(len(users), n_items))
        counts.sum_duplicates()
        rng = np.random.default_rng(data.seed)
        f = self.factors
        X = rng.normal(scale=0.05, size=(len(users), f))
        Y = rng.normal(scale=0.05, size=(n_items, f))
        eye = self.reg * np.eye(f)

        def solve(target: np.ndarray, fixed: np.ndarray, matrix: sp.csr_matrix) -> None:
            gram = fixed.T @ fixed
            for i in range(matrix.shape[0]):
                lo, hi = matrix.indptr[i], matrix.indptr[i + 1]
                if lo == hi:
                    target[i] = 0.0
                    continue
                idx, conf = matrix.indices[lo:hi], 1.0 + self.alpha * matrix.data[lo:hi]
                F = fixed[idx]
                target[i] = np.linalg.solve(gram + (F.T * (conf - 1.0)) @ F + eye, F.T @ conf)

        item_view = counts.T.tocsr()
        for _ in range(self.iterations):
            solve(X, Y, counts)
            solve(Y, X, item_view)
        self.item_factors = Y
        self.has_factor = np.asarray(item_view.getnnz(axis=1) > 0)
        self.gram = Y.T @ Y
        return self

    def score(self, state: RequestState, rows: np.ndarray, catalogue: Catalogue) -> np.ndarray:
        fallback = popularity_fallback(state, rows, catalogue)
        w_pos, _ = history_weights(state.items, state.t, half_life_days=14.0)
        use = (w_pos > 0) & self.has_factor[state.items.video_idx] if len(w_pos) else np.array([], dtype=bool)
        if not np.any(use):
            return fallback
        F = self.item_factors[state.items.video_idx[use]]
        conf = 1.0 + self.alpha * w_pos[use]
        x = np.linalg.solve(self.gram + (F.T * (conf - 1.0)) @ F + self.reg * np.eye(self.factors), F.T @ conf)
        vid = catalogue.video_index[rows]
        # videos without factors (new since training) get the median CF score plus the popularity tie-break
        cf = self.item_factors[vid] @ x
        cf = np.where(self.has_factor[vid], cf, np.median(cf[self.has_factor[vid]]) if self.has_factor[vid].any() else 0.0)
        return cf + 1e-3 * fallback


def all_baselines() -> list[Baseline]:
    return [RecentBaseline(), PopularityBaseline(), FeedbackRateBaseline(), TfidfBaseline(),
            ExplicitPreferenceBaseline(), ImplicitCFBaseline()]


BASELINE_NAMES = [b.name for b in all_baselines()]


def make_baseline(name: str) -> Baseline:
    for b in all_baselines():
        if b.name == name:
            return b
    raise KeyError(f"unknown baseline {name!r}; choose from {BASELINE_NAMES}")
