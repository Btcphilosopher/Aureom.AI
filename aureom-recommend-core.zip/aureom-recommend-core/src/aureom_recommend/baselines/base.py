"""Baseline interface and the shared "score eligible videos, take the top k" recommender.

Every baseline

* is fitted only on training impressions (matured before the training cutoff),
* scores candidates from a :class:`RequestState`, i.e. from information received before the
  request time (popularity and feedback statistics come from ``state.stats``),
* returns a sensible ranking for users and videos that were absent from training.

``baseline_recommender`` wraps a baseline in the same call signature as
:func:`aureom_recommend.inference.recommend.recommend`, so the evaluation harness treats
baselines and the learned system identically. Baselines obey the same hard eligibility
rules and exact-duplicate suppression, but apply no diversity re-ranking.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable, Iterable

import numpy as np
import pandas as pd

from ..composition.eligibility import hard_eligibility_mask
from ..config import Config
from ..data.catalogue import Catalogue
from ..data.histories import HistoryStore, PreferenceStore
from ..data.timeutil import as_epoch
from ..features.state import RequestState, build_request_state
from ..inference.types import Feed, FeedItem


@dataclass
class BaselineData:
    catalogue: Catalogue
    impressions: pd.DataFrame        # training impressions only
    cutoff: float
    config: Config
    seed: int = 0


class Baseline(ABC):
    name: str = "baseline"

    def fit(self, data: BaselineData) -> "Baseline":
        return self

    @abstractmethod
    def score(self, state: RequestState, rows: np.ndarray, catalogue: Catalogue) -> np.ndarray:
        """Scores (higher is better) for the catalogue ``rows`` of one request."""


def popularity_fallback(state: RequestState, rows: np.ndarray, catalogue: Catalogue) -> np.ndarray:
    """Cold-start fallback shared by personalised baselines: smoothed popularity in [0, 1)."""
    pop = state.stats.popularity[catalogue.video_index[rows]]
    return pop / (1.0 + pop)


def top_k_rows(rows: np.ndarray, scores: np.ndarray, k: int, groups: np.ndarray) -> np.ndarray:
    """Indices into ``rows`` of the top ``k`` by score, one per duplicate group, deterministic ties."""
    order = np.lexsort((rows, -scores))
    chosen: list[int] = []
    seen: set[int] = set()
    for i in order.tolist():
        g = int(groups[i])
        if g in seen:
            continue
        seen.add(g)
        chosen.append(i)
        if len(chosen) >= k:
            break
    return np.asarray(chosen, dtype="int64")


def baseline_recommender(baseline: Baseline, config: Config) -> Callable[..., Feed]:
    def recommend(user_id: str, context: str, as_of: Any, k: int, catalogue: Catalogue, histories: HistoryStore,
                  preferences: PreferenceStore, artefacts: Any = None, previously_recommended: Iterable[str] = (),
                  seed: int = 0) -> Feed:
        t = as_epoch(as_of)
        state = build_request_state(user_id, context, t, catalogue, histories, preferences, None, config)
        rows = np.flatnonzero(hard_eligibility_mask(state, catalogue, config, previously_recommended))
        feed = Feed(user_id=str(user_id), context=context, as_of=t, diagnostics={"n_eligible": int(len(rows))})
        if len(rows) == 0 or k <= 0:
            return feed
        scores = np.asarray(baseline.score(state, rows, catalogue), dtype="float64")
        top = top_k_rows(rows, scores, k, catalogue.duplicate_group[rows])
        for rank, i in enumerate(top.tolist(), start=1):
            feed.items.append(FeedItem(
                video_id=str(catalogue.video_ids[rows[i]]), rank=rank, retrieval_sources=(baseline.name,),
                prediction_heads={}, score_contributions={"baseline_score": float(scores[i])},
                final_score=float(scores[i]), exploration={"is_exploration": False},
                model_version=f"baseline:{baseline.name}", policy_version="none"))
        return feed

    recommend.__name__ = f"recommend_{baseline.name}"
    return recommend
