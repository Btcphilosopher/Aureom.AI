"""Hybrid candidate generation with source attribution.

Sources (each with its own quota; 0 disables it):

``two_tower``           nearest videos to the user embedding (exact or FAISS)
``content_similarity``  nearest videos to the user's time-decayed content profile
``followed_creators``   newest eligible videos of followed creators
``selected_topics``     eligible videos on declared topics, ordered by popularity and freshness
``recent``              newest eligible videos
``popularity``          highest time-decayed popularity as of the request
``exploration``         a bounded, seeded uniform sample (see composition/exploration notes)

Hard eligibility is applied *before* every source, so no source can propose a blocked,
unavailable or excluded video. Candidates are de-duplicated by catalogue row and every
candidate keeps the list of sources that proposed it. When supply is short, fewer
candidates are returned - nothing is padded with ineligible videos.

With personalisation disabled only ``recent``, ``popularity`` and ``exploration`` run.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np

from ..config import Config
from ..constants import (DAY, PERSONALISED_SOURCES, SOURCES, SRC_CONTENT, SRC_EXPLORATION, SRC_FOLLOWED,
                         SRC_POPULARITY, SRC_RECENT, SRC_TOPICS, SRC_TWO_TOWER)
from ..data.catalogue import Catalogue
from ..features.state import RequestState, history_weights
from .index import exact_top_k


@dataclass
class CandidateSet:
    rows: np.ndarray                                     # sorted catalogue rows
    sources: list[tuple[str, ...]]                       # per candidate, in SOURCES order
    exploration_details: dict[int, dict[str, Any]] = field(default_factory=dict)   # row -> sampling details
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def __len__(self) -> int:
        return len(self.rows)


def content_profile(state: RequestState, content_vectors: np.ndarray, config: Config) -> Optional[np.ndarray]:
    """Unit-norm time-decayed content profile of the user's history, or None without positive history."""
    if "content_profile" not in state.cache:
        w_pos, w_neg = history_weights(state.items, state.t, config.candidates.content_profile_half_life_days)
        profile = None
        if len(w_pos) and w_pos.sum() > 0:
            vec = (w_pos - 0.5 * w_neg) @ content_vectors[state.items.row]
            norm = np.linalg.norm(vec)
            profile = (vec / norm).astype("float32") if norm > 0 else None
        state.cache["content_profile"] = profile
    return state.cache["content_profile"]


def _top(rows: np.ndarray, scores: np.ndarray, k: int) -> np.ndarray:
    if len(rows) == 0 or k <= 0:
        return rows[:0]
    order = np.lexsort((rows, -scores))[:k]
    return rows[order]


def generate_candidates(state: RequestState, catalogue: Catalogue, eligible: np.ndarray, config: Config,
                        rng: np.random.Generator, *, user_embedding: Optional[np.ndarray] = None,
                        index: Any = None, content_vectors: Optional[np.ndarray] = None) -> CandidateSet:
    """Collect candidates from every enabled source among ``eligible`` rows."""
    cc = config.candidates
    el_rows = np.flatnonzero(eligible)
    proposals: dict[str, np.ndarray] = {}
    diag: dict[str, Any] = {"n_eligible": int(len(el_rows))}
    details: dict[int, dict[str, Any]] = {}
    if len(el_rows) == 0:
        return CandidateSet(rows=el_rows, sources=[], diagnostics=diag)
    quota = {s: int(getattr(cc, s)) for s in SOURCES}
    if not state.personalised:
        for s in PERSONALISED_SOURCES:
            quota[s] = 0
    age = state.t - catalogue.published_at[el_rows]
    pop = state.stats.popularity[catalogue.video_index[el_rows]]

    if quota[SRC_TWO_TOWER] and user_embedding is not None and index is not None:
        rows, _, info = index.search(user_embedding, quota[SRC_TWO_TOWER], eligible)
        proposals[SRC_TWO_TOWER] = rows
        diag["index"] = info
    if quota[SRC_CONTENT] and content_vectors is not None:
        profile = content_profile(state, content_vectors, config)
        if profile is not None:
            proposals[SRC_CONTENT] = exact_top_k(content_vectors, profile, quota[SRC_CONTENT], eligible)[0]
    if quota[SRC_FOLLOWED] and len(state.followed_creator_idx):
        m = np.isin(catalogue.creator_index[el_rows], state.followed_creator_idx)
        proposals[SRC_FOLLOWED] = _top(el_rows[m], -age[m], quota[SRC_FOLLOWED])
    if quota[SRC_TOPICS] and len(state.selected_topic_cat_idx):
        m = catalogue.topic_matrix[el_rows][:, state.selected_topic_cat_idx].any(axis=1)
        score = pop[m] / (1.0 + pop[m]) + 0.5 * np.exp(-age[m] / (7 * DAY))
        proposals[SRC_TOPICS] = _top(el_rows[m], score, quota[SRC_TOPICS])
    if quota[SRC_RECENT]:
        proposals[SRC_RECENT] = _top(el_rows, -age, quota[SRC_RECENT])
    if quota[SRC_POPULARITY]:
        proposals[SRC_POPULARITY] = _top(el_rows, pop, quota[SRC_POPULARITY])
    if quota[SRC_EXPLORATION]:
        # two disjoint pools, each sampled uniformly without replacement, so that the
        # probability of a row being drawn is exactly n_drawn / pool_size for its pool
        is_new = age < config.features.new_video_days * DAY
        n_new = int(round(quota[SRC_EXPLORATION] * cc.exploration_new_video_share))
        drawn = []
        for pool_name, pool, want in (("new_videos", el_rows[is_new], n_new),
                                      ("established_videos", el_rows[~is_new], quota[SRC_EXPLORATION] - n_new)):
            take = min(want, len(pool))
            if take <= 0:
                continue
            pick = np.sort(rng.choice(pool, size=take, replace=False))
            drawn.append(pick)
            for r in pick.tolist():
                details[r] = {"pool": pool_name, "pool_size": int(len(pool)), "n_drawn": int(take),
                              "candidate_draw_probability": take / len(pool)}
        proposals[SRC_EXPLORATION] = np.concatenate(drawn) if drawn else el_rows[:0]

    members: dict[int, list[str]] = {}
    for src in SOURCES:                                   # fixed order => deterministic attribution
        for r in proposals.get(src, np.array([], dtype="int64")).tolist():
            members.setdefault(int(r), []).append(src)
    rows = np.array(sorted(members), dtype="int64")
    diag["per_source"] = {s: int(len(p)) for s, p in proposals.items()}
    diag["n_candidates"] = int(len(rows))
    return CandidateSet(rows=rows, sources=[tuple(members[int(r)]) for r in rows.tolist()],
                        exploration_details=details, diagnostics=diag)
