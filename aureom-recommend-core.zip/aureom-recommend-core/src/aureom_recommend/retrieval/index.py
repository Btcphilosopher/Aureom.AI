"""Nearest-neighbour retrieval with eligibility filtering.

* :class:`ExactIndex` - exact search over the *eligible* rows only (NumPy). Used for small
  catalogues and as the fallback.
* :class:`FaissIndex` - FAISS inner-product search (exact ``IndexFlatIP`` or approximate
  ``IndexHNSWFlat``). The index cannot see per-request eligibility, so the search
  **oversamples** (``k * oversample_factor``), filters, and doubles the request for up to
  ``max_oversample_rounds`` rounds. If filtering still leaves too few rows it falls back to
  exact search over the eligible rows when there are at most ``exact_fallback_max_eligible``
  of them; otherwise it returns fewer than ``k``.

FAISS is optional: without it ``build_index`` returns the exact NumPy index.
"""
from __future__ import annotations

from typing import Any

import numpy as np

from ..config import RetrievalConfig

try:  # optional dependency
    import faiss  # type: ignore

    HAVE_FAISS = True
except Exception:  # pragma: no cover - exercised only without faiss installed
    faiss = None
    HAVE_FAISS = False


def exact_top_k(embeddings: np.ndarray, query: np.ndarray, k: int, eligible: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Exact top-k rows by inner product among ``eligible`` rows; deterministic tie-break by row index."""
    rows = np.flatnonzero(eligible)
    if len(rows) == 0 or k <= 0:
        return np.array([], dtype="int64"), np.array([], dtype="float32")
    scores = embeddings[rows] @ query
    k = min(k, len(rows))
    part = np.argpartition(-scores, k - 1)[:k] if k < len(rows) else np.arange(len(rows))
    order = part[np.lexsort((rows[part], -scores[part]))]
    return rows[order], scores[order].astype("float32")


class ExactIndex:
    kind = "exact"

    def __init__(self, embeddings: np.ndarray) -> None:
        self.embeddings = np.ascontiguousarray(embeddings, dtype="float32")

    def search(self, query: np.ndarray, k: int, eligible: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
        rows, scores = exact_top_k(self.embeddings, np.asarray(query, dtype="float32"), k, eligible)
        return rows, scores, {"method": "exact", "rounds": 0, "fallback": False}


class FaissIndex:
    def __init__(self, embeddings: np.ndarray, kind: str, cfg: RetrievalConfig) -> None:
        if not HAVE_FAISS:
            raise RuntimeError("faiss is not installed; use the exact index")
        self.embeddings = np.ascontiguousarray(embeddings, dtype="float32")
        self.kind, self.cfg = kind, cfg
        d = self.embeddings.shape[1]
        if kind == "faiss_flat":
            self.index = faiss.IndexFlatIP(d)
        elif kind == "faiss_hnsw":
            self.index = faiss.IndexHNSWFlat(d, 32, faiss.METRIC_INNER_PRODUCT)
            self.index.hnsw.efConstruction = 80
            self.index.hnsw.efSearch = 64
        else:
            raise ValueError(f"unknown faiss index kind {kind!r}")
        if len(self.embeddings):
            self.index.add(self.embeddings)

    def search(self, query: np.ndarray, k: int, eligible: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
        n = len(self.embeddings)
        info: dict[str, Any] = {"method": self.kind, "rounds": 0, "fallback": False}
        n_eligible = int(eligible.sum())
        if n == 0 or k <= 0 or n_eligible == 0:
            return np.array([], dtype="int64"), np.array([], dtype="float32"), info
        target = min(k, n_eligible)
        q = np.ascontiguousarray(np.asarray(query, dtype="float32")[None, :])
        fetch = min(n, max(k * self.cfg.oversample_factor, k))
        rows, scores = np.array([], dtype="int64"), np.array([], dtype="float32")
        for rounds in range(1, self.cfg.max_oversample_rounds + 1):
            dist, idx = self.index.search(q, int(fetch))
            ok = idx[0] >= 0                                   # FAISS pads missing results with -1
            cand, cs = idx[0][ok], dist[0][ok]
            keep = eligible[cand]
            rows, scores = cand[keep][:k].astype("int64"), cs[keep][:k].astype("float32")
            info["rounds"] = rounds
            if len(rows) >= target or fetch >= n:
                break
            fetch = min(n, fetch * 2)
        if len(rows) < target and n_eligible <= self.cfg.exact_fallback_max_eligible:
            rows, scores = exact_top_k(self.embeddings, q[0], k, eligible)
            info["fallback"] = True
        info["returned"] = int(len(rows))
        return rows, scores, info


def build_index(embeddings: np.ndarray, cfg: RetrievalConfig) -> ExactIndex | FaissIndex:
    kind = cfg.index
    if kind == "auto":
        kind = "exact" if (len(embeddings) <= cfg.exact_max_rows or not HAVE_FAISS) else "faiss_hnsw"
    if kind == "exact" or not HAVE_FAISS:
        return ExactIndex(embeddings)
    return FaissIndex(embeddings, kind, cfg)
