r"""Contrastive retrieval objective: temperature-scaled sampled softmax.

For a batch of B (user, positive video) pairs and a candidate set C (the batch's own
positives plus M uniformly sampled catalogue videos)

.. math::
    \mathcal{L} = -\frac{1}{B}\sum_i \log
      \frac{\exp(\tilde s_{i,i^+})}{\exp(\tilde s_{i,i^+}) + \sum_{j \in N_i}\exp(\tilde s_{ij})},
    \qquad \tilde s_{ij} = s(u_i, v_j)/\tau - \beta \log q_j

Negatives ``N_i`` are the candidates that survive the mask (see ``build_candidate_masks`` in
training/retriever.py). A candidate is **not** a negative for row ``i`` when it

* is row ``i``'s own positive, or the same video appearing elsewhere in the batch,
* shares a ``duplicate_group_id`` with the positive (a copy of it),
* is a known positive of user ``i`` anywhere in the training data (or a copy of one),
* was not available at the example's historical time, or belongs to the other surface.

Sampled, unobserved videos are *contrastive alternatives*: the loss only says the positive
should outscore them. It does not treat them as disliked.

Sampling correction (logQ, Yi et al. 2019): in-batch negatives appear in proportion to how
often a video is a positive, which penalises popular videos. ``q_j`` is the expected number
of times candidate ``j`` enters a candidate set, ``B * p_j + M / n_pool`` with ``p_j`` the
video's share of training positives; subtracting ``beta * log q_j`` from every logit
(``beta = logq_correction``) removes that bias. The correction is used in training only.

Multiple positives: with ``multi_positive = "mask"`` other known positives are simply removed
from the denominator. With ``"average"`` they are used as additional positives and the
per-positive losses are averaged (supervised-contrastive style).
"""
from __future__ import annotations

from typing import Optional

import torch


def sampled_softmax_loss(user_emb: torch.Tensor, cand_emb: torch.Tensor, pos_index: torch.Tensor,
                         negative_mask: torch.Tensor, temperature: float, log_q: Optional[torch.Tensor] = None,
                         logq_weight: float = 0.0, extra_positive_mask: Optional[torch.Tensor] = None,
                         multi_positive: str = "mask") -> torch.Tensor:
    """Masked sampled-softmax loss.

    ``negative_mask[i, j]`` is True where candidate ``j`` may serve as a negative for row ``i``.
    ``pos_index[i]`` is the candidate index of row ``i``'s positive (always kept).
    """
    logits = user_emb @ cand_emb.T / temperature
    if log_q is not None and logq_weight != 0.0:
        logits = logits - logq_weight * log_q.unsqueeze(0)
    b = logits.shape[0]
    own = torch.zeros_like(negative_mask)
    own[torch.arange(b, device=logits.device), pos_index] = True
    neg = negative_mask & ~own
    neg_logsumexp = torch.logsumexp(logits.masked_fill(~neg, float("-inf")), dim=1)       # -inf when no negatives
    if multi_positive == "mask" or extra_positive_mask is None:
        s_pos = logits.gather(1, pos_index.unsqueeze(1)).squeeze(1)
        return (torch.logaddexp(s_pos, neg_logsumexp) - s_pos).mean()
    if multi_positive == "average":
        pos = own | (extra_positive_mask & ~neg)
        per_pos = torch.logaddexp(logits, neg_logsumexp.unsqueeze(1)) - logits
        return ((per_pos * pos).sum(1) / pos.sum(1).clamp(min=1)).mean()
    raise ValueError(f"unknown multi_positive mode {multi_positive!r}")
