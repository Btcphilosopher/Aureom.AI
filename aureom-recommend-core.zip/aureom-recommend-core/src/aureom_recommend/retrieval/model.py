"""Two-tower retrieval model.

Similarity: both towers end in L2 normalisation, so ``s(u, v) = <e_u, e_v>`` is the cosine
similarity in [-1, 1]. Training divides it by a temperature; serving uses the raw inner
product (maximum inner-product search over unit vectors == cosine top-k).

Video tower: content features only by default (text SVD, content embedding, duration,
topics, language), plus *optional* learned creator and video-ID embeddings. A brand-new
video has no ID embedding - it maps to UNK - and still gets a useful vector from content.
ID dropout during training replaces known IDs by UNK at random so the unknown-ID pathway is
actually trained rather than left at its initial value.

User tower: no user-ID embedding at all. A user is represented by declared topics, followed
creators, preferred languages, the request context and a pooled history, so unseen users
are handled by construction (empty inputs are a normal, trained-on case). The tower is
*item-based with a residual*::

    e_u = normalise( a_pos * pool_pos(e_v) - a_neg * pool_neg(e_v) + MLP(user features) )

where ``pool(e_v)`` pools the *video-tower embeddings* of history items. A user therefore
starts out as the centroid of what they engaged with, in the same space the candidates live
in (a strong, sample-efficient prior), and the MLP - fed with the declared preferences,
context and the pooled item features - learns the correction and carries users without
history.

History pooling: ``time_decay`` is the simple baseline - a weighted mean with weights
``softplus(a_type) * (0.5 + 0.5 * strength) * exp(-dt / tau)`` and learned ``tau`` -
computed separately over positive-type and negative-type items. ``attention`` replaces the
fixed decay by a learned masked attention over the same items.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..config import RetrievalConfig
from ..constants import DAY, H_NEGATIVE_TYPES, H_POSITIVE_TYPES, N_HISTORY_TYPES, PAD, UNK
from ..features.space import VideoFeatures


@dataclass
class TowerDims:
    n_dense: int
    n_topics: int
    n_languages: int
    n_creators: int
    n_videos: int
    max_history: int
    n_contexts: int = 2

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


class VideoBank:
    """Feature tensors for every catalogue row (inputs of the video tower)."""

    def __init__(self, features: VideoFeatures, device: torch.device | str = "cpu") -> None:
        self.dense = torch.as_tensor(features.dense, dtype=torch.float32, device=device)
        self.topics = torch.as_tensor(features.topics, dtype=torch.long, device=device)
        self.language = torch.as_tensor(features.language, dtype=torch.long, device=device)
        self.creator = torch.as_tensor(features.creator, dtype=torch.long, device=device)
        self.video = torch.as_tensor(features.video, dtype=torch.long, device=device)
        self.n_rows = int(self.dense.shape[0])


def _bag(emb: nn.Embedding, idx: torch.Tensor) -> torch.Tensor:
    """Mean embedding over non-PAD entries (zeros when everything is PAD)."""
    mask = (idx != PAD).unsqueeze(-1).float()
    return (emb(idx) * mask).sum(-2) / mask.sum(-2).clamp(min=1.0)


class TwoTower(nn.Module):
    def __init__(self, dims: TowerDims, cfg: RetrievalConfig) -> None:
        super().__init__()
        self.dims, self.cfg = dims, cfg
        f, h, d = cfg.feature_dim, cfg.hidden_dim, cfg.embedding_dim
        self.dense_proj = nn.Linear(dims.n_dense, f)
        self.topic_emb = nn.Embedding(dims.n_topics, f, padding_idx=PAD)
        self.lang_emb = nn.Embedding(dims.n_languages, f, padding_idx=PAD)
        self.creator_emb = nn.Embedding(dims.n_creators, f, padding_idx=PAD)
        self.video_emb = nn.Embedding(dims.n_videos, f, padding_idx=PAD)
        self.video_mlp = nn.Sequential(nn.Linear(f, h), nn.ReLU(), nn.Linear(h, d))
        # user side
        self.type_emb = nn.Embedding(N_HISTORY_TYPES, f, padding_idx=0)
        self.type_weight = nn.Embedding(N_HISTORY_TYPES, 1)
        self.log_tau = nn.Parameter(torch.full((2,), float(np.log(np.expm1(cfg.initial_decay_days)))))
        self.attention = nn.Sequential(nn.Linear(f + 2, h), nn.Tanh(), nn.Linear(h, 1))
        self.context_emb = nn.Embedding(dims.n_contexts, f)
        self.user_mlp = nn.Sequential(nn.Linear(6 * f + 3, h), nn.ReLU(), nn.Linear(h, d))
        self.history_scale = nn.Parameter(torch.tensor([1.0, 0.3]))      # a_pos, a_neg
        self.register_buffer("pos_types", torch.tensor(H_POSITIVE_TYPES))
        self.register_buffer("neg_types", torch.tensor(H_NEGATIVE_TYPES))
        for emb in (self.topic_emb, self.lang_emb, self.creator_emb, self.video_emb, self.type_emb, self.context_emb):
            nn.init.normal_(emb.weight, std=0.1)
            if emb.padding_idx is not None:
                with torch.no_grad():
                    emb.weight[emb.padding_idx].zero_()
        nn.init.constant_(self.type_weight.weight, 0.5)
        with torch.no_grad():                       # start close to the pure item-based user vector
            self.user_mlp[-1].weight.mul_(0.3)
            self.user_mlp[-1].bias.zero_()

    # ------------------------------------------------------------------ video side
    def item_base(self, bank: VideoBank, rows: torch.Tensor) -> torch.Tensor:
        """Shared item representation, used by the video tower and as history items in the user tower."""
        x = self.dense_proj(bank.dense[rows]) + _bag(self.topic_emb, bank.topics[rows]) + self.lang_emb(bank.language[rows])
        creator, video = bank.creator[rows], bank.video[rows]
        if self.training and self.cfg.id_dropout > 0:
            drop_v = torch.rand(video.shape, device=video.device) < self.cfg.id_dropout
            drop_c = torch.rand(creator.shape, device=creator.device) < self.cfg.id_dropout / 2
            video = torch.where(drop_v & (video != PAD), torch.full_like(video, UNK), video)
            creator = torch.where(drop_c & (creator != PAD), torch.full_like(creator, UNK), creator)
        if self.cfg.use_creator_embedding:
            x = x + self.creator_emb(creator)
        if self.cfg.use_video_id_embedding:
            x = x + self.video_emb(video)
        return x

    def encode_videos(self, bank: VideoBank, rows: torch.Tensor) -> torch.Tensor:
        return F.normalize(self.video_mlp(torch.relu(self.item_base(bank, rows))), dim=-1)

    # ------------------------------------------------------------------ user side
    def history_weights(self, hb: torch.Tensor, batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Normalised pooling weights over positive-type and negative-type history items, plus count features."""
        typ, strength = batch["hist_type"], batch["hist_strength"]
        valid = (batch["hist_rows"] >= 0) & (typ > 0)
        dt_days = batch["hist_dt"] / DAY
        is_pos = valid & torch.isin(typ, self.pos_types)
        is_neg = valid & torch.isin(typ, self.neg_types)
        weights = []
        if self.cfg.history_pooling == "attention":
            feats = torch.cat([hb + self.type_emb(typ), torch.log1p(dt_days).unsqueeze(-1), strength.unsqueeze(-1)], -1)
            logits = self.attention(feats).squeeze(-1)
            for m in (is_pos, is_neg):
                w = torch.softmax(logits.masked_fill(~m, -1e9), dim=1) * m.float()
                weights.append(w / w.sum(1, keepdim=True).clamp(min=1e-6))
        elif self.cfg.history_pooling == "time_decay":
            tau = F.softplus(self.log_tau) + 1e-3
            base_w = F.softplus(self.type_weight(typ).squeeze(-1)) * (0.5 + 0.5 * strength)
            for i, m in enumerate((is_pos, is_neg)):
                w = base_w * torch.exp(-dt_days / tau[i]) * m.float()
                weights.append(w / w.sum(1, keepdim=True).clamp(min=1e-6))
        else:
            raise ValueError(f"unknown history_pooling {self.cfg.history_pooling!r}")
        norm = float(np.log1p(self.dims.max_history))
        scalars = torch.stack([torch.log1p(is_pos.float().sum(1)) / norm, torch.log1p(is_neg.float().sum(1)) / norm,
                               valid.any(1).float()], dim=1)
        return weights[0], weights[1], scalars

    def encode_users(self, bank: VideoBank, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        rows = batch["hist_rows"]
        uniq, inv = torch.unique(rows.clamp(min=0), return_inverse=True)
        base = self.item_base(bank, uniq)
        hb = base[inv]                                                        # (B, L, f) item features
        hv = F.normalize(self.video_mlp(torch.relu(base)), dim=-1)[inv]       # (B, L, d) video-tower embeddings
        w_pos, w_neg, scalars = self.history_weights(hb, batch)
        pool = lambda w, x: (w.unsqueeze(-1) * x).sum(1)                      # noqa: E731
        x = torch.cat([pool(w_pos, hb), pool(w_neg, hb), _bag(self.topic_emb, batch["topics"]),
                       _bag(self.creator_emb, batch["followed"]), _bag(self.lang_emb, batch["languages"]),
                       self.context_emb(batch["context"]), scalars], dim=1)
        item_based = self.history_scale[0] * pool(w_pos, hv) - self.history_scale[1] * pool(w_neg, hv)
        return F.normalize(item_based + self.user_mlp(x), dim=-1)


def to_tensors(inputs: dict[str, np.ndarray], device: torch.device | str = "cpu") -> dict[str, torch.Tensor]:
    float_keys = {"hist_dt", "hist_strength"}
    return {k: torch.as_tensor(v, dtype=torch.float32 if k in float_keys else torch.long, device=device)
            for k, v in inputs.items()}
