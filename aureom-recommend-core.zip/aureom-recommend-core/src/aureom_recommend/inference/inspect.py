"""Algorithm inspection: every candidate of a request with its predictions and policy terms.

``recommend`` exposes this information for the items that made the feed; ``score_candidates``
returns it for *all* candidates, before composition. It is a debugging and analysis tool - the
frame contains model outputs and source attribution, not embeddings or user history.
"""
from __future__ import annotations

from typing import Any, Iterable

import numpy as np
import pandas as pd

from ..artefacts.bundle import RecommenderArtefacts
from ..composition.eligibility import hard_eligibility_mask
from ..data.catalogue import Catalogue
from ..data.histories import HistoryStore, PreferenceStore
from ..data.timeutil import as_epoch
from ..features.state import build_request_state
from ..ranking.features import ranking_features
from ..retrieval.candidates import generate_candidates
from .recommend import request_rng


def score_candidates(user_id: str, context: str, as_of: Any, catalogue: Catalogue, histories: HistoryStore,
                     preferences: PreferenceStore, artefacts: RecommenderArtefacts,
                     previously_recommended: Iterable[str] = frozenset(), seed: int = 42) -> pd.DataFrame:
    """One row per candidate: sources, calibrated head predictions, signed policy contributions, policy score."""
    cfg = artefacts.config
    t = as_epoch(as_of)
    runtime = artefacts.runtime(catalogue)
    state = build_request_state(user_id, context, t, catalogue, histories, preferences, artefacts.space, cfg)
    eligible = hard_eligibility_mask(state, catalogue, cfg, set(previously_recommended))
    user_emb = artefacts.retriever.embed_user(runtime.bank, state.tower_inputs)
    cands = generate_candidates(state, catalogue, eligible, cfg, request_rng(seed, state.user_id, context, t),
                                user_embedding=user_emb, index=runtime.index,
                                content_vectors=runtime.features.content_vectors)
    columns = ["video_id", "retrieval_sources", "policy_score"]
    if len(cands) == 0:
        return pd.DataFrame(columns=columns)
    feats = ranking_features(state, cands.rows, catalogue, runtime.features, runtime.video_embeddings, user_emb, cfg)
    preds = artefacts.ranker.predict(feats)
    total, contributions = artefacts.policy.score(preds)
    frame = pd.DataFrame({"video_id": catalogue.video_ids[cands.rows].astype(str),
                          "retrieval_sources": [", ".join(s) for s in cands.sources], "policy_score": total})
    for task, p in preds.items():
        frame[f"p_{task}"] = p
    for task, c in contributions.items():
        frame[f"contribution_{task}"] = c
    frame["policy_version"] = artefacts.policy.version
    order = np.lexsort((cands.rows, -total))
    return frame.iloc[order].reset_index(drop=True)
