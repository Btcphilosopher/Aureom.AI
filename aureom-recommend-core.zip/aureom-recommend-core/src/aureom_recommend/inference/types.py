"""Exported recommendation results.

A :class:`FeedItem` carries what is needed to inspect the algorithm (sources, head
predictions, policy contributions, exploration details, versions) and nothing private:
no embeddings and no user history.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Iterator


@dataclass(frozen=True)
class FeedItem:
    video_id: str
    rank: int                                   # 1-based position in the feed
    retrieval_sources: tuple[str, ...]
    prediction_heads: dict[str, float]          # calibrated head outputs, all in [0, 1]
    score_contributions: dict[str, float]       # signed policy and composition terms that sum to final_score
    final_score: float
    exploration: dict[str, Any]                 # {"is_exploration": bool, ...sampling details...}
    model_version: str
    policy_version: str

    def to_dict(self) -> dict[str, Any]:
        out = asdict(self)
        out["retrieval_sources"] = list(self.retrieval_sources)
        return out


@dataclass
class Feed:
    user_id: str
    context: str
    as_of: float
    items: list[FeedItem] = field(default_factory=list)
    diagnostics: dict[str, Any] = field(default_factory=dict)   # counts and relaxations only, nothing private

    def __iter__(self) -> Iterator[FeedItem]:
        return iter(self.items)

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, i: int) -> FeedItem:
        return self.items[i]

    @property
    def video_ids(self) -> list[str]:
        return [it.video_id for it in self.items]

    def to_records(self) -> list[dict[str, Any]]:
        return [it.to_dict() for it in self.items]
