"""Online inference: one call produces one composed feed."""
from __future__ import annotations

import zlib
from typing import Any, Iterable

import numpy as np

from ..artefacts.bundle import RecommenderArtefacts
from ..composition.eligibility import hard_eligibility_mask
from ..composition.rerank import compose_feed
from ..data.catalogue import Catalogue
from ..data.histories import HistoryStore, PreferenceStore
from ..data.timeutil import as_epoch
from ..features.state import build_request_state
from ..ranking.features import ranking_features
from ..retrieval.candidates import generate_candidates
from .types import Feed, FeedItem


def request_rng(seed: int, user_id: str, context: str, t: float) -> np.random.Generator:
    """Deterministic generator per (seed, user, context, time): same inputs, same exploration draws."""
    return np.random.default_rng([int(seed) & 0xFFFFFFFF, zlib.crc32(f"{user_id}|{context}|{t:.6f}".encode())])


def recommend(user_id: str, context: str, as_of: Any, k: int, catalogue: Catalogue, histories: HistoryStore,
              preferences: PreferenceStore, artefacts: RecommenderArtefacts,
              previously_recommended: Iterable[str] = frozenset(), seed: int = 42) -> Feed:
    """Recommend up to ``k`` videos for ``user_id`` on the ``context`` surface as of ``as_of``.

    Pipeline: point-in-time user state -> hard eligibility -> hybrid candidates -> multitask
    predictions -> policy score -> constrained greedy composition -> eligibility re-check.
    Fewer than ``k`` items (possibly none) are returned when eligible supply is insufficient.
    The call is deterministic given its arguments.
    """
    cfg = artefacts.config
    t = as_epoch(as_of)
    previously_recommended = set(previously_recommended)
    runtime = artefacts.runtime(catalogue)
    state = build_request_state(user_id, context, t, catalogue, histories, preferences, artefacts.space, cfg)
    eligible = hard_eligibility_mask(state, catalogue, cfg, previously_recommended)
    rng = request_rng(seed, state.user_id, context, t)
    user_emb = artefacts.retriever.embed_user(runtime.bank, state.tower_inputs)
    cands = generate_candidates(state, catalogue, eligible, cfg, rng, user_embedding=user_emb, index=runtime.index,
                                content_vectors=runtime.features.content_vectors)
    feed = Feed(user_id=state.user_id, context=context, as_of=t,
                diagnostics={**cands.diagnostics, "personalised": state.personalised, "requested": int(k)})
    if len(cands) == 0 or k <= 0:
        feed.diagnostics["returned"] = 0
        return feed
    rows = cands.rows
    feats = ranking_features(state, rows, catalogue, runtime.features, runtime.video_embeddings, user_emb, cfg)
    preds = artefacts.ranker.predict(feats)
    policy = artefacts.policy
    total, contributions = policy.score(preds)
    consumed = np.isin(catalogue.duplicate_group[rows], catalogue.video_group[state.consumed_video_idx])
    composed = compose_feed(
        total, creators=catalogue.creator_index[rows], topic_matrix=catalogue.topic_matrix[rows],
        groups=catalogue.duplicate_group[rows], content_vectors=runtime.features.content_vectors[rows],
        age_seconds=t - catalogue.published_at[rows], consumed=consumed, sources=cands.sources,
        exploration_details=[cands.exploration_details.get(int(r)) for r in rows], k=k, config=cfg.composition, rng=rng)
    # hard eligibility is re-applied to the composed feed before anything is returned
    still_eligible = hard_eligibility_mask(state, catalogue, cfg, previously_recommended)
    removed = 0
    for j, i in enumerate(composed.order):
        if not still_eligible[rows[i]]:
            removed += 1
            continue
        contrib = {task: float(c[i]) for task, c in contributions.items()}
        contrib["diversity_penalty"] = -composed.diversity_penalties[j]
        contrib["freshness_bonus"] = composed.freshness_bonuses[j]
        if composed.consumed_penalties[j]:
            contrib["consumed_penalty"] = -composed.consumed_penalties[j]
        feed.items.append(FeedItem(
            video_id=str(catalogue.video_ids[rows[i]]), rank=len(feed.items) + 1, retrieval_sources=cands.sources[i],
            prediction_heads={task: float(p[i]) for task, p in preds.items()}, score_contributions=contrib,
            final_score=float(sum(contrib.values())), exploration=composed.exploration[j] or {"is_exploration": False},
            model_version=artefacts.model_version, policy_version=policy.version))
    feed.diagnostics.update({"returned": len(feed.items), "relaxations": composed.relaxations,
                             "removed_by_final_eligibility_check": removed})
    return feed
