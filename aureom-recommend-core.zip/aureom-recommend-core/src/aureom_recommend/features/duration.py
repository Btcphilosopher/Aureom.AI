"""Duration-conditioned viewing baseline and the duration-adjusted viewing target.

Why
---
Raw watch seconds automatically favour long videos; raw completion ratio automatically
favours short ones. Both therefore confound "how long is the video" with "how much did the
viewer value it".

Formula
-------
Fit (training plays only): for each playback context ``c`` the plays are split into
duration buckets ``b`` at quantiles of ``log(duration)``; each bucket stores the empirical
distribution ``F_{c,b}`` of the completion ratio ``x = unique_watched_seconds / duration``.

Target for an impression of a video in bucket ``(c, b)``::

    r = 0                                   if no play was observed
    r = ( F(x-) + F(x) ) / 2                otherwise   (mid-rank quantile, in [0, 1])

i.e. "what fraction of training plays of similarly long videos in this context were watched
less than this one". Within every bucket the target is ~Uniform(0, 1) over plays, so no
duration range is preferred by construction.

Clipping: ``x`` is clipped to [0, 1]; durations outside the training range use the edge
buckets; buckets are merged until each holds ``min_bucket_count`` plays.

Censoring: unique coverage cannot exceed the duration, so completed plays tie at ``x = 1``.
Ties receive their mid-rank - completing a video that few people complete scores higher
than completing one that most people complete. No attempt is made to impute how much more
a completing viewer "would have" watched. Viewing is also censored by the outcome window.

Limitations: the baseline is estimated from *logged* exposure (not from random exposure);
genuine quality differences between duration ranges are normalised away; drift after the
training period is not tracked; residual within-bucket duration effects remain.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from ..config import DurationConfig
from ..constants import CONTEXTS


@dataclass
class DurationBaseline:
    version: str
    edges: list[np.ndarray] = field(default_factory=list)            # per context: inner log-duration edges
    references: list[list[np.ndarray]] = field(default_factory=list)  # per context, per bucket: sorted completion ratios
    watch_caps: list[float] = field(default_factory=list)            # per context: p95 watch seconds (ablation target)
    n_fit: int = 0

    @classmethod
    def fit(cls, impressions: pd.DataFrame, config: DurationConfig) -> "DurationBaseline":
        """Fit on *training* impressions; only observed plays contribute."""
        played = impressions.loc[(impressions["m_duration"].to_numpy() > 0) & impressions["has_play"].to_numpy()]
        ctx = played["context_idx"].to_numpy()
        logd = np.log(played["duration_seconds"].to_numpy())
        x = played["completion_ratio"].to_numpy()
        secs = played["unique_watched_seconds"].to_numpy()
        edges, refs, caps = [], [], []
        for c in range(len(CONTEXTS)):
            m = ctx == c
            n = int(m.sum())
            n_b = max(1, min(config.n_buckets, n // max(1, config.min_bucket_count)))
            if n == 0:
                edges.append(np.array([], dtype="float64"))
                refs.append([np.linspace(0.0, 1.0, 101)])            # identity fallback: r == completion ratio
                caps.append(1.0)
                continue
            inner = np.unique(np.quantile(logd[m], np.linspace(0, 1, n_b + 1)[1:-1])) if n_b > 1 else np.array([])
            bucket = np.searchsorted(inner, logd[m], side="right")
            ctx_refs = []
            for b in range(len(inner) + 1):
                vals = np.sort(x[m][bucket == b])
                if len(vals) == 0:
                    vals = np.sort(x[m])
                if len(vals) > config.max_reference_points:          # deterministic thinning
                    vals = vals[np.linspace(0, len(vals) - 1, config.max_reference_points).round().astype(int)]
                ctx_refs.append(vals.astype("float64"))
            edges.append(inner.astype("float64"))
            refs.append(ctx_refs)
            caps.append(float(max(np.quantile(secs[m], 0.95), 1.0)))
        return cls(version=config.version, edges=edges, references=refs, watch_caps=caps, n_fit=len(played))

    # ------------------------------------------------------------------ transform
    def bucket_of(self, context_idx: np.ndarray, duration: np.ndarray) -> np.ndarray:
        out = np.zeros(len(duration), dtype="int64")
        logd = np.log(np.maximum(duration, 1e-6))
        for c in range(len(self.edges)):
            m = context_idx == c
            if m.any():
                out[m] = np.searchsorted(self.edges[c], logd[m], side="right")
        return out

    def adjusted(self, context_idx: np.ndarray, duration: np.ndarray, completion_ratio: np.ndarray,
                 played: np.ndarray) -> np.ndarray:
        """Duration-adjusted viewing in [0, 1] (0 where no play was observed)."""
        context_idx = np.asarray(context_idx)
        x = np.clip(np.asarray(completion_ratio, dtype="float64"), 0.0, 1.0)
        bucket = self.bucket_of(context_idx, np.asarray(duration, dtype="float64"))
        out = np.zeros(len(x), dtype="float64")
        played = np.asarray(played, dtype=bool)
        for c in range(len(self.references)):
            for b, ref in enumerate(self.references[c]):
                m = played & (context_idx == c) & (bucket == b)
                if m.any():
                    lo = np.searchsorted(ref, x[m], side="left")
                    hi = np.searchsorted(ref, x[m], side="right")
                    out[m] = (lo + hi) / (2.0 * len(ref))
        return np.clip(out, 0.0, 1.0)

    def transform(self, impressions: pd.DataFrame, target: str = "duration_adjusted") -> pd.DataFrame:
        """Return a copy with ``duration_adjusted_viewing`` and the configured ``y_duration``."""
        df = impressions.copy()
        ctx = df["context_idx"].to_numpy()
        played = df["has_play"].to_numpy() & df["view_observed"].to_numpy()
        adj = self.adjusted(ctx, df["duration_seconds"].to_numpy(), df["completion_ratio"].to_numpy(), played)
        df["duration_adjusted_viewing"] = adj
        if target == "duration_adjusted":
            y = adj
        elif target == "completion_ratio":                           # ablation: favours short videos
            y = np.where(played, df["completion_ratio"].to_numpy(), 0.0)
        elif target == "capped_watch_seconds":                       # ablation: favours long videos
            caps = np.asarray(self.watch_caps)[ctx]
            y = np.where(played, np.clip(df["unique_watched_seconds"].to_numpy() / caps, 0.0, 1.0), 0.0)
        else:
            raise ValueError(f"unknown duration target {target!r}")
        df["y_duration"] = y.astype("float32")
        return df

    # ------------------------------------------------------------------ persistence
    def to_dict(self) -> dict[str, Any]:
        return {"version": self.version, "n_fit": self.n_fit, "watch_caps": list(self.watch_caps),
                "edges": [e.tolist() for e in self.edges],
                "references": [[r.tolist() for r in ctx] for ctx in self.references]}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DurationBaseline":
        return cls(version=data["version"], n_fit=int(data["n_fit"]), watch_caps=list(data["watch_caps"]),
                   edges=[np.asarray(e, dtype="float64") for e in data["edges"]],
                   references=[[np.asarray(r, dtype="float64") for r in ctx] for ctx in data["references"]])
