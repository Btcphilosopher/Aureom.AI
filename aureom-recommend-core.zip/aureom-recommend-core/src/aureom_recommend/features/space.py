"""Training-only fitted feature space: vocabularies, text model and scalers.

``FeatureSpace.fit`` sees only catalogue rows that were visible before the training cutoff
and only training interactions. ``transform_catalogue`` can then featurise *any* catalogue
row - including videos, creators, topics and languages that did not exist at fit time, which
map to the UNK index (the "unknown-ID pathway").
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer

from ..config import FeatureConfig
from ..constants import PAD, UNK
from ..data.catalogue import Catalogue


def _vocab(values: Iterable[str]) -> dict[str, int]:
    return {v: i + 2 for i, v in enumerate(sorted(set(values)))}      # 0 = PAD, 1 = UNK


def _l2(x: np.ndarray) -> np.ndarray:
    return x / np.maximum(np.linalg.norm(x, axis=1, keepdims=True), 1e-12)


@dataclass
class VideoFeatures:
    """Model inputs for every catalogue row."""

    dense: np.ndarray            # (n_rows, n_dense) float32
    topics: np.ndarray           # (n_rows, max_topics) int64, PAD-padded
    language: np.ndarray         # (n_rows,) int64
    creator: np.ndarray          # (n_rows,) int64
    video: np.ndarray            # (n_rows,) int64
    content_vectors: np.ndarray  # (n_rows, d) L2-normalised, model independent (similarity / diversity)


@dataclass
class FeatureSpace:
    topic_vocab: dict[str, int]
    language_vocab: dict[str, int]
    creator_vocab: dict[str, int]
    video_vocab: dict[str, int]
    tfidf: TfidfVectorizer
    svd: TruncatedSVD | None
    logdur_mean: float
    logdur_std: float
    content_dim: int
    max_video_topics: int
    cutoff: float

    @classmethod
    def fit(cls, catalogue: Catalogue, cutoff: float, train_positive_video_ids: Sequence[str],
            config: FeatureConfig, seed: int = 0) -> "FeatureSpace":
        rows = catalogue.rows_visible_before(cutoff)
        if len(rows) == 0:
            raise ValueError("no catalogue rows are visible before the training cutoff")
        topics = [t for i in rows for t in catalogue.topics[i]]
        langs = [catalogue.languages[i] for i in rows if catalogue.languages[i] is not None]
        ids, counts = np.unique(np.asarray(list(train_positive_video_ids), dtype=object).astype(str), return_counts=True)
        frequent = ids[counts >= config.min_video_interactions]
        tfidf = TfidfVectorizer(max_features=config.text_max_features, sublinear_tf=True, lowercase=True)
        matrix = tfidf.fit_transform(catalogue.text(rows))
        k = min(config.text_svd_dim, matrix.shape[1] - 1, matrix.shape[0] - 1)
        svd = None
        if k >= 2:
            svd = TruncatedSVD(n_components=k, random_state=seed, algorithm="arpack")
            svd.fit(matrix)
        logd = np.log1p(catalogue.duration[rows])
        return cls(
            topic_vocab=_vocab(topics), language_vocab=_vocab(langs),
            creator_vocab=_vocab(str(catalogue.creator_ids[i]) for i in rows), video_vocab=_vocab(frequent.tolist()),
            tfidf=tfidf, svd=svd, logdur_mean=float(logd.mean()), logdur_std=float(logd.std() + 1e-6),
            content_dim=catalogue.content_embedding.shape[1], max_video_topics=config.max_video_topics, cutoff=cutoff,
        )

    # ------------------------------------------------------------------ encoders
    def encode(self, vocab: dict[str, int], values: Iterable[str | None], width: int) -> np.ndarray:
        """Fixed-width index vector; unknown values map to UNK, the remainder is PAD."""
        out = np.full(width, PAD, dtype="int64")
        for i, v in enumerate(list(values)[:width]):
            out[i] = vocab.get(str(v), UNK)
        return out

    @property
    def text_dim(self) -> int:
        return 0 if self.svd is None else int(self.svd.n_components)

    @property
    def n_dense(self) -> int:
        return self.text_dim + self.content_dim + 3

    def transform_catalogue(self, catalogue: Catalogue) -> VideoFeatures:
        n = catalogue.n_rows
        if catalogue.content_embedding.shape[1] != self.content_dim:
            raise ValueError(f"content_embedding dimension {catalogue.content_embedding.shape[1]} does not match "
                             f"the fitted feature space ({self.content_dim})")
        if self.svd is not None:
            text = _l2(self.svd.transform(self.tfidf.transform(catalogue.text())).astype("float32"))
        else:
            text = np.zeros((n, 0), dtype="float32")
        emb = _l2(catalogue.content_embedding)
        emb[~catalogue.has_content_embedding] = 0.0
        zlog = (np.log1p(catalogue.duration) - self.logdur_mean) / self.logdur_std
        dense = np.concatenate([
            text, emb, catalogue.has_content_embedding[:, None].astype("float32"),
            np.clip(zlog, -4, 4)[:, None].astype("float32"), catalogue.is_short[:, None].astype("float32"),
        ], axis=1).astype("float32")
        topics = np.stack([self.encode(self.topic_vocab, ts, self.max_video_topics) for ts in catalogue.topics]) \
            if n else np.zeros((0, self.max_video_topics), dtype="int64")
        language = np.array([PAD if l is None else self.language_vocab.get(l, UNK) for l in catalogue.languages],
                            dtype="int64")
        creator = np.array([self.creator_vocab.get(str(c), UNK) for c in catalogue.creator_ids], dtype="int64")
        video = np.array([self.video_vocab.get(str(v), UNK) for v in catalogue.video_ids], dtype="int64")
        content = _l2(np.concatenate([emb, text], axis=1)) if (emb.shape[1] + text.shape[1]) else np.zeros((n, 1), "float32")
        return VideoFeatures(dense=dense, topics=topics, language=language, creator=creator, video=video,
                             content_vectors=content.astype("float32"))
