"""Per-request user state, shared by training-example construction and online inference.

Using one code path for both guarantees that the ranker sees the same feature definitions
offline and at serving time.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..config import Config
from ..constants import (CONTEXT_INDEX, DAY, H_EARLY_SKIP, H_MEANINGFUL, H_NEGATIVE_FEEDBACK, H_POSITIVE_FEEDBACK,
                         H_STRONG_POSITIVE)
from ..data.catalogue import Catalogue
from ..data.histories import HistoryStore, PreferenceStore, StatsSnapshot, UserItems
from ..data.schemas import UserPreferences
from .space import FeatureSpace


@dataclass
class RequestState:
    user_id: str
    context: str
    context_idx: int
    t: float
    prefs: UserPreferences
    personalised: bool
    items: UserItems                       # full history as of t (empty when personalisation is off)
    stats: StatsSnapshot
    preferred_language_idx: np.ndarray     # catalogue language indices
    selected_topic_cat_idx: np.ndarray     # catalogue topic indices
    followed_creator_idx: np.ndarray       # catalogue creator indices
    blocked_creator_idx: np.ndarray
    excluded_video_idx: np.ndarray
    consumed_video_idx: np.ndarray
    negative_video_idx: np.ndarray
    is_new_user: bool
    history_len: int
    tower_inputs: dict[str, np.ndarray] = field(default_factory=dict)   # 1-row arrays for the user tower
    cache: dict[str, Any] = field(default_factory=dict)


def tower_inputs(items: UserItems, prefs: UserPreferences, t: float, context_idx: int, space: FeatureSpace,
                 config: Config, personalised: bool = True) -> dict[str, np.ndarray]:
    """User-tower inputs (one row). History is the most recent ``max_history`` items, newest first."""
    fc = config.features
    L = fc.max_history
    rows = np.full(L, -1, dtype="int64")
    dt = np.zeros(L, dtype="float32")
    typ = np.zeros(L, dtype="int64")
    strength = np.zeros(L, dtype="float32")
    n = min(len(items), L) if personalised else 0
    if n:
        rows[:n] = items.row[::-1][:n]
        dt[:n] = np.maximum(t - items.t_item[::-1][:n], 0.0)
        typ[:n] = items.type[::-1][:n]
        strength[:n] = items.strength[::-1][:n]
    if personalised:
        topics = space.encode(space.topic_vocab, prefs.selected_topics, fc.max_selected_topics)
        followed = space.encode(space.creator_vocab, prefs.followed_creators, fc.max_followed_creators)
    else:
        topics = np.zeros(fc.max_selected_topics, dtype="int64")
        followed = np.zeros(fc.max_followed_creators, dtype="int64")
    langs = space.encode(space.language_vocab, prefs.preferred_languages, fc.max_preferred_languages)
    return {"hist_rows": rows, "hist_dt": dt, "hist_type": typ, "hist_strength": strength, "topics": topics,
            "followed": followed, "languages": langs, "context": np.array(context_idx, dtype="int64")}


def build_request_state(user_id: str, context: str, as_of: float, catalogue: Catalogue, histories: HistoryStore,
                        preferences: PreferenceStore, space: FeatureSpace | None, config: Config) -> RequestState:
    """Assemble everything known about the user strictly before ``as_of``."""
    if context not in CONTEXT_INDEX:
        raise ValueError(f"unknown context {context!r}")
    if histories.catalogue.fingerprint != catalogue.fingerprint:
        raise ValueError("histories were built against a different catalogue; call histories.rebind(catalogue) first")
    prefs = preferences.get(user_id)
    personalised = bool(prefs.personalisation_enabled)
    all_items = histories.items_as_of(user_id, as_of)
    if prefs.history_reset_at is not None and len(all_items):
        keep = all_items.t_item >= float(prefs.history_reset_at)       # defensive: cleaning already removed these
        all_items = UserItems(*(getattr(all_items, f)[keep] for f in ("video_idx", "row", "t_item", "type",
                                                                      "strength", "context_idx")))
    # hard controls use the complete history even when personalisation is disabled
    consumed = np.unique(all_items.video_idx[np.isin(all_items.type, H_STRONG_POSITIVE)])
    negative = np.unique(all_items.video_idx[all_items.type == H_NEGATIVE_FEEDBACK])
    blocked = np.union1d(histories.blocks_as_of(user_id, as_of), _known(catalogue.creator_idx(prefs.blocked_creators)))
    items = all_items if personalised else UserItems.empty()
    first_seen = histories.first_seen(user_id)
    state = RequestState(
        user_id=str(user_id), context=context, context_idx=CONTEXT_INDEX[context], t=float(as_of), prefs=prefs,
        personalised=personalised, items=items, stats=histories.stats.snapshot(as_of),
        preferred_language_idx=catalogue.language_idx(prefs.preferred_languages),
        selected_topic_cat_idx=catalogue.topic_idx(prefs.selected_topics) if personalised else np.array([], dtype="int64"),
        followed_creator_idx=_known(catalogue.creator_idx(prefs.followed_creators)) if personalised else np.array([], dtype="int64"),
        blocked_creator_idx=blocked.astype("int64"),
        excluded_video_idx=_known(catalogue.video_idx(prefs.excluded_videos)),
        consumed_video_idx=consumed, negative_video_idx=negative,
        is_new_user=bool(len(all_items) == 0 or (as_of - first_seen) < config.features.new_user_days * DAY),
        history_len=len(all_items),
    )
    if space is not None:
        state.tower_inputs = tower_inputs(items, prefs, state.t, state.context_idx, space, config, personalised)
    return state


def _known(idx: np.ndarray) -> np.ndarray:
    return idx[idx >= 0]


def history_weights(items: UserItems, t: float, half_life_days: float) -> tuple[np.ndarray, np.ndarray]:
    """Time-decayed weights of history items for hand-built profiles: (positive, negative).

    Meaningful views count with ``0.5 + 0.5 * strength`` and explicit positive feedback with 2;
    early skips count 0.5 and explicit negative feedback 2 on the negative side. Partial
    views are neutral - they are neither evidence of interest nor of dislike.
    """
    if len(items) == 0:
        z = np.array([], dtype="float64")
        return z, z
    decay = np.exp(-np.log(2.0) * np.maximum(t - items.t_item, 0.0) / (half_life_days * DAY))
    pos = np.where(items.type == H_MEANINGFUL, 0.5 + 0.5 * items.strength, 0.0) + 2.0 * (items.type == H_POSITIVE_FEEDBACK)
    neg = 0.5 * (items.type == H_EARLY_SKIP) + 2.0 * (items.type == H_NEGATIVE_FEEDBACK)
    return decay * pos, decay * neg
