"""Input data contracts: typed records plus DataFrame validators.

Three tables are accepted (as pandas DataFrames or Parquet files):

* ``videos``        one row per (video_id, metadata_version)
* ``interactions``  one row per logged event
* ``preferences``   one row per user

Optional values are *explicitly* nullable (``None`` / ``NaN`` / ``NaT``). Validators coerce
types, null out invalid optional values, and drop (or, in strict mode, reject) rows that
violate a required constraint. Every decision is counted in a :class:`ValidationReport`.

Propensities: ``selection_propensity`` is kept only when the row names a
``logging_policy_id`` *and* the value is a probability in (0, 1]. Anything else becomes
missing. The pipeline never fabricates a propensity.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Iterable, Optional, Sequence

import numpy as np
import pandas as pd

from ..constants import CONTEXTS, EV_IMPRESSION, EV_PROGRESS, EV_SURVEY, EVENT_TYPES
from .timeutil import to_epoch_seconds, to_utc


class SchemaError(ValueError):
    """Raised when a table cannot be coerced into its contract."""


# --------------------------------------------------------------------------- records
@dataclass(frozen=True)
class VideoRecord:
    video_id: str
    creator_id: str
    title: str
    description: Optional[str]
    language: Optional[str]
    topic_ids: tuple[str, ...]
    duration_seconds: float
    published_at: datetime
    available_from: Optional[datetime]          # missing => published_at
    available_until: Optional[datetime]         # missing => no expiry
    content_embedding: Optional[tuple[float, ...]]
    duplicate_group_id: Optional[str]
    eligibility_labels: tuple[str, ...]
    metadata_version: int
    metadata_valid_from: Optional[datetime] = None   # extension: when this metadata version became visible


@dataclass(frozen=True)
class InteractionRecord:
    event_id: str
    user_id: str
    session_id: Optional[str]
    video_id: str
    event_type: str
    occurred_at: datetime
    received_at: datetime
    request_id: Optional[str]
    position: Optional[int]
    playback_id: Optional[str]
    playback_context: Optional[str]
    watched_interval_start: Optional[float]
    watched_interval_end: Optional[float]
    foreground: Optional[bool]
    explicit_feedback: Optional[float]          # satisfaction rating, survey responses only
    logging_policy_id: Optional[str]
    selection_propensity: Optional[float]       # only when supplied by the logging policy


@dataclass(frozen=True)
class UserPreferences:
    user_id: str
    selected_topics: tuple[str, ...] = ()
    preferred_languages: tuple[str, ...] = ()
    followed_creators: tuple[str, ...] = ()
    blocked_creators: tuple[str, ...] = ()
    excluded_videos: tuple[str, ...] = ()
    personalisation_enabled: bool = True
    history_reset_at: Optional[datetime] = None


VIDEO_COLUMNS = (
    "video_id", "creator_id", "title", "description", "language", "topic_ids", "duration_seconds",
    "published_at", "available_from", "available_until", "content_embedding", "duplicate_group_id",
    "eligibility_labels", "metadata_version",
)
VIDEO_OPTIONAL_COLUMNS = ("metadata_valid_from",)
INTERACTION_COLUMNS = (
    "event_id", "user_id", "session_id", "video_id", "event_type", "occurred_at", "received_at",
    "request_id", "position", "playback_id", "playback_context", "watched_interval_start",
    "watched_interval_end", "foreground", "explicit_feedback", "logging_policy_id", "selection_propensity",
)
PREFERENCE_COLUMNS = (
    "user_id", "selected_topics", "preferred_languages", "followed_creators", "blocked_creators",
    "excluded_videos", "personalisation_enabled", "history_reset_at",
)


@dataclass
class ValidationReport:
    table: str
    rows_in: int = 0
    rows_out: int = 0
    dropped: dict[str, int] = field(default_factory=dict)
    nullified: dict[str, int] = field(default_factory=dict)

    def drop(self, reason: str, n: int) -> None:
        if n:
            self.dropped[reason] = self.dropped.get(reason, 0) + int(n)

    def null(self, reason: str, n: int) -> None:
        if n:
            self.nullified[reason] = self.nullified.get(reason, 0) + int(n)

    def to_dict(self) -> dict[str, Any]:
        return {"table": self.table, "rows_in": self.rows_in, "rows_out": self.rows_out,
                "dropped": dict(self.dropped), "nullified": dict(self.nullified)}


# --------------------------------------------------------------------------- helpers
def _require_columns(df: pd.DataFrame, columns: Iterable[str], table: str) -> None:
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise SchemaError(f"{table}: missing required columns {missing}")


def _is_missing(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, (float, np.floating)):
        return bool(np.isnan(value))
    return value is pd.NA or value is pd.NaT


def as_str_tuple(value: Any) -> tuple[str, ...]:
    """Normalise a list-like cell (list / tuple / ndarray / missing) to a tuple of strings."""
    if _is_missing(value):
        return ()
    if isinstance(value, str):
        return (value,)
    return tuple(str(v) for v in value if not _is_missing(v))


def _str_column(series: pd.Series) -> pd.Series:
    """Object column of ``str`` or ``None`` (uniform across pandas 2.x and 3.x string dtypes)."""
    vals = series.to_numpy(dtype=object)
    out = np.empty(len(vals), dtype=object)
    for i, v in enumerate(vals):
        out[i] = None if _is_missing(v) else str(v)
    return pd.Series(out, index=series.index, dtype=object)


def _tuple_column(series: pd.Series) -> pd.Series:
    vals = series.to_numpy(dtype=object)
    out = np.empty(len(vals), dtype=object)
    for i, v in enumerate(vals):
        out[i] = as_str_tuple(v)
    return pd.Series(out, index=series.index, dtype=object)


def _float_column(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").astype("float64")


def _apply_drop(df: pd.DataFrame, bad: np.ndarray, reason: str, report: ValidationReport, strict: bool) -> pd.DataFrame:
    n = int(bad.sum())
    if n == 0:
        return df
    if strict:
        raise SchemaError(f"{report.table}: {n} rows violate '{reason}'")
    report.drop(reason, n)
    return df.loc[~bad]


# --------------------------------------------------------------------------- videos
def validate_videos(videos: pd.DataFrame, strict: bool = False) -> tuple[pd.DataFrame, ValidationReport]:
    """Validate the video table. Returns a clean copy sorted by (video_id, metadata_version)."""
    _require_columns(videos, VIDEO_COLUMNS, "videos")
    report = ValidationReport("videos", rows_in=len(videos))
    df = videos.copy()
    for col in ("video_id", "creator_id", "title", "description", "language", "duplicate_group_id"):
        df[col] = _str_column(df[col])
    for col in ("topic_ids", "eligibility_labels"):
        df[col] = _tuple_column(df[col])
    df["duration_seconds"] = _float_column(df["duration_seconds"])
    for col in ("published_at", "available_from", "available_until"):
        df[col] = to_utc(df[col]).to_numpy()
    if "metadata_valid_from" in df.columns:
        df["metadata_valid_from"] = to_utc(df["metadata_valid_from"]).to_numpy()
    else:
        df["metadata_valid_from"] = pd.Series(pd.NaT, index=df.index, dtype=df["published_at"].dtype)
    df["metadata_version"] = pd.to_numeric(df["metadata_version"], errors="coerce")

    bad = df["video_id"].isna().to_numpy() | df["creator_id"].isna().to_numpy()
    df = _apply_drop(df, bad, "missing_video_or_creator_id", report, strict)
    df = _apply_drop(df, df["title"].isna().to_numpy(), "missing_title", report, strict)
    dur = df["duration_seconds"].to_numpy()
    df = _apply_drop(df, ~(np.isfinite(dur) & (dur > 0)), "non_positive_duration", report, strict)
    df = _apply_drop(df, df["published_at"].isna().to_numpy(), "missing_published_at", report, strict)
    df = _apply_drop(df, df["metadata_version"].isna().to_numpy(), "missing_metadata_version", report, strict)
    df["metadata_version"] = df["metadata_version"].astype("int64")

    pub = to_epoch_seconds(df["published_at"])
    a_from = to_epoch_seconds(df["available_from"])
    a_until = to_epoch_seconds(df["available_until"])
    a_from = np.where(np.isnan(a_from), pub, a_from)
    bad = ~np.isnan(a_until) & (a_until <= a_from)
    df = _apply_drop(df, bad, "available_until_not_after_available_from", report, strict)

    df = df.sort_values(["video_id", "metadata_version"], kind="mergesort")
    dup = df.duplicated(["video_id", "metadata_version"], keep="first").to_numpy()
    df = _apply_drop(df, dup, "duplicate_video_version", report, strict)

    # content embeddings: optional per row, but a single dimensionality across the table
    emb = df["content_embedding"].to_numpy(dtype=object)
    dims = {len(e) for e in emb if not _is_missing(e)}
    if len(dims) > 1:
        raise SchemaError(f"videos: content_embedding has inconsistent dimensions {sorted(dims)}")
    cleaned = np.empty(len(emb), dtype=object)
    n_bad = 0
    for i, e in enumerate(emb):
        if _is_missing(e):
            cleaned[i] = None
            continue
        arr = np.asarray(e, dtype="float32")
        if not np.all(np.isfinite(arr)):
            cleaned[i] = None
            n_bad += 1
        else:
            cleaned[i] = arr
    report.null("non_finite_content_embedding", n_bad)
    df["content_embedding"] = pd.Series(cleaned, index=df.index, dtype=object)

    # a video with several metadata versions needs to say when each became visible
    multi = df.groupby("video_id")["metadata_version"].transform("size").to_numpy() > 1
    later = multi & (df.groupby("video_id").cumcount().to_numpy() > 0)
    if np.any(later & df["metadata_valid_from"].isna().to_numpy()):
        raise SchemaError("videos: later metadata versions require metadata_valid_from (point-in-time correctness)")

    df = df.reset_index(drop=True)
    report.rows_out = len(df)
    return df, report


# --------------------------------------------------------------------------- interactions
def validate_interactions(events: pd.DataFrame, strict: bool = False) -> tuple[pd.DataFrame, ValidationReport]:
    """Validate the interaction log (types, enumerations, optional fields, propensities)."""
    _require_columns(events, INTERACTION_COLUMNS, "interactions")
    report = ValidationReport("interactions", rows_in=len(events))
    df = events[list(INTERACTION_COLUMNS)].copy()
    for col in ("event_id", "user_id", "session_id", "video_id", "event_type", "request_id", "playback_id",
                "playback_context", "logging_policy_id"):
        df[col] = _str_column(df[col])
    for col in ("occurred_at", "received_at"):
        df[col] = to_utc(df[col]).to_numpy()
    for col in ("position", "watched_interval_start", "watched_interval_end", "explicit_feedback",
                "selection_propensity"):
        df[col] = _float_column(df[col])
    fg = df["foreground"].to_numpy(dtype=object)
    fg_out = np.full(len(fg), np.nan)
    for i, v in enumerate(fg):
        if not _is_missing(v):
            fg_out[i] = 1.0 if bool(v) else 0.0
    df["foreground"] = fg_out          # 1.0 / 0.0 / NaN (unknown)

    required = ["event_id", "user_id", "video_id", "event_type", "occurred_at", "received_at"]
    bad = df[required].isna().any(axis=1).to_numpy()
    df = _apply_drop(df, bad, "missing_required_field", report, strict)
    bad = ~df["event_type"].isin(EVENT_TYPES).to_numpy()
    df = _apply_drop(df, bad, "unknown_event_type", report, strict)

    ctx = df["playback_context"]
    bad_ctx = ctx.notna().to_numpy() & ~ctx.isin(CONTEXTS).to_numpy()
    report.null("unknown_playback_context", int(bad_ctx.sum()))
    df.loc[bad_ctx, "playback_context"] = None

    pos = df["position"].to_numpy()
    bad_pos = ~np.isnan(pos) & (pos < 0)
    report.null("negative_position", int(bad_pos.sum()))
    df.loc[bad_pos, "position"] = np.nan

    # impressions must be tied to a request so that outcomes can be associated with them
    is_imp = (df["event_type"] == EV_IMPRESSION).to_numpy()
    df = _apply_drop(df, is_imp & df["request_id"].isna().to_numpy(), "impression_without_request_id", report, strict)

    # propensities: only valid probabilities supplied together with a logging policy id
    is_imp = (df["event_type"] == EV_IMPRESSION).to_numpy()
    p = df["selection_propensity"].to_numpy()
    has_p = ~np.isnan(p)
    invalid = has_p & (~(p > 0) | (p > 1) | df["logging_policy_id"].isna().to_numpy() | ~is_imp)
    report.null("invalid_selection_propensity", int(invalid.sum()))
    df.loc[invalid, "selection_propensity"] = np.nan

    # explicit satisfaction is only meaningful on survey responses
    is_survey = (df["event_type"] == EV_SURVEY).to_numpy()
    fb = df["explicit_feedback"].to_numpy()
    stray = ~np.isnan(fb) & ~is_survey
    report.null("explicit_feedback_on_non_survey_event", int(stray.sum()))
    df.loc[stray, "explicit_feedback"] = np.nan
    df = _apply_drop(df, is_survey & np.isnan(df["explicit_feedback"].to_numpy()), "survey_without_rating", report, strict)

    # progress events need a playback id; interval values are validated in clean_events
    is_prog = (df["event_type"] == EV_PROGRESS).to_numpy()
    df = _apply_drop(df, is_prog & df["playback_id"].isna().to_numpy(), "progress_without_playback_id", report, strict)

    df = df.reset_index(drop=True)
    report.rows_out = len(df)
    return df, report


# --------------------------------------------------------------------------- preferences
def validate_preferences(preferences: pd.DataFrame, strict: bool = False) -> tuple[pd.DataFrame, ValidationReport]:
    _require_columns(preferences, PREFERENCE_COLUMNS, "preferences")
    report = ValidationReport("preferences", rows_in=len(preferences))
    df = preferences[list(PREFERENCE_COLUMNS)].copy()
    df["user_id"] = _str_column(df["user_id"])
    for col in ("selected_topics", "preferred_languages", "followed_creators", "blocked_creators", "excluded_videos"):
        df[col] = _tuple_column(df[col])
    flag = df["personalisation_enabled"].to_numpy(dtype=object)
    # a missing flag is treated as "enabled" only because that is the documented product default
    df["personalisation_enabled"] = np.array([True if _is_missing(v) else bool(v) for v in flag], dtype=bool)
    df["history_reset_at"] = to_utc(df["history_reset_at"]).to_numpy()
    df = _apply_drop(df, df["user_id"].isna().to_numpy(), "missing_user_id", report, strict)
    df = _apply_drop(df, df.duplicated("user_id", keep="first").to_numpy(), "duplicate_user_id", report, strict)
    df = df.sort_values("user_id", kind="mergesort").reset_index(drop=True)
    report.rows_out = len(df)
    return df, report


def records_to_frame(records: Sequence[Any]) -> pd.DataFrame:
    """Convert a sequence of record dataclasses into a DataFrame (object columns for lists)."""
    from dataclasses import asdict
    return pd.DataFrame([asdict(r) for r in records])
