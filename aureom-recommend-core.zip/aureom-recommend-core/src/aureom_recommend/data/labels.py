"""Label construction: impressions, outcome attribution, observation states, task masks.

``build_examples`` turns cleaned events into

* ``impressions`` - one row per (user, request, video) impression with raw viewing
  targets, an observation state and, per ranking task, a label ``y_*`` and a mask ``m_*``
  (1 = label observed and usable);
* ``versions`` - point-in-time history items (see below);
* ``blocks`` - creator blocks with the time they became observable.

Outcome window
--------------
An outcome belongs to an impression when it carries the same ``(user, request, video)``
key, or - for outcome events without a request id - when it is the latest earlier
impression of that video to that user within the window (fallback attribution).
With ``W = outcome_window_seconds`` and ``G = late_arrival_grace_seconds`` the label of an
impression at time ``t`` uses exactly the events with ``occurred_at <= t + W`` and
``received_at <= t + W + G``. The impression is **matured** when ``t + W + G <= cutoff``.
Labels are therefore frozen at maturity: they do not change if the cutoff moves later, and
an unmatured impression has every mask set to 0 (state ``incomplete``).

States (``state`` column)
-------------------------
``never shown`` is the absence of a row. Rows are one of: ``incomplete`` (not matured, or a
play with no usable observation - e.g. a play_start with neither progress nor play_end),
``impression_no_play``, ``early_skip``, ``partial_view``, ``positive`` (meaningful view or
like/save/share) and ``explicit_negative`` (dislike / not interested / creator block).

Masks
-----
* meaningful, duration: matured and the viewing outcome is observed (no-play counts as 0)
* like_or_save, negative: matured
* satisfaction: matured **and a survey response exists** - a missing response is missing,
  never dissatisfaction.

History versions
----------------
History items are keyed by *playback* (or, for feedback without a playback, by
user/video/request) - never by impression attribution - so that an item is defined by its
own events alone. A *version* row is emitted each time a newly received event changes what
is known about an item, and is visible from its ``t_available`` (the ``received_at`` of
that event). "History as of t" is therefore a function of events received before ``t``
only: rebuilding from a log truncated at ``t`` gives the same answer (tested). Views become
history items once they are meaningful, or once playback ended (early skip / partial view);
explicit feedback is visible as soon as it is received.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from ..config import Config
from ..constants import (CONTEXT_INDEX, CONTEXTS, EV_BLOCK_CREATOR, EV_IMPRESSION, EV_PLAY_END, EV_PLAY_START,
                         EV_PROGRESS, EV_SURVEY, H_EARLY_SKIP, H_MEANINGFUL, H_NEGATIVE_FEEDBACK, H_PARTIAL,
                         H_POSITIVE_FEEDBACK, NEGATIVE_FEEDBACK_EVENTS, POSITIVE_FEEDBACK_EVENTS, STATE_EARLY_SKIP,
                         STATE_INCOMPLETE, STATE_NEGATIVE, STATE_NO_PLAY, STATE_PARTIAL, STATE_POSITIVE, TASKS)
from .catalogue import Catalogue
from .intervals import IntervalSet, grouped_union_length
from .timeutil import as_epoch


@dataclass
class ExampleSet:
    impressions: pd.DataFrame
    versions: pd.DataFrame
    blocks: pd.DataFrame
    cutoff: float
    report: dict[str, Any] = field(default_factory=dict)


def _thresholds(config: Config, context_idx: np.ndarray, duration: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Per-row meaningful-view and early-skip thresholds in seconds."""
    lc = config.labels
    mv_s = np.array([lc.meaningful_view[c]["min_seconds"] for c in CONTEXTS])[context_idx]
    mv_f = np.array([lc.meaningful_view[c]["min_fraction"] for c in CONTEXTS])[context_idx]
    es_s = np.array([lc.early_skip[c]["max_seconds"] for c in CONTEXTS])[context_idx]
    es_f = np.array([lc.early_skip[c]["max_fraction"] for c in CONTEXTS])[context_idx]
    return np.minimum(mv_s, mv_f * duration), np.minimum(es_s, es_f * duration)


def build_examples(events: pd.DataFrame, catalogue: Catalogue, cutoff: Any, config: Config) -> ExampleSet:
    """Construct point-in-time examples from cleaned ``events`` as known at ``cutoff``."""
    lc = config.labels
    W, G = lc.outcome_window_seconds, lc.late_arrival_grace_seconds
    skew = config.events.clock_skew_tolerance_seconds
    cutoff = as_epoch(cutoff)
    report: dict[str, Any] = {"cutoff": cutoff, "label_version": lc.version}

    ev = events.loc[events["t_received"].to_numpy() <= cutoff]
    vidx_all = catalogue.video_idx(ev["video_id"].to_numpy(dtype=object))
    report["events_for_unknown_videos"] = int((vidx_all < 0).sum())
    ev = ev.loc[vidx_all >= 0].assign(video_idx=vidx_all[vidx_all >= 0])

    # ------------------------------------------------------------------ impressions
    is_imp = (ev["event_type"] == EV_IMPRESSION).to_numpy()
    imps = ev.loc[is_imp].sort_values(["t_occurred", "t_received", "event_id"], kind="mergesort")
    imps = imps.drop_duplicates(["user_id", "request_id", "video_id"], keep="first").reset_index(drop=True)
    n_imp = len(imps)
    imp_t = imps["t_occurred"].to_numpy()
    imp_row = catalogue.rows_at(imps["video_idx"].to_numpy(), imp_t)
    imp_ctx_logged = imps["playback_context"].to_numpy(dtype=object)
    imp_ctx = np.array([CONTEXT_INDEX[c] if c in CONTEXT_INDEX else -1 for c in imp_ctx_logged], dtype="int64")
    imp_ctx = np.where(imp_ctx < 0, catalogue.context_index[imp_row], imp_ctx)
    imp_dur = catalogue.duration[imp_row]
    imps = imps.assign(imp_idx=np.arange(n_imp))

    # ------------------------------------------------------------------ attribute outcomes
    out = ev.loc[~is_imp].copy()
    key = imps[["user_id", "request_id", "video_id", "imp_idx"]]
    out = out.merge(key, how="left", on=["user_id", "request_id", "video_id"])
    exact = out["imp_idx"].notna().to_numpy()
    report["outcomes_exact_attribution"] = int(exact.sum())
    if lc.attribution_fallback and (~exact).any() and n_imp:
        rest = out.loc[~exact].drop(columns="imp_idx").sort_values("t_occurred", kind="mergesort")
        right = imps[["user_id", "video_id", "t_occurred", "imp_idx"]].sort_values("t_occurred", kind="mergesort")
        fb = pd.merge_asof(rest, right, on="t_occurred", by=["user_id", "video_id"], direction="backward", tolerance=W)
        out = pd.concat([out.loc[exact], fb], ignore_index=True)
    out_imp = out["imp_idx"].to_numpy(dtype="float64")
    attributed = ~np.isnan(out_imp)
    report["outcomes_fallback_attribution"] = int(attributed.sum() - exact.sum())
    report["outcomes_unattributed"] = int((~attributed).sum())
    imp_of = np.where(attributed, out_imp, -1).astype("int64")
    o_t = out["t_occurred"].to_numpy()
    o_r = out["t_received"].to_numpy()
    # events before their impression (beyond clock skew) cannot be its outcome
    dt = o_t - np.where(attributed, imp_t[np.maximum(imp_of, 0)], 0.0)
    bad_order = attributed & (dt < -skew)
    imp_of[bad_order] = -1
    attributed = imp_of >= 0

    # outcome groups: the impression when attributed, otherwise the playback (or the lone event)
    etype = out["event_type"].to_numpy(dtype=object)
    pb = out["playback_id"].to_numpy(dtype=object)
    eid = out["event_id"].to_numpy(dtype=object)
    loose_key = np.array([f"p:{p}" if p is not None else f"e:{e}" for p, e in zip(pb, eid)], dtype=object)
    loose_codes, loose_uniques = pd.factorize(loose_key[~attributed], sort=True)
    grp = imp_of.copy()
    grp[~attributed] = n_imp + loose_codes
    n_grp = n_imp + len(loose_uniques)

    # group metadata (impression values, or the first event of an unattributed playback)
    o_vidx = out["video_idx"].to_numpy()
    o_user = out["user_id"].to_numpy(dtype=object)
    g_t = np.full(n_grp, np.inf)
    g_t[:n_imp] = imp_t
    np.minimum.at(g_t, grp[~attributed], o_t[~attributed])
    g_vidx = np.full(n_grp, -1, dtype="int64")
    g_vidx[:n_imp] = imps["video_idx"].to_numpy()
    g_vidx[grp[~attributed]] = o_vidx[~attributed]
    g_user = np.empty(n_grp, dtype=object)
    g_user[:n_imp] = imps["user_id"].to_numpy(dtype=object)
    g_user[grp[~attributed]] = o_user[~attributed]
    g_row = catalogue.rows_at(g_vidx, g_t)
    g_dur = catalogue.duration[g_row]
    g_ctx = catalogue.context_index[g_row].copy()
    g_ctx[:n_imp] = imp_ctx
    mv_thr, es_thr = _thresholds(config, g_ctx, g_dur)

    # label window (only meaningful for attributed outcomes)
    in_window = attributed & (o_t <= g_t[grp] + W) & (o_r <= g_t[grp] + W + G)
    report["outcomes_outside_label_window"] = int((attributed & ~in_window).sum())

    # ------------------------------------------------------------------ viewing aggregates
    is_prog = etype == EV_PROGRESS
    s = np.maximum(out["watched_interval_start"].to_numpy(dtype="float64"), 0.0)
    e = np.minimum(out["watched_interval_end"].to_numpy(dtype="float64"), g_dur[grp])
    fg_raw = out["foreground"].to_numpy(dtype="float64")
    if config.events.unknown_foreground_policy == "foreground":
        fg = is_prog & (np.isnan(fg_raw) | (fg_raw == 1.0))
    else:
        fg = is_prog & (fg_raw == 1.0)
    bg = is_prog & (fg_raw == 0.0)
    unknown_fg = is_prog & np.isnan(fg_raw)
    valid_seg = is_prog & (e > s)
    wall_s, wall_e = o_t - (e - s), o_t

    def agg(mask: np.ndarray, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        return grouped_union_length(grp[mask], a[mask], b[mask], n_grp)[:n_imp]

    lab = in_window & valid_seg
    unique = agg(lab & fg, s, e)
    total = np.maximum(agg(lab & fg, wall_s, wall_e), unique)       # wall-clock union can never be below coverage
    background = agg(lab & bg, wall_s, wall_e)
    unknown_seconds = agg(lab & unknown_fg, wall_s, wall_e)

    def any_in(mask: np.ndarray) -> np.ndarray:
        flag = np.zeros(n_imp, dtype=bool)
        flag[grp[in_window & mask]] = True
        return flag

    has_start = any_in(etype == EV_PLAY_START)
    has_end = any_in(etype == EV_PLAY_END)
    has_progress = any_in(valid_seg)
    has_play = has_start | has_end | has_progress
    pos_fb = any_in(np.isin(etype, POSITIVE_FEEDBACK_EVENTS))
    neg_fb = any_in(np.isin(etype, NEGATIVE_FEEDBACK_EVENTS))
    is_survey = etype == EV_SURVEY
    rating = np.full(n_imp, np.nan)
    sv = np.flatnonzero(in_window & is_survey)
    sv = sv[np.lexsort((o_r[sv], o_t[sv]))]                          # the latest response wins
    rating[grp[sv]] = out["explicit_feedback"].to_numpy(dtype="float64")[sv]
    observed_at = imps["t_received"].to_numpy().copy()
    np.maximum.at(observed_at, grp[in_window], o_r[in_window])

    # ------------------------------------------------------------------ states, labels, masks
    maturity = imp_t + W + G
    matured = maturity <= cutoff
    view_observed = ~has_play | has_progress | has_end
    mv = mv_thr[:n_imp]
    meaningful = has_play & (unique >= mv)
    early_skip = has_play & view_observed & (unique < es_thr[:n_imp])
    completion = np.clip(unique / imp_dur, 0.0, 1.0)

    state = np.full(n_imp, STATE_PARTIAL, dtype=object)
    state[~has_play] = STATE_NO_PLAY
    state[early_skip] = STATE_EARLY_SKIP
    state[has_play & ~view_observed] = STATE_INCOMPLETE
    state[meaningful | pos_fb] = STATE_POSITIVE
    state[neg_fb] = STATE_NEGATIVE
    state[~matured] = STATE_INCOMPLETE

    sat = (rating - lc.satisfaction_min) / (lc.satisfaction_max - lc.satisfaction_min)
    view_mask = matured & view_observed
    frame = pd.DataFrame({
        "imp_idx": np.arange(n_imp), "request_id": imps["request_id"].to_numpy(dtype=object),
        "user_id": imps["user_id"].to_numpy(dtype=object), "video_id": imps["video_id"].to_numpy(dtype=object),
        "session_id": imps["session_id"].to_numpy(dtype=object),
        "video_idx": imps["video_idx"].to_numpy(), "row": imp_row, "t": imp_t, "t_received": imps["t_received"].to_numpy(),
        "context_idx": imp_ctx, "position": imps["position"].to_numpy(dtype="float64"),
        "logging_policy_id": imps["logging_policy_id"].to_numpy(dtype=object),
        "selection_propensity": imps["selection_propensity"].to_numpy(dtype="float64"),
        "duration_seconds": imp_dur, "maturity_time": maturity, "matured": matured, "outcome_observed_at": observed_at,
        "state": state, "has_play": has_play, "view_observed": view_observed,
        "unique_watched_seconds": unique, "total_valid_playback_seconds": total,
        "background_seconds": background, "unknown_foreground_seconds": unknown_seconds,
        "completion_ratio": completion, "rewatch_seconds": np.maximum(0.0, total - unique),
        "early_skip": early_skip, "meaningful_view": meaningful, "liked_or_saved": pos_fb, "negative_feedback": neg_fb,
        "satisfaction_rating": rating,
        "y_meaningful": meaningful.astype("float32"), "m_meaningful": view_mask.astype("float32"),
        # y_duration is filled by DurationBaseline.transform (fitted on training data only)
        "y_duration": np.zeros(n_imp, dtype="float32"), "m_duration": view_mask.astype("float32"),
        "y_like_or_save": pos_fb.astype("float32"), "m_like_or_save": matured.astype("float32"),
        "y_satisfaction": np.nan_to_num(sat, nan=0.0).astype("float32"),
        "m_satisfaction": (matured & ~np.isnan(rating)).astype("float32"),
        "y_negative": neg_fb.astype("float32"), "m_negative": matured.astype("float32"),
    })
    # positives for retrieval / relevance: a matured positive state
    frame["is_positive"] = (frame["state"] == STATE_POSITIVE).to_numpy()

    # ------------------------------------------------------------------ history versions
    # keyed by playback (intrinsic to the events), independent of impression attribution
    req = out["request_id"].to_numpy(dtype=object)
    o_vid = out["video_id"].to_numpy(dtype=object)
    h_key = np.array([f"p:{p}" if p is not None else f"f:{u}|{v}|{r if r is not None else i}"
                      for p, u, v, r, i in zip(pb, o_user, o_vid, req, eid)], dtype=object)
    h_group = pd.factorize(h_key, sort=True)[0]
    ev_row = catalogue.rows_at(o_vidx, o_t)
    ev_dur = catalogue.duration[ev_row]
    ev_ctx_logged = out["playback_context"].to_numpy(dtype=object)
    ev_ctx = np.array([CONTEXT_INDEX.get(c, -1) for c in ev_ctx_logged], dtype="int64")
    ev_ctx = np.where(ev_ctx < 0, catalogue.context_index[ev_row], ev_ctx)
    ev_mv, ev_es = _thresholds(config, ev_ctx, ev_dur)
    h_end = np.minimum(out["watched_interval_end"].to_numpy(dtype="float64"), ev_dur)
    versions = _history_versions(
        group=h_group, t_received=o_r, t_occurred=o_t, etype=etype, seg_start=s, seg_end=h_end,
        fg=fg & (h_end > s), user=o_user, vidx=o_vidx, ctx=ev_ctx, dur=ev_dur, mv_thr=ev_mv, es_thr=ev_es)
    versions["row"] = catalogue.rows_at(versions["video_idx"].to_numpy(), versions["t_item"].to_numpy())

    # ------------------------------------------------------------------ blocks
    is_block = etype == EV_BLOCK_CREATOR
    blocks = pd.DataFrame({
        "user_id": o_user[is_block], "creator_idx": catalogue.creator_index[g_row[grp[is_block]]],
        "t_available": o_r[is_block],
    }).sort_values(["user_id", "t_available"], kind="mergesort").reset_index(drop=True)

    report.update({
        "n_impressions": n_imp, "n_matured": int(matured.sum()),
        "state_counts": {k: int(v) for k, v in pd.Series(state).value_counts().items()},
        "mask_counts": {t: int(frame[f"m_{t}"].sum()) for t in TASKS},
        "n_history_versions": len(versions), "n_unattributed_groups": int(n_grp - n_imp),
        "n_history_items": int(versions["group"].nunique()),
    })
    return ExampleSet(impressions=frame, versions=versions, blocks=blocks, cutoff=cutoff, report=report)


def _history_versions(*, group: np.ndarray, t_received: np.ndarray, t_occurred: np.ndarray, etype: np.ndarray,
                      seg_start: np.ndarray, seg_end: np.ndarray, fg: np.ndarray, user: np.ndarray, vidx: np.ndarray,
                      ctx: np.ndarray, dur: np.ndarray, mv_thr: np.ndarray, es_thr: np.ndarray) -> pd.DataFrame:
    """Walk each item's events in arrival order and emit a row whenever the known state changes.

    Every quantity of a version (type, strength, item time) is computed from the events of the
    same item that were received up to and including the event that produced it.
    """
    kind = np.zeros(len(group), dtype="int8")           # 1 progress(fg) 2 play_end 3 positive fb 4 negative fb 5 play_start
    kind[etype == EV_PLAY_START] = 5
    kind[fg] = 1
    kind[etype == EV_PLAY_END] = 2
    kind[np.isin(etype, POSITIVE_FEEDBACK_EVENTS)] = 3
    kind[np.isin(etype, NEGATIVE_FEEDBACK_EVENTS)] = 4
    sel = np.flatnonzero(kind > 0)
    sel = sel[np.lexsort((kind[sel], t_occurred[sel], t_received[sel], group[sel]))]
    g_l, r_l, o_l, k_l = group[sel].tolist(), t_received[sel].tolist(), t_occurred[sel].tolist(), kind[sel].tolist()
    s_l, e_l = seg_start[sel].tolist(), seg_end[sel].tolist()
    mv_l, es_l, dur_l = mv_thr[sel].tolist(), es_thr[sel].tolist(), dur[sel].tolist()

    out_i: list[int] = []
    out_t: list[float] = []
    out_item: list[float] = []
    out_type: list[int] = []
    out_strength: list[float] = []
    cur = -1
    cover = IntervalSet()
    ended = pos = neg = False
    t_item = np.inf
    last: tuple[int, float, float] | None = None
    for i, (g, r, o, k, s, e) in enumerate(zip(g_l, r_l, o_l, k_l, s_l, e_l)):
        if g != cur:
            cur, cover, ended, pos, neg, last, t_item = g, IntervalSet(), False, False, False, None, np.inf
        t_item = min(t_item, o)
        if k == 1:
            cover.add(s, e)
        elif k == 2:
            ended = True
        elif k == 3:
            pos = True
        elif k == 4:
            neg = True
        u = cover.total
        if neg:
            typ = H_NEGATIVE_FEEDBACK
        elif pos:
            typ = H_POSITIVE_FEEDBACK
        elif u >= mv_l[i]:
            typ = H_MEANINGFUL
        elif ended:
            typ = H_EARLY_SKIP if u < es_l[i] else H_PARTIAL
        else:
            continue                                    # playback in progress, nothing conclusive yet
        state = (typ, round(min(1.0, u / dur_l[i]), 2), t_item)
        if last != state:
            last = state
            out_i.append(i)
            out_t.append(r)
            out_item.append(t_item)
            out_type.append(typ)
            out_strength.append(state[1])
    idx = sel[np.asarray(out_i, dtype="int64")] if out_i else np.array([], dtype="int64")
    frame = pd.DataFrame({
        "group": group[idx], "user_id": user[idx], "video_idx": vidx[idx],
        "t_item": np.asarray(out_item, dtype="float64"), "t_available": np.asarray(out_t, dtype="float64"),
        "type": np.asarray(out_type, dtype="int8"), "strength": np.asarray(out_strength, dtype="float32"),
        "context_idx": ctx[idx],
    })
    return frame.sort_values(["user_id", "t_available", "group"], kind="mergesort").reset_index(drop=True)
