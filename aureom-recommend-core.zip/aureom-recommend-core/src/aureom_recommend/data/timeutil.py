"""Time helpers. All timestamps are UTC; internally they are float seconds since the epoch."""
from __future__ import annotations

from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd


def to_utc(series: Any) -> pd.Series:
    """Coerce to tz-aware UTC timestamps (naive inputs are interpreted as UTC)."""
    out = pd.to_datetime(pd.Series(series), utc=True, errors="coerce")
    return out


def to_epoch_seconds(series: Any) -> np.ndarray:
    """Float64 epoch seconds with NaN for missing timestamps (resolution independent)."""
    s = to_utc(series)
    vals = s.dt.tz_localize(None).to_numpy().astype("datetime64[us]")
    out = vals.astype("int64").astype("float64") / 1e6
    out[np.isnat(vals)] = np.nan
    return out


def from_epoch_seconds(seconds: Any) -> pd.Series:
    arr = np.asarray(seconds, dtype="float64")
    micro = np.where(np.isnan(arr), 0, np.round(arr * 1e6)).astype("int64")
    out = pd.Series(pd.to_datetime(micro, unit="us", utc=True))
    out[np.isnan(arr)] = pd.NaT
    return out


def as_epoch(value: Any) -> float:
    """Scalar timestamp / datetime / string / number -> epoch seconds."""
    if isinstance(value, (int, float, np.integer, np.floating)):
        return float(value)
    ts = pd.Timestamp(value)
    ts = ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
    return float((ts - pd.Timestamp(0, tz="UTC")).total_seconds())      # independent of the timestamp's unit


def as_timestamp(seconds: float) -> datetime:
    return pd.Timestamp(float(seconds), unit="s", tz="UTC").to_pydatetime()
