"""Deterministic event cleaning.

``clean_events`` applies, in order:

1. **Schema validation** (:func:`validate_interactions`).
2. **Deduplication of event identifiers** - for a repeated ``event_id`` the delivery with
   the earliest ``received_at`` wins (ties broken by the remaining columns, so the result
   does not depend on input order).
3. **Late-arrival handling** - ``lateness = received_at - occurred_at``.
   Events received more than ``clock_skew_tolerance_seconds`` *before* they occurred are
   dropped as clock errors; events later than ``max_event_lateness_seconds`` are dropped.
   Everything else is kept and ordered by ``(occurred_at, received_at, event_id)``.
   Downstream code treats an event as *observable at time t* iff ``received_at <= t``;
   ``occurred_at`` is used for ordering and for "time since" features.
4. **Personalisation reset** - events of a user that occurred before that user's
   ``history_reset_at`` are removed entirely (they are neither labels nor history).
5. **Playback-interval validation** - progress events need ``0 <= start < end``; with a
   catalogue, ``end`` may exceed the video duration by at most
   ``interval_end_tolerance_seconds`` (then it is clipped) - anything beyond is invalid.

The cleaned frame carries the contract columns plus ``t_occurred`` / ``t_received`` (epoch
seconds). The cleaning report is available as ``frame.attrs["report"]``.
"""
from __future__ import annotations

from typing import Any, Optional

import numpy as np
import pandas as pd

from ..config import Config, EventConfig
from ..constants import EV_PROGRESS
from .catalogue import Catalogue
from .schemas import validate_interactions, validate_preferences
from .timeutil import to_epoch_seconds


def _event_config(config: Config | EventConfig | None) -> EventConfig:
    if config is None:
        return EventConfig()
    return config.events if isinstance(config, Config) else config


def clean_events(raw_events: pd.DataFrame, config: Config | EventConfig | None = None,
                 preferences: Optional[pd.DataFrame] = None, catalogue: Optional[Catalogue] = None) -> pd.DataFrame:
    """Validate, deduplicate, order and filter the raw interaction log (see module docstring)."""
    cfg = _event_config(config)
    df, schema_report = validate_interactions(raw_events)
    report: dict[str, Any] = {"schema": schema_report.to_dict(), "rows_in": len(raw_events)}
    df["t_occurred"] = to_epoch_seconds(df["occurred_at"])
    df["t_received"] = to_epoch_seconds(df["received_at"])

    # 2. deduplicate event ids: earliest delivery wins, deterministic under any input order
    sort_cols = ["event_id", "t_received", "t_occurred", "user_id", "video_id", "event_type"]
    df = df.sort_values(sort_cols, kind="mergesort")
    dup = df.duplicated("event_id", keep="first").to_numpy()
    report["duplicate_event_ids_removed"] = int(dup.sum())
    df = df.loc[~dup]

    # 3. late arrivals and clock errors
    lateness = (df["t_received"] - df["t_occurred"]).to_numpy()
    clock_error = lateness < -cfg.clock_skew_tolerance_seconds
    too_late = lateness > cfg.max_event_lateness_seconds
    report["received_before_occurred_removed"] = int(clock_error.sum())
    report["too_late_removed"] = int(too_late.sum())
    df = df.loc[~(clock_error | too_late)]

    # 4. personalisation reset
    report["before_history_reset_removed"] = 0
    if preferences is not None and len(preferences):
        prefs, _ = validate_preferences(preferences)
        reset = pd.Series(to_epoch_seconds(prefs["history_reset_at"]), index=prefs["user_id"].to_numpy())
        user_reset = df["user_id"].map(reset).to_numpy(dtype="float64")
        before = ~np.isnan(user_reset) & (df["t_occurred"].to_numpy() < user_reset)
        report["before_history_reset_removed"] = int(before.sum())
        df = df.loc[~before]

    # 5. playback intervals
    is_prog = (df["event_type"] == EV_PROGRESS).to_numpy()
    s = df["watched_interval_start"].to_numpy(dtype="float64").copy()
    e = df["watched_interval_end"].to_numpy(dtype="float64").copy()
    invalid = is_prog & (np.isnan(s) | np.isnan(e) | (s < 0) | (e <= s))
    clipped = np.zeros(len(df), dtype=bool)
    if catalogue is not None:
        vidx = catalogue.video_idx(df["video_id"].to_numpy(dtype=object))
        rows = catalogue.rows_at(vidx, df["t_occurred"].to_numpy())
        dur = np.where(rows >= 0, catalogue.duration[np.maximum(rows, 0)], np.inf)
        beyond = is_prog & ~invalid & (e > dur + cfg.interval_end_tolerance_seconds)
        clipped = is_prog & ~invalid & ~beyond & (e > dur)
        e = np.where(clipped, dur, e)
        invalid |= beyond | (is_prog & (s >= dur))
    report["invalid_intervals_removed"] = int(invalid.sum())
    report["interval_ends_clipped"] = int(clipped.sum())
    df = df.assign(watched_interval_end=e).loc[~invalid]

    df = df.sort_values(["t_occurred", "t_received", "event_id"], kind="mergesort").reset_index(drop=True)
    report["rows_out"] = len(df)
    df.attrs["report"] = report
    return df
