"""Watch-interval accounting.

Two different unions are computed for every playback (or impression):

* **content domain** - the union of reported ``[start, end]`` content intervals gives
  ``unique_watched_seconds`` (unique content coverage). Re-watching adds nothing here.
* **wall-clock domain** - each report covers the wall-clock span
  ``[occurred_at - (end - start), occurred_at]`` (playback rate 1 is assumed and
  ``occurred_at`` marks the end of the reported segment). The union of those spans gives
  ``total_valid_playback_seconds``. A re-sent or cumulative progress update occupies the
  same wall-clock span as the original and therefore adds nothing, whereas a genuine loop
  occupies new wall-clock time and is counted. ``rewatch_seconds = total - unique``.
"""
from __future__ import annotations

from bisect import bisect_left
from typing import Iterable

import numpy as np


def merge_intervals(intervals: Iterable[tuple[float, float]]) -> list[tuple[float, float]]:
    """Reference implementation: sorted, disjoint union of closed intervals (empty ones ignored)."""
    out: list[tuple[float, float]] = []
    for s, e in sorted((float(s), float(e)) for s, e in intervals if e > s):
        if out and s <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], e))
        else:
            out.append((s, e))
    return out


def union_length(intervals: Iterable[tuple[float, float]]) -> float:
    return float(sum(e - s for s, e in merge_intervals(intervals)))


class IntervalSet:
    """Incrementally maintained disjoint interval union (used for point-in-time history versions)."""

    __slots__ = ("starts", "ends", "total")

    def __init__(self) -> None:
        self.starts: list[float] = []
        self.ends: list[float] = []
        self.total = 0.0

    def add(self, s: float, e: float) -> float:
        """Insert ``[s, e]`` and return the new total covered length."""
        if e <= s:
            return self.total
        i = bisect_left(self.ends, s)                 # first interval that may overlap
        j = i
        while j < len(self.starts) and self.starts[j] <= e:
            s = min(s, self.starts[j])
            e = max(e, self.ends[j])
            self.total -= self.ends[j] - self.starts[j]
            j += 1
        self.starts[i:j] = [s]
        self.ends[i:j] = [e]
        self.total += e - s
        return self.total


def grouped_union_length(groups: np.ndarray, starts: np.ndarray, ends: np.ndarray, n_groups: int) -> np.ndarray:
    """Vectorised union length per group. ``groups`` are integer ids in ``[0, n_groups)``."""
    out = np.zeros(n_groups, dtype="float64")
    groups = np.asarray(groups, dtype="int64")
    starts = np.asarray(starts, dtype="float64")
    ends = np.asarray(ends, dtype="float64")
    keep = ends > starts
    if not keep.any():
        return out
    g, s, e = groups[keep], starts[keep], ends[keep]
    order = np.lexsort((e, s, g))
    g, s, e = g[order], s[order], e[order]
    first = np.r_[True, g[1:] != g[:-1]]
    # make values relative to each group's first start so a per-group offset keeps float precision
    base = s[np.flatnonzero(first)][np.cumsum(first) - 1]
    s, e = s - base, e - base
    span = float(e.max()) + 1.0
    rank = (np.cumsum(first) - 1).astype("float64")
    running = np.maximum.accumulate(e + rank * span) - rank * span      # cummax of end within group
    prev = np.r_[-np.inf, running[:-1]]
    prev[first] = -np.inf
    np.add.at(out, g, np.maximum(0.0, e - np.maximum(s, prev)))
    return out
