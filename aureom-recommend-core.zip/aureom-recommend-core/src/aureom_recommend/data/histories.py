"""Point-in-time user state: histories, creator blocks and aggregate statistics.

Every accessor takes an ``as_of`` time and only reveals information that had been
*received* strictly before it:

* ``items_as_of``     - the latest known version of each history item (see labels.py)
* ``blocks_as_of``    - creators blocked via events, plus blocks in the preference snapshot
* ``stats.snapshot``  - popularity and smoothed feedback rates on a refresh grid
                        (``floor(t / refresh) * refresh <= t``, so there is no look-ahead)

A store holds dense indices into the catalogue it was built with; use
:meth:`HistoryStore.rebind` before serving from a different (e.g. grown) catalogue.

Because the store answers "as of" queries, one store built from the whole log can serve
rolling evaluation: a simulated request at time ``t`` sees exactly what a store built from
the log truncated at ``t`` would show (tested in tests/test_temporal_leakage.py).
"""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

from ..config import Config, StatsConfig
from ..constants import DAY, H_MEANINGFUL, H_NEGATIVE_FEEDBACK, H_POSITIVE_FEEDBACK
from .catalogue import Catalogue
from .labels import ExampleSet
from .schemas import UserPreferences, validate_preferences
from .timeutil import to_epoch_seconds


@dataclass
class UserItems:
    """A user's history as of some time, ordered oldest to newest."""

    video_idx: np.ndarray
    row: np.ndarray
    t_item: np.ndarray
    type: np.ndarray
    strength: np.ndarray
    context_idx: np.ndarray

    def __len__(self) -> int:
        return len(self.video_idx)

    @classmethod
    def empty(cls) -> "UserItems":
        z = np.array([], dtype="int64")
        return cls(z, z, np.array([], dtype="float64"), np.array([], dtype="int8"), np.array([], dtype="float32"), z)


class PreferenceStore:
    """User preference snapshot. Unknown users get empty preferences with personalisation enabled.

    The snapshot is treated as declared settings that were valid whenever it is used; changes
    that arrive as events (creator blocks) are handled point-in-time by :class:`HistoryStore`.
    """

    def __init__(self, preferences: Optional[pd.DataFrame] = None) -> None:
        self._prefs: dict[str, UserPreferences] = {}
        if preferences is not None and len(preferences):
            df, _ = validate_preferences(preferences)
            reset = to_epoch_seconds(df["history_reset_at"])
            for i, rec in enumerate(df.to_dict("records")):
                self._prefs[rec["user_id"]] = UserPreferences(
                    user_id=rec["user_id"], selected_topics=rec["selected_topics"],
                    preferred_languages=rec["preferred_languages"], followed_creators=rec["followed_creators"],
                    blocked_creators=rec["blocked_creators"], excluded_videos=rec["excluded_videos"],
                    personalisation_enabled=bool(rec["personalisation_enabled"]),
                    history_reset_at=None if np.isnan(reset[i]) else float(reset[i]),  # epoch seconds
                )

    def get(self, user_id: str) -> UserPreferences:
        return self._prefs.get(str(user_id)) or UserPreferences(user_id=str(user_id))

    def __contains__(self, user_id: str) -> bool:
        return str(user_id) in self._prefs

    def user_ids(self) -> list[str]:
        return sorted(self._prefs)


@dataclass
class StatsSnapshot:
    """Aggregate statistics computed from observations received before ``t``."""

    t: float
    popularity: np.ndarray          # time-decayed positive count per video
    positives: np.ndarray           # first-time positives per video (all playbacks)
    negatives: np.ndarray
    impressions: np.ndarray
    global_positive_rate: float
    global_negative_rate: float
    positive_rate: np.ndarray       # Bayesian-smoothed per video
    negative_rate: np.ndarray
    creator_positive_rate: np.ndarray   # smoothed, per catalogue creator
    creator_impressions: np.ndarray


class AggregateStats:
    def __init__(self, examples: ExampleSet, catalogue: Catalogue, config: StatsConfig) -> None:
        self.cfg = config
        self.n_videos = catalogue.n_videos
        self.video_creator = catalogue.video_creator
        self.n_creators = catalogue.n_creators
        v = examples.versions
        typ = v["type"].to_numpy()

        def first_events(mask: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
            sub = v.loc[mask].sort_values("t_available", kind="mergesort").drop_duplicates("group", keep="first")
            return sub["t_available"].to_numpy(), sub["video_idx"].to_numpy()

        # the first moment each history item became positive / negative (items are keyed by playback,
        # so these counts include the few positives from playbacks that had no impression)
        self._pos_t, self._pos_v = first_events(np.isin(typ, (H_MEANINGFUL, H_POSITIVE_FEEDBACK)))
        self._pop_t, self._pop_v = self._pos_t, self._pos_v
        self._neg_t, self._neg_v = first_events(typ == H_NEGATIVE_FEEDBACK)
        imp = examples.impressions.sort_values("t_received", kind="mergesort")
        self._imp_t, self._imp_v = imp["t_received"].to_numpy(), imp["video_idx"].to_numpy()
        self._cache: OrderedDict[float, StatsSnapshot] = OrderedDict()

    def snapshot(self, t: float) -> StatsSnapshot:
        grid = np.floor(t / self.cfg.refresh_seconds) * self.cfg.refresh_seconds
        hit = self._cache.get(grid)
        if hit is not None:
            self._cache.move_to_end(grid)
            return hit
        snap = self._compute(float(grid))
        self._cache[grid] = snap
        if len(self._cache) > 512:
            self._cache.popitem(last=False)
        return snap

    def _compute(self, t: float) -> StatsSnapshot:
        n = self.n_videos

        def count(times: np.ndarray, vids: np.ndarray) -> np.ndarray:
            k = int(np.searchsorted(times, t, side="left"))            # strictly before t
            return np.bincount(vids[:k], minlength=n).astype("float64")

        k = int(np.searchsorted(self._pop_t, t, side="left"))
        decay = np.exp(-np.log(2.0) * (t - self._pop_t[:k]) / (self.cfg.popularity_half_life_days * DAY))
        popularity = np.bincount(self._pop_v[:k], weights=decay, minlength=n)
        pos, neg, imp = count(self._pos_t, self._pos_v), count(self._neg_t, self._neg_v), count(self._imp_t, self._imp_v)
        a = self.cfg.prior_strength
        total = imp.sum()
        g_pos = float(pos.sum() / total) if total > 0 else 0.0
        g_neg = float(neg.sum() / total) if total > 0 else 0.0
        c_pos = np.bincount(self.video_creator, weights=pos, minlength=self.n_creators)
        c_imp = np.bincount(self.video_creator, weights=imp, minlength=self.n_creators)
        return StatsSnapshot(
            t=t, popularity=popularity, positives=pos, negatives=neg, impressions=imp,
            global_positive_rate=g_pos, global_negative_rate=g_neg,
            positive_rate=(pos + a * g_pos) / (imp + a), negative_rate=(neg + a * g_neg) / (imp + a),
            creator_positive_rate=(c_pos + a * g_pos) / (c_imp + a), creator_impressions=c_imp,
        )


class HistoryStore:
    """Point-in-time histories for all users plus aggregate statistics."""

    def __init__(self, examples: ExampleSet, catalogue: Catalogue, config: Config) -> None:
        v = examples.versions
        self.catalogue = catalogue
        self._avail = v["t_available"].to_numpy()
        self._group = v["group"].to_numpy()
        self._vidx = v["video_idx"].to_numpy()
        self._row = v["row"].to_numpy()
        self._t_item = v["t_item"].to_numpy()
        self._type = v["type"].to_numpy()
        self._strength = v["strength"].to_numpy()
        self._ctx = v["context_idx"].to_numpy()
        self._slices = self._slices_of(v["user_id"].to_numpy(dtype=object))
        b = examples.blocks
        self._block_t = b["t_available"].to_numpy()
        self._block_creator = b["creator_idx"].to_numpy()
        self._block_slices = self._slices_of(b["user_id"].to_numpy(dtype=object))
        first = examples.impressions.groupby("user_id")["t_received"].min()
        self._first_seen: dict[str, float] = first.to_dict()
        for user, (s, _) in self._slices.items():
            self._first_seen[user] = min(self._first_seen.get(user, np.inf), float(self._avail[s]))
        self.stats = AggregateStats(examples, catalogue, config.stats)
        self.cutoff = examples.cutoff

    def rebind(self, catalogue: Catalogue) -> "HistoryStore":
        """The same histories expressed against another catalogue (e.g. after new videos were added).

        A store holds dense indices of the catalogue it was built with, so it must be re-bound
        before it is used with a different one. Items of videos that no longer exist are dropped.
        """
        if catalogue.fingerprint == self.catalogue.fingerprint:
            return self
        import copy

        old = self.catalogue
        new = copy.copy(self)
        vmap = catalogue.video_idx(old.unique_video_ids)
        cmap = catalogue.creator_idx(old.unique_creator_ids)
        new.catalogue = catalogue
        new._vidx = vmap[self._vidx]
        keep = new._vidx >= 0
        if not keep.all():
            users = np.concatenate([np.full(e - s, u, dtype=object) for u, (s, e) in self._slices.items()])
            order = np.argsort(np.concatenate([np.arange(s, e) for s, e in self._slices.values()]), kind="stable")
            users = users[order][keep]
            for name in ("_avail", "_group", "_vidx", "_t_item", "_type", "_strength", "_ctx"):
                setattr(new, name, getattr(new, name)[keep])
            new._slices = self._slices_of(users)
        new._row = catalogue.rows_at(new._vidx, new._t_item)
        new._block_creator = cmap[self._block_creator]            # unknown creators become -1 and match nothing
        stats = copy.copy(self.stats)
        stats.n_videos, stats.n_creators, stats.video_creator = catalogue.n_videos, catalogue.n_creators, catalogue.video_creator
        for t_name, v_name in (("_pos_t", "_pos_v"), ("_pop_t", "_pop_v"), ("_neg_t", "_neg_v"), ("_imp_t", "_imp_v")):
            mapped = vmap[getattr(self.stats, v_name)]
            setattr(stats, t_name, getattr(self.stats, t_name)[mapped >= 0])
            setattr(stats, v_name, mapped[mapped >= 0])
        stats._cache = OrderedDict()
        new.stats = stats
        return new

    @staticmethod
    def _slices_of(users: np.ndarray) -> dict[str, tuple[int, int]]:
        if len(users) == 0:
            return {}
        change = np.flatnonzero(np.r_[True, users[1:] != users[:-1], True])
        return {users[s]: (int(s), int(e)) for s, e in zip(change[:-1], change[1:])}

    def user_ids(self) -> list[str]:
        return sorted(self._first_seen)

    def first_seen(self, user_id: str) -> float:
        return self._first_seen.get(str(user_id), np.inf)

    def items_as_of(self, user_id: str, t: float) -> UserItems:
        """Latest version of every history item received strictly before ``t``."""
        sl = self._slices.get(str(user_id))
        if sl is None:
            return UserItems.empty()
        s, e = sl
        pos = s + int(np.searchsorted(self._avail[s:e], t, side="left"))
        if pos == s:
            return UserItems.empty()
        rev = self._group[s:pos][::-1]
        _, first_idx = np.unique(rev, return_index=True)
        keep = (pos - 1) - first_idx
        keep = keep[np.lexsort((keep, self._t_item[keep]))]
        return UserItems(video_idx=self._vidx[keep], row=self._row[keep], t_item=self._t_item[keep],
                         type=self._type[keep], strength=self._strength[keep], context_idx=self._ctx[keep])

    def blocks_as_of(self, user_id: str, t: float) -> np.ndarray:
        """Catalogue creator indices blocked through events received strictly before ``t``."""
        sl = self._block_slices.get(str(user_id))
        if sl is None:
            return np.array([], dtype="int64")
        s, e = sl
        pos = s + int(np.searchsorted(self._block_t[s:e], t, side="left"))
        return np.unique(self._block_creator[s:pos])
