"""Local Parquet IO for the three contract tables (PyArrow engine)."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .schemas import _is_missing

LIST_COLUMNS = {
    "videos": ("topic_ids", "eligibility_labels", "content_embedding"),
    "preferences": ("selected_topics", "preferred_languages", "followed_creators", "blocked_creators",
                    "excluded_videos"),
    "interactions": (),
}


def _listify(df: pd.DataFrame, columns: tuple[str, ...]) -> pd.DataFrame:
    out = df.copy()
    for col in columns:
        if col in out.columns:
            out[col] = pd.Series(
                [None if _is_missing(v) else list(np.asarray(v).tolist()) for v in out[col].to_numpy(dtype=object)],
                index=out.index, dtype=object)
    return out


def write_table(df: pd.DataFrame, path: str | Path, table: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    _listify(df, LIST_COLUMNS.get(table, ())).to_parquet(path, engine="pyarrow", index=False)


def read_table(path: str | Path) -> pd.DataFrame:
    return pd.read_parquet(path, engine="pyarrow")


def write_dataset(directory: str | Path, videos: pd.DataFrame, interactions: pd.DataFrame,
                  preferences: pd.DataFrame) -> None:
    directory = Path(directory)
    write_table(videos, directory / "videos.parquet", "videos")
    write_table(interactions, directory / "interactions.parquet", "interactions")
    write_table(preferences, directory / "preferences.parquet", "preferences")


def read_dataset(directory: str | Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    directory = Path(directory)
    return (read_table(directory / "videos.parquet"), read_table(directory / "interactions.parquet"),
            read_table(directory / "preferences.parquet"))
