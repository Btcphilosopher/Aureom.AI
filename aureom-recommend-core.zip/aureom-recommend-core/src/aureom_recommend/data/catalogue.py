"""Point-in-time video catalogue.

The catalogue holds one row per *(video_id, metadata_version)*. Each row is visible during
``[valid_from, valid_to)`` where ``valid_to`` is the next version's ``valid_from``. At any
instant exactly one row per video is "live", so later metadata edits can never leak into an
earlier recommendation or training example: every time-dependent lookup goes through
:meth:`Catalogue.live_mask` or :meth:`Catalogue.rows_at`.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from ..constants import CONTEXT_INDEX, LONG_FORM, SHORT_FORM
from .schemas import validate_videos
from .timeutil import to_epoch_seconds


@dataclass
class Catalogue:
    frame: pd.DataFrame                 # validated rows, sorted by (video_id, metadata_version)
    video_ids: np.ndarray               # (n_rows,) object
    video_index: np.ndarray             # (n_rows,) dense index of the video each row belongs to
    unique_video_ids: np.ndarray        # (n_videos,)
    creator_ids: np.ndarray             # (n_rows,) object
    creator_index: np.ndarray           # (n_rows,) dense catalogue-level creator index
    unique_creator_ids: np.ndarray
    languages: np.ndarray               # (n_rows,) object, None when missing
    topics: list[tuple[str, ...]]
    duration: np.ndarray
    published_at: np.ndarray            # epoch seconds
    available_from: np.ndarray
    available_until: np.ndarray         # +inf when there is no expiry
    valid_from: np.ndarray              # -inf for the first version
    valid_to: np.ndarray                # +inf for the latest version
    content_embedding: np.ndarray       # (n_rows, d) float32, zeros where missing
    has_content_embedding: np.ndarray
    duplicate_group: np.ndarray         # (n_rows,) int; videos without a group get a private id
    eligibility_labels: list[tuple[str, ...]]
    short_form_max_duration: float

    # ------------------------------------------------------------------ construction
    @classmethod
    def from_frame(cls, videos: pd.DataFrame, short_form_max_duration: float = 120.0,
                   validated: bool = False) -> "Catalogue":
        df = videos if validated else validate_videos(videos)[0]
        video_ids = df["video_id"].to_numpy(dtype=object)
        unique_videos, video_index = np.unique(video_ids.astype(str), return_inverse=True)
        creator_ids = df["creator_id"].to_numpy(dtype=object)
        unique_creators, creator_index = np.unique(creator_ids.astype(str), return_inverse=True)
        published = to_epoch_seconds(df["published_at"])
        a_from = to_epoch_seconds(df["available_from"])
        a_from = np.where(np.isnan(a_from), published, a_from)
        a_until = to_epoch_seconds(df["available_until"])
        a_until = np.where(np.isnan(a_until), np.inf, a_until)

        v_from = to_epoch_seconds(df["metadata_valid_from"])
        first = np.r_[True, video_index[1:] != video_index[:-1]]
        v_from = np.where(first, -np.inf, v_from)             # first version is valid from the start
        last = np.r_[first[1:], True]
        v_to = np.where(last, np.inf, np.r_[v_from[1:], np.inf])

        emb_cells = df["content_embedding"].to_numpy(dtype=object)
        dim = next((len(e) for e in emb_cells if e is not None), 0)
        emb = np.zeros((len(df), dim), dtype="float32")
        has_emb = np.zeros(len(df), dtype=bool)
        for i, e in enumerate(emb_cells):
            if e is not None:
                emb[i] = e
                has_emb[i] = True

        groups = df["duplicate_group_id"].to_numpy(dtype=object)
        group_ids: dict[str, int] = {}
        dup = np.empty(len(df), dtype="int64")
        for i, g in enumerate(groups):
            key = f"g:{g}" if g is not None else f"v:{video_ids[i]}"
            dup[i] = group_ids.setdefault(key, len(group_ids))

        return cls(
            frame=df, video_ids=video_ids, video_index=video_index.astype("int64"),
            unique_video_ids=unique_videos.astype(object), creator_ids=creator_ids,
            creator_index=creator_index.astype("int64"), unique_creator_ids=unique_creators.astype(object),
            languages=df["language"].to_numpy(dtype=object), topics=list(df["topic_ids"].to_numpy(dtype=object)),
            duration=df["duration_seconds"].to_numpy(dtype="float64"), published_at=published,
            available_from=a_from, available_until=a_until, valid_from=v_from, valid_to=v_to,
            content_embedding=emb, has_content_embedding=has_emb, duplicate_group=dup,
            eligibility_labels=list(df["eligibility_labels"].to_numpy(dtype=object)),
            short_form_max_duration=float(short_form_max_duration),
        )

    def __post_init__(self) -> None:
        self._video_lookup = {v: i for i, v in enumerate(self.unique_video_ids)}
        self._creator_lookup = {c: i for i, c in enumerate(self.unique_creator_ids)}
        order = np.arange(self.n_rows)
        first = np.r_[True, self.video_index[1:] != self.video_index[:-1]]
        self._first_row = order[first]                              # (n_videos,)
        self._n_versions = np.diff(np.r_[self._first_row, self.n_rows])
        self.is_short = self.duration <= self.short_form_max_duration
        self.context_index = np.where(self.is_short, CONTEXT_INDEX[SHORT_FORM], CONTEXT_INDEX[LONG_FORM])
        langs = sorted({l for l in self.languages if l is not None})
        self.unique_languages = np.array(langs, dtype=object)
        lang_lookup = {l: i for i, l in enumerate(langs)}
        self.language_index = np.array([lang_lookup.get(l, -1) for l in self.languages], dtype="int64")
        topics = sorted({t for ts in self.topics for t in ts})
        self.unique_topics = np.array(topics, dtype=object)
        self._topic_lookup = {t: i for i, t in enumerate(topics)}
        # dense (n_rows, n_topics) membership; adequate for the catalogue sizes this package targets
        self.topic_matrix = np.zeros((self.n_rows, len(topics)), dtype=bool)
        for i, ts in enumerate(self.topics):
            for t in ts:
                self.topic_matrix[i, self._topic_lookup[t]] = True
        self.video_creator = self.creator_index[self._first_row]     # creator per dense video index
        self.video_group = self.duplicate_group[self._first_row]
        self._label_masks: dict[tuple, np.ndarray] = {}
        blob = "|".join(f"{v}:{m}" for v, m in zip(self.video_ids, self.frame["metadata_version"].to_numpy()))
        self.fingerprint = hashlib.sha256(blob.encode()).hexdigest()[:16]

    # ------------------------------------------------------------------ sizes / lookups
    @property
    def n_rows(self) -> int:
        return len(self.video_ids)

    @property
    def n_videos(self) -> int:
        return len(self.unique_video_ids)

    @property
    def n_creators(self) -> int:
        return len(self.unique_creator_ids)

    def video_idx(self, video_ids: Iterable[str]) -> np.ndarray:
        """Dense video index per id; -1 for ids that are not in the catalogue."""
        return np.fromiter((self._video_lookup.get(str(v), -1) for v in video_ids), dtype="int64")

    def creator_idx(self, creator_ids: Iterable[str]) -> np.ndarray:
        return np.fromiter((self._creator_lookup.get(str(c), -1) for c in creator_ids), dtype="int64")

    def topic_idx(self, topics: Iterable[str]) -> np.ndarray:
        return np.array([self._topic_lookup[t] for t in topics if t in self._topic_lookup], dtype="int64")

    def language_idx(self, languages: Iterable[str]) -> np.ndarray:
        lookup = {l: i for i, l in enumerate(self.unique_languages)}
        return np.array([lookup[l] for l in languages if l in lookup], dtype="int64")

    def label_mask(self, excluded: Sequence[str] = (), required: Sequence[str] = ()) -> np.ndarray:
        """Rows passing the configured eligibility-label rules (cached per rule set)."""
        key = (tuple(excluded), tuple(required))
        if key not in self._label_masks:
            ex, req = set(excluded), set(required)
            self._label_masks[key] = np.array(
                [not (ex & set(labels)) and req <= set(labels) for labels in self.eligibility_labels], dtype=bool)
        return self._label_masks[key]

    # ------------------------------------------------------------------ time-dependent views
    def version_live_mask(self, t: float) -> np.ndarray:
        """Rows whose metadata version is the one visible at time ``t``."""
        return (self.valid_from <= t) & (t < self.valid_to)

    def live_mask(self, t: float) -> np.ndarray:
        """Rows that are the visible version *and* published and available at ``t``."""
        return (self.version_live_mask(t) & (self.published_at <= t)
                & (self.available_from <= t) & (t < self.available_until))

    def context_mask(self, context: str) -> np.ndarray:
        return self.is_short if context == SHORT_FORM else ~self.is_short

    def rows_at(self, video_index: np.ndarray, t: np.ndarray) -> np.ndarray:
        """Catalogue row of each video's metadata version visible at time ``t`` (-1 if unknown video)."""
        video_index = np.asarray(video_index, dtype="int64")
        t = np.broadcast_to(np.asarray(t, dtype="float64"), video_index.shape)
        out = np.full(video_index.shape, -1, dtype="int64")
        ok = video_index >= 0
        out[ok] = self._first_row[video_index[ok]]
        multi = ok & (self._n_versions[np.where(ok, video_index, 0)] > 1)
        for i in np.flatnonzero(multi):
            start = self._first_row[video_index[i]]
            n = self._n_versions[video_index[i]]
            k = int(np.searchsorted(self.valid_from[start:start + n], t[i], side="right")) - 1
            out[i] = start + max(k, 0)
        return out

    def rows_visible_before(self, cutoff: float) -> np.ndarray:
        """Row indices whose metadata version and publication both precede ``cutoff`` (training snapshot)."""
        return np.flatnonzero((self.valid_from <= cutoff) & (self.published_at <= cutoff))

    def text(self, rows: Sequence[int] | np.ndarray | None = None) -> list[str]:
        titles = self.frame["title"].to_numpy(dtype=object)
        descs = self.frame["description"].to_numpy(dtype=object)
        idx = range(self.n_rows) if rows is None else rows
        return [f"{titles[i]} {descs[i] or ''}" for i in idx]
