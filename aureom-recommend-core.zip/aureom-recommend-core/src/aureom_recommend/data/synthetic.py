"""Seeded synthetic world for end-to-end testing of the algorithm.

EVERYTHING PRODUCED HERE IS SYNTHETIC. The simulator owns latent user preference vectors,
latent video vectors and video quality. Those latents are written only to the ``oracle/``
sub-directory and are read exclusively by :class:`Oracle` (designated oracle evaluation).
They are never part of the three contract tables and no feature code imports this module.

What the simulator covers (each item is exercised by the pipeline or the tests):

* latent user preferences over topics, several languages, short- and long-form videos
* creator popularity imbalance (Pareto weights) and a popularity-biased logging policy
* a uniform-random logging policy on part of the long-form surface, the only place where
  ``selection_propensity`` is supplied (slate inclusion probability m / n_eligible)
* new users and new videos arriving throughout the period
* sparse satisfaction surveys, explicit dislikes, "not interested" and creator blocks
* duplicate re-uploads (``duplicate_group_id``) and later metadata edits (version 2 rows)
* delayed events, re-sent progress updates, duplicate event ids, cumulative progress
  reporting, seeking, looping, background playback, lost play_end events, corrupt intervals
* duration-dependent viewing: completion falls with duration while absolute seconds rise
"""
from __future__ import annotations

import json
import math
import random
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd

from ..constants import (DAY, EV_BLOCK_CREATOR, EV_DISLIKE, EV_IMPRESSION, EV_LIKE, EV_NOT_INTERESTED, EV_PLAY_END,
                         EV_PLAY_START, EV_PROGRESS, EV_SAVE, EV_SHARE, EV_SURVEY, HOUR, LONG_FORM, SHORT_FORM)
from .io import write_dataset
from .schemas import INTERACTION_COLUMNS
from .timeutil import as_epoch, from_epoch_seconds

POLICY_BIASED = "biased_popularity_v1"      # supplies no propensities
POLICY_UNIFORM = "uniform_random_v1"        # supplies slate-inclusion propensities (long-form only)
POLICY_UNIFORM_NOPROP = "uniform_random_unlogged_v1"   # uniform exposure, propensity not recorded


@dataclass
class SyntheticConfig:
    seed: int = 7
    scenario: str = "default"
    start: str = "2026-01-05T00:00:00Z"
    n_days: int = 42
    n_users: int = 1200
    n_creators: int = 150
    n_videos: int = 2500
    n_topics: int = 20
    languages: tuple[str, ...] = ("en", "es", "fr")
    language_probs: tuple[float, ...] = (0.6, 0.25, 0.15)
    latent_dim: int = 12
    embedding_dim: int = 16
    short_form_share: float = 0.6
    short_form_max_duration: float = 120.0
    preexisting_video_fraction: float = 0.55
    late_video_fraction: float = 0.0        # extra share of videos published in the final quarter
    new_user_fraction: float = 0.25
    late_user_fraction: float = 0.0         # extra share of users joining in the final quarter
    mean_sessions_per_day: float = 0.55
    slate_short: int = 12
    slate_long: int = 10
    # exposure policy
    popularity_bias: float = 1.0
    creator_bias: float = 0.5
    freshness_bias: float = 1.0
    exposure_personalisation: float = 1.0
    exposure_noise: float = 1.0
    uniform_fraction_long: float = 0.12     # share of long-form requests served by the uniform policy
    uniform_everywhere: bool = False        # preference-recovery scenario: uniform exposure on all requests
    # behaviour
    duration_bias: float = 0.8
    survey_rate: float = 0.05
    duplicate_fraction: float = 0.03
    edit_fraction: float = 0.04
    organic_play_rate: float = 0.02
    # true-relevance model: rho = sigmoid(b0 + b1 * cos + b2 * quality + b3 * followed - b4 * disliked - b5 * lang)
    b0: float = -2.2
    b1: float = 4.0
    b2: float = 0.5
    b3: float = 0.6
    b4: float = 1.5
    b5: float = 3.0


SCENARIOS: dict[str, dict[str, Any]] = {
    "default": {},
    # can the learner recover preferences when exposure is unbiased and viewing is duration-neutral?
    "preference_recovery": {"uniform_everywhere": True, "popularity_bias": 0.0, "creator_bias": 0.0,
                            "freshness_bias": 0.0, "exposure_personalisation": 0.0, "duration_bias": 0.0},
    # strong dependence of viewing on duration: raw watch time and raw completion both mislead
    "duration_bias": {"duration_bias": 1.6},
    # exposure concentrated on already-popular items; quality is independent of popularity
    "popularity_bias": {"popularity_bias": 2.5, "creator_bias": 1.5, "exposure_noise": 0.5,
                        "exposure_personalisation": 0.3},
    # many users and videos first appear late in the period
    "cold_start": {"new_user_fraction": 0.5, "late_user_fraction": 0.3, "preexisting_video_fraction": 0.35,
                   "late_video_fraction": 0.3},
}


def scenario_config(name: str = "default", **overrides: Any) -> SyntheticConfig:
    if name not in SCENARIOS:
        raise KeyError(f"unknown scenario {name!r}; choose from {sorted(SCENARIOS)}")
    return SyntheticConfig(**{"scenario": name, **SCENARIOS[name], **overrides})


def _sigmoid(x: np.ndarray | float) -> Any:
    return 1.0 / (1.0 + np.exp(-x))


# --------------------------------------------------------------------------- oracle
@dataclass
class Oracle:
    """Ground-truth relevance, for *oracle evaluation only* (never for features or training)."""

    user_ids: np.ndarray
    video_ids: np.ndarray
    user_latent: np.ndarray
    user_dislike: np.ndarray        # (U, T) bool
    user_lang: np.ndarray           # (U, L) bool
    follow_indptr: np.ndarray
    follow_indices: np.ndarray      # creator indices
    video_latent: np.ndarray
    video_quality: np.ndarray
    video_topic1: np.ndarray
    video_topic2: np.ndarray        # -1 when absent
    video_lang: np.ndarray
    video_creator: np.ndarray
    params: dict[str, float]

    def __post_init__(self) -> None:
        self._u = {u: i for i, u in enumerate(self.user_ids.tolist())}
        self._v = {v: i for i, v in enumerate(self.video_ids.tolist())}

    def relevance_by_index(self, u: int, v: np.ndarray) -> np.ndarray:
        p = self.params
        followed = np.isin(self.video_creator[v], self.follow_indices[self.follow_indptr[u]:self.follow_indptr[u + 1]])
        t2 = self.video_topic2[v]
        disliked = self.user_dislike[u][self.video_topic1[v]] | ((t2 >= 0) & self.user_dislike[u][np.maximum(t2, 0)])
        lang_miss = ~self.user_lang[u][self.video_lang[v]]
        a = (p["b0"] + p["b1"] * (self.video_latent[v] @ self.user_latent[u]) + p["b2"] * self.video_quality[v]
             + p["b3"] * followed - p["b4"] * disliked - p["b5"] * lang_miss)
        return _sigmoid(a)

    def utility(self, user_id: str, video_ids: Sequence[str]) -> np.ndarray:
        """True relevance rho(u, v) in (0, 1); NaN for ids the simulator does not know."""
        out = np.full(len(video_ids), np.nan)
        u = self._u.get(str(user_id))
        if u is None:
            return out
        idx = np.array([self._v.get(str(v), -1) for v in video_ids], dtype="int64")
        ok = idx >= 0
        out[ok] = self.relevance_by_index(u, idx[ok])
        return out

    def save(self, directory: str | Path) -> None:
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        arrays = {k: v for k, v in self.__dict__.items() if isinstance(v, np.ndarray)}
        arrays["user_ids"] = self.user_ids.astype(str)
        arrays["video_ids"] = self.video_ids.astype(str)
        np.savez_compressed(directory / "oracle.npz", **arrays)
        (directory / "oracle_params.json").write_text(json.dumps(self.params, indent=2))

    @classmethod
    def load(cls, directory: str | Path) -> "Oracle":
        directory = Path(directory)
        data = np.load(directory / "oracle.npz")
        params = json.loads((directory / "oracle_params.json").read_text())
        kwargs = {k: data[k] for k in data.files}
        kwargs["user_ids"] = kwargs["user_ids"].astype(object)
        kwargs["video_ids"] = kwargs["video_ids"].astype(object)
        return cls(params=params, **kwargs)


@dataclass
class SyntheticDataset:
    videos: pd.DataFrame
    interactions: pd.DataFrame
    preferences: pd.DataFrame
    oracle: Oracle
    config: SyntheticConfig
    summary: dict[str, Any] = field(default_factory=dict)

    def save(self, directory: str | Path) -> None:
        directory = Path(directory)
        write_dataset(directory, self.videos, self.interactions, self.preferences)
        self.oracle.save(directory / "oracle")
        (directory / "synthetic_config.json").write_text(json.dumps(asdict(self.config), indent=2))
        (directory / "SYNTHETIC_DATA.txt").write_text(
            "All tables in this directory are SYNTHETIC, generated by aureom_recommend.data.synthetic.\n"
            "The oracle/ sub-directory holds simulator latents for oracle evaluation only.\n")


# --------------------------------------------------------------------------- generator
def _make_words(rng: random.Random, n: int, prefix: str) -> list[str]:
    cons, vow = "bcdfghjklmnprstvz", "aeiou"
    words: set[str] = set()
    while len(words) < n:
        syll = rng.randint(2, 3)
        words.add(prefix + "".join(rng.choice(cons) + rng.choice(vow) for _ in range(syll)) + rng.choice(cons))
    return sorted(words)


def generate_synthetic(config: SyntheticConfig | None = None) -> SyntheticDataset:
    """Simulate the world. Deterministic given ``config`` (including its seed)."""
    cfg = config or SyntheticConfig()
    rng = np.random.default_rng(cfg.seed)
    prng = random.Random(cfg.seed + 1)
    t0 = as_epoch(cfg.start)
    t_end = t0 + cfg.n_days * DAY
    T, L, D = cfg.n_topics, len(cfg.languages), cfg.latent_dim
    n_u, n_c, n_v = cfg.n_users, cfg.n_creators, cfg.n_videos

    # ---------------------------------------------------------------- topics / lexicon
    topic_vec = rng.normal(size=(T, D))
    topic_vec /= np.linalg.norm(topic_vec, axis=1, keepdims=True)
    topic_pop = rng.dirichlet(np.full(T, 1.5))
    common_words = {lang: _make_words(prng, 150, f"{lang}") for lang in cfg.languages}
    topic_words = {(lang, t): _make_words(prng, 25, f"{lang}{t % 10}") for lang in cfg.languages for t in range(T)}

    # ---------------------------------------------------------------- creators
    c_topic1 = rng.choice(T, size=n_c, p=topic_pop)
    c_topic2 = rng.choice(T, size=n_c, p=topic_pop)
    c_lang = rng.choice(L, size=n_c, p=np.asarray(cfg.language_probs))
    c_weight = rng.pareto(1.2, size=n_c) + 1.0                 # heavy-tailed creator popularity
    c_weight /= c_weight.sum()
    c_short = rng.beta(1.2, 1.2, size=n_c) * 0.8 + cfg.short_form_share - 0.4
    c_quality = rng.normal(0.0, 0.5, size=n_c)                 # independent of popularity by construction
    c_vec = rng.normal(size=(n_c, D)) * 0.35

    # ---------------------------------------------------------------- videos (latents)
    n_dup = int(round(cfg.duplicate_fraction * n_v))
    n_base = n_v - n_dup
    v_creator = rng.choice(n_c, size=n_base, p=c_weight ** 0.8 / (c_weight ** 0.8).sum())
    v_t1 = c_topic1[v_creator].copy()
    switch = rng.random(n_base) < 0.2
    v_t1[switch] = c_topic2[v_creator][switch]
    v_t2 = np.where(rng.random(n_base) < 0.4, rng.choice(T, size=n_base, p=topic_pop), -1)
    v_t2[v_t2 == v_t1] = -1
    v_lang = c_lang[v_creator]
    v_short = rng.random(n_base) < np.clip(c_short[v_creator], 0.05, 0.95)
    dur_short = np.clip(np.exp(rng.normal(math.log(25.0), 0.6, size=n_base)), 5.0, cfg.short_form_max_duration)
    dur_long = np.clip(np.exp(rng.normal(math.log(600.0), 0.8, size=n_base)), 180.0, 5400.0)
    v_dur = np.round(np.where(v_short, dur_short, dur_long), 1)
    z = topic_vec[v_t1] + 0.5 * np.where((v_t2 >= 0)[:, None], topic_vec[np.maximum(v_t2, 0)], 0.0)
    z = z + c_vec[v_creator] + rng.normal(size=(n_base, D)) * 0.25
    z /= np.linalg.norm(z, axis=1, keepdims=True)
    v_quality = c_quality[v_creator] + rng.normal(0.0, 0.7, size=n_base)

    n_pre = int(cfg.preexisting_video_fraction * n_base)
    n_late = int(cfg.late_video_fraction * n_base)
    pub = np.concatenate([
        rng.uniform(t0 - 60 * DAY, t0, size=n_pre),
        rng.uniform(t_end - 0.25 * cfg.n_days * DAY, t_end, size=n_late),
        rng.uniform(t0, t_end, size=n_base - n_pre - n_late),
    ])
    rng.shuffle(pub)
    projection = rng.normal(size=(D, cfg.embedding_dim)) / math.sqrt(D)
    v_emb = z @ projection + rng.normal(size=(n_base, cfg.embedding_dim)) * 0.15

    def make_text(lang: str, t1: int, t2: int, creator: int) -> tuple[str, str]:
        tw = topic_words[(lang, t1)] + (topic_words[(lang, t2)] if t2 >= 0 else [])
        cw = common_words[lang]
        title = prng.sample(tw, 3) + prng.sample(cw, 2)
        desc = [prng.choice(tw) for _ in range(8)] + [prng.choice(cw) for _ in range(7)] + [f"creator{creator}"]
        prng.shuffle(title)
        prng.shuffle(desc)
        return " ".join(title), " ".join(desc)

    texts = [make_text(cfg.languages[v_lang[i]], int(v_t1[i]), int(v_t2[i]), int(v_creator[i])) for i in range(n_base)]
    dup_group = np.full(n_base, -1)

    # duplicates: re-uploads sharing content with an earlier video
    src = rng.choice(n_base, size=n_dup, replace=False) if n_dup else np.array([], dtype=int)
    same_creator = rng.random(n_dup) < 0.5
    d_creator = np.where(same_creator, v_creator[src], rng.choice(n_c, size=n_dup))
    d_pub = np.minimum(pub[src] + rng.uniform(0.5, 10.0, size=n_dup) * DAY, t_end - HOUR)
    dup_group[src] = src
    v_creator = np.concatenate([v_creator, d_creator])
    v_t1, v_t2 = np.concatenate([v_t1, v_t1[src]]), np.concatenate([v_t2, v_t2[src]])
    v_lang, v_short = np.concatenate([v_lang, v_lang[src]]), np.concatenate([v_short, v_short[src]])
    v_dur, z = np.concatenate([v_dur, v_dur[src]]), np.concatenate([z, z[src]])
    v_quality = np.concatenate([v_quality, v_quality[src]])
    pub = np.concatenate([pub, d_pub])
    v_emb = np.concatenate([v_emb, v_emb[src] + rng.normal(size=(n_dup, cfg.embedding_dim)) * 0.01])
    texts += [texts[s] for s in src]
    dup_group = np.concatenate([dup_group, src])

    avail_until = np.where(rng.random(n_v) < 0.05, pub + rng.uniform(10, 30, size=n_v) * DAY, np.inf)
    label_draw = rng.random(n_v)
    elig_ok = label_draw >= 0.02
    video_ids = np.array([f"v{i:06d}" for i in range(n_v)], dtype=object)
    creator_ids = np.array([f"c{i:04d}" for i in range(n_c)], dtype=object)
    topic_ids = [f"t{i:02d}" for i in range(T)]

    # ---------------------------------------------------------------- users
    u_lat = np.zeros((n_u, D))
    u_like = np.zeros((n_u, T))
    u_dislike = np.zeros((n_u, T), dtype=bool)
    u_lang = np.zeros((n_u, L), dtype=bool)
    for u in range(n_u):
        k = int(rng.integers(2, 5))
        liked = rng.choice(T, size=k, replace=False, p=topic_pop)
        w = rng.dirichlet(np.full(k, 1.5))
        u_like[u, liked] = w
        rest = np.setdiff1d(np.arange(T), liked)
        u_dislike[u, rng.choice(rest, size=int(rng.integers(1, 3)), replace=False)] = True
        vec = w @ topic_vec[liked] + rng.normal(size=D) * 0.15
        u_lat[u] = vec / np.linalg.norm(vec)
        primary = rng.choice(L, p=np.asarray(cfg.language_probs))
        u_lang[u, primary] = True
        if rng.random() < 0.25:
            u_lang[u, rng.integers(0, L)] = True
    n_new = int(cfg.new_user_fraction * n_u)
    n_late_u = int(cfg.late_user_fraction * n_u)
    join = np.concatenate([
        rng.uniform(t0 - 90 * DAY, t0, size=n_u - n_new),
        rng.uniform(t_end - 0.25 * cfg.n_days * DAY, t_end - 0.5 * DAY, size=min(n_late_u, n_new)),
        rng.uniform(t0, t_end - DAY, size=max(n_new - n_late_u, 0)),
    ])
    rng.shuffle(join)
    activity = np.clip(rng.lognormal(math.log(cfg.mean_sessions_per_day), 0.8, size=n_u), 0.03, 4.0)
    f_short = rng.beta(2.0, 2.0, size=n_u) * 0.7 + 0.15
    user_ids = np.array([f"u{i:05d}" for i in range(n_u)], dtype=object)

    # declared preferences (noisy views of the latents) --------------------------------
    creators_by_topic = [np.flatnonzero((c_topic1 == t) | (c_topic2 == t)) for t in range(T)]
    declared_topics = np.zeros((n_u, T), dtype=bool)
    declared_lang = np.zeros((n_u, L), dtype=bool)
    followed: list[np.ndarray] = []
    pref_rows = []
    for u in range(n_u):
        liked = np.flatnonzero(u_like[u] > 0)
        sel: list[int] = []
        if rng.random() < 0.7:
            sel = list(rng.choice(liked, size=min(len(liked), int(rng.integers(1, 4))), replace=False))
            if rng.random() < 0.15:
                sel.append(int(rng.integers(0, T)))
        declared_topics[u, sel] = True
        if rng.random() < 0.9:
            declared_lang[u] = u_lang[u]
        fol = np.array([], dtype=int)
        if rng.random() < 0.6:
            pool = np.unique(np.concatenate([creators_by_topic[t] for t in liked]))
            pool = pool[u_lang[u][c_lang[pool]]]
            if len(pool):
                p = c_weight[pool] / c_weight[pool].sum()
                fol = rng.choice(pool, size=min(len(pool), int(rng.integers(1, 6))), replace=False, p=p)
        followed.append(np.sort(fol))
        excluded = list(rng.choice(n_v, size=2, replace=False)) if rng.random() < 0.03 else []
        pre_blocked = [int(rng.integers(0, n_c))] if rng.random() < 0.02 else []
        reset = rng.uniform(t0 + 0.1 * cfg.n_days * DAY, t0 + 0.6 * cfg.n_days * DAY) if rng.random() < 0.02 else np.nan
        pref_rows.append({
            "user_id": user_ids[u],
            "selected_topics": [topic_ids[t] for t in sorted(set(sel))],
            "preferred_languages": [cfg.languages[i] for i in np.flatnonzero(declared_lang[u])],
            "followed_creators": [creator_ids[c] for c in fol],
            "blocked_creators": [creator_ids[c] for c in pre_blocked],
            "excluded_videos": [video_ids[v] for v in excluded],
            "personalisation_enabled": bool(rng.random() >= 0.03),
            "history_reset_at": reset,
        })
    preferences = pd.DataFrame(pref_rows)
    preferences["history_reset_at"] = from_epoch_seconds(preferences["history_reset_at"].to_numpy()).to_numpy()

    oracle = Oracle(
        user_ids=user_ids, video_ids=video_ids, user_latent=u_lat, user_dislike=u_dislike, user_lang=u_lang,
        follow_indptr=np.cumsum([0] + [len(f) for f in followed]), follow_indices=np.concatenate(followed + [np.array([], dtype=int)]).astype("int64"),
        video_latent=z, video_quality=v_quality, video_topic1=v_t1, video_topic2=v_t2, video_lang=v_lang,
        video_creator=v_creator, params={k: getattr(cfg, k) for k in ("b0", "b1", "b2", "b3", "b4", "b5")},
    )

    # ---------------------------------------------------------------- simulation
    log_dur = np.log(v_dur)
    zlogd = np.zeros(n_v)
    for mask in (v_short, ~v_short):
        if mask.any():
            zlogd[mask] = (log_dur[mask] - log_dur[mask].mean()) / (log_dur[mask].std() + 1e-9)
    log_cw = np.log(c_weight[v_creator] * n_c)
    pop = np.zeros(n_v)
    pop_decay = 0.5 ** (1.0 / 3.0)
    blocked: dict[int, set[int]] = {u: {int(creator_ids.tolist().index(c))} for u, r in enumerate(pref_rows)
                                    for c in r["blocked_creators"]}
    excluded_idx: dict[int, list[int]] = {u: [int(v[1:]) for v in r["excluded_videos"]] for u, r in enumerate(pref_rows)
                                          if r["excluded_videos"]}
    watched: list[set[int]] = [set() for _ in range(n_u)]
    events: list[tuple] = []
    counters = {"event": 0, "playback": 0, "request": 0, "session": 0}
    R = prng.random

    def delay() -> float:
        x = R()
        if x < 0.90:
            return prng.expovariate(0.5)
        if x < 0.98:
            return prng.uniform(60.0, HOUR)
        if x < 0.997:
            return prng.uniform(HOUR, 12 * HOUR)
        return prng.uniform(48 * HOUR, 72 * HOUR)

    def emit(user: int, session: str, video: int, etype: str, t: float, request: str | None, position: float = np.nan,
             playback: str | None = None, ctx: str | None = None, ws: float = np.nan, we: float = np.nan,
             fg: Any = None, fb: float = np.nan, policy: str | None = None, prop: float = np.nan) -> None:
        counters["event"] += 1
        eid = f"e{counters['event']:09d}"
        row = (eid, user_ids[user], session, video_ids[video], etype, t, t + delay(), request, position, playback,
               ctx, ws, we, fg, fb, policy, prop)
        events.append(row)
        x = R()
        if etype == EV_PROGRESS and x < 0.03:        # client re-sends the same update under a new event id
            counters["event"] += 1
            events.append((f"e{counters['event']:09d}",) + row[1:6] + (row[6] + prng.uniform(1.0, 30.0),) + row[7:])
        elif x < 0.04:                               # exact duplicate delivery of the same event id
            events.append(row[:6] + (row[6] + prng.uniform(0.5, 20.0),) + row[7:])

    def play(u: int, v: int, rho: float, t_start: float, session: str, request: str | None, ctx: str) -> float:
        counters["playback"] += 1
        pid = f"p{counters['playback']:08d}"
        req = None if R() < 0.05 else request      # some clients drop the request id on outcome events
        d = float(v_dur[v])
        short = ctx == SHORT_FORM
        if R() < 0.03 + 0.3 * (1.0 - rho) ** 2:
            frac = prng.uniform(0.0, 0.06)
        else:
            x = 5.0 * (rho - 0.45) + (0.2 if short else -0.8) - cfg.duration_bias * zlogd[v] + prng.gauss(0.0, 0.7)
            frac = 1.0 / (1.0 + math.exp(-x))
            if frac > 0.95:
                frac = 1.0
        w = frac * d
        passes: list[tuple[float, float, bool]] = []          # (content_start, content_end, foreground)
        if w > 0.2:
            if not short and w > 90.0 and frac < 0.9 and R() < 0.15:      # seek forward once
                a = w * prng.uniform(0.3, 0.7)
                gap = prng.uniform(10.0, max(11.0, (d - w) * 0.8))
                passes += [(0.0, a, True), (min(a + gap, d - (w - a)), min(a + gap, d - (w - a)) + (w - a), True)]
            else:
                passes.append((0.0, w, True))
            if short and frac == 1.0 and R() < 0.35 * rho:                 # looping
                for _ in range(prng.randint(0, 2)):
                    passes.append((0.0, d, True))
                passes.append((0.0, d * prng.uniform(0.2, 0.9), True))
            if not short and R() < 0.10 and len(passes) == 1 and w > 60.0:  # tail of playback in background
                cut = w * prng.uniform(0.4, 0.8)
                passes = [(0.0, cut, True), (cut, w, False)]
        lost_progress = R() < 0.01
        emit(u, session, v, EV_PLAY_START, t_start, req, playback=pid, ctx=ctx)
        wall = t_start + 0.5
        cumulative = R() < 0.2
        hb = 5.0 if short else 30.0
        for (cs, ce, fg) in passes:
            step = max(hb, (ce - cs) / 6.0)
            a = cs
            while a < ce - 1e-9:
                b = min(ce, a + step)
                wall += b - a
                if not lost_progress:
                    s_rep, e_rep = (cs if cumulative else a), b
                    x = R()
                    if x < 0.0015:
                        s_rep, e_rep = e_rep, s_rep              # corrupt: reversed interval
                    elif x < 0.003:
                        e_rep = d + 100.0 + e_rep                # corrupt: far beyond the video
                    fg_val: Any = None if R() < 0.01 else fg
                    emit(u, session, v, EV_PROGRESS, wall, req, playback=pid, ctx=ctx, ws=round(s_rep, 3),
                         we=round(e_rep, 3), fg=fg_val)
                a = b
        t_stop = wall + 0.3
        if R() >= 0.02:
            emit(u, session, v, EV_PLAY_END, t_stop, req, playback=pid, ctx=ctx)
        if lost_progress:
            return t_stop
        engaged = frac >= 0.5
        if engaged:
            watched[u].add(v)
            if R() < 0.45 * rho ** 1.5:
                emit(u, session, v, EV_LIKE, t_stop + 0.5, req, playback=pid, ctx=ctx)
            if R() < 0.12 * rho ** 1.5:
                emit(u, session, v, EV_SAVE, t_stop + 0.8, req, playback=pid, ctx=ctx)
            if R() < 0.03 * rho ** 2:
                emit(u, session, v, EV_SHARE, t_stop + 1.0, req, playback=pid, ctx=ctx)
        if engaged or R() < 0.3 * rho:
            pop[v] += 1.0
        if R() < 0.04 * (1.0 - rho) ** 3:
            emit(u, session, v, EV_DISLIKE, t_stop + 0.6, req, playback=pid, ctx=ctx)
        if R() < 0.008 * (1.0 - rho) ** 4:
            emit(u, session, v, EV_BLOCK_CREATOR, t_stop + 0.9, req, playback=pid, ctx=ctx)
            blocked.setdefault(u, set()).add(int(v_creator[v]))
        if R() < cfg.survey_rate:                   # sparse, independent of the outcome (missing completely at random)
            rating = min(5.0, max(1.0, round(1.0 + 4.0 * rho + prng.gauss(0.0, 0.6))))
            emit(u, session, v, EV_SURVEY, t_stop + 2.0, req, playback=pid, ctx=ctx, fb=rating)
        return t_stop

    def session(u: int, t: float) -> None:
        counters["session"] += 1
        sid = f"s{counters['session']:07d}"
        short = R() < f_short[u]
        ctx = SHORT_FORM if short else LONG_FORM
        fmt = v_short if short else ~v_short
        shown: list[int] = []
        t_cur = t
        fol_mask = np.isin(v_creator, followed[u])
        decl = declared_topics[u]
        decl_match = decl[v_t1] | ((v_t2 >= 0) & decl[np.maximum(v_t2, 0)])
        lang_ok = declared_lang[u][v_lang] if declared_lang[u].any() else np.ones(n_v, dtype=bool)
        n_req = min(3, 1 + int(rng.poisson(0.6)))
        for _ in range(n_req):
            pool = fmt & (pub <= t_cur) & (t_cur < avail_until) & elig_ok & lang_ok
            if u in blocked:
                pool &= ~np.isin(v_creator, list(blocked[u]))
            if shown:
                pool[shown] = False
            if watched[u]:
                pool[list(watched[u])] = False
            if u in excluded_idx:
                pool[excluded_idx[u]] = False
            idx = np.flatnonzero(pool)
            if len(idx) == 0:
                return
            m = min(len(idx), cfg.slate_short if short else cfg.slate_long)
            counters["request"] += 1
            rid = f"r{counters['request']:08d}"
            prop = np.nan
            if cfg.uniform_everywhere or (not short and R() < cfg.uniform_fraction_long):
                chosen = rng.choice(idx, size=m, replace=False)
                if short:
                    policy = POLICY_UNIFORM_NOPROP   # reach depends on the user, so no valid propensity exists
                else:
                    policy, prop = POLICY_UNIFORM, m / len(idx)
            else:
                policy = POLICY_BIASED
                score = (cfg.popularity_bias * np.log1p(pop[idx]) + cfg.creator_bias * log_cw[idx]
                         + cfg.freshness_bias * np.exp(-(t_cur - pub[idx]) / (5 * DAY))
                         + cfg.exposure_personalisation * (1.2 * decl_match[idx] + 1.5 * fol_mask[idx])
                         + cfg.exposure_noise * rng.gumbel(size=len(idx)))
                top = np.argpartition(-score, m - 1)[:m]
                chosen = idx[top[np.argsort(-score[top], kind="stable")]]
            rho = oracle.relevance_by_index(u, chosen)
            shown.extend(int(c) for c in chosen)
            if short:
                left = False
                for pos, (v, r) in enumerate(zip(chosen.tolist(), rho.tolist())):
                    # a rare logging bug writes 0.0 as a "propensity"; validation must null it, never trust it
                    p_log = 0.0 if (policy == POLICY_BIASED and R() < 0.005) else prop
                    emit(u, sid, v, EV_IMPRESSION, t_cur, rid, position=pos, ctx=ctx, policy=policy, prop=p_log)
                    if R() < 0.03:
                        t_cur += 1.0                                   # swiped away before playback started
                        if R() < 0.05 * (1.0 - r) ** 2:
                            emit(u, sid, v, EV_NOT_INTERESTED, t_cur, rid, ctx=ctx)
                    else:
                        t_cur = play(u, v, r, t_cur + 0.3, sid, rid, ctx) + 1.0
                    if R() < 0.03 + 0.15 * (1.0 - r):
                        left = True
                        break
                if left:
                    return
            else:
                for pos, v in enumerate(chosen.tolist()):
                    emit(u, sid, v, EV_IMPRESSION, t_cur, rid, position=pos, ctx=ctx, policy=policy, prop=prop)
                t_cur += prng.uniform(3.0, 20.0)
                clicks = 0
                for pos, (v, r) in enumerate(zip(chosen.tolist(), rho.tolist())):
                    if clicks >= 2:
                        break
                    if R() < 0.9 * r / (1.0 + 0.15 * pos):
                        clicks += 1
                        t_cur = play(u, v, r, t_cur, sid, rid, ctx) + prng.uniform(2.0, 15.0)
                    elif R() < 0.01 * (1.0 - r) ** 2:
                        emit(u, sid, v, EV_NOT_INTERESTED, t_cur, rid, ctx=ctx)
                if R() < 0.4:
                    return
            t_cur += prng.uniform(1.0, 10.0)
        if R() < cfg.organic_play_rate:              # direct / search playback with no impression at all
            idx = np.flatnonzero(fmt & (pub <= t_cur) & (t_cur < avail_until) & elig_ok)
            if len(idx):
                v = int(idx[rng.integers(0, len(idx))])
                play(u, v, float(oracle.relevance_by_index(u, np.array([v]))[0]), t_cur, sid, None, ctx)

    for day in range(cfg.n_days):
        day_start = t0 + day * DAY
        pop *= pop_decay
        eligible_users = np.flatnonzero(join < day_start + DAY)
        n_sess = rng.poisson(activity[eligible_users])
        starts: list[tuple[float, int]] = []
        for u, k in zip(eligible_users.tolist(), n_sess.tolist()):
            for _ in range(k):
                hour = (prng.gauss(19.0, 4.0)) % 24.0          # evening-heavy diurnal pattern
                ts = day_start + hour * HOUR
                if ts >= join[u]:
                    starts.append((ts, u))
        starts.sort()
        for ts, u in starts:
            session(u, ts)

    # ---------------------------------------------------------------- assemble tables
    interactions = pd.DataFrame.from_records(events, columns=list(INTERACTION_COLUMNS))
    for col in ("occurred_at", "received_at"):
        interactions[col] = from_epoch_seconds(interactions[col].to_numpy()).to_numpy()
    interactions = interactions.sample(frac=1.0, random_state=cfg.seed).reset_index(drop=True)   # logs arrive unordered

    labels = [["general"] if x >= 0.04 else (["general", "age_restricted"] if x >= 0.02 else ["not_recommendable"])
              for x in label_draw]
    video_rows = []
    for i in range(n_v):
        title, desc = texts[i]
        t2 = int(v_t2[i])
        video_rows.append({
            "video_id": video_ids[i], "creator_id": creator_ids[v_creator[i]], "title": title, "description": desc,
            "language": cfg.languages[v_lang[i]] if rng.random() >= 0.01 else None,
            "topic_ids": [topic_ids[v_t1[i]]] + ([topic_ids[t2]] if t2 >= 0 else []),
            "duration_seconds": float(v_dur[i]), "published_at": pub[i], "available_from": pub[i] if rng.random() < 0.9 else np.nan,
            "available_until": avail_until[i] if np.isfinite(avail_until[i]) else np.nan,
            "content_embedding": v_emb[i].astype("float32") if rng.random() >= 0.01 else None,
            "duplicate_group_id": f"dg{int(dup_group[i]):06d}" if dup_group[i] >= 0 else None,
            "eligibility_labels": labels[i], "metadata_version": 1, "metadata_valid_from": np.nan,
        })
    # later metadata edits: version 2 becomes visible some days after publication
    n_edit = int(cfg.edit_fraction * n_v)
    for i in rng.choice(n_v, size=n_edit, replace=False).tolist():
        valid_from = pub[i] + rng.uniform(1.0, 15.0) * DAY
        if valid_from >= t_end:
            continue
        row = dict(video_rows[i])
        title, desc = make_text(cfg.languages[v_lang[i]], int(v_t1[i]), int(v_t2[i]), int(v_creator[i]))
        row.update({"title": title, "description": desc, "metadata_version": 2, "metadata_valid_from": valid_from})
        if v_emb is not None and row["content_embedding"] is not None:
            row["content_embedding"] = (v_emb[i] + rng.normal(size=cfg.embedding_dim) * 0.05).astype("float32")
        video_rows.append(row)
    videos = pd.DataFrame(video_rows)
    for col in ("published_at", "available_from", "available_until", "metadata_valid_from"):
        videos[col] = from_epoch_seconds(videos[col].to_numpy(dtype="float64")).to_numpy()

    summary = {
        "synthetic": True, "scenario": cfg.scenario, "seed": cfg.seed, "n_users": n_u, "n_videos": n_v,
        "n_video_rows": len(videos), "n_events": len(interactions), "n_requests": counters["request"],
        "n_sessions": counters["session"], "n_playbacks": counters["playback"],
    }
    return SyntheticDataset(videos=videos, interactions=interactions, preferences=preferences, oracle=oracle,
                            config=cfg, summary=summary)
