"""Shared constants: contexts, event types, history interaction types, task names."""
from __future__ import annotations

SHORT_FORM = "short_form"
LONG_FORM = "long_form"
CONTEXTS: tuple[str, ...] = (SHORT_FORM, LONG_FORM)
CONTEXT_INDEX = {c: i for i, c in enumerate(CONTEXTS)}

# --- event types -----------------------------------------------------------
EV_IMPRESSION = "impression"
EV_PLAY_START = "play_start"
EV_PROGRESS = "progress"
EV_PLAY_END = "play_end"
EV_LIKE = "like"
EV_SAVE = "save"
EV_SHARE = "share"
EV_DISLIKE = "dislike"
EV_NOT_INTERESTED = "not_interested"
EV_BLOCK_CREATOR = "block_creator"
EV_SURVEY = "survey_response"

PLAYBACK_EVENTS = (EV_PLAY_START, EV_PROGRESS, EV_PLAY_END)
POSITIVE_FEEDBACK_EVENTS = (EV_LIKE, EV_SAVE, EV_SHARE)
NEGATIVE_FEEDBACK_EVENTS = (EV_DISLIKE, EV_NOT_INTERESTED, EV_BLOCK_CREATOR)
EVENT_TYPES: tuple[str, ...] = (
    EV_IMPRESSION, *PLAYBACK_EVENTS, *POSITIVE_FEEDBACK_EVENTS, *NEGATIVE_FEEDBACK_EVENTS, EV_SURVEY,
)

# --- observation states of an impression -----------------------------------
# "never shown" is not a row state: it is the absence of an impression row.
STATE_INCOMPLETE = "incomplete"            # window not matured, or play with no usable observation
STATE_NO_PLAY = "impression_no_play"       # shown, matured, no play observed
STATE_EARLY_SKIP = "early_skip"            # play observed, abandoned almost immediately
STATE_PARTIAL = "partial_view"             # play observed, neither early skip nor meaningful
STATE_POSITIVE = "positive"                # meaningful view or like/save/share
STATE_NEGATIVE = "explicit_negative"       # dislike / not interested / creator block
STATES = (STATE_INCOMPLETE, STATE_NO_PLAY, STATE_EARLY_SKIP, STATE_PARTIAL, STATE_POSITIVE, STATE_NEGATIVE)

# --- history interaction types (0 is padding) ------------------------------
H_PAD = 0
H_MEANINGFUL = 1
H_PARTIAL = 2
H_EARLY_SKIP = 3
H_POSITIVE_FEEDBACK = 4
H_NEGATIVE_FEEDBACK = 5
N_HISTORY_TYPES = 6
H_POSITIVE_TYPES = (H_MEANINGFUL, H_PARTIAL, H_POSITIVE_FEEDBACK)
H_NEGATIVE_TYPES = (H_EARLY_SKIP, H_NEGATIVE_FEEDBACK)
H_STRONG_POSITIVE = (H_MEANINGFUL, H_POSITIVE_FEEDBACK)

# --- ranking tasks ----------------------------------------------------------
T_MEANINGFUL = "meaningful"
T_DURATION = "duration"
T_LIKE = "like_or_save"
T_SATISFACTION = "satisfaction"
T_NEGATIVE = "negative"
TASKS: tuple[str, ...] = (T_MEANINGFUL, T_DURATION, T_LIKE, T_SATISFACTION, T_NEGATIVE)
BINARY_TASKS = (T_MEANINGFUL, T_LIKE, T_NEGATIVE)
BOUNDED_TASKS = (T_DURATION, T_SATISFACTION)

# --- vocabulary conventions -------------------------------------------------
PAD = 0
UNK = 1

# --- candidate sources -------------------------------------------------------
SRC_TWO_TOWER = "two_tower"
SRC_CONTENT = "content_similarity"
SRC_FOLLOWED = "followed_creators"
SRC_TOPICS = "selected_topics"
SRC_RECENT = "recent"
SRC_POPULARITY = "popularity"
SRC_EXPLORATION = "exploration"
SOURCES = (SRC_TWO_TOWER, SRC_CONTENT, SRC_FOLLOWED, SRC_TOPICS, SRC_RECENT, SRC_POPULARITY, SRC_EXPLORATION)
PERSONALISED_SOURCES = (SRC_TWO_TOWER, SRC_CONTENT, SRC_FOLLOWED, SRC_TOPICS)

DAY = 86400.0
HOUR = 3600.0
