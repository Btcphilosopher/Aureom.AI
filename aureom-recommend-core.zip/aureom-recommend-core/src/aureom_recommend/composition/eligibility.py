"""Hard eligibility. These rules are never relaxed and are applied twice: before candidate
generation and again on the composed feed.

A catalogue row is eligible for a request at time ``t`` iff

* it is the metadata version visible at ``t`` and the video is published and available,
* it belongs to the requested surface (short-form / long-form),
* it passes the configured eligibility-label rules,
* its language is one of the user's preferred languages (``language_filter = "strict"`` and
  the user declared at least one; videos with unknown language are then excluded),
* its creator is not blocked by the user (preference snapshot or block events before ``t``),
* it is not an excluded video, not a video the user gave explicit negative feedback on,
  not previously recommended in this session, and - with ``consumed_handling = "exclude"`` -
  neither consumed nor a duplicate of something consumed.

A block is an exclusion: no score can bring a blocked creator back.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Iterable

import numpy as np

from ..config import Config
from ..data.catalogue import Catalogue

if TYPE_CHECKING:
    from ..features.state import RequestState


def hard_eligibility_mask(state: "RequestState", catalogue: Catalogue, config: Config,
                          previously_recommended: Iterable[str] = ()) -> np.ndarray:
    el = config.eligibility
    mask = catalogue.live_mask(state.t) & catalogue.context_mask(state.context)
    mask &= catalogue.label_mask(el.excluded_labels, el.required_labels)
    if el.language_filter == "strict" and len(state.preferred_language_idx):
        mask &= np.isin(catalogue.language_index, state.preferred_language_idx)
    if len(state.blocked_creator_idx):
        mask &= ~np.isin(catalogue.creator_index, state.blocked_creator_idx)
    banned = [state.excluded_video_idx]
    if el.exclude_negative_feedback_videos:
        banned.append(state.negative_video_idx)
    prev = catalogue.video_idx(previously_recommended)
    banned.append(prev[prev >= 0])
    banned_idx = np.concatenate(banned) if banned else np.array([], dtype="int64")
    if len(banned_idx):
        mask &= ~np.isin(catalogue.video_index, banned_idx)
    if config.composition.consumed_handling == "exclude" and len(state.consumed_video_idx):
        mask &= ~np.isin(catalogue.duplicate_group, catalogue.video_group[state.consumed_video_idx])
    return mask
