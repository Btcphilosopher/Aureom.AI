"""Extension point for learned exploration (contextual bandits, reinforcement learning).

Nothing here is implemented on purpose. The shipped system explores only through seeded
uniform sampling (retrieval/candidates.py, composition/rerank.py). A learned exploration
policy should be plugged in *only after*:

1. the serving path logs, for every exploratory decision, the action set and the exact
   probability of the chosen action (``selection_propensity`` with a ``logging_policy_id``),
2. off-policy evaluation with those propensities has been validated
   (evaluation/propensity.py reports "unavailable" until then).
"""
from __future__ import annotations

from typing import Any, Protocol, Sequence

import numpy as np


class SlotPolicy(Protocol):
    """Chooses the item for an exploration slot and reports the probability of that choice."""

    policy_id: str

    def choose(self, context_features: np.ndarray, candidate_features: np.ndarray, feasible: Sequence[int],
               rng: np.random.Generator) -> tuple[int, float]:
        """Return (index into ``feasible``, probability with which it was chosen)."""
        ...

    def update(self, logged_decisions: Any) -> None:
        """Learn from logged (context, action, propensity, reward) tuples."""
        ...


class ContextualBanditPolicy:
    """Placeholder: deliberately not implemented in the initial algorithm."""

    policy_id = "contextual_bandit_unimplemented"

    def choose(self, *args: Any, **kwargs: Any) -> tuple[int, float]:
        raise NotImplementedError("contextual bandits are outside the initial implementation; see module docstring")

    def update(self, *args: Any, **kwargs: Any) -> None:
        raise NotImplementedError("contextual bandits are outside the initial implementation; see module docstring")
