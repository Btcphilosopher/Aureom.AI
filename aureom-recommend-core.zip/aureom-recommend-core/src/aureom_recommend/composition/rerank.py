r"""Constrained greedy feed composition.

At each position the next item is the feasible candidate with the highest

.. math::
    S_{\text{feed}}(v \mid A) = S(u, v, c) - \lambda_d \max_{a \in A} \operatorname{sim}(v, a) + \lambda_f F(v)

where ``A`` is the set already selected, ``sim`` is the cosine similarity of content vectors
clipped to [0, 1], and ``F(v) = 0.5^{age / half-life}`` in (0, 1] is the freshness term.
With ``consumed_handling = "demote"`` a fixed penalty is subtracted for consumed videos.

Hard rules - never relaxed
    Eligibility (availability, surface, language, labels, blocks, exclusions, previously
    recommended, consumed when ``"exclude"``) and exact duplicates: at most one video per
    ``duplicate_group_id``.

Soft rules - relaxed one at a time, in ``relaxation_order``, only when no feasible candidate
remains and the feed is not full
    1. ``topic_concentration``  at most ``ceil(max_topic_share * k)`` items per topic
    2. ``creator_cap``          at most ``max_per_creator`` items per creator
    3. ``near_duplicate``       no item with content similarity above the threshold to a chosen item

Exploration: up to ``max_exploration_slots`` configured positions are filled by a seeded
uniform draw among the feasible candidates that came *only* from the exploration source.
The item records the size of that choice set and ``1 / size``. This is the conditional
probability of the draw at that slot, **not** the probability of the item (or the slate)
being shown; slate-level propensities are not computed and are reported as ``None``.

This is a greedy heuristic. It is not a globally optimal slate and is not described as one.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np

from ..config import CompositionConfig
from ..constants import DAY, SRC_EXPLORATION


@dataclass
class ComposedFeed:
    order: list[int]                                   # indices into the candidate arrays, in feed order
    feed_scores: list[float]
    diversity_penalties: list[float]
    freshness_bonuses: list[float]
    consumed_penalties: list[float]
    exploration: list[Optional[dict[str, Any]]]
    relaxations: list[dict[str, Any]] = field(default_factory=list)


def compose_feed(scores: np.ndarray, *, creators: np.ndarray, topic_matrix: np.ndarray, groups: np.ndarray,
                 content_vectors: np.ndarray, age_seconds: np.ndarray, consumed: np.ndarray,
                 sources: list[tuple[str, ...]], exploration_details: list[Optional[dict[str, Any]]], k: int,
                 config: CompositionConfig, rng: np.random.Generator) -> ComposedFeed:
    """Greedy constrained selection over ``n`` candidates (all arrays are aligned, length ``n``)."""
    n = len(scores)
    out = ComposedFeed([], [], [], [], [], [])
    if n == 0 or k <= 0:
        return out
    base = np.asarray(scores, dtype="float64")
    fresh = config.lambda_freshness * np.power(0.5, np.maximum(age_seconds, 0.0) / (config.freshness_half_life_days * DAY))
    cons_pen = np.where(consumed, config.consumed_penalty, 0.0) if config.consumed_handling == "demote" else np.zeros(n)
    max_sim = np.zeros(n)
    available = np.ones(n, dtype=bool)
    creator_count: dict[int, int] = {}
    topic_count = np.zeros(topic_matrix.shape[1], dtype="int64")
    topic_cap = max(1, int(np.ceil(config.max_topic_share * k)))
    explore_only = np.array([s == (SRC_EXPLORATION,) for s in sources], dtype=bool)
    slots = set(sorted(p for p in config.exploration_positions if 0 <= p < k)[:max(0, config.max_exploration_slots)])
    active = {name: True for name in ("topic_concentration", "creator_cap", "near_duplicate")}
    order_to_relax = [r for r in config.relaxation_order if r in active]
    order_to_relax += [r for r in active if r not in order_to_relax]

    def feasible() -> np.ndarray:
        ok = available.copy()
        if active["creator_cap"] and creator_count:
            full = [c for c, cnt in creator_count.items() if cnt >= config.max_per_creator]
            if full:
                ok &= ~np.isin(creators, full)
        if active["topic_concentration"]:
            full_topics = topic_count >= topic_cap
            if full_topics.any():
                ok &= ~topic_matrix[:, full_topics].any(axis=1)
        if active["near_duplicate"]:
            ok &= max_sim <= config.near_duplicate_similarity
        return ok

    while len(out.order) < k and available.any():
        position = len(out.order)
        ok = feasible()
        info: Optional[dict[str, Any]] = None
        pick = -1
        if position in slots:
            pool = np.flatnonzero(ok & explore_only)
            if len(pool):
                pick = int(pool[rng.integers(0, len(pool))])
                info = {"is_exploration": True, **(exploration_details[pick] or {}),
                        "slot_choice_set_size": int(len(pool)), "slot_choice_probability": 1.0 / len(pool),
                        "slate_probability": None}
        if pick < 0:
            if not ok.any():
                relaxable = [r for r in order_to_relax if active[r]]
                if not relaxable:
                    break                                   # only hard rules remain: return a shorter feed
                active[relaxable[0]] = False
                out.relaxations.append({"position": position, "relaxed": relaxable[0]})
                continue
            value = base - config.lambda_diversity * max_sim + fresh - cons_pen
            cand = np.flatnonzero(ok)
            pick = int(cand[np.lexsort((cand, -value[cand]))[0]])
        out.order.append(pick)
        out.diversity_penalties.append(float(config.lambda_diversity * max_sim[pick]))
        out.freshness_bonuses.append(float(fresh[pick]))
        out.consumed_penalties.append(float(cons_pen[pick]))
        out.feed_scores.append(float(base[pick] - config.lambda_diversity * max_sim[pick] + fresh[pick] - cons_pen[pick]))
        out.exploration.append(info)
        available &= groups != groups[pick]                 # hard: one item per duplicate group
        creator_count[int(creators[pick])] = creator_count.get(int(creators[pick]), 0) + 1
        topic_count += topic_matrix[pick]
        max_sim = np.maximum(max_sim, np.clip(content_vectors @ content_vectors[pick], 0.0, 1.0))
    return out
