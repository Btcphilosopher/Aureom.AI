"""Ranking features for (request state, candidate rows).

The same function builds training rows (for logged impressions, as of the logged request)
and serving rows (for generated candidates), so offline and online definitions cannot drift.
Everything is derived from the point-in-time :class:`RequestState`, the catalogue row that
was visible at request time, and the frozen retriever.

Position: the logged position is a *training-only* feature that absorbs position bias; at
serving time every candidate is scored at position 0.
"""
from __future__ import annotations

from typing import Optional

import numpy as np

from ..config import Config
from ..constants import DAY, H_NEGATIVE_TYPES, H_POSITIVE_TYPES
from ..data.catalogue import Catalogue
from ..features.space import VideoFeatures
from ..features.state import RequestState, history_weights
from ..retrieval.candidates import content_profile

DENSE_FEATURES: tuple[str, ...] = (
    "retrieval_score", "content_similarity", "has_content_profile", "selected_topic_overlap", "creator_followed",
    "history_topic_affinity_pos", "history_topic_affinity_neg", "creator_history_pos", "creator_history_neg",
    "has_language_preference", "language_match", "consumed_before",
    "log_history_len", "is_new_user", "has_selected_topics", "has_followed_creators", "personalised",
    "z_log_duration", "is_short", "log_age_days", "log_popularity", "positive_rate", "negative_rate",
    "log_impressions", "creator_positive_rate", "log_creator_impressions", "n_topics", "has_content_embedding",
    "context", "log_position",
)
POSITION_FEATURE = DENSE_FEATURES.index("log_position")


def _user_aggregates(state: RequestState, catalogue: Catalogue) -> dict[str, np.ndarray]:
    if "rank_aggregates" not in state.cache:
        items = state.items
        n_t, n_c = catalogue.topic_matrix.shape[1], catalogue.n_creators
        if len(items):
            w_pos, w_neg = history_weights(items, state.t, half_life_days=14.0)
            tm = catalogue.topic_matrix[items.row]
            creators = catalogue.creator_index[items.row]
            agg = {
                "topic_pos": (w_pos @ tm) / max(w_pos.sum(), 1e-9), "topic_neg": (w_neg @ tm) / max(w_neg.sum(), 1e-9),
                "creator_pos": np.bincount(creators[np.isin(items.type, H_POSITIVE_TYPES)], minlength=n_c).astype("float64"),
                "creator_neg": np.bincount(creators[np.isin(items.type, H_NEGATIVE_TYPES)], minlength=n_c).astype("float64"),
            }
        else:
            agg = {"topic_pos": np.zeros(n_t), "topic_neg": np.zeros(n_t), "creator_pos": np.zeros(n_c),
                   "creator_neg": np.zeros(n_c)}
        state.cache["rank_aggregates"] = agg
    return state.cache["rank_aggregates"]


def ranking_features(state: RequestState, rows: np.ndarray, catalogue: Catalogue, features: VideoFeatures,
                     video_embeddings: np.ndarray, user_embedding: np.ndarray, config: Config,
                     position: Optional[np.ndarray] = None) -> dict[str, np.ndarray]:
    """Feature arrays for ``rows`` (dense matrix, categorical ids and frozen tower embeddings)."""
    n = len(rows)
    vid = catalogue.video_index[rows]
    creators = catalogue.creator_index[rows]
    stats = state.stats
    agg = _user_aggregates(state, catalogue)
    tm = catalogue.topic_matrix[rows]
    n_topics = np.maximum(tm.sum(axis=1), 1)
    profile = content_profile(state, features.content_vectors, config)
    v_emb = video_embeddings[rows]
    d = np.zeros((n, len(DENSE_FEATURES)), dtype="float32")
    d[:, 0] = v_emb @ user_embedding
    if profile is not None:
        d[:, 1] = features.content_vectors[rows] @ profile
        d[:, 2] = 1.0
    if len(state.selected_topic_cat_idx):
        d[:, 3] = tm[:, state.selected_topic_cat_idx].sum(axis=1) / n_topics
        d[:, 14] = 1.0
    if len(state.followed_creator_idx):
        d[:, 4] = np.isin(creators, state.followed_creator_idx)
        d[:, 15] = 1.0
    d[:, 5] = (tm @ agg["topic_pos"]) / n_topics
    d[:, 6] = (tm @ agg["topic_neg"]) / n_topics
    d[:, 7] = np.log1p(agg["creator_pos"][creators])
    d[:, 8] = np.log1p(agg["creator_neg"][creators])
    if len(state.preferred_language_idx):
        d[:, 9] = 1.0
        d[:, 10] = np.isin(catalogue.language_index[rows], state.preferred_language_idx)
    d[:, 11] = np.isin(vid, state.consumed_video_idx)
    d[:, 12] = np.log1p(len(state.items))
    d[:, 13] = float(state.is_new_user)
    d[:, 16] = float(state.personalised)
    d[:, 17] = features.dense[rows, -2]
    d[:, 18] = catalogue.is_short[rows]
    d[:, 19] = np.log1p(np.maximum(state.t - catalogue.published_at[rows], 0.0) / DAY)
    d[:, 20] = np.log1p(stats.popularity[vid])
    d[:, 21] = stats.positive_rate[vid]
    d[:, 22] = stats.negative_rate[vid]
    d[:, 23] = np.log1p(stats.impressions[vid])
    d[:, 24] = stats.creator_positive_rate[creators]
    d[:, 25] = np.log1p(stats.creator_impressions[creators])
    d[:, 26] = tm.sum(axis=1)
    d[:, 27] = catalogue.has_content_embedding[rows]
    d[:, 28] = state.context_idx
    if position is not None and config.ranker.use_position_feature:
        d[:, POSITION_FEATURE] = np.log1p(np.nan_to_num(np.asarray(position, dtype="float64"), nan=0.0))
    return {
        "dense": d, "creator": features.creator[rows], "language": features.language[rows],
        "context": np.full(n, state.context_idx, dtype="int64"),
        "user_vec": np.repeat(user_embedding[None, :].astype("float32"), n, axis=0), "video_vec": v_emb.astype("float32"),
    }


def concat_features(parts: list[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    return {k: np.concatenate([p[k] for p in parts]) for k in parts[0]}
