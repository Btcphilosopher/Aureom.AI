"""Multitask ranking network: shared trunk, one logit per task."""
from __future__ import annotations

from dataclasses import asdict, dataclass

import torch
import torch.nn as nn

from ..config import RankerConfig
from ..constants import TASKS


@dataclass
class RankerDims:
    n_dense: int
    tower_dim: int
    n_creators: int
    n_languages: int
    n_contexts: int = 2

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


class MultiTaskRanker(nn.Module):
    def __init__(self, dims: RankerDims, cfg: RankerConfig) -> None:
        super().__init__()
        self.dims, self.cfg = dims, cfg
        self.creator_emb = nn.Embedding(dims.n_creators, 16, padding_idx=0)
        self.language_emb = nn.Embedding(dims.n_languages, 4, padding_idx=0)
        self.context_emb = nn.Embedding(dims.n_contexts, 4)
        width = dims.n_dense + 16 + 4 + 4 + (3 * dims.tower_dim if cfg.use_tower_embeddings else 0)
        layers: list[nn.Module] = []
        for h in cfg.hidden_dims:
            layers += [nn.Linear(width, h), nn.ReLU(), nn.Dropout(cfg.dropout)]
            width = h
        self.trunk = nn.Sequential(*layers)
        self.heads = nn.Linear(width, len(TASKS))

    def forward(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        parts = [batch["dense"], self.creator_emb(batch["creator"]), self.language_emb(batch["language"]),
                 self.context_emb(batch["context"])]
        if self.cfg.use_tower_embeddings:
            u, v = batch["user_vec"], batch["video_vec"]
            parts += [u, v, u * v]
        return self.heads(self.trunk(torch.cat(parts, dim=1)))
