r"""Masked multitask loss.

.. math::
    \mathcal{L} = \sum_t \alpha_t\,
        \frac{\sum_i m_{it}\,\ell_t(y_{it}, \hat y_{it})}{\max(1, \sum_i m_{it})}
        + \lambda \lVert\theta\rVert_2^2

``m_it`` is 1 only where task ``t``'s label was observed and is usable (see data/labels.py).
A task with no valid label in the batch contributes exactly zero and is reported as skipped.

Per-task losses: binary heads (meaningful, like_or_save, negative) use binary cross-entropy
on logits. Bounded heads (duration, satisfaction) have targets in [0, 1] and use the same
cross-entropy with *soft* targets, which is a proper scoring rule for the mean of a [0, 1]
variable and keeps predictions inside the bounds.

Class imbalance: an optional positive weight ``w_t`` may be applied to binary heads. That
inflates predicted odds by ``w_t``, so the ranker subtracts ``log w_t`` from the logit at
prediction time (prior correction, see ranking/ranker.py); weights never silently distort
probabilities.
"""
from __future__ import annotations

from typing import Mapping, Optional, Sequence

import torch
import torch.nn.functional as F


def masked_multitask_loss(logits: torch.Tensor, targets: torch.Tensor, masks: torch.Tensor, tasks: Sequence[str],
                          task_weights: Mapping[str, float], pos_weights: Optional[Mapping[str, float]] = None,
                          ) -> tuple[torch.Tensor, dict[str, float]]:
    """Return (weighted loss without the L2 term, per-task mean losses for tasks with labels)."""
    total = logits.new_zeros(())
    per_task: dict[str, float] = {}
    for j, task in enumerate(tasks):
        m = masks[:, j]
        n = m.sum()
        if n.item() == 0:
            continue                                        # no usable labels for this task in the batch
        pw = None
        if pos_weights and pos_weights.get(task, 1.0) != 1.0:
            pw = logits.new_tensor(float(pos_weights[task]))
        ell = F.binary_cross_entropy_with_logits(logits[:, j], targets[:, j], reduction="none", pos_weight=pw)
        task_loss = (ell * m).sum() / torch.clamp(n, min=1.0)
        total = total + float(task_weights.get(task, 1.0)) * task_loss
        per_task[task] = float(task_loss.detach())
    return total, per_task


def l2_penalty(model: torch.nn.Module) -> torch.Tensor:
    """Squared L2 norm of the linear weight matrices (biases and embedding tables are excluded)."""
    terms = [(mod.weight ** 2).sum() for mod in model.modules() if isinstance(mod, torch.nn.Linear)]
    return torch.stack(terms).sum() if terms else torch.zeros(())
