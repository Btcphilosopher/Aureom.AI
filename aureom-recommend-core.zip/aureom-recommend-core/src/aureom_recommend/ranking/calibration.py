"""Post-hoc calibration on a separate validation window.

Each head gets a Platt map ``p = sigmoid(a * z + b)`` with ``a > 0`` (monotone, so the
within-head ordering is unchanged), fitted by minimising cross-entropy on the calibration
window. A head is calibrated only when label support is sufficient:

* binary heads: at least ``min_examples`` usable labels and ``min_class_support`` of each class
* bounded heads: at least ``min_examples`` usable labels

Otherwise the head keeps the identity map and the reason is recorded.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
from scipy.optimize import minimize


@dataclass
class PlattCalibrator:
    a: float = 1.0
    b: float = 0.0
    fitted: bool = False
    status: str = "identity"
    n_examples: int = 0

    def apply(self, logits: np.ndarray) -> np.ndarray:
        z = np.clip(self.a * np.asarray(logits, dtype="float64") + self.b, -35.0, 35.0)
        return 1.0 / (1.0 + np.exp(-z))

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "PlattCalibrator":
        return cls(**data)


def fit_platt(logits: np.ndarray, targets: np.ndarray, binary: bool, min_examples: int = 200,
              min_class_support: int = 30) -> PlattCalibrator:
    """Fit ``sigmoid(a z + b)`` to (possibly soft) targets in [0, 1]."""
    z = np.asarray(logits, dtype="float64")
    y = np.asarray(targets, dtype="float64")
    n = len(z)
    if n < min_examples:
        return PlattCalibrator(status=f"identity: only {n} labelled examples (< {min_examples})", n_examples=n)
    if binary:
        n_pos = int((y > 0.5).sum())
        if min(n_pos, n - n_pos) < min_class_support:
            return PlattCalibrator(status=f"identity: minority class has {min(n_pos, n - n_pos)} examples "
                                          f"(< {min_class_support})", n_examples=n)

    def objective(theta: np.ndarray) -> tuple[float, np.ndarray]:
        a, b = np.exp(theta[0]), theta[1]
        s = np.clip(a * z + b, -35.0, 35.0)
        p = 1.0 / (1.0 + np.exp(-s))
        loss = np.mean(np.logaddexp(0.0, s) - y * s)
        g = p - y
        return float(loss), np.array([np.mean(g * z) * a, np.mean(g)])

    res = minimize(objective, x0=np.zeros(2), jac=True, method="L-BFGS-B", bounds=[(-5.0, 5.0), (-20.0, 20.0)])
    return PlattCalibrator(a=float(np.exp(res.x[0])), b=float(res.x[1]), fitted=True, status="fitted", n_examples=n)
