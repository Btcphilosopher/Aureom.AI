"""Trained ranker wrapper: standardisation, prior correction, calibration, prediction."""
from __future__ import annotations

from typing import Any, Optional

import numpy as np
import torch

from ..config import Config
from ..constants import BINARY_TASKS, TASKS
from .calibration import PlattCalibrator
from .model import MultiTaskRanker, RankerDims

_LONG = {"creator", "language", "context"}


def feature_tensors(features: dict[str, np.ndarray], mean: np.ndarray, std: np.ndarray,
                    device: torch.device | str = "cpu") -> dict[str, torch.Tensor]:
    out: dict[str, torch.Tensor] = {}
    for k, v in features.items():
        if k == "dense":
            v = np.clip((v - mean) / std, -6.0, 6.0)
        out[k] = torch.as_tensor(v, dtype=torch.long if k in _LONG else torch.float32, device=device)
    return out


class Ranker:
    def __init__(self, model: MultiTaskRanker, dims: RankerDims, config: Config, dense_mean: np.ndarray,
                 dense_std: np.ndarray, pos_weights: Optional[dict[str, float]] = None,
                 calibrators: Optional[dict[str, PlattCalibrator]] = None, device: torch.device | str = "cpu",
                 history: Optional[list[dict[str, Any]]] = None) -> None:
        self.model, self.dims, self.config = model.to(device).eval(), dims, config
        self.dense_mean = np.asarray(dense_mean, dtype="float32")
        self.dense_std = np.asarray(dense_std, dtype="float32")
        self.pos_weights = {t: float((pos_weights or {}).get(t, 1.0)) for t in TASKS}
        self.calibrators = calibrators or {t: PlattCalibrator() for t in TASKS}
        self.device = torch.device(device)
        self.history = history or []

    @torch.no_grad()
    def logits(self, features: dict[str, np.ndarray], batch_size: int = 8192) -> np.ndarray:
        """Head logits with the positive-weight prior correction applied (``z - log w``)."""
        self.model.eval()
        n = len(features["dense"])
        out = []
        for s in range(0, n, batch_size):
            batch = feature_tensors({k: v[s:s + batch_size] for k, v in features.items()}, self.dense_mean,
                                    self.dense_std, self.device)
            out.append(self.model(batch).cpu().numpy())
        z = np.concatenate(out).astype("float64") if out else np.zeros((0, len(TASKS)))
        for j, task in enumerate(TASKS):
            if task in BINARY_TASKS and self.pos_weights[task] != 1.0:
                z[:, j] -= np.log(self.pos_weights[task])
        return z

    def predict(self, features: dict[str, np.ndarray], calibrated: bool = True) -> dict[str, np.ndarray]:
        """Per-head predictions in [0, 1]."""
        z = self.logits(features)
        if calibrated:
            return {task: self.calibrators[task].apply(z[:, j]) for j, task in enumerate(TASKS)}
        return {task: 1.0 / (1.0 + np.exp(-np.clip(z[:, j], -35, 35))) for j, task in enumerate(TASKS)}
