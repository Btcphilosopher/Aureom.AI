r"""Explicit, versioned ranking policy.

.. math::
    S(u, v, c) = w_m\,p_{\text{meaningful}} + w_d\,\hat r_{\text{duration}} + w_p\,p_{\text{positive}}
                 + w_s\,\hat s_{\text{satisfaction}} - w_n\,p_{\text{negative}}

All five components are calibrated head outputs on a common [0, 1] scale:

=================  ==========================================================================
``meaningful``     P(meaningful view | impression)
``duration``       E[duration-adjusted viewing | impression]  (quantile scale, 0 = no play)
``positive``       P(like, save or share | impression)
``satisfaction``   E[(rating - min) / (max - min) | a survey response is observed]
``negative``       P(dislike, not-interested or creator block | impression)
=================  ==========================================================================

Being on one scale does not make the components equally frequent (a like is far rarer than a
meaningful view), so the weights also encode how much one unit of each outcome is worth.
They are configuration, not a finding: no weighting is claimed to be optimal in general.
Raw watch time and session length are deliberately *not* components.

A user's block is not part of this score - blocked creators are removed by hard eligibility
and cannot be bought back by any combination of terms.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np

from ..config import PolicyConfig
from ..constants import T_DURATION, T_LIKE, T_MEANINGFUL, T_NEGATIVE, T_SATISFACTION


@dataclass(frozen=True)
class RankingPolicy:
    version: str
    weights: Mapping[str, float]          # signed weight per head

    @classmethod
    def from_config(cls, cfg: PolicyConfig) -> "RankingPolicy":
        return cls(version=cfg.version, weights={
            T_MEANINGFUL: cfg.w_meaningful, T_DURATION: cfg.w_duration, T_LIKE: cfg.w_positive,
            T_SATISFACTION: cfg.w_satisfaction, T_NEGATIVE: -cfg.w_negative})

    def score(self, predictions: Mapping[str, np.ndarray]) -> tuple[np.ndarray, dict[str, np.ndarray]]:
        """Return (S, per-head signed contributions). ``S`` is exactly the sum of the contributions."""
        contributions = {task: float(w) * np.asarray(predictions[task], dtype="float64")
                         for task, w in self.weights.items()}
        total = np.sum(list(contributions.values()), axis=0) if contributions else np.zeros(0)
        return total, contributions
