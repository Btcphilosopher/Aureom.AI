# Dependencies and compatibility

## Versions the reported results were produced with

| package | version | role |
|---|---|---|
| Python | 3.13 | |
| PyTorch | 2.15 (CPU execution) | two-tower retriever, multitask ranker |
| NumPy | 2.5 | arrays, exact retrieval fallback |
| pandas | 3.1 | tables |
| PyArrow | 26.0 | Parquet |
| scikit-learn | 1.9 | TF-IDF, truncated SVD |
| SciPy | 1.18 | sparse matrices, L-BFGS for calibration |
| faiss-cpu | 1.16 | optional approximate / exact inner-product index |
| Matplotlib | 3.11 | evaluation plots |
| pytest | 9.2 | tests |

`pyproject.toml` declares lower bounds (Python ≥ 3.11, pandas ≥ 2.2, torch ≥ 2.2, …). Only the
versions in the table were executed; older versions inside the bounds are expected to work but
were not run.

## Compatibility notes checked against official sources

Sources: the projects' own documentation and release-note files and PyPI metadata (URLs below).

- **pandas 3.x.** Strings are inferred as the new `str` dtype (PyArrow-backed when PyArrow is
  installed); Copy-on-Write is the only mode; datetime resolution is inferred and is often
  microseconds rather than nanoseconds; PyArrow remains optional; Python ≥ 3.11 is required.
  The code therefore never assumes `object` strings or nanosecond integers: identifiers are
  normalised to Python strings, and all time arithmetic goes through
  `data/timeutil.py` (epoch seconds, unit-independent). An early version of `as_epoch` divided
  `Timestamp.value` by the timestamp's unit and was caught by the test-suite; it now uses
  `total_seconds()`.
  — `pandas/doc/source/whatsnew/v3.0.0.rst`, <https://pypi.org/pypi/pandas/3.1.1/json>
- **FAISS.** `IndexFlatIP` is exact inner-product search; `IndexHNSWFlat(d, M,
  faiss.METRIC_INNER_PRODUCT)` is supported from Python; missing results are returned as `-1`
  (the index wrapper filters them). From 1.14.2 the `faiss-cpu` PyPI package is published by Meta
  AI Research; earlier wheels were community-built. FAISS is optional here: without it the exact
  NumPy index is used.
  — <https://github.com/facebookresearch/faiss/wiki/Faiss-indexes>,
  <https://github.com/facebookresearch/faiss/wiki/FAQ>, <https://pypi.org/pypi/faiss-cpu/1.16.0/json>
- **PyTorch.** `torch.load` defaults to `weights_only=True` since 2.6; artefacts are saved as
  plain state dicts and tensors and loaded with `weights_only=True` explicitly. The default Linux
  wheel on PyPI depends on CUDA packages; a CPU-only build is available from
  `https://download.pytorch.org/whl/cpu`. All reported results were computed on CPU
  (`torch.cuda.is_available()` was false); `device = "cuda"` or `"auto"` enables a GPU when one
  exists and falls back to CPU otherwise. Full Python 3.13 support starts with torch 2.6.
  — `pytorch/torch/serialization.py` (v2.15.0), `pytorch/RELEASE.md`, <https://pypi.org/pypi/torch/2.15.0/json>
- **scikit-learn.** `TfidfVectorizer` and `TruncatedSVD(random_state=...)` are stable public API
  in 1.9; the fitted objects are stored with joblib, so an artefact should be loaded with the
  scikit-learn version recorded in its manifest.
  — `scikit-learn/doc/api_reference.py` (1.9.1), <https://pypi.org/pypi/scikit-learn/1.9.1/json>
- **NumPy random streams.** `numpy.random.Generator` streams are only guaranteed stable for the
  same NumPy version and platform (NEP 19). Results are reproducible given the seed *and* the
  library versions above; a different NumPy release may generate a different synthetic world.
  — `numpy/doc/neps/nep-0019-rng-policy.rst`, `numpy/doc/source/reference/random/compatibility.rst`

## Reproducibility

- One `seed` in the config drives model initialisation, shuffling, negative sampling, evaluation
  sampling and bootstrap; the simulator has its own seed.
- `recommend` is deterministic given its arguments (the exploration generator is seeded from
  `seed`, user, context and time).
- Multi-threaded floating-point reductions in PyTorch can differ in the last bits between
  machines; set `torch_threads = 1` for bit-stable training at the cost of speed.
- Artefacts record the config hash, label / policy / duration-baseline versions, feature and task
  lists, tensor dimensions, library versions and a SHA-256 of every file;
  `load_artefacts` refuses mismatches.
