# Evaluation method

Three stages are evaluated separately. **Every metric states its relevance label and candidate
universe; metrics with different universes are never compared with each other.**

| stage | module | relevance label | candidate universe |
|---|---|---|---|
| retrieval (scorers) | `evaluation/retrieval_eval.py` | future positive impressions of the user within the horizon | full eligible catalogue |
| candidate generation | same | same | the unordered candidate set vs. the eligible catalogue |
| ranking | `evaluation/ranking_eval.py` | the logged impression matured positive; per-head observed labels | the logged slate |
| feed | `evaluation/offline.py` | future positive impressions of the user within the horizon | full eligible catalogue |

"Positive" = meaningful view or like/save/share on a matured impression. "Eligible" = hard
eligibility only (availability, surface, language, labels, blocks, exclusions).

## Metrics

Recall@K, NDCG@K (binary gain, ideal over `min(K, |relevant|)`), MRR · Brier score and expected
calibration error (10 equal-width bins) before and after calibration, ROC AUC for binary heads ·
MAE / RMSE for the duration target and satisfaction · catalogue and creator coverage, creator
exposure Gini · intra-list diversity (1 − mean pairwise content cosine) · duplicate rate ·
creator concentration (largest creator share in a feed) · new-video exposure · latency
(single request, single process).

Slices: short-form / long-form · new / established users · sparse / dense histories ·
new / established videos (recall restricted to relevant videos of that age).

Intervals: 95 % percentile bootstrap that resamples **users** (requests of one user are
correlated; resampling requests would understate the uncertainty).

## Rolling replay

Test requests are the logged requests of the test window, in time order. For each one the
recommender is called with `as_of` = the request time; histories, blocks and aggregate statistics
are "as of" queries, so only events already received at that simulated moment are visible.
`tests/test_temporal_leakage.py` checks that rebuilding all state from a log truncated at `t`
yields identical histories, statistics and recommendations.

## Exposure bias

Labels exist only for videos the logging policy showed. Hit-based offline metrics therefore
(a) reward agreement with the logging policy, (b) give no credit for good videos that were never
shown, and (c) inherit the logging policy's preferences — here, popular creators and declared
topics. A popularity baseline can score well on Recall@K for exactly that reason. These metrics
are reported because they are what real logs allow, but they are a biased proxy.

Two less biased views are provided:

- **Oracle metrics (synthetic data only).** The simulator knows the true relevance `ρ(u, v)`.
  `oracle_utility@k` is the mean `ρ` of the feed and `oracle_ndcg@k` its graded NDCG against the
  ideal ordering of the same eligible universe. The oracle is stored separately from the
  contract tables and is read by evaluation code only.
- **Propensity-weighted evaluation** (`evaluation/propensity.py`). Computed only from impressions
  with a valid logged propensity from a policy the caller declares to have full support, and only
  with enough overlap; otherwise the result is `unavailable` with the reason. In the synthetic
  world this exists for the long-form surface (a uniform-random policy on a share of requests) and
  is unavailable for short-form, where reach depends on the user and no valid propensity exists.
  Estimators: IPS and self-normalised IPS of the mean reward per recommended item, with a user
  bootstrap. Assumptions are listed in the output: reward independent of slate and position; full
  support.

## What is *not* claimed

- Results on synthetic data are not evidence about real users.
- The learned system is not tuned until it beats the baselines; where a baseline is better on a
  metric the tables show it.
- No policy weighting or diversity setting is claimed to be optimal.
