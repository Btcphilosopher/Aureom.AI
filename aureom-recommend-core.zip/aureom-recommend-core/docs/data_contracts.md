# Data contracts and event processing

Three tables, as pandas DataFrames or Parquet files (`data/io.py`). Validators live in
`data/schemas.py`; typed records are `VideoRecord`, `InteractionRecord`, `UserPreferences`.
All timestamps are UTC (naive values are interpreted as UTC).

## videos — one row per (video_id, metadata_version)

| field | type | required | notes |
|---|---|---|---|
| video_id, creator_id | str | yes | |
| title | str | yes | |
| description | str | no | |
| language | str | no | unknown language is excluded under a strict language filter |
| topic_ids | list[str] | yes (may be empty) | |
| duration_seconds | float > 0 | yes | ≤ `short_form_max_duration_seconds` ⇒ short-form surface |
| published_at | timestamp | yes | |
| available_from | timestamp | no | missing ⇒ `published_at` |
| available_until | timestamp | no | missing ⇒ no expiry; must be after `available_from` |
| content_embedding | list[float] | no | one dimensionality per table; missing ⇒ zeros + indicator |
| duplicate_group_id | str | no | videos sharing it are copies of each other |
| eligibility_labels | list[str] | yes (may be empty) | matched against configured excluded / required labels |
| metadata_version | int | yes | |
| metadata_valid_from | timestamp | for versions after the first | *extension*: when the version became visible |

A row is visible during `[valid_from, next version's valid_from)`. Later versions without
`metadata_valid_from` are rejected, because their visibility time would have to be guessed.

## interactions — one row per logged event

`event_type ∈ {impression, play_start, progress, play_end, like, save, share, dislike,
not_interested, block_creator, survey_response}`.

| field | required | notes |
|---|---|---|
| event_id, user_id, video_id, event_type, occurred_at, received_at | yes | |
| session_id, playback_context | no | unknown context values become missing |
| request_id | impressions: yes | outcome events may omit it (fallback attribution) |
| position | no | zero-based slate position of an impression |
| playback_id | progress: yes | |
| watched_interval_start / _end | progress: yes | content seconds; `occurred_at` marks the end of the segment |
| foreground | no | `true` / `false` / missing (unknown) |
| explicit_feedback | survey_response: yes | satisfaction rating on the configured scale; nulled on other events |
| logging_policy_id | no | |
| selection_propensity | no | kept only on impressions, with a policy id, and in (0, 1]; otherwise set to missing |

**Propensities are never invented.** A value that is not a valid probability supplied by a named
logging policy is treated as absent, and evaluation that needs propensities reports
"unavailable" (see `docs/evaluation.md`).

## preferences — one row per user

`selected_topics`, `preferred_languages`, `followed_creators`, `blocked_creators`,
`excluded_videos` (lists, may be empty), `personalisation_enabled` (missing ⇒ enabled),
`history_reset_at` (optional). Users without a row get empty preferences.

- `personalisation_enabled = false`: no history, declared topics or follows are used and only
  non-personalised candidate sources run; blocks, exclusions and languages still apply.
- `history_reset_at`: the user's events from before the reset are removed during cleaning.
- The snapshot is treated as declared settings; blocks that arrive as `block_creator` events
  take effect from the moment the event was received.

## Event processing rules (`clean_events`)

| step | rule |
|---|---|
| duplicate event ids | earliest `received_at` wins; result is independent of input order |
| ordering | `(occurred_at, received_at, event_id)` |
| late arrival | `received_at − occurred_at > max_event_lateness_seconds` (48 h) ⇒ dropped |
| clock errors | received more than `clock_skew_tolerance_seconds` before it occurred ⇒ dropped |
| observability | an event is usable at time `t` iff `received_at < t` |
| reset | events before the user's `history_reset_at` ⇒ dropped |
| intervals | need `0 ≤ start < end`; `end` may exceed the duration by `interval_end_tolerance_seconds` (clipped), beyond that ⇒ dropped |

Label construction, the outcome window, observation states and masks are described in the module
docstring of `data/labels.py` and in `docs/algorithm.md` §1. The validation and cleaning reports
(counts per rule) are returned with the data and stored in the artefact's `report.json`.

## Known limits of the reference implementation

- `Catalogue.topic_matrix` is a dense rows × topics boolean matrix and candidate sources other
  than the two-tower index scan the eligible rows with NumPy. Both are appropriate up to roughly
  10⁵ catalogue rows; beyond that they should be replaced by sparse / indexed lookups.
- A `HistoryStore` holds dense indices of the catalogue it was built with; call
  `histories.rebind(catalogue)` before serving from a catalogue that has grown.
- Playback rate 1 is assumed when converting reported content intervals into wall-clock spans.
