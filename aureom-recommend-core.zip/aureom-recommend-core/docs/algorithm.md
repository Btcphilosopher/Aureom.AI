# AUREOM RECOMMEND — the algorithm in brief

Notation: user `u`, video `v`, context `c ∈ {short_form, long_form}`, request time `t`.
Everything a model sees for a request at `t` is computed from events **received before `t`**
and from the catalogue metadata version **visible at `t`**.

## 1. From events to labels

1. **Cleaning** (`data/events.py`): deduplicate `event_id` (earliest delivery wins), drop
   events received more than 48 h late or before they occurred, drop a user's events from
   before their personalisation reset, drop invalid playback intervals.
2. **Interval accounting** (`data/intervals.py`). For one impression let `I_j = [a_j, b_j]` be
   the reported *foreground* content intervals and `o_j` the event time of report `j`.

   - unique coverage `U = |⋃_j I_j|` → `unique_watched_seconds`
   - total playback `T = |⋃_j [o_j − (b_j − a_j), o_j]|` (union in wall-clock time) →
     `total_valid_playback_seconds`; re-sent or cumulative updates occupy the same wall-clock
     span and add nothing, loops occupy new wall-clock time and do
   - `completion_ratio = min(1, U / duration)`, `rewatch_seconds = max(0, T − U)`
   - background playback and playback with unknown foreground state are accounted separately
     and never count as viewing.
3. **Outcome window** (`data/labels.py`). With window `W` and late-arrival grace `G`, the label
   of an impression at `t_i` uses events with `occurred_at ≤ t_i + W` and
   `received_at ≤ t_i + W + G`; the impression is *matured* at `t_i + W + G`. Unmatured
   impressions are masked for every task.
4. **States**: never shown (no row) · impression, no play · early skip · partial view ·
   positive (meaningful view or like/save/share) · explicit negative · incomplete.
   `meaningful_view ⇔ U ≥ min(s_c, f_c · duration)` with per-context, versioned `(s_c, f_c)`.
5. **Masks** `m_it ∈ {0,1}`: viewing heads need a matured, observed viewing outcome; feedback
   heads need maturity; the satisfaction head needs an actual survey response.

## 2. Duration-adjusted viewing (`features/duration.py`)

Raw seconds favour long videos, raw completion favours short ones. On **training plays only**,
split each context's plays into buckets `b` by quantiles of `log(duration)` and store the
empirical distribution `F_{c,b}` of the completion ratio `x`. The target is the mid-rank
quantile

```
r(u, v) = 0                              no play observed
r(u, v) = ( F_{c,b}(x⁻) + F_{c,b}(x) ) / 2      otherwise, r ∈ [0, 1]
```

Within every bucket `r` is approximately uniform over plays, so no duration range is
favoured by construction. Completed plays tie at `x = 1` and receive their mid-rank (completing
something few people complete scores higher). Viewing is right-censored by the video length and
by the outcome window; no imputation is attempted. The baseline is estimated from logged, not
randomised, exposure, and normalises away genuine quality differences between duration ranges.

## 3. Baselines (`baselines/`)

Recent · time-decayed popularity `Σ_e 0.5^{(t − t_e)/h}` · smoothed positive rate
`(pos + α·m)/(imp + α)` with `m` the global rate before `t` · TF-IDF cosine to a decayed history
profile · explicit topic / followed-creator match · implicit ALS with user fold-in from the
history as of `t`. All statistics are "as of `t`"; all fall back to popularity for users or
videos without data.

## 4. Two-tower retrieval (`retrieval/model.py`, `retrieval/loss.py`)

**Video tower.** `b(v) = W·x_v + mean(E_topic) + E_lang + E_creator + E_video`, where `x_v` holds
text (TF-IDF → SVD), the content embedding and duration features; unknown creators and videos
use a trained UNK embedding (ID dropout). `e_v = normalise(MLP(relu(b(v))))`.

**User tower** (no user-ID embedding). History item `j` has type `τ_j`, strength `s_j` and age
`Δ_j`. Time-decayed pooling weights (the baseline; attention is the alternative):

```
w_j ∝ softplus(a_{τ_j}) · (0.5 + 0.5·s_j) · exp(−Δ_j / τ_±)        (normalised per polarity)
e_u = normalise( α₊ Σ_{j∈pos} w_j e_{v_j} − α₋ Σ_{j∈neg} w_j e_{v_j} + MLP(z_u) )
```

`z_u` concatenates pooled item features, declared topics, followed creators, preferred languages
and the context embedding. **Similarity** `s(u, v) = ⟨e_u, e_v⟩` (cosine).

**Objective.** For batch `B` with candidates = in-batch positives ∪ `M` uniform samples,

```
L = −(1/|B|) Σ_i log  exp(s̃_ii⁺) / ( exp(s̃_ii⁺) + Σ_{j∈N_i} exp(s̃_ij) ),   s̃_ij = s(u_i, v_j)/τ − β·log q_j
```

`N_i` excludes: the positive and its duplicate-group copies, known positives of `u_i`, videos
not yet published / not available at the example's time, and videos of the other surface.
`q_j = |B|·p_j + M/n_pool` is the expected number of times `v_j` enters a candidate set (logQ
correction for in-batch popularity). Sampled videos are contrastive alternatives, not dislikes.

## 5. Candidate generation (`retrieval/candidates.py`)

Union of two-tower neighbours, content-profile neighbours, followed creators, declared topics,
recent, popular and a bounded uniform exploration sample; hard eligibility is applied before
every source; each candidate keeps its source list. Exact search for small catalogues; FAISS
with oversample-and-filter and a bounded exact fallback otherwise.

## 6. Multitask ranker (`ranking/`)

Shared MLP trunk over point-in-time cross features, video statistics as of `t`, and the frozen
tower embeddings `[e_u, e_v, e_u ⊙ e_v]`; one logit per task
`t ∈ {meaningful, duration, like_or_save, satisfaction, negative}`.

```
L = Σ_t α_t · ( Σ_i m_it ℓ_t(y_it, ŷ_it) ) / max(1, Σ_i m_it)  +  λ‖θ‖²
```

`ℓ_t` is cross-entropy on logits (soft targets in [0,1] for the two bounded heads). A task with
no usable label in a batch contributes zero. A positive weight `w_t` on rare binary heads is
undone at prediction time by `z ← z − log w_t`; each head is then Platt-calibrated
(`σ(a·z + b)`, `a > 0`) on a separate later window when label support is sufficient.

## 7. Policy (`ranking/policy.py`)

```
S(u,v,c) = w_m p_meaningful + w_d r̂_duration + w_p p_positive + w_s ŝ_satisfaction − w_n p_negative
```

All components are calibrated values in [0, 1]. Weights are versioned configuration, not a
claim of optimality. Raw watch time and session length are not components. A block is an
exclusion handled by eligibility, never a term of `S`.

## 8. Feed composition (`composition/rerank.py`)

Greedy: at each position choose the feasible candidate maximising

```
S_feed(v | A) = S(u,v,c) − λ_d · max_{a∈A} sim(v, a) + λ_f · 0.5^{age(v)/h}
```

Hard (never relaxed): eligibility, one item per duplicate group. Soft, relaxed in this order
only when no feasible candidate remains: topic concentration → creator cap → near-duplicate
threshold. Up to `max_exploration_slots` configured positions are filled by a seeded uniform draw
among exploration-only candidates; the draw's choice-set size and conditional probability are
reported, slate-level probabilities are not computed. Eligibility is re-applied to the result.
The greedy slate is a heuristic, not a global optimum.

## 9. Chronological training (`training/`)

```
[ retrieval train | retr. valid ]→ retriever frozen →[ ranker train | ranker valid | calibration ]→[ test ]
```

A window contains an impression only if its label matured inside the window (embargo).
Vocabularies, TF-IDF/SVD and scalers are fitted on catalogue rows visible before the retrieval
cutoff; the duration baseline on training windows; ranker features are produced by the frozen
retriever; calibration uses a window the ranker never trained on; nothing touches the test
window. Evaluation replays test requests in time order against "as of" histories.

## 10. Cold start and exploration

New users: declared topics, languages, follows, freshness and smoothed popularity feed both the
candidate sources and the user tower's residual MLP. New videos: content features give them an
embedding immediately; half of the exploration sample is reserved for videos inside the
new-video window. Contextual bandits and RL are intentionally out of scope
(`composition/extension.py` documents the interface and its preconditions).
