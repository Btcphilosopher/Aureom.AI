## 1. Observations

Written by hand after reading the tables below; every figure quoted here is in those tables.
One simulator seed and one training seed were run, so differences of about 0.01 are within noise
(see the bootstrap intervals).

**Full feeds (default world).**
- On simulator ground truth the learned system has the highest oracle NDCG@20 (0.535; the best
  baselines are implicit CF at 0.493 and TF-IDF at 0.486) while being far less concentrated: its
  largest creator share per feed is 0.15 against 0.47–0.53 for the personalised baselines, and its
  intra-list diversity is 0.85 against 0.72–0.79.
- On logged positives the order is different. Popularity (Recall@20 0.206) and explicit
  preferences (0.192) lead; the learned system (0.137) is on a level with the feedback-rate
  baseline and below implicit CF. The logging policy favoured popular creators and declared
  topics, and those two baselines reproduce it. This is the exposure-bias gap described in
  `docs/evaluation.md`; without an oracle it could not be resolved from these logs.
- The learned system is not ahead everywhere. Its mean oracle utility with default composition
  (0.299) is only slightly above implicit CF (0.290) and TF-IDF (0.287); the larger margin in
  oracle NDCG comes with the diversity constraints already paid for.

**Retrieval.** The two-tower scorer has the best Recall@100 over the full eligible catalogue
(0.416) but not the best top of the list: popularity and explicit preferences are level or
ahead at Recall@10, and implicit CF and TF-IDF have higher oracle utility in their top 20
(0.299 / 0.296 against 0.276). As a candidate generator it does its job — the hybrid set holds
about 200 of 500 eligible videos and 77 % of the oracle-ideal top 20 — but on its own it is not a
better ranker than the simple baselines.

**Ranking.** On logged slates the policy orders impressions clearly better than the logged order
or chance (NDCG@10 0.726 / 0.616 / 0.570). The heads were already close to calibrated on the test
window; Platt scaling moved ECE by less than 0.002 in either direction (slightly worse for
meaningful, duration and satisfaction, better for negative). The satisfaction head rests on 967
labelled test impressions and should be read accordingly.

**Propensity-weighted evaluation.** Unavailable for short-form (no valid propensities). For
long-form (452 uniformly logged requests, about 300 matched impressions per recommender) the
intervals are wide and mostly overlap; the only clear statement is that the popularity baseline
is at the bottom, which agrees with the oracle and disagrees with logged recall.

**Ablations.**
- *Sources.* Dropping all personalised sources costs the most (oracle NDCG 0.543 → 0.465).
  Dropping any single source moves it by at most 0.007 — the sources overlap heavily — except
  exploration, whose removal *raises* it by 0.019. That is the measured price of the two
  exploration slots.
- *Heads.* No single head is essential: removing any one changes oracle NDCG by at most 0.007.
  Single-head policies are worse (duration only 0.504, like/save only 0.423).
- *Diversity.* The creator and topic caps are expensive in this world, where users have two to
  four liked topics: switching every diversity control off raises oracle NDCG from 0.543 to
  0.605 and creator concentration from 0.15 to 0.41. The defaults are a choice, not an optimum.
- *Duration target.* Eligible supply and the oracle-ideal feed are duration-neutral (about 0.20
  per bucket), but logged popularity puts 0.42 of its mass on the shortest fifth: short videos are
  completed more often, become "popular" and are shown more. Ranking by the duration head alone,
  the raw completion-ratio target amplifies this (0.49 in the shortest bucket), the
  duration-adjusted target reduces it (0.39) and the capped-watch-seconds target, which pulls the
  other way, lands closest to neutral here (0.30). The duration-adjusted target removes the
  target's own duration preference; it does not remove duration effects that enter through other
  features such as popularity. In the dedicated duration-bias world the picture is sharper:
  completion ratio puts 0.67 of recommendations in the shortest bucket and loses relevance
  (oracle NDCG 0.467), the adjusted target 0.33 (0.562), capped seconds 0.42 (0.561).
- *History pooling.* Attention pooling is indistinguishable from the time-decay baseline
  (oracle NDCG 0.544 against 0.543).

**Scenarios.**
- *Preference recovery.* With unbiased exposure the learned system recovers preferences best
  (oracle NDCG 0.576; TF-IDF 0.506, popularity 0.369).
- *Popularity bias.* Logged recall and ground truth disagree outright: popularity has by far the
  highest Recall@20 (0.444) and nearly the lowest oracle NDCG (0.299); the learned system has the
  highest oracle NDCG (0.456) with Recall@20 of 0.165.
- *Cold start.* For new users the learned system (oracle NDCG 0.426) is not better than the
  explicit-preference baseline (0.444); with about 100 requests the difference is within noise.
  It does surface new videos: recall on new-video positives is 0.202 against 0.110 for
  popularity, and a third of its feed items are new videos.
