import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Taiwan Railways — Connecting Taiwan, Advancing the Future',
  description: 'The next-generation digital portal of Taiwan Railways. Fully functional booking, interactive timetable, fare calculation, real-time live-status tracking, and bilingual experience.',
  openGraph: {
    title: 'Taiwan Railways — Connecting Taiwan, Advancing the Future',
    description: 'The next-generation digital portal of Taiwan Railways. Fully functional booking, interactive timetable, fare calculation, real-time live-status tracking, and bilingual experience.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Taiwan Railways — Connecting Taiwan, Advancing the Future',
    description: 'The next-generation digital portal of Taiwan Railways. Fully functional booking, interactive timetable, fare calculation, real-time live-status tracking, and bilingual experience.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
