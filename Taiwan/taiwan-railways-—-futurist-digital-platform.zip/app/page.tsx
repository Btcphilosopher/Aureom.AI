'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';

// Core Framework Layout Components
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import BookingWidget from '@/components/BookingWidget';
import QuickServices from '@/components/QuickServices';
import NewsPanel from '@/components/NewsPanel';
import LiveStatus from '@/components/LiveStatus';
import ContentCards from '@/components/ContentCards';
import Footer from '@/components/Footer';
import MobileBottomNav from '@/components/MobileBottomNav';

// Secondary Section Pages
import ExploreSection from '@/components/ExploreSection';
import TimetableSection from '@/components/TimetableSection';
import FareCalculatorSection from '@/components/FareCalculatorSection';
import SearchResultsSection from '@/components/SearchResultsSection';
import TicketViewer from '@/components/TicketViewer';
import MemberDashboard from '@/components/MemberDashboard';
import AboutSection from '@/components/AboutSection';

import { type Language } from '@/lib/i18n';
import { type UserTicket } from '@/lib/data';

export default function Home() {
  const [lang, setLang] = React.useState<Language>('zh');
  // Support custom subroutes
  const [route, setRoute] = React.useState<string>('/');
  
  // Ticketing Search State
  const [searchParams, setSearchParams] = React.useState<{
    fromId: string;
    toId: string;
    date: string;
    passengers: { adult: number; child: number; senior: number };
  } | null>(null);

  // Tickets Storage (User Wallet)
  const [addedTickets, setAddedTickets] = React.useState<UserTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = React.useState<UserTicket | undefined>(undefined);

  // Callback to trigger direct booking from Explore grids
  const handlePlanJourney = (fromId: string, toId: string) => {
    setSearchParams({
      fromId,
      toId,
      date: '2026-08-28',
      passengers: { adult: 1, child: 0, senior: 0 }
    });
    setRoute('/ticketing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Callback to trigger booking from the general homepage widget
  const handleSearchSubmit = (
    fromId: string,
    toId: string,
    date: string,
    passengers: { adult: number; child: number; senior: number }
  ) => {
    setSearchParams({ fromId, toId, date, passengers });
    setRoute('/ticketing');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Callback on successful payment
  const handleBookingSuccess = (newTicket: UserTicket) => {
    setAddedTickets(prev => [newTicket, ...prev]);
    setSelectedTicket(newTicket);
    setRoute('/ticketing/ticket');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Helper page router switcher
  const renderMainContent = () => {
    switch (route) {
      case '/':
        return (
          <div className="space-y-12">
                        {/* Cinematic Hero carousel */}
            <HeroSection lang={lang} setRoute={setRoute} />

            {/* Main Content Grid: Left Main Section & Right Sidebar */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column (8 cols): Interactive Widget, shortcuts, news, and features */}
              <div className="lg:col-span-8 space-y-12">
                
                {/* 1. Quick Booking Widget */}
                <BookingWidget lang={lang} onSearch={handleSearchSubmit} />

                {/* 2. Interactive Service Shortcuts */}
                <QuickServices lang={lang} setRoute={setRoute} />

                {/* 3. Live News Feed with Modal details */}
                <NewsPanel lang={lang} />

                {/* 4. Promotional Cards with dynamic app popups */}
                <ContentCards lang={lang} setRoute={setRoute} />

              </div>

              {/* Right Column (4 cols): Real-Time Status Monitor with ticker loops */}
              <div className="lg:col-span-4 sticky top-24">
                <LiveStatus lang={lang} />
              </div>

            </div>
          </div>
        );

      case '/ticketing':
        if (searchParams) {
          return (
            <SearchResultsSection
              lang={lang}
              fromId={searchParams.fromId}
              toId={searchParams.toId}
              date={searchParams.date}
              passengers={searchParams.passengers}
              onBookingSuccess={handleBookingSuccess}
              onBackToSearch={() => { setSearchParams(null); }}
            />
          );
        }
        return (
          <div className="max-w-3xl mx-auto py-8">
            <BookingWidget lang={lang} onSearch={handleSearchSubmit} />
          </div>
        );

      case '/ticketing/ticket':
        return (
          <TicketViewer 
            lang={lang} 
            activeTicket={selectedTicket} 
          />
        );

      case '/timetable':
        return (
          <TimetableSection
            lang={lang}
            onBook={(fromId, toId, journeyId) => {
              setSearchParams({
                fromId,
                toId,
                date: '2026-08-28',
                passengers: { adult: 1, child: 0, senior: 0 }
              });
              setRoute('/ticketing');
            }}
          />
        );

      case '/fares':
        return (
          <FareCalculatorSection lang={lang} />
        );

      case '/explore':
        return (
          <ExploreSection
            lang={lang}
            onPlanJourney={handlePlanJourney}
          />
        );

      case '/member':
        return (
          <MemberDashboard
            lang={lang}
            addedTickets={addedTickets}
            onSelectTicket={(ticket) => {
              setSelectedTicket(ticket);
              setRoute('/ticketing/ticket');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        );

      case '/about':
        return (
          <AboutSection lang={lang} />
        );

      default:
        return (
          <div className="py-20 text-center space-y-4">
            <h3 className="text-white text-xl font-bold">404 // ROUTE DISRUPTED</h3>
            <p className="text-slate-400 text-xs">The requested digital segment is offline.</p>
            <button 
              onClick={() => setRoute('/')}
              className="bg-[#00BCFF] text-[#001730] px-4 py-2 rounded-xl text-xs font-bold"
            >
              Return Home
            </button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#001021] text-slate-100 font-sans flex flex-col justify-between overflow-x-hidden select-none pb-16 md:pb-0">
      
      {/* Top Header Navigation */}
      <Header lang={lang} setLang={setLang} currentRoute={route} setRoute={setRoute} />

      {/* Main Container */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={route + (searchParams ? '_searched' : '_idle')}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.35, ease: 'easeInOut' }}
          >
            {renderMainContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Footer (Standard multi-column) */}
      <Footer lang={lang} setLang={setLang} setRoute={setRoute} />

      {/* Sticky Mobile Bottom Navigation Bar */}
      <MobileBottomNav lang={lang} route={route} setRoute={setRoute} />

    </div>
  );
}
