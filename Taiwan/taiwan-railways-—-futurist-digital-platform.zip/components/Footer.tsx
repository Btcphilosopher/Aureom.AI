'use client';

import * as React from 'react';
import { getTranslation, type Language } from '@/lib/i18n';
import { Smartphone, Shield, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  lang: Language;
  setLang: (lang: Language) => void;
  setRoute: (route: string) => void;
}

export default function Footer({ lang, setLang, setRoute }: FooterProps) {
  
  const handleLinkClick = (route: string, e: React.MouseEvent) => {
    e.preventDefault();
    setRoute(route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="tra-footer" className="w-full bg-slate-950 border-t border-white/10 text-slate-300 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Core Link Columns Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pb-12 border-b border-white/10">
          
          {/* Column 1: TRA Corporate */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 border-l-2 border-cyan-500 pl-2 leading-none">
              {getTranslation(lang, 'footer.about')}
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
              <li>
                <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-cyan-400 transition-colors flex items-center">
                  <span>{getTranslation(lang, 'footer.corp')}</span>
                </a>
              </li>
              <li>
                <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.careers')}
                </a>
              </li>
              <li>
                <a href="#/" onClick={(e) => handleLinkClick('/', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.news')}
                </a>
              </li>
              <li>
                <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.contact')}
                </a>
              </li>
            </ul>
          </div>

          {/* Column 2: Passenger Services */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 border-l-2 border-cyan-500 pl-2 leading-none">
              {getTranslation(lang, 'footer.services')}
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
              <li>
                <a href="#/ticketing" onClick={(e) => handleLinkClick('/ticketing', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.booking')}
                </a>
              </li>
              <li>
                <a href="#/timetable" onClick={(e) => handleLinkClick('/timetable', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.schedule')}
                </a>
              </li>
              <li>
                <a href="#/fares" onClick={(e) => handleLinkClick('/fares', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.fareInfo')}
                </a>
              </li>
              <li>
                <a href="#/member" onClick={(e) => handleLinkClick('/member', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.eticket')}
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Travel Discovery */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 border-l-2 border-cyan-500 pl-2 leading-none">
              {getTranslation(lang, 'footer.travel')}
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
              <li>
                <a href="#/explore" onClick={(e) => handleLinkClick('/explore', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.explore')}
                </a>
              </li>
              <li>
                <a href="#/explore" onClick={(e) => handleLinkClick('/explore', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.destinations')}
                </a>
              </li>
              <li>
                <a href="#/explore" onClick={(e) => handleLinkClick('/explore', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.tourism')}
                </a>
              </li>
              <li>
                <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.accessibility')}
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Customer Help Desk */}
          <div>
            <h4 className="text-white font-bold text-sm tracking-wider uppercase mb-4 border-l-2 border-cyan-500 pl-2 leading-none">
              {getTranslation(lang, 'footer.support')}
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400 font-medium">
              <li>
                <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.help')}
                </a>
              </li>
              <li>
                <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.lost')}
                </a>
              </li>
              <li>
                <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-red-400 transition-colors font-bold text-red-500 flex items-center space-x-1">
                  <span>{getTranslation(lang, 'footer.emergency')}</span>
                </a>
              </li>
              <li>
                <a href="#/" onClick={(e) => handleLinkClick('/', e)} className="hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, 'footer.status')}
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom row: Badges, Language, Copyrights */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-6">
          
          {/* Official Transportation Badges */}
          <div className="flex flex-wrap items-center gap-4 justify-center md:justify-start">
            {/* TRA Logo Motif */}
            <div className="flex items-center space-x-2 text-white font-black text-sm">
              <svg className="w-5 h-5 text-cyan-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="9" />
                <path d="M6 12h12M12 6v12M9 9l6 6M15 9l-6 6" />
              </svg>
              <span className="font-mono text-xs tracking-widest text-slate-400">TRA 2030+</span>
            </div>
            
            <div className="h-4 w-[1px] bg-white/10 hidden sm:block" />

            <div className="flex items-center space-x-1 bg-slate-900/60 border border-white/10 px-2.5 py-1 rounded text-[10px] text-slate-400 font-medium">
              <Shield className="w-3.5 h-3.5 text-cyan-400" />
              <span>WCAG 2.2 AA Certified</span>
            </div>
          </div>

          {/* Privacy and Policy Links */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-[11px] text-slate-500 font-semibold font-sans">
            <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-white transition-colors">
              {getTranslation(lang, 'footer.privacy')}
            </a>
            <span>•</span>
            <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-white transition-colors">
              {getTranslation(lang, 'footer.terms')}
            </a>
            <span>•</span>
            <a href="#/about" onClick={(e) => handleLinkClick('/about', e)} className="hover:text-white transition-colors">
              {getTranslation(lang, 'footer.statement')}
            </a>
          </div>

          {/* Copyright notice */}
          <div className="text-[11px] text-slate-500 text-center md:text-right font-mono font-medium">
            {getTranslation(lang, 'footer.copyright')}
          </div>
        </div>

      </div>
    </footer>
  );
}
