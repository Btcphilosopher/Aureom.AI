'use client';

import * as React from 'react';
import { BadgeDollarSign, Info, AlertTriangle, Coffee, ShieldAlert, Sparkles, Train } from 'lucide-react';
import { STATIONS, calculateFare } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface FareCalculatorSectionProps {
  lang: Language;
}

export default function FareCalculatorSection({ lang }: FareCalculatorSectionProps) {
  const [fromStation, setFromStation] = React.useState('TPE');
  const [toStation, setToStation] = React.useState('KHH');
  const [passengerType, setPassengerType] = React.useState<'adult' | 'child' | 'senior'>('adult');
  const [cabinClass, setCabinClass] = React.useState<'standard' | 'business'>('standard');

  const { baseFare, discountedFare, estimatedTime } = calculateFare(
    fromStation, 
    toStation, 
    cabinClass === 'business' ? 'EXP' : 'CK', 
    passengerType
  );

  const businessFare = Math.round(discountedFare * 1.5);
  const finalDisplayFare = cabinClass === 'business' ? businessFare : discountedFare;

  return (
    <section id="fare-calculator-container" className="w-full py-6 space-y-8 text-left">
      
      {/* Title Header */}
      <div className="border-b border-white/10 pb-5">
        <h2 className="text-3xl font-extrabold text-white tracking-tight">
          {getTranslation(lang, 'fare.title')}
        </h2>
        <p className="text-slate-400 text-sm mt-1">
          {getTranslation(lang, 'fare.subtitle')}
        </p>
      </div>

      {/* Grid: Inputs Panel & Results Panel */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        
        {/* Left Inputs Card */}
        <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 space-y-6 shadow-lg">
          
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold font-mono">
            <BadgeDollarSign className="w-4 h-4" />
            <span>FARE PARAMETERS ESTIMATOR</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* From Station */}
            <div>
              <label className="block text-slate-400 text-xs font-semibold mb-1.5" htmlFor="fc-from">
                {getTranslation(lang, 'booking.from')}
              </label>
              <select
                id="fc-from"
                value={fromStation}
                onChange={(e) => setFromStation(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 cursor-pointer"
              >
                {STATIONS.map(s => <option key={s.id} value={s.id}>{s.zh} {s.en}</option>)}
              </select>
            </div>

            {/* To Station */}
            <div>
              <label className="block text-slate-400 text-xs font-semibold mb-1.5" htmlFor="fc-to">
                {getTranslation(lang, 'booking.to')}
              </label>
              <select
                id="fc-to"
                value={toStation}
                onChange={(e) => setToStation(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-2.5 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 cursor-pointer"
              >
                {STATIONS.map(s => <option key={s.id} value={s.id}>{s.zh} {s.en}</option>)}
              </select>
            </div>
          </div>

          {/* Passenger discount types */}
          <div>
            <label className="block text-slate-400 text-xs font-semibold mb-2">
              {getTranslation(lang, 'fare.passenger')}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['adult', 'child', 'senior'] as const).map((type) => (
                <button
                  id={`fc-passenger-btn-${type}`}
                  key={type}
                  type="button"
                  onClick={() => setPassengerType(type)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                    passengerType === type
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400'
                      : 'bg-slate-950 border-white/10 text-slate-300 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  {getTranslation(lang, `booking.${type}`)}
                </button>
              ))}
            </div>
          </div>

          {/* Cabin Selection */}
          <div>
            <label className="block text-slate-400 text-xs font-semibold mb-2">
              {getTranslation(lang, 'fare.ticketType')}
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                id="fc-cabin-standard"
                type="button"
                onClick={() => setCabinClass('standard')}
                className={`py-3 px-4 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center space-y-1 cursor-pointer ${
                  cabinClass === 'standard'
                    ? 'bg-cyan-500/10 border-cyan-500 text-white'
                    : 'bg-slate-950 border-white/10 text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Train className="w-4 h-4 text-slate-400" />
                <span>{getTranslation(lang, 'fare.standard')}</span>
              </button>
              
              <button
                id="fc-cabin-business"
                type="button"
                onClick={() => setCabinClass('business')}
                className={`py-3 px-4 rounded-xl text-xs font-bold border transition-all flex flex-col items-center justify-center space-y-1 cursor-pointer ${
                  cabinClass === 'business'
                    ? 'bg-cyan-500/10 border-cyan-500 text-white'
                    : 'bg-slate-950 border-white/10 text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Coffee className="w-4 h-4 text-cyan-400" />
                <span>{getTranslation(lang, 'fare.business')}</span>
              </button>
            </div>
          </div>

        </div>

        {/* Right Fare Output Results Card */}
        <div className="space-y-6">
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
            
            <span className="text-[10px] text-slate-400 font-mono tracking-widest block uppercase mb-4">
              CALCULATION RECEIPT
            </span>

            {/* Price tag block */}
            <div className="space-y-1 border-b border-white/5 pb-6 mb-6">
              <span className="text-xs text-slate-400">
                {cabinClass === 'business' ? getTranslation(lang, 'fare.business') : getTranslation(lang, 'fare.standard')}
              </span>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-xs text-cyan-400 font-bold font-mono">NT$</span>
                <span className="text-4xl font-black text-cyan-400 font-mono tracking-tight">
                  {finalDisplayFare.toLocaleString()}
                </span>
                <span className="text-xs text-slate-400">/ Single Ticket 單程票</span>
              </div>
            </div>

            {/* Travel breakdown info */}
            <div className="space-y-4 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Estimated Duration 行車時間</span>
                <span className="font-bold text-white font-mono">{estimatedTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Passenger Category 乘客類型</span>
                <span className="font-bold text-white">{getTranslation(lang, `booking.${passengerType}`)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Available Ticket Types 可選座位</span>
                <span className="font-bold text-white">E-Pass, QR Code, Mobile Pay</span>
              </div>
            </div>

            {/* Cabin Premium Features description */}
            <div className="mt-6 pt-4 border-t border-white/5 text-xs">
              {cabinClass === 'business' ? (
                <div className="bg-cyan-500/5 rounded-xl p-3 border border-cyan-500/20 space-y-2">
                  <div className="flex items-center space-x-1.5 text-xs text-cyan-400 font-bold">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>騰雲座艙頂級特權 / Tengyun Premium Amenities</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    提供專屬精品茶點服務、主動抗噪舒適座艙、隨車免費5G智慧Wi-Fi及加大寬幅人體工學座椅。
                  </p>
                </div>
              ) : (
                <div className="bg-slate-950 rounded-xl p-3 border border-white/10 space-y-2">
                  <div className="flex items-center space-x-1.5 text-xs text-slate-300 font-bold">
                    <Train className="w-3.5 h-3.5 text-slate-400" />
                    <span>標準車廂舒適特點 / Standard Cabin Services</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    安靜平穩的無干擾環境，配置獨立個人充電座、防噪防滑靜音地板及貼心無障礙友善車廂。
                  </p>
                </div>
              )}
            </div>

          </div>

          {/* Guidelines notes */}
          <div className="space-y-3 bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-xl p-4 text-xs leading-relaxed text-slate-400">
            <div className="flex items-center space-x-1.5 text-amber-500 font-bold">
              <Info className="w-3.5 h-3.5 text-amber-500" />
              <span>{getTranslation(lang, 'fare.passenger')}</span>
            </div>
            <p className="text-[11px]">{getTranslation(lang, 'fc.result.type')}</p>
            <p className="text-[11px] text-slate-500 italic">{getTranslation(lang, 'fare.result.disclaimer')}</p>
          </div>
        </div>

      </div>
    </section>
  );
}
