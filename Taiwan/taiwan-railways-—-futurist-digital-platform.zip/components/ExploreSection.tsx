'use client';

import * as React from 'react';
import { motion } from 'motion/react';
import { Compass, Clock, MapPin, Tag, Landmark, Sparkles, ArrowRight } from 'lucide-react';
import { DESTINATIONS, type Destination } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface ExploreSectionProps {
  lang: Language;
  onPlanJourney: (fromId: string, toId: string) => void;
}

export default function ExploreSection({ lang, onPlanJourney }: ExploreSectionProps) {
  const [selectedRegion, setSelectedRegion] = React.useState<string>('All');

  const regions = [
    { id: 'All', labelKey: 'explore.all' },
    { id: 'North', labelKey: 'explore.North' },
    { id: 'Central', labelKey: 'explore.Central' },
    { id: 'South', labelKey: 'explore.South' },
    { id: 'East', labelKey: 'explore.East' },
    { id: 'Islands', labelKey: 'explore.Islands' }
  ];

  const filteredDestinations = selectedRegion === 'All' 
    ? DESTINATIONS 
    : DESTINATIONS.filter(d => d.region === selectedRegion);

  return (
    <section id="explore-taiwan-page" className="w-full py-6 space-y-8 text-left">
      
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-5">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold font-mono uppercase tracking-widest">
            <Compass className="w-4 h-4 text-cyan-400" />
            <span>TAIWAN RAIL TOURISM 2030</span>
          </div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">
            {getTranslation(lang, 'explore.title')}
          </h2>
          <p className="text-slate-400 text-sm">
            {getTranslation(lang, 'explore.subtitle')}
          </p>
        </div>

        {/* Region Filter Tabs */}
        <div className="flex flex-wrap gap-2 pt-2 md:pt-0">
          {regions.map((reg) => (
            <button
              id={`filter-tab-${reg.id}`}
              key={reg.id}
              onClick={() => setSelectedRegion(reg.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                selectedRegion === reg.id
                  ? 'bg-cyan-500 border-cyan-500 text-slate-950 font-black shadow-lg shadow-cyan-500/10'
                  : 'bg-slate-950 border-white/10 text-slate-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              {getTranslation(lang, reg.labelKey)}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Destination Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDestinations.map((dest) => (
          <motion.div
            layout
            id={`explore-card-${dest.id}`}
            key={dest.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden shadow-lg hover:border-cyan-500 transition-all group h-[480px] justify-between"
          >
            {/* Aspect card top photo with hover scale */}
            <div className="relative h-44 overflow-hidden flex-shrink-0">
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent z-10" />
              <img
                src={dest.image}
                alt={lang === 'zh' ? dest.nameZh : dest.nameEn}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 left-4 z-20 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-md text-[10px] font-bold text-white border border-white/10 flex items-center space-x-1">
                <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                <span>{lang === 'zh' ? dest.nameZh : dest.nameEn}</span>
              </div>
            </div>

            {/* Destination description & station info body */}
            <div className="p-5 flex-1 flex flex-col justify-between">
              <div className="space-y-4">
                {/* Station and Travel Time badge */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold border-b border-white/5 pb-2.5">
                  <div className="flex items-center space-x-1">
                    <Landmark className="w-3.5 h-3.5 text-cyan-400/70" />
                    <span className="truncate max-w-[120px]">{lang === 'zh' ? dest.stationZh : dest.stationEn}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-slate-400">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>{lang === 'zh' ? dest.travelTimeZh : dest.travelTimeEn}</span>
                  </div>
                </div>

                {/* Main Desc */}
                <p className="text-slate-300 text-xs leading-relaxed line-clamp-3">
                  {lang === 'zh' ? dest.descZh : dest.descEn}
                </p>

                {/* Attractions tags */}
                <div className="space-y-1.5">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
                    <Tag className="w-3 h-3 text-cyan-400" />
                    <span>{getTranslation(lang, 'explore.attractions')}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-0.5">
                    {(lang === 'zh' ? dest.attractionsZh : dest.attractionsEn).slice(0, 3).map((attr, aIdx) => (
                      <span 
                        key={aIdx} 
                        className="bg-slate-950 text-slate-300 border border-white/10 px-2 py-0.5 rounded text-[10px] font-medium leading-none"
                      >
                        {attr}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Plan Journey Booking CTA */}
              <button
                id={`plan-journey-btn-${dest.id}`}
                onClick={() => onPlanJourney('TPE', dest.id.toUpperCase())}
                className="w-full flex items-center justify-center space-x-2 bg-slate-950 border border-white/10 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950 py-2.5 rounded-xl text-xs font-bold transition-all mt-4 group cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{getTranslation(lang, 'explore.plan')}</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
