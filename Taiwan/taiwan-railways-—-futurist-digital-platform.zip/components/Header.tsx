'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Globe, User, ChevronDown } from 'lucide-react';
import { getTranslation, type Language } from '@/lib/i18n';

interface HeaderProps {
  lang: Language;
  setLang: (lang: Language) => void;
  currentRoute: string;
  setRoute: (route: string) => void;
}

export default function Header({ lang, setLang, currentRoute, setRoute }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setLangDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems = [
    { id: 'home', labelKey: 'nav.home', route: '/' },
    { id: 'travel', labelKey: 'nav.travelInfo', route: '/travel' },
    { id: 'ticketing', labelKey: 'nav.ticketing', route: '/ticketing' },
    { id: 'explore', labelKey: 'nav.explore', route: '/explore' },
    { id: 'member', labelKey: 'nav.member', route: '/member' },
    { id: 'about', labelKey: 'nav.about', route: '/about' },
  ];

  const toggleLanguage = () => {
    setLang(lang === 'zh' ? 'en' : 'zh');
    setLangDropdownOpen(false);
  };

  const handleNavClick = (route: string) => {
    setRoute(route);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header id="tra-header" className="sticky top-0 z-50 w-full backdrop-blur-md bg-slate-950/80 border-b border-white/10 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo & Emblem */}
          <button 
            id="logo-btn"
            onClick={() => handleNavClick('/')} 
            className="flex items-center space-x-3.5 focus:outline-none focus:ring-2 focus:ring-cyan-500/40 rounded-lg p-1.5 transition-all text-left"
          >
            {/* TRA Futuristic Emblem */}
            <div className="w-8 h-8 flex-shrink-0 bg-cyan-500 rounded-sm flex items-center justify-center rotate-45 border border-cyan-400/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]">
              <div className="w-4 h-4 border-2 border-slate-950"></div>
            </div>
            <div>
              <h1 className="text-white font-bold tracking-tight uppercase text-base md:text-lg leading-tight">
                {lang === 'zh' ? '臺灣鐵路' : 'Taiwan Railways'}
              </h1>
              <p className="text-cyan-400/80 uppercase text-[9px] tracking-[0.25em] font-bold font-mono leading-none mt-0.5">
                TAIWAN RAILWAYS
              </p>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden lg:flex space-x-1" aria-label="Main Navigation">
            {navItems.map((item) => {
              const isActive = 
                currentRoute === item.route || 
                (item.route !== '/' && currentRoute.startsWith(item.route));
              return (
                <button
                  id={`nav-${item.id}`}
                  key={item.id}
                  onClick={() => handleNavClick(item.route)}
                  className={`relative px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-cyan-500/30 ${
                    isActive 
                      ? 'text-cyan-400 bg-white/5 font-semibold' 
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {getTranslation(lang, item.labelKey)}
                  {isActive && (
                    <motion.div 
                      layoutId="nav-indicator" 
                      className="absolute bottom-0 left-4 right-4 h-[2px] bg-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.5)]"
                      transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Header Controls */}
          <div className="flex items-center space-x-3">
            
            {/* Language Selector Dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                id="lang-selector"
                onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-lg border border-white/10 bg-slate-900/50 text-xs font-semibold text-slate-300 hover:text-white hover:bg-white/5 transition-all focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                aria-haspopup="true"
                aria-expanded={langDropdownOpen}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{lang === 'zh' ? '繁體中文' : 'English'}</span>
                <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${langDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {langDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-2 w-36 rounded-xl border border-white/10 bg-slate-900/95 backdrop-blur-md shadow-2xl z-50 p-1.5"
                  >
                    <button
                      id="lang-option-zh"
                      onClick={() => { setLang('zh'); setLangDropdownOpen(false); }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                        lang === 'zh' ? 'text-cyan-400 bg-white/5 font-semibold' : 'text-slate-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      繁體中文 (ZH)
                    </button>
                    <button
                      id="lang-option-en"
                      onClick={() => { setLang('en'); setLangDropdownOpen(false); }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                        lang === 'en' ? 'text-cyan-400 bg-white/5 font-semibold' : 'text-slate-400 hover:text-white hover:bg-white/5'
                      }`}
                    >
                      English (EN)
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Member Profile Quick Action */}
            <button
              id="member-btn"
              onClick={() => handleNavClick('/member')}
              className={`p-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all ${
                currentRoute.startsWith('/member')
                  ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400'
                  : 'border-white/10 bg-slate-900/50 text-slate-300 hover:text-white hover:bg-white/5'
              }`}
              title={getTranslation(lang, 'nav.account')}
              aria-label="Member Dashboard"
            >
              <User className="w-4 h-4" />
            </button>

            {/* Mobile Hamburger Menu Button */}
            <button
              id="hamburger-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg border border-white/10 bg-slate-900/50 text-slate-300 hover:text-white hover:bg-white/5 focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 bg-black z-40 lg:hidden"
            />

            {/* Drawer */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-[280px] bg-[#001730] border-l border-[#002B54] z-50 p-6 shadow-2xl flex flex-col justify-between lg:hidden"
            >
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <span className="text-[#00BCFF] font-mono text-xs tracking-widest font-bold">TAIWAN RAILWAYS</span>
                  <button 
                    id="close-drawer"
                    onClick={() => setMobileMenuOpen(false)} 
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-white/5 hover:bg-white/10"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex flex-col space-y-2 pt-4">
                  {navItems.map((item) => {
                    const isActive = 
                      currentRoute === item.route || 
                      (item.route !== '/' && currentRoute.startsWith(item.route));
                    return (
                      <button
                        id={`mobile-nav-${item.id}`}
                        key={item.id}
                        onClick={() => handleNavClick(item.route)}
                        className={`w-full text-left px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                          isActive 
                            ? 'text-[#00BCFF] bg-[#00BCFF]/10 border-l-4 border-[#00BCFF] pl-3' 
                            : 'text-[#D2E2F5] hover:bg-white/5'
                        }`}
                      >
                        {getTranslation(lang, item.labelKey)}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Bottom controls in drawer */}
              <div className="border-t border-[#002B54] pt-6 space-y-4">
                <button
                  id="mobile-drawer-lang-btn"
                  onClick={toggleLanguage}
                  className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-[#002447]/50 border border-[#003B70] text-xs font-semibold text-[#D2E2F5]"
                >
                  <span className="flex items-center space-x-2">
                    <Globe className="w-4 h-4 text-[#00BCFF]" />
                    <span>Language</span>
                  </span>
                  <span className="text-white">{lang === 'zh' ? '繁體中文' : 'English'}</span>
                </button>

                <div className="text-center text-[10px] text-slate-500 font-mono">
                  TRA SMART METROPOLIS SYSTEM v3.5
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
