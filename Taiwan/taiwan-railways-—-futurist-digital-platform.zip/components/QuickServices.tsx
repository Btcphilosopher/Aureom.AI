'use client';

import * as React from 'react';
import { Clock, BadgeDollarSign, ClipboardList, QrCode, UserCheck } from 'lucide-react';
import { getTranslation, type Language } from '@/lib/i18n';

interface QuickServicesProps {
  lang: Language;
  setRoute: (route: string) => void;
}

export default function QuickServices({ lang, setRoute }: QuickServicesProps) {
  const services = [
    {
      id: 'timetable',
      titleKey: 'quick.timetable',
      icon: Clock,
      route: '/timetable'
    },
    {
      id: 'fares',
      titleKey: 'quick.fares',
      icon: BadgeDollarSign,
      route: '/fares'
    },
    {
      id: 'orders',
      titleKey: 'quick.orders',
      icon: ClipboardList,
      route: '/member?tab=orders'
    },
    {
      id: 'eticket',
      titleKey: 'quick.eticket',
      icon: QrCode,
      route: '/member?tab=tickets'
    },
    {
      id: 'member',
      titleKey: 'quick.member',
      icon: UserCheck,
      route: '/member'
    }
  ];

  return (
    <div 
      id="quick-services" 
      className="w-full bg-slate-900/20 backdrop-blur-md border border-white/10 rounded-2xl p-6 shadow-2xl"
    >
      {/* Horizontally scrollable container on mobile, grid on desktop */}
      <div className="flex md:grid md:grid-cols-5 gap-4 overflow-x-auto pb-2 md:pb-0 scrollbar-none snap-x">
        {services.map((srv) => {
          const IconComponent = srv.icon;
          return (
            <button
              id={`quick-service-btn-${srv.id}`}
              key={srv.id}
              onClick={() => setRoute(srv.route)}
              className="flex-shrink-0 w-[170px] md:w-auto snap-center flex items-center gap-4 p-4 rounded-xl border border-white/5 bg-white/5 text-slate-100 hover:text-white hover:border-cyan-500/50 hover:bg-white/10 hover:scale-[1.03] active:scale-95 transition-all duration-200 group text-left focus:outline-none focus:ring-2 focus:ring-cyan-500/40 cursor-pointer"
            >
              {/* Icon Container */}
              <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center text-cyan-400 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-all flex-shrink-0">
                <IconComponent className="w-5 h-5 text-cyan-400 group-hover:text-slate-950 transition-colors" />
              </div>

              {/* Text Information Column */}
              <div className="flex flex-col min-w-0">
                <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider truncate font-mono">
                  {srv.id}
                </p>
                <p className="text-sm font-semibold text-white leading-tight group-hover:text-cyan-400 transition-colors truncate">
                  {getTranslation(lang, srv.titleKey)}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
