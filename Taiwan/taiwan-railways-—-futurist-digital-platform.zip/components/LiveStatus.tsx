'use client';

import * as React from 'react';
import { motion } from 'motion/react';
import { RefreshCw, Navigation, AlertTriangle, CheckCircle, Flame, Train } from 'lucide-react';
import { LIVE_STATUS_DATA, type LiveTrainStatus } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface LiveStatusProps {
  lang: Language;
}

export default function LiveStatus({ lang }: LiveStatusProps) {
  const [statuses, setStatuses] = React.useState<LiveTrainStatus[]>(LIVE_STATUS_DATA);
  const [activeIdx, setActiveIdx] = React.useState(0);
  const [tick, setTick] = React.useState(0);

  // Simulated active ticker loop
  React.useEffect(() => {
    const interval = setInterval(() => {
      setStatuses((prev) =>
        prev.map((item) => {
          if (item.status === 'suspended') return item;
          
          let newProgress = item.progress + 1.5;
          let currentPosZh = item.currentPositionZh;
          let currentPosEn = item.currentPositionEn;

          if (newProgress >= 100) {
            newProgress = 0;
            currentPosZh = item.fromZh;
            currentPosEn = item.fromEn;
          } else if (newProgress > 75) {
            currentPosZh = item.toZh;
            currentPosEn = item.toEn;
          } else if (newProgress > 35 && newProgress < 40) {
            currentPosZh = '臺中';
            currentPosEn = 'Taichung';
          } else if (newProgress > 15 && newProgress < 20) {
            currentPosZh = '新竹';
            currentPosEn = 'Hsinchu';
          }

          return {
            ...item,
            progress: parseFloat(newProgress.toFixed(1)),
            currentPositionZh: currentPosZh,
            currentPositionEn: currentPosEn,
          };
        })
      );
      setTick((t) => t + 1);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const activeTrain = statuses[activeIdx];

  const getStatusBadge = (status: LiveTrainStatus['status']) => {
    switch (status) {
      case 'on-time':
        return {
          labelZh: '準點',
          labelEn: 'On Time',
          color: 'text-[#00FF88] bg-[#00FF88]/10 border-[#00FF88]/20',
          dot: 'bg-[#00FF88]',
          icon: CheckCircle
        };
      case 'delayed':
        return {
          labelZh: '延誤',
          labelEn: 'Delayed',
          color: 'text-[#FF4A4A] bg-[#FF4A4A]/10 border-[#FF4A4A]/20',
          dot: 'bg-[#FF4A4A]',
          icon: AlertTriangle
        };
      case 'suspended':
        return {
          labelZh: '停駛',
          labelEn: 'Suspended',
          color: 'text-slate-400 bg-slate-500/10 border-slate-500/20',
          dot: 'bg-slate-500',
          icon: AlertTriangle
        };
      case 'partial-delay':
        return {
          labelZh: '部分延誤',
          labelEn: 'Partial Delay',
          color: 'text-[#FFAE00] bg-[#FFAE00]/10 border-[#FFAE00]/20',
          dot: 'bg-[#FFAE00]',
          icon: AlertTriangle
        };
    }
  };

  return (
    <div 
      id="live-status-card" 
      className="w-full bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl flex flex-col h-full justify-between"
    >
      <div>
        {/* Header Row */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <span className="w-1 h-3.5 bg-cyan-500 rounded-sm" />
            <div>
              <h3 className="text-white font-bold text-sm leading-none uppercase tracking-wider">
                {getTranslation(lang, 'live.title')}
              </h3>
              <span className="text-slate-500 text-[9px] uppercase tracking-wider font-mono">
                {getTranslation(lang, 'live.subtitle')}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-1.5 bg-slate-950 px-2 py-1 rounded border border-white/5">
            <RefreshCw className="w-2.5 h-2.5 text-cyan-400 animate-spin" />
            <span className="text-[8px] text-slate-500 font-mono tracking-widest uppercase">
              {getTranslation(lang, 'live.simulatorActive')}
            </span>
          </div>
        </div>

        {/* Carousel Tabs for Quick Switch Trains */}
        <div className="flex space-x-1.5 overflow-x-auto pb-2 scrollbar-none mb-4 border-b border-white/10">
          {statuses.map((item, idx) => {
            const b = getStatusBadge(item.status);
            return (
              <button
                id={`live-tab-btn-${item.trainNo}`}
                key={item.id}
                onClick={() => setActiveIdx(idx)}
                className={`flex-shrink-0 px-2.5 py-1.5 rounded-lg border text-xs font-semibold flex items-center space-x-1.5 transition-all cursor-pointer ${
                  activeIdx === idx 
                    ? 'bg-slate-950 border-cyan-500 text-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.15)]' 
                    : 'bg-white/5 border-transparent text-slate-400 hover:text-white hover:bg-white/10'
                }`}
              >
                <span className="font-mono text-[10px]">{item.trainNo}</span>
                <span className={`w-1.5 h-1.5 rounded-full ${b.dot}`} />
              </button>
            );
          })}
        </div>

        {/* Selected Train Tracking Panel */}
        {activeTrain && (
          <div className="space-y-4">
            {/* Train details row */}
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] font-bold text-cyan-400 uppercase font-mono tracking-wide">
                  {lang === 'zh' ? activeTrain.typeZh : activeTrain.typeEn} {activeTrain.trainNo}
                </span>
                <div className="text-white font-extrabold text-base flex items-center space-x-1.5 mt-0.5">
                  <span>{lang === 'zh' ? activeTrain.fromZh : activeTrain.fromEn}</span>
                  <span className="text-slate-500 font-mono">→</span>
                  <span>{lang === 'zh' ? activeTrain.toZh : activeTrain.toEn}</span>
                </div>
              </div>

              {/* Status Badge */}
              {(() => {
                const b = getStatusBadge(activeTrain.status);
                const Icon = b.icon;
                return (
                  <div className={`flex items-center space-x-1 px-2.5 py-1 rounded-lg border text-xs font-bold ${b.color}`}>
                    <Icon className="w-3.5 h-3.5" />
                    <span>{lang === 'zh' ? b.labelZh : b.labelEn}</span>
                    {activeTrain.delayMinutes > 0 && (
                      <span className="font-mono font-black ml-1">+{activeTrain.delayMinutes}m</span>
                    )}
                  </div>
                );
              })()}
            </div>

            {/* Visual Track Sliding Line */}
            <div className="relative pt-6 pb-2 px-2">
              <div className="absolute left-0 right-0 h-[3px] bg-slate-800 top-8 rounded-full" />
              
              {/* Start Node */}
              <div className="absolute left-0 top-7 flex flex-col items-center">
                <div className="w-2.5 h-2.5 rounded-full bg-cyan-500 border-2 border-slate-900 shadow-[0_0_6px_rgba(6,182,212,0.8)]" />
                <span className="text-[9px] text-slate-500 mt-2 font-mono">{activeTrain.departureTime}</span>
              </div>

              {/* Moving Train Dot Overlay */}
              {activeTrain.status !== 'suspended' && (
                <div 
                  className="absolute top-4 -translate-x-1/2 flex flex-col items-center z-10 transition-all duration-1000 ease-out"
                  style={{ left: `${activeTrain.progress}%` }}
                >
                  <div className="bg-cyan-500 text-slate-950 p-1.5 rounded-lg border border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.5)]">
                    <Train className="w-3.5 h-3.5 rotate-90" />
                  </div>
                  <span className="text-[9px] font-bold text-cyan-400 mt-1 font-mono">{activeTrain.progress}%</span>
                </div>
              )}

              {/* End Node */}
              <div className="absolute right-0 top-7 flex flex-col items-center">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-700 border-2 border-slate-900" />
                <span className="text-[9px] text-slate-500 mt-2 font-mono">{activeTrain.expectedArrivalTime}</span>
              </div>
            </div>

            {/* Position details */}
            <div className="pt-8 flex justify-between text-xs border-t border-white/10">
              <span className="text-slate-400 flex items-center space-x-1">
                <Navigation className="w-3 h-3 text-cyan-400" />
                <span>{getTranslation(lang, 'live.position')}</span>
              </span>
              <span className="text-white font-bold">
                {lang === 'zh' ? activeTrain.currentPositionZh : activeTrain.currentPositionEn}
              </span>
            </div>
          </div>
        )}
      </div>

      <div className="text-[9px] text-slate-600 font-mono pt-4 text-center">
        TRA INTEGRATED SECURE FEED // REFRESHED INTERVAL: 4000ms
      </div>
    </div>
  );
}
