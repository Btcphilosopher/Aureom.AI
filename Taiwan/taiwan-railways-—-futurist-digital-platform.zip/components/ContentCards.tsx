'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Smartphone, Compass, ShieldCheck, Sparkles, X } from 'lucide-react';
import { getTranslation, type Language } from '@/lib/i18n';

interface ContentCardsProps {
  lang: Language;
  setRoute: (route: string) => void;
}

export default function ContentCards({ lang, setRoute }: ContentCardsProps) {
  const [activeModal, setActiveModal] = React.useState<string | null>(null);

  const cards = [
    {
      id: 'train',
      titleKey: 'card.newTrain.title',
      subtitleKey: 'card.newTrain.subtitle',
      descKey: 'card.newTrain.desc',
      image: 'https://picsum.photos/seed/futuristiccabin/800/600',
      route: '/about'
    },
    {
      id: 'explore',
      titleKey: 'card.explore.title',
      subtitleKey: 'card.explore.subtitle',
      descKey: 'card.explore.desc',
      image: 'https://picsum.photos/seed/formosacoast/800/600',
      route: '/explore'
    },
    {
      id: 'app',
      titleKey: 'card.app.title',
      subtitleKey: 'card.app.subtitle',
      descKey: 'card.app.desc',
      image: 'https://picsum.photos/seed/smartphoneapp/800/600',
      route: '/member'
    }
  ];

  return (
    <div id="content-cards-section" className="w-full">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {cards.map((card) => (
          <div
            id={`content-card-${card.id}`}
            key={card.id}
            className="group relative bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden shadow-lg hover:border-cyan-500 transition-all duration-300 flex flex-col h-[380px]"
          >
            {/* Visual Header Image Section with Hover Zoom */}
            <div className="relative h-44 overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent z-10" />
              <img
                src={card.image}
                alt={getTranslation(lang, card.titleKey)}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 left-4 z-20 bg-black/60 backdrop-blur-md px-2.5 py-1 rounded text-[9px] uppercase tracking-wider text-cyan-400 border border-cyan-500/30 font-mono">
                {card.id === 'train' ? 'FLEET 2030' : card.id === 'explore' ? 'TRAVEL' : 'MOBILE APP'}
              </div>
            </div>

            {/* Content Body */}
            <div className="p-5 flex-1 flex flex-col justify-between">
              <div>
                <h4 className="text-white font-extrabold text-base leading-tight group-hover:text-cyan-400 transition-colors">
                  {getTranslation(lang, card.titleKey)}
                </h4>
                <p className="text-slate-400 font-semibold text-[10px] tracking-wider uppercase font-mono mt-0.5 mb-2">
                  {getTranslation(lang, card.subtitleKey)}
                </p>
                <p className="text-slate-400 text-xs leading-relaxed line-clamp-3">
                  {getTranslation(lang, card.descKey)}
                </p>
              </div>

              {/* CTA triggers */}
              <div className="pt-4 border-t border-white/5 flex items-center justify-between">
                <button
                  id={`card-learn-more-btn-${card.id}`}
                  onClick={() => {
                    if (card.id === 'app') {
                      setActiveModal('app');
                    } else {
                      setRoute(card.route);
                    }
                  }}
                  className="inline-flex items-center space-x-1.5 text-xs font-bold text-cyan-400 hover:text-white transition-all group-hover:underline"
                >
                  <span>{getTranslation(lang, 'card.more')}</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Mini App Simulation Modal */}
      <AnimatePresence>
        {activeModal === 'app' && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveModal(null)}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed left-1/2 -translate-x-1/2 top-[12%] w-[340px] h-[550px] bg-slate-900 border-2 border-white/10 rounded-[32px] p-6 shadow-2xl z-50 flex flex-col justify-between overflow-hidden"
            >
              {/* Smartphone Speaker notch */}
              <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-black rounded-full flex items-center justify-center">
                <div className="w-8 h-1 bg-slate-800 rounded-full" />
              </div>

              {/* Close Phone */}
              <div className="flex justify-between items-center pt-2">
                <span className="text-[10px] text-slate-400 font-mono">10:45 AM</span>
                <button 
                  id="close-app-modal"
                  onClick={() => setActiveModal(null)} 
                  className="p-1 rounded-full bg-white/5 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Phone Content Screen */}
              <div className="flex-1 bg-slate-950 border border-white/5 rounded-2xl my-3 p-4 flex flex-col justify-between text-left relative overflow-hidden">
                {/* Header */}
                <div className="flex items-center space-x-2 border-b border-white/5 pb-2">
                  <Smartphone className="w-5 h-5 text-cyan-400" />
                  <div>
                    <h5 className="text-white text-xs font-black">臺鐵智慧行動卡</h5>
                    <p className="text-[8px] text-slate-400 uppercase font-mono">TRA PASS v3.0</p>
                  </div>
                </div>

                {/* Virtual Card */}
                <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-white/10 rounded-xl p-3 shadow-lg my-3 space-y-4">
                  <div className="flex justify-between items-center text-[8px] text-cyan-400 font-semibold tracking-wider">
                    <span>MEMBER METRO CARD</span>
                    <Sparkles className="w-3 h-3 text-cyan-400 animate-pulse" />
                  </div>
                  <div>
                    <div className="text-[9px] text-slate-500">Cardholder</div>
                    <div className="text-xs font-bold text-white">WANG XIAO-MING</div>
                  </div>
                  <div className="flex justify-between items-end">
                    <div>
                      <div className="text-[9px] text-slate-500">TPASS Status</div>
                      <div className="text-[10px] font-bold text-[#00FF88]">ACTIVE</div>
                    </div>
                    {/* NFC Tap motif */}
                    <div className="w-7 h-7 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                      <Compass className="w-4 h-4 text-cyan-400" />
                    </div>
                  </div>
                </div>

                {/* Sub features list */}
                <div className="space-y-1.5 flex-1 overflow-y-auto">
                  <div className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5">
                    <span className="text-[10px] text-white font-medium">🚄 EMU3000 Onboard Bento Order</span>
                    <span className="text-[9px] text-cyan-400 font-mono">Order</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5">
                    <span className="text-[10px] text-white font-medium">🔔 Smart Push Delay Warnings</span>
                    <span className="text-[9px] text-cyan-400 font-mono">On</span>
                  </div>
                </div>

                {/* QR Code trigger */}
                <div className="flex flex-col items-center border-t border-white/5 pt-2 mt-2">
                  <div className="bg-white p-1 rounded-lg">
                    <svg className="w-14 h-14 text-black" viewBox="0 0 100 100" fill="currentColor">
                      <rect x="10" y="10" width="20" height="20" />
                      <rect x="70" y="10" width="20" height="20" />
                      <rect x="10" y="70" width="20" height="20" />
                      <rect x="40" y="40" width="20" height="20" />
                      <rect x="70" y="70" width="10" height="10" />
                      <rect x="80" y="80" width="10" height="10" />
                    </svg>
                  </div>
                  <span className="text-[8px] text-slate-500 mt-1 uppercase font-mono tracking-widest">TAP AT GATES</span>
                </div>
              </div>

              {/* Bottom Home Indicator Bar */}
              <div className="w-24 h-1 bg-slate-700 mx-auto rounded-full mt-2" />
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
