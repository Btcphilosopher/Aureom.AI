/* eslint-disable react-hooks/set-state-in-effect */
'use client';

import * as React from 'react';
import { motion } from 'motion/react';
import { Search, Train, Clock, ArrowRight, AlertCircle, Info, Ticket } from 'lucide-react';
import { STATIONS, searchTrains, type Journey } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface TimetableSectionProps {
  lang: Language;
  onBook: (fromId: string, toId: string, journeyId: string) => void;
}

export default function TimetableSection({ lang, onBook }: TimetableSectionProps) {
  const [fromStation, setFromStation] = React.useState('TPE');
  const [toStation, setToStation] = React.useState('KHH');
  const [date, setDate] = React.useState('2026-08-28');
  const [searched, setSearched] = React.useState(true);
  const [results, setResults] = React.useState<Journey[]>([]);
  const [selectedJourney, setSelectedJourney] = React.useState<Journey | null>(null);

  React.useEffect(() => {
    if (searched) {
      setResults(searchTrains(fromStation, toStation, date));
    }
  }, [fromStation, toStation, date, searched]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    setSelectedJourney(null);
  };

  return (
    <section id="timetable-page-container" className="w-full py-6 space-y-8 text-left">
      
      {/* Title Header */}
      <div className="border-b border-white/10 pb-5">
        <h2 className="text-3xl font-extrabold text-white tracking-tight">
          {getTranslation(lang, 'timetable.title')}
        </h2>
        <p className="text-slate-400 text-sm mt-1">
          {getTranslation(lang, 'timetable.subtitle')}
        </p>
      </div>

      {/* Grid: Inputs Form & Results Table */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Inputs Card */}
        <div className="lg:col-span-1">
          <form onSubmit={handleSearch} className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-5 space-y-4 shadow-lg">
            <div>
              <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-2" htmlFor="tt-from">
                {getTranslation(lang, 'booking.from')}
              </label>
              <select
                id="tt-from"
                value={fromStation}
                onChange={(e) => { setFromStation(e.target.value); setSearched(false); }}
                className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-2.5 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50 cursor-pointer"
              >
                {STATIONS.map(s => <option key={s.id} value={s.id} className="bg-slate-900">{s.zh} {s.en}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-2" htmlFor="tt-to">
                {getTranslation(lang, 'booking.to')}
              </label>
              <select
                id="tt-to"
                value={toStation}
                onChange={(e) => { setToStation(e.target.value); setSearched(false); }}
                className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-2.5 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50 cursor-pointer"
              >
                {STATIONS.map(s => <option key={s.id} value={s.id} className="bg-slate-900">{s.zh} {s.en}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-2" htmlFor="tt-date">
                {getTranslation(lang, 'booking.date')}
              </label>
              <input
                id="tt-date"
                type="date"
                value={date}
                onChange={(e) => { setDate(e.target.value); setSearched(false); }}
                className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-2.5 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50 cursor-pointer"
              />
            </div>

            <button
              id="tt-search-btn"
              type="submit"
              className="w-full flex items-center justify-center space-x-2 bg-cyan-500 text-slate-950 hover:bg-cyan-400 py-3 rounded-xl font-bold text-xs uppercase tracking-wider transition-all cursor-pointer shadow-[0_4px_15px_rgba(6,182,212,0.25)]"
            >
              <Search className="w-4 h-4 stroke-[2.5]" />
              <span>{getTranslation(lang, 'booking.search')}</span>
            </button>
          </form>
        </div>

        {/* Right Timetable Table Display */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden shadow-lg">
            
            {/* Table Header */}
            <div className="hidden md:grid grid-cols-12 gap-2 bg-slate-950 px-6 py-4 text-xs font-bold text-slate-400 border-b border-white/10 uppercase tracking-wider">
              <div className="col-span-3">{getTranslation(lang, 'timetable.col.train')}</div>
              <div className="col-span-2">{getTranslation(lang, 'timetable.col.dep')}</div>
              <div className="col-span-2">{getTranslation(lang, 'timetable.col.arr')}</div>
              <div className="col-span-2">{getTranslation(lang, 'timetable.col.dur')}</div>
              <div className="col-span-2 text-center">{getTranslation(lang, 'timetable.col.status')}</div>
              <div className="col-span-1 text-right">{getTranslation(lang, 'timetable.col.action')}</div>
            </div>

            {/* Results Row Listing */}
            <div className="divide-y divide-white/5">
              {results.length > 0 ? (
                results.map((jrn) => (
                  <button
                    id={`timetable-row-btn-${jrn.id}`}
                    key={jrn.id}
                    onClick={() => setSelectedJourney(selectedJourney?.id === jrn.id ? null : jrn)}
                    className={`w-full text-left grid grid-cols-1 md:grid-cols-12 gap-2 px-6 py-4 items-center hover:bg-slate-900/60 transition-all text-xs font-medium ${
                      selectedJourney?.id === jrn.id ? 'bg-slate-900/80' : ''
                    }`}
                  >
                    {/* Mobile layouts stack items */}
                    <div className="col-span-3 font-bold text-white flex items-center space-x-2">
                      <Train className="w-4 h-4 text-cyan-400/80" />
                      <div>
                        <span className="block text-white font-bold">{lang === 'zh' ? jrn.typeZh : jrn.typeEn}</span>
                        <span className="text-slate-500 font-mono font-bold text-[10px]">{jrn.trainNo} 車次</span>
                      </div>
                    </div>

                    <div className="col-span-2 font-mono font-bold text-sm text-white pt-2 md:pt-0">
                      <span className="md:hidden text-slate-400 mr-1">Dep:</span>{jrn.departureTime}
                    </div>

                    <div className="col-span-2 font-mono font-bold text-sm text-white">
                      <span className="md:hidden text-slate-400 mr-1">Arr:</span>{jrn.arrivalTime}
                    </div>

                    <div className="col-span-2 text-slate-300 font-mono">
                      <span className="md:hidden text-slate-400 mr-1">Duration:</span>{jrn.duration}
                    </div>

                    <div className="col-span-2 text-center pt-2 md:pt-0">
                      <span className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-md text-[10px] font-bold border ${
                        jrn.status === 'on-time' 
                          ? 'text-[#00FF88] bg-[#00FF88]/10 border-[#00FF88]/20' 
                          : jrn.status === 'delayed'
                            ? 'text-[#FF4A4A] bg-[#FF4A4A]/10 border-[#FF4A4A]/20'
                            : 'text-slate-400 bg-slate-500/10 border-slate-500/20'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${jrn.status === 'on-time' ? 'bg-[#00FF88]' : jrn.status === 'delayed' ? 'bg-[#FF4A4A]' : 'bg-slate-500'}`} />
                        <span>{jrn.status === 'on-time' ? getTranslation(lang, 'live.onTime') : jrn.status === 'delayed' ? `${getTranslation(lang, 'live.delayed')} +${jrn.delayMinutes}m` : getTranslation(lang, 'live.suspended')}</span>
                      </span>
                    </div>

                    <div className="col-span-1 text-right pt-2 md:pt-0 flex md:block justify-between items-center">
                      <span className="md:hidden text-slate-400">Book:</span>
                      {jrn.status !== 'suspended' ? (
                        <button
                          id={`timetable-row-book-${jrn.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onBook(fromStation, toStation, jrn.id);
                          }}
                          className="bg-cyan-500/10 hover:bg-cyan-500 text-cyan-400 hover:text-slate-950 p-2 rounded-lg border border-cyan-500/30 transition-all"
                          title="Instant Book"
                        >
                          <Ticket className="w-4 h-4" />
                        </button>
                      ) : (
                        <span className="text-slate-500 font-bold text-xs">-</span>
                      )}
                    </div>

                    {/* Expandable Click Details Panel */}
                    {selectedJourney?.id === jrn.id && (
                      <div className="col-span-12 mt-4 bg-slate-950/80 border border-white/10 rounded-xl p-4 space-y-2 text-slate-300 font-sans leading-relaxed text-left">
                        <div className="flex items-center space-x-1.5 text-xs text-cyan-400 font-bold">
                          <Info className="w-3.5 h-3.5" />
                          <span>列車營運詳細特徵 / Vehicle Specifications</span>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs pt-2">
                          <div>
                            <span className="block text-slate-500">搭載席位 / Seat Matrix</span>
                            <span className="font-bold text-white">{jrn.availableSeats} Seats Available</span>
                          </div>
                          <div>
                            <span className="block text-slate-500">提供服務 / Services</span>
                            <span className="font-bold text-white">{jrn.features.join(', ')}</span>
                          </div>
                          <div>
                            <span className="block text-slate-500">單程票價 / Fare</span>
                            <span className="font-bold text-cyan-400">NT$ {jrn.fare}</span>
                          </div>
                          <div>
                            <span className="block text-slate-500">運行路徑 / Route sector</span>
                            <span className="font-bold text-white">{jrn.fromZh} ➜ {jrn.toZh}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </button>
                ))
              ) : (
                <div className="p-8 text-center text-slate-500 text-xs">
                  {getTranslation(lang, 'search.noResults')}
                </div>
              )}
            </div>

          </div>
          
          {/* Demo Disclaimer notice */}
          <div className="flex items-start space-x-2 bg-slate-900/30 border border-white/10 rounded-xl p-4 text-[11px] text-slate-400">
            <AlertCircle className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
            <p>{getTranslation(lang, 'search.demoWarning')}</p>
          </div>
        </div>

      </div>
    </section>
  );
}
