'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeftRight, Calendar, Users, ChevronDown, Search, Plus, Minus } from 'lucide-react';
import { STATIONS, type Station } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface BookingWidgetProps {
  lang: Language;
  onSearch: (from: string, to: string, date: string, passengers: { adult: number; child: number; senior: number }) => void;
  initialFrom?: string;
  initialTo?: string;
  initialDate?: string;
}

export default function BookingWidget({ 
  lang, 
  onSearch,
  initialFrom = 'TPE', 
  initialTo = 'KHH',
  initialDate = '2026-08-28'
}: BookingWidgetProps) {
  const [fromStation, setFromStation] = React.useState(initialFrom);
  const [toStation, setToStation] = React.useState(initialTo);
  const [date, setDate] = React.useState(initialDate);
  
  const [passengers, setPassengers] = React.useState({
    adult: 1,
    child: 0,
    senior: 0
  });

  const [passDropdownOpen, setPassDropdownOpen] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setPassDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const totalPassengers = passengers.adult + passengers.child + passengers.senior;

  const handleSwap = () => {
    const temp = fromStation;
    setFromStation(toStation);
    setToStation(temp);
  };

  const handleIncrement = (type: 'adult' | 'child' | 'senior') => {
    setPassengers(prev => ({
      ...prev,
      [type]: prev[type] + 1
    }));
  };

  const handleDecrement = (type: 'adult' | 'child' | 'senior') => {
    if (type === 'adult' && passengers.adult <= 1) return; // Must have at least 1 adult
    if (passengers[type] <= 0) return;
    setPassengers(prev => ({
      ...prev,
      [type]: prev[type] - 1
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(fromStation, toStation, date, passengers);
  };

  return (
    <div 
      id="booking-card" 
      className="w-full bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Card Title Header with custom Professional Polish side accent */}
        <div className="flex items-center space-x-3 border-b border-white/10 pb-4 mb-6">
          <span className="w-1.5 h-4 bg-cyan-500 rounded-sm"></span>
          <div>
            <h3 className="text-sm font-bold tracking-widest uppercase text-white">
              {getTranslation(lang, 'booking.title')}
            </h3>
            <p className="text-slate-500 text-[10px] uppercase tracking-wider font-mono">
              {getTranslation(lang, 'booking.subtitle')}
            </p>
          </div>
        </div>

        {/* Station Selection Fields Row */}
        <div className="grid grid-cols-1 md:grid-cols-11 gap-4 items-center">
          
          {/* From Station Input */}
          <div className="md:col-span-5 relative">
            <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-2" htmlFor="from-station-select">
              {getTranslation(lang, 'booking.from')}
            </label>
            <select
              id="from-station-select"
              value={fromStation}
              onChange={(e) => setFromStation(e.target.value)}
              className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-3 text-white font-bold text-base focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all cursor-pointer appearance-none"
            >
              {STATIONS.map((st) => (
                <option key={st.id} value={st.id} className="bg-slate-900">
                  {st.zh} {st.en}
                </option>
              ))}
            </select>
            <div className="absolute right-4 bottom-3.5 pointer-events-none text-slate-400">
              <ChevronDown className="w-4 h-4" />
            </div>
          </div>

          {/* Swap Button Column */}
          <div className="md:col-span-1 flex justify-center pt-5">
            <button
              id="swap-station-btn"
              type="button"
              onClick={handleSwap}
              className="p-3 rounded-full border border-white/10 bg-slate-950/50 text-cyan-400 hover:bg-cyan-500 hover:text-slate-950 transition-all duration-200 transform hover:rotate-180 focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              title={getTranslation(lang, 'booking.swap')}
              aria-label="Swap departure and destination"
            >
              <ArrowLeftRight className="w-4 h-4" />
            </button>
          </div>

          {/* To Station Input */}
          <div className="md:col-span-5 relative">
            <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-2" htmlFor="to-station-select">
              {getTranslation(lang, 'booking.to')}
            </label>
            <select
              id="to-station-select"
              value={toStation}
              onChange={(e) => setToStation(e.target.value)}
              className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-3 text-white font-bold text-base focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all cursor-pointer appearance-none"
            >
              {STATIONS.map((st) => (
                <option key={st.id} value={st.id} className="bg-slate-900">
                  {st.zh} {st.en}
                </option>
              ))}
            </select>
            <div className="absolute right-4 bottom-3.5 pointer-events-none text-slate-400">
              <ChevronDown className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* Date and Passengers Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Date Picker Input */}
          <div className="relative">
            <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-2" htmlFor="date-input">
              {getTranslation(lang, 'booking.date')}
            </label>
            <div className="relative">
              <input
                id="date-input"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                min="2026-01-01"
                className="w-full bg-slate-950/50 border border-white/10 rounded-lg pl-11 pr-4 py-3 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all cursor-pointer"
              />
              <Calendar className="absolute left-4 top-3.5 w-4 h-4 text-cyan-400" />
            </div>
          </div>

          {/* Passengers Custom Selector Popover */}
          <div className="relative" ref={dropdownRef}>
            <label className="block text-[10px] text-slate-500 uppercase font-bold tracking-wider mb-2" id="passengers-label">
              {getTranslation(lang, 'booking.passengers')}
            </label>
            <button
              id="passenger-dropdown-btn"
              type="button"
              onClick={() => setPassDropdownOpen(!passDropdownOpen)}
              className="w-full flex items-center justify-between bg-slate-950/50 border border-white/10 rounded-lg pl-11 pr-4 py-3 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50 transition-all text-left"
              aria-haspopup="true"
              aria-expanded={passDropdownOpen}
              aria-labelledby="passengers-label"
            >
              <div className="flex items-center">
                <Users className="absolute left-4 top-3.5 w-4 h-4 text-cyan-400" />
                <span className="truncate">
                  {getTranslation(lang, 'booking.passengerCount', { count: totalPassengers })}
                </span>
              </div>
              <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${passDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {/* Dropdown Overlay Pane */}
            <AnimatePresence>
              {passDropdownOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute left-0 right-0 mt-2 border border-white/10 rounded-xl p-5 shadow-2xl z-30 space-y-4 bg-slate-900/95 backdrop-blur-md"
                >
                  {/* Adult Rows */}
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-white text-sm font-semibold">{getTranslation(lang, 'booking.adult')}</div>
                      <div className="text-slate-400 text-[10px]">NT$ Full Fare</div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <button
                        id="dec-adult-btn"
                        type="button"
                        onClick={() => handleDecrement('adult')}
                        className="w-8 h-8 rounded-lg bg-slate-950/50 border border-white/10 text-slate-300 hover:text-cyan-400 hover:border-cyan-400 flex items-center justify-center transition-all disabled:opacity-30"
                        disabled={passengers.adult <= 1}
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-white font-bold text-sm w-4 text-center">{passengers.adult}</span>
                      <button
                        id="inc-adult-btn"
                        type="button"
                        onClick={() => handleIncrement('adult')}
                        className="w-8 h-8 rounded-lg bg-slate-950/50 border border-white/10 text-slate-300 hover:text-cyan-400 hover:border-cyan-400 flex items-center justify-center transition-all"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Child Rows */}
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-white text-sm font-semibold">{getTranslation(lang, 'booking.child')}</div>
                      <div className="text-slate-400 text-[10px]">50% Fare Discount</div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <button
                        id="dec-child-btn"
                        type="button"
                        onClick={() => handleDecrement('child')}
                        className="w-8 h-8 rounded-lg bg-slate-950/50 border border-white/10 text-slate-300 hover:text-cyan-400 hover:border-cyan-400 flex items-center justify-center transition-all disabled:opacity-30"
                        disabled={passengers.child <= 0}
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-white font-bold text-sm w-4 text-center">{passengers.child}</span>
                      <button
                        id="inc-child-btn"
                        type="button"
                        onClick={() => handleIncrement('child')}
                        className="w-8 h-8 rounded-lg bg-slate-950/50 border border-white/10 text-slate-300 hover:text-cyan-400 hover:border-cyan-400 flex items-center justify-center transition-all"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Senior Rows */}
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-white text-sm font-semibold">{getTranslation(lang, 'booking.senior')}</div>
                      <div className="text-slate-400 text-[10px]">65+ Concession / 半價</div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <button
                        id="dec-senior-btn"
                        type="button"
                        onClick={() => handleDecrement('senior')}
                        className="w-8 h-8 rounded-lg bg-slate-950/50 border border-white/10 text-slate-300 hover:text-cyan-400 hover:border-cyan-400 flex items-center justify-center transition-all disabled:opacity-30"
                        disabled={passengers.senior <= 0}
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="text-white font-bold text-sm w-4 text-center">{passengers.senior}</span>
                      <button
                        id="inc-senior-btn"
                        type="button"
                        onClick={() => handleIncrement('senior')}
                        className="w-8 h-8 rounded-lg bg-slate-950/50 border border-white/10 text-slate-300 hover:text-cyan-400 hover:border-cyan-400 flex items-center justify-center transition-all"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Footer Text */}
                  <div className="text-[10px] text-slate-400 border-t border-white/10 pt-2 text-center">
                    {getTranslation(lang, 'booking.passengerDetail', passengers)}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Submit Search Button */}
        <button
          id="search-trains-submit"
          type="submit"
          className="w-full flex items-center justify-center space-x-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 py-4 rounded-xl font-bold uppercase tracking-wider shadow-[0_4px_20px_rgba(6,182,212,0.25)] hover:shadow-[0_4px_25px_rgba(6,182,212,0.45)] transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
        >
          <Search className="w-4 h-4 stroke-[2.5]" />
          <span className="tracking-wider">{getTranslation(lang, 'booking.search')}</span>
        </button>
      </form>
    </div>
  );
}
