'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, Play, Pause, ArrowRight } from 'lucide-react';
import { getTranslation, type Language } from '@/lib/i18n';

interface HeroSectionProps {
  lang: Language;
  setRoute: (route: string) => void;
}

const SLIDES = [
  {
    id: 1,
    image: 'https://picsum.photos/seed/taipei101/1600/900',
    titleZh: '前進未來　連結臺灣',
    titleEn: 'Connecting Taiwan, Advancing the Future',
    subtitleZh: '次世代軌道科技與綠能美學，引領明日低碳安全行。',
    subtitleEn: 'Pioneering carbon-neutral transport through green energy & next-gen rail tech.',
  },
  {
    id: 2,
    image: 'https://picsum.photos/seed/hualiencoast/1600/900',
    titleZh: '山海隨行　極致舒適',
    titleEn: 'Scenic Splendors, Supreme Comfort',
    subtitleZh: '穿梭雄偉中央山脈與壯麗太平洋，漫遊福爾摩沙。',
    subtitleEn: 'Glide effortlessly between majestic peak forests and blue ocean breeze.',
  },
  {
    id: 3,
    image: 'https://picsum.photos/seed/futuretrain/1600/900',
    titleZh: '智慧出行　感應隨行',
    titleEn: 'Seamless Flow, Intelligent Transit',
    subtitleZh: '結合5G感測與AI導航，全面升級您每日的通勤網絡。',
    subtitleEn: 'Harness the power of high-speed AI routing and real-time smart tickets.',
  }
];

export default function HeroSection({ lang, setRoute }: HeroSectionProps) {
  const [currentSlide, setCurrentSlide] = React.useState(0);
  const [isPlaying, setIsPlaying] = React.useState(true);
  const timerRef = React.useRef<NodeJS.Timeout | null>(null);

  const nextSlide = React.useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  }, []);

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);
  };

  // Autoplay functionality
  React.useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        nextSlide();
      }, 5500);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, nextSlide]);

  const titleParts = SLIDES[currentSlide].titleZh.split(/[\s　]+/);

  return (
    <section 
      id="hero-carousel"
      className="relative w-full h-[400px] md:h-[500px] lg:h-[620px] bg-slate-950 overflow-hidden flex items-center rounded-2xl border border-white/10 shadow-2xl"
      onMouseEnter={() => setIsPlaying(false)}
      onMouseLeave={() => setIsPlaying(true)}
      aria-label="Cinematic Slideshow"
    >
      {/* Background Images with Cross-fading */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0.3, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0.3, scale: 0.95 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="absolute inset-0 w-full h-full"
        >
          {/* Dark Overlay Gradient to enhance text legibility */}
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/60 to-transparent z-10" />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/30 z-10" />
          
          <img
            src={SLIDES[currentSlide].image}
            alt="Futuristic Railway Vision"
            className="w-full h-full object-cover object-center"
            loading="lazy"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </AnimatePresence>

      {/* Hero Core Content Layout */}
      <div className="relative max-w-7xl mx-auto px-6 sm:px-10 lg:px-12 w-full z-20 pointer-events-none">
        <div className="max-w-2xl text-left text-white pointer-events-auto">
          {/* Subtle Tagline resembling the Professional Polish spec */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex items-center gap-2 mb-4"
          >
            <div className="h-px w-8 bg-cyan-400"></div>
            <span className="text-cyan-400 text-xs tracking-[0.25em] font-bold uppercase">
              {lang === 'zh' ? '智慧運輸 FUTURE MOBILITY' : 'FUTURE MOBILITY'}
            </span>
          </motion.div>

          {/* Core Bilingual Headline with elegant light-vs-bold weights */}
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-4xl md:text-5xl lg:text-7xl font-light leading-[1.1] mb-6 text-white"
          >
            {lang === 'zh' ? (
              <>
                {titleParts[0]}
                <br />
                <span className="font-bold text-white">{titleParts[1] || ''}</span>
              </>
            ) : (
              <span className="font-bold text-white">{SLIDES[currentSlide].titleEn}</span>
            )}
          </motion.h2>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-slate-300 text-base lg:text-lg mb-8 max-w-lg leading-relaxed font-normal"
          >
            {lang === 'zh' ? SLIDES[currentSlide].subtitleZh : SLIDES[currentSlide].subtitleEn}
          </motion.p>

          {/* CTA Link */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <button
              id="hero-cta-btn"
              onClick={() => setRoute('/explore')}
              className="group flex items-center gap-4 bg-white text-slate-950 px-8 py-4 rounded-full font-bold hover:bg-cyan-400 transition-all hover:scale-[1.03] active:scale-95 cursor-pointer"
            >
              <span className="text-sm font-bold uppercase tracking-wider">
                {lang === 'zh' ? '探索更多 Explore' : 'Explore Formosa'}
              </span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform stroke-[2.5]" />
            </button>
          </motion.div>
        </div>
      </div>

      {/* Slideshow Control Panel (Static bottom controls) */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex items-center bg-slate-900/60 backdrop-blur-md border border-white/10 px-4 py-2 rounded-full space-x-4">
        {/* Prev Arrow */}
        <button
          id="prev-slide-btn"
          onClick={prevSlide}
          className="text-slate-300 hover:text-cyan-400 transition-colors focus:outline-none"
          aria-label="Previous Slide"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        {/* Slide Indicators */}
        <div className="flex space-x-2">
          {SLIDES.map((_, idx) => (
            <button
              id={`slide-indicator-${idx}`}
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`w-2 h-2 rounded-full transition-all duration-300 focus:outline-none ${
                currentSlide === idx 
                  ? 'bg-cyan-400 w-5' 
                  : 'bg-white/20 hover:bg-white/50'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* Next Arrow */}
        <button
          id="next-slide-btn"
          onClick={nextSlide}
          className="text-slate-300 hover:text-cyan-400 transition-colors focus:outline-none"
          aria-label="Next Slide"
        >
          <ChevronRight className="w-4 h-4" />
        </button>

        {/* Play/Pause Button */}
        <div className="w-[1px] h-4 bg-white/10" />
        <button
          id="play-pause-btn"
          onClick={() => setIsPlaying(!isPlaying)}
          className="text-slate-300 hover:text-cyan-400 transition-colors focus:outline-none"
          aria-label={isPlaying ? 'Pause Autoplay' : 'Play Autoplay'}
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
        </button>
      </div>
    </section>
  );
}
