'use client';

import * as React from 'react';
import { Home, Calendar, Compass, User, Search } from 'lucide-react';
import { getTranslation, type Language } from '@/lib/i18n';

interface MobileBottomNavProps {
  lang: Language;
  route: string;
  setRoute: (route: string) => void;
}

export default function MobileBottomNav({ lang, route, setRoute }: MobileBottomNavProps) {
  
  const navItems = [
    { id: '/', icon: Home, labelKey: 'nav.home' },
    { id: '/ticketing', icon: Search, labelKey: 'nav.booking' },
    { id: '/timetable', icon: Calendar, labelKey: 'nav.timetable' },
    { id: '/explore', icon: Compass, labelKey: 'nav.explore' },
    { id: '/member', icon: User, labelKey: 'nav.member' }
  ];

  return (
    <nav 
      id="mobile-bottom-navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-slate-950/95 backdrop-blur-md border-t border-white/10 pb-safe"
    >
      <div className="grid grid-cols-5 h-14 items-center">
        {navItems.map((item) => {
          const Icon = item.icon;
          // Subroute matching logic
          const isActive = route === item.id || (item.id !== '/' && route.startsWith(item.id));
          
          return (
            <button
              id={`mobile-nav-btn-${item.id === '/' ? 'home' : item.id.replace('/', '')}`}
              key={item.id}
              onClick={() => {
                setRoute(item.id);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex flex-col items-center justify-center space-y-1 h-full cursor-pointer"
            >
              <Icon 
                className={`w-5 h-5 transition-colors ${
                  isActive ? 'text-cyan-400' : 'text-slate-500'
                }`} 
              />
              <span 
                className={`text-[8px] font-bold leading-none tracking-wider ${
                  isActive ? 'text-white' : 'text-slate-600'
                }`}
              >
                {getTranslation(lang, item.labelKey).split(' ')[0]}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
