'use client';

import * as React from 'react';
import { ShieldCheck, Info, HelpCircle, Phone, HeartHandshake, Compass, Leaf, Milestone } from 'lucide-react';
import { getTranslation, type Language } from '@/lib/i18n';

interface AboutSectionProps {
  lang: Language;
}

export default function AboutSection({ lang }: AboutSectionProps) {
  return (
    <section id="about-tra-page" className="w-full py-6 space-y-8 text-left">
      
      {/* Title Header */}
      <div className="border-b border-white/10 pb-5">
        <h2 className="text-3xl font-extrabold text-white tracking-tight">
          {getTranslation(lang, 'nav.about')}
        </h2>
        <p className="text-slate-400 text-sm mt-1">
          {lang === 'zh' ? '國營臺灣鐵路股份有限公司 — 迎向 2030 軌道新未來' : 'Taiwan Railway Corporation, Ltd. — Stepping Into The 2030 Future'}
        </p>
      </div>

      {/* Grid: 2 columns */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Left Columns - Corporate Profile & Vision */}
        <div className="md:col-span-2 space-y-6">
          
          {/* Card 1: Future vision */}
          <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 space-y-4 shadow-lg">
            <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold font-mono uppercase">
              <Milestone className="w-4 h-4" />
              <span>FUTURE MOBILITY MILESTONES</span>
            </div>
            <h3 className="text-white font-extrabold text-lg leading-tight">
              {lang === 'zh' ? '永續綠能與極速聯結' : 'Sustainability and Fast Connections'}
            </h3>
            <p className="text-slate-300 text-xs leading-relaxed">
              {lang === 'zh' 
                ? '臺鐵公司於2024年國營公司化後，全面啟動次世代鐵道升級。我們承諾於2030年前達成全線智慧電網覆蓋與淨零碳排營運，並與台灣高速鐵路（THSR）深度協同，打造無縫、流暢的低碳全島半日交通生活圈。'
                : 'Following its incorporation in 2024, Taiwan Railway Corporation has launched its next-generation smart railroad upgrade. We commit to reaching 100% smart grid coverage and carbon-neutral operations by 2030, establishing a half-day island-wide transport net.'
              }
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="bg-slate-950 border border-white/10 p-3.5 rounded-xl flex items-center space-x-3 text-xs">
                <Leaf className="w-5 h-5 text-[#00FF88] flex-shrink-0" />
                <div>
                  <span className="font-bold text-white block">Eco-Friendly Tech</span>
                  <span className="text-[10px] text-slate-400">100% Renewable power feeds</span>
                </div>
              </div>
              <div className="bg-slate-950 border border-white/10 p-3.5 rounded-xl flex items-center space-x-3 text-xs">
                <ShieldCheck className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                <div>
                  <span className="font-bold text-white block">AI Safety First</span>
                  <span className="text-[10px] text-slate-400">3D Lidar hazard alerts</span>
                </div>
              </div>
            </div>
          </div>

          {/* Card 2: Accessibility */}
          <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 space-y-3 shadow-lg">
            <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold font-mono uppercase">
              <HeartHandshake className="w-4 h-4" />
              <span>ACCESSIBILITY POLICY</span>
            </div>
            <h3 className="text-white font-extrabold text-lg leading-tight">
              {getTranslation(lang, 'footer.accessibility')}
            </h3>
            <p className="text-slate-300 text-xs leading-relaxed">
              {lang === 'zh'
                ? '我們致力於提供每位旅客無障礙、尊榮安心的乘車體驗。全台各大樞紐車站均配備自動化輪椅渡板、主動光學導盲導航與無縫行李智能轉運系統。若您需要專人乘車引導，歡迎撥打24小時客服熱線或於APP一鍵預約。'
                : 'We are committed to providing a barrier-free, seamless boarding experience for all. All major hubs are secured with automated wheelchair ramps, high-precision audio braille navigation, and smart baggage transit. Book personal guides via the app.'
              }
            </p>
          </div>

        </div>

        {/* Right Column - Service Support details */}
        <div className="space-y-6">
          
          {/* Emergency contacts card */}
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 text-red-500 text-xs font-bold font-mono uppercase">
              <Phone className="w-4 h-4 text-red-500" />
              <span>EMERGENCY HELPLINE</span>
            </div>
            <div className="space-y-3 text-xs text-slate-300">
              <div className="border-b border-white/5 pb-2.5">
                <span className="block text-slate-500 text-[10px] uppercase font-mono">24H Emergency Service (緊急客服)</span>
                <span className="font-bold text-white text-base font-mono">0800-765-888</span>
              </div>
              <div className="border-b border-white/5 pb-2.5">
                <span className="block text-slate-500 text-[10px] uppercase font-mono">Local Calls Localized (市話專線)</span>
                <span className="font-bold text-white text-base font-mono">02-2191-0096</span>
              </div>
              <div>
                <span className="block text-slate-500 text-[10px] uppercase font-mono">Text SMS Dispatch (簡訊客服)</span>
                <span className="font-bold text-white text-base font-mono">0921-765-888</span>
              </div>
            </div>
          </div>

          {/* Help Center card */}
          <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-5 space-y-3.5 shadow-lg text-xs leading-relaxed text-slate-400">
            <div className="flex items-center space-x-1.5 text-slate-300 font-bold">
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              <span>{getTranslation(lang, 'footer.help')}</span>
            </div>
            <div className="space-y-2 text-[11px] text-slate-400">
              <p className="font-bold text-white">Q: 如何辦理退票手續？</p>
              <p className="pl-3 text-slate-400">A: 電子票券可於APP中一鍵退票；實體票券可攜至任一車站智慧窗口辦理。</p>
              
              <p className="font-bold text-white mt-3">Q: TPASS 智慧通勤方案如何整合？</p>
              <p className="pl-3 text-slate-400">A: 下載 TRA APP 並綁定手機 NFC 後，感應閘門即可免綁卡直接通行。</p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
