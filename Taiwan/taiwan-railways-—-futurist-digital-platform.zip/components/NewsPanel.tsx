'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Calendar, X, Tag } from 'lucide-react';
import { NEWS_DATA, type NewsItem } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface NewsPanelProps {
  lang: Language;
}

export default function NewsPanel({ lang }: NewsPanelProps) {
  const [selectedNews, setSelectedNews] = React.useState<NewsItem | null>(null);

  return (
    <div 
      id="news-panel-card" 
      className="w-full bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl flex flex-col h-full"
    >
      {/* Header Row */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
        <div className="flex items-center space-x-2">
          <span className="w-1 h-3.5 bg-cyan-500 rounded-sm" />
          <div>
            <h3 className="text-white font-bold text-sm leading-none uppercase tracking-wider">
              {getTranslation(lang, 'news.title')}
            </h3>
            <span className="text-slate-500 text-[9px] uppercase tracking-wider font-mono">
              {getTranslation(lang, 'news.subtitle')}
            </span>
          </div>
        </div>
        
        {/* Mock View More button */}
        <button
          id="news-more-btn"
          onClick={() => setSelectedNews(NEWS_DATA[0])} // just opens an article to demonstrate clicked state
          className="flex items-center space-x-1 text-xs text-cyan-400 hover:text-white hover:underline transition-all"
        >
          <span>{getTranslation(lang, 'news.more')}</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* News List Container */}
      <div className="space-y-3.5 flex-1 overflow-y-auto pr-1">
        {NEWS_DATA.map((item) => (
          <button
            id={`news-item-btn-${item.id}`}
            key={item.id}
            onClick={() => setSelectedNews(item)}
            className="w-full text-left p-3 rounded-xl bg-white/5 border border-white/5 hover:border-cyan-500/50 hover:bg-white/10 transition-all duration-200 group flex flex-col cursor-pointer"
          >
            {/* Meta row: Date & Tag */}
            <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
              <span className="font-mono flex items-center space-x-1">
                <Calendar className="w-3 h-3 text-cyan-400/80" />
                <span>{item.date}</span>
              </span>
              <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-1.5 py-0.5 rounded text-[9px] font-semibold">
                {lang === 'zh' ? item.categoryZh : item.categoryEn}
              </span>
            </div>

            {/* News Title */}
            <h4 className="text-white font-bold text-xs group-hover:text-cyan-400 transition-colors leading-snug line-clamp-2">
              {lang === 'zh' ? item.titleZh : item.titleEn}
            </h4>
          </button>
        ))}
      </div>

      {/* Interactive Modal overlay for news detail state */}
      <AnimatePresence>
        {selectedNews && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedNews(null)}
              className="fixed inset-0 bg-black z-50"
            />

            {/* Modal Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="fixed inset-x-4 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 top-[10%] md:w-[600px] max-h-[80%] bg-slate-900 border border-white/10 rounded-2xl p-6 shadow-2xl z-50 overflow-y-auto text-left backdrop-blur-xl"
            >
              {/* Top Row */}
              <div className="flex justify-between items-start mb-4 border-b border-white/10 pb-3">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 text-xs text-slate-400">
                    <span className="font-mono">{selectedNews.date}</span>
                    <span>•</span>
                    <span className="text-cyan-400 font-semibold">
                      {lang === 'zh' ? selectedNews.categoryZh : selectedNews.categoryEn}
                    </span>
                  </div>
                  <h3 className="text-white font-extrabold text-lg leading-snug">
                    {lang === 'zh' ? selectedNews.titleZh : selectedNews.titleEn}
                  </h3>
                </div>
                <button
                  id="close-news-modal"
                  onClick={() => setSelectedNews(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-white/5 hover:bg-white/10"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* News Content Body */}
              <div className="text-slate-300 text-sm leading-relaxed space-y-4">
                <p>{lang === 'zh' ? selectedNews.contentZh : selectedNews.contentEn}</p>
                <div className="bg-slate-950/50 border border-white/10 rounded-xl p-4 mt-6 text-xs text-slate-400 font-mono">
                  <div>SOURCE: TAIWAN RAILWAYS ADMINISTRATION OFFICIAL PRESS</div>
                  <div>VERIFICATION: SECURE BLOCKCHAIN SYSTEM LOGGED</div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
