/* eslint-disable react-hooks/set-state-in-effect */
'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Smartphone, QrCode, Download, Plus, Sparkles, Check, CheckCircle2, Ticket, Printer, ShieldAlert } from 'lucide-react';
import { MOCK_TICKETS, type UserTicket } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface TicketViewerProps {
  lang: Language;
  activeTicket?: UserTicket;
}

export default function TicketViewer({ lang, activeTicket }: TicketViewerProps) {
  // Use the active ticket passed from checkout, otherwise fall back to pre-populated mock tickets
  const [currentTicket, setCurrentTicket] = React.useState<UserTicket>(activeTicket || MOCK_TICKETS[0]);
  const [walletAdded, setWalletAdded] = React.useState(false);
  const [pdfDownloaded, setPdfDownloaded] = React.useState(false);

  // Sync if active ticket changes (e.g. they just booked a ticket)
  React.useEffect(() => {
    if (activeTicket) {
      setCurrentTicket(activeTicket);
    }
  }, [activeTicket]);

  const handleAddToWallet = () => {
    setWalletAdded(true);
    setTimeout(() => setWalletAdded(false), 3000);
  };

  const handleDownloadPDF = () => {
    setPdfDownloaded(true);
    setTimeout(() => setPdfDownloaded(false), 3000);
  };

  return (
    <section id="ticket-viewer-page" className="w-full py-6 space-y-8 text-left">
      
      {/* Title Header */}
      <div className="border-b border-white/10 pb-5">
        <h2 className="text-3xl font-extrabold text-white tracking-tight">
          {getTranslation(lang, 'ticket.title')}
        </h2>
        <p className="text-slate-400 text-sm mt-1">
          {getTranslation(lang, 'ticket.subtitle')}
        </p>
      </div>

      {/* Grid: Wallet Cards & Actions */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Mock Passes selection menu */}
        <div className="md:col-span-4 space-y-4">
          <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-5 space-y-3.5 shadow-lg">
            <span className="text-[10px] text-slate-400 font-mono tracking-widest uppercase block mb-2">
              MY ACTIVE PASSES ({MOCK_TICKETS.length + (activeTicket ? 1 : 0)})
            </span>

            {/* List tickets */}
            {/* 1. Newly created ticket */}
            {activeTicket && (
              <button
                id={`ticket-select-btn-${activeTicket.ticketNo}`}
                onClick={() => setCurrentTicket(activeTicket)}
                className={`w-full text-left p-3.5 rounded-xl border flex items-center space-x-3 transition-all cursor-pointer ${
                  currentTicket.ticketNo === activeTicket.ticketNo
                    ? 'border-cyan-500 bg-cyan-500/10 text-white'
                    : 'border-white/5 bg-transparent text-slate-400 hover:bg-white/5'
                }`}
              >
                <Ticket className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                <div className="truncate text-xs">
                  <span className="block font-bold text-white">{activeTicket.fromZh} ➜ {activeTicket.toZh}</span>
                  <span className="font-mono text-[10px] text-slate-400 font-bold">{activeTicket.trainNo} 車次 • {activeTicket.date}</span>
                </div>
              </button>
            )}

            {/* 2. Pre-populated tickets */}
            {MOCK_TICKETS.map((t) => (
              <button
                id={`ticket-select-btn-${t.ticketNo}`}
                key={t.ticketNo}
                onClick={() => setCurrentTicket(t)}
                className={`w-full text-left p-3.5 rounded-xl border flex items-center space-x-3 transition-all cursor-pointer ${
                  currentTicket.ticketNo === t.ticketNo
                    ? 'border-cyan-500 bg-cyan-500/10 text-white'
                    : 'border-white/5 bg-transparent text-slate-400 hover:bg-white/5'
                }`}
              >
                <Ticket className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                <div className="truncate text-xs">
                  <span className="block font-bold text-white">{t.fromZh} ➜ {t.toZh}</span>
                  <span className="font-mono text-[10px] text-slate-400 font-bold">{t.trainNo} 車次 • {t.date}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Side: Virtual NFC Ticket boarding card view */}
        <div className="md:col-span-8 flex flex-col items-center">
          
          {/* Animated Feedback messages */}
          <AnimatePresence>
            {(walletAdded || pdfDownloaded) && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="w-full max-w-sm mb-4 bg-[#00FF88]/10 border border-[#00FF88]/40 p-3.5 rounded-xl flex items-center space-x-2.5 text-[#00FF88] text-xs font-bold shadow-lg"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {walletAdded ? getTranslation(lang, 'ticket.saved') : 'PDF Ticket Receipt exported successfully!'}
                </span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Actual Ticket Visual Card */}
          <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border border-white/10 rounded-2xl shadow-[0_25px_50px_rgba(0,0,0,0.6)] overflow-hidden relative border-t-cyan-500 border-t-[3px]">
            {/* Top glass reflection light effect */}
            <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent z-10" />
            
            {/* Sub demonstration disclaimer sticker */}
            <div className="bg-[#FFAE00] text-slate-950 text-center text-[10px] font-black tracking-widest py-1 uppercase border-b border-black/20">
              {getTranslation(lang, 'ticket.demoLabel')}
            </div>

            {/* Core Ticket Info Header */}
            <div className="p-6 space-y-6">
              
              {/* Row 1: Logo & Route */}
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-[9px] text-cyan-400 font-mono tracking-widest font-black uppercase">TAIWAN RAILWAY TRANSIT</div>
                  <h4 className="text-white font-extrabold text-base leading-snug mt-0.5">
                    {lang === 'zh' ? currentTicket.typeZh : currentTicket.typeEn}
                  </h4>
                </div>
                <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                  <svg className="w-5 h-5 text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="9" />
                    <path d="M6 12h12M12 6v12" />
                  </svg>
                </div>
              </div>

              {/* Row 2: Stations Large Display */}
              <div className="flex justify-between items-center bg-slate-900/60 border border-white/5 p-4 rounded-xl">
                <div>
                  <span className="text-[10px] text-slate-500 font-mono">FROM</span>
                  <span className="text-white font-black text-xl block leading-none mt-1">{currentTicket.fromZh}</span>
                  <span className="text-slate-400 text-[11px] font-bold font-mono block mt-0.5">{currentTicket.fromEn}</span>
                </div>

                <div className="flex flex-col items-center flex-1 px-4">
                  <span className="text-xs font-mono font-bold text-cyan-400">{currentTicket.trainNo}</span>
                  <div className="w-full h-[1.5px] bg-white/10 my-1" />
                  <span className="text-[9px] text-slate-500 font-mono tracking-wider">SECURE PASS</span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-500 font-mono">TO</span>
                  <span className="text-white font-black text-xl block leading-none mt-1">{currentTicket.toZh}</span>
                  <span className="text-slate-400 text-[11px] font-bold font-mono block mt-0.5">{currentTicket.toEn}</span>
                </div>
              </div>

              {/* Row 3: Double parameters list */}
              <div className="grid grid-cols-2 gap-4 text-xs font-sans border-b border-white/10 pb-4">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-mono">{getTranslation(lang, 'ticket.passenger')}</span>
                  <span className="font-extrabold text-white block mt-0.5">{lang === 'zh' ? currentTicket.passengerNameZh : currentTicket.passengerNameEn}</span>
                  <span className="text-slate-400 text-[10px] leading-none block mt-0.5">{currentTicket.passengerType}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-mono">{getTranslation(lang, 'ticket.date')}</span>
                  <span className="font-extrabold text-white font-mono block mt-0.5">{currentTicket.date}</span>
                </div>
              </div>

              {/* Row 4: Seat parameters */}
              <div className="grid grid-cols-3 gap-4 text-xs font-sans border-b border-white/10 pb-4">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-mono">Departure</span>
                  <span className="font-black text-white font-mono block mt-0.5">{currentTicket.departureTime}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-mono">{getTranslation(lang, 'ticket.seat')}</span>
                  <span className="font-black text-white font-mono block mt-0.5">{currentTicket.carNo} 車 / {currentTicket.seatNo.split(' ')[0]}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-mono">Fare</span>
                  <span className="font-black text-cyan-400 font-mono block mt-0.5">NT$ {currentTicket.fare.toLocaleString()}</span>
                </div>
              </div>

            </div>

            {/* Dotted separator with notched side cutouts */}
            <div className="relative h-4 flex items-center bg-transparent">
              <div className="absolute -left-3 w-6 h-6 rounded-full bg-slate-950 border border-white/10" />
              <div className="w-full border-t border-dashed border-white/20 mx-4" />
              <div className="absolute -right-3 w-6 h-6 rounded-full bg-slate-950 border border-white/10" />
            </div>

            {/* Bottom Section: QR Code and scanning guidelines */}
            <div className="p-6 bg-slate-950 flex flex-col items-center space-y-4">
              
              {/* QR Box */}
              <div className="bg-white p-3.5 rounded-2xl shadow-xl flex items-center justify-center">
                <svg className="w-32 h-32 text-black" viewBox="0 0 100 100" fill="currentColor">
                  {/* Top-Left Finder */}
                  <rect x="5" y="5" width="25" height="25" />
                  <rect x="10" y="10" width="15" height="15" fill="white" />
                  <rect x="14" y="14" width="7" height="7" />

                  {/* Top-Right Finder */}
                  <rect x="70" y="5" width="25" height="25" />
                  <rect x="75" y="10" width="15" height="15" fill="white" />
                  <rect x="79" y="14" width="7" height="7" />

                  {/* Bottom-Left Finder */}
                  <rect x="5" y="70" width="25" height="25" />
                  <rect x="10" y="75" width="15" height="15" fill="white" />
                  <rect x="14" y="79" width="7" height="7" />

                  {/* Inner random noise dots to represent high-tech ticket QR code */}
                  <rect x="40" y="15" width="5" height="10" />
                  <rect x="45" y="5" width="10" height="5" />
                  <rect x="40" y="40" width="15" height="15" />
                  <rect x="45" y="45" width="5" height="5" fill="white" />
                  <rect x="70" y="40" width="10" height="10" />
                  <rect x="85" y="45" width="10" height="5" />
                  <rect x="40" y="70" width="15" height="5" />
                  <rect x="45" y="85" width="5" height="10" />
                  <rect x="70" y="70" width="10" height="10" />
                  <rect x="85" y="75" width="10" height="15" />
                  <rect x="80" y="80" width="5" height="5" fill="white" />
                </svg>
              </div>

              {/* Guidelines text */}
              <div className="text-center">
                <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-widest font-mono">
                  {getTranslation(lang, 'ticket.ticketNo')}: {currentTicket.ticketNo}
                </span>
                <p className="text-[10px] text-slate-500 max-w-xs mt-1.5 leading-relaxed leading-none">
                  {getTranslation(lang, 'ticket.scannedWarning')}
                </p>
              </div>

            </div>
          </div>

          {/* Quick Ticket Action buttons */}
          <div className="w-full max-w-sm grid grid-cols-2 gap-4 mt-6">
            <button
              id="wallet-add-btn"
              onClick={handleAddToWallet}
              className="flex items-center justify-center space-x-1.5 bg-slate-900 border border-white/10 text-white hover:text-cyan-400 hover:border-cyan-500 py-3 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4 text-cyan-400" />
              <span>{getTranslation(lang, 'ticket.wallet')}</span>
            </button>

            <button
              id="pdf-download-btn"
              onClick={handleDownloadPDF}
              className="flex items-center justify-center space-x-1.5 bg-slate-900 border border-white/10 text-white hover:text-cyan-400 hover:border-cyan-500 py-3 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-400" />
              <span>{getTranslation(lang, 'ticket.download')}</span>
            </button>
          </div>

          {/* Verification disclaimer */}
          <div className="w-full max-w-sm mt-6 flex items-start space-x-2 bg-red-500/5 border border-red-500/20 rounded-xl p-4 text-[11px] text-slate-400">
            <ShieldAlert className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              * Security Note: This railway pass is a simulation mockup generated in the Google AI Studio environment. It holds no valid monetary value for boarding actual vehicles operated by the Taiwan Railways Corporation, Ltd.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
}
