/* eslint-disable react-hooks/set-state-in-effect */
'use client';

import * as React from 'react';
import { motion } from 'motion/react';
import { Train, Clock, BadgeDollarSign, Filter, ArrowRight, ArrowLeft, ArrowUpDown, ShieldCheck, ShoppingCart, Loader2 } from 'lucide-react';
import { STATIONS, searchTrains, calculateFare, type Journey, type UserTicket } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface SearchResultsSectionProps {
  lang: Language;
  fromId: string;
  toId: string;
  date: string;
  passengers: { adult: number; child: number; senior: number };
  onBookingSuccess: (ticket: UserTicket) => void;
  onBackToSearch: () => void;
}

export default function SearchResultsSection({
  lang,
  fromId,
  toId,
  date,
  passengers,
  onBookingSuccess,
  onBackToSearch
}: SearchResultsSectionProps) {
  const [loading, setLoading] = React.useState(true);
  const [results, setResults] = React.useState<Journey[]>([]);
  const [sortBy, setSortBy] = React.useState<'departure' | 'duration' | 'fare'>('departure');
  const [trainTypeFilter, setTrainTypeFilter] = React.useState<string>('all');
  const [selectedJourney, setSelectedJourney] = React.useState<Journey | null>(null);
  const [checkoutLoading, setCheckoutLoading] = React.useState(false);

  const fromStation = STATIONS.find(s => s.id === fromId) || STATIONS[0];
  const toStation = STATIONS.find(s => s.id === toId) || STATIONS[1];
  const totalPassengersCount = passengers.adult + passengers.child + passengers.senior;

  // Simulate search API loading state
  React.useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => {
      const data = searchTrains(fromId, toId, date);
      setResults(data);
      setLoading(false);
    }, 1200);
    return () => clearTimeout(t);
  }, [fromId, toId, date]);

  // Handle Sort operations
  const sortedResults = React.useMemo(() => {
    let list = [...results];
    
    // Apply Train type filters
    if (trainTypeFilter !== 'all') {
      list = list.filter(j => j.typeZh.includes(trainTypeFilter) || j.typeEn.includes(trainTypeFilter));
    }

    if (sortBy === 'departure') {
      return list.sort((a, b) => a.departureTime.localeCompare(b.departureTime));
    } else if (sortBy === 'duration') {
      return list.sort((a, b) => a.duration.localeCompare(b.duration));
    } else if (sortBy === 'fare') {
      return list.sort((a, b) => a.fare - b.fare);
    }
    return list;
  }, [results, sortBy, trainTypeFilter]);

  // Total checkout cost calculation
  const calculatedCheckoutCost = selectedJourney 
    ? (selectedJourney.fare * totalPassengersCount) 
    : 0;

  // Simulate payment / checkout process
  const handlePaymentSubmit = () => {
    if (!selectedJourney) return;
    setCheckoutLoading(true);
    
    setTimeout(() => {
      // Create actual new ticket for the mock wallet
      const newTicket: UserTicket = {
        ticketNo: `TRA-2026-${Math.floor(1000 + Math.random() * 9000)}B`,
        passengerNameZh: '王小明',
        passengerNameEn: 'Wang Xiao-Ming',
        passengerType: `Adult / 成人 (x${passengers.adult}) ${passengers.child ? `, Child / 孩童 (x${passengers.child})` : ''}`,
        trainNo: selectedJourney.trainNo,
        typeZh: selectedJourney.typeZh,
        typeEn: selectedJourney.typeEn,
        fromZh: selectedJourney.fromZh,
        fromEn: selectedJourney.fromEn,
        toZh: selectedJourney.toZh,
        toEn: selectedJourney.toEn,
        date: date,
        departureTime: selectedJourney.departureTime,
        arrivalTime: selectedJourney.arrivalTime,
        carNo: '08',
        seatNo: '11-C (Window / 靠窗)',
        fare: calculatedCheckoutCost,
        qrValue: `TRA_BOOKING_${selectedJourney.trainNo}_${Date.now()}`
      };
      setCheckoutLoading(false);
      onBookingSuccess(newTicket);
    }, 1800);
  };

  return (
    <section id="results-flow-container" className="w-full py-4 text-left">
      
      {/* Return Navigation bar */}
      <div className="flex items-center justify-between mb-6">
        <button
          id="back-to-search-btn"
          onClick={onBackToSearch}
          className="inline-flex items-center space-x-1.5 text-xs font-bold text-slate-300 hover:text-cyan-400 transition-all bg-slate-900 border border-white/10 px-3 py-1.5 rounded-lg cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{getTranslation(lang, 'ui.back')}</span>
        </button>

        <span className="text-[10px] text-slate-500 font-mono tracking-wider">
          QUERY ID: {fromId}_{toId}_{date}
        </span>
      </div>

      {/* Grid: Sort/Filters Column & Results Column */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Side: Filter and sorting sidebar */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-5 space-y-5 shadow-lg">
            
            <div className="flex items-center space-x-2 text-white font-bold text-xs uppercase border-b border-white/5 pb-2.5">
              <Filter className="w-4 h-4 text-cyan-400" />
              <span>{getTranslation(lang, 'search.filter.type')}</span>
            </div>

            {/* Train type radio selectors */}
            <div className="space-y-2">
              {[
                { id: 'all', zh: '全部車種', en: 'All Types' },
                { id: 'EMU3000', zh: '新世代自強號 (EMU3000)', en: 'TRA Express' },
                { id: '普悠瑪', zh: '普悠瑪/太魯閣號', en: 'Puyuma/Taroko' },
                { id: '自強', zh: '一般自強號', en: 'Tze-Chiang Limited' },
                { id: '區間', zh: '區間快車', en: 'Local Express' }
              ].map((filter) => (
                <button
                  id={`filter-opt-${filter.id}`}
                  key={filter.id}
                  onClick={() => setTrainTypeFilter(filter.id)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                    trainTypeFilter === filter.id
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400'
                      : 'bg-transparent border-transparent text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {lang === 'zh' ? filter.zh : filter.en}
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-2 text-white font-bold text-xs uppercase border-b border-white/5 pb-2.5 pt-4">
              <ArrowUpDown className="w-4 h-4 text-cyan-400" />
              <span>Sort Preferences</span>
            </div>

            {/* Sorting buttons */}
            <div className="space-y-2">
              {[
                { id: 'departure', label: 'search.sort.departure' },
                { id: 'duration', label: 'search.sort.duration' },
                { id: 'fare', label: 'search.sort.fare' }
              ].map((sort) => (
                <button
                  id={`sort-opt-${sort.id}`}
                  key={sort.id}
                  onClick={() => setSortBy(sort.id as any)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                    sortBy === sort.id
                      ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400'
                      : 'bg-transparent border-transparent text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {getTranslation(lang, sort.label)}
                </button>
              ))}
            </div>

          </div>
        </div>

        {/* Right Side: Results Cards / Skeletons */}
        <div className="lg:col-span-3 space-y-4">
          
          {/* Header Banner summary */}
          <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <span className="text-cyan-400 text-[10px] uppercase font-mono tracking-widest font-bold">ACTIVE SECTOR SECURED</span>
              <div className="text-white text-lg font-black flex items-center space-x-2 mt-0.5">
                <span>{fromStation.zh}</span>
                <span className="text-slate-500 font-mono">➜</span>
                <span>{toStation.zh}</span>
                <span className="text-slate-500 font-mono text-xs font-normal">({date})</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {getTranslation(lang, 'booking.passengerCount', { count: totalPassengersCount })}: {getTranslation(lang, 'booking.passengerDetail', passengers)}
              </p>
            </div>

            <div className="flex sm:flex-col items-start sm:items-end text-xs">
              <span className="text-slate-400 mr-2 sm:mr-0">Status:</span>
              <span className="text-[#00FF88] font-bold">Secure Line Connected</span>
            </div>
          </div>

          {/* Skeletons Loader when searching */}
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((sIdx) => (
                <div key={sIdx} className="w-full bg-slate-900/40 border border-white/10 rounded-2xl h-24 animate-pulse flex items-center justify-between px-6">
                  <div className="space-y-2 w-1/3">
                    <div className="h-4 bg-slate-950 rounded w-3/4" />
                    <div className="h-3 bg-slate-950 rounded w-1/2" />
                  </div>
                  <div className="h-6 bg-slate-950 rounded w-16" />
                  <div className="h-10 bg-slate-950 rounded-xl w-24" />
                </div>
              ))}
              <div className="flex items-center justify-center space-x-2 text-xs text-slate-400 pt-4">
                <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                <span>{getTranslation(lang, 'search.loading')}</span>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {sortedResults.length > 0 ? (
                sortedResults.map((jrn) => (
                  <div
                    id={`search-result-card-${jrn.id}`}
                    key={jrn.id}
                    className={`w-full bg-slate-900/40 backdrop-blur-xl border rounded-2xl p-5 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6 transition-all ${
                      selectedJourney?.id === jrn.id
                        ? 'border-cyan-500 bg-slate-900/60 shadow-lg'
                        : 'border-white/10 hover:border-cyan-500/40'
                    }`}
                  >
                    {/* Time Schedule Details */}
                    <div className="flex-1 flex items-center justify-between max-w-sm">
                      {/* From */}
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">{jrn.departureTime}</span>
                        <span className="text-white font-extrabold text-base block mt-0.5">{jrn.fromZh}</span>
                        <span className="text-slate-400 text-[10px] font-medium font-mono uppercase block">{jrn.fromEn}</span>
                      </div>

                      {/* Line arrow marker */}
                      <div className="flex-1 flex flex-col items-center px-4 relative">
                        <span className="text-[9px] font-mono text-slate-500 font-semibold">{jrn.duration}</span>
                        <div className="w-full h-[2px] bg-slate-800 my-1 relative">
                          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-cyan-500" />
                        </div>
                        <span className="text-[9px] font-mono text-cyan-400 uppercase font-bold">{jrn.trainNo}</span>
                      </div>

                      {/* To */}
                      <div>
                        <span className="text-[10px] text-slate-400 block font-semibold">{jrn.arrivalTime}</span>
                        <span className="text-white font-extrabold text-base block mt-0.5">{jrn.toZh}</span>
                        <span className="text-slate-400 text-[10px] font-medium font-mono uppercase block">{jrn.toEn}</span>
                      </div>
                    </div>

                    {/* Train type description */}
                    <div className="md:w-36 text-left">
                      <span className="text-[10px] text-cyan-400 font-bold block uppercase tracking-wider">{jrn.typeEn}</span>
                      <span className="text-white font-extrabold text-xs block leading-snug mt-0.5">{jrn.typeZh}</span>
                      <div className="flex items-center space-x-1 mt-1 text-[10px] text-slate-500 font-semibold font-mono">
                        {jrn.features.slice(0, 2).map((feat, fIdx) => (
                          <span key={fIdx} className="bg-slate-950 border border-white/5 px-1 rounded">{feat}</span>
                        ))}
                      </div>
                    </div>

                    {/* Price & availability */}
                    <div className="flex items-center justify-between md:block text-left md:text-right md:w-28 border-t md:border-t-0 pt-4 md:pt-0 border-white/5">
                      <div>
                        <span className="text-[10px] text-slate-400 block md:inline mr-1">Fare:</span>
                        <span className="text-white font-extrabold text-base font-mono">NT$ {jrn.fare.toLocaleString()}</span>
                      </div>
                      <span className={`text-[10px] block mt-1 font-bold ${jrn.availableSeats < 50 ? 'text-red-400' : 'text-emerald-400'}`}>
                        {jrn.status === 'suspended' 
                          ? getTranslation(lang, 'live.suspended') 
                          : jrn.availableSeats === 0 
                            ? getTranslation(lang, 'search.seatSoldOut') 
                            : getTranslation(lang, 'search.seatsLeft', { count: jrn.availableSeats })}
                      </span>
                    </div>

                    {/* Selector Select button */}
                    <div className="flex-shrink-0">
                      {jrn.status !== 'suspended' && jrn.availableSeats > 0 ? (
                        <button
                          id={`select-train-btn-${jrn.id}`}
                          onClick={() => setSelectedJourney(selectedJourney?.id === jrn.id ? null : jrn)}
                          className={`w-full md:w-auto px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            selectedJourney?.id === jrn.id
                              ? 'bg-cyan-500 text-slate-950'
                              : 'bg-slate-950 border border-white/10 text-cyan-400 hover:bg-slate-900'
                          }`}
                        >
                          {getTranslation(lang, 'search.select')}
                        </button>
                      ) : (
                        <span className="text-slate-500 font-bold block text-center min-w-[70px]">-</span>
                      )}
                    </div>

                  </div>
                ))
              ) : (
                <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-12 text-center text-slate-500 text-xs">
                  {getTranslation(lang, 'search.noResults')}
                </div>
              )}
            </div>
          )}

          {/* Checkout Checkout payment sliding panel */}
          {selectedJourney && (
            <div id="checkout-panel" className="bg-gradient-to-b from-slate-900 to-slate-950 border border-cyan-500 rounded-2xl p-6 shadow-2xl mt-8">
              <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold font-mono tracking-widest uppercase mb-4">
                <ShoppingCart className="w-4 h-4" />
                <span>SECURE CHECKOUT TERMINAL</span>
              </div>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-white/5 pb-5 mb-5 text-left">
                <div>
                  <h4 className="text-white font-extrabold text-sm">
                    {lang === 'zh' ? selectedJourney.typeZh : selectedJourney.typeEn} ({selectedJourney.trainNo}車次)
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    {selectedJourney.fromZh} ➜ {selectedJourney.toZh} • {selectedJourney.departureTime} ➜ {selectedJourney.arrivalTime}
                  </p>
                  <p className="text-xs text-slate-400">
                    {getTranslation(lang, 'booking.passengerCount', { count: totalPassengersCount })} ({getTranslation(lang, 'booking.passengerDetail', passengers)})
                  </p>
                </div>

                <div className="text-left md:text-right">
                  <span className="text-xs text-slate-400">{getTranslation(lang, 'search.totalPrice')}</span>
                  <div className="text-white text-2xl font-black font-mono mt-0.5 text-cyan-400">
                    NT$ {calculatedCheckoutCost.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Action and warning links */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <span className="text-[11px] text-slate-400 flex items-center space-x-1.5 leading-none">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>TRA SSL Secure 256-bit Encrypted checkout.</span>
                </span>

                <button
                  id="checkout-payment-btn"
                  onClick={handlePaymentSubmit}
                  disabled={checkoutLoading}
                  className="bg-cyan-500 text-slate-950 py-3 px-6 rounded-xl text-xs font-black shadow-lg shadow-cyan-500/10 hover:bg-cyan-400 active:scale-95 transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
                >
                  {checkoutLoading ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>{getTranslation(lang, 'ui.loading')}</span>
                    </>
                  ) : (
                    <>
                      <span>{getTranslation(lang, 'search.bookNow')}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

        </div>

      </div>
    </section>
  );
}
