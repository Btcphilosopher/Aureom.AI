'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Award, Shield, Key, Heart, MapPin, Compass, Settings, CheckCircle2, Ticket, History, Save, Calendar } from 'lucide-react';
import { MOCK_MEMBER, MOCK_TICKETS, STATIONS, type UserTicket } from '@/lib/data';
import { getTranslation, type Language } from '@/lib/i18n';

interface MemberDashboardProps {
  lang: Language;
  onSelectTicket: (ticket: UserTicket) => void;
  addedTickets?: UserTicket[];
}

export default function MemberDashboard({ lang, onSelectTicket, addedTickets = [] }: MemberDashboardProps) {
  const [member, setMember] = React.useState(MOCK_MEMBER);
  const [activeTab, setActiveTab] = React.useState<'overview' | 'settings'>('overview');
  
  // Profile settings state fields
  const [nameZh, setNameZh] = React.useState(member.nameZh);
  const [nameEn, setNameEn] = React.useState(member.nameEn);
  const [email, setEmail] = React.useState(member.email);
  const [saveSuccess, setSaveSuccess] = React.useState(false);

  const allTickets = [...addedTickets, ...MOCK_TICKETS];

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    setMember(prev => ({
      ...prev,
      nameZh,
      nameEn,
      email
    }));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <section id="member-dashboard-page" className="w-full py-6 space-y-8 text-left">
      
      {/* Title Header */}
      <div className="border-b border-white/10 pb-5 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">
            {getTranslation(lang, 'member.title')}
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            {getTranslation(lang, 'member.subtitle')}
          </p>
        </div>

        {/* Tab options switcher */}
        <div className="flex bg-slate-900 p-1 rounded-xl border border-white/10 self-start md:self-auto">
          <button
            id="member-tab-overview"
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Dashboard
          </button>
          <button
            id="member-tab-settings"
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-cyan-500 text-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {getTranslation(lang, 'member.settings')}
          </button>
        </div>
      </div>

      {/* Grid: Card details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Loyalty Card and TPASS */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Virtual Loyalty Card Display */}
          <div className="w-full bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-white/10 rounded-2xl p-6 shadow-2xl relative overflow-hidden text-white">
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
            
            {/* Header: Chip or Level badge */}
            <div className="flex justify-between items-center mb-6">
              <span className="text-[10px] text-cyan-400 font-mono tracking-widest font-black uppercase">
                TAIWAN RAILWAYS ELITE
              </span>
              <Award className="w-6 h-6 text-cyan-400" />
            </div>

            {/* Member Details */}
            <div className="space-y-4">
              <div>
                <span className="text-[10px] text-slate-400 block uppercase font-mono">{getTranslation(lang, 'member.name')}</span>
                <span className="text-lg font-black block">{lang === 'zh' ? member.nameZh : member.nameEn}</span>
              </div>

              <div className="grid grid-cols-2 gap-4 border-t border-white/10 pt-4">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">{getTranslation(lang, 'member.level')}</span>
                  <span className="text-xs font-bold text-cyan-400 block">{lang === 'zh' ? member.levelZh : member.levelEn}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">{getTranslation(lang, 'member.no')}</span>
                  <span className="text-xs font-mono font-semibold block">{member.id}</span>
                </div>
              </div>
            </div>

            {/* Dotted code barcode at bottom */}
            <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
              <div className="h-6 flex items-center space-x-[2px] opacity-40">
                {[1, 3, 2, 4, 1, 2, 1, 3, 4, 2, 1, 2, 3, 1, 4, 2].map((w, idx) => (
                  <div key={idx} className="h-full bg-white" style={{ width: `${w}px` }} />
                ))}
              </div>
              <span className="text-[9px] text-cyan-400 font-bold font-mono">12,450 {getTranslation(lang, 'member.pointsLabel')}</span>
            </div>
          </div>

          {/* TPASS details */}
          <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-5 space-y-3 shadow-lg text-left">
            <span className="text-[10px] text-slate-400 font-mono tracking-widest uppercase block border-b border-white/10 pb-2">
              TPASS 3.0 PROGRAM
            </span>
            <div className="flex items-center space-x-3 pt-1">
              <div className="w-8 h-8 rounded-lg bg-[#00FF88]/10 border border-[#00FF88]/30 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4 text-[#00FF88]" />
              </div>
              <div>
                <span className="text-white font-bold text-xs block">
                  {lang === 'zh' ? member.tpassStatusZh : member.tpassStatusEn}
                </span>
                <span className="text-[10px] text-slate-500 block leading-tight mt-0.5">
                  Bio-Auth and NFC Wallet sync configured on mobile app.
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Dynamic screens switcher */}
        <div className="lg:col-span-8">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' ? (
              <motion.div
                key="overview-pane"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 15 }}
                className="space-y-6"
              >
                {/* Active Tickets / Upcoming Journeys */}
                <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-lg text-left">
                  <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold font-mono uppercase mb-4 border-b border-white/10 pb-3">
                    <Ticket className="w-4 h-4" />
                    <span>{getTranslation(lang, 'member.upcoming')}</span>
                  </div>

                  <div className="space-y-3">
                    {allTickets.map((t) => (
                      <div
                        id={`member-upcoming-card-${t.ticketNo}`}
                        key={t.ticketNo}
                        className="p-4 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <span className="text-[10px] text-cyan-400 font-mono font-bold">{t.trainNo} 車次 • {t.typeZh}</span>
                          <div className="text-white font-extrabold text-sm flex items-center space-x-2">
                            <span>{t.fromZh} ({t.departureTime})</span>
                            <span className="text-slate-500 font-mono">➜</span>
                            <span>{t.toZh} ({t.arrivalTime})</span>
                          </div>
                          <span className="text-slate-400 text-xs block">Date: {t.date} | Seat: Car {t.carNo} Seat {t.seatNo.split(' ')[0]}</span>
                        </div>

                        <button
                          id={`member-view-ticket-${t.ticketNo}`}
                          onClick={() => onSelectTicket(t)}
                          className="bg-cyan-500/10 hover:bg-cyan-500 text-cyan-400 hover:text-slate-950 px-4 py-2 rounded-xl text-xs font-bold transition-all border border-cyan-500/30 cursor-pointer text-center"
                        >
                          {getTranslation(lang, 'ticket.view')}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Saved Frequent Routes & Stations */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Stations */}
                  <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg text-left">
                    <div className="flex items-center space-x-2 text-slate-300 text-xs font-bold uppercase mb-4 border-b border-white/10 pb-2.5">
                      <MapPin className="w-4 h-4 text-cyan-400" />
                      <span>{getTranslation(lang, 'member.savedStations')}</span>
                    </div>
                    <div className="space-y-2">
                      {member.savedRoutes.map((rt, idx) => {
                        const fromSt = STATIONS.find(s => s.id === rt.from);
                        const toSt = STATIONS.find(s => s.id === rt.to);
                        return (
                          <div key={idx} className="flex items-center justify-between p-2.5 rounded-lg bg-white/5 border border-white/5 text-xs text-white">
                            <span className="font-bold">{fromSt?.zh} ➜ {toSt?.zh}</span>
                            <span className="text-slate-400 font-mono font-bold text-[10px] uppercase">{rt.from} to {rt.to}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Past History */}
                  <div className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg text-left">
                    <div className="flex items-center space-x-2 text-slate-300 text-xs font-bold uppercase mb-4 border-b border-white/10 pb-2.5">
                      <History className="w-4 h-4 text-slate-400" />
                      <span>{getTranslation(lang, 'member.past')}</span>
                    </div>
                    <div className="space-y-2.5 text-xs text-slate-400">
                      <div className="flex justify-between items-center text-[11px] border-b border-white/5 pb-2">
                        <span>Taipei ➜ Taichung (08/12)</span>
                        <span className="font-mono text-[#00FF88] font-bold">Completed</span>
                      </div>
                      <div className="flex justify-between items-center text-[11px] border-b border-white/5 pb-2">
                        <span>Taichung ➜ Kaohsiung (08/04)</span>
                        <span className="font-mono text-[#00FF88] font-bold">Completed</span>
                      </div>
                      <div className="flex justify-between items-center text-[11px]">
                        <span>Taipei ➜ Hualien (07/20)</span>
                        <span className="font-mono text-[#00FF88] font-bold">Completed</span>
                      </div>
                    </div>
                  </div>
                </div>

              </motion.div>
            ) : (
              <motion.div
                key="settings-pane"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 15 }}
                className="bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-lg text-left"
              >
                <div className="flex items-center space-x-2 text-cyan-400 text-xs font-bold font-mono uppercase mb-6 border-b border-white/10 pb-3">
                  <Settings className="w-4 h-4" />
                  <span>PROFILE SETTINGS & CONTROLS</span>
                </div>

                <AnimatePresence>
                  {saveSuccess && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="mb-4 bg-[#00FF88]/10 border border-[#00FF88]/40 p-3 rounded-xl flex items-center space-x-2 text-[#00FF88] text-xs font-bold"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Profile information saved successfully!</span>
                    </motion.div>
                  )}
                </AnimatePresence>

                <form onSubmit={handleProfileSave} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-slate-400 text-xs font-semibold mb-1.5" htmlFor="set-name-zh">
                        中文姓名 / Name in Chinese
                      </label>
                      <input
                        id="set-name-zh"
                        type="text"
                        value={nameZh}
                        onChange={(e) => setNameZh(e.target.value)}
                        className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-2.5 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 text-xs font-semibold mb-1.5" htmlFor="set-name-en">
                        英文姓名 / Name in English
                      </label>
                      <input
                        id="set-name-en"
                        type="text"
                        value={nameEn}
                        onChange={(e) => setNameEn(e.target.value)}
                        className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-2.5 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 text-xs font-semibold mb-1.5" htmlFor="set-email">
                      電子郵件 / Email Address
                    </label>
                    <input
                      id="set-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-950/50 border border-white/10 rounded-lg px-4 py-2.5 text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
                      required
                    />
                  </div>

                  <div className="pt-4 border-t border-white/10 flex justify-end">
                    <button
                      id="member-save-profile-btn"
                      type="submit"
                      className="flex items-center justify-center space-x-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 py-3 px-6 rounded-xl text-xs font-black shadow-[0_4px_15px_rgba(6,182,212,0.25)] transition-all cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>儲存變更 Save Changes</span>
                    </button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
