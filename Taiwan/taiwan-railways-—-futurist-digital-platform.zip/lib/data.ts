export interface Station {
  id: string;
  zh: string;
  en: string;
  region: 'North' | 'Central' | 'South' | 'East';
}

export interface TrainType {
  code: string;
  zh: string;
  en: string;
  fareRate: number; // NT$ per base unit
  durationMinutes: number; // base duration between adjacent major hubs
}

export interface NewsItem {
  id: string;
  date: string;
  titleZh: string;
  titleEn: string;
  categoryZh: string;
  categoryEn: string;
  contentZh: string;
  contentEn: string;
}

export interface LiveTrainStatus {
  id: string;
  trainNo: string;
  typeZh: string;
  typeEn: string;
  fromZh: string;
  fromEn: string;
  toZh: string;
  toEn: string;
  status: 'on-time' | 'delayed' | 'suspended' | 'partial-delay';
  delayMinutes: number;
  departureTime: string;
  expectedArrivalTime: string;
  progress: number; // 0 to 100
  currentPositionZh: string;
  currentPositionEn: string;
}

export interface Destination {
  id: string;
  nameZh: string;
  nameEn: string;
  region: 'North' | 'Central' | 'South' | 'East' | 'Islands';
  stationZh: string;
  stationEn: string;
  descZh: string;
  descEn: string;
  travelTimeZh: string;
  travelTimeEn: string;
  attractionsZh: string[];
  attractionsEn: string[];
  image: string;
}

export interface Journey {
  id: string;
  trainNo: string;
  typeZh: string;
  typeEn: string;
  fromZh: string;
  fromEn: string;
  toZh: string;
  toEn: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  availableSeats: number;
  fare: number;
  status: 'on-time' | 'delayed' | 'suspended';
  delayMinutes: number;
  features: string[];
}

export const STATIONS: Station[] = [
  { id: 'TPE', zh: '臺北', en: 'Taipei', region: 'North' },
  { id: 'BQC', zh: '板橋', en: 'Banqiao', region: 'North' },
  { id: 'HSC', zh: '新竹', en: 'Hsinchu', region: 'North' },
  { id: 'TCH', zh: '臺中', en: 'Taichung', region: 'Central' },
  { id: 'CYI', zh: '嘉義', en: 'Chiayi', region: 'Central' },
  { id: 'TNN', zh: '臺南', en: 'Tainan', region: 'South' },
  { id: 'KHH', zh: '高雄', en: 'Kaohsiung', region: 'South' },
  { id: 'TYD', zh: '桃園', en: 'Taoyuan', region: 'North' },
  { id: 'ILA', zh: '宜蘭', en: 'Yilan', region: 'East' },
  { id: 'HUN', zh: '花蓮', en: 'Hualien', region: 'East' },
  { id: 'TTT', zh: '臺東', en: 'Taitung', region: 'East' },
  { id: 'PEH', zh: '屏東', en: 'Pingtung', region: 'South' }
];

export const TRAIN_TYPES: TrainType[] = [
  { code: 'EXP', zh: '新世代自強號 (EMU3000)', en: 'TRA Express (EMU3000)', fareRate: 2.2, durationMinutes: 140 },
  { code: 'TC', zh: '太魯閣/普悠瑪號', en: 'Taroko / Puyuma Express', fareRate: 2.2, durationMinutes: 150 },
  { code: 'CK', zh: '自強號', en: 'Tze-Chiang Limited Express', fareRate: 1.9, durationMinutes: 180 },
  { code: 'JG', zh: '莒光號', en: 'Chu-Kuang Express', fareRate: 1.4, durationMinutes: 240 },
  { code: 'LC', zh: '區間快車', en: 'Local Express', fareRate: 1.1, durationMinutes: 210 }
];

export const NEWS_DATA: NewsItem[] = [
  {
    id: 'news-1',
    date: '2026/08/20',
    titleZh: '臺鐵公司未來藍圖：智慧綠能與高鐵協同升級',
    titleEn: 'TRA Future Blueprint: Smart Green Energy & HSR Collaboration',
    categoryZh: '未來規劃',
    categoryEn: 'Future Planning',
    contentZh: '臺鐵公司發表2030未來數位化與零碳排鐵路營運策略，將引進智慧電網與次世代高速車組，提供旅客更低碳、高效率的環島旅程。',
    contentEn: 'TRA released its 2030 future strategy for carbon-neutral operations, introducing smart grids and next-generation express fleets to provide low-carbon, highly efficient island-wide journeys.'
  },
  {
    id: 'news-2',
    date: '2026/08/18',
    titleZh: '智慧鐵道新世代：全面啟用AI人流導引與安全感測器',
    titleEn: 'Next-Gen Smart Rail: AI Crowd Guidance & Safety Sensors Fully Implemented',
    categoryZh: '系統更新',
    categoryEn: 'System Update',
    contentZh: '全台12大核心車站今日起啟用次世代智慧AI導航，提供旅客即時人流分析、最佳轉乘路徑規劃，並在月台增設高感度光學雷達安全防護系統。',
    contentEn: 'Beginning today, 12 major rail stations nationwide have enabled AI passenger navigation, offering real-time flow analysis and transit routing while securing platforms with lidar safety sensors.'
  },
  {
    id: 'news-3',
    date: '2026/08/15',
    titleZh: '「EMU3500 臺灣之光」新型未來列車正式上線，提升旅運體驗',
    titleEn: 'New "EMU3500 Light of Taiwan" Futurist Express Fleet Launched',
    categoryZh: '列車資訊',
    categoryEn: 'Train Info',
    contentZh: '首批高靜音、全景觀景車窗設計的新型EMU3500列車今日於東部幹線首發，配備智慧調光玻璃、主動抗噪座椅及5G物聯網個人座艙。',
    contentEn: 'The first batch of silent, panoramic-window EMU3500 trainsets debuted on the East Coast Line today, boasting smart tinting glass, active noise-canceling seats, and 5G IoT cabins.'
  },
  {
    id: 'news-4',
    date: '2026/08/10',
    titleZh: '「TPASS 3.0」智慧通勤月票方案上線：結合生物辨識與電子錢包',
    titleEn: 'TPASS 3.0 Commuter Pass Live: Bio-Auth and Digital Wallet Integration',
    categoryZh: '票務公告',
    categoryEn: 'Ticketing',
    contentZh: '新一代TPASS通勤月票全面支持手機錢包感應與無感人臉快速過閘，並加入微交通（共享單車、接駁巴士）一票到底的未來整合。',
    contentEn: 'The new TPASS pass supports seamless mobile wallet tap-in, biometric gate access, and fully covers micro-mobility connections (shared e-bikes, shuttle buses) in a single fare.'
  },
  {
    id: 'news-5',
    date: '2026/08/05',
    titleZh: '臺東新站啟用，打造東台灣未來科技門戶與多功能轉運中心',
    titleEn: 'New Taitung Station Debuts as East Taiwan\'s Tech Gateway',
    categoryZh: '車站啟用',
    categoryEn: 'Station Open',
    contentZh: '融合原住民文化美學與極簡科技風的臺東新站正式揭幕，配備智慧綠建築循環溫控、3D沉浸式旅遊導覽大廳及全自動行李託運中心。',
    contentEn: 'Integrating indigenous aesthetics and high-tech minimalism, the brand-new Taitung Station opened with smart thermal controls, immersive 3D travel lobbies, and automated check-ins.'
  }
];

export const LIVE_STATUS_DATA: LiveTrainStatus[] = [
  {
    id: 'live-1',
    trainNo: '117',
    typeZh: '新世代自強號',
    typeEn: 'TRA Express',
    fromZh: '南港',
    fromEn: 'Nangang',
    toZh: '左營',
    toEn: 'Zuoying',
    status: 'on-time',
    delayMinutes: 0,
    departureTime: '10:30',
    expectedArrivalTime: '13:45',
    progress: 45,
    currentPositionZh: '臺中',
    currentPositionEn: 'Taichung'
  },
  {
    id: 'live-2',
    trainNo: '228',
    typeZh: '太魯閣號',
    typeEn: 'Taroko Express',
    fromZh: '樹林',
    fromEn: 'Shulin',
    toZh: '花蓮',
    toEn: 'Hualien',
    status: 'delayed',
    delayMinutes: 8,
    departureTime: '11:15',
    expectedArrivalTime: '13:30',
    progress: 72,
    currentPositionZh: '礁溪',
    currentPositionEn: 'Jiaoxi'
  },
  {
    id: 'live-3',
    trainNo: '415',
    typeZh: '普悠瑪號',
    typeEn: 'Puyuma Express',
    fromZh: '臺北',
    fromEn: 'Taipei',
    toZh: '臺東',
    toEn: 'Taitung',
    status: 'on-time',
    delayMinutes: 0,
    departureTime: '12:00',
    expectedArrivalTime: '15:48',
    progress: 15,
    currentPositionZh: '宜蘭',
    currentPositionEn: 'Yilan'
  },
  {
    id: 'live-4',
    trainNo: '152',
    typeZh: '自強號',
    typeEn: 'Tze-Chiang Exp',
    fromZh: '屏東',
    fromEn: 'Pingtung',
    toZh: '七堵',
    toEn: 'Qidu',
    status: 'partial-delay',
    delayMinutes: 12,
    departureTime: '08:45',
    expectedArrivalTime: '14:10',
    progress: 88,
    currentPositionZh: '中壢',
    currentPositionEn: 'Zhongli'
  },
  {
    id: 'live-5',
    trainNo: '802',
    typeZh: '區間快車',
    typeEn: 'Local Express',
    fromZh: '新竹',
    fromEn: 'Hsinchu',
    toZh: '基隆',
    toEn: 'Keelung',
    status: 'suspended',
    delayMinutes: 0,
    departureTime: '12:30',
    expectedArrivalTime: '14:15',
    progress: 0,
    currentPositionZh: '新竹 (未出發)',
    currentPositionEn: 'Hsinchu (Not Departed)'
  }
];

export const DESTINATIONS: Destination[] = [
  {
    id: 'tpe',
    nameZh: '臺北',
    nameEn: 'Taipei',
    region: 'North',
    stationZh: '臺北車站',
    stationEn: 'Taipei Main Station',
    descZh: '匯集政治、經濟與文化核心的摩登都市，擁抱古色古香與次世代未來科技。',
    descEn: 'Taiwan\'s political and cultural epicenter, blending historic temples with sleek skyscrapers and futuristic technologies.',
    travelTimeZh: '起點 / Hub',
    travelTimeEn: 'Origin / Hub',
    attractionsZh: ['台北101', '大稻埕歷史特區', '故宮博物院', '西門町科技商圈'],
    attractionsEn: ['Taipei 101', 'Dadaocheng Old Street', 'National Palace Museum', 'Ximending Tech District'],
    image: 'https://picsum.photos/seed/taipei101/800/600'
  },
  {
    id: 'ila',
    nameZh: '宜蘭',
    nameEn: 'Yilan',
    region: 'East',
    stationZh: '宜蘭車站',
    stationEn: 'Yilan Station',
    descZh: '穿越雪山隧道，迎來的是開闊的蘭陽平原與純淨的溫泉泉源。',
    descEn: 'Crossing the mountain range unveils the beautiful Lanyang Plain, lush rice fields, and soothing natural hot springs.',
    travelTimeZh: '約 1 小時 10 分 (自強號)',
    travelTimeEn: 'Approx. 1h 10m (Express)',
    attractionsZh: ['礁溪溫泉公園', '羅東夜市', '太平山國家森林', '蘭陽博物館'],
    attractionsEn: ['Jiaoxi Hot Springs', 'Luodong Night Market', 'Taipingshan Forest', 'Lanyang Museum'],
    image: 'https://picsum.photos/seed/yilan/800/600'
  },
  {
    id: 'hun',
    nameZh: '花蓮',
    nameEn: 'Hualien',
    region: 'East',
    stationZh: '花蓮車站',
    stationEn: 'Hualien Station',
    descZh: '大自然鬼斧神工的太魯閣峽谷與浩瀚太平洋在此交織成最壯麗的風景。',
    descEn: 'Where the jaw-dropping marble walls of Taroko Gorge collide with the turquoise waters of the endless Pacific.',
    travelTimeZh: '約 2 小時 (普悠瑪號)',
    travelTimeEn: 'Approx. 2h (Puyuma Express)',
    attractionsZh: ['太魯閣國家公園', '七星潭', '鯉魚潭', '東大門夜市'],
    attractionsEn: ['Taroko Gorge National Park', 'Qixingtan Beach', 'Liyu Lake', 'Dongdamen Night Market'],
    image: 'https://picsum.photos/seed/hualien/800/600'
  },
  {
    id: 'ttt',
    nameZh: '臺東',
    nameEn: 'Taitung',
    region: 'East',
    stationZh: '臺東車站',
    stationEn: 'Taitung Station',
    descZh: '太平洋徐徐海風吹拂的慢活城市，是熱氣球嘉年華與東海岸藝術的故鄉。',
    descEn: 'Blessed by refreshing ocean breezes, Taitung is the land of slow living, hot air balloons, and indigenous arts.',
    travelTimeZh: '約 3 小時 30 分 (EMU3000)',
    travelTimeEn: 'Approx. 3h 30m (EMU3000)',
    attractionsZh: ['三仙台', '伯朗大道', '台東森林公園', '鹿野高台'],
    attractionsEn: ['Sanxiantai Arch Bridge', 'Brown Avenue', 'Taitung Forest Park', 'Luye Highland'],
    image: 'https://picsum.photos/seed/taitung/800/600'
  },
  {
    id: 'khh',
    nameZh: '高雄',
    nameEn: 'Kaohsiung',
    region: 'South',
    stationZh: '高雄車站',
    stationEn: 'Kaohsiung Station',
    descZh: '充滿陽光魅力的港灣大都市，藝術中心與智慧碼頭交織出前衛海港風情。',
    descEn: 'A sun-drenched maritime metropolis where historic piers, cutting-edge art centers, and high-tech ports meet.',
    travelTimeZh: '約 2 小時 45 分 (快速列車)',
    travelTimeEn: 'Approx. 2h 45m (Express Train)',
    attractionsZh: ['駁二藝術特區', '愛河之星', '旗津半島', '衛武營國家藝術中心'],
    attractionsEn: ['The Pier-2 Art Center', 'Love River', 'Cijin Island', 'Weiwuying Center for the Arts'],
    image: 'https://picsum.photos/seed/kaohsiung/800/600'
  },
  {
    id: 'peh',
    nameZh: '屏東',
    nameEn: 'Pingtung',
    region: 'South',
    stationZh: '屏東車站',
    stationEn: 'Pingtung Station',
    descZh: '熱帶氣候、黃金沙灘與墾丁國境之南，充滿南國熱情與豐富生態。',
    descEn: 'Tropical heat, golden sand beaches, and Kenting\'s bio-diverse coral reefs await at Taiwan\'s southernmost paradise.',
    travelTimeZh: '約 3 小時 10 分 (自強號)',
    travelTimeEn: 'Approx. 3h 10m (Express)',
    attractionsZh: ['墾丁國家公園', '大鵬灣國家風景區', '勝利星村', '鵝鑾鼻燈塔'],
    attractionsEn: ['Kenting National Park', 'Dapeng Bay', 'Shengli Star Village', 'Eluanbi Lighthouse'],
    image: 'https://picsum.photos/seed/pingtung/800/600'
  },
  {
    id: 'tch',
    nameZh: '臺中',
    nameEn: 'Taichung',
    region: 'Central',
    stationZh: '臺中車站',
    stationEn: 'Taichung Station',
    descZh: '氣候宜人、綠意盎然的文化之都，融合前衛歌劇院與創意餐飲美學。',
    descEn: 'An urban oasis boasting pleasant year-round weather, lush parks, avant-garde architecture, and a culinary canvas.',
    travelTimeZh: '約 1 小時 30 分 (自強號)',
    travelTimeEn: 'Approx. 1h 30m (Express)',
    attractionsZh: ['台中國家歌劇院', '高美濕地', '逢甲夜市', '草悟道'],
    attractionsEn: ['National Taichung Theater', 'Gaomei Wetlands', 'Fengjia Night Market', 'Calligraphy Greenway'],
    image: 'https://picsum.photos/seed/taichung/800/600'
  },
  {
    id: 'cyi',
    nameZh: '嘉義',
    nameEn: 'Chiayi',
    region: 'Central',
    stationZh: '嘉義車站',
    stationEn: 'Chiayi Station',
    descZh: '阿里山森林鐵路的門戶，飄著檜木香氣與舉世聞名的雞肉飯美味。',
    descEn: 'The gateway to the sacred Alishan Forest Railway, infused with Japanese hinoki cypress scents and renowned chicken rice.',
    travelTimeZh: '約 2 小時 15 分 (自強號)',
    travelTimeEn: 'Approx. 2h 15m (Express)',
    attractionsZh: ['阿里山森林遊樂區', '檜意森活村', '故宮南院', '文化路夜市'],
    attractionsEn: ['Alishan Forest Recreation', 'Hinoki Village', 'Southern Branch of Palace Museum', 'Wenhua Road Night Market'],
    image: 'https://picsum.photos/seed/chiayi/800/600'
  },
  {
    id: 'tnn',
    nameZh: '臺南',
    nameEn: 'Tainan',
    region: 'South',
    stationZh: '臺南車站',
    stationEn: 'Tainan Station',
    descZh: '臺灣最古老的城市，漫步在磚紅巷弄、老宅古蹟與精緻小吃之中。',
    descEn: 'Taiwan\'s oldest historic city, loaded with ancient red-brick alleys, towering fortress walls, and legendary street foods.',
    travelTimeZh: '約 2 小時 30 分 (自強號)',
    travelTimeEn: 'Approx. 2h 30m (Express)',
    attractionsZh: ['安平古堡', '奇美博物館', '神農街老屋', '赤崁樓'],
    attractionsEn: ['Anping Fort', 'Chimei Museum', 'Shennong Street', 'Chihkan Tower'],
    image: 'https://picsum.photos/seed/tainan/800/600'
  }
];

// Fare calculation algorithm helper
export function calculateFare(fromId: string, toId: string, trainCode: string, passengerType: 'adult' | 'child' | 'senior'): {
  baseFare: number;
  discountedFare: number;
  durationMinutes: number;
  estimatedTime: string;
} {
  const fromIndex = STATIONS.findIndex(s => s.id === fromId);
  const toIndex = STATIONS.findIndex(s => s.id === toId);
  
  if (fromIndex === -1 || toIndex === -1) {
    return { baseFare: 0, discountedFare: 0, durationMinutes: 0, estimatedTime: '0h' };
  }
  
  const distanceUnits = Math.abs(fromIndex - toIndex);
  if (distanceUnits === 0) {
    return { baseFare: 15, discountedFare: 15, durationMinutes: 10, estimatedTime: '10m' };
  }

  const train = TRAIN_TYPES.find(t => t.code === trainCode) || TRAIN_TYPES[0];
  
  // Base cost calculation
  const distanceKm = distanceUnits * 32 + 10; // estimate distance
  const rawFare = Math.round(distanceKm * train.fareRate);
  
  // Passenger discounts
  let discountMultiplier = 1.0;
  if (passengerType === 'child') discountMultiplier = 0.5;
  if (passengerType === 'senior') discountMultiplier = 0.5;
  
  const discountedFare = Math.round(rawFare * discountMultiplier);
  const durationMin = Math.round(distanceUnits * (train.durationMinutes / 4));
  
  const h = Math.floor(durationMin / 60);
  const m = durationMin % 60;
  const estimatedTime = h > 0 ? `${h}h ${m}m` : `${m}m`;

  return {
    baseFare: rawFare,
    discountedFare,
    durationMinutes: durationMin,
    estimatedTime
  };
}

// Generate highly realistic timetables / trains on search
export function searchTrains(fromId: string, toId: string, date: string): Journey[] {
  const fromStation = STATIONS.find(s => s.id === fromId);
  const toStation = STATIONS.find(s => s.id === toId);
  
  if (!fromStation || !toStation) return [];
  
  const results: Journey[] = [];
  const baseHours = [6, 8, 10, 11, 13, 14, 16, 17, 19, 21, 22];
  
  baseHours.forEach((hour, idx) => {
    // Select deterministic but authentic train type
    const typeIdx = idx % TRAIN_TYPES.length;
    const trainType = TRAIN_TYPES[typeIdx];
    const { discountedFare, estimatedTime, durationMinutes } = calculateFare(fromId, toId, trainType.code, 'adult');
    
    const depMin = (idx * 13) % 60;
    const depTimeStr = `${String(hour).padStart(2, '0')}:${String(depMin).padStart(2, '0')}`;
    
    // Calculate arrival time
    const totalMin = hour * 60 + depMin + durationMinutes;
    const arrHour = Math.floor(totalMin / 60) % 24;
    const arrMin = totalMin % 60;
    const arrTimeStr = `${String(arrHour).padStart(2, '0')}:${String(arrMin).padStart(2, '0')}`;
    
    const trainNum = String(100 + idx * 24 + 11).substring(0, 3);
    
    // Seat count
    const availableSeats = Math.max(0, Math.floor(150 * Math.sin(idx + 2.5) + 120));
    const statusVal = idx === 3 ? 'delayed' : idx === 8 ? 'suspended' : 'on-time';
    const delayMins = statusVal === 'delayed' ? 12 : 0;
    
    results.push({
      id: `${fromId}-${toId}-${trainNum}-${idx}`,
      trainNo: trainNum,
      typeZh: trainType.zh,
      typeEn: trainType.en,
      fromZh: fromStation.zh,
      fromEn: fromStation.en,
      toZh: toStation.zh,
      toEn: toStation.en,
      departureTime: depTimeStr,
      arrivalTime: arrTimeStr,
      duration: estimatedTime,
      availableSeats,
      fare: discountedFare,
      status: statusVal,
      delayMinutes: delayMins,
      features: ['WiFi', 'Power Outlet', 'ADA Space', 'Luggage Cab'][idx % 4] ? [['WiFi', 'Power Outlet'], ['WiFi', 'ADA Space', 'Power Outlet'], ['WiFi', 'Bicycle Space'], ['Power Outlet']][idx % 4] : ['WiFi']
    });
  });
  
  return results;
}

export interface UserTicket {
  ticketNo: string;
  passengerNameZh: string;
  passengerNameEn: string;
  passengerType: string;
  trainNo: string;
  typeZh: string;
  typeEn: string;
  fromZh: string;
  fromEn: string;
  toZh: string;
  toEn: string;
  date: string;
  departureTime: string;
  arrivalTime: string;
  carNo: string;
  seatNo: string;
  fare: number;
  qrValue: string;
}

export const MOCK_TICKETS: UserTicket[] = [
  {
    ticketNo: 'TRA-2026-9901A',
    passengerNameZh: '王小明',
    passengerNameEn: 'Wang Xiao-Ming',
    passengerType: 'Adult / 成人',
    trainNo: '117',
    typeZh: '新世代自強號 (EMU3000)',
    typeEn: 'TRA Express (EMU3000)',
    fromZh: '臺北',
    fromEn: 'Taipei',
    toZh: '高雄',
    toEn: 'Kaohsiung',
    date: '2026-08-26',
    departureTime: '10:30',
    arrivalTime: '13:45',
    carNo: '05',
    seatNo: '12-A (Window / 靠窗)',
    fare: 1490,
    qrValue: 'TRA_TICKET_MOCK_VALIDATION_0826_WANG'
  },
  {
    ticketNo: 'TRA-2026-4482B',
    passengerNameZh: '王小明',
    passengerNameEn: 'Wang Xiao-Ming',
    passengerType: 'Adult / 成人',
    trainNo: '415',
    typeZh: '普悠瑪號',
    typeEn: 'Puyuma Express',
    fromZh: '臺北',
    fromEn: 'Taipei',
    toZh: '花蓮',
    toEn: 'Hualien',
    date: '2026-09-02',
    departureTime: '12:00',
    arrivalTime: '14:05',
    carNo: '02',
    seatNo: '08-C (Aisle / 靠走道)',
    fare: 440,
    qrValue: 'TRA_TICKET_MOCK_VALIDATION_0902_WANG'
  }
];

export interface MemberProfile {
  id: string;
  nameZh: string;
  nameEn: string;
  email: string;
  levelZh: string;
  levelEn: string;
  points: number;
  tpassStatusZh: string;
  tpassStatusEn: string;
  savedRoutes: { from: string; to: string }[];
}

export const MOCK_MEMBER: MemberProfile = {
  id: 'TRA-MEM-889210',
  nameZh: '王小明',
  nameEn: 'Wang Xiao-Ming',
  email: 'tom@ahyx.org',
  levelZh: '晶鑽尊榮會員',
  levelEn: 'Diamond Elite Member',
  points: 12450,
  tpassStatusZh: 'TPASS 3.0 生效中 (至 2026/09/25)',
  tpassStatusEn: 'TPASS 3.0 Active (expires 2026/09/25)',
  savedRoutes: [
    { from: 'TPE', to: 'KHH' },
    { from: 'TPE', to: 'HUN' }
  ]
};
