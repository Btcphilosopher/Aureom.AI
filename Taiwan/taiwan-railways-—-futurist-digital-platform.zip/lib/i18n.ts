export type Language = 'zh' | 'en';

export const TRANSLATIONS: Record<Language, Record<string, string>> = {
  zh: {
    // Nav & Header
    'nav.home': '首頁',
    'nav.travelInfo': '乘車資訊',
    'nav.ticketing': '購票服務',
    'nav.explore': '探索臺灣',
    'nav.member': '會員服務',
    'nav.about': '關於臺鐵',
    'nav.lang': '繁體中文',
    'nav.account': '會員登入',
    'nav.menu': '選單',
    
    // Hero
    'hero.title': '前進未來　連結臺灣',
    'hero.subtitle': 'Connecting Taiwan, Advancing the Future',
    'hero.cta': '探索更多',
    
    // Booking Widget
    'booking.title': '立即訂票',
    'booking.subtitle': 'Book Tickets',
    'booking.from': '出發地',
    'booking.to': '目的地',
    'booking.date': '出發日期',
    'booking.passengers': '人數',
    'booking.search': '查詢車次',
    'booking.swap': '對調起迄站',
    'booking.passengerCount': '{count} 位乘客',
    'booking.passengerDetail': '{adult}成人, {child}孩童, {senior}敬老',
    'booking.adult': '成人 (全票)',
    'booking.child': '孩童 (半票)',
    'booking.senior': '敬老 (優待票)',
    
    // Quick Services
    'quick.timetable': '時刻查詢',
    'quick.fares': '票價查詢',
    'quick.orders': '訂單查詢',
    'quick.eticket': '電子票證',
    'quick.member': '會員專區',
    
    // News Section
    'news.title': '最新消息',
    'news.subtitle': 'News',
    'news.more': '更多',
    
    // Live Status
    'live.title': '即時運行資訊',
    'live.subtitle': 'Live Status',
    'live.trainNo': '車次',
    'live.onTime': '準點',
    'live.delayed': '延誤',
    'live.suspended': '停駛',
    'live.partialDelay': '部分延誤',
    'live.min': '分',
    'live.expected': '預計',
    'live.position': '目前位置',
    'live.route': '運行區間',
    'live.simulatorActive': '實時模擬運作中',
    
    // Content Cards
    'card.newTrain.title': '全新列車體驗',
    'card.newTrain.subtitle': 'New Train Experience',
    'card.newTrain.desc': '開創明日鐵道旅程。EMU3500 次世代科技列車全面導入，極致靜音、5G個人座艙、智慧調光全景車窗，帶給您頭等艙級舒適。',
    'card.explore.title': '探索臺灣之美',
    'card.explore.subtitle': 'Explore Taiwan',
    'card.explore.desc': '沿著太平洋藍色海岸，穿越中央山脈的雲霧森林。坐火車去旅行，在每一站發現福爾摩沙的獨特溫度與人文底蘊。',
    'card.app.title': '臺鐵會員 APP',
    'card.app.subtitle': 'TRA Member App',
    'card.app.desc': '智慧出行，一手掌控。電子票卡過閘、即時誤點推播、會員積點兌換與車上便當點餐服務，2030全面升級。',
    'card.more': '了解更多',
    
    // Explore section
    'explore.title': '探索臺灣之美',
    'explore.subtitle': 'Explore Taiwan',
    'explore.all': '全部地區',
    'explore.North': '北部',
    'explore.Central': '中部',
    'explore.South': '南部',
    'explore.East': '東部',
    'explore.Islands': '離島與支線',
    'explore.attractions': '著名景點',
    'explore.plan': '規劃行程',
    'explore.duration': '車程',
    'explore.station': '抵達車站',
    
    // Search results / Booking journey flow
    'search.title': '車次查詢結果',
    'search.sub': 'Available Trains',
    'search.date': '搭乘日期',
    'search.route': '行駛區間',
    'search.sort.departure': '最早出發',
    'search.sort.duration': '時間最短',
    'search.sort.fare': '票價最低',
    'search.filter.type': '車種篩選',
    'search.filter.all': '全部車種',
    'search.seatsLeft': '剩餘 {count} 席',
    'search.seatSoldOut': '客滿',
    'search.select': '選擇車次',
    'search.noResults': '抱歉，此日期區間無符合的列車班次。請嘗試更改出發站、目的地或日期。',
    'search.demoWarning': '本頁面數據僅供模擬演示，非即時營運動態。',
    'search.loading': '智慧系統正搜尋最優火車路線與即時席位...',
    'search.bookNow': '立即付款購票',
    'search.totalPrice': '訂票總額',
    
    // Timetable Dedicated Page
    'timetable.title': '列車時刻表查詢',
    'timetable.subtitle': 'Train Timetable Search',
    'timetable.col.train': '車種車次',
    'timetable.col.dep': '出發時間',
    'timetable.col.arr': '抵達時間',
    'timetable.col.dur': '行車時間',
    'timetable.col.status': '運行狀態',
    'timetable.col.action': '預訂',
    
    // Fares Calculator Page
    'fare.title': '車次票價試算',
    'fare.subtitle': 'Fare Calculator',
    'fare.passenger': '票種選擇',
    'fare.ticketType': '車廂種類',
    'fare.standard': '一般車廂',
    'fare.business': '騰雲座艙 (商務)',
    'fare.result.standard': '標準車廂單程票價',
    'fare.result.discounted': '符合優惠單程票價',
    'fare.result.type': '適用對象說明：半票適用於12歲以下孩童；優待票適用於65歲以上敬老乘客。',
    'fare.result.disclaimer': '※ 以上試算僅供參考，實際票價以最終訂票系統結帳為準。',
    
    // E-Ticket Page
    'ticket.title': '我的電子車票',
    'ticket.subtitle': 'My Digital Ticket',
    'ticket.demoLabel': '展示票券 / 非搭乘憑證',
    'ticket.passenger': '搭乘旅客',
    'ticket.train': '車種車次',
    'ticket.date': '搭乘日期',
    'ticket.seat': '車廂 / 座位',
    'ticket.ticketNo': '票卡編號',
    'ticket.wallet': '加入 Apple Wallet',
    'ticket.download': '下載 PDF 憑證',
    'ticket.view': '顯示票券',
    'ticket.scannedWarning': '請將此 QR Code 對準閘門感應區，即可快速通關。',
    'ticket.saved': '已成功儲存至您的憑證包！',
    
    // Member Dashboard
    'member.title': '會員智慧控制大廳',
    'member.subtitle': 'Member Smart Dashboard',
    'member.no': '會員卡號',
    'member.level': '會員等級',
    'member.points': '累積紅利點數',
    'member.pointsLabel': '點',
    'member.upcoming': '即將到來的旅程',
    'member.past': '歷史搭乘紀錄',
    'member.savedStations': '常用起訖站',
    'member.settings': '智慧行安全設定',
    'member.tpass': '定期通勤方案 (TPASS)',
    'member.orders': '訂單管理',
    'member.tickets': '票卡夾',
    'member.name': '姓名',
    'member.email': '電子郵件',
    
    // Footer sections
    'footer.about': '關於臺鐵',
    'footer.corp': '企業資訊',
    'footer.careers': '人才招募',
    'footer.news': '新聞發布',
    'footer.contact': '聯絡我們',
    
    'footer.services': '旅客服務',
    'footer.booking': '線上購票',
    'footer.schedule': '時刻表',
    'footer.fareInfo': '票價說明',
    'footer.eticket': '電子票卡',
    'footer.memberApp': 'APP 下載',
    
    'footer.travel': '鐵道旅遊',
    'footer.explore': '探索臺灣',
    'footer.destinations': '熱門景點',
    'footer.tourism': '鐵道觀光列車',
    'footer.accessibility': '無障礙服務',
    
    'footer.support': '客服支援',
    'footer.help': '常見問題 (FAQ)',
    'footer.lost': '遺失物協尋',
    'footer.emergency': '緊急通報資訊',
    'footer.status': '即時運行報告',
    
    'footer.privacy': '隱私權保護政策',
    'footer.terms': '服務條款',
    'footer.statement': '無障礙聲明書',
    'footer.copyright': '© 2026 國營臺灣鐵路股份有限公司 版權所有',
    
    // General / UI state
    'ui.loading': '載入中...',
    'ui.submit': '提交',
    'ui.cancel': '取消',
    'ui.back': '返回上一頁',
    'ui.alert.success': '操作成功',
    'ui.all': '全部',
    'ui.noRecord': '尚無任何紀錄'
  },
  en: {
    // Nav & Header
    'nav.home': 'Home',
    'nav.travelInfo': 'Travel Info',
    'nav.ticketing': 'Ticketing',
    'nav.explore': 'Explore Taiwan',
    'nav.member': 'Member Service',
    'nav.about': 'About TRA',
    'nav.lang': 'English',
    'nav.account': 'Account',
    'nav.menu': 'Menu',
    
    // Hero
    'hero.title': 'Connecting Taiwan, Advancing the Future',
    'hero.subtitle': 'Connecting Taiwan, Advancing the Future',
    'hero.cta': 'Explore More',
    
    // Booking Widget
    'booking.title': 'Book Tickets',
    'booking.subtitle': 'Book Tickets',
    'booking.from': 'From',
    'booking.to': 'To',
    'booking.date': 'Date',
    'booking.passengers': 'Passengers',
    'booking.search': 'Search Trains',
    'booking.swap': 'Swap Stations',
    'booking.passengerCount': '{count} Traveler(s)',
    'booking.passengerDetail': '{adult} Adult(s), {child} Child(ren), {senior} Senior(s)',
    'booking.adult': 'Adult (Full Fare)',
    'booking.child': 'Child (Half Fare)',
    'booking.senior': 'Senior (Concession)',
    
    // Quick Services
    'quick.timetable': 'Timetable',
    'quick.fares': 'Fares',
    'quick.orders': 'My Orders',
    'quick.eticket': 'E-Ticket',
    'quick.member': 'Member Area',
    
    // News Section
    'news.title': 'Latest News',
    'news.subtitle': 'News',
    'news.more': 'More',
    
    // Live Status
    'live.title': 'Real-Time Train Status',
    'live.subtitle': 'Live Status',
    'live.trainNo': 'Train No.',
    'live.onTime': 'On Time',
    'live.delayed': 'Delayed',
    'live.suspended': 'Suspended',
    'live.partialDelay': 'Partial Delay',
    'live.min': 'mins',
    'live.expected': 'Exp',
    'live.position': 'Current Location',
    'live.route': 'Route Sector',
    'live.simulatorActive': 'Live Simulator Active',
    
    // Content Cards
    'card.newTrain.title': 'New Train Experience',
    'card.newTrain.subtitle': 'New Train Experience',
    'card.newTrain.desc': 'Pioneering tomorrow\'s railway journeys. The EMU3500 next-generation express fleet is now operational, featuring supreme noise reduction, 5G smart private cabins, and panoramic smart-dimming windows.',
    'card.explore.title': 'Explore Taiwan',
    'card.explore.subtitle': 'Explore Taiwan',
    'card.explore.desc': 'Meander along the deep blue Pacific coastline and cross misty mountain pine forests. Traveling by rail invites you to discover Formosa\'s distinct local warmth and rich cultural roots.',
    'card.app.title': 'TRA Member App',
    'card.app.subtitle': 'TRA Member App',
    'card.app.desc': 'Smart travel right in your palm. Seamless electronic gate access, instant delay alerts, loyalty point redemptions, and onboard bento ordering all fully upgraded for 2030+.',
    'card.more': 'Learn More',
    
    // Explore section
    'explore.title': 'Explore the Beauty of Taiwan',
    'explore.subtitle': 'Explore Taiwan',
    'explore.all': 'All Regions',
    'explore.North': 'North',
    'explore.Central': 'Central',
    'explore.South': 'South',
    'explore.East': 'East',
    'explore.Islands': 'Islands & Branches',
    'explore.attractions': 'Must-Visit Attractions',
    'explore.plan': 'Plan Journey',
    'explore.duration': 'Travel Time',
    'explore.station': 'Arriving Station',
    
    // Search results / Booking journey flow
    'search.title': 'Train Search Results',
    'search.sub': 'Available Trains',
    'search.date': 'Date',
    'search.route': 'Route Sector',
    'search.sort.departure': 'Earliest Departure',
    'search.sort.duration': 'Shortest Journey',
    'search.sort.fare': 'Lowest Fare',
    'search.filter.type': 'Train Type Filter',
    'search.filter.all': 'All Types',
    'search.seatsLeft': '{count} seats left',
    'search.seatSoldOut': 'Sold Out',
    'search.select': 'Select Train',
    'search.noResults': 'We could not find any train matches for your inputs. Please try searching another date or station combination.',
    'search.demoWarning': 'All data shown on this page is for demonstration purposes and is simulated.',
    'search.loading': 'Smart algorithm is mapping optimal train routes and checking seat matrices...',
    'search.bookNow': 'Proceed to Payment',
    'search.totalPrice': 'Total Fare',
    
    // Timetable Dedicated Page
    'timetable.title': 'Train Timetable Search',
    'timetable.subtitle': 'Train Timetable Search',
    'timetable.col.train': 'Train No / Class',
    'timetable.col.dep': 'Departure',
    'timetable.col.arr': 'Arrival',
    'timetable.col.dur': 'Duration',
    'timetable.col.status': 'Status',
    'timetable.col.action': 'Book',
    
    // Fares Calculator Page
    'fare.title': 'Fare Calculator',
    'fare.subtitle': 'Fare Calculator',
    'fare.passenger': 'Passenger Class',
    'fare.ticketType': 'Cabin Class',
    'fare.standard': 'Standard Cabin',
    'fare.business': 'Tengyun Premium (Business)',
    'fare.result.standard': 'Standard One-Way Fare',
    'fare.result.discounted': 'Discounted One-Way Fare',
    'fare.result.type': 'Fare categories: Half-fare applies to children under 12; Concession applies to seniors aged 65 and above.',
    'fare.result.disclaimer': '* The above calculation is for reference. Actual fares are determined at checkout in the ticketing system.',
    
    // E-Ticket Page
    'ticket.title': 'My E-Ticket',
    'ticket.subtitle': 'My Digital Ticket',
    'ticket.demoLabel': 'DEMONSTRATION TICKET / NOT FOR BOARDING',
    'ticket.passenger': 'Passenger',
    'ticket.train': 'Train No / Type',
    'ticket.date': 'Travel Date',
    'ticket.seat': 'Car / Seat',
    'ticket.ticketNo': 'Ticket No.',
    'ticket.wallet': 'Add to Apple Wallet',
    'ticket.download': 'Download PDF Receipt',
    'ticket.view': 'View Ticket',
    'ticket.scannedWarning': 'Align this QR Code with the turnstile sensor for seamless, contactless boarding.',
    'ticket.saved': 'Successfully saved to your digital passes!',
    
    // Member Dashboard
    'member.title': 'Smart Member Portal',
    'member.subtitle': 'Member Smart Dashboard',
    'member.no': 'Member Card ID',
    'member.level': 'Loyalty Tier',
    'member.points': 'Accumulated Points',
    'member.pointsLabel': 'pts',
    'member.upcoming': 'Upcoming Journeys',
    'member.past': 'Past Travel History',
    'member.savedStations': 'Frequent Stations',
    'member.settings': 'Smart Transit Controls',
    'member.tpass': 'TPASS 3.0 Program',
    'member.orders': 'My Orders',
    'member.tickets': 'Ticket Wallet',
    'member.name': 'Name',
    'member.email': 'Email Address',
    
    // Footer sections
    'footer.about': 'About TRA',
    'footer.corp': 'Corporate Profile',
    'footer.careers': 'Careers & Talent',
    'footer.news': 'Press Releases',
    'footer.contact': 'Contact Support',
    
    'footer.services': 'Passenger Services',
    'footer.booking': 'Book Online',
    'footer.schedule': 'Timetables',
    'footer.fareInfo': 'Fares Info',
    'footer.eticket': 'Digital E-Ticket',
    'footer.memberApp': 'Download App',
    
    'footer.travel': 'Rail Travel',
    'footer.explore': 'Explore Taiwan',
    'footer.destinations': 'Destinations',
    'footer.tourism': 'Scenic Railway Cruises',
    'footer.accessibility': 'Barrier-Free Travel',
    
    'footer.support': 'Support Help',
    'footer.help': 'Help Center (FAQ)',
    'footer.lost': 'Lost & Found',
    'footer.emergency': 'Emergency Alerts',
    'footer.status': 'Network Run Status',
    
    'footer.privacy': 'Privacy Policy',
    'footer.terms': 'Terms of Service',
    'footer.statement': 'Accessibility Statement',
    'footer.copyright': '© 2026 Taiwan Railway Corporation, Ltd. All Rights Reserved.',
    
    // General / UI state
    'ui.loading': 'Loading...',
    'ui.submit': 'Submit',
    'ui.cancel': 'Cancel',
    'ui.back': 'Back',
    'ui.alert.success': 'Success',
    'ui.all': 'All',
    'ui.noRecord': 'No historical logs found'
  }
};

export function getTranslation(lang: Language, key: string, params?: Record<string, string | number>): string {
  const dict = TRANSLATIONS[lang] || TRANSLATIONS.zh;
  let text = dict[key];
  if (!text) {
    // Fallback to English if not in Chinese, or vice versa
    const fallbackDict = lang === 'zh' ? TRANSLATIONS.en : TRANSLATIONS.zh;
    text = fallbackDict[key] || key;
  }
  
  if (params) {
    Object.entries(params).forEach(([k, v]) => {
      text = text.replace(`{${k}}`, String(v));
    });
  }
  
  return text;
}
