-- TAIWAN RAILWAY.OS PostgreSQL DDL Schema
-- 臺灣智慧鐵路作業系統資料庫結構

CREATE TABLE IF NOT EXISTS railways (
    railway_id VARCHAR(50) PRIMARY KEY,
    name_en VARCHAR(100) NOT NULL,
    name_zh_tw VARCHAR(100) NOT NULL,
    operator VARCHAR(100) DEFAULT 'Taiwan Railway Corporation',
    country_code VARCHAR(10) DEFAULT 'TW'
);

CREATE TABLE IF NOT EXISTS lines (
    line_id VARCHAR(50) PRIMARY KEY,
    railway_id VARCHAR(50) REFERENCES railways(railway_id),
    name_en VARCHAR(100) NOT NULL,
    name_zh_tw VARCHAR(100) NOT NULL,
    region VARCHAR(50) NOT NULL,
    gauge_mm INT DEFAULT 1067,
    electrified BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS stations (
    station_id VARCHAR(50) PRIMARY KEY,
    station_code VARCHAR(20) UNIQUE NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    name_zh_tw VARCHAR(100) NOT NULL,
    latitude NUMERIC(9,6) NOT NULL,
    longitude NUMERIC(9,6) NOT NULL,
    region VARCHAR(50) NOT NULL,
    station_type VARCHAR(30) NOT NULL,
    passenger_capacity INT DEFAULT 10000,
    operational_status VARCHAR(30) DEFAULT 'OPERATIONAL'
);

CREATE TABLE IF NOT EXISTS platforms (
    platform_id VARCHAR(50) PRIMARY KEY,
    station_id VARCHAR(50) REFERENCES stations(station_id),
    track_id VARCHAR(50) NOT NULL,
    length_meters NUMERIC(6,2) NOT NULL,
    direction VARCHAR(20) DEFAULT 'BIDIRECTIONAL',
    occupied BOOLEAN DEFAULT FALSE,
    maintenance_status VARCHAR(30) DEFAULT 'OK'
);

CREATE TABLE IF NOT EXISTS tracks (
    track_id VARCHAR(50) PRIMARY KEY,
    line_id VARCHAR(50) REFERENCES lines(line_id),
    track_type VARCHAR(30) DEFAULT 'MAINLINE'
);

CREATE TABLE IF NOT EXISTS track_sections (
    section_id VARCHAR(50) PRIMARY KEY,
    track_id VARCHAR(50) REFERENCES tracks(track_id),
    start_node VARCHAR(50) NOT NULL,
    end_node VARCHAR(50) NOT NULL,
    length_meters NUMERIC(8,2) NOT NULL,
    speed_limit_kmh NUMERIC(5,2) NOT NULL,
    gradient NUMERIC(4,2) DEFAULT 0.0,
    electrification BOOLEAN DEFAULT TRUE,
    occupancy_status VARCHAR(30) DEFAULT 'CLEAR'
);

CREATE TABLE IF NOT EXISTS signals (
    signal_id VARCHAR(50) PRIMARY KEY,
    section_id VARCHAR(50) REFERENCES track_sections(section_id),
    state VARCHAR(20) DEFAULT 'GREEN',
    mode VARCHAR(20) DEFAULT 'AUTOMATIC'
);

CREATE TABLE IF NOT EXISTS switches (
    switch_id VARCHAR(50) PRIMARY KEY,
    junction_id VARCHAR(50) NOT NULL,
    state VARCHAR(20) DEFAULT 'NORMAL',
    locked BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS bridges (
    bridge_id VARCHAR(50) PRIMARY KEY,
    section_id VARCHAR(50) REFERENCES track_sections(section_id),
    name_en VARCHAR(100),
    name_zh_tw VARCHAR(100),
    health_score NUMERIC(5,2) DEFAULT 100.0
);

CREATE TABLE IF NOT EXISTS tunnels (
    tunnel_id VARCHAR(50) PRIMARY KEY,
    section_id VARCHAR(50) REFERENCES track_sections(section_id),
    name_en VARCHAR(100),
    name_zh_tw VARCHAR(100),
    length_meters NUMERIC(8,2)
);

CREATE TABLE IF NOT EXISTS level_crossings (
    crossing_id VARCHAR(50) PRIMARY KEY,
    section_id VARCHAR(50) REFERENCES track_sections(section_id),
    location_description VARCHAR(200),
    barrier_status VARCHAR(20) DEFAULT 'OPEN'
);

CREATE TABLE IF NOT EXISTS trains (
    train_id VARCHAR(50) PRIMARY KEY,
    service_number VARCHAR(20) NOT NULL,
    train_type VARCHAR(30) NOT NULL,
    origin_station_id VARCHAR(50) REFERENCES stations(station_id),
    destination_station_id VARCHAR(50) REFERENCES stations(station_id),
    capacity INT DEFAULT 538,
    formation VARCHAR(50) DEFAULT 'EMU3000'
);

CREATE TABLE IF NOT EXISTS train_services (
    service_id VARCHAR(50) PRIMARY KEY,
    train_id VARCHAR(50) REFERENCES trains(train_id),
    scheduled_departure TIMESTAMP,
    scheduled_arrival TIMESTAMP,
    operational_status VARCHAR(30) DEFAULT 'SCHEDULED'
);

CREATE TABLE IF NOT EXISTS timetables (
    timetable_id VARCHAR(50) PRIMARY KEY,
    service_id VARCHAR(50) REFERENCES train_services(service_id),
    station_id VARCHAR(50) REFERENCES stations(station_id),
    scheduled_arrival TIMESTAMP,
    scheduled_departure TIMESTAMP,
    dwell_seconds INT DEFAULT 180
);

CREATE TABLE IF NOT EXISTS train_positions (
    telemetry_id BIGSERIAL PRIMARY KEY,
    train_id VARCHAR(50) REFERENCES trains(train_id),
    latitude NUMERIC(9,6) NOT NULL,
    longitude NUMERIC(9,6) NOT NULL,
    speed_kmh NUMERIC(5,2) NOT NULL,
    heading NUMERIC(5,2) NOT NULL,
    track_section_id VARCHAR(50),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS incidents (
    incident_id VARCHAR(50) PRIMARY KEY,
    incident_type VARCHAR(50) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    location_asset_id VARCHAR(50),
    description VARCHAR(500),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS maintenance_events (
    event_id VARCHAR(50) PRIMARY KEY,
    asset_id VARCHAR(50) NOT NULL,
    maintenance_type VARCHAR(50),
    scheduled_date DATE,
    status VARCHAR(30) DEFAULT 'PLANNED'
);

CREATE TABLE IF NOT EXISTS weather_events (
    event_id VARCHAR(50) PRIMARY KEY,
    region VARCHAR(50),
    typhoon_mode VARCHAR(30) DEFAULT 'NORMAL',
    rainfall_mm_hr NUMERIC(6,2),
    wind_speed_ms NUMERIC(5,2),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS passenger_flow (
    record_id BIGSERIAL PRIMARY KEY,
    station_id VARCHAR(50) REFERENCES stations(station_id),
    entries_per_min INT,
    exits_per_min INT,
    density_ratio NUMERIC(4,2),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS energy_records (
    record_id BIGSERIAL PRIMARY KEY,
    train_id VARCHAR(50) REFERENCES trains(train_id),
    kwh_consumed NUMERIC(8,2),
    kwh_regenerated NUMERIC(8,2),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS recommendations (
    recommendation_id VARCHAR(50) PRIMARY KEY,
    train_id VARCHAR(50),
    title_en VARCHAR(200),
    title_zh_tw VARCHAR(200),
    reason TEXT,
    confidence NUMERIC(4,2),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
    log_id BIGSERIAL PRIMARY KEY,
    user_id VARCHAR(50),
    user_role VARCHAR(50),
    action VARCHAR(100),
    details TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    role VARCHAR(50) NOT NULL,
    email VARCHAR(100)
);
