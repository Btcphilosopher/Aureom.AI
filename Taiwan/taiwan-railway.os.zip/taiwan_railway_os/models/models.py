from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class TrainType(str, Enum):
    LOCAL = "LOCAL"                 # 區間車
    EXPRESS = "EXPRESS"             # 快速列車
    INTERCITY = "INTERCITY"         # 城際列車
    LIMITED_EXPRESS = "LIMITED_EXPRESS" # 特別快車
    TOURIST = "TOURIST"             # 觀光列車
    SPECIAL = "SPECIAL"             # 臨時列車
    FREIGHT = "FREIGHT"             # 貨運列車

class TrainStatus(str, Enum):
    SCHEDULED = "SCHEDULED"         # 已排程
    PREPARING = "PREPARING"         # 準備中
    DEPARTING = "DEPARTING"         # 出發中
    RUNNING = "RUNNING"             # 行駛中
    APPROACHING = "APPROACHING"     # 進站中
    ARRIVING = "ARRIVING"           # 抵達中
    DWELLING = "DWELLING"           # 停站中
    DEPARTED = "DEPARTED"           # 已離站
    DELAYED = "DELAYED"             # 延誤
    DIVERTED = "DIVERTED"           # 改道
    CANCELLED = "CANCELLED"         # 取消
    OUT_OF_SERVICE = "OUT_OF_SERVICE" # 停止服務

class StationType(str, Enum):
    MAJOR = "MAJOR"                 # 主要車站
    INTERCITY = "INTERCITY"         # 城際車站
    REGIONAL = "REGIONAL"           # 區域車站
    LOCAL = "LOCAL"                 # 地方車站
    RURAL = "RURAL"                 # 鄉鎮車站
    JUNCTION = "JUNCTION"           # 轉乘／交會車站

class SignalState(str, Enum):
    RED = "RED"
    YELLOW = "YELLOW"
    GREEN = "GREEN"
    RESTRICTED = "RESTRICTED"
    FAULT = "FAULT"
    UNKNOWN = "UNKNOWN"

class SwitchState(str, Enum):
    NORMAL = "NORMAL"
    REVERSE = "REVERSE"
    MOVING = "MOVING"
    LOCKED = "LOCKED"
    FAULT = "FAULT"

class TrackOccupancyStatus(str, Enum):
    CLEAR = "CLEAR"
    OCCUPIED = "OCCUPIED"
    MAINTENANCE = "MAINTENANCE"
    BLOCKED = "BLOCKED"
    UNKNOWN = "UNKNOWN"

class TyphoonState(str, Enum):
    NORMAL = "NORMAL"
    WATCH = "WATCH"
    WARNING = "WARNING"
    RESTRICTED = "RESTRICTED"
    EMERGENCY = "EMERGENCY"

class UserRole(str, Enum):
    NETWORK_CONTROLLER = "NETWORK_CONTROLLER" # 網路控制人員
    STATION_OPERATOR = "STATION_OPERATOR"     # 車站操作員
    MAINTENANCE = "MAINTENANCE"               # 維護人員
    SAFETY = "SAFETY"                         # 安全管理
    PLANNER = "PLANNER"                       # 運輸規劃
    ANALYST = "ANALYST"                       # 分析人員
    VIEWER = "VIEWER"                         # 檢視者
    ADMIN = "ADMIN"                           # 管理員

class Station(BaseModel):
    station_id: str
    station_code: str
    name_en: str
    name_zh_tw: str
    latitude: float
    longitude: float
    region: str
    platforms: List[str]
    tracks: List[str]
    station_type: StationType
    passenger_capacity: int
    accessibility: bool = True
    parking: bool = True
    bike_facilities: bool = True
    ticketing: bool = True
    operational_status: str = "NORMAL"

class Platform(BaseModel):
    platform_id: str
    station_id: str
    track_id: str
    length: float
    direction: str
    occupied: bool = False
    reserved_train: Optional[str] = None
    boarding_status: str = "OPEN"
    passenger_density: float = 0.2
    accessibility: bool = True
    maintenance_status: str = "OK"

class TrackSection(BaseModel):
    section_id: str
    start_node: str
    end_node: str
    length_meters: float
    speed_limit_kmh: float
    gradient: float = 0.0
    electrification: bool = True
    track_type: str = "MAINLINE"
    occupancy: TrackOccupancyStatus = TrackOccupancyStatus.CLEAR
    direction: str = "BIDIRECTIONAL"
    status: str = "OPERATIONAL"
    maintenance_state: str = "GOOD"

class Signal(BaseModel):
    signal_id: str
    station_id: Optional[str] = None
    track_section_id: str
    state: SignalState = SignalState.GREEN
    mode: str = "AUTOMATIC"

class TrackSwitch(BaseModel):
    switch_id: str
    junction_id: str
    state: SwitchState = SwitchState.NORMAL
    locked: bool = True

class Train(BaseModel):
    train_id: str
    service_number: str
    train_type: TrainType
    origin: str
    destination: str
    current_location: Dict[str, float]  # {"latitude": ..., "longitude": ...}
    current_track: str
    speed: float  # km/h
    heading: float # degrees
    ETA: str
    ETD: str
    delay_minutes: float = 0.0
    passenger_load: float = 0.5  # % capacity
    formation: str = "EMU3000-12C"
    capacity: int = 538
    energy_consumption_kwh: float = 45.2
    operational_status: TrainStatus = TrainStatus.RUNNING

class DelayCascadeNode(BaseModel):
    train_id: str
    service_number: str
    original_delay: float
    cascaded_delay: float
    impacted_services: List[str]
    cause: str

class DisruptionScenario(BaseModel):
    id: str
    scenario_type: str
    affected_asset: str
    severity: str
    description_en: str
    description_zh_tw: str

class StrategyOption(BaseModel):
    id: str
    name_en: str
    name_zh_tw: str
    action_type: str # HOLD, SHORT_TURN, REROUTE, SKIP_STOP, RESCHEDULE
    delay_minutes: float
    passenger_impact: str
    train_conflicts: int
    platform_conflicts: int
    energy_cost_kwh: float
    network_recovery_minutes: float
    confidence_pct: float

class Recommendation(BaseModel):
    recommendation_id: str
    title_en: str
    title_zh_tw: str
    reason: str
    data_inputs: List[str]
    constraints: List[str]
    expected_effect: str
    confidence: float
    alternatives: List[StrategyOption]

class KPI(BaseModel):
    punctuality_pct: float = 94.7
    active_trains: int = 182
    delayed_trains: int = 14
    avg_delay_minutes: float = 3.2
    passenger_throughput_hourly: int = 45200
    track_utilization_pct: float = 81.5
    platform_utilization_pct: float = 76.2
    network_capacity_pct: float = 82.0
    energy_kwh_per_train_km: float = 18.4
    infrastructure_health_score: float = 94.0
    network_health_score: float = 94.0
