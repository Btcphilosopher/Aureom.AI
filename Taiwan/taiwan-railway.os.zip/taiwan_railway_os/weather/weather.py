from typing import Dict, Any, List
from taiwan_railway_os.models.models import TyphoonState

class RailWeatherEngine:
    def __init__(self):
        self.typhoon_state = TyphoonState.NORMAL
        self.rainfall_mm_hr = 12.0
        self.wind_speed_m_s = 8.5

    def set_typhoon_mode(self, mode: TyphoonState) -> Dict[str, Any]:
        self.typhoon_state = mode
        speed_limits = {
            TyphoonState.NORMAL: 130,
            TyphoonState.WATCH: 100,
            TyphoonState.WARNING: 70,
            TyphoonState.RESTRICTED: 30,
            TyphoonState.EMERGENCY: 0
        }
        limit = speed_limits[mode]
        return {
            "mode": mode.value,
            "system_speed_limit_kmh": limit,
            "actions_required": [
                f"Enforce max train speed {limit} km/h network-wide",
                "Activate bridge wind sensor monitoring",
                "Prepare emergency diesel locomotives at depots"
            ] if mode != TyphoonState.NORMAL else ["Normal Operations"]
        }

class FloodRiskEngine:
    def calculate_risk(self, rainfall_mm: float, water_level_m: float) -> Dict[str, Any]:
        risk_score = min(1.0, (rainfall_mm * 0.01) + (water_level_m * 0.15))
        affected_sections = ["SEC-004 (Xizhi)", "SEC-018 (Ruifang)"] if risk_score > 0.6 else []
        return {
            "flood_probability": round(risk_score, 2),
            "risk_score": round(risk_score * 100, 1),
            "affected_sections": affected_sections
        }

class LandslideRiskEngine:
    def calculate_risk(self, rainfall_mm: float, slope_deg: float) -> str:
        score = rainfall_mm * (slope_deg / 45.0)
        if score > 80:
            return "CRITICAL"
        elif score > 50:
            return "HIGH"
        elif score > 20:
            return "MEDIUM"
        return "LOW"
