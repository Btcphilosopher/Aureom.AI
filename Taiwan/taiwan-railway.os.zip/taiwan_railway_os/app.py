from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any
import asyncio
import json

from taiwan_railway_os.config.settings import settings
from taiwan_railway_os.network.graph import RailwayNetwork
from taiwan_railway_os.models.models import TyphoonState, UserRole
from taiwan_railway_os.operations.recovery import ServiceRecoveryEngine
from taiwan_railway_os.weather.weather import RailWeatherEngine, FloodRiskEngine, LandslideRiskEngine
from taiwan_railway_os.infrastructure.maintenance import MaintenanceEngine
from taiwan_railway_os.ai.decision_engine import RailDecisionEngine, RailwayCopilot

app = FastAPI(
    title=settings.APP_NAME,
    description=f"{settings.APP_NAME_ZH} - Railway Automation, Digital Twin & Network Optimisation Platform",
    version=settings.VERSION
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

network = RailwayNetwork()
recovery_engine = ServiceRecoveryEngine()
weather_engine = RailWeatherEngine()
flood_engine = FloodRiskEngine()
landslide_engine = LandslideRiskEngine()
maintenance_engine = MaintenanceEngine()
decision_engine = RailDecisionEngine()
copilot = RailwayCopilot()

@app.get("/")
def get_root():
    return {
        "system": settings.APP_NAME,
        "title_zh": settings.APP_NAME_ZH,
        "mode": "SIMULATION",
        "status": "OPERATIONAL",
        "safety_interlock": "ACTIVE_DETERMINISTIC"
    }

@app.get("/network")
def get_network():
    return {
        "node_count": len(network.stations),
        "edge_count": len(network.track_sections),
        "regions": ["Northern Taiwan", "Western Corridor", "Eastern Corridor", "Pingtung", "Southern Link", "Branch Lines"]
    }

@app.get("/stations")
def get_stations():
    return [s.model_dump() for s in network.stations.values()]

@app.get("/trains")
def get_trains():
    # Return active synthetic trains
    return [
        {
            "id": "TR-218",
            "service_number": "218",
            "type": "LIMITED_EXPRESS",
            "origin": "Taipei",
            "destination": "Hualien",
            "latitude": 24.1477,
            "longitude": 120.6736,
            "speed": 92.0,
            "delay_minutes": 7.0,
            "passenger_load": 0.84,
            "status": "RUNNING"
        },
        {
            "id": "TR-103",
            "service_number": "103",
            "type": "INTERCITY",
            "origin": "Keelung",
            "destination": "Kaohsiung",
            "latitude": 24.9892,
            "longitude": 121.3135,
            "speed": 110.0,
            "delay_minutes": 12.0,
            "passenger_load": 0.92,
            "status": "DELAYED"
        },
        {
            "id": "TR-431",
            "service_number": "431",
            "type": "LOCAL",
            "origin": "Hualien",
            "destination": "Taitung",
            "latitude": 23.9934,
            "longitude": 121.6012,
            "speed": 0.0,
            "delay_minutes": 0.0,
            "passenger_load": 0.45,
            "status": "DWELLING"
        }
    ]

@app.get("/tracks")
def get_tracks():
    return [sec.model_dump() for sec in network.track_sections.values()]

@app.get("/signals")
def get_signals():
    return [
        {"signal_id": "SIG-001", "track_section": "SEC-001", "state": "GREEN"},
        {"signal_id": "SIG-002", "track_section": "SEC-002", "state": "YELLOW"},
        {"signal_id": "SIG-003", "track_section": "SEC-003", "state": "RED"}
    ]

@app.get("/switches")
def get_switches():
    return [
        {"switch_id": "SW-101", "junction": "Taipei North", "state": "NORMAL", "locked": True},
        {"switch_id": "SW-102", "junction": "Changhua South", "state": "REVERSE", "locked": True}
    ]

@app.get("/platforms")
def get_platforms():
    return [
        {"platform_id": "TAIPEI-P1", "station": "Taipei", "occupied": True, "train": "TR-103"},
        {"platform_id": "TAIPEI-P2", "station": "Taipei", "occupied": False, "train": None},
        {"platform_id": "TAIPEI-P3", "station": "Taipei", "occupied": True, "train": "TR-218"}
    ]

@app.get("/operations")
def get_operations():
    return {
        "active_trains_count": 182,
        "delayed_trains_count": 14,
        "punctuality_pct": 94.7,
        "avg_delay_mins": 3.2,
        "safety_level": "OPTIMAL"
    }

@app.get("/weather")
def get_weather():
    return {
        "typhoon_mode": weather_engine.typhoon_state.value,
        "rainfall_mm_hr": weather_engine.rainfall_mm_hr,
        "wind_speed_ms": weather_engine.wind_speed_m_s,
        "flood_risk": flood_engine.calculate_risk(weather_engine.rainfall_mm_hr, 1.2),
        "landslide_risk": landslide_engine.calculate_risk(weather_engine.rainfall_mm_hr, 32.0)
    }

@app.get("/maintenance")
def get_maintenance():
    return maintenance_engine.evaluate_infrastructure_health()

@app.get("/recommendations")
def get_recommendations():
    rec = decision_engine.generate_recommendation({"train_id": "TR-218", "delay_minutes": 7.0})
    return [rec.model_dump()]

@app.post("/copilot/ask")
def ask_copilot(query: Dict[str, str]):
    q = query.get("question", "")
    return copilot.answer_query(q, {"health_score": 94.0, "delayed_trains_count": 14})

@app.websocket("/ws/network")
async def websocket_network(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            # Stream live updates
            telemetry = {
                "event_type": "TELEMETRY_UPDATE",
                "timestamp": asyncio.get_event_loop().time(),
                "active_trains": 182,
                "punctuality_pct": 94.7,
                "system_mode": "SIMULATION"
            }
            await websocket.send_text(json.dumps(telemetry))
            await asyncio.sleep(2)
    except WebSocketDisconnect:
        pass
