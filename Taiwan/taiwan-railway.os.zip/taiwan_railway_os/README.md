# TAIWAN RAILWAY.OS (臺灣智慧鐵路作業系統)
## Railway Automation, Digital Twin & Network Optimisation Platform

### 1. Architectural Overview
TAIWAN RAILWAY.OS is a bilingual (English / 繁體中文 zh-TW) computational railway operating platform providing real-time telemetry processing, Network Digital Twin graph modelling, AI-driven delay cascade forecasting, platform allocation optimization, and decision-support recommendations for the Taiwanese railway environment.

### 2. Safety Architecture
**Primary Functions:**
- Monitoring (監控)
- Simulation (模擬)
- Prediction (預測)
- Optimisation (最佳化)
- Decision Support (決策支援)

*Note:* All physical signalling, interlocking, braking, and train-control commands sit behind certified railway safety interlocks. The platform outputs structured operational recommendations rather than bypassing deterministic interlocks.

### 3. Kotlin Front-End Contract (REST & WebSocket API)
The visual Kotlin application connects to Python Rail Core via REST and WebSocket streaming:

- `GET /network`: Railway graph topology nodes & edges
- `GET /stations`: 241+ Station models with geocoordinates & capacity
- `GET /trains`: Live animated train positions with lat/lon, speed, heading, delay & occupancy
- `GET /weather`: Typhoon mode status, wind speed, rainfall & landslide risk score
- `GET /recommendations`: Explainable AI recommendations (Title, Reason, Constraints, Expected Effect, Confidence)
- `WS /ws/network`: Real-time JSON stream of train position updates, signal aspect changes, and occupancy events.

### 4. Running the Python Core
```bash
cd taiwan_railway_os
pip install -r requirements.txt
uvicorn taiwan_railway_os.app:app --reload --port 8000
```
