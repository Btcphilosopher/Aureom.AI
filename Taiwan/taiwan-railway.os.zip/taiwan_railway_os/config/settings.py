import os
from pydantic import BaseModel

class Settings(BaseModel):
    APP_NAME: str = "TAIWAN RAILWAY.OS"
    APP_NAME_ZH: str = "臺灣智慧鐵路作業系統"
    VERSION: str = "1.0.0"
    ENV: str = os.getenv("RAIL_ENV", "simulation")
    SIMULATION_TICK_SECONDS: float = 2.0
    DEFAULT_LOCALE: str = "zh-TW"
    
    # Network defaults
    TOTAL_STATIONS_SIMULATED: int = 241
    TOTAL_ACTIVE_TRAINS: int = 182
    
    # Safety Interlock
    SAFETY_INTERLOCK_AUTHORITATIVE: bool = True
    
settings = Settings()
