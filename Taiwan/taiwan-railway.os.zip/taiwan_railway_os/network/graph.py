import networkx as nx
from typing import Dict, List, Optional
from taiwan_railway_os.models.models import Station, TrackSection, StationType

class RailwayNetwork:
    def __init__(self):
        self.graph = nx.DiGraph()
        self.stations: Dict[str, Station] = {}
        self.track_sections: Dict[str, TrackSection] = {}
        self._build_taiwan_synthetic_network()

    def _build_taiwan_synthetic_network(self):
        # Key major & regional Taiwan Railway Stations
        raw_stations = [
            ("STA-1000", "KEELUNG", "Keelung", "基隆", 25.1317, 121.7402, "northern", StationType.MAJOR),
            ("STA-1010", "QIDU", "Qidu", "七堵", 25.0955, 121.7132, "northern", StationType.JUNCTION),
            ("STA-1020", "XIZHI", "Xizhi", "汐止", 25.0683, 121.6601, "northern", StationType.REGIONAL),
            ("STA-1000-N", "TAIPEI", "Taipei", "臺北", 25.0478, 121.5170, "western", StationType.MAJOR),
            ("STA-1030", "BANQIAO", "Banqiao", "板橋", 25.0142, 121.4638, "western", StationType.MAJOR),
            ("STA-1040", "TAOYUAN", "Taoyuan", "桃園", 24.9892, 121.3135, "western", StationType.MAJOR),
            ("STA-1050", "ZHONGLI", "Zhongli", "中壢", 24.9537, 121.2257, "western", StationType.MAJOR),
            ("STA-1060", "HSINCHU", "Hsinchu", "新竹", 24.8018, 120.9715, "western", StationType.MAJOR),
            ("STA-1070", "MIAOLI", "Miaoli", "苗栗", 24.5700, 120.8256, "western", StationType.REGIONAL),
            ("STA-1080", "TAICHUNG", "Taichung", "臺中", 24.1368, 120.6850, "western", StationType.MAJOR),
            ("STA-1090", "CHANGHUA", "Changhua", "彰化", 24.0816, 120.5383, "western", StationType.JUNCTION),
            ("STA-1100", "CHIAYI", "Chiayi", "嘉義", 23.4791, 120.4411, "western", StationType.MAJOR),
            ("STA-1110", "TAINAN", "Tainan", "臺南", 22.9972, 120.2127, "western", StationType.MAJOR),
            ("STA-1120", "KAOHSIUNG", "Kaohsiung", "高雄", 22.6397, 120.3023, "western", StationType.MAJOR),
            ("STA-1130", "PINGTUNG", "Pingtung", "屏東", 22.6692, 120.4862, "pingtung", StationType.MAJOR),
            ("STA-1140", "CHAOZHOU", "Chaozhou", "潮州", 22.5502, 120.5361, "pingtung", StationType.JUNCTION),
            ("STA-1150", "FANG LIAO", "Fangliao", "枋寮", 22.3662, 120.5947, "southern_link", StationType.JUNCTION),
            ("STA-1200", "YILAN", "Yilan", "宜蘭", 24.7545, 121.7582, "eastern", StationType.MAJOR),
            ("STA-1210", "LUODONG", "Luodong", "羅東", 24.6770, 121.7721, "eastern", StationType.INTERCITY),
            ("STA-1220", "SUAO", "Suao", "蘇澳", 24.5950, 121.8481, "eastern", StationType.REGIONAL),
            ("STA-1230", "HUALIEN", "Hualien", "花蓮", 23.9934, 121.6012, "eastern", StationType.MAJOR),
            ("STA-1240", "YULI", "Yuli", "玉里", 23.3364, 121.3121, "eastern", StationType.REGIONAL),
            ("STA-1250", "TAITUNG", "Taitung", "臺東", 22.7932, 121.1233, "eastern", StationType.MAJOR),
            # Branch lines
            ("STA-1300", "RUIFANG", "Ruifang", "瑞芳", 25.1089, 121.8058, "pingxi", StationType.JUNCTION),
            ("STA-1310", "PINGXI", "Pingxi", "平溪", 25.0256, 121.7388, "pingxi", StationType.RURAL),
            ("STA-1320", "NEIWAN", "Neiwan", "內灣", 24.7032, 121.1824, "neiwan", StationType.RURAL),
            ("STA-1330", "JIJI", "Jiji", "集集", 23.8268, 120.7845, "jiji", StationType.RURAL),
        ]

        for sid, code, en, zh, lat, lon, reg, stype in raw_stations:
            st = Station(
                station_id=sid,
                station_code=code,
                name_en=en,
                name_zh_tw=zh,
                latitude=lat,
                longitude=lon,
                region=reg,
                platforms=[f"{sid}-P1", f"{sid}-P2", f"{sid}-P3"],
                tracks=[f"{sid}-T1", f"{sid}-T2"],
                station_type=stype,
                passenger_capacity=15000 if stype == StationType.MAJOR else 5000
            )
            self.stations[sid] = st
            self.graph.add_node(sid, station=st)

        # Connect adjacent stations in graph
        keys = list(self.stations.keys())
        for i in range(len(keys) - 1):
            s1 = keys[i]
            s2 = keys[i+1]
            sec_id = f"SEC-{i+1:03d}"
            sec = TrackSection(
                section_id=sec_id,
                start_node=s1,
                end_node=s2,
                length_meters=12500.0,
                speed_limit_kmh=130.0,
            )
            self.track_sections[sec_id] = sec
            self.graph.add_edge(s1, s2, section=sec, weight=12.5)
            self.graph.add_edge(s2, s1, section=sec, weight=12.5)

    def get_shortest_path(self, origin_id: str, dest_id: str):
        try:
            return nx.shortest_path(self.graph, source=origin_id, target=dest_id)
        except Exception:
            return [origin_id, dest_id]
