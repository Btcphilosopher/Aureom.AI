from typing import List, Dict, Any

class MaintenanceEngine:
    def evaluate_infrastructure_health(self) -> List[Dict[str, Any]]:
        assets = [
            {
                "asset_id": "BRG-012",
                "type": "BRIDGE",
                "name_en": "Cengwen River Bridge",
                "name_zh_tw": "曾文溪橋",
                "health_score": 92.4,
                "failure_probability": 0.02,
                "remaining_useful_life_days": 1420,
                "maintenance_priority": "LOW",
                "telemetry": {"vibration_mm_s": 0.42, "temperature_c": 28.5}
            },
            {
                "asset_id": "TUN-008",
                "type": "TUNNEL",
                "name_en": "Caoling Tunnel",
                "name_zh_tw": "草嶺隧道",
                "health_score": 88.1,
                "failure_probability": 0.05,
                "remaining_useful_life_days": 850,
                "maintenance_priority": "MEDIUM",
                "telemetry": {"water_seepage_l_min": 1.2, "smoke_ppm": 0.0}
            },
            {
                "asset_id": "SW-104",
                "type": "SWITCH",
                "name_en": "Taipei North Junction Switch #4",
                "name_zh_tw": "臺北北端交會道岔 #4",
                "health_score": 78.5,
                "failure_probability": 0.14,
                "remaining_useful_life_days": 180,
                "maintenance_priority": "HIGH",
                "telemetry": {"motor_current_a": 14.8, "throw_time_s": 2.8}
            }
        ]
        return assets
