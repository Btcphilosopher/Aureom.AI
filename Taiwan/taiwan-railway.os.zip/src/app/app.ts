import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from './services/railway';
import { HeaderComponent } from './components/header/header';
import { KpiBarComponent } from './components/kpi-bar/kpi-bar';
import { DigitalTwinMapComponent } from './components/digital-twin-map/digital-twin-map';
import { TimetablePlatformsComponent } from './components/timetable-platforms/timetable-platforms';
import { DelayCascadeComponent } from './components/delay-cascade/delay-cascade';
import { RecoverySimulatorComponent } from './components/recovery-simulator/recovery-simulator';
import { EmergencyModesComponent } from './components/emergency-modes/emergency-modes';
import { MaintenancePanelComponent } from './components/maintenance-panel/maintenance-panel';
import { CopilotDrawerComponent } from './components/copilot-drawer/copilot-drawer';
import { TimeMachineComponent } from './components/time-machine/time-machine';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderComponent,
    KpiBarComponent,
    DigitalTwinMapComponent,
    TimetablePlatformsComponent,
    DelayCascadeComponent,
    RecoverySimulatorComponent,
    EmergencyModesComponent,
    MaintenancePanelComponent,
    CopilotDrawerComponent,
    TimeMachineComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-mono selection:bg-cyan-500 selection:text-slate-950">
      <!-- Top Control Bar -->
      <app-header />

      <!-- KPI Metrics Strip -->
      <app-kpi-bar />

      <!-- Active View Viewport -->
      <main class="flex-1 flex flex-col overflow-hidden">
        <ng-container [ngSwitch]="service.activeTab()">
          <app-digital-twin-map *ngSwitchCase="'twin'" />
          <app-timetable-platforms *ngSwitchCase="'timetable'" />
          <app-delay-cascade *ngSwitchCase="'cascade'" />
          <app-recovery-simulator *ngSwitchCase="'recovery'" />
          <app-emergency-modes *ngSwitchCase="'modes'" />
          <app-maintenance-panel *ngSwitchCase="'maintenance'" />
          <app-copilot-drawer *ngSwitchCase="'copilot'" />
          <app-time-machine *ngSwitchCase="'timemachine'" />
          <app-digital-twin-map *ngSwitchDefault />
        </ng-container>
      </main>

      <!-- Bottom Status Bar -->
      <footer class="bg-slate-950 border-t border-slate-800/80 px-4 py-1.5 flex justify-between items-center text-[10px] text-slate-500 font-mono">
        <div class="flex items-center gap-3">
          <span>TAIWAN RAILWAY.OS v2.4.0</span>
          <span>•</span>
          <span class="text-cyan-400">ROLE: {{ service.role() }}</span>
          <span>•</span>
          <span class="text-emerald-400">LOCALE: {{ service.locale() }}</span>
        </div>
        <div class="flex items-center gap-3">
          <span>INTERLOCK: ACTIVE (SAFETY CERTIFIED)</span>
          <span>•</span>
          <span>WEBSOCKET STREAM: 100% ONLINE</span>
        </div>
      </footer>
    </div>
  `
})
export class App {
  service = inject(RailwayService);
}
