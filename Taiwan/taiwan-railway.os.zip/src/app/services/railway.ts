import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export type Locale = 'zh-TW' | 'en';

export interface TrainData {
  id: string;
  service_number: string;
  train_type: string;
  origin: string;
  destination: string;
  latitude: number;
  longitude: number;
  speed: number;
  heading: number;
  track_section: string;
  delay_minutes: number;
  passenger_load: number;
  status: string;
  region: string;
  energy_kwh: number;
}

export interface StationData {
  station_id: string;
  code: string;
  name_en: string;
  name_zh_tw: string;
  latitude: number;
  longitude: number;
  region: string;
  type: string;
  platforms: string[];
  passenger_capacity: number;
}

export interface MaintenanceData {
  id: string;
  asset_type: string;
  name_en: string;
  name_zh_tw: string;
  health_score: number;
  remaining_days: number;
  priority: string;
  telemetry: string;
}

export interface RecommendationData {
  id: string;
  title_en: string;
  title_zh_tw: string;
  reason: string;
  data_inputs: string[];
  constraints: string[];
  expected_effect: string;
  confidence: number;
  alternatives: any[];
}

@Injectable({ providedIn: 'root' })
export class RailwayService {
  private http = inject(HttpClient);

  // Core Reactive Signals
  locale = signal<Locale>('zh-TW');
  role = signal<string>('NETWORK_CONTROLLER');
  activeTab = signal<string>('twin');
  selectedTrainId = signal<string | null>('TR-218');
  selectedStationId = signal<string | null>('STA-1200');

  // Network State
  punctualityRate = signal<number>(94.7);
  healthScore = signal<number>(94.0);
  networkCapacityPct = signal<number>(81.5);
  typhoonMode = signal<string>('NORMAL');
  earthquakeAlert = signal<boolean>(false);

  // Map Layers Toggles
  layers = signal({
    network: true,
    trains: true,
    stations: true,
    tracks: true,
    signals: true,
    switches: true,
    passengers: false,
    weather: false,
    risk: false,
    maintenance: false,
    energy: false
  });

  // Collections
  trains = signal<TrainData[]>([]);
  stations = signal<StationData[]>([]);
  maintenanceAssets = signal<MaintenanceData[]>([]);
  recommendations = signal<RecommendationData[]>([]);

  // Selected Train Object
  selectedTrain = computed(() => {
    const id = this.selectedTrainId();
    return this.trains().find(t => t.id === id) || this.trains()[0] || null;
  });

  constructor() {
    this.refreshAll();
    // Live polling simulation update every 3s
    if (typeof window !== 'undefined') {
      setInterval(() => {
        this.fetchTrains();
        this.fetchNetworkKpis();
      }, 3000);
    }
  }

  async refreshAll() {
    await Promise.all([
      this.fetchNetworkKpis(),
      this.fetchStations(),
      this.fetchTrains(),
      this.fetchMaintenance(),
      this.fetchRecommendations()
    ]);
  }

  async fetchNetworkKpis() {
    try {
      const data: any = await firstValueFrom(this.http.get('/api/network'));
      if (data && data.kpis) {
        this.punctualityRate.set(data.kpis.punctuality_pct);
        this.healthScore.set(data.kpis.health_score);
        this.networkCapacityPct.set(data.kpis.network_capacity_pct);
        this.typhoonMode.set(data.kpis.typhoon_mode);
        this.earthquakeAlert.set(data.kpis.earthquake_alert);
      }
    } catch (e) {
      console.error(e);
    }
  }

  async fetchStations() {
    try {
      const list: any = await firstValueFrom(this.http.get('/api/stations'));
      this.stations.set(list || []);
    } catch (e) {
      console.error(e);
    }
  }

  async fetchTrains() {
    try {
      const list: any = await firstValueFrom(this.http.get('/api/trains'));
      this.trains.set(list || []);
    } catch (e) {
      console.error(e);
    }
  }

  async fetchMaintenance() {
    try {
      const list: any = await firstValueFrom(this.http.get('/api/maintenance'));
      this.maintenanceAssets.set(list || []);
    } catch (e) {
      console.error(e);
    }
  }

  async fetchRecommendations() {
    try {
      const list: any = await firstValueFrom(this.http.get('/api/recommendations'));
      this.recommendations.set(list || []);
    } catch (e) {
      console.error(e);
    }
  }

  toggleLayer(layerKey: keyof ReturnType<typeof this.layers>) {
    this.layers.update(prev => ({
      ...prev,
      [layerKey]: !prev[layerKey]
    }));
  }

  async setTyphoonMode(mode: string) {
    this.typhoonMode.set(mode);
    await firstValueFrom(this.http.post('/api/mode/typhoon', { mode }));
    this.fetchNetworkKpis();
  }

  async setEarthquakeAlert(active: boolean) {
    this.earthquakeAlert.set(active);
    await firstValueFrom(this.http.post('/api/mode/earthquake', { active }));
    this.fetchNetworkKpis();
  }

  async askCopilot(question: string): Promise<string> {
    try {
      const res: any = await firstValueFrom(this.http.post('/api/copilot/ask', {
        question,
        locale: this.locale()
      }));
      return res.answer || 'No response returned';
    } catch (e) {
      return this.locale() === 'zh-TW'
        ? '系統分析失敗，請檢查 API 連線。'
        : 'System analysis failed. Check API connection.';
    }
  }
}
