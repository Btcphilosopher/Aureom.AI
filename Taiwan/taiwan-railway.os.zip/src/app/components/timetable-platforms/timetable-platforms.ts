import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

@Component({
  selector: 'app-timetable-platforms',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#0a0b0d] min-h-[calc(100vh-140px)] text-zinc-300 font-mono space-y-6">
      <!-- Section Header -->
      <div class="flex items-center justify-between border-b border-zinc-800/80 pb-4">
        <div>
          <h2 class="text-lg font-bold text-orange-400 flex items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-orange-500 animate-pulse"></span>
            {{ service.locale() === 'zh-TW' ? '列車時刻表與月台分配最佳化引擎' : 'Timetable & Platform Allocation Optimiser' }}
          </h2>
          <p class="text-xs text-zinc-400 mt-1">
            {{ service.locale() === 'zh-TW' ? '智慧排程、月台交會衝突檢測與車次停靠時間管理' : 'AI-driven conflict resolution, platform allocation & headway management' }}
          </p>
        </div>
        <button class="bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 text-orange-400 text-xs px-3.5 py-2 rounded-lg font-semibold transition-all shadow-sm">
          ⚡ {{ service.locale() === 'zh-TW' ? '重新計算最佳化月台分配' : 'Re-optimize Platforms' }}
        </button>
      </div>

      <!-- Platform Conflict Matrix Summary -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '月台使用率 (Taipei Main)' : 'Taipei Platform Utilisation' }}</span>
          <span class="text-2xl font-bold text-orange-400 font-mono mt-1 block">82.4%</span>
          <span class="text-xs text-zinc-500 block mt-1">4 Mainline Platforms Active</span>
        </div>

        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '交會點潛在衝突' : 'Junction Conflicts Detected' }}</span>
          <span class="text-2xl font-bold text-amber-400 font-mono mt-1 block">1 Potential</span>
          <span class="text-xs text-zinc-500 block mt-1">Taipei North Junction #4</span>
        </div>

        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '最小發車班距安全保護' : 'Minimum Safety Headway' }}</span>
          <span class="text-2xl font-bold text-emerald-400 font-mono mt-1 block">180s PASS</span>
          <span class="text-xs text-zinc-500 block mt-1">Interlocked deterministic safety</span>
        </div>
      </div>

      <!-- Station Platform Allocation Grid -->
      <div class="bg-[#12151a] border border-zinc-800 rounded-xl p-5 shadow-sm">
        <h3 class="text-sm font-bold text-zinc-200 mb-4 border-b border-zinc-800/80 pb-2.5 flex items-center justify-between">
          <span>{{ service.locale() === 'zh-TW' ? '車站月台即時佔用狀態' : 'Live Platform Occupation Matrix' }}</span>
          <span class="text-xs text-zinc-500 font-normal">Updated Live</span>
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div *ngFor="let plat of platformsList" class="bg-[#0a0b0d] border border-zinc-800/80 p-3.5 rounded-lg space-y-2.5">
            <div class="flex justify-between items-center">
              <span class="text-xs font-bold text-orange-300">{{ plat.station }} - {{ plat.platform }}</span>
              <span [class]="plat.occupied ? 'px-2 py-0.5 text-[10px] rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-semibold' : 'px-2 py-0.5 text-[10px] rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-semibold'">
                {{ plat.occupied ? (service.locale() === 'zh-TW' ? '月台佔用中' : 'OCCUPIED') : (service.locale() === 'zh-TW' ? '空閒' : 'AVAILABLE') }}
              </span>
            </div>
            
            <div class="text-xs text-zinc-400 space-y-1 pt-1 border-t border-zinc-800/50">
              <div class="flex justify-between">
                <span class="text-zinc-500">{{ service.locale() === 'zh-TW' ? '預定停靠列車' : 'Assigned Train' }}:</span>
                <span class="text-zinc-200 font-bold">{{ plat.train || 'None' }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-zinc-500">{{ service.locale() === 'zh-TW' ? '停留時間' : 'Dwell Time' }}:</span>
                <span class="text-zinc-300 font-mono">180s</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TimetablePlatformsComponent {
  service = inject(RailwayService);

  platformsList = [
    { station: '臺北 (Taipei)', platform: '月台 1 (P1)', occupied: true, train: 'TR-103 (自強號)' },
    { station: '臺北 (Taipei)', platform: '月台 2 (P2)', occupied: false, train: null },
    { station: '臺北 (Taipei)', platform: '月台 3 (P3)', occupied: true, train: 'TR-218 (太魯閣號)' },
    { station: '臺北 (Taipei)', platform: '月台 4 (P4)', occupied: false, train: null },
    { station: '花蓮 (Hualien)', platform: '月台 1 (P1)', occupied: true, train: 'TR-431 (區間車)' },
    { station: '花蓮 (Hualien)', platform: '月台 2 (P2)', occupied: false, train: null },
    { station: '高雄 (Kaohsiung)', platform: '月台 1 (P1)', occupied: false, train: null },
    { station: '高雄 (Kaohsiung)', platform: '月台 2 (P2)', occupied: true, train: 'TR-115 (莒光號)' },
  ];
}
