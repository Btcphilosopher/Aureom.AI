import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

@Component({
  selector: 'app-emergency-modes',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#0a0b0d] min-h-[calc(100vh-140px)] text-zinc-300 font-mono space-y-6">
      <div class="border-b border-zinc-800/80 pb-4">
        <h2 class="text-lg font-bold text-amber-400 flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
          {{ service.locale() === 'zh-TW' ? '極端天候與天然災害緊急應變模式' : 'Typhoon & Earthquake Emergency Response Simulator' }}
        </h2>
        <p class="text-xs text-zinc-400 mt-1">
          {{ service.locale() === 'zh-TW' ? '管理颱風警戒（戒備／警戒／速限／全面停駛）與強震感測自動緊急煞車通報' : 'Simulate typhoon speed limits, bridge wind thresholds, rainfall flood risk & seismic shock response' }}
        </p>
      </div>

      <!-- Typhoon Mode Controls -->
      <div class="bg-[#12151a] border border-zinc-800 p-5 rounded-xl space-y-4 shadow-sm">
        <div class="flex items-center justify-between border-b border-zinc-800/80 pb-3">
          <div>
            <h3 class="text-sm font-bold text-amber-400 flex items-center gap-2">
              🌀 {{ service.locale() === 'zh-TW' ? '防颱應變應變階層' : 'Typhoon Speed Restriction Level' }}
            </h3>
            <span class="text-xs text-zinc-400 mt-0.5 block">
              {{ service.locale() === 'zh-TW' ? '目前狀態' : 'Current Mode' }}: <strong class="text-orange-400 font-mono">{{ service.typhoonMode() }}</strong>
            </span>
          </div>
          <span class="text-xs text-zinc-400 bg-[#0a0b0d] px-3 py-1.5 rounded-lg border border-zinc-800 font-mono">
            Rainfall: 12.0 mm/hr | Wind Speed: 8.5 m/s
          </span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
          <button (click)="service.setTyphoonMode('NORMAL')" [class]="service.typhoonMode() === 'NORMAL' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 font-bold p-3 rounded-xl text-xs transition-all' : 'bg-[#0a0b0d] hover:bg-zinc-800/60 text-zinc-300 p-3 rounded-xl border border-zinc-800 text-xs transition-all'">
            NORMAL (130 km/h)
          </button>
          <button (click)="service.setTyphoonMode('WATCH')" [class]="service.typhoonMode() === 'WATCH' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 font-bold p-3 rounded-xl text-xs transition-all' : 'bg-[#0a0b0d] hover:bg-zinc-800/60 text-zinc-300 p-3 rounded-xl border border-zinc-800 text-xs transition-all'">
            WATCH (100 km/h)
          </button>
          <button (click)="service.setTyphoonMode('WARNING')" [class]="service.typhoonMode() === 'WARNING' ? 'bg-orange-500/20 text-orange-300 border border-orange-500/50 font-bold p-3 rounded-xl text-xs transition-all' : 'bg-[#0a0b0d] hover:bg-zinc-800/60 text-zinc-300 p-3 rounded-xl border border-zinc-800 text-xs transition-all'">
            WARNING (70 km/h)
          </button>
          <button (click)="service.setTyphoonMode('RESTRICTED')" [class]="service.typhoonMode() === 'RESTRICTED' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/50 font-bold p-3 rounded-xl text-xs transition-all' : 'bg-[#0a0b0d] hover:bg-zinc-800/60 text-zinc-300 p-3 rounded-xl border border-zinc-800 text-xs transition-all'">
            RESTRICTED (30 km/h)
          </button>
          <button (click)="service.setTyphoonMode('EMERGENCY')" [class]="service.typhoonMode() === 'EMERGENCY' ? 'bg-rose-600 text-white font-bold p-3 rounded-xl text-xs animate-pulse transition-all shadow-lg shadow-rose-950' : 'bg-[#0a0b0d] hover:bg-zinc-800/60 text-zinc-300 p-3 rounded-xl border border-zinc-800 text-xs transition-all'">
            EMERGENCY (0 km/h)
          </button>
        </div>
      </div>

      <!-- Earthquake Simulation Control -->
      <div class="bg-[#12151a] border border-zinc-800 p-5 rounded-xl space-y-4 shadow-sm">
        <div class="flex items-center justify-between border-b border-zinc-800/80 pb-3">
          <div>
            <h3 class="text-sm font-bold text-rose-400 flex items-center gap-2">
              ⚡ {{ service.locale() === 'zh-TW' ? '地震即時警報與自動安全停車' : 'Seismic Alert & Automatic Train Protection (ATP)' }}
            </h3>
            <span class="text-xs text-zinc-400 mt-0.5 block">
              {{ service.locale() === 'zh-TW' ? '當強震儀感測震度達 4 級以上時，自動向全網列車發送緊急煞車訊號' : 'Triggers automatic emergency brake broadcast when P-wave seismic threshold exceeded' }}
            </span>
          </div>

          <button (click)="service.setEarthquakeAlert(!service.earthquakeAlert())" [class]="service.earthquakeAlert() ? 'bg-rose-600 text-white font-bold px-4 py-2.5 rounded-lg text-xs animate-bounce shadow-lg shadow-rose-950' : 'bg-zinc-800/80 hover:bg-zinc-800 border border-zinc-700/50 text-zinc-200 px-4 py-2.5 rounded-lg text-xs font-semibold transition-all'">
            {{ service.earthquakeAlert() ? (service.locale() === 'zh-TW' ? '解除地震緊急警戒' : 'Reset Earthquake Alert') : (service.locale() === 'zh-TW' ? '觸發 5 級強震模擬' : 'Simulate Magnitude 5.8 Earthquake') }}
          </button>
        </div>

        @if (service.earthquakeAlert()) {
          <div class="bg-rose-950/40 border border-rose-500/40 p-4 rounded-xl text-xs text-rose-200 space-y-2">
            <div class="font-bold text-sm text-rose-400 flex items-center gap-2">
              <span>⚠️</span>
              <span>EMERGENCY SEISMIC BRAKE BROADCAST ACTIVE</span>
            </div>
            <div>• All active mainline trains automatically instructed to perform Emergency Brake (EB).</div>
            <div>• Cengwen River Bridge & Caoling Tunnel health monitoring sensor streams switched to high-frequency sampling (100 Hz).</div>
            <div>• Track inspection teams dispatched for visual inspection before resuming power.</div>
          </div>
        }
      </div>
    </div>
  `
})
export class EmergencyModesComponent {
  service = inject(RailwayService);
}
