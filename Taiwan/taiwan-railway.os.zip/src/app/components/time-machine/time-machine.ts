import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

@Component({
  selector: 'app-time-machine',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#0a0b0d] min-h-[calc(100vh-140px)] text-zinc-300 font-mono space-y-6">
      <div class="border-b border-zinc-800/80 pb-4">
        <h2 class="text-lg font-bold text-orange-400 flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-orange-500 animate-pulse"></span>
          ⏪ {{ service.locale() === 'zh-TW' ? '鐵路網時光機與歷史事件重播' : 'Network Time Machine & Historical Replay' }}
        </h2>
        <p class="text-xs text-zinc-400 mt-1">
          {{ service.locale() === 'zh-TW' ? '支援全網狀態快照儲存、逐格分析、快速前進／倒帶與歷史事故重演' : 'Frame-by-frame replay of historical telemetry, train positions, signal aspects & dispatching decisions' }}
        </p>
      </div>

      <!-- Playback Controls Bar -->
      <div class="bg-[#12151a] border border-zinc-800 p-5 rounded-xl space-y-4 shadow-sm">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div class="flex items-center gap-3">
            <button (click)="isPlaying.set(!isPlaying())" class="bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/40 text-orange-300 font-bold px-4 py-2.5 rounded-lg text-xs transition-all shadow-sm">
              {{ isPlaying() ? '⏸ PAUSE' : '▶ PLAY REPLAY' }}
            </button>
            <button (click)="sliderVal.set(0)" class="bg-[#0a0b0d] hover:bg-zinc-800 text-zinc-300 border border-zinc-800 px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-all">
              ⏮ RESET (08:00)
            </button>
          </div>

          <div class="text-sm font-bold text-amber-400 font-mono bg-[#0a0b0d] px-3.5 py-1.5 rounded-lg border border-zinc-800">
            REPLAY TIME: {{ formatTime(sliderVal()) }}
          </div>
        </div>

        <!-- Replay Timeline Slider -->
        <div class="space-y-2 pt-2">
          <input
            type="range"
            min="0"
            max="180"
            [value]="sliderVal()"
            (input)="sliderVal.set(+$any($event.target).value)"
            class="w-full h-2 bg-[#0a0b0d] rounded-lg appearance-none cursor-pointer accent-orange-500 border border-zinc-800"
          />
          <div class="flex justify-between text-[11px] text-zinc-500 font-mono">
            <span>08:00:00 (Start)</span>
            <span>09:00:00</span>
            <span>10:00:00</span>
            <span>11:00:00 (End)</span>
          </div>
        </div>
      </div>

      <!-- Replay Frame Telemetry Summary -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '快照狀態' : 'Replay Snapshot' }}</span>
          <span class="text-lg font-bold text-zinc-200 mt-1 block">Frame #{{ sliderVal() }} / 180</span>
          <span class="text-xs text-zinc-500 block mt-1">Telemetry synced at 1Hz</span>
        </div>

        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '當時全網準點率' : 'Replay Punctuality' }}</span>
          <span class="text-lg font-bold text-emerald-400 mt-1 block">95.2%</span>
          <span class="text-xs text-zinc-500 block mt-1">Normal operational baseline</span>
        </div>

        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '歷史發送行控指令' : 'Dispatched Decision' }}</span>
          <span class="text-lg font-bold text-orange-400 mt-1 block">TR-218 Dwell +3m</span>
          <span class="text-xs text-zinc-500 block mt-1">Recorded in system audit log</span>
        </div>
      </div>
    </div>
  `
})
export class TimeMachineComponent {
  service = inject(RailwayService);

  sliderVal = signal<number>(45);
  isPlaying = signal<boolean>(false);

  formatTime(val: number) {
    const totalMin = 8 * 60 + val;
    const hrs = Math.floor(totalMin / 60);
    const mins = totalMin % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:00`;
  }
}
