import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService, TrainData, StationData } from '../../services/railway';

@Component({
  selector: 'app-digital-twin-map',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex-1 flex flex-col md:flex-row h-[calc(100vh-140px)] bg-[#0a0b0d] text-zinc-300 font-mono relative overflow-hidden">
      
      <!-- Layer Toggles Bar (Left Floating) -->
      <div class="w-full md:w-56 bg-[#0c0e12]/95 border-r border-zinc-800/80 p-3 flex flex-col gap-3 overflow-y-auto z-10 backdrop-blur-sm">
        <div class="flex items-center justify-between border-b border-zinc-800/80 pb-2">
          <span class="text-xs font-bold text-orange-400 uppercase tracking-wider flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
            {{ service.locale() === 'zh-TW' ? '圖層控制' : 'Map Layers' }}
          </span>
          <span class="text-[10px] text-zinc-500 font-semibold">11 Active</span>
        </div>

        <div class="space-y-1 text-xs">
          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">🌐 {{ service.locale() === 'zh-TW' ? '鐵路網' : 'Network Graph' }}</span>
            <input type="checkbox" [checked]="service.layers().network" (change)="service.toggleLayer('network')" class="accent-orange-500">
          </label>

          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">🚆 {{ service.locale() === 'zh-TW' ? '動態列車' : 'Trains' }}</span>
            <input type="checkbox" [checked]="service.layers().trains" (change)="service.toggleLayer('trains')" class="accent-orange-500">
          </label>

          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">🚉 {{ service.locale() === 'zh-TW' ? '車站／月台' : 'Stations & Platforms' }}</span>
            <input type="checkbox" [checked]="service.layers().stations" (change)="service.toggleLayer('stations')" class="accent-orange-500">
          </label>

          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">🛤️ {{ service.locale() === 'zh-TW' ? '軌道區段' : 'Tracks' }}</span>
            <input type="checkbox" [checked]="service.layers().tracks" (change)="service.toggleLayer('tracks')" class="accent-orange-500">
          </label>

          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">🚦 {{ service.locale() === 'zh-TW' ? '號誌系統' : 'Signals' }}</span>
            <input type="checkbox" [checked]="service.layers().signals" (change)="service.toggleLayer('signals')" class="accent-orange-500">
          </label>

          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">🔀 {{ service.locale() === 'zh-TW' ? '道岔狀態' : 'Switches' }}</span>
            <input type="checkbox" [checked]="service.layers().switches" (change)="service.toggleLayer('switches')" class="accent-orange-500">
          </label>

          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">👥 {{ service.locale() === 'zh-TW' ? '旅客流量' : 'Passenger Flow' }}</span>
            <input type="checkbox" [checked]="service.layers().passengers" (change)="service.toggleLayer('passengers')" class="accent-orange-500">
          </label>

          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">🌧️ {{ service.locale() === 'zh-TW' ? '氣象／颱風' : 'Weather' }}</span>
            <input type="checkbox" [checked]="service.layers().weather" (change)="service.toggleLayer('weather')" class="accent-orange-500">
          </label>

          <label class="flex items-center justify-between p-1.5 rounded-md hover:bg-zinc-800/50 cursor-pointer transition-colors">
            <span class="text-zinc-300">⚡ {{ service.locale() === 'zh-TW' ? '牽引能源' : 'Traction Energy' }}</span>
            <input type="checkbox" [checked]="service.layers().energy" (change)="service.toggleLayer('energy')" class="accent-orange-500">
          </label>
        </div>

        <!-- System Status Summary Card -->
        <div class="mt-auto bg-[#12151a] border border-zinc-800 p-2.5 rounded-lg text-[11px] space-y-1.5 shadow-inner">
          <div class="text-amber-400 font-bold uppercase tracking-wider border-b border-zinc-800 pb-1 flex items-center justify-between">
            <span>{{ service.locale() === 'zh-TW' ? '行控中心即時資訊' : 'Control Telemetry' }}</span>
            <span class="text-[9px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-1 py-0.5 rounded">ONLINE</span>
          </div>
          <div class="flex justify-between text-zinc-400">
            <span>{{ service.locale() === 'zh-TW' ? '遙測事件頻率' : 'Event Stream' }}:</span>
            <span class="text-zinc-200 font-semibold">2,400 ev/s</span>
          </div>
          <div class="flex justify-between text-zinc-400">
            <span>{{ service.locale() === 'zh-TW' ? '延誤連鎖' : 'Cascade Risk' }}:</span>
            <span class="text-amber-400 font-bold">MODERATE</span>
          </div>
        </div>
      </div>

      <!-- Main Canvas Map Area -->
      <div class="flex-1 relative bg-[#0a0b0d] flex items-center justify-center p-4">
        
        <!-- Grid Background Pattern -->
        <div class="absolute inset-0 bg-[linear-gradient(to_right,#1c212b_1px,transparent_1px),linear-gradient(to_bottom,#1c212b_1px,transparent_1px)] bg-[size:32px_32px] opacity-30 pointer-events-none"></div>

        <!-- Taiwan Railway Map SVG Representation -->
        <svg class="w-full h-full max-w-4xl max-h-[700px] z-0" viewBox="0 0 900 700">
          <!-- Background Region Labels -->
          <text x="250" y="80" fill="#3f3f46" font-size="14" font-weight="bold" font-family="monospace">NORTHERN TAIWAN 北臺灣</text>
          <text x="180" y="320" fill="#3f3f46" font-size="14" font-weight="bold" font-family="monospace">WESTERN CORRIDOR 西部幹線</text>
          <text x="620" y="320" fill="#3f3f46" font-size="14" font-weight="bold" font-family="monospace">EASTERN CORRIDOR 東部幹線</text>
          <text x="350" y="650" fill="#3f3f46" font-size="14" font-weight="bold" font-family="monospace">PINGTUNG & SOUTHERN LINK 屏東／南迴線</text>

          <!-- Track Section Lines -->
          @if (service.layers().network || service.layers().tracks) {
            <!-- Western Line Track -->
            <path d="M 320,100 L 280,180 L 260,260 L 240,360 L 230,460 L 250,560" stroke="#0ea5e9" stroke-width="4" fill="none" opacity="0.7"/>
            <!-- Eastern Line Track -->
            <path d="M 320,100 L 520,160 L 580,280 L 560,420 L 500,560 L 250,560" stroke="#10b981" stroke-width="4" fill="none" opacity="0.7"/>
            <!-- Branch Line: Pingxi -->
            <path d="M 320,100 L 420,80 L 460,110" stroke="#f59e0b" stroke-width="2.5" stroke-dasharray="4,4" fill="none"/>
          }

          <!-- Signals Rendering -->
          @if (service.layers().signals) {
            <circle cx="300" cy="140" r="5" fill="#10b981" />
            <circle cx="270" cy="220" r="5" fill="#f59e0b" />
            <circle cx="550" cy="220" r="5" fill="#ef4444" />
          }

          <!-- Stations Nodes -->
          @if (service.layers().stations) {
            <g *ngFor="let station of stationsMap">
              <circle
                [attr.cx]="station.x"
                [attr.cy]="station.y"
                r="7"
                [attr.fill]="service.selectedStationId() === station.id ? '#f97316' : '#18181b'"
                stroke="#f97316"
                stroke-width="2"
                class="cursor-pointer hover:r-9 transition-all"
                (click)="service.selectedStationId.set(station.id)"
              />
              <text [attr.x]="station.x + 12" [attr.y]="station.y + 4" fill="#a1a1aa" font-size="11" font-family="monospace">
                {{ service.locale() === 'zh-TW' ? station.zh : station.en }}
              </text>
            </g>
          }

          <!-- Dynamic Trains Rendering -->
          @if (service.layers().trains) {
            <g *ngFor="let train of trainsMapped">
              <!-- Animated Glow Ring for Selected or Delayed Train -->
              <circle
                [attr.cx]="train.x"
                [attr.cy]="train.y"
                [attr.r]="train.delay > 0 ? 14 : 10"
                [attr.fill]="train.delay > 0 ? '#f59e0b22' : '#f9731622'"
                [attr.stroke]="train.delay > 0 ? '#f59e0b' : '#f97316'"
                stroke-width="1.5"
                class="animate-ping"
                style="animation-duration: 3s;"
              />
              
              <!-- Train Symbol Marker -->
              <rect
                [attr.x]="train.x - 12"
                [attr.y]="train.y - 8"
                width="24"
                height="16"
                rx="3"
                [attr.fill]="service.selectedTrainId() === train.id ? '#ea580c' : train.delay > 0 ? '#b45309' : '#15803d'"
                stroke="#f97316"
                stroke-width="1.5"
                class="cursor-pointer hover:scale-110 transition-transform"
                (click)="service.selectedTrainId.set(train.id)"
              />

              <text [attr.x]="train.x" [attr.y]="train.y + 4" text-anchor="middle" fill="#ffffff" font-size="9" font-weight="bold" font-family="monospace">
                {{ train.service_number }}
              </text>

              <!-- Speed & Delay Label Floating -->
              <text [attr.x]="train.x + 16" [attr.y]="train.y - 12" [attr.fill]="train.delay > 0 ? '#f59e0b' : '#fb923c'" font-size="10" font-family="monospace" font-weight="bold">
                {{ train.speed }}km/h {{ train.delay > 0 ? '+' + train.delay + 'm' : '' }}
              </text>
            </g>
          }
        </svg>

        <!-- Floating Quick Telemetry Overlay for Selected Item -->
        <div class="absolute bottom-4 right-4 bg-[#12151a]/95 border border-zinc-800 backdrop-blur-md p-4 rounded-xl w-80 shadow-2xl z-20 font-mono text-xs">
          @if (service.selectedTrain(); as t) {
            <div class="flex items-center justify-between border-b border-zinc-800 pb-2.5 mb-2.5">
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full" [class]="t.delay_minutes > 0 ? 'bg-amber-400' : 'bg-emerald-400'"></span>
                <span class="font-bold text-orange-400">列車 {{ t.service_number }} ({{ t.id }})</span>
              </div>
              <span class="text-[10px] uppercase px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 font-semibold border border-zinc-700/50">
                {{ t.train_type }}
              </span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-zinc-300">
              <div>
                <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '區間與狀態' : 'Route & Status' }}</span>
                <span class="text-zinc-100 font-semibold">{{ t.origin }} ➔ {{ t.destination }}</span>
              </div>
              <div>
                <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '當前車速' : 'Speed' }}</span>
                <span class="text-orange-400 font-bold">{{ t.speed }} km/h</span>
              </div>
              <div>
                <span class="text-slate-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '延誤時間' : 'Delay' }}</span>
                <span [class]="t.delay_minutes > 0 ? 'text-amber-400 font-bold' : 'text-emerald-400'">
                  {{ t.delay_minutes > 0 ? '+' + t.delay_minutes + ' min' : '準點 (On Time)' }}
                </span>
              </div>
              <div>
                <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '車廂載客率' : 'Occupancy' }}</span>
                <span class="text-zinc-100 font-semibold">{{ (t.passenger_load * 100).toFixed(0) }}%</span>
              </div>
            </div>

            <!-- Occupancy bar -->
            <div class="mt-3 bg-[#0a0b0d] rounded-full h-1.5 overflow-hidden border border-zinc-800">
              <div class="bg-orange-500 h-full transition-all duration-500" [style.width.%]="t.passenger_load * 100"></div>
            </div>
          } @else {
            <div class="text-zinc-500 text-center py-2">
              {{ service.locale() === 'zh-TW' ? '請點擊地圖上的列車或車站檢視即時遙測數據' : 'Click on a train or station to view telemetry' }}
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class DigitalTwinMapComponent {
  service = inject(RailwayService);

  stationsMap = [
    { id: 'STA-1000', en: 'Taipei', zh: '臺北', x: 320, y: 100 },
    { id: 'STA-1010', en: 'Banqiao', zh: '板橋', x: 280, y: 180 },
    { id: 'STA-1020', en: 'Hsinchu', zh: '新竹', x: 260, y: 260 },
    { id: 'STA-1030', en: 'Taichung', zh: '臺中', x: 240, y: 360 },
    { id: 'STA-1040', en: 'Tainan', zh: '臺南', x: 230, y: 460 },
    { id: 'STA-1050', en: 'Kaohsiung', zh: '高雄', x: 250, y: 560 },
    { id: 'STA-1200', en: 'Hualien', zh: '花蓮', x: 580, y: 280 },
    { id: 'STA-1250', en: 'Taitung', zh: '臺東', x: 500, y: 560 },
  ];

  get trainsMapped() {
    return this.service.trains().map(t => {
      // Approximate map coordinates based on train route
      let x = 320, y = 100;
      if (t.id === 'TR-218') { x = 500; y = 220; }
      else if (t.id === 'TR-103') { x = 270; y = 220; }
      else if (t.id === 'TR-431') { x = 580; y = 280; }
      else if (t.id === 'TR-115') { x = 260; y = 260; }
      else if (t.id === 'TR-502') { x = 440; y = 90; }
      else if (t.id === 'TR-708') { x = 240; y = 360; }
      
      return {
        ...t,
        x, y,
        delay: t.delay_minutes
      };
    });
  }
}
