import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

@Component({
  selector: 'app-header',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="bg-slate-950 border-b border-cyan-900/40 text-slate-100 px-4 py-2 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-50">
      <!-- Brand & Title -->
      <div class="flex items-center gap-3">
        <div class="w-9 h-9 rounded-lg bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-cyan-400 font-mono font-bold text-lg shadow-sm shadow-cyan-500/20">
          TR
        </div>
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-base font-bold tracking-wider font-mono text-cyan-300">
              {{ service.locale() === 'zh-TW' ? '臺灣智慧鐵路作業系統' : 'TAIWAN RAILWAY.OS' }}
            </h1>
            <span class="text-[10px] uppercase tracking-widest px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono font-semibold">
              {{ service.locale() === 'zh-TW' ? '模擬模式' : 'SIMULATION' }}
            </span>
            <span class="text-[10px] tracking-widest px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono font-semibold">
              {{ service.locale() === 'zh-TW' ? '營運中' : 'OPERATIONAL' }}
            </span>
          </div>
          <p class="text-xs text-slate-400 font-mono hidden sm:block">
            {{ service.locale() === 'zh-TW' ? '鐵路自動化、數位孿生與網路最佳化平台' : 'Railway Automation, Digital Twin & Network Optimisation Platform' }}
          </p>
        </div>
      </div>

      <!-- Center KPIs & Emergency Indicators -->
      <div class="flex items-center gap-4 text-xs font-mono">
        <!-- Typhoon Mode Indicator -->
        @if (service.typhoonMode() !== 'NORMAL') {
          <div class="flex items-center gap-1.5 bg-amber-950/80 border border-amber-500/60 text-amber-300 px-2.5 py-1 rounded animate-pulse">
            <span class="w-2 h-2 rounded-full bg-amber-400"></span>
            <span>TYPHOON: {{ service.typhoonMode() }}</span>
          </div>
        }

        <!-- Earthquake Alert Indicator -->
        @if (service.earthquakeAlert()) {
          <div class="flex items-center gap-1.5 bg-red-950/80 border border-red-500/60 text-red-300 px-2.5 py-1 rounded animate-bounce">
            <span class="w-2 h-2 rounded-full bg-red-500"></span>
            <span>EARTHQUAKE SUSPENSION</span>
          </div>
        }

        <!-- Network Health Score -->
        <div class="hidden md:flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1 rounded">
          <span class="text-slate-400">{{ service.locale() === 'zh-TW' ? '鐵路網健康度' : 'NETWORK HEALTH' }}:</span>
          <span [class]="service.healthScore() > 85 ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'">
            {{ service.healthScore() }} / 100
          </span>
        </div>

        <!-- Live Clock -->
        <div class="text-cyan-400 font-mono text-xs bg-cyan-950/40 border border-cyan-800/40 px-2.5 py-1 rounded hidden lg:block">
          {{ currentTime() }}
        </div>
      </div>

      <!-- Controls: Role & Language -->
      <div class="flex items-center gap-2">
        <!-- RBAC Role Select -->
        <select
          [value]="service.role()"
          (change)="service.role.set($any($event.target).value)"
          class="bg-slate-900 border border-slate-700 text-slate-300 text-xs font-mono rounded px-2 py-1 focus:outline-none focus:border-cyan-500"
        >
          <option value="NETWORK_CONTROLLER">NETWORK_CONTROLLER (網路控制員)</option>
          <option value="STATION_OPERATOR">STATION_OPERATOR (車站員)</option>
          <option value="MAINTENANCE">MAINTENANCE (維護員)</option>
          <option value="SAFETY">SAFETY (安全管理)</option>
          <option value="PLANNER">PLANNER (規劃員)</option>
          <option value="ADMIN">ADMIN (管理員)</option>
        </select>

        <!-- Language Switcher -->
        <button
          (click)="toggleLocale()"
          class="bg-cyan-950 hover:bg-cyan-900 border border-cyan-600/50 text-cyan-300 text-xs font-mono px-2.5 py-1 rounded transition-colors"
        >
          {{ service.locale() === 'zh-TW' ? 'EN' : '繁體中文' }}
        </button>
      </div>
    </header>

    <!-- Navigation Tabs Bar -->
    <nav class="bg-slate-900 border-b border-slate-800 px-4 py-1.5 flex items-center gap-1 overflow-x-auto font-mono text-xs">
      <button
        *ngFor="let tab of tabs"
        (click)="service.activeTab.set(tab.id)"
        [class]="service.activeTab() === tab.id 
          ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/60 font-semibold px-3 py-1 rounded' 
          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800 px-3 py-1 rounded transition-colors'"
      >
        {{ service.locale() === 'zh-TW' ? tab.labelZh : tab.labelEn }}
      </button>
    </nav>
  `
})
export class HeaderComponent {
  service = inject(RailwayService);

  currentTime = signal<string>('');

  tabs = [
    { id: 'twin', labelEn: '🌐 Digital Twin Map', labelZh: '🌐 數位孿生圖' },
    { id: 'timetable', labelEn: '🚉 Timetable & Platforms', labelZh: '🚉 時刻表與月台' },
    { id: 'cascade', labelEn: '📉 Delay Cascade Engine', labelZh: '📉 延誤連鎖分析' },
    { id: 'recovery', labelEn: '⚙️ Service Recovery', labelZh: '⚙️ 恢復營運方案' },
    { id: 'modes', labelEn: '🌀 Emergency Modes', labelZh: '🌀 颱風／地震模式' },
    { id: 'maintenance', labelEn: '🛠️ Predictive Maintenance', labelZh: '🛠️ 預測性維護' },
    { id: 'copilot', labelEn: '🤖 AI Operations Copilot', labelZh: '🤖 AI 行控 Copilot' },
    { id: 'timemachine', labelEn: '⏪ Network Time Machine', labelZh: '⏪ 時光機重播' },
  ];

  constructor() {
    this.updateClock();
    if (typeof window !== 'undefined') {
      setInterval(() => this.updateClock(), 1000);
    }
  }

  updateClock() {
    const now = new Date();
    this.currentTime.set(now.toISOString().replace('T', ' ').substring(0, 19));
  }

  toggleLocale() {
    this.service.locale.set(this.service.locale() === 'zh-TW' ? 'en' : 'zh-TW');
  }
}
