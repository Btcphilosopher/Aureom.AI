import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

@Component({
  selector: 'app-kpi-bar',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 border-b border-slate-800 px-4 py-2 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 text-xs font-mono">
      <!-- On Time Rate -->
      <div class="bg-slate-950/60 border border-slate-800 p-2 rounded flex flex-col justify-between">
        <span class="text-slate-400 text-[11px] uppercase tracking-wider">
          {{ service.locale() === 'zh-TW' ? '全網準點率' : 'On-Time Rate' }}
        </span>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-base font-bold text-emerald-400 font-mono">{{ service.punctualityRate() }}%</span>
          <span class="text-[10px] text-emerald-500/80">▲ 0.3%</span>
        </div>
      </div>

      <!-- Active Trains -->
      <div class="bg-slate-950/60 border border-slate-800 p-2 rounded flex flex-col justify-between">
        <span class="text-slate-400 text-[11px] uppercase tracking-wider">
          {{ service.locale() === 'zh-TW' ? '營運中列車' : 'Active Trains' }}
        </span>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-base font-bold text-cyan-300 font-mono">{{ service.trains().length || 182 }}</span>
          <span class="text-[10px] text-slate-500">Mainline & Branches</span>
        </div>
      </div>

      <!-- Delayed Trains -->
      <div class="bg-slate-950/60 border border-slate-800 p-2 rounded flex flex-col justify-between">
        <span class="text-slate-400 text-[11px] uppercase tracking-wider">
          {{ service.locale() === 'zh-TW' ? '延誤列車' : 'Delayed Trains' }}
        </span>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-base font-bold text-amber-400 font-mono">
            {{ delayedCount() }}
          </span>
          <span class="text-[10px] text-amber-500/80">Avg 3.2 min</span>
        </div>
      </div>

      <!-- Network Capacity -->
      <div class="bg-slate-950/60 border border-slate-800 p-2 rounded flex flex-col justify-between">
        <span class="text-slate-400 text-[11px] uppercase tracking-wider">
          {{ service.locale() === 'zh-TW' ? '網路容量使用率' : 'Network Capacity' }}
        </span>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-base font-bold text-indigo-400 font-mono">{{ service.networkCapacityPct() }}%</span>
          <span class="text-[10px] text-slate-500">85,000 pax/hr</span>
        </div>
      </div>

      <!-- Active Incidents -->
      <div class="bg-slate-950/60 border border-slate-800 p-2 rounded flex flex-col justify-between">
        <span class="text-slate-400 text-[11px] uppercase tracking-wider">
          {{ service.locale() === 'zh-TW' ? '即時通報事故' : 'Active Incidents' }}
        </span>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-base font-bold text-rose-400 font-mono">2</span>
          <span class="text-[10px] text-rose-500">1 High, 1 Low</span>
        </div>
      </div>

      <!-- Network Health Score -->
      <div class="bg-slate-950/60 border border-slate-800 p-2 rounded flex flex-col justify-between">
        <span class="text-slate-400 text-[11px] uppercase tracking-wider">
          {{ service.locale() === 'zh-TW' ? '系統安全指標' : 'Safety Index' }}
        </span>
        <div class="flex items-baseline justify-between mt-1">
          <span class="text-base font-bold text-cyan-400 font-mono">DETERMINISTIC</span>
          <span class="text-[10px] text-emerald-400">Interlocked</span>
        </div>
      </div>
    </div>
  `
})
export class KpiBarComponent {
  service = inject(RailwayService);

  delayedCount() {
    return this.service.trains().filter(t => t.delay_minutes > 0).length || 14;
  }
}
