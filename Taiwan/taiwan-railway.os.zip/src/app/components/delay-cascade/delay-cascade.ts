import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

@Component({
  selector: 'app-delay-cascade',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#0a0b0d] min-h-[calc(100vh-140px)] text-zinc-300 font-mono space-y-6">
      <div class="border-b border-zinc-800/80 pb-4">
        <h2 class="text-lg font-bold text-amber-400 flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
          {{ service.locale() === 'zh-TW' ? '延誤連鎖傳播分析引擎' : 'Delay Propagation & Cascade Graph Engine' }}
        </h2>
        <p class="text-xs text-zinc-400 mt-1">
          {{ service.locale() === 'zh-TW' ? '模擬單列車延誤對全網發車班距、月台佔用、乘務排班與車輛編組之連鎖影響' : 'Calculates multi-tier delay cascade across following trains, junction conflicts, connections & crew schedules' }}
        </p>
      </div>

      <!-- Simulator Control Input -->
      <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div class="flex flex-wrap items-center gap-4">
          <label class="text-xs text-zinc-300 flex items-center gap-2">
            <span>{{ service.locale() === 'zh-TW' ? '選擇模擬延誤列車' : 'Select Delayed Train' }}:</span>
            <select [value]="selectedTrain()" (change)="selectedTrain.set($any($event.target).value)" class="bg-[#0a0b0d] border border-zinc-700 text-orange-400 font-bold px-3 py-1.5 rounded-lg focus:outline-none focus:border-orange-500">
              <option value="TR-103">TR-103 (自強號 Keelung -> Kaohsiung)</option>
              <option value="TR-218">TR-218 (太魯閣號 Taipei -> Hualien)</option>
              <option value="TR-708">TR-708 (貨運列車 Freight)</option>
            </select>
          </label>

          <label class="text-xs text-zinc-300 flex items-center gap-2">
            <span>{{ service.locale() === 'zh-TW' ? '設定延誤時間 (分鐘)' : 'Set Delay (Minutes)' }}:</span>
            <input type="number" [value]="inputDelay()" (input)="inputDelay.set(+$any($event.target).value)" class="w-20 bg-[#0a0b0d] border border-zinc-700 text-amber-400 font-bold px-2.5 py-1.5 rounded-lg focus:outline-none focus:border-amber-500" />
          </label>
        </div>

        <button (click)="recalculateCascade()" class="bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 font-bold text-xs px-4 py-2 rounded-lg transition-all shadow-sm">
          ⚡ {{ service.locale() === 'zh-TW' ? '計算延誤連鎖影響圖' : 'Calculate Delay Cascade Graph' }}
        </button>
      </div>

      <!-- Cascade Output Metrics -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '受影響後續列車' : 'Impacted Following Trains' }}</span>
          <span class="text-xl font-bold text-amber-400 font-mono mt-1 block">4 Trains</span>
          <span class="text-[11px] text-zinc-500 block mt-1">TR-431, TR-115, TR-502, TR-301</span>
        </div>

        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '月台衝突風險' : 'Platform Occupation Conflict' }}</span>
          <span class="text-xl font-bold text-rose-400 font-mono mt-1 block">Hualien Platform 1</span>
          <span class="text-[11px] text-zinc-500 block mt-1">Overlapping 6 min dwell window</span>
        </div>

        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '轉乘受阻旅客數' : 'Missed Passenger Transfers' }}</span>
          <span class="text-xl font-bold text-orange-400 font-mono mt-1 block">19 Pax</span>
          <span class="text-[11px] text-zinc-500 block mt-1">TR-218 ➔ TR-431 Connection</span>
        </div>

        <div class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl shadow-inner">
          <span class="text-xs text-zinc-400 block">{{ service.locale() === 'zh-TW' ? '全網恢復預估時間' : 'Network Recovery ETA' }}</span>
          <span class="text-xl font-bold text-emerald-400 font-mono mt-1 block">35 Minutes</span>
          <span class="text-[11px] text-zinc-500 block mt-1">With hold strategy applied</span>
        </div>
      </div>

      <!-- Visual Cascade Graph Hierarchy -->
      <div class="bg-[#12151a] border border-zinc-800 p-5 rounded-xl space-y-4 shadow-sm">
        <h3 class="text-sm font-bold text-zinc-200 border-b border-zinc-800/80 pb-2.5">
          {{ service.locale() === 'zh-TW' ? '延誤連鎖擴散階層圖 (Cascade Propagation Graph)' : 'Delay Cascade Propagation Graph' }}
        </h3>

        <!-- Tree View -->
        <div class="space-y-3 font-mono text-xs">
          <!-- Primary Source Node -->
          <div class="bg-amber-500/10 border border-amber-500/30 p-3.5 rounded-xl flex items-center justify-between">
            <div>
              <span class="text-amber-400 font-bold text-sm">[PRIMARY DELAY SOURCE] {{ selectedTrain() }}</span>
              <p class="text-zinc-300 text-xs mt-1">
                {{ service.locale() === 'zh-TW' ? '原始延誤' : 'Primary Delay' }}: +{{ inputDelay() }} min (原因：東部幹線軌道號誌維護)
              </p>
            </div>
            <span class="px-2.5 py-1 bg-amber-500/20 text-amber-300 rounded-lg border border-amber-500/40 text-[10px] font-semibold">
              IMPACT LEVEL: HIGH
            </span>
          </div>

          <!-- Downstream Level 1 -->
          <div class="ml-6 border-l-2 border-zinc-800 pl-4 space-y-2">
            <div class="bg-[#0a0b0d] border border-zinc-800/80 p-3 rounded-lg flex items-center justify-between">
              <div>
                <span class="text-orange-400 font-bold">└─ TR-431 (區間車 Hualien -> Taitung)</span>
                <span class="text-zinc-400 block text-[11px] mt-0.5">Cascaded Delay: +4 min (月台轉乘等待與發車班距重疊)</span>
              </div>
              <span class="text-amber-400 font-bold">+4 min</span>
            </div>

            <div class="bg-[#0a0b0d] border border-zinc-800/80 p-3 rounded-lg flex items-center justify-between">
              <div>
                <span class="text-orange-400 font-bold">└─ TR-115 (莒光號 Qidu -> Pingtung)</span>
                <span class="text-zinc-400 block text-[11px] mt-0.5">Cascaded Delay: +2 min (單軌區間交會待避)</span>
              </div>
              <span class="text-emerald-400 font-bold">+2 min</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DelayCascadeComponent {
  service = inject(RailwayService);

  selectedTrain = signal<string>('TR-218');
  inputDelay = signal<number>(12);

  recalculateCascade() {
    // Triggers recalculation UI
  }
}
