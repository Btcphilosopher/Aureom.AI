import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

@Component({
  selector: 'app-recovery-simulator',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#0a0b0d] min-h-[calc(100vh-140px)] text-zinc-300 font-mono space-y-6">
      <div class="border-b border-zinc-800/80 pb-4">
        <h2 class="text-lg font-bold text-orange-400 flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-orange-500 animate-pulse"></span>
          {{ service.locale() === 'zh-TW' ? '事故恢復營運方案決策最佳化引擎' : 'Service Recovery & Strategy Comparison Engine' }}
        </h2>
        <p class="text-xs text-zinc-400 mt-1">
          {{ service.locale() === 'zh-TW' ? '針對營運中斷情境自動計算多組恢復策略，包含暫停、折返、改道、越站與重新分配月台' : 'Generates multiple candidate recovery strategies evaluating delay minutes, passenger impact, conflicts & recovery time' }}
        </p>
      </div>

      <!-- Comparison Strategy Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Strategy A Card -->
        <div class="bg-[#12151a] border border-orange-500/50 p-5 rounded-xl relative space-y-4 shadow-xl">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-xs font-bold text-orange-400 tracking-wider uppercase flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-orange-500"></span>
                {{ service.locale() === 'zh-TW' ? '推薦方案 A (RECOMMENDED STRATEGY A)' : 'RECOMMENDED STRATEGY A' }}
              </span>
              <h3 class="text-base font-bold text-zinc-100 mt-1.5">
                {{ service.locale() === 'zh-TW' ? '於花蓮站等待 431 次接駁列車 4 分鐘' : 'Hold Connecting Train TR-431 for 4 minutes at Hualien' }}
              </h3>
            </div>
            <span class="bg-orange-500/10 text-orange-400 border border-orange-500/30 text-xs font-bold px-2.5 py-1 rounded-lg">
              91% CONFIDENCE
            </span>
          </div>

          <p class="text-xs text-zinc-300 leading-relaxed bg-[#0a0b0d] p-3.5 rounded-lg border border-zinc-800/80">
            {{ service.locale() === 'zh-TW' 
              ? '預測 218 次列車將延誤 7 分鐘抵達花蓮。建議：等待 431 次接駁列車 4 分鐘。預期效果：431 次列車延誤 +4 分鐘，減少 19 次轉乘失敗。' 
              : 'Train 218 is predicted to arrive 7 minutes late at Hualien. Recommended action: Hold connecting service 431 for 4 minutes. Expected effect: +4 min delay to 431, -19 missed connections.' }}
          </p>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-[#0a0b0d] p-3 rounded-lg border border-zinc-800/80">
              <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '全網恢復時間' : 'Network Recovery' }}</span>
              <span class="text-emerald-400 font-bold">35 Minutes</span>
            </div>
            <div class="bg-[#0a0b0d] p-3 rounded-lg border border-zinc-800/80">
              <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '旅客影響程度' : 'Passenger Impact' }}</span>
              <span class="text-emerald-400 font-bold">Low (-19 missed)</span>
            </div>
            <div class="bg-[#0a0b0d] p-3 rounded-lg border border-zinc-800/80">
              <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '月台衝突數' : 'Platform Conflicts' }}</span>
              <span class="text-zinc-200 font-bold">0 Conflicts</span>
            </div>
            <div class="bg-[#0a0b0d] p-3 rounded-lg border border-zinc-800/80">
              <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '牽引能耗增加' : 'Energy Cost' }}</span>
              <span class="text-zinc-200 font-bold">12.5 kWh</span>
            </div>
          </div>

          <button class="w-full bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/40 text-orange-300 font-bold text-xs py-2.5 rounded-lg transition-all shadow-sm">
            {{ service.locale() === 'zh-TW' ? '採納並發送方案 A 建議指令' : 'Apply Recovery Strategy A' }}
          </button>
        </div>

        <!-- Strategy B Card -->
        <div class="bg-[#12151a] border border-zinc-800 p-5 rounded-xl space-y-4">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-xs font-bold text-amber-400 tracking-wider uppercase flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-amber-500"></span>
                {{ service.locale() === 'zh-TW' ? '替代方案 B (ALTERNATIVE STRATEGY B)' : 'ALTERNATIVE STRATEGY B' }}
              </span>
              <h3 class="text-base font-bold text-zinc-100 mt-1.5">
                {{ service.locale() === 'zh-TW' ? '103 次列車於臺中站折返' : 'Short-turn Train TR-103 at Taichung Station' }}
              </h3>
            </div>
            <span class="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs font-bold px-2.5 py-1 rounded-lg">
              85% CONFIDENCE
            </span>
          </div>

          <p class="text-xs text-zinc-300 leading-relaxed bg-[#0a0b0d] p-3.5 rounded-lg border border-zinc-800/80">
            {{ service.locale() === 'zh-TW'
              ? '將 103 次自強號於臺中站提前折返，開往基隆。優點：避免彰化段班距累積；缺點：南部往新竹旅客需改搭後續 115 次列車。'
              : 'Short-turn TR-103 at Taichung back toward Keelung. Pros: Avoids bottleneck downstream at Changhua. Cons: Southbound passengers must transfer to TR-115.' }}
          </p>

          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="bg-[#0a0b0d] p-3 rounded-lg border border-zinc-800/80">
              <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '全網恢復時間' : 'Network Recovery' }}</span>
              <span class="text-emerald-400 font-bold">22 Minutes</span>
            </div>
            <div class="bg-[#0a0b0d] p-3 rounded-lg border border-zinc-800/80">
              <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '旅客影響程度' : 'Passenger Impact' }}</span>
              <span class="text-amber-400 font-bold">Medium (Transfer Required)</span>
            </div>
            <div class="bg-[#0a0b0d] p-3 rounded-lg border border-zinc-800/80">
              <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '月台衝突數' : 'Platform Conflicts' }}</span>
              <span class="text-amber-400 font-bold">1 Re-assignment</span>
            </div>
            <div class="bg-[#0a0b0d] p-3 rounded-lg border border-zinc-800/80">
              <span class="text-zinc-500 text-[10px] block">{{ service.locale() === 'zh-TW' ? '牽引能耗增加' : 'Energy Cost' }}</span>
              <span class="text-zinc-200 font-bold">48.0 kWh</span>
            </div>
          </div>

          <button class="w-full bg-zinc-800/80 hover:bg-zinc-800 text-zinc-200 border border-zinc-700/50 font-bold text-xs py-2.5 rounded-lg transition-all">
            {{ service.locale() === 'zh-TW' ? '採納並發送方案 B 建議指令' : 'Apply Recovery Strategy B' }}
          </button>
        </div>
      </div>
    </div>
  `
})
export class RecoverySimulatorComponent {
  service = inject(RailwayService);
}
