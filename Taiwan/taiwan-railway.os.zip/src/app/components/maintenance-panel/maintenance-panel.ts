import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

@Component({
  selector: 'app-maintenance-panel',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#0a0b0d] min-h-[calc(100vh-140px)] text-zinc-300 font-mono space-y-6">
      <div class="border-b border-zinc-800/80 pb-4">
        <h2 class="text-lg font-bold text-orange-400 flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-orange-500 animate-pulse"></span>
          {{ service.locale() === 'zh-TW' ? '智慧鐵路設施預測性維護與健康度評估' : 'Predictive Maintenance & Asset Health Intelligence' }}
        </h2>
        <p class="text-xs text-zinc-400 mt-1">
          {{ service.locale() === 'zh-TW' ? '即時監測橋梁振動、隧道滲水、道岔轉轍馬達電流與平交道遮斷機使用次數' : 'Continuous monitoring of bridges, tunnels, switches & level crossings with Remaining Useful Life (RUL) estimation' }}
        </p>
      </div>

      <!-- Infrastructure Asset Health List -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div *ngFor="let asset of service.maintenanceAssets()" class="bg-[#12151a] border border-zinc-800 p-4 rounded-xl space-y-3.5 shadow-sm">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-[#0a0b0d] text-zinc-400 border border-zinc-800">
                {{ asset.asset_type }}
              </span>
              <h3 class="text-sm font-bold text-zinc-200 mt-2">
                {{ service.locale() === 'zh-TW' ? asset.name_zh_tw : asset.name_en }}
              </h3>
            </div>
            
            <span [class]="asset.priority === 'HIGH' ? 'px-2 py-0.5 text-[10px] font-bold rounded-md bg-rose-500/10 text-rose-400 border border-rose-500/30' : asset.priority === 'MEDIUM' ? 'px-2 py-0.5 text-[10px] font-bold rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/30' : 'px-2 py-0.5 text-[10px] font-bold rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'">
              {{ asset.priority }} PRIORITY
            </span>
          </div>

          <div class="space-y-2 text-xs">
            <div class="flex justify-between text-zinc-400">
              <span>{{ service.locale() === 'zh-TW' ? '健康度分數' : 'Health Score' }}:</span>
              <span [class]="asset.health_score < 80 ? 'text-amber-400 font-bold' : 'text-emerald-400 font-bold'">
                {{ asset.health_score }} / 100
              </span>
            </div>

            <!-- Health Bar -->
            <div class="bg-[#0a0b0d] rounded-full h-1.5 overflow-hidden border border-zinc-800">
              <div [class]="asset.health_score < 80 ? 'bg-amber-500 h-full' : 'bg-emerald-500 h-full'" [style.width.%]="asset.health_score"></div>
            </div>

            <div class="flex justify-between text-zinc-400 pt-1">
              <span>{{ service.locale() === 'zh-TW' ? '剩餘可用壽命 (RUL)' : 'Remaining Useful Life' }}:</span>
              <span class="text-zinc-200 font-bold">{{ asset.remaining_days }} Days</span>
            </div>

            <div class="bg-[#0a0b0d] p-2.5 rounded-lg text-[10px] text-zinc-400 border border-zinc-800/80 font-mono mt-2 space-y-0.5">
              <span class="text-orange-400 font-bold block">{{ service.locale() === 'zh-TW' ? '遙測感測數據' : 'Telemetry Stream' }}</span>
              <span class="text-zinc-300">{{ asset.telemetry }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MaintenancePanelComponent {
  service = inject(RailwayService);
}
