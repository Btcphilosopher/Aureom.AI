import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RailwayService } from '../../services/railway';

interface ChatMessage {
  sender: 'user' | 'copilot';
  text: string;
  time: string;
}

@Component({
  selector: 'app-copilot-drawer',
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 bg-[#0a0b0d] min-h-[calc(100vh-140px)] text-zinc-300 font-mono flex flex-col justify-between space-y-4">
      <div class="border-b border-zinc-800/80 pb-4">
        <h2 class="text-lg font-bold text-orange-400 flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-orange-500 animate-pulse"></span>
          🤖 {{ service.locale() === 'zh-TW' ? 'AI 行控智慧助理 (RailwayCopilot)' : 'AI Railway Operations Copilot' }}
        </h2>
        <p class="text-xs text-zinc-400 mt-1">
          {{ service.locale() === 'zh-TW' ? '結合 Gemini AI 與即時路網遙測資料，提供可解釋性排班決策與情境詢問' : 'Groundable AI decision support assistant powered by Gemini for dispatcher queries & what-if analysis' }}
        </p>
      </div>

      <!-- Quick Suggested Prompt Chips -->
      <div class="flex flex-wrap gap-2 text-xs">
        <button
          *ngFor="let prompt of suggestedPrompts"
          (click)="askQuestion(service.locale() === 'zh-TW' ? prompt.zh : prompt.en)"
          class="bg-[#12151a] hover:bg-zinc-800/80 border border-zinc-700/60 text-orange-300 px-3 py-1.5 rounded-lg transition-all text-left shadow-sm font-sans"
        >
          💡 {{ service.locale() === 'zh-TW' ? prompt.zh : prompt.en }}
        </button>
      </div>

      <!-- Chat History Box -->
      <div class="flex-1 bg-[#12151a] border border-zinc-800 rounded-xl p-4 space-y-4 overflow-y-auto max-h-[500px] shadow-inner">
        <div *ngFor="let msg of messages()" [class]="msg.sender === 'user' ? 'text-right' : 'text-left'">
          <div [class]="msg.sender === 'user' 
            ? 'inline-block bg-orange-500/10 border border-orange-500/30 text-orange-200 px-4 py-3 rounded-2xl text-xs max-w-2xl text-left shadow-sm' 
            : 'inline-block bg-[#0a0b0d] border border-zinc-800 text-zinc-200 px-4 py-3 rounded-2xl text-xs max-w-3xl whitespace-pre-line text-left shadow-sm'">
            <div class="text-[10px] text-zinc-500 mb-1 font-bold flex items-center gap-1.5">
              <span class="w-1.5 h-1.5 rounded-full" [class]="msg.sender === 'user' ? 'bg-orange-400' : 'bg-emerald-400'"></span>
              <span>{{ msg.sender === 'user' ? (service.locale() === 'zh-TW' ? '行控人員' : 'DISPATCHER') : 'RAILWAY COPILOT (GEMINI)' }} • {{ msg.time }}</span>
            </div>
            {{ msg.text }}
          </div>
        </div>

        @if (isLoading()) {
          <div class="text-left">
            <div class="inline-block bg-[#0a0b0d] border border-zinc-800 text-amber-400 px-4 py-2.5 rounded-2xl text-xs animate-pulse">
              ⚡ {{ service.locale() === 'zh-TW' ? 'AI 行控助理正在分析路網圖與遙測數據...' : 'Copilot analyzing railway graph & live telemetry...' }}
            </div>
          </div>
        }
      </div>

      <!-- Input Box -->
      <div class="flex items-center gap-3">
        <input
          type="text"
          [value]="userInput()"
          (input)="userInput.set($any($event.target).value)"
          (keyup.enter)="sendMessage()"
          [placeholder]="service.locale() === 'zh-TW' ? '請輸入您的行控問題，例如：目前有哪些列車延誤？' : 'Ask a question, e.g. Which trains are delayed right now?'"
          class="flex-1 bg-[#12151a] border border-zinc-700/80 text-zinc-100 text-xs px-4 py-3 rounded-xl focus:outline-none focus:border-orange-500 font-mono"
        />
        <button
          (click)="sendMessage()"
          class="bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/40 text-orange-300 font-bold text-xs px-5 py-3 rounded-xl transition-all shadow-sm"
        >
          {{ service.locale() === 'zh-TW' ? '發送詢問' : 'Send' }}
        </button>
      </div>
    </div>
  `
})
export class CopilotDrawerComponent {
  service = inject(RailwayService);

  userInput = signal<string>('');
  isLoading = signal<boolean>(false);

  messages = signal<ChatMessage[]>([
    {
      sender: 'copilot',
      text: '您好！我是 臺灣智慧鐵路作業系統 的 AI 行控助理。我可以協助您分析路網準點率、延誤傳播原因、極端天候應變，或模擬月台與班表調整方案。請問有什麼可以為您服務？',
      time: '08:00:00'
    }
  ]);

  suggestedPrompts = [
    { en: 'Which trains are currently delayed across the network?', zh: '目前全線有哪些列車延誤？' },
    { en: 'Why is Train TR-218 delayed near Hualien?', zh: '218 次列車於花蓮段延誤的原因為何？' },
    { en: 'What happens if Taipei Station Platform 3 closes for 30 minutes?', zh: '若臺北車站 3 號月台封閉 30 分鐘會有什麼影響？' },
    { en: 'Summarize network safety status during current typhoon level.', zh: '總結當前防颱應變模式下的路網安全狀態。' }
  ];

  askQuestion(q: string) {
    this.userInput.set(q);
    this.sendMessage();
  }

  async sendMessage() {
    const text = this.userInput().trim();
    if (!text) return;

    const now = new Date().toLocaleTimeString();
    this.messages.update(prev => [...prev, { sender: 'user', text, time: now }]);
    this.userInput.set('');
    this.isLoading.set(true);

    const answer = await this.service.askCopilot(text);
    this.isLoading.set(false);
    this.messages.update(prev => [...prev, { sender: 'copilot', text: answer, time: new Date().toLocaleTimeString() }]);
  }
}
