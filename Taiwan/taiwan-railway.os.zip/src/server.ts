import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Initialize Gemini Client server-side
const ai = new GoogleGenAI({
  apiKey: process.env['GEMINI_API_KEY'] || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Taiwan Railway Simulation Engine State
let typhoonMode = 'NORMAL'; // NORMAL, WATCH, WARNING, RESTRICTED, EMERGENCY
let earthquakeActive = false;
let simulationTime = new Date();

interface SimulatedTrain {
  id: string;
  service_number: string;
  train_type: string;
  origin: string;
  destination: string;
  latitude: number;
  longitude: number;
  speed: number;
  heading: number;
  track_section: string;
  delay_minutes: number;
  passenger_load: number; // ratio 0.0 - 1.0
  status: string; // RUNNING, DWELLING, APPROACHING, DELAYED, DIVERTED, CANCELLED
  region: string;
  energy_kwh: number;
}

const initialTrains: SimulatedTrain[] = [
  { id: 'TR-218', service_number: '218', train_type: 'LIMITED_EXPRESS', origin: 'Taipei', destination: 'Hualien', latitude: 24.1477, longitude: 120.6736, speed: 94, heading: 180, track_section: 'SEC-048', delay_minutes: 7, passenger_load: 0.88, status: 'RUNNING', region: 'Eastern Corridor', energy_kwh: 48.2 },
  { id: 'TR-103', service_number: '103', train_type: 'INTERCITY', origin: 'Keelung', destination: 'Kaohsiung', latitude: 24.9892, longitude: 121.3135, speed: 110, heading: 210, track_section: 'SEC-012', delay_minutes: 12, passenger_load: 0.94, status: 'DELAYED', region: 'Western Corridor', energy_kwh: 62.5 },
  { id: 'TR-431', service_number: '431', train_type: 'LOCAL', origin: 'Hualien', destination: 'Taitung', latitude: 23.9934, longitude: 121.6012, speed: 0, heading: 170, track_section: 'SEC-102', delay_minutes: 0, passenger_load: 0.42, status: 'DWELLING', region: 'Eastern Corridor', energy_kwh: 12.0 },
  { id: 'TR-115', service_number: '115', train_type: 'EXPRESS', origin: 'Qidu', destination: 'Pingtung', latitude: 24.8018, longitude: 120.9715, speed: 102, heading: 220, track_section: 'SEC-028', delay_minutes: 2, passenger_load: 0.76, status: 'RUNNING', region: 'Western Corridor', energy_kwh: 51.0 },
  { id: 'TR-502', service_number: '502', train_type: 'TOURIST', origin: 'Taipei', destination: 'Pingxi', latitude: 25.0256, longitude: 121.7388, speed: 45, heading: 90, track_section: 'SEC-B01', delay_minutes: 0, passenger_load: 0.65, status: 'RUNNING', region: 'Pingxi Branch', energy_kwh: 22.4 },
  { id: 'TR-708', service_number: '708', train_type: 'FREIGHT', origin: 'Hsinchu', destination: 'Hualien', latitude: 24.5700, longitude: 120.8256, speed: 70, heading: 140, track_section: 'SEC-035', delay_minutes: 15, passenger_load: 1.0, status: 'RUNNING', region: 'Western Corridor', energy_kwh: 88.0 },
];

let activeTrains = [...initialTrains];

// Periodic simulation step
setInterval(() => {
  simulationTime = new Date(simulationTime.getTime() + 5000);
  activeTrains.forEach((t) => {
    if (earthquakeActive) {
      t.speed = 0;
      t.status = 'OUT_OF_SERVICE';
      return;
    }
    if (typhoonMode === 'WARNING') {
      t.speed = Math.min(t.speed, 70);
    } else if (typhoonMode === 'RESTRICTED') {
      t.speed = Math.min(t.speed, 30);
    } else if (typhoonMode === 'EMERGENCY') {
      t.speed = 0;
      t.status = 'CANCELLED';
      return;
    }

    if (t.status === 'RUNNING') {
      // Simulate micro-movement along route
      t.latitude += (Math.random() - 0.48) * 0.002;
      t.longitude += (Math.random() - 0.48) * 0.002;
      t.speed = Math.min(130, Math.max(30, t.speed + (Math.random() - 0.5) * 4));
      t.energy_kwh += t.speed * 0.05;
    } else if (t.status === 'DWELLING') {
      if (Math.random() > 0.7) {
        t.status = 'RUNNING';
        t.speed = 40;
      }
    }
  });
}, 3000);

// API Endpoints
app.get('/api/network', (req, res) => {
  res.json({
    mode: 'SIMULATION',
    status: 'OPERATIONAL',
    system: 'TAIWAN RAILWAY.OS',
    system_zh: '臺灣智慧鐵路作業系統',
    network_regions: [
      { id: 'northern', name_en: 'Northern Taiwan', name_zh_tw: '北臺灣', stations_count: 32 },
      { id: 'western', name_en: 'Western Corridor', name_zh_tw: '西部幹線', stations_count: 85 },
      { id: 'eastern', name_en: 'Eastern Corridor', name_zh_tw: '東部幹線', stations_count: 48 },
      { id: 'pingtung', name_en: 'Pingtung Line', name_zh_tw: '屏東線', stations_count: 18 },
      { id: 'southern_link', name_en: 'Southern Link', name_zh_tw: '南迴線', stations_count: 14 },
      { id: 'branch_lines', name_en: 'Branch Lines', name_zh_tw: '支線 (平溪/深澳/內灣/六家/集集/沙崙)', stations_count: 44 }
    ],
    kpis: {
      punctuality_pct: 94.7,
      active_trains: activeTrains.length,
      delayed_trains: activeTrains.filter((t) => t.delay_minutes > 5).length,
      network_capacity_pct: 81.5,
      health_score: earthquakeActive ? 42.0 : typhoonMode !== 'NORMAL' ? 76.5 : 94.0,
      typhoon_mode: typhoonMode,
      earthquake_alert: earthquakeActive
    }
  });
});

app.get('/api/stations', (req, res) => {
  res.json([
    { station_id: 'STA-1000', code: 'TAIPEI', name_en: 'Taipei', name_zh_tw: '臺北', latitude: 25.0478, longitude: 121.5170, region: 'Western Corridor', type: 'MAJOR', platforms: ['P1', 'P2', 'P3', 'P4'], passenger_capacity: 120000 },
    { station_id: 'STA-1010', code: 'BANQIAO', name_en: 'Banqiao', name_zh_tw: '板橋', latitude: 25.0142, longitude: 121.4638, region: 'Western Corridor', type: 'MAJOR', platforms: ['P1', 'P2'], passenger_capacity: 75000 },
    { station_id: 'STA-1020', code: 'HSINCHU', name_en: 'Hsinchu', name_zh_tw: '新竹', latitude: 24.8018, longitude: 120.9715, region: 'Western Corridor', type: 'MAJOR', platforms: ['P1', 'P2', 'P3'], passenger_capacity: 55000 },
    { station_id: 'STA-1030', code: 'TAICHUNG', name_en: 'Taichung', name_zh_tw: '臺中', latitude: 24.1368, longitude: 120.6850, region: 'Western Corridor', type: 'MAJOR', platforms: ['P1', 'P2', 'P3'], passenger_capacity: 85000 },
    { station_id: 'STA-1040', code: 'TAINAN', name_en: 'Tainan', name_zh_tw: '臺南', latitude: 22.9972, longitude: 120.2127, region: 'Western Corridor', type: 'MAJOR', platforms: ['P1', 'P2'], passenger_capacity: 65000 },
    { station_id: 'STA-1050', code: 'KAOHSIUNG', name_en: 'Kaohsiung', name_zh_tw: '高雄', latitude: 22.6397, longitude: 120.3023, region: 'Western Corridor', type: 'MAJOR', platforms: ['P1', 'P2', 'P3', 'P4'], passenger_capacity: 95000 },
    { station_id: 'STA-1200', code: 'HUALIEN', name_en: 'Hualien', name_zh_tw: '花蓮', latitude: 23.9934, longitude: 121.6012, region: 'Eastern Corridor', type: 'MAJOR', platforms: ['P1', 'P2', 'P3'], passenger_capacity: 45000 },
    { station_id: 'STA-1250', code: 'TAITUNG', name_en: 'Taitung', name_zh_tw: '臺東', latitude: 22.7932, longitude: 121.1233, region: 'Eastern Corridor', type: 'MAJOR', platforms: ['P1', 'P2'], passenger_capacity: 35000 },
  ]);
});

app.get('/api/trains', (req, res) => {
  res.json(activeTrains);
});

app.get('/api/maintenance', (req, res) => {
  res.json([
    { id: 'BRG-012', asset_type: 'BRIDGE', name_en: 'Cengwen River Bridge', name_zh_tw: '曾文溪橋', health_score: 92.4, remaining_days: 1420, priority: 'LOW', telemetry: 'Vibration 0.42 mm/s, Temp 28.5°C' },
    { id: 'TUN-008', asset_type: 'TUNNEL', name_en: 'Caoling Tunnel', name_zh_tw: '草嶺隧道', health_score: 88.1, remaining_days: 850, priority: 'MEDIUM', telemetry: 'Seepage 1.2 L/min, Smoke 0.0 ppm' },
    { id: 'SW-104', asset_type: 'SWITCH', name_en: 'Taipei North Junction Switch #4', name_zh_tw: '臺北北端交會道岔 #4', health_score: 78.5, remaining_days: 180, priority: 'HIGH', telemetry: 'Motor Current 14.8A, Throw Time 2.8s' },
    { id: 'LC-204', asset_type: 'LEVEL_CROSSING', name_en: 'Ruifang Crossing #2', name_zh_tw: '瑞芳二號平交道', health_score: 95.0, remaining_days: 2100, priority: 'LOW', telemetry: 'Barrier cycles 14,280, Warning state OK' }
  ]);
});

app.get('/api/recommendations', (req, res) => {
  res.json([
    {
      id: 'REC-2026-01',
      title_en: 'Hold connecting service TR-431 for 4 minutes at Hualien',
      title_zh_tw: '於花蓮站等待 431 次接駁列車 4 分鐘',
      reason: 'Train TR-218 is predicted to arrive 7 minutes late at Hualien. Holding TR-431 for 4 mins prevents 19 missed passenger connections while keeping downstream delay cascade under 5 minutes.',
      data_inputs: ['GPS Telemetry TR-218', 'Track Circuit Occupancy SEC-048', 'Passenger Tap-In Flow'],
      constraints: ['Minimum 3 min platform dwell', 'Single-track headway rule'],
      expected_effect: '+4 min delay to TR-431, -19 missed passenger connections',
      confidence: 0.91,
      alternatives: [
        { name_en: 'Strategy A: Hold TR-431 for 4 mins', name_zh_tw: '方案 A：暫停 431 次 4 分鐘', delay_impact: '+4 min', recovery_time: '35 min', passenger_impact: 'Low' },
        { name_en: 'Strategy B: Short-turn TR-103 at Taichung', name_zh_tw: '方案 B：103 次於臺中折返', delay_impact: '0 min', recovery_time: '22 min', passenger_impact: 'Medium' }
      ]
    }
  ]);
});

// Mode controls
app.post('/api/mode/typhoon', (req, res) => {
  const { mode } = req.body;
  typhoonMode = mode || 'NORMAL';
  res.json({ success: true, typhoon_mode: typhoonMode });
});

app.post('/api/mode/earthquake', (req, res) => {
  const { active } = req.body;
  earthquakeActive = !!active;
  res.json({ success: true, earthquake_alert: earthquakeActive });
});

// AI Copilot Endpoint using @google/genai
app.post('/api/copilot/ask', async (req, res) => {
  const { question, locale } = req.body;
  const isZh = locale === 'zh-TW';

  try {
    const prompt = `You are RailwayCopilot for TAIWAN RAILWAY.OS (臺灣智慧鐵路作業系統).
Answer the user query based strictly on the current network telemetry state:
- Punctuality Rate: 94.7%
- Active Trains: 182
- Currently Delayed Trains: TR-103 (+12 mins near Taoyuan), TR-218 (+7 mins near Hualien)
- Active Emergency Mode: Typhoon state=${typhoonMode}, Earthquake=${earthquakeActive ? 'TRIGGERED' : 'NORMAL'}
- Infrastructure Status: Switch #4 at Taipei North Junction has HIGH maintenance priority (Health 78.5%).

User Question: "${question}"
Target Language: ${isZh ? 'Traditional Chinese (繁體中文)' : 'English'}. Never use Simplified Chinese.

Formulate an explainable, precise operational answer. Include:
1. Operational Direct Answer
2. Root Cause Analysis
3. Recommended Dispatcher Action
4. Risk / Impact Mitigation`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
    });

    res.json({ answer: response.text });
  } catch (err: any) {
    // Fallback structured answer if API key not present or error
    res.json({
      answer: isZh
        ? `[系統智慧分析] 根據目前臺鐵路網狀態：\n1. 營運狀況：全網 182 列列車運作中，準點率 94.7%。\n2. 延誤分析：218 次列車於花蓮段延誤 7 分鐘；103 次列車於桃園段延誤 12 分鐘。\n3. 建議處置：於花蓮站扣留 431 次接駁列車 4 分鐘，可減少 19 次轉乘失敗。`
        : `[System Copilot Analysis] Based on current Taiwan Railway state:\n1. Status: 182 active trains, 94.7% punctuality rate.\n2. Delays: TR-218 delayed 7 mins near Hualien; TR-103 delayed 12 mins near Taoyuan.\n3. Recommendation: Hold connecting service TR-431 for 4 minutes at Hualien to prevent 19 missed connections.`
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);
