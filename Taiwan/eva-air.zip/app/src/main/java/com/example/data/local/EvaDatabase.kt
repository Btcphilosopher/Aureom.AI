package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface EvaDao {
    @Query("SELECT * FROM saved_trips")
    fun getAllTrips(): Flow<List<TripEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrips(trips: List<TripEntity>)

    @Query("SELECT * FROM saved_boarding_passes")
    fun getAllBoardingPasses(): Flow<List<BoardingPassEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBoardingPass(pass: BoardingPassEntity)

    @Query("SELECT * FROM user_preferences WHERE id = 1")
    fun getUserPreferences(): Flow<UserPreferencesEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserPreferences(prefs: UserPreferencesEntity)
}

@Database(
    entities = [TripEntity::class, BoardingPassEntity::class, UserPreferencesEntity::class],
    version = 1,
    exportSchema = false
)
abstract class EvaDatabase : RoomDatabase() {
    abstract fun evaDao(): EvaDao
}
