package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EvaMint,
    onPrimary = Color.Black,
    primaryContainer = EvaGreen,
    onPrimaryContainer = Color.White,
    secondary = EvaGold,
    onSecondary = Color.Black,
    background = EvaDeepBackground,
    onBackground = EvaTextLight,
    surface = EvaCardBgDark,
    onSurface = EvaTextLight,
    surfaceVariant = EvaSurfaceDark,
    onSurfaceVariant = Color(0xFFB0D8C8),
    outline = EvaBorderDark
)

private val LightColorScheme = lightColorScheme(
    primary = EvaGreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2EB),
    onPrimaryContainer = EvaDarkGreen,
    secondary = EvaGold,
    onSecondary = Color.Black,
    background = EvaDarkGreen, // Default to rich immersive green background
    onBackground = EvaTextLight,
    surface = EvaCardBgDark,
    onSurface = EvaTextLight,
    surfaceVariant = EvaSurfaceDark,
    onSurfaceVariant = Color(0xFFC8E6DA),
    outline = EvaBorderDark
)

@Composable
fun EvaTheme(
    darkTheme: Boolean = true, // Default to rich Immersive UI theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

