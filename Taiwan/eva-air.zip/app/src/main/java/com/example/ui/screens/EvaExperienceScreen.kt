package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.i18n.AppLanguage
import com.example.data.models.Cabin
import com.example.ui.components.Cabin3DViewer

@Composable
fun EvaExperienceScreen(
    cabins: List<Cabin>,
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("eva_experience_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "The EVA Air Cabin Experience" else "長榮航空艙等與奢華體驗",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Explore 3D seat specifications & Michelin dining privileges" else "探索獨立包廂、人體工學座椅與米其林美饌細節",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Cabin3DViewer(
                cabins = cabins,
                currentLanguage = currentLanguage
            )
        }
    }
}
