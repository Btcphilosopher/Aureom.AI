package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EvaDeepBackground
import com.example.ui.theme.EvaForestGreen
import com.example.ui.theme.EvaGold
import com.example.ui.theme.EvaGreen
import com.example.ui.theme.EvaMint

@Composable
fun InteractiveHeroCanvas(
    onAircraftClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var flightDirection by remember { mutableFloatStateOf(1.0f) } // 1.0f = East bound, -1.0f = West bound
    var bankAngle by remember { mutableFloatStateOf(-15f) }

    val infiniteTransition = rememberInfiniteTransition(label = "HeroAircraftCruising")
    val cruiseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "cruise"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        EvaForestGreen,
                        EvaGreen,
                        Color(0xFF003D20)
                    )
                )
            )
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, dragAmount ->
                    change.consume()
                    if (dragAmount > 10f) {
                        flightDirection = 1.0f
                        bankAngle = -10f
                    } else if (dragAmount < -10f) {
                        flightDirection = -1.0f
                        bankAngle = 10f
                    }
                }
            }
            .clickable { onAircraftClick() }
            .testTag("interactive_hero_canvas")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Draw subtle Taiwanese mountain ridge silhouettes in background
            val ridgePath = Path().apply {
                moveTo(0f, h * 0.8f)
                cubicTo(w * 0.2f, h * 0.6f, w * 0.35f, h * 0.75f, w * 0.5f, h * 0.65f)
                cubicTo(w * 0.65f, h * 0.55f, w * 0.8f, h * 0.7f, w, h * 0.6f)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(
                path = ridgePath,
                color = Color(0xFF002914).copy(alpha = 0.5f)
            )

            // Draw floating cloud layers
            drawCircle(
                color = Color.White.copy(alpha = 0.08f),
                radius = h * 0.4f,
                center = Offset(w * 0.25f, h * 0.3f)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.06f),
                radius = h * 0.5f,
                center = Offset(w * 0.75f, h * 0.4f)
            )

            // Calculate aircraft position based on progress and direction
            val currentX = if (flightDirection > 0) {
                w * 0.1f + (w * 0.8f) * cruiseProgress
            } else {
                w * 0.9f - (w * 0.8f) * cruiseProgress
            }
            val currentY = h * 0.35f + kotlin.math.sin(cruiseProgress * Math.PI.toFloat() * 2f) * 12f

            // Draw aircraft silhouette
            rotate(
                degrees = if (flightDirection > 0) bankAngle else -bankAngle,
                pivot = Offset(currentX, currentY)
            ) {
                drawAircraftSilhouette(
                    center = Offset(currentX, currentY),
                    aircraftColor = Color.White,
                    scale = 1.1f * flightDirection
                )
            }
        }

        // Tap Hint Overlay Badge
        Surface(
            color = Color.Black.copy(alpha = 0.35f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp)
        ) {
            Text(
                text = "Tap aircraft to Explore Destinations ✈️",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = EvaGold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}
