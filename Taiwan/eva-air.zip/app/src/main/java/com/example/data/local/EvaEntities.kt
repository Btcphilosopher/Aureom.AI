package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val pnr: String,
    val flightNumber: String,
    val originCode: String,
    val originCityEn: String,
    val originCityZh: String,
    val destCode: String,
    val destCityEn: String,
    val destCityZh: String,
    val departureDate: String,
    val departureTime: String,
    val arrivalTime: String,
    val seatNumber: String,
    val gate: String,
    val terminal: String,
    val boardingGroup: String,
    val passengerName: String,
    val classType: String,
    val status: String,
    val journeyState: String,
    val baggageTag: String
)

@Entity(tableName = "saved_boarding_passes")
data class BoardingPassEntity(
    @PrimaryKey val id: String,
    val pnr: String,
    val passengerName: String,
    val flightNumber: String,
    val originCode: String,
    val originCityEn: String,
    val originCityZh: String,
    val destCode: String,
    val destCityEn: String,
    val destCityZh: String,
    val departureTime: String,
    val departureDate: String,
    val gate: String,
    val seat: String,
    val boardingGroup: String,
    val classType: String,
    val qrCodePayload: String
)

@Entity(tableName = "user_preferences")
data class UserPreferencesEntity(
    @PrimaryKey val id: Int = 1,
    val languageCode: String = "en",
    val currencyCode: String = "TWD",
    val isDarkMode: Boolean = false,
    val isReducedMotion: Boolean = false,
    val activeJourneyState: String = "BOOKED"
)
