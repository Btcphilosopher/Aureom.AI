package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EvaDeepBackground
import com.example.ui.theme.EvaGold
import com.example.ui.theme.EvaGreen
import com.example.ui.theme.EvaMint
import kotlin.math.atan2

@Composable
fun InteractiveMapCanvas(
    originCode: String = "TPE",
    destCode: String = "LHR",
    originCity: String = "Taipei",
    destCity: String = "London",
    flightNumber: String = "BR067",
    progressOverride: Float? = null,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "FlightMapProgress")
    val animatedProgress by infiniteTransition.animateFloat(
        initialValue = 0.05f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "flightProgress"
    )

    val currentProgress = progressOverride ?: animatedProgress

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(EvaDeepBackground)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.8f, 3f)
                    offsetX += pan.x
                    offsetY += pan.y
                }
            }
            .testTag("interactive_flight_map_canvas")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            withTransform({
                translate(offsetX, offsetY)
                scale(scale, scale, pivot = Offset(w / 2f, h / 2f))
            }) {
                // Background Radar Grid Circles
                drawCircle(
                    color = Color.White.copy(alpha = 0.04f),
                    radius = w * 0.45f,
                    center = Offset(w * 0.5f, h * 0.5f),
                    style = Stroke(width = 1.dp.toPx())
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.03f),
                    radius = w * 0.25f,
                    center = Offset(w * 0.5f, h * 0.5f),
                    style = Stroke(width = 1.dp.toPx())
                )

                // Define Coordinates for Origin (TPE) and Destination (LHR / NRT)
                val tpeX = w * 0.2f
                val tpeY = h * 0.7f

                val destX = w * 0.82f
                val destY = h * 0.3f

                val controlX = w * 0.5f
                val controlY = h * 0.05f

                // Draw Great Circle Arc Path
                val arcPath = Path().apply {
                    moveTo(tpeX, tpeY)
                    quadraticTo(controlX, controlY, destX, destY)
                }

                // Draw Dashed Route Path
                drawPath(
                    path = arcPath,
                    color = EvaMint.copy(alpha = 0.35f),
                    style = Stroke(
                        width = 2.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f),
                        cap = StrokeCap.Round
                    )
                )

                // Measure Path Progress
                val pathMeasure = PathMeasure()
                pathMeasure.setPath(arcPath, false)
                val totalLength = pathMeasure.length
                val flownDistance = totalLength * currentProgress

                val flownPath = Path()
                pathMeasure.getSegment(0f, flownDistance, flownPath, true)

                // Traveled Path Glow
                drawPath(
                    path = flownPath,
                    color = EvaMint,
                    style = Stroke(
                        width = 3.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                )

                // Origin Node Pulse
                drawCircle(color = EvaGold, radius = 6.dp.toPx(), center = Offset(tpeX, tpeY))
                drawCircle(color = EvaGold.copy(alpha = 0.3f), radius = 12.dp.toPx(), center = Offset(tpeX, tpeY))

                // Destination Node
                drawCircle(color = Color.White, radius = 6.dp.toPx(), center = Offset(destX, destY))
                drawCircle(color = Color.White.copy(alpha = 0.3f), radius = 12.dp.toPx(), center = Offset(destX, destY))

                // Aircraft Position and Angle
                val planePos = pathMeasure.getPosition(flownDistance)
                val planeNext = pathMeasure.getPosition((flownDistance + 2f).coerceAtMost(totalLength))

                val angle = if (planeNext != Offset.Unspecified && planePos != Offset.Unspecified) {
                    val dx = planeNext.x - planePos.x
                    val dy = planeNext.y - planePos.y
                    Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                } else {
                    -20f
                }

                if (planePos != Offset.Unspecified) {
                    rotate(degrees = angle, pivot = planePos) {
                        drawAircraftSilhouette(
                            center = planePos,
                            aircraftColor = EvaGold,
                            scale = 1.2f
                        )
                    }
                }
            }
        }

        // Overlay Map Controls (Zoom In, Zoom Out, Reset, Follow Aircraft)
        Surface(
            color = Color.Black.copy(alpha = 0.5f),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp)
        ) {
            Row(modifier = Modifier.padding(4.dp)) {
                IconButton(
                    onClick = { scale = (scale + 0.3f).coerceAtMost(3f) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color.White)
                }
                IconButton(
                    onClick = { scale = (scale - 0.3f).coerceAtLeast(0.8f) },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color.White)
                }
                IconButton(
                    onClick = {
                        scale = 1f
                        offsetX = 0f
                        offsetY = 0f
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.CenterFocusStrong, contentDescription = "Reset View", tint = EvaGold)
                }
            }
        }

        // Map Info Badge (Flight, Origin, Destination)
        Surface(
            color = Color.Black.copy(alpha = 0.6f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = flightNumber,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = EvaGold
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$originCode ($originCity) → $destCode ($destCity)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White
                )
            }
        }
    }
}
