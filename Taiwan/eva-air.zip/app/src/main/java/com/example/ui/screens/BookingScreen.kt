package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.FlightLand
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppLanguage
import com.example.data.i18n.Translations
import com.example.data.models.Airport
import com.example.data.models.Currency
import com.example.data.models.FareOption
import com.example.data.models.Flight
import com.example.data.models.Trip
import com.example.ui.components.AnimatedAircraftRouteCanvas
import com.example.ui.theme.EvaGold
import com.example.ui.theme.EvaGreen
import com.example.ui.theme.EvaMint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class TripType { ROUND_TRIP, ONE_WAY, MULTI_CITY }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    airportsMap: Map<String, Airport>,
    currentLanguage: AppLanguage,
    currentCurrency: Currency,
    onSearchFlights: (String, String) -> List<Flight>,
    onConfirmBooking: (String, String, String, String, String, String, String) -> Trip,
    onBookingSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    var tripType by remember { mutableStateOf(TripType.ROUND_TRIP) }
    var originCode by remember { mutableStateOf("TPE") }
    var destCode by remember { mutableStateOf("NRT") }
    var travelDate by remember { mutableStateOf("18 SEP 2026") }
    var passengerCount by remember { mutableStateOf(1) }
    var selectedCabinClass by remember { mutableStateOf("Royal Laurel Class") }

    // Screen States: FORM -> SEARCHING -> RESULTS -> CONFIRMED
    var bookingStage by remember { mutableStateOf("FORM") } // FORM, SEARCHING, RESULTS, CONFIRMED
    var searchResults by remember { mutableStateOf<List<Flight>>(emptyList()) }
    var selectedFlight by remember { mutableStateOf<Flight?>(null) }
    var selectedFareOption by remember { mutableStateOf<FareOption?>(null) }
    var confirmedTrip by remember { mutableStateOf<Trip?>(null) }

    // Airport Selector Modal State
    var showAirportSelector by remember { mutableStateOf(false) }
    var selectorTargetIsOrigin by remember { mutableStateOf(true) }

    // Date Picker Modal State
    var showDatePicker by remember { mutableStateOf(false) }

    // Comparison Bottom Sheet State
    var showComparisonSheet by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("booking_screen")
    ) {
        when (bookingStage) {
            "FORM" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "Book Your Flight" else "預訂航班",
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Trip Type Switcher
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TripType.entries.forEach { type ->
                                val isSelected = type == tripType
                                Surface(
                                    onClick = { tripType = type },
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (isSelected) EvaGreen else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier.padding(vertical = 10.dp)
                                    ) {
                                        Text(
                                            text = when (type) {
                                                TripType.ROUND_TRIP -> Translations.get("booking.round_trip", currentLanguage)
                                                TripType.ONE_WAY -> Translations.get("booking.one_way", currentLanguage)
                                                TripType.MULTI_CITY -> Translations.get("booking.multi_city", currentLanguage)
                                            },
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // FROM / TO Selector Card
                    item {
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                // FROM Field
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectorTargetIsOrigin = true
                                            showAirportSelector = true
                                        }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = EvaGreen, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(Translations.get("booking.from", currentLanguage), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        val orig = airportsMap[originCode]
                                        Text("${orig?.cityEn} (${orig?.code})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

                                // Swap Icon
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(EvaGreen.copy(alpha = 0.15f))
                                            .clickable {
                                                val temp = originCode
                                                originCode = destCode
                                                destCode = temp
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.SwapHoriz, contentDescription = "Swap", tint = EvaGreen)
                                    }
                                }

                                // TO Field
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectorTargetIsOrigin = false
                                            showAirportSelector = true
                                        }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.FlightLand, contentDescription = null, tint = EvaGreen, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(Translations.get("booking.to", currentLanguage), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        val dest = airportsMap[destCode]
                                        Text("${dest?.cityEn} (${dest?.code})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    }
                                }
                            }
                        }
                    }

                    // DATE & PASSENGERS Card
                    item {
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { showDatePicker = true }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = EvaGreen, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(Translations.get("booking.dates", currentLanguage), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(travelDate, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = EvaGreen, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(Translations.get("booking.passengers", currentLanguage), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("$passengerCount Adult", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                    }
                                }
                            }
                        }
                    }

                    // Search Button
                    item {
                        Button(
                            onClick = {
                                bookingStage = "SEARCHING"
                                scope.launch {
                                    delay(2000) // 2s realistic flight search animation
                                    searchResults = onSearchFlights(originCode, destCode)
                                    bookingStage = "RESULTS"
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EvaGreen),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("search_flights_button")
                        ) {
                            Text(
                                text = Translations.get("booking.search", currentLanguage),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }

            "SEARCHING" -> {
                // Flight Search Scene Animation
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        AnimatedAircraftRouteCanvas(
                            modifier = Modifier.fillMaxWidth(0.9f),
                            height = 140.dp,
                            routeColor = EvaMint,
                            aircraftColor = EvaGold
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "$originCode → $destCode",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = EvaGreen
                        )
                        Text(
                            text = Translations.get("booking.searching", currentLanguage),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            "RESULTS" -> {
                // Flight Search Results List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "$originCode → $destCode Results",
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${searchResults.size} direct flights found • $travelDate",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            OutlinedButton(
                                onClick = { showComparisonSheet = true },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Compare", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    items(searchResults) { flight ->
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("EVA AIR ${flight.flightNumber}", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = EvaGreen))
                                    Surface(color = EvaGreen.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp)) {
                                        Text("NONSTOP • ${flight.aircraft}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = EvaGreen), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(flight.departureTime, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black))
                                        Text(flight.origin.cityEn, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(flight.duration, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Icon(Icons.Default.Flight, contentDescription = null, tint = EvaGold, modifier = Modifier.size(20.dp))
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(flight.arrivalTime, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black))
                                        Text(flight.destination.cityEn, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)

                                // Fare Class Options Buttons
                                Text("SELECT CABIN FARE:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(8.dp))

                                flight.fareOptions.forEach { fare ->
                                    Surface(
                                        onClick = {
                                            selectedFlight = flight
                                            selectedFareOption = fare
                                            val newTrip = onConfirmBooking(
                                                originCode,
                                                destCode,
                                                flight.flightNumber,
                                                travelDate,
                                                flight.departureTime,
                                                fare.cabinNameEn,
                                                "12A"
                                            )
                                            confirmedTrip = newTrip
                                            bookingStage = "CONFIRMED"
                                        },
                                        shape = RoundedCornerShape(16.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(fare.cabinNameEn, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                                Text("Baggage: ${fare.baggageAllowance} • ${fare.refundPolicy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }

                                            Text(
                                                currentCurrency.formatPrice(fare.priceTwd),
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EvaGreen)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "CONFIRMED" -> {
                // Booking Confirmation Animated View
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(EvaGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Confirmed", tint = Color.White, modifier = Modifier.size(48.dp))
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = Translations.get("booking.ready", currentLanguage),
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = EvaGreen
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "PNR Reference: ${confirmedTrip?.pnr ?: "BR92X8"}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        AnimatedAircraftRouteCanvas(
                            modifier = Modifier.fillMaxWidth(0.9f),
                            height = 100.dp,
                            routeColor = EvaMint,
                            aircraftColor = EvaGold
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                bookingStage = "FORM"
                                onBookingSuccess()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EvaGreen),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text("View Boarding Pass in My Trips", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Smart Airport Selector Full Screen Modal
        if (showAirportSelector) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Translations.get("booking.select_airport", currentLanguage), style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
                        IconButton(onClick = { showAirportSelector = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(Translations.get("booking.popular", currentLanguage), style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = EvaGreen))

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(airportsMap.values.toList()) { airport ->
                            Surface(
                                onClick = {
                                    if (selectorTargetIsOrigin) originCode = airport.code else destCode = airport.code
                                    showAirportSelector = false
                                },
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(EvaGreen.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(airport.code, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = EvaGreen))
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(if (currentLanguage == AppLanguage.EN) airport.cityEn else airport.cityZh, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                        Text(if (currentLanguage == AppLanguage.EN) airport.nameEn else airport.nameZh, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Travel Date Picker Calendar Modal
        if (showDatePicker) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Select Travel Date", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
                        IconButton(onClick = { showDatePicker = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("SEPTEMBER 2026", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EvaGreen))

                    Spacer(modifier = Modifier.height(16.dp))

                    val sampleDates = listOf("14 SEP", "15 SEP", "16 SEP", "17 SEP", "18 SEP", "19 SEP", "20 SEP")
                    sampleDates.forEach { dateStr ->
                        Surface(
                            onClick = {
                                travelDate = dateStr + " 2026"
                                showDatePicker = false
                            },
                            shape = RoundedCornerShape(16.dp),
                            color = if (dateStr in travelDate) EvaGreen else MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(dateStr, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = if (dateStr in travelDate) Color.White else MaterialTheme.colorScheme.onSurface))
                                Text("From TWD 11,888", style = MaterialTheme.typography.bodyMedium.copy(color = if (dateStr in travelDate) EvaGold else EvaGreen))
                            }
                        }
                    }
                }
            }
        }

        // Flight Comparison Bottom Sheet
        if (showComparisonSheet) {
            ModalBottomSheet(
                onDismissRequest = { showComparisonSheet = false },
                sheetState = rememberModalBottomSheetState()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(Translations.get("booking.compare", currentLanguage), style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ATTRIBUTES", style = MaterialTheme.typography.labelSmall, color = EvaGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Aircraft", style = MaterialTheme.typography.bodySmall)
                            Text("Baggage", style = MaterialTheme.typography.bodySmall)
                            Text("Refund", style = MaterialTheme.typography.bodySmall)
                            Text("Miles", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ECONOMY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Boeing 787", style = MaterialTheme.typography.bodySmall)
                            Text("23kg x 1", style = MaterialTheme.typography.bodySmall)
                            Text("With Fee", style = MaterialTheme.typography.bodySmall)
                            Text("1,850 mi", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ROYAL LAUREL", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = EvaGreen))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Boeing 787", style = MaterialTheme.typography.bodySmall)
                            Text("32kg x 2", style = MaterialTheme.typography.bodySmall)
                            Text("Full Refund", style = MaterialTheme.typography.bodySmall)
                            Text("6,500 mi", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
