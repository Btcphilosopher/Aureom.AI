package com.example.data.models

import androidx.annotation.DrawableRes

enum class JourneyState(val labelEn: String, val labelZh: String) {
    NO_TRIP("No Trip", "無預訂行程"),
    BOOKED("14 Days Before", "已訂位 - 出發前"),
    CHECK_IN_OPEN("24 Hours Before", "報到開放中"),
    CHECKED_IN("Checked In", "完成報到"),
    AT_AIRPORT("At Airport", "抵達機場"),
    BOARDING("Boarding Now", "登機中"),
    AIRBORNE("Airborne", "飛行中"),
    ARRIVED("Arrived", "已抵達")
}

enum class Currency(val code: String, val symbol: String, val rateToTwd: Double) {
    TWD("TWD", "NT$", 1.0),
    USD("USD", "$", 0.031),
    GBP("GBP", "£", 0.024),
    JPY("JPY", "¥", 4.65),
    EUR("EUR", "€", 0.028),
    CAD("CAD", "CA$", 0.042),
    AUD("AUD", "AU$", 0.046);

    fun formatPrice(amountTwd: Int): String {
        val converted = amountTwd * rateToTwd
        return when (this) {
            TWD, JPY -> "$symbol${String.format("%,d", converted.toInt())}"
            else -> "$symbol${String.format("%,.0f", converted)}"
        }
    }
}

data class Airport(
    val code: String,
    val cityEn: String,
    val cityZh: String,
    val nameEn: String,
    val nameZh: String,
    val country: String,
    val imageDesc: String = ""
)

data class FareOption(
    val cabinClass: String,
    val cabinNameEn: String,
    val cabinNameZh: String,
    val priceTwd: Int,
    val baggageAllowance: String,
    val seatSelection: String,
    val mealIncluded: Boolean,
    val mileageEarned: Int,
    val refundPolicy: String
)

data class Flight(
    val id: String,
    val flightNumber: String,
    val origin: Airport,
    val destination: Airport,
    val departureTime: String,
    val arrivalTime: String,
    val duration: String,
    val aircraft: String,
    val fareOptions: List<FareOption>
)

data class Trip(
    val id: String,
    val pnr: String,
    val flightNumber: String,
    val origin: Airport,
    val destination: Airport,
    val departureDate: String,
    val departureTime: String,
    val arrivalTime: String,
    val seatNumber: String,
    val gate: String,
    val terminal: String,
    val boardingGroup: String,
    val passengerName: String,
    val classType: String,
    val status: String,
    val journeyState: JourneyState,
    val baggageTag: String
)

data class BoardingPass(
    val id: String,
    val pnr: String,
    val passengerName: String,
    val flightNumber: String,
    val originCode: String,
    val originCityEn: String,
    val originCityZh: String,
    val destCode: String,
    val destCityEn: String,
    val destCityZh: String,
    val departureTime: String,
    val departureDate: String,
    val gate: String,
    val seat: String,
    val boardingGroup: String,
    val classType: String,
    val qrCodePayload: String
)

data class BaggageStep(
    val titleEn: String,
    val titleZh: String,
    val location: String,
    val time: String,
    val isDone: Boolean
)

data class BaggageItem(
    val tagNumber: String,
    val currentStatusEn: String,
    val currentStatusZh: String,
    val originCode: String,
    val destCode: String,
    val steps: List<BaggageStep>
)

data class Destination(
    val id: String,
    val cityEn: String,
    val cityZh: String,
    val countryEn: String,
    val countryZh: String,
    val airportCode: String,
    val flightTime: String,
    val startingFareTwd: Int,
    val taglineEn: String,
    val taglineZh: String,
    val bestSeason: String,
    val lat: Double,
    val lng: Double
)

data class Offer(
    val id: String,
    val originCode: String,
    val destCode: String,
    val destCityEn: String,
    val destCityZh: String,
    val fareTwd: Int,
    val cabinClass: String,
    val validDates: String,
    val milesEarned: Int,
    val tag: String
)

data class LoyaltyAccount(
    val memberName: String,
    val memberNumber: String,
    val tier: String,
    val milesBalance: Int,
    val milesToNextTier: Int,
    val nextTierName: String,
    val expiryDate: String
)

data class LiveFlightStatus(
    val flightNumber: String,
    val originCode: String,
    val destCode: String,
    val originCity: String,
    val destCity: String,
    val statusEn: String,
    val statusZh: String,
    val scheduledDeparture: String,
    val estimatedDeparture: String,
    val gate: String,
    val altitudeFt: Int,
    val speedKmh: Int,
    val remainingMinutes: Int,
    val progressPercent: Float,
    val aircraft: String
)

data class CabinFeature(
    val titleEn: String,
    val titleZh: String,
    val descriptionEn: String,
    val descriptionZh: String
)

data class Cabin(
    val id: String,
    val nameEn: String,
    val nameZh: String,
    val taglineEn: String,
    val taglineZh: String,
    val pitch: String,
    val width: String,
    val recline: String,
    val features: List<CabinFeature>
)
