package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.EvaGold
import com.example.ui.theme.EvaGreen
import com.example.ui.theme.EvaMint
import kotlin.math.atan2

@Composable
fun AnimatedAircraftRouteCanvas(
    modifier: Modifier = Modifier,
    height: Dp = 120.dp,
    routeColor: Color = EvaMint,
    aircraftColor: Color = EvaGreen,
    showClouds: Boolean = true,
    progressOverride: Float? = null,
    isReversed: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "AircraftRouteTransition")
    val animatedProgress by infiniteTransition.animateFloat(
        initialValue = if (isReversed) 1f else 0f,
        targetValue = if (isReversed) 0f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "progress"
    )

    val currentProgress = progressOverride ?: animatedProgress

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val w = size.width
        val h = size.height

        val startX = w * 0.1f
        val startY = h * 0.75f
        val endX = w * 0.9f
        val endY = h * 0.35f
        val controlX = w * 0.5f
        val controlY = h * 0.05f

        // Draw curved flight route path
        val routePath = Path().apply {
            moveTo(startX, startY)
            quadraticTo(controlX, controlY, endX, endY)
        }

        // Draw background dashed path
        drawPath(
            path = routePath,
            color = routeColor.copy(alpha = 0.3f),
            style = Stroke(
                width = 3.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f),
                cap = StrokeCap.Round
            )
        )

        // Draw illuminated active path up to current aircraft position
        val pathMeasure = PathMeasure()
        pathMeasure.setPath(routePath, false)
        val pathLength = pathMeasure.length
        val currentDistance = pathLength * currentProgress.coerceIn(0f, 1f)

        val traveledPath = Path()
        pathMeasure.getSegment(0f, currentDistance, traveledPath, true)

        drawPath(
            path = traveledPath,
            color = routeColor,
            style = Stroke(
                width = 4.dp.toPx(),
                cap = StrokeCap.Round
            )
        )

        // Calculate aircraft position and tangent rotation angle
        val pos = pathMeasure.getPosition(currentDistance)
        val nextPos = pathMeasure.getPosition((currentDistance + 2f).coerceAtMost(pathLength))

        val tangentAngle = if (nextPos != Offset.Unspecified && pos != Offset.Unspecified) {
            val dx = nextPos.x - pos.x
            val dy = nextPos.y - pos.y
            Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        } else {
            -25f
        }

        // Draw realistic EVA Air Jet silhouette
        if (pos != Offset.Unspecified) {
            rotate(degrees = tangentAngle, pivot = pos) {
                drawAircraftSilhouette(
                    center = pos,
                    aircraftColor = aircraftColor,
                    scale = 1.0f
                )
            }
        }
    }
}

fun DrawScope.drawAircraftSilhouette(
    center: Offset,
    aircraftColor: Color,
    scale: Float = 1.0f
) {
    val sizePx = 28.dp.toPx() * scale

    withTransform({
        translate(center.x, center.y)
    }) {
        // Draw Shadow underneath
        val shadowPath = Path().apply {
            moveTo(-sizePx * 0.5f, sizePx * 0.4f)
            lineTo(sizePx * 0.4f, sizePx * 0.4f)
            lineTo(0f, sizePx * 0.7f)
            close()
        }
        drawPath(shadowPath, color = Color.Black.copy(alpha = 0.15f))

        // Main Fuselage & Wings (Boeing 787 profile)
        val aircraftPath = Path().apply {
            // Nose tip
            moveTo(sizePx * 0.7f, 0f)

            // Upper fuselage
            cubicTo(
                sizePx * 0.4f, -sizePx * 0.15f,
                -sizePx * 0.1f, -sizePx * 0.15f,
                -sizePx * 0.6f, -sizePx * 0.1f
            )

            // Tail fin
            lineTo(-sizePx * 0.8f, -sizePx * 0.5f)
            lineTo(-sizePx * 0.65f, -sizePx * 0.1f)

            // Left wing
            lineTo(-sizePx * 0.1f, -sizePx * 0.7f)
            lineTo(0.1f, -sizePx * 0.15f)

            // Lower fuselage to tail
            lineTo(-sizePx * 0.6f, sizePx * 0.1f)

            // Right wing
            lineTo(-sizePx * 0.1f, sizePx * 0.7f)
            lineTo(0.1f, sizePx * 0.15f)

            // Return to nose tip
            cubicTo(
                sizePx * 0.4f, sizePx * 0.15f,
                sizePx * 0.6f, sizePx * 0.1f,
                sizePx * 0.7f, 0f
            )
            close()
        }

        // Draw body
        drawPath(
            path = aircraftPath,
            color = aircraftColor
        )

        // Draw Wing Accent Line (EVA Emerald Green / Gold highlight)
        drawLine(
            color = EvaGold,
            start = Offset(-sizePx * 0.2f, 0f),
            end = Offset(sizePx * 0.5f, 0f),
            strokeWidth = 2.dp.toPx()
        )

        // Navigation light (red/green on wingtips)
        drawCircle(
            color = EvaMint,
            radius = 2.dp.toPx(),
            center = Offset(-sizePx * 0.1f, -sizePx * 0.7f)
        )
    }
}
