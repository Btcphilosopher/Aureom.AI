package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.i18n.AppLanguage
import com.example.data.local.BoardingPassEntity
import com.example.data.local.EvaDao
import com.example.data.local.EvaDatabase
import com.example.data.local.TripEntity
import com.example.data.local.UserPreferencesEntity
import com.example.data.models.Airport
import com.example.data.models.BaggageItem
import com.example.data.models.BaggageStep
import com.example.data.models.BoardingPass
import com.example.data.models.Cabin
import com.example.data.models.CabinFeature
import com.example.data.models.Currency
import com.example.data.models.Destination
import com.example.data.models.FareOption
import com.example.data.models.Flight
import com.example.data.models.JourneyState
import com.example.data.models.LiveFlightStatus
import com.example.data.models.LoyaltyAccount
import com.example.data.models.Offer
import com.example.data.models.Trip
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class EvaRepository(context: Context) {

    // Static Airport Database (Initialized first)
    val airports = mapOf(
        "TPE" to Airport("TPE", "Taipei", "台北", "Taiwan Taoyuan Intl", "台灣桃園國際機場", "Taiwan"),
        "NRT" to Airport("NRT", "Tokyo", "東京", "Narita Intl Airport", "成田國際機場", "Japan"),
        "LHR" to Airport("LHR", "London", "倫敦", "Heathrow Airport", "希斯洛機場", "United Kingdom"),
        "LAX" to Airport("LAX", "Los Angeles", "洛杉磯", "Los Angeles Intl", "洛杉磯國際機場", "United States"),
        "SFO" to Airport("SFO", "San Francisco", "舊金山", "San Francisco Intl", "舊金山國際機場", "United States"),
        "JFK" to Airport("JFK", "New York", "紐約", "John F. Kennedy Intl", "甘迺迪國際機場", "United States"),
        "SIN" to Airport("SIN", "Singapore", "新加坡", "Changi Airport", "樟宜機場", "Singapore"),
        "BKK" to Airport("BKK", "Bangkok", "曼谷", "Suvarnabhumi Airport", "蘇凡納布機場", "Thailand"),
        "CDG" to Airport("CDG", "Paris", "巴黎", "Charles de Gaulle", "戴高樂機場", "France"),
        "AMS" to Airport("AMS", "Amsterdam", "阿姆斯特丹", "Schiphol Airport", "史基浦機場", "Netherlands"),
        "YVR" to Airport("YVR", "Vancouver", "溫哥華", "Vancouver Intl", "溫哥華國際機場", "Canada"),
        "BNE" to Airport("BNE", "Brisbane", "布里斯本", "Brisbane Airport", "布里斯本機場", "Australia")
    )

    private val db = Room.databaseBuilder(
        context.applicationContext,
        EvaDatabase::class.java,
        "eva_air_database.db"
    ).fallbackToDestructiveMigration().build()

    private val dao: EvaDao = db.evaDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    // Reactive App State
    private val _currentLanguage = MutableStateFlow(AppLanguage.EN)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _currentCurrency = MutableStateFlow(Currency.TWD)
    val currentCurrency: StateFlow<Currency> = _currentCurrency.asStateFlow()

    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _isReducedMotion = MutableStateFlow(false)
    val isReducedMotion: StateFlow<Boolean> = _isReducedMotion.asStateFlow()

    private val _activeJourneyState = MutableStateFlow(JourneyState.BOOKED)
    val activeJourneyState: StateFlow<JourneyState> = _activeJourneyState.asStateFlow()

    private val _currentTrip = MutableStateFlow<Trip?>(null)
    val currentTrip: StateFlow<Trip?> = _currentTrip.asStateFlow()

    private val _allTrips = MutableStateFlow<List<Trip>>(emptyList())
    val allTrips: StateFlow<List<Trip>> = _allTrips.asStateFlow()

    private val _boardingPass = MutableStateFlow<BoardingPass?>(null)
    val boardingPass: StateFlow<BoardingPass?> = _boardingPass.asStateFlow()

    init {
        // Seed initial data
        scope.launch {
            dao.getUserPreferences().collect { prefs ->
                if (prefs != null) {
                    _currentLanguage.value = if (prefs.languageCode == "zh-TW") AppLanguage.ZH_TW else AppLanguage.EN
                    _currentCurrency.value = Currency.entries.firstOrNull { it.code == prefs.currencyCode } ?: Currency.TWD
                    _isDarkMode.value = prefs.isDarkMode
                    _isReducedMotion.value = prefs.isReducedMotion
                    _activeJourneyState.value = JourneyState.entries.firstOrNull { it.name == prefs.activeJourneyState } ?: JourneyState.BOOKED
                }
            }
        }
        setupDefaultTripData()
    }

    private fun setupDefaultTripData() {
        val defaultTrip = Trip(
            id = "TRIP-001",
            pnr = "BR92X8",
            flightNumber = "BR067",
            origin = airports["TPE"]!!,
            destination = airports["LHR"]!!,
            departureDate = "18 SEP 2026",
            departureTime = "09:40",
            arrivalTime = "14:35",
            seatNumber = "12A",
            gate = "B7",
            terminal = "Terminal 2",
            boardingGroup = "GROUP 1",
            passengerName = "CHEN / WEI-TING",
            classType = "Royal Laurel Class",
            status = "CONFIRMED",
            journeyState = JourneyState.BOOKED,
            baggageTag = "BR-882910"
        )
        _currentTrip.value = defaultTrip
        _allTrips.value = listOf(defaultTrip)

        _boardingPass.value = BoardingPass(
            id = "BP-001",
            pnr = "BR92X8",
            passengerName = "CHEN / WEI-TING",
            flightNumber = "BR067",
            originCode = "TPE",
            originCityEn = "Taipei",
            originCityZh = "台北",
            destCode = "LHR",
            destCityEn = "London",
            destCityZh = "倫敦",
            departureTime = "09:40",
            departureDate = "18 SEP 2026",
            gate = "B7",
            seat = "12A",
            boardingGroup = "GROUP 1",
            classType = "Royal Laurel Class",
            qrCodePayload = "EVA|BR067|18SEP|TPE|LHR|CHEN/WEITING|12A|BR92X8"
        )
    }

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
        savePreferences()
    }

    fun setCurrency(currency: Currency) {
        _currentCurrency.value = currency
        savePreferences()
    }

    fun setDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
        savePreferences()
    }

    fun setReducedMotion(enabled: Boolean) {
        _isReducedMotion.value = enabled
        savePreferences()
    }

    fun setJourneyState(state: JourneyState) {
        _activeJourneyState.value = state
        _currentTrip.value = _currentTrip.value?.copy(journeyState = state)
        savePreferences()
    }

    private fun savePreferences() {
        scope.launch {
            dao.saveUserPreferences(
                UserPreferencesEntity(
                    id = 1,
                    languageCode = _currentLanguage.value.code,
                    currencyCode = _currentCurrency.value.code,
                    isDarkMode = _isDarkMode.value,
                    isReducedMotion = _isReducedMotion.value,
                    activeJourneyState = _activeJourneyState.value.name
                )
            )
        }
    }

    // Popular Destinations
    val popularDestinations = listOf(
        Destination("DEST-1", "Tokyo", "東京", "Japan", "日本", "NRT", "3h 25m", 11888, "Modern Elegance & Heritage", "極致時尚與千年古都", "Autumn / Spring", 35.772, 140.392),
        Destination("DEST-2", "London", "倫敦", "United Kingdom", "英國", "LHR", "14h 55m", 34800, "Royal Sophistication & Culture", "英倫皇室古典風華", "Summer", 51.470, -0.454),
        Destination("DEST-3", "Paris", "巴黎", "France", "法國", "CDG", "14h 20m", 36200, "City of Light & Culinary Excellence", "花都浪漫與頂級美饌", "Spring / Autumn", 49.009, 2.547),
        Destination("DEST-4", "Los Angeles", "洛杉磯", "United States", "美國", "LAX", "12h 10m", 32500, "Sunshine Coast & Entertainment", "陽光西岸與好萊塢風情", "Year Round", 33.942, -118.408),
        Destination("DEST-5", "San Francisco", "舊金山", "United States", "美國", "SFO", "11h 45m", 31800, "Silicon Valley & Golden Gate", "矽谷科技與金門大橋", "Summer / Autumn", 37.621, -122.379),
        Destination("DEST-6", "Singapore", "新加坡", "Singapore", "新加坡", "SIN", "4h 30m", 9800, "Garden City & Modern Hospitality", "花園城市與極致熱帶款待", "Year Round", 1.364, 103.991)
    )

    // Mock Flights Search
    fun searchFlights(originCode: String, destCode: String): List<Flight> {
        val orig = airports[originCode] ?: airports["TPE"]!!
        val dest = airports[destCode] ?: airports["NRT"]!!

        return listOf(
            Flight(
                id = "FL-198",
                flightNumber = "BR198",
                origin = orig,
                destination = dest,
                departureTime = "08:50",
                arrivalTime = "13:15",
                duration = "3h 25m",
                aircraft = "Boeing 787-10 Dreamliner",
                fareOptions = listOf(
                    FareOption("Economy", "Economy Class", "經濟艙", 11888, "23kg x 1", "Standard", true, 1850, "Refundable with fee"),
                    FareOption("Premium Economy", "Premium Economy", "豪華經濟艙", 18888, "23kg x 2", "Preferred", true, 3200, "Change free"),
                    FareOption("Royal Laurel", "Royal Laurel Class", "皇璽桂冠艙", 38800, "32kg x 2", "Any Seat Free", true, 6500, "Full Refundable")
                )
            ),
            Flight(
                id = "FL-196",
                flightNumber = "BR196",
                origin = orig,
                destination = dest,
                departureTime = "14:20",
                arrivalTime = "18:45",
                duration = "3h 25m",
                aircraft = "Boeing 777-300ER",
                fareOptions = listOf(
                    FareOption("Economy", "Economy Class", "經濟艙", 10888, "23kg x 1", "Standard", true, 1850, "Refundable with fee"),
                    FareOption("Premium Economy", "Premium Economy", "豪華經濟艙", 17500, "23kg x 2", "Preferred", true, 3200, "Change free"),
                    FareOption("Royal Laurel", "Royal Laurel Class", "皇璽桂冠艙", 36500, "32kg x 2", "Any Seat Free", true, 6500, "Full Refundable")
                )
            )
        )
    }

    // Editorial Offers
    val offers = listOf(
        Offer("OFF-1", "TPE", "NRT", "Tokyo Narita", "東京成田", 11888, "Royal Laurel Available", "Valid Sep - Nov 2026", 1850, "POPULAR"),
        Offer("OFF-2", "TPE", "LHR", "London Heathrow", "倫敦希斯洛", 34800, "Premium Economy", "Autumn Special", 6200, "LUXURY"),
        Offer("OFF-3", "TPE", "CDG", "Paris CDG", "巴黎戴高樂", 36200, "Royal Laurel Class", "Gourmet Dining Included", 7100, "FEATURED"),
        Offer("OFF-4", "TPE", "LAX", "Los Angeles", "洛杉磯", 32500, "Economy / Premium", "Direct Nonstop", 5800, "BEST SELLER")
    )

    // Loyalty Account
    val loyaltyAccount = LoyaltyAccount(
        memberName = "CHEN / WEI-TING",
        memberNumber = "889-102-941",
        tier = "GOLD",
        milesBalance = 42850,
        milesToNextTier = 8150,
        nextTierName = "DIAMOND",
        expiryDate = "31 DEC 2027"
    )

    // Live Flight Status Mock
    fun getLiveFlightStatus(query: String): LiveFlightStatus {
        return LiveFlightStatus(
            flightNumber = if (query.isNotBlank()) query.uppercase() else "BR067",
            originCode = "TPE",
            destCode = "LHR",
            originCity = "Taipei",
            destCity = "London",
            statusEn = "AIRBORNE - ON TIME",
            statusZh = "飛行中 - 準時發車",
            scheduledDeparture = "09:40",
            estimatedDeparture = "09:40",
            gate = "B7",
            altitudeFt = 36000,
            speedKmh = 890,
            remainingMinutes = 402,
            progressPercent = 0.68f,
            aircraft = "Boeing 787-10 Dreamliner (B-17812)"
        )
    }

    // Baggage Info Mock
    val baggageItem = BaggageItem(
        tagNumber = "BR-882910",
        currentStatusEn = "LOADED ON AIRCRAFT ✓",
        currentStatusZh = "已裝載至班機貨艙 ✓",
        originCode = "TPE",
        destCode = "LHR",
        steps = listOf(
            BaggageStep("Checked in at Terminal 2", "於第二航廈完成托運", "TPE", "07:45", true),
            BaggageStep("Security Screening Passed", "安檢掃描通過", "TPE", "08:12", true),
            BaggageStep("Loaded on BR067", "已裝載至 BR067 班機", "TPE", "09:10", true),
            BaggageStep("In Transit", "空中運輸中", "EN ROUTE", "09:40", true),
            BaggageStep("Arrival & Baggage Carousel 4", "抵達與 4 號行李轉盤發放", "LHR", "14:50 (EST)", false)
        )
    )

    // Cabins Detail
    val cabins = listOf(
        Cabin(
            id = "royal",
            nameEn = "Royal Laurel Class",
            nameZh = "皇璽桂冠艙",
            taglineEn = "Private Suite & Reverse Herringbone Lie-Flat Seats",
            taglineZh = "獨立隱密包廂與 180 度全平躺座椅",
            pitch = "82 inches",
            width = "26 inches",
            recline = "180° Full Flat",
            features = listOf(
                CabinFeature("Gourmet Dining", "星級名廚美饌", "Curated menus by Michelin chefs with Dom Pérignon & Din Tai Fung", "米其林星級主廚精心打造，搭配頂級香檳與鼎泰豐名菜"),
                CabinFeature("Ferragamo Amenity Kit", "菲拉格慕過夜包", "Exclusive Salvatore Ferragamo luxury amenity items", "義大利精品 Salvatore Ferragamo 專屬奢華軟綿過夜包"),
                CabinFeature("OLED Touch Screen", "超高畫質觸控螢幕", "18-inch HD touch screen with noise-canceling headphones", "18 吋高畫質觸控大螢幕與主動式降噪耳機")
            )
        ),
        Cabin(
            id = "premium_econ",
            nameEn = "Premium Economy Class",
            nameZh = "豪華經濟艙",
            taglineEn = "Spacious Ergonomic Comfort & Dedicated Service",
            taglineZh = "寬敞人體工學座椅與專屬優質服務",
            pitch = "38 inches",
            width = "19.5 inches",
            recline = "8 inches",
            features = listOf(
                CabinFeature("Extra Legroom", "寬敞舒適伸展空間", "Generous seat pitch with adjustable headrest and footrest", "超大椅距與多段式可調頭靠、腿靠"),
                CabinFeature("Dedicated Dining", "精選風味餐點", "Premium meals served with fine wine and Taiwanese tea", "專屬精緻套餐與台灣高山名茶、佳釀")
            )
        ),
        Cabin(
            id = "economy",
            nameEn = "Economy Class",
            nameZh = "經濟艙",
            taglineEn = "Warm Taiwanese Hospitality & Modern Entertainment",
            taglineZh = "溫馨台灣款待與新一代個人娛樂系統",
            pitch = "32 inches",
            width = "18 inches",
            recline = "6 inches",
            features = listOf(
                CabinFeature("Personal HD Display", "個人高畫質螢幕", "12-inch touch screen with over 500 movies and games", "12 吋個人觸控螢幕，包含逾 500 部影音娛樂"),
                CabinFeature("Inflight Wi-Fi", "機上高空 Wi-Fi", "High-speed satellite connectivity across long-haul routes", "長程航線高速衛星網路連線")
            )
        )
    )

    fun createNewBooking(
        originCode: String,
        destCode: String,
        flightNumber: String,
        date: String,
        time: String,
        classType: String,
        seat: String
    ): Trip {
        val orig = airports[originCode] ?: airports["TPE"]!!
        val dest = airports[destCode] ?: airports["NRT"]!!
        val newTrip = Trip(
            id = "TRIP-${System.currentTimeMillis() % 10000}",
            pnr = "BR${(1000..9999).random()}",
            flightNumber = flightNumber,
            origin = orig,
            destination = dest,
            departureDate = date,
            departureTime = time,
            arrivalTime = "18:00",
            seatNumber = seat,
            gate = "A5",
            terminal = "Terminal 2",
            boardingGroup = "GROUP 2",
            passengerName = "CHEN / WEI-TING",
            classType = classType,
            status = "CONFIRMED",
            journeyState = JourneyState.BOOKED,
            baggageTag = "BR-${(100000..999999).random()}"
        )
        _currentTrip.value = newTrip
        _allTrips.value = listOf(newTrip) + _allTrips.value

        _boardingPass.value = BoardingPass(
            id = "BP-${newTrip.id}",
            pnr = newTrip.pnr,
            passengerName = newTrip.passengerName,
            flightNumber = newTrip.flightNumber,
            originCode = orig.code,
            originCityEn = orig.cityEn,
            originCityZh = orig.cityZh,
            destCode = dest.code,
            destCityEn = dest.cityEn,
            destCityZh = dest.cityZh,
            departureTime = newTrip.departureTime,
            departureDate = newTrip.departureDate,
            gate = newTrip.gate,
            seat = newTrip.seatNumber,
            boardingGroup = newTrip.boardingGroup,
            classType = newTrip.classType,
            qrCodePayload = "EVA|${newTrip.flightNumber}|${newTrip.departureDate}|${orig.code}|${dest.code}|${newTrip.passengerName}|${newTrip.seatNumber}|${newTrip.pnr}"
        )

        return newTrip
    }
}
