package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppLanguage
import com.example.data.i18n.Translations
import com.example.data.models.Currency
import com.example.data.models.JourneyState
import com.example.data.models.Offer
import com.example.data.models.Trip
import com.example.ui.components.InteractiveHeroCanvas
import com.example.ui.theme.EvaGold
import com.example.ui.theme.EvaGreen
import com.example.ui.theme.EvaMint
import com.example.ui.theme.GlassSurfaceBorder

@Composable
fun HomeScreen(
    trip: Trip?,
    activeJourneyState: JourneyState,
    currentLanguage: AppLanguage,
    currentCurrency: Currency,
    offers: List<Offer>,
    onNavigateToBook: () -> Unit,
    onNavigateToTrips: () -> Unit,
    onNavigateToBoardingPass: () -> Unit,
    onNavigateToFlightStatus: () -> Unit,
    onNavigateToBaggage: () -> Unit,
    onNavigateToDestinations: () -> Unit,
    onNavigateToLoyalty: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("home_screen"),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Top Greeting Section
        item {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                Text(
                    text = Translations.get("home.greeting.afternoon", currentLanguage),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = Translations.get("home.where_to", currentLanguage),
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Interactive Atmospheric Aviation Hero
        item {
            InteractiveHeroCanvas(
                onAircraftClick = onNavigateToDestinations
            )
        }

        // Dynamic Journey-Aware Contextual Card
        item {
            ContextualJourneyCard(
                trip = trip,
                journeyState = activeJourneyState,
                currentLanguage = currentLanguage,
                onBookClick = onNavigateToBook,
                onManageClick = onNavigateToTrips,
                onBoardingPassClick = onNavigateToBoardingPass,
                onCheckInClick = onNavigateToTrips
            )
        }

        // Primary Action Grid (Book, My Trips, Check-in, Boarding Pass, Flight Status, Baggage)
        item {
            Column {
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "PRIMARY ACTIONS" else "快捷服務",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    ),
                    color = EvaGreen,
                    modifier = Modifier.padding(bottom = 10.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionButton(
                        title = Translations.get("nav.book", currentLanguage),
                        icon = Icons.Default.FlightTakeoff,
                        onClick = onNavigateToBook,
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionButton(
                        title = Translations.get("nav.trips", currentLanguage),
                        icon = Icons.Default.AirplaneTicket,
                        onClick = onNavigateToTrips,
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionButton(
                        title = Translations.get("home.boarding_pass", currentLanguage),
                        icon = Icons.Default.QrCode2,
                        onClick = onNavigateToBoardingPass,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickActionButton(
                        title = Translations.get("home.flight_status", currentLanguage),
                        icon = Icons.Default.Flight,
                        onClick = onNavigateToFlightStatus,
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionButton(
                        title = Translations.get("trips.baggage", currentLanguage),
                        icon = Icons.Default.Luggage,
                        onClick = onNavigateToBaggage,
                        modifier = Modifier.weight(1f)
                    )
                    QuickActionButton(
                        title = Translations.get("loyalty.title", currentLanguage),
                        icon = Icons.Default.Star,
                        onClick = onNavigateToLoyalty,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Editorial Luxury Offers Carousel
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "LUXURY TRAVEL OFFERS" else "精選奢華特惠航線",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "View All" else "查看全部",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = EvaGreen,
                        modifier = Modifier.clickable { onNavigateToDestinations() }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(offers) { offer ->
                        EditorialOfferCard(
                            offer = offer,
                            currentLanguage = currentLanguage,
                            currentCurrency = currentCurrency,
                            onBookOffer = onNavigateToBook
                        )
                    }
                }
            }
        }

        // EVA Experience Preview Cards
        item {
            Column(modifier = Modifier.padding(bottom = 24.dp)) {
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "THE EVA EXPERIENCE" else "長榮尊榮體驗",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToBook() }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(EvaGreen.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restaurant,
                                contentDescription = null,
                                tint = EvaGreen,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (currentLanguage == AppLanguage.EN) "Michelin-Starred Inflight Dining" else "米其林星級機上美饌",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (currentLanguage == AppLanguage.EN) "Pre-order gourmet meals up to 21 days before departure" else "出發前 21 天即可預選星級餐點與精選名茶",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = EvaGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ContextualJourneyCard(
    trip: Trip?,
    journeyState: JourneyState,
    currentLanguage: AppLanguage,
    onBookClick: () -> Unit,
    onManageClick: () -> Unit,
    onBoardingPassClick: () -> Unit,
    onCheckInClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(32.dp),
        color = Color(0x1AFFFFFF),
        border = androidx.compose.foundation.BorderStroke(1.dp, GlassSurfaceBorder),
        shadowElevation = 12.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("contextual_journey_card")
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            if (journeyState == JourneyState.NO_TRIP || trip == null) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                ) {
                    Text(
                        text = Translations.get("home.start_journey", currentLanguage),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Explore 60+ global destinations with EVA Air" else "探索長榮航空全球超過 60 個航點",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(
                        onClick = onBookClick,
                        colors = ButtonDefaults.buttonColors(containerColor = EvaGreen),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth(0.85f)
                    ) {
                        Text(
                            text = Translations.get("home.book_flight", currentLanguage),
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            } else {
                // Top Flight Codes Header (TPE <---> LHR)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = trip.origin.code,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = (-1).sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "${trip.origin.cityEn} / ${trip.origin.cityZh}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = trip.flightNumber,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = EvaMint,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Box(
                            modifier = Modifier
                                .width(48.dp)
                                .height(1.dp)
                                .background(Color.White.copy(alpha = 0.3f))
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = trip.destination.code,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = (-1).sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "${trip.destination.cityEn} / ${trip.destination.cityZh}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Middle Details Grid (Departure / Seat)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        color = Color(0x0FFFFFFF),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "DEPARTURE / 啟程",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = Color.White.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = trip.departureDate,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = trip.departureTime,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }

                    Surface(
                        color = Color(0x0FFFFFFF),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "SEAT / 座位",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = Color.White.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = trip.seatNumber,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                            Text(
                                text = trip.classType,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Status & Terminal Info
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(EvaMint)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ON TIME / 準點",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = EvaMint
                            )
                        )
                    }

                    Text(
                        text = "TERMINAL ${trip.terminal} / GATE ${trip.gate}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Primary Action Button (Boarding Pass / Check-in)
                Button(
                    onClick = if (journeyState == JourneyState.CHECK_IN_OPEN) onCheckInClick else onBoardingPassClick,
                    colors = ButtonDefaults.buttonColors(containerColor = EvaGreen),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (journeyState == JourneyState.CHECK_IN_OPEN) "CHECK-IN NOW / 立即報到" else "BOARDING PASS / 登機證",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionButton(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0x1AFFFFFF),
        border = androidx.compose.foundation.BorderStroke(1.dp, GlassSurfaceBorder),
        shadowElevation = 4.dp,
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(EvaMint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = EvaMint,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                color = Color.White
            )
        }
    }
}

@Composable
fun EditorialOfferCard(
    offer: Offer,
    currentLanguage: AppLanguage,
    currentCurrency: Currency,
    onBookOffer: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = Modifier
            .width(220.dp)
            .clickable { onBookOffer() }
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(EvaGreen, Color(0xFF00381C))
                        )
                    )
                    .padding(12.dp)
            ) {
                Surface(
                    color = EvaGold,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = offer.tag,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
                        color = Color.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Column(modifier = Modifier.align(Alignment.BottomStart)) {
                    Text(
                        text = "TPE → ${offer.destCode}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) offer.destCityEn else offer.destCityZh,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }

            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = offer.cabinClass,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "From ${currentCurrency.formatPrice(offer.fareTwd)}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EvaGreen)
                )
            }
        }
    }
}
