package com.example.data.i18n

enum class AppLanguage(val code: String, val label: String) {
    EN("en", "English"),
    ZH_TW("zh-TW", "繁體中文")
}

object Translations {
    private val dictionary = mapOf(
        "app.name" to mapOf("en" to "EVA Air", "zh-TW" to "長榮航空"),
        "home.greeting.afternoon" to mapOf("en" to "Good afternoon", "zh-TW" to "午安"),
        "home.greeting.morning" to mapOf("en" to "Good morning", "zh-TW" to "早安"),
        "home.greeting.evening" to mapOf("en" to "Good evening", "zh-TW" to "晚上好"),
        "home.where_to" to mapOf("en" to "Where will you fly next?", "zh-TW" to "下一趟旅程，想飛去哪裡？"),
        "home.start_journey" to mapOf("en" to "START YOUR JOURNEY", "zh-TW" to "開啟您的全新旅程"),
        "home.book_flight" to mapOf("en" to "Book a flight", "zh-TW" to "預訂航班"),
        "home.manage_trip" to mapOf("en" to "Manage Trip", "zh-TW" to "管理行程"),
        "home.boarding_pass" to mapOf("en" to "Boarding Pass", "zh-TW" to "登機證"),
        "home.flight_status" to mapOf("en" to "Flight Status", "zh-TW" to "航班動態"),
        "home.check_in_now" to mapOf("en" to "CHECK IN NOW", "zh-TW" to "立即報到"),
        "home.gate" to mapOf("en" to "Gate", "zh-TW" to "登機門"),
        "home.boarding_in" to mapOf("en" to "Boarding in", "zh-TW" to "登機倒數"),
        "home.travel_mode" to mapOf("en" to "TRAVEL MODE", "zh-TW" to "旅程隨行模式"),
        "home.in_flight" to mapOf("en" to "You're on your way", "zh-TW" to "飛行中 - 祝您旅途愉快"),
        "home.arrived" to mapOf("en" to "Welcome to", "zh-TW" to "歡迎抵達"),
        
        // Nav
        "nav.home" to mapOf("en" to "HOME", "zh-TW" to "首頁"),
        "nav.book" to mapOf("en" to "BOOK", "zh-TW" to "預訂"),
        "nav.trips" to mapOf("en" to "MY TRIPS", "zh-TW" to "我的行程"),
        "nav.flights" to mapOf("en" to "FLIGHTS", "zh-TW" to "航班"),
        "nav.account" to mapOf("en" to "ACCOUNT", "zh-TW" to "帳戶"),
        
        // Booking
        "booking.round_trip" to mapOf("en" to "ROUND TRIP", "zh-TW" to "來回"),
        "booking.one_way" to mapOf("en" to "ONE WAY", "zh-TW" to "單程"),
        "booking.multi_city" to mapOf("en" to "MULTI-CITY", "zh-TW" to "多角化航線"),
        "booking.from" to mapOf("en" to "FROM", "zh-TW" to "出發地"),
        "booking.to" to mapOf("en" to "TO", "zh-TW" to "目的地"),
        "booking.dates" to mapOf("en" to "DATES", "zh-TW" to "日期"),
        "booking.passengers" to mapOf("en" to "PASSENGERS", "zh-TW" to "乘客"),
        "booking.cabin" to mapOf("en" to "CABIN", "zh-TW" to "艙等"),
        "booking.promo" to mapOf("en" to "PROMO CODE", "zh-TW" to "優惠代碼"),
        "booking.search" to mapOf("en" to "SEARCH FLIGHTS", "zh-TW" to "搜尋航班"),
        "booking.searching" to mapOf("en" to "Searching flights...", "zh-TW" to "正在搜尋航班..."),
        "booking.select_airport" to mapOf("en" to "Select Airport", "zh-TW" to "選擇機場"),
        "booking.recent" to mapOf("en" to "Recent Airports", "zh-TW" to "最近搜尋"),
        "booking.popular" to mapOf("en" to "Popular Destinations", "zh-TW" to "熱門航點"),
        "booking.compare" to mapOf("en" to "Compare Fares", "zh-TW" to "比較艙等與票價"),
        "booking.confirm" to mapOf("en" to "Confirm Booking", "zh-TW" to "確認預訂"),
        "booking.ready" to mapOf("en" to "You're ready to fly.", "zh-TW" to "旅程已準備就緒。"),

        // Fares
        "cabin.royal_laurel" to mapOf("en" to "Royal Laurel Class", "zh-TW" to "皇璽桂冠艙"),
        "cabin.business" to mapOf("en" to "Business Class", "zh-TW" to "商務艙"),
        "cabin.premium_econ" to mapOf("en" to "Premium Economy", "zh-TW" to "豪華經濟艙"),
        "cabin.economy" to mapOf("en" to "Economy Class", "zh-TW" to "經濟艙"),

        // Trips
        "trips.title" to mapOf("en" to "My Journeys", "zh-TW" to "我的行程列表"),
        "trips.timeline" to mapOf("en" to "Journey Timeline", "zh-TW" to "旅程時間軸"),
        "trips.confirmed" to mapOf("en" to "CONFIRMED", "zh-TW" to "已確認"),
        "trips.baggage" to mapOf("en" to "Baggage Tracking", "zh-TW" to "行李追蹤"),

        // Loyalty
        "loyalty.title" to mapOf("en" to "INFINITY MILEAGELANDS", "zh-TW" to "無限萬哩遊"),
        "loyalty.card" to mapOf("en" to "Digital Membership Card", "zh-TW" to "數位會員卡"),
        "loyalty.miles" to mapOf("en" to "miles", "zh-TW" to "哩程"),
        "loyalty.to_next" to mapOf("en" to "miles to Diamond", "zh-TW" to "哩里程即可升等鑽石卡"),

        // Flight Status & Map
        "status.search_hint" to mapOf("en" to "Flight number or city (e.g. BR067)", "zh-TW" to "請輸入航班號或城市 (如 BR067)"),
        "status.airborne" to mapOf("en" to "AIRBORNE", "zh-TW" to "飛行中"),
        "status.altitude" to mapOf("en" to "Altitude", "zh-TW" to "高度"),
        "status.speed" to mapOf("en" to "Speed", "zh-TW" to "速度"),
        "status.remaining" to mapOf("en" to "Remaining", "zh-TW" to "剩餘飛行時間"),

        // Destinations
        "destinations.fly_to" to mapOf("en" to "FLY THERE", "zh-TW" to "搭乘長榮飛往"),
        "destinations.explore" to mapOf("en" to "Explore Destinations", "zh-TW" to "探索全球航點"),

        // Common & Settings
        "settings.language" to mapOf("en" to "Language", "zh-TW" to "語言"),
        "settings.currency" to mapOf("en" to "Currency", "zh-TW" to "貨幣"),
        "settings.dark_mode" to mapOf("en" to "Dark Mode", "zh-TW" to "深色模式"),
        "settings.reduced_motion" to mapOf("en" to "Reduced Motion", "zh-TW" to "減緩動態效果"),
        "settings.demo_simulator" to mapOf("en" to "Journey State Simulator", "zh-TW" to "旅程狀態模擬器"),
        "offline.indicator" to mapOf("en" to "OFFLINE MODE - CACHED DATA", "zh-TW" to "離線模式 - 已顯示快取資料")
    )

    fun get(key: String, language: AppLanguage): String {
        return dictionary[key]?.get(language.code) ?: dictionary[key]?.get("en") ?: key
    }
}
