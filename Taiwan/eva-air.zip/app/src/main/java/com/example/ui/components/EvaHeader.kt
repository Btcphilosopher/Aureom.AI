package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplaneTicket
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppLanguage
import com.example.data.models.Currency
import com.example.data.models.JourneyState
import com.example.ui.theme.EvaGold
import com.example.ui.theme.EvaGreen
import com.example.ui.theme.EvaMint
import com.example.ui.theme.GlassSurfaceBorder
import com.example.ui.theme.GlassSurfaceDark

@Composable
fun EvaHeader(
    currentLanguage: AppLanguage,
    currentCurrency: Currency,
    activeJourneyState: JourneyState,
    onLanguageToggle: (AppLanguage) -> Unit,
    onCurrencySelect: (Currency) -> Unit,
    onJourneyStateSelect: (JourneyState) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptics = LocalHapticFeedback.current
    var langMenuExpanded by remember { mutableStateOf(false) }
    var currMenuExpanded by remember { mutableStateOf(false) }
    var stateMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Top Main Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // EVA AIR / Greeting Block
            Column(
                modifier = Modifier
                    .weight(1f)
                    .testTag("header_brand")
            ) {
                Text(
                    text = "EVA AIR / 長榮航空",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    ),
                    color = Color.White.copy(alpha = 0.7f)
                )
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Good afternoon, " else "午安，",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Light
                        ),
                        color = Color.White
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Jason" else "傑森",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold
                        ),
                        color = EvaMint
                    )
                }

                Text(
                    text = if (currentLanguage == AppLanguage.EN) "Next flight in 18h • BR067" else "下一班機 18 小時後起飛 • BR067",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = Color.White.copy(alpha = 0.6f)
                )
            }

            // User Avatar Pill with Ring Border
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                    .background(EvaGreen),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "J",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Quick Controls Row: Language, Currency, Journey State Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Language Switcher Pill
            Box {
                Surface(
                    onClick = { langMenuExpanded = true },
                    shape = RoundedCornerShape(20.dp),
                    color = GlassSurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassSurfaceBorder),
                    modifier = Modifier.testTag("language_toggle_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Language",
                            modifier = Modifier.size(13.dp),
                            tint = EvaMint
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "EN" else "繁中",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                            color = Color.White
                        )
                    }
                }

                DropdownMenu(
                    expanded = langMenuExpanded,
                    onDismissRequest = { langMenuExpanded = false }
                ) {
                    AppLanguage.entries.forEach { lang ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = lang.label,
                                    fontWeight = if (lang == currentLanguage) FontWeight.Bold else FontWeight.Normal,
                                    color = if (lang == currentLanguage) EvaMint else MaterialTheme.colorScheme.onSurface
                                )
                            },
                            onClick = {
                                onLanguageToggle(lang)
                                langMenuExpanded = false
                            }
                        )
                    }
                }
            }

            // Currency Switcher
            Box {
                Surface(
                    onClick = { currMenuExpanded = true },
                    shape = RoundedCornerShape(20.dp),
                    color = GlassSurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassSurfaceBorder),
                    modifier = Modifier.testTag("currency_selector_button")
                ) {
                    Text(
                        text = currentCurrency.code,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                DropdownMenu(
                    expanded = currMenuExpanded,
                    onDismissRequest = { currMenuExpanded = false }
                ) {
                    Currency.entries.forEach { curr ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "${curr.code} (${curr.symbol})",
                                    fontWeight = if (curr == currentCurrency) FontWeight.Bold else FontWeight.Normal,
                                    color = if (curr == currentCurrency) EvaMint else MaterialTheme.colorScheme.onSurface
                                )
                            },
                            onClick = {
                                onCurrencySelect(curr)
                                currMenuExpanded = false
                            }
                        )
                    }
                }
            }

            // Journey State Simulator Dropdown
            Box {
                Surface(
                    onClick = { stateMenuExpanded = true },
                    shape = RoundedCornerShape(20.dp),
                    color = EvaMint.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EvaMint.copy(alpha = 0.4f)),
                    modifier = Modifier.testTag("state_simulator_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "State Simulator",
                            modifier = Modifier.size(13.dp),
                            tint = EvaMint
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) activeJourneyState.labelEn else activeJourneyState.labelZh,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp),
                            color = EvaMint
                        )
                    }
                }

                DropdownMenu(
                    expanded = stateMenuExpanded,
                    onDismissRequest = { stateMenuExpanded = false }
                ) {
                    Text(
                        text = "JOURNEY STATE SIMULATOR",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        ),
                        color = EvaMint,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                    JourneyState.entries.forEach { state ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (currentLanguage == AppLanguage.EN) state.labelEn else state.labelZh,
                                    fontWeight = if (state == activeJourneyState) FontWeight.Bold else FontWeight.Normal,
                                    color = if (state == activeJourneyState) EvaMint else MaterialTheme.colorScheme.onSurface
                                )
                            },
                            onClick = {
                                onJourneyStateSelect(state)
                                stateMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}
