package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.i18n.AppLanguage
import com.example.data.i18n.Translations
import com.example.data.models.Currency
import com.example.data.models.Destination
import com.example.ui.components.InteractiveMapCanvas
import com.example.ui.theme.EvaGold
import com.example.ui.theme.EvaGreen

@Composable
fun DestinationExplorerScreen(
    destinations: List<Destination>,
    currentLanguage: AppLanguage,
    currentCurrency: Currency,
    onBookDestination: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var flyThereTarget by remember { mutableStateOf<Destination?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("destination_explorer_screen")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = Translations.get("destinations.title", currentLanguage),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Discover world-class destinations connected from Taipei" else "探索自台北直飛連通之全球頂級航點",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(destinations) { dest ->
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { flyThereTarget = dest }
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(EvaGreen, Color(0xFF003D20))
                                        )
                                    )
                                    .padding(12.dp)
                            ) {
                                Surface(
                                    color = EvaGold,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.align(Alignment.TopStart)
                                ) {
                                    Text(
                                        dest.airportCode,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp),
                                        color = Color.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                Column(modifier = Modifier.align(Alignment.BottomStart)) {
                                    Text(
                                        if (currentLanguage == AppLanguage.EN) dest.cityEn else dest.cityZh,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                    Text(
                                        if (currentLanguage == AppLanguage.EN) dest.countryEn else dest.countryZh,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                }
                            }

                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    "Flight: ${dest.flightTime}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    "From ${currentCurrency.formatPrice(dest.startingFareTwd)}",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EvaGreen)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = { flyThereTarget = dest },
                                    colors = ButtonDefaults.buttonColors(containerColor = EvaGreen),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.FlightTakeoff, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(Translations.get("destinations.fly_there", currentLanguage), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // "Fly There" Signature 3D Animated Modal Overlay
        if (flyThereTarget != null) {
            val target = flyThereTarget!!
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("FLY THERE — ${target.cityEn.uppercase()}", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black, color = EvaGreen))
                        IconButton(onClick = { flyThereTarget = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    InteractiveMapCanvas(
                        originCode = "TPE",
                        destCode = target.airportCode,
                        originCity = "Taipei",
                        destCity = target.cityEn,
                        flightNumber = "BR ${target.airportCode}",
                        progressOverride = 0.65f
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(if (currentLanguage == AppLanguage.EN) target.taglineEn else target.taglineZh, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Best Season: ${target.bestSeason} • Direct Nonstop Flight", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            val code = target.airportCode
                            flyThereTarget = null
                            onBookDestination(code)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EvaGreen),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Text("Book Taipei (TPE) to ${target.cityEn}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }
}
