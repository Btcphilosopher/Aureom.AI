package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.i18n.AppLanguage
import com.example.data.models.BoardingPass
import com.example.data.models.Currency
import com.example.data.models.JourneyState
import com.example.data.models.Trip
import com.example.data.repository.EvaRepository
import com.example.ui.components.BottomNavBar
import com.example.ui.components.DigitalBoardingPassCard
import com.example.ui.components.EvaHeader
import com.example.ui.components.NavTab
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.BaggageScreen
import com.example.ui.screens.BookingScreen
import com.example.ui.screens.DestinationExplorerScreen
import com.example.ui.screens.EvaExperienceScreen
import com.example.ui.screens.FlightStatusScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoyaltyScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.TripsScreen
import com.example.ui.theme.EvaGreen
import com.example.ui.theme.EvaTheme

class MainActivity : ComponentActivity() {

    private lateinit var repository: EvaRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        repository = EvaRepository(this)

        setContent {
            val currentLanguage by repository.currentLanguage.collectAsState()
            val currentCurrency by repository.currentCurrency.collectAsState()
            val isDarkMode by repository.isDarkMode.collectAsState()
            val isReducedMotion by repository.isReducedMotion.collectAsState()
            val activeJourneyState by repository.activeJourneyState.collectAsState()
            val currentTrip by repository.currentTrip.collectAsState()
            val allTrips by repository.allTrips.collectAsState()
            val boardingPass by repository.boardingPass.collectAsState()

            EvaTheme(darkTheme = isDarkMode) {
                EvaAppContent(
                    repository = repository,
                    currentLanguage = currentLanguage,
                    currentCurrency = currentCurrency,
                    isDarkMode = isDarkMode,
                    isReducedMotion = isReducedMotion,
                    activeJourneyState = activeJourneyState,
                    currentTrip = currentTrip,
                    allTrips = allTrips,
                    boardingPass = boardingPass
                )
            }
        }
    }
}

enum class DetailScreen {
    NONE, BOARDING_PASS, BAGGAGE, DESTINATION_EXPLORER, LOYALTY, EXPERIENCE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EvaAppContent(
    repository: EvaRepository,
    currentLanguage: AppLanguage,
    currentCurrency: Currency,
    isDarkMode: Boolean,
    isReducedMotion: Boolean,
    activeJourneyState: JourneyState,
    currentTrip: Trip?,
    allTrips: List<Trip>,
    boardingPass: BoardingPass?
) {
    var isShowingSplash by remember { mutableStateOf(true) }
    var selectedTab by remember { mutableStateOf(NavTab.HOME) }
    var activeDetailScreen by remember { mutableStateOf(DetailScreen.NONE) }

    if (isShowingSplash) {
        SplashScreen(
            onSplashFinished = { isShowingSplash = false }
        )
    } else {
        Scaffold(
            topBar = {
                if (activeDetailScreen == DetailScreen.NONE) {
                    Column(
                        modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)
                    ) {
                        EvaHeader(
                            currentLanguage = currentLanguage,
                            currentCurrency = currentCurrency,
                            activeJourneyState = activeJourneyState,
                            onLanguageToggle = { repository.setLanguage(it) },
                            onCurrencySelect = { repository.setCurrency(it) },
                            onJourneyStateSelect = { repository.setJourneyState(it) }
                        )
                    }
                } else {
                    TopAppBar(
                        title = {
                            Text(
                                text = when (activeDetailScreen) {
                                    DetailScreen.BOARDING_PASS -> "Digital Boarding Pass"
                                    DetailScreen.BAGGAGE -> "Real-time Baggage Tracker"
                                    DetailScreen.DESTINATION_EXPLORER -> "Destination Explorer"
                                    DetailScreen.LOYALTY -> "Infinity MileageLands"
                                    DetailScreen.EXPERIENCE -> "The EVA Air Experience"
                                    else -> ""
                                },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { activeDetailScreen = DetailScreen.NONE }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        )
                    )
                }
            },
            bottomBar = {
                if (activeDetailScreen == DetailScreen.NONE) {
                    BottomNavBar(
                        selectedTab = selectedTab,
                        currentLanguage = currentLanguage,
                        onTabSelected = { selectedTab = it }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (activeDetailScreen != DetailScreen.NONE) {
                    when (activeDetailScreen) {
                        DetailScreen.BOARDING_PASS -> {
                            if (boardingPass != null) {
                                Box(modifier = Modifier.padding(16.dp)) {
                                    DigitalBoardingPassCard(
                                        boardingPass = boardingPass,
                                        currentLanguage = currentLanguage
                                    )
                                }
                            }
                        }
                        DetailScreen.BAGGAGE -> {
                            BaggageScreen(
                                baggageItem = repository.baggageItem,
                                currentLanguage = currentLanguage
                            )
                        }
                        DetailScreen.DESTINATION_EXPLORER -> {
                            DestinationExplorerScreen(
                                destinations = repository.popularDestinations,
                                currentLanguage = currentLanguage,
                                currentCurrency = currentCurrency,
                                onBookDestination = { destCode ->
                                    activeDetailScreen = DetailScreen.NONE
                                    selectedTab = NavTab.BOOK
                                }
                            )
                        }
                        DetailScreen.LOYALTY -> {
                            LoyaltyScreen(
                                account = repository.loyaltyAccount,
                                currentLanguage = currentLanguage
                            )
                        }
                        DetailScreen.EXPERIENCE -> {
                            EvaExperienceScreen(
                                cabins = repository.cabins,
                                currentLanguage = currentLanguage
                            )
                        }
                        else -> {}
                    }
                } else {
                    AnimatedContent(
                        targetState = selectedTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "TabTransition"
                    ) { tab ->
                        when (tab) {
                            NavTab.HOME -> {
                                HomeScreen(
                                    trip = currentTrip,
                                    activeJourneyState = activeJourneyState,
                                    currentLanguage = currentLanguage,
                                    currentCurrency = currentCurrency,
                                    offers = repository.offers,
                                    onNavigateToBook = { selectedTab = NavTab.BOOK },
                                    onNavigateToTrips = { selectedTab = NavTab.TRIPS },
                                    onNavigateToBoardingPass = { activeDetailScreen = DetailScreen.BOARDING_PASS },
                                    onNavigateToFlightStatus = { selectedTab = NavTab.FLIGHTS },
                                    onNavigateToBaggage = { activeDetailScreen = DetailScreen.BAGGAGE },
                                    onNavigateToDestinations = { activeDetailScreen = DetailScreen.DESTINATION_EXPLORER },
                                    onNavigateToLoyalty = { activeDetailScreen = DetailScreen.LOYALTY }
                                )
                            }
                            NavTab.BOOK -> {
                                BookingScreen(
                                    airportsMap = repository.airports,
                                    currentLanguage = currentLanguage,
                                    currentCurrency = currentCurrency,
                                    onSearchFlights = { orig, dest -> repository.searchFlights(orig, dest) },
                                    onConfirmBooking = { orig, dest, flight, date, time, cls, seat ->
                                        repository.createNewBooking(orig, dest, flight, date, time, cls, seat)
                                    },
                                    onBookingSuccess = {
                                        selectedTab = NavTab.TRIPS
                                    }
                                )
                            }
                            NavTab.TRIPS -> {
                                TripsScreen(
                                    trips = allTrips,
                                    currentLanguage = currentLanguage,
                                    onNavigateToBoardingPass = { activeDetailScreen = DetailScreen.BOARDING_PASS },
                                    onNavigateToBaggage = { activeDetailScreen = DetailScreen.BAGGAGE }
                                )
                            }
                            NavTab.FLIGHTS -> {
                                FlightStatusScreen(
                                    currentLanguage = currentLanguage,
                                    onSearchStatus = { repository.getLiveFlightStatus(it) }
                                )
                            }
                            NavTab.ACCOUNT -> {
                                AccountScreen(
                                    currentLanguage = currentLanguage,
                                    currentCurrency = currentCurrency,
                                    isDarkMode = isDarkMode,
                                    isReducedMotion = isReducedMotion,
                                    onLanguageToggle = { repository.setLanguage(it) },
                                    onCurrencySelect = { repository.setCurrency(it) },
                                    onDarkModeToggle = { repository.setDarkMode(it) },
                                    onReducedMotionToggle = { repository.setReducedMotion(it) },
                                    onNavigateToLoyalty = { activeDetailScreen = DetailScreen.LOYALTY },
                                    onNavigateToExperience = { activeDetailScreen = DetailScreen.EXPERIENCE }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
