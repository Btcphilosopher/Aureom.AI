package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI Brand Palette
val EvaGreen = Color(0xFF005C42)
val EvaDarkGreen = Color(0xFF003E2D)
val EvaDeepBackground = Color(0xFF002A1F)
val EvaForestGreen = Color(0xFF001F17)
val EvaMint = Color(0xFF00FF9D) // Neon Immersive Accent
val EvaNeonGlow = Color(0xFF00FF9D)
val EvaGold = Color(0xFFC5A359)
val EvaGoldWarm = Color(0xFFE5C158)

// Glassmorphism Surfaces
val GlassSurfaceDark = Color(0x14FFFFFF)
val GlassSurfaceBorder = Color(0x26FFFFFF)
val GlassCardBackground = Color(0x1F005C42)

// General Colors
val EvaSoftGrey = Color(0xFFF4F6F5)
val EvaCardBgLight = Color(0xFFFFFFFF)
val EvaCardBgDark = Color(0xFF003828)
val EvaSurfaceDark = Color(0xFF004834)
val EvaBorderLight = Color(0xFFE2E8E5)
val EvaBorderDark = Color(0x3300FF9D)
val EvaTextPrimary = Color(0xFF111815)
val EvaTextSecondary = Color(0xFF5E6D66)
val EvaTextLight = Color(0xFFFFFFFF)

