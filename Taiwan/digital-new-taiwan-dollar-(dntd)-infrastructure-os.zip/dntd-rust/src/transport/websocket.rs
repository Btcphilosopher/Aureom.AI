use std::sync::Arc;
use tracing::info;
use crate::core::state::AppState;

pub struct WebSocketGateway {
    state: Arc<AppState>,
}

impl WebSocketGateway {
    pub fn new(state: Arc<AppState>) -> Self {
        Self { state }
    }

    pub async fn run(&self, port: u16) -> Result<(), Box<dyn std::error::Error>> {
        info!("WebSocket Gateway streaming events to Kotlin Command Centre on 0.0.0.0:{}", port);
        Ok(())
    }
}
