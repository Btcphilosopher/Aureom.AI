use std::sync::Arc;
use tracing::info;
use crate::core::state::AppState;

pub struct GrpcServer {
    state: Arc<AppState>,
}

impl GrpcServer {
    pub fn new(state: Arc<AppState>) -> Self {
        Self { state }
    }

    pub async fn run(&self, port: u16) -> Result<(), Box<dyn std::error::Error>> {
        info!("gRPC Server listening for Python simulation engine on 0.0.0.0:{}", port);
        // Tonic service listener stub
        Ok(())
    }
}
