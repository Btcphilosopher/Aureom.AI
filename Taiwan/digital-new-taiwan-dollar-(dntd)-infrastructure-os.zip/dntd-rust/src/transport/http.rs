use std::sync::Arc;
use axum::{routing::get, Router, Json};
use tracing::info;
use crate::core::state::AppState;
use crate::monitoring::health::SystemHealthReport;

pub struct HttpServer {
    state: Arc<AppState>,
}

impl HttpServer {
    pub fn new(state: Arc<AppState>) -> Self {
        Self { state }
    }

    pub async fn run(&self, port: u16) -> Result<(), Box<dyn std::error::Error>> {
        let app = Router::new()
            .route("/health", get(|| async { Json(SystemHealthReport::all_online()) }))
            .route("/metrics/diagnostics", get(|state: axum::extract::State<Arc<AppState>>| async move {
                let snap = state.state_cache.get_snapshot();
                Json(snap)
            }))
            .with_state(self.state.clone());

        info!("HTTP REST Gateway initialized on 0.0.0.0:{}", port);
        let listener = tokio::net::TcpListener::bind(format!("0.0.0.0:{}", port)).await?;
        axum::serve(listener, app).await?;
        Ok(())
    }
}
