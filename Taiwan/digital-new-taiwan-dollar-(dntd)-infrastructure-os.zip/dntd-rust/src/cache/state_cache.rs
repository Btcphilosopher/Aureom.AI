use std::sync::Arc;
use dashmap::DashMap;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BankLiquidity {
    pub bank_id: String,
    pub bank_name: String,
    pub balance_minor: i64,
    pub reserve_ratio: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemSnapshot {
    pub cbdc_supply_minor: i64,
    pub total_payment_volume_minor: i64,
    pub settlement_volume_count: u64,
    pub active_wallets: u32,
    pub risk_level: String,
    pub settlement_latency_p50_ms: f64,
    pub settlement_latency_p95_ms: f64,
    pub settlement_latency_p99_ms: f64,
}

pub struct StateCache {
    pub cbdc_supply_minor: Arc<DashMap<String, i64>>,
    pub bank_liquidities: Arc<DashMap<String, BankLiquidity>>,
    pub wallet_count: Arc<DashMap<String, u32>>,
    pub system_metrics: Arc<DashMap<String, f64>>,
}

impl StateCache {
    pub fn new() -> Self {
        let cache = Self {
            cbdc_supply_minor: Arc::new(DashMap::new()),
            bank_liquidities: Arc::new(DashMap::new()),
            wallet_count: Arc::new(DashMap::new()),
            system_metrics: Arc::new(DashMap::new()),
        };

        // Seed initial simulation cache values
        cache.cbdc_supply_minor.insert("TOTAL_SUPPLY".to_string(), 84_200_000_000_00); // NT$84.2B in minor units
        
        cache.bank_liquidities.insert("BANK_A".to_string(), BankLiquidity {
            bank_id: "BANK_A".to_string(),
            bank_name: "Bank A (Taiwan Financial)".to_string(),
            balance_minor: 120_000_000_000_00,
            reserve_ratio: 0.18,
        });

        cache.bank_liquidities.insert("BANK_B".to_string(), BankLiquidity {
            bank_id: "BANK_B".to_string(),
            bank_name: "Bank B (Formosa Commerce)".to_string(),
            balance_minor: 91_000_000_000_00,
            reserve_ratio: 0.15,
        });

        cache.bank_liquidities.insert("BANK_C".to_string(), BankLiquidity {
            bank_id: "BANK_C".to_string(),
            bank_name: "Bank C (Taipei Metro)".to_string(),
            balance_minor: 65_000_000_000_00,
            reserve_ratio: 0.12,
        });

        cache.wallet_count.insert("ACTIVE_COUNT".to_string(), 48200);

        cache.system_metrics.insert("SETTLEMENT_LATENCY_P50".to_string(), 31.0);
        cache.system_metrics.insert("SETTLEMENT_LATENCY_P95".to_string(), 54.0);
        cache.system_metrics.insert("SETTLEMENT_LATENCY_P99".to_string(), 88.0);

        cache
    }

    pub fn get_snapshot(&self) -> SystemSnapshot {
        let supply = self.cbdc_supply_minor.get("TOTAL_SUPPLY").map(|v| *v).unwrap_or(84_200_000_000_00);
        let active_wallets = self.wallet_count.get("ACTIVE_COUNT").map(|v| *v).unwrap_or(48200);

        SystemSnapshot {
            cbdc_supply_minor: supply,
            total_payment_volume_minor: 184_920_000_00,
            settlement_volume_count: 9421,
            active_wallets,
            risk_level: "LOW".to_string(),
            settlement_latency_p50_ms: 31.0,
            settlement_latency_p95_ms: 54.0,
            settlement_latency_p99_ms: 88.0,
        }
    }
}
