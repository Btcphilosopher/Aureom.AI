use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EventMetadata {
    pub event_id: String,
    pub timestamp: i64,
    pub source: String,
    pub schema_version: String,
    pub correlation_id: String,
    pub sequence_number: u64,
    pub signature: Option<String>,
    pub nonce: String,
}

impl Default for EventMetadata {
    fn default() -> Self {
        Self {
            event_id: uuid::Uuid::new_v4().to_string(),
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_millis() as i64,
            source: "rust-overlay".to_string(),
            schema_version: "1.0.0".to_string(),
            correlation_id: uuid::Uuid::new_v4().to_string(),
            sequence_number: 0,
            signature: None,
            nonce: uuid::Uuid::new_v4().to_string(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", content = "payload")]
pub enum DntdEvent {
    MoneyIssued {
        metadata: EventMetadata,
        transaction_id: String,
        target_bank_id: String,
        amount_minor: i64,
        reason: String,
    },
    MoneyRedeemed {
        metadata: EventMetadata,
        transaction_id: String,
        bank_id: String,
        amount_minor: i64,
    },
    PaymentCreated {
        metadata: EventMetadata,
        payment_id: String,
        sender_id: String,
        recipient_id: String,
        amount_minor: i64,
    },
    PaymentSettled {
        metadata: EventMetadata,
        payment_id: String,
        sender_id: String,
        recipient_id: String,
        amount_minor: i64,
        latency_ms: i64,
    },
    RiskAlert {
        metadata: EventMetadata,
        risk_id: String,
        title: String,
        severity: String,
        description: String,
        source_node: String,
    },
    LiquidityUpdate {
        metadata: EventMetadata,
        bank_id: String,
        balance_minor: i64,
        reserve_ratio: f64,
    },
}

impl DntdEvent {
    pub fn metadata(&self) -> &EventMetadata {
        match self {
            DntdEvent::MoneyIssued { metadata, .. } => metadata,
            DntdEvent::MoneyRedeemed { metadata, .. } => metadata,
            DntdEvent::PaymentCreated { metadata, .. } => metadata,
            DntdEvent::PaymentSettled { metadata, .. } => metadata,
            DntdEvent::RiskAlert { metadata, .. } => metadata,
            DntdEvent::LiquidityUpdate { metadata, .. } => metadata,
        }
    }

    pub fn stream_category(&self) -> &'static str {
        match self {
            DntdEvent::MoneyIssued { .. } | DntdEvent::MoneyRedeemed { .. } => "MONETARY",
            DntdEvent::PaymentCreated { .. } => "PAYMENT",
            DntdEvent::PaymentSettled { .. } => "LEDGER",
            DntdEvent::RiskAlert { .. } => "RISK",
            DntdEvent::LiquidityUpdate { .. } => "LIQUIDITY",
        }
    }
}
