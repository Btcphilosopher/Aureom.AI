use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use tokio::sync::broadcast;
use tracing::{info, warn};

use crate::events::event::DntdEvent;

pub struct EventBus {
    sender: broadcast::Sender<DntdEvent>,
    sequence_counter: Arc<AtomicU64>,
}

impl EventBus {
    pub fn new(capacity: usize) -> Self {
        let (sender, _) = broadcast::channel(capacity);
        Self {
            sender,
            sequence_counter: Arc::new(AtomicU64::new(1)),
        }
    }

    pub fn publish(&self, mut event: DntdEvent) -> Result<u64, String> {
        let seq = self.sequence_counter.fetch_add(1, Ordering::SeqCst);
        
        // Mutate sequence number in metadata
        match &mut event {
            DntdEvent::MoneyIssued { metadata, .. } => metadata.sequence_number = seq,
            DntdEvent::MoneyRedeemed { metadata, .. } => metadata.sequence_number = seq,
            DntdEvent::PaymentCreated { metadata, .. } => metadata.sequence_number = seq,
            DntdEvent::PaymentSettled { metadata, .. } => metadata.sequence_number = seq,
            DntdEvent::RiskAlert { metadata, .. } => metadata.sequence_number = seq,
            DntdEvent::LiquidityUpdate { metadata, .. } => metadata.sequence_number = seq,
        }

        match self.sender.send(event) {
            Ok(receivers) => {
                info!(seq = seq, receivers = receivers, "Event published to bus");
                Ok(seq)
            }
            Err(e) => {
                warn!("No active subscribers for event: {}", e);
                Ok(seq)
            }
        }
    }

    pub fn subscribe(&self) -> broadcast::Receiver<DntdEvent> {
        self.sender.subscribe()
    }
}
