use std::sync::Arc;
use tokio::sync::broadcast;
use tracing::info;

use crate::events::bus::EventBus;
use crate::events::event::DntdEvent;

pub struct EventRouter {
    ledger_tx: broadcast::Sender<DntdEvent>,
    payment_tx: broadcast::Sender<DntdEvent>,
    monetary_tx: broadcast::Sender<DntdEvent>,
    risk_tx: broadcast::Sender<DntdEvent>,
}

impl EventRouter {
    pub fn new(bus: Arc<EventBus>) -> Self {
        let (ledger_tx, _) = broadcast::channel(1000);
        let (payment_tx, _) = broadcast::channel(1000);
        let (monetary_tx, _) = broadcast::channel(1000);
        let (risk_tx, _) = broadcast::channel(1000);

        let router = Self {
            ledger_tx,
            payment_tx,
            monetary_tx,
            risk_tx,
        };

        // Start background dispatch loop
        let mut rx = bus.subscribe();
        let l_tx = router.ledger_tx.clone();
        let p_tx = router.payment_tx.clone();
        let m_tx = router.monetary_tx.clone();
        let r_tx = router.risk_tx.clone();

        tokio::spawn(async move {
            while let Ok(event) = rx.recv().await {
                match event.stream_category() {
                    "LEDGER" => { let _ = l_tx.send(event); }
                    "PAYMENT" => { let _ = p_tx.send(event); }
                    "MONETARY" => { let _ = m_tx.send(event); }
                    "RISK" => { let _ = r_tx.send(event); }
                    _ => {
                        let _ = p_tx.send(event);
                    }
                }
            }
        });

        info!("EventRouter initialized and listening to EventBus");
        router
    }

    pub fn subscribe_stream(&self, category: &str) -> broadcast::Receiver<DntdEvent> {
        match category.to_uppercase().as_str() {
            "LEDGER" => self.ledger_tx.subscribe(),
            "PAYMENT" => self.payment_tx.subscribe(),
            "MONETARY" => self.monetary_tx.subscribe(),
            "RISK" => self.risk_tx.subscribe(),
            _ => self.payment_tx.subscribe(),
        }
    }
}
