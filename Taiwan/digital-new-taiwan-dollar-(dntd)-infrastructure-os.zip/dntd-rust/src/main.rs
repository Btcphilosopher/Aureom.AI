mod core;
mod transport;
mod events;
mod telemetry;
mod security;
mod bridge;
mod cache;
mod monitoring;

use std::sync::Arc;
use tracing::info;
use tracing_subscriber::FmtSubscriber;

use crate::core::state::AppState;
use crate::transport::http::HttpServer;
use crate::transport::grpc::GrpcServer;
use crate::transport::websocket::WebSocketGateway;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Initialize structured tracing
    let subscriber = FmtSubscriber::builder()
        .with_max_level(tracing::Level::INFO)
        .finish();
    tracing::subscriber::set_global_default(subscriber)
        .expect("Failed to set tracing subscriber");

    info!("------------------------------------------------------------");
    info!("DIGITAL NEW TAIWAN DOLLAR (DNTD) - RUST SYSTEM OVERLAY v1.0");
    info!("Taiwan Central Bank Synthetic Infrastructure Layer");
    info!("------------------------------------------------------------");

    let app_state = Arc::new(AppState::new());

    let http_server = HttpServer::new(app_state.clone());
    let grpc_server = GrpcServer::new(app_state.clone());
    let ws_gateway = WebSocketGateway::new(app_state.clone());

    tokio::select! {
        res = http_server.run(8080) => if let Err(e) = res { eprintln!("HTTP error: {}", e); },
        res = grpc_server.run(50051) => if let Err(e) = res { eprintln!("gRPC error: {}", e); },
        res = ws_gateway.run(8081) => if let Err(e) = res { eprintln!("WS error: {}", e); },
    }

    Ok(())
}
