use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Money {
    pub currency: String,
    pub amount_minor: i64,
}

impl Money {
    pub fn dntd(amount_minor: i64) -> Self {
        Self {
            currency: "DNTD".to_string(),
            amount_minor,
        }
    }

    pub fn to_formatted_string(&self) -> String {
        let major = self.amount_minor / 100;
        let minor = (self.amount_minor % 100).abs();
        format!("NT$ {}.{:02}", major, minor)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Wallet {
    pub wallet_id: String,
    pub owner_type: String,
    pub owner_name: String,
    pub balance: Money,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Transaction {
    pub transaction_id: String,
    pub sender_id: String,
    pub recipient_id: String,
    pub amount: Money,
    pub status: String,
    pub timestamp: i64,
    pub risk_score: f64,
    pub settlement_latency_ms: i64,
}
