use thiserror::Error;

#[derive(Error, Debug)]
pub enum DntdError {
    #[error("Transport failure: {0}")]
    TransportError(String),

    #[error("Invalid event schema: {0}")]
    InvalidEventSchema(String),

    #[error("Schema version mismatch: expected {expected}, got {found}")]
    SchemaVersionMismatch { expected: String, found: String },

    #[error("Authentication failure: {0}")]
    AuthenticationFailed(String),

    #[error("Duplicate event detected (event_id: {0})")]
    DuplicateEvent(String),

    #[error("Python simulation engine unavailable at {0}")]
    PythonEngineUnavailable(String),

    #[error("Invalid monetary amount: {0}")]
    InvalidMonetaryAmount(String),

    #[error("Internal overlay error: {0}")]
    Internal(String),
}
