use serde::Deserialize;

#[derive(Debug, Clone, Deserialize)]
pub struct AppConfig {
    pub http_port: u16,
    pub grpc_port: u16,
    pub ws_port: u16,
    pub python_engine_url: String,
    pub max_event_bus_capacity: usize,
}

impl Default for AppConfig {
    fn default() -> Self {
        Self {
            http_port: 8080,
            grpc_port: 50051,
            ws_port: 8081,
            python_engine_url: "http://127.0.0.1:50052".to_string(),
            max_event_bus_capacity: 100_000,
        }
    }
}
