use std::sync::Arc;
use crate::events::bus::EventBus;
use crate::events::router::EventRouter;
use crate::cache::state_cache::StateCache;
use crate::telemetry::collector::TelemetryCollector;
use crate::security::verification::ReplayCache;

pub struct AppState {
    pub event_bus: Arc<EventBus>,
    pub event_router: Arc<EventRouter>,
    pub state_cache: Arc<StateCache>,
    pub telemetry: Arc<TelemetryCollector>,
    pub replay_cache: Arc<ReplayCache>,
}

impl AppState {
    pub fn new() -> Self {
        let bus = Arc::new(EventBus::new(50_000));
        let router = Arc::new(EventRouter::new(bus.clone()));
        let cache = Arc::new(StateCache::new());
        let telemetry = Arc::new(TelemetryCollector::new());
        let replay = Arc::new(ReplayCache::new());

        Self {
            event_bus: bus,
            event_router: router,
            state_cache: cache,
            telemetry,
            replay_cache: replay,
        }
    }
}
