use dashmap::DashMap;
use std::sync::Arc;
use tracing::warn;

pub struct ReplayCache {
    seen_events: Arc<DashMap<String, i64>>, // event_id -> timestamp
}

impl ReplayCache {
    pub fn new() -> Self {
        Self {
            seen_events: Arc::new(DashMap::new()),
        }
    }

    /// Returns true if event is valid (not a duplicate), false if replayed
    pub fn validate_and_insert(&self, event_id: &str, timestamp: i64) -> bool {
        if self.seen_events.contains_key(event_id) {
            warn!(event_id = event_id, "Replay attack detected or duplicate event received!");
            return false;
        }

        self.seen_events.insert(event_id.to_string(), timestamp);
        true
    }

    pub fn purge_stale(&self, max_age_ms: i64) {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as i64;

        self.seen_events.retain(|_, &mut ts| (now - ts) < max_age_ms);
    }
}
