use ed25519_dalek::{SigningKey, Signature, Signer};
use ed25519_dalek::VerifyingKey;
use rand_core::OsRng;

pub struct EventSigner {
    signing_key: SigningKey,
}

impl EventSigner {
    pub fn generate() -> Self {
        let mut csprng = OsRng;
        let signing_key = SigningKey::generate(&mut csprng);
        Self { signing_key }
    }

    pub fn public_key(&self) -> VerifyingKey {
        self.signing_key.verifying_key()
    }

    pub fn sign_canonical_payload(&self, payload: &[u8]) -> String {
        let signature: Signature = self.signing_key.sign(payload);
        hex::encode(signature.to_bytes())
    }
}
