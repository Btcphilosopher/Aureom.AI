use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum OperatorRole {
    Read,
    Simulation,
    Admin,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SessionIdentity {
    pub operator_id: String,
    pub name: String,
    pub role: OperatorRole,
    pub authenticated_at: i64,
}

impl SessionIdentity {
    pub fn default_central_bank_operator() -> Self {
        Self {
            operator_id: "OP-CBC-8012".to_string(),
            name: "Taipei Central Bank Director".to_string(),
            role: OperatorRole::Admin,
            authenticated_at: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs() as i64,
        }
    }

    pub fn can_issue_cbdc(&self) -> bool {
        self.role == OperatorRole::Admin || self.role == OperatorRole::Simulation
    }
}
