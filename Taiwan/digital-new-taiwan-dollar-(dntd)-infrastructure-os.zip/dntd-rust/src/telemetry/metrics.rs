use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TechnicalTelemetry {
    pub events_per_sec: f64,
    pub messages_per_sec: f64,
    pub active_websockets: usize,
    pub grpc_latency_ms: f64,
    pub event_queue_depth: usize,
    pub dropped_events: u64,
    pub cpu_usage_pct: f64,
    pub ram_usage_mb: f64,
    pub timestamp: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonetaryTelemetry {
    pub cbdc_supply_minor: i64,
    pub payment_volume_24h_minor: i64,
    pub velocity: f64,
    pub active_wallets: u32,
    pub settlement_volume: u64,
    pub timestamp: i64,
}
