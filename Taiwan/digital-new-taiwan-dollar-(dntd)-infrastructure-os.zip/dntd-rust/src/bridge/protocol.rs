use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioSubmission {
    pub scenario_id: String,
    pub cbdc_adoption_rate: f64,
    pub wallet_limit_minor: i64,
    pub remuneration_rate: f64,
    pub bank_liquidity_mode: String,
    pub simulation_speed: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScenarioResult {
    pub scenario_id: String,
    pub total_supply_minor: i64,
    pub deposit_impact_pct: f64,
    pub velocity: f64,
    pub avg_latency_ms: f64,
    pub total_transactions: u64,
}
