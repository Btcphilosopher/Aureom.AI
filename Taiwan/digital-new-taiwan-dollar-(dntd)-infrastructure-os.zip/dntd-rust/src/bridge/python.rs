use tracing::{info, error};
use crate::events::event::DntdEvent;
use crate::events::bus::EventBus;
use std::sync::Arc;

pub struct PythonBridge {
    event_bus: Arc<EventBus>,
}

impl PythonBridge {
    pub fn new(event_bus: Arc<EventBus>) -> Self {
        Self { event_bus }
    }

    pub fn receive_python_event(&self, raw_json: &str) -> Result<u64, String> {
        match serde_json::from_str::<DntdEvent>(raw_json) {
            Ok(event) => {
                info!(source = "python-engine", event_type = event.stream_category(), "Inbound event validated from Python");
                self.event_bus.publish(event)
            }
            Err(e) => {
                error!("Failed to deserialize Python event: {}", e);
                Err(format!("Malformed Python payload: {}", e))
            }
        }
    }
}
