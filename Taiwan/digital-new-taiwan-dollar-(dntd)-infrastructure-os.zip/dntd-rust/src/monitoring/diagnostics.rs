use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiagnosticMetrics {
    pub events_per_sec: f64,
    pub queue_depth: usize,
    pub p50_latency_ms: f64,
    pub p95_latency_ms: f64,
    pub p99_latency_ms: f64,
    pub memory_mb: f64,
    pub cpu_pct: f64,
    pub connected_clients: usize,
}
