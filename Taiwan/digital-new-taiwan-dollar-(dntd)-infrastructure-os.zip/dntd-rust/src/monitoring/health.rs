use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum HealthStatus {
    ONLINE,
    DEGRADED,
    OFFLINE,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemHealthReport {
    pub python_engine: HealthStatus,
    pub rust_overlay: HealthStatus,
    pub database: HealthStatus,
    pub event_bus: HealthStatus,
    pub websocket: HealthStatus,
    pub kotlin_client: HealthStatus,
    pub timestamp: i64,
}

impl SystemHealthReport {
    pub fn all_online() -> Self {
        Self {
            python_engine: HealthStatus::ONLINE,
            rust_overlay: HealthStatus::ONLINE,
            database: HealthStatus::ONLINE,
            event_bus: HealthStatus::ONLINE,
            websocket: HealthStatus::ONLINE,
            kotlin_client: HealthStatus::ONLINE,
            timestamp: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_millis() as i64,
        }
    }
}
