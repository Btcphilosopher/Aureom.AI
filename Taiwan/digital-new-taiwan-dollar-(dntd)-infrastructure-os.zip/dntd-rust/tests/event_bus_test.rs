#[cfg(test)]
mod tests {
    use dntd_rust::events::bus::EventBus;
    use dntd_rust::events::event::{DntdEvent, EventMetadata};

    #[tokio::test]
    async fn test_event_publish_subscribe() {
        let bus = EventBus::new(100);
        let mut rx = bus.subscribe();

        let event = DntdEvent::PaymentCreated {
            metadata: EventMetadata::default(),
            payment_id: "PAY-001".to_string(),
            sender_id: "WALLET-A".to_string(),
            recipient_id: "MERCHANT-B".to_string(),
            amount_minor: 25000, // NT$250.00
        };

        let seq = bus.publish(event).expect("Publish failed");
        assert!(seq > 0);

        let received = rx.recv().await.expect("Receive failed");
        if let DntdEvent::PaymentCreated { payment_id, amount_minor, .. } = received {
            assert_eq!(payment_id, "PAY-001");
            assert_eq!(amount_minor, 25000);
        } else {
            panic!("Unexpected event type");
        }
    }
}
