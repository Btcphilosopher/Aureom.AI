# Digital New Taiwan Dollar (DNTD) - Rust System Overlay

High-performance event bus, stream processor, security boundary, protocol normalisation layer, and real-time telemetry engine for the Digital New Taiwan Dollar (DNTD) central bank synthetic infrastructure.

## Architectural Responsibilities

- **High-Performance Message Bus**: Async Tokio channels & broadcast streams capable of processing 10,000+ events/sec.
- **Protocol & Event Router**: Routes events into domain streams (`LEDGER`, `PAYMENT`, `MONETARY`, `RISK`, `LIQUIDITY`).
- **Security Boundary**: Validates authentication, schema version, nonces, and optional Ed25519 signatures; enforces replay cache protection.
- **Read-Optimized State Cache**: Thread-safe `DashMap` cache providing instant snapshot queries to Kotlin UI without database roundtrips.
- **Technical Telemetry Engine**: Computes high-resolution infrastructure metrics (events/sec, gRPC latency, queue depth, memory/CPU).

## Getting Started

```bash
cargo build --release
cargo test
cargo run
```
