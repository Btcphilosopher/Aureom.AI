import time
import uuid
from typing import Dict, Optional

class MonetaryLedger:
    """
    AUTHORITATIVE DIGITAL NEW TAIWAN DOLLAR (DNTD) MONETARY LEDGER
    Python is the sole source of truth for CBDC supply and wallet balances.
    Amounts are stored strictly in minor units (int64 cents: 100 minor = NT$1.00).
    """

    def __init__(self):
        self.total_supply_minor: int = 84_200_000_000_00 # NT$84.2 Billion
        self.wallets: Dict[str, int] = {
            "CENTRAL_BANK": 100_000_000_000_00, # Reserves
            "BANK_A": 120_000_000_000_00,
            "BANK_B": 91_000_000_000_00,
            "BANK_C": 65_000_000_000_00,
            "W-TAIPEI-01": 250_000_00, # NT$250,000
            "M-TAIPEI-02": 10_000_000_00, # NT$100,000
        }
        self.transactions: Dict[str, dict] = {}

    def issue_cbdc(self, target_bank_id: str, amount_minor: int, reason: str = "Simulation Issuance") -> dict:
        if amount_minor <= 0:
            raise ValueError("Issuance amount must be positive")
        
        self.total_supply_minor += amount_minor
        current_balance = self.wallets.get(target_bank_id, 0)
        self.wallets[target_bank_id] = current_balance + amount_minor

        tx_id = f"ISSUE-{uuid.uuid4().hex[:8].upper()}"
        event = {
            "type": "MoneyIssued",
            "payload": {
                "metadata": {
                    "event_id": uuid.uuid4().hex,
                    "timestamp": int(time.time() * 1000),
                    "source": "python-engine",
                    "schema_version": "1.0.0",
                    "correlation_id": uuid.uuid4().hex,
                    "sequence_number": 0,
                    "nonce": uuid.uuid4().hex
                },
                "transaction_id": tx_id,
                "target_bank_id": target_bank_id,
                "amount_minor": amount_minor,
                "reason": reason
            }
        }
        return event

    def redeem_cbdc(self, bank_id: str, amount_minor: int) -> dict:
        current_balance = self.wallets.get(bank_id, 0)
        if current_balance < amount_minor:
            raise ValueError(f"Insufficient funds in bank {bank_id} for redemption")

        self.wallets[bank_id] = current_balance - amount_minor
        self.total_supply_minor -= amount_minor

        tx_id = f"REDEEM-{uuid.uuid4().hex[:8].upper()}"
        event = {
            "type": "MoneyRedeemed",
            "payload": {
                "metadata": {
                    "event_id": uuid.uuid4().hex,
                    "timestamp": int(time.time() * 1000),
                    "source": "python-engine",
                    "schema_version": "1.0.0",
                    "correlation_id": uuid.uuid4().hex,
                    "sequence_number": 0,
                    "nonce": uuid.uuid4().hex
                },
                "transaction_id": tx_id,
                "bank_id": bank_id,
                "amount_minor": amount_minor
            }
        }
        return event

    def process_payment(self, sender_id: str, recipient_id: str, amount_minor: int) -> dict:
        sender_bal = self.wallets.get(sender_id, 500_000_00) # Default balance if new
        if sender_bal < amount_minor:
            raise ValueError(f"Insufficient funds in wallet {sender_id}")

        self.wallets[sender_id] = sender_bal - amount_minor
        rec_bal = self.wallets.get(recipient_id, 0)
        self.wallets[recipient_id] = rec_bal + amount_minor

        tx_id = f"TX-{uuid.uuid4().hex[:8].upper()}"
        event = {
            "type": "PaymentSettled",
            "payload": {
                "metadata": {
                    "event_id": uuid.uuid4().hex,
                    "timestamp": int(time.time() * 1000),
                    "source": "python-engine",
                    "schema_version": "1.0.0",
                    "correlation_id": uuid.uuid4().hex,
                    "sequence_number": 0,
                    "nonce": uuid.uuid4().hex
                },
                "payment_id": tx_id,
                "sender_id": sender_id,
                "recipient_id": recipient_id,
                "amount_minor": amount_minor,
                "latency_ms": 28
            }
        }
        return event
