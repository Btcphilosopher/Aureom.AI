import time
import json
import logging
from ledger import MonetaryLedger

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

def main():
    logging.info("============================================================")
    logging.info("DIGITAL NEW TAIWAN DOLLAR (DNTD) - PYTHON MONETARY SIMULATION ENGINE")
    logging.info("Authoritative Economic & Ledger Source of Truth")
    logging.info("============================================================")

    ledger = MonetaryLedger()
    logging.info(f"Initial CBDC Supply: NT$ {ledger.total_supply_minor / 100:,.2f}")

    # Emit synthetic payment loop
    sample_event = ledger.process_payment("W-TAIPEI-01", "M-TAIPEI-02", 25000)
    logging.info(f"Generated Settled Event: {json.dumps(sample_event)}")

if __name__ == "__main__":
    main()
