# DIGITAL NEW TAIWAN DOLLAR (DNTD) 數位新臺幣
### Central-Bank-Grade Synthetic Research & Simulation Platform

This project implements a tri-layer central bank digital currency (CBDC) simulation architecture for the Digital New Taiwan Dollar (DNTD):

- **Python Monetary Engine**: Authoritative monetary simulation, ledger, issuance, redemption, payments, settlement, risk modelling, and economic policy logic.
- **Rust System Overlay**: High-performance event bus, stream processor, security boundary, protocol normalisation, and real-time telemetry engine.
- **Kotlin Application Framework & Command Centre**: Central bank operator dashboard, live payment flow visualisations, network map, liquidity monitoring, and research lab.

---

## Architecture Overview

```
                         KOTLIN
                    DIGITAL NTD UI
                          │
                          │ WebSocket / gRPC
                          ▼
                    RUST OVERLAY
                          │
             ┌────────────┼────────────┐
             ▼            ▼            ▼
        EVENT BUS     SECURITY      STREAMING
             │            │            │
             └────────────┼────────────┘
                          │
                          ▼
                    PYTHON ENGINE
                          │
        ┌─────────────────┼─────────────────┐
        ▼                 ▼                 ▼
      LEDGER           PAYMENTS         MONETARY
      ENGINE            ENGINE           ENGINE
        │                 │                 │
        └─────────────────┼─────────────────┘
                          ▼
                    SIMULATION STATE
```

## Money Protocol
Monetary values are never transmitted as floating point numbers. All monetary representation uses:
```protobuf
message Money {
    string currency = 1;      // "DNTD"
    int64 amount_minor = 2;   // e.g., 10000 = NT$100.00
}
```

## Running the Platform

To start the integrated environment:

```bash
make dev
```
Or with Docker Compose:
```bash
docker-compose -f docker/docker-compose.yml up --build
```
