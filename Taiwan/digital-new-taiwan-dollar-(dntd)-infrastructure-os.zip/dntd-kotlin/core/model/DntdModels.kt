package dntd.core.model

import kotlinx.serialization.Serializable

enum class Language {
    ENGLISH,
    TRADITIONAL_CHINESE
}

@Serializable
data class MoneyModel(
    val currency: String = "DNTD",
    val amountMinor: Long
)

@Serializable
sealed class DntdEvent {
    @Serializable
    data class MoneyIssued(
        val transactionId: String,
        val targetBankId: String,
        val amountMinor: Long,
        val timestamp: Long
    ) : DntdEvent()

    @Serializable
    data class PaymentSettled(
        val paymentId: String,
        val senderId: String,
        val recipientId: String,
        val amountMinor: Long,
        val latencyMs: Long,
        val timestamp: Long
    ) : DntdEvent()

    @Serializable
    data class RiskAlert(
        val riskId: String,
        val severity: String,
        val description: String,
        val timestamp: Long
    ) : DntdEvent()

    @Serializable
    data class LiquidityUpdate(
        val bankId: String,
        val balanceMinor: Long,
        val timestamp: Long
    ) : DntdEvent()
}
