package dntd.core.state

import kotlinx.serialization.Serializable

@Serializable
data class DntdSystemState(
    val cbdcSupply: Long = 84_200_000_000_00L, // Minor units (cents)
    val transactionVolume: Long = 18_492_000_000L,
    val activeWallets: Int = 48_200,
    val settlementLatency: Double = 31.0, // ms
    val riskLevel: String = "LOW",
    val systemStatus: String = "ONLINE",
    val eventsPerSec: Double = 18492.0,
    val wsLatencyMs: Double = 23.0
)
