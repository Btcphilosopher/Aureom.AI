package dntd.core.formatting

import dntd.core.model.Language

object TaiwanCurrencyFormatter {
    fun formatDntd(amountMinor: Long, language: Language = Language.TRADITIONAL_CHINESE): String {
        val major = amountMinor / 100.0
        return when {
            major >= 1_000_000_000 -> {
                val b = major / 1_000_000_000.0
                if (language == Language.TRADITIONAL_CHINESE) "NT$ ${String.format("%.1f", b)}億"
                else "NT$ ${String.format("%.1f", b)}B"
            }
            major >= 1_000_000 -> {
                val m = major / 1_000_000.0
                if (language == Language.TRADITIONAL_CHINESE) "NT$ ${String.format("%.1f", m)}萬"
                else "NT$ ${String.format("%.1f", m)}M"
            }
            else -> "NT$ ${String.format("%,.2f", major)}"
        }
    }
}
