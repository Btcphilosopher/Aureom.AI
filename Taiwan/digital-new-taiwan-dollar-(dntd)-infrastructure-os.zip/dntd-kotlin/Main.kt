package dntd

import kotlinx.coroutines.*
import dntd.core.state.DntdSystemState
import dntd.viewmodel.DntdViewModel

/**
 * Main entry point for the Digital New Taiwan Dollar (DNTD) Kotlin Operator Command Centre.
 * Connects to the Rust event overlay via WebSockets and manages Jetpack Compose state streams.
 */
fun main() = runBlocking {
    println("============================================================")
    println("DIGITAL NEW TAIWAN DOLLAR (DNTD) - KOTLIN COMMAND CENTRE")
    println("Central Bank Operator Interface & Visualisation Layer")
    println("============================================================")

    val viewModel = DntdViewModel()
    viewModel.connectRustOverlay("ws://127.0.0.1:8081")

    launch {
        viewModel.systemState.collect { state ->
            println("[UI STATE UPDATE] Supply: NT$ ${state.cbdcSupply / 100} | TxVol: ${state.transactionVolume} | Risk: ${state.riskLevel}")
        }
    }
}
