package dntd.viewmodel

import kotlinx.coroutines.flow.*
import dntd.core.state.DntdSystemState
import dntd.core.model.DntdEvent
import dntd.core.model.Language

class DntdViewModel {
    private val _systemState = MutableStateFlow(DntdSystemState())
    val systemState: StateFlow<DntdSystemState> = _systemState.asStateFlow()

    private val _language = MutableStateFlow(Language.TRADITIONAL_CHINESE)
    val language: StateFlow<Language> = _language.asStateFlow()

    private val _eventStream = MutableSharedFlow<DntdEvent>()
    val eventStream: SharedFlow<DntdEvent> = _eventStream.asSharedFlow()

    fun setLanguage(lang: Language) {
        _language.value = lang
    }

    fun connectRustOverlay(url: String) {
        println("Connecting Kotlin Coroutine Flow to Rust Overlay at $url")
    }

    fun handleIncomingEvent(event: DntdEvent) {
        when (event) {
            is DntdEvent.MoneyIssued -> {
                _systemState.update { current ->
                    current.copy(cbdcSupply = current.cbdcSupply + event.amountMinor)
                }
            }
            is DntdEvent.PaymentSettled -> {
                _systemState.update { current ->
                    current.copy(
                        transactionVolume = current.transactionVolume + event.amountMinor,
                        settlementLatency = (current.settlementLatency * 0.9) + (event.latencyMs * 0.1)
                    )
                }
            }
            is DntdEvent.RiskAlert -> {
                _systemState.update { current ->
                    current.copy(riskLevel = event.severity)
                }
            }
            else -> {}
        }
    }
}
