# Digital New Taiwan Dollar (DNTD) Master Architecture

```
                         KOTLIN
                    DIGITAL NTD UI
                          │
                          │ WebSocket / gRPC
                          ▼
                    RUST OVERLAY
                          │
             ┌────────────┼────────────┐
             ▼            ▼            ▼
        EVENT BUS     SECURITY      STREAMING
             │            │            │
             └────────────┼────────────┘
                          │
                          ▼
                    PYTHON ENGINE
                          │
        ┌─────────────────┼─────────────────┐
        ▼                 ▼                 ▼
      LEDGER           PAYMENTS         MONETARY
      ENGINE            ENGINE           ENGINE
        │                 │                 │
        └─────────────────┼─────────────────┘
                          ▼
                    SIMULATION STATE
```

## Language Responsibilities

- **PYTHON**: Research + Economics + Authoritative Monetary State Simulation.
- **RUST**: Systems + Concurrency + Event Bus Overlay + Telemetry Engine + Security Protocols.
- **KOTLIN**: Application Framework + Command Centre UI + Visualisation + Operator Interface.
