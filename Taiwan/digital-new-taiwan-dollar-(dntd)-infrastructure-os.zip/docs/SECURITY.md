# Digital New Taiwan Dollar (DNTD) Security Boundary & Cryptography

## Security Boundary Principles

1. **Protocol Boundary**: Rust validates message schema, timestamp validity, required fields, and nonces before propagating to the Event Bus.
2. **Ed25519 Signatures**: Optional signed events undergo Ed25519 public-key verification in Rust.
3. **Replay Protection**: Every event contains an `event_id`, `timestamp`, `nonce`, and `correlation_id`. Rust maintains a short-lived memory cache to drop duplicate sequences.
4. **Role-Based Permissions**: Operator endpoints enforce strict `READ`, `SIMULATION`, and `ADMIN` role boundaries.
