# Digital New Taiwan Dollar (DNTD) Strongly-Typed Event Specification

All events transmitted across gRPC and WebSocket channels inherit common metadata:

```protobuf
message EventMetadata {
    string event_id = 1;
    int64 timestamp = 2;
    string source = 3;
    string schema_version = 4;
    string correlation_id = 5;
    uint64 sequence_number = 6;
    bytes signature = 7;
    string nonce = 8;
}
```

## Domain Event Types

1. `MoneyIssued`: CBDC minting from Central Bank to Commercial Banks.
2. `MoneyRedeemed`: CBDC redemption back to central reserves.
3. `PaymentCreated`: Payment initiated by a wallet.
4. `PaymentSettled`: Authoritative settlement completed by Python engine.
5. `RiskAlert`: Synthetic risk or abnormal velocity trigger.
6. `LiquidityUpdate`: Commercial bank liquidity reserve ratio shift.
