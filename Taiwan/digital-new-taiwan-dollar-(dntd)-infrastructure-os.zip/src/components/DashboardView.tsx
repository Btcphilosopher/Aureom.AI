import React, { useState } from 'react';
import { SystemStateSnapshot, DntdEvent, Language, I18N, formatNTD } from '../types';
import { ArrowUpRight, ShieldAlert, Cpu, Activity, Zap, CheckCircle2 } from 'lucide-react';

interface DashboardViewProps {
  state: SystemStateSnapshot;
  events: DntdEvent[];
  language: Language;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ state, events, language }) => {
  const t = I18N[language];
  const [timeframe, setTimeframe] = useState<'1H' | '24H' | '7D' | '30D' | 'SIM'>('24H');

  const filteredPayments = events.filter((e) => e.type === 'PaymentSettled').slice(0, 8);

  return (
    <div className="space-y-4 font-mono text-[#e0e0e0]">
      {/* 6-Grid Main Operator Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* PANEL 1: CBDC SUPPLY */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-4 relative overflow-hidden shadow-lg group hover:border-[#00FF41]/40 transition-colors">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-2.5 mb-3">
            <span className="text-xs font-semibold tracking-wider text-zinc-400 uppercase flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00FF41] shadow-[0_0_6px_#00FF41]" />
              {t.cbdcSupply}
            </span>
            <div className="flex items-center gap-1 bg-zinc-900 border border-zinc-800 rounded p-0.5 text-[10px]">
              {(['1H', '24H', '7D', '30D', 'SIM'] as const).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-1.5 py-0.5 rounded transition-colors ${
                    timeframe === tf ? 'bg-[#00FF41] text-black font-bold' : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-baseline justify-between my-2">
            <div>
              <div className="text-3xl font-extrabold text-[#00FF41] tracking-tight">
                {formatNTD(state.cbdcSupply, language)}
              </div>
              <div className="flex items-center gap-1 text-[#00FF41] text-xs font-semibold mt-1">
                <ArrowUpRight className="w-3.5 h-3.5 text-[#00FF41]" />
                <span>+2.8% (24h Net Expansion)</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs text-zinc-500 uppercase tracking-wider block">{t.activeWallets}</span>
              <span className="text-lg font-bold text-zinc-200">{state.activeWallets.toLocaleString()}</span>
            </div>
          </div>

          {/* Real-time SVG Sparkline Graph */}
          <div className="h-16 w-full mt-4 bg-zinc-950/80 rounded border border-[#1a1a1c] p-1 flex items-end">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 300 50">
              <defs>
                <linearGradient id="supplyGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00FF41" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#00FF41" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              <path
                d="M 0 40 Q 50 35, 100 25 T 200 20 T 300 8 L 300 50 L 0 50 Z"
                fill="url(#supplyGradient)"
              />
              <path
                d="M 0 40 Q 50 35, 100 25 T 200 20 T 300 8"
                fill="none"
                stroke="#00FF41"
                strokeWidth="2"
                strokeDasharray="4 2"
              />
              <circle cx="300" cy="8" r="3.5" fill="#00FF41" className="animate-ping" />
              <circle cx="300" cy="8" r="2.5" fill="#00FF41" />
            </svg>
          </div>
        </div>

        {/* PANEL 2: LIVE PAYMENT FLOW */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-4 shadow-lg flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-2.5 mb-3">
            <span className="text-xs font-semibold tracking-wider text-zinc-400 uppercase flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-[#00FF41]" />
              {t.livePayments}
            </span>
            <span className="text-[10px] text-[#00FF41] bg-[#00FF41]/10 border border-[#00FF41]/30 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
              STREAMING LIVE
            </span>
          </div>

          <div className="space-y-2 max-h-[140px] overflow-y-auto scrollbar-thin pr-1 text-xs">
            {filteredPayments.length === 0 ? (
              <div className="text-zinc-500 italic text-center py-6">Awaiting synthetic transactions...</div>
            ) : (
              filteredPayments.map((p, idx) => (
                <div
                  key={p.payload.event_id || idx}
                  className="flex items-center justify-between bg-zinc-900/80 border border-zinc-800 px-3 py-1.5 rounded hover:border-[#00FF41]/50 transition-all"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-zinc-500 font-mono text-[10px]">{p.payload.payment_id}</span>
                    <span className="text-zinc-200 font-semibold">{p.payload.sender_id}</span>
                    <span className="text-[#00FF41]">→</span>
                    <span className="text-zinc-300">{p.payload.recipient_id}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[#00FF41] font-bold">{formatNTD(p.payload.amount_minor, language)}</span>
                    <span className="text-[10px] text-black font-bold bg-[#00FF41] px-1.5 py-0.5 rounded">
                      {p.payload.latency_ms || 28}ms
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* PANEL 3: SETTLEMENT ENGINE */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-4 shadow-lg">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-2.5 mb-3">
            <span className="text-xs font-semibold tracking-wider text-zinc-400 uppercase flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#00FF41]" />
              {t.settlement}
            </span>
            <span className="text-xs text-zinc-500 font-mono uppercase tracking-wider">RTGS-EQUIVALENT</span>
          </div>

          <div className="grid grid-cols-2 gap-4 my-2">
            <div>
              <div className="text-2xl font-bold text-[#00FF41]">99.999%</div>
              <div className="text-[11px] text-zinc-400 uppercase tracking-wider">Success Rate</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-zinc-100">{state.settlementLatency.toFixed(0)}ms avg</div>
              <div className="text-[11px] text-zinc-400 uppercase tracking-wider">P50 Settlement Latency</div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 pt-2 border-t border-zinc-900 text-center text-[10px]">
            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800">
              <span className="text-zinc-500 block uppercase tracking-wider">{t.pendingCount}</span>
              <span className="text-amber-400 font-bold">{state.settlementStats.pending}</span>
            </div>
            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800">
              <span className="text-zinc-500 block uppercase tracking-wider">{t.processingCount}</span>
              <span className="text-cyan-400 font-bold">{state.settlementStats.processing}</span>
            </div>
            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800">
              <span className="text-zinc-500 block uppercase tracking-wider">{t.settledCount}</span>
              <span className="text-[#00FF41] font-bold">{state.settlementStats.settled.toLocaleString()}</span>
            </div>
            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800">
              <span className="text-zinc-500 block uppercase tracking-wider">{t.failedCount}</span>
              <span className="text-rose-400 font-bold">{state.settlementStats.failed}</span>
            </div>
          </div>
        </div>

        {/* PANEL 4: BANK LIQUIDITY */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-4 shadow-lg">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-2.5 mb-3">
            <span className="text-xs font-semibold tracking-wider text-zinc-400 uppercase flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              {t.bankLiquidity}
            </span>
            <span className="text-[10px] text-zinc-500 uppercase tracking-wider">TARGET: 15% MIN RESERVES</span>
          </div>

          <div className="space-y-3 my-1">
            {Object.entries(state.bankBalances || {}).map(([bankId, rawBal]) => {
              const numVal = Number(rawBal);
              const pct = Math.min(100, Math.max(10, (numVal / 150_000_000_000_00) * 100));
              return (
                <div key={bankId} className="space-y-1">
                  <div className="flex justify-between text-xs font-medium">
                    <span className="text-zinc-200 font-semibold">{bankId}</span>
                    <span className="text-[#00FF41] font-mono">{formatNTD(numVal, language)}</span>
                  </div>
                  <div className="w-full bg-zinc-950 h-2.5 rounded overflow-hidden flex border border-zinc-800">
                    <div
                      className="bg-[#00FF41] h-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                    <div className="bg-zinc-950 h-full flex-1" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* PANEL 5: RISK TERMINAL */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-4 shadow-lg">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-2.5 mb-3">
            <span className="text-xs font-semibold tracking-wider text-zinc-400 uppercase flex items-center gap-2">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              {t.riskMonitor}
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/40 uppercase tracking-wider">
              {t.low} RISK
            </span>
          </div>

          <div className="flex items-center justify-between my-2">
            <div>
              <div className="text-2xl font-extrabold text-zinc-100">SYSTEM RISK: {state.riskLevel}</div>
              <div className="text-xs text-zinc-400 mt-1">8 Active Synthetic Alerts Monitored</div>
            </div>
            <div className="text-right text-[10px] space-y-0.5 uppercase tracking-wider">
              <div className="text-zinc-400">CRITICAL: <span className="text-[#00FF41] font-bold">0</span></div>
              <div className="text-zinc-400">HIGH: <span className="text-amber-400 font-bold">1</span></div>
              <div className="text-zinc-400">MEDIUM: <span className="text-cyan-400 font-bold">3</span></div>
              <div className="text-zinc-400">LOW: <span className="text-zinc-300 font-bold">4</span></div>
            </div>
          </div>
        </div>

        {/* PANEL 6: SYSTEM TELEMETRY */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-4 shadow-lg">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-2.5 mb-3">
            <span className="text-xs font-semibold tracking-wider text-zinc-400 uppercase flex items-center gap-2">
              <Cpu className="w-3.5 h-3.5 text-[#00FF41]" />
              {t.telemetry}
            </span>
            <span className="text-[10px] text-[#00FF41] font-bold uppercase tracking-wider">RUST EVENT BUS</span>
          </div>

          <div className="grid grid-cols-2 gap-4 my-2">
            <div>
              <div className="text-2xl font-bold text-[#00FF41]">{state.eventsPerSec.toLocaleString()}</div>
              <div className="text-[11px] text-zinc-400 uppercase tracking-wider">{t.eventsPerSec}</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-zinc-100">{state.wsLatencyMs}ms</div>
              <div className="text-[11px] text-zinc-400 uppercase tracking-wider">{t.wsLatency}</div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-zinc-900 text-center text-[10px]">
            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800">
              <span className="text-zinc-500 block uppercase tracking-wider">Queue Depth</span>
              <span className="text-[#00FF41] font-bold">4 msgs</span>
            </div>
            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800">
              <span className="text-zinc-500 block uppercase tracking-wider">CPU Usage</span>
              <span className="text-[#00FF41] font-bold">14.2%</span>
            </div>
            <div className="bg-zinc-900/80 p-1.5 rounded border border-zinc-800">
              <span className="text-zinc-500 block uppercase tracking-wider">RAM Usage</span>
              <span className="text-[#00FF41] font-bold">68.5 MB</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
