import React, { useState, useEffect } from 'react';
import { Language, I18N } from '../types';
import { FileCode2, Cpu, Layers, Server, ArrowDown } from 'lucide-react';

interface ArchitectureViewProps {
  language: Language;
}

export const ArchitectureView: React.FC<ArchitectureViewProps> = ({ language }) => {
  const t = I18N[language];
  const [codebaseFiles, setCodebaseFiles] = useState<Record<string, string>>({});
  const [selectedFile, setSelectedFile] = useState<string>('proto/dntd.proto');

  useEffect(() => {
    fetch('/api/dntd/codebase')
      .then((res) => res.json())
      .then((data) => {
        if (data.files) {
          setCodebaseFiles(data.files);
        }
      })
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="space-y-6 font-mono text-[#e0e0e0]">
      
      {/* SECTION 42: TOPOLOGY GRAPH */}
      <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg">
        <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#00FF41]" />
            <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
              {t.archTopology} (MASTER TRI-LAYER TOPOLOGY)
            </h3>
          </div>
          <span className="text-xs text-[#00FF41] font-mono font-bold uppercase tracking-wider">SECTION 42 ARCHITECTURE</span>
        </div>

        <div className="flex flex-col items-center justify-center space-y-4 py-4 bg-zinc-950/80 rounded-sm border border-[#1a1a1c]">
          {/* PYTHON LAYER */}
          <div className="w-80 bg-[#0e0e10] border-2 border-[#00FF41] rounded-sm p-3 text-center shadow-[0_0_12px_rgba(0,255,65,0.2)]">
            <span className="text-[10px] text-[#00FF41] font-bold block uppercase tracking-wider">AUTHORITATIVE MONETARY STATE</span>
            <span className="text-sm font-extrabold text-[#00FF41]">PYTHON ENGINE</span>
            <span className="text-[10px] text-zinc-400 block mt-1 uppercase tracking-wider">Economics • Ledger • Issuance • Payments</span>
          </div>

          <ArrowDown className="w-5 h-5 text-[#00FF41] animate-bounce" />

          {/* RUST LAYER */}
          <div className="w-80 bg-[#0e0e10] border-2 border-cyan-400 rounded-sm p-3 text-center shadow-[0_0_12px_rgba(34,211,238,0.2)]">
            <span className="text-[10px] text-cyan-400 font-bold block uppercase tracking-wider">SYSTEM OVERLAY & MESSAGE BUS</span>
            <span className="text-sm font-extrabold text-cyan-200">RUST EVENT OVERLAY</span>
            <span className="text-[10px] text-zinc-400 block mt-1 uppercase tracking-wider">Tokio Channels • Security • Telemetry • Axum</span>
          </div>

          <ArrowDown className="w-5 h-5 text-[#00FF41] animate-bounce" />

          {/* KOTLIN LAYER */}
          <div className="w-80 bg-[#0e0e10] border-2 border-amber-400 rounded-sm p-3 text-center shadow-[0_0_12px_rgba(251,191,36,0.2)]">
            <span className="text-[10px] text-amber-400 font-bold block uppercase tracking-wider">COMMAND CENTRE UI & VISUALISATION</span>
            <span className="text-sm font-extrabold text-amber-200">KOTLIN APPLICATION</span>
            <span className="text-[10px] text-zinc-400 block mt-1 uppercase tracking-wider">Jetpack Compose • Coroutines • Flow • Ktor</span>
          </div>
        </div>
      </div>

      {/* CODEBASE REPOSITORY INSPECTOR */}
      <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg">
        <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <FileCode2 className="w-4 h-4 text-[#00FF41]" />
            <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
              SOURCE CODE REPOSITORY BROWSER
            </h3>
          </div>
          <span className="text-xs text-zinc-500 uppercase tracking-wider">PROTOBUF / RUST / KOTLIN / PYTHON</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* FILE LIST SIDEBAR */}
          <div className="bg-zinc-900 border border-zinc-800 rounded-sm p-2 space-y-1 max-h-[400px] overflow-y-auto">
            {Object.keys(codebaseFiles).map((fp) => (
              <button
                key={fp}
                onClick={() => setSelectedFile(fp)}
                className={`w-full text-left px-2.5 py-1.5 rounded-sm text-[11px] truncate font-mono transition-colors uppercase tracking-wider ${
                  selectedFile === fp
                    ? 'bg-[#00FF41]/20 text-[#00FF41] font-bold border border-[#00FF41]/60'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
                }`}
              >
                {fp}
              </button>
            ))}
          </div>

          {/* CODE DISPLAY AREA */}
          <div className="md:col-span-3 bg-zinc-950/90 border border-zinc-800 rounded-sm p-4 font-mono text-xs overflow-x-auto max-h-[400px]">
            <div className="text-[10px] text-[#00FF41] border-b border-zinc-800 pb-2 mb-2 font-bold uppercase tracking-wider">
              {selectedFile}
            </div>
            <pre className="text-zinc-300 leading-relaxed font-mono whitespace-pre">
              {codebaseFiles[selectedFile] || '// Loading file content...'}
            </pre>
          </div>
        </div>
      </div>

    </div>
  );
};
