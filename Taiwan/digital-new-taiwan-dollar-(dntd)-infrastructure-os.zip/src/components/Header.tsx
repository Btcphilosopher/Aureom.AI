import React from 'react';
import { Language, I18N } from '../types';
import { ShieldCheck, Activity, Globe, Cpu, Server, Layers, FileCode2 } from 'lucide-react';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  activeTab: string;
  onTabChange: (tab: string) => void;
  systemStatus: string;
  eventsPerSec: number;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  activeTab,
  onTabChange,
  systemStatus,
  eventsPerSec,
}) => {
  const t = I18N[language];

  const tabs = [
    { id: 'dashboard', label: language === 'TRADITIONAL_CHINESE' ? '指揮中心' : 'COMMAND CENTRE', icon: Activity },
    { id: 'flow', label: language === 'TRADITIONAL_CHINESE' ? '交易與網路圖' : 'FLOW & NETWORK', icon: Globe },
    { id: 'settlement', label: language === 'TRADITIONAL_CHINESE' ? '清算與風險' : 'SETTLEMENT & RISK', icon: ShieldCheck },
    { id: 'issuance', label: language === 'TRADITIONAL_CHINESE' ? '發行與贖回' : 'ISSUANCE & REDEEM', icon: Cpu },
    { id: 'monetary', label: language === 'TRADITIONAL_CHINESE' ? '貨幣實驗室' : 'POLICY LAB', icon: Layers },
    { id: 'ledger', label: language === 'TRADITIONAL_CHINESE' ? '帳本鏈' : 'LEDGER CHAIN', icon: Server },
    { id: 'codebase', label: language === 'TRADITIONAL_CHINESE' ? '架構與程式碼' : 'CODEBASE & ARCH', icon: FileCode2 },
  ];

  return (
    <header className="bg-[#0e0e10] border-b border-[#2a2a2c] text-[#e0e0e0] sticky top-0 z-50 font-mono select-none">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#00FF41] flex items-center justify-center rounded-sm shadow-[0_0_10px_rgba(0,255,65,0.25)] shrink-0">
            <div className="w-4 h-4 border-2 border-black rotate-45"></div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-bold leading-tight tracking-tighter text-white">
                {t.title}
                <span className="text-zinc-500 font-normal ml-2 text-xs sm:text-sm hidden sm:inline">
                  DIGITAL NEW TAIWAN DOLLAR (DNTD)
                </span>
              </h1>
            </div>
            <div className="text-[10px] text-[#00FF41] font-bold uppercase tracking-widest mt-0.5">
              {t.subtitle} // v4.2.0-STABLE
            </div>
          </div>
        </div>

        {/* System Health Status & Controls */}
        <div className="flex items-center gap-3 text-xs">
          <div className="text-right hidden lg:block mr-2">
            <div className="text-[10px] text-zinc-500 uppercase tracking-wider">Network Authority</div>
            <div className="text-xs font-bold text-zinc-200">TAIPEI-CB-SIM-01</div>
          </div>

          <div className="flex items-center gap-2 px-3 py-1 bg-zinc-900 border border-zinc-700 rounded text-zinc-200">
            <div className="w-2 h-2 rounded-full bg-[#00FF41] shadow-[0_0_8px_#00FF41] animate-pulse"></div>
            <span className="text-[10px] font-bold tracking-wider uppercase">
              {systemStatus === 'ONLINE' ? t.systemOnline : t.systemDegraded}
            </span>
          </div>

          <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 bg-zinc-900/80 border border-zinc-800 rounded text-zinc-400">
            <Cpu className="w-3.5 h-3.5 text-[#00FF41]" />
            <span className="text-[11px]">{eventsPerSec.toLocaleString()} {t.eventsPerSec}</span>
          </div>

          {/* Language Selector */}
          <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded p-0.5 text-[10px]">
            <button
              onClick={() => onLanguageChange('TRADITIONAL_CHINESE')}
              className={`px-2 py-1 rounded transition-colors ${
                language === 'TRADITIONAL_CHINESE'
                  ? 'bg-[#00FF41] text-black font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              繁體中文
            </button>
            <button
              onClick={() => onLanguageChange('ENGLISH')}
              className={`px-2 py-1 rounded transition-colors ${
                language === 'ENGLISH'
                  ? 'bg-[#00FF41] text-black font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              EN
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-[#0c0c0e] border-t border-[#2a2a2c] overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto px-4 flex gap-1 py-1.5">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-mono tracking-wide transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-[#00FF41]/10 border border-[#00FF41] text-[#00FF41] font-bold shadow-[0_0_8px_rgba(0,255,65,0.15)]'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60 border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#00FF41]' : 'text-zinc-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
