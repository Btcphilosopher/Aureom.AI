import React, { useState } from 'react';
import { DntdEvent, Language, I18N, formatNTD } from '../types';
import { Server, ArrowRight, CheckCircle, ShieldCheck } from 'lucide-react';

interface LedgerExplorerViewProps {
  events: DntdEvent[];
  language: Language;
}

export const LedgerExplorerView: React.FC<LedgerExplorerViewProps> = ({ events, language }) => {
  const t = I18N[language];
  const [selectedTx, setSelectedTx] = useState<any | null>(null);

  const settlementEvents = events.filter((e) => e.type === 'PaymentSettled' || e.type === 'MoneyIssued');

  return (
    <div className="space-y-6 font-mono text-[#e0e0e0]">
      <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg">
        <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 text-[#00FF41]" />
            <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
              {t.ledgerExplorer} (AUTHORITATIVE LEDGER)
            </h3>
          </div>
          <span className="text-xs text-zinc-500 font-mono uppercase tracking-wider">EVENT-SOURCED JOURNAL</span>
        </div>

        {/* SECTION 34: LEDGER TABLE */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#2a2a2c] text-zinc-500 uppercase tracking-wider">
                <th className="py-2 px-3">TX ID</th>
                <th className="py-2 px-3">TIME</th>
                <th className="py-2 px-3">FROM</th>
                <th className="py-2 px-3">TO</th>
                <th className="py-2 px-3">AMOUNT</th>
                <th className="py-2 px-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-900">
              {settlementEvents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-zinc-500 italic">
                    Awaiting ledger events...
                  </td>
                </tr>
              ) : (
                settlementEvents.map((evt, idx) => {
                  const p = evt.payload;
                  const txId = p.payment_id || p.transaction_id || `8A2${idx}`;
                  const from = p.sender_id || 'CENTRAL_BANK';
                  const to = p.recipient_id || p.target_bank_id || 'BANK_A';
                  const amount = p.amount_minor || 0;
                  const timeStr = new Date(p.timestamp || Date.now()).toLocaleTimeString();

                  return (
                    <tr
                      key={p.event_id || idx}
                      onClick={() => setSelectedTx({ ...p, txId, from, to, amount })}
                      className="hover:bg-zinc-900/80 cursor-pointer transition-colors"
                    >
                      <td className="py-2.5 px-3 font-bold text-[#00FF41]">{txId}</td>
                      <td className="py-2.5 px-3 text-zinc-400">{timeStr}</td>
                      <td className="py-2.5 px-3 text-zinc-300">{from}</td>
                      <td className="py-2.5 px-3 text-zinc-300">{to}</td>
                      <td className="py-2.5 px-3 font-bold text-zinc-100">{formatNTD(amount, language)}</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/40 uppercase tracking-wider">
                          SETTLED
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 35: TRANSACTION DETAIL MODAL */}
      {selectedTx && (
        <div className="fixed inset-0 bg-[#0a0a0b]/90 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#0e0e10] border-2 border-[#00FF41] rounded-sm max-w-xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-[#1a1a1c] pb-3">
              <div>
                <span className="text-[10px] text-[#00FF41] font-bold block uppercase tracking-wider">TRANSACTION EVENT LIFECYCLE</span>
                <h4 className="text-base font-extrabold text-[#00FF41]">{selectedTx.txId}</h4>
              </div>
              <button
                onClick={() => setSelectedTx(null)}
                className="text-zinc-400 hover:text-zinc-200 text-xs px-2 py-1 rounded bg-zinc-900 uppercase tracking-wider"
              >
                CLOSE
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-zinc-900/80 p-3 rounded-sm border border-zinc-800">
              <div><span className="text-zinc-500 block uppercase tracking-wider">SENDER:</span> <span className="font-bold text-zinc-200">{selectedTx.from}</span></div>
              <div><span className="text-zinc-500 block uppercase tracking-wider">RECIPIENT:</span> <span className="font-bold text-zinc-200">{selectedTx.to}</span></div>
              <div><span className="text-zinc-500 block uppercase tracking-wider">AMOUNT:</span> <span className="font-bold text-[#00FF41]">{formatNTD(selectedTx.amount, language)}</span></div>
              <div><span className="text-zinc-500 block uppercase tracking-wider">SETTLEMENT TIME:</span> <span className="font-bold text-[#00FF41]">{selectedTx.latency_ms || 28} ms</span></div>
            </div>

            {/* EVENT CHAIN LIFECYCLE STAGES */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-zinc-400 block uppercase tracking-wider">EVENT CHAIN LIFECYCLE</span>
              <div className="flex items-center justify-between bg-zinc-900 p-3 rounded-sm border border-zinc-800 text-[11px]">
                {['CREATED', 'AUTHORISED', 'VALIDATED', 'SETTLED', 'RECONCILED'].map((step, idx) => (
                  <React.Fragment key={step}>
                    <div className="flex flex-col items-center">
                      <CheckCircle className="w-4 h-4 text-[#00FF41] mb-1" />
                      <span className="text-[#00FF41] font-bold uppercase tracking-wider">{step}</span>
                    </div>
                    {idx < 4 && <ArrowRight className="w-3.5 h-3.5 text-[#00FF41]/60" />}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
