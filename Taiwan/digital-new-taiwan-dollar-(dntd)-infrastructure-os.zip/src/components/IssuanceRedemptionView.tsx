import React, { useState } from 'react';
import { SystemStateSnapshot, Language, I18N, formatNTD } from '../types';
import { Cpu, ShieldCheck, AlertCircle } from 'lucide-react';

interface IssuanceRedemptionViewProps {
  state: SystemStateSnapshot;
  language: Language;
  onRefreshState: () => void;
}

export const IssuanceRedemptionView: React.FC<IssuanceRedemptionViewProps> = ({ state, language, onRefreshState }) => {
  const t = I18N[language];

  // Issuance State
  const [issueBank, setIssueBank] = useState('BANK_A');
  const [issueAmountNTD, setIssueAmountNTD] = useState('100000000'); // NT$ 100M
  const [issueReason, setIssueReason] = useState('Simulation Policy Expansion');
  const [showIssueConfirm, setShowIssueConfirm] = useState(false);
  const [issuing, setIssuing] = useState(false);

  // Redemption State
  const [redeemBank, setRedeemBank] = useState('BANK_A');
  const [redeemAmountNTD, setRedeemAmountNTD] = useState('50000000'); // NT$ 50M
  const [showRedeemConfirm, setShowRedeemConfirm] = useState(false);
  const [redeeming, setRedeeming] = useState(false);

  const handleIssueSubmit = async () => {
    setIssuing(true);
    try {
      const amountMinor = Math.floor(parseFloat(issueAmountNTD) * 100);
      const res = await fetch('/api/dntd/issue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target_bank_id: issueBank,
          amount_minor: amountMinor,
          reason: issueReason,
        }),
      });
      if (res.ok) {
        setShowIssueConfirm(false);
        onRefreshState();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIssuing(false);
    }
  };

  const handleRedeemSubmit = async () => {
    setRedeeming(true);
    try {
      const amountMinor = Math.floor(parseFloat(redeemAmountNTD) * 100);
      const res = await fetch('/api/dntd/redeem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bank_id: redeemBank,
          amount_minor: amountMinor,
        }),
      });
      if (res.ok) {
        setShowRedeemConfirm(false);
        onRefreshState();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setRedeeming(false);
    }
  };

  return (
    <div className="space-y-6 font-mono text-[#e0e0e0]">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* SECTION 36: CBDC ISSUANCE TERMINAL */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg relative">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#00FF41]" />
              <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
                {language === 'TRADITIONAL_CHINESE' ? 'CBDC 數位新臺幣發行終端' : 'CBDC ISSUANCE TERMINAL'}
              </h3>
            </div>
            <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
              {t.simulationNotice}
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs text-zinc-400 block mb-1 uppercase tracking-wider">TARGET COMMERCIAL BANK</label>
              <select
                value={issueBank}
                onChange={(e) => setIssueBank(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded p-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-[#00FF41]"
              >
                <option value="BANK_A">BANK A (Taiwan Financial)</option>
                <option value="BANK_B">BANK B (Formosa Commerce)</option>
                <option value="BANK_C">BANK C (Taipei Metro)</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-zinc-400 block mb-1 uppercase tracking-wider">AMOUNT (NT$)</label>
              <input
                type="number"
                value={issueAmountNTD}
                onChange={(e) => setIssueAmountNTD(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded p-2 text-xs font-mono text-[#00FF41] font-bold focus:outline-none focus:border-[#00FF41]"
              />
            </div>

            <div>
              <label className="text-xs text-zinc-400 block mb-1 uppercase tracking-wider">POLICY / REASON</label>
              <input
                type="text"
                value={issueReason}
                onChange={(e) => setIssueReason(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded p-2 text-xs font-mono text-zinc-300 focus:outline-none focus:border-[#00FF41]"
              />
            </div>

            <button
              onClick={() => setShowIssueConfirm(true)}
              className="w-full bg-[#00FF41] hover:bg-[#00FF41]/90 text-black font-bold py-2.5 rounded-sm text-xs transition-colors tracking-wider shadow-[0_0_12px_rgba(0,255,65,0.25)] uppercase"
            >
              [ {t.issue} ]
            </button>
          </div>

          {/* Explicit Issuance Confirmation Modal */}
          {showIssueConfirm && (
            <div className="absolute inset-0 bg-[#0a0a0b]/95 backdrop-blur rounded-sm p-6 flex flex-col justify-between border-2 border-[#00FF41] z-20">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-[#00FF41]">
                  <ShieldCheck className="w-5 h-5" />
                  <span className="font-bold text-sm tracking-wider uppercase">{t.confirmSimulation}</span>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  You are about to issue <span className="text-[#00FF41] font-bold">NT$ {parseFloat(issueAmountNTD).toLocaleString()}</span> of CBDC to <span className="text-[#00FF41] font-bold">{issueBank}</span> in the authoritative Python simulation ledger.
                </p>
                <div className="bg-zinc-900 p-2 rounded text-[11px] text-amber-300 border border-amber-800/80">
                  {t.simulationNotice} This action will broadcast a MoneyIssued event to the Rust Overlay and update total CBDC supply.
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowIssueConfirm(false)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-2 rounded-sm text-xs font-bold uppercase tracking-wider"
                >
                  CANCEL
                </button>
                <button
                  onClick={handleIssueSubmit}
                  disabled={issuing}
                  className="flex-1 bg-[#00FF41] hover:bg-[#00FF41]/90 text-black py-2 rounded-sm text-xs font-bold uppercase tracking-wider"
                >
                  {issuing ? 'ISSUING...' : 'CONFIRM & EXECUTE'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 37: CBDC REDEMPTION TERMINAL */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg relative">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
                {language === 'TRADITIONAL_CHINESE' ? 'CBDC 數位新臺幣贖回終端' : 'CBDC REDEMPTION TERMINAL'}
              </h3>
            </div>
            <span className="text-[10px] bg-zinc-900 text-zinc-400 border border-zinc-800 px-2 py-0.5 rounded font-bold uppercase tracking-wider">
              RESERVE DEDUCTION
            </span>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs text-zinc-400 block mb-1 uppercase tracking-wider">REDEMPTION BANK</label>
              <select
                value={redeemBank}
                onChange={(e) => setRedeemBank(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded p-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-[#00FF41]"
              >
                <option value="BANK_A">BANK A (Taiwan Financial)</option>
                <option value="BANK_B">BANK B (Formosa Commerce)</option>
                <option value="BANK_C">BANK C (Taipei Metro)</option>
              </select>
            </div>

            <div>
              <label className="text-xs text-zinc-400 block mb-1 uppercase tracking-wider">REDEMPTION AMOUNT (NT$)</label>
              <input
                type="number"
                value={redeemAmountNTD}
                onChange={(e) => setRedeemAmountNTD(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded p-2 text-xs font-mono text-amber-300 font-bold focus:outline-none focus:border-[#00FF41]"
              />
            </div>

            <button
              onClick={() => setShowRedeemConfirm(true)}
              className="w-full bg-amber-500 hover:bg-amber-400 text-black font-bold py-2.5 rounded-sm text-xs transition-colors tracking-wider uppercase"
            >
              [ {t.redeem} ]
            </button>
          </div>

          {/* Explicit Redemption Confirmation Modal */}
          {showRedeemConfirm && (
            <div className="absolute inset-0 bg-[#0a0a0b]/95 backdrop-blur rounded-sm p-6 flex flex-col justify-between border-2 border-amber-500 z-20">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-amber-400">
                  <ShieldCheck className="w-5 h-5" />
                  <span className="font-bold text-sm tracking-wider uppercase">CONFIRM REDEMPTION</span>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  You are about to redeem <span className="text-amber-300 font-bold">NT$ {parseFloat(redeemAmountNTD).toLocaleString()}</span> from <span className="text-amber-300 font-bold">{redeemBank}</span>.
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setShowRedeemConfirm(false)}
                  className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-2 rounded-sm text-xs font-bold uppercase tracking-wider"
                >
                  CANCEL
                </button>
                <button
                  onClick={handleRedeemSubmit}
                  disabled={redeeming}
                  className="flex-1 bg-amber-500 hover:bg-amber-400 text-black py-2 rounded-sm text-xs font-bold uppercase tracking-wider"
                >
                  {redeeming ? 'REDEEMING...' : 'CONFIRM REDEMPTION'}
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
