import React from 'react';
import { SystemStateSnapshot, DntdEvent, Language, I18N } from '../types';
import { ShieldAlert, CheckCircle2, Clock, AlertTriangle } from 'lucide-react';

interface SettlementRiskViewProps {
  state: SystemStateSnapshot;
  events: DntdEvent[];
  language: Language;
}

export const SettlementRiskView: React.FC<SettlementRiskViewProps> = ({ state, events, language }) => {
  const t = I18N[language];

  const riskAlerts = events.filter((e) => e.type === 'RiskAlert').slice(0, 5);

  return (
    <div className="space-y-6 font-mono text-[#e0e0e0]">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* SECTION 32: SETTLEMENT MONITOR */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#00FF41]" />
              <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
                {language === 'TRADITIONAL_CHINESE' ? '清算與結算監控器' : 'SETTLEMENT ENGINE MONITOR'}
              </h3>
            </div>
            <span className="text-xs text-zinc-500 font-mono uppercase tracking-wider">P2P & INTERBANK</span>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-zinc-900/80 p-3 rounded-sm border border-zinc-800 space-y-1">
              <span className="text-xs text-zinc-500 block uppercase tracking-wider">{t.pendingCount}</span>
              <span className="text-xl font-bold text-amber-400">{state.settlementStats.pending}</span>
            </div>
            <div className="bg-zinc-900/80 p-3 rounded-sm border border-zinc-800 space-y-1">
              <span className="text-xs text-zinc-500 block uppercase tracking-wider">{t.processingCount}</span>
              <span className="text-xl font-bold text-cyan-400">{state.settlementStats.processing}</span>
            </div>
            <div className="bg-zinc-900/80 p-3 rounded-sm border border-zinc-800 space-y-1">
              <span className="text-xs text-zinc-500 block uppercase tracking-wider">{t.settledCount}</span>
              <span className="text-xl font-bold text-[#00FF41]">{state.settlementStats.settled.toLocaleString()}</span>
            </div>
            <div className="bg-zinc-900/80 p-3 rounded-sm border border-zinc-800 space-y-1">
              <span className="text-xs text-zinc-500 block uppercase tracking-wider">{t.failedCount}</span>
              <span className="text-xl font-bold text-rose-400">{state.settlementStats.failed}</span>
            </div>
          </div>

          {/* LATENCY PERCENTILE BREAKDOWN */}
          <div className="bg-zinc-950/80 p-4 rounded-sm border border-[#1a1a1c] space-y-3">
            <div className="text-xs font-bold text-zinc-300 flex items-center gap-2 uppercase tracking-wider">
              <Clock className="w-3.5 h-3.5 text-[#00FF41]" />
              <span>SETTLEMENT LATENCY PERCENTILES</span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-zinc-400 uppercase tracking-wider">P50 (Median)</span>
                <span className="text-[#00FF41] font-bold">{state.settlementStats.p50} ms</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400 uppercase tracking-wider">P95 (Tail Latency)</span>
                <span className="text-amber-300 font-bold">{state.settlementStats.p95} ms</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400 uppercase tracking-wider">P99 (Extreme Edge)</span>
                <span className="text-rose-400 font-bold">{state.settlementStats.p99} ms</span>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 33: RISK TERMINAL */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
                {language === 'TRADITIONAL_CHINESE' ? '風險監控終端' : 'RISK TERMINAL'}
              </h3>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/40 uppercase tracking-wider">
              SYSTEM RISK: LOW
            </span>
          </div>

          <div className="grid grid-cols-4 gap-2 mb-4 text-center text-xs">
            <div className="bg-zinc-900 p-2 rounded-sm border border-zinc-800">
              <span className="text-zinc-500 block text-[10px] uppercase tracking-wider">{t.critical}</span>
              <span className="text-[#00FF41] font-bold text-sm">0</span>
            </div>
            <div className="bg-zinc-900 p-2 rounded-sm border border-zinc-800">
              <span className="text-zinc-500 block text-[10px] uppercase tracking-wider">{t.high}</span>
              <span className="text-amber-400 font-bold text-sm">1</span>
            </div>
            <div className="bg-zinc-900 p-2 rounded-sm border border-zinc-800">
              <span className="text-zinc-500 block text-[10px] uppercase tracking-wider">{t.medium}</span>
              <span className="text-cyan-400 font-bold text-sm">3</span>
            </div>
            <div className="bg-zinc-900 p-2 rounded-sm border border-zinc-800">
              <span className="text-zinc-500 block text-[10px] uppercase tracking-wider">{t.low}</span>
              <span className="text-zinc-300 font-bold text-sm">4</span>
            </div>
          </div>

          {/* ACTIVE ALERTS LIST */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">SYNTHETIC RISK STREAM</h4>
            {riskAlerts.length === 0 ? (
              <div className="p-4 rounded-sm bg-zinc-900/60 border border-zinc-800 text-center text-xs text-zinc-500 italic">
                No critical anomalies active.
              </div>
            ) : (
              riskAlerts.map((alert, idx) => (
                <div
                  key={alert.payload.event_id || idx}
                  className="bg-zinc-900/80 border-l-4 border-l-amber-500 border border-zinc-800 p-3 rounded-sm text-xs space-y-1"
                >
                  <div className="flex items-center justify-between font-bold text-amber-400">
                    <span className="flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      {alert.payload.title || 'ABNORMAL VELOCITY'}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                      SEVERITY: {alert.payload.severity || 'HIGH'}
                    </span>
                  </div>
                  <p className="text-zinc-300 text-[11px]">{alert.payload.description}</p>
                  <div className="text-[10px] text-zinc-500 flex justify-between pt-1">
                    <span>SOURCE: {alert.payload.source_node || 'SIMULATION_ENGINE'}</span>
                    <span>ACTION: MONITOR</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
