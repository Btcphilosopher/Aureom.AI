import React, { useState } from 'react';
import { Play, Pause, FastForward, RotateCcw, StepForward } from 'lucide-react';

export const SimulationBar: React.FC = () => {
  const [speed, setSpeed] = useState<number>(1);
  const [paused, setPaused] = useState<boolean>(false);

  const updateSimulation = async (newSpeed: number, newPaused: boolean) => {
    setSpeed(newSpeed);
    setPaused(newPaused);
    try {
      await fetch('/api/dntd/simulation/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ speed: newSpeed, paused: newPaused }),
      });
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="bg-[#0e0e10] border-t border-[#2a2a2c] text-[#e0e0e0] font-mono py-2.5 px-4 sticky bottom-0 z-40 shadow-2xl">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
        
        {/* TIMELINE CONTROLS */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider mr-1">
            SIMULATION CONTROLS:
          </span>

          <button
            onClick={() => updateSimulation(speed, !paused)}
            className={`px-3 py-1.5 rounded flex items-center gap-1.5 font-bold transition-all ${
              paused
                ? 'bg-orange-500 text-black shadow-[0_0_8px_rgba(249,115,22,0.3)]'
                : 'bg-[#00FF41] text-black shadow-[0_0_8px_rgba(0,255,65,0.3)]'
            }`}
          >
            {paused ? <Play className="w-3.5 h-3.5 fill-black" /> : <Pause className="w-3.5 h-3.5 fill-black" />}
            <span className="text-[10px] uppercase tracking-wider">{paused ? 'PAUSED' : 'LIVE RUN'}</span>
          </button>

          <button
            onClick={() => updateSimulation(speed, false)}
            className="px-2.5 py-1 bg-zinc-900 border border-zinc-700 rounded text-zinc-300 hover:text-[#00FF41] hover:border-[#00FF41] flex items-center gap-1 transition-colors text-[10px] uppercase font-bold"
          >
            <StepForward className="w-3.5 h-3.5" />
            <span>STEP</span>
          </button>

          <button
            onClick={() => updateSimulation(100, false)}
            className="px-2.5 py-1 bg-zinc-900 border border-zinc-700 rounded text-zinc-300 hover:text-[#00FF41] hover:border-[#00FF41] flex items-center gap-1 transition-colors text-[10px] uppercase font-bold"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span>FFWD</span>
          </button>

          <button
            onClick={() => updateSimulation(1, false)}
            className="px-2.5 py-1 bg-zinc-900 border border-zinc-700 rounded text-zinc-300 hover:text-[#00FF41] hover:border-[#00FF41] flex items-center gap-1 transition-colors text-[10px] uppercase font-bold"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET</span>
          </button>
        </div>

        {/* SPEED MULTIPLIERS */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-zinc-500 font-bold mr-1 uppercase tracking-wider">SPEED:</span>
          {[1, 10, 100, 1000].map((s) => (
            <button
              key={s}
              onClick={() => updateSimulation(s, false)}
              className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all ${
                speed === s
                  ? 'bg-[#00FF41] text-black border border-[#00FF41] shadow-[0_0_6px_rgba(0,255,65,0.2)]'
                  : 'bg-zinc-900 text-zinc-400 border border-zinc-800 hover:text-zinc-200'
              }`}
            >
              {s}x
            </button>
          ))}
        </div>

      </div>
    </div>
  );
};
