import React, { useState } from 'react';
import { SystemStateSnapshot, Language, I18N } from '../types';
import { Layers, Sliders, Play, BarChart3 } from 'lucide-react';

interface MonetaryLabViewProps {
  state: SystemStateSnapshot;
  language: Language;
}

export const MonetaryLabView: React.FC<MonetaryLabViewProps> = ({ state, language }) => {
  const t = I18N[language];

  const [adoption, setAdoption] = useState(45);
  const [walletLimit, setWalletLimit] = useState(100000);
  const [remuneration, setRemuneration] = useState(0.5);
  const [liquidityMode, setLiquidityMode] = useState('HIGH');
  const [activeScenario, setActiveScenario] = useState<'SINGLE' | 'COMPARISON'>('SINGLE');

  return (
    <div className="space-y-6 font-mono text-[#e0e0e0]">
      
      {/* HEADER CONTROLS */}
      <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h3 className="text-sm font-bold text-[#00FF41] tracking-wider flex items-center gap-2 uppercase">
            <Layers className="w-4 h-4" />
            {t.monetaryLab} (MONETARY SIMULATION LAB)
          </h3>
          <p className="text-xs text-zinc-500">Research & Macroeconomic Policy Output Experiments</p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setActiveScenario('SINGLE')}
            className={`px-3 py-1.5 rounded-sm text-xs font-bold transition-colors uppercase tracking-wider ${
              activeScenario === 'SINGLE'
                ? 'bg-[#00FF41] text-black'
                : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
            }`}
          >
            SINGLE EXPERIMENT
          </button>
          <button
            onClick={() => setActiveScenario('COMPARISON')}
            className={`px-3 py-1.5 rounded-sm text-xs font-bold transition-colors uppercase tracking-wider ${
              activeScenario === 'COMPARISON'
                ? 'bg-[#00FF41] text-black'
                : 'bg-zinc-900 text-zinc-400 border border-zinc-800'
            }`}
          >
            SCENARIO A VS B COMPARISON
          </button>
        </div>
      </div>

      {activeScenario === 'SINGLE' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* PARAMETER CONTROLS */}
          <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 space-y-4 shadow-lg">
            <h4 className="text-xs font-bold text-zinc-300 border-b border-[#1a1a1c] pb-2 flex items-center gap-2 uppercase tracking-wider">
              <Sliders className="w-3.5 h-3.5 text-[#00FF41]" />
              EXPERIMENTAL POLICY INPUTS
            </h4>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-400 uppercase tracking-wider">CBDC ADOPTION RATE</span>
                <span className="text-[#00FF41] font-bold">{adoption}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="95"
                value={adoption}
                onChange={(e) => setAdoption(Number(e.target.value))}
                className="w-full accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-400 uppercase tracking-wider">INDIVIDUAL WALLET LIMIT</span>
                <span className="text-[#00FF41] font-bold">NT$ {walletLimit.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="10000"
                max="1000000"
                step="10000"
                value={walletLimit}
                onChange={(e) => setWalletLimit(Number(e.target.value))}
                className="w-full accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-400 uppercase tracking-wider">CBDC REMUNERATION INTEREST RATE</span>
                <span className="text-[#00FF41] font-bold">{remuneration}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="5"
                step="0.1"
                value={remuneration}
                onChange={(e) => setRemuneration(Number(e.target.value))}
                className="w-full accent-[#00FF41]"
              />
            </div>

            <div>
              <label className="text-xs text-zinc-400 block mb-1 uppercase tracking-wider">BANK LIQUIDITY MODE</label>
              <select
                value={liquidityMode}
                onChange={(e) => setLiquidityMode(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-700 rounded p-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-[#00FF41]"
              >
                <option value="HIGH">HIGH (Standard Central Reserve)</option>
                <option value="DEGRADED">DEGRADED (Liquidity Disintermediation)</option>
              </select>
            </div>

            <button className="w-full bg-[#00FF41] hover:bg-[#00FF41]/90 text-black font-bold py-2.5 rounded-sm text-xs transition-colors flex items-center justify-center gap-2 uppercase tracking-wider shadow-[0_0_10px_rgba(0,255,65,0.2)]">
              <Play className="w-4 h-4 fill-black" />
              RUN POLICY SCENARIO
            </button>
          </div>

          {/* SIMULATION MODEL OUTPUTS */}
          <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 space-y-4 shadow-lg">
            <h4 className="text-xs font-bold text-zinc-300 border-b border-[#1a1a1c] pb-2 flex items-center gap-2 uppercase tracking-wider">
              <BarChart3 className="w-3.5 h-3.5 text-[#00FF41]" />
              MODEL OUTPUTS (RESEARCH SIMULATION)
            </h4>

            <div className="space-y-3 text-xs">
              <div className="bg-zinc-900/80 p-3 rounded-sm border border-zinc-800 flex justify-between items-center">
                <span className="text-zinc-400 uppercase tracking-wider">ESTIMATED CBDC SUPPLY</span>
                <span className="text-[#00FF41] font-bold">NT$ {(84.2 * (adoption / 45)).toFixed(1)}B</span>
              </div>
              <div className="bg-zinc-900/80 p-3 rounded-sm border border-zinc-800 flex justify-between items-center">
                <span className="text-zinc-400 uppercase tracking-wider">COMMERCIAL BANK DEPOSIT IMPACT</span>
                <span className="text-amber-400 font-bold">-{(adoption * 0.42).toFixed(1)}% Shift</span>
              </div>
              <div className="bg-zinc-900/80 p-3 rounded-sm border border-zinc-800 flex justify-between items-center">
                <span className="text-zinc-400 uppercase tracking-wider">PROJECTED VELOCITY</span>
                <span className="text-[#00FF41] font-bold font-mono">{(1.4 * (remuneration + 1)).toFixed(2)}x</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* SECTION 64: COMPARISON MODE */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-[#0e0e10] border border-[#00FF41]/60 rounded-sm p-5 space-y-3">
            <span className="text-xs font-bold text-[#00FF41] block border-b border-zinc-800 pb-2 uppercase tracking-wider">
              SCENARIO A: ORGANIC ADOPTION (BASELINE)
            </span>
            <div className="text-xs space-y-2 font-mono">
              <div className="flex justify-between"><span className="text-zinc-400">CBDC Supply:</span><span className="text-zinc-200 font-bold">NT$ 84.2B</span></div>
              <div className="flex justify-between"><span className="text-zinc-400">Bank Deposit Impact:</span><span className="text-[#00FF41] font-bold">-12.4%</span></div>
              <div className="flex justify-between"><span className="text-zinc-400">Velocity:</span><span className="text-[#00FF41] font-bold">1.42x</span></div>
              <div className="flex justify-between"><span className="text-zinc-400">Avg Settlement Latency:</span><span className="text-zinc-200 font-bold">31 ms</span></div>
            </div>
          </div>

          <div className="bg-[#0e0e10] border border-amber-800/80 rounded-sm p-5 space-y-3">
            <span className="text-xs font-bold text-amber-400 block border-b border-zinc-800 pb-2 uppercase tracking-wider">
              SCENARIO B: HIGH-VELOCITY STRESS RUN
            </span>
            <div className="text-xs space-y-2 font-mono">
              <div className="flex justify-between"><span className="text-zinc-400">CBDC Supply:</span><span className="text-zinc-200 font-bold">NT$ 185.0B</span></div>
              <div className="flex justify-between"><span className="text-zinc-400">Bank Deposit Impact:</span><span className="text-rose-400 font-bold">-38.2%</span></div>
              <div className="flex justify-between"><span className="text-zinc-400">Velocity:</span><span className="text-amber-300 font-bold">4.18x</span></div>
              <div className="flex justify-between"><span className="text-zinc-400">Avg Settlement Latency:</span><span className="text-amber-400 font-bold">88 ms</span></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
