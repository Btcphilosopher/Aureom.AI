import React, { useState } from 'react';
import { SystemStateSnapshot, Language, I18N } from '../types';
import { Activity, MapPin, Zap } from 'lucide-react';

interface FlowGraphViewProps {
  state: SystemStateSnapshot;
  language: Language;
}

export const FlowGraphView: React.FC<FlowGraphViewProps> = ({ state, language }) => {
  const t = I18N[language];
  const [selectedNode, setSelectedNode] = useState<string | null>(null);

  return (
    <div className="space-y-6 font-mono text-[#e0e0e0]">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* SECTION 27: TRANSACTION FLOW TOPOLOGY GRAPH */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
            <div>
              <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
                {language === 'TRADITIONAL_CHINESE' ? '中央銀行貨幣流向拓樸' : 'CBDC SETTLEMENT FLOW TOPOLOGY'}
              </h3>
              <p className="text-xs text-zinc-500">Section 27 - Real-Time Interbank & Retail Path</p>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/40 uppercase tracking-wider">
              ANIMATED GRAPH
            </span>
          </div>

          <div className="h-[360px] w-full relative bg-zinc-950/80 rounded border border-[#1a1a1c] p-4 flex flex-col items-center justify-between">
            {/* CENTRAL BANK */}
            <div className="z-10 bg-[#0e0e10] border-2 border-[#00FF41] px-4 py-2 rounded-sm shadow-[0_0_15px_rgba(0,255,65,0.2)] text-center">
              <span className="text-[10px] text-[#00FF41] block font-bold uppercase tracking-wider">MONETARY AUTHORITY</span>
              <span className="text-sm font-extrabold text-white">CENTRAL BANK (中央銀行)</span>
              <span className="text-[10px] text-zinc-400 block">NT$ 84.2B ISSUED</span>
            </div>

            {/* SVG Connecting Lines with Pulsing Pulses */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 400 360">
              {/* Lines to Banks */}
              <path d="M 200 65 L 110 145" stroke="#00FF41" strokeWidth="1.5" strokeDasharray="4 2" />
              <path d="M 200 65 L 290 145" stroke="#00FF41" strokeWidth="1.5" strokeDasharray="4 2" />

              {/* Lines to Wallets */}
              <path d="M 110 185 L 110 245" stroke="#22c55e" strokeWidth="1.5" />
              <path d="M 290 185 L 290 245" stroke="#22c55e" strokeWidth="1.5" />

              {/* Lines to Merchant */}
              <path d="M 110 285 L 200 330" stroke="#00FF41" strokeWidth="1.5" />
              <path d="M 290 285 L 200 330" stroke="#00FF41" strokeWidth="1.5" />

              {/* Animated pulses */}
              <circle cx="155" cy="105" r="4" fill="#00FF41" className="animate-ping" />
              <circle cx="245" cy="105" r="4" fill="#00FF41" className="animate-ping" />
              <circle cx="155" cy="308" r="4" fill="#00FF41" className="animate-pulse" />
            </svg>

            {/* BANKS LAYER */}
            <div className="w-full flex justify-around z-10">
              <div className="bg-[#0e0e10] border border-[#00FF41]/60 px-3 py-1.5 rounded-sm text-center w-36 shadow-md">
                <span className="text-[10px] text-[#00FF41] block font-bold uppercase tracking-wider">COMMERCIAL BANK</span>
                <span className="text-xs font-bold text-zinc-200">BANK A</span>
                <span className="text-[10px] text-zinc-400 block">NT$ 120B Reserves</span>
              </div>
              <div className="bg-[#0e0e10] border border-[#00FF41]/60 px-3 py-1.5 rounded-sm text-center w-36 shadow-md">
                <span className="text-[10px] text-[#00FF41] block font-bold uppercase tracking-wider">COMMERCIAL BANK</span>
                <span className="text-xs font-bold text-zinc-200">BANK B</span>
                <span className="text-[10px] text-zinc-400 block">NT$ 91B Reserves</span>
              </div>
            </div>

            {/* WALLETS LAYER */}
            <div className="w-full flex justify-around z-10">
              <div className="bg-[#0e0e10] border border-zinc-700 px-3 py-1.5 rounded-sm text-center w-32">
                <span className="text-[10px] text-zinc-500 block uppercase tracking-wider">RETAIL WALLET</span>
                <span className="text-xs font-bold text-zinc-300">WALLET A</span>
              </div>
              <div className="bg-[#0e0e10] border border-zinc-700 px-3 py-1.5 rounded-sm text-center w-32">
                <span className="text-[10px] text-zinc-500 block uppercase tracking-wider">RETAIL WALLET</span>
                <span className="text-xs font-bold text-zinc-300">WALLET B</span>
              </div>
            </div>

            {/* MERCHANT DESTINATION */}
            <div className="z-10 bg-[#0e0e10] border-2 border-[#00FF41] px-5 py-1.5 rounded-sm text-center shadow-[0_0_12px_rgba(0,255,65,0.25)]">
              <span className="text-[10px] text-[#00FF41] font-bold block uppercase tracking-wider">SETTLEMENT ENDPOINT</span>
              <span className="text-xs font-extrabold text-white">MERCHANT (商家)</span>
            </div>
          </div>
        </div>

        {/* SECTION 30: REGIONAL ECONOMIC NETWORK HEATMAP */}
        <div className="bg-[#0e0e10] border border-[#2a2a2c] rounded-sm p-5 shadow-lg">
          <div className="flex items-center justify-between border-b border-[#1a1a1c] pb-3 mb-4">
            <div>
              <h3 className="text-sm font-bold text-[#00FF41] tracking-wider uppercase">
                {language === 'TRADITIONAL_CHINESE' ? '臺灣區域經濟點熱圖' : 'TAIWAN REGIONAL REGION HEATMAP'}
              </h3>
              <p className="text-xs text-zinc-500">Section 30 - Synthetic Economic Nodes</p>
            </div>
            <span className="text-xs text-[#00FF41] font-mono font-bold uppercase tracking-wider">6 METRO NODES</span>
          </div>

          <div className="space-y-3">
            {state.nodes.map((node) => (
              <div
                key={node.id}
                onClick={() => setSelectedNode(node.id)}
                className={`p-3 rounded-sm border cursor-pointer transition-all ${
                  selectedNode === node.id
                    ? 'bg-[#00FF41]/10 border-[#00FF41]'
                    : 'bg-zinc-900/80 border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#00FF41]" />
                    <span className="font-bold text-zinc-200 text-xs">{node.name}</span>
                  </div>
                  <span className="text-xs text-[#00FF41] font-mono font-bold">{node.volume24h}</span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-zinc-950 h-2 rounded overflow-hidden border border-zinc-800">
                    <div
                      className="bg-[#00FF41] h-full"
                      style={{ width: `${node.activity * 100}%` }}
                    />
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono">
                    {(node.activity * 100).toFixed(0)}% Activity
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
