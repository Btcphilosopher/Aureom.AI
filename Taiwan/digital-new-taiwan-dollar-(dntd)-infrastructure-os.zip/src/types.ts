export type Language = 'TRADITIONAL_CHINESE' | 'ENGLISH';

export interface SystemStateSnapshot {
  cbdcSupply: number; // in minor units
  transactionVolume: number; // in minor units
  activeWallets: number;
  settlementLatency: number;
  riskLevel: string;
  systemStatus: string;
  bankBalances: Record<string, number>;
  nodes: Array<{
    id: string;
    name: string;
    volume24h: string;
    activity: number;
  }>;
  eventsPerSec: number;
  wsLatencyMs: number;
  settlementStats: {
    pending: number;
    processing: number;
    settled: number;
    failed: number;
    p50: number;
    p95: number;
    p99: number;
  };
}

export interface DntdEvent {
  type: 'MoneyIssued' | 'MoneyRedeemed' | 'PaymentCreated' | 'PaymentSettled' | 'RiskAlert' | 'LiquidityUpdate';
  stream: string;
  payload: any;
}

export const I18N = {
  TRADITIONAL_CHINESE: {
    title: '數位新臺幣',
    subtitle: '中央銀行系統指揮中心',
    systemOnline: '系統正常運作中',
    systemDegraded: '系統效能降級',
    systemOffline: '連線中斷',
    cbdcSupply: '貨幣供給 (CBDC)',
    livePayments: '即時支付流向',
    settlement: '清算與結算引擎',
    bankLiquidity: '商業銀行流動性',
    riskMonitor: '系統風險監控',
    telemetry: '系統技術遠測',
    issuance: '貨幣發行終端',
    redemption: '貨幣贖回終端',
    monetaryLab: '貨幣政策實驗室',
    ledgerExplorer: '數位帳本與事件鏈',
    archTopology: '系統架構與程式碼',
    runScenario: '執行情境模擬',
    issue: '發行數位新臺幣',
    redeem: '贖回數位新臺幣',
    confirmSimulation: '確認模擬操作',
    simulationNotice: '【僅供學術研究與模擬】',
    eventsPerSec: '每秒事件處理數',
    wsLatency: 'WebSocket 延遲',
    activeWallets: '活躍錢包總數',
    settledCount: '已清算交易筆數',
    pendingCount: '待清算數',
    processingCount: '處理中',
    failedCount: '失敗筆數',
    activeAlerts: '風險警報數',
    critical: '嚴重',
    high: '高風險',
    medium: '中風險',
    low: '低風險',
  },
  ENGLISH: {
    title: 'DIGITAL NEW TAIWAN DOLLAR',
    subtitle: 'CENTRAL BANK SYSTEM COMMAND CENTRE',
    systemOnline: 'SYSTEM ONLINE',
    systemDegraded: 'SYSTEM DEGRADED',
    systemOffline: 'CONNECTION LOST',
    cbdcSupply: 'CBDC SUPPLY',
    livePayments: 'LIVE PAYMENT FLOW',
    settlement: 'SETTLEMENT ENGINE',
    bankLiquidity: 'BANK LIQUIDITY',
    riskMonitor: 'RISK MONITOR',
    telemetry: 'SYSTEM TELEMETRY',
    issuance: 'CBDC ISSUANCE TERMINAL',
    redemption: 'CBDC REDEMPTION TERMINAL',
    monetaryLab: 'MONETARY POLICY LAB',
    ledgerExplorer: 'LEDGER & EVENT CHAIN',
    archTopology: 'ARCHITECTURE & CODEBASE',
    runScenario: 'RUN SCENARIO',
    issue: 'ISSUE DNTD',
    redeem: 'REDEEM DNTD',
    confirmSimulation: 'CONFIRM SIMULATION ACTION',
    simulationNotice: '[ SIMULATION RESEARCH ONLY ]',
    eventsPerSec: 'events/sec',
    wsLatency: 'WebSocket latency',
    activeWallets: 'Active Wallets',
    settledCount: 'Settled Transactions',
    pendingCount: 'Pending',
    processingCount: 'Processing',
    failedCount: 'Failed',
    activeAlerts: 'Active Alerts',
    critical: 'CRITICAL',
    high: 'HIGH',
    medium: 'MEDIUM',
    low: 'LOW',
  },
};

export function formatNTD(amountMinor: number, language: Language = 'TRADITIONAL_CHINESE'): String {
  const major = amountMinor / 100;
  if (major >= 1_000_000_000) {
    const b = (major / 1_000_000_000).toFixed(1);
    return language === 'TRADITIONAL_CHINESE' ? `NT$ ${b}億` : `NT$ ${b}B`;
  }
  if (major >= 1_000_000) {
    const m = (major / 1_000_000).toFixed(1);
    return language === 'TRADITIONAL_CHINESE' ? `NT$ ${m}萬` : `NT$ ${m}M`;
  }
  return `NT$ ${major.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
