/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { FlowGraphView } from './components/FlowGraphView';
import { SettlementRiskView } from './components/SettlementRiskView';
import { IssuanceRedemptionView } from './components/IssuanceRedemptionView';
import { MonetaryLabView } from './components/MonetaryLabView';
import { LedgerExplorerView } from './components/LedgerExplorerView';
import { ArchitectureView } from './components/ArchitectureView';
import { SimulationBar } from './components/SimulationBar';
import { SystemStateSnapshot, DntdEvent, Language } from './types';

export default function App() {
  const [language, setLanguage] = useState<Language>('TRADITIONAL_CHINESE');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [events, setEvents] = useState<DntdEvent[]>([]);

  const [systemState, setSystemState] = useState<SystemStateSnapshot>({
    cbdcSupply: 84_200_000_000_00,
    transactionVolume: 18_492_000_000,
    activeWallets: 48200,
    settlementLatency: 31.0,
    riskLevel: 'LOW',
    systemStatus: 'ONLINE',
    bankBalances: {
      BANK_A: 120_000_000_000_00,
      BANK_B: 91_000_000_000_00,
      BANK_C: 65_000_000_000_00,
    },
    nodes: [
      { id: 'NODE_TPE', name: 'Taipei (臺北)', volume24h: 'NT$ 34.2B', activity: 0.92 },
      { id: 'NODE_NTP', name: 'New Taipei (新北)', volume24h: 'NT$ 21.8B', activity: 0.88 },
      { id: 'NODE_TYN', name: 'Taoyuan (桃園)', volume24h: 'NT$ 12.4B', activity: 0.76 },
      { id: 'NODE_TXG', name: 'Taichung (臺中)', volume24h: 'NT$ 18.1B', activity: 0.84 },
      { id: 'NODE_TNN', name: 'Tainan (臺南)', volume24h: 'NT$ 9.6B', activity: 0.69 },
      { id: 'NODE_KHH', name: 'Kaohsiung (高雄)', volume24h: 'NT$ 15.3B', activity: 0.81 },
    ],
    eventsPerSec: 18492,
    wsLatencyMs: 23,
    settlementStats: {
      pending: 14,
      processing: 27,
      settled: 9421,
      failed: 2,
      p50: 31,
      p95: 54,
      p99: 88,
    },
  });

  const fetchState = () => {
    fetch('/api/dntd/state')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.cbdcSupply) {
          setSystemState(data);
        }
      })
      .catch((e) => console.error(e));
  };

  useEffect(() => {
    fetchState();
    const interval = setInterval(fetchState, 3000);

    // Setup WebSocket Event Stream to Rust Overlay
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/events`;
    const ws = new WebSocket(wsUrl);

    ws.onmessage = (msg) => {
      try {
        const parsed = JSON.parse(msg.data);
        if (parsed && parsed.type) {
          setEvents((prev) => [parsed, ...prev.slice(0, 49)]);

          if (parsed.type === 'MoneyIssued' || parsed.type === 'MoneyRedeemed') {
            fetchState();
          }
        }
      } catch (e) {
        // ignore
      }
    };

    return () => {
      clearInterval(interval);
      ws.close();
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0b] text-[#e0e0e0] font-mono flex flex-col justify-between selection:bg-[#00FF41] selection:text-black">
      <div>
        <Header
          language={language}
          onLanguageChange={setLanguage}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          systemStatus={systemState.systemStatus}
          eventsPerSec={systemState.eventsPerSec}
        />

        <main className="max-w-7xl mx-auto px-4 py-6">
          {activeTab === 'dashboard' && (
            <DashboardView state={systemState} events={events} language={language} />
          )}

          {activeTab === 'flow' && (
            <FlowGraphView state={systemState} language={language} />
          )}

          {activeTab === 'settlement' && (
            <SettlementRiskView state={systemState} events={events} language={language} />
          )}

          {activeTab === 'issuance' && (
            <IssuanceRedemptionView
              state={systemState}
              language={language}
              onRefreshState={fetchState}
            />
          )}

          {activeTab === 'monetary' && (
            <MonetaryLabView state={systemState} language={language} />
          )}

          {activeTab === 'ledger' && (
            <LedgerExplorerView events={events} language={language} />
          )}

          {activeTab === 'codebase' && (
            <ArchitectureView language={language} />
          )}
        </main>
      </div>

      <div>
        <SimulationBar />
        <footer className="h-7 bg-[#00FF41] text-black text-[10px] font-bold px-6 flex items-center justify-between uppercase tracking-wider select-none">
          <span>CENTRAL BANK OF TAIWAN | FINANCIAL RESEARCH DIVISION | SIMULATION MODE ACTIVE</span>
          <span className="hidden sm:inline">TAIPEI-CB-SIM-01 | NODE: RUST-BUS-01 | SESSION: 4A-8F-21</span>
        </footer>
      </div>
    </div>
  );
}
