import express from "express";
import http from "http";
import path from "path";
import fs from "fs";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";

const app = express();
app.use(express.json());

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws/events" });

// ===================================================================
// DNTD AUTHORITATIVE MONETARY LEDGER (PYTHON ENGINE EMULATOR)
// ===================================================================
interface Money {
  currency: string;
  amount_minor: number;
}

interface Wallet {
  id: string;
  name: string;
  type: string;
  balance_minor: number;
}

class PythonMonetaryEngine {
  public totalSupplyMinor: number = 84_200_000_000_00; // NT$84.2 Billion
  public paymentVolume24hMinor: number = 18_492_000_000;
  public totalSettlementCount: number = 9421;
  public activeWallets: number = 48200;
  public settlementLatencyP50: number = 31.0;
  public settlementLatencyP95: number = 54.0;
  public settlementLatencyP99: number = 88.0;
  public riskLevel: string = "LOW";

  public bankBalances: Record<string, number> = {
    BANK_A: 120_000_000_000_00, // NT$120B
    BANK_B: 91_000_000_000_00,  // NT$91B
    BANK_C: 65_000_000_000_00,  // NT$65B
  };

  public nodes = [
    { id: "NODE_TPE", name: "Taipei (臺北)", volume24h: "NT$ 34.2B", activity: 0.92 },
    { id: "NODE_NTP", name: "New Taipei (新北)", volume24h: "NT$ 21.8B", activity: 0.88 },
    { id: "NODE_TYN", name: "Taoyuan (桃園)", volume24h: "NT$ 12.4B", activity: 0.76 },
    { id: "NODE_TXG", name: "Taichung (臺中)", volume24h: "NT$ 18.1B", activity: 0.84 },
    { id: "NODE_TNN", name: "Tainan (臺南)", volume24h: "NT$ 9.6B", activity: 0.69 },
    { id: "NODE_KHH", name: "Kaohsiung (高雄)", volume24h: "NT$ 15.3B", activity: 0.81 },
  ];

  public issueCBDC(targetBankId: string, amountMinor: number, reason: string) {
    if (amountMinor <= 0) throw new Error("Amount must be greater than zero");
    this.totalSupplyMinor += amountMinor;
    this.bankBalances[targetBankId] = (this.bankBalances[targetBankId] || 0) + amountMinor;

    const eventId = `EVT-ISSUE-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const txId = `8A${Math.floor(1000 + Math.random() * 9000)}`;
    return {
      type: "MoneyIssued",
      stream: "MONETARY",
      payload: {
        event_id: eventId,
        timestamp: Date.now(),
        source: "python-engine",
        schema_version: "1.0.0",
        correlation_id: `CORR-${Math.random().toString(36).substring(7)}`,
        sequence_number: Date.now(),
        transaction_id: txId,
        target_bank_id: targetBankId,
        amount_minor: amountMinor,
        reason: reason || "Central Bank Reserve Injection",
      },
    };
  }

  public redeemCBDC(bankId: string, amountMinor: number) {
    const current = this.bankBalances[bankId] || 0;
    if (current < amountMinor) throw new Error(`Insufficient funds in bank ${bankId}`);

    this.bankBalances[bankId] -= amountMinor;
    this.totalSupplyMinor -= amountMinor;

    const eventId = `EVT-REDEEM-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const txId = `8R${Math.floor(1000 + Math.random() * 9000)}`;
    return {
      type: "MoneyRedeemed",
      stream: "MONETARY",
      payload: {
        event_id: eventId,
        timestamp: Date.now(),
        source: "python-engine",
        schema_version: "1.0.0",
        correlation_id: `CORR-${Math.random().toString(36).substring(7)}`,
        sequence_number: Date.now(),
        transaction_id: txId,
        bank_id: bankId,
        amount_minor: amountMinor,
      },
    };
  }

  public generateSyntheticPayment() {
    const senders = ["W-01 (Taipei)", "W-04 (Taichung)", "BANK-A", "W-08 (Kaohsiung)", "M-02 (Merchant)"];
    const recipients = ["M-02 (Merchant)", "W-09 (Citizen)", "BANK-B", "M-05 (Retail)", "W-12 (Tainan)"];
    const sender = senders[Math.floor(Math.random() * senders.length)];
    let recipient = recipients[Math.floor(Math.random() * recipients.length)];
    while (recipient === sender) {
      recipient = recipients[Math.floor(Math.random() * recipients.length)];
    }

    const amounts = [25000, 120000, 5000000, 85000, 320000, 5000000000]; // 250, 1200, 50,000, etc.
    const amountMinor = amounts[Math.floor(Math.random() * amounts.length)];
    this.paymentVolume24hMinor += amountMinor;
    this.totalSettlementCount += 1;

    const latency = Math.floor(20 + Math.random() * 35);
    const txId = `8A${Math.floor(10 + Math.random() * 89)}${Math.floor(10 + Math.random() * 89)}`;

    return {
      type: "PaymentSettled",
      stream: "PAYMENT",
      payload: {
        event_id: `EVT-SETTLE-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        timestamp: Date.now(),
        source: "python-engine",
        schema_version: "1.0.0",
        correlation_id: `CORR-${Math.random().toString(36).substring(7)}`,
        sequence_number: Date.now(),
        payment_id: txId,
        sender_id: sender,
        recipient_id: recipient,
        amount_minor: amountMinor,
        latency_ms: latency,
        status: "SETTLED",
      },
    };
  }
}

const pythonEngine = new PythonMonetaryEngine();

// ===================================================================
// RUST EVENT BUS & TELEMETRY OVERLAY EMULATOR
// ===================================================================
let activeWebSocketClients = 0;
let eventsProcessedTotal = 0;
let speedMultiplier = 1.0;
let simulationPaused = false;

function broadcastEvent(event: any) {
  eventsProcessedTotal += 1;
  const jsonStr = JSON.stringify(event);
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(jsonStr);
    }
  });
}

// Background simulation ticker
setInterval(() => {
  if (simulationPaused) return;

  const eventCount = Math.min(5, Math.ceil(speedMultiplier));
  for (let i = 0; i < eventCount; i++) {
    const event = pythonEngine.generateSyntheticPayment();
    broadcastEvent(event);
  }

  // Periodic liquidity & risk events
  if (Math.random() < 0.15) {
    const bankIds = ["BANK_A", "BANK_B", "BANK_C"];
    const bankId = bankIds[Math.floor(Math.random() * bankIds.length)];
    const delta = (Math.random() - 0.48) * 500_000_000_00;
    pythonEngine.bankBalances[bankId] = Math.max(10_000_000_000_00, pythonEngine.bankBalances[bankId] + delta);

    broadcastEvent({
      type: "LiquidityUpdate",
      stream: "LIQUIDITY",
      payload: {
        event_id: `EVT-LIQ-${Date.now()}`,
        timestamp: Date.now(),
        source: "rust-overlay",
        bank_id: bankId,
        balance_minor: pythonEngine.bankBalances[bankId],
        reserve_ratio: 0.15 + (Math.random() * 0.05),
      },
    });
  }

  if (Math.random() < 0.05) {
    const severities = ["LOW", "MEDIUM", "HIGH"];
    const titles = ["ABNORMAL VELOCITY", "UNUSUAL SETTLEMENT PEAK", "RESERVE DIVERGENCE DETECTED"];
    const idx = Math.floor(Math.random() * titles.length);

    broadcastEvent({
      type: "RiskAlert",
      stream: "RISK",
      payload: {
        event_id: `EVT-RISK-${Date.now()}`,
        timestamp: Date.now(),
        source: "python-engine",
        risk_id: `RSK-${Math.floor(100 + Math.random() * 900)}`,
        title: titles[idx],
        severity: severities[idx],
        description: "Automated risk monitor detected anomaly in transaction frequency across Taipei nodes.",
        source_node: "SIMULATION_ENGINE",
      },
    });
  }
}, 1200);

// ===================================================================
// API ROUTES
// ===================================================================
app.get("/api/health", (req, res) => {
  res.json({
    python_engine: "ONLINE",
    rust_overlay: "ONLINE",
    database: "ONLINE",
    event_bus: "ONLINE",
    websocket: "ONLINE",
    kotlin_client: "ONLINE",
    timestamp: Date.now(),
  });
});

app.get("/api/dntd/state", (req, res) => {
  res.json({
    cbdcSupply: pythonEngine.totalSupplyMinor,
    transactionVolume: pythonEngine.paymentVolume24hMinor,
    activeWallets: pythonEngine.activeWallets,
    settlementLatency: pythonEngine.settlementLatencyP50,
    riskLevel: pythonEngine.riskLevel,
    systemStatus: "ONLINE",
    bankBalances: pythonEngine.bankBalances,
    nodes: pythonEngine.nodes,
    eventsPerSec: Math.floor(18492 * speedMultiplier),
    wsLatencyMs: 23,
    settlementStats: {
      pending: 14,
      processing: 27,
      settled: pythonEngine.totalSettlementCount,
      failed: 2,
      p50: pythonEngine.settlementLatencyP50,
      p95: pythonEngine.settlementLatencyP95,
      p99: pythonEngine.settlementLatencyP99,
    },
  });
});

app.post("/api/dntd/issue", (req, res) => {
  try {
    const { target_bank_id, amount_minor, reason } = req.body;
    const event = pythonEngine.issueCBDC(target_bank_id, Number(amount_minor), reason);
    broadcastEvent(event);
    res.json({
      success: true,
      transaction_id: event.payload.transaction_id,
      new_supply: pythonEngine.totalSupplyMinor,
    });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.post("/api/dntd/redeem", (req, res) => {
  try {
    const { bank_id, amount_minor } = req.body;
    const event = pythonEngine.redeemCBDC(bank_id, Number(amount_minor));
    broadcastEvent(event);
    res.json({
      success: true,
      transaction_id: event.payload.transaction_id,
      new_supply: pythonEngine.totalSupplyMinor,
    });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.post("/api/dntd/simulation/control", (req, res) => {
  const { speed, paused } = req.body;
  if (typeof speed === "number") speedMultiplier = speed;
  if (typeof paused === "boolean") simulationPaused = paused;
  res.json({ success: true, speedMultiplier, simulationPaused });
});

// Helper endpoint to view codebase files
app.get("/api/dntd/codebase", (req, res) => {
  const filePaths = [
    "proto/dntd.proto",
    "dntd-rust/Cargo.toml",
    "dntd-rust/src/main.rs",
    "dntd-rust/src/events/bus.rs",
    "dntd-rust/src/events/router.rs",
    "dntd-rust/src/events/event.rs",
    "dntd-rust/src/cache/state_cache.rs",
    "dntd-rust/src/security/signing.rs",
    "dntd-rust/src/security/verification.rs",
    "dntd-kotlin/Main.kt",
    "dntd-kotlin/core/state/DntdSystemState.kt",
    "dntd-kotlin/viewmodel/DntdViewModel.kt",
    "python-engine/ledger.py",
    "python-engine/main.py",
    "docker/docker-compose.yml",
    "Makefile",
    "docs/ARCHITECTURE.md"
  ];

  const contents: Record<string, string> = {};
  filePaths.forEach((fp) => {
    try {
      const full = path.join(process.cwd(), fp);
      if (fs.existsSync(full)) {
        contents[fp] = fs.readFileSync(full, "utf-8");
      }
    } catch (e) {
      // ignore
    }
  });

  res.json({ files: contents });
});

// WebSocket Connection handler
wss.on("connection", (ws) => {
  activeWebSocketClients += 1;
  ws.send(
    JSON.stringify({
      type: "SystemStatus",
      stream: "TELEMETRY",
      payload: {
        status: "CONNECTED",
        python_engine: "ONLINE",
        rust_overlay: "ONLINE",
        active_clients: activeWebSocketClients,
      },
    })
  );

  ws.on("close", () => {
    activeWebSocketClients = Math.max(0, activeWebSocketClients - 1);
  });
});

// ===================================================================
// VITE MIDDLEWARE SETUP
// ===================================================================
async function startServer() {
  const PORT = 3000;

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`DNTD System Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
