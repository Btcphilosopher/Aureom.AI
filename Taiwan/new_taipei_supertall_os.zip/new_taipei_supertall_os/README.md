# NEW TAIPEI SUPERTALL CONSTRUCTION OS
### 新北超高層建築智慧施工作業系統

A Python 3.13+ engineering and construction-management platform for
**planning, simulating, optimising, and monitoring** the construction of
supertall/high-rise buildings in New Taipei City, Taiwan.

> **SIMULATION ONLY / 模擬專案.** The bundled demonstration project
> (`NT-SUPERTALL-001`, 420 m / 92 floors / 6 basements) is entirely
> synthetic. This software is **not** a replacement for licensed
> architects, structural/geotechnical/construction/fire engineers,
> building authorities, certified structural-analysis software, statutory
> approval, or site safety management. **Every structural, geotechnical,
> and seismic number this platform produces is a PRELIMINARY ENGINEERING
> ESTIMATE** and must be independently verified by qualified, licensed
> professionals before it informs any real design, permitting, or
> construction decision. Compliance flags are configurable
> `ComplianceTrigger`s for professional/regulatory review — **never** an
> approval decision. See `domain/calculation.py` and
> `compliance/new_taipei.py` for the full disclaimers embedded in the code.

---

## What it does

Models the full delivery pipeline of a hypothetical supertall tower —
site → planning → geotechnical → foundation → excavation → podium → core →
frame → façade → MEP → vertical transport → interiors → testing →
commissioning → completion — and optimises across **duration, cost,
labour, materials, cranes, hoists, concrete/steel/truck logistics,
storage, sequencing, weather risk, cash flow, embodied carbon, and
regulatory review triggers.**

It can answer questions like:

- How long will the building take, and what's the critical path?
- What's the cheapest / fastest / lowest-risk / lowest-carbon strategy?
- Where are the bottlenecks? How many cranes/workers are required?
- When should long-lead materials (elevators, steel) be ordered?
- What happens if a typhoon causes two weeks of downtime? If excavation
  slips 30 days? If steel prices rise 20%? If we add a crane?
- What's the P80 completion date? The P80 cost?
- What regulatory review triggers are present, and what needs
  professional engineering review?
- What's happening on site today? (digital twin / daily control centre)

## Architecture

```
BUILDING → STRUCTURE / SCHEDULE / FINANCE → ENGINEERING / SIMULATION / COST MODEL
         → OPTIMISATION ENGINE → LOGISTICS / RISK / COMPLIANCE → DIGITAL TWIN
         → FastAPI + WebSockets
```

| Package | Responsibility |
|---|---|
| `config/` | Typed settings + versioned regulatory/material/labour rate config (YAML) |
| `domain/` | Building, floor, structural, foundation, excavation, crane, hoist, material, worker, equipment, site models |
| `engineering/` | Preliminary loads, wind, seismic, structural demand, foundation, geotechnical, excavation-risk calculations — every result is a traceable `CalculationResult` |
| `construction/` | Sequencing, CPM schedule engine, concrete/steel/facade/MEP/interiors/commissioning/vertical-transport engines, risk register |
| `logistics/` | Site-as-a-graph, truck routing, crane/hoist queueing, concrete logistics |
| `optimisation/` | OR-Tools CP-SAT schedule crashing, crane count/position, cost, workforce, materials, multi-objective PLAN A–E |
| `simulation/` | SimPy floor-by-floor construction, truck queueing, weather/typhoon scenarios, schedule & cost Monte Carlo, what-if scenario engine |
| `finance/` | Cost, cash-flow S-curve, procurement/long-lead tracking, carbon, waste, sensitivity |
| `compliance/` | Versioned New Taipei regulatory rules, `ComplianceTrigger` flags, urban design review, compliance dashboard |
| `digital_twin/` | Real-time-style site entities, telemetry, per-floor progress, replay, rule-based construction copilot |
| `database/` | SQLAlchemy ORM models + repositories (SQLite by default; PostgreSQL/PostGIS in production) |
| `api/` | FastAPI REST endpoints + WebSocket streams |
| `reports/` | CSV / Parquet / Excel / JSON / PDF report generators |

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .

# Run the CLI demonstration (builds NT-SUPERTALL-001, optimises its
# schedule, runs the construction simulation, prices it, and prints the
# PLAN A-E multi-objective comparison):
python app.py

# Run the API:
uvicorn new_taipei_supertall_os.api.app:app --reload
# then browse http://127.0.0.1:8000/docs

# Run the tests:
pip install -e ".[dev]"
pytest
```

## Configuration & regulatory versioning

Nothing that matters — material rates, labour rates, site parameters, or
regulatory thresholds — is hard-coded in an algorithm. They live in:

- `new_taipei_supertall_os/config/*.yaml` — site, currency, material, and labour rates.
- `new_taipei_supertall_os/regulations/new_taipei/<year>/rules.yaml` — versioned
  `RegulationRule(jurisdiction, effective_date, source, parameter, value, applicability)`
  records. Add a new year's rule-set as a sibling directory and switch
  `active_regulatory_year` in `config/settings.py`. These are an
  **illustrative, configurable representation** of the kinds of
  thresholds New Taipei's review processes currently use — reconcile
  against the official current regulations before relying on them.

## Auditability

Every calculation that could inform a real decision returns a
`domain.calculation.CalculationResult`: `value, units, method, inputs,
assumptions, timestamp, model_version, confidence`. Structural,
geotechnical, wind, seismic, and foundation results are automatically
stamped with the `PRELIMINARY ENGINEERING ESTIMATE` notice. Buildings,
schedules, cost estimates, regulatory configs, optimisation runs, and
simulation runs all carry `version, timestamp, author, scenario`.

## Extending with real project data

- Site investigation: `engineering.geotechnical.SiteInvestigation.from_csv(...)`
- Neighbouring assets / excavation monitoring: `domain.site.NeighbouringAsset`
- Regulatory updates: add a new `regulations/new_taipei/<year>/rules.yaml`
- Real cost/labour rates: edit `config/materials.yaml` / `config/labour.yaml`

None of this replaces professional engineering judgement, licensed
review, or the competent authority's own approval process.
