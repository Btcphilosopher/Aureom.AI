from new_taipei_supertall_os.optimisation.schedule import ScheduleOptimizer
from new_taipei_supertall_os.simulation.engine import ConstructionSimulation
from new_taipei_supertall_os.simulation.scenarios import ScenarioEngine
from new_taipei_supertall_os.config.settings import get_settings


def test_schedule_optimizer_runs_and_does_not_lengthen_schedule(demo_building):
    optimizer = ScheduleOptimizer(time_limit_s=5)
    schedule = optimizer.optimize(demo_building)
    assert schedule.duration_days > 0
    assert len(schedule.critical_path) > 0


def test_construction_simulation_completion_probability_in_range(demo_building):
    sim = ConstructionSimulation(demo_building, n_cranes=4)
    result = sim.run(days=400, n_trials=10)
    assert 0.0 <= result.completion_probability <= 1.0
    assert 0.0 <= result.average_crane_utilisation <= 1.0
    assert result.p50_days <= result.p80_days <= result.p90_days


def test_scenario_engine_add_floors_increases_duration_and_cost(demo_building):
    engine = ScenarioEngine(get_settings())
    result = engine.what_if_add_floors(demo_building, added_floors=10)
    assert result.duration_delta_days > 0
    assert result.resource_delta["floors_delta"] == 10
