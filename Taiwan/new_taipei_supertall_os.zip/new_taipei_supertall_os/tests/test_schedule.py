from new_taipei_supertall_os.construction.schedule import CriticalPathEngine, ProjectSchedule, Task
from new_taipei_supertall_os.construction.sequencing import build_demo_schedule


def test_cpm_engine_on_simple_diamond():
    tasks = [
        Task(id="a", name="A", duration_days=5, predecessors=[]),
        Task(id="b", name="B", duration_days=3, predecessors=["a"]),
        Task(id="c", name="C", duration_days=7, predecessors=["a"]),
        Task(id="d", name="D", duration_days=2, predecessors=["b", "c"]),
    ]
    schedule = ProjectSchedule(project_id="p1", tasks=tasks)
    CriticalPathEngine().run(schedule)
    assert schedule.duration_days == 14  # 5 + 7 + 2, via the longer branch
    assert "c" in schedule.critical_path
    assert "b" not in schedule.critical_path


def test_demo_schedule_builds_and_is_acyclic(demo_building):
    schedule = build_demo_schedule(demo_building)
    CriticalPathEngine().run(schedule)
    assert schedule.duration_days > 0
    assert len(schedule.critical_path) > 0
    # every task id referenced as a predecessor must exist
    ids = {t.id for t in schedule.tasks}
    for t in schedule.tasks:
        for p in t.predecessors:
            assert p in ids


def test_smaller_building_has_shorter_schedule(demo_building):
    small = demo_building.model_copy(update={"floors": 20, "height_m": 90, "basement_floors": 2})
    s_demo = build_demo_schedule(demo_building)
    s_small = build_demo_schedule(small)
    CriticalPathEngine().run(s_demo)
    CriticalPathEngine().run(s_small)
    assert s_small.duration_days < s_demo.duration_days
