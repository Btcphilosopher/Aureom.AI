import pytest

from new_taipei_supertall_os.domain.building import Building


@pytest.fixture
def demo_building() -> Building:
    return Building(
        id="NT-SUPERTALL-001",
        name="Test Tower",
        height_m=420,
        floors=92,
        basement_floors=6,
        gross_floor_area_m2=250000,
        site_area_m2=18000,
        use_mix={"commercial": 0.25, "office": 0.40, "residential": 0.25, "hotel": 0.10},
    )
