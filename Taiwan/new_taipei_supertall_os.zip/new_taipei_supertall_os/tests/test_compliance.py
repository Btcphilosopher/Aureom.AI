from new_taipei_supertall_os.compliance.approvals import ReviewStatus, build_compliance_dashboard
from new_taipei_supertall_os.compliance.new_taipei import NewTaipeiPlanningRules
from new_taipei_supertall_os.compliance.planning import UrbanDesignReviewEngine
from new_taipei_supertall_os.domain.excavation import ExcavationModel


def test_supertall_demo_triggers_urban_design_review(demo_building):
    udr = UrbanDesignReviewEngine()
    assessment = udr.assess(demo_building.site_area_m2, demo_building.gross_floor_area_m2, demo_building.height_m)
    assert assessment.review_required is True
    assert assessment.documents_required


def test_compliance_dashboard_never_claims_approval(demo_building):
    exc = ExcavationModel(excavation_depth_m=32, excavation_area_m2=15000, basement_levels=6)
    triggers = NewTaipeiPlanningRules().evaluate(demo_building, exc, [])
    dashboard = build_compliance_dashboard(demo_building.id, triggers)
    assert "does not imply" in dashboard.disclaimer.lower() or "NOT" in dashboard.disclaimer
    statuses = {item.category.value: item.status for item in dashboard.items}
    assert statuses["urban_design_review"] == ReviewStatus.REQUIRES_DOCUMENT_REVIEW
    # no status in this dashboard is ever "APPROVED" without explicit human action
    assert all(s != ReviewStatus.APPROVED for s in statuses.values())
