from new_taipei_supertall_os.domain.calculation import PRELIMINARY_ENGINEERING_NOTICE
from new_taipei_supertall_os.domain.excavation import ExcavationModel
from new_taipei_supertall_os.domain.foundation import FoundationModel
from new_taipei_supertall_os.domain.site import NeighbouringAsset
from new_taipei_supertall_os.engineering.excavation_model import ExcavationRiskEngine, RiskLevel, estimated_duration_days
from new_taipei_supertall_os.engineering.foundation_model import preliminary_foundation_demand
from new_taipei_supertall_os.engineering.geotechnical import SiteInvestigation
from new_taipei_supertall_os.engineering.seismic import SeismicModel
from new_taipei_supertall_os.engineering.wind import WindModel


def test_wind_and_seismic_results_are_stamped_preliminary(demo_building):
    wind = WindModel(building_height_m=demo_building.height_m, building_width_m=55, building_depth_m=55, wind_speed_m_s=42)
    shear = wind.total_wind_force_kn()
    assert shear.value > 0
    assert PRELIMINARY_ENGINEERING_NOTICE in shear.assumptions

    seismic = SeismicModel(building_mass_tonnes=300000, height_m=demo_building.height_m)
    base_shear = seismic.base_shear_kn()
    assert base_shear.value > 0
    assert PRELIMINARY_ENGINEERING_NOTICE in base_shear.assumptions


def test_foundation_demand_positive():
    foundation = FoundationModel(pile_count=250, pile_capacity_kn=18000, pile_length_m=60)
    site = SiteInvestigation.placeholder("test-site")
    demand = preliminary_foundation_demand(foundation, gravity_reaction_kn=3_000_000, site=site)
    assert demand.average_pile_load.value > 0
    assert 0 < demand.average_pile_utilisation.value < 5  # sanity bound, not a design check
    assert demand.settlement_estimate.value > 0


def test_excavation_risk_flags_critical_for_close_sensitive_neighbour():
    exc = ExcavationModel(excavation_depth_m=32, excavation_area_m2=15000, basement_levels=6)
    neighbours = [NeighbouringAsset(id="n1", name="MRT viaduct", distance_m=10, sensitivity="critical")]
    assessment = ExcavationRiskEngine().assess(exc, neighbours)
    assert assessment.overall_level == RiskLevel.CRITICAL
    assert estimated_duration_days(exc).value > 0
