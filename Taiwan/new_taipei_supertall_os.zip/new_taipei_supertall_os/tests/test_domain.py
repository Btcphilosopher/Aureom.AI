import pytest
from pydantic import ValidationError

from new_taipei_supertall_os.domain.building import MassingEngine


def test_building_is_supertall(demo_building):
    assert demo_building.is_supertall
    assert demo_building.total_floor_count_incl_basement == 98


def test_use_mix_must_sum_to_one():
    from new_taipei_supertall_os.domain.building import Building
    with pytest.raises(ValidationError):
        Building(id="x", name="x", height_m=100, floors=20, gross_floor_area_m2=1000,
                  site_area_m2=1000, use_mix={"office": 0.2, "residential": 0.2})


def test_massing_engine_generates_all_floors(demo_building):
    profile = MassingEngine().generate(demo_building)
    numbers = sorted(f.number for f in profile.floors)
    assert numbers[0] == -demo_building.basement_floors
    assert numbers[-1] == demo_building.floors
    assert len(numbers) == demo_building.total_floor_count_incl_basement

    zones = profile.floor_area_by_zone()
    assert set(zones) >= {"basement", "podium", "lower_tower"}
    assert all(area > 0 for area in zones.values())
