from fastapi.testclient import TestClient

from new_taipei_supertall_os.api.app import app

client = TestClient(app)

ENDPOINTS = [
    "/", "/health", "/api/project", "/api/building", "/api/floors", "/api/structure",
    "/api/foundation", "/api/excavation", "/api/cranes", "/api/hoists", "/api/workforce",
    "/api/materials", "/api/schedule", "/api/cost", "/api/risk", "/api/weather",
    "/api/compliance", "/api/optimisation",
]


def test_all_rest_endpoints_return_200():
    for path in ENDPOINTS:
        response = client.get(path)
        assert response.status_code == 200, f"{path} -> {response.status_code}: {response.text[:300]}"


def test_simulation_endpoint_accepts_query_params():
    response = client.get("/api/simulation", params={"n_trials": 5})
    assert response.status_code == 200
    body = response.json()
    assert "completion_probability" in body


def test_digital_twin_websocket_streams_a_snapshot():
    with client.websocket_connect("/ws/digital-twin") as ws:
        data = ws.receive_json()
        assert data["project_id"] == "NT-SUPERTALL-001"
        assert len(data["entities"]) > 0
