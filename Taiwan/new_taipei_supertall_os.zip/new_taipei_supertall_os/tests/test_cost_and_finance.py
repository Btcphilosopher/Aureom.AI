from new_taipei_supertall_os.config.settings import get_settings
from new_taipei_supertall_os.construction.concrete import ConcreteEngine
from new_taipei_supertall_os.domain.building import MassingEngine
from new_taipei_supertall_os.finance.cost import ConstructionCostEngine, CostCategory, cost_per_m2
from new_taipei_supertall_os.finance.sensitivity import CostMonteCarlo


def _estimate(demo_building):
    settings = get_settings()
    massing = MassingEngine().generate(demo_building)
    above = [f for f in massing.floors if f.number > 0]
    ce = ConcreteEngine()
    pours = [ce.plan_pour(f, "slab", ce.floor_slab_volume_m3(f)) for f in above[:15]]
    return ConstructionCostEngine(settings).estimate(demo_building, massing.floors, pours)


def test_cost_estimate_has_positive_total_and_all_categories(demo_building):
    estimate = _estimate(demo_building)
    assert estimate.total_twd > 0
    categories = {li.category for li in estimate.line_items}
    assert CostCategory.CONCRETE in categories
    assert CostCategory.CONTINGENCY in categories
    assert cost_per_m2(estimate, demo_building.gross_floor_area_m2) > 0


def test_cost_monte_carlo_percentiles_are_ordered(demo_building):
    estimate = _estimate(demo_building)
    mc = CostMonteCarlo(seed=42)
    result = mc.run(estimate, n_simulations=300)
    assert result.p50_cost_twd <= result.p80_cost_twd <= result.p90_cost_twd
