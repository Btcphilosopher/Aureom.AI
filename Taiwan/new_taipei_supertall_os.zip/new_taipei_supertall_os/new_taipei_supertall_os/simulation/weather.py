"""Weather construction impact engine and typhoon scenario
(spec sections 42, 43)."""

from __future__ import annotations

import random
from enum import Enum

from pydantic import BaseModel


class WeatherEvent(str, Enum):
    CLEAR = "clear"
    RAIN = "rain"
    HEAVY_RAIN = "heavy_rain"
    TYPHOON = "typhoon"
    HIGH_WIND = "high_wind"
    EXTREME_HEAT = "extreme_heat"
    LIGHTNING = "lightning"


class WeatherImpact(BaseModel):
    event: WeatherEvent
    tower_crane_factor: float   # productivity multiplier, 0 = full stop
    concrete_factor: float
    facade_factor: float
    lifting_factor: float
    excavation_factor: float
    external_work_factor: float
    transport_factor: float


IMPACT_TABLE: dict[WeatherEvent, WeatherImpact] = {
    WeatherEvent.CLEAR: WeatherImpact(event=WeatherEvent.CLEAR, tower_crane_factor=1.0, concrete_factor=1.0,
                                       facade_factor=1.0, lifting_factor=1.0, excavation_factor=1.0,
                                       external_work_factor=1.0, transport_factor=1.0),
    WeatherEvent.RAIN: WeatherImpact(event=WeatherEvent.RAIN, tower_crane_factor=0.85, concrete_factor=0.9,
                                      facade_factor=0.8, lifting_factor=0.85, excavation_factor=0.8,
                                      external_work_factor=0.7, transport_factor=0.9),
    WeatherEvent.HEAVY_RAIN: WeatherImpact(event=WeatherEvent.HEAVY_RAIN, tower_crane_factor=0.5, concrete_factor=0.4,
                                            facade_factor=0.3, lifting_factor=0.5, excavation_factor=0.3,
                                            external_work_factor=0.2, transport_factor=0.6),
    WeatherEvent.HIGH_WIND: WeatherImpact(event=WeatherEvent.HIGH_WIND, tower_crane_factor=0.3, concrete_factor=0.9,
                                           facade_factor=0.2, lifting_factor=0.2, excavation_factor=0.9,
                                           external_work_factor=0.5, transport_factor=0.9),
    WeatherEvent.TYPHOON: WeatherImpact(event=WeatherEvent.TYPHOON, tower_crane_factor=0.0, concrete_factor=0.0,
                                         facade_factor=0.0, lifting_factor=0.0, excavation_factor=0.0,
                                         external_work_factor=0.0, transport_factor=0.0),
    WeatherEvent.EXTREME_HEAT: WeatherImpact(event=WeatherEvent.EXTREME_HEAT, tower_crane_factor=0.9, concrete_factor=0.75,
                                              facade_factor=0.85, lifting_factor=0.9, excavation_factor=0.85,
                                              external_work_factor=0.7, transport_factor=1.0),
    WeatherEvent.LIGHTNING: WeatherImpact(event=WeatherEvent.LIGHTNING, tower_crane_factor=0.0, concrete_factor=0.6,
                                           facade_factor=0.0, lifting_factor=0.0, excavation_factor=0.5,
                                           external_work_factor=0.0, transport_factor=0.8),
}


class WeatherConstructionEngine:
    """Generates a stochastic daily weather event stream, with elevated
    typhoon/heavy-rain probability in the configured typhoon season."""

    def __init__(
        self,
        typhoon_season_months: list[int] | None = None,
        base_probabilities: dict[WeatherEvent, float] | None = None,
        typhoon_season_probabilities: dict[WeatherEvent, float] | None = None,
        seed: int | None = None,
    ):
        self.typhoon_season_months = typhoon_season_months or [6, 7, 8, 9, 10]
        self.base_probabilities = base_probabilities or {
            WeatherEvent.CLEAR: 0.72, WeatherEvent.RAIN: 0.18, WeatherEvent.HEAVY_RAIN: 0.04,
            WeatherEvent.HIGH_WIND: 0.03, WeatherEvent.TYPHOON: 0.0, WeatherEvent.EXTREME_HEAT: 0.02,
            WeatherEvent.LIGHTNING: 0.01,
        }
        self.typhoon_season_probabilities = typhoon_season_probabilities or {
            WeatherEvent.CLEAR: 0.55, WeatherEvent.RAIN: 0.2, WeatherEvent.HEAVY_RAIN: 0.1,
            WeatherEvent.HIGH_WIND: 0.05, WeatherEvent.TYPHOON: 0.03, WeatherEvent.EXTREME_HEAT: 0.05,
            WeatherEvent.LIGHTNING: 0.02,
        }
        self._rng = random.Random(seed)

    def daily_event(self, day_index: int, start_month: int = 3) -> WeatherEvent:
        month = ((start_month - 1 + day_index // 30) % 12) + 1
        probs = self.typhoon_season_probabilities if month in self.typhoon_season_months else self.base_probabilities
        events, weights = zip(*probs.items())
        return self._rng.choices(events, weights=weights, k=1)[0]

    def impact(self, event: WeatherEvent) -> WeatherImpact:
        return IMPACT_TABLE[event]


class TyphoonImpactResult(BaseModel):
    days_lost: float
    cost_impact_twd: float
    schedule_impact_days: float
    restart_days: float


class TyphoonConstructionScenario:
    """Simulates a discrete typhoon event: shutdown, equipment securing,
    site evacuation, material protection, crane downtime, rainfall,
    post-storm inspection, restart (spec section 43)."""

    def __init__(
        self,
        secure_days: float = 1.0,
        shutdown_days: float = 1.5,
        post_storm_inspection_days: float = 1.0,
        restart_ramp_days: float = 1.0,
        daily_site_cost_twd: float = 15_000_000.0,
    ):
        self.secure_days = secure_days
        self.shutdown_days = shutdown_days
        self.post_storm_inspection_days = post_storm_inspection_days
        self.restart_ramp_days = restart_ramp_days
        self.daily_site_cost_twd = daily_site_cost_twd

    def simulate(self, severity: float = 1.0) -> TyphoonImpactResult:
        """``severity`` scales the base durations (1.0 = typical typhoon,
        >1 = a more severe event)."""
        secure = self.secure_days * severity
        shutdown = self.shutdown_days * severity
        inspection = self.post_storm_inspection_days * severity
        restart = self.restart_ramp_days * severity
        total_days_lost = secure + shutdown + inspection + restart * 0.5  # restart is partial productivity
        cost_impact = total_days_lost * self.daily_site_cost_twd
        return TyphoonImpactResult(
            days_lost=round(total_days_lost, 2), cost_impact_twd=round(cost_impact, 0),
            schedule_impact_days=round(secure + shutdown + inspection + restart, 2),
            restart_days=round(restart, 2),
        )
