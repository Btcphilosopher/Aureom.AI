"""SimPy-based discrete-event construction simulation, weather scenarios,
logistics queueing, and the what-if scenario engine."""
