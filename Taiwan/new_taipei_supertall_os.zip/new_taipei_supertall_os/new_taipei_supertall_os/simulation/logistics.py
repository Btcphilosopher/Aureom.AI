"""SimPy stochastic truck/material-delivery queueing model, complementing
the deterministic :mod:`logistics.trucks` planner (spec sections 20, 29, 49)."""

from __future__ import annotations

import random

import simpy
from pydantic import BaseModel


class TruckSimResult(BaseModel):
    n_trucks: int
    average_wait_min: float
    max_wait_min: float
    gate_utilisation: float


def simulate_truck_arrivals(
    n_gates: int,
    n_trucks: int,
    mean_interarrival_min: float,
    mean_service_min: float,
    seed: int | None = None,
) -> TruckSimResult:
    """M/M/c-style queueing simulation (Poisson arrivals, exponential
    service) for truck gate throughput planning."""
    rng = random.Random(seed)
    env = simpy.Environment()
    gates = simpy.Resource(env, capacity=n_gates)
    waits: list[float] = []
    busy_time = {"value": 0.0}

    def truck(name: int):
        arrival = env.now
        with gates.request() as req:
            yield req
            wait = env.now - arrival
            waits.append(wait)
            service = rng.expovariate(1 / mean_service_min)
            busy_time["value"] += service
            yield env.timeout(service)

    def generator():
        for i in range(n_trucks):
            env.process(truck(i))
            yield env.timeout(rng.expovariate(1 / mean_interarrival_min))

    env.process(generator())
    env.run()

    total_time = env.now
    avg_wait = sum(waits) / len(waits) if waits else 0.0
    max_wait = max(waits) if waits else 0.0
    utilisation = busy_time["value"] / max(total_time * n_gates, 1e-6)

    return TruckSimResult(
        n_trucks=n_trucks, average_wait_min=round(avg_wait, 2),
        max_wait_min=round(max_wait, 2), gate_utilisation=round(min(utilisation, 1.0), 3),
    )
