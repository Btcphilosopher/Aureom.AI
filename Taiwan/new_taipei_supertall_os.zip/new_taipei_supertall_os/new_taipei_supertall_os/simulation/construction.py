"""SimPy discrete-event floor-by-floor tower construction process.

Models tower cranes as SimPy ``Resource`` objects shared across floor
construction cycles, with each simulated day's productivity scaled by a
weather factor from :mod:`simulation.weather`.
"""

from __future__ import annotations

import random

import simpy
from pydantic import BaseModel

from new_taipei_supertall_os.construction.sequencing import FloorCycle
from new_taipei_supertall_os.simulation.weather import WeatherConstructionEngine


class FloorCompletionEvent(BaseModel):
    floor_number: int
    start_day: float
    end_day: float


class CraneUtilisationSample(BaseModel):
    crane_id: str
    busy_days: float


class FloorByFloorSimulationResult(BaseModel):
    total_days: float
    floor_events: list[FloorCompletionEvent]
    crane_utilisation: dict[str, float]
    weather_days_lost: float


def run_floor_by_floor_simulation(
    n_floors: int,
    n_cranes: int,
    floor_cycle: FloorCycle,
    weather_engine: WeatherConstructionEngine,
    productivity_std: float = 0.08,
    seed: int | None = None,
) -> FloorByFloorSimulationResult:
    """Runs one stochastic trial of tower-frame construction: each floor's
    cycle consumes one crane-resource unit for its full cycle time,
    stretched by that day's weather productivity factor and a random
    productivity draw."""
    rng = random.Random(seed)
    env = simpy.Environment()
    cranes = simpy.Resource(env, capacity=n_cranes)
    crane_busy_time = {f"crane-{i+1}": 0.0 for i in range(n_cranes)}
    events: list[FloorCompletionEvent] = []
    weather_days_lost = {"value": 0.0}

    def weather_factor(day: float) -> float:
        event = weather_engine.daily_event(int(day))
        impact = weather_engine.impact(event)
        factor = (impact.tower_crane_factor + impact.concrete_factor) / 2
        if factor <= 0.05:
            weather_days_lost["value"] += 1.0
        return max(factor, 0.05)

    def floor_process(floor_number: int):
        with cranes.request() as req:
            yield req
            start = env.now
            base_cycle = floor_cycle.cycle_time_days(floor_number)
            productivity = max(0.4, rng.gauss(1.0, productivity_std))
            wf = weather_factor(env.now)
            effective_cycle = base_cycle / (productivity * wf)
            yield env.timeout(effective_cycle)
            end = env.now
            events.append(FloorCompletionEvent(floor_number=floor_number, start_day=round(start, 2), end_day=round(end, 2)))
            # attribute busy time round-robin (SimPy Resource doesn't expose
            # which "unit" served the request, so approximate via slot index)
            slot = f"crane-{(floor_number - 1) % n_cranes + 1}"
            crane_busy_time[slot] += effective_cycle

    for floor_number in range(1, n_floors + 1):
        env.process(floor_process(floor_number))

    env.run()

    total_days = max((e.end_day for e in events), default=0.0)
    utilisation = {cid: round(busy / max(total_days, 1e-6), 3) for cid, busy in crane_busy_time.items()}

    return FloorByFloorSimulationResult(
        total_days=round(total_days, 1), floor_events=sorted(events, key=lambda e: e.floor_number),
        crane_utilisation=utilisation, weather_days_lost=weather_days_lost["value"],
    )
