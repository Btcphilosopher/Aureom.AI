"""Schedule Monte Carlo simulation (spec section 50).

Randomises task durations (weather, productivity, delivery delay,
equipment downtime, labour availability all folded into a per-task
duration multiplier distribution) and re-runs the CPM engine per trial.
"""

from __future__ import annotations

import random

from pydantic import BaseModel

from new_taipei_supertall_os.construction.schedule import CriticalPathEngine, ProjectSchedule


class ScheduleMonteCarloResult(BaseModel):
    n_simulations: int
    p50_days: float
    p80_days: float
    p90_days: float
    mean_days: float
    std_dev_days: float


class ScheduleMonteCarlo:
    def __init__(
        self,
        weather_std: float = 0.05,
        productivity_std: float = 0.07,
        delivery_delay_std: float = 0.05,
        equipment_downtime_std: float = 0.04,
        labour_availability_std: float = 0.05,
        seed: int | None = None,
    ):
        self.stds = [weather_std, productivity_std, delivery_delay_std, equipment_downtime_std, labour_availability_std]
        self._rng = random.Random(seed)

    def run(self, schedule: ProjectSchedule, n_simulations: int = 1000) -> ScheduleMonteCarloResult:
        cpm = CriticalPathEngine()
        durations: list[float] = []
        for _ in range(n_simulations):
            trial = schedule.model_copy(deep=True)
            for task in trial.tasks:
                multiplier = 1.0
                for std in self.stds:
                    multiplier += max(-0.5, self._rng.gauss(0, std))
                task.duration_days = max(task.duration_days * multiplier, 0.1)
            cpm.run(trial)
            durations.append(trial.duration_days)

        durations.sort()

        def pct(p: float) -> float:
            idx = min(len(durations) - 1, int(p * len(durations)))
            return round(durations[idx], 1)

        mean = sum(durations) / len(durations)
        variance = sum((d - mean) ** 2 for d in durations) / len(durations)
        return ScheduleMonteCarloResult(
            n_simulations=n_simulations, p50_days=pct(0.5), p80_days=pct(0.8), p90_days=pct(0.9),
            mean_days=round(mean, 1), std_dev_days=round(variance**0.5, 1),
        )
