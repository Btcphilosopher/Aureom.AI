"""Top-level construction simulation orchestrator (spec sections 49, 63).

``ConstructionSimulation`` runs repeated stochastic floor-by-floor SimPy
trials (see :mod:`simulation.construction`) to estimate the probability of
finishing the tower structure by a target date and average crane
utilisation — this is the object used by the example entry point in
``app.py``.
"""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.construction.sequencing import FloorCycle
from new_taipei_supertall_os.domain.building import Building
from new_taipei_supertall_os.simulation.construction import run_floor_by_floor_simulation
from new_taipei_supertall_os.simulation.weather import WeatherConstructionEngine


class SimulationResult(BaseModel):
    n_trials: int
    target_days: float
    completion_probability: float
    average_crane_utilisation: float
    average_total_days: float
    average_weather_days_lost: float
    p50_days: float
    p80_days: float
    p90_days: float


class ConstructionSimulation:
    def __init__(
        self,
        building: Building,
        n_cranes: int = 4,
        floor_cycle: FloorCycle | None = None,
        weather_engine: WeatherConstructionEngine | None = None,
    ):
        self.building = building
        self.n_cranes = n_cranes
        self.floor_cycle = floor_cycle or FloorCycle()
        self.weather_engine = weather_engine or WeatherConstructionEngine()

    def run(self, days: float, speed: int = 10, n_trials: int | None = None) -> SimulationResult:
        """``speed`` is accepted for API/CLI compatibility with a
        real-time playback rate and does not change the statistical
        result; ``n_trials`` controls Monte Carlo robustness directly and
        defaults to a value informed by ``speed`` (more trials for a
        "slower", more thorough analysis request)."""
        trials = n_trials if n_trials is not None else max(10, min(80, speed * 3))
        totals: list[float] = []
        utilisations: list[float] = []
        weather_losses: list[float] = []

        for trial in range(trials):
            result = run_floor_by_floor_simulation(
                n_floors=self.building.floors, n_cranes=self.n_cranes,
                floor_cycle=self.floor_cycle, weather_engine=self.weather_engine, seed=trial,
            )
            totals.append(result.total_days)
            utilisations.append(sum(result.crane_utilisation.values()) / max(len(result.crane_utilisation), 1))
            weather_losses.append(result.weather_days_lost)

        totals_sorted = sorted(totals)

        def pct(p: float) -> float:
            idx = min(len(totals_sorted) - 1, int(p * len(totals_sorted)))
            return round(totals_sorted[idx], 1)

        on_time = sum(1 for t in totals if t <= days)
        return SimulationResult(
            n_trials=trials, target_days=days,
            completion_probability=round(on_time / trials, 4),
            average_crane_utilisation=round(sum(utilisations) / trials, 4),
            average_total_days=round(sum(totals) / trials, 1),
            average_weather_days_lost=round(sum(weather_losses) / trials, 1),
            p50_days=pct(0.5), p80_days=pct(0.8), p90_days=pct(0.9),
        )
