"""What-if scenario engine (spec section 57).

Every scenario is evaluated by actually re-running the schedule/cost/carbon
pipeline on a modified building/schedule, then diffing against the
baseline — never a hard-coded delta.
"""

from __future__ import annotations

from dataclasses import dataclass

from pydantic import BaseModel

from new_taipei_supertall_os.config.settings import Settings
from new_taipei_supertall_os.construction.concrete import ConcreteEngine
from new_taipei_supertall_os.construction.risk import ConstructionRiskEngine
from new_taipei_supertall_os.construction.sequencing import CoreFrameStrategy, build_demo_schedule
from new_taipei_supertall_os.construction.steel import SteelConstructionEngine
from new_taipei_supertall_os.domain.building import Building, MassingEngine
from new_taipei_supertall_os.domain.structural import StructuralSystemType
from new_taipei_supertall_os.finance.carbon import ConstructionCarbonEngine
from new_taipei_supertall_os.finance.cost import ConstructionCostEngine
from new_taipei_supertall_os.optimisation.schedule import ScheduleOptimizer


class ScenarioResult(BaseModel):
    name: str
    description: str
    baseline_duration_days: float
    scenario_duration_days: float
    duration_delta_days: float
    baseline_cost_twd: float
    scenario_cost_twd: float
    cost_delta_twd: float
    baseline_carbon_kgco2e: float
    scenario_carbon_kgco2e: float
    carbon_delta_kgco2e: float
    risk_delta: float
    resource_delta: dict[str, float]


@dataclass
class _Evaluation:
    duration_days: float
    cost_twd: float
    carbon_kgco2e: float
    risk_index: float


class ScenarioEngine:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.cost_engine = ConstructionCostEngine(settings)
        self.carbon_engine = ConstructionCarbonEngine(settings)
        self.risk_engine = ConstructionRiskEngine()

    def _evaluate(
        self,
        building: Building,
        strategy: CoreFrameStrategy = CoreFrameStrategy.CORE_FIRST,
        extra_duration_days: float = 0.0,
        cost_multiplier: float = 1.0,
        productivity_multiplier: float = 1.0,
        n_cranes_delta: int = 0,
        crash_fraction: float = 0.15,
        risk_multiplier: float = 1.0,
    ) -> _Evaluation:
        profile = MassingEngine().generate(building)
        above_grade = [f for f in profile.floors if f.number > 0]

        schedule = build_demo_schedule(building, strategy=strategy)
        for task in schedule.tasks:
            task.duration_days = task.duration_days / max(productivity_multiplier, 0.1)
        speedup = 1.0 + n_cranes_delta * 0.06  # each extra crane ~6% faster on crane-bound phases, coarse
        for task in schedule.tasks:
            if "tower_cranes" in task.resources or task.phase in ("core", "tower_structure"):
                task.duration_days = task.duration_days / max(speedup, 0.5)

        optimizer = ScheduleOptimizer(crash_fraction=crash_fraction)
        result = optimizer.optimize_schedule(schedule)
        duration = result.schedule.duration_days + extra_duration_days

        ce = ConcreteEngine()
        system = StructuralSystemType(building.structural_system)
        pours = [ce.plan_pour(f, "slab", ce.floor_slab_volume_m3(f) * system.relative_concrete_m3_per_m2 / 0.55)
                 for f in above_grade]
        cost_estimate = self.cost_engine.estimate(building, profile.floors, pours)
        cost = cost_estimate.total_twd * cost_multiplier

        se = SteelConstructionEngine()
        steel_tonnes = se.building_steel_tonnage(above_grade, system)
        carbon = self.carbon_engine.estimate(building, profile.floors, pours, steel_tonnes=steel_tonnes).total_kgco2e

        risk = self.risk_engine.overall_risk_index(self.risk_engine.demo_risk_register()) * risk_multiplier

        return _Evaluation(duration_days=round(duration, 1), cost_twd=round(cost, 0),
                            carbon_kgco2e=round(carbon, 0), risk_index=round(risk, 4))

    def _diff(self, name: str, description: str, baseline: _Evaluation, scenario: _Evaluation,
              resource_delta: dict[str, float] | None = None) -> ScenarioResult:
        return ScenarioResult(
            name=name, description=description,
            baseline_duration_days=baseline.duration_days, scenario_duration_days=scenario.duration_days,
            duration_delta_days=round(scenario.duration_days - baseline.duration_days, 1),
            baseline_cost_twd=baseline.cost_twd, scenario_cost_twd=scenario.cost_twd,
            cost_delta_twd=round(scenario.cost_twd - baseline.cost_twd, 0),
            baseline_carbon_kgco2e=baseline.carbon_kgco2e, scenario_carbon_kgco2e=scenario.carbon_kgco2e,
            carbon_delta_kgco2e=round(scenario.carbon_kgco2e - baseline.carbon_kgco2e, 0),
            risk_delta=round(scenario.risk_index - baseline.risk_index, 4),
            resource_delta=resource_delta or {},
        )

    def baseline(self, building: Building) -> _Evaluation:
        return self._evaluate(building)

    # --- named "what if" questions (spec section 57) -----------------

    def what_if_height(self, building: Building, new_height_m: float) -> ScenarioResult:
        base = self.baseline(building)
        b2 = building.model_copy(update={"height_m": new_height_m,
                                          "floors": max(1, round(building.floors * new_height_m / building.height_m))})
        scenario = self._evaluate(b2)
        return self._diff("height_change", f"Tower height changed from {building.height_m}m to {new_height_m}m",
                           base, scenario, {"floors_delta": b2.floors - building.floors})

    def what_if_add_floors(self, building: Building, added_floors: int) -> ScenarioResult:
        base = self.baseline(building)
        new_height = building.height_m * (building.floors + added_floors) / building.floors
        b2 = building.model_copy(update={"floors": building.floors + added_floors, "height_m": new_height})
        scenario = self._evaluate(b2)
        return self._diff("add_floors", f"Added {added_floors} floors", base, scenario,
                           {"floors_delta": added_floors})

    def what_if_larger_core(self, building: Building, gfa_efficiency_loss_pct: float = 3.0) -> ScenarioResult:
        base = self.baseline(building)
        b2 = building.model_copy(update={"gross_floor_area_m2": building.gross_floor_area_m2 * (1 - gfa_efficiency_loss_pct / 100)})
        scenario = self._evaluate(b2, productivity_multiplier=0.97, risk_multiplier=0.9)
        return self._diff("larger_core", f"Core enlarged, ~{gfa_efficiency_loss_pct}% net GFA efficiency loss",
                           base, scenario, {"gfa_delta_m2": b2.gross_floor_area_m2 - building.gross_floor_area_m2})

    def what_if_structural_system(self, building: Building, system: StructuralSystemType) -> ScenarioResult:
        base = self.baseline(building)
        b2 = building.model_copy(update={"structural_system": system.value})
        scenario = self._evaluate(b2)
        return self._diff("structural_system_change", f"Structural system switched to {system.value}", base, scenario)

    def what_if_extra_crane(self, building: Building, extra_cranes: int = 1) -> ScenarioResult:
        base = self.baseline(building)
        scenario = self._evaluate(building, n_cranes_delta=extra_cranes)
        return self._diff("extra_crane", f"{extra_cranes} additional tower crane(s)", base, scenario,
                           {"cranes_delta": extra_cranes})

    def what_if_excavation_delay(self, building: Building, delay_days: float) -> ScenarioResult:
        base = self.baseline(building)
        scenario = self._evaluate(building, extra_duration_days=delay_days)
        return self._diff("excavation_delay", f"Excavation delayed by {delay_days} days", base, scenario)

    def what_if_concrete_productivity_drop(self, building: Building, drop_pct: float) -> ScenarioResult:
        base = self.baseline(building)
        scenario = self._evaluate(building, productivity_multiplier=1 - drop_pct / 100)
        return self._diff("concrete_productivity_drop", f"Concrete productivity falls {drop_pct}%", base, scenario)

    def what_if_steel_price_increase(self, building: Building, increase_pct: float) -> ScenarioResult:
        base = self.baseline(building)
        # crude: steel is ~15-20% of hard cost; scale total cost proportionally
        steel_share = 0.17
        cost_multiplier = 1 + steel_share * (increase_pct / 100)
        scenario = self._evaluate(building, cost_multiplier=cost_multiplier)
        return self._diff("steel_price_increase", f"Steel price rises {increase_pct}%", base, scenario)

    def what_if_typhoon_downtime(self, building: Building, days_lost: float) -> ScenarioResult:
        base = self.baseline(building)
        scenario = self._evaluate(building, extra_duration_days=days_lost, risk_multiplier=1.1)
        return self._diff("typhoon_downtime", f"Typhoon causes {days_lost} days of downtime", base, scenario)

    def what_if_facade_concurrent_with_structure(self, building: Building) -> ScenarioResult:
        base = self.baseline(building)
        scenario = self._evaluate(building, strategy=CoreFrameStrategy.SYNCHRONIZED, productivity_multiplier=1.05,
                                   risk_multiplier=1.15)
        return self._diff("facade_concurrent", "Facade built concurrently with structure", base, scenario)

    def what_if_faster_floor_cycle(self, building: Building, cycle_reduction_pct: float) -> ScenarioResult:
        base = self.baseline(building)
        scenario = self._evaluate(building, productivity_multiplier=1 + cycle_reduction_pct / 100)
        return self._diff("faster_floor_cycle", f"Floor cycle time reduced {cycle_reduction_pct}%", base, scenario)
