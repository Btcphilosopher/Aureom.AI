"""Preliminary engineering estimation layer.

Every public calculation function in this package returns a
``domain.calculation.CalculationResult`` (or a collection of them) so the
inputs, method, and assumptions behind every number stay attached to it.

NONE of these calculations are a substitute for sealed structural,
geotechnical, or fire-engineering calculations performed by a licensed
professional using certified analysis software. See
``domain.calculation.PRELIMINARY_ENGINEERING_NOTICE``.
"""
