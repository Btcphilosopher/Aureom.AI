"""Excavation quantity/duration calculations and the excavation risk engine
(spec sections 14, 15)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel

from new_taipei_supertall_os.domain.calculation import CalculationResult
from new_taipei_supertall_os.domain.excavation import ExcavationModel
from new_taipei_supertall_os.domain.site import NeighbouringAsset


def excavation_volume_m3(excavation: ExcavationModel) -> CalculationResult:
    return CalculationResult(
        value=round(excavation.excavation_volume_m3, 0),
        units="m3",
        method="volume = depth * plan_area",
        inputs={"depth_m": excavation.excavation_depth_m, "area_m2": excavation.excavation_area_m2},
        domain="geotechnical",
    )


def estimated_duration_days(
    excavation: ExcavationModel,
    excavation_rate_m3_per_day: float = 900.0,
) -> CalculationResult:
    volume = excavation_volume_m3(excavation).value
    duration = volume / max(excavation_rate_m3_per_day, 1.0)
    # add support-stage installation overhead
    duration_with_support = duration + excavation.support_stages * 4.0
    return CalculationResult(
        value=round(duration_with_support, 1),
        units="days",
        method="volume / daily_excavation_rate + support_stages * days_per_support_stage(4)",
        inputs={"volume_m3": volume, "excavation_rate_m3_per_day": excavation_rate_m3_per_day,
                "support_stages": excavation.support_stages},
        domain="geotechnical",
    )


def truck_demand(excavation: ExcavationModel, truck_capacity_m3: float = 12.0, bulking_factor: float = 1.25) -> CalculationResult:
    volume = excavation_volume_m3(excavation).value
    trucks = (volume * bulking_factor) / max(truck_capacity_m3, 1.0)
    return CalculationResult(
        value=round(trucks, 0),
        units="truck loads",
        method="trucks = volume * bulking_factor / truck_capacity_m3",
        inputs={"volume_m3": volume, "bulking_factor": bulking_factor, "truck_capacity_m3": truck_capacity_m3},
        domain="geotechnical",
    )


class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class ExcavationRiskFactor(BaseModel):
    name: str
    level: RiskLevel
    detail: str


class ExcavationRiskAssessment(BaseModel):
    overall_level: RiskLevel
    factors: list[ExcavationRiskFactor]
    note: str = (
        "Automated risk flagging only. Does not constitute a safety decision; "
        "all HIGH/CRITICAL flags require review and sign-off by a qualified "
        "geotechnical/structural engineer and the site safety team."
    )


class ExcavationRiskEngine:
    """Monitors deep excavation risk indicators and produces LOW/MEDIUM/
    HIGH/CRITICAL flags (spec section 15). Never makes an autonomous
    safety decision."""

    def assess(
        self,
        excavation: ExcavationModel,
        neighbours: list[NeighbouringAsset],
        observed_lateral_movement_mm: float = 0.0,
        observed_settlement_mm: float = 0.0,
        rainfall_24h_mm: float = 0.0,
        groundwater_drawdown_m: float = 0.0,
    ) -> ExcavationRiskAssessment:
        factors: list[ExcavationRiskFactor] = []

        # Depth / basement category
        if excavation.excavation_depth_m >= 25 or excavation.basement_levels >= 5:
            factors.append(ExcavationRiskFactor(
                name="excavation_depth", level=RiskLevel.HIGH,
                detail=f"depth={excavation.excavation_depth_m}m, basements={excavation.basement_levels}"))
        elif excavation.excavation_depth_m >= 15 or excavation.basement_levels >= 3:
            factors.append(ExcavationRiskFactor(
                name="excavation_depth", level=RiskLevel.MEDIUM,
                detail=f"depth={excavation.excavation_depth_m}m, basements={excavation.basement_levels}"))
        else:
            factors.append(ExcavationRiskFactor(name="excavation_depth", level=RiskLevel.LOW,
                                                  detail=f"depth={excavation.excavation_depth_m}m"))

        # Adjacent structures
        close_sensitive = [n for n in neighbours if n.distance_m <= 20 and n.sensitivity in ("high", "critical")]
        if close_sensitive:
            level = RiskLevel.CRITICAL if any(n.sensitivity == "critical" for n in close_sensitive) else RiskLevel.HIGH
            factors.append(ExcavationRiskFactor(
                name="adjacent_structures", level=level,
                detail=f"{len(close_sensitive)} sensitive asset(s) within 20m"))
        elif any(n.distance_m <= 40 for n in neighbours):
            factors.append(ExcavationRiskFactor(name="adjacent_structures", level=RiskLevel.MEDIUM,
                                                  detail="assets within 40m"))
        else:
            factors.append(ExcavationRiskFactor(name="adjacent_structures", level=RiskLevel.LOW, detail="no close assets"))

        # Groundwater / drawdown
        if groundwater_drawdown_m >= 2.0:
            factors.append(ExcavationRiskFactor(name="groundwater", level=RiskLevel.HIGH,
                                                  detail=f"drawdown={groundwater_drawdown_m}m"))
        elif groundwater_drawdown_m >= 0.5:
            factors.append(ExcavationRiskFactor(name="groundwater", level=RiskLevel.MEDIUM,
                                                  detail=f"drawdown={groundwater_drawdown_m}m"))
        else:
            factors.append(ExcavationRiskFactor(name="groundwater", level=RiskLevel.LOW, detail="stable"))

        # Monitored lateral movement / settlement
        if observed_lateral_movement_mm >= 30 or observed_settlement_mm >= 25:
            factors.append(ExcavationRiskFactor(name="monitoring", level=RiskLevel.CRITICAL,
                                                  detail=f"lateral={observed_lateral_movement_mm}mm, "
                                                          f"settlement={observed_settlement_mm}mm"))
        elif observed_lateral_movement_mm >= 15 or observed_settlement_mm >= 12:
            factors.append(ExcavationRiskFactor(name="monitoring", level=RiskLevel.HIGH,
                                                  detail=f"lateral={observed_lateral_movement_mm}mm, "
                                                          f"settlement={observed_settlement_mm}mm"))
        elif observed_lateral_movement_mm >= 5 or observed_settlement_mm >= 5:
            factors.append(ExcavationRiskFactor(name="monitoring", level=RiskLevel.MEDIUM,
                                                  detail=f"lateral={observed_lateral_movement_mm}mm, "
                                                          f"settlement={observed_settlement_mm}mm"))
        else:
            factors.append(ExcavationRiskFactor(name="monitoring", level=RiskLevel.LOW, detail="within tolerance"))

        # Rainfall / slope stability proxy
        if rainfall_24h_mm >= 200:
            factors.append(ExcavationRiskFactor(name="rainfall", level=RiskLevel.CRITICAL,
                                                  detail=f"{rainfall_24h_mm}mm/24h"))
        elif rainfall_24h_mm >= 100:
            factors.append(ExcavationRiskFactor(name="rainfall", level=RiskLevel.HIGH,
                                                  detail=f"{rainfall_24h_mm}mm/24h"))
        elif rainfall_24h_mm >= 40:
            factors.append(ExcavationRiskFactor(name="rainfall", level=RiskLevel.MEDIUM,
                                                  detail=f"{rainfall_24h_mm}mm/24h"))
        else:
            factors.append(ExcavationRiskFactor(name="rainfall", level=RiskLevel.LOW, detail="normal"))

        order = {RiskLevel.LOW: 0, RiskLevel.MEDIUM: 1, RiskLevel.HIGH: 2, RiskLevel.CRITICAL: 3}
        overall = max(factors, key=lambda f: order[f.level]).level
        return ExcavationRiskAssessment(overall_level=overall, factors=factors)
