"""Preliminary gravity load estimation (spec section 7).

Coarse, configurable dead/live load assumptions by floor use-type, used
for planning-level demand estimates (foundation sizing inputs, crane
lift-weight sanity checks, cost/quantity cross-checks). NOT a substitute
for a structural engineer's load takedown.
"""

from __future__ import annotations

from new_taipei_supertall_os.domain.building import Building
from new_taipei_supertall_os.domain.calculation import CalculationResult
from new_taipei_supertall_os.domain.floor import Floor, FloorUseType

# kPa (kN/m2), configurable planning defaults — NOT a code load table.
DEAD_LOAD_KPA_BY_USE: dict[FloorUseType, float] = {
    FloorUseType.RETAIL: 5.5,
    FloorUseType.OFFICE: 4.5,
    FloorUseType.RESIDENTIAL: 4.0,
    FloorUseType.HOTEL: 4.2,
    FloorUseType.MECHANICAL: 7.0,
    FloorUseType.PLANT: 7.5,
    FloorUseType.LOBBY: 5.0,
    FloorUseType.PARKING: 4.8,
    FloorUseType.OBSERVATION: 5.0,
    FloorUseType.SERVICE: 5.5,
    FloorUseType.REFUGE: 5.0,
}

LIVE_LOAD_KPA_BY_USE: dict[FloorUseType, float] = {
    FloorUseType.RETAIL: 4.0,
    FloorUseType.OFFICE: 2.5,
    FloorUseType.RESIDENTIAL: 2.0,
    FloorUseType.HOTEL: 2.0,
    FloorUseType.MECHANICAL: 5.0,
    FloorUseType.PLANT: 7.5,
    FloorUseType.LOBBY: 4.0,
    FloorUseType.PARKING: 2.5,
    FloorUseType.OBSERVATION: 5.0,
    FloorUseType.SERVICE: 3.0,
    FloorUseType.REFUGE: 3.5,
}

SELF_WEIGHT_KN_PER_M = 12.0  # coarse facade + envelope line load per perimeter metre


def floor_dead_load_kn(floor: Floor) -> CalculationResult:
    rate = DEAD_LOAD_KPA_BY_USE.get(floor.use_type, 4.5)
    value = rate * floor.area_m2
    return CalculationResult(
        value=round(value, 1),
        units="kN",
        method="dead_load = configurable_kpa_by_use * floor_area_m2",
        inputs={"floor_number": floor.number, "use_type": floor.use_type.value,
                "area_m2": floor.area_m2, "rate_kpa": rate},
        assumptions=["Configurable planning-level dead load rate, not a code takedown."],
        domain="structural",
    )


def floor_live_load_kn(floor: Floor) -> CalculationResult:
    rate = LIVE_LOAD_KPA_BY_USE.get(floor.use_type, 2.5)
    value = rate * floor.area_m2
    return CalculationResult(
        value=round(value, 1),
        units="kN",
        method="live_load = configurable_kpa_by_use * floor_area_m2 (unreduced)",
        inputs={"floor_number": floor.number, "use_type": floor.use_type.value,
                "area_m2": floor.area_m2, "rate_kpa": rate},
        assumptions=["No live-load reduction applied (conservative planning estimate)."],
        domain="structural",
    )


def cumulative_gravity_reaction_kn(floors: list[Floor], live_load_factor: float = 0.4) -> CalculationResult:
    """Approximate total gravity reaction at foundation level: sum of full
    dead load plus a configurable fraction of live load (a coarse stand-in
    for load-combination / live-load reduction with height), for
    foundation-sizing sanity checks only."""
    total_dead = sum(floor_dead_load_kn(f).value for f in floors)
    total_live = sum(floor_live_load_kn(f).value for f in floors)
    value = total_dead + live_load_factor * total_live
    return CalculationResult(
        value=round(value, 0),
        units="kN",
        method="sum(dead_load) + live_load_factor * sum(live_load)",
        inputs={"n_floors": len(floors), "live_load_factor": live_load_factor,
                "total_dead_kn": round(total_dead, 0), "total_live_kn": round(total_live, 0)},
        assumptions=["Coarse planning combination, not a governing code load combination."],
        domain="structural",
    )


def building_seismic_mass_tonnes(building: Building, floors: list[Floor]) -> CalculationResult:
    """Approximate seismic mass = dead load + a fraction of live load,
    converted to mass, used as SeismicModel input."""
    reaction = cumulative_gravity_reaction_kn(floors, live_load_factor=0.25)
    mass_tonnes = reaction.value / 9.81
    return CalculationResult(
        value=round(mass_tonnes, 0),
        units="tonnes",
        method="mass = (dead_load + 0.25*live_load) / g",
        inputs={"building_id": building.id, "gravity_reaction_kn": reaction.value},
        assumptions=["Seismic weight approximation per common code convention "
                     "(full dead + partial live), coarse."],
        domain="seismic",
    )
