"""Geotechnical model (spec section 13).

``SoilLayer`` and ``SiteInvestigation`` hold whatever ground data is
available. This module does NOT invent New Taipei geology: without an
imported site-investigation dataset, callers get an explicitly-labelled
generic placeholder profile which must be replaced with real borehole /
CPT / SPT data before any real design or excavation decision is made.
"""

from __future__ import annotations

import csv
from pathlib import Path

from pydantic import BaseModel, Field


class SoilLayer(BaseModel):
    depth_top_m: float
    depth_base_m: float
    soil_type: str
    density_kn_m3: float = 18.0
    friction_angle_deg: float | None = None
    cohesion_kpa: float | None = None
    elastic_modulus_mpa: float | None = None
    spt_n: float | None = None
    groundwater_level_m: float | None = None

    @property
    def thickness_m(self) -> float:
        return self.depth_base_m - self.depth_top_m


class SiteInvestigation(BaseModel):
    site_id: str
    source: str = "PLACEHOLDER - no imported site investigation"
    is_placeholder: bool = True
    layers: list[SoilLayer] = Field(default_factory=list)
    groundwater_level_m: float = -3.0

    def layer_at_depth(self, depth_m: float) -> SoilLayer | None:
        for layer in self.layers:
            if layer.depth_top_m <= depth_m <= layer.depth_base_m:
                return layer
        return None

    def average_friction_angle(self) -> float | None:
        vals = [l.friction_angle_deg for l in self.layers if l.friction_angle_deg is not None]
        return sum(vals) / len(vals) if vals else None

    @classmethod
    def placeholder(cls, site_id: str, total_depth_m: float = 80.0) -> "SiteInvestigation":
        """A clearly-labelled generic layered profile for demonstration
        purposes only. Basin alluvium -> gravel is a common Taipei-basin
        *pattern*, not a claim about any specific site's actual ground
        conditions."""
        layers = [
            SoilLayer(depth_top_m=0, depth_base_m=10, soil_type="fill/soft clay",
                      density_kn_m3=17.0, friction_angle_deg=22, cohesion_kpa=15, spt_n=4),
            SoilLayer(depth_top_m=10, depth_base_m=30, soil_type="silty clay",
                      density_kn_m3=18.5, friction_angle_deg=26, cohesion_kpa=30, spt_n=10),
            SoilLayer(depth_top_m=30, depth_base_m=55, soil_type="sandy silt",
                      density_kn_m3=19.5, friction_angle_deg=30, cohesion_kpa=10, spt_n=25),
            SoilLayer(depth_top_m=55, depth_base_m=total_depth_m, soil_type="dense gravel",
                      density_kn_m3=21.0, friction_angle_deg=36, cohesion_kpa=0, spt_n=60),
        ]
        return cls(site_id=site_id, layers=layers, is_placeholder=True)

    @classmethod
    def from_csv(cls, site_id: str, path: str | Path) -> "SiteInvestigation":
        """Import a real site-investigation dataset. Expected columns:
        depth_top_m, depth_base_m, soil_type, density_kn_m3,
        friction_angle_deg, cohesion_kpa, elastic_modulus_mpa, spt_n."""
        layers: list[SoilLayer] = []
        with Path(path).open(newline="", encoding="utf-8") as fh:
            for row in csv.DictReader(fh):
                layers.append(
                    SoilLayer(
                        depth_top_m=float(row["depth_top_m"]),
                        depth_base_m=float(row["depth_base_m"]),
                        soil_type=row["soil_type"],
                        density_kn_m3=float(row.get("density_kn_m3") or 18.0),
                        friction_angle_deg=_maybe_float(row.get("friction_angle_deg")),
                        cohesion_kpa=_maybe_float(row.get("cohesion_kpa")),
                        elastic_modulus_mpa=_maybe_float(row.get("elastic_modulus_mpa")),
                        spt_n=_maybe_float(row.get("spt_n")),
                    )
                )
        return cls(site_id=site_id, source=f"imported:{path}", is_placeholder=False, layers=layers)


def _maybe_float(v: str | None) -> float | None:
    if v in (None, ""):
        return None
    return float(v)
