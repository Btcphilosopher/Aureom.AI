"""Preliminary foundation demand calculations (spec section 12)."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.domain.calculation import CalculationResult
from new_taipei_supertall_os.domain.foundation import FoundationModel, FoundationType
from new_taipei_supertall_os.engineering.geotechnical import SiteInvestigation


class FoundationDemandSummary(BaseModel):
    total_load: CalculationResult
    average_pile_load: CalculationResult
    average_pile_utilisation: CalculationResult
    raft_pressure: CalculationResult
    settlement_estimate: CalculationResult

    model_config = {"arbitrary_types_allowed": True}


def total_gravity_load_kn(gravity_reaction_kn: float, load_factor: float = 1.0) -> CalculationResult:
    return CalculationResult(
        value=round(gravity_reaction_kn * load_factor, 0),
        units="kN",
        method="total_load = gravity_reaction_kn * load_factor",
        inputs={"gravity_reaction_kn": gravity_reaction_kn, "load_factor": load_factor},
        domain="foundation",
    )


def average_pile_load_kn(total_load_kn: float, pile_count: int) -> CalculationResult:
    value = total_load_kn / max(pile_count, 1)
    return CalculationResult(
        value=round(value, 1),
        units="kN/pile",
        method="average_pile_load = total_load / pile_count "
               "(assumes even distribution — a real design requires a pile-group analysis)",
        inputs={"total_load_kn": total_load_kn, "pile_count": pile_count},
        confidence="indicative",
        domain="foundation",
    )


def average_pile_utilisation(average_pile_load_kn_: float, pile_capacity_kn: float) -> CalculationResult:
    value = average_pile_load_kn_ / max(pile_capacity_kn, 1.0)
    return CalculationResult(
        value=round(value, 3),
        units="ratio",
        method="utilisation = average_pile_load / pile_capacity",
        inputs={"average_pile_load_kn": average_pile_load_kn_, "pile_capacity_kn": pile_capacity_kn},
        domain="foundation",
    )


def raft_pressure_kpa(total_load_kn: float, raft_area_m2: float) -> CalculationResult:
    value = total_load_kn / max(raft_area_m2, 1.0)
    return CalculationResult(
        value=round(value, 1),
        units="kPa",
        method="raft_pressure = total_load / raft_area",
        inputs={"total_load_kn": total_load_kn, "raft_area_m2": raft_area_m2},
        domain="foundation",
    )


def settlement_estimate_mm(
    raft_pressure_kpa_: float,
    raft_width_m: float,
    soil_elastic_modulus_mpa: float,
    influence_factor: float = 0.85,
) -> CalculationResult:
    """Very coarse elastic settlement estimate:
    S = influence_factor * q * B * (1 - v^2) / Es, with v=0.3 assumed.
    Purely for order-of-magnitude planning comparison across scenarios —
    NOT a substitute for a geotechnical settlement analysis (which must
    consider layering, consolidation, pile-group interaction, etc.).
    """
    v = 0.3
    es_kpa = soil_elastic_modulus_mpa * 1000.0
    settlement_m = influence_factor * raft_pressure_kpa_ * raft_width_m * (1 - v**2) / max(es_kpa, 1.0)
    return CalculationResult(
        value=round(settlement_m * 1000, 1),
        units="mm",
        method="S = If * q * B * (1 - v^2) / Es (elastic half-space approximation, v=0.3)",
        inputs={"raft_pressure_kpa": raft_pressure_kpa_, "raft_width_m": raft_width_m,
                "soil_elastic_modulus_mpa": soil_elastic_modulus_mpa, "influence_factor": influence_factor},
        confidence="indicative",
        domain="geotechnical",
    )


def preliminary_foundation_demand(
    foundation: FoundationModel,
    gravity_reaction_kn: float,
    site: SiteInvestigation | None = None,
    load_factor: float = 1.0,
) -> FoundationDemandSummary:
    total = total_gravity_load_kn(gravity_reaction_kn, load_factor)
    avg_pile = average_pile_load_kn(total.value, foundation.pile_count)
    util = average_pile_utilisation(avg_pile.value, foundation.pile_capacity_kn)
    # Coarse tributary-area proxy when no raft geometry is given: each pile
    # "owns" a square of side (3 * pile diameter), summed over pile count.
    raft_area = foundation.raft_area_m2 or (foundation.pile_count * (foundation.pile_diameter_m * 3) ** 2)
    raft_press = raft_pressure_kpa(total.value, raft_area)
    es = 40.0
    if site is not None:
        layer = site.layer_at_depth(foundation.pile_length_m)
        if layer and layer.elastic_modulus_mpa:
            es = layer.elastic_modulus_mpa
    settlement = settlement_estimate_mm(raft_press.value, raft_area**0.5, es)
    return FoundationDemandSummary(
        total_load=total,
        average_pile_load=avg_pile,
        average_pile_utilisation=util,
        raft_pressure=raft_press,
        settlement_estimate=settlement,
    )
