"""Preliminary wind load estimation (spec section 10).

Uses a simple velocity-pressure formulation (q = 0.5 * rho * V^2 * shape *
exposure), NOT any specific national wind-loading code's full gust/terrain
methodology. Results are explicitly PRELIMINARY ENGINEERING ESTIMATEs.
"""

from __future__ import annotations

from typing import ClassVar

from pydantic import BaseModel

from new_taipei_supertall_os.domain.calculation import CalculationResult

AIR_DENSITY_KG_M3 = 1.225


class WindModel(BaseModel):
    building_height_m: float
    building_width_m: float
    building_depth_m: float
    wind_speed_m_s: float
    exposure: str = "C"  # A (urban/dense) .. D (open/coastal), coarse configurable multiplier
    shape_factor: float = 1.3  # coarse drag/shape coefficient

    EXPOSURE_MULTIPLIER: ClassVar[dict[str, float]] = {"A": 0.85, "B": 1.0, "C": 1.15, "D": 1.3}

    def exposure_multiplier(self) -> float:
        return self.EXPOSURE_MULTIPLIER.get(self.exposure, 1.0)

    def height_multiplier(self, z_m: float) -> float:
        """Coarse power-law velocity profile (v(z)/v_ref), alpha=0.22 as a
        generic urban-terrain planning exponent."""
        z_ref = max(self.building_height_m, 10.0)
        alpha = 0.22
        return max(0.4, (max(z_m, 3.0) / z_ref) ** alpha)

    def wind_pressure_kpa(self, z_m: float | None = None) -> CalculationResult:
        z = z_m if z_m is not None else self.building_height_m
        v_z = self.wind_speed_m_s * self.height_multiplier(z)
        q = 0.5 * AIR_DENSITY_KG_M3 * v_z**2 * self.exposure_multiplier() * self.shape_factor / 1000.0
        return CalculationResult(
            value=round(q, 3),
            units="kPa",
            method="q = 0.5 * rho * v(z)^2 * exposure_multiplier * shape_factor",
            inputs={"z_m": z, "base_wind_speed_m_s": self.wind_speed_m_s,
                    "exposure": self.exposure, "shape_factor": self.shape_factor},
            domain="wind",
        )

    def wind_force_kn(self, z_m: float | None = None) -> CalculationResult:
        z = z_m if z_m is not None else self.building_height_m
        q = self.wind_pressure_kpa(z).value
        force = q * self.building_width_m  # per metre height -> treat as line load, see total force below
        return CalculationResult(
            value=round(force, 1),
            units="kN/m",
            method="line_force = wind_pressure_kpa(z) * building_width_m",
            inputs={"z_m": z, "building_width_m": self.building_width_m},
            domain="wind",
        )

    def total_wind_force_kn(self, n_segments: int = 20) -> CalculationResult:
        """Integrate the line-force profile up the height (simple Riemann
        sum) for a total base shear estimate."""
        dz = self.building_height_m / n_segments
        total = 0.0
        for i in range(n_segments):
            z = (i + 0.5) * dz
            total += self.wind_force_kn(z).value * dz
        return CalculationResult(
            value=round(total, 0),
            units="kN",
            method=f"riemann_sum(wind_force_kn(z), n_segments={n_segments})",
            inputs={"building_height_m": self.building_height_m, "n_segments": n_segments},
            domain="wind",
        )

    def overturning_moment_knm(self) -> CalculationResult:
        """Base overturning moment from the wind force profile, taking
        moment about the foundation level."""
        n_segments = 20
        dz = self.building_height_m / n_segments
        moment = 0.0
        for i in range(n_segments):
            z = (i + 0.5) * dz
            force_at_z = self.wind_force_kn(z).value * dz
            moment += force_at_z * z
        return CalculationResult(
            value=round(moment, 0),
            units="kN.m",
            method="sum(force_segment * lever_arm_z)",
            inputs={"building_height_m": self.building_height_m},
            domain="wind",
        )

    def floor_shear_profile(self, floor_elevations_m: list[float]) -> list[CalculationResult]:
        """Cumulative shear at each floor elevation (shear above that level)."""
        sorted_elevs = sorted(floor_elevations_m)
        results = []
        n_segments = 40
        dz = self.building_height_m / n_segments
        for elev in sorted_elevs:
            shear = 0.0
            z = elev
            while z < self.building_height_m:
                mid = z + dz / 2
                if mid > self.building_height_m:
                    break
                shear += self.wind_force_kn(mid).value * dz
                z += dz
            results.append(
                CalculationResult(
                    value=round(shear, 1),
                    units="kN",
                    method="integrate wind_force_kn(z) from elevation to building_height",
                    inputs={"elevation_m": elev},
                    domain="wind",
                )
            )
        return results
