"""Preliminary seismic demand estimation (spec section 11).

Uses a generic equivalent-static-force approximation (base shear as a
fraction of seismic weight, first-mode period from a height-based
empirical formula, inverted-triangular storey-shear distribution). This is
NOT a code-compliant response-spectrum or code-specific equivalent-static
procedure — it exists purely to give the optimisation/scenario layers a
directionally-sensible number, and every output is stamped PRELIMINARY.
"""

from __future__ import annotations

from typing import ClassVar

from pydantic import BaseModel

from new_taipei_supertall_os.domain.calculation import CalculationResult
from new_taipei_supertall_os.domain.structural import StructuralSystemType


class SeismicModel(BaseModel):
    building_mass_tonnes: float
    height_m: float
    site_class: str = "C"
    seismic_zone_factor: float = 0.30
    structural_system: StructuralSystemType = StructuralSystemType.COMPOSITE_FRAME
    importance_factor: float = 1.25  # high-occupancy supertall, configurable

    SITE_CLASS_AMPLIFICATION: ClassVar[dict[str, float]] = {
        "A": 0.8, "B": 0.9, "C": 1.0, "D": 1.2, "E": 1.4,
    }

    def period_estimate_s(self) -> CalculationResult:
        """Empirical fundamental-period approximation, T ~ Ct * H^0.75
        (a widely-used code-style height-based formula), Ct depends
        loosely on system type."""
        ct_by_system = {
            StructuralSystemType.REINFORCED_CONCRETE_CORE: 0.05,
            StructuralSystemType.STEEL_FRAME: 0.085,
            StructuralSystemType.COMPOSITE_FRAME: 0.065,
            StructuralSystemType.MEGA_FRAME: 0.058,
            StructuralSystemType.DIAGRID: 0.055,
            StructuralSystemType.OUTRIGGER: 0.052,
            StructuralSystemType.DUAL_SYSTEM: 0.055,
        }
        ct = ct_by_system.get(self.structural_system, 0.06)
        t = ct * self.height_m**0.75
        return CalculationResult(
            value=round(t, 2),
            units="s",
            method="T = Ct * H^0.75 (generic empirical height-based formula)",
            inputs={"height_m": self.height_m, "Ct": ct, "structural_system": self.structural_system.value},
            domain="seismic",
        )

    def response_coefficient(self) -> CalculationResult:
        """Coarse seismic response coefficient Cs, roughly analogous to a
        code Sa(T)/R*I style term but deliberately simplified: it combines
        zone factor, site amplification, and a system-dependent ductility
        discount, then decays with period."""
        amp = self.SITE_CLASS_AMPLIFICATION.get(self.site_class, 1.0)
        t = self.period_estimate_s().value
        ductility_r = self.structural_system.relative_lateral_stiffness_factor
        cs_base = self.seismic_zone_factor * amp * self.importance_factor / max(ductility_r, 0.5)
        # long-period decay ~ 1/T for T>1s, generic
        cs = cs_base if t <= 1.0 else cs_base / t
        cs = max(cs, 0.01)
        return CalculationResult(
            value=round(cs, 4),
            units="dimensionless",
            method="Cs = zone_factor * site_amplification * importance_factor / "
                    "ductility_proxy, decayed by 1/T for T>1s",
            inputs={"period_s": t, "site_amplification": amp, "ductility_proxy": ductility_r},
            domain="seismic",
        )

    def base_shear_kn(self) -> CalculationResult:
        cs = self.response_coefficient().value
        weight_kn = self.building_mass_tonnes * 9.81
        shear = cs * weight_kn
        return CalculationResult(
            value=round(shear, 0),
            units="kN",
            method="V = Cs * W",
            inputs={"Cs": cs, "seismic_weight_kn": round(weight_kn, 0)},
            domain="seismic",
        )

    def storey_shear_distribution(self, floor_elevations_m: list[float], floor_masses_tonnes: list[float]) -> list[CalculationResult]:
        """Inverted-triangular (linear with height) distribution of base
        shear to floors, per a generic code-style Fx = V * (wx*hx)/sum(wi*hi)."""
        if len(floor_elevations_m) != len(floor_masses_tonnes):
            raise ValueError("floor_elevations_m and floor_masses_tonnes must be same length")
        v = self.base_shear_kn().value
        weighted = [m * h for m, h in zip(floor_masses_tonnes, floor_elevations_m)]
        denom = sum(weighted) or 1.0
        results = []
        for elev, mass, w in zip(floor_elevations_m, floor_masses_tonnes, weighted):
            fx = v * w / denom
            results.append(
                CalculationResult(
                    value=round(fx, 1),
                    units="kN",
                    method="Fx = V * (wx*hx) / sum(wi*hi)",
                    inputs={"elevation_m": elev, "mass_tonnes": mass},
                    domain="seismic",
                )
            )
        return results

    def lateral_displacement_estimate_m(self) -> CalculationResult:
        """Very coarse top-of-building lateral displacement estimate,
        derived from base shear, an assumed effective lateral stiffness
        proxy, and system stiffness factor. For comparative scenario
        analysis only."""
        v = self.base_shear_kn().value
        k_eff = 15000.0 * self.structural_system.relative_lateral_stiffness_factor  # kN/m, coarse proxy
        disp = v / max(k_eff, 1.0)
        return CalculationResult(
            value=round(disp, 3),
            units="m",
            method="delta = V / k_eff (k_eff is a coarse configurable stiffness proxy)",
            inputs={"base_shear_kn": v, "k_eff_kn_per_m": k_eff},
            confidence="indicative",
            domain="seismic",
        )
