"""Preliminary structural demand summary (spec section 7).

Combines the loads/wind/seismic modules into a single per-building
demand summary: gravity reactions, governing lateral force case,
approximate drift ratio, approximate overturning moment. This is a
planning/optimisation aggregation layer, not a structural analysis.
"""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.domain.building import Building
from new_taipei_supertall_os.domain.calculation import CalculationResult
from new_taipei_supertall_os.domain.floor import Floor
from new_taipei_supertall_os.domain.structural import StructuralFrame
from new_taipei_supertall_os.engineering import loads
from new_taipei_supertall_os.engineering.seismic import SeismicModel
from new_taipei_supertall_os.engineering.wind import WindModel


class StructuralDemandSummary(BaseModel):
    building_id: str
    gravity_reaction: CalculationResult
    seismic_mass_tonnes: CalculationResult
    wind_base_shear: CalculationResult
    wind_overturning_moment: CalculationResult
    seismic_base_shear: CalculationResult
    seismic_period_s: CalculationResult
    governing_lateral_case: str
    approximate_drift_ratio: CalculationResult

    model_config = {"arbitrary_types_allowed": True}


def preliminary_structural_demand(
    building: Building,
    floors: list[Floor],
    frame: StructuralFrame,
    wind: WindModel,
    seismic_zone_factor: float = 0.30,
    site_class: str = "C",
) -> StructuralDemandSummary:
    gravity = loads.cumulative_gravity_reaction_kn(floors)
    seismic_mass = loads.building_seismic_mass_tonnes(building, floors)

    seismic = SeismicModel(
        building_mass_tonnes=seismic_mass.value,
        height_m=building.height_m,
        site_class=site_class,
        seismic_zone_factor=seismic_zone_factor,
        structural_system=frame.system_type,
    )
    wind_shear = wind.total_wind_force_kn()
    wind_otm = wind.overturning_moment_knm()
    seismic_shear = seismic.base_shear_kn()
    period = seismic.period_estimate_s()

    governing = "wind" if wind_shear.value >= seismic_shear.value else "seismic"

    # Drift ratio approximation: use whichever lateral case governs, apply
    # to a coarse stiffness proxy scaled by core geometry.
    k_eff = 12000.0 * frame.system_type.relative_lateral_stiffness_factor * (frame.core.plan_area_m2 / 400.0)
    governing_force = max(wind_shear.value, seismic_shear.value)
    top_disp_m = governing_force / max(k_eff, 1.0)
    drift_ratio = top_disp_m / max(building.height_m, 1.0)

    drift_result = CalculationResult(
        value=round(drift_ratio, 5),
        units="ratio (dimensionless, delta/H)",
        method="drift_ratio = (governing_lateral_force / k_eff) / building_height, "
               "k_eff scaled by core plan area and system stiffness factor",
        inputs={"governing_case": governing, "governing_force_kn": governing_force,
                "k_eff_kn_per_m": k_eff, "height_m": building.height_m},
        confidence="indicative",
        domain="structural",
    )

    return StructuralDemandSummary(
        building_id=building.id,
        gravity_reaction=gravity,
        seismic_mass_tonnes=seismic_mass,
        wind_base_shear=wind_shear,
        wind_overturning_moment=wind_otm,
        seismic_base_shear=seismic_shear,
        seismic_period_s=period,
        governing_lateral_case=governing,
        approximate_drift_ratio=drift_result,
    )
