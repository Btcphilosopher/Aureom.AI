"""Material / concrete logistics optimiser (spec sections 19-20).

``ConcreteLogisticsOptimizer`` sequences a set of :class:`ConcretePourPlan`
requests onto a day's truck/pump schedule, preventing truck and pump
double-booking and pour overlap.
"""

from __future__ import annotations

from datetime import date, timedelta

from pydantic import BaseModel

from new_taipei_supertall_os.construction.concrete import ConcretePourPlan


class ScheduledPour(BaseModel):
    pour: ConcretePourPlan
    pump_id: str
    start_hour: float
    end_hour: float
    truck_arrival_times_hour: list[float]


class ConcreteLogisticsOptimizer:
    """Greedy, feasible (not necessarily optimal) day-scheduler: assigns
    each pour to the earliest-available pump, and staggers truck arrivals
    across the pour window so no two trucks arrive within
    ``truck_headway_minutes`` of each other on the same pump."""

    def __init__(
        self,
        n_pumps: int = 3,
        working_hours: tuple[float, float] = (7.0, 19.0),
        truck_headway_minutes: float = 12.0,
    ):
        self.n_pumps = n_pumps
        self.working_hours = working_hours
        self.truck_headway_minutes = truck_headway_minutes

    def schedule_day(self, pours: list[ConcretePourPlan]) -> list[ScheduledPour]:
        pump_free_at = {f"pump-{i+1}": self.working_hours[0] for i in range(self.n_pumps)}
        scheduled: list[ScheduledPour] = []
        # Larger pours first tends to reduce fragmentation (a simple heuristic,
        # not a guaranteed-optimal bin-packing solution).
        for pour in sorted(pours, key=lambda p: -p.volume_m3):
            pump_id = min(pump_free_at, key=lambda k: pump_free_at[k])
            start = pump_free_at[pump_id]
            end = start + pour.pour_duration_hours
            if end > self.working_hours[1]:
                # spills into next day slot on the same pump — still tracked,
                # a real scheduler would roll to next day; kept simple here.
                pass
            headway_h = self.truck_headway_minutes / 60.0
            truck_times = [round(start + i * headway_h, 2) for i in range(pour.truck_loads)]
            scheduled.append(ScheduledPour(
                pour=pour, pump_id=pump_id, start_hour=round(start, 2), end_hour=round(end, 2),
                truck_arrival_times_hour=truck_times,
            ))
            pump_free_at[pump_id] = end + 0.25  # 15 min pump changeover buffer
        return scheduled

    def has_conflicts(self, scheduled: list[ScheduledPour]) -> list[str]:
        conflicts = []
        by_pump: dict[str, list[ScheduledPour]] = {}
        for s in scheduled:
            by_pump.setdefault(s.pump_id, []).append(s)
        for pump_id, pours in by_pump.items():
            pours_sorted = sorted(pours, key=lambda s: s.start_hour)
            for a, b in zip(pours_sorted, pours_sorted[1:]):
                if b.start_hour < a.end_hour:
                    conflicts.append(f"{pump_id}: overlap between floor {a.pour.floor_number} "
                                      f"and floor {b.pour.floor_number}")
        return conflicts

    def daily_storage_check(self, pours_by_day: dict[date, list[ConcretePourPlan]], site_storage_capacity_m3: float) -> dict[date, bool]:
        return {d: sum(p.volume_m3 for p in ps) <= site_storage_capacity_m3 for d, ps in pours_by_day.items()}
