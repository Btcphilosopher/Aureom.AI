"""Site logistics engine: represents the site as a graph and answers
routing / congestion questions over it (spec section 28)."""

from __future__ import annotations

import networkx as nx
from pydantic import BaseModel

from new_taipei_supertall_os.domain.site import Site, SiteNode, SiteNodeType


class RouteResult(BaseModel):
    path: list[str]
    length_m: float
    estimated_minutes: float


class SiteLogisticsEngine:
    def __init__(self, site: Site):
        self.site = site
        self._graph = self._build_graph()

    def _build_graph(self) -> nx.Graph:
        g = nx.Graph()
        for node in self.site.nodes:
            g.add_node(node.id, node=node)
        for edge in self.site.edges:
            g.add_edge(edge.from_node, edge.to_node, length_m=edge.length_m, max_speed_kmh=edge.max_speed_kmh)
        return g

    def shortest_route(self, from_node: str, to_node: str) -> RouteResult:
        path = nx.shortest_path(self._graph, from_node, to_node, weight="length_m")
        length = nx.shortest_path_length(self._graph, from_node, to_node, weight="length_m")
        # crude time estimate using min edge speed along the path
        minutes = 0.0
        for a, b in zip(path, path[1:]):
            edge = self._graph.edges[a, b]
            speed_m_per_min = (edge["max_speed_kmh"] * 1000) / 60
            minutes += edge["length_m"] / max(speed_m_per_min, 1e-6)
        return RouteResult(path=path, length_m=round(length, 1), estimated_minutes=round(minutes, 2))

    def nodes_of_type(self, node_type: SiteNodeType) -> list[SiteNode]:
        return [n for n in self.site.nodes if n.node_type == node_type]

    def laydown_utilisation(self, stored_area_m2_by_node: dict[str, float]) -> dict[str, float]:
        out = {}
        for node in self.nodes_of_type(SiteNodeType.LAYDOWN_ZONE):
            used = stored_area_m2_by_node.get(node.id, 0.0)
            out[node.id] = round(used / node.capacity, 3) if node.capacity else 0.0
        return out

    def congestion_flags(self, utilisation: dict[str, float], threshold: float = 0.9) -> list[str]:
        return [node_id for node_id, u in utilisation.items() if u >= threshold]

    @staticmethod
    def demo_site(area_m2: float = 18000.0) -> Site:
        """A small, clearly-labelled illustrative site layout for the
        demonstration project."""
        nodes = [
            SiteNode(id="truck-gate-1", node_type=SiteNodeType.TRUCK_GATE, x_m=0, y_m=0),
            SiteNode(id="truck-gate-2", node_type=SiteNodeType.TRUCK_GATE, x_m=140, y_m=0),
            SiteNode(id="worker-entrance", node_type=SiteNodeType.WORKER_ENTRANCE, x_m=0, y_m=90),
            SiteNode(id="laydown-1", node_type=SiteNodeType.LAYDOWN_ZONE, x_m=40, y_m=40, capacity=2500),
            SiteNode(id="laydown-2", node_type=SiteNodeType.LAYDOWN_ZONE, x_m=100, y_m=40, capacity=2000),
            SiteNode(id="crane-1", node_type=SiteNodeType.TOWER_CRANE, x_m=60, y_m=60),
            SiteNode(id="crane-2", node_type=SiteNodeType.TOWER_CRANE, x_m=100, y_m=60),
            SiteNode(id="crane-3", node_type=SiteNodeType.TOWER_CRANE, x_m=60, y_m=100),
            SiteNode(id="crane-4", node_type=SiteNodeType.TOWER_CRANE, x_m=100, y_m=100),
            SiteNode(id="pump-1", node_type=SiteNodeType.CONCRETE_PUMP, x_m=70, y_m=50),
            SiteNode(id="welfare", node_type=SiteNodeType.WELFARE, x_m=10, y_m=90),
            SiteNode(id="wash-bay", node_type=SiteNodeType.WASH_BAY, x_m=20, y_m=10),
            SiteNode(id="waste-area", node_type=SiteNodeType.WASTE_AREA, x_m=120, y_m=10),
        ]
        edges = []
        chain = ["truck-gate-1", "wash-bay", "laydown-1", "crane-1", "crane-3", "worker-entrance"]
        for a, b in zip(chain, chain[1:]):
            na, nb = next(n for n in nodes if n.id == a), next(n for n in nodes if n.id == b)
            length = ((na.x_m - nb.x_m) ** 2 + (na.y_m - nb.y_m) ** 2) ** 0.5
            edges.append({"from_node": a, "to_node": b, "length_m": round(length, 1)})
        chain2 = ["truck-gate-2", "laydown-2", "crane-2", "crane-4", "waste-area"]
        for a, b in zip(chain2, chain2[1:]):
            na, nb = next(n for n in nodes if n.id == a), next(n for n in nodes if n.id == b)
            length = ((na.x_m - nb.x_m) ** 2 + (na.y_m - nb.y_m) ** 2) ** 0.5
            edges.append({"from_node": a, "to_node": b, "length_m": round(length, 1)})
        for extra in [("laydown-1", "pump-1"), ("laydown-2", "pump-1"), ("crane-1", "crane-2"), ("welfare", "worker-entrance")]:
            na = next(n for n in nodes if n.id == extra[0])
            nb = next(n for n in nodes if n.id == extra[1])
            length = ((na.x_m - nb.x_m) ** 2 + (na.y_m - nb.y_m) ** 2) ** 0.5
            edges.append({"from_node": extra[0], "to_node": extra[1], "length_m": round(length, 1)})

        from new_taipei_supertall_os.domain.site import SiteEdge
        return Site(id="site-demo", name="NT-SUPERTALL-001 site (SIMULATION ONLY)", area_m2=area_m2,
                     nodes=nodes, edges=[SiteEdge(**e) for e in edges])
