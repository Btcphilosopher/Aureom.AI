"""Operational tower-crane lift-task queueing (used by the digital twin and
simulation layers). Strategic crane-count/position optimisation lives in
``optimisation.cranes``."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.domain.crane import CraneTaskType, TowerCrane


class LiftTask(BaseModel):
    id: str
    crane_id: str
    task_type: CraneTaskType
    radial_distance_m: float
    lift_height_m: float
    requested_at_min: float


class LiftEvent(BaseModel):
    task_id: str
    crane_id: str
    start_min: float
    end_min: float
    wait_min: float


class CraneQueueEngine:
    """FCFS queue per crane; assumes each crane can only run one lift at a
    time (physically accurate for a single hook)."""

    def simulate(self, cranes: list[TowerCrane], tasks: list[LiftTask]) -> list[LiftEvent]:
        crane_by_id = {c.id: c for c in cranes}
        free_at: dict[str, float] = {c.id: 0.0 for c in cranes}
        events: list[LiftEvent] = []
        for task in sorted(tasks, key=lambda t: t.requested_at_min):
            crane = crane_by_id.get(task.crane_id)
            if crane is None:
                continue
            start = max(task.requested_at_min, free_at[task.crane_id])
            duration = crane.average_cycle_time_min(task.radial_distance_m, task.lift_height_m)
            end = start + duration
            free_at[task.crane_id] = end
            events.append(LiftEvent(task_id=task.id, crane_id=task.crane_id, start_min=round(start, 1),
                                     end_min=round(end, 1), wait_min=round(start - task.requested_at_min, 1)))
        return events

    def utilisation(self, events: list[LiftEvent], crane_id: str, horizon_min: float) -> float:
        busy = sum(e.end_min - e.start_min for e in events if e.crane_id == crane_id)
        return round(busy / max(horizon_min, 1e-6), 3)
