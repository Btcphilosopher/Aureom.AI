"""Truck routing / arrival-queue engine (spec section 29)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class VehicleType(str, Enum):
    CONCRETE_TRUCK = "concrete_truck"
    STEEL_TRUCK = "steel_truck"
    MATERIAL_TRUCK = "material_truck"
    EXCAVATION_TRUCK = "excavation_truck"
    WASTE_TRUCK = "waste_truck"


class TruckJob(BaseModel):
    id: str
    vehicle_type: VehicleType
    scheduled_arrival_hour: float
    service_time_min: float = 20.0
    gate: str = "gate-1"


class TruckEvent(BaseModel):
    truck_id: str
    arrival_hour: float
    queue_start_hour: float
    loading_start_hour: float
    departure_hour: float
    queue_wait_min: float


class TruckRoutingEngine:
    """Single-server-per-gate queueing model (FCFS) for truck arrivals,
    loading/unloading, and departure — a deterministic approximation used
    for planning; ``simulation.logistics`` runs the stochastic SimPy
    version for Monte Carlo purposes."""

    def __init__(self, gates: list[str] | None = None):
        self.gates = gates or ["gate-1"]

    def simulate(self, jobs: list[TruckJob]) -> list[TruckEvent]:
        gate_free_at: dict[str, float] = {g: 0.0 for g in self.gates}
        events: list[TruckEvent] = []
        for job in sorted(jobs, key=lambda j: j.scheduled_arrival_hour):
            gate = job.gate if job.gate in gate_free_at else self.gates[0]
            queue_start = job.scheduled_arrival_hour
            loading_start = max(queue_start, gate_free_at[gate])
            departure = loading_start + job.service_time_min / 60.0
            gate_free_at[gate] = departure
            events.append(TruckEvent(
                truck_id=job.id, arrival_hour=job.scheduled_arrival_hour,
                queue_start_hour=queue_start, loading_start_hour=loading_start,
                departure_hour=departure, queue_wait_min=round((loading_start - queue_start) * 60, 1),
            ))
        return events

    def average_queue_wait_min(self, events: list[TruckEvent]) -> float:
        if not events:
            return 0.0
        return round(sum(e.queue_wait_min for e in events) / len(events), 1)

    def peak_queue_length(self, events: list[TruckEvent], resolution_min: float = 5.0) -> int:
        if not events:
            return 0
        end = max(e.departure_hour for e in events)
        step = resolution_min / 60.0
        t = 0.0
        peak = 0
        while t <= end:
            in_queue = sum(1 for e in events if e.queue_start_hour <= t < e.loading_start_hour)
            peak = max(peak, in_queue)
            t += step
        return peak
