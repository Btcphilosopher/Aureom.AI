"""Construction hoist queueing / worker-and-material movement optimiser
(spec section 25)."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.domain.hoist import ConstructionHoist


class HoistRequest(BaseModel):
    id: str
    hoist_id: str
    requested_at_min: float
    destination_height_m: float
    passengers: int = 1


class HoistEvent(BaseModel):
    request_id: str
    hoist_id: str
    start_min: float
    end_min: float
    wait_min: float


class HoistQueueEngine:
    def simulate(self, hoists: list[ConstructionHoist], requests: list[HoistRequest]) -> list[HoistEvent]:
        hoist_by_id = {h.id: h for h in hoists}
        free_at: dict[str, float] = {h.id: 0.0 for h in hoists}
        events: list[HoistEvent] = []
        for req in sorted(requests, key=lambda r: r.requested_at_min):
            hoist = hoist_by_id.get(req.hoist_id)
            if hoist is None:
                continue
            start = max(req.requested_at_min, free_at[req.hoist_id])
            duration = hoist.cycle_time_min(req.destination_height_m)
            end = start + duration
            free_at[req.hoist_id] = end
            events.append(HoistEvent(request_id=req.id, hoist_id=req.hoist_id, start_min=round(start, 1),
                                      end_min=round(end, 1), wait_min=round(start - req.requested_at_min, 1)))
        return events

    def optimise_worker_material_split(self, hoists: list[ConstructionHoist], worker_demand_per_day: float, material_demand_trips_per_day: float) -> dict[str, int]:
        """Very simple proportional-allocation heuristic: split the hoist
        fleet between dedicated worker and material duty in proportion to
        relative demand, keeping at least one of each where possible."""
        n = len(hoists)
        if n == 0:
            return {"worker_hoists": 0, "material_hoists": 0}
        total_demand = worker_demand_per_day + material_demand_trips_per_day
        worker_share = worker_demand_per_day / total_demand if total_demand else 0.5
        worker_hoists = max(1, round(n * worker_share)) if n > 1 else 1
        worker_hoists = min(worker_hoists, n - 1) if n > 1 else worker_hoists
        return {"worker_hoists": worker_hoists, "material_hoists": n - worker_hoists}
