"""SQLAlchemy ORM models (PostgreSQL/PostGIS-oriented; works against SQLite
for local development and tests too — PostGIS-specific geometry columns
are avoided here in favour of a portable lat/lon float pair so the demo
runs without the PostGIS extension installed)."""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import JSON, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class BuildingRecord(Base):
    __tablename__ = "buildings"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(255))
    city: Mapped[str] = mapped_column(String(128), default="New Taipei City")
    height_m: Mapped[float] = mapped_column(Float)
    floors: Mapped[int] = mapped_column(Integer)
    basement_floors: Mapped[int] = mapped_column(Integer, default=0)
    gross_floor_area_m2: Mapped[float] = mapped_column(Float)
    site_area_m2: Mapped[float] = mapped_column(Float)
    structural_system: Mapped[str] = mapped_column(String(64))
    foundation_type: Mapped[str] = mapped_column(String(64))
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    use_mix: Mapped[dict] = mapped_column(JSON, default=dict)
    is_demonstration: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    floors_rel: Mapped[list["FloorRecord"]] = relationship(back_populates="building", cascade="all, delete-orphan")
    schedules: Mapped[list["ScheduleRecord"]] = relationship(back_populates="building", cascade="all, delete-orphan")
    cost_estimates: Mapped[list["CostEstimateRecord"]] = relationship(back_populates="building", cascade="all, delete-orphan")


class FloorRecord(Base):
    __tablename__ = "floors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    building_id: Mapped[str] = mapped_column(ForeignKey("buildings.id"))
    number: Mapped[int] = mapped_column(Integer)
    elevation_m: Mapped[float] = mapped_column(Float)
    area_m2: Mapped[float] = mapped_column(Float)
    use_type: Mapped[str] = mapped_column(String(32))
    construction_status: Mapped[str] = mapped_column(String(32), default="not_started")
    progress_structure_pct: Mapped[float] = mapped_column(Float, default=0.0)
    progress_facade_pct: Mapped[float] = mapped_column(Float, default=0.0)
    progress_mep_pct: Mapped[float] = mapped_column(Float, default=0.0)
    progress_interiors_pct: Mapped[float] = mapped_column(Float, default=0.0)

    building: Mapped[BuildingRecord] = relationship(back_populates="floors_rel")


class ScheduleRecord(Base):
    __tablename__ = "schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    building_id: Mapped[str] = mapped_column(ForeignKey("buildings.id"))
    version: Mapped[str] = mapped_column(String(32), default="0.1.0")
    scenario: Mapped[str] = mapped_column(String(128), default="baseline")
    duration_days: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    building: Mapped[BuildingRecord] = relationship(back_populates="schedules")
    tasks: Mapped[list["TaskRecord"]] = relationship(back_populates="schedule", cascade="all, delete-orphan")


class TaskRecord(Base):
    __tablename__ = "tasks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    schedule_id: Mapped[int] = mapped_column(ForeignKey("schedules.id"))
    task_key: Mapped[str] = mapped_column(String(128))
    name: Mapped[str] = mapped_column(String(255))
    duration_days: Mapped[float] = mapped_column(Float)
    predecessors: Mapped[list] = mapped_column(JSON, default=list)
    phase: Mapped[str] = mapped_column(String(64), default="")
    cost_twd: Mapped[float] = mapped_column(Float, default=0.0)
    es: Mapped[float | None] = mapped_column(Float, nullable=True)
    ef: Mapped[float | None] = mapped_column(Float, nullable=True)
    ls: Mapped[float | None] = mapped_column(Float, nullable=True)
    lf: Mapped[float | None] = mapped_column(Float, nullable=True)
    is_critical: Mapped[bool] = mapped_column(default=False)

    schedule: Mapped[ScheduleRecord] = relationship(back_populates="tasks")


class CostEstimateRecord(Base):
    __tablename__ = "cost_estimates"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    building_id: Mapped[str] = mapped_column(ForeignKey("buildings.id"))
    currency: Mapped[str] = mapped_column(String(8), default="TWD")
    total_twd: Mapped[float] = mapped_column(Float)
    scenario: Mapped[str] = mapped_column(String(128), default="baseline")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    building: Mapped[BuildingRecord] = relationship(back_populates="cost_estimates")
    line_items: Mapped[list["CostLineItemRecord"]] = relationship(back_populates="estimate", cascade="all, delete-orphan")


class CostLineItemRecord(Base):
    __tablename__ = "cost_line_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    estimate_id: Mapped[int] = mapped_column(ForeignKey("cost_estimates.id"))
    category: Mapped[str] = mapped_column(String(64))
    amount_twd: Mapped[float] = mapped_column(Float)
    method: Mapped[str] = mapped_column(Text)

    estimate: Mapped[CostEstimateRecord] = relationship(back_populates="line_items")


class ComplianceStatusRecord(Base):
    __tablename__ = "compliance_status"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    building_id: Mapped[str] = mapped_column(ForeignKey("buildings.id"))
    category: Mapped[str] = mapped_column(String(64))
    status: Mapped[str] = mapped_column(String(32))
    notes: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)


class DigitalTwinEntityRecord(Base):
    __tablename__ = "digital_twin_entities"

    id: Mapped[str] = mapped_column(String(128), primary_key=True)
    building_id: Mapped[str] = mapped_column(ForeignKey("buildings.id"))
    entity_type: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(32))
    task: Mapped[str | None] = mapped_column(String(255), nullable=True)
    location_x_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    location_y_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    location_z_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    attributes: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, onupdate=_utcnow)
