"""SQLAlchemy persistence layer: ORM models and repositories."""
