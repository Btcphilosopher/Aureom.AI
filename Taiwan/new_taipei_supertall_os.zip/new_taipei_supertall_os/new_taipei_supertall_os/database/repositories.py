"""Thin repository layer over the SQLAlchemy models, plus a session-factory
helper. Uses SQLite by default for local/dev/test use; point
``config.settings.DatabaseConfig.url`` at PostgreSQL/PostGIS for
production."""

from __future__ import annotations

from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from new_taipei_supertall_os.construction.schedule import ProjectSchedule
from new_taipei_supertall_os.database.models import (
    Base,
    BuildingRecord,
    ComplianceStatusRecord,
    CostEstimateRecord,
    CostLineItemRecord,
    DigitalTwinEntityRecord,
    FloorRecord,
    ScheduleRecord,
    TaskRecord,
)
from new_taipei_supertall_os.digital_twin.state import DigitalTwinState
from new_taipei_supertall_os.domain.building import Building
from new_taipei_supertall_os.domain.floor import Floor
from new_taipei_supertall_os.finance.cost import CostEstimate


def make_engine(url: str = "sqlite:///:memory:", echo: bool = False):
    return create_engine(url, echo=echo, future=True)


def init_db(engine) -> None:
    Base.metadata.create_all(engine)


@contextmanager
def session_scope(engine):
    SessionLocal = sessionmaker(bind=engine, future=True)
    session: Session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


class BuildingRepository:
    def __init__(self, session: Session):
        self.session = session

    def save(self, building: Building, floors: list[Floor] | None = None) -> BuildingRecord:
        record = self.session.get(BuildingRecord, building.id)
        if record is None:
            record = BuildingRecord(id=building.id)
            self.session.add(record)
        record.name = building.name
        record.city = building.city
        record.height_m = building.height_m
        record.floors = building.floors
        record.basement_floors = building.basement_floors
        record.gross_floor_area_m2 = building.gross_floor_area_m2
        record.site_area_m2 = building.site_area_m2
        record.structural_system = building.structural_system
        record.foundation_type = building.foundation_type
        record.use_mix = building.use_mix
        record.is_demonstration = building.is_demonstration
        if floors:
            record.floors_rel.clear()
            for f in floors:
                record.floors_rel.append(FloorRecord(
                    number=f.number, elevation_m=f.elevation_m, area_m2=f.area_m2,
                    use_type=f.use_type.value, construction_status=f.construction_status.value,
                    progress_structure_pct=f.progress_structure_pct, progress_facade_pct=f.progress_facade_pct,
                    progress_mep_pct=f.progress_mep_pct, progress_interiors_pct=f.progress_interiors_pct,
                ))
        return record

    def get(self, building_id: str) -> BuildingRecord | None:
        return self.session.get(BuildingRecord, building_id)

    def list_all(self) -> list[BuildingRecord]:
        return list(self.session.query(BuildingRecord).all())


class ScheduleRepository:
    def __init__(self, session: Session):
        self.session = session

    def save(self, building_id: str, schedule: ProjectSchedule, scenario: str = "baseline") -> ScheduleRecord:
        record = ScheduleRecord(building_id=building_id, version=schedule.version_info.version,
                                 scenario=scenario, duration_days=schedule.duration_days)
        by_id = {r.task_id: r for r in schedule.activity_results}
        for t in schedule.tasks:
            act = by_id.get(t.id)
            record.tasks.append(TaskRecord(
                task_key=t.id, name=t.name, duration_days=t.duration_days,
                predecessors=t.predecessors, phase=t.phase, cost_twd=t.cost_twd,
                es=act.es if act else None, ef=act.ef if act else None,
                ls=act.ls if act else None, lf=act.lf if act else None,
                is_critical=act.is_critical if act else False,
            ))
        self.session.add(record)
        return record

    def latest(self, building_id: str) -> ScheduleRecord | None:
        return (
            self.session.query(ScheduleRecord)
            .filter(ScheduleRecord.building_id == building_id)
            .order_by(ScheduleRecord.created_at.desc())
            .first()
        )


class CostRepository:
    def __init__(self, session: Session):
        self.session = session

    def save(self, building_id: str, estimate: CostEstimate, scenario: str = "baseline") -> CostEstimateRecord:
        record = CostEstimateRecord(building_id=building_id, currency=estimate.currency,
                                     total_twd=estimate.total_twd, scenario=scenario)
        for li in estimate.line_items:
            record.line_items.append(CostLineItemRecord(category=li.category.value, amount_twd=li.amount_twd, method=li.method))
        self.session.add(record)
        return record

    def latest(self, building_id: str) -> CostEstimateRecord | None:
        return (
            self.session.query(CostEstimateRecord)
            .filter(CostEstimateRecord.building_id == building_id)
            .order_by(CostEstimateRecord.created_at.desc())
            .first()
        )


class ComplianceRepository:
    def __init__(self, session: Session):
        self.session = session

    def upsert(self, building_id: str, category: str, status: str, notes: str = "") -> ComplianceStatusRecord:
        record = (
            self.session.query(ComplianceStatusRecord)
            .filter_by(building_id=building_id, category=category)
            .first()
        )
        if record is None:
            record = ComplianceStatusRecord(building_id=building_id, category=category)
            self.session.add(record)
        record.status = status
        record.notes = notes
        return record

    def all_for_building(self, building_id: str) -> list[ComplianceStatusRecord]:
        return list(self.session.query(ComplianceStatusRecord).filter_by(building_id=building_id).all())


class DigitalTwinRepository:
    def __init__(self, session: Session):
        self.session = session

    def save_state(self, building_id: str, state: DigitalTwinState) -> None:
        for entity in state.entities.values():
            record = self.session.get(DigitalTwinEntityRecord, entity.id)
            if record is None:
                record = DigitalTwinEntityRecord(id=entity.id, building_id=building_id)
                self.session.add(record)
            record.entity_type = entity.entity_type.value
            record.status = entity.status
            record.task = entity.task
            record.location_x_m = entity.location_x_m
            record.location_y_m = entity.location_y_m
            record.location_z_m = entity.location_z_m
            record.attributes = entity.attributes

    def all_for_building(self, building_id: str) -> list[DigitalTwinEntityRecord]:
        return list(self.session.query(DigitalTwinEntityRecord).filter_by(building_id=building_id).all())
