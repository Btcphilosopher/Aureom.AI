"""Cost, cash-flow, procurement and sensitivity engines. All monetary
figures are generated from configurable rates and computed quantities
(config/materials.yaml, config/labour.yaml) — never hard-coded totals."""
