"""Procurement tracking and long-lead material detection
(spec sections 38, 39)."""

from __future__ import annotations

from datetime import date, timedelta

from pydantic import BaseModel

from new_taipei_supertall_os.domain.material import Material, MaterialBatch


class ProcurementStatus(BaseModel):
    material: Material
    batch: MaterialBatch
    required_on_site_date: date
    latest_order_date: date
    is_long_lead: bool
    buffer_days: int
    risk: str  # "on_track" | "at_risk" | "late"


class LongLeadMaterialEngine:
    """Flags materials whose lead time makes them at risk of a schedule
    impact (spec section 39)."""

    def __init__(self, long_lead_threshold_days: int = 90, buffer_days: int = 14):
        self.long_lead_threshold_days = long_lead_threshold_days
        self.buffer_days = buffer_days

    def is_long_lead(self, material: Material) -> bool:
        return material.lead_time_days >= self.long_lead_threshold_days

    def assess(self, material: Material, batch: MaterialBatch, today: date | None = None) -> ProcurementStatus:
        today = today or date.today()
        required = batch.consumption_date or batch.delivery_date
        if required is None:
            raise ValueError("batch must have a delivery_date or consumption_date")
        latest_order = required - timedelta(days=material.lead_time_days + self.buffer_days)
        days_until_order_deadline = (latest_order - today).days
        if days_until_order_deadline < 0:
            risk = "late"
        elif days_until_order_deadline <= self.buffer_days:
            risk = "at_risk"
        else:
            risk = "on_track"
        return ProcurementStatus(
            material=material, batch=batch, required_on_site_date=required,
            latest_order_date=latest_order, is_long_lead=self.is_long_lead(material),
            buffer_days=self.buffer_days, risk=risk,
        )


class ProcurementEngine:
    """Tracks material/supplier/quantity/delivery-date/lead-time/cost/status."""

    def __init__(self):
        self._batches: list[MaterialBatch] = []
        self._materials: dict[str, Material] = {}

    def register_material(self, material: Material) -> None:
        self._materials[material.id] = material

    def add_batch(self, batch: MaterialBatch) -> None:
        self._batches.append(batch)

    def batches_by_status(self, status: str) -> list[MaterialBatch]:
        return [b for b in self._batches if b.status == status]

    def total_committed_cost_twd(self) -> float:
        return round(sum(b.cost_twd for b in self._batches if b.status in ("ordered", "in_transit", "delivered", "consumed")), 0)

    def most_urgent(self, engine: LongLeadMaterialEngine, today: date | None = None) -> list[ProcurementStatus]:
        results = []
        for batch in self._batches:
            material = self._materials.get(batch.material_id)
            if material is None or not (batch.consumption_date or batch.delivery_date):
                continue
            results.append(engine.assess(material, batch, today))
        return sorted(results, key=lambda r: (r.risk != "late", r.risk != "at_risk", r.latest_order_date))
