"""Construction waste tracking / reduction engine (spec section 54)."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.config.settings import Settings
from new_taipei_supertall_os.construction.concrete import ConcretePourPlan
from new_taipei_supertall_os.domain.building import Building


class WasteEstimate(BaseModel):
    concrete_waste_m3: float
    steel_waste_tonnes: float
    packaging_waste_kg: float
    recycling_target_fraction: float
    recyclable_waste_kg: float


class WasteEngine:
    def __init__(self, settings: Settings):
        self.waste_cfg = settings.materials.get("waste", {})

    def estimate(self, building: Building, pours: list[ConcretePourPlan], steel_tonnes: float, gfa_m2: float) -> WasteEstimate:
        concrete_vol = sum(p.volume_m3 for p in pours)
        concrete_waste = concrete_vol * self.waste_cfg.get("concrete_waste_fraction", 0.03)
        steel_waste = steel_tonnes * self.waste_cfg.get("steel_waste_fraction", 0.02)
        packaging_waste = gfa_m2 * self.waste_cfg.get("packaging_waste_kg_per_m2_gfa", 0.8)
        recycling_target = self.waste_cfg.get("recycling_rate_target", 0.55)
        total_waste_kg = concrete_waste * 2400 + steel_waste * 1000 + packaging_waste
        return WasteEstimate(
            concrete_waste_m3=round(concrete_waste, 1),
            steel_waste_tonnes=round(steel_waste, 2),
            packaging_waste_kg=round(packaging_waste, 0),
            recycling_target_fraction=recycling_target,
            recyclable_waste_kg=round(total_waste_kg * recycling_target, 0),
        )

    def optimise_ordering_buffer(self, current_waste_fraction: float, target_fraction: float) -> float:
        """Suggested reduction in over-ordering buffer, as a fraction, to
        move from the current observed waste fraction toward the target."""
        return max(0.0, round(current_waste_fraction - target_fraction, 4))
