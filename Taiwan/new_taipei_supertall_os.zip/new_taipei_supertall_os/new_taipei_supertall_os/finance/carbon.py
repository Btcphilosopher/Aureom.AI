"""Construction carbon engine (spec section 53)."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.config.settings import Settings
from new_taipei_supertall_os.construction.concrete import ConcretePourPlan
from new_taipei_supertall_os.construction.facade import FacadeEngine
from new_taipei_supertall_os.construction.steel import SteelConstructionEngine
from new_taipei_supertall_os.domain.building import Building
from new_taipei_supertall_os.domain.floor import Floor
from new_taipei_supertall_os.domain.structural import StructuralSystemType


class CarbonEstimate(BaseModel):
    building_id: str
    concrete_kgco2e: float
    steel_kgco2e: float
    facade_kgco2e: float
    transport_kgco2e: float
    equipment_fuel_kgco2e: float
    electricity_kgco2e: float
    waste_kgco2e: float

    @property
    def total_kgco2e(self) -> float:
        return round(sum([
            self.concrete_kgco2e, self.steel_kgco2e, self.facade_kgco2e,
            self.transport_kgco2e, self.equipment_fuel_kgco2e,
            self.electricity_kgco2e, self.waste_kgco2e,
        ]), 0)

    def kgco2e_per_m2(self, gfa_m2: float) -> float:
        return round(self.total_kgco2e / max(gfa_m2, 1.0), 1)

    def kgco2e_per_floor(self, n_floors: int) -> float:
        return round(self.total_kgco2e / max(n_floors, 1), 1)


class ConstructionCarbonEngine:
    def __init__(self, settings: Settings, construction_duration_days: float = 1500.0):
        self.settings = settings
        self.materials = settings.materials
        self.construction_duration_days = construction_duration_days

    def estimate(
        self,
        building: Building,
        floors: list[Floor],
        pours: list[ConcretePourPlan],
        steel_tonnes: float | None = None,
        equipment_daily_fuel_kgco2e: float = 1800.0,
        electricity_kgco2e_per_kwh: float = 0.5,
        site_electricity_kwh_per_day: float = 4500.0,
    ) -> CarbonEstimate:
        conc_rates = self.materials.get("concrete", {}).get("grades", {})
        concrete_co2 = sum(p.volume_m3 * conc_rates.get(p.grade, {}).get("co2e_kg_per_m3", 350) for p in pours)

        steel_rate = self.materials.get("steel", {}).get("co2e_kg_per_tonne", 1850)
        if steel_tonnes is None:
            se = SteelConstructionEngine()
            steel_tonnes = se.building_steel_tonnage([f for f in floors if f.number > 0],
                                                       StructuralSystemType(building.structural_system))
        steel_co2 = steel_tonnes * steel_rate

        facade_rate = self.materials.get("facade", {}).get("co2e_kg_per_m2", 220)
        fe = FacadeEngine()
        facade_area = fe.material_demand_m2([f for f in floors if f.number > 0])
        facade_co2 = facade_area * facade_rate

        # transport: a coarse proxy proportional to concrete+steel mass moved
        transport_co2 = (sum(p.volume_m3 for p in pours) * 2.4 + steel_tonnes) * 12.0

        equipment_co2 = equipment_daily_fuel_kgco2e * self.construction_duration_days
        electricity_co2 = site_electricity_kwh_per_day * self.construction_duration_days * electricity_kgco2e_per_kwh

        waste_fraction = self.materials.get("waste", {}).get("concrete_waste_fraction", 0.03)
        waste_co2 = concrete_co2 * waste_fraction + steel_co2 * self.materials.get("waste", {}).get("steel_waste_fraction", 0.02)

        return CarbonEstimate(
            building_id=building.id,
            concrete_kgco2e=round(concrete_co2, 0),
            steel_kgco2e=round(steel_co2, 0),
            facade_kgco2e=round(facade_co2, 0),
            transport_kgco2e=round(transport_co2, 0),
            equipment_fuel_kgco2e=round(equipment_co2, 0),
            electricity_kgco2e=round(electricity_co2, 0),
            waste_kgco2e=round(waste_co2, 0),
        )
