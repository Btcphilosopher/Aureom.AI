"""Cost Monte Carlo simulation and single-factor sensitivity analysis
(spec section 51)."""

from __future__ import annotations

import random

from pydantic import BaseModel

from new_taipei_supertall_os.finance.cost import CostEstimate


class CostMonteCarloResult(BaseModel):
    n_simulations: int
    p50_cost_twd: float
    p80_cost_twd: float
    p90_cost_twd: float
    mean_cost_twd: float
    std_dev_twd: float


class CostMonteCarlo:
    """Randomises material price, labour, schedule delay, equipment,
    weather, and contingency-draw factors around the deterministic
    estimate, per spec section 51."""

    def __init__(
        self,
        material_price_std: float = 0.08,
        labour_std: float = 0.06,
        schedule_delay_cost_std: float = 0.10,
        equipment_std: float = 0.05,
        weather_std: float = 0.04,
        contingency_draw_std: float = 0.03,
        seed: int | None = None,
    ):
        self.stds = [material_price_std, labour_std, schedule_delay_cost_std,
                     equipment_std, weather_std, contingency_draw_std]
        self._rng = random.Random(seed)

    def run(self, estimate: CostEstimate, n_simulations: int = 1000) -> CostMonteCarloResult:
        base = estimate.total_twd
        samples = []
        for _ in range(n_simulations):
            multiplier = 1.0
            for std in self.stds:
                multiplier += self._rng.gauss(0, std)
            samples.append(max(base * multiplier, 0.0))
        samples.sort()

        def pct(p: float) -> float:
            idx = min(len(samples) - 1, int(p * len(samples)))
            return round(samples[idx], 0)

        mean = sum(samples) / len(samples)
        variance = sum((s - mean) ** 2 for s in samples) / len(samples)
        return CostMonteCarloResult(
            n_simulations=n_simulations,
            p50_cost_twd=pct(0.50), p80_cost_twd=pct(0.80), p90_cost_twd=pct(0.90),
            mean_cost_twd=round(mean, 0), std_dev_twd=round(variance**0.5, 0),
        )


class SensitivityFactor(BaseModel):
    name: str
    low_multiplier: float
    high_multiplier: float
    low_cost_twd: float
    high_cost_twd: float
    swing_twd: float


def tornado_sensitivity(estimate: CostEstimate, factors: dict[str, tuple[float, float]]) -> list[SensitivityFactor]:
    """``factors``: {name: (low_multiplier, high_multiplier)} applied to the
    total cost independently, for a classic tornado-chart sensitivity view."""
    base = estimate.total_twd
    out = []
    for name, (lo, hi) in factors.items():
        low_cost = base * lo
        high_cost = base * hi
        out.append(SensitivityFactor(
            name=name, low_multiplier=lo, high_multiplier=hi,
            low_cost_twd=round(low_cost, 0), high_cost_twd=round(high_cost, 0),
            swing_twd=round(abs(high_cost - low_cost), 0),
        ))
    return sorted(out, key=lambda f: -f.swing_twd)
