"""Cash-flow engine: monthly planned/actual/forecast/cumulative expenditure
and S-curve generation (spec section 37)."""

from __future__ import annotations

import math

from pydantic import BaseModel

from new_taipei_supertall_os.construction.schedule import ProjectSchedule


class MonthlyCashflow(BaseModel):
    month_index: int
    planned_twd: float
    actual_twd: float | None = None
    forecast_twd: float | None = None
    cumulative_planned_twd: float = 0.0
    cumulative_actual_twd: float | None = None


class CashFlowEngine:
    """Distributes each task's cost across its own duration window using a
    smooth S-curve weighting (a common construction cash-flow shape: slow
    start, fast middle, slow finish), then aggregates by month.
    """

    def __init__(self, total_project_cost_twd: float | None = None):
        self.total_project_cost_twd = total_project_cost_twd

    @staticmethod
    def _s_curve_weight(t: float) -> float:
        """Logistic-shaped density over t in [0, 1]."""
        # derivative of a logistic CDF, normalised numerically by caller
        k = 10.0
        x = k * (t - 0.5)
        return math.exp(-x) / (1 + math.exp(-x)) ** 2

    def _task_monthly_distribution(self, duration_days: float, cost_twd: float, n_points: int = 30) -> list[float]:
        if duration_days <= 0:
            return [cost_twd]
        weights = [self._s_curve_weight((i + 0.5) / n_points) for i in range(n_points)]
        total_w = sum(weights) or 1.0
        return [cost_twd * w / total_w for w in weights]

    def planned_monthly_cashflow(self, schedule: ProjectSchedule, activity_results: dict[str, tuple[float, float]] | None = None) -> list[MonthlyCashflow]:
        """``activity_results`` maps task_id -> (ES, EF) in days; if not
        supplied, derived from ``schedule.activity_results`` (requires the
        CriticalPathEngine to have run first)."""
        es_ef = activity_results or {r.task_id: (r.es, r.ef) for r in schedule.activity_results}
        if not es_ef:
            raise ValueError("Schedule has no activity timing — run CriticalPathEngine.run() first.")

        horizon_days = max(ef for _, ef in es_ef.values())
        n_months = max(1, math.ceil(horizon_days / 30.4))
        monthly = [0.0] * n_months

        for task in schedule.tasks:
            if task.id not in es_ef or task.cost_twd <= 0:
                continue
            es, ef = es_ef[task.id]
            duration = max(ef - es, 0.1)
            n_points = max(1, math.ceil(duration))
            dist = self._task_monthly_distribution(duration, task.cost_twd, n_points=n_points)
            day_per_point = duration / n_points
            for i, amount in enumerate(dist):
                day = es + (i + 0.5) * day_per_point
                month_idx = min(int(day / 30.4), n_months - 1)
                monthly[month_idx] += amount

        cumulative = 0.0
        results = []
        for i, amount in enumerate(monthly):
            cumulative += amount
            results.append(MonthlyCashflow(month_index=i, planned_twd=round(amount, 0),
                                            cumulative_planned_twd=round(cumulative, 0)))
        return results

    def apply_actuals(self, planned: list[MonthlyCashflow], actual_by_month: dict[int, float]) -> list[MonthlyCashflow]:
        cumulative_actual = 0.0
        for row in planned:
            if row.month_index in actual_by_month:
                row.actual_twd = actual_by_month[row.month_index]
                cumulative_actual += row.actual_twd
                row.cumulative_actual_twd = round(cumulative_actual, 0)
            else:
                row.forecast_twd = row.planned_twd
        return planned
