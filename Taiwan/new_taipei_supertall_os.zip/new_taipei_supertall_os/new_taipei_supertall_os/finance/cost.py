"""Construction cost engine (spec sections 35, 36).

Costs are always derived from configurable rates (``config/materials.yaml``,
``config/labour.yaml``) multiplied by quantities computed elsewhere in the
platform (structural, facade, MEP, workforce engines) — never hard-coded
totals.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field

from new_taipei_supertall_os.config.settings import Settings
from new_taipei_supertall_os.construction.concrete import ConcretePourPlan
from new_taipei_supertall_os.construction.facade import FacadeEngine
from new_taipei_supertall_os.construction.mep import MEPEngine
from new_taipei_supertall_os.construction.steel import SteelConstructionEngine
from new_taipei_supertall_os.domain.building import Building
from new_taipei_supertall_os.domain.floor import Floor
from new_taipei_supertall_os.domain.structural import StructuralSystemType


class CostCategory(str, Enum):
    LAND = "land"
    DESIGN = "design"
    CONSULTANTS = "consultants"
    PERMITS = "permits"
    DEMOLITION = "demolition"
    EXCAVATION = "excavation"
    FOUNDATION = "foundation"
    CONCRETE = "concrete"
    STEEL = "steel"
    FACADE = "facade"
    MEP = "mep"
    ELEVATORS = "elevators"
    INTERIORS = "interiors"
    LABOUR = "labour"
    EQUIPMENT = "equipment"
    LOGISTICS = "logistics"
    TEMPORARY_WORKS = "temporary_works"
    FINANCING = "financing"
    CONTINGENCY = "contingency"


class CostLineItem(BaseModel):
    category: CostCategory
    amount_twd: float
    method: str
    quantity: float | None = None
    unit: str | None = None
    unit_rate_twd: float | None = None


class CostEstimate(BaseModel):
    building_id: str
    currency: str = "TWD"
    line_items: list[CostLineItem] = Field(default_factory=list)

    @property
    def total_twd(self) -> float:
        return round(sum(li.amount_twd for li in self.line_items), 0)

    def by_category(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for li in self.line_items:
            out[li.category.value] = out.get(li.category.value, 0.0) + li.amount_twd
        return out


class ConstructionCostEngine:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.materials = settings.materials
        self.labour = settings.labour

    def _concrete_rate(self, grade: str = "C40") -> float:
        return self.materials.get("concrete", {}).get("grades", {}).get(grade, {}).get("unit_cost_twd_per_m3", 3800)

    def concrete_cost(self, pours: list[ConcretePourPlan]) -> CostLineItem:
        total = 0.0
        for p in pours:
            total += p.volume_m3 * self._concrete_rate(p.grade)
        return CostLineItem(category=CostCategory.CONCRETE, amount_twd=round(total, 0),
                             method="sum(pour_volume_m3 * grade_unit_rate)",
                             quantity=sum(p.volume_m3 for p in pours), unit="m3")

    def steel_cost(self, floors: list[Floor], system: StructuralSystemType) -> CostLineItem:
        rate = self.materials.get("steel", {}).get("unit_cost_twd_per_tonne", 42000)
        se = SteelConstructionEngine()
        tonnes = se.building_steel_tonnage(floors, system)
        return CostLineItem(category=CostCategory.STEEL, amount_twd=round(tonnes * rate, 0),
                             method="steel_tonnage * unit_cost_per_tonne",
                             quantity=tonnes, unit="tonnes", unit_rate_twd=rate)

    def facade_cost(self, floors: list[Floor]) -> CostLineItem:
        rate = self.materials.get("facade", {}).get("unit_cost_twd_per_m2", 18000)
        fe = FacadeEngine(unit_cost_twd_per_m2=rate)
        cost = fe.cost_twd(floors)
        return CostLineItem(category=CostCategory.FACADE, amount_twd=cost,
                             method="facade_area_m2 * unit_cost_per_m2",
                             quantity=fe.material_demand_m2(floors), unit="m2", unit_rate_twd=rate)

    def mep_cost(self, floors: list[Floor]) -> CostLineItem:
        rate = self.materials.get("mep", {}).get("unit_cost_twd_per_m2_gfa", 9500)
        me = MEPEngine(unit_cost_twd_per_m2_gfa=rate)
        cost = me.total_material_demand_twd(floors)
        gfa = sum(f.area_m2 for f in floors)
        return CostLineItem(category=CostCategory.MEP, amount_twd=cost,
                             method="sum(floor_area_m2 * mep_rate_by_system)",
                             quantity=gfa, unit="m2 gfa", unit_rate_twd=rate)

    def elevator_cost(self, elevator_count: int) -> CostLineItem:
        rate = self.materials.get("elevators", {}).get("unit_cost_twd_per_unit", 18_000_000)
        return CostLineItem(category=CostCategory.ELEVATORS, amount_twd=round(elevator_count * rate, 0),
                             method="elevator_count * unit_cost_per_unit",
                             quantity=elevator_count, unit="units", unit_rate_twd=rate)

    def interiors_cost(self, floors: list[Floor]) -> CostLineItem:
        from new_taipei_supertall_os.construction.interiors import InteriorsEngine
        cost = InteriorsEngine().total_cost_twd(floors)
        return CostLineItem(category=CostCategory.INTERIORS, amount_twd=cost, method="sum(floor_area*fitout_rate_by_use)")

    def labour_cost(self, worker_days_by_trade: dict[str, float]) -> CostLineItem:
        total = 0.0
        rates = self.labour.get("trades", {})
        for trade, days in worker_days_by_trade.items():
            rate = rates.get(trade, {}).get("daily_rate_twd", 3500)
            total += days * rate
        return CostLineItem(category=CostCategory.LABOUR, amount_twd=round(total, 0),
                             method="sum(worker_days_by_trade * trade_daily_rate)")

    def flat_rate_item(self, category: CostCategory, basis_amount_twd: float, fraction: float, method: str) -> CostLineItem:
        return CostLineItem(category=category, amount_twd=round(basis_amount_twd * fraction, 0), method=method)

    def estimate(
        self,
        building: Building,
        floors: list[Floor],
        pours: list[ConcretePourPlan],
        elevator_count: int = 60,
        worker_days_by_trade: dict[str, float] | None = None,
        land_cost_twd_per_m2: float = 350_000.0,
    ) -> CostEstimate:
        above_grade = [f for f in floors if f.number > 0]
        items: list[CostLineItem] = []

        land = CostLineItem(category=CostCategory.LAND, amount_twd=round(building.site_area_m2 * land_cost_twd_per_m2, 0),
                             method="site_area_m2 * land_rate_per_m2",
                             quantity=building.site_area_m2, unit="m2", unit_rate_twd=land_cost_twd_per_m2)
        items.append(land)
        items.append(self.concrete_cost(pours))
        items.append(self.steel_cost(above_grade, StructuralSystemType(building.structural_system)))
        items.append(self.facade_cost(above_grade))
        items.append(self.mep_cost(above_grade))
        items.append(self.elevator_cost(elevator_count))
        items.append(self.interiors_cost(above_grade))
        if worker_days_by_trade:
            items.append(self.labour_cost(worker_days_by_trade))

        hard_cost_so_far = sum(li.amount_twd for li in items if li.category != CostCategory.LAND)
        items.append(self.flat_rate_item(CostCategory.DESIGN, hard_cost_so_far, 0.045, "4.5% of hard cost (design fees)"))
        items.append(self.flat_rate_item(CostCategory.CONSULTANTS, hard_cost_so_far, 0.02, "2% of hard cost"))
        items.append(self.flat_rate_item(CostCategory.PERMITS, hard_cost_so_far, 0.005, "0.5% of hard cost"))
        items.append(self.flat_rate_item(CostCategory.DEMOLITION, hard_cost_so_far, 0.01, "1% of hard cost"))
        items.append(self.flat_rate_item(CostCategory.EXCAVATION, hard_cost_so_far, 0.06, "6% of hard cost (deep excavation)"))
        items.append(self.flat_rate_item(CostCategory.FOUNDATION, hard_cost_so_far, 0.08, "8% of hard cost (piled raft)"))
        items.append(self.flat_rate_item(CostCategory.EQUIPMENT, hard_cost_so_far, 0.05, "5% of hard cost (cranes/hoists/pumps)"))
        items.append(self.flat_rate_item(CostCategory.LOGISTICS, hard_cost_so_far, 0.02, "2% of hard cost"))
        items.append(self.flat_rate_item(CostCategory.TEMPORARY_WORKS, hard_cost_so_far, 0.03, "3% of hard cost"))
        items.append(self.flat_rate_item(CostCategory.FINANCING, hard_cost_so_far, 0.04, "4% of hard cost (construction financing)"))
        subtotal = sum(li.amount_twd for li in items)
        items.append(self.flat_rate_item(CostCategory.CONTINGENCY, subtotal, 0.08, "8% contingency on subtotal"))

        return CostEstimate(building_id=building.id, line_items=items)


def cost_per_floor(estimate: CostEstimate, n_floors: int) -> float:
    return round(estimate.total_twd / max(n_floors, 1), 0)


def cost_per_m2(estimate: CostEstimate, gfa_m2: float) -> float:
    return round(estimate.total_twd / max(gfa_m2, 1.0), 1)


def cost_breakdown_per_m2(estimate: CostEstimate, gfa_m2: float) -> dict[str, float]:
    return {cat: round(amt / max(gfa_m2, 1.0), 1) for cat, amt in estimate.by_category().items()}
