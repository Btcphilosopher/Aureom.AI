"""Task/ProjectSchedule model and critical-path engine (spec sections 32, 33).

``ProjectSchedule`` wraps a NetworkX DAG of ``Task`` nodes. ``CriticalPathEngine``
performs a standard forward/backward CPM pass (ES/EF/LS/LF/Float) and
classifies activities as critical / near-critical.
"""

from __future__ import annotations

import networkx as nx
from pydantic import BaseModel, Field

from new_taipei_supertall_os.domain.calculation import VersionInfo


class Task(BaseModel):
    id: str
    name: str
    duration_days: float
    predecessors: list[str] = Field(default_factory=list)
    resources: dict[str, float] = Field(default_factory=dict)
    cost_twd: float = 0.0
    phase: str = ""


class ScheduleActivityResult(BaseModel):
    task_id: str
    es: float
    ef: float
    ls: float
    lf: float
    total_float: float
    is_critical: bool
    is_near_critical: bool


class ProjectSchedule(BaseModel):
    project_id: str
    tasks: list[Task]
    version_info: VersionInfo = Field(default_factory=VersionInfo)

    # populated by CriticalPathEngine.run()
    duration_days: float = 0.0
    critical_path: list[str] = Field(default_factory=list)
    activity_results: list[ScheduleActivityResult] = Field(default_factory=list)

    def to_graph(self) -> nx.DiGraph:
        g = nx.DiGraph()
        for t in self.tasks:
            g.add_node(t.id, task=t)
        for t in self.tasks:
            for p in t.predecessors:
                if p not in g:
                    raise ValueError(f"Task {t.id} depends on unknown predecessor {p}")
                g.add_edge(p, t.id)
        if not nx.is_directed_acyclic_graph(g):
            cycles = list(nx.simple_cycles(g))
            raise ValueError(f"Schedule contains cycles: {cycles}")
        return g

    def task(self, task_id: str) -> Task:
        for t in self.tasks:
            if t.id == task_id:
                return t
        raise KeyError(task_id)

    def total_cost_twd(self) -> float:
        return sum(t.cost_twd for t in self.tasks)


class CriticalPathEngine:
    """Standard critical-path method (CPM) forward/backward pass."""

    def __init__(self, near_critical_float_days: float = 5.0):
        self.near_critical_float_days = near_critical_float_days

    def run(self, schedule: ProjectSchedule) -> ProjectSchedule:
        g = schedule.to_graph()
        order = list(nx.topological_sort(g))

        es: dict[str, float] = {}
        ef: dict[str, float] = {}
        for node in order:
            task = g.nodes[node]["task"]
            preds = list(g.predecessors(node))
            es[node] = max((ef[p] for p in preds), default=0.0)
            ef[node] = es[node] + task.duration_days

        project_duration = max(ef.values(), default=0.0)

        lf: dict[str, float] = {}
        ls: dict[str, float] = {}
        for node in reversed(order):
            task = g.nodes[node]["task"]
            succs = list(g.successors(node))
            lf[node] = min((ls[s] for s in succs), default=project_duration)
            ls[node] = lf[node] - task.duration_days

        results: list[ScheduleActivityResult] = []
        critical: list[str] = []
        for node in order:
            total_float = round(ls[node] - es[node], 4)
            is_critical = abs(total_float) < 1e-6
            is_near = (not is_critical) and total_float <= self.near_critical_float_days
            if is_critical:
                critical.append(node)
            results.append(
                ScheduleActivityResult(
                    task_id=node, es=round(es[node], 2), ef=round(ef[node], 2),
                    ls=round(ls[node], 2), lf=round(lf[node], 2),
                    total_float=total_float, is_critical=is_critical, is_near_critical=is_near,
                )
            )

        schedule.duration_days = round(project_duration, 2)
        schedule.critical_path = critical
        schedule.activity_results = results
        return schedule

    def near_critical_activities(self, schedule: ProjectSchedule) -> list[ScheduleActivityResult]:
        return [r for r in schedule.activity_results if r.is_near_critical]

    def schedule_risk_summary(self, schedule: ProjectSchedule) -> dict[str, float]:
        n_total = len(schedule.activity_results) or 1
        n_critical = sum(1 for r in schedule.activity_results if r.is_critical)
        n_near = sum(1 for r in schedule.activity_results if r.is_near_critical)
        return {
            "duration_days": schedule.duration_days,
            "n_activities": n_total,
            "n_critical": n_critical,
            "n_near_critical": n_near,
            "critical_fraction": round(n_critical / n_total, 3),
        }
