"""Construction planning engines: sequencing, schedule/CPM, and the
trade-specific quantity/duration engines (concrete, steel, facade, MEP,
interiors, commissioning)."""
