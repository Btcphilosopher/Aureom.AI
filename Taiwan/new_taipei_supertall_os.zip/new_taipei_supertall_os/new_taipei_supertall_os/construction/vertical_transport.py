"""Elevator / vertical transportation system engine (spec section 24)."""

from __future__ import annotations

from pydantic import BaseModel, Field

from new_taipei_supertall_os.domain.hoist import ConstructionHoist


class ElevatorGroup(BaseModel):
    id: str
    elevator_count: int
    speed_m_per_min: float = 600.0
    capacity_persons: int = 24
    travel_height_m: float = 400.0
    serves_floors: tuple[int, int] = (0, 92)


class ElevatorSystem(BaseModel):
    groups: list[ElevatorGroup] = Field(default_factory=list)

    def round_trip_time_s(self, group: ElevatorGroup, avg_stops: int = 6, door_time_s: float = 8.0) -> float:
        travel_s = (group.travel_height_m / group.speed_m_per_min) * 60 * 2
        stop_time_s = avg_stops * door_time_s
        return travel_s + stop_time_s

    def handling_capacity_persons_per_5min(self, group: ElevatorGroup) -> float:
        """Standard elevator-traffic-analysis style 5-minute handling
        capacity estimate: (300s / RTT) * elevators * capacity * loading
        efficiency (0.8 typical)."""
        rtt = self.round_trip_time_s(group)
        trips_per_5min = 300 / max(rtt, 1e-6)
        return round(trips_per_5min * group.elevator_count * group.capacity_persons * 0.8, 1)

    def total_handling_capacity(self) -> float:
        return round(sum(self.handling_capacity_persons_per_5min(g) for g in self.groups), 1)


class ConstructionHoistPlan(BaseModel):
    hoists: list[ConstructionHoist] = Field(default_factory=list)

    def total_worker_capacity_per_day(self, height_m: float, hours_per_day: float = 10.0) -> float:
        return round(sum(h.daily_capacity_persons(height_m, hours_per_day) for h in self.hoists), 1)

    def peak_workforce_supportable(self, height_m: float, shifts_per_worker: int = 2, hours_per_day: float = 10.0) -> float:
        """Two trips/worker/day (up + down) is the usual assumption; this
        derives the max workforce the hoist fleet can move per day."""
        return round(self.total_worker_capacity_per_day(height_m, hours_per_day) / shifts_per_worker, 0)
