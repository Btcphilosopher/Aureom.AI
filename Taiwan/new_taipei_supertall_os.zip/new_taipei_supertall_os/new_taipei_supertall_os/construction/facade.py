"""Facade engine (spec section 22)."""

from __future__ import annotations

import math

from pydantic import BaseModel

from new_taipei_supertall_os.domain.floor import Floor


class FacadeFloorDemand(BaseModel):
    floor_number: int
    perimeter_m: float
    panel_count: int
    material_area_m2: float


class FacadeEngine:
    def __init__(
        self,
        panel_area_m2: float = 12.0,
        install_rate_panels_per_crew_per_day: float = 6.0,
        crews: int = 4,
        unit_cost_twd_per_m2: float = 18000.0,
    ):
        self.panel_area_m2 = panel_area_m2
        self.install_rate_panels_per_crew_per_day = install_rate_panels_per_crew_per_day
        self.crews = crews
        self.unit_cost_twd_per_m2 = unit_cost_twd_per_m2

    def estimate_perimeter_m(self, floor: Floor) -> float:
        """Coarse perimeter estimate from plan area, assuming a roughly
        square-ish plate (perimeter = 4*sqrt(area)). Real perimeter should
        come from the actual floor geometry when available."""
        return 4 * math.sqrt(max(floor.area_m2, 0.0))

    def floor_demand(self, floor: Floor, facade_height_m: float | None = None) -> FacadeFloorDemand:
        height = facade_height_m or floor.floor_to_floor_m
        perimeter = self.estimate_perimeter_m(floor)
        area = perimeter * height
        panels = max(1, math.ceil(area / self.panel_area_m2))
        return FacadeFloorDemand(floor_number=floor.number, perimeter_m=round(perimeter, 1),
                                  panel_count=panels, material_area_m2=round(area, 1))

    def panels_per_day(self) -> float:
        return self.crews * self.install_rate_panels_per_crew_per_day

    def floors_per_week(self, floors: list[Floor]) -> float:
        avg_panels = sum(self.floor_demand(f).panel_count for f in floors) / max(len(floors), 1)
        return round(7 * self.panels_per_day() / max(avg_panels, 1e-6), 2)

    def installation_duration_days(self, floors: list[Floor]) -> float:
        total_panels = sum(self.floor_demand(f).panel_count for f in floors)
        return round(total_panels / max(self.panels_per_day(), 1e-6), 1)

    def material_demand_m2(self, floors: list[Floor]) -> float:
        return round(sum(self.floor_demand(f).material_area_m2 for f in floors), 1)

    def cost_twd(self, floors: list[Floor]) -> float:
        return round(self.material_demand_m2(floors) * self.unit_cost_twd_per_m2, 0)
