"""MEP (mechanical, electrical, plumbing, fire, comms) engine (spec section 23)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel

from new_taipei_supertall_os.domain.floor import Floor, FloorUseType


class MEPSystem(str, Enum):
    HVAC = "hvac"
    ELECTRICAL = "electrical"
    PLUMBING = "plumbing"
    FIRE = "fire"
    COMMUNICATIONS = "communications"
    VERTICAL_RISERS = "vertical_risers"


class MEPFloorDemand(BaseModel):
    floor_number: int
    system: MEPSystem
    labour_hours: float
    material_cost_twd: float


class MEPEngine:
    # coarse labour hours per m2 by system, configurable
    LABOUR_HOURS_PER_M2 = {
        MEPSystem.HVAC: 0.35,
        MEPSystem.ELECTRICAL: 0.30,
        MEPSystem.PLUMBING: 0.20,
        MEPSystem.FIRE: 0.15,
        MEPSystem.COMMUNICATIONS: 0.08,
        MEPSystem.VERTICAL_RISERS: 0.05,
    }
    # additional intensity for plant/mechanical floors
    PLANT_FLOOR_MULTIPLIER = 2.5

    def __init__(self, unit_cost_twd_per_m2_gfa: float = 9500.0, crew_size: int = 10, hours_per_day: float = 8.0):
        self.unit_cost_twd_per_m2_gfa = unit_cost_twd_per_m2_gfa
        self.crew_size = crew_size
        self.hours_per_day = hours_per_day

    def floor_demand(self, floor: Floor) -> list[MEPFloorDemand]:
        multiplier = self.PLANT_FLOOR_MULTIPLIER if floor.use_type in (FloorUseType.MECHANICAL, FloorUseType.PLANT) else 1.0
        out = []
        for system, rate in self.LABOUR_HOURS_PER_M2.items():
            hours = floor.area_m2 * rate * multiplier
            share = rate / sum(self.LABOUR_HOURS_PER_M2.values())
            cost = floor.area_m2 * self.unit_cost_twd_per_m2_gfa * share * multiplier
            out.append(MEPFloorDemand(floor_number=floor.number, system=system,
                                       labour_hours=round(hours, 1), material_cost_twd=round(cost, 0)))
        return out

    def floor_duration_days(self, floor: Floor) -> float:
        demand = self.floor_demand(floor)
        total_hours = sum(d.labour_hours for d in demand)
        crew_hours_per_day = self.crew_size * self.hours_per_day
        return round(total_hours / max(crew_hours_per_day, 1e-6), 2)

    def total_material_demand_twd(self, floors: list[Floor]) -> float:
        return round(sum(d.material_cost_twd for f in floors for d in self.floor_demand(f)), 0)

    def installation_duration_days(self, floors: list[Floor], concurrent_floors: int = 4) -> float:
        """Total duration if ``concurrent_floors`` floors are worked
        simultaneously by separate crews (a coarse resource-levelling
        proxy)."""
        per_floor = [self.floor_duration_days(f) for f in floors]
        if not per_floor:
            return 0.0
        # process floors in waves of `concurrent_floors`
        total = 0.0
        for i in range(0, len(per_floor), concurrent_floors):
            wave = per_floor[i:i + concurrent_floors]
            total += max(wave)
        return round(total, 1)
