"""Default construction sequence, floor construction cycle, core-first vs
frame-first comparison, and the synthetic demonstration programme
(spec sections 16, 17, 18, 62).
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel

from new_taipei_supertall_os.construction.schedule import ProjectSchedule, Task
from new_taipei_supertall_os.domain.building import Building


class SequenceStage(str, Enum):
    SITE_PREPARATION = "site_preparation"
    DEMOLITION = "demolition"
    UTILITIES = "utilities"
    EXCAVATION = "excavation"
    RETAINING_STRUCTURE = "retaining_structure"
    FOUNDATION = "foundation"
    BASEMENT_STRUCTURE = "basement_structure"
    PODIUM = "podium"
    CORE = "core"
    TOWER_STRUCTURE = "tower_structure"
    FACADE = "facade"
    MEP = "mep"
    ELEVATORS = "elevators"
    INTERIORS = "interiors"
    TESTING = "testing"
    COMMISSIONING = "commissioning"
    LANDSCAPING = "landscaping"
    FINAL_INSPECTION = "final_inspection"


DEFAULT_SEQUENCE: list[SequenceStage] = list(SequenceStage)


class FloorCycle(BaseModel):
    """A repeatable tower-floor construction cycle (spec section 17)."""

    formwork_days: float = 1.5
    rebar_days: float = 1.5
    mep_embeds_days: float = 0.5
    concrete_days: float = 1.0
    curing_days: float = 2.0
    stripping_days: float = 0.5
    vertical_transport_buffer_days: float = 0.5

    def cycle_time_days(self, floor_number: int = 0, height_penalty_per_100m: float = 0.15) -> float:
        """Cycle time grows slightly with height (longer hoisting/logistics
        runs), configurable via ``height_penalty_per_100m``."""
        base = (
            self.formwork_days + self.rebar_days + self.mep_embeds_days
            + self.concrete_days + self.curing_days + self.stripping_days
            + self.vertical_transport_buffer_days
        )
        elevation_penalty = (max(floor_number, 0) / 100.0) * height_penalty_per_100m
        return round(base + elevation_penalty, 2)


class CoreFrameStrategy(str, Enum):
    CORE_FIRST = "core_first"
    FRAME_FIRST = "frame_first"
    SYNCHRONIZED = "synchronized"


class CoreFrameComparison(BaseModel):
    strategy: CoreFrameStrategy
    duration_days: float
    crane_utilisation_estimate: float
    labour_estimate_worker_days: float
    concrete_schedule_risk: str


def compare_core_frame_strategies(
    building: Building,
    floor_cycle: FloorCycle,
    core_lead_floors: float = 8.0,
) -> list[CoreFrameComparison]:
    """Coarse comparative estimate of core-first / frame-first /
    synchronized strategies (spec section 18). Not a substitute for a
    full 4D construction simulation of each option — use
    ``simulation.construction`` for that."""
    n = building.floors
    base_cycle = floor_cycle.cycle_time_days()
    results = []
    for strategy in CoreFrameStrategy:
        if strategy is CoreFrameStrategy.SYNCHRONIZED:
            duration = n * base_cycle * 0.62
            crane_util = 0.82
            labour = n * 40
            risk = "MEDIUM - core and frame progress must be tightly coordinated"
        elif strategy is CoreFrameStrategy.CORE_FIRST:
            duration = (core_lead_floors * base_cycle * 0.5) + n * base_cycle * 0.66
            crane_util = 0.74
            labour = n * 38
            risk = "LOW - core leads frame, simpler crane/logistics sequencing"
        else:  # frame first
            duration = n * base_cycle * 0.70
            crane_util = 0.70
            labour = n * 42
            risk = "MEDIUM-HIGH - core must catch up to maintain lateral stability margins"
        results.append(CoreFrameComparison(
            strategy=strategy, duration_days=round(duration, 1),
            crane_utilisation_estimate=crane_util,
            labour_estimate_worker_days=round(labour, 0),
            concrete_schedule_risk=risk,
        ))
    return results


def _months_to_days(months: float) -> float:
    return months * 30.4


def build_demo_schedule(
    building: Building,
    segments: int = 6,
    strategy: CoreFrameStrategy = CoreFrameStrategy.CORE_FIRST,
) -> ProjectSchedule:
    """Builds the synthetic demonstration programme (spec section 62) as a
    dependency-graph ``ProjectSchedule`` with genuine parallel work between
    tower structure / facade / MEP / interiors, rather than a naive sum of
    phase durations.
    """
    # The spec section 62 durations (3/8/5/10/6/30/24/26/20/6 months) are
    # calibrated to the reference NT-SUPERTALL-001 demo (92 floors, 6
    # basements); they are scaled here so the schedule stays responsive to
    # a different building size (used by scenario/optimisation re-runs).
    reference_floors = 92
    reference_basements = 6
    floor_scale = max(building.floors, 1) / reference_floors
    basement_scale = max(building.basement_floors, 1) / reference_basements if building.basement_floors else 0.4

    site_prep = _months_to_days(3)
    excavation = _months_to_days(8) * basement_scale
    foundation = _months_to_days(5) * (0.5 + 0.5 * floor_scale)
    basement = _months_to_days(10) * basement_scale
    podium = _months_to_days(6)
    tower = _months_to_days(30) * floor_scale
    facade = _months_to_days(24) * floor_scale
    mep = _months_to_days(26) * floor_scale
    interiors = _months_to_days(20) * floor_scale
    commissioning = _months_to_days(6) * (0.7 + 0.3 * floor_scale)

    tasks: list[Task] = []

    def add(id_: str, name: str, duration: float, preds: list[str], phase: str, resources: dict | None = None, cost: float = 0.0) -> str:
        tasks.append(Task(id=id_, name=name, duration_days=round(duration, 1),
                           predecessors=preds, phase=phase, resources=resources or {}, cost_twd=cost))
        return id_

    add("site_prep", "Site preparation", site_prep, [], "site_preparation")
    add("demolition", "Demolition", site_prep * 0.4, ["site_prep"], "demolition")
    add("utilities", "Utility diversion", site_prep * 0.5, ["demolition"], "utilities")
    add("excavation", "Deep basement excavation", excavation, ["utilities"], "excavation",
        resources={"excavation_trucks": 12})
    add("retaining", "Retaining wall / diaphragm wall", excavation * 0.5, ["utilities"], "retaining_structure")
    add("foundation", "Piled raft foundation", foundation, ["excavation", "retaining"], "foundation",
        resources={"concrete_crew": 1})
    add("basement", "Basement structure (B6-B1)", basement, ["foundation"], "basement_structure")
    add("podium", "Podium structure", podium, ["basement"], "podium")

    seg_tower = tower / segments
    seg_facade = facade / segments
    seg_mep = mep / segments
    seg_interiors = interiors / segments

    core_lead = 0.5 if strategy is CoreFrameStrategy.CORE_FIRST else (0.0 if strategy is CoreFrameStrategy.SYNCHRONIZED else -0.25)

    prev_core = "podium"
    prev_tower = "podium"
    prev_facade: str | None = None
    prev_mep: str | None = None
    prev_interiors: str | None = None

    for i in range(1, segments + 1):
        core_id = add(f"core_seg_{i}", f"Core structure segment {i}/{segments}",
                       seg_tower * (1 + core_lead * 0.15), [prev_core], "core",
                       resources={"tower_cranes": 2})
        tower_preds = [prev_tower, core_id] if strategy is not CoreFrameStrategy.SYNCHRONIZED else [prev_tower]
        tower_id = add(f"tower_seg_{i}", f"Tower frame segment {i}/{segments}",
                        seg_tower, tower_preds, "tower_structure",
                        resources={"tower_cranes": 3, "steel_crew": 2, "concrete_crew": 2})
        facade_preds = [tower_id] + ([prev_facade] if prev_facade else [])
        facade_id = add(f"facade_seg_{i}", f"Facade segment {i}/{segments}",
                         seg_facade, facade_preds, "facade", resources={"facade_crew": 4})
        mep_preds = [facade_id] + ([prev_mep] if prev_mep else [])
        mep_id = add(f"mep_seg_{i}", f"MEP first-fix segment {i}/{segments}",
                      seg_mep, mep_preds, "mep", resources={"mep_crew": 6})
        interiors_preds = [mep_id] + ([prev_interiors] if prev_interiors else [])
        interiors_id = add(f"interiors_seg_{i}", f"Interiors segment {i}/{segments}",
                            seg_interiors, interiors_preds, "interiors", resources={"finishing_crew": 8})

        prev_core, prev_tower = core_id, tower_id
        prev_facade, prev_mep, prev_interiors = facade_id, mep_id, interiors_id

    add("elevators", "Elevator installation", _months_to_days(10), [f"tower_seg_{segments}"], "elevators")
    add("testing", "Systems testing", _months_to_days(2), [prev_interiors, "elevators"], "testing")
    add("commissioning", "Commissioning", commissioning, ["testing"], "commissioning")
    add("landscaping", "Landscaping & external works", _months_to_days(3), [f"facade_seg_{segments}"], "landscaping")
    add("final_inspection", "Final inspection", _months_to_days(1), ["commissioning", "landscaping"], "final_inspection")

    return ProjectSchedule(project_id=building.id, tasks=tasks)
