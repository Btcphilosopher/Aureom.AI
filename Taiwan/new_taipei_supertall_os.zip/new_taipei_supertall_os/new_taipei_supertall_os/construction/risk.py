"""General construction risk register and scoring engine (spec section 44)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class RiskCategory(str, Enum):
    GEOTECHNICAL = "geotechnical"
    STRUCTURAL = "structural"
    WEATHER = "weather"
    PROCUREMENT = "procurement"
    LABOUR = "labour"
    EQUIPMENT = "equipment"
    LOGISTICS = "logistics"
    FINANCIAL = "financial"
    SCHEDULE = "schedule"
    REGULATORY = "regulatory"
    NEIGHBOURING_STRUCTURES = "neighbouring_structures"
    UTILITY = "utility"


class Risk(BaseModel):
    id: str
    category: RiskCategory
    description: str
    probability: float = Field(ge=0.0, le=1.0)  # 0..1
    impact: float = Field(ge=0.0, le=1.0)        # normalised 0..1 impact severity
    exposure_twd: float = 0.0                     # optional monetary exposure
    mitigation: str = ""

    @property
    def risk_score(self) -> float:
        return round(self.probability * self.impact, 4)


class ConstructionRiskEngine:
    def register(self, risks: list[Risk]) -> list[Risk]:
        return risks

    def top_risks(self, risks: list[Risk], n: int = 5) -> list[Risk]:
        return sorted(risks, key=lambda r: -r.risk_score)[:n]

    def overall_risk_index(self, risks: list[Risk]) -> float:
        if not risks:
            return 0.0
        return round(sum(r.risk_score for r in risks) / len(risks), 4)

    def by_category(self, risks: list[Risk]) -> dict[str, float]:
        out: dict[str, list[float]] = {}
        for r in risks:
            out.setdefault(r.category.value, []).append(r.risk_score)
        return {k: round(sum(v) / len(v), 4) for k, v in out.items()}

    @staticmethod
    def demo_risk_register() -> list[Risk]:
        """A clearly-labelled illustrative baseline risk register for the
        demonstration project (SIMULATION ONLY)."""
        return [
            Risk(id="r-geo-1", category=RiskCategory.GEOTECHNICAL,
                 description="Unexpected soft layer at pile founding depth",
                 probability=0.25, impact=0.6, exposure_twd=150_000_000,
                 mitigation="Additional boreholes; pile re-design contingency"),
            Risk(id="r-struct-1", category=RiskCategory.STRUCTURAL,
                 description="Core wall reinforcement congestion causing rework",
                 probability=0.2, impact=0.4, exposure_twd=40_000_000,
                 mitigation="Early rebar detailing coordination / BIM clash checks"),
            Risk(id="r-weather-1", category=RiskCategory.WEATHER,
                 description="Typhoon season crane/facade downtime",
                 probability=0.7, impact=0.35, exposure_twd=80_000_000,
                 mitigation="Typhoon response plan; schedule buffer in facade phase"),
            Risk(id="r-proc-1", category=RiskCategory.PROCUREMENT,
                 description="Elevator system late delivery",
                 probability=0.3, impact=0.5, exposure_twd=60_000_000,
                 mitigation="Early order, dual-source shortlist"),
            Risk(id="r-labour-1", category=RiskCategory.LABOUR,
                 description="Skilled facade crew shortage at peak",
                 probability=0.35, impact=0.4, exposure_twd=30_000_000,
                 mitigation="Multi-contractor facade crew mobilisation plan"),
            Risk(id="r-fin-1", category=RiskCategory.FINANCIAL,
                 description="Steel price volatility",
                 probability=0.4, impact=0.45, exposure_twd=120_000_000,
                 mitigation="Forward-price a portion of steel tonnage"),
            Risk(id="r-reg-1", category=RiskCategory.REGULATORY,
                 description="Extended urban design review cycle",
                 probability=0.3, impact=0.3, exposure_twd=20_000_000,
                 mitigation="Early pre-application consultation"),
            Risk(id="r-neigh-1", category=RiskCategory.NEIGHBOURING_STRUCTURES,
                 description="Settlement affecting adjacent rail structure",
                 probability=0.15, impact=0.8, exposure_twd=200_000_000,
                 mitigation="Real-time monitoring, staged excavation, trigger-level response plan"),
        ]
