"""Concrete quantity, logistics and tracking engine (spec section 19)."""

from __future__ import annotations

from datetime import date

from pydantic import BaseModel, Field

from new_taipei_supertall_os.domain.floor import Floor
from new_taipei_supertall_os.domain.material import MaterialBatch


class ConcretePourPlan(BaseModel):
    floor_number: int
    element: str
    grade: str
    volume_m3: float
    truck_loads: int
    pour_duration_hours: float
    pump_capacity_m3_per_hour: float
    crew_size: int
    cementitious_material_tonnes: float
    pour_date: date | None = None
    supplier: str | None = None


class ConcreteEngine:
    """Computes pour-level quantities and tracks concrete by floor/element/
    pour date/supplier (spec section 19). Material rates are read from
    ``config/materials.yaml`` via the caller (kept out of this class so it
    stays independently testable)."""

    def __init__(
        self,
        truck_capacity_m3: float = 6.0,
        pump_capacity_m3_per_hour: float = 45.0,
        default_crew_size: int = 12,
        cementitious_kg_per_m3: dict[str, float] | None = None,
    ):
        self.truck_capacity_m3 = truck_capacity_m3
        self.pump_capacity_m3_per_hour = pump_capacity_m3_per_hour
        self.default_crew_size = default_crew_size
        self.cementitious_kg_per_m3 = cementitious_kg_per_m3 or {
            "C30": 320, "C40": 380, "C60": 480, "C80_HSC": 560,
        }

    def plan_pour(
        self,
        floor: Floor,
        element: str,
        volume_m3: float,
        grade: str = "C40",
        pour_date: date | None = None,
        supplier: str | None = None,
    ) -> ConcretePourPlan:
        truck_loads = max(1, round(volume_m3 / self.truck_capacity_m3))
        pour_duration = volume_m3 / self.pump_capacity_m3_per_hour
        cementitious_kg = volume_m3 * self.cementitious_kg_per_m3.get(grade, 380)
        return ConcretePourPlan(
            floor_number=floor.number, element=element, grade=grade,
            volume_m3=round(volume_m3, 1), truck_loads=truck_loads,
            pour_duration_hours=round(pour_duration, 2),
            pump_capacity_m3_per_hour=self.pump_capacity_m3_per_hour,
            crew_size=self.default_crew_size,
            cementitious_material_tonnes=round(cementitious_kg / 1000, 2),
            pour_date=pour_date, supplier=supplier,
        )

    def floor_slab_volume_m3(self, floor: Floor, slab_thickness_m: float = 0.22) -> float:
        return floor.area_m2 * slab_thickness_m

    def to_material_batches(self, pours: list[ConcretePourPlan], unit_cost_by_grade: dict[str, float]) -> list[MaterialBatch]:
        batches = []
        for i, p in enumerate(pours):
            cost = p.volume_m3 * unit_cost_by_grade.get(p.grade, 3800)
            batches.append(MaterialBatch(
                id=f"concrete-{p.floor_number}-{p.element}-{i}",
                material_id=f"concrete-{p.grade}", quantity=p.volume_m3, unit="m3",
                delivery_date=p.pour_date, consumption_date=p.pour_date,
                floor_number=p.floor_number, element=p.element, supplier=p.supplier,
                status="planned", cost_twd=round(cost, 0),
            ))
        return batches

    def total_volume_m3(self, pours: list[ConcretePourPlan]) -> float:
        return round(sum(p.volume_m3 for p in pours), 1)
