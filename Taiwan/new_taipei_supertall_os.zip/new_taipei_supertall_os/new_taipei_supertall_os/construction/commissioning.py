"""Testing & commissioning engine (spec section 1 pipeline / section 62)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class CommissioningSystem(str, Enum):
    FIRE_LIFE_SAFETY = "fire_life_safety"
    HVAC = "hvac"
    ELECTRICAL = "electrical"
    ELEVATORS = "elevators"
    BMS = "building_management_system"
    FACADE_PERFORMANCE = "facade_performance"


class CommissioningTask(BaseModel):
    system: CommissioningSystem
    duration_days: float
    crew_size: int
    status: str = "not_started"  # not_started | in_progress | passed | failed | requires_review


class CommissioningEngine:
    DEFAULT_DURATIONS_DAYS = {
        CommissioningSystem.FIRE_LIFE_SAFETY: 25,
        CommissioningSystem.HVAC: 35,
        CommissioningSystem.ELECTRICAL: 30,
        CommissioningSystem.ELEVATORS: 20,
        CommissioningSystem.BMS: 25,
        CommissioningSystem.FACADE_PERFORMANCE: 15,
    }

    def plan(self, gfa_m2: float, scale_factor_per_100k_m2: float = 0.15) -> list[CommissioningTask]:
        scale = 1.0 + (gfa_m2 / 100_000) * scale_factor_per_100k_m2
        return [
            CommissioningTask(system=sys_, duration_days=round(days * scale, 1), crew_size=6)
            for sys_, days in self.DEFAULT_DURATIONS_DAYS.items()
        ]

    def total_duration_days(self, tasks: list[CommissioningTask], concurrent: int = 3) -> float:
        durations = sorted((t.duration_days for t in tasks), reverse=True)
        waves = [durations[i:i + concurrent] for i in range(0, len(durations), concurrent)]
        return round(sum(max(w) for w in waves), 1)
