"""Interior fit-out engine."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.domain.floor import Floor, FloorUseType

FITOUT_RATE_TWD_PER_M2 = {
    FloorUseType.RETAIL: 22000,
    FloorUseType.OFFICE: 16000,
    FloorUseType.RESIDENTIAL: 20000,
    FloorUseType.HOTEL: 26000,
    FloorUseType.LOBBY: 30000,
    FloorUseType.OBSERVATION: 35000,
}

FITOUT_DAYS_PER_1000M2 = {
    FloorUseType.RETAIL: 12,
    FloorUseType.OFFICE: 8,
    FloorUseType.RESIDENTIAL: 10,
    FloorUseType.HOTEL: 14,
    FloorUseType.LOBBY: 16,
    FloorUseType.OBSERVATION: 20,
}


class InteriorsFloorEstimate(BaseModel):
    floor_number: int
    cost_twd: float
    duration_days: float


class InteriorsEngine:
    def floor_estimate(self, floor: Floor) -> InteriorsFloorEstimate:
        rate = FITOUT_RATE_TWD_PER_M2.get(floor.use_type, 14000)
        days_rate = FITOUT_DAYS_PER_1000M2.get(floor.use_type, 9)
        return InteriorsFloorEstimate(
            floor_number=floor.number,
            cost_twd=round(floor.area_m2 * rate, 0),
            duration_days=round(floor.area_m2 / 1000 * days_rate, 1),
        )

    def total_cost_twd(self, floors: list[Floor]) -> float:
        return round(sum(self.floor_estimate(f).cost_twd for f in floors), 0)

    def installation_duration_days(self, floors: list[Floor], concurrent_floors: int = 6) -> float:
        per_floor = [self.floor_estimate(f).duration_days for f in floors]
        total = 0.0
        for i in range(0, len(per_floor), concurrent_floors):
            total += max(per_floor[i:i + concurrent_floors], default=0.0)
        return round(total, 1)
