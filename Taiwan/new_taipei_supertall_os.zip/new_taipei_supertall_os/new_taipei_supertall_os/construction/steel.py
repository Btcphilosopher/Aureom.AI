"""Structural steel tracking and quantity engine (spec section 21)."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.domain.floor import Floor
from new_taipei_supertall_os.domain.structural import StructuralSystemType


class SteelDemand(BaseModel):
    floor_number: int
    element: str
    tonnes: float


class SteelConstructionEngine:
    def __init__(
        self,
        fabrication_lead_time_days: int = 45,
        erection_rate_tonnes_per_day_per_crane: float = 25.0,
    ):
        self.fabrication_lead_time_days = fabrication_lead_time_days
        self.erection_rate_tonnes_per_day_per_crane = erection_rate_tonnes_per_day_per_crane

    def floor_steel_demand(self, floor: Floor, system: StructuralSystemType, elements: tuple[str, ...] = ("columns", "beams")) -> list[SteelDemand]:
        rate = system.relative_steel_tonnes_per_m2
        total = floor.area_m2 * rate
        split = {"columns": 0.35, "beams": 0.45, "mega_columns": 0.10, "trusses": 0.05, "outriggers": 0.05}
        demands = []
        for element in elements:
            frac = split.get(element, 1.0 / max(len(elements), 1))
            demands.append(SteelDemand(floor_number=floor.number, element=element, tonnes=round(total * frac, 2)))
        return demands

    def building_steel_tonnage(self, floors: list[Floor], system: StructuralSystemType) -> float:
        return round(sum(f.area_m2 * system.relative_steel_tonnes_per_m2 for f in floors), 1)

    def fabrication_demand_schedule(self, floors: list[Floor], system: StructuralSystemType, install_start_offset_days: float = 0) -> list[dict]:
        """Returns [{floor_number, order_by_day, tonnes}] — the fabrication
        order-by date, offset backward from an assumed install date, by
        ``fabrication_lead_time_days``."""
        out = []
        for f in floors:
            tonnes = f.area_m2 * system.relative_steel_tonnes_per_m2
            install_day = install_start_offset_days + max(f.number, 0) * (tonnes / max(self.erection_rate_tonnes_per_day_per_crane, 1))
            out.append({
                "floor_number": f.number,
                "tonnes": round(tonnes, 2),
                "install_day_estimate": round(install_day, 1),
                "order_by_day": round(install_day - self.fabrication_lead_time_days, 1),
            })
        return out

    def crane_demand_tonnes_per_day(self, tonnes: float, n_cranes: int) -> float:
        capacity = n_cranes * self.erection_rate_tonnes_per_day_per_crane
        return round(tonnes / max(capacity, 1e-6), 2)  # days needed

    def installation_rate(self, n_cranes: int) -> float:
        return n_cranes * self.erection_rate_tonnes_per_day_per_crane
