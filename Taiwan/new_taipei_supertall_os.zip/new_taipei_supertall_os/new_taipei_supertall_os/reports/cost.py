"""Cost report (spec sections 35, 36)."""

from __future__ import annotations

import pandas as pd

from new_taipei_supertall_os.finance.cost import CostEstimate


def cost_breakdown_report(estimate: CostEstimate) -> pd.DataFrame:
    rows = [
        {"category": li.category.value, "amount_twd": li.amount_twd, "method": li.method,
         "quantity": li.quantity, "unit": li.unit, "unit_rate_twd": li.unit_rate_twd}
        for li in estimate.line_items
    ]
    df = pd.DataFrame(rows)
    df["pct_of_total"] = (df["amount_twd"] / estimate.total_twd * 100).round(2)
    df = df.astype(object).where(pd.notnull(df), None)
    return df.sort_values("amount_twd", ascending=False).reset_index(drop=True)


def cost_summary(estimate: CostEstimate, gfa_m2: float, n_floors: int) -> dict:
    return {
        "total_twd": estimate.total_twd,
        "cost_per_m2_twd": round(estimate.total_twd / max(gfa_m2, 1), 1),
        "cost_per_floor_twd": round(estimate.total_twd / max(n_floors, 1), 0),
    }
