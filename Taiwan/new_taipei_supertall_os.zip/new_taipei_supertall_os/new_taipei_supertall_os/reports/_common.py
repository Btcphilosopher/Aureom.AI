"""Shared export helpers (spec section 65: JSON, CSV, Parquet, Excel, PDF,
GeoJSON, IFC metadata)."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def export_dataframe(df: pd.DataFrame, path: str | Path, fmt: str | None = None) -> Path:
    path = Path(path)
    fmt = fmt or path.suffix.lstrip(".").lower()
    if fmt == "csv":
        df.to_csv(path, index=False)
    elif fmt in ("parquet", "pq"):
        df.to_parquet(path, index=False)
    elif fmt in ("xlsx", "excel"):
        df.to_excel(path, index=False)
    elif fmt == "json":
        df.to_json(path, orient="records", indent=2, date_format="iso")
    else:
        raise ValueError(f"Unsupported export format: {fmt}")
    return path


def export_pdf_summary(title: str, rows: list[tuple[str, str]], path: str | Path) -> Path:
    """A minimal PDF summary table (label/value rows) using reportlab, if
    installed; raises a clear error otherwise (PDF export is optional)."""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
    except ImportError as exc:  # pragma: no cover - optional dependency
        raise RuntimeError("reportlab is required for PDF export (pip install reportlab)") from exc

    path = Path(path)
    c = canvas.Canvas(str(path), pagesize=A4)
    width, height = A4
    y = height - 50
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, y, title)
    y -= 30
    c.setFont("Helvetica", 10)
    for label, value in rows:
        if y < 50:
            c.showPage()
            y = height - 50
        c.drawString(40, y, f"{label}: {value}")
        y -= 16
    c.save()
    return path
