"""Risk report (spec section 44)."""

from __future__ import annotations

import pandas as pd

from new_taipei_supertall_os.construction.risk import Risk


def risk_report(risks: list[Risk]) -> pd.DataFrame:
    rows = [
        {"id": r.id, "category": r.category.value, "description": r.description,
         "probability": r.probability, "impact": r.impact, "risk_score": r.risk_score,
         "exposure_twd": r.exposure_twd, "mitigation": r.mitigation}
        for r in risks
    ]
    return pd.DataFrame(rows).sort_values("risk_score", ascending=False).reset_index(drop=True)
