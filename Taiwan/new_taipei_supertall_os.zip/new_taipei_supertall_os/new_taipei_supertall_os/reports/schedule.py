"""Schedule report: task list with ES/EF/LS/LF/float and critical flag
(spec section 33)."""

from __future__ import annotations

import pandas as pd

from new_taipei_supertall_os.construction.schedule import ProjectSchedule


def schedule_report(schedule: ProjectSchedule) -> pd.DataFrame:
    by_id = {r.task_id: r for r in schedule.activity_results}
    rows = []
    for t in schedule.tasks:
        r = by_id.get(t.id)
        rows.append({
            "task_id": t.id, "name": t.name, "phase": t.phase, "duration_days": t.duration_days,
            "es": r.es if r else None, "ef": r.ef if r else None,
            "ls": r.ls if r else None, "lf": r.lf if r else None,
            "total_float": r.total_float if r else None,
            "is_critical": r.is_critical if r else False,
            "is_near_critical": r.is_near_critical if r else False,
        })
    return pd.DataFrame(rows).sort_values("es").reset_index(drop=True)
