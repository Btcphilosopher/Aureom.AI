"""Progress report (spec section 46's per-floor variance, rolled up)."""

from __future__ import annotations

import pandas as pd

from new_taipei_supertall_os.digital_twin.progress import ConstructionDigitalTwin


def progress_report(twin: ConstructionDigitalTwin) -> pd.DataFrame:
    rows = [
        {"floor": r.floor_number, "planned_pct": r.planned_progress_pct,
         "actual_pct": r.actual_progress_pct, "variance_pct": r.variance_pct, "status": r.status}
        for r in twin.all_floor_progress()
    ]
    return pd.DataFrame(rows).sort_values("floor").reset_index(drop=True)


def progress_summary(twin: ConstructionDigitalTwin) -> dict:
    df = progress_report(twin)
    return {
        "overall_progress_pct": twin.overall_progress_pct(),
        "n_floors": len(df),
        "n_behind": int((df["status"] == "behind").sum()) if not df.empty else 0,
        "n_on_track": int((df["status"] == "on_track").sum()) if not df.empty else 0,
    }
