"""Report generators. Each module returns a Pandas DataFrame (or a small
tree of them) plus helpers to export to CSV / Parquet / Excel / JSON
(spec section 65). PDF export uses reportlab where installed."""
