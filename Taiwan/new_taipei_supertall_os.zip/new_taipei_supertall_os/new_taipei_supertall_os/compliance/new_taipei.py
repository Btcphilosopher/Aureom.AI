"""New Taipei City regulatory rule loader and ComplianceTrigger engine
(spec sections 30, 59).

IMPORTANT: this module represents the *kinds* of thresholds New Taipei
City's current review processes use, loaded from versioned, editable YAML
(``regulations/new_taipei/<year>/rules.yaml``). It never decides whether a
project is legally approved — it only raises ``ComplianceTrigger`` flags
for a qualified professional / the competent authority to review. Values
must be reconciled against the official, current regulations before being
relied on for a real project.
"""

from __future__ import annotations

from datetime import date

import yaml
from pydantic import BaseModel

from new_taipei_supertall_os.config.settings import REGULATIONS_DIR, get_settings
from new_taipei_supertall_os.domain.building import Building
from new_taipei_supertall_os.domain.excavation import ExcavationModel
from new_taipei_supertall_os.domain.site import NeighbouringAsset


class RegulationRule(BaseModel):
    id: str
    jurisdiction: str
    effective_date: date
    source: str
    parameter: str
    value: float | bool | str
    applicability: str


class RegulationEngine:
    """Loads a jurisdiction's versioned rule-set for a given year."""

    def __init__(self, jurisdiction: str = "new_taipei", year: str | None = None):
        settings = get_settings()
        self.jurisdiction = jurisdiction
        self.year = year or settings.active_regulatory_year
        self.rules: list[RegulationRule] = self._load()

    def _load(self) -> list[RegulationRule]:
        path = REGULATIONS_DIR / self.jurisdiction / self.year / "rules.yaml"
        if not path.exists():
            return []
        with path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return [RegulationRule(**r) for r in data.get("rules", [])]

    def get(self, parameter: str) -> RegulationRule | None:
        return next((r for r in self.rules if r.parameter == parameter), None)

    def value(self, parameter: str, default: float | bool | str | None = None):
        rule = self.get(parameter)
        return rule.value if rule is not None else default


class ComplianceTrigger(BaseModel):
    trigger_id: str
    name: str
    triggered: bool
    rule_id: str | None
    detail: str
    requires_professional_review: bool = True


class NewTaipeiPlanningRules:
    """Evaluates a building/excavation/site against the loaded rule-set and
    raises ``ComplianceTrigger`` flags. Never an approval decision."""

    def __init__(self, engine: RegulationEngine | None = None):
        self.engine = engine or RegulationEngine()

    def evaluate(
        self,
        building: Building,
        excavation: ExcavationModel | None = None,
        neighbours: list[NeighbouringAsset] | None = None,
        max_structural_span_m: float = 0.0,
        geologically_sensitive: bool = False,
    ) -> list[ComplianceTrigger]:
        neighbours = neighbours or []
        triggers: list[ComplianceTrigger] = []

        def check(param: str, name: str, actual: float, trigger_id: str) -> None:
            rule = self.engine.get(param)
            threshold = rule.value if rule else None
            triggered = threshold is not None and actual > float(threshold)
            triggers.append(ComplianceTrigger(
                trigger_id=trigger_id, name=name, triggered=triggered,
                rule_id=rule.id if rule else None,
                detail=f"actual={actual}, threshold={threshold} ({rule.source if rule else 'no rule loaded'})",
            ))

        check("urban_design_review.site_area_threshold_m2", "Urban design review (site area)",
              building.site_area_m2, "udr-site-area")
        check("urban_design_review.gross_floor_area_threshold_m2", "Urban design review (GFA)",
              building.gross_floor_area_m2, "udr-gfa")
        check("construction_disaster_prevention.height_threshold_m", "Construction disaster prevention (height)",
              building.height_m, "cdp-height")
        check("fire_safety_review.height_threshold_m", "Enhanced fire safety review (height)",
              building.height_m, "fire-height")
        check("traffic_review.gross_floor_area_threshold_m2", "Traffic impact review (GFA)",
              building.gross_floor_area_m2, "traffic-gfa")

        if excavation is not None:
            check("construction_disaster_prevention.excavation_depth_threshold_m",
                  "Major/deep excavation review", excavation.excavation_depth_m, "cdp-excavation-depth")
            check("construction_disaster_prevention.basement_levels_threshold",
                  "Deep excavation review (basement levels)", excavation.basement_levels, "cdp-basement-levels")

        if max_structural_span_m:
            check("construction_disaster_prevention.large_span_threshold_m",
                  "Large structural span review", max_structural_span_m, "cdp-large-span")

        rail_threshold = self.engine.value("construction_disaster_prevention.rail_proximity_threshold_m", 50)
        rail_neighbours = [n for n in neighbours if n.asset_type == "rail_structure" and n.distance_m <= float(rail_threshold)]
        triggers.append(ComplianceTrigger(
            trigger_id="cdp-rail-proximity", name="Rail/metro proximity coordination review",
            triggered=bool(rail_neighbours), rule_id="ntpc-rail-proximity",
            detail=f"{len(rail_neighbours)} rail/metro structure(s) within {rail_threshold}m",
        ))

        geo_rule = self.engine.get("construction_disaster_prevention.geologically_sensitive_flag")
        triggers.append(ComplianceTrigger(
            trigger_id="cdp-geo-sensitive", name="Geologically sensitive area review",
            triggered=geologically_sensitive, rule_id=geo_rule.id if geo_rule else None,
            detail="Flag set from imported site investigation / GIS data" if geologically_sensitive
                   else "Not flagged in current site data",
        ))

        return triggers
