"""Construction-disaster-prevention / site safety flagging
(spec sections 30, 60).

This module never makes a site safety decision. It aggregates
ComplianceTrigger and ExcavationRiskEngine output into a single
"attention required" view for the site safety team and engineers.
"""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.compliance.new_taipei import ComplianceTrigger
from new_taipei_supertall_os.engineering.excavation_model import ExcavationRiskAssessment, RiskLevel


class ConstructionSafetyFlag(BaseModel):
    source: str  # "compliance_trigger" | "excavation_risk"
    name: str
    severity: str
    detail: str
    requires_professional_review: bool = True


class ConstructionSafetyDashboard(BaseModel):
    flags: list[ConstructionSafetyFlag]
    note: str = (
        "Automated flagging only. Never a substitute for the site safety "
        "management plan, the responsible site safety officer, or the "
        "competent authority's own inspection and approval process."
    )


def build_construction_safety_dashboard(
    triggers: list[ComplianceTrigger],
    excavation_risk: ExcavationRiskAssessment | None = None,
) -> ConstructionSafetyDashboard:
    flags: list[ConstructionSafetyFlag] = []
    for t in triggers:
        if t.triggered:
            flags.append(ConstructionSafetyFlag(
                source="compliance_trigger", name=t.name, severity="ATTENTION_REQUIRED",
                detail=t.detail, requires_professional_review=t.requires_professional_review,
            ))
    if excavation_risk is not None:
        for factor in excavation_risk.factors:
            if factor.level in (RiskLevel.HIGH, RiskLevel.CRITICAL):
                flags.append(ConstructionSafetyFlag(
                    source="excavation_risk", name=factor.name, severity=factor.level.value,
                    detail=factor.detail,
                ))
    return ConstructionSafetyDashboard(flags=flags)
