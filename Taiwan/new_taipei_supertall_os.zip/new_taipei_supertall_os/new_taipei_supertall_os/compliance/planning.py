"""Urban design review engine (spec section 31)."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.compliance.new_taipei import RegulationEngine


class UrbanDesignReviewAssessment(BaseModel):
    review_required: bool
    potential_review_path: str
    triggered_conditions: list[str]
    documents_required: list[str]


class UrbanDesignReviewEngine:
    def __init__(self, engine: RegulationEngine | None = None):
        self.engine = engine or RegulationEngine()

    def assess(
        self,
        site_area_m2: float,
        gross_floor_area_m2: float,
        height_m: float,
        land_use: str = "mixed_use",
        location: str = "",
    ) -> UrbanDesignReviewAssessment:
        site_threshold = float(self.engine.value("urban_design_review.site_area_threshold_m2", 6000))
        gfa_threshold = float(self.engine.value("urban_design_review.gross_floor_area_threshold_m2", 30000))
        height_threshold = float(self.engine.value("construction_disaster_prevention.height_threshold_m", 50))

        conditions = []
        if site_area_m2 > site_threshold:
            conditions.append(f"site_area_m2 ({site_area_m2}) exceeds threshold ({site_threshold})")
        if gross_floor_area_m2 > gfa_threshold:
            conditions.append(f"gross_floor_area_m2 ({gross_floor_area_m2}) exceeds threshold ({gfa_threshold})")
        if height_m > height_threshold:
            conditions.append(f"height_m ({height_m}) exceeds construction-disaster-prevention height threshold ({height_threshold})")

        review_required = site_area_m2 > site_threshold and gross_floor_area_m2 > gfa_threshold

        if review_required:
            path = ("Formal urban design review pathway (illustrative): pre-application consultation -> "
                    "urban design review committee submission -> conditional approval -> building permit application.")
        else:
            path = ("Standard building-permit pathway (illustrative) — urban design review thresholds not met; "
                    "confirm with the competent authority as other triggers may still apply.")

        documents = [
            "Site survey / land title documents",
            "Massing and shadow/wind impact study",
            "Traffic impact assessment" if gross_floor_area_m2 > 20000 else None,
            "Geotechnical site investigation report",
            "Preliminary structural system report",
            "Construction disaster prevention plan" if height_m > height_threshold else None,
            "Environmental impact statement or exemption" if site_area_m2 > 10000 else None,
        ]
        documents = [d for d in documents if d]

        return UrbanDesignReviewAssessment(
            review_required=review_required, potential_review_path=path,
            triggered_conditions=conditions, documents_required=documents,
        )
