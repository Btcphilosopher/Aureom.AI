"""Compliance dashboard (spec section 60).

Statuses here are workflow-tracking states set by the project team — this
software NEVER equates a status here with actual government approval.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field

from new_taipei_supertall_os.compliance.new_taipei import ComplianceTrigger


class ReviewCategory(str, Enum):
    URBAN_DESIGN_REVIEW = "urban_design_review"
    BUILDING_PERMIT = "building_permit"
    STRUCTURAL_REVIEW = "structural_review"
    GEOTECHNICAL_REVIEW = "geotechnical_review"
    CONSTRUCTION_DISASTER_PREVENTION = "construction_disaster_prevention"
    ENVIRONMENTAL_REVIEW = "environmental_review"
    TRAFFIC_REVIEW = "traffic_review"
    FIRE_SAFETY_REVIEW = "fire_safety_review"


class ReviewStatus(str, Enum):
    NOT_STARTED = "NOT_STARTED"
    IN_PROGRESS = "IN_PROGRESS"
    REQUIRES_DOCUMENT_REVIEW = "REQUIRES_DOCUMENT_REVIEW"
    APPROVED = "APPROVED"


class ReviewItem(BaseModel):
    category: ReviewCategory
    status: ReviewStatus = ReviewStatus.NOT_STARTED
    triggered: bool = False
    notes: str = ""


class ComplianceDashboard(BaseModel):
    project_id: str
    items: list[ReviewItem] = Field(default_factory=list)
    disclaimer: str = (
        "This dashboard reflects the project team's own workflow tracking. "
        "It is NOT a record of, and does not imply, actual approval by New "
        "Taipei City Government or any other competent authority. Only the "
        "relevant government agency can confirm real regulatory status."
    )

    def by_category(self) -> dict[str, str]:
        return {i.category.value: i.status.value for i in self.items}


TRIGGER_TO_CATEGORY: dict[str, ReviewCategory] = {
    "udr-site-area": ReviewCategory.URBAN_DESIGN_REVIEW,
    "udr-gfa": ReviewCategory.URBAN_DESIGN_REVIEW,
    "cdp-height": ReviewCategory.CONSTRUCTION_DISASTER_PREVENTION,
    "cdp-excavation-depth": ReviewCategory.CONSTRUCTION_DISASTER_PREVENTION,
    "cdp-basement-levels": ReviewCategory.CONSTRUCTION_DISASTER_PREVENTION,
    "cdp-large-span": ReviewCategory.STRUCTURAL_REVIEW,
    "cdp-rail-proximity": ReviewCategory.CONSTRUCTION_DISASTER_PREVENTION,
    "cdp-geo-sensitive": ReviewCategory.GEOTECHNICAL_REVIEW,
    "fire-height": ReviewCategory.FIRE_SAFETY_REVIEW,
    "traffic-gfa": ReviewCategory.TRAFFIC_REVIEW,
}


def build_compliance_dashboard(project_id: str, triggers: list[ComplianceTrigger]) -> ComplianceDashboard:
    """Seeds every review category NOT_STARTED, then bumps any category
    with a triggered condition to REQUIRES_DOCUMENT_REVIEW. Building
    permit and environmental review are always tracked (not driven by a
    single threshold) and default to NOT_STARTED for the team to update."""
    items = {cat: ReviewItem(category=cat) for cat in ReviewCategory}
    for t in triggers:
        cat = TRIGGER_TO_CATEGORY.get(t.trigger_id)
        if cat is None:
            continue
        if t.triggered:
            items[cat].triggered = True
            if items[cat].status == ReviewStatus.NOT_STARTED:
                items[cat].status = ReviewStatus.REQUIRES_DOCUMENT_REVIEW
            items[cat].notes = (items[cat].notes + "; " if items[cat].notes else "") + t.detail
    return ComplianceDashboard(project_id=project_id, items=list(items.values()))
