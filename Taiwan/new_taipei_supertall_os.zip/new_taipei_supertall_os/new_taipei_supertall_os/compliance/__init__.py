"""New Taipei City regulatory configuration and compliance-trigger flagging.

Nothing in this package decides whether a project is legally approved or
compliant. It loads versioned, configurable RegulationRule records and
flags ComplianceTrigger conditions for professional/regulatory review.
See ``domain.calculation.PRELIMINARY_ENGINEERING_NOTICE`` and the module
docstrings below for the full disclaimer.
"""
