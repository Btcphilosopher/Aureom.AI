"""Optimisation endpoint: PLAN A-E multi-objective comparison
(spec sections 52, 56)."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from new_taipei_supertall_os.api.service import ProjectService, get_project_service

router = APIRouter(tags=["optimisation"])


@router.get("/api/optimisation")
def get_optimisation(svc: ProjectService = Depends(get_project_service)):
    from new_taipei_supertall_os.optimisation.multiobjective import SupertallOptimizer
    optimizer = SupertallOptimizer(svc.settings)
    plans = optimizer.generate_plans(svc.building)
    dominant = optimizer.dominant_plan(plans)
    return {
        "plans": [p.model_dump(mode="json") for p in plans],
        "dominant_plan": dominant.label.value,
    }
