"""Construction/structure/foundation/excavation/logistics/cost/risk/weather
/compliance endpoints (spec section 56)."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from new_taipei_supertall_os.api.service import ProjectService, get_project_service
from new_taipei_supertall_os.reports.cost import cost_breakdown_report, cost_summary
from new_taipei_supertall_os.reports.risk import risk_report
from new_taipei_supertall_os.reports.schedule import schedule_report

router = APIRouter(tags=["construction"])


@router.get("/api/structure")
def get_structure(svc: ProjectService = Depends(get_project_service)):
    demand = svc.structural_demand()
    return demand.model_dump(mode="json")


@router.get("/api/foundation")
def get_foundation(svc: ProjectService = Depends(get_project_service)):
    demand = svc.foundation_demand()
    return {
        "foundation": svc.foundation().model_dump(mode="json"),
        "demand": demand.model_dump(mode="json"),
    }


@router.get("/api/excavation")
def get_excavation(svc: ProjectService = Depends(get_project_service)):
    risk = svc.excavation_risk()
    return {
        "excavation": svc.excavation().model_dump(mode="json"),
        "risk": risk.model_dump(mode="json"),
    }


@router.get("/api/cranes")
def get_cranes(svc: ProjectService = Depends(get_project_service)):
    return svc.crane_recommendation().model_dump(mode="json")


@router.get("/api/hoists")
def get_hoists(svc: ProjectService = Depends(get_project_service)):
    from new_taipei_supertall_os.construction.vertical_transport import ConstructionHoistPlan
    from new_taipei_supertall_os.domain.hoist import ConstructionHoist
    hoists = [ConstructionHoist(id=f"hoist-{i+1}") for i in range(6)]
    plan = ConstructionHoistPlan(hoists=hoists)
    return {
        "hoists": [h.model_dump(mode="json") for h in hoists],
        "peak_workforce_supportable": plan.peak_workforce_supportable(svc.building.height_m),
    }


@router.get("/api/workforce")
def get_workforce(svc: ProjectService = Depends(get_project_service)):
    from new_taipei_supertall_os.optimisation.workforce import WorkforceOptimizer
    from new_taipei_supertall_os.domain.worker import Trade
    wo = WorkforceOptimizer(svc.settings)
    return [wo.plan_crew(t, target_worker_hours_per_day=320).model_dump(mode="json") for t in Trade]


@router.get("/api/materials")
def get_materials(svc: ProjectService = Depends(get_project_service)):
    from new_taipei_supertall_os.construction.steel import SteelConstructionEngine
    se = SteelConstructionEngine()
    from new_taipei_supertall_os.domain.structural import StructuralSystemType
    system = StructuralSystemType(svc.building.structural_system)
    return {
        "steel_tonnage": se.building_steel_tonnage(svc.above_grade_floors(), system),
        "carbon": svc.carbon().model_dump(mode="json"),
    }


@router.get("/api/schedule")
def get_schedule(svc: ProjectService = Depends(get_project_service)):
    df = schedule_report(svc.schedule())
    return {
        "duration_days": svc.schedule().duration_days,
        "critical_path": svc.schedule().critical_path,
        "tasks": df.to_dict(orient="records"),
    }


@router.get("/api/cost")
def get_cost(svc: ProjectService = Depends(get_project_service)):
    estimate = svc.cost()
    return {
        "total_twd": estimate.total_twd,
        "summary": cost_summary(estimate, svc.building.gross_floor_area_m2, svc.building.floors),
        "breakdown": cost_breakdown_report(estimate).to_dict(orient="records"),
    }


@router.get("/api/risk")
def get_risk(svc: ProjectService = Depends(get_project_service)):
    return risk_report(svc.risks()).to_dict(orient="records")


@router.get("/api/weather")
def get_weather(svc: ProjectService = Depends(get_project_service)):
    engine = svc.weather_engine()
    upcoming = [engine.daily_event(i).value for i in range(14)]
    return {"typhoon_season_months": svc.settings.site.typhoon_season_months, "next_14_days_forecast": upcoming}


@router.get("/api/compliance")
def get_compliance(svc: ProjectService = Depends(get_project_service)):
    dashboard = svc.compliance_dashboard()
    return {
        "dashboard": dashboard.model_dump(mode="json"),
        "urban_design_review": svc.urban_design_review().model_dump(mode="json"),
        "triggers": [t.model_dump(mode="json") for t in svc.compliance_triggers()],
    }
