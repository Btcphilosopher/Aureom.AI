"""FastAPI application: REST endpoints (spec section 56) and WebSocket
digital-twin/telemetry streams. See ``api.app.create_app``."""
