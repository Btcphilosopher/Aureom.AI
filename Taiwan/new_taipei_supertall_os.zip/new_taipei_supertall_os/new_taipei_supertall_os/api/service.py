"""In-process project service: builds and caches the demonstration
project's computed views (schedule, cost, simulation, optimisation,
compliance, digital twin) for the API layer to serve.

A real deployment would back this with the ``database`` layer / a
per-project cache; this keeps the API runnable standalone with the
NT-SUPERTALL-001 demonstration project.
"""

from __future__ import annotations

from functools import lru_cache

from new_taipei_supertall_os.compliance.approvals import ComplianceDashboard, build_compliance_dashboard
from new_taipei_supertall_os.compliance.new_taipei import NewTaipeiPlanningRules
from new_taipei_supertall_os.compliance.planning import UrbanDesignReviewEngine
from new_taipei_supertall_os.config.settings import get_settings
from new_taipei_supertall_os.construction.concrete import ConcreteEngine
from new_taipei_supertall_os.construction.risk import ConstructionRiskEngine
from new_taipei_supertall_os.construction.sequencing import build_demo_schedule
from new_taipei_supertall_os.construction.schedule import CriticalPathEngine, ProjectSchedule
from new_taipei_supertall_os.construction.steel import SteelConstructionEngine
from new_taipei_supertall_os.digital_twin.progress import ConstructionDigitalTwin
from new_taipei_supertall_os.domain.building import Building, MassingEngine, MassingProfile
from new_taipei_supertall_os.domain.excavation import ExcavationModel
from new_taipei_supertall_os.domain.foundation import FoundationModel
from new_taipei_supertall_os.domain.site import NeighbouringAsset
from new_taipei_supertall_os.domain.structural import CoreSystem, StructuralFrame, StructuralSystemType
from new_taipei_supertall_os.engineering.excavation_model import ExcavationRiskEngine
from new_taipei_supertall_os.engineering.foundation_model import preliminary_foundation_demand
from new_taipei_supertall_os.engineering.geotechnical import SiteInvestigation
from new_taipei_supertall_os.engineering.structural_model import preliminary_structural_demand
from new_taipei_supertall_os.engineering.wind import WindModel
from new_taipei_supertall_os.finance.carbon import ConstructionCarbonEngine
from new_taipei_supertall_os.finance.cost import ConstructionCostEngine, CostEstimate
from new_taipei_supertall_os.logistics.site_logistics import SiteLogisticsEngine
from new_taipei_supertall_os.optimisation.cranes import CraneOptimizer
from new_taipei_supertall_os.optimisation.multiobjective import SupertallOptimizer
from new_taipei_supertall_os.simulation.engine import ConstructionSimulation
from new_taipei_supertall_os.simulation.weather import WeatherConstructionEngine


def demo_building() -> Building:
    return Building(
        id="NT-SUPERTALL-001", name="New Taipei Demonstration Tower", city="New Taipei City",
        height_m=420, floors=92, basement_floors=6, gross_floor_area_m2=250000, site_area_m2=18000,
        structural_system="composite_frame", foundation_type="piled_raft",
        use_mix={"commercial": 0.25, "office": 0.40, "residential": 0.25, "hotel": 0.10},
    )


class ProjectService:
    def __init__(self, building: Building | None = None):
        self.settings = get_settings()
        self.building = building or demo_building()
        self._massing: MassingProfile | None = None
        self._schedule: ProjectSchedule | None = None
        self._cost: CostEstimate | None = None
        self._compliance: ComplianceDashboard | None = None

    def massing(self) -> MassingProfile:
        if self._massing is None:
            self._massing = MassingEngine().generate(self.building)
        return self._massing

    def floors(self):
        return self.massing().floors

    def above_grade_floors(self):
        return [f for f in self.floors() if f.number > 0]

    def frame(self) -> StructuralFrame:
        core = CoreSystem(core_width_m=35, core_depth_m=45, elevator_count=48, stair_count=4)
        return StructuralFrame(system_type=StructuralSystemType(self.building.structural_system), core=core)

    def wind_model(self) -> WindModel:
        s = self.settings.site
        return WindModel(building_height_m=self.building.height_m, building_width_m=55, building_depth_m=55,
                          wind_speed_m_s=s.basic_wind_speed_ms)

    def structural_demand(self):
        return preliminary_structural_demand(self.building, self.floors(), self.frame(), self.wind_model(),
                                              seismic_zone_factor=self.settings.site.seismic_zone_factor,
                                              site_class=self.settings.site.site_class)

    def foundation(self) -> FoundationModel:
        return FoundationModel(pile_count=260, pile_capacity_kn=18000, pile_length_m=60, pile_diameter_m=1.5)

    def site_investigation(self) -> SiteInvestigation:
        return SiteInvestigation.placeholder(self.building.id)

    def foundation_demand(self):
        demand = self.structural_demand()
        return preliminary_foundation_demand(self.foundation(), demand.gravity_reaction.value, self.site_investigation())

    def excavation(self) -> ExcavationModel:
        return ExcavationModel(excavation_depth_m=32, excavation_area_m2=self.building.site_area_m2 * 0.85,
                                basement_levels=self.building.basement_floors)

    def neighbours(self) -> list[NeighbouringAsset]:
        return [
            NeighbouringAsset(id="n1", name="Adjacent MRT viaduct", distance_m=18, sensitivity="critical",
                               asset_type="rail_structure", monitoring_required=True),
            NeighbouringAsset(id="n2", name="Neighbouring commercial tower", distance_m=25, sensitivity="high",
                               asset_type="building", monitoring_required=True),
        ]

    def excavation_risk(self):
        return ExcavationRiskEngine().assess(self.excavation(), self.neighbours(), observed_lateral_movement_mm=8)

    def schedule(self) -> ProjectSchedule:
        if self._schedule is None:
            sched = build_demo_schedule(self.building)
            CriticalPathEngine().run(sched)
            self._schedule = sched
        return self._schedule

    def cost(self) -> CostEstimate:
        if self._cost is None:
            ce = ConcreteEngine()
            system = StructuralSystemType(self.building.structural_system)
            pours = [ce.plan_pour(f, "slab", ce.floor_slab_volume_m3(f) * system.relative_concrete_m3_per_m2 / 0.55)
                     for f in self.above_grade_floors()]
            self._cost = ConstructionCostEngine(self.settings).estimate(self.building, self.floors(), pours,
                                                                          elevator_count=self.frame().core.elevator_count)
        return self._cost

    def carbon(self):
        ce = ConcreteEngine()
        system = StructuralSystemType(self.building.structural_system)
        pours = [ce.plan_pour(f, "slab", ce.floor_slab_volume_m3(f) * system.relative_concrete_m3_per_m2 / 0.55)
                 for f in self.above_grade_floors()]
        se = SteelConstructionEngine()
        tonnes = se.building_steel_tonnage(self.above_grade_floors(), system)
        return ConstructionCarbonEngine(self.settings).estimate(self.building, self.floors(), pours, steel_tonnes=tonnes)

    def risks(self):
        return ConstructionRiskEngine().demo_risk_register()

    def compliance_triggers(self):
        return NewTaipeiPlanningRules().evaluate(self.building, self.excavation(), self.neighbours(),
                                                   max_structural_span_m=18)

    def compliance_dashboard(self) -> ComplianceDashboard:
        if self._compliance is None:
            self._compliance = build_compliance_dashboard(self.building.id, self.compliance_triggers())
        return self._compliance

    def urban_design_review(self):
        return UrbanDesignReviewEngine().assess(self.building.site_area_m2, self.building.gross_floor_area_m2,
                                                  self.building.height_m)

    def weather_engine(self) -> WeatherConstructionEngine:
        return WeatherConstructionEngine(typhoon_season_months=self.settings.site.typhoon_season_months)

    def simulation(self, days: float | None = None, speed: int = 10, n_trials: int = 20):
        target = days or self.schedule().duration_days
        sim = ConstructionSimulation(self.building, weather_engine=self.weather_engine())
        return sim.run(days=target, speed=speed, n_trials=n_trials)

    def crane_recommendation(self):
        candidates = CraneOptimizer.default_candidates(self.building)
        return CraneOptimizer().optimize(self.building, candidates, total_daily_lift_demand_hours=32)

    def optimisation_plans(self):
        return SupertallOptimizer(self.settings).generate_plans(self.building)

    def digital_twin(self) -> ConstructionDigitalTwin:
        twin = ConstructionDigitalTwin(project_id=self.building.id)
        twin.load_floors(self.floors())
        return twin

    def site_logistics(self) -> SiteLogisticsEngine:
        site = SiteLogisticsEngine.demo_site(self.building.site_area_m2)
        return SiteLogisticsEngine(site)


@lru_cache(maxsize=1)
def get_project_service() -> ProjectService:
    return ProjectService()
