"""WebSocket streams: /ws/project, /ws/construction, /ws/logistics,
/ws/digital-twin (spec section 56)."""

from __future__ import annotations

import asyncio
import random
from datetime import datetime, timezone

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from new_taipei_supertall_os.api.service import get_project_service
from new_taipei_supertall_os.digital_twin.state import DigitalTwinState, EntityType, SiteEntity

router = APIRouter(tags=["websocket"])


async def _stream(websocket: WebSocket, payload_fn, interval_s: float = 3.0) -> None:
    await websocket.accept()
    try:
        while True:
            await websocket.send_json(payload_fn())
            await asyncio.sleep(interval_s)
    except WebSocketDisconnect:
        return


@router.websocket("/ws/project")
async def ws_project(websocket: WebSocket):
    svc = get_project_service()

    def payload():
        return {
            "type": "project_snapshot", "timestamp": datetime.now(timezone.utc).isoformat(),
            "building_id": svc.building.id, "schedule_duration_days": svc.schedule().duration_days,
            "overall_progress_pct": svc.digital_twin().overall_progress_pct(),
        }

    await _stream(websocket, payload)


@router.websocket("/ws/construction")
async def ws_construction(websocket: WebSocket):
    svc = get_project_service()

    def payload():
        crit = svc.schedule().critical_path
        return {
            "type": "construction_update", "timestamp": datetime.now(timezone.utc).isoformat(),
            "critical_path_length": len(crit), "duration_days": svc.schedule().duration_days,
        }

    await _stream(websocket, payload)


@router.websocket("/ws/logistics")
async def ws_logistics(websocket: WebSocket):
    svc = get_project_service()

    def payload():
        return {
            "type": "logistics_update", "timestamp": datetime.now(timezone.utc).isoformat(),
            "site_nodes": len(svc.site_logistics().site.nodes),
            "simulated_truck_queue_estimate": random.randint(0, 4),
        }

    await _stream(websocket, payload)


@router.websocket("/ws/digital-twin")
async def ws_digital_twin(websocket: WebSocket):
    svc = get_project_service()
    state = DigitalTwinState(project_id=svc.building.id)
    for i in range(4):
        state.upsert(SiteEntity(id=f"crane-{i+1}", entity_type=EntityType.CRANE, status="active",
                                 task="lift" if i % 2 == 0 else "idle"))

    def payload():
        state.as_of = datetime.now(timezone.utc)
        return state.snapshot()

    await _stream(websocket, payload)
