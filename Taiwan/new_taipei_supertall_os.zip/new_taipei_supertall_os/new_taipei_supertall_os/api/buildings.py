"""Building/project/floor endpoints (spec section 56)."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from new_taipei_supertall_os.api.service import ProjectService, get_project_service

router = APIRouter(tags=["buildings"])


@router.get("/api/project")
def get_project(svc: ProjectService = Depends(get_project_service)):
    return {
        "building": svc.building.model_dump(mode="json"),
        "label": svc.building.label(),
        "is_supertall": svc.building.is_supertall,
        "floor_area_ratio": svc.building.floor_area_ratio,
    }


@router.get("/api/building")
def get_building(svc: ProjectService = Depends(get_project_service)):
    return svc.building.model_dump(mode="json")


@router.get("/api/floors")
def get_floors(svc: ProjectService = Depends(get_project_service)):
    return [f.model_dump(mode="json") for f in svc.floors()]
