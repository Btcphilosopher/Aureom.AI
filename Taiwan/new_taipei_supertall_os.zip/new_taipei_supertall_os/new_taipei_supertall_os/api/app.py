"""FastAPI application factory.

Run with:
    uvicorn new_taipei_supertall_os.api.app:app --reload
"""

from __future__ import annotations

from fastapi import FastAPI

from new_taipei_supertall_os.api import buildings, construction, optimisation, simulation, websocket

DISCLAIMER = (
    "NEW TAIPEI SUPERTALL CONSTRUCTION OS is a planning, simulation, optimisation, "
    "cost and digital-twin platform. It is NOT a replacement for licensed architects, "
    "structural/geotechnical/construction/fire engineers, building authorities, certified "
    "structural-analysis software, statutory approval, or site safety management. All "
    "structural calculations are PRELIMINARY ENGINEERING ESTIMATES requiring independent "
    "verification by qualified professionals. SIMULATION ONLY / 模擬專案."
)


def create_app() -> FastAPI:
    app = FastAPI(
        title="New Taipei Supertall Construction OS",
        description=DISCLAIMER,
        version="0.1.0",
    )

    @app.get("/")
    def root():
        return {"service": "new-taipei-supertall-construction-os", "disclaimer": DISCLAIMER}

    @app.get("/health")
    def health():
        return {"status": "ok"}

    app.include_router(buildings.router)
    app.include_router(construction.router)
    app.include_router(simulation.router)
    app.include_router(optimisation.router)
    app.include_router(websocket.router)
    return app


app = create_app()
