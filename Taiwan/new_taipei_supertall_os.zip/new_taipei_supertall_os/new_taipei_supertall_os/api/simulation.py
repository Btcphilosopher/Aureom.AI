"""Simulation endpoint (spec section 56)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from new_taipei_supertall_os.api.service import ProjectService, get_project_service

router = APIRouter(tags=["simulation"])


@router.get("/api/simulation")
def get_simulation(
    days: float | None = Query(default=None, description="Target completion day; defaults to the CPM schedule duration"),
    n_trials: int = Query(default=20, ge=1, le=200),
    svc: ProjectService = Depends(get_project_service),
):
    result = svc.simulation(days=days, n_trials=n_trials)
    return result.model_dump(mode="json")
