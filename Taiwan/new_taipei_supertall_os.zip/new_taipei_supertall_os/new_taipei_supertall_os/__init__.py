"""NEW TAIPEI SUPERTALL CONSTRUCTION OS

新北超高層建築智慧施工作業系統

A planning, simulation, optimisation, cost and digital-twin platform for
supertall/high-rise construction in New Taipei City, Taiwan.

This is engineering- and construction-management SOFTWARE. It is NOT a
replacement for licensed architects, structural/geotechnical/construction/
fire engineers, building authorities, certified structural-analysis
software, statutory approval, or site safety management. All structural
calculations that could affect life safety are labelled PRELIMINARY
ENGINEERING ESTIMATES and must be independently verified by qualified
professionals. SIMULATION ONLY / 模擬專案.
"""

__version__ = "0.1.0"
