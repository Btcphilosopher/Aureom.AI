"""Cost optimiser: compares structural-system / foundation-type
alternatives on total cost, holding other assumptions constant
(spec section 35, feeding the "cheapest" plan in the multi-objective
optimiser)."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.config.settings import Settings
from new_taipei_supertall_os.construction.concrete import ConcreteEngine
from new_taipei_supertall_os.domain.building import Building, MassingEngine
from new_taipei_supertall_os.domain.structural import StructuralSystemType
from new_taipei_supertall_os.finance.cost import ConstructionCostEngine, CostEstimate


class StructuralSystemOption(BaseModel):
    system_type: StructuralSystemType
    total_cost_twd: float
    relative_to_baseline_pct: float


class CostOptimizer:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.cost_engine = ConstructionCostEngine(settings)

    def _estimate_for_system(self, building: Building, system: StructuralSystemType) -> CostEstimate:
        b2 = building.model_copy(update={"structural_system": system.value})
        profile = MassingEngine().generate(b2)
        floors = [f for f in profile.floors if f.number > 0]
        ce = ConcreteEngine()
        pours = [ce.plan_pour(f, "slab", ce.floor_slab_volume_m3(f) * system.relative_concrete_m3_per_m2 / 0.55)
                 for f in floors]
        return self.cost_engine.estimate(b2, profile.floors, pours)

    def compare_structural_systems(self, building: Building, candidates: list[StructuralSystemType] | None = None) -> list[StructuralSystemOption]:
        candidates = candidates or list(StructuralSystemType)
        estimates = {c: self._estimate_for_system(building, c) for c in candidates}
        baseline = min(e.total_twd for e in estimates.values())
        return sorted(
            [StructuralSystemOption(system_type=c, total_cost_twd=e.total_twd,
                                     relative_to_baseline_pct=round((e.total_twd / baseline - 1) * 100, 1))
             for c, e in estimates.items()],
            key=lambda o: o.total_cost_twd,
        )

    def cheapest_system(self, building: Building) -> StructuralSystemOption:
        return self.compare_structural_systems(building)[0]
