"""Site logistics optimiser: chooses truck-arrival dispatch windows that
minimise peak queue length / gate congestion (spec sections 20, 28, 29)."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.logistics.trucks import TruckJob, TruckRoutingEngine


class DispatchPlan(BaseModel):
    jobs: list[TruckJob]
    peak_queue_length: int
    average_wait_min: float


class LogisticsOptimizer:
    """Greedy re-spacing heuristic: spread a day's truck jobs evenly across
    the working window per gate, respecting a minimum headway, to minimise
    peak queue length. (A full MILP dispatch optimiser is a natural
    OR-Tools extension; this keeps the default fast and deterministic.)"""

    def __init__(self, working_hours: tuple[float, float] = (7.0, 19.0), min_headway_min: float = 8.0):
        self.working_hours = working_hours
        self.min_headway_min = min_headway_min

    def optimize(self, jobs: list[TruckJob]) -> DispatchPlan:
        by_gate: dict[str, list[TruckJob]] = {}
        for j in jobs:
            by_gate.setdefault(j.gate, []).append(j)

        respaced: list[TruckJob] = []
        headway_h = self.min_headway_min / 60.0
        for gate, gate_jobs in by_gate.items():
            gate_jobs_sorted = sorted(gate_jobs, key=lambda j: j.scheduled_arrival_hour)
            t = max(self.working_hours[0], gate_jobs_sorted[0].scheduled_arrival_hour) if gate_jobs_sorted else self.working_hours[0]
            for j in gate_jobs_sorted:
                new_time = max(t, j.scheduled_arrival_hour)
                respaced.append(j.model_copy(update={"scheduled_arrival_hour": round(new_time, 2)}))
                t = new_time + headway_h

        engine = TruckRoutingEngine(gates=list(by_gate.keys()) or ["gate-1"])
        events = engine.simulate(respaced)
        return DispatchPlan(
            jobs=respaced,
            peak_queue_length=engine.peak_queue_length(events),
            average_wait_min=engine.average_queue_wait_min(events),
        )
