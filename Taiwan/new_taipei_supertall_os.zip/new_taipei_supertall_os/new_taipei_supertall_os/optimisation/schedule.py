"""Schedule optimiser (spec section 34): OR-Tools CP-SAT based
time/cost trade-off (crashing) on top of the dependency-graph schedule
built by ``construction.sequencing``.

The model: each task can optionally be "crashed" (extra crew/overtime),
shortening its duration by a configurable fraction at a configurable cost
premium. CP-SAT chooses which tasks to crash to minimise a weighted
objective of project duration and crashing cost, subject to precedence
constraints.
"""

from __future__ import annotations

from ortools.sat.python import cp_model
from pydantic import BaseModel, Field

from new_taipei_supertall_os.construction.schedule import CriticalPathEngine, ProjectSchedule, Task
from new_taipei_supertall_os.construction.sequencing import CoreFrameStrategy, build_demo_schedule
from new_taipei_supertall_os.domain.building import Building
from new_taipei_supertall_os.domain.calculation import VersionInfo


class CrashDecision(BaseModel):
    task_id: str
    crashed: bool
    normal_duration_days: float
    optimised_duration_days: float
    extra_cost_twd: float


class ScheduleOptimizationResult(BaseModel):
    schedule: ProjectSchedule
    crash_decisions: list[CrashDecision]
    total_extra_cost_twd: float
    solver_status: str
    version_info: VersionInfo = Field(default_factory=VersionInfo)


class ScheduleOptimizer:
    """Objectives (spec 34): minimum duration, minimum cost, minimum risk,
    minimum resource conflict — implemented here as a configurable weighted
    duration-vs-cost CP-SAT crashing model. Set ``duration_weight`` /
    ``cost_weight`` to bias toward Plan A (fastest) vs Plan B (cheapest);
    see ``optimisation.multiobjective`` for the full multi-plan sweep.
    """

    def __init__(
        self,
        crash_fraction: float = 0.2,
        crashable_phases: tuple[str, ...] = ("tower_structure", "core", "facade", "mep", "excavation", "foundation"),
        cost_per_day_saved_twd: float = 6_000_000.0,
        duration_weight: float = 1.0,
        cost_weight: float = 0.0000006,
        time_limit_s: float = 8.0,
    ):
        self.crash_fraction = crash_fraction
        self.crashable_phases = set(crashable_phases)
        self.cost_per_day_saved_twd = cost_per_day_saved_twd
        self.duration_weight = duration_weight
        self.cost_weight = cost_weight
        self.time_limit_s = time_limit_s

    def optimize(
        self,
        building: Building,
        schedule: ProjectSchedule | None = None,
        strategy: CoreFrameStrategy = CoreFrameStrategy.CORE_FIRST,
    ) -> ProjectSchedule:
        schedule = schedule or build_demo_schedule(building, strategy=strategy)
        result = self.optimize_schedule(schedule)
        return result.schedule

    def optimize_schedule(self, schedule: ProjectSchedule) -> ScheduleOptimizationResult:
        graph = schedule.to_graph()
        tasks_by_id = {t.id: t for t in schedule.tasks}
        # baseline horizon for interval domains
        cpm = CriticalPathEngine()
        baseline = cpm.run(schedule.model_copy(deep=True))
        horizon = int(baseline.duration_days * 1.05) + 10

        model = cp_model.CpModel()
        starts, ends, intervals, crash_vars = {}, {}, {}, {}

        int_scale = 100  # represent day fractions to 0.01 precision as integers

        for t in schedule.tasks:
            normal_dur = max(int(round(t.duration_days * int_scale)), 1)
            crashable = t.phase in self.crashable_phases
            if crashable:
                crash_var = model.NewBoolVar(f"crash_{t.id}")
                crashed_dur = max(int(round(t.duration_days * (1 - self.crash_fraction) * int_scale)), 1)
                dur = model.NewIntVar(crashed_dur, normal_dur, f"dur_{t.id}")
                model.Add(dur == normal_dur).OnlyEnforceIf(crash_var.Not())
                model.Add(dur == crashed_dur).OnlyEnforceIf(crash_var)
                crash_vars[t.id] = crash_var
            else:
                dur = model.NewConstant(normal_dur)

            start = model.NewIntVar(0, horizon * int_scale, f"start_{t.id}")
            end = model.NewIntVar(0, horizon * int_scale, f"end_{t.id}")
            interval = model.NewIntervalVar(start, dur, end, f"interval_{t.id}")
            starts[t.id], ends[t.id], intervals[t.id] = start, end, interval

        for t in schedule.tasks:
            for p in t.predecessors:
                model.Add(starts[t.id] >= ends[p])

        makespan = model.NewIntVar(0, horizon * int_scale, "makespan")
        model.AddMaxEquality(makespan, list(ends.values()))

        total_crash_cost = model.NewIntVar(0, 10_000_000_000, "total_crash_cost")
        crash_cost_terms = []
        for t in schedule.tasks:
            if t.id in crash_vars:
                days_saved = t.duration_days * self.crash_fraction
                cost = int(round(days_saved * self.cost_per_day_saved_twd))
                crash_cost_terms.append(crash_vars[t.id] * cost)
        if crash_cost_terms:
            model.Add(total_crash_cost == sum(crash_cost_terms))
        else:
            model.Add(total_crash_cost == 0)

        # weighted objective: minimise duration_weight*makespan + cost_weight*cost
        # scale to integers by multiplying weights
        w_dur = max(int(self.duration_weight * 1000), 1)
        w_cost = max(int(self.cost_weight * 1000), 0)
        model.Minimize(w_dur * makespan + w_cost * total_crash_cost)

        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = self.time_limit_s
        solver.parameters.num_search_workers = 8
        status = solver.Solve(model)

        status_name = solver.StatusName(status)
        crash_decisions = []
        total_extra = 0.0
        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            for t in schedule.tasks:
                crashed = t.id in crash_vars and solver.Value(crash_vars[t.id]) == 1
                new_dur = t.duration_days * (1 - self.crash_fraction) if crashed else t.duration_days
                extra_cost = t.duration_days * self.crash_fraction * self.cost_per_day_saved_twd if crashed else 0.0
                total_extra += extra_cost
                crash_decisions.append(CrashDecision(
                    task_id=t.id, crashed=crashed, normal_duration_days=t.duration_days,
                    optimised_duration_days=round(new_dur, 2), extra_cost_twd=round(extra_cost, 0),
                ))
                t.duration_days = round(new_dur, 2)
                t.cost_twd += extra_cost
        else:
            crash_decisions = [CrashDecision(task_id=t.id, crashed=False, normal_duration_days=t.duration_days,
                                              optimised_duration_days=t.duration_days, extra_cost_twd=0.0)
                                for t in schedule.tasks]

        cpm.run(schedule)  # recompute ES/EF/LS/LF/float and critical path on the (possibly crashed) durations
        return ScheduleOptimizationResult(
            schedule=schedule, crash_decisions=crash_decisions,
            total_extra_cost_twd=round(total_extra, 0), solver_status=status_name,
        )
