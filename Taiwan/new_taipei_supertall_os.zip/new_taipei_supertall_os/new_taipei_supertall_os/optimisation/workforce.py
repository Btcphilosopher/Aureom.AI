"""Workforce optimiser (spec section 41): crew size / shift structure to
minimise duration WITHOUT exceeding configured safe labour limits."""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.config.settings import Settings
from new_taipei_supertall_os.domain.worker import Trade


class CrewPlan(BaseModel):
    trade: Trade
    crew_size: int
    shifts_per_day: int
    hours_per_shift: float
    daily_cost_twd: float
    productivity_factor: float
    is_safe: bool
    notes: str


class WorkforceOptimizer:
    def __init__(self, settings: Settings):
        self.labour_cfg = settings.labour

    def plan_crew(self, trade: Trade, target_worker_hours_per_day: float) -> CrewPlan:
        trade_cfg = self.labour_cfg.get("trades", {}).get(trade.value, {})
        prod_cfg = self.labour_cfg.get("productivity", {})
        shift_cfg = self.labour_cfg.get("shift", {})

        crew_min = trade_cfg.get("crew_min", 4)
        crew_max = trade_cfg.get("crew_max", 40)
        rate = trade_cfg.get("daily_rate_twd", 3500)
        hours_per_shift = shift_cfg.get("hours_per_shift", 8)
        max_safe_hours = prod_cfg.get("max_safe_daily_hours", 10)
        overtime_penalty = prod_cfg.get("overtime_efficiency_penalty_per_hour", 0.02)

        # Prefer adding crew (single shift) before extending hours or adding
        # a second shift, since overtime degrades productivity.
        single_shift_hours = min(hours_per_shift, target_worker_hours_per_day / max(crew_min, 1))
        needed_crew_single_shift = target_worker_hours_per_day / max(hours_per_shift, 1)

        if needed_crew_single_shift <= crew_max:
            crew_size = max(crew_min, round(needed_crew_single_shift))
            shifts = 1
            hours = hours_per_shift
            productivity = 1.0
            notes = "Single shift, crew-size scaled to demand."
            is_safe = True
        else:
            # crew capped -> extend hours (bounded by max_safe_daily_hours),
            # then add a second shift if still short.
            crew_size = crew_max
            hours = min(max_safe_hours, target_worker_hours_per_day / crew_max)
            overtime_hours = max(0.0, hours - hours_per_shift)
            productivity = max(0.5, 1.0 - overtime_hours * overtime_penalty)
            shifts = 1
            is_safe = hours <= max_safe_hours
            notes = "Crew at trade maximum; extended shift hours used before adding a shift."
            remaining = target_worker_hours_per_day - crew_size * hours
            if remaining > 0:
                shifts = 2
                notes = "Crew at trade maximum, two shifts used to meet demand within safe daily hours."
                hours = hours_per_shift

        daily_cost = crew_size * rate * shifts
        return CrewPlan(
            trade=trade, crew_size=crew_size, shifts_per_day=shifts, hours_per_shift=round(hours, 1),
            daily_cost_twd=round(daily_cost, 0), productivity_factor=round(productivity, 3),
            is_safe=is_safe, notes=notes,
        )
