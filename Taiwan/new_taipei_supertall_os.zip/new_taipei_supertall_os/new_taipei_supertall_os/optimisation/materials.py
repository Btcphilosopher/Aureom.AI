"""Material ordering optimiser: reduces waste and cost by rounding order
quantities to efficient batch sizes while respecting a minimum safety
buffer (spec sections 20, 38, 54)."""

from __future__ import annotations

import math

from pydantic import BaseModel


class OrderPlan(BaseModel):
    required_quantity: float
    ordered_quantity: float
    batch_size: float
    buffer_fraction: float
    waste_fraction: float
    cost_twd: float


class MaterialsOptimizer:
    def __init__(self, default_buffer_fraction: float = 0.03):
        self.default_buffer_fraction = default_buffer_fraction

    def optimise_order(self, required_quantity: float, unit_cost_twd: float, batch_size: float = 1.0, buffer_fraction: float | None = None) -> OrderPlan:
        buffer = self.default_buffer_fraction if buffer_fraction is None else buffer_fraction
        with_buffer = required_quantity * (1 + buffer)
        ordered = math.ceil(with_buffer / batch_size) * batch_size if batch_size > 0 else with_buffer
        waste_fraction = (ordered - required_quantity) / max(required_quantity, 1e-9)
        return OrderPlan(
            required_quantity=round(required_quantity, 2), ordered_quantity=round(ordered, 2),
            batch_size=batch_size, buffer_fraction=buffer, waste_fraction=round(waste_fraction, 4),
            cost_twd=round(ordered * unit_cost_twd, 0),
        )
