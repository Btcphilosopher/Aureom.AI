"""Optimisation engines. Where OR-Tools CP-SAT is appropriate (schedule
resource levelling, crane count/position) it is used directly; OR-Tools is
a required dependency (see pyproject.toml) so no silent fallback is used."""
