"""Tower crane count / position optimiser (spec section 27).

Formulated as a set-covering problem: given a grid of candidate crane
positions and a grid of demand points across the building footprint, find
the minimum number of cranes (from the candidate positions) whose combined
reach covers every demand point, then reports coverage overlap and a
utilisation estimate from total lifting demand.
"""

from __future__ import annotations

import itertools
import math

from ortools.sat.python import cp_model
from pydantic import BaseModel

from new_taipei_supertall_os.domain.building import Building


class CraneCandidatePosition(BaseModel):
    id: str
    x_m: float
    y_m: float
    max_radius_m: float = 65.0


class CraneOptimizationResult(BaseModel):
    selected_positions: list[str]
    n_cranes: int
    coverage_fraction: float
    average_overlap: float
    estimated_utilisation: float
    solver_status: str


class CraneOptimizer:
    def __init__(self, demand_grid_spacing_m: float = 20.0, min_coverage_fraction: float = 0.98, time_limit_s: float = 5.0):
        self.demand_grid_spacing_m = demand_grid_spacing_m
        self.min_coverage_fraction = min_coverage_fraction
        self.time_limit_s = time_limit_s

    def _demand_points(self, building: Building) -> list[tuple[float, float]]:
        side = math.sqrt(building.site_area_m2)
        n = max(2, int(side / self.demand_grid_spacing_m))
        step = side / n
        return [(i * step, j * step) for i, j in itertools.product(range(n + 1), range(n + 1))]

    def optimize(self, building: Building, candidates: list[CraneCandidatePosition], total_daily_lift_demand_hours: float = 0.0) -> CraneOptimizationResult:
        demand_points = self._demand_points(building)
        coverage = {
            c.id: [i for i, p in enumerate(demand_points) if math.dist((c.x_m, c.y_m), p) <= c.max_radius_m]
            for c in candidates
        }

        model = cp_model.CpModel()
        select = {c.id: model.NewBoolVar(f"select_{c.id}") for c in candidates}

        n_points = len(demand_points)
        covered_count = model.NewIntVar(0, n_points, "covered_count")
        point_covered = []
        for i in range(n_points):
            covering = [select[c.id] for c in candidates if i in coverage[c.id]]
            if covering:
                pc = model.NewBoolVar(f"pt_covered_{i}")
                model.Add(sum(covering) >= 1).OnlyEnforceIf(pc)
                model.Add(sum(covering) == 0).OnlyEnforceIf(pc.Not())
                point_covered.append(pc)
            else:
                point_covered.append(model.NewConstant(0))
        model.Add(covered_count == sum(point_covered))
        min_covered = int(self.min_coverage_fraction * n_points)
        model.Add(covered_count >= min_covered)

        model.Minimize(sum(select.values()))
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = self.time_limit_s
        status = solver.Solve(model)
        status_name = solver.StatusName(status)

        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            # relax coverage requirement and just cover as much as possible
            model2 = cp_model.CpModel()
            select2 = {c.id: model2.NewBoolVar(f"select_{c.id}") for c in candidates}
            model2.Add(sum(select2.values()) >= 1)
            for c in candidates:
                model2.Add(select2[c.id] == 1)
            solver2 = cp_model.CpSolver()
            solver2.Solve(model2)
            selected = [c.id for c in candidates]
            status_name = "FALLBACK_ALL_CANDIDATES"
        else:
            selected = [c.id for c in candidates if solver.Value(select[c.id]) == 1]

        covered_points = set()
        overlaps = []
        for i, p in enumerate(demand_points):
            n_covering = sum(1 for cid in selected if i in coverage[cid])
            if n_covering > 0:
                covered_points.add(i)
            overlaps.append(n_covering)

        coverage_fraction = len(covered_points) / max(n_points, 1)
        avg_overlap = sum(overlaps) / max(len(overlaps), 1)

        utilisation = 0.0
        if selected and total_daily_lift_demand_hours > 0:
            capacity_hours = len(selected) * 10.0  # 10 working hours/crane/day, configurable
            utilisation = min(1.0, total_daily_lift_demand_hours / capacity_hours)

        return CraneOptimizationResult(
            selected_positions=selected, n_cranes=len(selected),
            coverage_fraction=round(coverage_fraction, 3), average_overlap=round(avg_overlap, 2),
            estimated_utilisation=round(utilisation, 3), solver_status=status_name,
        )

    @staticmethod
    def default_candidates(building: Building, spacing_m: float = 45.0, radius_m: float = 65.0) -> list[CraneCandidatePosition]:
        side = math.sqrt(building.site_area_m2)
        n = max(2, int(side / spacing_m))
        step = side / n
        return [
            CraneCandidatePosition(id=f"pos-{i}-{j}", x_m=i * step, y_m=j * step, max_radius_m=radius_m)
            for i, j in itertools.product(range(n + 1), range(n + 1))
        ]
