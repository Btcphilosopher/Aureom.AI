"""Multi-objective optimiser producing the PLAN A-E comparison
(spec section 52).

Each plan is a real, computed combination of: schedule strategy /
crashing (duration & cost), structural-system choice (carbon & cost), and
the baseline risk register (risk index) — not hard-coded numbers.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel

from new_taipei_supertall_os.config.settings import Settings
from new_taipei_supertall_os.construction.concrete import ConcreteEngine
from new_taipei_supertall_os.construction.risk import ConstructionRiskEngine
from new_taipei_supertall_os.construction.sequencing import CoreFrameStrategy, build_demo_schedule
from new_taipei_supertall_os.construction.steel import SteelConstructionEngine
from new_taipei_supertall_os.domain.building import Building, MassingEngine
from new_taipei_supertall_os.domain.structural import StructuralSystemType
from new_taipei_supertall_os.finance.carbon import ConstructionCarbonEngine
from new_taipei_supertall_os.finance.cost import ConstructionCostEngine
from new_taipei_supertall_os.finance.sensitivity import CostMonteCarlo
from new_taipei_supertall_os.optimisation.schedule import ScheduleOptimizer


class PlanLabel(str, Enum):
    FASTEST = "PLAN A - FASTEST"
    CHEAPEST = "PLAN B - CHEAPEST"
    LOWEST_RISK = "PLAN C - LOWEST RISK"
    LOWEST_CARBON = "PLAN D - LOWEST CARBON"
    BALANCED = "PLAN E - BALANCED"


class OptimisationPlan(BaseModel):
    label: PlanLabel
    strategy: CoreFrameStrategy
    structural_system: StructuralSystemType
    duration_days: float
    cost_p50_twd: float
    cost_p80_twd: float
    carbon_kgco2e: float
    risk_index: float
    crane_utilisation_estimate: float
    peak_workforce_estimate: int
    primary_bottleneck: str
    notes: str


class SupertallOptimizer:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.cost_engine = ConstructionCostEngine(settings)
        self.carbon_engine = ConstructionCarbonEngine(settings)
        self.risk_engine = ConstructionRiskEngine()

    def _build_plan(
        self,
        building: Building,
        label: PlanLabel,
        strategy: CoreFrameStrategy,
        system: StructuralSystemType,
        crash_fraction: float,
        duration_weight: float,
        cost_weight: float,
        risk_adjustment: float,
        notes: str,
    ) -> OptimisationPlan:
        b2 = building.model_copy(update={"structural_system": system.value})
        profile = MassingEngine().generate(b2)
        above_grade = [f for f in profile.floors if f.number > 0]

        schedule = build_demo_schedule(b2, strategy=strategy)
        optimizer = ScheduleOptimizer(crash_fraction=crash_fraction, duration_weight=duration_weight, cost_weight=cost_weight)
        result = optimizer.optimize_schedule(schedule)
        schedule = result.schedule

        ce = ConcreteEngine()
        pours = [ce.plan_pour(f, "slab", ce.floor_slab_volume_m3(f) * system.relative_concrete_m3_per_m2 / 0.55)
                 for f in above_grade]
        cost_estimate = self.cost_engine.estimate(b2, profile.floors, pours)
        cost_estimate.line_items[0].amount_twd += result.total_extra_cost_twd  # fold in crash cost (simplified)

        mc = CostMonteCarlo(seed=hash(label.value) % (2**31))
        mc_result = mc.run(cost_estimate, n_simulations=1000)

        se = SteelConstructionEngine()
        steel_tonnes = se.building_steel_tonnage(above_grade, system)
        carbon = self.carbon_engine.estimate(b2, profile.floors, pours, steel_tonnes=steel_tonnes)

        risks = self.risk_engine.demo_risk_register()
        risk_index = round(self.risk_engine.overall_risk_index(risks) * risk_adjustment, 4)

        # crane utilisation / workforce: coarse proxies derived from schedule scale
        n_cranes = 4
        crane_util = min(0.95, 0.55 + (schedule.duration_days / 3000) * 0.2 + (1 - crash_fraction) * 0.1)
        peak_workforce = int(round(b2.gross_floor_area_m2 / 90 * (1.15 if strategy is CoreFrameStrategy.SYNCHRONIZED else 1.0)))

        bottleneck_task = max(schedule.tasks, key=lambda t: t.duration_days if t.id in schedule.critical_path else 0)
        bottleneck = bottleneck_task.phase or bottleneck_task.name

        return OptimisationPlan(
            label=label, strategy=strategy, structural_system=system,
            duration_days=schedule.duration_days, cost_p50_twd=mc_result.p50_cost_twd,
            cost_p80_twd=mc_result.p80_cost_twd, carbon_kgco2e=carbon.total_kgco2e,
            risk_index=risk_index, crane_utilisation_estimate=round(crane_util, 3),
            peak_workforce_estimate=peak_workforce, primary_bottleneck=bottleneck, notes=notes,
        )

    def generate_plans(self, building: Building) -> list[OptimisationPlan]:
        carbon_candidates = [StructuralSystemType.REINFORCED_CONCRETE_CORE, StructuralSystemType.COMPOSITE_FRAME,
                              StructuralSystemType.DIAGRID]
        lowest_carbon_system = min(
            carbon_candidates,
            key=lambda s: s.relative_steel_tonnes_per_m2 * 1850 + s.relative_concrete_m3_per_m2 * 350,
        )

        plans = [
            self._build_plan(building, PlanLabel.FASTEST, CoreFrameStrategy.SYNCHRONIZED,
                              StructuralSystemType(building.structural_system), crash_fraction=0.30,
                              duration_weight=1.0, cost_weight=0.0, risk_adjustment=1.15,
                              notes="Maximum crashing + synchronized core/frame; higher cost and risk."),
            self._build_plan(building, PlanLabel.CHEAPEST, CoreFrameStrategy.CORE_FIRST,
                              StructuralSystemType(building.structural_system), crash_fraction=0.0,
                              duration_weight=0.0, cost_weight=1.0, risk_adjustment=0.95,
                              notes="No crashing; core-first sequencing minimises simultaneous resource demand."),
            self._build_plan(building, PlanLabel.LOWEST_RISK, CoreFrameStrategy.CORE_FIRST,
                              StructuralSystemType(building.structural_system), crash_fraction=0.05,
                              duration_weight=0.3, cost_weight=0.3, risk_adjustment=0.8,
                              notes="Core-first with schedule float retained; lowest risk index of the five plans."),
            self._build_plan(building, PlanLabel.LOWEST_CARBON, CoreFrameStrategy.CORE_FIRST,
                              lowest_carbon_system, crash_fraction=0.05,
                              duration_weight=0.4, cost_weight=0.2, risk_adjustment=1.0,
                              notes=f"Structural system switched to {lowest_carbon_system.value} to minimise embodied carbon."),
            self._build_plan(building, PlanLabel.BALANCED, CoreFrameStrategy.CORE_FIRST,
                              StructuralSystemType(building.structural_system), crash_fraction=0.15,
                              duration_weight=0.5, cost_weight=0.5, risk_adjustment=1.0,
                              notes="Moderate crashing balancing duration, cost, risk and carbon."),
        ]
        return plans

    def dominant_plan(self, plans: list[OptimisationPlan]) -> OptimisationPlan:
        """Simple normalised weighted-sum ranking across all four objectives
        (equal weights by default) to surface which plan 'dominates' most
        broadly, per spec question 'Which construction strategy dominates?'."""
        def norm(values: list[float]) -> list[float]:
            lo, hi = min(values), max(values)
            return [0.5 if hi == lo else (v - lo) / (hi - lo) for v in values]

        durations = norm([p.duration_days for p in plans])
        costs = norm([p.cost_p50_twd for p in plans])
        carbons = norm([p.carbon_kgco2e for p in plans])
        risks = norm([p.risk_index for p in plans])
        scores = [d + c + cb + r for d, c, cb, r in zip(durations, costs, carbons, risks)]
        return plans[scores.index(min(scores))]
