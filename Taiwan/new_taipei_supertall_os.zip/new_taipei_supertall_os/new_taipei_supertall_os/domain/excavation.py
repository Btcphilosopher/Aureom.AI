"""Deep excavation domain model (spec section 14)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class RetainingWallType(str, Enum):
    DIAPHRAGM_WALL = "diaphragm_wall"
    SECANT_PILE_WALL = "secant_pile_wall"
    SHEET_PILE = "sheet_pile"
    SOLDIER_PILE = "soldier_pile"
    OTHER = "other"


class ExcavationModel(BaseModel):
    excavation_depth_m: float
    excavation_area_m2: float
    basement_levels: int
    retaining_wall_type: RetainingWallType = RetainingWallType.DIAPHRAGM_WALL
    groundwater_level_m: float = -3.0
    support_stages: int = 5
    wall_thickness_m: float = 1.0
    wall_embedment_below_formation_m: float = 8.0

    @property
    def excavation_volume_m3(self) -> float:
        return self.excavation_depth_m * self.excavation_area_m2
