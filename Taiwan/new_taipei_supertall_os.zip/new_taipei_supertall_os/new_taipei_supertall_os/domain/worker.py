"""Workforce domain model (spec section 40)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class Trade(str, Enum):
    CIVIL = "civil"
    STRUCTURAL = "structural"
    STEEL = "steel"
    CONCRETE = "concrete"
    MEP = "mep"
    ELECTRICAL = "electrical"
    PLUMBING = "plumbing"
    FACADE = "facade"
    CRANE = "crane"
    SURVEY = "survey"
    SAFETY = "safety"
    FINISHING = "finishing"
    COMMISSIONING = "commissioning"


class Worker(BaseModel):
    id: str
    trade: Trade
    daily_rate_twd: float
    productivity_factor: float = 1.0  # 1.0 == baseline


class Crew(BaseModel):
    id: str
    trade: Trade
    size: int
    daily_rate_twd_per_worker: float
    shift_hours: float = 8.0
    shifts_per_day: int = 1
    productivity_factor: float = 1.0

    @property
    def daily_cost_twd(self) -> float:
        return self.size * self.daily_rate_twd_per_worker * self.shifts_per_day

    @property
    def effective_worker_hours_per_day(self) -> float:
        return self.size * self.shift_hours * self.shifts_per_day * self.productivity_factor


class WorkforceSnapshot(BaseModel):
    """Headcount by trade at a point in the schedule, for peak-workforce
    reporting and safety-loading checks."""

    date_index_days: int
    headcount_by_trade: dict[str, int] = Field(default_factory=dict)

    @property
    def total_headcount(self) -> int:
        return sum(self.headcount_by_trade.values())
