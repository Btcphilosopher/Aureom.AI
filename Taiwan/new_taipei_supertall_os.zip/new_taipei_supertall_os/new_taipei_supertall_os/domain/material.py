"""Material domain model, used by concrete/steel/facade/procurement engines."""

from __future__ import annotations

from datetime import date
from enum import Enum

from pydantic import BaseModel


class MaterialCategory(str, Enum):
    CONCRETE = "concrete"
    REBAR = "rebar"
    STRUCTURAL_STEEL = "structural_steel"
    GLASS = "glass"
    ALUMINIUM = "aluminium"
    CEMENT = "cement"
    MEP_EQUIPMENT = "mep_equipment"
    ELEVATOR = "elevator"
    MECHANICAL_PLANT = "mechanical_plant"
    FORMWORK = "formwork"
    OTHER = "other"


class Material(BaseModel):
    id: str
    name: str
    category: MaterialCategory
    unit: str = "unit"
    unit_cost_twd: float = 0.0
    co2e_kg_per_unit: float = 0.0
    supplier: str | None = None
    lead_time_days: int = 0


class MaterialBatch(BaseModel):
    """A quantity of a material delivered/consumed on a given date, used for
    procurement tracking (spec section 38) and concrete/steel logs
    (spec sections 19, 21)."""

    id: str
    material_id: str
    quantity: float
    unit: str
    delivery_date: date | None = None
    consumption_date: date | None = None
    floor_number: int | None = None
    element: str | None = None
    supplier: str | None = None
    status: str = "planned"  # planned | ordered | in_transit | delivered | consumed
    cost_twd: float = 0.0
