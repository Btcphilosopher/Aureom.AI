"""Site domain model: the physical site as a graph of nodes (entrances,
gates, laydown areas, cranes, hoists, pumps, welfare) and edges (temporary
roads), plus neighbouring-asset tracking for excavation risk (spec
sections 28, 45)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class SiteNodeType(str, Enum):
    ENTRANCE = "entrance"
    TRUCK_GATE = "truck_gate"
    WORKER_ENTRANCE = "worker_entrance"
    LAYDOWN_ZONE = "laydown_zone"
    MATERIAL_STORAGE = "material_storage"
    TOWER_CRANE = "tower_crane"
    HOIST = "hoist"
    CONCRETE_PUMP = "concrete_pump"
    WELFARE = "welfare"
    WASH_BAY = "wash_bay"
    WASTE_AREA = "waste_area"


class SiteNode(BaseModel):
    id: str
    node_type: SiteNodeType
    x_m: float
    y_m: float
    capacity: float | None = None


class SiteEdge(BaseModel):
    """A temporary road/route segment between two site nodes."""

    from_node: str
    to_node: str
    length_m: float
    max_speed_kmh: float = 15.0
    bidirectional: bool = True


class Site(BaseModel):
    id: str
    name: str
    area_m2: float
    boundary_polygon: list[tuple[float, float]] = Field(default_factory=list)
    nodes: list[SiteNode] = Field(default_factory=list)
    edges: list[SiteEdge] = Field(default_factory=list)

    def node(self, node_id: str) -> SiteNode | None:
        return next((n for n in self.nodes if n.id == node_id), None)


class NeighbouringAsset(BaseModel):
    """A structure/asset adjacent to the site, tracked for excavation and
    construction risk purposes (spec section 45). The platform only
    *flags* proximity risk; it never decides whether it is safe."""

    id: str
    name: str
    distance_m: float
    height_m: float | None = None
    foundation_depth_m: float | None = None
    sensitivity: str = "medium"  # low | medium | high | critical (engineer-assigned)
    monitoring_required: bool = True
    asset_type: str = "building"  # building | rail_structure | utility | slope | heritage
