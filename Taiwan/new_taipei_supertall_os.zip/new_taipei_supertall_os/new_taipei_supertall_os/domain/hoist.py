"""Construction hoist domain model (spec section 25)."""

from __future__ import annotations

from pydantic import BaseModel


class ConstructionHoist(BaseModel):
    id: str
    capacity_kg: float = 3200.0
    capacity_persons: int = 32
    speed_m_per_min: float = 90.0
    travel_height_m: float = 400.0
    availability_fraction: float = 0.9
    dedicated_to: str = "mixed"  # "worker" | "material" | "mixed"

    def one_way_travel_time_min(self, height_m: float) -> float:
        return height_m / max(self.speed_m_per_min, 1.0)

    def cycle_time_min(self, height_m: float, load_unload_min: float = 2.0) -> float:
        return 2 * self.one_way_travel_time_min(height_m) + 2 * load_unload_min

    def daily_capacity_persons(self, height_m: float, hours_per_day: float = 10.0) -> float:
        cycle = self.cycle_time_min(height_m)
        trips_per_day = (hours_per_day * 60 / max(cycle, 1e-6)) * self.availability_fraction
        return trips_per_day * self.capacity_persons
