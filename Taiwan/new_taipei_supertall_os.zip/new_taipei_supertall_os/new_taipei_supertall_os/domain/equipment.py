"""Generic construction equipment domain model (concrete pumps, excavators,
generators, etc. — anything that isn't a tower crane or hoist, which have
their own richer models)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class EquipmentType(str, Enum):
    CONCRETE_PUMP = "concrete_pump"
    EXCAVATOR = "excavator"
    BATCHING_PLANT = "batching_plant"
    GENERATOR = "generator"
    WELFARE_UNIT = "welfare_unit"
    SURVEY_STATION = "survey_station"
    DEWATERING_PUMP = "dewatering_pump"
    OTHER = "other"


class Equipment(BaseModel):
    id: str
    equipment_type: EquipmentType
    capacity: float = 0.0
    capacity_unit: str = ""
    availability_fraction: float = 0.9
    daily_cost_twd: float = 0.0
    location_x_m: float | None = None
    location_y_m: float | None = None
    status: str = "idle"  # idle | active | maintenance | breakdown
