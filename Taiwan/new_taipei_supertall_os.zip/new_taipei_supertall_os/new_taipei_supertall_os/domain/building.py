"""Building domain model and the supertall massing engine (spec sections 4, 6).

``Building`` is the root aggregate that most of the rest of the platform
hangs off. ``MassingEngine`` derives a plausible floor-by-floor massing
(podium / tower / setbacks / mechanical floors / crown) from a small set of
top-level parameters, entirely for planning/optimisation purposes — it is
not an architectural design tool.
"""

from __future__ import annotations

from datetime import date
from enum import Enum

from pydantic import BaseModel, Field, field_validator

from new_taipei_supertall_os.domain.calculation import VersionInfo
from new_taipei_supertall_os.domain.floor import ConstructionStatus, Floor, FloorUseType


class MassingZone(str, Enum):
    PODIUM = "podium"
    LOWER_TOWER = "lower_tower"
    UPPER_TOWER = "upper_tower"
    CROWN = "crown"
    BASEMENT = "basement"


class Building(BaseModel):
    """Root aggregate describing a (hypothetical) supertall building project.

    This is a PLANNING / SIMULATION model. Nothing here constitutes an
    architectural or structural design.
    """

    id: str
    name: str
    city: str = "New Taipei City"
    height_m: float
    floors: int
    basement_floors: int = 0
    gross_floor_area_m2: float
    site_area_m2: float
    use_mix: dict[str, float] = Field(default_factory=dict)
    structural_system: str = "composite_frame"
    foundation_type: str = "piled_raft"
    start_date: date | None = None
    is_demonstration: bool = True
    version_info: VersionInfo = Field(default_factory=VersionInfo)

    @field_validator("use_mix")
    @classmethod
    def _use_mix_sums_to_one(cls, v: dict[str, float]) -> dict[str, float]:
        if v:
            total = sum(v.values())
            if not (0.95 <= total <= 1.05):
                raise ValueError(f"use_mix must sum to ~1.0, got {total:.3f}")
        return v

    @property
    def average_floor_to_floor_m(self) -> float:
        if self.floors <= 0:
            return 4.2
        return self.height_m / self.floors

    @property
    def floor_area_ratio(self) -> float:
        """Total GFA / site area — a common planning-density indicator."""
        if self.site_area_m2 <= 0:
            return 0.0
        return self.gross_floor_area_m2 / self.site_area_m2

    @property
    def is_supertall(self) -> bool:
        return self.height_m >= 300.0

    @property
    def total_floor_count_incl_basement(self) -> int:
        return self.floors + self.basement_floors

    def label(self) -> str:
        tag = "SIMULATION ONLY / 模擬專案" if self.is_demonstration else ""
        return f"{self.name} ({self.id}) {tag}".strip()


class MassingProfile(BaseModel):
    """Output of :class:`MassingEngine`: one row per floor plus zone summaries."""

    floors: list[Floor]
    zone_boundaries: dict[str, tuple[int, int]]

    def floor_area_by_zone(self) -> dict[str, float]:
        out: dict[str, float] = {}
        zone_of = {}
        for zone, (lo, hi) in self.zone_boundaries.items():
            for n in range(lo, hi + 1):
                zone_of[n] = zone
        for floor in self.floors:
            zone = zone_of.get(floor.number, "unclassified")
            out[zone] = out.get(zone, 0.0) + floor.area_m2
        return out


class MassingEngine:
    """Derives a floor-by-floor massing profile for a supertall tower.

    The algorithm is a simple, transparent, configurable heuristic:

    * basement floors are constant-area parking/plant floors;
    * a podium block (large plate) for the first ``podium_floors``;
    * the tower plate steps down at ``setback_floor`` and again in the
      ``upper_tower_fraction`` of remaining floors;
    * mechanical/refuge floors are inserted every ``mechanical_floor_interval``
      floors;
    * the top ``crown_floors`` taper toward a reduced crown plate.
    """

    def __init__(
        self,
        podium_floors: int = 10,
        setback_floor_fraction: float = 0.65,
        upper_setback_fraction: float = 0.88,
        mechanical_floor_interval: int = 20,
        crown_floors: int = 4,
        basement_plate_area_m2: float | None = None,
    ) -> None:
        self.podium_floors = podium_floors
        self.setback_floor_fraction = setback_floor_fraction
        self.upper_setback_fraction = upper_setback_fraction
        self.mechanical_floor_interval = mechanical_floor_interval
        self.crown_floors = crown_floors
        self.basement_plate_area_m2 = basement_plate_area_m2

    def generate(self, building: Building) -> MassingProfile:
        floors: list[Floor] = []
        f2f = building.average_floor_to_floor_m

        # --- basements ---
        basement_area = self.basement_plate_area_m2 or (building.site_area_m2 * 0.85)
        elevation = 0.0
        for i in range(building.basement_floors, 0, -1):
            elevation -= f2f
            floors.append(
                Floor(
                    number=-i,
                    elevation_m=elevation,
                    floor_to_floor_m=f2f,
                    area_m2=basement_area,
                    use_type=FloorUseType.PARKING,
                    structural_system=building.structural_system,
                )
            )

        # --- above-grade plate schedule ---
        n = building.floors
        setback_floor = max(self.podium_floors + 1, round(n * self.setback_floor_fraction))
        upper_setback_floor = max(setback_floor + 1, round(n * self.upper_setback_fraction))
        crown_start = max(upper_setback_floor + 1, n - self.crown_floors + 1)

        podium_plate = building.gross_floor_area_m2 / max(n, 1) * 1.35
        tower_plate = building.gross_floor_area_m2 / max(n, 1) * 1.05
        reduced_plate = tower_plate * 0.72
        upper_plate = tower_plate * 0.52
        crown_plate = tower_plate * 0.30

        elevation = 0.0
        for level in range(1, n + 1):
            elevation += f2f
            if level <= self.podium_floors:
                area = podium_plate
                use = FloorUseType.RETAIL if level <= 3 else FloorUseType.LOBBY
            elif level < setback_floor:
                area = tower_plate
                use = FloorUseType.OFFICE
            elif level < upper_setback_floor:
                area = reduced_plate
                use = FloorUseType.RESIDENTIAL
            elif level < crown_start:
                area = upper_plate
                use = FloorUseType.HOTEL
            else:
                area = crown_plate
                use = FloorUseType.OBSERVATION if level == n else FloorUseType.HOTEL

            is_mech = (
                level % self.mechanical_floor_interval == 0
                and level not in (setback_floor, upper_setback_floor)
            )
            if is_mech:
                use = FloorUseType.MECHANICAL
                area *= 0.6

            floors.append(
                Floor(
                    number=level,
                    elevation_m=elevation,
                    floor_to_floor_m=f2f,
                    area_m2=round(area, 1),
                    use_type=use,
                    structural_system=building.structural_system,
                    is_mechanical_floor=is_mech,
                    is_outrigger_floor=level in (setback_floor, upper_setback_floor),
                    construction_status=ConstructionStatus.NOT_STARTED,
                )
            )

        boundaries = {
            MassingZone.BASEMENT.value: (-building.basement_floors, 0) if building.basement_floors else (0, 0),
            MassingZone.PODIUM.value: (1, self.podium_floors),
            MassingZone.LOWER_TOWER.value: (self.podium_floors + 1, setback_floor - 1),
            MassingZone.UPPER_TOWER.value: (setback_floor, crown_start - 1),
            MassingZone.CROWN.value: (crown_start, n),
        }
        return MassingProfile(floors=floors, zone_boundaries=boundaries)
