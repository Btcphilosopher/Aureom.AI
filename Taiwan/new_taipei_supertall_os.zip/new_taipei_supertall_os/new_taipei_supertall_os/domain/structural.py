"""Abstract structural system, core, and outrigger domain models
(spec sections 7, 8, 9).

These describe *what kind* of structural system a project intends to use,
and hold enough geometry to feed preliminary planning calculations in
``engineering/structural_model.py``. They do NOT perform final structural
design or certification.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class StructuralSystemType(str, Enum):
    REINFORCED_CONCRETE_CORE = "reinforced_concrete_core"
    STEEL_FRAME = "steel_frame"
    COMPOSITE_FRAME = "composite_frame"
    MEGA_FRAME = "mega_frame"
    DIAGRID = "diagrid"
    OUTRIGGER = "outrigger"
    DUAL_SYSTEM = "dual_system"

    @property
    def relative_lateral_stiffness_factor(self) -> float:
        """A coarse, configurable relative-stiffness multiplier used only
        for comparative (not absolute) preliminary drift/optimisation
        estimates. NOT a substitute for a structural model.
        """
        return {
            StructuralSystemType.REINFORCED_CONCRETE_CORE: 1.0,
            StructuralSystemType.STEEL_FRAME: 0.8,
            StructuralSystemType.COMPOSITE_FRAME: 1.15,
            StructuralSystemType.MEGA_FRAME: 1.35,
            StructuralSystemType.DIAGRID: 1.45,
            StructuralSystemType.OUTRIGGER: 1.6,
            StructuralSystemType.DUAL_SYSTEM: 1.5,
        }[self]

    @property
    def relative_steel_tonnes_per_m2(self) -> float:
        return {
            StructuralSystemType.REINFORCED_CONCRETE_CORE: 0.02,
            StructuralSystemType.STEEL_FRAME: 0.14,
            StructuralSystemType.COMPOSITE_FRAME: 0.09,
            StructuralSystemType.MEGA_FRAME: 0.11,
            StructuralSystemType.DIAGRID: 0.13,
            StructuralSystemType.OUTRIGGER: 0.10,
            StructuralSystemType.DUAL_SYSTEM: 0.10,
        }[self]

    @property
    def relative_concrete_m3_per_m2(self) -> float:
        return {
            StructuralSystemType.REINFORCED_CONCRETE_CORE: 0.55,
            StructuralSystemType.STEEL_FRAME: 0.20,
            StructuralSystemType.COMPOSITE_FRAME: 0.38,
            StructuralSystemType.MEGA_FRAME: 0.30,
            StructuralSystemType.DIAGRID: 0.25,
            StructuralSystemType.OUTRIGGER: 0.32,
            StructuralSystemType.DUAL_SYSTEM: 0.34,
        }[self]


class CoreSystem(BaseModel):
    """Central core wall system (spec section 8)."""

    core_width_m: float
    core_depth_m: float
    core_wall_thickness_m: float = 0.6
    elevator_count: int = 0
    stair_count: int = 2
    service_shafts: int = 4
    mep_shafts: int = 6
    top_wall_thickness_m: float = 0.35  # allows tapering thickness with height

    @property
    def plan_area_m2(self) -> float:
        return self.core_width_m * self.core_depth_m

    def wall_thickness_at_floor(self, floor_number: int, total_floors: int) -> float:
        """Linearly taper wall thickness with height — a common but
        simplified planning assumption; a real taper schedule is set by
        the structural engineer."""
        if total_floors <= 1:
            return self.core_wall_thickness_m
        frac = max(0.0, min(1.0, floor_number / total_floors))
        return self.core_wall_thickness_m + frac * (self.top_wall_thickness_m - self.core_wall_thickness_m)


class OutriggerLevel(BaseModel):
    """An outrigger / belt-truss / mega-column mechanical level
    (spec section 9)."""

    floor_number: int
    has_outrigger: bool = True
    has_belt_truss: bool = True
    mega_columns: int = 4
    stiffness_gain_factor: float = Field(
        default=1.15,
        description="Configurable, coarse multiplier applied to core lateral "
        "stiffness at/above this level for preliminary drift comparisons "
        "only.",
    )


class StructuralFrame(BaseModel):
    """Ties a structural system, core, and set of outrigger levels together
    for a given building."""

    system_type: StructuralSystemType = StructuralSystemType.COMPOSITE_FRAME
    core: CoreSystem
    outrigger_levels: list[OutriggerLevel] = Field(default_factory=list)
    typical_column_spacing_m: float = 9.0
    perimeter_column_count: int = 8

    def active_outrigger_below(self, floor_number: int) -> OutriggerLevel | None:
        candidates = [o for o in self.outrigger_levels if o.floor_number <= floor_number]
        return max(candidates, key=lambda o: o.floor_number) if candidates else None
