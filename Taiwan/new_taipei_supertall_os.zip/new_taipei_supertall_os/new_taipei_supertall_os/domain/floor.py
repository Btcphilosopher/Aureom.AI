"""Floor-level domain model (spec section 5)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class FloorUseType(str, Enum):
    RETAIL = "retail"
    OFFICE = "office"
    RESIDENTIAL = "residential"
    HOTEL = "hotel"
    MECHANICAL = "mechanical"
    PLANT = "plant"
    LOBBY = "lobby"
    PARKING = "parking"
    OBSERVATION = "observation"
    SERVICE = "service"
    REFUGE = "refuge"  # high-rise refuge floor


class ConstructionStatus(str, Enum):
    NOT_STARTED = "not_started"
    STRUCTURE_IN_PROGRESS = "structure_in_progress"
    STRUCTURE_COMPLETE = "structure_complete"
    FACADE_IN_PROGRESS = "facade_in_progress"
    MEP_IN_PROGRESS = "mep_in_progress"
    INTERIORS_IN_PROGRESS = "interiors_in_progress"
    COMPLETE = "complete"


class Floor(BaseModel):
    """A single above- or below-grade floor plate.

    ``number`` uses the convention: basements are negative (-1 = first
    basement below grade), ground floor is 0, tower floors are positive.
    """

    number: int
    elevation_m: float
    floor_to_floor_m: float = 4.2
    area_m2: float
    use_type: FloorUseType = FloorUseType.OFFICE
    structural_system: str = "reinforced_concrete_core"
    construction_status: ConstructionStatus = ConstructionStatus.NOT_STARTED
    is_mechanical_floor: bool = False
    is_outrigger_floor: bool = False
    is_refuge_floor: bool = False

    # Digital-twin progress tracking (spec section 46), 0-100.
    progress_structure_pct: float = Field(default=0.0, ge=0.0, le=100.0)
    progress_facade_pct: float = Field(default=0.0, ge=0.0, le=100.0)
    progress_mep_pct: float = Field(default=0.0, ge=0.0, le=100.0)
    progress_interiors_pct: float = Field(default=0.0, ge=0.0, le=100.0)

    @property
    def overall_progress_pct(self) -> float:
        weights = {
            "structure": (self.progress_structure_pct, 0.35),
            "facade": (self.progress_facade_pct, 0.25),
            "mep": (self.progress_mep_pct, 0.25),
            "interiors": (self.progress_interiors_pct, 0.15),
        }
        total = sum(v * w for v, w in weights.values())
        return round(total, 1)

    def is_below_grade(self) -> bool:
        return self.number < 0
