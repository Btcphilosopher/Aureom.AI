"""Domain models: the static description of a supertall building project.

Nothing in this package performs simulation, optimisation, or final
engineering certification — it is the typed vocabulary the rest of the
platform (engineering, construction, logistics, optimisation, simulation,
finance, compliance, digital_twin) builds on.
"""
