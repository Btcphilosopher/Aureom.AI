"""Tower crane domain model (spec section 26)."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class CraneTaskType(str, Enum):
    STEEL = "steel"
    REBAR = "rebar"
    FORMWORK = "formwork"
    MEP = "mep"
    FACADE = "facade"
    MATERIALS = "materials"


class TowerCrane(BaseModel):
    id: str
    model: str = "generic-luffing"
    position_x_m: float = 0.0
    position_y_m: float = 0.0
    max_load_kg: float = 20000.0
    max_radius_m: float = 65.0
    hook_height_m: float = 250.0
    lifting_speed_m_per_min: float = 60.0
    slewing_speed_rpm: float = 0.8
    availability_fraction: float = 0.92
    tasks: list[CraneTaskType] = Field(default_factory=lambda: list(CraneTaskType))

    def coverage_radius_m(self) -> float:
        return self.max_radius_m

    def average_cycle_time_min(self, radial_distance_m: float, lift_height_m: float) -> float:
        """Very coarse single-cycle time estimate (hoist + slew + lower + return)."""
        hoist_time = (lift_height_m / max(self.lifting_speed_m_per_min, 1.0)) * 2
        slew_fraction = min(1.0, radial_distance_m / max(self.max_radius_m, 1.0))
        slew_time = slew_fraction * (1.0 / max(self.slewing_speed_rpm, 0.1)) * 60 * 0.5
        attach_detach_min = 3.0
        return hoist_time + slew_time + attach_detach_min
