"""Foundation domain model (spec section 12).

Data only — calculations live in ``engineering/foundation_model.py``.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class FoundationType(str, Enum):
    MAT_FOUNDATION = "mat_foundation"
    PILE_FOUNDATION = "pile_foundation"
    PILED_RAFT = "piled_raft"
    DEEP_FOUNDATION = "deep_foundation"


class FoundationModel(BaseModel):
    foundation_type: FoundationType = FoundationType.PILED_RAFT
    pile_diameter_m: float = 1.5
    pile_length_m: float = 55.0
    pile_capacity_kn: float = 18000.0
    pile_count: int = 220
    raft_thickness_m: float = 3.5
    raft_area_m2: float | None = None
    design_safety_factor: float = 2.0

    def total_pile_capacity_kn(self) -> float:
        return self.pile_capacity_kn * self.pile_count
