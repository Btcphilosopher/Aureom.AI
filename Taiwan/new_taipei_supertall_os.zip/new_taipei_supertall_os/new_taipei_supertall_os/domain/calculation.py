"""Auditability primitives shared across every engineering/optimisation module.

Every numeric result produced by this platform that could plausibly inform a
design, schedule, or cost decision is wrapped in a :class:`CalculationResult`
so that the platform can always answer: "what calculation produced this
number, from what inputs, using what method, and with what confidence?"

None of the results produced anywhere in this codebase are a substitute for
sealed/stamped engineering calculations. Anything with ``domain in
{"structural", "geotechnical", "seismic"}`` is additionally guaranteed to
carry the :data:`PRELIMINARY_ENGINEERING_NOTICE` string in its
``assumptions`` list.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

MODEL_VERSION = "0.1.0"

PRELIMINARY_ENGINEERING_NOTICE = (
    "PRELIMINARY ENGINEERING ESTIMATE ONLY - not a substitute for sealed "
    "structural, geotechnical, or fire engineering calculations. Must be "
    "independently verified by a qualified, licensed professional before "
    "any design, permitting, or construction decision relies on it."
)


class Confidence(str, Enum):
    """Qualitative confidence band for a calculated value.

    This is a modelling judgement about the calculation itself (input
    quality, method fidelity), not a statement about regulatory adequacy.
    """

    INDICATIVE = "indicative"      # order-of-magnitude, demo/default inputs
    PRELIMINARY = "preliminary"    # reasonable engineering approximation
    DETAILED = "detailed"          # based on project-specific survey/data
    VERIFIED = "verified"          # cross-checked against external source


class CalculationResult(BaseModel):
    """A single traceable, versioned calculated value.

    ``inputs`` should be a flat, JSON-serialisable snapshot of everything
    the calculation consumed, so a result can be reproduced or challenged
    without re-reading source code.
    """

    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    value: float
    units: str
    method: str
    inputs: dict[str, Any] = Field(default_factory=dict)
    assumptions: list[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    model_version: str = MODEL_VERSION
    confidence: Confidence = Confidence.PRELIMINARY
    domain: str = "general"

    def model_post_init(self, __context: Any) -> None:  # noqa: D401
        if self.domain in {"structural", "geotechnical", "seismic", "wind", "foundation"}:
            if PRELIMINARY_ENGINEERING_NOTICE not in self.assumptions:
                self.assumptions.append(PRELIMINARY_ENGINEERING_NOTICE)

    def as_row(self) -> dict[str, Any]:
        """Flat dict suitable for a Pandas/Polars DataFrame row or CSV export."""
        return {
            "id": self.id,
            "value": self.value,
            "units": self.units,
            "method": self.method,
            "assumptions": "; ".join(self.assumptions),
            "timestamp": self.timestamp.isoformat(),
            "model_version": self.model_version,
            "confidence": self.confidence.value,
            "domain": self.domain,
        }


class VersionInfo(BaseModel):
    """Attached to every building model, schedule, cost estimate, regulatory
    configuration, optimisation run, and simulation run per spec section 67.
    """

    version: str = "0.1.0"
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    author: str = "system"
    scenario: str = "baseline"


class Versioned(BaseModel):
    """Mixin providing a `version_info` field. Use via multiple inheritance
    or composition where a BaseModel already has its own base.
    """

    version_info: VersionInfo = Field(default_factory=VersionInfo)
