"""Central configuration loading.

Regulatory values, material rates, labour rates, and site parameters are
never hard-coded inside algorithms (see spec sections 30 and 59). They live
in versioned YAML under ``config/`` and ``regulations/`` and are loaded here
into typed Pydantic models.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field

CONFIG_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CONFIG_DIR.parent
REGULATIONS_DIR = PROJECT_ROOT / "regulations"


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


class CurrencyConfig(BaseModel):
    base_currency: str = "TWD"
    display_currency: str = "TWD"
    fx_rates_to_twd: dict[str, float] = Field(default_factory=lambda: {"TWD": 1.0, "USD": 32.0})

    def convert(self, amount: float, from_ccy: str, to_ccy: str) -> float:
        rate_from = self.fx_rates_to_twd.get(from_ccy, 1.0)
        rate_to = self.fx_rates_to_twd.get(to_ccy, 1.0)
        twd = amount * rate_from
        return twd / rate_to


class SiteConfig(BaseModel):
    city: str = "New Taipei City"
    district: str = "Banqiao"
    latitude: float = 25.0138
    longitude: float = 121.4625
    basic_wind_speed_ms: float = 42.0
    seismic_zone_factor: float = 0.30
    site_class: str = "C"
    groundwater_level_m: float = -3.0
    typhoon_season_months: list[int] = Field(default_factory=lambda: [6, 7, 8, 9, 10])


class DatabaseConfig(BaseModel):
    url: str = os.environ.get(
        "NT_SUPERTALL_DATABASE_URL",
        "postgresql+psycopg://postgres:postgres@localhost:5432/new_taipei_supertall",
    )
    echo: bool = False


class Settings(BaseModel):
    """Top-level, immutable-by-convention application settings."""

    environment: str = os.environ.get("NT_SUPERTALL_ENV", "development")
    project_root: Path = PROJECT_ROOT
    currency: CurrencyConfig = Field(default_factory=CurrencyConfig)
    site: SiteConfig = Field(default_factory=SiteConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    materials: dict[str, Any] = Field(default_factory=dict)
    labour: dict[str, Any] = Field(default_factory=dict)
    regulations_dir: Path = REGULATIONS_DIR
    active_regulatory_year: str = "2026"

    model_config = {"arbitrary_types_allowed": True}


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Load settings once, merging YAML config files over the defaults."""
    raw_site = _load_yaml(CONFIG_DIR / "new_taipei.yaml")
    raw_materials = _load_yaml(CONFIG_DIR / "materials.yaml")
    raw_labour = _load_yaml(CONFIG_DIR / "labour.yaml")

    settings = Settings()
    if raw_site:
        site_data = {**settings.site.model_dump(), **raw_site.get("site", {})}
        settings.site = SiteConfig(**site_data)
        if "currency" in raw_site:
            currency_data = {**settings.currency.model_dump(), **raw_site["currency"]}
            settings.currency = CurrencyConfig(**currency_data)
    settings.materials = raw_materials
    settings.labour = raw_labour
    return settings


def load_scenario(name: str) -> dict[str, Any]:
    """Load a named scenario override file from config/scenarios/<name>.yaml."""
    path = CONFIG_DIR / "scenarios" / f"{name}.yaml"
    return _load_yaml(path)
