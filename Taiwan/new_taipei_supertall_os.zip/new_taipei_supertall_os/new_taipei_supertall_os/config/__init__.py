"""Configuration loading (typed settings + versioned regulatory config)."""
