"""Site digital twin entity state (spec section 48).

Buildings, cranes, hoists, trucks, workers, materials, excavation, and
temporary structures are represented as real-time-style entities:
``id, location, status, task, timestamp``.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum

from pydantic import BaseModel, Field


class EntityType(str, Enum):
    BUILDING = "building"
    CRANE = "crane"
    HOIST = "hoist"
    TRUCK = "truck"
    WORKER_CREW = "worker_crew"
    MATERIAL_BATCH = "material_batch"
    EXCAVATION = "excavation"
    TEMPORARY_STRUCTURE = "temporary_structure"


class SiteEntity(BaseModel):
    id: str
    entity_type: EntityType
    location_x_m: float | None = None
    location_y_m: float | None = None
    location_z_m: float | None = None
    status: str = "idle"
    task: str | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    attributes: dict = Field(default_factory=dict)


class DigitalTwinState(BaseModel):
    project_id: str
    entities: dict[str, SiteEntity] = Field(default_factory=dict)
    as_of: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def upsert(self, entity: SiteEntity) -> None:
        entity.timestamp = datetime.now(timezone.utc)
        self.entities[entity.id] = entity
        self.as_of = entity.timestamp

    def by_type(self, entity_type: EntityType) -> list[SiteEntity]:
        return [e for e in self.entities.values() if e.entity_type == entity_type]

    def snapshot(self) -> dict:
        return {"project_id": self.project_id, "as_of": self.as_of.isoformat(),
                "entities": {k: v.model_dump(mode="json") for k, v in self.entities.items()}}
