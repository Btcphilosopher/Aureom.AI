"""Replay engine: plays back a recorded sequence of digital-twin snapshots
or telemetry events for after-the-fact review / animation."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel

from new_taipei_supertall_os.digital_twin.state import DigitalTwinState


class ReplayFrame(BaseModel):
    timestamp: datetime
    state: dict


class ReplayEngine:
    def __init__(self):
        self._frames: list[ReplayFrame] = []

    def capture(self, state: DigitalTwinState) -> None:
        self._frames.append(ReplayFrame(timestamp=state.as_of, state=state.snapshot()))

    def frames_between(self, start: datetime, end: datetime) -> list[ReplayFrame]:
        return [f for f in self._frames if start <= f.timestamp <= end]

    def latest(self) -> ReplayFrame | None:
        return self._frames[-1] if self._frames else None

    def frame_at_index(self, index: int) -> ReplayFrame:
        return self._frames[index]

    def __len__(self) -> int:
        return len(self._frames)
