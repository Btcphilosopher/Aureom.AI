"""Site digital twin: real-time-style entity state, telemetry, per-floor
progress tracking, and replay."""
