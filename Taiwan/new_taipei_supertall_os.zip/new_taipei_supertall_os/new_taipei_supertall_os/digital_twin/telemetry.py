"""Telemetry ingestion for the site digital twin: time-series metric
readings from cranes, hoists, sensors, weather stations, etc."""

from __future__ import annotations

from datetime import datetime, timezone

from pydantic import BaseModel, Field


class TelemetryEvent(BaseModel):
    entity_id: str
    metric: str
    value: float
    unit: str = ""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class TelemetryStore:
    def __init__(self):
        self._events: list[TelemetryEvent] = []

    def record(self, event: TelemetryEvent) -> None:
        self._events.append(event)

    def latest(self, entity_id: str, metric: str) -> TelemetryEvent | None:
        matches = [e for e in self._events if e.entity_id == entity_id and e.metric == metric]
        return max(matches, key=lambda e: e.timestamp) if matches else None

    def series(self, entity_id: str, metric: str) -> list[TelemetryEvent]:
        return sorted([e for e in self._events if e.entity_id == entity_id and e.metric == metric],
                      key=lambda e: e.timestamp)

    def as_dataframe_records(self) -> list[dict]:
        return [e.model_dump(mode="json") for e in self._events]
