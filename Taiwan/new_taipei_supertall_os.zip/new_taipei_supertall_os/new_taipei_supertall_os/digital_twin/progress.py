"""Per-floor construction progress digital twin (spec section 46).

Example (from the spec):
    Floor 37
    Structure: 82%
    Facade: 41%
    MEP: 27%
    Overall: 53%
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from new_taipei_supertall_os.domain.floor import Floor


class FloorProgress(BaseModel):
    floor_number: int
    planned_progress_pct: float
    actual_progress_pct: float

    @property
    def variance_pct(self) -> float:
        return round(self.actual_progress_pct - self.planned_progress_pct, 1)

    @property
    def status(self) -> str:
        if self.variance_pct >= -1:
            return "on_track"
        if self.variance_pct >= -10:
            return "slightly_behind"
        return "behind"


class ConstructionDigitalTwin(BaseModel):
    project_id: str
    floors: dict[int, Floor] = Field(default_factory=dict)
    planned_progress_by_floor: dict[int, float] = Field(default_factory=dict)

    def load_floors(self, floors: list[Floor]) -> None:
        self.floors = {f.number: f for f in floors}

    def set_planned(self, floor_number: int, planned_pct: float) -> None:
        self.planned_progress_by_floor[floor_number] = planned_pct

    def floor_progress(self, floor_number: int) -> FloorProgress:
        floor = self.floors[floor_number]
        planned = self.planned_progress_by_floor.get(floor_number, floor.overall_progress_pct)
        return FloorProgress(floor_number=floor_number, planned_progress_pct=round(planned, 1),
                              actual_progress_pct=floor.overall_progress_pct)

    def all_floor_progress(self) -> list[FloorProgress]:
        return [self.floor_progress(n) for n in sorted(self.floors)]

    def overall_progress_pct(self) -> float:
        rows = self.all_floor_progress()
        if not rows:
            return 0.0
        return round(sum(r.actual_progress_pct for r in rows) / len(rows), 1)

    def floors_behind(self, threshold_pct: float = -10.0) -> list[FloorProgress]:
        return [r for r in self.all_floor_progress() if r.variance_pct <= threshold_pct]

    def detail_report(self, floor_number: int) -> dict:
        floor = self.floors[floor_number]
        return {
            "floor": floor_number,
            "structure_pct": floor.progress_structure_pct,
            "facade_pct": floor.progress_facade_pct,
            "mep_pct": floor.progress_mep_pct,
            "interiors_pct": floor.progress_interiors_pct,
            "overall_pct": floor.overall_progress_pct,
        }
