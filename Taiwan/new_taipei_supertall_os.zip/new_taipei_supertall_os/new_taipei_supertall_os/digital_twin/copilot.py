"""AI construction copilot (spec section 58).

Every answer cites the underlying computed data it was drawn from
(schedule / simulation / optimisation / cost objects passed in via
``ProjectContext``) — nothing here fabricates site data. This is a
deterministic, rule-based question router, not a language model; it can
be wired to an LLM later as long as that LLM is constrained to only
summarise the ``citations`` payload returned here, not invent new facts.
"""

from __future__ import annotations

from pydantic import BaseModel

from new_taipei_supertall_os.construction.risk import Risk
from new_taipei_supertall_os.construction.schedule import ProjectSchedule
from new_taipei_supertall_os.digital_twin.progress import ConstructionDigitalTwin
from new_taipei_supertall_os.finance.cost import CostEstimate
from new_taipei_supertall_os.finance.procurement import ProcurementStatus
from new_taipei_supertall_os.optimisation.cranes import CraneOptimizationResult
from new_taipei_supertall_os.simulation.engine import SimulationResult
from new_taipei_supertall_os.simulation.scenarios import ScenarioResult


class ProjectContext(BaseModel):
    """Bundles the live computed objects the copilot is allowed to cite."""
    schedule: ProjectSchedule
    simulation: SimulationResult | None = None
    cost_estimate: CostEstimate | None = None
    top_risks: list[Risk] = []
    digital_twin: ConstructionDigitalTwin | None = None
    procurement_urgency: list[ProcurementStatus] = []
    crane_result: CraneOptimizationResult | None = None
    typhoon_scenario: ScenarioResult | None = None

    model_config = {"arbitrary_types_allowed": True}


class CopilotAnswer(BaseModel):
    question: str
    answer: str
    citations: dict


class ConstructionCopilot:
    def ask(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        q = question.strip()
        handlers = [
            (("關鍵路徑", "critical path"), self._critical_path),
            (("拖慢", "落後", "lagging", "delay"), self._lagging_phase),
            (("塔吊", "利用率", "crane utilisation", "crane utilization"), self._crane_utilisation),
            (("延誤", "material", "材料"), self._material_delay_risk),
            (("增加一台塔吊", "extra crane"), self._extra_crane),
            (("成本風險", "cost risk"), self._cost_risk),
            (("樓層", "落後", "floor behind"), self._floor_behind),
            (("颱風", "typhoon"), self._typhoon),
            (("採購", "procurement"), self._urgent_procurement),
        ]
        for keywords, handler in handlers:
            if any(k in q for k in keywords):
                return handler(question, ctx)
        return CopilotAnswer(question=question, answer="No matching computed data source for this question yet — "
                              "extend ConstructionCopilot with a handler backed by real project data.", citations={})

    def _critical_path(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        cp = ctx.schedule.critical_path
        answer = (f"The current critical path has {len(cp)} activities, ending at day "
                   f"{ctx.schedule.duration_days}. Critical tasks: {', '.join(cp[:8])}"
                   f"{'...' if len(cp) > 8 else ''}.")
        return CopilotAnswer(question=question, answer=answer,
                              citations={"schedule.critical_path": cp, "schedule.duration_days": ctx.schedule.duration_days})

    def _lagging_phase(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        crit_tasks = [t for t in ctx.schedule.tasks if t.id in ctx.schedule.critical_path]
        if not crit_tasks:
            return CopilotAnswer(question=question, answer="No critical-path data available yet.", citations={})
        worst = max(crit_tasks, key=lambda t: t.duration_days)
        answer = f"The phase most driving the overall duration is '{worst.phase}' ({worst.name}), {worst.duration_days} days, on the critical path."
        return CopilotAnswer(question=question, answer=answer, citations={"task": worst.model_dump()})

    def _crane_utilisation(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        if ctx.simulation is None:
            return CopilotAnswer(question=question, answer="No simulation result available yet.", citations={})
        answer = f"Average simulated crane utilisation is {ctx.simulation.average_crane_utilisation:.1%} across {ctx.simulation.n_trials} trials."
        return CopilotAnswer(question=question, answer=answer, citations={"simulation": ctx.simulation.model_dump()})

    def _material_delay_risk(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        if not ctx.procurement_urgency:
            return CopilotAnswer(question=question, answer="No procurement tracking data loaded.", citations={})
        worst = ctx.procurement_urgency[0]
        answer = (f"'{worst.material.name}' is the material most likely to cause delay: status={worst.risk}, "
                   f"required on site {worst.required_on_site_date}, latest order date {worst.latest_order_date}.")
        return CopilotAnswer(question=question, answer=answer, citations={"procurement_status": worst.model_dump()})

    def _extra_crane(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        if ctx.typhoon_scenario is None:
            return CopilotAnswer(question=question, answer="Run ScenarioEngine.what_if_extra_crane() and pass the result to answer this precisely.", citations={})
        answer = f"Per the computed scenario: {ctx.typhoon_scenario.description} -> duration changes by {ctx.typhoon_scenario.duration_delta_days} days."
        return CopilotAnswer(question=question, answer=answer, citations={"scenario": ctx.typhoon_scenario.model_dump()})

    def _cost_risk(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        if ctx.cost_estimate is None or not ctx.top_risks:
            return CopilotAnswer(question=question, answer="No cost estimate / risk register loaded.", citations={})
        worst_risk = max(ctx.top_risks, key=lambda r: r.risk_score)
        answer = (f"Total estimated cost is NT${ctx.cost_estimate.total_twd:,.0f}. The largest cost-related risk is "
                   f"'{worst_risk.description}' (score {worst_risk.risk_score}, exposure NT${worst_risk.exposure_twd:,.0f}).")
        return CopilotAnswer(question=question, answer=answer,
                              citations={"cost_total_twd": ctx.cost_estimate.total_twd, "risk": worst_risk.model_dump()})

    def _floor_behind(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        if ctx.digital_twin is None:
            return CopilotAnswer(question=question, answer="No digital twin progress data loaded.", citations={})
        behind = ctx.digital_twin.floors_behind()
        if not behind:
            return CopilotAnswer(question=question, answer="No floors currently flagged behind plan.", citations={})
        worst = min(behind, key=lambda r: r.variance_pct)
        answer = f"Floor {worst.floor_number} is furthest behind plan: {worst.variance_pct} pp variance (planned {worst.planned_progress_pct}%, actual {worst.actual_progress_pct}%)."
        return CopilotAnswer(question=question, answer=answer, citations={"floor_progress": worst.model_dump()})

    def _typhoon(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        if ctx.typhoon_scenario is None:
            return CopilotAnswer(question=question, answer="Run ScenarioEngine.what_if_typhoon_downtime() and pass the result to answer this.", citations={})
        s = ctx.typhoon_scenario
        answer = f"Under this typhoon scenario, completion shifts by {s.duration_delta_days} days (baseline {s.baseline_duration_days} -> {s.scenario_duration_days} days)."
        return CopilotAnswer(question=question, answer=answer, citations={"scenario": s.model_dump()})

    def _urgent_procurement(self, question: str, ctx: ProjectContext) -> CopilotAnswer:
        if not ctx.procurement_urgency:
            return CopilotAnswer(question=question, answer="No procurement tracking data loaded.", citations={})
        worst = ctx.procurement_urgency[0]
        answer = f"The most urgent procurement item is '{worst.material.name}' — risk status: {worst.risk}."
        return CopilotAnswer(question=question, answer=answer, citations={"procurement_status": worst.model_dump()})
