"""NEW TAIPEI SUPERTALL CONSTRUCTION OS — example CLI entry point
(spec sections 63, 64).

    SIMULATION ONLY / 模擬專案 — NT-SUPERTALL-001 is a synthetic
    demonstration project. Nothing produced by this script is a real
    engineering design, cost, or schedule for an actual building.

Run:
    python app.py
"""

from __future__ import annotations

from new_taipei_supertall_os.compliance.approvals import build_compliance_dashboard
from new_taipei_supertall_os.compliance.new_taipei import NewTaipeiPlanningRules
from new_taipei_supertall_os.compliance.planning import UrbanDesignReviewEngine
from new_taipei_supertall_os.config.settings import get_settings
from new_taipei_supertall_os.construction.concrete import ConcreteEngine
from new_taipei_supertall_os.construction.risk import ConstructionRiskEngine
from new_taipei_supertall_os.domain.building import Building, MassingEngine
from new_taipei_supertall_os.domain.excavation import ExcavationModel
from new_taipei_supertall_os.domain.structural import StructuralSystemType
from new_taipei_supertall_os.engineering.excavation_model import ExcavationRiskEngine
from new_taipei_supertall_os.finance.cost import ConstructionCostEngine, cost_per_floor, cost_per_m2
from new_taipei_supertall_os.optimisation.multiobjective import SupertallOptimizer
from new_taipei_supertall_os.optimisation.schedule import ScheduleOptimizer
from new_taipei_supertall_os.simulation.engine import ConstructionSimulation


def main() -> None:
    building = Building(
        id="NT-SUPERTALL-001",
        name="New Taipei Demonstration Tower",
        city="New Taipei City",
        height_m=420,
        floors=92,
        basement_floors=6,
        gross_floor_area_m2=250000,
        site_area_m2=18000,
        structural_system="composite_frame",
        foundation_type="piled_raft",
        use_mix={
            "commercial": 0.25,
            "office": 0.40,
            "residential": 0.25,
            "hotel": 0.10,
        },
    )

    print("=" * 60)
    print("NEW TAIPEI SUPERTALL CONSTRUCTION OS")
    print("新北超高層建築智慧施工作業系統")
    print("=" * 60)
    print("SIMULATION ONLY / 模擬專案 — demonstration project, not a real building.")
    print()
    print(f"Project: {building.name}")
    print(f"Height: {building.height_m} m")
    print(f"Floors: {building.floors}")
    print(f"Basements: {building.basement_floors}")
    print(f"Gross floor area: {building.gross_floor_area_m2:,.0f} m2")

    optimizer = ScheduleOptimizer()
    schedule = optimizer.optimize(building)

    print()
    print("OPTIMISED PROGRAMME")
    print("=" * 60)
    print(f"Estimated duration: {schedule.duration_days:,.0f} days "
          f"(~{schedule.duration_days / 365:.1f} years)")
    print(f"Critical activities: {len(schedule.critical_path)}")

    simulation = ConstructionSimulation(building)
    result = simulation.run(days=schedule.duration_days, speed=10)

    print()
    print("SIMULATION")
    print("=" * 60)
    print(f"Completion probability by target date: {result.completion_probability:.1%}")
    print(f"Average tower-crane utilisation: {result.average_crane_utilisation:.1%}")
    print(f"P50 / P80 / P90 structural-frame duration: "
          f"{result.p50_days:.0f} / {result.p80_days:.0f} / {result.p90_days:.0f} days")

    # --- cost -----------------------------------------------------------
    settings = get_settings()
    massing = MassingEngine().generate(building)
    above_grade = [f for f in massing.floors if f.number > 0]
    system = StructuralSystemType(building.structural_system)
    ce = ConcreteEngine()
    pours = [ce.plan_pour(f, "slab", ce.floor_slab_volume_m3(f) * system.relative_concrete_m3_per_m2 / 0.55)
             for f in above_grade]
    cost_estimate = ConstructionCostEngine(settings).estimate(building, massing.floors, pours)

    print()
    print("COST (preliminary, generated from configurable rates)")
    print("=" * 60)
    print(f"Estimated total cost: NT$ {cost_estimate.total_twd / 1e9:,.2f} billion")
    print(f"Cost per m2 GFA: NT$ {cost_per_m2(cost_estimate, building.gross_floor_area_m2):,.0f}/m2")
    print(f"Cost per floor: NT$ {cost_per_floor(cost_estimate, building.floors) / 1e6:,.1f} million")

    # --- risk -------------------------------------------------------------
    risk_engine = ConstructionRiskEngine()
    risks = risk_engine.demo_risk_register()
    top_risks = risk_engine.top_risks(risks, n=3)

    print()
    print("TOP RISKS (illustrative baseline register)")
    print("=" * 60)
    for r in top_risks:
        print(f"- [{r.category.value}] {r.description} (score={r.risk_score})")

    # --- compliance ---------------------------------------------------
    excavation = ExcavationModel(excavation_depth_m=32, excavation_area_m2=building.site_area_m2 * 0.85,
                                  basement_levels=building.basement_floors)
    triggers = NewTaipeiPlanningRules().evaluate(building, excavation, [], max_structural_span_m=18)
    dashboard = build_compliance_dashboard(building.id, triggers)
    udr = UrbanDesignReviewEngine().assess(building.site_area_m2, building.gross_floor_area_m2, building.height_m)

    print()
    print("COMPLIANCE TRIGGERS (flags for professional/regulatory review only)")
    print("=" * 60)
    for cat, status in dashboard.by_category().items():
        print(f"- {cat}: {status}")
    print(f"Urban design review required: {udr.review_required}")

    exc_risk = ExcavationRiskEngine().assess(excavation, [])
    print(f"Excavation risk (auto-flag only): {exc_risk.overall_level.value}")

    # --- multi-objective optimisation -----------------------------------
    print()
    print("MULTI-OBJECTIVE OPTIMISATION")
    print("=" * 60)
    supertall_optimizer = SupertallOptimizer(settings)
    plans = supertall_optimizer.generate_plans(building)
    for plan in plans:
        print(f"\n{plan.label.value}")
        print(f"  Construction duration: {plan.duration_days:,.0f} days")
        print(f"  Estimated cost (P50/P80): NT$ {plan.cost_p50_twd / 1e9:,.1f}bn / "
              f"NT$ {plan.cost_p80_twd / 1e9:,.1f}bn")
        print(f"  Carbon: {plan.carbon_kgco2e / 1e6:,.1f} kt CO2e")
        print(f"  Crane utilisation: {plan.crane_utilisation_estimate:.0%}")
        print(f"  Peak workforce: {plan.peak_workforce_estimate:,}")
        print(f"  Primary bottleneck: {plan.primary_bottleneck}")
    dominant = supertall_optimizer.dominant_plan(plans)
    print(f"\nDominant plan (balanced normalised ranking): {dominant.label.value}")

    print()
    print("=" * 60)
    print("Reminder: all structural, geotechnical and cost figures above are")
    print("PRELIMINARY ENGINEERING ESTIMATES for planning/optimisation purposes")
    print("only, and require independent verification by qualified, licensed")
    print("professionals before any real design or construction decision.")
    print("=" * 60)


if __name__ == "__main__":
    main()
