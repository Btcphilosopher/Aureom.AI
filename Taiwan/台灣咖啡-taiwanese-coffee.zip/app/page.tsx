'use client';

import React from 'react';
import { TopUtilityBar } from '@/components/navigation/TopUtilityBar';
import { MainNav } from '@/components/navigation/MainNav';
import { MobileBottomNav } from '@/components/navigation/MobileBottomNav';
import { HeroSection } from '@/components/hero/HeroSection';
import { FeaturesStrip } from '@/components/features/FeaturesStrip';
import { MenuSection } from '@/components/menu/MenuSection';
import { FarmStorySection } from '@/components/story/FarmStorySection';
import { StoresSection } from '@/components/stores/StoresSection';
import { LoyaltySection } from '@/components/loyalty/LoyaltySection';
import { ArticlesSection } from '@/components/articles/ArticlesSection';
import { Footer } from '@/components/footer/Footer';

// Modals & Interactive Overlays
import { WifiModal } from '@/components/wifi/WifiModal';
import { SignatureStoryModal } from '@/components/hero/SignatureStoryModal';
import { ProductDetailModal } from '@/components/menu/ProductDetailModal';
import { CartDrawer } from '@/components/order/CartDrawer';
import { OrderTrackerModal } from '@/components/order/OrderTrackerModal';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F3] dark:bg-[#121714] text-[#1F2421] dark:text-[#E8EAE8] transition-colors duration-300">
      {/* Top Utility Bar */}
      <TopUtilityBar />

      {/* Main Sticky Navigation */}
      <MainNav />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Cinematic Hero Section */}
        <HeroSection />

        {/* 2. Four-Card Service Features Strip */}
        <FeaturesStrip />

        {/* 3. Recommended Highlights & Full Digital Menu */}
        <MenuSection />

        {/* 4. Coffee Origins & Terroir Story */}
        <FarmStorySection />

        {/* 5. Store Locations & Space Atmosphere */}
        <StoresSection />

        {/* 6. Loyalty Program & Member Card */}
        <LoyaltySection />

        {/* 7. Editorial Magazine & Coffee Articles */}
        <ArticlesSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Sticky Bottom Nav (Hidden on Desktop) */}
      <MobileBottomNav />

      {/* Global Interactive Overlays */}
      <WifiModal />
      <SignatureStoryModal />
      <ProductDetailModal />
      <CartDrawer />
      <OrderTrackerModal />
    </div>
  );
}
