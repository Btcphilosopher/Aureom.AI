import type { Metadata } from 'next';
import './globals.css';
import { AppProvider } from '@/context/AppContext';

export const metadata: Metadata = {
  title: '台灣咖啡 | TAIWANESE COFFEE — Artisanal Coffee & Digital Café Experience',
  description:
    '嚴選台灣在地咖啡豆，職人用心烘焙。體驗頂級台灣精品手沖、高速免費Wi-Fi、數位點餐與會員禮遇。',
  openGraph: {
    title: '台灣咖啡 | TAIWANESE COFFEE',
    description:
      '嚴選台灣在地咖啡豆，職人用心烘焙。體驗頂級台灣精品手沖、高速免費Wi-Fi、數位點餐與會員禮遇。',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: '台灣咖啡 | TAIWANESE COFFEE',
    description:
      '嚴選台灣在地咖啡豆，職人用心烘焙。體驗頂級台灣精品手沖、高速免費Wi-Fi、數位點餐與會員禮遇。',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-TW" className="scroll-smooth" suppressHydrationWarning>
      <body suppressHydrationWarning className="antialiased min-h-screen">
        <AppProvider>{children}</AppProvider>
      </body>
    </html>
  );
}
