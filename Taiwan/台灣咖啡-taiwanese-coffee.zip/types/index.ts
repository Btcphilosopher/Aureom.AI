export type Language = 'zh-TW' | 'en';
export type ThemeMode = 'light' | 'dark';

export type ProductCategory =
  | 'all'
  | 'coffee'
  | 'tea'
  | 'cold_drinks'
  | 'desserts'
  | 'dessert'
  | 'beverage'
  | 'breakfast'
  | 'light_bites';

export interface Product {
  id: string;
  nameZh: string;
  nameEn: string;
  category: string;
  price: number;
  descriptionZh: string;
  descriptionEn: string;
  image: string;
  originZh?: string;
  originEn?: string;
  roastLevelZh?: string;
  roastLevelEn?: string;
  tastingNotesZh?: string[];
  tastingNotesEn?: string[];
  allowHotIced?: boolean;
  defaultTemp?: 'hot' | 'iced';
  sizes?: ('regular' | 'large')[];
  milkOptions?: boolean;
  sugarOptions?: boolean;
  iceOptions?: boolean;
  featured?: boolean;
  tagZh?: string;
  tagEn?: string;
  awardZh?: string;
  awardEn?: string;
  badgeZh?: string;
  badgeEn?: string;
}

export interface CartItem {
  cartItemId: string;
  product: Product;
  quantity: number;
  temperature?: 'hot' | 'iced';
  size: 'regular' | 'large';
  milk?: 'whole' | 'oat' | 'soy' | 'almond' | 'none';
  sugar?: 'regular' | 'half' | 'quarter' | 'none';
  ice?: 'regular' | 'less' | 'none';
  beanType?: 'house' | 'single_origin_alishan';
  unitPrice: number;
  totalPrice: number;
  specialInstructions?: string;
}

export type OrderStatus =
  | 'confirmed'
  | 'preparing'
  | 'grinding'
  | 'brewing'
  | 'almost_ready'
  | 'ready';

export interface Order {
  id: string;
  orderNumber: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  total: number;
  storeId: string;
  storeNameZh: string;
  storeNameEn: string;
  diningOption: 'dine_in' | 'takeaway';
  orderType?: 'dine_in' | 'takeaway';
  tableNumber?: string;
  pickupCode?: string;
  status: OrderStatus;
  estimatedMinutes: number;
  estimatedMinutesRemaining?: number;
  createdAt: number;
  pointsEarned: number;
}

export interface Store {
  id: string;
  nameZh: string;
  nameEn: string;
  districtZh: string;
  districtEn: string;
  addressZh: string;
  addressEn: string;
  descriptionZh?: string;
  descriptionEn?: string;
  hoursZh: string;
  hoursEn: string;
  openingHoursZh?: string;
  openingHoursEn?: string;
  phone: string;
  image: string;
  seatsAvailablePercent: number;
  seats?: number;
  wifiSpeed?: string;
  isFlagship?: boolean;
  featuresZh?: string[];
  featuresEn?: string[];
  services: {
    wifi: boolean;
    takeaway: boolean;
    seating: boolean;
    powerOutlets: boolean;
    pourOverBar: boolean;
    petFriendly: boolean;
  };
  coordinates: {
    lat: number;
    lng: number;
  };
}

export type StoreLocation = Store;

export interface Article {
  id: string;
  titleZh: string;
  titleEn: string;
  subtitleZh: string;
  subtitleEn: string;
  readTimeZh: string;
  readTimeEn: string;
  categoryZh: string;
  categoryEn: string;
  image: string;
  publishedDate: string;
  contentZh: string[];
  contentEn: string[];
}

export interface CoffeeOrigin {
  id: string;
  nameZh: string;
  nameEn: string;
  countyZh: string;
  countyEn: string;
  altitude: string;
  climateZh: string;
  climateEn: string;
  variety: string;
  tastingNotesZh: string;
  tastingNotesEn: string;
  farmStoryZh: string;
  farmStoryEn: string;
  mapCoords: { x: number; y: number }; // percentage on Taiwan map
  regionZh?: string;
  regionEn?: string;
  farmZh?: string;
  farmEn?: string;
  processZh?: string;
  processEn?: string;
  descriptionZh?: string;
  descriptionEn?: string;
  image?: string;
  flavorNotesZh?: string[];
  flavorNotesEn?: string[];
}

export interface WifiSession {
  isConnected: boolean;
  phoneNumber?: string;
  connectedAt?: number;
  ipAddress?: string;
  ssid: string;
  signalStrength: 'excellent' | 'good' | 'fair';
  speedMbps: number;
  termsAccepted: boolean;
}

export interface LoyaltyMember {
  memberId: string;
  memberName?: string;
  memberNumber?: string;
  tier: 'SILVER' | 'GOLD' | 'PLATINUM';
  tierZh?: string;
  tierEn?: string;
  tierNameZh: string;
  tierNameEn: string;
  points: number;
  nextRewardThreshold: number;
  stampsCount: number; // 0 to 10
  visitsCount: number;
  favouriteDrinkZh: string;
  favouriteDrinkEn: string;
  availableRewards: {
    id: string;
    nameZh: string;
    nameEn: string;
    pointsCost: number;
    descriptionZh: string;
    descriptionEn: string;
  }[];
}
