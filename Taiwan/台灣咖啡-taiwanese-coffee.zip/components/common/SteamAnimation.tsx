'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';

export const SteamAnimation: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { reducedMotion } = useApp();

  if (reducedMotion) {
    return null;
  }

  return (
    <div
      className={`pointer-events-none absolute inset-x-0 -top-24 h-36 overflow-hidden flex justify-center items-end opacity-70 mix-blend-screen ${className}`}
      aria-hidden="true"
    >
      <svg
        className="w-48 h-40 transform -translate-y-2"
        viewBox="0 0 160 140"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="steamGrad1" x1="0%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
            <stop offset="40%" stopColor="#FFF8EE" stopOpacity="0.45" />
            <stop offset="80%" stopColor="#FFFFFF" stopOpacity="0.15" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="steamGrad2" x1="0%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0" />
            <stop offset="35%" stopColor="#FFF4E0" stopOpacity="0.4" />
            <stop offset="75%" stopColor="#FFFFFF" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
          <filter id="steamBlur" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3.5" />
          </filter>
        </defs>

        {/* Wisp 1 */}
        <path
          d="M72 135 C68 115, 82 95, 74 70 C66 45, 85 25, 78 5"
          stroke="url(#steamGrad1)"
          strokeWidth="10"
          strokeLinecap="round"
          filter="url(#steamBlur)"
          className="animate-steam-1"
        />

        {/* Wisp 2 */}
        <path
          d="M84 135 C90 110, 75 90, 88 65 C96 40, 78 20, 86 5"
          stroke="url(#steamGrad2)"
          strokeWidth="12"
          strokeLinecap="round"
          filter="url(#steamBlur)"
          className="animate-steam-2"
        />

        {/* Wisp 3 */}
        <path
          d="M60 135 C55 112, 65 92, 58 72 C50 50, 68 30, 62 10"
          stroke="url(#steamGrad1)"
          strokeWidth="8"
          strokeLinecap="round"
          filter="url(#steamBlur)"
          className="animate-steam-3"
        />
      </svg>
    </div>
  );
};
