'use client';

import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'dark' | 'light' | 'gold';
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  variant = 'dark',
  showText = true,
}) => {
  const sizeMap = {
    sm: { circle: 'w-8 h-8 text-sm', textMain: 'text-base', textSub: 'text-[9px]' },
    md: { circle: 'w-10 h-10 text-lg', textMain: 'text-lg', textSub: 'text-[10px]' },
    lg: { circle: 'w-14 h-14 text-2xl', textMain: 'text-xl', textSub: 'text-xs' },
    xl: { circle: 'w-20 h-20 text-3xl', textMain: 'text-2xl', textSub: 'text-sm' },
  };

  const currentSize = sizeMap[size];

  const colorStyles = {
    dark: {
      border: 'border-[#1C3328] dark:border-[#E8E1D3]',
      char: 'text-[#1C3328] dark:text-[#E8E1D3]',
      sub: 'text-[#1C3328]/70 dark:text-[#E8E1D3]/70',
      title: 'text-[#1C3328] dark:text-[#F7F4EE]',
    },
    light: {
      border: 'border-[#F7F4EE]',
      char: 'text-[#F7F4EE]',
      sub: 'text-[#F7F4EE]/80',
      title: 'text-[#F7F4EE]',
    },
    gold: {
      border: 'border-[#C5A475]',
      char: 'text-[#C5A475]',
      sub: 'text-[#C5A475]/80',
      title: 'text-[#C5A475]',
    },
  }[variant];

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Circular 啡 Seal Logo */}
      <div className="flex flex-col items-center">
        <div
          className={`${currentSize.circle} rounded-full border-[1.5px] ${colorStyles.border} flex items-center justify-center font-serif font-medium tracking-normal transition-transform duration-300 hover:scale-105 shadow-xs`}
          style={{ fontFamily: '"Noto Serif TC", "Songti TC", "Cinzel", serif' }}
        >
          <span className={`${colorStyles.char} leading-none pt-0.5`}>啡</span>
        </div>
        <span
          className={`mt-0.5 text-[8px] tracking-[0.2em] uppercase font-sans ${colorStyles.sub} font-medium`}
        >
          TAIWAN COFFEE
        </span>
      </div>

      {/* Brand Text */}
      {showText && (
        <div className="flex flex-col justify-center text-left">
          <span
            className={`${currentSize.textMain} font-serif font-bold tracking-wider leading-tight ${colorStyles.title}`}
            style={{ fontFamily: '"Noto Serif TC", "Songti TC", "Cinzel", serif' }}
          >
            台灣咖啡
          </span>
          <span
            className={`${currentSize.textSub} font-sans tracking-[0.18em] uppercase ${colorStyles.sub} font-semibold`}
          >
            TAIWANESE COFFEE SHOP
          </span>
        </div>
      )}
    </div>
  );
};
