'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Coffee, Award, Wifi, Armchair } from 'lucide-react';

export const FeaturesStrip: React.FC = () => {
  const { t } = useApp();

  const features = [
    {
      id: 'feat_beans',
      icon: Coffee,
      titleZh: t.feat1Title,
      titleEn: t.feat1Sub,
      descZh: '支持在地小農，品質保證',
      descEn: 'Support local farmers',
    },
    {
      id: 'feat_barista',
      icon: Award,
      titleZh: t.feat2Title,
      titleEn: t.feat2Sub,
      descZh: '專業沖煮，完美呈現',
      descEn: 'Brewed to perfection',
    },
    {
      id: 'feat_wifi',
      icon: Wifi,
      titleZh: t.feat3Title,
      titleEn: t.feat3Sub,
      descZh: '不限時使用，連結世界',
      descEn: 'Stay connected',
    },
    {
      id: 'feat_space',
      icon: Armchair,
      titleZh: t.feat4Title,
      titleEn: t.feat4Sub,
      descZh: '放鬆、工作、閱讀的好地方',
      descEn: 'Relax, work, read',
    },
  ];

  return (
    <section
      id="features"
      className="w-full bg-[#FAF8F3] dark:bg-[#121714] border-t border-b border-[#EFE9DC] dark:border-[#1E2922] py-8 sm:py-10 transition-colors"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {features.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.id}
                className="flex items-center sm:items-start gap-4 p-4 rounded-xl hover:bg-[#F3EFE6] dark:hover:bg-[#1A251F] transition-colors duration-200 group"
              >
                {/* Icon Container */}
                <div className="w-12 h-12 rounded-full border border-[#1C3328]/20 dark:border-[#C5A475]/30 flex items-center justify-center text-[#1C3328] dark:text-[#C5A475] shrink-0 group-hover:scale-105 group-hover:bg-[#1C3328] group-hover:text-white dark:group-hover:bg-[#284839] transition-all">
                  <Icon className="w-5 h-5" />
                </div>

                {/* Content */}
                <div className="flex flex-col text-left">
                  <h4 className="text-sm font-serif font-bold text-[#1F2421] dark:text-[#F7F4EE] leading-tight">
                    {item.titleZh}
                  </h4>
                  <span className="text-[10px] font-sans font-semibold tracking-wider text-[#717E77] dark:text-[#97A59E] uppercase leading-tight mb-1">
                    {item.titleEn}
                  </span>
                  <p className="text-xs text-[#55635C] dark:text-[#B4C0B9] leading-snug">
                    {item.descZh}
                  </p>
                  <span className="text-[10px] text-[#8E9B94] dark:text-[#7A8A80] font-sans">
                    {item.descEn}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
