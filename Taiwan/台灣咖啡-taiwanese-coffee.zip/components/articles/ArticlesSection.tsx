'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { articlesData } from '@/data/articlesData';
import { Article } from '@/types';
import { BookOpen, Clock, X, ArrowRight } from 'lucide-react';

export const ArticlesSection: React.FC = () => {
  const { t, lang } = useApp();
  const [readingArticle, setReadingArticle] = useState<Article | null>(null);

  return (
    <section
      id="coffee-life"
      className="w-full bg-[#FAF8F3] dark:bg-[#121714] py-14 sm:py-20 transition-colors"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EFE9DD] dark:bg-[#1E2922] text-[#1C3328] dark:text-[#C5A475] text-xs font-serif font-medium mb-3">
            <BookOpen className="w-3.5 h-3.5" />
            <span>季刊《啡語》第 04 期</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
            {t.articlesTitle}
          </h2>
          <p className="text-xs sm:text-sm font-sans tracking-widest text-[#717E77] dark:text-[#97A59E] uppercase font-semibold mt-1">
            {t.articlesSubtitle}
          </p>
          <div className="w-12 h-[2px] bg-[#1C3328] dark:bg-[#C5A475] mt-3" />
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {articlesData.map((article) => (
            <article
              key={article.id}
              onClick={() => setReadingArticle(article)}
              className="group bg-white dark:bg-[#18231D] rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-[#E8E2D5] dark:border-[#283C30] transition-all duration-300 flex flex-col justify-between cursor-pointer"
            >
              <div>
                <div className="relative w-full h-52 overflow-hidden bg-[#2C1D11]">
                  <Image
                    src={article.image}
                    alt={article.titleZh}
                    fill
                    sizes="(max-width: 768px) 100vw, 400px"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs text-white text-[10px] font-sans font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    {lang === 'zh-TW' ? article.categoryZh : article.categoryEn}
                  </div>
                </div>

                <div className="p-6 text-left">
                  <div className="flex items-center gap-2 text-xs text-[#717E77] dark:text-[#97A59E] mb-2 font-mono">
                    <Clock className="w-3.5 h-3.5 text-[#C5A475]" />
                    <span>{lang === 'zh-TW' ? article.readTimeZh : article.readTimeEn}</span>
                    <span>•</span>
                    <span>{article.publishedDate}</span>
                  </div>

                  <h3 className="text-base sm:text-lg font-serif font-bold text-[#1F2421] dark:text-[#F7F4EE] group-hover:text-[#1C3328] dark:group-hover:text-[#C5A475] transition-colors leading-snug">
                    {lang === 'zh-TW' ? article.titleZh : article.titleEn}
                  </h3>

                  <p className="text-xs text-[#55635C] dark:text-[#A0B0A7] line-clamp-3 leading-relaxed mt-2.5">
                    {lang === 'zh-TW' ? article.subtitleZh : article.subtitleEn}
                  </p>
                </div>
              </div>

              <div className="p-6 pt-0 text-left">
                <span className="text-xs font-serif font-semibold text-[#1C3328] dark:text-[#C5A475] inline-flex items-center gap-1 group-hover:underline">
                  <span>閱讀全文 READ ARTICLE</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Article Reader Modal */}
      {readingArticle && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) setReadingArticle(null);
          }}
        >
          <div className="w-full max-w-2xl max-h-[85vh] bg-[#FAF8F3] dark:bg-[#16211B] rounded-3xl shadow-2xl border border-[#E8E2D5] dark:border-[#283C30] overflow-hidden flex flex-col">
            <div className="relative w-full h-56 shrink-0 bg-[#2C1D11]">
              <Image
                src={readingArticle.image}
                alt={readingArticle.titleZh}
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <button
                onClick={() => setReadingArticle(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white cursor-pointer"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-4 left-6 right-6 text-white">
                <span className="text-xs font-sans tracking-widest text-[#C5A475] uppercase font-bold">
                  {lang === 'zh-TW' ? readingArticle.categoryZh : readingArticle.categoryEn} •{' '}
                  {lang === 'zh-TW' ? readingArticle.readTimeZh : readingArticle.readTimeEn}
                </span>
                <h2 className="text-xl sm:text-2xl font-serif font-bold">
                  {lang === 'zh-TW' ? readingArticle.titleZh : readingArticle.titleEn}
                </h2>
              </div>
            </div>

            <div className="p-6 sm:p-8 overflow-y-auto text-left space-y-4 text-sm text-[#3E4742] dark:text-[#CBD5CF] leading-relaxed">
              <p className="font-serif italic text-base text-[#1C3328] dark:text-[#C5A475] border-l-2 border-[#1C3328] dark:border-[#C5A475] pl-4 py-1">
                {lang === 'zh-TW' ? readingArticle.subtitleZh : readingArticle.subtitleEn}
              </p>
              <div className="space-y-3 font-serif">
                {(lang === 'zh-TW' ? readingArticle.contentZh : readingArticle.contentEn).map(
                  (paragraph, idx) => (
                    <p key={idx}>{paragraph}</p>
                  )
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
