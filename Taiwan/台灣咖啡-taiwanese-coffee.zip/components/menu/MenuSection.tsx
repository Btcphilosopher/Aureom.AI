'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { productsData } from '@/data/menuData';
import { ProductCategory, Product } from '@/types';
import { Plus, Coffee, Sparkles, SlidersHorizontal } from 'lucide-react';

export const MenuSection: React.FC = () => {
  const { t, lang, openProductModal, addToCart } = useApp();
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('coffee');

  const categories: { id: ProductCategory; labelZh: string; labelEn: string }[] = [
    { id: 'coffee', labelZh: t.catCoffee, labelEn: 'COFFEE' },
    { id: 'tea', labelZh: t.catTea, labelEn: 'TEA' },
    { id: 'cold_drinks', labelZh: t.catColdDrinks, labelEn: 'SPECIALTY' },
    { id: 'desserts', labelZh: t.catDesserts, labelEn: 'DESSERT' },
    { id: 'light_bites', labelZh: t.catLightBites, labelEn: 'LIGHT BITES' },
  ];

  const recommendedProducts = productsData.filter((p) => p.featured);
  const categoryProducts = productsData.filter((p) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'dessert' || activeCategory === 'desserts') {
      return p.category === 'dessert' || p.category === 'desserts';
    }
    if (activeCategory === 'beverage' || activeCategory === 'cold_drinks') {
      return p.category === 'beverage' || p.category === 'cold_drinks';
    }
    if (activeCategory === 'light_bites') {
      return p.category === 'light_bites' || p.category === 'breakfast';
    }
    return p.category === activeCategory;
  });

  const handleQuickAdd = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation();
    // If product has complex modifiers or sizes, open modal; otherwise quick add
    if (product.milkOptions || product.sizes?.length || product.sugarOptions) {
      openProductModal(product);
    } else {
      addToCart({
        cartItemId: `item_${product.id}_${product.price}`,
        product,
        quantity: 1,
        size: 'regular',
        unitPrice: product.price,
        totalPrice: product.price,
      });
    }
  };

  return (
    <section
      id="menu"
      className="w-full bg-[#FAF8F3] dark:bg-[#121714] py-16 sm:py-24 border-t border-[#E8E2D5] dark:border-[#202E25] transition-colors"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Section Title */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EFE9DD] dark:bg-[#1E2922] text-[#1C3328] dark:text-[#C5A475] text-xs font-serif font-medium mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>精選旬味 • 在地風土</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE] tracking-tight">
            {t.menuTitle}
          </h2>
          <p className="text-xs sm:text-sm font-sans tracking-widest text-[#717E77] dark:text-[#97A59E] uppercase font-semibold mt-1">
            {t.menuSubtitle}
          </p>
          <div className="w-16 h-[2px] bg-[#1C3328] dark:bg-[#C5A475] mt-4" />
        </div>

        {/* 1. RECOMMENDED SECTION (HIGHLIGHTED CARDS) */}
        <div className="mb-16">
          <div className="flex items-center justify-between mb-6 pb-2 border-b border-[#E8E2D5] dark:border-[#283C30]">
            <div>
              <h3 className="text-xl sm:text-2xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
                {t.recommendedTitle}
              </h3>
              <p className="text-xs text-[#717E77] dark:text-[#97A59E] uppercase tracking-wider font-mono">
                {t.recommendedSubtitle}
              </p>
            </div>
            <span className="text-xs font-serif font-semibold text-[#1C3328] dark:text-[#C5A475] hidden sm:inline-block">
              ★ 季節限定與主理人推薦
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {recommendedProducts.map((product) => (
              <div
                key={product.id}
                onClick={() => openProductModal(product)}
                className="group relative bg-white dark:bg-[#18231D] rounded-2xl overflow-hidden border border-[#E8E2D5] dark:border-[#283C30] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer"
              >
                <div>
                  {/* Image container with badge */}
                  <div className="relative w-full h-48 overflow-hidden bg-[#2C1D11]">
                    <Image
                      src={product.image}
                      alt={product.nameZh}
                      fill
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                    />
                    {(product.tagZh || product.featured) && (
                      <div className="absolute top-3 left-3 bg-[#1C3328] text-[#C5A475] text-[10px] font-sans font-bold px-2.5 py-1 rounded-full uppercase tracking-wider shadow-xs">
                        {lang === 'zh-TW' ? product.tagZh || '人氣推薦' : product.tagEn || 'FEATURED'}
                      </div>
                    )}

                    {product.awardZh && (
                      <div className="absolute bottom-2 left-2 right-2 bg-black/65 backdrop-blur-xs text-white text-[10px] px-2 py-0.5 rounded-sm line-clamp-1">
                        🏆 {lang === 'zh-TW' ? product.awardZh : product.awardEn}
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-5 text-left">
                    <div className="flex items-baseline justify-between mb-1">
                      <h4 className="text-base font-serif font-bold text-[#1F2421] dark:text-[#F7F4EE] group-hover:text-[#1C3328] dark:group-hover:text-[#C5A475] transition-colors line-clamp-1">
                        {lang === 'zh-TW' ? product.nameZh : product.nameEn}
                      </h4>
                      <span className="font-mono text-sm font-bold text-[#1C3328] dark:text-[#C5A475] ml-2">
                        NT$ {product.price}
                      </span>
                    </div>

                    <p className="text-[11px] text-[#717E77] dark:text-[#97A59E] line-clamp-1 mb-2 font-mono">
                      {lang === 'zh-TW' ? product.nameEn : product.nameZh}
                    </p>

                    <p className="text-xs text-[#55635C] dark:text-[#A0B0A7] line-clamp-2 leading-relaxed mb-3">
                      {lang === 'zh-TW' ? product.descriptionZh : product.descriptionEn}
                    </p>

                    {/* Tasting notes chips */}
                    {product.tastingNotesZh && (
                      <div className="flex flex-wrap gap-1">
                        {product.tastingNotesZh.slice(0, 3).map((note, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded-md bg-[#FAF8F3] dark:bg-[#121A15] border border-[#E8E2D5] dark:border-[#2C3D32] text-[#1C3328] dark:text-[#C5A475] text-[10px]"
                          >
                            {note}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Card footer CTA */}
                <div className="p-5 pt-0">
                  <button
                    type="button"
                    onClick={(e) => handleQuickAdd(e, product)}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#EFE9DD] hover:bg-[#1C3328] text-[#1C3328] hover:text-white dark:bg-[#203127] dark:hover:bg-[#C5A475] dark:text-[#E8EAE8] dark:hover:text-[#1C3328] text-xs font-serif font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{t.addToOrder}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2. CATEGORY TABS & FULL PRODUCT GRID */}
        <div>
          {/* Tabs bar */}
          <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap mb-10">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`py-2.5 px-5 sm:px-6 rounded-full text-xs sm:text-sm font-serif font-bold tracking-wider transition-all duration-200 cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#1C3328] text-[#FAF8F3] shadow-md dark:bg-[#C5A475] dark:text-[#1C3328]'
                    : 'bg-white dark:bg-[#18231D] text-[#55635C] dark:text-[#A0B0A7] border border-[#DDD5C7] dark:border-[#283C30] hover:border-[#1C3328] dark:hover:border-[#C5A475]'
                }`}
              >
                <span>{cat.labelZh}</span>
                <span className="text-[10px] ml-1.5 opacity-70 font-sans">{cat.labelEn}</span>
              </button>
            ))}
          </div>

          {/* Active Category Products Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categoryProducts.map((product) => (
              <div
                key={product.id}
                onClick={() => openProductModal(product)}
                className="group bg-white dark:bg-[#18231D] rounded-2xl p-4 sm:p-5 border border-[#E8E2D5] dark:border-[#283C30] shadow-sm hover:shadow-md hover:border-[#1C3328]/40 dark:hover:border-[#C5A475]/40 transition-all flex gap-4 cursor-pointer"
              >
                {/* Left Thumbnail */}
                <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-xl overflow-hidden shrink-0 bg-[#2C1D11]">
                  <Image
                    src={product.image}
                    alt={product.nameZh}
                    fill
                    sizes="120px"
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  {product.originZh && (
                    <div className="absolute bottom-0 inset-x-0 bg-black/60 text-white text-[9px] text-center py-0.5">
                      {product.originZh}
                    </div>
                  )}
                </div>

                {/* Right Info */}
                <div className="flex-1 flex flex-col justify-between text-left min-w-0">
                  <div>
                    <div className="flex items-start justify-between gap-1">
                      <h4 className="text-base font-serif font-bold text-[#1F2421] dark:text-[#F7F4EE] group-hover:text-[#1C3328] dark:group-hover:text-[#C5A475] transition-colors truncate">
                        {lang === 'zh-TW' ? product.nameZh : product.nameEn}
                      </h4>
                      <span className="font-mono text-sm font-bold text-[#1C3328] dark:text-[#C5A475] shrink-0">
                        NT$ {product.price}
                      </span>
                    </div>

                    <p className="text-[10px] text-[#717E77] dark:text-[#97A59E] font-mono truncate">
                      {lang === 'zh-TW' ? product.nameEn : product.nameZh}
                    </p>

                    <p className="text-xs text-[#55635C] dark:text-[#A0B0A7] line-clamp-2 mt-1.5 leading-snug">
                      {lang === 'zh-TW' ? product.descriptionZh : product.descriptionEn}
                    </p>
                  </div>

                  {/* Actions & tags */}
                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-[#F0ECE1] dark:border-[#22332A]">
                    <div className="flex items-center gap-1.5 text-[10px] text-[#717E77] dark:text-[#97A59E]">
                      {product.allowHotIced ? (
                        <span>🔥 冰/熱</span>
                      ) : (
                        <span>{product.defaultTemp === 'hot' ? '🔥 僅熱飲' : '🧊 僅冷飲'}</span>
                      )}
                      {product.milkOptions && <span>• 燕麥奶可</span>}
                    </div>

                    <button
                      type="button"
                      onClick={(e) => handleQuickAdd(e, product)}
                      className="p-1.5 rounded-lg bg-[#EFE9DD] hover:bg-[#1C3328] text-[#1C3328] hover:text-white dark:bg-[#203127] dark:hover:bg-[#C5A475] dark:text-[#E8EAE8] dark:hover:text-[#1C3328] transition-colors cursor-pointer"
                      aria-label="Add to cart"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
