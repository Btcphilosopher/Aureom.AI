'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Product, CartItem } from '@/types';
import { useApp } from '@/context/AppContext';
import { X, Plus, Minus } from 'lucide-react';

interface ProductFormProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
  t: (typeof import('@/data/translations').translations)['zh-TW'];
  lang: string;
}

const ProductFormContent: React.FC<ProductFormProps> = ({
  product,
  onClose,
  onAddToCart,
  t,
  lang,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [temperature, setTemperature] = useState<'hot' | 'iced'>(product.defaultTemp || 'hot');
  const [size, setSize] = useState<'regular' | 'large'>('regular');
  const [milk, setMilk] = useState<'whole' | 'oat' | 'soy' | 'almond' | 'none'>(
    product.milkOptions ? 'whole' : 'none'
  );
  const [sugar, setSugar] = useState<'regular' | 'half' | 'quarter' | 'none'>(
    product.sugarOptions ? 'regular' : 'none'
  );
  const [ice, setIce] = useState<'regular' | 'less' | 'none'>(
    product.iceOptions ? 'regular' : 'none'
  );
  const [beanType, setBeanType] = useState<'house' | 'single_origin_alishan'>('house');
  const [specialInstructions, setSpecialInstructions] = useState('');

  // Calculate dynamic unit price with modifiers
  let unitPrice = product.price;
  if (size === 'large') unitPrice += 20;
  if (milk === 'oat' || milk === 'almond') unitPrice += 20;
  if (milk === 'soy') unitPrice += 10;
  if (beanType === 'single_origin_alishan') unitPrice += 40;

  const totalPrice = unitPrice * quantity;

  const handleSubmit = () => {
    const item: CartItem = {
      cartItemId: `item_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      product,
      quantity,
      temperature: product.allowHotIced ? temperature : product.defaultTemp,
      size,
      milk: product.milkOptions ? milk : undefined,
      sugar: product.sugarOptions ? sugar : undefined,
      ice: product.iceOptions && temperature === 'iced' ? ice : undefined,
      beanType: product.category === 'coffee' ? beanType : undefined,
      unitPrice,
      totalPrice,
      specialInstructions: specialInstructions.trim() || undefined,
    };

    onAddToCart(item);
    onClose();
  };

  return (
    <div
      id="product-detail-modal"
      className="w-full max-w-xl max-h-[90vh] bg-[#FAF8F3] dark:bg-[#16211B] rounded-3xl shadow-2xl border border-[#E8E2D5] dark:border-[#283C30] overflow-hidden flex flex-col transition-all"
    >
      {/* Modal Top Header with Image */}
      <div className="relative w-full h-52 sm:h-60 bg-[#2C1D11] shrink-0">
        <Image
          src={product.image}
          alt={product.nameZh}
          fill
          sizes="(max-width: 768px) 100vw, 600px"
          className="object-cover"
          priority
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title on image */}
        <div className="absolute bottom-4 left-6 right-6 text-white">
          <span className="text-xs font-sans tracking-widest text-[#C5A475] uppercase font-bold">
            {product.category.toUpperCase()}
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold leading-tight">
            {lang === 'zh-TW' ? product.nameZh : product.nameEn}
          </h2>
          <p className="text-xs text-[#E5E0D5] font-sans">
            {lang === 'zh-TW' ? product.nameEn : product.nameZh}
          </p>
        </div>
      </div>

      {/* Modal Scrollable Body */}
      <div className="p-6 overflow-y-auto space-y-5 text-left">
        {/* Description & Origin info */}
        <div>
          <p className="text-sm text-[#4A5550] dark:text-[#CBD5CF] leading-relaxed">
            {lang === 'zh-TW' ? product.descriptionZh : product.descriptionEn}
          </p>

          {(product.originZh || product.roastLevelZh) && (
            <div className="mt-3 p-3 rounded-xl bg-[#EFE9DD] dark:bg-[#1C2821] flex flex-wrap gap-x-4 gap-y-2 text-xs">
              {product.originZh && (
                <div className="flex items-center gap-1 text-[#1C3328] dark:text-[#C5A475]">
                  <span className="font-semibold">產地 Origin:</span>
                  <span>{lang === 'zh-TW' ? product.originZh : product.originEn}</span>
                </div>
              )}
              {product.roastLevelZh && (
                <div className="flex items-center gap-1 text-[#1C3328] dark:text-[#C5A475]">
                  <span className="font-semibold">焙度 Roast:</span>
                  <span>{lang === 'zh-TW' ? product.roastLevelZh : product.roastLevelEn}</span>
                </div>
              )}
            </div>
          )}

          {/* Tasting Notes */}
          {product.tastingNotesZh && product.tastingNotesZh.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap mt-3">
              <span className="text-xs font-semibold text-[#717E77] dark:text-[#97A59E]">
                風味筆記:
              </span>
              {(lang === 'zh-TW'
                ? product.tastingNotesZh
                : product.tastingNotesEn || product.tastingNotesZh
              ).map((note, i) => (
                <span
                  key={i}
                  className="px-2.5 py-0.5 rounded-full bg-[#E5DFD1] dark:bg-[#22332A] text-[#1C3328] dark:text-[#E8EAE8] text-[11px] font-medium"
                >
                  {note}
                </span>
              ))}
            </div>
          )}
        </div>

        <hr className="border-[#E8E2D5] dark:border-[#283C30]" />

        {/* Temperature Choice */}
        {product.allowHotIced && (
          <div>
            <label className="block text-xs font-serif font-bold text-[#1F2421] dark:text-[#E8EAE8] mb-2">
              溫度選擇 TEMPERATURE
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setTemperature('hot')}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  temperature === 'hot'
                    ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839] dark:border-[#284839]'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C] hover:bg-[#EFE9DD]'
                }`}
              >
                <span>🔥</span>
                <span>{t.hot}</span>
              </button>
              <button
                type="button"
                onClick={() => setTemperature('iced')}
                className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  temperature === 'iced'
                    ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839] dark:border-[#284839]'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C] hover:bg-[#EFE9DD]'
                }`}
              >
                <span>🧊</span>
                <span>{t.iced}</span>
              </button>
            </div>
          </div>
        )}

        {/* Size Choice */}
        {product.sizes && product.sizes.length > 1 && (
          <div>
            <label className="block text-xs font-serif font-bold text-[#1F2421] dark:text-[#E8EAE8] mb-2">
              杯量規格 SIZE
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setSize('regular')}
                className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                  size === 'regular'
                    ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839]'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C] hover:bg-[#EFE9DD]'
                }`}
              >
                {t.sizeRegular}
              </button>
              <button
                type="button"
                onClick={() => setSize('large')}
                className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                  size === 'large'
                    ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839]'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C] hover:bg-[#EFE9DD]'
                }`}
              >
                {t.sizeLarge}
              </button>
            </div>
          </div>
        )}

        {/* Coffee Bean Selection */}
        {product.category === 'coffee' && (
          <div>
            <label className="block text-xs font-serif font-bold text-[#1F2421] dark:text-[#E8EAE8] mb-2">
              咖啡豆種 BEAN PROFILE
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setBeanType('house')}
                className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                  beanType === 'house'
                    ? 'border-[#1C3328] bg-[#EBF4EE] dark:bg-[#1D2B22] text-[#1C3328] dark:text-[#88D3A8] font-bold'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C] hover:bg-[#EFE9DD]'
                }`}
              >
                <span className="block">{t.beanHouse}</span>
                <span className="text-[10px] text-[#717E77] font-normal">
                  中深焙 • 焦糖黑巧克力
                </span>
              </button>

              <button
                type="button"
                onClick={() => setBeanType('single_origin_alishan')}
                className={`p-2.5 rounded-xl border text-left text-xs transition-all cursor-pointer ${
                  beanType === 'single_origin_alishan'
                    ? 'border-[#1C3328] bg-[#EBF4EE] dark:bg-[#1D2B22] text-[#1C3328] dark:text-[#88D3A8] font-bold'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C] hover:bg-[#EFE9DD]'
                }`}
              >
                <span className="block">{t.beanAlishan}</span>
                <span className="text-[10px] text-[#717E77] font-normal">
                  淺中焙 • 阿里山高山花果香
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Milk Options */}
        {product.milkOptions && (
          <div>
            <label className="block text-xs font-serif font-bold text-[#1F2421] dark:text-[#E8EAE8] mb-2">
              乳品選擇 MILK SELECTION
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setMilk('whole')}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  milk === 'whole'
                    ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839]'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C]'
                }`}
              >
                {t.milkWhole}
              </button>
              <button
                type="button"
                onClick={() => setMilk('oat')}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  milk === 'oat'
                    ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839]'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C]'
                }`}
              >
                {t.milkOat}
              </button>
              <button
                type="button"
                onClick={() => setMilk('soy')}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  milk === 'soy'
                    ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839]'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C]'
                }`}
              >
                {t.milkSoy}
              </button>
              <button
                type="button"
                onClick={() => setMilk('almond')}
                className={`p-2 rounded-xl border text-center transition-all cursor-pointer ${
                  milk === 'almond'
                    ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839]'
                    : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C]'
                }`}
              >
                {t.milkAlmond}
              </button>
            </div>
          </div>
        )}

        {/* Sweetness */}
        {product.sugarOptions && (
          <div>
            <label className="block text-xs font-serif font-bold text-[#1F2421] dark:text-[#E8EAE8] mb-2">
              甜度調整 SWEETNESS
            </label>
            <div className="grid grid-cols-4 gap-2 text-xs">
              {(['regular', 'half', 'quarter', 'none'] as const).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSugar(s)}
                  className={`py-1.5 px-2 rounded-xl border text-center transition-all cursor-pointer ${
                    sugar === s
                      ? 'border-[#1C3328] bg-[#1C3328] text-white dark:bg-[#284839]'
                      : 'border-[#DDD5C7] dark:border-[#2C3D32] text-[#55635C]'
                  }`}
                >
                  {s === 'regular' && t.sugarRegular}
                  {s === 'half' && t.sugarHalf}
                  {s === 'quarter' && t.sugarQuarter}
                  {s === 'none' && t.sugarNone}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Special Instructions */}
        <div>
          <label className="block text-xs font-serif font-bold text-[#1F2421] dark:text-[#E8EAE8] mb-1.5">
            備註說明 SPECIAL NOTES
          </label>
          <input
            type="text"
            value={specialInstructions}
            onChange={(e) => setSpecialInstructions(e.target.value)}
            placeholder={t.notesPlaceholder}
            className="w-full text-xs p-2.5 bg-white dark:bg-[#121A15] border border-[#DDD5C7] dark:border-[#2C3D32] rounded-xl text-[#1F2421] dark:text-[#E8EAE8] focus:outline-hidden focus:border-[#1C3328]"
          />
        </div>
      </div>

      {/* Modal Footer with Quantity and Add Button */}
      <div className="bg-[#EFE9DD] dark:bg-[#101712] p-4 sm:p-5 border-t border-[#DDD5C7] dark:border-[#223028] flex items-center justify-between gap-4">
        {/* Quantity selector */}
        <div className="flex items-center gap-3 bg-white dark:bg-[#1A251F] border border-[#DDD5C7] dark:border-[#2C3D32] rounded-xl p-1 shadow-2xs">
          <button
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            className="p-1.5 rounded-lg hover:bg-[#EFE9DD] dark:hover:bg-[#25362C] text-[#1F2421] dark:text-[#E8EAE8] transition-colors cursor-pointer"
            aria-label="Decrease quantity"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <span className="w-6 text-center text-sm font-bold font-mono">{quantity}</span>
          <button
            onClick={() => setQuantity(quantity + 1)}
            className="p-1.5 rounded-lg hover:bg-[#EFE9DD] dark:hover:bg-[#25362C] text-[#1F2421] dark:text-[#E8EAE8] transition-colors cursor-pointer"
            aria-label="Increase quantity"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Add to Order Button */}
        <button
          onClick={handleSubmit}
          className="flex-1 py-3.5 px-6 rounded-xl bg-[#1C3328] hover:bg-[#14261E] dark:bg-[#284839] dark:hover:bg-[#345946] text-white font-serif font-bold text-sm tracking-wider shadow-md hover:shadow-lg transition-all flex items-center justify-between cursor-pointer"
        >
          <span>{t.addToOrder}</span>
          <span className="font-mono text-base text-[#C5A475]">NT$ {totalPrice}</span>
        </button>
      </div>
    </div>
  );
};

export const ProductDetailModal: React.FC = () => {
  const { selectedProduct, closeProductModal, addToCart, t, lang } = useApp();

  if (!selectedProduct) return null;

  return (
    <div
      id="product-detail-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeProductModal();
      }}
    >
      <ProductFormContent
        key={selectedProduct.id}
        product={selectedProduct}
        onClose={closeProductModal}
        onAddToCart={addToCart}
        t={t}
        lang={lang}
      />
    </div>
  );
};
