'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import {
  Wifi,
  X,
  CheckCircle2,
  Smartphone,
  User,
  RefreshCw,
  Clock,
  ChevronRight,
} from 'lucide-react';

export const WifiModal: React.FC = () => {
  const {
    isWifiModalOpen,
    closeWifiModal,
    wifiSession,
    wifiDurationStr,
    connectWifi,
    disconnectWifi,
    t,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'mobile' | 'account'>('mobile');
  const [phoneNumber, setPhoneNumber] = useState('0912-345-678');
  const [localStep, setLocalStep] = useState<'phone' | 'otp' | 'connecting'>('phone');
  const [otpCode, setOtpCode] = useState('');
  const [countdown, setCountdown] = useState(60);
  const [speedVal, setSpeedVal] = useState(238);
  const [isSpeedTesting, setIsSpeedTesting] = useState(false);
  const [agreedTerms, setAgreedTerms] = useState(true);

  // Countdown timer for OTP
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (localStep === 'otp' && countdown > 0) {
      timer = setInterval(() => setCountdown((c) => c - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [localStep, countdown]);

  if (!isWifiModalOpen) return null;

  const isConnected = wifiSession.isConnected;

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || !agreedTerms) return;
    setLocalStep('otp');
    setCountdown(60);
    setOtpCode('8860');
  };

  const handleVerifyAndConnect = (e: React.FormEvent) => {
    e.preventDefault();
    setLocalStep('connecting');

    setTimeout(() => {
      connectWifi(phoneNumber);
      setLocalStep('phone');
    }, 1800);
  };

  const runSpeedTest = () => {
    setIsSpeedTesting(true);
    let count = 0;
    const testInterval = setInterval(() => {
      count++;
      setSpeedVal(Math.floor(210 + Math.random() * 50));
      if (count > 8) {
        clearInterval(testInterval);
        setIsSpeedTesting(false);
      }
    }, 200);
  };

  return (
    <div
      id="wifi-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeWifiModal();
      }}
    >
      <div
        id="wifi-modal-content"
        className="w-full max-w-lg bg-[#FAF8F3] dark:bg-[#16211B] rounded-3xl shadow-2xl border border-[#E8E2D5] dark:border-[#283C30] overflow-hidden transition-all transform scale-100"
      >
        {/* Modal Header */}
        <div className="bg-[#1C3328] dark:bg-[#0E1712] text-white p-6 relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#2A4839] flex items-center justify-center text-[#C5A475]">
              <Wifi className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-serif font-bold tracking-wide">{t.wifiTitle}</h2>
              <p className="text-[10px] font-sans tracking-widest text-[#C5A475] uppercase font-semibold">
                {t.wifiSubtitle}
              </p>
            </div>
          </div>

          <button
            onClick={closeWifiModal}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/80 hover:text-white transition-colors cursor-pointer"
            aria-label="Close Wi-Fi Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {isConnected ? (
            /* CONNECTED STATE DASHBOARD */
            <div className="space-y-5">
              <div className="bg-[#EBF4EE] dark:bg-[#182B21] border border-[#2BB673]/40 rounded-2xl p-4 text-center">
                <div className="w-10 h-10 rounded-full bg-[#2BB673] text-white flex items-center justify-center mx-auto mb-2 shadow-xs">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-base font-serif font-bold text-[#1C3328] dark:text-[#88D3A8]">
                  {t.wifiConnected} • {t.wifiConnectedSub}
                </h3>
                <p className="text-xs text-[#4A5550] dark:text-[#A0CBB3] mt-1">
                  {t.wifiWelcomeZh}
                </p>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 gap-3 text-left">
                <div className="bg-white dark:bg-[#121A15] p-3.5 rounded-xl border border-[#E8E2D5] dark:border-[#2C3D32]">
                  <span className="text-[10px] font-sans text-[#717E77] uppercase font-semibold block">
                    {t.wifiNetworkName}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#1C3328] dark:text-[#E8EAE8] block mt-0.5">
                    {wifiSession.ssid}
                  </span>
                </div>

                <div className="bg-white dark:bg-[#121A15] p-3.5 rounded-xl border border-[#E8E2D5] dark:border-[#2C3D32]">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-sans text-[#717E77] uppercase font-semibold">
                      {t.wifiSpeed}
                    </span>
                    <button
                      onClick={runSpeedTest}
                      disabled={isSpeedTesting}
                      className="text-[10px] text-[#C5A475] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className={`w-3 h-3 ${isSpeedTesting ? 'animate-spin' : ''}`} />
                      <span>測速</span>
                    </button>
                  </div>
                  <span className="text-sm font-mono font-bold text-[#1C3328] dark:text-[#E8EAE8] block mt-0.5">
                    {speedVal} Mbps
                  </span>
                </div>

                <div className="bg-white dark:bg-[#121A15] p-3.5 rounded-xl border border-[#E8E2D5] dark:border-[#2C3D32]">
                  <span className="text-[10px] font-sans text-[#717E77] uppercase font-semibold block">
                    {t.wifiSessionTime}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#1C3328] dark:text-[#E8EAE8] block mt-0.5 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#C5A475]" />
                    <span>{wifiDurationStr}</span>
                  </span>
                </div>

                <div className="bg-white dark:bg-[#121A15] p-3.5 rounded-xl border border-[#E8E2D5] dark:border-[#2C3D32]">
                  <span className="text-[10px] font-sans text-[#717E77] uppercase font-semibold block">
                    {t.wifiSignal}
                  </span>
                  <span className="text-xs font-serif font-bold text-[#2BB673] block mt-0.5">
                    ●●●●● {t.wifiExcellent}
                  </span>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <a
                  href="#menu"
                  onClick={closeWifiModal}
                  className="py-2.5 rounded-xl bg-[#1C3328] text-white text-xs font-medium text-center hover:bg-[#15271F] transition-colors"
                >
                  探索菜單點餐
                </a>

                <button
                  type="button"
                  onClick={() => {
                    disconnectWifi();
                    setLocalStep('phone');
                  }}
                  className="py-2.5 rounded-xl border border-[#E88] text-[#C33] text-xs font-medium hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors cursor-pointer"
                >
                  {t.wifiDisconnect}
                </button>
              </div>
            </div>
          ) : localStep === 'connecting' ? (
            /* CONNECTING ANIMATION */
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative w-24 h-24 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border-4 border-[#1C3328]/20 dark:border-[#C5A475]/20 animate-ping" />
                <div className="w-16 h-16 rounded-full bg-[#1C3328] dark:bg-[#284839] text-white flex items-center justify-center shadow-lg">
                  <Wifi className="w-8 h-8 animate-bounce" />
                </div>
              </div>
              <div>
                <h3 className="text-base font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
                  {t.wifiConnecting}
                </h3>
                <p className="text-xs text-[#717E77] dark:text-[#97A59E] font-mono mt-1">
                  DHCP • 192.168.88.104 • WPA3
                </p>
              </div>
            </div>
          ) : localStep === 'otp' ? (
            /* OTP VERIFICATION STEP */
            <form onSubmit={handleVerifyAndConnect} className="space-y-5">
              <div className="bg-[#EBF4EE] dark:bg-[#1D2B22] p-4 rounded-2xl text-center border border-[#2BB673]/30">
                <span className="text-xs font-serif font-bold text-[#1C3328] dark:text-[#88D3A8] block">
                  {t.wifiCodeSent}
                </span>
                <span className="text-xs font-mono text-[#55635C] dark:text-[#A0CBB3] mt-1 block">
                  +886 {phoneNumber}
                </span>
                <span className="text-[11px] text-[#717E77] block mt-0.5">
                  {t.wifiCodeSentDesc}
                </span>
              </div>

              <div>
                <label className="block text-xs font-serif font-semibold text-[#1F2421] dark:text-[#E8EAE8] mb-1.5 text-center">
                  {t.wifiEnterCode}
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="8860"
                  className="w-full text-center text-2xl font-mono tracking-[0.4em] bg-white dark:bg-[#121A15] border border-[#DDD5C7] dark:border-[#2C3D32] rounded-xl p-3 text-[#1F2421] dark:text-[#E8EAE8] focus:outline-hidden focus:border-[#1C3328] focus:ring-2 focus:ring-[#1C3328]/10"
                />
              </div>

              <div className="flex items-center justify-between text-xs text-[#717E77] px-1">
                <button
                  type="button"
                  onClick={() => setOtpCode('8860')}
                  className="text-[#1C3328] dark:text-[#C5A475] font-semibold underline underline-offset-2 hover:opacity-80 cursor-pointer"
                >
                  {t.wifiAutoFill}
                </button>
                <span>
                  {countdown > 0 ? `${countdown} ${t.wifiResendIn}` : t.wifiResendCode}
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-[#1C3328] hover:bg-[#15271F] dark:bg-[#284839] dark:hover:bg-[#345946] text-white text-sm font-serif font-bold tracking-wider shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Wifi className="w-4 h-4" />
                <span>{t.wifiConnectBtn}</span>
              </button>
            </form>
          ) : (
            /* PHONE INPUT STEP */
            <div className="space-y-5">
              <div className="grid grid-cols-2 p-1.5 bg-[#EFE9DD] dark:bg-[#121A15] rounded-2xl text-xs font-serif font-semibold">
                <button
                  type="button"
                  onClick={() => setActiveTab('mobile')}
                  className={`py-2 rounded-xl transition-all cursor-pointer ${
                    activeTab === 'mobile'
                      ? 'bg-white dark:bg-[#203127] text-[#1C3328] dark:text-[#E8EAE8] shadow-xs'
                      : 'text-[#717E77] hover:text-[#1C3328]'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>{t.wifiTabMobile}</span>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('account')}
                  className={`py-2 rounded-xl transition-all cursor-pointer ${
                    activeTab === 'account'
                      ? 'bg-white dark:bg-[#203127] text-[#1C3328] dark:text-[#E8EAE8] shadow-xs'
                      : 'text-[#717E77] hover:text-[#1C3328]'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <User className="w-3.5 h-3.5" />
                    <span>{t.wifiTabAccount}</span>
                  </div>
                </button>
              </div>

              {activeTab === 'mobile' ? (
                <form onSubmit={handleSendOtp} className="space-y-4">
                  <div>
                    <label className="block text-xs font-serif font-semibold text-[#1F2421] dark:text-[#E8EAE8] mb-1.5">
                      {t.wifiPhonePrompt}
                    </label>
                    <div className="flex items-center bg-white dark:bg-[#121A15] border border-[#DDD5C7] dark:border-[#2C3D32] rounded-xl p-3 focus-within:border-[#1C3328] focus-within:ring-2 focus-within:ring-[#1C3328]/10 transition-all">
                      <div className="flex items-center gap-1.5 pr-3 border-r border-[#E8E2D5] dark:border-[#2C3D32] text-sm font-semibold text-[#1F2421] dark:text-[#E8EAE8] select-none">
                        <span className="text-base">🇹🇼</span>
                        <span>+886</span>
                      </div>
                      <input
                        type="tel"
                        required
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder={t.wifiPhonePlaceholder}
                        className="w-full pl-3 text-sm bg-transparent text-[#1F2421] dark:text-[#E8EAE8] placeholder-[#9E9589] focus:outline-hidden font-medium"
                      />
                    </div>
                  </div>

                  <label className="flex items-start gap-2.5 cursor-pointer text-xs text-[#55635C] dark:text-[#97A59E] leading-relaxed">
                    <input
                      type="checkbox"
                      checked={agreedTerms}
                      onChange={(e) => setAgreedTerms(e.target.checked)}
                      className="mt-0.5 rounded border-[#C4B9A7] text-[#1C3328] focus:ring-[#1C3328]"
                    />
                    <span>{t.wifiTermsAgree}</span>
                  </label>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-[#1C3328] hover:bg-[#15271F] dark:bg-[#284839] dark:hover:bg-[#345946] text-white text-sm font-serif font-bold tracking-wider shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>{t.wifiGetCode}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <div className="space-y-4">
                  <p className="text-xs text-[#55635C] dark:text-[#97A59E] text-center">
                    使用台灣咖啡會員帳號或社交帳號一鍵免密碼連線。
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setLocalStep('connecting');
                      setTimeout(() => {
                        connectWifi('LINE_MEMBER_88');
                        setLocalStep('phone');
                      }, 1500);
                    }}
                    className="w-full py-3 rounded-xl bg-[#06C755] hover:bg-[#05B24C] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
                  >
                    <span>使用 LINE 帳號一鍵登入連線</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLocalStep('connecting');
                      setTimeout(() => {
                        connectWifi('GOOGLE_AUTH_MEMBER');
                        setLocalStep('phone');
                      }, 1500);
                    }}
                    className="w-full py-3 rounded-xl border border-[#DDD5C7] dark:border-[#2C3D32] bg-white dark:bg-[#1C2822] text-[#1F2421] dark:text-[#E8EAE8] text-xs font-semibold flex items-center justify-center gap-2 hover:bg-[#F3EFE6] transition-colors cursor-pointer"
                  >
                    <span>使用 Google 帳號快速連線</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
