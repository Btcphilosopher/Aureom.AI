'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { coffeeOriginsData } from '@/data/coffeeStoryData';
import { MapPin, Mountain, Sun, Sparkles, Award } from 'lucide-react';

export const FarmStorySection: React.FC = () => {
  const { t, lang } = useApp();
  const [selectedOriginId, setSelectedOriginId] = useState<string>('alishan');

  const activeOrigin =
    coffeeOriginsData.find((o) => o.id === selectedOriginId) || coffeeOriginsData[0];

  return (
    <section
      id="farm-story"
      className="w-full bg-[#FAF8F3] dark:bg-[#121714] py-14 sm:py-20 border-t border-b border-[#EFE9DC] dark:border-[#1E2922] transition-colors"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EFE9DD] dark:bg-[#1E2922] text-[#1C3328] dark:text-[#C5A475] text-xs font-serif font-medium mb-3">
            <Mountain className="w-3.5 h-3.5" />
            <span>嚴選台灣高山微氣候</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
            {t.storyTitle}
          </h2>
          <p className="text-xs sm:text-sm font-sans tracking-widest text-[#717E77] dark:text-[#97A59E] uppercase font-semibold mt-1">
            {t.storySubtitle}
          </p>
          <div className="w-12 h-[2px] bg-[#1C3328] dark:bg-[#C5A475] mt-3" />
        </div>

        {/* Origin Selector Pills */}
        <div className="flex items-center justify-center gap-2 sm:gap-4 overflow-x-auto pb-4 mb-8 no-scrollbar">
          {coffeeOriginsData.map((origin) => (
            <button
              key={origin.id}
              onClick={() => setSelectedOriginId(origin.id)}
              className={`px-4 sm:px-6 py-2.5 rounded-full text-xs sm:text-sm font-serif font-semibold whitespace-nowrap transition-all duration-300 cursor-pointer ${
                selectedOriginId === origin.id
                  ? 'bg-[#1C3328] dark:bg-[#C5A475] text-white dark:text-[#121714] shadow-md scale-105'
                  : 'bg-[#EFE9DD] dark:bg-[#1C2822] text-[#55635C] dark:text-[#CBD5CF] hover:bg-[#E2DACB]'
              }`}
            >
              <span>{lang === 'zh-TW' ? origin.nameZh : origin.nameEn}</span>
              <span className="ml-1.5 text-[10px] font-sans opacity-80 font-mono">
                {origin.altitude}
              </span>
            </button>
          ))}
        </div>

        {/* Origin Showcase Card */}
        <div className="bg-white dark:bg-[#18231D] rounded-3xl p-6 sm:p-10 shadow-xl border border-[#E8E2D5] dark:border-[#283C30] grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Visual: Farm Photo */}
          <div className="lg:col-span-6 relative w-full h-72 sm:h-96 rounded-2xl overflow-hidden shadow-md bg-[#2C1D11]">
            <Image
              src={
                activeOrigin.image ||
                'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1000&auto=format&fit=crop'
              }
              alt={activeOrigin.nameZh}
              fill
              sizes="(max-width: 1024px) 100vw, 550px"
              className="object-cover transition-transform duration-700 hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-xs text-white text-xs font-serif px-3 py-1 rounded-full flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#C5A475]" />
              <span>{lang === 'zh-TW' ? activeOrigin.regionZh : activeOrigin.regionEn}</span>
            </div>

            <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-xs text-[#C5A475] text-xs font-mono px-3 py-1 rounded-full">
              海拔 {activeOrigin.altitude}
            </div>
          </div>

          {/* Right Details */}
          <div className="lg:col-span-6 flex flex-col justify-center text-left space-y-4">
            <div>
              <span className="text-xs font-mono tracking-widest text-[#C5A475] uppercase font-bold">
                ESTATE ORIGIN SHOWCASE
              </span>
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE] mt-1">
                {lang === 'zh-TW' ? activeOrigin.nameZh : activeOrigin.nameEn}
              </h3>
              <p className="text-xs font-sans text-[#717E77] dark:text-[#97A59E]">
                {lang === 'zh-TW' ? activeOrigin.regionZh : activeOrigin.regionEn} •{' '}
                {lang === 'zh-TW' ? activeOrigin.farmZh : activeOrigin.farmEn}
              </p>
            </div>

            <p className="text-sm text-[#4A5550] dark:text-[#CBD5CF] leading-relaxed">
              {lang === 'zh-TW' ? activeOrigin.descriptionZh : activeOrigin.descriptionEn}
            </p>

            {/* Farm specs table */}
            <div className="grid grid-cols-2 gap-3 py-3 border-t border-b border-[#EFE9DD] dark:border-[#283C30] text-xs">
              <div>
                <span className="text-[#717E77] dark:text-[#97A59E] block">處理法 Process</span>
                <span className="font-serif font-bold text-[#1C3328] dark:text-[#E8EAE8]">
                  {lang === 'zh-TW' ? activeOrigin.processZh : activeOrigin.processEn}
                </span>
              </div>
              <div>
                <span className="text-[#717E77] dark:text-[#97A59E] block">合作農友 Partner</span>
                <span className="font-serif font-bold text-[#1C3328] dark:text-[#E8EAE8]">
                  {lang === 'zh-TW' ? activeOrigin.farmZh : activeOrigin.farmEn}
                </span>
              </div>
            </div>

            {/* Flavor Tags */}
            <div>
              <span className="text-xs font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE] block mb-2">
                主調風味 TASTING NOTES
              </span>
              <div className="flex flex-wrap gap-2">
                {(
                  activeOrigin.flavorNotesZh ||
                  (lang === 'zh-TW' ? activeOrigin.tastingNotesZh : activeOrigin.tastingNotesEn)
                    .split(/[、,]/)
                    .map((s) => s.trim())
                ).map((note, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 rounded-full bg-[#F3EFE6] dark:bg-[#202E26] text-[#1C3328] dark:text-[#C5A475] text-xs font-medium border border-[#DDD5C7] dark:border-[#2C3D32]"
                  >
                    ✨ {note}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
