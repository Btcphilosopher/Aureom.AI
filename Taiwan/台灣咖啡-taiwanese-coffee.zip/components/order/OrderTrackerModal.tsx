'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import {
  X,
  Clock,
  CheckCircle,
  Coffee,
  QrCode,
  Flame,
  Sparkles,
  MapPin,
  Wifi,
} from 'lucide-react';

export const OrderTrackerModal: React.FC = () => {
  const {
    isOrderTrackerOpen,
    closeOrderTracker,
    activeOrder,
    t,
    lang,
    wifiSession,
    openWifiModal,
  } = useApp();

  if (!isOrderTrackerOpen || !activeOrder) return null;

  const stages = [
    { key: 'confirmed', labelZh: '訂單已確認', labelEn: 'CONFIRMED', icon: CheckCircle },
    { key: 'preparing', labelZh: '吧台接單備料', labelEn: 'PREPARING', icon: Sparkles },
    { key: 'grinding', labelZh: '現磨台灣莊園豆', labelEn: 'GRINDING', icon: Flame },
    { key: 'brewing', labelZh: '手沖精準萃取中', labelEn: 'BREWING', icon: Coffee },
    { key: 'ready', labelZh: '餐點已就緒請取餐', labelEn: 'READY FOR PICKUP', icon: CheckCircle },
  ];

  const currentStageIndex =
    activeOrder.status === 'ready'
      ? 4
      : activeOrder.status === 'almost_ready'
      ? 3
      : activeOrder.status === 'brewing'
      ? 3
      : activeOrder.status === 'grinding'
      ? 2
      : activeOrder.status === 'preparing'
      ? 1
      : 0;

  return (
    <div
      id="order-tracker-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeOrderTracker();
      }}
    >
      <div
        id="order-tracker-modal"
        className="w-full max-w-lg bg-[#FAF8F3] dark:bg-[#16211B] rounded-3xl shadow-2xl border border-[#E8E2D5] dark:border-[#283C30] overflow-hidden flex flex-col"
      >
        {/* Header */}
        <div className="bg-[#1C3328] dark:bg-[#0E1712] text-white p-6 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-sans tracking-widest text-[#C5A475] uppercase font-bold">
                LIVE ORDER TRACKER
              </span>
              <span className="w-2 h-2 rounded-full bg-[#2BB673] animate-pulse" />
            </div>
            <h2 className="text-xl font-serif font-bold mt-0.5">
              訂單編號 #{activeOrder.orderNumber}
            </h2>
          </div>
          <button
            onClick={closeOrderTracker}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tracker Progress Body */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[80vh]">
          {/* Status Alert Banner */}
          <div
            className={`p-4 rounded-2xl border text-center transition-all ${
              activeOrder.status === 'ready'
                ? 'bg-[#EBF4EE] dark:bg-[#192D22] border-[#2BB673] text-[#1C3328] dark:text-[#88D3A8]'
                : 'bg-[#F4ECE1] dark:bg-[#202922] border-[#C5A475]/40 text-[#1C3328] dark:text-[#F7F4EE]'
            }`}
          >
            <span className="text-xs font-sans uppercase tracking-wider font-semibold text-[#717E77] dark:text-[#A0B5AA] block">
              {activeOrder.orderType === 'dine_in'
                ? `內用服務 • 桌號 ${activeOrder.tableNumber || '08'}`
                : '外帶自取 TAKEAWAY'}
            </span>
            <h3 className="text-lg font-serif font-bold mt-1">
              {stages[currentStageIndex].labelZh}
            </h3>
            <p className="text-xs text-[#55635C] dark:text-[#C5D3CB] mt-0.5">
              {activeOrder.status === 'ready'
                ? '請至吧台出示下方取餐 QR Code'
                : `預估出餐時間約剩餘 ${activeOrder.estimatedMinutesRemaining} 分鐘`}
            </p>
          </div>

          {/* Stepper Timeline */}
          <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#DDD5C7] dark:before:bg-[#283C30]">
            {stages.map((stage, idx) => {
              const isPast = idx < currentStageIndex;
              const isCurrent = idx === currentStageIndex;
              const isFuture = idx > currentStageIndex;
              const Icon = stage.icon;

              return (
                <div key={stage.key} className="relative flex items-center gap-4">
                  {/* Step Dot/Icon */}
                  <div
                    className={`absolute -left-6 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold transition-all ${
                      isPast
                        ? 'bg-[#2BB673] text-white ring-2 ring-[#EBF4EE]'
                        : isCurrent
                        ? 'bg-[#1C3328] dark:bg-[#C5A475] text-white dark:text-[#121714] ring-4 ring-[#1C3328]/20 animate-pulse'
                        : 'bg-[#DDD5C7] dark:bg-[#2C3D32] text-[#717E77]'
                    }`}
                  >
                    {isPast ? '✓' : idx + 1}
                  </div>

                  <div className="flex-1 text-left">
                    <h4
                      className={`text-xs font-serif font-bold ${
                        isCurrent
                          ? 'text-[#1C3328] dark:text-[#F7F4EE] text-sm'
                          : isPast
                          ? 'text-[#4A5550] dark:text-[#97A59E]'
                          : 'text-[#9E9589]'
                      }`}
                    >
                      {stage.labelZh}
                    </h4>
                    <span className="text-[9px] font-sans tracking-wider text-[#717E77] dark:text-[#8E9D95] uppercase">
                      {stage.labelEn}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* QR Code Pickup Badge */}
          <div className="bg-white dark:bg-[#121A15] p-4 rounded-2xl border border-[#E8E2D5] dark:border-[#283C30] flex items-center justify-between gap-4">
            <div className="text-left">
              <span className="text-[10px] font-sans text-[#717E77] uppercase font-bold block">
                PICKUP CODE
              </span>
              <span className="text-xl font-mono font-bold text-[#1C3328] dark:text-[#C5A475] block mt-0.5">
                {activeOrder.pickupCode || 'TW-8809'}
              </span>
              <span className="text-[11px] text-[#55635C] dark:text-[#97A59E] block">
                出示此碼給咖啡師快速核銷
              </span>
            </div>

            <div className="w-16 h-16 bg-[#F3EFE6] dark:bg-[#202E26] rounded-xl flex items-center justify-center p-2 border border-[#DDD5C7] dark:border-[#2C3D32]">
              <QrCode className="w-full h-full text-[#1C3328] dark:text-[#E8EAE8]" />
            </div>
          </div>

          {/* Wi-Fi Upsell if not connected */}
          {!wifiSession.isConnected && (
            <div className="bg-[#EBF4EE] dark:bg-[#1A2A21] p-3.5 rounded-xl border border-[#2BB673]/30 flex items-center justify-between">
              <div className="flex items-center gap-2.5 text-xs text-left">
                <Wifi className="w-4 h-4 text-[#1C3328] dark:text-[#88D3A8]" />
                <div>
                  <span className="font-serif font-bold text-[#1C3328] dark:text-[#E8EAE8] block">
                    享受門市免費 Wi-Fi 6 高速連線
                  </span>
                  <span className="text-[10px] text-[#55635C] dark:text-[#A0B5AA]">
                    免密碼一鍵登入，不限時使用
                  </span>
                </div>
              </div>
              <button
                onClick={() => {
                  closeOrderTracker();
                  openWifiModal();
                }}
                className="px-3 py-1.5 rounded-lg bg-[#1C3328] text-white text-[11px] font-serif"
              >
                立即連線
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
