'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import {
  X,
  Plus,
  Minus,
  Trash2,
  ShoppingBag,
  Clock,
  MapPin,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    closeCart,
    cart,
    updateCartItemQuantity,
    removeFromCart,
    clearCart,
    cartSubtotal,
    cartCount,
    createOrder,
    t,
    lang,
    loyaltyMember,
  } = useApp();

  const [orderType, setOrderType] = useState<'dine_in' | 'takeaway'>('dine_in');
  const [tableNumber, setTableNumber] = useState('08');
  const [customerName, setCustomerName] = useState('林小姐 / Ms. Lin');
  const [customerPhone, setCustomerPhone] = useState('0912-345-678');
  const [specialNote, setSpecialNote] = useState('');
  const [usePoints, setUsePoints] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isCartOpen) return null;

  const pointsDiscount = usePoints && loyaltyMember.points >= 50 ? 50 : 0;
  const finalTotal = Math.max(0, cartSubtotal - pointsDiscount);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setIsSubmitting(true);

    setTimeout(() => {
      createOrder({
        orderType,
        tableNumber: orderType === 'dine_in' ? tableNumber : undefined,
        customerName,
        customerPhone,
        specialNotes: specialNote || undefined,
      });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <div
      id="cart-drawer-backdrop"
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeCart();
      }}
    >
      <div
        id="cart-drawer-container"
        className="w-full max-w-md bg-[#FAF8F3] dark:bg-[#151F19] h-full shadow-2xl flex flex-col justify-between border-l border-[#E8E2D5] dark:border-[#283C30] transition-all transform animate-slide-left"
      >
        {/* Drawer Header */}
        <div className="bg-[#1C3328] dark:bg-[#0E1712] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="w-5 h-5 text-[#C5A475]" />
            <h2 className="text-lg font-serif font-bold tracking-wide">
              {t.cartTitle} ({cartCount})
            </h2>
          </div>
          <button
            onClick={closeCart}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/80 transition-colors"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-5 text-left">
          {cart.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-[#EFE9DD] dark:bg-[#1E2B23] flex items-center justify-center text-[#717E77]">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <p className="text-sm font-serif text-[#717E77] dark:text-[#97A59E]">
                {t.cartEmpty}
              </p>
              <button
                onClick={closeCart}
                className="px-4 py-2 rounded-full bg-[#1C3328] text-white text-xs font-medium"
              >
                瀏覽菜單
              </button>
            </div>
          ) : (
            <>
              {/* Order Type Toggle (Dine In vs Takeaway) */}
              <div className="grid grid-cols-2 p-1 bg-[#EFE9DD] dark:bg-[#121A15] rounded-xl text-xs font-serif font-semibold">
                <button
                  type="button"
                  onClick={() => setOrderType('dine_in')}
                  className={`py-2 rounded-lg transition-all ${
                    orderType === 'dine_in'
                      ? 'bg-white dark:bg-[#203127] text-[#1C3328] dark:text-[#E8EAE8] shadow-xs'
                      : 'text-[#717E77]'
                  }`}
                >
                  內用 DINE-IN
                </button>
                <button
                  type="button"
                  onClick={() => setOrderType('takeaway')}
                  className={`py-2 rounded-lg transition-all ${
                    orderType === 'takeaway'
                      ? 'bg-white dark:bg-[#203127] text-[#1C3328] dark:text-[#E8EAE8] shadow-xs'
                      : 'text-[#717E77]'
                  }`}
                >
                  外帶 TAKEAWAY
                </button>
              </div>

              {/* Table / Contact Details */}
              <div className="bg-white dark:bg-[#18231D] p-3.5 rounded-xl border border-[#E8E2D5] dark:border-[#2C3D32] space-y-2.5 text-xs">
                {orderType === 'dine_in' && (
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#55635C] dark:text-[#97A59E]">
                      桌號 Table No.:
                    </span>
                    <input
                      type="text"
                      value={tableNumber}
                      onChange={(e) => setTableNumber(e.target.value)}
                      placeholder="例如: 08"
                      className="w-20 text-right p-1 font-mono font-bold bg-[#FAF8F3] dark:bg-[#121A15] border border-[#DDD5C7] rounded-md"
                    />
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-[#55635C] dark:text-[#97A59E]">
                    取餐姓名 Name:
                  </span>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-36 text-right p-1 bg-[#FAF8F3] dark:bg-[#121A15] border border-[#DDD5C7] rounded-md font-medium"
                  />
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
                  <span>餐點明細 ITEMS</span>
                  <button
                    onClick={clearCart}
                    className="text-[11px] text-[#C33] hover:underline flex items-center gap-1 font-sans"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>清空</span>
                  </button>
                </div>

                {cart.map((item) => (
                  <div
                    key={item.cartItemId}
                    className="p-3 bg-white dark:bg-[#18231D] rounded-xl border border-[#E8E2D5] dark:border-[#2C3D32] flex items-start gap-3"
                  >
                    <div className="relative w-14 h-14 rounded-lg overflow-hidden shrink-0 bg-[#2C1D11]">
                      <Image
                        src={item.product.image}
                        alt={item.product.nameZh}
                        fill
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <h4 className="text-xs font-serif font-bold text-[#1F2421] dark:text-[#F7F4EE] truncate">
                          {lang === 'zh-TW' ? item.product.nameZh : item.product.nameEn}
                        </h4>
                        <span className="text-xs font-mono font-bold text-[#1C3328] dark:text-[#C5A475]">
                          NT$ {item.totalPrice}
                        </span>
                      </div>

                      {/* Customizations summary */}
                      <p className="text-[10px] text-[#717E77] dark:text-[#97A59E] mt-0.5 leading-tight">
                        {item.temperature === 'hot' ? '熱' : '冰'} •{' '}
                        {item.size === 'large' ? '大杯' : '中杯'}
                        {item.milk && ` • ${item.milk}`}
                        {item.sugar && ` • ${item.sugar}`}
                      </p>

                      {/* Quantity Controls */}
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-2 bg-[#F3EFE6] dark:bg-[#202E26] rounded-lg p-0.5">
                          <button
                            onClick={() =>
                              updateCartItemQuantity(item.cartItemId, item.quantity - 1)
                            }
                            className="p-1 hover:text-[#1C3328]"
                            aria-label="Decrease quantity"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-mono font-bold w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              updateCartItemQuantity(item.cartItemId, item.quantity + 1)
                            }
                            className="p-1 hover:text-[#1C3328]"
                            aria-label="Increase quantity"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.cartItemId)}
                          className="text-[#999] hover:text-[#C33] p-1"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Loyalty Points Redemption Box */}
              {loyaltyMember.points > 0 && (
                <div className="bg-[#EBF4EE] dark:bg-[#182820] p-3 rounded-xl border border-[#2BB673]/30 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#C5A475]" />
                    <div>
                      <span className="font-serif font-bold text-[#1C3328] dark:text-[#88D3A8] block">
                        會員點數折抵 (現有 {loyaltyMember.points} 點)
                      </span>
                      <span className="text-[10px] text-[#55635C] dark:text-[#A0CBB3]">
                        使用 50 點折抵 NT$50
                      </span>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={usePoints}
                    onChange={(e) => setUsePoints(e.target.checked)}
                    className="rounded border-[#C4B9A7] text-[#1C3328] focus:ring-[#1C3328]"
                  />
                </div>
              )}
            </>
          )}
        </div>

        {/* Drawer Footer Checkout */}
        {cart.length > 0 && (
          <div className="bg-[#EFE9DD] dark:bg-[#101712] p-5 border-t border-[#DDD5C7] dark:border-[#223028] space-y-3">
            <div className="space-y-1.5 text-xs text-[#55635C] dark:text-[#97A59E]">
              <div className="flex justify-between">
                <span>小計 Subtotal</span>
                <span className="font-mono">NT$ {cartSubtotal}</span>
              </div>
              {pointsDiscount > 0 && (
                <div className="flex justify-between text-[#2BB673]">
                  <span>點數折抵 Points Discount</span>
                  <span className="font-mono">- NT$ {pointsDiscount}</span>
                </div>
              )}
              <div className="flex justify-between font-serif font-bold text-base text-[#1C3328] dark:text-[#F7F4EE] pt-2 border-t border-[#DDD5C7] dark:border-[#283C30]">
                <span>應付總額 Total</span>
                <span className="font-mono text-xl text-[#C5A475]">NT$ {finalTotal}</span>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-xl bg-[#1C3328] hover:bg-[#15271F] dark:bg-[#284839] dark:hover:bg-[#345946] text-white text-sm font-serif font-bold tracking-wider shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
            >
              {isSubmitting ? (
                <span className="animate-pulse">正在為您傳送訂單至吧台...</span>
              ) : (
                <>
                  <span>{t.checkout}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
