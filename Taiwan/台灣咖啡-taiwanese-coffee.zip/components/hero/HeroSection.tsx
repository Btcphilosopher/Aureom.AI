'use client';

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { SteamAnimation } from '@/components/common/SteamAnimation';
import { Wifi, ArrowRight, Check, ChevronDown, Sparkles, ShieldCheck } from 'lucide-react';

interface HeroSlide {
  id: string;
  nameZh: string;
  nameEn: string;
  subtitleZh: string;
  subtitleEn: string;
  image: string;
  roastZh: string;
}

const heroSlides: HeroSlide[] = [
  {
    id: 'slide_latte',
    nameZh: '黑糖厚乳拿鐵',
    nameEn: 'Brown Sugar Cream Latte',
    subtitleZh: '台南手工柴燒黑糖炙燒 • 產地小農濃醇鮮乳',
    subtitleEn: 'Tainan Wood-Fired Caramelized Sugar & Estate Milk',
    image: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?q=80&w=1200&auto=format&fit=crop',
    roastZh: '中度烘焙 Medium Roast',
  },
  {
    id: 'slide_pourover',
    nameZh: '阿里山特富野單品手沖',
    nameEn: 'Alishan Single Origin Pour Over',
    subtitleZh: '海拔 1,300m 蜜處理 • 帶有高山烏龍與白花清香',
    subtitleEn: '1,300m Honey Process with Oolong & Jasmine Florals',
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1200&auto=format&fit=crop',
    roastZh: '淺中烘焙 Light-Medium',
  },
  {
    id: 'slide_sicily',
    nameZh: '屏東九如西西里檸檬咖啡',
    nameEn: 'Pingtung Sicily Lemon Coffee',
    subtitleZh: '鮮榨檸檬與微氣泡 • 沁涼酸甜果香',
    subtitleEn: 'Fresh Pingtung Lemon Juice & Sparkling Espresso',
    image: 'https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?q=80&w=1200&auto=format&fit=crop',
    roastZh: '中深烘焙 Medium-Dark',
  },
  {
    id: 'slide_coldbrew',
    nameZh: '16小時慢滴冷萃咖啡',
    nameEn: '16-Hour Slow-Drip Cold Brew',
    subtitleZh: '低溫冰釀發酵 • 散發威士忌與蘭姆酒醇香',
    subtitleEn: 'Slow Ice Drip with Winey Berry & Chocolate Notes',
    image: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?q=80&w=1200&auto=format&fit=crop',
    roastZh: '中度烘焙 Medium',
  },
];

export const HeroSection: React.FC = () => {
  const {
    t,
    lang,
    reducedMotion,
    openWifiModal,
    connectWifi,
    wifiSession,
    openBeanToWifi,
  } = useApp();

  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [agreedTerms, setAgreedTerms] = useState(true);
  const [quickConnecting, setQuickConnecting] = useState(false);
  const [quickOtpSent, setQuickOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');

  // Subtle Mouse Parallax state
  const heroRef = useRef<HTMLDivElement>(null);
  const [parallaxOffset, setParallaxOffset] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    if (reducedMotion || !heroRef.current) return;
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    const x = (clientX / innerWidth - 0.5) * 16;
    const y = (clientY / innerHeight - 0.5) * 16;
    setParallaxOffset({ x, y });
  };

  // Auto cycle carousel gently every 7 seconds
  useEffect(() => {
    if (reducedMotion) return;
    const interval = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev + 1) % heroSlides.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [reducedMotion]);

  const activeSlide = heroSlides[currentSlideIndex];

  const handleQuickWifiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreedTerms) return;

    if (!quickOtpSent) {
      setQuickOtpSent(true);
      setOtpCode('8860'); // Pre-fill sample OTP for convenient demo
    } else {
      setQuickConnecting(true);
      setTimeout(() => {
        connectWifi(phoneNumber || '0912-345-678');
        setQuickConnecting(false);
      }, 1200);
    }
  };

  return (
    <section
      id="hero"
      ref={heroRef}
      onMouseMove={handleMouseMove}
      className="relative min-h-[640px] lg:min-h-[720px] bg-[#FAF8F3] dark:bg-[#121714] overflow-hidden pt-6 pb-12 lg:py-16 transition-colors duration-300"
    >
      {/* Soft warm background radial lighting and watermark character */}
      <div className="absolute inset-0 pointer-events-none opacity-40 dark:opacity-20 overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-radial from-[#F5E8D2] to-transparent rounded-full blur-3xl" />
      </div>
      <div className="absolute -left-12 sm:-left-24 top-1/2 -translate-y-1/2 text-[#E8E1D5] dark:text-[#192720] text-[300px] sm:text-[450px] font-serif leading-none select-none pointer-events-none opacity-50 dark:opacity-25 z-0">
        啡
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
        {/* Main Grid: Left Typography, Center Cup Visual, Right Wi-Fi Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-6 items-center">
          {/* Left Column: Hero Copy & CTA (5 cols on lg) */}
          <div className="lg:col-span-5 flex flex-col justify-center text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EFE9DD] dark:bg-[#1E2922] text-[#1C3328] dark:text-[#C5A475] text-xs font-serif font-medium w-fit mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t.heroBeansOrigin}</span>
            </div>

            <h1
              className="text-3xl sm:text-4xl lg:text-[42px] xl:text-[46px] font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE] leading-[1.2] tracking-wide"
              style={{ fontFamily: '"Noto Serif TC", "Songti TC", "Cinzel", Georgia, serif' }}
            >
              <span className="block">{t.heroHeading1}</span>
              <span className="block">{t.heroHeading2}</span>
            </h1>

            <div className="w-12 h-[2px] bg-[#1C3328] dark:bg-[#C5A475] my-4 sm:my-5" />

            <p className="text-xs sm:text-sm font-sans font-semibold tracking-widest text-[#717E77] dark:text-[#A2B1A8] uppercase mb-2">
              TAIWANESE COFFEE, YOUR DAILY MOMENT
            </p>

            <p className="text-sm sm:text-base font-sans text-[#4A5550] dark:text-[#CBD5CF] leading-relaxed mb-6 sm:mb-8 max-w-md">
              {t.heroSubheading}
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 sm:gap-4">
              <a
                href="#menu"
                id="hero-explore-menu-btn"
                className="inline-flex items-center gap-2 px-6 sm:px-7 py-3 rounded-full bg-[#1C3328] hover:bg-[#14261E] dark:bg-[#284839] dark:hover:bg-[#345946] text-white text-xs sm:text-sm font-serif font-medium tracking-wider shadow-md hover:shadow-lg transition-all duration-300 transform active:scale-95 group"
              >
                <span>{t.heroCtaMenu}</span>
                <span className="text-[10px] uppercase font-sans tracking-widest text-[#C5A475]">
                  EXPLORE MENU
                </span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </a>

              <button
                id="hero-bean-to-wifi-btn"
                onClick={openBeanToWifi}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-[#1C3328]/30 dark:border-[#C5A475]/40 hover:bg-[#EFE9DD] dark:hover:bg-[#1E2922] text-[#1C3328] dark:text-[#F7F4EE] text-xs font-medium transition-colors"
              >
                <span>☕</span>
                <span className="font-serif">{t.heroExploreStory}</span>
              </button>
            </div>
          </div>

          {/* Center Column: Interactive Coffee Cup Showcase (4 cols on lg) */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center relative my-4 lg:my-0">
            <div
              className="relative w-64 h-64 sm:w-76 sm:h-76 md:w-84 md:h-84 flex items-center justify-center transition-transform duration-300 ease-out"
              style={{
                transform: `translate3d(${parallaxOffset.x}px, ${parallaxOffset.y}px, 0)`,
              }}
            >
              {/* Wooden saucer aura & shadow */}
              <div className="absolute inset-x-4 bottom-2 h-12 bg-black/15 dark:bg-black/40 rounded-full blur-xl transform scale-90" />

              {/* Coffee Cup Container with Circular Seal Motif */}
              <div className="relative w-full h-full rounded-2xl overflow-hidden shadow-2xl border-[4px] border-[#FAF8F3] dark:border-[#222E26] bg-[#2C1D11]">
                <Image
                  src={activeSlide.image}
                  alt={activeSlide.nameZh}
                  fill
                  sizes="(max-width: 768px) 100vw, 400px"
                  className="object-cover transition-opacity duration-700 hover:scale-105"
                  priority
                  referrerPolicy="no-referrer"
                />

                {/* Subtle dark vignette overlay for depth */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />

                {/* Steam Rising Animation */}
                <SteamAnimation className="bottom-20" />

                {/* Cup Center Brand Emblem */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <div className="w-12 h-12 rounded-full border border-white/40 backdrop-blur-xs flex items-center justify-center text-white font-serif text-lg font-medium">
                    啡
                  </div>
                  <span className="text-[8px] text-white/80 tracking-[0.25em] font-sans uppercase font-bold mt-1">
                    TAIWAN COFFEE
                  </span>
                </div>

                {/* Current Slide Info Badge */}
                <div className="absolute bottom-3 inset-x-3 text-center bg-black/50 backdrop-blur-sm py-1.5 px-3 rounded-lg text-white">
                  <span className="text-xs font-serif font-medium block">
                    {lang === 'zh-TW' ? activeSlide.nameZh : activeSlide.nameEn}
                  </span>
                  <span className="text-[10px] text-[#C5A475] font-sans font-medium block truncate">
                    {lang === 'zh-TW' ? activeSlide.subtitleZh : activeSlide.subtitleEn}
                  </span>
                </div>
              </div>
            </div>

            {/* Carousel Dots */}
            <div className="flex items-center gap-2.5 mt-5">
              {heroSlides.map((slide, idx) => (
                <button
                  key={slide.id}
                  onClick={() => setCurrentSlideIndex(idx)}
                  className={`transition-all duration-300 rounded-full cursor-pointer ${
                    currentSlideIndex === idx
                      ? 'w-6 h-2 bg-[#1C3328] dark:bg-[#C5A475]'
                      : 'w-2 h-2 bg-[#D1C9BA] dark:bg-[#3D4D43] hover:bg-[#9E9382]'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>
          </div>

          {/* Right Column: Embedded Wi-Fi Quick Access Card (3 cols on lg, matching visual reference) */}
          <div className="lg:col-span-3 flex justify-center lg:justify-end">
            <div
              id="hero-wifi-card"
              className="w-full max-w-[340px] bg-[#FAF8F3] dark:bg-[#19231D] rounded-2xl p-5 sm:p-6 shadow-xl border border-[#E8E2D5] dark:border-[#28392F] transition-all"
            >
              {/* Header */}
              <div className="flex flex-col items-center text-center mb-4">
                <div className="w-10 h-10 rounded-full bg-[#EBF4EE] dark:bg-[#23352B] flex items-center justify-center text-[#1C3328] dark:text-[#88D3A8] mb-2">
                  <Wifi className="w-5 h-5" />
                </div>
                <h3 className="text-base font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE] leading-tight">
                  {t.wifiTitle}
                </h3>
                <p className="text-[10px] font-sans tracking-widest text-[#717E77] dark:text-[#97A59E] uppercase font-semibold">
                  {t.wifiSubtitle}
                </p>
              </div>

              {/* Connected State vs Connect Form */}
              {wifiSession.isConnected ? (
                <div className="bg-[#EBF4EE] dark:bg-[#1D2B22] border border-[#2BB673]/30 rounded-xl p-4 text-center">
                  <div className="w-8 h-8 rounded-full bg-[#2BB673] text-white flex items-center justify-center mx-auto mb-2">
                    <Check className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-serif font-bold text-[#1C3328] dark:text-[#E8EAE8] block">
                    {t.wifiConnected}
                  </span>
                  <span className="text-[10px] text-[#3F7556] dark:text-[#88D3A8] block font-mono mt-0.5">
                    SSID: TAIWANCOFFEE_FREE
                  </span>
                  <button
                    onClick={openWifiModal}
                    className="mt-3 w-full py-2 rounded-lg bg-[#1C3328] text-white text-xs font-medium hover:bg-[#15271F] transition-colors"
                  >
                    查看 Wi-Fi 面板
                  </button>
                </div>
              ) : (
                <form onSubmit={handleQuickWifiSubmit} className="flex flex-col gap-3">
                  {/* Tabs */}
                  <div className="grid grid-cols-2 p-1 bg-[#EFE9DD] dark:bg-[#121A15] rounded-xl text-center text-xs">
                    <button
                      type="button"
                      className="py-1.5 rounded-lg bg-white dark:bg-[#223028] font-serif font-semibold text-[#1C3328] dark:text-[#F7F4EE] shadow-2xs"
                    >
                      <span className="block text-[11px] leading-tight">{t.wifiTabMobile}</span>
                      <span className="block text-[8px] font-sans text-[#717E77] tracking-wider uppercase">
                        MOBILE
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={openWifiModal}
                      className="py-1.5 text-[#717E77] dark:text-[#8E9D95] hover:text-[#1C3328] font-serif"
                    >
                      <span className="block text-[11px] leading-tight">{t.wifiTabAccount}</span>
                      <span className="block text-[8px] font-sans text-[#717E77] tracking-wider uppercase">
                        ACCOUNT
                      </span>
                    </button>
                  </div>

                  {/* Phone Input or OTP Input */}
                  {!quickOtpSent ? (
                    <div className="flex items-center bg-white dark:bg-[#121A15] border border-[#DDD5C7] dark:border-[#2C3D32] rounded-xl p-2 focus-within:border-[#1C3328] transition-colors">
                      <div className="flex items-center gap-1 pr-2 border-r border-[#E8E2D5] dark:border-[#2C3D32] text-xs font-medium text-[#1F2421] dark:text-[#E8EAE8] select-none">
                        <span>🇹🇼</span>
                        <span>+886</span>
                        <ChevronDown className="w-3 h-3 text-[#717E77]" />
                      </div>
                      <input
                        type="tel"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        placeholder="請輸入手機號碼"
                        className="w-full pl-2 text-xs bg-transparent text-[#1F2421] dark:text-[#E8EAE8] placeholder-[#9E9589] focus:outline-hidden"
                      />
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="bg-[#EBF4EE] dark:bg-[#1D2B22] p-2 rounded-lg text-center">
                        <span className="text-[11px] text-[#1C3328] dark:text-[#A0CBB3] font-medium block">
                          驗證碼已發送至手機
                        </span>
                        <span className="text-[9px] text-[#717E77] block">
                          (測試碼已自動帶入：8860)
                        </span>
                      </div>
                      <input
                        type="text"
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value)}
                        placeholder="4位數驗證碼"
                        maxLength={6}
                        className="w-full text-center text-sm font-mono tracking-widest bg-white dark:bg-[#121A15] border border-[#DDD5C7] dark:border-[#2C3D32] rounded-xl p-2 text-[#1F2421] dark:text-[#E8EAE8] focus:outline-hidden focus:border-[#1C3328]"
                      />
                    </div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={quickConnecting}
                    className="w-full py-2.5 rounded-xl bg-[#1C3328] hover:bg-[#14261E] dark:bg-[#2A4839] dark:hover:bg-[#355A47] text-white text-xs font-serif font-bold tracking-wider shadow-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-75"
                  >
                    {quickConnecting ? (
                      <span className="animate-pulse">正在連線 Wi-Fi...</span>
                    ) : quickOtpSent ? (
                      <span>連線 Wi-Fi CONNECT</span>
                    ) : (
                      <span>取得驗證碼 GET CODE</span>
                    )}
                  </button>

                  {/* Terms Checkbox */}
                  <label className="flex items-start gap-2 cursor-pointer select-none text-[10px] text-[#717E77] dark:text-[#97A59E] leading-tight">
                    <input
                      type="checkbox"
                      checked={agreedTerms}
                      onChange={(e) => setAgreedTerms(e.target.checked)}
                      className="mt-0.5 rounded border-[#C4B9A7] text-[#1C3328] focus:ring-[#1C3328]"
                    />
                    <span>{t.wifiTermsAgree}</span>
                  </label>

                  {/* Other login options */}
                  <button
                    type="button"
                    onClick={openWifiModal}
                    className="text-center text-[10px] text-[#717E77] dark:text-[#97A59E] hover:text-[#1C3328] dark:hover:text-[#C5A475] pt-1 transition-colors flex items-center justify-center gap-1"
                  >
                    <ShieldCheck className="w-3 h-3" />
                    <span>{t.wifiOtherOptions}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
