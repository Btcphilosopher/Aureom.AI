'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { X, ArrowRight, ArrowLeft, Wifi, Sparkles, Check } from 'lucide-react';

export const SignatureStoryModal: React.FC = () => {
  const { isBeanToWifiOpen, closeBeanToWifi, openWifiModal, t } = useApp();
  const [currentStep, setCurrentStep] = useState(0);

  if (!isBeanToWifiOpen) return null;

  const journeySteps = [
    {
      step: 1,
      char: '豆',
      titleZh: '咖啡果實 • 山林育種',
      titleEn: 'THE COFFEE BEAN',
      descZh: '生長於台灣阿里山海拔 1,300 公尺之高山雲霧間，吸取甘泉純淨養分，孕育極致糖度。',
      descEn: 'Born in the alpine mists of Alishan at 1,300m, absorbing pure mountain water and floral terroir.',
      image: 'https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?q=80&w=800&auto=format&fit=crop',
      accent: '#C5A475',
    },
    {
      step: 2,
      char: '焙',
      titleZh: '職人烘焙 • 鎖住香氣',
      titleEn: 'ARTISANAL ROAST',
      descZh: '於台北烘豆工坊小批次淺中焙，精準控溫，釋放標誌性的白花香氣與高山烏龍茶感。',
      descEn: 'Small-batch roasted in Taipei to unlock vibrant floral notes and distinctive oolong sweetness.',
      image: 'https://images.unsplash.com/photo-1518832553480-cd0e625ed3e6?q=80&w=800&auto=format&fit=crop',
      accent: '#8E5B32',
    },
    {
      step: 3,
      char: '萃',
      titleZh: '精準手沖 • 滴滴香醇',
      titleEn: 'PERFECT EXTRACTION',
      descZh: '以 91°C 熱水與細緻注水螺旋，精確萃取每一顆咖啡粉的芳香精華。',
      descEn: 'Water flows at 91°C in delicate spirals, capturing the pure essence of Taiwanese terroir.',
      image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800&auto=format&fit=crop',
      accent: '#2A4839',
    },
    {
      step: 4,
      char: '杯',
      titleZh: '鶯歌陶杯 • 溫暖盛裝',
      titleEn: 'THE CERAMIC CUP',
      descZh: '以在地陶藝家手作陶器呈遞，傳遞台灣土地的厚實人情與溫暖。',
      descEn: 'Served in handcrafted Yingge ceramics for authentic warmth and tactile elegance.',
      image: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?q=80&w=800&auto=format&fit=crop',
      accent: '#1C3328',
    },
    {
      step: 5,
      char: '網',
      titleZh: 'Wi-Fi 6 極速 • 連結社群',
      titleEn: 'COMMUNITY & WI-FI',
      descZh: '在咖啡香氣縈繞的空間裡，Wi-Fi 6 高速覆蓋，為您的靈感、工作與對話賦予無限可能。',
      descEn: 'Surrounded by rich coffee aroma, high-speed Wi-Fi 6 connects you seamlessly with the world.',
      image: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=800&auto=format&fit=crop',
      accent: '#2BB673',
    },
  ];

  const current = journeySteps[currentStep];

  return (
    <div
      id="signature-journey-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeBeanToWifi();
      }}
    >
      <div
        id="signature-journey-content"
        className="w-full max-w-2xl bg-[#FAF8F3] dark:bg-[#151F19] rounded-3xl shadow-2xl border border-[#E8E2D5] dark:border-[#283C30] overflow-hidden flex flex-col"
      >
        {/* Header */}
        <div className="bg-[#1C3328] dark:bg-[#0E1712] text-white p-5 flex items-center justify-between border-b border-[#284839]">
          <div className="flex items-center gap-2.5">
            <span className="text-xl">☕</span>
            <div>
              <h2 className="text-base font-serif font-bold">FROM BEAN TO WI-FI</h2>
              <p className="text-[10px] font-sans tracking-widest text-[#C5A475] uppercase">
                從產地豆香到極速連線的完整生態
              </p>
            </div>
          </div>
          <button
            onClick={closeBeanToWifi}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="grid grid-cols-5 p-2 bg-[#EFE9DD] dark:bg-[#121A15] border-b border-[#DDD5C7] dark:border-[#223028]">
          {journeySteps.map((s, idx) => (
            <button
              key={s.step}
              onClick={() => setCurrentStep(idx)}
              className={`py-1.5 flex flex-col items-center justify-center transition-all ${
                currentStep === idx
                  ? 'bg-white dark:bg-[#203127] rounded-xl shadow-xs text-[#1C3328] dark:text-[#E8EAE8]'
                  : 'text-[#717E77] hover:text-[#1C3328]'
              }`}
            >
              <span className="text-sm font-serif font-bold leading-none">{s.char}</span>
              <span className="text-[9px] font-sans uppercase font-medium mt-0.5">
                STEP {s.step}
              </span>
            </button>
          ))}
        </div>

        {/* Body Content */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          {/* Image */}
          <div className="relative w-full h-56 md:h-64 rounded-2xl overflow-hidden shadow-md border-2 border-[#FAF8F3] dark:border-[#223028]">
            <Image
              src={current.image}
              alt={current.titleZh}
              fill
              className="object-cover transition-transform duration-700 hover:scale-105"
              sizes="(max-width: 768px) 100vw, 350px"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs text-white text-xs font-serif font-bold px-2.5 py-1 rounded-md">
              {current.char} • {current.titleEn}
            </div>
          </div>

          {/* Details */}
          <div className="flex flex-col justify-center text-left space-y-3">
            <span className="text-xs font-mono font-bold tracking-widest text-[#C5A475]">
              PHASE 0{current.step} / 05
            </span>
            <h3 className="text-xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
              {current.titleZh}
            </h3>
            <p className="text-xs text-[#55635C] dark:text-[#C5D0C9] leading-relaxed">
              {current.descZh}
            </p>
            <p className="text-[11px] text-[#717E77] dark:text-[#8E9D95] leading-relaxed italic">
              {current.descEn}
            </p>

            {/* Navigation buttons */}
            <div className="flex items-center gap-3 pt-3">
              {currentStep > 0 && (
                <button
                  onClick={() => setCurrentStep((prev) => prev - 1)}
                  className="p-2.5 rounded-xl border border-[#DDD5C7] dark:border-[#2C3D32] text-[#1F2421] dark:text-[#E8EAE8] hover:bg-[#EFE9DD] transition-colors"
                  aria-label="Previous step"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
              )}

              {currentStep < journeySteps.length - 1 ? (
                <button
                  onClick={() => setCurrentStep((prev) => prev + 1)}
                  className="flex-1 py-2.5 rounded-xl bg-[#1C3328] dark:bg-[#284839] text-white text-xs font-serif font-bold tracking-wider hover:bg-[#15271F] transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <span>下一步 NEXT</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={() => {
                    closeBeanToWifi();
                    openWifiModal();
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-[#2BB673] hover:bg-[#249E63] text-white text-xs font-serif font-bold tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow-md animate-pulse"
                >
                  <Wifi className="w-4 h-4" />
                  <span>立即連線 WI-FI ACCESS</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
