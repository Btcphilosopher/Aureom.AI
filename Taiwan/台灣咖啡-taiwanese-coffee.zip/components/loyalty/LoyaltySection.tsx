'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { loyaltyTiersData, loyaltyRewardsData } from '@/data/loyaltyData';
import { Award, Sparkles, Check, Gift, QrCode, Shield, ChevronRight } from 'lucide-react';

export const LoyaltySection: React.FC = () => {
  const { loyaltyMember, redeemLoyaltyReward, t, lang } = useApp();
  const [activeTab, setActiveTab] = useState<'card' | 'rewards' | 'tiers'>('card');
  const [redeemSuccessMsg, setRedeemSuccessMsg] = useState<string | null>(null);

  const handleRedeem = (rewardId: string, rewardName: string, cost: number) => {
    if (loyaltyMember.points < cost) {
      alert(
        lang === 'zh-TW'
          ? `點數不足！需要 ${cost} 點，目前擁有 ${loyaltyMember.points} 點。`
          : `Insufficient points! Requires ${cost} points, you currently have ${loyaltyMember.points}.`
      );
      return;
    }

    const success = redeemLoyaltyReward(rewardId);
    if (success) {
      setRedeemSuccessMsg(
        lang === 'zh-TW' ? `兌換成功！已獲得「${rewardName}」` : `Redeemed ${rewardName}!`
      );
      setTimeout(() => setRedeemSuccessMsg(null), 4000);
    }
  };

  return (
    <section
      id="loyalty"
      className="w-full bg-[#FAF8F3] dark:bg-[#121714] py-14 sm:py-20 border-t border-b border-[#EFE9DC] dark:border-[#1E2922] transition-colors"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EFE9DD] dark:bg-[#1E2922] text-[#1C3328] dark:text-[#C5A475] text-xs font-serif font-medium mb-3">
            <Award className="w-3.5 h-3.5" />
            <span>台灣咖啡 尊爵會員計劃</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
            {t.loyaltyTitle}
          </h2>
          <p className="text-xs sm:text-sm font-sans tracking-widest text-[#717E77] dark:text-[#97A59E] uppercase font-semibold mt-1">
            {t.loyaltySubtitle}
          </p>
          <div className="w-12 h-[2px] bg-[#1C3328] dark:bg-[#C5A475] mt-3" />
        </div>

        {/* Tab switchers */}
        <div className="flex justify-center gap-2 mb-8">
          <button
            onClick={() => setActiveTab('card')}
            className={`px-5 py-2 rounded-full text-xs font-serif font-semibold transition-all ${
              activeTab === 'card'
                ? 'bg-[#1C3328] text-white dark:bg-[#C5A475] dark:text-[#121714]'
                : 'bg-[#EFE9DD] dark:bg-[#1C2822] text-[#55635C] dark:text-[#CBD5CF]'
            }`}
          >
            我的會員卡
          </button>
          <button
            onClick={() => setActiveTab('rewards')}
            className={`px-5 py-2 rounded-full text-xs font-serif font-semibold transition-all ${
              activeTab === 'rewards'
                ? 'bg-[#1C3328] text-white dark:bg-[#C5A475] dark:text-[#121714]'
                : 'bg-[#EFE9DD] dark:bg-[#1C2822] text-[#55635C] dark:text-[#CBD5CF]'
            }`}
          >
            點數兌換專區
          </button>
          <button
            onClick={() => setActiveTab('tiers')}
            className={`px-5 py-2 rounded-full text-xs font-serif font-semibold transition-all ${
              activeTab === 'tiers'
                ? 'bg-[#1C3328] text-white dark:bg-[#C5A475] dark:text-[#121714]'
                : 'bg-[#EFE9DD] dark:bg-[#1C2822] text-[#55635C] dark:text-[#CBD5CF]'
            }`}
          >
            會員等級權益
          </button>
        </div>

        {/* Success Alert */}
        {redeemSuccessMsg && (
          <div className="max-w-md mx-auto mb-6 p-3 bg-[#EBF4EE] dark:bg-[#192D22] border border-[#2BB673] rounded-xl text-center text-xs font-serif font-bold text-[#1C3328] dark:text-[#88D3A8] animate-fade-in">
            {redeemSuccessMsg}
          </div>
        )}

        {/* TAB 1: DIGITAL CARD VIEW */}
        {activeTab === 'card' && (
          <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* The Digital Card itself */}
            <div className="md:col-span-6 flex justify-center">
              <div
                id="digital-loyalty-card"
                className="w-full max-w-sm h-56 rounded-2xl bg-gradient-to-br from-[#1C3328] via-[#2A4839] to-[#0E1B15] p-6 text-white shadow-2xl flex flex-col justify-between relative overflow-hidden border border-[#C5A475]/30"
              >
                {/* Gold aura */}
                <div className="absolute top-0 right-0 w-40 h-40 bg-[#C5A475]/15 rounded-full blur-2xl pointer-events-none" />

                {/* Card Top */}
                <div className="flex items-start justify-between relative z-10">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full border border-white/40 flex items-center justify-center font-serif text-sm font-bold text-[#C5A475]">
                      啡
                    </div>
                    <div>
                      <span className="text-xs font-serif font-bold tracking-wider block">
                        台灣咖啡
                      </span>
                      <span className="text-[8px] font-sans tracking-[0.2em] text-[#C5A475] uppercase">
                        BLACK GOLD CARD
                      </span>
                    </div>
                  </div>

                  <span className="px-2.5 py-0.5 rounded-full bg-[#C5A475]/20 border border-[#C5A475]/50 text-[#C5A475] text-[10px] font-mono font-bold">
                    {loyaltyMember.tierZh}
                  </span>
                </div>

                {/* Card Middle: Points */}
                <div className="relative z-10">
                  <span className="text-[10px] font-sans text-white/70 uppercase tracking-wider block">
                    CURRENT REWARD POINTS
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-mono font-bold text-[#C5A475]">
                      {loyaltyMember.points}
                    </span>
                    <span className="text-xs font-serif text-white/80">點 POINTS</span>
                  </div>
                </div>

                {/* Card Bottom: Member Name & Barcode */}
                <div className="flex items-end justify-between relative z-10 pt-2 border-t border-white/15 text-xs">
                  <div>
                    <span className="font-serif block font-medium">
                      {loyaltyMember.memberName}
                    </span>
                    <span className="text-[10px] font-mono text-white/60">
                      {loyaltyMember.memberNumber}
                    </span>
                  </div>
                  <QrCode className="w-7 h-7 text-white/80" />
                </div>
              </div>
            </div>

            {/* Loyalty Summary */}
            <div className="md:col-span-6 text-left space-y-4">
              <div>
                <span className="text-xs font-mono text-[#C5A475] font-bold tracking-wider">
                  MEMBER STATUS
                </span>
                <h3 className="text-xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
                  您好，{loyaltyMember.memberName}
                </h3>
                <p className="text-xs text-[#55635C] dark:text-[#CBD5CF] mt-1">
                  您目前享有「{loyaltyMember.tierZh}」之專屬待遇。距離下一等級僅差 120 點。
                </p>
              </div>

              {/* Quick Perks */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2 text-[#1F2421] dark:text-[#E8EAE8]">
                  <Check className="w-4 h-4 text-[#2BB673]" />
                  <span>門市消費每滿 NT$30 累積 1 點</span>
                </div>
                <div className="flex items-center gap-2 text-[#1F2421] dark:text-[#E8EAE8]">
                  <Check className="w-4 h-4 text-[#2BB673]" />
                  <span>免費升級植物奶（燕麥奶 / 杏仁奶）</span>
                </div>
                <div className="flex items-center gap-2 text-[#1F2421] dark:text-[#E8EAE8]">
                  <Check className="w-4 h-4 text-[#2BB673]" />
                  <span>Wi-Fi 6 會員專屬高優先級頻寬通道</span>
                </div>
              </div>

              <button
                onClick={() => setActiveTab('rewards')}
                className="py-2.5 px-6 rounded-full bg-[#1C3328] hover:bg-[#14261E] dark:bg-[#284839] text-white text-xs font-serif font-medium tracking-wider shadow-sm transition-all"
              >
                瀏覽可兌換之飲品與甜點
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: REWARDS CATALOG */}
        {activeTab === 'rewards' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {loyaltyRewardsData.map((reward) => (
              <div
                key={reward.id}
                className="bg-white dark:bg-[#18231D] rounded-2xl p-5 border border-[#E8E2D5] dark:border-[#283C30] shadow-sm flex flex-col justify-between text-left"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xl">🎁</span>
                    <span className="px-2 py-0.5 rounded-full bg-[#FAF0E4] dark:bg-[#2C2117] text-[#8E5B32] dark:text-[#C5A475] font-mono text-xs font-bold">
                      {reward.pointsCost} 點
                    </span>
                  </div>
                  <h4 className="text-sm font-serif font-bold text-[#1F2421] dark:text-[#F7F4EE]">
                    {lang === 'zh-TW' ? reward.nameZh : reward.nameEn}
                  </h4>
                  <p className="text-xs text-[#55635C] dark:text-[#97A59E] mt-1">
                    {lang === 'zh-TW' ? reward.descriptionZh : reward.descriptionEn}
                  </p>
                </div>

                <button
                  onClick={() =>
                    handleRedeem(
                      reward.id,
                      lang === 'zh-TW' ? reward.nameZh : reward.nameEn,
                      reward.pointsCost
                    )
                  }
                  className="mt-4 w-full py-2 rounded-xl bg-[#1C3328] hover:bg-[#14261E] dark:bg-[#284839] text-white text-xs font-serif font-semibold transition-colors cursor-pointer"
                >
                  立即兌換 REDEEM
                </button>
              </div>
            ))}
          </div>
        )}

        {/* TAB 3: TIERS OVERVIEW */}
        {activeTab === 'tiers' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto text-left">
            {loyaltyTiersData.map((tier) => (
              <div
                key={tier.tier}
                className="bg-white dark:bg-[#18231D] rounded-2xl p-6 border border-[#E8E2D5] dark:border-[#283C30] shadow-sm flex flex-col justify-between"
              >
                <div>
                  <span className="text-xs font-sans tracking-widest text-[#C5A475] uppercase font-bold">
                    TIER {tier.tier.toUpperCase()}
                  </span>
                  <h4 className="text-lg font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE] mt-1">
                    {lang === 'zh-TW' ? tier.nameZh : tier.nameEn}
                  </h4>
                  <span className="text-xs text-[#717E77] block mt-0.5">
                    累積門檻: {tier.minPoints} 點起
                  </span>

                  <ul className="mt-4 space-y-2 text-xs text-[#4A5550] dark:text-[#CBD5CF]">
                    {(lang === 'zh-TW' ? tier.perksZh : tier.perksEn).map((perk, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-[#2BB673] shrink-0" />
                        <span>{perk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};
