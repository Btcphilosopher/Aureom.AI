'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { Logo } from '@/components/common/Logo';
import { Wifi, ShoppingBag, Menu as MenuIcon, X, Award, ChevronRight } from 'lucide-react';

export const MainNav: React.FC = () => {
  const {
    t,
    cartCount,
    openCart,
    openWifiModal,
    wifiSession,
    activeOrder,
    openOrderTracker,
  } = useApp();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#hero', labelZh: '首頁', labelEn: 'HOME' },
    { href: '#farm-story', labelZh: '關於我們', labelEn: 'ABOUT' },
    { href: '#menu', labelZh: '菜單', labelEn: 'MENU' },
    { href: '#locations', labelZh: '門市資訊', labelEn: 'LOCATIONS' },
    { href: '#coffee-life', labelZh: '咖啡生活', labelEn: 'COFFEE LIFE' },
    { href: '#contact', labelZh: '聯絡我們', labelEn: 'CONTACT' },
  ];

  return (
    <header
      id="main-navigation"
      className={`sticky top-0 w-full z-30 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAF8F3]/95 dark:bg-[#121714]/95 backdrop-blur-md shadow-sm py-2.5 sm:py-3 border-b border-[#E8E2D5] dark:border-[#222E26]'
          : 'bg-[#FAF8F3] dark:bg-[#121714] py-4 sm:py-5 border-b border-[#EFE9DC] dark:border-[#1E2922]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <a
          href="#hero"
          className="flex items-center gap-2 group transition-opacity hover:opacity-90"
          id="nav-brand-link"
        >
          <Logo size={isScrolled ? 'sm' : 'md'} variant="dark" />
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 xl:gap-8" aria-label="Main Navigation">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="flex flex-col items-center text-center group py-1"
            >
              <span className="text-sm font-serif font-medium text-[#1F2421] dark:text-[#E8EAE8] group-hover:text-[#1C3328] dark:group-hover:text-[#C5A475] transition-colors leading-tight">
                {link.labelZh}
              </span>
              <span className="text-[10px] font-sans font-medium tracking-widest text-[#717E77] dark:text-[#8E9D95] group-hover:text-[#1C3328] dark:group-hover:text-[#C5A475] transition-colors uppercase">
                {link.labelEn}
              </span>
            </a>
          ))}
        </nav>

        {/* Right Actions: Live Order Button (if active), Cart, and Dark Green Wi-Fi Pill */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Active Order status pill */}
          {activeOrder && (
            <button
              id="nav-active-order-btn"
              onClick={openOrderTracker}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#EBF4EE] dark:bg-[#1C3328] border border-[#3E7D5C]/30 text-[#1C3328] dark:text-[#88D3A8] text-xs font-medium hover:bg-[#D8ECE0] transition-colors shadow-2xs"
            >
              <span className="w-2 h-2 rounded-full bg-[#2BB673] animate-pulse" />
              <span>#{activeOrder.orderNumber} 製作中</span>
            </button>
          )}

          {/* Cart Icon Button */}
          <button
            id="nav-cart-btn"
            onClick={openCart}
            className="relative p-2 rounded-full text-[#1C3328] dark:text-[#E8EAE8] hover:bg-[#EFE9DD] dark:hover:bg-[#1C2620] transition-colors cursor-pointer"
            aria-label={`Cart with ${cartCount} items`}
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#C5A475] text-white font-bold text-[10px] w-5 h-5 rounded-full flex items-center justify-center shadow-xs animate-scale">
                {cartCount}
              </span>
            )}
          </button>

          {/* Large Dark-Green Pill Wi-Fi Button */}
          <button
            id="nav-wifi-login-btn"
            onClick={openWifiModal}
            className="relative inline-flex items-center gap-2.5 px-4 sm:px-6 py-2 sm:py-2.5 rounded-full bg-[#1C3328] hover:bg-[#15271F] dark:bg-[#2A4839] dark:hover:bg-[#345946] text-white shadow-sm hover:shadow-md transition-all duration-300 transform active:scale-95 cursor-pointer group"
          >
            <div className="relative flex items-center justify-center">
              <Wifi
                className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                  wifiSession.isConnected ? 'text-[#88D3A8]' : 'text-white'
                }`}
              />
              {wifiSession.isConnected ? (
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-[#48DF8D] rounded-full ring-2 ring-[#1C3328] animate-pulse" />
              ) : null}
            </div>

            <div className="flex flex-col text-left">
              <span className="text-xs sm:text-sm font-serif font-bold tracking-wide leading-none">
                {wifiSession.isConnected ? 'Wi-Fi 已連線' : t.navWifiLogin}
              </span>
              <span className="text-[9px] font-sans tracking-wider uppercase text-[#C5A475] font-semibold leading-none mt-0.5">
                {wifiSession.isConnected ? 'CONNECTED' : 'WI-FI LOGIN'}
              </span>
            </div>
          </button>

          {/* Mobile Menu Hamburger */}
          <button
            id="mobile-menu-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-[#1C3328] dark:text-[#E8EAE8] hover:bg-[#EFE9DD] dark:hover:bg-[#1C2620] transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="lg:hidden bg-[#FAF8F3] dark:bg-[#121714] border-b border-[#E8E2D5] dark:border-[#222E26] px-6 py-5 shadow-lg transition-all"
        >
          <div className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center justify-between py-2.5 border-b border-[#EFE9DC]/60 dark:border-[#1E2922]/60 text-[#1F2421] dark:text-[#E8EAE8]"
              >
                <div>
                  <span className="text-base font-serif font-semibold block">{link.labelZh}</span>
                  <span className="text-xs font-sans text-[#717E77] tracking-wider uppercase font-medium">
                    {link.labelEn}
                  </span>
                </div>
                <ChevronRight className="w-4 h-4 text-[#717E77]" />
              </a>
            ))}

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openWifiModal();
              }}
              className="mt-2 w-full py-3 rounded-xl bg-[#1C3328] text-white flex items-center justify-center gap-2 font-medium"
            >
              <Wifi className="w-4 h-4" />
              <span>{wifiSession.isConnected ? '查看 Wi-Fi 狀態' : '連線免費 Wi-Fi'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
