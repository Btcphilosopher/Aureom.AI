'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Home, Coffee, ShoppingBag, Wifi, Award } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const {
    cartCount,
    openCart,
    openWifiModal,
    wifiSession,
    activeOrder,
    openOrderTracker,
  } = useApp();

  return (
    <div
      id="mobile-bottom-nav"
      className="fixed bottom-0 inset-x-0 bg-[#FAF8F3]/95 dark:bg-[#121714]/95 backdrop-blur-lg border-t border-[#E8E2D5] dark:border-[#222E26] py-2 px-3 flex items-center justify-around z-30 lg:hidden shadow-lg"
    >
      {/* Home */}
      <a
        href="#hero"
        className="flex flex-col items-center justify-center text-[#55635C] dark:text-[#97A59E] hover:text-[#1C3328] dark:hover:text-[#E8EAE8] py-1 px-2"
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px] font-sans font-medium mt-0.5">首頁</span>
      </a>

      {/* Menu */}
      <a
        href="#menu"
        className="flex flex-col items-center justify-center text-[#55635C] dark:text-[#97A59E] hover:text-[#1C3328] dark:hover:text-[#E8EAE8] py-1 px-2"
      >
        <Coffee className="w-5 h-5" />
        <span className="text-[10px] font-sans font-medium mt-0.5">菜單</span>
      </a>

      {/* Wi-Fi Prominent Center Button */}
      <button
        onClick={openWifiModal}
        className="relative -top-3 flex flex-col items-center justify-center bg-[#1C3328] dark:bg-[#2A4839] text-white w-13 h-13 rounded-full shadow-md active:scale-95 transition-transform"
        aria-label="Wi-Fi Login"
      >
        <Wifi className={`w-6 h-6 ${wifiSession.isConnected ? 'text-[#7FE5A8]' : 'text-white'}`} />
        <span className="text-[8px] font-sans font-bold uppercase tracking-wider mt-0.5 text-[#C5A475]">
          {wifiSession.isConnected ? 'LIVE' : 'WI-FI'}
        </span>
        {wifiSession.isConnected && (
          <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-[#34D399] ring-2 ring-[#1C3328] animate-pulse" />
        )}
      </button>

      {/* Orders / Cart */}
      <button
        onClick={() => {
          if (activeOrder) {
            openOrderTracker();
          } else {
            openCart();
          }
        }}
        className="relative flex flex-col items-center justify-center text-[#55635C] dark:text-[#97A59E] hover:text-[#1C3328] dark:hover:text-[#E8EAE8] py-1 px-2"
        aria-label="Orders and Cart"
      >
        <ShoppingBag className="w-5 h-5" />
        <span className="text-[10px] font-sans font-medium mt-0.5">
          {activeOrder ? '進度' : '訂單'}
        </span>
        {cartCount > 0 && !activeOrder && (
          <span className="absolute top-0 right-1 bg-[#C5A475] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
            {cartCount}
          </span>
        )}
        {activeOrder && (
          <span className="absolute top-0 right-1 bg-[#2BB673] w-2.5 h-2.5 rounded-full animate-ping" />
        )}
      </button>

      {/* Member Loyalty */}
      <a
        href="#loyalty"
        className="flex flex-col items-center justify-center text-[#55635C] dark:text-[#97A59E] hover:text-[#1C3328] dark:hover:text-[#E8EAE8] py-1 px-2"
      >
        <Award className="w-5 h-5" />
        <span className="text-[10px] font-sans font-medium mt-0.5">會員</span>
      </a>
    </div>
  );
};
