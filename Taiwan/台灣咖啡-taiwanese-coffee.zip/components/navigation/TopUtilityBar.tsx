'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { MapPin, Clock, Instagram, Facebook, MessageCircle, Moon, Sun, Eye } from 'lucide-react';

export const TopUtilityBar: React.FC = () => {
  const { lang, setLang, t, theme, toggleTheme, reducedMotion, setReducedMotion } = useApp();

  return (
    <div
      id="top-utility-bar"
      className="w-full bg-[#1C3328] dark:bg-[#111C16] text-[#E5E0D5] text-xs py-2 px-4 sm:px-8 border-b border-[#284839] transition-colors duration-300 z-40 relative"
    >
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-y-2">
        {/* Left: Address and Hours */}
        <div className="flex items-center gap-3 sm:gap-6 text-[11px] sm:text-xs">
          <div className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer">
            <MapPin className="w-3.5 h-3.5 text-[#C5A475]" />
            <span className="truncate max-w-[200px] sm:max-w-none">{t.topAddress}</span>
          </div>

          <span className="text-[#3A5D4B] hidden sm:inline">•</span>

          <div className="flex items-center gap-1.5 hover:text-white transition-colors">
            <Clock className="w-3.5 h-3.5 text-[#C5A475]" />
            <span>{t.topHours}</span>
          </div>
        </div>

        {/* Right: Language switch, Accessibility, Dark mode, Social icons */}
        <div className="flex items-center gap-4 sm:gap-5 ml-auto text-[11px] sm:text-xs">
          {/* Language Switch */}
          <div className="flex items-center gap-2 font-medium tracking-wide">
            <button
              id="btn-lang-zh"
              onClick={() => setLang('zh-TW')}
              className={`transition-colors cursor-pointer ${
                lang === 'zh-TW'
                  ? 'text-white font-bold underline underline-offset-4 decoration-[#C5A475]'
                  : 'text-[#B4C0B9] hover:text-white'
              }`}
            >
              繁體中文
            </button>
            <span className="text-[#3A5D4B]">|</span>
            <button
              id="btn-lang-en"
              onClick={() => setLang('en')}
              className={`transition-colors cursor-pointer ${
                lang === 'en'
                  ? 'text-white font-bold underline underline-offset-4 decoration-[#C5A475]'
                  : 'text-[#B4C0B9] hover:text-white'
              }`}
            >
              ENGLISH
            </button>
          </div>

          <span className="text-[#3A5D4B] hidden xs:inline">•</span>

          {/* Accessibility & Theme Toggles */}
          <div className="flex items-center gap-2">
            <button
              id="btn-theme-toggle"
              onClick={toggleTheme}
              title={theme === 'light' ? '切換至夜間沉浸模式' : '切換至日間白晝模式'}
              className="p-1 rounded-full text-[#B4C0B9] hover:text-white hover:bg-[#284839] transition-colors cursor-pointer"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? (
                <Moon className="w-3.5 h-3.5" />
              ) : (
                <Sun className="w-3.5 h-3.5 text-[#E6C687]" />
              )}
            </button>

            <button
              id="btn-motion-toggle"
              onClick={() => setReducedMotion(!reducedMotion)}
              title={reducedMotion ? '啟用完整動態' : '啟用減弱動態模式 (Reduced Motion)'}
              className={`p-1 rounded-full transition-colors cursor-pointer ${
                reducedMotion
                  ? 'text-[#C5A475] bg-[#284839]'
                  : 'text-[#B4C0B9] hover:text-white hover:bg-[#284839]'
              }`}
              aria-label="Toggle reduced motion"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
          </div>

          <span className="text-[#3A5D4B] hidden sm:inline">•</span>

          {/* Social Links */}
          <div className="hidden sm:flex items-center gap-2.5 text-[#B4C0B9]">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="Instagram"
            >
              <Instagram className="w-3.5 h-3.5" />
            </a>
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="Facebook"
            >
              <Facebook className="w-3.5 h-3.5" />
            </a>
            <a
              href="https://line.me"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
              aria-label="LINE Official Account"
            >
              <MessageCircle className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
