'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Logo } from '@/components/common/Logo';
import {
  MapPin,
  Clock,
  Phone,
  Mail,
  Instagram,
  Facebook,
  MessageCircle,
  Wifi,
  ArrowRight,
  Heart,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { t, openWifiModal } = useApp();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setSubscribed(true);
  };

  return (
    <footer
      id="contact"
      className="w-full bg-[#1C3328] dark:bg-[#0D1510] text-[#E5E0D5] pt-14 pb-24 lg:pb-14 border-t border-[#2A4839] transition-colors"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-[#284839]">
          {/* Brand Info (4 cols on lg) */}
          <div className="lg:col-span-4 flex flex-col text-left">
            <Logo size="lg" variant="light" className="mb-4" />
            <p className="text-xs text-[#B4C0B9] leading-relaxed max-w-sm mb-6">
              嚴選台灣阿里山、屏東、南投及雲林在地莊園咖啡豆，以細緻手沖與現代空間，融合高頻高速聯網體驗，陪伴您每一個靈感與靜心時刻。
            </p>

            {/* Social Icons */}
            <div className="flex items-center gap-3 text-[#C5A475]">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full border border-[#284839] hover:border-[#C5A475] flex items-center justify-center transition-colors hover:text-white"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full border border-[#284839] hover:border-[#C5A475] flex items-center justify-center transition-colors hover:text-white"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://line.me"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full border border-[#284839] hover:border-[#C5A475] flex items-center justify-center transition-colors hover:text-white"
                aria-label="Line"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links (2 cols on lg) */}
          <div className="lg:col-span-2 flex flex-col text-left space-y-3 text-xs">
            <h4 className="text-sm font-serif font-bold text-white tracking-wider">探索導覽</h4>
            <a href="#hero" className="text-[#B4C0B9] hover:text-white transition-colors">
              品牌首頁 Home
            </a>
            <a href="#farm-story" className="text-[#B4C0B9] hover:text-white transition-colors">
              高山風土 Origins
            </a>
            <a href="#menu" className="text-[#B4C0B9] hover:text-white transition-colors">
              全品菜單 Menu
            </a>
            <a href="#locations" className="text-[#B4C0B9] hover:text-white transition-colors">
              門市據點 Locations
            </a>
            <a href="#loyalty" className="text-[#B4C0B9] hover:text-white transition-colors">
              尊爵會員 Loyalty
            </a>
            <a href="#coffee-life" className="text-[#B4C0B9] hover:text-white transition-colors">
              咖啡季刊 Editorial
            </a>
          </div>

          {/* Stores & Service (3 cols on lg) */}
          <div className="lg:col-span-3 flex flex-col text-left space-y-3 text-xs">
            <h4 className="text-sm font-serif font-bold text-white tracking-wider">旗艦門市</h4>
            <div className="flex items-start gap-2 text-[#B4C0B9]">
              <MapPin className="w-4 h-4 text-[#C5A475] shrink-0 mt-0.5" />
              <span>台北市大安區忠孝東路四段181巷40弄</span>
            </div>
            <div className="flex items-center gap-2 text-[#B4C0B9]">
              <Clock className="w-4 h-4 text-[#C5A475] shrink-0" />
              <span>每日 07:00 – 22:00</span>
            </div>
            <div className="flex items-center gap-2 text-[#B4C0B9]">
              <Phone className="w-4 h-4 text-[#C5A475] shrink-0" />
              <span className="font-mono">(02) 2771-8899</span>
            </div>

            <button
              onClick={openWifiModal}
              className="mt-2 inline-flex items-center gap-2 text-xs text-[#C5A475] hover:underline"
            >
              <Wifi className="w-4 h-4" />
              <span>門市 Wi-Fi 6 登入說明</span>
            </button>
          </div>

          {/* Newsletter Signup (3 cols on lg) */}
          <div className="lg:col-span-3 flex flex-col text-left space-y-3">
            <h4 className="text-sm font-serif font-bold text-white tracking-wider">
              訂閱《啡語》電子報
            </h4>
            <p className="text-xs text-[#B4C0B9] leading-relaxed">
              每月接收當季產地新豆採收、咖啡師手沖指南與會員專屬優惠。
            </p>

            {subscribed ? (
              <div className="p-3 rounded-xl bg-[#284839] text-[#88D3A8] text-xs font-serif font-medium">
                ✓ 感謝您的訂閱！我們已發送確認信。
              </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="flex flex-col gap-2">
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="請輸入您的 Email"
                  className="p-2.5 rounded-xl bg-[#14261E] border border-[#284839] text-xs text-white placeholder-[#717E77] focus:outline-hidden focus:border-[#C5A475]"
                />
                <button
                  type="submit"
                  className="py-2.5 rounded-xl bg-[#C5A475] hover:bg-[#B39366] text-[#1C3328] font-serif font-bold text-xs tracking-wider transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>立即訂閱 SUBSCRIBE</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Bottom copyright & notes */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-[#7E9689] gap-4">
          <div className="flex items-center gap-1">
            <span>© {new Date().getFullYear()} 台灣咖啡 TAIWANESE COFFEE. All rights reserved.</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <a href="#contact" className="hover:text-white transition-colors">
              隱私權政策 Privacy Policy
            </a>
            <span>•</span>
            <a href="#contact" className="hover:text-white transition-colors">
              Wi-Fi 使用條款 Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
