'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useApp } from '@/context/AppContext';
import { storesData } from '@/data/storesData';
import { StoreLocation } from '@/types';
import { MapPin, Phone, Clock, Wifi, Zap, Users, ExternalLink } from 'lucide-react';

export const StoresSection: React.FC = () => {
  const { t, lang } = useApp();
  const [selectedStoreId, setSelectedStoreId] = useState<string>(storesData[0].id);

  const activeStore = storesData.find((s) => s.id === selectedStoreId) || storesData[0];

  return (
    <section
      id="locations"
      className="w-full bg-[#FAF8F3] dark:bg-[#121714] py-14 sm:py-20 transition-colors"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        {/* Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE]">
            {t.storesTitle}
          </h2>
          <p className="text-xs sm:text-sm font-sans tracking-widest text-[#717E77] dark:text-[#97A59E] uppercase font-semibold mt-1">
            {t.storesSubtitle}
          </p>
          <div className="w-12 h-[2px] bg-[#1C3328] dark:bg-[#C5A475] mt-3" />
        </div>

        {/* Store Tabs */}
        <div className="flex items-center justify-start sm:justify-center gap-2 sm:gap-3 overflow-x-auto pb-3 mb-8 no-scrollbar">
          {storesData.map((store) => (
            <button
              key={store.id}
              onClick={() => setSelectedStoreId(store.id)}
              className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-serif font-semibold whitespace-nowrap transition-all duration-300 cursor-pointer ${
                selectedStoreId === store.id
                  ? 'bg-[#1C3328] dark:bg-[#C5A475] text-white dark:text-[#121714] shadow-md scale-105'
                  : 'bg-[#EFE9DD] dark:bg-[#1C2822] text-[#55635C] dark:text-[#CBD5CF] hover:bg-[#E2DACB]'
              }`}
            >
              <span>{lang === 'zh-TW' ? store.nameZh : store.nameEn}</span>
              {store.isFlagship && (
                <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-[#C5A475] text-white text-[9px] font-sans font-bold">
                  旗艦
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Store Detail Hero */}
        <div className="bg-white dark:bg-[#18231D] rounded-3xl p-6 sm:p-10 shadow-xl border border-[#E8E2D5] dark:border-[#283C30] grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Store Photo */}
          <div className="lg:col-span-7 relative w-full h-72 sm:h-96 rounded-2xl overflow-hidden shadow-md bg-[#2C1D11]">
            <Image
              src={activeStore.image}
              alt={activeStore.nameZh}
              fill
              sizes="(max-width: 1024px) 100vw, 650px"
              className="object-cover transition-transform duration-700 hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-xs text-white text-xs font-serif px-3 py-1 rounded-full">
              {activeStore.seats} 座席 • 獨立插座率 90%
            </div>
            <div className="absolute bottom-4 left-4 right-4 bg-black/70 backdrop-blur-xs text-white p-3 rounded-xl flex items-center justify-between text-xs">
              <span className="flex items-center gap-1 text-[#C5A475]">
                <Wifi className="w-3.5 h-3.5" />
                <span>{activeStore.wifiSpeed}</span>
              </span>
              <span className="text-[#88D3A8] font-medium">● 目前座位充裕 (空席 14 席)</span>
            </div>
          </div>

          {/* Store Info */}
          <div className="lg:col-span-5 flex flex-col justify-center text-left space-y-4">
            <div>
              <span className="text-xs font-sans tracking-widest text-[#C5A475] uppercase font-bold">
                STORE INFORMATION
              </span>
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE] mt-0.5">
                {lang === 'zh-TW' ? activeStore.nameZh : activeStore.nameEn}
              </h3>
              <p className="text-xs font-sans text-[#717E77] dark:text-[#97A59E]">
                {lang === 'zh-TW' ? activeStore.nameEn : activeStore.nameZh}
              </p>
            </div>

            <p className="text-xs sm:text-sm text-[#4A5550] dark:text-[#CBD5CF] leading-relaxed">
              {lang === 'zh-TW' ? activeStore.descriptionZh : activeStore.descriptionEn}
            </p>

            {/* Address & Hours details */}
            <div className="space-y-3 pt-2 text-xs">
              <div className="flex items-start gap-2.5 text-[#1F2421] dark:text-[#E8EAE8]">
                <MapPin className="w-4 h-4 text-[#C5A475] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold block">
                    {lang === 'zh-TW' ? activeStore.addressZh : activeStore.addressEn}
                  </span>
                  <span className="text-[11px] text-[#717E77] dark:text-[#97A59E]">
                    {lang === 'zh-TW' ? activeStore.addressEn : activeStore.addressZh}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2.5 text-[#1F2421] dark:text-[#E8EAE8]">
                <Clock className="w-4 h-4 text-[#C5A475] shrink-0" />
                <span>
                  {lang === 'zh-TW' ? activeStore.openingHoursZh : activeStore.openingHoursEn}
                </span>
              </div>

              <div className="flex items-center gap-2.5 text-[#1F2421] dark:text-[#E8EAE8]">
                <Phone className="w-4 h-4 text-[#C5A475] shrink-0" />
                <span className="font-mono">{activeStore.phone}</span>
              </div>
            </div>

            {/* Features pills */}
            <div className="pt-2">
              <span className="text-[11px] font-serif font-bold text-[#1C3328] dark:text-[#F7F4EE] block mb-2">
                門市設施 AMENITIES
              </span>
              <div className="flex flex-wrap gap-2">
                {(
                  (lang === 'zh-TW'
                    ? activeStore.featuresZh
                    : activeStore.featuresEn || activeStore.featuresZh) || [
                    '高速 Wi-Fi 6',
                    '獨立電源插座',
                    '手沖咖啡專區',
                    '寵物友善',
                  ]
                ).map((feat, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-lg bg-[#EFE9DD] dark:bg-[#202E26] text-[#1C3328] dark:text-[#E8EAE8] text-[11px] font-medium"
                  >
                    ✓ {feat}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 flex gap-3">
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(activeStore.addressZh)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2.5 rounded-xl bg-[#1C3328] hover:bg-[#14261E] dark:bg-[#284839] text-white text-xs font-serif font-bold tracking-wider text-center flex items-center justify-center gap-1.5 shadow-sm"
              >
                <span>Google 地圖導航</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href={`tel:${activeStore.phone.replace(/[^0-9]/g, '')}`}
                className="px-4 py-2.5 rounded-xl border border-[#DDD5C7] dark:border-[#2C3D32] text-xs font-medium text-center hover:bg-[#EFE9DD] transition-colors"
              >
                致電門市
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
