import { CoffeeOrigin } from '@/types';

export interface FarmStep {
  step: number;
  character: string;
  titleZh: string;
  titleEn: string;
  subtitleZh: string;
  subtitleEn: string;
  descriptionZh: string;
  descriptionEn: string;
  image: string;
  badgeZh: string;
  badgeEn: string;
}

export const farmStepsData: FarmStep[] = [
  {
    step: 1,
    character: '山',
    titleZh: '高山風土',
    titleEn: 'Mountain Terroir',
    subtitleZh: '雲霧繚繞的海拔 1,200 公尺',
    subtitleEn: 'Misty Alpine Peaks at 1,200m+',
    descriptionZh:
      '台灣中央山脈與阿里山茶區擁有得天獨厚的微型氣候。年均溫18度，日夜溫差劇烈，讓咖啡果實能更緩慢成熟，累積豐富的花香與高甜度。',
    descriptionEn:
      'Taiwan’s Central Mountain Range and Alishan terroirs feature sharp day-night temperature shifts. Mists shroud the hillsides, allowing cherries to develop dense cell structures and refined floral aromas.',
    image:
      'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1000&auto=format&fit=crop',
    badgeZh: '產地直擊 • 阿里山特富野',
    badgeEn: 'Direct Origin • Alishan Tefuye',
  },
  {
    step: 2,
    character: '果',
    titleZh: '純手工採摘',
    titleEn: 'Selective Harvesting',
    subtitleZh: '只採摘深紅透亮的完熟櫻桃',
    subtitleEn: '100% Handpicked Ruby-Red Cherries',
    descriptionZh:
      '拒絕機械化混合採收。在地鄒族青年與小農於採收期清晨穿梭林間，嚴選糖度超過 22 Brix 的鮮紅櫻桃果實，為好風味打下極致基礎。',
    descriptionEn:
      'Local indigenous Tsou farmers meticulously select each cherry by hand at optimum ripeness (over 22 Brix sugar density), eliminating any defect before processing.',
    image:
      'https://images.unsplash.com/photo-1611162618071-b39a2ec055fb?q=80&w=1000&auto=format&fit=crop',
    badgeZh: '糖度檢測 • 22° Brix',
    badgeEn: 'Sugar Index • 22° Brix',
  },
  {
    step: 3,
    character: '豆',
    titleZh: '匠心發酵',
    titleEn: 'Terroir Fermentation',
    subtitleZh: '蜜處理與厭氧日曬工法',
    subtitleEn: 'Honey Process & Anaerobic Sun-Drying',
    descriptionZh:
      '保留部分果肉黏膜，在台灣高山專屬非洲高架棚架上均勻日曬 21 天，結合現代厭氧控溫發酵，孕育出標誌性的高山烏龍茶感與熱帶果香。',
    descriptionEn:
      'Sun-dried on raised African beds for 21 days with temperature-controlled micro-fermentations, unlocking signature Taiwan Oolong tea body and nectarine sweetness.',
    image:
      'https://images.unsplash.com/photo-1587734195503-904fca47e0e9?q=80&w=1000&auto=format&fit=crop',
    badgeZh: '21天高架日曬 • 慢速乾燥',
    badgeEn: '21-Day Raised Bed Drying',
  },
  {
    step: 4,
    character: '焙',
    titleZh: '微批次烘焙',
    titleEn: 'Artisanal Roasting',
    subtitleZh: '精準調控烘焙升溫曲線',
    subtitleEn: 'Small-Batch Roasting in Taipei',
    descriptionZh:
      '由世界烘豆師認證團隊於台北工坊小量烘焙。淺中烘焙曲線完整保留產地原生花果酸甜與茶感餘韻，展現純淨通透的台灣風土。',
    descriptionEn:
      'Crafted in small batches in our Taipei roastery. Our precise thermal profile preserves delicate floral acids, crisp citrus, and lingering tea sweetness.',
    image:
      'https://images.unsplash.com/photo-1518832553480-cd0e625ed3e6?q=80&w=1000&auto=format&fit=crop',
    badgeZh: '台北工坊 • 每週新鮮烘焙',
    badgeEn: 'Taipei Roastery • Fresh Weekly',
  },
  {
    step: 5,
    character: '杯',
    titleZh: '極致呈遞',
    titleEn: 'Heartfelt Brew',
    subtitleZh: '以職人手沖與陶瓷工藝盛裝',
    subtitleEn: 'Hand-Poured into Artisan Ceramics',
    descriptionZh:
      '透過精確水溫 91°C 與細緻注水節奏，搭配台灣鶯歌陶藝名家手作厚土陶瓷杯，將這杯承載台灣土地熱情的甘醇咖啡端至您的眼前。',
    descriptionEn:
      'Extracted at 91°C with calibrated flow rate, served in custom Yingge handcrafted ceramic cups for optimal tactile warmth and aromatic concentration.',
    image:
      'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1000&auto=format&fit=crop',
    badgeZh: '鶯歌陶器 • 91°C 精萃',
    badgeEn: 'Yingge Ceramics • 91°C Brew',
  },
];

export const taiwanOriginsData: CoffeeOrigin[] = [
  {
    id: 'alishan',
    nameZh: '嘉義 阿里山',
    nameEn: 'Chiayi Alishan',
    countyZh: '嘉義縣 阿里山鄉',
    countyEn: 'Alishan Township, Chiayi County',
    altitude: '1,200 – 1,550m',
    climateZh: '高山涼溫、午後濃霧、純淨高山泉水',
    climateEn: 'Cool alpine mist, steep slopes, mountain springs',
    variety: 'Geisha (藝妓), Typica (鐵比卡), SL34',
    tastingNotesZh: '白花香氣、佛手柑、高山烏龍茶韻、百香果、黑糖甜感',
    tastingNotesEn: 'Jasmine blossom, bergamot, high-mountain oolong, passionfruit, cane sugar',
    farmStoryZh: '阿里山得天獨厚的茶園共生環境，賦予咖啡豆舉世聞名的精緻茶感與多重花果香氣。',
    farmStoryEn: 'Grown alongside legendary high-mountain tea plantations, imparting extraordinary floral elegance.',
    mapCoords: { x: 44, y: 56 },
  },
  {
    id: 'gukeng',
    nameZh: '雲林 古坑',
    nameEn: 'Yunlin Gukeng',
    countyZh: '雲林縣 古坑鄉荷苞山',
    countyEn: 'Hebao Mountain, Gukeng, Yunlin',
    altitude: '600 – 900m',
    climateZh: '日照充足、排水良好之砂質壤土',
    climateEn: 'Subtropical sunshine, well-draining volcanic loam',
    variety: 'Typica (鐵比卡), Bourbon (波旁)',
    tastingNotesZh: '烤杏仁、黑巧克力、焦糖香氣、圓潤醇厚',
    tastingNotesEn: 'Roasted almond, dark chocolate, caramel, balanced mellow body',
    farmStoryZh: '台灣歷史悠久的咖啡原鄉，日治時期曾作為皇室貢品，經典醇厚耐人尋味。',
    farmStoryEn: 'Taiwan’s historic coffee cradle once gifted to royalty, famous for deep, comforting chocolate sweetness.',
    mapCoords: { x: 38, y: 48 },
  },
  {
    id: 'nantou',
    nameZh: '南投 國姓',
    nameEn: 'Nantou Guoxing',
    countyZh: '南投縣 國姓鄉九份二山',
    countyEn: 'Guoxing Township, Nantou County',
    altitude: '800 – 1,100m',
    climateZh: '盆地山谷、日夜溫差適中、無污染山泉',
    climateEn: 'Valley microclimate, protected watershed',
    variety: 'Arabica Typica, Yellow Bourbon (黃波旁)',
    tastingNotesZh: '紅蘋果、青梅酸甜、龍眼蜜、烤核桃',
    tastingNotesEn: 'Red apple, green plum crispness, longan honey, toasted walnut',
    farmStoryZh: '通過台灣產地標章認證，農民以永續友善農法耕作，果酸清新明亮。',
    farmStoryEn: 'Certified origin traceability with organic polyculture, bringing vibrant fruit acidity.',
    mapCoords: { x: 48, y: 44 },
  },
  {
    id: 'hualien',
    nameZh: '花蓮 舞鶴',
    nameEn: 'Hualien Wuhe',
    countyZh: '花蓮縣 瑞穗鄉舞鶴台地',
    countyEn: 'Wuhe Terrace, Ruisui, Hualien',
    altitude: '300 – 600m',
    climateZh: '太平洋海風吹拂、日照溫和、有機紅土',
    climateEn: 'Pacific ocean breezes, gentle sun, rich red clay',
    variety: 'Typica, Caturra',
    tastingNotesZh: '黑糖蜜香、熱帶芒果乾、柑橘、茶感回甘',
    tastingNotesEn: 'Brown sugar nectar, dried mango, orange peel, sweet tea finish',
    farmStoryZh: '座落於北回歸線舞鶴台地，深受太平洋海風滋潤，散發獨特的蜜香氣息。',
    farmStoryEn: 'Bathed by Pacific breezes on the Tropic of Cancer, offering a honeyed finish reminiscent of local teas.',
    mapCoords: { x: 62, y: 46 },
  },
  {
    id: 'pingtung',
    nameZh: '屏東 德文/大武山',
    nameEn: 'Pingtung Dawu Mountain',
    countyZh: '屏東縣 三地門鄉德文部落',
    countyEn: 'Sandimen, Mt. Dawu, Pingtung',
    altitude: '800 – 1,200m',
    climateZh: '南島陽光、大武山純淨山嵐、有機腐殖土',
    climateEn: 'Southern sunshine, mountain breeze, rich organic humus',
    variety: 'Typica (日治百年老樹後代)',
    tastingNotesZh: '桂圓肉、可可豆、黑莓果、厚實濃郁餘韻',
    tastingNotesEn: 'Dried longan, cacao nibs, blackberry, exceptionally rich velvety body',
    farmStoryZh: '承襲排灣族與魯凱族祖傳山林智慧，生長於大武山聖山腳下，風味深沉厚實。',
    farmStoryEn: 'Cultivated under the stewardship of indigenous Paiwan communities, known for earthy, deeply resonant body.',
    mapCoords: { x: 42, y: 72 },
  },
];

export const coffeeOriginsData = taiwanOriginsData;
