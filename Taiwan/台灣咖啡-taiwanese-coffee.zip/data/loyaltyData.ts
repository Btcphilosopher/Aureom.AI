import { LoyaltyMember } from '@/types';

export interface LoyaltyReward {
  id: string;
  nameZh: string;
  nameEn: string;
  pointsCost: number;
  descriptionZh: string;
  descriptionEn: string;
}

export interface LoyaltyTier {
  tier: 'silver' | 'gold' | 'platinum';
  nameZh: string;
  nameEn: string;
  thresholdPoints: number;
  minPoints?: number;
  perksZh: string[];
  perksEn: string[];
}

export const loyaltyRewardsData: LoyaltyReward[] = [
  {
    id: 'rew_pour_over',
    nameZh: '免費兌換 阿里山精品手沖一杯',
    nameEn: 'Free Alishan Single-Origin Pour Over',
    pointsCost: 500,
    descriptionZh: '任選阿里山特富野蜜處理或日曬手沖咖啡一杯 (價值 NT$160)',
    descriptionEn: 'Redeem one complimentary cup of Alishan pour-over coffee (Value NT$160)',
  },
  {
    id: 'rew_tiramisu',
    nameZh: '主廚招牌提拉米蘇甜點券',
    nameEn: 'Artisanal Tiramisu Voucher',
    pointsCost: 400,
    descriptionZh: '門市內用或外帶兌換手工提拉米蘇一份 (價值 NT$120)',
    descriptionEn: 'Redeem one handcrafted Italian-style Tiramisu (Value NT$120)',
  },
  {
    id: 'rew_beans_discount',
    nameZh: '自家烘焙咖啡豆 NT$100 折價券',
    nameEn: 'NT$100 Coffee Beans Coupon',
    pointsCost: 300,
    descriptionZh: '購買半磅或濾掛包咖啡豆折抵 NT$100',
    descriptionEn: 'NT$100 off any half-pound bean bag or drip bags',
  },
  {
    id: 'rew_oat_milk_upgrade',
    nameZh: '免費升級燕麥奶券 (3次)',
    nameEn: 'Free Oat Milk Upgrade (x3)',
    pointsCost: 200,
    descriptionZh: '點購任一拿鐵飲品免費升級高品質小農燕麥奶',
    descriptionEn: 'Complimentary oat milk upgrade for 3 beverage orders',
  },
];

export const loyaltyTiersData: LoyaltyTier[] = [
  {
    tier: 'silver',
    nameZh: '白銀品味會員',
    nameEn: 'Silver Connoisseur',
    thresholdPoints: 0,
    minPoints: 0,
    perksZh: ['門市消費累積點數 (NT$10 = 1點)', '門市高速 Wi-Fi 6 專屬登入', '數位集點卡 10 點贈單品'],
    perksEn: ['Earn 1 pt per NT$10', 'High-speed Wi-Fi 6 login', 'Digital stamp card 10th free'],
  },
  {
    tier: 'gold',
    nameZh: '黃金典藏會員',
    nameEn: 'Gold Reserve',
    thresholdPoints: 1000,
    minPoints: 1000,
    perksZh: ['點數累積 1.2 倍加速', '每月 1 次免費升級燕麥奶', '線上點餐免排隊快取', '當月壽星精選甜點一份'],
    perksEn: ['1.2x points multiplier', 'Monthly free oat milk upgrade', 'Mobile priority pickup', 'Birthday cake gift'],
  },
  {
    tier: 'platinum',
    nameZh: '黑卡白金尊榮會員',
    nameEn: 'Platinum Reserve Black',
    thresholdPoints: 3000,
    minPoints: 3000,
    perksZh: [
      '點數累積 1.5 倍加速',
      '全年免費任選植物奶升級',
      'VIP 包廂與窗景座位優先預約權',
      '每季阿里山稀有批次咖啡豆搶先品飲',
      'Wi-Fi 6 專屬極速頻寬 (500Mbps)',
    ],
    perksEn: [
      '1.5x points multiplier',
      'Complimentary plant milk all year',
      'VIP reservation priority',
      'Exclusive seasonal micro-lots',
      'Ultra Wi-Fi priority channel',
    ],
  },
];

export const initialLoyaltyData: LoyaltyMember = {
  memberId: 'TC-8892-TW',
  memberName: '林宸宇 (Chen-Yu Lin)',
  memberNumber: 'TC-8892-TW',
  tier: 'GOLD',
  tierZh: '黃金典藏會員',
  tierEn: 'Gold Reserve Member',
  tierNameZh: '黃金會員 (Gold Member)',
  tierNameEn: 'Gold Tier Member',
  points: 1840,
  nextRewardThreshold: 2000,
  stampsCount: 7, // 7 out of 10 stamps
  visitsCount: 14,
  favouriteDrinkZh: '黑糖拿鐵 (Brown Sugar Latte)',
  favouriteDrinkEn: 'Brown Sugar Latte',
  availableRewards: loyaltyRewardsData,
};
