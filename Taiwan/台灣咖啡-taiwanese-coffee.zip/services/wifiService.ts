import { WifiSession } from '@/types';
import { storageService } from './storageService';

const WIFI_SESSION_KEY = 'wifi_session';

export const wifiService = {
  getInitialSession: (): WifiSession => {
    return storageService.get<WifiSession>(WIFI_SESSION_KEY, {
      isConnected: false,
      ssid: 'TAIWANCOFFEE_FREE',
      signalStrength: 'excellent',
      speedMbps: 238,
      termsAccepted: false,
    });
  },

  saveSession: (session: WifiSession): void => {
    storageService.set(WIFI_SESSION_KEY, session);
  },

  connect: (phoneNumber?: string): WifiSession => {
    const session: WifiSession = {
      isConnected: true,
      phoneNumber: phoneNumber || '0912-345-678',
      connectedAt: Date.now(),
      ipAddress: '192.168.88.104',
      ssid: 'TAIWANCOFFEE_FREE',
      signalStrength: 'excellent',
      speedMbps: 238,
      termsAccepted: true,
    };
    wifiService.saveSession(session);
    return session;
  },

  disconnect: (): WifiSession => {
    const session: WifiSession = {
      isConnected: false,
      ssid: 'TAIWANCOFFEE_FREE',
      signalStrength: 'excellent',
      speedMbps: 238,
      termsAccepted: false,
    };
    wifiService.saveSession(session);
    return session;
  },

  formatElapsedTime: (connectedAt?: number): string => {
    if (!connectedAt) return '00:00:00';
    const totalSeconds = Math.max(0, Math.floor((Date.now() - connectedAt) / 1000));
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  },
};
