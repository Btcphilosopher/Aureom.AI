'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  Language,
  ThemeMode,
  Product,
  CartItem,
  Order,
  OrderStatus,
  WifiSession,
  LoyaltyMember,
  Article,
  Store,
} from '@/types';
import { translations } from '@/data/translations';
import { initialLoyaltyData } from '@/data/loyaltyData';
import { storesData } from '@/data/storesData';
import { wifiService } from '@/services/wifiService';
import { storageService } from '@/services/storageService';

export interface CreateOrderParams {
  orderType?: 'dine_in' | 'takeaway';
  storeId?: string;
  tableNumber?: string;
  customerName?: string;
  customerPhone?: string;
  specialNotes?: string;
}

interface AppContextType {
  // Localization & Theme
  lang: Language;
  setLang: (lang: Language) => void;
  t: (typeof translations)['zh-TW'];
  theme: ThemeMode;
  toggleTheme: () => void;
  reducedMotion: boolean;
  setReducedMotion: (val: boolean) => void;

  // Wi-Fi
  wifiSession: WifiSession;
  wifiDurationStr: string;
  isWifiModalOpen: boolean;
  openWifiModal: () => void;
  closeWifiModal: () => void;
  connectWifi: (phone?: string) => void;
  disconnectWifi: () => void;
  isCaptivePortalOpen: boolean;
  openCaptivePortal: () => void;
  closeCaptivePortal: () => void;

  // Cart & Ordering
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  updateCartItemQty: (cartItemId: string, delta: number) => void;
  updateCartItemQuantity: (cartItemId: string, quantity: number) => void;
  removeCartItem: (cartItemId: string) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;

  // Selected Product Detail Modal
  selectedProduct: Product | null;
  openProductModal: (product: Product) => void;
  closeProductModal: () => void;

  // Active Order & Barista Progress Tracker
  activeOrder: Order | null;
  placeOrder: (diningOption: 'dine_in' | 'takeaway', storeId?: string, tableNum?: string) => Order;
  createOrder: (params?: CreateOrderParams) => Order;
  cancelActiveOrder: () => void;
  isOrderTrackerOpen: boolean;
  openOrderTracker: () => void;
  closeOrderTracker: () => void;

  // Loyalty Program
  loyalty: LoyaltyMember;
  loyaltyMember: LoyaltyMember;
  addStamp: () => void;
  resetStamps: () => void;
  redeemReward: (rewardId: string) => boolean;
  redeemLoyaltyReward: (rewardId: string) => boolean;

  // Reservation Modal
  isReservationOpen: boolean;
  selectedStoreForReservation: Store | null;
  openReservationModal: (store?: Store) => void;
  closeReservationModal: () => void;

  // Article Modal
  selectedArticle: Article | null;
  openArticleModal: (article: Article) => void;
  closeArticleModal: () => void;

  // Signature Journey "From Bean to Wi-Fi"
  isBeanToWifiOpen: boolean;
  openBeanToWifi: () => void;
  closeBeanToWifi: () => void;

  // Selected Store Map Modal
  selectedStoreForMap: Store | null;
  openStoreMapModal: (store: Store) => void;
  closeStoreMapModal: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  // Lazy state initializations from storage
  const [lang, setLangState] = useState<Language>(() => {
    return storageService.get<Language>('lang', 'zh-TW') || 'zh-TW';
  });

  const [theme, setThemeState] = useState<ThemeMode>(() => {
    return storageService.get<ThemeMode>('theme', 'light') || 'light';
  });

  const [reducedMotion, setReducedMotionState] = useState<boolean>(() => {
    return storageService.get<boolean>('reduced_motion', false) || false;
  });

  const [wifiSession, setWifiSession] = useState<WifiSession>(() => wifiService.getInitialSession());
  const [wifiDurationStr, setWifiDurationStr] = useState<string>('00:00:00');
  const [isWifiModalOpen, setIsWifiModalOpen] = useState<boolean>(false);
  const [isCaptivePortalOpen, setIsCaptivePortalOpen] = useState<boolean>(false);

  const [cart, setCart] = useState<CartItem[]>(() => {
    return storageService.get<CartItem[]>('cart', []) || [];
  });
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [activeOrder, setActiveOrder] = useState<Order | null>(() => {
    return storageService.get<Order | null>('active_order', null);
  });
  const [isOrderTrackerOpen, setIsOrderTrackerOpen] = useState<boolean>(false);

  const [loyalty, setLoyalty] = useState<LoyaltyMember>(() => {
    return storageService.get<LoyaltyMember>('loyalty', initialLoyaltyData) || initialLoyaltyData;
  });

  const [isReservationOpen, setIsReservationOpen] = useState<boolean>(false);
  const [selectedStoreForReservation, setSelectedStoreForReservation] = useState<Store | null>(null);

  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [isBeanToWifiOpen, setIsBeanToWifiOpen] = useState<boolean>(false);
  const [selectedStoreForMap, setSelectedStoreForMap] = useState<Store | null>(null);

  // Loyalty functions defined early
  const addStamp = useCallback(() => {
    setLoyalty((prev) => {
      const nextCount = prev.stampsCount >= 10 ? 1 : prev.stampsCount + 1;
      const updated = {
        ...prev,
        stampsCount: nextCount,
      };
      storageService.set('loyalty', updated);
      return updated;
    });
  }, []);

  const resetStamps = useCallback(() => {
    setLoyalty((prev) => {
      const updated = { ...prev, stampsCount: 0 };
      storageService.set('loyalty', updated);
      return updated;
    });
  }, []);

  const redeemReward = useCallback(
    (rewardId: string): boolean => {
      const reward = loyalty.availableRewards.find((r) => r.id === rewardId);
      if (!reward || loyalty.points < reward.pointsCost) return false;

      setLoyalty((prev) => {
        const updated = {
          ...prev,
          points: prev.points - reward.pointsCost,
        };
        storageService.set('loyalty', updated);
        return updated;
      });
      return true;
    },
    [loyalty.availableRewards, loyalty.points]
  );

  // Sync theme class to document
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Update Wi-Fi elapsed timer every second if connected
  useEffect(() => {
    if (!wifiSession.isConnected || !wifiSession.connectedAt) {
      return;
    }
    const interval = setInterval(() => {
      setWifiDurationStr(wifiService.formatElapsedTime(wifiSession.connectedAt));
    }, 1000);
    return () => clearInterval(interval);
  }, [wifiSession.isConnected, wifiSession.connectedAt]);

  // Order progression timer simulation
  useEffect(() => {
    if (!activeOrder || activeOrder.status === 'ready') return;

    const stages: OrderStatus[] = [
      'confirmed',
      'preparing',
      'grinding',
      'brewing',
      'almost_ready',
      'ready',
    ];
    const currentIndex = stages.indexOf(activeOrder.status);

    if (currentIndex < stages.length - 1) {
      const timer = setTimeout(() => {
        const nextStatus = stages[currentIndex + 1];
        const updatedOrder: Order = {
          ...activeOrder,
          status: nextStatus,
          estimatedMinutes: Math.max(1, activeOrder.estimatedMinutes - 2),
        };
        setActiveOrder(updatedOrder);
        storageService.set('active_order', updatedOrder);

        if (nextStatus === 'ready') {
          addStamp();
        }
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [activeOrder, addStamp]);

  const setLang = (newLang: Language) => {
    setLangState(newLang);
    storageService.set('lang', newLang);
  };

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setThemeState(nextTheme);
    storageService.set('theme', nextTheme);
  };

  const setReducedMotion = (val: boolean) => {
    setReducedMotionState(val);
    storageService.set('reduced_motion', val);
  };

  // Wi-Fi Actions
  const openWifiModal = () => setIsWifiModalOpen(true);
  const closeWifiModal = () => setIsWifiModalOpen(false);

  const connectWifi = (phone: string = '0912-345-678') => {
    const session = wifiService.connect(phone);
    setWifiSession(session);
    setWifiDurationStr('00:00:01');
  };

  const disconnectWifi = () => {
    const session = wifiService.disconnect();
    setWifiSession(session);
    setWifiDurationStr('00:00:00');
  };

  const openCaptivePortal = () => setIsCaptivePortalOpen(true);
  const closeCaptivePortal = () => setIsCaptivePortalOpen(false);

  // Cart Actions
  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);

  const addToCart = (newItem: CartItem) => {
    setCart((prev) => {
      const updated = [...prev, newItem];
      storageService.set('cart', updated);
      return updated;
    });
    setIsCartOpen(true);
  };

  const updateCartItemQty = (cartItemId: string, delta: number) => {
    setCart((prev) => {
      const updated = prev
        .map((item) => {
          if (item.cartItemId === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0
              ? { ...item, quantity: newQty, totalPrice: newQty * item.unitPrice }
              : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
      storageService.set('cart', updated);
      return updated;
    });
  };

  const updateCartItemQuantity = (cartItemId: string, quantity: number) => {
    setCart((prev) => {
      if (quantity <= 0) {
        const filtered = prev.filter((item) => item.cartItemId !== cartItemId);
        storageService.set('cart', filtered);
        return filtered;
      }
      const updated = prev.map((item) => {
        if (item.cartItemId === cartItemId) {
          return { ...item, quantity, totalPrice: quantity * item.unitPrice };
        }
        return item;
      });
      storageService.set('cart', updated);
      return updated;
    });
  };

  const removeCartItem = (cartItemId: string) => {
    setCart((prev) => {
      const updated = prev.filter((i) => i.cartItemId !== cartItemId);
      storageService.set('cart', updated);
      return updated;
    });
  };

  const clearCart = () => {
    setCart([]);
    storageService.remove('cart');
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => sum + item.totalPrice, 0);

  // Product modal
  const openProductModal = (product: Product) => setSelectedProduct(product);
  const closeProductModal = () => setSelectedProduct(null);

  // Orders
  const placeOrder = (
    diningOption: 'dine_in' | 'takeaway',
    storeId: string = 'store_zhongxiao',
    tableNum?: string
  ): Order => {
    const targetStore = storesData.find((s) => s.id === storeId) || storesData[0];
    const subtotal = cartSubtotal;
    const randomOrderNum = `A${Math.floor(100 + Math.random() * 900)}`;
    const pointsEarned = Math.floor(subtotal / 10);

    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      orderNumber: randomOrderNum,
      pickupCode: `TW-${Math.floor(1000 + Math.random() * 9000)}`,
      items: [...cart],
      subtotal,
      tax: 0,
      total: subtotal,
      storeId: targetStore.id,
      storeNameZh: targetStore.nameZh,
      storeNameEn: targetStore.nameEn,
      diningOption,
      orderType: diningOption,
      tableNumber: tableNum || (diningOption === 'dine_in' ? '08' : undefined),
      status: 'confirmed',
      estimatedMinutes: 8,
      estimatedMinutesRemaining: 8,
      createdAt: Date.now(),
      pointsEarned,
    };

    setActiveOrder(newOrder);
    storageService.set('active_order', newOrder);
    clearCart();
    setIsCartOpen(false);
    setIsOrderTrackerOpen(true);

    // Update loyalty points
    setLoyalty((prev) => {
      const updated = {
        ...prev,
        points: prev.points + pointsEarned,
        visitsCount: prev.visitsCount + 1,
      };
      storageService.set('loyalty', updated);
      return updated;
    });

    return newOrder;
  };

  const createOrder = (params?: CreateOrderParams): Order => {
    return placeOrder(
      params?.orderType || 'dine_in',
      params?.storeId || 'store_zhongxiao',
      params?.tableNumber
    );
  };

  const cancelActiveOrder = () => {
    setActiveOrder(null);
    storageService.remove('active_order');
    setIsOrderTrackerOpen(false);
  };

  const openOrderTracker = () => setIsOrderTrackerOpen(true);
  const closeOrderTracker = () => setIsOrderTrackerOpen(false);

  // Reservations
  const openReservationModal = (store?: Store) => {
    setSelectedStoreForReservation(store || storesData[0]);
    setIsReservationOpen(true);
  };
  const closeReservationModal = () => setIsReservationOpen(false);

  // Articles
  const openArticleModal = (article: Article) => setSelectedArticle(article);
  const closeArticleModal = () => setSelectedArticle(null);

  // Bean to Wi-Fi Signature Journey
  const openBeanToWifi = () => setIsBeanToWifiOpen(true);
  const closeBeanToWifi = () => setIsBeanToWifiOpen(false);

  // Store Map Modal
  const openStoreMapModal = (store: Store) => setSelectedStoreForMap(store);
  const closeStoreMapModal = () => setSelectedStoreForMap(null);

  const t = translations[lang];

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        t,
        theme,
        toggleTheme,
        reducedMotion,
        setReducedMotion,
        wifiSession,
        wifiDurationStr,
        isWifiModalOpen,
        openWifiModal,
        closeWifiModal,
        connectWifi,
        disconnectWifi,
        isCaptivePortalOpen,
        openCaptivePortal,
        closeCaptivePortal,
        cart,
        addToCart,
        updateCartItemQty,
        updateCartItemQuantity,
        removeCartItem,
        removeFromCart: removeCartItem,
        clearCart,
        cartCount,
        cartSubtotal,
        isCartOpen,
        openCart,
        closeCart,
        selectedProduct,
        openProductModal,
        closeProductModal,
        activeOrder,
        placeOrder,
        createOrder,
        cancelActiveOrder,
        isOrderTrackerOpen,
        openOrderTracker,
        closeOrderTracker,
        loyalty,
        loyaltyMember: loyalty,
        addStamp,
        resetStamps,
        redeemReward,
        redeemLoyaltyReward: redeemReward,
        isReservationOpen,
        selectedStoreForReservation,
        openReservationModal,
        closeReservationModal,
        selectedArticle,
        openArticleModal,
        closeArticleModal,
        isBeanToWifiOpen,
        openBeanToWifi,
        closeBeanToWifi,
        selectedStoreForMap,
        openStoreMapModal,
        closeStoreMapModal,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
