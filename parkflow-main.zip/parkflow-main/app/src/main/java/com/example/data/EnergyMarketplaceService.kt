package com.example.data

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient

data class EnergyTariff(
    val id: String,
    val provider: String,
    val source: String, // "Solar Renewable", "Wind Power", "Hydroelectric", "National Grid"
    val ratePerKwh: Double,
    val offPeakDiscountPercent: Int,
    val greenPercent: Int,
    val isOffPeakNow: Boolean,
    val description: String
)

interface EnergyMarketplaceApi {
    @GET("energy/tariffs")
    suspend fun getEnergyTariffs(): List<EnergyTariff>
}

object EnergyMarketplaceClient {
    private const val BASE_URL = "https://raw.githubusercontent.com/aistudio-templates/datasets/main/parkflow/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    val apiService: EnergyMarketplaceApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(EnergyMarketplaceApi::class.java)
    }

    // High fidelity offline dataset for immediate fallback / local development
    val OFFLINE_TARIFFS = listOf(
        EnergyTariff(
            id = "t1",
            provider = "Octopus Agile",
            source = "Wind Power",
            ratePerKwh = 0.28,
            offPeakDiscountPercent = 35,
            greenPercent = 100,
            isOffPeakNow = true,
            description = "Dynamic billing updated half-hourly, tracking wholesale wind abundance."
        ),
        EnergyTariff(
            id = "t2",
            provider = "OVO Solar Grid",
            source = "Solar Renewable",
            ratePerKwh = 0.32,
            offPeakDiscountPercent = 25,
            greenPercent = 90,
            isOffPeakNow = false,
            description = "Optimized charging for daylight hours utilizing intense solar offsets."
        ),
        EnergyTariff(
            id = "t3",
            provider = "E.ON Next Drive",
            source = "Hydroelectric",
            ratePerKwh = 0.35,
            offPeakDiscountPercent = 40,
            greenPercent = 100,
            isOffPeakNow = true,
            description = "Stable hydroelectric tariff with deep off-peak savings between 12 AM and 5 AM."
        ),
        EnergyTariff(
            id = "t4",
            provider = "British Gas Standard",
            source = "National Grid Mixer",
            ratePerKwh = 0.45,
            offPeakDiscountPercent = 10,
            greenPercent = 45,
            isOffPeakNow = false,
            description = "Reliable base network tariff drawing balanced regional supply mix."
        )
    )
}
