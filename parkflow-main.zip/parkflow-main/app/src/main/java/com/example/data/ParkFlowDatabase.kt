package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CarPark::class,
        Reservation::class,
        ChargingSession::class,
        UserLoyalty::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ParkFlowDatabase : RoomDatabase() {
    abstract fun dao(): ParkFlowDao

    companion object {
        @Volatile
        private var INSTANCE: ParkFlowDatabase? = null

        fun getDatabase(context: Context): ParkFlowDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ParkFlowDatabase::class.java,
                    "parkflow_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        // Beautiful set of initial car parks seeded in key locations (Manchester Center / Piccadilly area)
        // reference coordinates: latitude = 53.4808, longitude = -2.2426
        val SEED_CAR_PARKS = listOf(
            CarPark(
                id = 1,
                name = "Piccadilly Plaza Multi-Storey",
                latitude = 53.4802,
                longitude = -2.2390,
                type = "Multi-Storey",
                totalSpaces = 350,
                occupiedSpaces = 142, // Green / Available
                hasEvChargers = true,
                evChargersCount = 12,
                hourlyRate = 4.50,
                rating = 4.7f,
                chargerPower = "150 kW DC Rapid",
                chargerAvailability = "8/12 Free",
                maxChargerPower = 150,
                connectorType = "CCS2 & Type 2",
                costPerKwh = 0.55,
                peakHours = "08:30-10:30, 16:30-18:30",
                occupancyTrend = "40,45,43,38,35,48,60,82,90,92,85,75"
            ),
            CarPark(
                id = 2,
                name = "Deansgate Luxury Secure Lot",
                latitude = 53.4820,
                longitude = -2.2475,
                type = "Surface Lot",
                totalSpaces = 120,
                occupiedSpaces = 108, // Amber / Limited Space
                hasEvChargers = true,
                evChargersCount = 6,
                hourlyRate = 6.20,
                rating = 4.9f,
                chargerPower = "350 kW Ultra-Rapid",
                chargerAvailability = "1/6 Free",
                maxChargerPower = 350,
                connectorType = "CCS2 & CHAdeMO",
                costPerKwh = 0.68,
                peakHours = "09:00-12:00, 17:00-20:00",
                occupancyTrend = "60,65,70,75,70,82,88,92,95,98,90,85"
            ),
            CarPark(
                id = 3,
                name = "Albert Square Street Parking",
                latitude = 53.4795,
                longitude = -2.2443,
                type = "Street Parking",
                totalSpaces = 40,
                occupiedSpaces = 39, // Red / Full
                hasEvChargers = false,
                evChargersCount = 0,
                hourlyRate = 3.00,
                rating = 4.2f,
                chargerPower = "No EV charging",
                chargerAvailability = "0/0",
                maxChargerPower = 0,
                connectorType = "None",
                costPerKwh = 0.0,
                peakHours = "10:00-15:00, 17:00-19:00",
                occupancyTrend = "20,25,35,60,70,85,95,99,100,100,90,80"
            ),
            CarPark(
                id = 4,
                name = "Spinningfields Solar Charging Hub",
                latitude = 53.4812,
                longitude = -2.2530,
                type = "Surface Lot",
                totalSpaces = 180,
                occupiedSpaces = 75, // Green / Available
                hasEvChargers = true,
                evChargersCount = 30,
                hourlyRate = 5.00,
                rating = 4.8f,
                chargerPower = "22 kW AC Destination",
                chargerAvailability = "22/30 Free",
                maxChargerPower = 22,
                connectorType = "Type 2 AC",
                costPerKwh = 0.42,
                peakHours = "07:30-09:30, 14:00-16:00",
                occupancyTrend = "30,35,40,42,45,41,48,55,62,58,50,42"
            ),
            CarPark(
                id = 5,
                name = "Northern Quarter Electric Barn",
                latitude = 53.4842,
                longitude = -2.2355,
                type = "Multi-Storey",
                totalSpaces = 200,
                occupiedSpaces = 160, // Amber / Limited Space
                hasEvChargers = true,
                evChargersCount = 8,
                hourlyRate = 4.00,
                rating = 4.4f,
                chargerPower = "50 kW DC Fast",
                chargerAvailability = "2/8 Free",
                maxChargerPower = 50,
                connectorType = "CCS2 & Type 2",
                costPerKwh = 0.49,
                peakHours = "11:00-14:00, 18:00-21:00",
                occupancyTrend = "50,55,62,68,75,70,82,88,85,80,72,62"
            )
        )
    }
}
