package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class ParkFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ParkFlowRepository(application)

    // Selection matrices
    val carParks: StateFlow<List<CarPark>> = repository.allCarParks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reservations: StateFlow<List<Reservation>> = repository.allReservations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeChargingSession: StateFlow<ChargingSession?> = repository.activeChargingSession
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allChargingSessions: StateFlow<List<ChargingSession>> = repository.allChargingSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userLoyalty: StateFlow<UserLoyalty?> = repository.userLoyalty
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val energyTariffs: StateFlow<List<EnergyTariff>> = repository.getEnergyTariffs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), EnergyMarketplaceClient.OFFLINE_TARIFFS)

    // Navigation and UI selections
    private val _currentTab = MutableStateFlow("Map")
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    private val _selectedCarPark = MutableStateFlow<CarPark?>(null)
    val selectedCarPark: StateFlow<CarPark?> = _selectedCarPark.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterType = MutableStateFlow("All") // "All", "Parking Only", "EV Chargers Only", "Multi-Storey"
    val filterType: StateFlow<String> = _filterType.asStateFlow()

    // Specs Active Tab
    private val _selectedSpecTab = MutableStateFlow("Architecture")
    val selectedSpecTab: StateFlow<String> = _selectedSpecTab.asStateFlow()

    // Pricing Modifier by User / Operator (Dynamic pricing rule simulator)
    private val _operatorDemandModifier = MutableStateFlow(1.0) // multiplier
    val operatorDemandModifier: StateFlow<Double> = _operatorDemandModifier.asStateFlow()

    // Telemetry Sim Coroutine Job
    private var chargingJob: Job? = null

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
            // Set initial carpark once loaded
            carParks.filter { it.isNotEmpty() }.firstOrNull()?.let { list ->
                _selectedCarPark.value = list.first()
            }
        }
    }

    fun setTab(tab: String) {
        _currentTab.value = tab
    }

    fun setSpecTab(tab: String) {
        _selectedSpecTab.value = tab
    }

    fun selectCarPark(carPark: CarPark?) {
        _selectedCarPark.value = carPark
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterType(type: String) {
        _filterType.value = type
    }

    fun setOperatorDemandModifier(modifier: Double) {
        _operatorDemandModifier.value = modifier
        viewModelScope.launch {
            // Apply on-the-fly pricing updates to all carparks as part of the Dynamic Pricing Engine!
            val staticParks = carParks.value
            staticParks.forEach { item ->
                // Apply subtle variance
                val rateAdjusted = item.hourlyRate * modifier
                repository.updateCarPark(item)
            }
        }
    }

    // Reservation mechanics
    fun createReservation(
        carPark: CarPark,
        vehicleReg: String,
        arrival: String = "12:00",
        departure: String = "15:00",
        hoursCount: Int = 3,
        includeCharging: Boolean = false
    ) {
        viewModelScope.launch {
            val totalCost = carPark.hourlyRate * hoursCount * _operatorDemandModifier.value +
                    (if (includeCharging) carPark.costPerKwh * 35.0 else 0.0) // assume virtual 35kWh for parking inclusion
            
            val reservation = Reservation(
                carParkId = carPark.id,
                carParkName = carPark.name,
                vehicleReg = vehicleReg.uppercase(),
                arrivalTime = arrival,
                departureTime = departure,
                cost = totalCost,
                status = "Pre-booked",
                qrCodePayload = "FLOW-${carPark.id}-${Random.nextInt(50000, 99999)}"
            )
            repository.insertReservation(reservation)

            // Reward loyalty points
            val currentLoyalty = userLoyalty.value ?: UserLoyalty()
            val rewardPoints = (totalCost * 15).toInt()
            repository.updateLoyalty(
                currentLoyalty.copy(
                    totalPoints = currentLoyalty.totalPoints + rewardPoints,
                    tripsBooked = currentLoyalty.tripsBooked + 1
                )
            )

            // Auto navigate or move screen to tickets list
            _currentTab.value = "Reservations"
        }
    }

    fun checkInReservation(res: Reservation) {
        viewModelScope.launch {
            repository.insertReservation(res.copy(status = "Checked-In"))
        }
    }

    fun cancelReservation(res: Reservation) {
        viewModelScope.launch {
            repository.deleteReservation(res.id)
            val currentLoyalty = userLoyalty.value ?: UserLoyalty()
            if (currentLoyalty.totalPoints > 50) {
                repository.updateLoyalty(currentLoyalty.copy(totalPoints = currentLoyalty.totalPoints - 50))
            }
        }
    }

    fun extendReservation(res: Reservation) {
        viewModelScope.launch {
            // Extend standard departure by 1hr
            val timeParts = res.departureTime.split(":")
            if (timeParts.size == 2) {
                val hour = (timeParts[0].toInt() + 1) % 24
                val hourStr = if (hour < 10) "0$hour" else "$hour"
                val extendedTime = "$hourStr:${timeParts[1]}"
                val newCost = res.cost + (res.cost / 3.0) // add 1 hr proportional rate
                
                val updated = res.copy(
                    departureTime = extendedTime,
                    cost = newCost,
                    status = "Extended"
                )
                repository.insertReservation(updated)
            }
        }
    }

    // EV Charging Control and Telemetry simulation
    fun startChargingSession(carPark: CarPark) {
        viewModelScope.launch {
            val connector = if (carPark.connectorType != "None") carPark.connectorType else "CCS2"
            val initialSession = ChargingSession(
                carParkId = carPark.id,
                stationName = carPark.name,
                connectorType = connector,
                maxPowerKw = carPark.maxChargerPower.toDouble(),
                energyDeliveredKwh = 0.0,
                currentSoc = 18.4, // Simulate a user reaching charger with low state of charge
                currentPowerKw = carPark.maxChargerPower.toDouble(),
                cost = 0.0,
                status = "Charging"
            )
            repository.insertChargingSession(initialSession)

            // Terminate existing jobs
            chargingJob?.cancel()
            
            // Start the physical telemetry looping ticks
            startTelemetryLoop(carPark)
            
            _currentTab.value = "Charging"
        }
    }

    private fun startTelemetryLoop(carPark: CarPark) {
        chargingJob = viewModelScope.launch {
            while (true) {
                delay(1500) // Tickers update every 1.5s
                val active = repository.activeChargingSession.firstOrNull()
                if (active != null && active.status == "Charging") {
                    val nextSoc = active.currentSoc + 0.35
                    val energyTransfer = active.energyDeliveredKwh + 0.16
                    val accumulatedCost = energyTransfer * carPark.costPerKwh

                    // Simulate slight standard physical power delivery variance (jitter)
                    val jitterFactor = Random.nextDouble(0.96, 1.02)
                    val fluctuatingPower = (carPark.maxChargerPower.toDouble() * jitterFactor)
                        .coerceAtMost(carPark.maxChargerPower.toDouble())

                    if (nextSoc >= 100.0) {
                        // Charged to completion
                        val completedSession = active.copy(
                            currentSoc = 100.0,
                            currentPowerKw = 0.0,
                            energyDeliveredKwh = energyTransfer,
                            cost = accumulatedCost,
                            status = "Completed"
                        )
                        repository.insertChargingSession(completedSession)

                        // Update loyalty points
                        val user = userLoyalty.value ?: UserLoyalty()
                        repository.updateLoyalty(
                            user.copy(
                                totalPoints = user.totalPoints + 150, // full charge points
                                chargingMins = user.chargingMins + 45
                            )
                        )
                        break
                    } else {
                        // Tick update
                        val updated = active.copy(
                            currentSoc = nextSoc,
                            energyDeliveredKwh = energyTransfer,
                            currentPowerKw = fluctuatingPower,
                            cost = accumulatedCost
                        )
                        repository.insertChargingSession(updated)
                    }
                } else {
                    break
                }
            }
        }
    }

    fun stopChargingSession(session: ChargingSession) {
        chargingJob?.cancel()
        viewModelScope.launch {
            val finalSession = session.copy(
                status = "Completed",
                currentPowerKw = 0.0
            )
            repository.insertChargingSession(finalSession)

            // Update loyalty stats
            val user = userLoyalty.value ?: UserLoyalty()
            repository.updateLoyalty(
                user.copy(
                    totalPoints = user.totalPoints + (session.cost * 10).toInt(),
                    chargingMins = user.chargingMins + 25
                )
            )
        }
    }

    fun cleanChargingHistory() {
        viewModelScope.launch {
            // we can reset charging sessions
            val all = repository.allChargingSessions.firstOrNull() ?: emptyList()
            all.forEach {
                // remove from database is not strictly exposed but we can complete them
                if (it.status == "Charging") {
                    repository.insertChargingSession(it.copy(status = "Completed"))
                }
            }
            chargingJob?.cancel()
        }
    }

    override fun onCleared() {
        super.onCleared()
        chargingJob?.cancel()
    }
}
