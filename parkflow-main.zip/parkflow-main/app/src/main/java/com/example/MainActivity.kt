package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.BlueprintScreen
import com.example.ui.BusinessAnalyticsScreen
import com.example.ui.ChargingControllerScreen
import com.example.ui.MapScreen
import com.example.ui.ParkFlowViewModel
import com.example.ui.ReservationsScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                val vm: ParkFlowViewModel = viewModel()
                val currentTab by vm.currentTab.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier
                                .windowInsetsPadding(WindowInsets.navigationBars)
                                .testTag("bottom_nav_bar")
                                .height(64.dp)
                                .drawBehind {
                                    // 1.dp top divider line: matching border-t border-white/5
                                    drawLine(
                                        color = Color.White.copy(alpha = 0.10f),
                                        start = Offset(0f, 0f),
                                        end = Offset(size.width, 0f),
                                        strokeWidth = 1.dp.toPx()
                                    )
                                },
                            containerColor = Color(0xFF0F172A).copy(alpha = 0.82f),
                            tonalElevation = 0.dp
                        ) {
                            val tabs = listOf(
                                Triple("Map", Icons.Default.Map, "Discovery"),
                                Triple("Reservations", Icons.Default.ConfirmationNumber, "Passes"),
                                Triple("Charging", Icons.Default.EvStation, "Charging"),
                                Triple("Dashboard", Icons.Default.Assessment, "Business"),
                                Triple("Blueprints", Icons.Default.Code, "Blueprints")
                            )

                            tabs.forEach { (tabName, icon, label) ->
                                val isSelected = currentTab == tabName
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { vm.setTab(tabName) },
                                    icon = {
                                        Icon(
                                            imageVector = icon,
                                            contentDescription = label,
                                            tint = if (isSelected) Color(0xFF60A5FA) else Color(0xFF94A3B8),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = label,
                                            color = if (isSelected) Color(0xFF60A5FA) else Color(0xFF94A3B8),
                                            fontSize = 9.sp,
                                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = Color.White.copy(alpha = 0.10f)
                                    ),
                                    modifier = Modifier.testTag("nav_tab_$tabName")
                                )
                            }
                        }
                    },
                    contentWindowInsets = WindowInsets.navigationBars
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .drawBehind {
                                // Deep modern dark space background base
                                drawRect(color = Color(0xFF0B111E))

                                // Orbs simulating light refraction behind frosted glass:
                                // Active blue orb
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        colors = listOf(Color(0xFF3B82F6).copy(alpha = 0.18f), Color.Transparent),
                                        radius = size.width * 0.9f,
                                        center = Offset(0f, size.height * 0.2f)
                                    ),
                                    radius = size.width * 0.9f,
                                    center = Offset(0f, size.height * 0.2f)
                                )

                                // Royal purple/violet orb (bottom-right)
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        colors = listOf(Color(0xFFA855F7).copy(alpha = 0.14f), Color.Transparent),
                                        radius = size.width * 1.0f,
                                        center = Offset(size.width, size.height * 0.8f)
                                    ),
                                    radius = size.width * 1.0f,
                                    center = Offset(size.width, size.height * 0.8f)
                                )

                                // Energetic Emerald orb (center-right)
                                drawCircle(
                                    brush = Brush.radialGradient(
                                        colors = listOf(Color(0xFF10B981).copy(alpha = 0.10f), Color.Transparent),
                                        radius = size.width * 0.7f,
                                        center = Offset(size.width * 0.8f, size.height * 0.4f)
                                    ),
                                    radius = size.width * 0.7f,
                                    center = Offset(size.width * 0.8f, size.height * 0.4f)
                                )
                            }
                            .padding(bottom = innerPadding.calculateBottomPadding())
                    ) {
                        AnimatedContent(
                            targetState = currentTab,
                            transitionSpec = {
                                fadeIn() togetherWith fadeOut()
                            },
                            label = "screen_trans"
                        ) { tab ->
                            when (tab) {
                                "Map" -> MapScreen(viewModel = vm)
                                "Reservations" -> ReservationsScreen(viewModel = vm)
                                "Charging" -> ChargingControllerScreen(viewModel = vm)
                                "Dashboard" -> BusinessAnalyticsScreen(viewModel = vm)
                                "Blueprints" -> BlueprintScreen(viewModel = vm)
                            }
                        }
                    }
                }
            }
        }
    }
}
