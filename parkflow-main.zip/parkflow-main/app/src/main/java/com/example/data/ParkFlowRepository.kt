package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow

class ParkFlowRepository(context: Context) {
    private val db = ParkFlowDatabase.getDatabase(context)
    private val dao = db.dao()

    val allCarParks: Flow<List<CarPark>> = dao.getAllCarParks()
    val allReservations: Flow<List<Reservation>> = dao.getAllReservations()
    val allChargingSessions: Flow<List<ChargingSession>> = dao.getAllChargingSessions()
    val activeChargingSession: Flow<ChargingSession?> = dao.getActiveChargingSession()
    val userLoyalty: Flow<UserLoyalty?> = dao.getLoyaltyAccount()

    suspend fun seedDatabaseIfEmpty() {
        try {
            // Check if database is already seeded
            val existing = dao.getAllCarParks().firstOrNull()
            if (existing == null || existing.isEmpty()) {
                Log.d("ParkFlowRepository", "Seeding database with default datasets")
                dao.insertCarParks(ParkFlowDatabase.SEED_CAR_PARKS)
                
                // seed loyalty
                dao.insertLoyaltyAccount(
                    UserLoyalty(
                        id = 1,
                        totalPoints = 240,
                        tier = "Gold",
                        tripsBooked = 14,
                        chargingMins = 310,
                        referralCode = "PARKFLOW310"
                    )
                )
            }
        } catch (e: Exception) {
            Log.e("ParkFlowRepository", "Seeding failed: ${e.message}", e)
        }
    }

    suspend fun updateCarPark(carPark: CarPark) {
        dao.updateCarPark(carPark)
    }

    suspend fun insertReservation(res: Reservation) {
        dao.insertReservation(res)
    }

    suspend fun updateReservation(res: Reservation) {
        dao.updateReservation(res)
    }

    suspend fun deleteReservation(id: Int) {
        dao.deleteReservationById(id)
    }

    suspend fun insertChargingSession(session: ChargingSession) {
        dao.insertChargingSession(session)
    }

    suspend fun updateChargingSession(session: ChargingSession) {
        dao.updateChargingSession(session)
    }

    suspend fun updateLoyalty(loyalty: UserLoyalty) {
        dao.updateLoyaltyAccount(loyalty)
    }

    fun getEnergyTariffs(): Flow<List<EnergyTariff>> = flow {
        try {
            val response = EnergyMarketplaceClient.apiService.getEnergyTariffs()
            emit(response)
        } catch (e: Exception) {
            Log.w("ParkFlowRepository", "Marketplace API failed, falling back to local dataset: ${e.message}")
            emit(EnergyMarketplaceClient.OFFLINE_TARIFFS)
        }
    }
}
