package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CarPark

@Composable
fun BusinessAnalyticsScreen(
    viewModel: ParkFlowViewModel,
    modifier: Modifier = Modifier
) {
    val carParks by viewModel.carParks.collectAsState()
    val reservations by viewModel.reservations.collectAsState()
    val chargingSessions by viewModel.allChargingSessions.collectAsState()
    val demandModifier by viewModel.operatorDemandModifier.collectAsState()

    // Aggregate key metrics from live data
    val totalBays = carParks.sumOf { it.totalSpaces }
    val occupiedBays = carParks.sumOf { it.occupiedSpaces }
    val overallOccupancyRate = if (totalBays > 0) ((occupiedBays.toFloat() / totalBays.toFloat()) * 100).toInt() else 0

    val billingRevenue = reservations.sumOf { it.cost }
    val chargingRevenue = chargingSessions.sumOf { it.cost }
    val cumulativeRevenue = billingRevenue + chargingRevenue

    val totalActiveChargers = carParks.sumOf { it.evChargersCount }
    // active mock status count
    val activeChargingSessionsCount = chargingSessions.count { it.status == "Charging" }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 110.dp)
        ) {
            // --- 1. Screen Header ---
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 24.dp)
                ) {
                    Text(
                        text = "Real-time systems audit",
                        color = Color(0xFF60A5FA),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "OPERATOR DASHBOARD",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp
                    )
                }
            }

            // --- 2. Live Core Metrics Grid ---
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Cumulative revenue
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.11f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("TOTAL REVENUE", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "£${String.format("%.2f", cumulativeRevenue)}",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Res: £${String.format("%.1f", billingRevenue)} • EV: £${String.format("%.1f", chargingRevenue)}",
                                color = Color(0xFF64748B),
                                fontSize = 9.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    // Combined Occupancy
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.11f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.PieChart, contentDescription = null, tint = Color(0xFF3B82F6), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("NET OCCUPANCY", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "$overallOccupancyRate%",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "$occupiedBays / $totalBays parking bays in use",
                                color = Color(0xFF64748B),
                                fontSize = 9.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Charger utilization card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.11f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.EvStation, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("CHARGER UTILIZATION", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "$activeChargingSessionsCount/5 active",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Active energy flow: ${activeChargingSessionsCount * 140}kW",
                                color = Color(0xFF64748B),
                                fontSize = 9.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    // Alerts and health
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.11f)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Icon(Icons.Default.Handyman, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("HEALTH MONITOR", color = Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = "100% HEALTHY",
                                color = Color(0xFF10B981),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "Next terminal clean: 2 days",
                                color = Color(0xFF64748B),
                                fontSize = 10.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }

            // --- 3. Custom Canvas Chart 1: Daily Occupancy Peak wave line ---
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Occupancy Demand Wave (24 Hours)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))

                        // Drawing occupancy wave trend on Canvas
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                        ) {
                            val w = size.width
                            val h = size.height

                            // Draw baseline grid lines
                            drawLine(Color(0xFF1E293B), Offset(0f, h * 0.25f), Offset(w, h * 0.25f), 1f)
                            drawLine(Color(0xFF1E293B), Offset(0f, h * 0.5f), Offset(w, h * 0.5f), 1f)
                            drawLine(Color(0xFF1E293B), Offset(0f, h * 0.75f), Offset(w, h * 0.75f), 1f)

                            val path = Path()
                            val points = listOf(
                                Offset(w * 0.0f, h * 0.8f),  // 12 AM
                                Offset(w * 0.1f, h * 0.9f),  // 3 AM
                                Offset(w * 0.2f, h * 0.7f),  // 6 AM
                                Offset(w * 0.35f, h * 0.15f), // 9 AM (Peak)
                                Offset(w * 0.5f, h * 0.4f),  // 12 PM
                                Offset(w * 0.65f, h * 0.3f),  // 3 PM
                                Offset(w * 0.78f, h * 0.1f),  // 6 PM (Peak)
                                Offset(w * 0.9f, h * 0.5f),  // 9 PM
                                Offset(w * 1.0f, h * 0.75f)  // 12 AM
                            )

                            path.moveTo(points[0].x, points[0].y)
                            for (i in 1 until points.size) {
                                // smooth out path using a simple cubic bezier formulation
                                val prev = points[i - 1]
                                val curr = points[i]
                                val cx1 = (prev.x + curr.x) / 2f
                                path.quadraticTo(prev.x, prev.y, cx1, (prev.y + curr.y) / 2f)
                            }

                            // Outline the line path with electric gradient
                            drawPath(
                                path = path,
                                brush = Brush.horizontalGradient(
                                    listOf(Color(0xFF3B82F6), Color(0xFF10B981))
                                ),
                                style = Stroke(width = 4f)
                            )

                            // Underline shading fill
                            val fillPath = Path().apply {
                                addPath(path)
                                lineTo(w, h)
                                lineTo(0f, h)
                                close()
                            }
                            drawPath(
                                path = fillPath,
                                brush = Brush.verticalGradient(
                                    listOf(Color(0xFF3B82F6).copy(0.12f), Color.Transparent)
                                )
                            )

                            // Draw peak circles holding values
                            drawCircle(Color(0xFFEF4444), 6f, Offset(w * 0.35f, h * 0.15f)) // Peak 9AM
                            drawCircle(Color(0xFFEF4444), 6f, Offset(w * 0.78f, h * 0.1f))  // Peak 6PM
                        }

                        // Time Axis Labels
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        ) {
                            listOf("12 AM", "6 AM", "12 PM (Lunch)", "6 PM (Rush)", "12 AM").forEach { label ->
                                Text(label, color = Color(0xFF64748B), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // --- 4. Custom Canvas Chart 2: Revenue over Week bar chart ---
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.BarChart, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Weekly Revenue Breakdown",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))

                        // Custom drawing vertical bars on Canvas
                        val barValues = listOf(140f, 180f, 220f, 260f, 310f, 150f, 90f) // Monday -> Sunday
                        val dayLabels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                        ) {
                            val w = size.width
                            val h = size.height
                            val maxRevenueRef = 350f

                            val spacing = 32f
                            val numBars = barValues.size
                            val barW = (w - (spacing * (numBars - 1))) / numBars

                            for (i in barValues.indices) {
                                val value = barValues[i]
                                val barH = (value / maxRevenueRef) * h
                                val rx = i * (barW + spacing)
                                val ry = h - barH

                                // Draw bar with subtle rounding on top
                                drawRect(
                                    brush = Brush.verticalGradient(
                                        listOf(Color(0xFFF59E0B), Color(0xFFD97706))
                                    ),
                                    topLeft = Offset(rx, ry),
                                    size = Size(barW, barH)
                                )
                            }
                        }

                        // Labels
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        ) {
                            for (i in dayLabels.indices) {
                                Text(
                                    text = "${dayLabels[i]}\n£${barValues[i].toInt()}",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // --- 5. DYNAMIC PRICING CONTROLLER (Interactive Slide Modifier) ---
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp)
                        .border(
                            1.dp,
                            Brush.linearGradient(listOf(Color(0xFF3B82F6).copy(alpha = 0.6f), Color(0xFFA855F7).copy(alpha = 0.6f))),
                            RoundedCornerShape(24.dp)
                        ),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B).copy(alpha = 0.45f)), // Frosted deep purple
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFFA855F7), modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Dynamic AI Pricing Grid",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "Modify global billing rates in real-time based on system peak loads or nearby event surges. All Map items update values instantly.",
                            color = Color(0xFFC7D2FE),
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Dynamic multiplier badge display
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Tariff billing multiplier:",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            
                            val multiplierText = when (demandModifier) {
                                1.0 -> "1.0x (Standard)"
                                1.25 -> "1.25x (Faire Rise)"
                                1.5 -> "1.5x (Busy Surge)"
                                2.0 -> "2.0x (Max Demand Peak)"
                                else -> "${demandModifier}x"
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF4C1D95),
                                modifier = Modifier.border(1.dp, Color(0xFFA855F7), RoundedCornerShape(8.dp))
                            ) {
                                Text(
                                    text = multiplierText,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Grid selector buttons instead of sliders for easier precise target clicking!
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(1.0, 1.25, 1.5, 2.0).forEach { mul ->
                                val active = demandModifier == mul
                                Button(
                                    onClick = { viewModel.setOperatorDemandModifier(mul) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(38.dp)
                                        .testTag("pricing_modifier_$mul"),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (active) Color(0xFFA855F7) else Color(0xFF312E81)
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("${mul}x", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }

            // --- 6. Live Node Occupancy Listing Table ---
            item {
                Text(
                    text = "INFRASTRUCTURE HEALTH LIST (${carParks.size})",
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 10.dp)
                )
            }

            items(carParks, key = { park -> park.id }) { park ->
                val occupancyPercent = ((park.occupiedSpaces.toFloat() / park.totalSpaces.toFloat()) * 100).toInt()
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(park.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "Base rate: £${String.format("%.2f", park.hourlyRate)}/hr • Power: ${park.chargerPower}",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }

                        // Utilization metric
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                "$occupancyPercent% occupied",
                                color = if (occupancyPercent >= 90) Color(0xFFEF4444) else Color(0xFF10B981),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "${park.occupiedSpaces}/${park.totalSpaces} bays",
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
