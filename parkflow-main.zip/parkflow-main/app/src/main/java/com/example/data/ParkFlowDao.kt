package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ParkFlowDao {
    // Car parks
    @Query("SELECT * FROM carparks")
    fun getAllCarParks(): Flow<List<CarPark>>

    @Query("SELECT * FROM carparks WHERE id = :id")
    suspend fun getCarParkById(id: Int): CarPark?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCarParks(carParks: List<CarPark>)

    @Update
    suspend fun updateCarPark(carPark: CarPark)

    // Reservations
    @Query("SELECT * FROM reservations ORDER BY id DESC")
    fun getAllReservations(): Flow<List<Reservation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReservation(reservation: Reservation)

    @Update
    suspend fun updateReservation(reservation: Reservation)

    @Query("DELETE FROM reservations WHERE id = :id")
    suspend fun deleteReservationById(id: Int)

    // Charging Sessions
    @Query("SELECT * FROM charging_sessions ORDER BY id DESC")
    fun getAllChargingSessions(): Flow<List<ChargingSession>>

    @Query("SELECT * FROM charging_sessions WHERE status = 'Charging' LIMIT 1")
    fun getActiveChargingSession(): Flow<ChargingSession?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChargingSession(session: ChargingSession)

    @Update
    suspend fun updateChargingSession(session: ChargingSession)

    // Loyalty
    @Query("SELECT * FROM user_loyalty WHERE id = 1")
    fun getLoyaltyAccount(): Flow<UserLoyalty?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoyaltyAccount(loyalty: UserLoyalty)

    @Update
    suspend fun updateLoyaltyAccount(loyalty: UserLoyalty)
}
