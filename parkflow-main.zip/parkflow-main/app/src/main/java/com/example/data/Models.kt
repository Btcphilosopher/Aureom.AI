package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "carparks")
data class CarPark(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val type: String, // "Multi-Storey", "Surface Lot", "Street Parking"
    val totalSpaces: Int,
    val occupiedSpaces: Int,
    val hasEvChargers: Boolean,
    val evChargersCount: Int,
    val hourlyRate: Double,
    val rating: Float,
    val chargerPower: String, // "22 kW AC", "50 kW DC", "150 kW DC", "350 kW Ultra-Rapid"
    val chargerAvailability: String, // "Available", "Busy", "Planned"
    val maxChargerPower: Int, // in kW
    val connectorType: String, // "CCS2", "Type 2", "CHAdeMO"
    val costPerKwh: Double, // pricing in £/kWh
    val peakHours: String, // "12:00-14:00, 17:00-19:00"
    val occupancyTrend: String // "80,75,60,50,45,55,75,85,90,95,95,90" (24h comma separated prediction)
)

@Entity(tableName = "reservations")
data class Reservation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val carParkId: Int,
    val carParkName: String,
    val vehicleReg: String,
    val arrivalTime: String,
    val departureTime: String,
    val cost: Double,
    val status: String, // "Active", "Checked-in", "Completed"
    val qrCodePayload: String, // unique reference string
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "charging_sessions")
data class ChargingSession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val carParkId: Int,
    val stationName: String,
    val connectorType: String,
    val maxPowerKw: Double,
    val energyDeliveredKwh: Double,
    val currentSoc: Double, // state of charge percentage e.g. 45.5
    val currentPowerKw: Double, // real time charging speed
    val cost: Double,
    val status: String, // "Initiating", "Charging", "Completed", "Paused"
    val startTime: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_loyalty")
data class UserLoyalty(
    @PrimaryKey val id: Int = 1, // Single account
    val totalPoints: Int = 240,
    val tier: String = "Gold",
    val tripsBooked: Int = 14,
    val chargingMins: Int = 310,
    val referralCode: String = "PARKFLOW310"
)
