package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CarPark
import kotlin.math.absoluteValue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    viewModel: ParkFlowViewModel,
    modifier: Modifier = Modifier
) {
    val carParks by viewModel.carParks.collectAsState()
    val selectedCarPark by viewModel.selectedCarPark.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filterType by viewModel.filterType.collectAsState()
    val demandModifier by viewModel.operatorDemandModifier.collectAsState()

    var showReservationDialog by remember { mutableStateOf(false) }

    // Map gesture offset values
    var mapOffset by remember { mutableStateOf(Offset(0f, 0f)) }

    // Search & Filter computation
    val filteredCarParks = remember(carParks, searchQuery, filterType) {
        carParks.filter { park ->
            val matchesQuery = park.name.contains(searchQuery, ignoreCase = true) ||
                              park.type.contains(searchQuery, ignoreCase = true)
            
            val matchesFilter = when (filterType) {
                "All" -> true
                "EV Charging" -> park.hasEvChargers
                "Multi-Storey" -> park.type == "Multi-Storey"
                "Available Now" -> (park.totalSpaces - park.occupiedSpaces) > 10
                else -> true
            }
            matchesQuery && matchesFilter
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Transparent) // Cool Transparent background showing under-orbs
    ) {
        // --- 1. Custom Vector Map Canvas ---
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        mapOffset = Offset(
                            x = (mapOffset.x + dragAmount.x).coerceIn(-400f, 400f),
                            y = (mapOffset.y + dragAmount.y).coerceIn(-400f, 400f)
                        )
                    }
                }
                .pointerInput(filteredCarParks) {
                    detectTapGestures { tapOffset ->
                        // Detect taps close to nodes
                        val canvasWidth = size.width
                        val canvasHeight = size.height
                        val centerX = canvasWidth / 2f + mapOffset.x
                        val centerY = canvasHeight / 2f + mapOffset.y

                        var closeNode: CarPark? = null
                        var minDistance = 80f // tap threshold pixels

                        filteredCarParks.forEach { item ->
                            // Scale coordinates around center
                            val dx = (item.longitude - (-2.2426)) * 6000f
                            val dy = -(item.latitude - 53.4808) * 8500f // Flip y for screen coords
                            val nodePos = Offset(centerX + dx.toFloat(), centerY + dy.toFloat())
                            
                            val distance = (tapOffset - nodePos).getDistance()
                            if (distance < minDistance) {
                                minDistance = distance
                                closeNode = item
                            }
                        }
                        if (closeNode != null) {
                            viewModel.selectCarPark(closeNode)
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f + mapOffset.x, size.height / 2f + mapOffset.y)

                // Draw technical grid lines
                val gridSpacing = 80f
                val strokeColor = Color(0xFF1E293B)
                val strokeWidth = 1f
                
                // Vertical grid lines
                var x = mapOffset.x % gridSpacing
                while (x < size.width) {
                    drawLine(strokeColor, Offset(x, 0f), Offset(x, size.height), strokeWidth)
                    x += gridSpacing
                }
                // Horizontal grid lines
                var y = mapOffset.y % gridSpacing
                while (y < size.height) {
                    drawLine(strokeColor, Offset(0f, y), Offset(size.width, y), strokeWidth)
                    y += gridSpacing
                }

                // Draw secondary road networks (futuristic circuit-like layout)
                val roadColor = Color(0xFF1E3A8A).copy(alpha = 0.35f)
                val roadWidth = 14f

                // Central Ring Road
                drawCircle(
                    color = roadColor,
                    radius = 280f,
                    center = center,
                    style = Stroke(roadWidth)
                )

                // Diagonal Arteries
                drawLine(roadColor, center - Offset(600f, 600f), center + Offset(600f, 600f), roadWidth)
                drawLine(roadColor, center - Offset(-600f, 600f), center + Offset(-600f, 600f), roadWidth)

                // Cross grid main streets
                drawLine(roadColor, Offset(0f, center.y), Offset(size.width, center.y), roadWidth)
                drawLine(roadColor, Offset(center.x, 0f), Offset(center.x, size.height), roadWidth)

                // Draw reference smart city radar ring
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF3B82F6).copy(0.08f), Color.Transparent),
                        center = center,
                        radius = 450f
                    ),
                    radius = 450f,
                    center = center
                )

                // Draw nodes for CarParks
                filteredCarParks.forEach { item ->
                    // Mercator projection scale factor around Reference Coordinate (Piccadilly -2.2426, 53.4808)
                    val dx = (item.longitude - (-2.2426)) * 6000
                    val dy = -(item.latitude - 53.4808) * 8500
                    val nodePos = Offset(center.x + dx.toFloat(), center.y + dy.toFloat())

                    // Color based on occupancy
                    val occupancyRate = item.occupiedSpaces.toFloat() / item.totalSpaces.toFloat()
                    val nodeColor = when {
                        occupancyRate >= 0.90f -> Color(0xFFEF4444) // Red / Full
                        occupancyRate >= 0.65f -> Color(0xFFF59E0B) // Amber / Busy
                        else -> Color(0xFF10B981) // Green / Available
                    }

                    // Multi-ring neon pulsing effect
                    drawCircle(
                        color = nodeColor.copy(alpha = 0.15f),
                        radius = 32f,
                        center = nodePos
                    )
                    drawCircle(
                        color = nodeColor.copy(alpha = 0.35f),
                        radius = 22f,
                        center = nodePos
                    )
                    drawCircle(
                        color = nodeColor,
                        radius = 12f,
                        center = nodePos
                    )

                    // Draw inner core to stand out
                    drawCircle(
                        color = Color.White,
                        radius = 4f,
                        center = nodePos
                    )

                    // Overlay brief tags (e.g. Rate indicator £)
                    val labelText = if (item.hasEvChargers) "⚡ £${item.hourlyRate}" else "£${item.hourlyRate}"
                    // Simple indicator visual placeholder (no canvas native text to avoid complex measurement bugs)
                }
            }
        }

        // --- 2. Floating Header Search Card & Filters ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 24.dp)
                .statusBarsPadding()
        ) {
            // Title & Concept Banner
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsCar,
                    contentDescription = null,
                    tint = Color(0xFF10B981),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PARKFLOW",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.weight(1f))
                
                // Signal Indicator of Location status
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.08f),
                    modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "MANCHESTER GPS",
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search location, terminal, station...", color = Color(0xFF64748B)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF94A3B8)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = null, tint = Color.LightGray)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("location_search")
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.12f))
                    .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(14.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                maxLines = 1,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Horizon Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val chips = listOf("All", "EV Charging", "Multi-Storey", "Available Now")
                items(chips) { tab ->
                    val isSelected = filterType == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setFilterType(tab) },
                        label = {
                            Text(
                                text = tab,
                                color = if (isSelected) Color.Black else Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF10B981),
                            containerColor = Color.White.copy(alpha = 0.10f),
                            selectedLabelColor = Color.Black,
                            labelColor = Color.White
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            selectedBorderColor = Color.Transparent,
                            borderColor = Color.White.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }

        // --- 3. Dynamic Interactive Map Compass Instruction (HUD) ---
        Card(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 12.dp, top = 160.dp)
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp)) {
                IconButton(
                    onClick = { mapOffset = Offset(0f, 0f) },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.MyLocation, contentDescription = "Recenter Map", tint = Color.White)
                }
                Spacer(modifier = Modifier.height(6.dp))
                IconButton(
                    onClick = { viewModel.setFilterType("All") },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.FilterList, contentDescription = "Clear Filters", tint = Color.LightGray)
                }
            }
        }

        // --- 4. Selected Card Deck View ---
        selectedCarPark?.let { park ->
            val spotsLeft = park.totalSpaces - park.occupiedSpaces
            val occupancyPercent = ((park.occupiedSpaces.toFloat() / park.totalSpaces.toFloat()) * 100).toInt()

            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
                    .navigationBarsPadding()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("car_park_detail_card")
                        .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(24.dp)),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.12f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        // Header row details
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = park.type.uppercase(),
                                    color = Color(0xFF60A5FA),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = park.name,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("${park.rating} rating", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("0.4 miles away", color = Color(0xFF94A3B8), fontSize = 12.sp)
                                }
                            }

                            // Dynamic Rate Tag
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.White.copy(alpha = 0.06f),
                                modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "HOURLY RATE",
                                        color = Color(0xFF94A3B8),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "£${String.format("%.2f", park.hourlyRate * demandModifier)}",
                                        color = Color(0xFF10B981),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }

                        Divider(color = Color(0xFF334155), modifier = Modifier.padding(vertical = 12.dp))

                        // Space Metrics Block
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Occupancy Capacity", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val indicatorColor = when {
                                        occupancyPercent >= 90 -> Color(0xFFEF4444)
                                        occupancyPercent >= 65 -> Color(0xFFF59E0B)
                                        else -> Color(0xFF10B981)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(indicatorColor)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "$spotsLeft / ${park.totalSpaces} spaces free ($occupancyPercent% full)",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            if (park.hasEvChargers) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("EV Charger Stations", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                    Text(
                                        text = "⚡ ${park.chargerPower} (${park.chargerAvailability})",
                                        color = Color(0xFF10B981),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Toggles Rows
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Reserve Space Button
                            Button(
                                onClick = { showReservationDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(46.dp)
                                    .testTag("reserve_spaces_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Book Parking", color = Color.White, fontWeight = FontWeight.Bold)
                            }

                            // Quick Charge Button
                            if (park.hasEvChargers) {
                                Button(
                                    onClick = { viewModel.startChargingSession(park) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp)
                                        .testTag("quick_charge_btn"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.EvStation, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Charge EV Now", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- 5. Interactive Full Sheet Reservation Modal ---
    if (showReservationDialog && selectedCarPark != null) {
        val park = selectedCarPark!!
        var vehicleRegInput by remember { mutableStateOf("M12 PARK") }
        var selectedArrival by remember { mutableStateOf("12:00") }
        var selectedDeparture by remember { mutableStateOf("15:00") }
        var selectedHours by remember { mutableIntStateOf(3) }
        var bookEvCharger by remember { mutableStateOf(park.hasEvChargers) }

        AlertDialog(
            onDismissRequest = { showReservationDialog = false },
            containerColor = Color(0xFF0F172A).copy(alpha = 0.94f),
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createReservation(
                            carPark = park,
                            vehicleReg = vehicleRegInput,
                            arrival = selectedArrival,
                            departure = selectedDeparture,
                            hoursCount = selectedHours,
                            includeCharging = bookEvCharger
                        )
                        showReservationDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Confirm Spot Booking", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReservationDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LockClock, contentDescription = null, tint = Color(0xFF60A5FA))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Book Parking Space", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Reserve at: ${park.name}",
                        color = Color(0xFF94A3B8),
                        fontSize = 14.sp
                    )
                    
                    // Vehicle details input
                    Text("VEHICLE REGISTRATION NUMBER (ANPR VALIDATED)", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = vehicleRegInput,
                        onValueChange = { vehicleRegInput = it.uppercase() },
                        singleLine = true,
                        placeholder = { Text("e.g. AB12 XYZ", color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth().testTag("vehicle_reg_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF3B82F6),
                            unfocusedBorderColor = Color(0xFF475569)
                        )
                    )

                    // Hours duration scroll
                    Text("HOURLY PLAN:", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(1, 2, 3, 5, 12).forEach { hour ->
                            val active = selectedHours == hour
                            OutlinedCard(
                                onClick = {
                                    selectedHours = hour
                                    // Update departure mock timestamps
                                    val arrHour = selectedArrival.split(":")[0].toInt()
                                    val depHour = (arrHour + hour) % 24
                                    val dep = if (depHour < 10) "0$depHour:00" else "$depHour:00"
                                    selectedDeparture = dep
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (active) Color(0xFF1D4ED8) else Color(0xFF1E293B)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                            ) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("${hour}H", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Virtual Pricing preview
                    val totalCalc = park.hourlyRate * selectedHours * demandModifier +
                            (if (bookEvCharger) park.costPerKwh * 30.0 else 0.0) // Virtual estimate

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Billing Cost", color = Color(0xFF94A3B8), fontSize = 10.sp)
                            Text(
                                "£${String.format("%.2f", totalCalc)}",
                                color = Color(0xFF10B981),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Earn Loyalty Points", color = Color(0xFF94A3B8), fontSize = 10.sp)
                            Text(
                                "★ +${(totalCalc * 15).toInt()} PTS",
                                color = Color(0xFFF59E0B),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    // Optional EV charging inclusion checkbox
                    if (park.hasEvChargers) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = bookEvCharger,
                                onCheckedChange = { bookEvCharger = it },
                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Include EV Charger Reservation (CCS2)",
                                color = Color.White,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        )
    }
}
