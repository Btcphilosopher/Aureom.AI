package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BlueprintScreen(
    viewModel: ParkFlowViewModel,
    modifier: Modifier = Modifier
) {
    val activeSubTab by viewModel.selectedSpecTab.collectAsState()
    val subTabs = listOf("System Arch", "Database Schema", "API Specs", "User Journeys", "OCPP & Payments")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // --- 1. Top Section ---
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 12.dp)
            ) {
                Text(
                    text = "Engineering Specifications Center",
                    color = Color(0xFF60A5FA),
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "PARKFLOW BLUEPRINTS",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp
                )
            }

            // --- 2. Horizontal Scrollable Tab Selector ---
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(subTabs) { tab ->
                    val isSelected = activeSubTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.setSpecTab(tab) },
                        label = {
                            Text(
                                text = tab,
                                color = if (isSelected) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF3B82F6),
                            containerColor = Color(0xFF1E293B)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            selectedBorderColor = Color.Transparent,
                            borderColor = Color(0xFF334155)
                        )
                    )
                }
            }

            // --- 3. Main Spec sheets container ---
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (activeSubTab) {
                    "System Arch" -> ArchSpecView()
                    "Database Schema" -> DatabaseSchemaSpecView()
                    "API Specs" -> ApiSpecView()
                    "User Journeys" -> UserJourneysSpecView()
                    "OCPP & Payments" -> OcppAndPaymentsView()
                }
            }
        }
    }
}

// ======================== SUB COMPOSABLES ========================

@Composable
fun ArchSpecView() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PARKFLOW FULL-STACK PRODUCT ARCHITECTURE", color = Color(0xFF60A5FA), fontSize = 12.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "The system utilizes an decoupled event-driven architectural pattern built on top of high-performance Kubernetes container nodes. API Gateways coordinate load traffic safely between microservices.",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // 1. Mobile & Client Blocks
        item {
            ArchBlock(
                title = "1. CLIENT WORKSPACES",
                accentColor = Color(0xFF10B981),
                details = listOf(
                    "ParkFlow Android App (Jetpack Compose, Room SQLite, Retrofit)",
                    "Apple iOS Mobile App (SwiftUI, CoreData, URLSession)",
                    "Android Auto & Apple CarPlay SDK integrations",
                    "Business Web Console Dashboard (React, Tailwind CSS, Vite)"
                )
            )
        }

        // Link Connector Visual indicator
        item { FlowConnector() }

        // 2. Gateway Block
        item {
            ArchBlock(
                title = "2. API GATEWAY LAYER (Kong / KrakenD)",
                accentColor = Color(0xFFF59E0B),
                details = listOf(
                    "Dynamic route routing & Rate Limiting (JWT Token authorization)",
                    "WebSockets charger telemetry relay streams",
                    "Unified GraphQL / RESTful interface adapters"
                )
            )
        }

        item { FlowConnector() }

        // 3. Microservices Grid
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "3. DECOUPLED MICROSERVICES BACKPLANE",
                        color = Color(0xFF3B82F6),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    val services = listOf(
                        "🅿️ Parking Service" to "Manages parking space grids, states, sensor status, spot geometries & capacity.",
                        "⚡ EV Charging Service" to "Coordinates charge points, status transitions, power distribution, energy telemetry.",
                        "💳 Billing & Payment" to "Stripe transaction captures, dynamic receipts generation, energy market billing.",
                        "👤 User & Fleet Profile" to "RFID tokens registration, telemetry accounts, corporate card invoicing, fleet rules.",
                        "🗺️ Navigation Service" to "Dynamic routing algorithms, waypoint schedules, walking path overlays (OSM/MapBox).",
                        "📈 Reporting & Forecasting" to "Gemini AI occupancy forecasting engine, dynamic rates modifications calculations."
                    )

                    services.forEach { (name, desc) ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(desc, color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Divider(color = Color(0xFF334155))
                        }
                    }
                }
            }
        }

        item { FlowConnector() }

        // 4. Persistence layers
        item {
            ArchBlock(
                title = "4. DATABASES & PERSISTENCE STACK",
                accentColor = Color(0xFFA855F7),
                details = listOf(
                    "PostgreSQL Cluster: Primary user records, bookings, transactions ledger",
                    "YugabyteDB / Cassandra: Horizontally scalable charging telemetry values",
                    "Redis Enterprise: Cache coordinates grids, nearby index nodes, rate locks",
                    "Apache Kafka Grid: Real-time sensor triggers, state change queues"
                )
            )
        }
    }
}

@Composable
fun DatabaseSchemaSpecView() {
    val schemaTables = listOf(
        TableSchema(
            tableName = "carparks (Primary Info Table)",
            rows = listOf(
                "id" to "INT (PK, Auto-Increment)",
                "name" to "VARCHAR(255)",
                "latitude • longitude" to "DOUBLE PRECISION",
                "totalSpaces • occupiedSpaces" to "INT",
                "hasEvChargers" to "BOOLEAN",
                "evChargerCount" to "INT",
                "hourlyRate" to "DECIMAL(10,2)",
                "costPerKwh" to "DECIMAL(10,2)",
                "connectorType" to "VARCHAR(50)"
            )
        ),
        TableSchema(
            tableName = "reservations (Parking Booking)",
            rows = listOf(
                "id" to "INT (PK, Auto-Increment)",
                "carParkId" to "INT (FK -> carparks.id)",
                "vehicleReg" to "VARCHAR(20)",
                "arrivalTime" to "VARCHAR(10) (HH:mm format)",
                "departureTime" to "VARCHAR(10)",
                "cost" to "DECIMAL(10,2)",
                "status" to "VARCHAR(50) (Active, Completed, Cancelled)",
                "qrCodePayload" to "VARCHAR(100) (Unique check-in barcode token)"
            )
        ),
        TableSchema(
            tableName = "charging_sessions (EV Telemetry sessions)",
            rows = listOf(
                "id" to "INT (PK, Auto-Increment)",
                "carParkId" to "INT (FK -> carparks.id)",
                "connectorType" to "VARCHAR(50)",
                "energyDeliveredKwh" to "DOUBLE PRECISION",
                "currentSoc" to "DOUBLE PRECISION (% charge percentage)",
                "currentPowerKw" to "DOUBLE PRECISION (live charging speed kW)",
                "cost" to "DECIMAL(10,2)",
                "status" to "VARCHAR(50) (Charging, Completed)"
            )
        ),
        TableSchema(
            tableName = "user_loyalty (Gamification ledger)",
            rows = listOf(
                "id" to "INT (PK)",
                "totalPoints" to "INT",
                "tier" to "VARCHAR(50) (Silver, Gold, Platinum)",
                "tripsBooked" to "INT",
                "chargingMins" to "INT",
                "referralCode" to "VARCHAR(50)"
            )
        )
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFF60A5FA))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "Interactive Table Modeling Database Schemas (SQLite/Postgres)",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        items(schemaTables) { table ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF3B82F6))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TABLE: ${table.tableName}".uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    table.rows.forEach { (colName, dataType) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(colName, color = Color(0xFFE2E8F0), fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text(dataType, color = Color(0xFF94A3B8), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                        Divider(color = Color(0xFF334155).copy(alpha = 0.5f))
                    }
                }
            }
        }
    }
}

@Composable
fun ApiSpecView() {
    val endpoints = listOf(
        ApiEndpoint(
            method = "GET",
            route = "/api/v1/spaces/nearby",
            desc = "Find nearby parking locations with active space counts and EV metrics.",
            params = listOf("lat (Double, Query)", "lon (Double, Query)", "filter (String, Optional)"),
            responseJson = "[\n  {\n    \"id\": 1,\n    \"name\": \"Piccadilly Plaza\",\n    \"totalSpaces\": 350,\n    \"occupiedSpaces\": 142,\n    \"hasEv\": true\n  }\n]"
        ),
        ApiEndpoint(
            method = "POST",
            route = "/api/v1/reservations/book",
            desc = "Reserve a specific parking bay and optionally block an EV port.",
            params = listOf("carParkId (Int)", "vehicleReg (String)", "startTime (String)", "durationHours (Int)"),
            responseJson = "{\n  \"status\": \"success\",\n  \"bookingReference\": \"FLOW-1-84192\",\n  \"totalCost\": 13.50,\n  \"qrCodePayload\": \"FLOW-1-84192\"\n}"
        ),
        ApiEndpoint(
            method = "POST",
            route = "/api/v1/charging/session/start",
            desc = "Begin dynamic electricity transfer session at a selected terminal.",
            params = listOf("carParkId (Int)", "connectorType (String)", "initialSoc (Double)"),
            responseJson = "{\n  \"sessionId\": 829,\n  \"status\": \"Charging\",\n  \"maxPowerKw\": 150.0,\n  \"currentPowerKw\": 148.2\n}"
        ),
        ApiEndpoint(
            method = "GET",
            route = "/v1/dynamic-marketplace/tariffs",
            desc = "Retrieve dynamic off-peak grid billing rates from energy marketplace.",
            params = emptyList(),
            responseJson = "[\n  {\n    \"provider\": \"Octopus Agile\",\n    \"source\": \"Wind Power\",\n    \"ratePerKwh\": 0.28,\n    \"isOffPeakNow\": true\n  }\n]"
        )
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Code, contentDescription = null, tint = Color(0xFF10B981))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "Interconnect API Endpoint Specifications",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        items(endpoints) { spec ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Method + Route
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val methodBg = if (spec.method == "GET") Color(0xFF064E3B) else Color(0xFF1E3A8A)
                        val methodFg = if (spec.method == "GET") Color(0xFF10B981) else Color(0xFF60A5FA)
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = methodBg
                        ) {
                            Text(
                                text = spec.method,
                                color = methodFg,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Text(
                            text = spec.route,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(spec.desc, color = Color(0xFF94A3B8), fontSize = 12.sp)

                    if (spec.params.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("REQUEST PARAMS / BODY:", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        spec.params.forEach { param ->
                            Text("• $param", color = Color.LightGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("RESPONSE PAYLOAD (200 OK):", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        color = Color(0xFF020617),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                    ) {
                        Text(
                            text = spec.responseJson,
                            color = Color(0xFF34D399),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun UserJourneysSpecView() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            JourneyStepCard(
                title = "JOURNEY PROFILE A: STANDARD COMMUTER (SPACE RESERVE)",
                steps = listOf(
                    "Step 1: Discover near available bays" to "Opens Map, filters by 'Available Now', reviews distance and hourly rate.",
                    "Step 2: Interactive grid Reservation" to "Taps 'Book Parking', registers license plate, selects 3 hour slot duration, triggers booking.",
                    "Step 3: ANPR Camera sync checking" to "Arrives at car park. Smart ANPR validation camera scans license plate, auto-matches active 예약 reservation, lifts barrier automatically.",
                    "Step 4: Remote Extension Remote" to "Meetings run late. Opens app, views ticket, taps 'Extend +1H', Stripe updates transaction billing balance, departure limit updates in security systems database."
                )
            )
        }

        item {
            JourneyStepCard(
                title = "JOURNEY PROFILE B: EV ROAD-TRIPPER (RAPID PLUG-IN)",
                accentBorder = Color(0xFF10B981),
                steps = listOf(
                    "Step 1: Charger hub isolation" to "Opens ParkFlow, selects 'EV Charging' filter, searches 150kW ultra-rapid hubs near Piccadilly.",
                    "Step 2: Plug-in and Start charge" to "Taps 'Charge EV Now'. Physical handshake authorizes CCS2 cable tethering dynamically with grid nodes.",
                    "Step 3: Telemetry simulation tracker" to "Sits in local coffee shop monitoring live SOC metrics (% charged, current flow kW, elapsed charging duration, pricing, grid frequency).",
                    "Step 4: Auto-Receipt and Loyalty bonus" to "Toggles session complete. Charging cable tethers de-latch safely. Automatic electronic receipt compiles. Customer gains 150 points for off-peak solar pricing choice."
                )
            )
        }
    }
}

@Composable
fun OcppAndPaymentsView() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // OCPP protocol details
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                modifier = Modifier
                    .fillParentMaxWidth()
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("OCPP 2.0.1 SYSTEM PROTOCOL FLOW", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "How ParkFlow communicates dynamically with physical EV charger sockets using standard OpenAPI OCPP streams:",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    val sequence = listOf(
                        "1. BootNotification" to "Physical charger station powers up, sends hardware metadata specs to ParkFlow Cloud Engine.",
                        "2. Authorize" to "User taps start session. RFID or App JWT validates charge socket access approval.",
                        "3. StartTransaction" to "Physical relais latch. Electric tethers lock. Grid power flow commences.",
                        "4. Telemetry MeterValues" to "Constant JSON packets updating current State of Charge, temperature, energy flow, dynamic grid frequency.",
                        "5. StopTransaction" to "User terminates. Latch disconnects tethers, calculates total metric billing, terminates power streams cleanly."
                    )

                    sequence.forEach { (msg, desc) ->
                        Row(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text("$msg: ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text(desc, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        }
                        Divider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }

        // Stripe billing infrastructure details
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier
                    .fillParentMaxWidth()
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("PAYMENT GATEWAY ENGINE & POWERCOIN CREDITS", color = Color(0xFF60A5FA), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "ParkFlow integrates multiple payment providers through a multi-tenant payment gateway broker. Dynamic pricing rates and energy tariffs lock down Stripe PaymentIntents securely.",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    val features = listOf(
                        "💳 Stripe PaymentIntents API" to "Performs automatic multi-party split-billing between the parking operators and clean energy grid utility provider.",
                        "⚡ Powercoin Energy Credits" to "Allows micro-grid operators to reward drivers with blockchain power credits when choosing off-peak solar/wind surpluses.",
                        "📱 Apple Pay & Google Pay API" to "Direct SDK bindings supporting instant biomechanic authorization check-out."
                    )

                    features.forEach { (title, desc) ->
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(desc, color = Color(0xFF94A3B8), fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

// Helpers
@Composable
fun ArchBlock(
    title: String,
    accentColor: Color,
    details: List<String>
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, color = accentColor, fontWeight = FontWeight.Black, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            details.forEach { detail ->
                Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(vertical = 2.dp)) {
                    Text("▪ ", color = accentColor, fontWeight = FontWeight.Bold)
                    Text(detail, color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun FlowConnector() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(Color(0xFF334155))
        )
    }
}

@Composable
fun JourneyStepCard(
    title: String,
    steps: List<Pair<String, String>>,
    accentBorder: Color = Color(0xFF3B82F6)
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, accentBorder, RoundedCornerShape(16.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, color = accentBorder, fontWeight = FontWeight.Black, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(14.dp))

            steps.forEachIndexed { idx, (stepTitle, stepDesc) ->
                Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(vertical = 6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(accentBorder),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${idx + 1}", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(stepTitle, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(stepDesc, color = Color(0xFF94A3B8), fontSize = 11.sp)
                    }
                }
                if (idx < steps.size - 1) {
                    Box(
                        modifier = Modifier
                            .padding(start = 9.dp)
                            .width(1.5.dp)
                            .height(16.dp)
                            .background(Color(0xFF334155))
                    )
                }
            }
        }
    }
}

data class TableSchema(val tableName: String, val rows: List<Pair<String, String>>)
data class ApiEndpoint(val method: String, val route: String, val desc: String, val params: List<String>, val responseJson: String)
