# Integration & Deployment Architecture Notes

> **Independent Design Concept:** This application is an architectural hospitality & payment concept. It does not represent confirmed merchant acceptance or live bookings by The Trump Organization. All properties, room rates, exchange quotes, and payment rails run in **Demonstration Mode** by default unless explicitly verified and enabled in production configuration.

---

## 1. Quick Start & Commands

```bash
# Install dependencies
npm install

# Run development server (http://localhost:3000)
npm run dev

# Build for production
npm run build

# Start production build
npm run start

# Run automated reservation, pricing, hold-race, webhook & crypto tests
npx vitest run

# TypeScript & ESLint verification
npm run lint
```

---

## 2. Database & Persistence Model

- **Configured Backend (`firebase-applet-config.json` + `firestore.rules` + `firebase-blueprint.json`)**:
  - Firebase Authentication (`GoogleAuthProvider` popup) and Firestore schema/rules are provisioned and deployed (`firestore.rules` validated via `@firebase/eslint-plugin-security-rules`).
- **Transactional Server Engine (`/lib/server/store.ts`)**:
  - Executes atomic inventory holds, nightly unit allocation, reservation creation, idempotent payment attempts, crypto quotes, refunds, webhook logs, audit events, and email outbox writes inside a serialized async lock (`withStoreLock`) persisted atomically to `.data/hospitality-store.json` (or `HOSPITALITY_STORE_PATH` for isolated test runs).
  - *Note on Relational SQL / PostgreSQL*: If migrating to a hosted PostgreSQL cluster in production, map the 14 collections defined in `lib/types.ts` and `firebase-blueprint.json` (Properties, RoomTypes, NightlyInventory, RatePlans, Holds, Guests, Reservations, PaymentAttempts, CryptoQuotes, Refunds, WebhookEvents, AdminUsers, AuditEvents, EmailOutbox) to `SELECT ... FOR UPDATE` transactions around `NightlyInventory` and `ReservationHolds`.

---

## 3. Payment & Settlement Boundaries

### Fail-Closed Mode Configuration
In `SystemConfig` (`lib/types.ts`), live payment acceptance is **disabled by default**:
- `liveUsdEnabled: false`
- `liveCryptoEnabled: false`

Attempting to request a `"live"` USD session or crypto quote while these flags are `false` returns **HTTP 403** unless both server-side provider credentials AND admin configuration flags are verified.

### US Dollars (`usd_card`)
- **Demonstration Mode**: Creates an attempt with `mode: "demo"` and simulates provider HMAC-SHA256 webhooks (`/api/payments/usd/simulate` -> `/api/webhooks/payments`). Never collects real card numbers.
- **Webhook Verification**: `/api/webhooks/payments` validates the `x-webhook-signature` HMAC-SHA256 header against `PAYMENT_WEBHOOK_SECRET` using timing-safe comparison, deduplicates events by `providerEventId`, and confirms reservations strictly upon verified webhook evidence.

### Proposed Cryptocurrency Checkout (`trump_token` & `usd1_stablecoin`)
- **Strict Allowlist (`lib/crypto-assets.ts`)**: Assets are never matched by ticker alone; quotes and transfer observations require an exact `{ assetId, network, tokenIdentifier }` tuple.
- **Exact Base-Unit Math (`BigInt`)**: USD totals (integer cents) convert to exact token base units via `BigInt` integer scaling without assuming `1 USD1 == $1.00 USD`.
- **Edge-Case Handling (`/api/payments/crypto/observe`)**:
  - Partial confirmations (`confirmations < requiredConfirmations`) -> `confirming` (booking remains `pending_payment`).
  - Underpayment -> `underpaid` (flagged in Admin Reconciliation).
  - Overpayment -> `overpaid` (flagged in Admin Reconciliation for partial refund review).
  - Expired Quote or Expired Hold at Payment -> marks reservation `reconciliation_required` (`late_payment_hold_expired`) instead of silently overselling inventory.

---

## 4. Optional AI Concierge (`/api/concierge`)
- Powered exclusively server-side via `@google/genai` using `GEMINI_API_KEY` and model `gemini-4-hydrogen` (`lib/server/store.ts` never sends secrets to the browser).
- Grounded strictly in live seeded property and availability data; supports read-only stay lookup and server-validated enquiry draft creation.

---

## 5. Checklist Before Accepting Real Bookings or Payments
1. Replace `.data/hospitality-store.json` with production Firestore admin credentials (server-side service account) or a managed PostgreSQL database with row-level locking.
2. Set cryptographically random secrets in `.env`: `BOOKING_TOKEN_SECRET`, `PAYMENT_WEBHOOK_SECRET`, `CRON_SECRET`.
3. Integrate a verified live hosted checkout provider (e.g., Stripe Checkout) with production webhook signing secrets before flipping `liveUsdEnabled`.
4. Verify official mainnet token contract addresses, mint IDs, decimals, custody provider capabilities, and live oracle feeds before enabling any live crypto adapter (`liveCryptoEnabled`).
5. Review and tighten `firestore.rules` before broader deployment.
6. Replace fictional demonstration property photography, amenities, and rates with verified property content.
