import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { ArrowRight, Clock } from "lucide-react";
import { listProperties } from "@/lib/server/store";
import { formatUsdCents } from "@/lib/crypto-assets";

export const metadata: Metadata = {
  title: "Golf & Private Experiences — The Trump Organization Concept",
  description:
    "Championship links tee times, private coastal yacht charters, culinary salons, and thermal wellness rituals.",
};

export const dynamic = "force-dynamic";

export default async function ExperiencesPage() {
  const { experiences } = await listProperties();

  return (
    <div className="bg-[#FAF8F3] py-12 sm:py-16">
      <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12">
        <div className="max-w-2xl mb-12">
          <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F] mb-3">
            Championship Golf &amp; Curated Access
          </p>
          <h1 className="font-serif text-4xl sm:text-5xl text-[#111111] text-balance">
            Distinctive Experiences
          </h1>
          <p className="mt-4 text-sm sm:text-base text-[#4A453C] leading-relaxed">
            Illustrative private experiences coordinated alongside your stay.
            Availability and tailored itineraries are arranged through Private
            Client Services.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {experiences.map((exp) => (
            <article
              key={exp.id}
              className="bg-white border border-[#E2DACB] flex flex-col justify-between"
            >
              <div>
                <div className="relative aspect-[16/10] bg-[#221F1B]">
                  <Image
                    src={exp.imageUrl}
                    alt={exp.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-7 space-y-3">
                  <p className="text-[11px] tracking-[0.2em] uppercase text-[#8A6B2F]">
                    {exp.propertyName}
                  </p>
                  <h2 className="font-serif text-2xl sm:text-3xl text-[#111111]">
                    {exp.title}
                  </h2>
                  <p className="text-sm text-[#4A453C] leading-relaxed">
                    {exp.description}
                  </p>
                </div>
              </div>

              <div className="px-7 py-5 border-t border-[#EBE4D6] bg-[#FAF8F3]/70 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4 text-xs">
                  <span className="inline-flex items-center gap-1.5 text-[#686054]">
                    <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                    {exp.duration}
                  </span>
                  <span aria-hidden="true">&middot;</span>
                  <span className="font-mono tabular-nums font-semibold text-[#111111]">
                    From {formatUsdCents(exp.startingPriceUsdCents)} USD
                  </span>
                </div>

                <Link
                  href={`/contact?subject=${encodeURIComponent(`Experience Enquiry: ${exp.title}`)}`}
                  className="inline-flex items-center gap-2 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-5 py-2.5 text-[10px] font-medium tracking-[0.18em] uppercase hover:bg-[#1E1E1E] transition-colors"
                >
                  <span>Request Coordination</span>
                  <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
}
