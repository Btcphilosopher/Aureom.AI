import type { Metadata } from "next";
import { Cormorant_Garamond, Plus_Jakarta_Sans, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/components/AuthProvider";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { ConciergeDrawer } from "@/components/ConciergeDrawer";

const cormorant = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-serif-cormorant",
  display: "swap",
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans-jakarta",
  display: "swap",
});

const ibmMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-mono-ibm",
  display: "swap",
});

export const metadata: Metadata = {
  title: "The Trump Organization — Luxury Hospitality & Residences Concept",
  description:
    "Independent luxury hospitality and residences concept featuring landmark hotels, coastal retreats, championship golf, and persistent demonstration reservations.",
  openGraph: {
    title: "The Trump Organization — Luxury Hospitality & Residences Concept",
    description:
      "Independent luxury hospitality and residences concept featuring landmark hotels, coastal retreats, championship golf, and persistent demonstration reservations.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "The Trump Organization — Luxury Hospitality & Residences Concept",
    description:
      "Independent luxury hospitality and residences concept featuring landmark hotels, coastal retreats, championship golf, and persistent demonstration reservations.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${cormorant.variable} ${jakarta.variable} ${ibmMono.variable}`}
    >
      <body
        suppressHydrationWarning
        className="min-h-screen flex flex-col bg-[#FAF8F3] text-[#111111] selection:bg-[#C5A25D]/25 selection:text-[#111111]"
      >
        <AuthProvider>
          <SiteHeader />
          <main className="flex-1">{children}</main>
          <SiteFooter />
          <ConciergeDrawer />
        </AuthProvider>
      </body>
    </html>
  );
}
