import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { FunctionDeclaration, GoogleGenAI, Type } from "@google/genai";
import { formatUsdCents } from "@/lib/crypto-assets";
import { listProperties, searchAvailability } from "@/lib/server/store";

const ConciergeSchema = z.object({
  message: z.string().min(1).max(2000),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "model"]),
        text: z.string(),
      })
    )
    .max(12)
    .optional(),
});

const listPropertiesDecl: FunctionDeclaration = {
  name: "listProperties",
  description:
    "Retrieve the approved catalog of demonstration properties, amenities, categories, and starting nightly USD rates.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      category: {
        type: Type.STRING,
        description:
          "Optional category filter: city_landmark, coastal_retreat, championship_golf, or residence.",
      },
    },
  },
};

const checkAvailabilityDecl: FunctionDeclaration = {
  name: "checkAvailability",
  description:
    "Query live backend room availability and server-calculated USD stay totals for a property and dates.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      propertyIdOrSlug: {
        type: Type.STRING,
        description: "The property ID or slug.",
      },
      checkIn: {
        type: Type.STRING,
        description: "Check-in date in YYYY-MM-DD format.",
      },
      checkOut: {
        type: Type.STRING,
        description: "Check-out date in YYYY-MM-DD format.",
      },
      adults: {
        type: Type.INTEGER,
        description: "Number of adult guests (minimum 1).",
      },
      children: {
        type: Type.INTEGER,
        description: "Number of child guests (minimum 0).",
      },
      roomCount: {
        type: Type.INTEGER,
        description: "Number of rooms requested (minimum 1).",
      },
    },
    required: ["propertyIdOrSlug", "checkIn", "checkOut"],
  },
};

const getBookingTermsDecl: FunctionDeclaration = {
  name: "getBookingTerms",
  description:
    "Retrieve published cancellation terms, rate plans, payment modes (demo vs live), and crypto disclosure rules.",
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const draftEnquiryDecl: FunctionDeclaration = {
  name: "draftEnquiry",
  description:
    "Prepare a support enquiry draft for the customer to review and explicitly confirm before submission. Never submits autonomously.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      subject: { type: Type.STRING },
      message: { type: Type.STRING },
      propertyId: { type: Type.STRING },
    },
    required: ["subject", "message"],
  },
};

async function executeToolCall(
  name: string,
  args: Record<string, unknown>
): Promise<unknown> {
  if (name === "listProperties") {
    const { properties, experiences } = await listProperties();
    const cat = typeof args.category === "string" ? args.category : undefined;
    const filtered = cat
      ? properties.filter((p) => p.category === cat)
      : properties;
    return {
      properties: filtered.map((p) => ({
        id: p.id,
        slug: p.slug,
        name: p.name,
        category: p.category,
        city: p.city,
        country: p.country,
        tagline: p.tagline,
        amenities: p.amenities,
        startingRateUsd: formatUsdCents(p.startingRateUsdCents),
      })),
      experiences: experiences.map((e) => ({
        title: e.title,
        propertyName: e.propertyName,
        duration: e.duration,
        startingPriceUsd: formatUsdCents(e.startingPriceUsdCents),
      })),
    };
  }

  if (name === "checkAvailability") {
    try {
      const res = await searchAvailability({
        propertyIdOrSlug: String(args.propertyIdOrSlug || "hudson-landmark-new-york"),
        checkIn: String(args.checkIn),
        checkOut: String(args.checkOut),
        adults: Number(args.adults) || 2,
        children: Number(args.children) || 0,
        roomCount: Number(args.roomCount) || 1,
      });
      return {
        property: res.property.name,
        slug: res.property.slug,
        checkIn: res.checkIn,
        checkOut: res.checkOut,
        nights: res.nights,
        offers: res.offers.map((o) => ({
          roomTypeId: o.roomType.id,
          roomName: o.roomType.name,
          availableUnits: o.availableUnits,
          isAvailable: o.isAvailable,
          occupancyError: o.occupancyError,
          rateOffers: o.rateOffers.map((ro) => ({
            ratePlanName: ro.ratePlan.name,
            totalUsd: formatUsdCents(ro.pricing.totalUsdCents),
            cancellationPolicy: ro.ratePlan.cancellationSummary,
          })),
        })),
      };
    } catch (err) {
      return {
        error: err instanceof Error ? err.message : "Availability lookup failed.",
      };
    }
  }

  if (name === "getBookingTerms") {
    const { ratePlans, systemConfig } = await listProperties();
    return {
      demonstrationNotice:
        "This is an independent hospitality design concept with fictional demonstration inventory. Proposed $TRUMP and USD1 checkouts operate via a simulation adapter and are not confirmed live merchant acceptance.",
      liveUsdEnabled: systemConfig.liveUsdEnabled,
      liveCryptoEnabled: systemConfig.liveCryptoEnabled,
      holdDurationMinutes: 15,
      ratePlans: ratePlans.slice(0, 3).map((rp) => ({
        name: rp.name,
        version: rp.cancellationPolicyVersion,
        summary: rp.cancellationSummary,
      })),
    };
  }

  if (name === "draftEnquiry") {
    return {
      draftReady: true,
      requiresExplicitUserConfirmation: true,
      subject: String(args.subject || "Private Concierge Enquiry"),
      message: String(args.message || ""),
      propertyId: args.propertyId ? String(args.propertyId) : undefined,
    };
  }

  return { error: `Unknown tool ${name}` };
}

async function runOfflineMockConcierge(userMessage: string): Promise<{
  reply: string;
  mode: "offline_mock";
  draftEnquiry?: { subject: string; message: string; propertyId?: string };
}> {
  const lower = userMessage.toLowerCase();
  const { properties, ratePlans } = await listProperties();

  if (lower.includes("cancel") || lower.includes("refund") || lower.includes("term") || lower.includes("policy")) {
    return {
      mode: "offline_mock",
      reply:
        "### Published Reservation & Cancellation Terms (Offline Demonstration Mode)\n\n" +
        ratePlans
          .slice(0, 3)
          .map((rp) => `- **${rp.name}** (${rp.cancellationPolicyVersion}): ${rp.cancellationSummary}`)
          .join("\n") +
        "\n\nInventory holds remain locked for **15 minutes** during checkout. Refunds are calculated in USD from your accepted policy snapshot; any crypto refund requires explicit wallet verification and administrative approval.",
    };
  }

  if (lower.includes("draft") || lower.includes("enquiry") || lower.includes("contact")) {
    const draft = {
      subject: "Private Stay & Concierge Consultation",
      message: `Hello Private Client Services,\n\nI would like assistance arranging an upcoming demonstration stay regarding: "${userMessage}".\n\nPlease advise on preferred suite availability.`,
      propertyId: properties[0]?.id,
    };
    return {
      mode: "offline_mock",
      reply:
        "I have prepared a support enquiry draft below. Review the text and click **Confirm & Send Enquiry** if you would like to submit it.",
      draftEnquiry: draft,
    };
  }

  if (lower.includes("golf") || lower.includes("coastal") || lower.includes("new york") || lower.includes("compare") || lower.includes("availab")) {
    const startDt = new Date(Date.now() + 7 * 86_400_000).toISOString().slice(0, 10);
    const endDt = new Date(Date.now() + 9 * 86_400_000).toISOString().slice(0, 10);
    const nyAvail = await searchAvailability({
      propertyIdOrSlug: "hudson-landmark-new-york",
      checkIn: startDt,
      checkOut: endDt,
      adults: 2,
      children: 0,
      roomCount: 1,
    });
    const offer = nyAvail.offers[0];
    return {
      mode: "offline_mock",
      reply:
        `### Approved Collection & Live Availability Snapshot (Offline Mode)\n\n` +
        properties
          .slice(0, 4)
          .map(
            (p) =>
              `- **${p.name}** (${p.city}) — Starting from ${formatUsdCents(p.startingRateUsdCents)}/night`
          )
          .join("\n") +
        (offer
          ? `\n\n**Sample Live Backend Check (${startDt} to ${endDt}, 2 adults):** ${nyAvail.property.name} · ${offer.roomType.name} (${offer.availableUnits} units remaining) starting at **${formatUsdCents(offer.rateOffers[0].pricing.totalUsdCents)} USD** total inclusive of fees and taxes.`
          : ""),
    };
  }

  return {
    mode: "offline_mock",
    reply:
      "Welcome to the Private Hospitality Concierge (Offline Demonstration Mode). I can compare our approved demonstration properties, retrieve live room availability and USD rate breakdowns, explain published cancellation policies, or draft a support enquiry for your confirmation.",
  };
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = ConciergeSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Please enter a valid concierge question." },
        { status: 400 }
      );
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      const mock = await runOfflineMockConcierge(parsed.data.message);
      return NextResponse.json(mock);
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    const systemInstruction =
      "You are the Private Hospitality Concierge for an independent luxury hospitality design concept. " +
      "ONLY cite properties, amenities, room types, availability, prices, and booking policies returned by your backend tools (listProperties, checkAvailability, getBookingTerms). " +
      "NEVER invent rooms, prices, policies, awards, customer reviews, or completed reservations. " +
      "NEVER initiate refunds, alter wallet destinations, or submit enquiries autonomously—use draftEnquiry to prepare a draft and ask for the guest's explicit confirmation. " +
      "Be concise, refined, and transparent that inventory and proposed crypto options are for demonstration.";

    const contents: { role: string; parts: Array<Record<string, unknown>> }[] = [
      ...(parsed.data.history || []).map((h) => ({
        role: h.role,
        parts: [{ text: h.text }],
      })),
      { role: "user", parts: [{ text: parsed.data.message }] },
    ];

    const tools = [
      {
        functionDeclarations: [
          listPropertiesDecl,
          checkAvailabilityDecl,
          getBookingTermsDecl,
          draftEnquiryDecl,
        ],
      },
    ];

    let draftEnquiry:
      | { subject: string; message: string; propertyId?: string }
      | undefined;

    try {
      let response = await ai.models.generateContent({
        model: "gemini-4-hydrogen",
        contents: contents as never,
        config: {
          systemInstruction,
          tools,
        },
      });

      // Up to 2 tool-call rounds
      for (let step = 0; step < 2; step++) {
        const calls = response.functionCalls;
        if (!calls || calls.length === 0) break;

        const prevContent = response.candidates?.[0]?.content;
        if (!prevContent) break;

        const toolResponseParts: Array<Record<string, unknown>> = [];
        for (const call of calls) {
          const toolName = call.name || "";
          const toolArgs = (call.args || {}) as Record<string, unknown>;
          const result = await executeToolCall(toolName, toolArgs);
          if (
            toolName === "draftEnquiry" &&
            result &&
            typeof result === "object" &&
            "draftReady" in result
          ) {
            const d = result as unknown as {
              subject: string;
              message: string;
              propertyId?: string;
            };
            draftEnquiry = {
              subject: d.subject,
              message: d.message,
              propertyId: d.propertyId,
            };
          }
          toolResponseParts.push({
            functionResponse: {
              id: call.id,
              name: toolName,
              response: { result },
            },
          });
        }

        contents.push(prevContent as never);
        contents.push({ role: "user", parts: toolResponseParts });

        response = await ai.models.generateContent({
          model: "gemini-4-hydrogen",
          contents: contents as never,
          config: {
            systemInstruction,
            tools,
          },
        });
      }

      return NextResponse.json({
        reply:
          response.text ||
          "I checked our hospitality records, though no text summary was generated. Please try rephrasing your request.",
        mode: "live_gemini",
        draftEnquiry,
      });
    } catch (geminiErr) {
      console.error("Gemini Concierge fallback:", geminiErr);
      const mock = await runOfflineMockConcierge(parsed.data.message);
      return NextResponse.json(mock);
    }
  } catch {
    return NextResponse.json(
      { error: "Concierge service is temporarily unavailable." },
      { status: 500 }
    );
  }
}
