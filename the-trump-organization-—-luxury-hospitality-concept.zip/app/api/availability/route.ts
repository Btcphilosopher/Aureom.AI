import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { searchAvailability } from "@/lib/server/store";

const AvailabilitySchema = z.object({
  propertyIdOrSlug: z.string().min(1),
  checkIn: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  checkOut: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  adults: z.number().int().min(1).max(24),
  children: z.number().int().min(0).max(24),
  roomCount: z.number().int().min(1).max(8),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = AvailabilitySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          error: "Invalid availability parameters.",
          issues: parsed.error.flatten(),
        },
        { status: 400 }
      );
    }
    const result = await searchAvailability(parsed.data);
    return NextResponse.json(result);
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Failed to calculate availability.";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
