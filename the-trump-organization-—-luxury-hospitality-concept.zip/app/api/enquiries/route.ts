import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { verifyBearerUser } from "@/lib/server/auth";
import { createEnquiry } from "@/lib/server/store";

const EnquirySchema = z.object({
  guestName: z.string().min(2).max(160),
  guestEmail: z.string().email().max(200),
  subject: z.string().min(2).max(200),
  message: z.string().min(5).max(4000),
  propertyId: z.string().optional(),
  reservationId: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await verifyBearerUser(req.headers.get("authorization"));
    const body = await req.json();
    const parsed = EnquirySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Please complete all required enquiry fields." },
        { status: 400 }
      );
    }

    const enquiry = await createEnquiry({
      ...parsed.data,
      guestUid: user?.uid,
    });
    return NextResponse.json({ enquiry }, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Failed to record enquiry." },
      { status: 400 }
    );
  }
}
