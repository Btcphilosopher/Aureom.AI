import { NextRequest, NextResponse } from "next/server";
import { listProperties } from "@/lib/server/store";

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ slug: string }> }
) {
  const { slug } = await context.params;
  const { properties, roomTypes, ratePlans, experiences } =
    await listProperties();
  const property = properties.find(
    (p) => p.slug === slug || p.id === slug
  );
  if (!property) {
    return NextResponse.json({ error: "Property not found." }, { status: 404 });
  }
  return NextResponse.json({
    property,
    roomTypes: roomTypes.filter((r) => r.propertyId === property.id),
    ratePlans: ratePlans.filter((rp) => rp.propertyId === property.id),
    experiences: experiences.filter((e) => e.propertyId === property.id),
  });
}
