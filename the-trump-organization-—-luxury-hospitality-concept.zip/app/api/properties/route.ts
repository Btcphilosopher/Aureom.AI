import { NextRequest, NextResponse } from "next/server";
import { listProperties } from "@/lib/server/store";

export async function GET(req: NextRequest) {
  const category = req.nextUrl.searchParams.get("category");
  const city = req.nextUrl.searchParams.get("city");
  const { properties, roomTypes, ratePlans, experiences, systemConfig } =
    await listProperties();

  const filtered = properties.filter((p) => {
    if (category && category !== "all" && p.category !== category) return false;
    if (
      city &&
      city !== "all" &&
      !p.city.toLowerCase().includes(city.toLowerCase()) &&
      !p.region.toLowerCase().includes(city.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return NextResponse.json({
    properties: filtered,
    roomTypes,
    ratePlans,
    experiences,
    systemConfig,
  });
}
