import { NextResponse } from "next/server";
import { runReconciliationSweep } from "@/lib/server/store";

export async function POST() {
  const summary = await runReconciliationSweep();
  return NextResponse.json({
    ok: true,
    sweptAt: new Date().toISOString(),
    ...summary,
  });
}
