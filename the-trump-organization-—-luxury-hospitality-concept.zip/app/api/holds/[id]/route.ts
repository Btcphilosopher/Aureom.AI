import { NextRequest, NextResponse } from "next/server";
import { getHoldById } from "@/lib/server/store";

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;
  const hold = await getHoldById(id);
  if (!hold) {
    return NextResponse.json({ error: "Hold not found." }, { status: 404 });
  }
  return NextResponse.json({ hold });
}
