import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createInventoryHold } from "@/lib/server/store";

const HoldSchema = z.object({
  propertyId: z.string().min(1),
  roomTypeId: z.string().min(1),
  ratePlanId: z.string().min(1),
  checkIn: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  checkOut: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  adults: z.number().int().min(1).max(24),
  children: z.number().int().min(0).max(24),
  roomCount: z.number().int().min(1).max(8),
  ttlSeconds: z.number().int().min(5).max(3600).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = HoldSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid hold request.", issues: parsed.error.flatten() },
        { status: 400 }
      );
    }
    const hold = await createInventoryHold(parsed.data);
    return NextResponse.json({ hold }, { status: 201 });
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Unable to place inventory hold.";
    const status = msg.toLowerCase().includes("insufficient") ? 409 : 400;
    return NextResponse.json({ error: msg }, { status });
  }
}
