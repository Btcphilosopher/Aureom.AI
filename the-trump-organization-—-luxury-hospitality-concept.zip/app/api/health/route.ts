import { NextResponse } from "next/server";
import { listProperties } from "@/lib/server/store";

export async function GET() {
  const { systemConfig, properties } = await listProperties();
  return NextResponse.json({
    ok: true,
    timestamp: new Date().toISOString(),
    propertyCount: properties.length,
    systemConfig,
  });
}
