import { NextRequest, NextResponse } from "next/server";
import { processWebhookEvent } from "@/lib/server/store";

export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-webhook-signature");
  const provider = req.headers.get("x-webhook-provider") || "usd_gateway";

  const result = await processWebhookEvent({
    rawBody,
    signatureHeader: signature,
    provider,
  });

  return NextResponse.json(
    {
      event: result.event,
      reservationStatus: result.reservation?.reservationStatus,
      paymentStatus: result.reservation?.paymentStatus,
    },
    { status: result.statusCode }
  );
}
