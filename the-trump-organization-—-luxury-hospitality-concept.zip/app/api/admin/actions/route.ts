import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { verifyBearerUser } from "@/lib/server/auth";
import {
  adminReconcileReservation,
  adminResolveRefund,
  getAdminRoleForUser,
  runReconciliationSweep,
  updateEnquiryStatus,
  updateInventoryUnitsOrRate,
} from "@/lib/server/store";

const AdminActionSchema = z.discriminatedUnion("actionType", [
  z.object({
    actionType: z.literal("resolve_refund"),
    refundId: z.string().min(1),
    decision: z.enum(["approve", "reject"]),
    walletVerified: z.boolean().optional(),
    adminNotes: z.string().max(500).optional(),
  }),
  z.object({
    actionType: z.literal("reconcile_reservation"),
    reservationId: z.string().min(1),
    decision: z.enum(["confirm_if_space", "mark_for_refund"]),
    notes: z.string().max(500).optional(),
  }),
  z.object({
    actionType: z.literal("update_inventory"),
    propertyId: z.string().min(1),
    roomTypeId: z.string().min(1),
    date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    totalUnits: z.number().int().min(0).max(100).optional(),
    overrideRateUsdCents: z.number().int().min(1000).max(5000000).optional(),
  }),
  z.object({
    actionType: z.literal("update_enquiry"),
    enquiryId: z.string().min(1),
    status: z.enum(["open", "in_review", "resolved"]),
  }),
  z.object({
    actionType: z.literal("run_sweep"),
  }),
]);

export async function POST(req: NextRequest) {
  try {
    const user = await verifyBearerUser(req.headers.get("authorization"));
    if (!user) {
      return NextResponse.json(
        { error: "Authentication required." },
        { status: 401 }
      );
    }

    const role = await getAdminRoleForUser(
      user.uid,
      user.email,
      user.email_verified
    );
    if (!role) {
      return NextResponse.json(
        { error: "Forbidden: administrative privileges required." },
        { status: 403 }
      );
    }

    const body = await req.json();
    const parsed = AdminActionSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid administrative action payload." },
        { status: 400 }
      );
    }

    const data = parsed.data;

    if (data.actionType === "resolve_refund") {
      if (role !== "super_admin" && role !== "finance_operator") {
        return NextResponse.json(
          { error: "Forbidden: finance_operator or super_admin role required." },
          { status: 403 }
        );
      }
      const refund = await adminResolveRefund({
        refundId: data.refundId,
        actorUid: user.email || user.uid,
        actorRole: role,
        decision: data.decision,
        walletVerified: data.walletVerified,
        adminNotes: data.adminNotes,
      });
      return NextResponse.json({ refund });
    }

    if (data.actionType === "reconcile_reservation") {
      const reservation = await adminReconcileReservation({
        reservationId: data.reservationId,
        actorUid: user.email || user.uid,
        actorRole: role,
        action: data.decision,
        notes: data.notes,
      });
      return NextResponse.json({
        reservation: { ...reservation, accessTokenHash: undefined },
      });
    }

    if (data.actionType === "update_inventory") {
      const inventory = await updateInventoryUnitsOrRate({
        propertyId: data.propertyId,
        roomTypeId: data.roomTypeId,
        date: data.date,
        totalUnits: data.totalUnits,
        overrideRateUsdCents: data.overrideRateUsdCents,
        actorUid: user.email || user.uid,
        actorRole: role,
      });
      return NextResponse.json({ inventory });
    }

    if (data.actionType === "update_enquiry") {
      const enquiry = await updateEnquiryStatus({
        enquiryId: data.enquiryId,
        status: data.status,
        actorUid: user.email || user.uid,
        actorRole: role,
      });
      return NextResponse.json({ enquiry });
    }

    const sweep = await runReconciliationSweep();
    return NextResponse.json({ sweep });
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Administrative action failed.";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
