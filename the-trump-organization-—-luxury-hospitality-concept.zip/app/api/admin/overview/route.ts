import { NextRequest, NextResponse } from "next/server";
import { verifyBearerUser } from "@/lib/server/auth";
import { getAdminOverview, getAdminRoleForUser } from "@/lib/server/store";

export async function GET(req: NextRequest) {
  const user = await verifyBearerUser(req.headers.get("authorization"));
  if (!user) {
    return NextResponse.json(
      { error: "Authentication required." },
      { status: 401 }
    );
  }

  const role = await getAdminRoleForUser(
    user.uid,
    user.email,
    user.email_verified
  );
  if (!role) {
    return NextResponse.json(
      { error: "Forbidden: verified administrative role required." },
      { status: 403 }
    );
  }

  const db = await getAdminOverview();

  // Strip accessTokenHash before sending to admin UI
  const reservations = Object.values(db.reservations)
    .map((r) => ({ ...r, accessTokenHash: undefined }))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  return NextResponse.json({
    role,
    adminEmail: user.email,
    systemConfig: db.systemConfig,
    properties: db.properties,
    roomTypes: db.roomTypes,
    ratePlans: db.ratePlans,
    nightlyInventory: Object.values(db.nightlyInventory).slice(0, 180),
    holds: Object.values(db.holds).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt)
    ),
    reservations,
    paymentAttempts: Object.values(db.paymentAttempts).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt)
    ),
    cryptoQuotes: Object.values(db.cryptoQuotes).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt)
    ),
    refunds: Object.values(db.refunds).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt)
    ),
    webhookEvents: Object.values(db.webhookEvents).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt)
    ),
    enquiries: Object.values(db.enquiries).sort((a, b) =>
      b.createdAt.localeCompare(a.createdAt)
    ),
    emailOutbox: db.emailOutbox,
    auditEvents: db.auditEvents,
  });
}
