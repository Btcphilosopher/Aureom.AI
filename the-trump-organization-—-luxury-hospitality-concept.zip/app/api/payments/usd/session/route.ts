import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createUsdPaymentSession } from "@/lib/server/store";

const UsdSessionSchema = z.object({
  reservationId: z.string().min(1),
  idempotencyKey: z.string().min(8).max(128),
  mode: z.enum(["demo", "live"]).default("demo"),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = UsdSessionSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid USD payment session request." },
        { status: 400 }
      );
    }

    const result = await createUsdPaymentSession(parsed.data);
    return NextResponse.json(result, {
      status: result.deduplicated ? 200 : 201,
    });
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Failed to create USD payment session.";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
