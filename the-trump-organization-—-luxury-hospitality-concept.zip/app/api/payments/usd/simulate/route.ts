import crypto from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { signWebhookPayload } from "@/lib/server/crypto-signing";
import { processWebhookEvent } from "@/lib/server/store";

const SimulateUsdWebhookSchema = z.object({
  reservationId: z.string().min(1),
  attemptId: z.string().min(1),
  outcome: z.enum([
    "payment.succeeded",
    "payment.failed",
    "duplicate_webhook",
    "invalid_signature",
  ]),
  externalEventId: z.string().optional(),
  failureReason: z.string().optional(),
});

/**
 * Demonstration-only endpoint that signs a simulated USD provider webhook
 * server-side and delivers it through the verified webhook processor.
 * Browser redirects alone NEVER confirm payment.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = SimulateUsdWebhookSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid simulation parameters." },
        { status: 400 }
      );
    }

    const eventType =
      parsed.data.outcome === "payment.failed"
        ? "payment.failed"
        : "payment.succeeded";

    const externalEventId =
      parsed.data.externalEventId ||
      `sim_evt_${crypto.randomBytes(8).toString("hex")}`;

    const rawBody = JSON.stringify({
      externalEventId,
      eventType,
      attemptId: parsed.data.attemptId,
      reservationId: parsed.data.reservationId,
      failureReason: parsed.data.failureReason,
    });

    const signature =
      parsed.data.outcome === "invalid_signature"
        ? "0".repeat(64)
        : signWebhookPayload(rawBody);

    const first = await processWebhookEvent({
      rawBody,
      signatureHeader: `sha256=${signature}`,
      provider: "usd_demo_gateway",
    });

    if (parsed.data.outcome === "duplicate_webhook") {
      const second = await processWebhookEvent({
        rawBody,
        signatureHeader: `sha256=${signature}`,
        provider: "usd_demo_gateway",
      });
      return NextResponse.json({
        first,
        second,
        reservation: second.reservation
          ? { ...second.reservation, accessTokenHash: undefined }
          : undefined,
      });
    }

    return NextResponse.json(
      {
        ...first,
        reservation: first.reservation
          ? { ...first.reservation, accessTokenHash: undefined }
          : undefined,
      },
      { status: first.statusCode }
    );
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Simulation failed.";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
