import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { observeCryptoPayment } from "@/lib/server/store";

const ObserveSchema = z.object({
  quoteId: z.string().min(1),
  observedNetwork: z.string().min(1),
  observedTokenIdentifier: z.string().min(1),
  observedBaseUnits: z.string().regex(/^\d+$/),
  txHash: z.string().min(8).max(200),
  confirmations: z.number().int().min(0).max(1000),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = ObserveSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid crypto observation payload." },
        { status: 400 }
      );
    }

    const result = await observeCryptoPayment({
      ...parsed.data,
      baseUrl: req.nextUrl.origin,
    });
    return NextResponse.json({
      quote: result.quote,
      attempt: result.attempt,
      reservation: {
        ...result.reservation,
        accessTokenHash: undefined,
      },
    });
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Crypto observation failed.";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
