import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { createCryptoQuote } from "@/lib/server/store";

const CryptoQuoteSchema = z.object({
  reservationId: z.string().min(1),
  assetId: z.string().min(1),
  network: z.string().min(1),
  tokenIdentifier: z.string().min(1),
  mode: z.enum(["demo", "live"]).default("demo"),
  quoteTtlSeconds: z.number().int().min(1).max(1800).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = CryptoQuoteSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid crypto quote request.", issues: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const result = await createCryptoQuote(parsed.data);
    return NextResponse.json(result, { status: 201 });
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Failed to create crypto quote.";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
