import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { lookupReservationWithEmail } from "@/lib/server/store";

const LookupSchema = z.object({
  confirmationCode: z.string().min(4).max(32),
  guestEmail: z.string().email().max(200),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = LookupSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          error:
            "Both a valid confirmation reference and matching guest email are required.",
        },
        { status: 400 }
      );
    }
    const result = await lookupReservationWithEmail(parsed.data);
    if (!result.found || !result.accessToken || !result.confirmationCode) {
      return NextResponse.json(
        { error: "No matching reservation was found for those credentials." },
        { status: 404 }
      );
    }
    return NextResponse.json({
      confirmationCode: result.confirmationCode,
      accessToken: result.accessToken,
      manageUrl: `/reservations/${result.confirmationCode}?token=${encodeURIComponent(result.accessToken)}`,
    });
  } catch {
    return NextResponse.json(
      { error: "Unable to verify booking credentials." },
      { status: 400 }
    );
  }
}
