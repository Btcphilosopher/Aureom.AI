import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { verifyBearerUser } from "@/lib/server/auth";
import {
  createReservationFromHold,
  listReservationsForUser,
} from "@/lib/server/store";

const CreateReservationSchema = z.object({
  holdId: z.string().min(1),
  guestName: z.string().min(2).max(160),
  guestEmail: z.string().email().max(200),
  guestPhone: z.string().min(5).max(40),
  guestCountry: z.string().max(100).optional(),
  specialRequests: z.string().max(1000).optional(),
  paymentMethod: z.enum(["usd_card", "trump_token", "usd1_stablecoin"]),
  acceptedPolicy: z.literal(true),
});

export async function GET(req: NextRequest) {
  const user = await verifyBearerUser(req.headers.get("authorization"));
  if (!user) {
    return NextResponse.json(
      { error: "Authentication required to list personal reservations." },
      { status: 401 }
    );
  }
  const reservations = await listReservationsForUser({
    uid: user.uid,
    email: user.email,
  });
  return NextResponse.json({ reservations });
}

export async function POST(req: NextRequest) {
  try {
    const user = await verifyBearerUser(req.headers.get("authorization"));
    const body = await req.json();
    const parsed = CreateReservationSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          error: "Please review your guest information and policy acceptance.",
          issues: parsed.error.flatten(),
        },
        { status: 400 }
      );
    }

    const origin = req.nextUrl.origin;
    const { reservation, accessToken, outboxEmail } =
      await createReservationFromHold({
        ...parsed.data,
        guestUid: user?.uid,
        baseUrl: origin,
      });

    return NextResponse.json(
      {
        reservation: {
          ...reservation,
          accessTokenHash: undefined,
        },
        accessToken,
        outboxEmail,
      },
      { status: 201 }
    );
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Failed to create reservation.";
    const status = msg.toLowerCase().includes("expired") ? 409 : 400;
    return NextResponse.json({ error: msg }, { status });
  }
}
