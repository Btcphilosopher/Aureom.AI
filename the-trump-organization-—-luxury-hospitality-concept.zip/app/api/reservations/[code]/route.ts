import { NextRequest, NextResponse } from "next/server";
import { verifyBearerUser } from "@/lib/server/auth";
import {
  getAdminRoleForUser,
  getReservationBundle,
} from "@/lib/server/store";

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ code: string }> }
) {
  const { code } = await context.params;
  const accessToken = req.nextUrl.searchParams.get("token");
  const user = await verifyBearerUser(req.headers.get("authorization"));
  const adminRole = user
    ? await getAdminRoleForUser(user.uid, user.email, user.email_verified)
    : null;

  const bundle = await getReservationBundle({
    confirmationCode: code,
    accessToken,
    userUid: user?.uid,
    userEmail: user?.email,
    isAdmin: Boolean(adminRole),
  });

  if (!bundle.authorized || !bundle.reservation) {
    return NextResponse.json(
      {
        error:
          "Access denied. A valid booking access link or authenticated guest account is required.",
      },
      { status: 403 }
    );
  }

  return NextResponse.json({
    ...bundle,
    reservation: {
      ...bundle.reservation,
      accessTokenHash: undefined,
    },
  });
}
