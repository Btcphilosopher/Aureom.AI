import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { verifyBearerUser } from "@/lib/server/auth";
import {
  getAdminRoleForUser,
  requestCancellationAndRefund,
} from "@/lib/server/store";

const CancelSchema = z.object({
  accessToken: z.string().optional(),
  reason: z.string().min(3).max(500),
  destinationWallet: z.string().max(200).optional(),
});

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ code: string }> }
) {
  try {
    const { code } = await context.params;
    const body = await req.json();
    const parsed = CancelSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Please provide a cancellation reason." },
        { status: 400 }
      );
    }

    const user = await verifyBearerUser(req.headers.get("authorization"));
    const adminRole = user
      ? await getAdminRoleForUser(user.uid, user.email, user.email_verified)
      : null;

    const result = await requestCancellationAndRefund({
      confirmationCode: code,
      accessToken:
        parsed.data.accessToken || req.nextUrl.searchParams.get("token"),
      userUid: user?.uid,
      userEmail: user?.email,
      isAdmin: Boolean(adminRole),
      reason: parsed.data.reason,
      destinationWallet: parsed.data.destinationWallet,
    });

    return NextResponse.json({
      reservation: {
        ...result.reservation,
        accessTokenHash: undefined,
      },
      refund: result.refund,
      explanation: result.explanation,
    });
  } catch (err) {
    const msg =
      err instanceof Error ? err.message : "Cancellation request failed.";
    const status = msg.toLowerCase().includes("unauthorized") ? 403 : 400;
    return NextResponse.json({ error: msg }, { status });
  }
}
