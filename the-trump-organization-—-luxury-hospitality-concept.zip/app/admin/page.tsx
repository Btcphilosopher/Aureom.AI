"use client";

import React, { useCallback, useEffect, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  LogIn,
  LogOut,
  RefreshCw,
  ShieldCheck,
} from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import { formatUsdCents } from "@/lib/crypto-assets";
import type {
  AuditEvent,
  CryptoQuote,
  EmailOutbox,
  Enquiry,
  NightlyInventory,
  PaymentAttempt,
  Property,
  RatePlan,
  Refund,
  Reservation,
  ReservationHold,
  RoomType,
  SystemIntegrationConfig,
  WebhookEvent,
} from "@/lib/types";

type AdminTab =
  | "health"
  | "inventory"
  | "reservations"
  | "exceptions"
  | "refunds"
  | "enquiries"
  | "audit";

interface AdminOverviewData {
  role: string;
  adminEmail: string;
  systemConfig: SystemIntegrationConfig;
  properties: Property[];
  roomTypes: RoomType[];
  ratePlans: RatePlan[];
  nightlyInventory: NightlyInventory[];
  holds: ReservationHold[];
  reservations: Reservation[];
  paymentAttempts: PaymentAttempt[];
  cryptoQuotes: CryptoQuote[];
  refunds: Refund[];
  webhookEvents: WebhookEvent[];
  enquiries: Enquiry[];
  emailOutbox: EmailOutbox[];
  auditEvents: AuditEvent[];
}

export default function AdminDashboardPage() {
  const { user, loading: authLoading, signInWithGoogle, signOut, getIdToken } =
    useAuth();

  const [tab, setTab] = useState<AdminTab>("health");
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionMsg, setActionMsg] = useState<string | null>(null);

  // Inventory Override Form
  const [invPropertyId, setInvPropertyId] = useState("prop-hudson-landmark");
  const [invRoomTypeId, setInvRoomTypeId] = useState("rt-hudson-deluxe");
  const [invDate, setInvDate] = useState(() =>
    new Date(Date.now() + 14 * 86_400_000).toISOString().slice(0, 10)
  );
  const [invUnits, setInvUnits] = useState(6);
  const [invRateUsd, setInvRateUsd] = useState("640");

  const loadOverview = useCallback(async () => {
    if (!user) return;
    await Promise.resolve();
    setLoading(true);
    setError(null);
    try {
      const token = await getIdToken();
      const res = await fetch("/api/admin/overview", {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || "Administrative access denied.");
        setData(null);
        return;
      }
      setData(json);
    } catch {
      setError("Failed to connect to administration API.");
    } finally {
      setLoading(false);
    }
  }, [user, getIdToken]);

  useEffect(() => {
    let active = true;
    (async () => {
      await Promise.resolve();
      if (!active) return;
      if (user) {
        await loadOverview();
      } else {
        setData(null);
      }
    })();
    return () => {
      active = false;
    };
  }, [user, loadOverview]);

  async function dispatchAdminAction(payload: Record<string, unknown>) {
    setActionMsg(null);
    const token = await getIdToken();
    const res = await fetch("/api/admin/actions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify(payload),
    });
    const json = await res.json();
    if (!res.ok) {
      setActionMsg(`Error: ${json.error || "Action rejected."}`);
      return;
    }
    setActionMsg("Administrative action persisted and recorded in audit log.");
    await loadOverview();
  }

  if (authLoading) {
    return (
      <div className="max-w-5xl mx-auto px-5 py-16 text-center text-sm text-[#575147]">
        Verifying session...
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-xl mx-auto px-5 py-20 text-center space-y-6">
        <ShieldCheck className="w-10 h-10 text-[#8A6B2F] mx-auto" aria-hidden="true" />
        <h1 className="font-serif text-4xl text-[#111111]">
          Demonstration Administration
        </h1>
        <p className="text-sm text-[#4A453C] leading-relaxed">
          All administrative routes enforce server-side Firebase Authentication
          and role-based access control. Sign in with an authorized Google
          account to manage inventory, payment exceptions, refunds, and audit
          history.
        </p>
        <button
          type="button"
          onClick={() => void signInWithGoogle()}
          className="inline-flex items-center gap-2.5 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-7 py-3.5 text-[11px] font-medium tracking-[0.2em] uppercase"
        >
          <LogIn className="w-4 h-4" aria-hidden="true" />
          <span>Sign In with Google</span>
        </button>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-xl mx-auto px-5 py-20 text-center space-y-5">
        <AlertTriangle className="w-10 h-10 text-[#8C2D19] mx-auto" aria-hidden="true" />
        <h1 className="font-serif text-3xl text-[#111111]">
          Administrative Role Required
        </h1>
        <p className="text-sm text-[#8C2D19] bg-[#FDF2F0] border border-[#E9C5BD] p-4">
          {error} (Signed in as {user.email})
        </p>
        <button
          type="button"
          onClick={() => void signOut()}
          className="inline-flex items-center gap-2 border border-[#D8D0C1] px-5 py-2.5 text-xs uppercase tracking-[0.16em]"
        >
          <LogOut className="w-4 h-4" aria-hidden="true" />
          <span>Sign Out</span>
        </button>
      </div>
    );
  }

  const tabs: { id: AdminTab; label: string }[] = [
    { id: "health", label: "Integration Health" },
    { id: "inventory", label: "Properties & Inventory" },
    { id: "reservations", label: "Reservations & Holds" },
    { id: "exceptions", label: "Exceptions & Webhooks" },
    { id: "refunds", label: "Refund Approvals" },
    { id: "enquiries", label: "Enquiries & Outbox" },
    { id: "audit", label: "Audit History" },
  ];

  const exceptionReservations =
    data?.reservations.filter(
      (r) =>
        r.reservationStatus === "reconciliation_required" ||
        r.paymentStatus === "reconciliation_required" ||
        r.paymentStatus === "underpaid" ||
        r.paymentStatus === "overpaid"
    ) || [];

  return (
    <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 py-10 space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#E2DACB] pb-6">
        <div>
          <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F] mb-2">
            Authenticated Portal &middot; Role: {data?.role || "verifying"}
          </p>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#111111]">
            Hospitality Operations &amp; Reconciliation
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          <span className="text-[#575147]">{user.email}</span>
          <button
            type="button"
            onClick={() => void loadOverview()}
            disabled={loading}
            className="inline-flex items-center gap-1.5 border border-[#D8D0C1] bg-white px-3.5 py-2 uppercase tracking-[0.14em] text-[10px]"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Refresh</span>
          </button>
          <button
            type="button"
            onClick={() => void signOut()}
            className="inline-flex items-center gap-1.5 border border-[#D8D0C1] bg-white px-3.5 py-2 uppercase tracking-[0.14em] text-[10px]"
          >
            <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Tab Bar */}
      <div className="flex flex-wrap gap-2 border-b border-[#E2DACB] pb-4">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 text-[11px] tracking-[0.16em] uppercase border transition-colors ${
              tab === t.id
                ? "bg-[#111111] text-[#FAF8F3] border-[#C5A25D]"
                : "bg-white text-[#3D3830] border-[#E2DACB] hover:border-[#C5A25D]"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {actionMsg && (
        <div className="border border-[#C5A25D] bg-white p-3.5 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-[#2B593F]" aria-hidden="true" />
          <span>{actionMsg}</span>
        </div>
      )}

      {!data ? (
        <div className="py-16 text-center text-sm text-[#575147]">
          Loading administration records...
        </div>
      ) : (
        <>
          {tab === "health" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white border border-[#E2DACB] p-5 space-y-1">
                  <p className="text-[10px] uppercase tracking-[0.18em] text-[#686054]">
                    Live USD Checkout Adapter
                  </p>
                  <p className="font-mono text-base font-semibold">
                    {data.systemConfig.liveUsdEnabled
                      ? "ENABLED"
                      : "DISABLED (Demo Sandbox Active)"}
                  </p>
                </div>
                <div className="bg-white border border-[#E2DACB] p-5 space-y-1">
                  <p className="text-[10px] uppercase tracking-[0.18em] text-[#686054]">
                    Live Crypto Settlement Adapter
                  </p>
                  <p className="font-mono text-base font-semibold">
                    {data.systemConfig.liveCryptoEnabled
                      ? "ENABLED"
                      : "DISABLED (Simulation Adapter Active)"}
                  </p>
                </div>
                <div className="bg-white border border-[#E2DACB] p-5 space-y-1">
                  <p className="text-[10px] uppercase tracking-[0.18em] text-[#686054]">
                    Email &amp; Concierge Integrations
                  </p>
                  <p className="font-mono text-xs font-semibold">
                    Email: {data.systemConfig.emailAdapterMode} &middot; AI:{" "}
                    {data.systemConfig.geminiConciergeMode}
                  </p>
                </div>
              </div>

              <div className="bg-white border border-[#E2DACB] p-6 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="font-serif text-2xl text-[#111111]">
                    Background Hold &amp; Quote Expiry Sweep
                  </h2>
                  <p className="text-xs text-[#575147] mt-1">
                    Releases expired 15-minute inventory holds back to nightly
                    availability and marks stale crypto quotes expired.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    void dispatchAdminAction({ actionType: "run_sweep" })
                  }
                  className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-5 py-2.5 text-[11px] tracking-[0.18em] uppercase"
                >
                  Run Sweep Now
                </button>
              </div>
            </div>
          )}

          {tab === "inventory" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void dispatchAdminAction({
                    actionType: "update_inventory",
                    propertyId: invPropertyId,
                    roomTypeId: invRoomTypeId,
                    date: invDate,
                    totalUnits: invUnits,
                    overrideRateUsdCents: Math.round(
                      (Number(invRateUsd) || 640) * 100
                    ),
                  });
                }}
                className="lg:col-span-4 bg-white border border-[#E2DACB] p-6 space-y-4 h-fit"
              >
                <h2 className="font-serif text-2xl text-[#111111]">
                  Adjust Nightly Inventory &amp; Rate
                </h2>
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1">
                    Property
                  </label>
                  <select
                    value={invPropertyId}
                    onChange={(e) => {
                      setInvPropertyId(e.target.value);
                      const firstRoom = data.roomTypes.find(
                        (r) => r.propertyId === e.target.value
                      );
                      if (firstRoom) setInvRoomTypeId(firstRoom.id);
                    }}
                    className="w-full border border-[#D8D0C1] px-3 py-2 text-xs"
                  >
                    {data.properties.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1">
                    Room Type
                  </label>
                  <select
                    value={invRoomTypeId}
                    onChange={(e) => setInvRoomTypeId(e.target.value)}
                    className="w-full border border-[#D8D0C1] px-3 py-2 text-xs"
                  >
                    {data.roomTypes
                      .filter((r) => r.propertyId === invPropertyId)
                      .map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name}
                        </option>
                      ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1">
                      Night Date
                    </label>
                    <input
                      type="date"
                      value={invDate}
                      onChange={(e) => setInvDate(e.target.value)}
                      className="w-full border border-[#D8D0C1] px-2.5 py-2 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1">
                      Total Units
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={invUnits}
                      onChange={(e) => setInvUnits(Number(e.target.value) || 0)}
                      className="w-full border border-[#D8D0C1] px-2.5 py-2 text-xs font-mono"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1">
                    Nightly Rate Override (USD)
                  </label>
                  <input
                    type="number"
                    min={50}
                    value={invRateUsd}
                    onChange={(e) => setInvRateUsd(e.target.value)}
                    className="w-full border border-[#D8D0C1] px-3 py-2 text-xs font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-2.5 text-[11px] tracking-[0.18em] uppercase"
                >
                  Save Nightly Allocation
                </button>
              </form>

              <div className="lg:col-span-8 bg-white border border-[#E2DACB] p-6 space-y-4">
                <h2 className="font-serif text-2xl text-[#111111]">
                  Property &amp; Room Catalog ({data.properties.length} properties,{" "}
                  {data.roomTypes.length} room types)
                </h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="border-b border-[#E2DACB] text-[10px] uppercase tracking-[0.14em] text-[#686054]">
                      <tr>
                        <th className="py-2 pr-4">Property</th>
                        <th className="py-2 pr-4">Category</th>
                        <th className="py-2 pr-4">City</th>
                        <th className="py-2">Starting Rate</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#EBE4D6]">
                      {data.properties.map((p) => (
                        <tr key={p.id}>
                          <td className="py-2.5 pr-4 font-medium">{p.name}</td>
                          <td className="py-2.5 pr-4 font-mono">{p.category}</td>
                          <td className="py-2.5 pr-4">{p.city}</td>
                          <td className="py-2.5 font-mono tabular-nums">
                            {formatUsdCents(p.startingRateUsdCents)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {tab === "reservations" && (
            <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
              <h2 className="font-serif text-2xl text-[#111111]">
                All Persistent Reservations ({data.reservations.length})
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="border-b border-[#E2DACB] text-[10px] uppercase tracking-[0.14em] text-[#686054]">
                    <tr>
                      <th className="py-2 pr-4">Reference</th>
                      <th className="py-2 pr-4">Property</th>
                      <th className="py-2 pr-4">Guest</th>
                      <th className="py-2 pr-4">Dates</th>
                      <th className="py-2 pr-4">Booking / Pay / Fulfill</th>
                      <th className="py-2">Total USD</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EBE4D6]">
                    {data.reservations.map((r) => (
                      <tr key={r.id}>
                        <td className="py-2.5 pr-4 font-mono font-semibold">
                          {r.confirmationCode}
                        </td>
                        <td className="py-2.5 pr-4">{r.propertyName}</td>
                        <td className="py-2.5 pr-4">{r.guestEmail}</td>
                        <td className="py-2.5 pr-4 font-mono">
                          {r.checkIn} &rarr; {r.checkOut}
                        </td>
                        <td className="py-2.5 pr-4 font-mono">
                          {r.reservationStatus} / {r.paymentStatus} /{" "}
                          {r.fulfillmentStatus}
                        </td>
                        <td className="py-2.5 font-mono tabular-nums">
                          {formatUsdCents(r.totalUsdCents)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === "exceptions" && (
            <div className="space-y-6">
              <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
                <h2 className="font-serif text-2xl text-[#111111]">
                  Payment &amp; Late-Hold Exceptions ({exceptionReservations.length})
                </h2>
                {exceptionReservations.length === 0 ? (
                  <p className="text-xs text-[#575147]">
                    No unresolved payment exceptions.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {exceptionReservations.map((r) => (
                      <div
                        key={r.id}
                        className="border border-[#C5A25D] bg-[#FAF8F3] p-4 flex flex-wrap items-center justify-between gap-4 text-xs"
                      >
                        <div>
                          <p className="font-mono font-semibold">
                            {r.confirmationCode} &mdash; {r.reservationStatus} /{" "}
                            {r.paymentStatus}
                          </p>
                          <p className="text-[#575147]">
                            {r.propertyName} ({r.checkIn} to {r.checkOut}) &middot;{" "}
                            {formatUsdCents(r.totalUsdCents)}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              void dispatchAdminAction({
                                actionType: "reconcile_reservation",
                                reservationId: r.id,
                                decision: "confirm_if_space",
                              })
                            }
                            className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-3.5 py-2 text-[10px] uppercase tracking-[0.14em]"
                          >
                            Confirm if Space Available
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              void dispatchAdminAction({
                                actionType: "reconcile_reservation",
                                reservationId: r.id,
                                decision: "mark_for_refund",
                              })
                            }
                            className="border border-[#8C2D19] text-[#8C2D19] px-3.5 py-2 text-[10px] uppercase tracking-[0.14em]"
                          >
                            Resolve via Refund
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
                <h2 className="font-serif text-2xl text-[#111111]">
                  Inbound Webhook Verification Log ({data.webhookEvents.length})
                </h2>
                <div className="space-y-2 text-xs font-mono">
                  {data.webhookEvents.slice(0, 20).map((w) => (
                    <div
                      key={w.id}
                      className="border border-[#EBE4D6] p-3 flex flex-wrap justify-between gap-2"
                    >
                      <span>
                        [{w.status}] {w.provider} &middot; {w.eventType} &middot;{" "}
                        {w.payloadSummary}
                      </span>
                      <span className="text-[#686054]">{w.createdAt}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab === "refunds" && (
            <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
              <h2 className="font-serif text-2xl text-[#111111]">
                Refund Approvals ({data.refunds.length})
              </h2>
              {data.refunds.length === 0 ? (
                <p className="text-xs text-[#575147]">No refund records.</p>
              ) : (
                <div className="space-y-3">
                  {data.refunds.map((rf) => (
                    <div
                      key={rf.id}
                      className="border border-[#E2DACB] bg-[#FAF8F3] p-4 flex flex-wrap items-center justify-between gap-4 text-xs"
                    >
                      <div className="space-y-1 font-mono">
                        <p className="font-semibold">
                          {rf.confirmationCode} &middot; Status:{" "}
                          <span className="uppercase">{rf.status}</span>
                        </p>
                        <p>
                          Net USD Refund: {formatUsdCents(rf.netUsdRefundCents)} (
                          Method: {rf.refundMethod})
                        </p>
                        {rf.displayTokenAmount && (
                          <p className="text-[#8A6B2F]">
                            Crypto Basis: {rf.displayTokenAmount}{" "}
                            {rf.tokenTicker} &middot; Destination:{" "}
                            {rf.destinationWallet || "Not provided"}
                          </p>
                        )}
                      </div>
                      {rf.status === "requested" && (
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() =>
                              void dispatchAdminAction({
                                actionType: "resolve_refund",
                                refundId: rf.id,
                                decision: "approve",
                                walletVerified: true,
                              })
                            }
                            className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-4 py-2 text-[10px] uppercase tracking-[0.14em]"
                          >
                            Verify Destination &amp; Approve
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              void dispatchAdminAction({
                                actionType: "resolve_refund",
                                refundId: rf.id,
                                decision: "reject",
                              })
                            }
                            className="border border-[#8C2D19] text-[#8C2D19] px-4 py-2 text-[10px] uppercase tracking-[0.14em]"
                          >
                            Reject
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {tab === "enquiries" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
                <h2 className="font-serif text-2xl text-[#111111]">
                  Guest Enquiries ({data.enquiries.length})
                </h2>
                {data.enquiries.map((enq) => (
                  <div
                    key={enq.id}
                    className="border border-[#EBE4D6] p-4 text-xs space-y-2"
                  >
                    <div className="flex justify-between font-mono">
                      <span className="font-semibold">{enq.subject}</span>
                      <span className="uppercase">{enq.status}</span>
                    </div>
                    <p className="text-[#575147]">
                      From: {enq.guestName} ({enq.guestEmail})
                    </p>
                    <p>{enq.message}</p>
                    <div className="flex gap-2 pt-1">
                      {(["open", "in_review", "resolved"] as const).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() =>
                            void dispatchAdminAction({
                              actionType: "update_enquiry",
                              enquiryId: enq.id,
                              status: st,
                            })
                          }
                          className="border border-[#D8D0C1] px-2.5 py-1 text-[10px] uppercase"
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
                <h2 className="font-serif text-2xl text-[#111111]">
                  Confirmation Email Outbox ({data.emailOutbox.length})
                </h2>
                {data.emailOutbox.slice(0, 12).map((em) => (
                  <div
                    key={em.id}
                    className="border border-[#EBE4D6] p-3 text-xs space-y-1"
                  >
                    <div className="flex justify-between font-mono text-[11px]">
                      <span>{em.to}</span>
                      <span className="uppercase text-[#8A6B2F]">
                        {em.status}
                      </span>
                    </div>
                    <p className="font-medium">{em.subject}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "audit" && (
            <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
              <h2 className="font-serif text-2xl text-[#111111]">
                Immutable Audit Log ({data.auditEvents.length})
              </h2>
              <div className="space-y-2 text-xs font-mono">
                {data.auditEvents.map((ev) => (
                  <div
                    key={ev.id}
                    className="border border-[#EBE4D6] p-3 flex flex-wrap justify-between gap-2"
                  >
                    <span>
                      <strong>{ev.action}</strong> &middot; {ev.actorUid} (
                      {ev.actorRole}) &middot; {ev.details}
                    </span>
                    <span className="text-[#686054]">{ev.createdAt}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
