import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy & Booking Terms — The Trump Organization Concept",
  description:
    "Published demonstration reservation terms, cancellation policies, privacy protections, and digital asset checkout disclosures.",
};

export default function TermsPage() {
  return (
    <div className="max-w-4xl mx-auto px-5 sm:px-8 py-12 sm:py-16 space-y-10 text-[#111111]">
      <div className="border-b border-[#E2DACB] pb-6">
        <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F] mb-3">
          Governance &amp; Disclosures
        </p>
        <h1 className="font-serif text-4xl sm:text-5xl">
          Privacy &amp; Booking Terms
        </h1>
      </div>

      <section className="space-y-3">
        <h2 className="font-serif text-2xl">
          1. Independent Design Concept Disclosure
        </h2>
        <p className="text-sm text-[#4A453C] leading-relaxed">
          This web application is an independent hospitality and reservation
          architecture concept. All properties, room allocations, tariffs, and
          experiences are fictional demonstration inventory. Proposed checkout
          options—including $TRUMP Token and USD1 Stablecoin—are simulated and
          must not be construed as confirmed merchant acceptance by the real
          organization.
        </p>
      </section>

      <section className="space-y-3">
        <h2 className="font-serif text-2xl">
          2. Server-Calculated Rates &amp; Atomic Holds
        </h2>
        <p className="text-sm text-[#4A453C] leading-relaxed">
          Displayed starting rates on collection cards reflect illustrative
          base tariffs before nightly adjustments, resort fees, and local
          occupancy taxes. When dates and guest occupancy are submitted, total
          USD pricing is computed strictly on the server. Selecting an offer
          places a 15-minute atomic inventory hold; if a hold expires prior to
          verified payment settlement, any late payment enters a manual
          reconciliation workflow rather than silently overbooking inventory.
        </p>
      </section>

      <section className="space-y-3">
        <h2 className="font-serif text-2xl">
          3. USD &amp; Proposed Digital Asset Settlement
        </h2>
        <p className="text-sm text-[#4A453C] leading-relaxed">
          All bookings remain denominated in US Dollars (USD). Live USD and
          live cryptocurrency adapters remain disabled by default until server
          secrets, allowlisted network identifiers, token contract metadata,
          and custody endpoints are explicitly validated. In demonstration mode,
          no real payment card details are collected and no live blockchain
          transfers should be sent. Proposed crypto quotes convert USD totals
          using exact base-unit arithmetic, lock a rate source and timestamp for
          5 minutes, and do not assume stablecoin 1:1 USD parity.
        </p>
      </section>

      <section className="space-y-3">
        <h2 className="font-serif text-2xl">
          4. Cancellation Policy Versions &amp; Refunds
        </h2>
        <p className="text-sm text-[#4A453C] leading-relaxed">
          The rate plan and cancellation policy version accepted at checkout
          (e.g., POLICY-V2026.1-FLEX48, FLEX24, or NONREF) are preserved
          immutably on each reservation. Refund entitlements are calculated in
          USD first; where a reservation was settled via simulated crypto,
          token refund quantities are derived at an explicit conversion
          timestamp and require destination wallet verification and
          administrative approval.
        </p>
      </section>

      <section className="space-y-3">
        <h2 className="font-serif text-2xl">
          5. Privacy &amp; Booking Access Security
        </h2>
        <p className="text-sm text-[#4A453C] leading-relaxed">
          Reservations are never accessible through predictable confirmation
          numbers alone. Access requires either a cryptographically signed
          access link or matching confirmation reference and verified guest
          email / authenticated account.
        </p>
      </section>
    </div>
  );
}
