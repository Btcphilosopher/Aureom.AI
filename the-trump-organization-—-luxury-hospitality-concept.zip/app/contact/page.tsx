"use client";

import React, { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { CheckCircle2 } from "lucide-react";

function ContactFormInner() {
  const sp = useSearchParams();
  const [guestName, setGuestName] = useState("");
  const [guestEmail, setGuestEmail] = useState("");
  const [subject, setSubject] = useState(sp.get("subject") || "");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sentId, setSentId] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ guestName, guestEmail, subject, message }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Unable to send enquiry.");
        return;
      }
      setSentId(data.enquiry.id);
      setGuestName("");
      setGuestEmail("");
      setSubject("");
      setMessage("");
    } catch {
      setError("Network error while submitting enquiry.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-5 sm:px-8 py-12 sm:py-16 space-y-8">
      <div>
        <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F] mb-3">
          Private Client Services
        </p>
        <h1 className="font-serif text-4xl sm:text-5xl text-[#111111]">
          Contact &amp; Inquiries
        </h1>
        <p className="mt-3 text-sm text-[#4A453C] leading-relaxed">
          Reach our demonstration hospitality desk for extended residential
          stays, championship golf coordination, or reservation assistance.
        </p>
      </div>

      {sentId ? (
        <div className="bg-white border border-[#C5A25D] p-8 space-y-4">
          <div className="flex items-center gap-2.5 text-[#2B593F]">
            <CheckCircle2 className="w-5 h-5" aria-hidden="true" />
            <h2 className="font-serif text-2xl text-[#111111]">
              Enquiry Recorded
            </h2>
          </div>
          <p className="text-sm text-[#4A453C]">
            Reference <span className="font-mono">{sentId}</span> has been
            logged for review in the demonstration administration queue.
          </p>
          <button
            type="button"
            onClick={() => setSentId(null)}
            className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-6 py-3 text-[11px] tracking-[0.18em] uppercase"
          >
            Submit Another Enquiry
          </button>
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="bg-white border border-[#E2DACB] p-7 sm:p-8 space-y-5"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="contact-name"
                className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
              >
                Full Name *
              </label>
              <input
                id="contact-name"
                type="text"
                required
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
              />
            </div>
            <div>
              <label
                htmlFor="contact-email"
                className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
              >
                Email Address *
              </label>
              <input
                id="contact-email"
                type="email"
                required
                value={guestEmail}
                onChange={(e) => setGuestEmail(e.target.value)}
                className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="contact-subject"
              className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
            >
              Subject *
            </label>
            <input
              id="contact-subject"
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
            />
          </div>

          <div>
            <label
              htmlFor="contact-message"
              className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
            >
              Message *
            </label>
            <textarea
              id="contact-message"
              rows={5}
              required
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
            />
          </div>

          {error && (
            <p role="alert" className="text-xs text-[#8C2D19]">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-7 py-3.5 text-[11px] font-medium tracking-[0.2em] uppercase"
          >
            {submitting ? "Sending..." : "Submit Enquiry"}
          </button>
        </form>
      )}
    </div>
  );
}

export default function ContactPage() {
  return (
    <Suspense fallback={<div className="py-16 text-center text-sm">Loading...</div>}>
      <ContactFormInner />
    </Suspense>
  );
}
