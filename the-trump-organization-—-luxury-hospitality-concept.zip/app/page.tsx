import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { listProperties } from "@/lib/server/store";
import { ReservationWidget } from "@/components/ReservationWidget";
import { formatUsdCents } from "@/lib/crypto-assets";

export const dynamic = "force-dynamic";

const COLLECTION_CARDS = [
  {
    title: "City Landmarks",
    href: "/properties?category=city_landmark",
    image: "/images/city-landmark.jpg",
    alt: "Limestone city landmark hotel entrance at dusk with bronze marquee canopy",
  },
  {
    title: "Coastal Retreats",
    href: "/properties?category=coastal_retreat",
    image: "/images/coastal-retreat.jpg",
    alt: "Mediterranean coastal cliffside resort villa with infinity pool overlooking the ocean",
  },
  {
    title: "Championship Golf",
    href: "/properties?category=championship_golf",
    image: "/images/championship-golf.jpg",
    alt: "Championship oceanfront links golf course at golden hour",
  },
];

export default async function HomePage() {
  const { properties, experiences } = await listProperties();

  return (
    <div className="bg-[#FAF8F3]">
      {/* Full-Width Photographic Hero */}
      <section className="relative min-h-[620px] lg:min-h-[680px] flex items-center overflow-hidden bg-[#1D1B18]">
        <Image
          src="/images/hero-waterfront.jpg"
          alt="Waterfront luxury hotel terrace with infinity pool and New York City skyline at golden sunset"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
          referrerPolicy="no-referrer"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/40 to-black/15"
        />

        <div className="relative z-10 w-full max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 py-12 lg:py-16 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* Left Editorial Statement */}
          <div className="lg:col-span-7 text-[#FAF8F3]">
            <p className="text-[11px] sm:text-xs font-medium tracking-[0.26em] uppercase text-[#E2C27D] mb-4">
              Exceptional Places. Distinctive Experiences.
            </p>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-[68px] leading-[1.03] font-normal text-balance max-w-xl">
              An extraordinary world awaits.
            </h1>
            <p className="mt-6 text-base sm:text-lg text-[#FAF8F3]/90 max-w-md leading-relaxed">
              Discover landmark properties, remarkable stays and private
              experiences.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Link
                href="/properties"
                className="inline-flex items-center gap-3 bg-[#FAF8F3] text-[#111111] px-7 py-4 text-[11px] font-medium tracking-[0.2em] uppercase hover:bg-white transition-colors"
              >
                <span>Explore Our Collection</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
              <Link
                href="/manage"
                className="inline-flex items-center gap-2 border border-[#FAF8F3]/60 text-[#FAF8F3] px-6 py-4 text-[11px] font-medium tracking-[0.2em] uppercase hover:bg-white/10 transition-colors"
              >
                <span>Manage Booking</span>
              </Link>
            </div>
          </div>

          {/* Right Reservation Panel */}
          <div className="lg:col-span-5 flex lg:justify-end">
            <ReservationWidget properties={properties} />
          </div>
        </div>
      </section>

      {/* Collection Pillars */}
      <section className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 py-14 sm:py-20">
        <h2 className="font-serif text-3xl sm:text-4xl lg:text-[44px] text-center text-[#111111] mb-10 sm:mb-12 text-balance">
          A collection without compromise.
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {COLLECTION_CARDS.map((card) => (
            <Link
              key={card.title}
              href={card.href}
              className="group relative aspect-[4/3] overflow-hidden bg-[#221F1B] block"
            >
              <Image
                src={card.image}
                alt={card.alt}
                fill
                sizes="(max-width: 768px) 100vw, 33vw"
                className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                referrerPolicy="no-referrer"
              />
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent"
              />
              <div className="absolute inset-x-0 bottom-0 p-6 text-center">
                <h3 className="font-serif text-base sm:text-lg tracking-[0.24em] uppercase text-[#FAF8F3]">
                  {card.title}
                </h3>
                <div className="w-14 h-[1.5px] bg-[#C5A25D] mx-auto mt-2.5 transition-all duration-300 group-hover:w-20" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Residences & Private Experiences */}
      <section className="border-t border-[#E5DFD2] bg-[#F4EFE4]/60">
        <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 py-16 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-5 space-y-5">
            <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F]">
              Private Residences &amp; Curated Experiences
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#111111] leading-tight text-balance">
              Tailored residences, championship links, and private coastal access.
            </h2>
            <p className="text-sm text-[#4A453C] leading-relaxed">
              Every stay in this demonstration collection is backed by server-side
              rate calculation, 15-minute atomic inventory holds, and transparent
              USD or proposed digital asset checkout flows.
            </p>
            <div className="pt-2 flex flex-wrap gap-4">
              <Link
                href="/experiences"
                className="inline-flex items-center gap-2.5 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-6 py-3.5 text-[11px] font-medium tracking-[0.2em] uppercase hover:bg-[#1E1E1E] transition-colors"
              >
                <span>View Golf &amp; Experiences</span>
                <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
              </Link>
              <Link
                href="/terms"
                className="inline-flex items-center px-5 py-3.5 border border-[#D4CBB8] text-[11px] font-medium tracking-[0.2em] uppercase text-[#111111] hover:border-[#C5A25D] transition-colors"
              >
                <span>Booking Terms</span>
              </Link>
            </div>
          </div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {experiences.slice(0, 2).map((exp, idx) => (
              <Link
                key={exp.id}
                href="/experiences"
                className="group bg-[#FAF8F3] border border-[#E2DACB] overflow-hidden flex flex-col"
              >
                <div className="relative aspect-[4/3] bg-[#221F1B]">
                  <Image
                    src={exp.imageUrl}
                    alt={exp.title}
                    fill
                    sizes="(max-width: 640px) 100vw, 35vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-[10px] tracking-[0.2em] uppercase text-[#8A6B2F] mb-2">
                      0{idx + 1}. {exp.propertyName}
                    </p>
                    <h3 className="font-serif text-xl text-[#111111] mb-2">
                      {exp.title}
                    </h3>
                    <p className="text-xs text-[#575147] leading-relaxed">
                      {exp.subtitle}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-[#EBE4D6] flex items-center justify-between text-xs">
                    <span className="text-[#686054]">{exp.duration}</span>
                    <span className="font-mono tabular-nums font-medium text-[#111111]">
                      From {formatUsdCents(exp.startingPriceUsdCents)} USD
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
