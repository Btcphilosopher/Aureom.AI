"use client";

import React, { Suspense, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Clock,
  Lock,
  ShieldAlert,
} from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import {
  CRYPTO_ASSET_ALLOWLIST,
  formatUsdCents,
  getAllowlistedAssetsForMethod,
} from "@/lib/crypto-assets";
import type {
  CryptoQuote,
  PaymentAttempt,
  PaymentMethod,
  Reservation,
  ReservationHold,
} from "@/lib/types";

function formatCountdown(targetIso: string, nowMs: number): string {
  const diff = Math.max(0, new Date(targetIso).getTime() - nowMs);
  const totalSec = Math.floor(diff / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

function ReserveCheckoutInner() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { user, getIdToken } = useAuth();

  const holdId = searchParams.get("holdId") || "";
  const initialPayment = (searchParams.get("payment") as PaymentMethod) || "usd_card";

  const [hold, setHold] = useState<ReservationHold | null>(null);
  const [loadingHold, setLoadingHold] = useState(true);
  const [holdError, setHoldError] = useState<string | null>(null);
  const [nowMs, setNowMs] = useState(() => Date.now());

  // Guest & Policy Form (null tracks untouched user input so Firebase user defaults apply without effect sync)
  const [guestNameInput, setGuestNameInput] = useState<string | null>(null);
  const [guestEmailInput, setGuestEmailInput] = useState<string | null>(null);
  const guestName = guestNameInput ?? user?.displayName ?? "";
  const guestEmail = guestEmailInput ?? user?.email ?? "";
  const [guestPhone, setGuestPhone] = useState("");
  const [guestCountry, setGuestCountry] = useState("United States");
  const [specialRequests, setSpecialRequests] = useState("");
  const [acceptedPolicy, setAcceptedPolicy] = useState(false);
  const [paymentMethod, setPaymentMethod] =
    useState<PaymentMethod>(initialPayment);

  // Created Reservation + Token
  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [creatingRes, setCreatingRes] = useState(false);
  const [resError, setResError] = useState<string | null>(null);

  // Payment States
  const [usdAttempt, setUsdAttempt] = useState<PaymentAttempt | null>(null);
  const [selectedAssetId, setSelectedAssetId] = useState<string>(
    initialPayment === "usd1_stablecoin"
      ? "usd1-eth-erc20-sim"
      : "trump-solana-spl-sim"
  );
  const effectiveAssetId =
    paymentMethod === "trump_token"
      ? "trump-solana-spl-sim"
      : selectedAssetId.startsWith("usd1-")
        ? selectedAssetId
        : "usd1-eth-erc20-sim";
  const [cryptoQuote, setCryptoQuote] = useState<CryptoQuote | null>(null);
  const [cryptoAttempt, setCryptoAttempt] = useState<PaymentAttempt | null>(null);
  const [paymentFeedback, setPaymentFeedback] = useState<string | null>(null);
  const [paymentBusy, setPaymentBusy] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    let active = true;
    const load = async () => {
      await Promise.resolve();
      if (!active) return;
      if (!holdId) {
        setLoadingHold(false);
        setHoldError(
          "No active inventory hold selected. Please choose a room first."
        );
        return;
      }
      setLoadingHold(true);
      try {
        const res = await fetch(`/api/holds/${encodeURIComponent(holdId)}`);
        const data = await res.json();
        if (!active) return;
        if (!res.ok) {
          setHoldError(data.error || "Inventory hold not found.");
        } else {
          setHold(data.hold);
        }
      } catch {
        if (active) setHoldError("Unable to load inventory hold.");
      } finally {
        if (active) setLoadingHold(false);
      }
    };
    void load();
    return () => {
      active = false;
    };
  }, [holdId]);

  const cryptoAssetsForMethod = useMemo(() => {
    if (paymentMethod === "usd_card") return [];
    return getAllowlistedAssetsForMethod(paymentMethod);
  }, [paymentMethod]);

  const holdExpired =
    !hold ||
    hold.status !== "active" ||
    new Date(hold.expiresAt).getTime() <= nowMs;

  async function handleCreateReservation(e: React.FormEvent) {
    e.preventDefault();
    if (!hold) return;
    setCreatingRes(true);
    setResError(null);
    try {
      const idToken = await getIdToken();
      const res = await fetch("/api/reservations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
        },
        body: JSON.stringify({
          holdId: hold.id,
          guestName,
          guestEmail,
          guestPhone,
          guestCountry,
          specialRequests,
          paymentMethod,
          acceptedPolicy,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setResError(data.error || "Could not create reservation.");
        return;
      }
      setReservation(data.reservation);
      setAccessToken(data.accessToken);

      // Save tokenized link locally for convenient session access in /manage
      try {
        const prev = JSON.parse(
          sessionStorage.getItem("demo_recent_bookings") || "[]"
        );
        const entry = {
          confirmationCode: data.reservation.confirmationCode,
          propertyName: data.reservation.propertyName,
          accessToken: data.accessToken,
          createdAt: data.reservation.createdAt,
        };
        sessionStorage.setItem(
          "demo_recent_bookings",
          JSON.stringify([entry, ...prev].slice(0, 10))
        );
      } catch {
        // Ignore sessionStorage restrictions
      }
    } catch {
      setResError("Network error while creating reservation.");
    } finally {
      setCreatingRes(false);
    }
  }

  async function handleStartUsdSession() {
    if (!reservation) return;
    setPaymentBusy(true);
    setPaymentFeedback(null);
    try {
      const res = await fetch("/api/payments/usd/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reservationId: reservation.id,
          idempotencyKey: `usd-${reservation.id}-v1`,
          mode: "demo",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPaymentFeedback(data.error || "Failed to initiate USD sandbox session.");
        return;
      }
      setUsdAttempt(data.attempt);
      setPaymentFeedback(
        data.deduplicated
          ? "Idempotent session reused without duplicate attempt."
          : "Demonstration USD checkout session created. Trigger a simulated provider webhook below to complete or test failures."
      );
    } finally {
      setPaymentBusy(false);
    }
  }

  async function handleSimulateUsdOutcome(
    outcome:
      | "payment.succeeded"
      | "payment.failed"
      | "duplicate_webhook"
      | "invalid_signature"
  ) {
    if (!reservation || !usdAttempt) return;
    setPaymentBusy(true);
    setPaymentFeedback(null);
    try {
      const res = await fetch("/api/payments/usd/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reservationId: reservation.id,
          attemptId: usdAttempt.id,
          outcome,
        }),
      });
      const data = await res.json();
      if (data.reservation) {
        setReservation(data.reservation);
      }
      if (outcome === "invalid_signature") {
        setPaymentFeedback(
          `Webhook rejected (HTTP ${res.status}): invalid HMAC signature logged.`
        );
      } else if (outcome === "duplicate_webhook") {
        setPaymentFeedback(
          `First webhook processed (${data.first?.event?.status}); duplicate event ignored idempotently (${data.second?.event?.status}).`
        );
      } else if (outcome === "payment.failed") {
        setPaymentFeedback(
          "Simulated provider decline webhook processed. Reservation remains pending payment."
        );
      } else {
        setPaymentFeedback(
          `Verified webhook confirmed booking (${data.reservation?.reservationStatus} / ${data.reservation?.paymentStatus}).`
        );
      }
    } finally {
      setPaymentBusy(false);
    }
  }

  async function handleRequestCryptoQuote(shortTtlSeconds?: number) {
    if (!reservation) return;
    const asset = CRYPTO_ASSET_ALLOWLIST[effectiveAssetId];
    if (!asset) return;
    setPaymentBusy(true);
    setPaymentFeedback(null);
    try {
      const res = await fetch("/api/payments/crypto/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reservationId: reservation.id,
          assetId: asset.assetId,
          network: asset.network,
          tokenIdentifier: asset.tokenIdentifier,
          mode: "demo",
          quoteTtlSeconds: shortTtlSeconds,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPaymentFeedback(data.error || "Unable to generate crypto quote.");
        return;
      }
      setCryptoQuote(data.quote);
      setCryptoAttempt(data.attempt);
      setPaymentFeedback(
        `Locked quote ${data.quote.id} for ${data.quote.displayTokenAmount} ${data.quote.ticker} on ${data.quote.network}.`
      );
    } finally {
      setPaymentBusy(false);
    }
  }

  async function handleObserveCryptoScenario(
    scenario:
      | "exact_confirming"
      | "exact_finalized"
      | "underpaid"
      | "overpaid"
      | "wrong_network"
  ) {
    if (!cryptoQuote) return;
    setPaymentBusy(true);
    setPaymentFeedback(null);
    try {
      const expected = BigInt(cryptoQuote.exactTokenBaseUnits);
      let observedBaseUnits = expected.toString();
      let observedNetwork = cryptoQuote.network;
      let observedTokenIdentifier = cryptoQuote.tokenIdentifier;
      let confirmations = cryptoQuote.requiredConfirmations;

      if (scenario === "exact_confirming") {
        confirmations = Math.max(1, Math.floor(cryptoQuote.requiredConfirmations / 2));
      } else if (scenario === "underpaid") {
        observedBaseUnits = ((expected * BigInt(90)) / BigInt(100)).toString();
      } else if (scenario === "overpaid") {
        observedBaseUnits = ((expected * BigInt(115)) / BigInt(100)).toString();
      } else if (scenario === "wrong_network") {
        observedNetwork = "Unlisted Testnet / Wrong Chain";
        observedTokenIdentifier = "UNLISTED:WRONG_TOKEN_CONTRACT";
      }

      const res = await fetch("/api/payments/crypto/observe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quoteId: cryptoQuote.id,
          observedNetwork,
          observedTokenIdentifier,
          observedBaseUnits,
          txHash: `0xsim_${cryptoQuote.id.slice(0, 12)}_${scenario}`,
          confirmations,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPaymentFeedback(data.error || "Observation failed.");
        return;
      }
      setCryptoQuote(data.quote);
      setCryptoAttempt(data.attempt);
      setReservation(data.reservation);
      setPaymentFeedback(
        data.attempt?.failureReason ||
          `Quote status updated to "${data.quote.status}" (${confirmations}/${data.quote.requiredConfirmations} confirmations).`
      );
    } finally {
      setPaymentBusy(false);
    }
  }

  if (loadingHold) {
    return (
      <div className="max-w-5xl mx-auto px-5 py-16">
        <div className="bg-white border border-[#E2DACB] p-10 text-center text-sm text-[#575147]">
          Loading atomic inventory hold...
        </div>
      </div>
    );
  }

  if (holdError || !hold) {
    return (
      <div className="max-w-3xl mx-auto px-5 py-16 text-center space-y-5">
        <h1 className="font-serif text-4xl text-[#111111]">
          Reservation Checkout
        </h1>
        <p className="text-sm text-[#8C2D19] bg-[#FDF2F0] border border-[#E9C5BD] p-4">
          {holdError || "Hold unavailable."}
        </p>
        <Link
          href="/properties"
          className="inline-flex items-center gap-2 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-6 py-3 text-[11px] tracking-[0.2em] uppercase"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Browse Properties</span>
        </Link>
      </div>
    );
  }

  const confirmationUrl =
    reservation && accessToken
      ? `/reservations/${reservation.confirmationCode}?token=${encodeURIComponent(accessToken)}`
      : null;

  return (
    <div className="max-w-[1320px] mx-auto px-5 sm:px-8 lg:px-12 py-12 space-y-8">
      {/* Header & Demonstration Mode Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#E2DACB] pb-6">
        <div>
          <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F] mb-2">
            Demonstration Mode &middot; Non-Production Settlement
          </p>
          <h1 className="font-serif text-4xl sm:text-5xl text-[#111111]">
            Reservation Checkout
          </h1>
        </div>

        <div className="bg-[#FAF8F3] border border-[#C5A25D] px-4 py-3 flex items-center gap-3">
          <Clock className="w-4 h-4 text-[#8A6B2F]" aria-hidden="true" />
          <div className="text-xs">
            <p className="uppercase tracking-[0.16em] text-[10px] text-[#686054]">
              Inventory Hold Timer
            </p>
            <p className="font-mono tabular-nums font-semibold text-[#111111]">
              {hold.status === "converted"
                ? "Converted to Booking"
                : holdExpired
                  ? "HOLD EXPIRED"
                  : `${formatCountdown(hold.expiresAt, nowMs)} remaining`}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left Column: Guest Form & Payment Execution */}
        <div className="lg:col-span-7 space-y-8">
          {!reservation ? (
            <form
              onSubmit={handleCreateReservation}
              className="bg-white border border-[#E2DACB] p-6 sm:p-8 space-y-6"
            >
              <h2 className="font-serif text-2xl text-[#111111]">
                1. Guest Details &amp; Policy Acceptance
              </h2>

              {holdExpired && (
                <div
                  role="alert"
                  className="bg-[#FDF2F0] border border-[#E9C5BD] p-4 text-xs text-[#8C2D19] flex items-start gap-2.5"
                >
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" aria-hidden="true" />
                  <span>
                    This inventory hold has expired and units were released back
                    to availability. Please return to the property page to
                    secure a fresh hold.
                  </span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="guest-name"
                    className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
                  >
                    Full Name *
                  </label>
                  <input
                    id="guest-name"
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestNameInput(e.target.value)}
                    placeholder="Alexandra Sterling"
                    className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
                  />
                </div>
                <div>
                  <label
                    htmlFor="guest-email"
                    className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
                  >
                    Email Address *
                  </label>
                  <input
                    id="guest-email"
                    type="email"
                    required
                    value={guestEmail}
                    onChange={(e) => setGuestEmailInput(e.target.value)}
                    placeholder="guest@example.com"
                    className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
                  />
                </div>
                <div>
                  <label
                    htmlFor="guest-phone"
                    className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
                  >
                    Telephone *
                  </label>
                  <input
                    id="guest-phone"
                    type="tel"
                    required
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    placeholder="+1 212 555 0148"
                    className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
                  />
                </div>
                <div>
                  <label
                    htmlFor="guest-country"
                    className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
                  >
                    Country / Region
                  </label>
                  <input
                    id="guest-country"
                    type="text"
                    value={guestCountry}
                    onChange={(e) => setGuestCountry(e.target.value)}
                    className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="guest-requests"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
                >
                  Arrival Notes or Requests (Optional)
                </label>
                <textarea
                  id="guest-requests"
                  rows={2}
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="Late afternoon arrival, high-floor quiet suite preference..."
                  className="w-full border border-[#D8D0C1] px-3.5 py-2 text-sm"
                />
              </div>

              {/* Payment Method Selection */}
              <div className="pt-2 space-y-3">
                <p className="text-[11px] font-semibold tracking-[0.18em] uppercase text-[#111111]">
                  Payment Method
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(
                    [
                      {
                        id: "usd_card",
                        title: "$ US Dollars",
                        sub: "Simulated Sandbox Gateway",
                      },
                      {
                        id: "trump_token",
                        title: "$TRUMP Token",
                        sub: "Simulated Crypto Adapter",
                      },
                      {
                        id: "usd1_stablecoin",
                        title: "USD1 Stablecoin",
                        sub: "Simulated Crypto Adapter",
                      },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setPaymentMethod(opt.id)}
                      className={`p-3.5 border text-left transition-colors ${
                        paymentMethod === opt.id
                          ? "border-[#C5A25D] bg-[#FAF8F3]"
                          : "border-[#E2DACB] bg-white hover:border-[#C5A25D]/60"
                      }`}
                    >
                      <p className="text-sm font-semibold text-[#111111]">
                        {opt.title}
                      </p>
                      <p className="text-[11px] text-[#686054] mt-0.5">
                        {opt.sub}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Locked Cancellation Policy Acceptance */}
              <div className="bg-[#FAF8F3] border border-[#E2DACB] p-4 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#111111]">
                    Cancellation Policy ({hold.policySnapshot.version})
                  </span>
                  <span className="text-[#686054]">
                    {hold.policySnapshot.refundable ? "Refundable Tier" : "Non-Refundable"}
                  </span>
                </div>
                <p className="text-xs text-[#4A453C] leading-relaxed">
                  {hold.policySnapshot.summary}
                </p>
                <label className="flex items-start gap-2.5 text-xs text-[#111111] cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    required
                    checked={acceptedPolicy}
                    onChange={(e) => setAcceptedPolicy(e.target.checked)}
                    className="mt-0.5 w-4 h-4 accent-[#111111]"
                  />
                  <span>
                    I acknowledge this is a fictional demonstration booking and
                    accept the rate and cancellation policy snapshot above.
                  </span>
                </label>
              </div>

              {resError && (
                <p
                  role="alert"
                  className="text-xs text-[#8C2D19] bg-[#FDF2F0] border border-[#E9C5BD] p-3"
                >
                  {resError}
                </p>
              )}

              <button
                type="submit"
                disabled={creatingRes || holdExpired}
                className="w-full inline-flex items-center justify-center gap-2 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-4 px-6 text-[11px] font-medium tracking-[0.2em] uppercase disabled:opacity-40"
              >
                <span>
                  {creatingRes
                    ? "Securing Reservation..."
                    : "Proceed to Demonstration Settlement"}
                </span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </form>
          ) : (
            /* Step 2: Payment Execution & Verification */
            <div className="bg-white border border-[#E2DACB] p-6 sm:p-8 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#EBE4D6] pb-4">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.2em] text-[#8A6B2F]">
                    Reference: {reservation.confirmationCode}
                  </p>
                  <h2 className="font-serif text-2xl text-[#111111] mt-1">
                    2. Settlement &amp; Verification
                  </h2>
                </div>
                <div className="text-right text-xs font-mono space-y-0.5">
                  <p>
                    Booking:{" "}
                    <strong className="uppercase">{reservation.reservationStatus}</strong>
                  </p>
                  <p>
                    Payment:{" "}
                    <strong className="uppercase">{reservation.paymentStatus}</strong>
                  </p>
                  <p>
                    Fulfillment:{" "}
                    <strong className="uppercase">{reservation.fulfillmentStatus}</strong>
                  </p>
                </div>
              </div>

              {/* Payment Method Switcher while unpaid */}
              {reservation.paymentStatus !== "paid" && (
                <div className="flex flex-wrap gap-2">
                  {(
                    [
                      { id: "usd_card", label: "US Dollars (Sandbox)" },
                      { id: "trump_token", label: "$TRUMP (Simulated)" },
                      { id: "usd1_stablecoin", label: "USD1 (Simulated)" },
                    ] as const
                  ).map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPaymentMethod(m.id)}
                      className={`px-3.5 py-2 border text-xs ${
                        paymentMethod === m.id
                          ? "border-[#C5A25D] bg-[#FAF8F3] font-semibold"
                          : "border-[#E2DACB] text-[#575147]"
                      }`}
                    >
                      {m.label}
                    </button>
                  ))}
                </div>
              )}

              {/* USD Sandbox Flow */}
              {paymentMethod === "usd_card" && (
                <div className="space-y-5">
                  <div className="bg-[#FAF8F3] border border-[#E2DACB] p-4 text-xs text-[#4A453C] flex items-start gap-3">
                    <Lock className="w-4 h-4 text-[#8A6B2F] shrink-0 mt-0.5" aria-hidden="true" />
                    <div>
                      <p className="font-semibold text-[#111111] mb-1">
                        Demonstration Mode — Simulated Hosted Checkout
                      </p>
                      <p>
                        No real credit card fields are collected and no actual
                        charge will occur. Reservations confirm strictly upon
                        verified server-side HMAC webhook evidence—never from a
                        browser redirect alone.
                      </p>
                    </div>
                  </div>

                  {!usdAttempt ? (
                    <button
                      type="button"
                      disabled={paymentBusy}
                      onClick={handleStartUsdSession}
                      className="w-full bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-3.5 px-6 text-[11px] font-medium tracking-[0.2em] uppercase"
                    >
                      {paymentBusy
                        ? "Creating Session..."
                        : `Create USD Sandbox Session (${formatUsdCents(reservation.totalUsdCents)})`}
                    </button>
                  ) : (
                    <div className="border border-[#E2DACB] p-5 space-y-4">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span>Session: {usdAttempt.providerSessionId}</span>
                        <span>Status: {usdAttempt.status}</span>
                      </div>

                      {reservation.paymentStatus !== "paid" && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleSimulateUsdOutcome("payment.succeeded")
                            }
                            className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-2.5 px-4 text-[10px] tracking-[0.16em] uppercase font-medium"
                          >
                            Simulate Verified Payment Webhook
                          </button>
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleSimulateUsdOutcome("payment.failed")
                            }
                            className="border border-[#D8D0C1] py-2.5 px-4 text-[10px] tracking-[0.16em] uppercase text-[#8C2D19]"
                          >
                            Simulate Failed Payment
                          </button>
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleSimulateUsdOutcome("duplicate_webhook")
                            }
                            className="border border-[#D8D0C1] py-2.5 px-4 text-[10px] tracking-[0.16em] uppercase"
                          >
                            Test Duplicate Webhook
                          </button>
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleSimulateUsdOutcome("invalid_signature")
                            }
                            className="border border-[#D8D0C1] py-2.5 px-4 text-[10px] tracking-[0.16em] uppercase"
                          >
                            Test Invalid Signature (401)
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Proposed Crypto Checkout Flow */}
              {paymentMethod !== "usd_card" && (
                <div className="space-y-5">
                  <div className="bg-[#FAF8F3] border border-[#C5A25D] p-4 text-xs text-[#4A453C] flex items-start gap-3">
                    <ShieldAlert className="w-4 h-4 text-[#8A6B2F] shrink-0 mt-0.5" aria-hidden="true" />
                    <div>
                      <p className="font-semibold text-[#111111] mb-1">
                        Proposed Cryptocurrency Checkout — Simulation Adapter
                      </p>
                      <p>
                        Independent design concept only. Do NOT send real funds,
                        do NOT enter seed phrases or private keys, and note that
                        stablecoins are not assumed equal to $1.00 USD.
                      </p>
                    </div>
                  </div>

                  {/* Allowlisted Asset Selector */}
                  <div className="space-y-2">
                    <label
                      htmlFor="crypto-asset-select"
                      className="block text-[10px] uppercase tracking-[0.18em] text-[#686054]"
                    >
                      Allowlisted Network &amp; Token Identifier
                    </label>
                    <select
                      id="crypto-asset-select"
                      value={effectiveAssetId}
                      onChange={(e) => {
                        setSelectedAssetId(e.target.value);
                        setCryptoQuote(null);
                      }}
                      className="w-full border border-[#D8D0C1] bg-white px-3.5 py-2.5 text-xs font-mono"
                    >
                      {cryptoAssetsForMethod.map((a) => (
                        <option key={a.assetId} value={a.assetId}>
                          {a.ticker} &mdash; {a.network} ({a.decimals} decimals)
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <button
                      type="button"
                      disabled={paymentBusy}
                      onClick={() => handleRequestCryptoQuote()}
                      className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-5 py-3 text-[11px] tracking-[0.18em] uppercase font-medium"
                    >
                      {cryptoQuote ? "Refresh 5-Min Quote" : "Request Conversion Quote"}
                    </button>
                    <button
                      type="button"
                      disabled={paymentBusy}
                      onClick={() => handleRequestCryptoQuote(2)}
                      className="border border-[#D8D0C1] px-4 py-3 text-[10px] tracking-[0.16em] uppercase text-[#575147]"
                    >
                      Create 2-Sec Expiry Quote (Test)
                    </button>
                  </div>

                  {cryptoQuote && (
                    <div className="border border-[#E2DACB] bg-[#FAF8F3] p-5 space-y-4 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E2DACB] pb-3">
                        <span className="font-mono font-semibold text-[#111111]">
                          Quote State: {cryptoQuote.status.toUpperCase()}
                          {cryptoAttempt ? ` (${cryptoAttempt.status})` : ""}
                        </span>
                        <span className="font-mono tabular-nums text-[#8A6B2F]">
                          Expires in {formatCountdown(cryptoQuote.expiresAt, nowMs)}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-[11px]">
                        <div>
                          <p className="text-[#686054]">EXACT PAYABLE AMOUNT</p>
                          <p className="text-base font-semibold text-[#111111]">
                            {cryptoQuote.displayTokenAmount} {cryptoQuote.ticker}
                          </p>
                          <p className="text-[10px] text-[#686054]">
                            Base units: {cryptoQuote.exactTokenBaseUnits}
                          </p>
                        </div>
                        <div>
                          <p className="text-[#686054]">USD EQUIVALENT + NETWORK FEE</p>
                          <p className="text-sm font-semibold text-[#111111]">
                            {formatUsdCents(cryptoQuote.totalPayableUsdCents)} USD
                          </p>
                          <p className="text-[10px] text-[#686054]">
                            Rate: ${cryptoQuote.exchangeRateUsdPerTokenString}/{cryptoQuote.ticker}
                          </p>
                        </div>
                        <div className="sm:col-span-2">
                          <p className="text-[#686054]">ALLOWLISTED TOKEN &amp; NETWORK</p>
                          <p className="break-all text-[#111111]">
                            {cryptoQuote.network} &middot; {cryptoQuote.tokenIdentifier}
                          </p>
                        </div>
                        <div className="sm:col-span-2">
                          <p className="text-[#686054]">RATE SOURCE &amp; TIMESTAMP</p>
                          <p className="text-[#111111]">
                            {cryptoQuote.rateSource} ({cryptoQuote.rateTimestamp})
                          </p>
                        </div>
                      </div>

                      {reservation.paymentStatus !== "paid" && (
                        <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleObserveCryptoScenario("exact_finalized")
                            }
                            className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-2.5 px-3 text-[10px] tracking-[0.15em] uppercase"
                          >
                            Simulate Confirmed Transfer ({cryptoQuote.requiredConfirmations} conf)
                          </button>
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleObserveCryptoScenario("exact_confirming")
                            }
                            className="border border-[#D8D0C1] bg-white py-2.5 px-3 text-[10px] tracking-[0.15em] uppercase"
                          >
                            Simulate Partial Confirming
                          </button>
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleObserveCryptoScenario("underpaid")
                            }
                            className="border border-[#D8D0C1] bg-white py-2.5 px-3 text-[10px] tracking-[0.15em] uppercase text-[#8C2D19]"
                          >
                            Simulate Underpayment (90%)
                          </button>
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleObserveCryptoScenario("overpaid")
                            }
                            className="border border-[#D8D0C1] bg-white py-2.5 px-3 text-[10px] tracking-[0.15em] uppercase text-[#8A6B2F]"
                          >
                            Simulate Overpayment (115%)
                          </button>
                          <button
                            type="button"
                            disabled={paymentBusy}
                            onClick={() =>
                              handleObserveCryptoScenario("wrong_network")
                            }
                            className="sm:col-span-2 border border-[#E9C5BD] bg-[#FDF2F0] py-2 px-3 text-[10px] tracking-[0.15em] uppercase text-[#8C2D19]"
                          >
                            Simulate Wrong Network / Unlisted Token Rejection
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {paymentFeedback && (
                <div className="border border-[#C5A25D] bg-[#FAF8F3] p-4 text-xs text-[#111111]">
                  {paymentFeedback}
                </div>
              )}

              {confirmationUrl && (
                <div className="pt-2 flex flex-wrap items-center justify-between gap-4 border-t border-[#EBE4D6]">
                  <div className="flex items-center gap-2 text-xs text-[#2B593F]">
                    <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                    <span>
                      {reservation.reservationStatus === "confirmed"
                        ? "Booking confirmed and persisted."
                        : "Reservation recorded. Open confirmation portal anytime."}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => router.push(confirmationUrl)}
                    className="inline-flex items-center gap-2 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-6 py-3 text-[11px] tracking-[0.18em] uppercase font-medium"
                  >
                    <span>Open Confirmation &amp; Management</span>
                    <ArrowRight className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Server-Calculated Price Summary */}
        <div className="lg:col-span-5">
          <div className="bg-white border border-[#E2DACB] p-6 sm:p-7 space-y-5 sticky top-28">
            <h2 className="font-serif text-2xl text-[#111111]">
              Stay &amp; Price Summary
            </h2>

            <div className="border-t border-b border-[#EBE4D6] py-4 space-y-2 text-xs">
              <p className="font-semibold text-sm text-[#111111]">
                {hold.rateSnapshot.roomTypeName}
              </p>
              <p className="text-[#575147]">
                {hold.checkIn} to {hold.checkOut} ({hold.nights} night(s) &middot;{" "}
                {hold.roomCount} room(s))
              </p>
              <p className="text-[#575147]">
                {hold.adults} adult(s), {hold.children} child(ren) &middot;{" "}
                {hold.rateSnapshot.ratePlanName}
              </p>
            </div>

            {/* Nightly Lines */}
            <div className="space-y-2 text-xs">
              <p className="text-[10px] uppercase tracking-[0.18em] text-[#686054]">
                Nightly Rate Schedule ({hold.roomCount} room)
              </p>
              {hold.pricing.nightlyLines.map((line) => (
                <div
                  key={line.date}
                  className="flex items-center justify-between font-mono tabular-nums text-[#3D3830]"
                >
                  <span>{line.date}</span>
                  <span>
                    {formatUsdCents(line.adjustedRateUsdCents * hold.roomCount)}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t border-[#EBE4D6] pt-4 space-y-2 text-xs font-mono tabular-nums">
              <div className="flex justify-between">
                <span className="text-[#575147]">Accommodation Subtotal</span>
                <span>{formatUsdCents(hold.pricing.subtotalUsdCents)}</span>
              </div>
              {hold.pricing.discountUsdCents > 0 && (
                <div className="flex justify-between text-[#2B593F]">
                  <span>Rate Plan Privilege Discount</span>
                  <span>-{formatUsdCents(hold.pricing.discountUsdCents)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-[#575147]">Resort &amp; Amenity Fees</span>
                <span>{formatUsdCents(hold.pricing.feesUsdCents)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#575147]">Occupancy &amp; Local Taxes</span>
                <span>{formatUsdCents(hold.pricing.taxesUsdCents)}</span>
              </div>
              <div className="border-t border-[#C5A25D]/60 pt-3 flex justify-between text-base font-semibold text-[#111111]">
                <span className="font-serif text-lg">Total (USD)</span>
                <span>{formatUsdCents(hold.pricing.totalUsdCents)} USD</span>
              </div>
            </div>

            {cryptoQuote && (
              <div className="bg-[#FAF8F3] border border-[#C5A25D] p-3.5 text-xs font-mono space-y-1">
                <p className="text-[10px] uppercase tracking-[0.16em] text-[#8A6B2F]">
                  Locked Crypto Quote Equivalent
                </p>
                <p className="font-semibold text-[#111111]">
                  {cryptoQuote.displayTokenAmount} {cryptoQuote.ticker}
                </p>
                <p className="text-[10px] text-[#686054]">
                  Includes {formatUsdCents(cryptoQuote.feeUsdCents)} network fee
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ReservePage() {
  return (
    <Suspense
      fallback={
        <div className="max-w-5xl mx-auto px-5 py-16 text-center text-sm">
          Loading reservation checkout...
        </div>
      }
    >
      <ReserveCheckoutInner />
    </Suspense>
  );
}
