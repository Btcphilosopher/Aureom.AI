"use client";

import React, { useCallback, useEffect, useState } from "react";
import { useParams, useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  AlertCircle,
  CheckCircle2,
  Mail,
  Printer,
  RefreshCw,
} from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import { formatUsdCents } from "@/lib/crypto-assets";
import type {
  CryptoQuote,
  EmailOutbox,
  PaymentAttempt,
  Refund,
  Reservation,
} from "@/lib/types";

export default function ReservationConfirmationPage() {
  const params = useParams<{ code: string }>();
  const searchParams = useSearchParams();
  const { getIdToken } = useAuth();

  const code = params.code;
  const token = searchParams.get("token");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reservation, setReservation] = useState<Reservation | null>(null);
  const [attempts, setAttempts] = useState<PaymentAttempt[]>([]);
  const [quotes, setQuotes] = useState<CryptoQuote[]>([]);
  const [refunds, setRefunds] = useState<Refund[]>([]);
  const [emails, setEmails] = useState<EmailOutbox[]>([]);

  // Cancellation state
  const [cancelReason, setCancelReason] = useState("Change of travel schedule");
  const [destinationWallet, setDestinationWallet] = useState("");
  const [cancelling, setCancelling] = useState(false);
  const [cancelMessage, setCancelMessage] = useState<string | null>(null);

  // Support enquiry state
  const [enquirySubject, setEnquirySubject] = useState("");
  const [enquiryMessage, setEnquiryMessage] = useState("");
  const [enquirySent, setEnquirySent] = useState(false);

  const loadBundle = useCallback(async () => {
    await Promise.resolve();
    setLoading(true);
    setError(null);
    try {
      const idToken = await getIdToken();
      const qs = token ? `?token=${encodeURIComponent(token)}` : "";
      const res = await fetch(
        `/api/reservations/${encodeURIComponent(code)}${qs}`,
        {
          headers: idToken ? { Authorization: `Bearer ${idToken}` } : {},
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Unable to access reservation.");
        return;
      }
      setReservation(data.reservation);
      setAttempts(data.paymentAttempts || []);
      setQuotes(data.cryptoQuotes || []);
      setRefunds(data.refunds || []);
      setEmails(data.emails || []);
    } catch {
      setError("Network error while loading reservation details.");
    } finally {
      setLoading(false);
    }
  }, [code, token, getIdToken]);

  useEffect(() => {
    let active = true;
    (async () => {
      if (active) await loadBundle();
    })();
    return () => {
      active = false;
    };
  }, [loadBundle]);

  async function handleCancelRequest(e: React.FormEvent) {
    e.preventDefault();
    if (!reservation) return;
    setCancelling(true);
    setCancelMessage(null);
    try {
      const idToken = await getIdToken();
      const res = await fetch(
        `/api/reservations/${encodeURIComponent(reservation.confirmationCode)}/cancel`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(idToken ? { Authorization: `Bearer ${idToken}` } : {}),
          },
          body: JSON.stringify({
            accessToken: token || undefined,
            reason: cancelReason,
            destinationWallet: destinationWallet || undefined,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setCancelMessage(data.error || "Unable to submit cancellation.");
        return;
      }
      setCancelMessage(data.explanation);
      await loadBundle();
    } finally {
      setCancelling(false);
    }
  }

  async function handleSubmitEnquiry(e: React.FormEvent) {
    e.preventDefault();
    if (!reservation) return;
    const res = await fetch("/api/enquiries", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        guestName: reservation.guestName,
        guestEmail: reservation.guestEmail,
        subject:
          enquirySubject || `Reservation ${reservation.confirmationCode}`,
        message: enquiryMessage,
        reservationId: reservation.id,
        propertyId: reservation.propertyId,
      }),
    });
    if (res.ok) {
      setEnquirySent(true);
      setEnquirySubject("");
      setEnquiryMessage("");
    }
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-5 py-16 text-center text-sm text-[#575147]">
        Verifying booking access token...
      </div>
    );
  }

  if (error || !reservation) {
    return (
      <div className="max-w-2xl mx-auto px-5 py-16 text-center space-y-5">
        <AlertCircle className="w-10 h-10 text-[#8C2D19] mx-auto" aria-hidden="true" />
        <h1 className="font-serif text-3xl text-[#111111]">
          Secure Booking Verification Required
        </h1>
        <p className="text-sm text-[#575147]">
          {error ||
            "Bookings cannot be accessed by reference number alone. Please use your tokenized link or verify your email."}
        </p>
        <Link
          href="/manage"
          className="inline-flex items-center justify-center bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-6 py-3 text-[11px] tracking-[0.2em] uppercase"
        >
          Verify Booking Credentials
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-[1200px] mx-auto px-5 sm:px-8 lg:px-12 py-12 space-y-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#E2DACB] pb-6">
        <div>
          <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F] mb-2">
            Confirmation Document &amp; Management
          </p>
          <h1 className="font-serif text-4xl text-[#111111]">
            {reservation.confirmationCode}
          </h1>
          <p className="text-sm text-[#575147] mt-1">
            {reservation.propertyName} &middot; {reservation.roomTypeName}
          </p>
        </div>

        <div className="flex items-center gap-3 print:hidden">
          <button
            type="button"
            onClick={() => void loadBundle()}
            className="inline-flex items-center gap-2 border border-[#D8D0C1] bg-white px-4 py-2.5 text-[11px] tracking-[0.16em] uppercase"
          >
            <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Refresh</span>
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-5 py-2.5 text-[11px] tracking-[0.16em] uppercase"
          >
            <Printer className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Print Folio</span>
          </button>
        </div>
      </div>

      {/* Separated State Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-[#E2DACB] p-5">
          <p className="text-[10px] uppercase tracking-[0.18em] text-[#686054]">
            Reservation State
          </p>
          <p className="mt-1 font-mono text-base font-semibold uppercase text-[#111111]">
            {reservation.reservationStatus.replaceAll("_", " ")}
          </p>
        </div>
        <div className="bg-white border border-[#E2DACB] p-5">
          <p className="text-[10px] uppercase tracking-[0.18em] text-[#686054]">
            Payment State
          </p>
          <p className="mt-1 font-mono text-base font-semibold uppercase text-[#111111]">
            {reservation.paymentStatus.replaceAll("_", " ")}
          </p>
        </div>
        <div className="bg-white border border-[#E2DACB] p-5">
          <p className="text-[10px] uppercase tracking-[0.18em] text-[#686054]">
            Fulfillment State
          </p>
          <p className="mt-1 font-mono text-base font-semibold uppercase text-[#111111]">
            {reservation.fulfillmentStatus.replaceAll("_", " ")}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Folio, Guest Info, Payment History, Outbox */}
        <div className="lg:col-span-7 space-y-8">
          <section className="bg-white border border-[#E2DACB] p-6 space-y-4">
            <h2 className="font-serif text-2xl text-[#111111]">
              Guest &amp; Itinerary Folio
            </h2>
            <div className="grid grid-cols-2 gap-4 text-xs border-t border-[#EBE4D6] pt-4">
              <div>
                <p className="text-[#686054] uppercase text-[10px] tracking-[0.16em]">
                  Guest
                </p>
                <p className="font-medium text-[#111111] mt-0.5">
                  {reservation.guestName}
                </p>
                <p className="text-[#575147]">{reservation.guestEmail}</p>
                <p className="text-[#575147]">{reservation.guestPhone}</p>
              </div>
              <div>
                <p className="text-[#686054] uppercase text-[10px] tracking-[0.16em]">
                  Stay Dates
                </p>
                <p className="font-mono text-[#111111] mt-0.5">
                  {reservation.checkIn} &rarr; {reservation.checkOut}
                </p>
                <p className="text-[#575147]">
                  {reservation.nights} night(s) &middot; {reservation.roomCount}{" "}
                  room(s) &middot; {reservation.adults} adult(s),{" "}
                  {reservation.children} child(ren)
                </p>
              </div>
            </div>

            <div className="border-t border-[#EBE4D6] pt-4 space-y-1.5 text-xs font-mono tabular-nums">
              <div className="flex justify-between">
                <span className="text-[#575147]">Total Billed (USD)</span>
                <span className="font-semibold">
                  {formatUsdCents(reservation.totalUsdCents)} USD
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#575147]">Settled Paid (USD)</span>
                <span className="font-semibold">
                  {formatUsdCents(reservation.paidUsdCents)} USD
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#575147]">Accepted Policy</span>
                <span>{reservation.cancellationPolicySnapshot.version}</span>
              </div>
            </div>
          </section>

          {/* Payment Attempts & Quotes */}
          <section className="bg-white border border-[#E2DACB] p-6 space-y-4">
            <h2 className="font-serif text-2xl text-[#111111]">
              Payment &amp; Quote Ledger
            </h2>
            {attempts.length === 0 ? (
              <p className="text-xs text-[#575147]">
                No payment attempts recorded yet.{" "}
                {reservation.reservationStatus === "pending_payment" && (
                  <Link
                    href={`/reserve?holdId=${encodeURIComponent(reservation.holdId)}`}
                    className="underline text-[#8A6B2F]"
                  >
                    Return to checkout
                  </Link>
                )}
              </p>
            ) : (
              <div className="space-y-3">
                {attempts.map((att) => (
                  <div
                    key={att.id}
                    className="border border-[#E5DFD2] bg-[#FAF8F3] p-3.5 text-xs font-mono space-y-1"
                  >
                    <div className="flex justify-between">
                      <span className="font-semibold">
                        {att.method} ({att.mode})
                      </span>
                      <span className="uppercase">{att.status}</span>
                    </div>
                    <p className="text-[#575147]">
                      Amount: {formatUsdCents(att.amountUsdCents)} &middot; Session:{" "}
                      {att.providerSessionId}
                    </p>
                    {att.txHash && (
                      <p className="text-[#575147] break-all">
                        Tx: {att.txHash} ({att.confirmations}/
                        {att.requiredConfirmations} conf)
                      </p>
                    )}
                    {att.failureReason && (
                      <p className="text-[#8C2D19]">{att.failureReason}</p>
                    )}
                  </div>
                ))}
              </div>
            )}

            {quotes.length > 0 && (
              <div className="pt-2 space-y-2">
                <p className="text-[10px] uppercase tracking-[0.18em] text-[#686054]">
                  Crypto Conversion Quotes
                </p>
                {quotes.map((q) => (
                  <div
                    key={q.id}
                    className="border border-[#E5DFD2] p-3 text-xs font-mono space-y-1"
                  >
                    <div className="flex justify-between">
                      <span>
                        {q.displayTokenAmount} {q.ticker} ({q.network})
                      </span>
                      <span className="uppercase">{q.status}</span>
                    </div>
                    <p className="text-[11px] text-[#686054]">
                      Rate: ${q.exchangeRateUsdPerTokenString} &middot;{" "}
                      {q.rateSource}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Local Email Outbox Preview */}
          <section className="bg-white border border-[#E2DACB] p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Mail className="w-4 h-4 text-[#8A6B2F]" aria-hidden="true" />
              <h2 className="font-serif text-2xl text-[#111111]">
                Confirmation Email Outbox Preview
              </h2>
            </div>
            {emails.map((em) => (
              <div
                key={em.id}
                className="border border-[#E5DFD2] bg-[#FAF8F3] p-4 text-xs space-y-2"
              >
                <div className="flex justify-between font-mono text-[11px]">
                  <span>To: {em.to}</span>
                  <span className="uppercase text-[#8A6B2F]">
                    Status: {em.status}
                  </span>
                </div>
                <p className="font-semibold text-[#111111]">{em.subject}</p>
                <pre className="whitespace-pre-wrap font-sans text-[#4A453C] leading-relaxed">
                  {em.bodyPreview}
                </pre>
              </div>
            ))}
          </section>
        </div>

        {/* Right: Cancellation & Support Enquiry */}
        <div className="lg:col-span-5 space-y-8 print:hidden">
          <section className="bg-white border border-[#E2DACB] p-6 space-y-4">
            <h2 className="font-serif text-2xl text-[#111111]">
              Cancellation &amp; Refunds
            </h2>
            <p className="text-xs text-[#4A453C] leading-relaxed">
              Accepted policy ({reservation.cancellationPolicySnapshot.version}):{" "}
              {reservation.cancellationPolicySnapshot.summary}
            </p>

            {refunds.length > 0 && (
              <div className="space-y-2 pt-2">
                {refunds.map((rf) => (
                  <div
                    key={rf.id}
                    className="border border-[#C5A25D] bg-[#FAF8F3] p-3.5 text-xs font-mono space-y-1"
                  >
                    <div className="flex justify-between font-semibold">
                      <span>Refund {rf.id.slice(0, 12)}</span>
                      <span className="uppercase">{rf.status}</span>
                    </div>
                    <p>
                      USD Entitlement: {formatUsdCents(rf.usdEntitlementCents)}{" "}
                      &middot; Fee: {formatUsdCents(rf.feeUsdCents)} &middot; Net
                      Refund: {formatUsdCents(rf.netUsdRefundCents)}
                    </p>
                    {rf.displayTokenAmount && (
                      <p className="text-[#8A6B2F]">
                        Token Basis: {rf.displayTokenAmount} {rf.tokenTicker} (at{" "}
                        {rf.conversionTimestamp})
                      </p>
                    )}
                    <p className="text-[11px] text-[#575147]">
                      Wallet Verified: {rf.walletVerified ? "Yes" : "Pending Admin Review"}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {reservation.reservationStatus !== "cancelled" && (
              <form onSubmit={handleCancelRequest} className="space-y-3 pt-2">
                <div>
                  <label
                    htmlFor="cancel-reason"
                    className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1"
                  >
                    Cancellation Reason
                  </label>
                  <input
                    id="cancel-reason"
                    type="text"
                    required
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    className="w-full border border-[#D8D0C1] px-3 py-2 text-xs"
                  />
                </div>
                {reservation.paymentMethod !== "usd_card" && (
                  <div>
                    <label
                      htmlFor="refund-wallet"
                      className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1"
                    >
                      Destination Refund Wallet (Required for Crypto Review)
                    </label>
                    <input
                      id="refund-wallet"
                      type="text"
                      value={destinationWallet}
                      onChange={(e) => setDestinationWallet(e.target.value)}
                      placeholder="Demo destination address for admin verification"
                      className="w-full border border-[#D8D0C1] px-3 py-2 text-xs font-mono"
                    />
                  </div>
                )}
                <button
                  type="submit"
                  disabled={cancelling}
                  className="w-full border border-[#8C2D19] text-[#8C2D19] hover:bg-[#FDF2F0] py-2.5 text-[11px] font-medium tracking-[0.18em] uppercase transition-colors"
                >
                  {cancelling
                    ? "Submitting..."
                    : "Submit Cancellation & Refund Request"}
                </button>
              </form>
            )}

            {cancelMessage && (
              <p className="text-xs bg-[#FAF8F3] border border-[#C5A25D] p-3 text-[#111111]">
                {cancelMessage}
              </p>
            )}
          </section>

          <section className="bg-white border border-[#E2DACB] p-6 space-y-4">
            <h2 className="font-serif text-2xl text-[#111111]">
              Reservation Support Enquiry
            </h2>
            <form onSubmit={handleSubmitEnquiry} className="space-y-3">
              <input
                type="text"
                placeholder="Subject (e.g., Chauffeur transfer)"
                value={enquirySubject}
                onChange={(e) => setEnquirySubject(e.target.value)}
                className="w-full border border-[#D8D0C1] px-3 py-2 text-xs"
              />
              <textarea
                rows={3}
                required
                placeholder="How may Private Client Services assist with your stay?"
                value={enquiryMessage}
                onChange={(e) => setEnquiryMessage(e.target.value)}
                className="w-full border border-[#D8D0C1] px-3 py-2 text-xs"
              />
              <button
                type="submit"
                className="w-full bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-2.5 text-[11px] tracking-[0.18em] uppercase font-medium"
              >
                Send Support Enquiry
              </button>
            </form>
            {enquirySent && (
              <p className="text-xs text-[#2B593F] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
                <span>Support enquiry logged for this reservation.</span>
              </p>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
