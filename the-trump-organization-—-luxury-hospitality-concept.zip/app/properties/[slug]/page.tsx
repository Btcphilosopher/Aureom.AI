import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { listProperties } from "@/lib/server/store";
import { PropertyDetailClient } from "@/components/PropertyDetailClient";
import type { PaymentMethod } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const { properties } = await listProperties();
  const prop = properties.find((p) => p.slug === slug || p.id === slug);
  return {
    title: prop
      ? `${prop.name} — Luxury Hospitality Concept`
      : "Property Not Found",
    description: prop?.tagline || "Luxury hospitality demonstration property.",
  };
}

export default async function PropertyDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{
    checkIn?: string;
    checkOut?: string;
    adults?: string;
    children?: string;
    rooms?: string;
    payment?: string;
  }>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const { properties, roomTypes, ratePlans, systemConfig } =
    await listProperties();

  const property = properties.find((p) => p.slug === slug || p.id === slug);
  if (!property) {
    notFound();
  }

  const propRooms = roomTypes.filter((r) => r.propertyId === property.id);
  const propPlans = ratePlans.filter((rp) => rp.propertyId === property.id);

  const baseMs = new Date(systemConfig.updatedAt).getTime();
  const defaultCheckIn =
    sp.checkIn && /^\d{4}-\d{2}-\d{2}$/.test(sp.checkIn)
      ? sp.checkIn
      : new Date(baseMs + 14 * 86_400_000).toISOString().slice(0, 10);
  const defaultCheckOut =
    sp.checkOut && /^\d{4}-\d{2}-\d{2}$/.test(sp.checkOut)
      ? sp.checkOut
      : new Date(baseMs + 16 * 86_400_000).toISOString().slice(0, 10);

  const paymentParam = sp.payment;
  const defaultPayment: PaymentMethod =
    paymentParam === "trump_token" || paymentParam === "usd1_stablecoin"
      ? paymentParam
      : "usd_card";

  return (
    <PropertyDetailClient
      property={property}
      initialRooms={propRooms}
      initialRatePlans={propPlans}
      defaultCheckIn={defaultCheckIn}
      defaultCheckOut={defaultCheckOut}
      defaultAdults={Math.max(1, Number(sp.adults) || 2)}
      defaultChildren={Math.max(0, Number(sp.children) || 0)}
      defaultRooms={Math.max(1, Number(sp.rooms) || 1)}
      defaultPayment={defaultPayment}
    />
  );
}
