import type { Metadata } from "next";
import { listProperties } from "@/lib/server/store";
import { PropertiesCatalogClient } from "@/components/PropertiesCatalogClient";

export const metadata: Metadata = {
  title: "Property Collection — The Trump Organization Concept",
  description:
    "Explore fictional demonstration city landmarks, coastal retreats, championship golf resorts, and private residences.",
};

export const dynamic = "force-dynamic";

export default async function PropertiesPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const sp = await searchParams;
  const { properties } = await listProperties();

  return (
    <PropertiesCatalogClient
      properties={properties}
      initialCategory={sp.category}
    />
  );
}
