"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, KeyRound, LogIn } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import type { Reservation } from "@/lib/types";
import { formatUsdCents } from "@/lib/crypto-assets";

interface RecentSessionBooking {
  confirmationCode: string;
  propertyName: string;
  accessToken: string;
  createdAt: string;
}

export default function ManageBookingsPage() {
  const router = useRouter();
  const { user, signInWithGoogle, getIdToken } = useAuth();

  const [confirmationCode, setConfirmationCode] = useState("");
  const [guestEmail, setGuestEmail] = useState("");
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [lookingUp, setLookingUp] = useState(false);

  const [myReservations, setMyReservations] = useState<Reservation[]>([]);
  const [sessionBookings, setSessionBookings] = useState<RecentSessionBooking[]>([]);

  useEffect(() => {
    const id = setTimeout(() => {
      try {
        const saved = JSON.parse(
          sessionStorage.getItem("demo_recent_bookings") || "[]"
        );
        if (Array.isArray(saved)) setSessionBookings(saved);
      } catch {
        // ignore
      }
    }, 0);
    return () => clearTimeout(id);
  }, []);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const token = await getIdToken();
      if (!token) return;
      const res = await fetch("/api/reservations", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setMyReservations(data.reservations || []);
      }
    })();
  }, [user, getIdToken]);

  async function handleLookup(e: React.FormEvent) {
    e.preventDefault();
    setLookingUp(true);
    setLookupError(null);
    try {
      const res = await fetch("/api/reservations/lookup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirmationCode, guestEmail }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLookupError(data.error || "Unable to verify reservation credentials.");
        return;
      }
      router.push(data.manageUrl);
    } catch {
      setLookupError("Network error while looking up booking.");
    } finally {
      setLookingUp(false);
    }
  }

  return (
    <div className="max-w-[1100px] mx-auto px-5 sm:px-8 lg:px-12 py-12 sm:py-16 space-y-12">
      <div className="max-w-2xl">
        <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F] mb-3">
          Secure Reservation Access
        </p>
        <h1 className="font-serif text-4xl sm:text-5xl text-[#111111]">
          Manage Your Stay
        </h1>
        <p className="mt-3 text-sm text-[#4A453C] leading-relaxed">
          To protect guest privacy, reservations cannot be retrieved by
          reference number alone. Verify with both your confirmation reference
          and guest email, or sign in with Google.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Verification Lookup Form */}
        <form
          onSubmit={handleLookup}
          className="bg-white border border-[#E2DACB] p-7 space-y-5"
        >
          <div className="flex items-center gap-2.5">
            <KeyRound className="w-4 h-4 text-[#8A6B2F]" aria-hidden="true" />
            <h2 className="font-serif text-2xl text-[#111111]">
              Reference &amp; Email Verification
            </h2>
          </div>

          <div>
            <label
              htmlFor="lookup-code"
              className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
            >
              Confirmation Reference
            </label>
            <input
              id="lookup-code"
              type="text"
              required
              value={confirmationCode}
              onChange={(e) => setConfirmationCode(e.target.value)}
              placeholder="TRM-8F3K9A2C"
              className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm font-mono uppercase"
            />
          </div>

          <div>
            <label
              htmlFor="lookup-email"
              className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1.5"
            >
              Guest Email Address
            </label>
            <input
              id="lookup-email"
              type="email"
              required
              value={guestEmail}
              onChange={(e) => setGuestEmail(e.target.value)}
              placeholder="guest@example.com"
              className="w-full border border-[#D8D0C1] px-3.5 py-2.5 text-sm"
            />
          </div>

          {lookupError && (
            <p
              role="alert"
              className="text-xs text-[#8C2D19] bg-[#FDF2F0] border border-[#E9C5BD] p-3"
            >
              {lookupError}
            </p>
          )}

          <button
            type="submit"
            disabled={lookingUp}
            className="w-full bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-3.5 text-[11px] font-medium tracking-[0.2em] uppercase"
          >
            {lookingUp ? "Verifying..." : "Access Reservation"}
          </button>
        </form>

        {/* Authenticated Guest Account & Session Bookings */}
        <div className="space-y-6">
          <div className="bg-white border border-[#E2DACB] p-7 space-y-4">
            <h2 className="font-serif text-2xl text-[#111111]">
              Authenticated Guest Account
            </h2>
            {!user ? (
              <div className="space-y-3">
                <p className="text-xs text-[#575147] leading-relaxed">
                  Sign in with Google to view all persistent bookings associated
                  with your email address.
                </p>
                <button
                  type="button"
                  onClick={() => void signInWithGoogle()}
                  className="inline-flex items-center gap-2 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-5 py-3 text-[11px] tracking-[0.18em] uppercase"
                >
                  <LogIn className="w-4 h-4" aria-hidden="true" />
                  <span>Sign In with Google</span>
                </button>
              </div>
            ) : myReservations.length === 0 ? (
              <p className="text-xs text-[#575147]">
                Signed in as <strong>{user.email}</strong>. No reservations
                matched this account yet.
              </p>
            ) : (
              <div className="space-y-3">
                {myReservations.map((r) => (
                  <Link
                    key={r.id}
                    href={`/reservations/${r.confirmationCode}`}
                    className="block border border-[#E5DFD2] bg-[#FAF8F3] p-4 hover:border-[#C5A25D] transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="font-semibold text-[#111111]">
                        {r.confirmationCode}
                      </span>
                      <span className="uppercase text-[#8A6B2F]">
                        {r.reservationStatus}
                      </span>
                    </div>
                    <p className="text-sm font-medium text-[#111111] mt-1">
                      {r.propertyName}
                    </p>
                    <p className="text-xs text-[#575147]">
                      {r.checkIn} &rarr; {r.checkOut} &middot;{" "}
                      {formatUsdCents(r.totalUsdCents)}
                    </p>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {sessionBookings.length > 0 && (
            <div className="bg-white border border-[#E2DACB] p-7 space-y-3">
              <h3 className="font-serif text-xl text-[#111111]">
                Recent Demonstration Bookings (This Session)
              </h3>
              <div className="space-y-2">
                {sessionBookings.map((sb) => (
                  <Link
                    key={sb.confirmationCode}
                    href={`/reservations/${sb.confirmationCode}?token=${encodeURIComponent(sb.accessToken)}`}
                    className="flex items-center justify-between border border-[#E5DFD2] bg-[#FAF8F3] px-4 py-3 text-xs hover:border-[#C5A25D]"
                  >
                    <div>
                      <p className="font-mono font-semibold text-[#111111]">
                        {sb.confirmationCode}
                      </p>
                      <p className="text-[#575147]">{sb.propertyName}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#8A6B2F]" aria-hidden="true" />
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
