import { describe, it, expect, beforeEach } from "vitest";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import {
  adminResolveRefund,
  createCryptoQuote,
  createInventoryHold,
  createReservationFromHold,
  createUsdPaymentSession,
  getReservationBundle,
  lookupReservationWithEmail,
  observeCryptoPayment,
  processWebhookEvent,
  requestCancellationAndRefund,
  runReconciliationSweep,
  searchAvailability,
} from "../lib/server/store";
import { signWebhookPayload } from "../lib/server/crypto-signing";
import {
  CRYPTO_ASSET_ALLOWLIST,
  usdCentsToTokenBaseUnits,
} from "../lib/crypto-assets";

function makeTempStore(): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "hosp-test-"));
  return path.join(dir, "store.json");
}

function futureDate(daysAhead: number): string {
  return new Date(Date.now() + daysAhead * 86_400_000)
    .toISOString()
    .slice(0, 10);
}

describe("Luxury Hospitality Reservation & Payment Engine", () => {
  let storePath: string;
  const checkIn = futureDate(10);
  const checkOut = futureDate(12);

  beforeEach(() => {
    storePath = makeTempStore();
  });

  it("validates stay dates, occupancy limits, and calculates server-side USD pricing", async () => {
    await expect(
      searchAvailability(
        {
          propertyIdOrSlug: "hudson-landmark-new-york",
          checkIn: futureDate(-2),
          checkOut,
          adults: 2,
          children: 0,
          roomCount: 1,
        },
        storePath
      )
    ).rejects.toThrow(/past/i);

    await expect(
      searchAvailability(
        {
          propertyIdOrSlug: "hudson-landmark-new-york",
          checkIn: checkOut,
          checkOut: checkIn,
          adults: 2,
          children: 0,
          roomCount: 1,
        },
        storePath
      )
    ).rejects.toThrow(/after arrival/i);

    const avail = await searchAvailability(
      {
        propertyIdOrSlug: "hudson-landmark-new-york",
        checkIn,
        checkOut,
        adults: 6,
        children: 0,
        roomCount: 1,
      },
      storePath
    );
    // Deluxe King maxOccupancy=3 -> invalid for 6 adults in 1 room
    const deluxe = avail.offers.find(
      (o) => o.roomType.id === "rt-hudson-deluxe"
    )!;
    expect(deluxe.occupancyValid).toBe(false);
    expect(deluxe.isAvailable).toBe(false);

    // Server-calculated pricing includes subtotal + resort fees + taxes
    const pricing = deluxe.rateOffers[0].pricing;
    expect(pricing.nights).toBe(2);
    expect(pricing.feesUsdCents).toBe(4500 * 2);
    expect(pricing.totalUsdCents).toBeGreaterThan(pricing.subtotalUsdCents);
  });

  it("prevents simultaneous double-booking of remaining inventory via atomic holds", async () => {
    // Penthouse has strictly 2 total units
    const requests = [1, 2, 3, 4].map(() =>
      createInventoryHold(
        {
          propertyId: "prop-hudson-landmark",
          roomTypeId: "rt-hudson-penthouse",
          ratePlanId: "rp-prop-hudson-landmark-bar",
          checkIn,
          checkOut,
          adults: 2,
          children: 0,
          roomCount: 1,
        },
        storePath
      )
    );

    const results = await Promise.allSettled(requests);
    const fulfilled = results.filter((r) => r.status === "fulfilled");
    const rejected = results.filter((r) => r.status === "rejected");

    expect(fulfilled.length).toBe(2);
    expect(rejected.length).toBe(2);
  });

  it("expires holds after TTL and releases inventory back to availability", async () => {
    const now = new Date();
    const hold = await createInventoryHold(
      {
        propertyId: "prop-hudson-landmark",
        roomTypeId: "rt-hudson-penthouse",
        ratePlanId: "rp-prop-hudson-landmark-bar",
        checkIn,
        checkOut,
        adults: 2,
        children: 0,
        roomCount: 2,
        ttlSeconds: 10,
        now,
      },
      storePath
    );
    expect(hold.status).toBe("active");

    // Sweep 15 seconds later
    const sweep = await runReconciliationSweep(
      storePath,
      new Date(now.getTime() + 15_000)
    );
    expect(sweep.expiredHolds).toBe(1);

    // Reservation creation from expired hold must fail
    await expect(
      createReservationFromHold(
        {
          holdId: hold.id,
          guestName: "Guest Test",
          guestEmail: "guest@example.com",
          guestPhone: "+12125550100",
          paymentMethod: "usd_card",
          acceptedPolicy: true,
        },
        storePath
      )
    ).rejects.toThrow(/expired/i);

    // Units are available again
    const avail = await searchAvailability(
      {
        propertyIdOrSlug: "hudson-landmark-new-york",
        checkIn,
        checkOut,
        adults: 2,
        children: 0,
        roomCount: 2,
      },
      storePath
    );
    const penthouse = avail.offers.find(
      (o) => o.roomType.id === "rt-hudson-penthouse"
    )!;
    expect(penthouse.availableUnits).toBe(2);
  });

  it("deduplicates checkout sessions, verifies webhooks, rejects bad signatures, and ignores duplicate events", async () => {
    const hold = await createInventoryHold(
      {
        propertyId: "prop-hudson-landmark",
        roomTypeId: "rt-hudson-deluxe",
        ratePlanId: "rp-prop-hudson-landmark-bar",
        checkIn,
        checkOut,
        adults: 2,
        children: 0,
        roomCount: 1,
      },
      storePath
    );

    const { reservation } = await createReservationFromHold(
      {
        holdId: hold.id,
        guestName: "Alex Mercer",
        guestEmail: "alex@example.com",
        guestPhone: "+12125550199",
        paymentMethod: "usd_card",
        acceptedPolicy: true,
      },
      storePath
    );

    // Fail-closed when live mode requested
    await expect(
      createUsdPaymentSession(
        {
          reservationId: reservation.id,
          idempotencyKey: "live-key-1234",
          mode: "live",
        },
        storePath
      )
    ).rejects.toThrow(/disabled/i);

    const firstSess = await createUsdPaymentSession(
      {
        reservationId: reservation.id,
        idempotencyKey: "idem-usd-001",
        mode: "demo",
      },
      storePath
    );
    const dupSess = await createUsdPaymentSession(
      {
        reservationId: reservation.id,
        idempotencyKey: "idem-usd-001",
        mode: "demo",
      },
      storePath
    );
    expect(dupSess.deduplicated).toBe(true);
    expect(dupSess.attempt.id).toBe(firstSess.attempt.id);

    const payload = JSON.stringify({
      externalEventId: "evt_unique_999",
      eventType: "payment.succeeded",
      attemptId: firstSess.attempt.id,
      reservationId: reservation.id,
    });

    // Invalid signature rejected
    const badSig = await processWebhookEvent(
      {
        rawBody: payload,
        signatureHeader: "sha256=" + "0".repeat(64),
        provider: "usd_demo",
      },
      storePath
    );
    expect(badSig.statusCode).toBe(401);
    expect(badSig.event.status).toBe("invalid_signature");

    // Valid signature confirms booking
    const validSig = signWebhookPayload(payload);
    const okRes = await processWebhookEvent(
      {
        rawBody: payload,
        signatureHeader: `sha256=${validSig}`,
        provider: "usd_demo",
      },
      storePath
    );
    expect(okRes.statusCode).toBe(200);
    expect(okRes.reservation?.reservationStatus).toBe("confirmed");
    expect(okRes.reservation?.paymentStatus).toBe("paid");
    expect(okRes.reservation?.fulfillmentStatus).toBe("ready_for_arrival");

    // Duplicate webhook ignored idempotently
    const dupRes = await processWebhookEvent(
      {
        rawBody: payload,
        signatureHeader: `sha256=${validSig}`,
        provider: "usd_demo",
      },
      storePath
    );
    expect(dupRes.event.status).toBe("duplicate_ignored");
  });

  it("handles late payment after hold expiry via reconciliation rather than silent overbooking", async () => {
    const t0 = new Date();
    const hold = await createInventoryHold(
      {
        propertyId: "prop-hudson-landmark",
        roomTypeId: "rt-hudson-penthouse",
        ratePlanId: "rp-prop-hudson-landmark-bar",
        checkIn,
        checkOut,
        adults: 2,
        children: 0,
        roomCount: 1,
        ttlSeconds: 5,
        now: t0,
      },
      storePath
    );
    const { reservation } = await createReservationFromHold(
      {
        holdId: hold.id,
        guestName: "Late Payer",
        guestEmail: "late@example.com",
        guestPhone: "+12125550122",
        paymentMethod: "usd_card",
        acceptedPolicy: true,
        now: t0,
      },
      storePath
    );
    const { attempt } = await createUsdPaymentSession(
      {
        reservationId: reservation.id,
        idempotencyKey: "late-pay-key",
        mode: "demo",
        now: t0,
      },
      storePath
    );

    // Expire the hold 10 seconds later
    await runReconciliationSweep(storePath, new Date(t0.getTime() + 10_000));

    // Late webhook arrives at t0 + 12s
    const payload = JSON.stringify({
      externalEventId: "evt_late_123",
      eventType: "payment.succeeded",
      attemptId: attempt.id,
      reservationId: reservation.id,
    });
    const sig = signWebhookPayload(payload);
    const lateOutcome = await processWebhookEvent(
      {
        rawBody: payload,
        signatureHeader: `sha256=${sig}`,
        provider: "usd_demo",
        now: new Date(t0.getTime() + 12_000),
      },
      storePath
    );

    expect(lateOutcome.event.status).toBe("reconciliation_queued");
    expect(lateOutcome.reservation?.reservationStatus).toBe(
      "reconciliation_required"
    );
    expect(lateOutcome.reservation?.fulfillmentStatus).toBe("on_hold");
  });

  it("enforces crypto allowlist, exact BigInt quote math, quote expiry, underpayment, overpayment, and network mismatch", async () => {
    // Non-1:1 USD1 precision verification
    const usd1 = CRYPTO_ASSET_ALLOWLIST["usd1-eth-erc20-sim"];
    const baseUnits = usdCentsToTokenBaseUnits(
      100000, // $1,000.00
      usd1.referenceUsdRateString, // 0.999400
      usd1.decimals,
      "up"
    );
    expect(baseUnits > 1_000_000_000n).toBe(true); // > 1000.000000 USD1 because USD1 = $0.9994

    const t0 = new Date();
    const hold = await createInventoryHold(
      {
        propertyId: "prop-hudson-landmark",
        roomTypeId: "rt-hudson-deluxe",
        ratePlanId: "rp-prop-hudson-landmark-bar",
        checkIn,
        checkOut,
        adults: 2,
        children: 0,
        roomCount: 1,
        now: t0,
      },
      storePath
    );
    const { reservation } = await createReservationFromHold(
      {
        holdId: hold.id,
        guestName: "Crypto Guest",
        guestEmail: "crypto@example.com",
        guestPhone: "+12125550177",
        paymentMethod: "trump_token",
        acceptedPolicy: true,
        now: t0,
      },
      storePath
    );

    const trump = CRYPTO_ASSET_ALLOWLIST["trump-solana-spl-sim"];

    // Unlisted token rejected
    await expect(
      createCryptoQuote(
        {
          reservationId: reservation.id,
          assetId: trump.assetId,
          network: "Wrong Chain",
          tokenIdentifier: trump.tokenIdentifier,
          mode: "demo",
          now: t0,
        },
        storePath
      )
    ).rejects.toThrow(/mismatch/i);

    const { quote } = await createCryptoQuote(
      {
        reservationId: reservation.id,
        assetId: trump.assetId,
        network: trump.network,
        tokenIdentifier: trump.tokenIdentifier,
        mode: "demo",
        quoteTtlSeconds: 60,
        now: t0,
      },
      storePath
    );

    // Wrong token/network observed
    const mismatch = await observeCryptoPayment(
      {
        quoteId: quote.id,
        observedNetwork: "Ethereum",
        observedTokenIdentifier: "FAKE:TOKEN",
        observedBaseUnits: quote.exactTokenBaseUnits,
        txHash: "0xbadnetwork123",
        confirmations: 32,
        now: t0,
      },
      storePath
    );
    expect(mismatch.quote.status).toBe("review_required");

    // Fresh quote for underpayment & overpayment tests
    const { quote: q2 } = await createCryptoQuote(
      {
        reservationId: reservation.id,
        assetId: trump.assetId,
        network: trump.network,
        tokenIdentifier: trump.tokenIdentifier,
        mode: "demo",
        quoteTtlSeconds: 60,
        now: t0,
      },
      storePath
    );
    const expected = BigInt(q2.exactTokenBaseUnits);

    const under = await observeCryptoPayment(
      {
        quoteId: q2.id,
        observedNetwork: q2.network,
        observedTokenIdentifier: q2.tokenIdentifier,
        observedBaseUnits: (expected - BigInt(100)).toString(),
        txHash: "0xunderpay123",
        confirmations: 32,
        now: t0,
      },
      storePath
    );
    expect(under.quote.status).toBe("underpaid");
    expect(under.reservation.paymentStatus).toBe("underpaid");

    const over = await observeCryptoPayment(
      {
        quoteId: q2.id,
        observedNetwork: q2.network,
        observedTokenIdentifier: q2.tokenIdentifier,
        observedBaseUnits: (expected + BigInt(50000)).toString(),
        txHash: "0xoverpay123",
        confirmations: 32,
        now: t0,
      },
      storePath
    );
    expect(over.quote.status).toBe("overpaid");
    expect(over.reservation.reservationStatus).toBe("reconciliation_required");

    // Expired quote test
    const expiredObs = await observeCryptoPayment(
      {
        quoteId: q2.id,
        observedNetwork: q2.network,
        observedTokenIdentifier: q2.tokenIdentifier,
        observedBaseUnits: expected.toString(),
        txHash: "0xlatequote123",
        confirmations: 32,
        now: new Date(t0.getTime() + 120_000),
      },
      storePath
    );
    expect(expiredObs.quote.status).toBe("review_required");
  });

  it("protects booking access tokens and enforces wallet-verified refund authorization", async () => {
    const hold = await createInventoryHold(
      {
        propertyId: "prop-hudson-landmark",
        roomTypeId: "rt-hudson-deluxe",
        ratePlanId: "rp-prop-hudson-landmark-bar",
        checkIn,
        checkOut,
        adults: 2,
        children: 0,
        roomCount: 1,
      },
      storePath
    );

    const { reservation, accessToken } = await createReservationFromHold(
      {
        holdId: hold.id,
        guestName: "Auth Guest",
        guestEmail: "authguest@example.com",
        guestPhone: "+12125550155",
        paymentMethod: "trump_token",
        acceptedPolicy: true,
      },
      storePath
    );

    // Reference alone without token must be denied
    const unauth = await getReservationBundle(
      { confirmationCode: reservation.confirmationCode },
      storePath
    );
    expect(unauth.authorized).toBe(false);

    // Valid token grants access
    const authd = await getReservationBundle(
      { confirmationCode: reservation.confirmationCode, accessToken },
      storePath
    );
    expect(authd.authorized).toBe(true);

    // Email + reference lookup succeeds
    const lookup = await lookupReservationWithEmail(
      {
        confirmationCode: reservation.confirmationCode,
        guestEmail: "authguest@example.com",
      },
      storePath
    );
    expect(lookup.found).toBe(true);

    // Settle via simulated crypto
    const trump = CRYPTO_ASSET_ALLOWLIST["trump-solana-spl-sim"];
    const { quote } = await createCryptoQuote(
      {
        reservationId: reservation.id,
        assetId: trump.assetId,
        network: trump.network,
        tokenIdentifier: trump.tokenIdentifier,
        mode: "demo",
      },
      storePath
    );
    await observeCryptoPayment(
      {
        quoteId: quote.id,
        observedNetwork: quote.network,
        observedTokenIdentifier: quote.tokenIdentifier,
        observedBaseUnits: quote.exactTokenBaseUnits,
        txHash: "0xsettled999",
        confirmations: quote.requiredConfirmations,
      },
      storePath
    );

    // Cancel and request refund
    const cancelRes = await requestCancellationAndRefund(
      {
        confirmationCode: reservation.confirmationCode,
        accessToken: lookup.accessToken,
        reason: "Schedule shifted",
        destinationWallet: "SimRefundWallet11111111111111",
      },
      storePath
    );
    expect(cancelRes.reservation.reservationStatus).toBe("cancelled");
    expect(cancelRes.refund).not.toBeNull();
    expect(cancelRes.refund?.netUsdRefundCents).toBe(reservation.totalUsdCents);
    expect(cancelRes.refund?.conversionTimestamp).toBeTruthy();

    // Admin approval without wallet verification must fail for crypto refund
    await expect(
      adminResolveRefund(
        {
          refundId: cancelRes.refund!.id,
          actorUid: "tom@ahyx.org",
          actorRole: "super_admin",
          decision: "approve",
          walletVerified: false,
        },
        storePath
      )
    ).rejects.toThrow(/wallet verification/i);

    const approved = await adminResolveRefund(
      {
        refundId: cancelRes.refund!.id,
        actorUid: "tom@ahyx.org",
        actorRole: "super_admin",
        decision: "approve",
        walletVerified: true,
      },
      storePath
    );
    expect(approved.status).toBe("completed");
  });
});
