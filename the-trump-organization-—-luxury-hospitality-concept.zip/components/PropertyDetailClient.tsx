"use client";

import React, { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  BedDouble,
  Check,
  Clock,
  MapPin,
  Maximize2,
  ShieldCheck,
  Users,
} from "lucide-react";
import type {
  PaymentMethod,
  PriceBreakdown,
  Property,
  RatePlan,
  RoomType,
} from "@/lib/types";
import { formatUsdCents } from "@/lib/crypto-assets";

interface RoomOffer {
  roomType: RoomType;
  availableUnits: number;
  isAvailable: boolean;
  occupancyValid: boolean;
  occupancyError?: string;
  rateOffers: {
    ratePlan: RatePlan;
    pricing: PriceBreakdown;
  }[];
}

interface PropertyDetailClientProps {
  property: Property;
  initialRooms: RoomType[];
  initialRatePlans: RatePlan[];
  defaultCheckIn: string;
  defaultCheckOut: string;
  defaultAdults: number;
  defaultChildren: number;
  defaultRooms: number;
  defaultPayment: PaymentMethod;
}

export function PropertyDetailClient({
  property,
  initialRooms,
  defaultCheckIn,
  defaultCheckOut,
  defaultAdults,
  defaultChildren,
  defaultRooms,
  defaultPayment,
}: PropertyDetailClientProps) {
  const router = useRouter();

  const [checkIn, setCheckIn] = useState(defaultCheckIn);
  const [checkOut, setCheckOut] = useState(defaultCheckOut);
  const [adults, setAdults] = useState(defaultAdults);
  const [children, setChildren] = useState(defaultChildren);
  const [roomCount, setRoomCount] = useState(defaultRooms);
  const [paymentMethod, setPaymentMethod] =
    useState<PaymentMethod>(defaultPayment);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nights, setNights] = useState(2);
  const [offers, setOffers] = useState<RoomOffer[]>([]);
  const [holdingKey, setHoldingKey] = useState<string | null>(null);
  const [holdError, setHoldError] = useState<string | null>(null);

  const runSearch = useCallback(async () => {
    await Promise.resolve();
    setLoading(true);
    setError(null);
    setHoldError(null);
    try {
      const res = await fetch("/api/availability", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          propertyIdOrSlug: property.slug,
          checkIn,
          checkOut,
          adults,
          children,
          roomCount,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Unable to search availability.");
        setOffers([]);
        return;
      }
      setNights(data.nights);
      setOffers(data.offers || []);
    } catch {
      setError("Network error while checking room availability.");
    } finally {
      setLoading(false);
    }
  }, [property.slug, checkIn, checkOut, adults, children, roomCount]);

  useEffect(() => {
    let active = true;
    (async () => {
      if (active) await runSearch();
    })();
    return () => {
      active = false;
    };
  }, [runSearch]);

  async function handleSelectOffer(roomTypeId: string, ratePlanId: string) {
    const key = `${roomTypeId}_${ratePlanId}`;
    setHoldingKey(key);
    setHoldError(null);
    try {
      const res = await fetch("/api/holds", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          propertyId: property.id,
          roomTypeId,
          ratePlanId,
          checkIn,
          checkOut,
          adults,
          children,
          roomCount,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setHoldError(
          data.error || "Unable to place temporary hold on this accommodation."
        );
        void runSearch();
        return;
      }
      router.push(
        `/reserve?holdId=${encodeURIComponent(data.hold.id)}&payment=${encodeURIComponent(paymentMethod)}`
      );
    } catch {
      setHoldError("Network error while securing inventory hold.");
    } finally {
      setHoldingKey(null);
    }
  }

  return (
    <div className="bg-[#FAF8F3] pb-20">
      {/* Hero Banner */}
      <section className="relative h-[420px] sm:h-[480px] bg-[#1D1B18] overflow-hidden">
        <Image
          src={property.heroImage}
          alt={property.name}
          fill
          priority
          sizes="100vw"
          className="object-cover"
          referrerPolicy="no-referrer"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent"
        />
        <div className="relative z-10 max-w-[1440px] mx-auto h-full px-5 sm:px-8 lg:px-12 pb-10 flex flex-col justify-end text-[#FAF8F3]">
          <p className="text-[11px] tracking-[0.24em] uppercase text-[#E2C27D] mb-2">
            {property.city}, {property.region} &middot; {property.country}
          </p>
          <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl text-balance max-w-3xl">
            {property.name}
          </h1>
          <p className="mt-3 text-sm sm:text-base text-[#FAF8F3]/90 max-w-2xl">
            {property.tagline}
          </p>
        </div>
      </section>

      <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 mt-12 grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left: Overview, Gallery, Amenities */}
        <div className="lg:col-span-4 space-y-8">
          <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
            <h2 className="font-serif text-2xl text-[#111111]">
              Property Overview
            </h2>
            <p className="text-sm text-[#4A453C] leading-relaxed">
              {property.description}
            </p>
            <div className="pt-3 border-t border-[#EBE4D6] flex items-start gap-2.5 text-xs text-[#575147]">
              <MapPin className="w-4 h-4 text-[#8A6B2F] shrink-0 mt-0.5" aria-hidden="true" />
              <span>{property.address}</span>
            </div>
          </div>

          <div className="bg-white border border-[#E2DACB] p-6 space-y-4">
            <h3 className="font-serif text-xl text-[#111111]">
              Signature Amenities
            </h3>
            <ul className="space-y-2.5 text-xs text-[#3D3830]">
              {property.amenities.map((am) => (
                <li key={am} className="flex items-center gap-2.5">
                  <Check className="w-3.5 h-3.5 text-[#8A6B2F] shrink-0" aria-hidden="true" />
                  <span>{am}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {property.galleryImages.slice(0, 2).map((img, i) => (
              <div
                key={i}
                className="relative aspect-[4/3] bg-[#221F1B] border border-[#E2DACB]"
              >
                <Image
                  src={img}
                  alt={`${property.name} architectural view ${i + 1}`}
                  fill
                  sizes="(max-width: 1024px) 50vw, 20vw"
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Right: Interactive Date Search + Room & Rate Selection */}
        <div className="lg:col-span-8 space-y-8">
          {/* Search Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void runSearch();
            }}
            className="bg-white border border-[#E2DACB] p-6"
          >
            <div className="flex items-center justify-between gap-4 mb-4">
              <h2 className="font-serif text-2xl text-[#111111]">
                Select Dates &amp; Accommodation
              </h2>
              <span className="text-[11px] tracking-[0.16em] uppercase text-[#8A6B2F]">
                15-Min Atomic Hold
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div>
                <label
                  htmlFor="prop-checkin"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1"
                >
                  Arrival
                </label>
                <input
                  id="prop-checkin"
                  type="date"
                  value={checkIn}
                  onChange={(e) => setCheckIn(e.target.value)}
                  className="w-full border border-[#D8D0C1] px-2.5 py-2 text-xs font-mono"
                />
              </div>
              <div>
                <label
                  htmlFor="prop-checkout"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1"
                >
                  Departure
                </label>
                <input
                  id="prop-checkout"
                  type="date"
                  value={checkOut}
                  onChange={(e) => setCheckOut(e.target.value)}
                  className="w-full border border-[#D8D0C1] px-2.5 py-2 text-xs font-mono"
                />
              </div>
              <div>
                <label
                  htmlFor="prop-adults"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1"
                >
                  Adults
                </label>
                <input
                  id="prop-adults"
                  type="number"
                  min={1}
                  max={16}
                  value={adults}
                  onChange={(e) => setAdults(Math.max(1, Number(e.target.value) || 1))}
                  className="w-full border border-[#D8D0C1] px-2.5 py-2 text-xs font-mono"
                />
              </div>
              <div>
                <label
                  htmlFor="prop-children"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1"
                >
                  Children
                </label>
                <input
                  id="prop-children"
                  type="number"
                  min={0}
                  max={12}
                  value={children}
                  onChange={(e) => setChildren(Math.max(0, Number(e.target.value) || 0))}
                  className="w-full border border-[#D8D0C1] px-2.5 py-2 text-xs font-mono"
                />
              </div>
              <div>
                <label
                  htmlFor="prop-rooms"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#686054] mb-1"
                >
                  Rooms
                </label>
                <input
                  id="prop-rooms"
                  type="number"
                  min={1}
                  max={8}
                  value={roomCount}
                  onChange={(e) => setRoomCount(Math.max(1, Number(e.target.value) || 1))}
                  className="w-full border border-[#D8D0C1] px-2.5 py-2 text-xs font-mono"
                />
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-[#EBE4D6] flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3 text-xs">
                <span className="text-[#686054]">Preferred settlement:</span>
                {(
                  [
                    { id: "usd_card", label: "US Dollars" },
                    { id: "trump_token", label: "$TRUMP (Sim)" },
                    { id: "usd1_stablecoin", label: "USD1 (Sim)" },
                  ] as const
                ).map((pm) => (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id)}
                    className={`px-3 py-1.5 border text-[11px] transition-colors ${
                      paymentMethod === pm.id
                        ? "border-[#C5A25D] bg-[#FAF8F3] font-semibold text-[#111111]"
                        : "border-[#E2DACB] text-[#575147]"
                    }`}
                  >
                    {pm.label}
                  </button>
                ))}
              </div>

              <button
                type="submit"
                disabled={loading}
                className="bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-6 py-2.5 text-[11px] tracking-[0.18em] uppercase font-medium"
              >
                {loading ? "Calculating..." : "Update Availability"}
              </button>
            </div>
          </form>

          {error && (
            <div
              role="alert"
              className="bg-[#FDF2F0] border border-[#E9C5BD] p-4 text-sm text-[#8C2D19]"
            >
              {error}
            </div>
          )}

          {holdError && (
            <div
              role="alert"
              className="bg-[#FDF2F0] border border-[#E9C5BD] p-4 text-sm text-[#8C2D19]"
            >
              {holdError}
            </div>
          )}

          {/* Room & Rate Offers */}
          {loading ? (
            <div className="space-y-4">
              {initialRooms.map((r) => (
                <div
                  key={r.id}
                  className="bg-white border border-[#E2DACB] p-6 animate-pulse h-44"
                />
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              {offers.map((offer) => (
                <article
                  key={offer.roomType.id}
                  className="bg-white border border-[#E2DACB] overflow-hidden"
                >
                  <div className="grid grid-cols-1 md:grid-cols-12">
                    <div className="md:col-span-4 relative min-h-[220px] bg-[#221F1B]">
                      <Image
                        src={offer.roomType.imageUrl}
                        alt={offer.roomType.name}
                        fill
                        sizes="(max-width: 768px) 100vw, 30vw"
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="md:col-span-8 p-6 space-y-4">
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <h3 className="font-serif text-2xl text-[#111111]">
                            {offer.roomType.name}
                          </h3>
                          <div className="mt-1.5 flex flex-wrap items-center gap-3 text-xs text-[#686054]">
                            <span className="inline-flex items-center gap-1">
                              <Maximize2 className="w-3.5 h-3.5" aria-hidden="true" />
                              {offer.roomType.sizeSqFt} sq ft
                            </span>
                            <span aria-hidden="true">&middot;</span>
                            <span className="inline-flex items-center gap-1">
                              <BedDouble className="w-3.5 h-3.5" aria-hidden="true" />
                              {offer.roomType.bedConfiguration}
                            </span>
                            <span aria-hidden="true">&middot;</span>
                            <span className="inline-flex items-center gap-1">
                              <Users className="w-3.5 h-3.5" aria-hidden="true" />
                              Up to {offer.roomType.maxOccupancy} guests/room
                            </span>
                          </div>
                        </div>

                        <span
                          className={`text-[11px] font-medium uppercase tracking-[0.15em] ${
                            offer.isAvailable
                              ? "text-[#2B593F]"
                              : "text-[#8C2D19]"
                          }`}
                        >
                          {offer.isAvailable
                            ? `${offer.availableUnits} unit(s) available`
                            : !offer.occupancyValid
                              ? "Capacity exceeded"
                              : "Sold out for dates"}
                        </span>
                      </div>

                      <p className="text-xs text-[#4A453C] leading-relaxed">
                        {offer.roomType.description}
                      </p>

                      {!offer.occupancyValid && offer.occupancyError && (
                        <p className="text-xs text-[#8C2D19] bg-[#FDF2F0] border border-[#E9C5BD] px-3 py-2">
                          {offer.occupancyError}
                        </p>
                      )}

                      {/* Rate Plans */}
                      <div className="pt-2 space-y-3">
                        {offer.rateOffers.map(({ ratePlan, pricing }) => {
                          const key = `${offer.roomType.id}_${ratePlan.id}`;
                          const isPending = holdingKey === key;
                          return (
                            <div
                              key={ratePlan.id}
                              className="border border-[#E5DFD2] bg-[#FAF8F3] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                            >
                              <div className="space-y-1 flex-1">
                                <div className="flex items-center gap-2">
                                  <p className="text-sm font-semibold text-[#111111]">
                                    {ratePlan.name}
                                  </p>
                                  <span className="text-[10px] font-mono text-[#686054]">
                                    {ratePlan.cancellationPolicyVersion}
                                  </span>
                                </div>
                                <p className="text-xs text-[#575147]">
                                  {ratePlan.cancellationSummary}
                                </p>
                                <p className="text-[11px] font-mono tabular-nums text-[#686054] pt-1">
                                  {nights} night(s) &times; {roomCount} room(s): Subtotal{" "}
                                  {formatUsdCents(pricing.subtotalUsdCents)}
                                  {pricing.discountUsdCents > 0
                                    ? ` \u2212 ${formatUsdCents(pricing.discountUsdCents)} discount`
                                    : ""}
                                  {" + "}
                                  {formatUsdCents(pricing.feesUsdCents)} fees +{" "}
                                  {formatUsdCents(pricing.taxesUsdCents)} taxes
                                </p>
                              </div>

                              <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                                <div className="text-right">
                                  <p className="text-[10px] uppercase tracking-[0.16em] text-[#686054]">
                                    Server-Calculated Total
                                  </p>
                                  <p className="font-mono tabular-nums text-lg font-semibold text-[#111111]">
                                    {formatUsdCents(pricing.totalUsdCents)} USD
                                  </p>
                                </div>
                                <button
                                  type="button"
                                  disabled={!offer.isAvailable || holdingKey !== null}
                                  onClick={() =>
                                    handleSelectOffer(
                                      offer.roomType.id,
                                      ratePlan.id
                                    )
                                  }
                                  className="inline-flex items-center gap-2 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-4 py-2.5 text-[10px] font-medium tracking-[0.18em] uppercase disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[#1E1E1E] transition-colors whitespace-nowrap"
                                >
                                  {isPending ? (
                                    <>
                                      <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                                      <span>Holding...</span>
                                    </>
                                  ) : (
                                    <>
                                      <ShieldCheck className="w-3.5 h-3.5 text-[#C5A25D]" aria-hidden="true" />
                                      <span>Hold &amp; Reserve</span>
                                      <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                                    </>
                                  )}
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
