"use client";

import React, { useState } from "react";
import Link from "next/link";
import { Building2, Menu, X } from "lucide-react";

const NAV_LINKS = [
  { label: "PROPERTIES", href: "/properties" },
  { label: "HOTELS", href: "/properties?category=city_landmark" },
  { label: "GOLF", href: "/properties?category=championship_golf" },
  { label: "RESIDENCES", href: "/properties?category=residence" },
  { label: "EXPERIENCES", href: "/experiences" },
];

export function SiteHeader() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F3]/95 backdrop-blur-sm border-b border-[#E5DFD2]">
      <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <Link
          href="/"
          className="flex items-center gap-3 text-[#111111] whitespace-nowrap shrink-0 group"
        >
          <Building2
            className="w-6 h-6 text-[#B6914B] transition-transform duration-200 group-hover:scale-105"
            strokeWidth={1.3}
            aria-hidden="true"
          />
          <span className="font-serif text-base sm:text-lg tracking-[0.22em] uppercase font-medium">
            The Trump Organization
          </span>
        </Link>

        {/* Zone 2: Primary Navigation */}
        <nav
          aria-label="Primary"
          className="hidden lg:flex items-center gap-8 text-[11px] font-medium tracking-[0.22em] text-[#222222]"
        >
          {NAV_LINKS.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-[#C5A25D] hover:text-[#111111] transition-colors duration-200"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <Link
            href="/properties"
            className="hidden sm:inline-flex items-center justify-center bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-6 py-2.5 text-[11px] font-medium tracking-[0.2em] uppercase hover:bg-[#1E1E1E] transition-colors duration-200 whitespace-nowrap shrink-0"
          >
            Reserve a Stay
          </Link>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? "Close navigation menu" : "Open navigation menu"}
            aria-expanded={mobileOpen}
            className="lg:hidden inline-flex items-center justify-center w-11 h-11 border border-[#E5DFD2] text-[#111111] hover:border-[#C5A25D] transition-colors"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <nav
          aria-label="Mobile Navigation"
          className="lg:hidden border-t border-[#E5DFD2] bg-[#FAF8F3] px-6 py-6 space-y-4"
        >
          <div className="flex flex-col space-y-3">
            {NAV_LINKS.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="py-2 text-xs font-medium tracking-[0.22em] uppercase text-[#111111] border-b border-[#E5DFD2]/60"
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/manage"
              onClick={() => setMobileOpen(false)}
              className="py-2 text-xs font-medium tracking-[0.22em] uppercase text-[#111111] border-b border-[#E5DFD2]/60"
            >
              Manage Booking
            </Link>
            <Link
              href="/contact"
              onClick={() => setMobileOpen(false)}
              className="py-2 text-xs font-medium tracking-[0.22em] uppercase text-[#111111] border-b border-[#E5DFD2]/60"
            >
              Contact
            </Link>
            <Link
              href="/admin"
              onClick={() => setMobileOpen(false)}
              className="py-2 text-xs font-medium tracking-[0.22em] uppercase text-[#666056]"
            >
              Administration
            </Link>
          </div>
          <Link
            href="/properties"
            onClick={() => setMobileOpen(false)}
            className="w-full inline-flex items-center justify-center bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-6 py-3 text-[11px] font-medium tracking-[0.2em] uppercase"
          >
            Reserve a Stay
          </Link>
        </nav>
      )}
    </header>
  );
}
