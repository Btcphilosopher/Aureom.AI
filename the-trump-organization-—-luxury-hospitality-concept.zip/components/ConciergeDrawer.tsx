"use client";

import React, { useState } from "react";
import Markdown from "react-markdown";
import { MessageSquare, Send, X } from "lucide-react";

interface ChatMessage {
  role: "user" | "model";
  text: string;
}

interface DraftEnquiry {
  subject: string;
  message: string;
  propertyId?: string;
}

export function ConciergeDrawer() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [modeLabel, setModeLabel] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "model",
      text: "Welcome to Private Client Concierge. I can retrieve live room availability, compare properties, clarify published booking terms, or draft a support enquiry for your confirmation.",
    },
  ]);

  const [draft, setDraft] = useState<DraftEnquiry | null>(null);
  const [guestName, setGuestName] = useState("");
  const [guestEmail, setGuestEmail] = useState("");
  const [submittingDraft, setSubmittingDraft] = useState(false);
  const [draftSubmitted, setDraftSubmitted] = useState<string | null>(null);

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || loading) return;

    const nextHistory = [...messages, { role: "user" as const, text: trimmed }];
    setMessages(nextHistory);
    setInput("");
    setLoading(true);
    setDraftSubmitted(null);

    try {
      const res = await fetch("/api/concierge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: trimmed,
          history: messages.slice(-8),
        }),
      });
      const data = await res.json();
      setModeLabel(
        data.mode === "live_gemini"
          ? "Gemini 4.0 Hydrogen"
          : "Offline Concierge Mode"
      );
      setMessages([
        ...nextHistory,
        {
          role: "model",
          text:
            data.reply ||
            data.error ||
            "I could not retrieve a response at this moment.",
        },
      ]);
      if (data.draftEnquiry) {
        setDraft(data.draftEnquiry);
      }
    } catch {
      setMessages([
        ...nextHistory,
        {
          role: "model",
          text: "Unable to reach the concierge service. Please try again or visit our Contact page.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function handleConfirmDraft(e: React.FormEvent) {
    e.preventDefault();
    if (!draft || !guestName.trim() || !guestEmail.trim()) return;
    setSubmittingDraft(true);
    try {
      const res = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          guestName,
          guestEmail,
          subject: draft.subject,
          message: draft.message,
          propertyId: draft.propertyId,
        }),
      });
      if (res.ok) {
        setDraftSubmitted(
          "Your enquiry has been confirmed and recorded with Private Client Services."
        );
        setDraft(null);
      }
    } finally {
      setSubmittingDraft(false);
    }
  }

  return (
    <>
      {!open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label="Open Private Concierge"
          className="fixed bottom-5 right-5 z-40 inline-flex items-center gap-2.5 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-5 py-3 text-[11px] font-medium tracking-[0.2em] uppercase shadow-xl hover:bg-[#1E1E1E] transition-colors"
        >
          <MessageSquare className="w-4 h-4 text-[#C5A25D]" aria-hidden="true" />
          <span>Concierge</span>
        </button>
      )}

      {open && (
        <section
          aria-label="Private Hospitality Concierge"
          className="fixed bottom-5 right-5 z-50 w-[calc(100vw-2.5rem)] max-w-[420px] bg-[#FAF8F3] border border-[#C5A25D] shadow-2xl flex flex-col max-h-[80vh]"
        >
          <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5DFD2] bg-[#111111] text-[#FAF8F3]">
            <div>
              <h3 className="font-serif text-lg tracking-wide">
                Private Concierge
              </h3>
              <p className="text-[10px] tracking-[0.18em] uppercase text-[#C5A25D]">
                {modeLabel || "Live Availability & Policy Guide"}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close Concierge"
              className="w-9 h-9 inline-flex items-center justify-center text-[#FAF8F3] hover:text-[#C5A25D]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`p-3 border ${
                  m.role === "user"
                    ? "bg-[#EFE9DC] border-[#DDD3BF] ml-6 text-[#111111]"
                    : "bg-white border-[#E5DFD2] mr-4 text-[#2A2620]"
                }`}
              >
                <div className="prose prose-xs max-w-none leading-relaxed">
                  <Markdown>{m.text}</Markdown>
                </div>
              </div>
            ))}

            {draft && (
              <form
                onSubmit={handleConfirmDraft}
                className="border border-[#C5A25D] bg-[#F5F0E4] p-3.5 space-y-2.5"
              >
                <p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#8A6B2F]">
                  Confirm Support Enquiry Draft
                </p>
                <p className="text-xs font-medium text-[#111111]">
                  {draft.subject}
                </p>
                <p className="text-xs text-[#4C453B] whitespace-pre-line">
                  {draft.message}
                </p>
                <input
                  type="text"
                  required
                  placeholder="Your full name"
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  className="w-full border border-[#D8D0C1] bg-white px-2.5 py-1.5 text-xs"
                />
                <input
                  type="email"
                  required
                  placeholder="Your email address"
                  value={guestEmail}
                  onChange={(e) => setGuestEmail(e.target.value)}
                  className="w-full border border-[#D8D0C1] bg-white px-2.5 py-1.5 text-xs"
                />
                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="submit"
                    disabled={submittingDraft}
                    className="flex-1 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-2 text-[10px] tracking-[0.18em] uppercase font-medium"
                  >
                    {submittingDraft ? "Sending..." : "Confirm & Send Enquiry"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setDraft(null)}
                    className="px-3 py-2 border border-[#D8D0C1] text-[10px] uppercase tracking-[0.14em]"
                  >
                    Dismiss
                  </button>
                </div>
              </form>
            )}

            {draftSubmitted && (
              <p className="text-xs text-[#2B593F] bg-[#EEF5F0] border border-[#B8D4C3] p-2.5">
                {draftSubmitted}
              </p>
            )}
          </div>

          <form
            onSubmit={handleSend}
            className="border-t border-[#E5DFD2] p-3 flex items-center gap-2 bg-white"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about availability, golf, or terms..."
              className="flex-1 text-xs px-3 py-2.5 border border-[#DDD5C7] bg-[#FAF8F3] focus:outline-none focus:border-[#C5A25D]"
            />
            <button
              type="submit"
              disabled={loading}
              aria-label="Send message"
              className="w-10 h-10 inline-flex items-center justify-center bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] hover:bg-[#1E1E1E]"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </section>
      )}
    </>
  );
}
