"use client";

import React, { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  Calendar,
  ChevronDown,
  MapPin,
  Search,
  Users,
} from "lucide-react";
import type { PaymentMethod, Property } from "@/lib/types";
import { formatUsdCents } from "@/lib/crypto-assets";

interface ReservationWidgetProps {
  properties: Property[];
}

function addDaysIso(days: number): string {
  const dt = new Date(Date.now() + days * 86_400_000);
  return dt.toISOString().slice(0, 10);
}

function formatReadableRange(checkIn: string, checkOut: string): string {
  const d1 = new Date(`${checkIn}T00:00:00Z`);
  const d2 = new Date(`${checkOut}T00:00:00Z`);
  if (Number.isNaN(d1.getTime()) || Number.isNaN(d2.getTime())) {
    return `${checkIn} — ${checkOut}`;
  }
  const day1 = d1.getUTCDate();
  const day2 = d2.getUTCDate();
  const month1 = d1.toLocaleString("en-US", { month: "long", timeZone: "UTC" });
  const month2 = d2.toLocaleString("en-US", { month: "long", timeZone: "UTC" });
  if (month1 === month2) {
    return `${day1}\u2014${day2} ${month1}`;
  }
  return `${day1} ${month1.slice(0, 3)} \u2014 ${day2} ${month2.slice(0, 3)}`;
}

export function ReservationWidget({ properties }: ReservationWidgetProps) {
  const router = useRouter();

  const defaultCheckIn = useMemo(() => addDaysIso(14), []);
  const defaultCheckOut = useMemo(() => addDaysIso(16), []);

  const [selectedSlug, setSelectedSlug] = useState(
    properties[0]?.slug || "hudson-landmark-new-york"
  );
  const [checkIn, setCheckIn] = useState(defaultCheckIn);
  const [checkOut, setCheckOut] = useState(defaultCheckOut);
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);
  const [roomCount, setRoomCount] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("usd_card");

  const [showDates, setShowDates] = useState(false);
  const [showGuests, setShowGuests] = useState(false);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [liveOffer, setLiveOffer] = useState<{
    totalUsdCents: number;
    nights: number;
    roomName: string;
    availableUnits: number;
  } | null>(null);

  const selectedProperty = useMemo(
    () => properties.find((p) => p.slug === selectedSlug) || properties[0],
    [properties, selectedSlug]
  );

  // Initial illustrative display matches mockup ($1,280.00 USD = 2 nights @ $640.00 starting rate)
  const isDefaultIllustrative =
    !liveOffer &&
    selectedSlug === (properties[0]?.slug || "hudson-landmark-new-york") &&
    checkIn === defaultCheckIn &&
    checkOut === defaultCheckOut &&
    adults === 2 &&
    children === 0 &&
    roomCount === 1;

  const displayedTotalCents = liveOffer
    ? liveOffer.totalUsdCents
    : (selectedProperty?.startingRateUsdCents || 64000) * 2 * roomCount;

  async function handleAvailabilitySearch() {
    setSearching(true);
    setSearchError(null);
    try {
      const res = await fetch("/api/availability", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          propertyIdOrSlug: selectedSlug,
          checkIn,
          checkOut,
          adults,
          children,
          roomCount,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLiveOffer(null);
        setSearchError(data.error || "Unable to verify availability.");
        return;
      }
      const firstAvailable = data.offers?.find(
        (o: { isAvailable: boolean }) => o.isAvailable
      );
      if (!firstAvailable) {
        setLiveOffer(null);
        setSearchError(
          data.offers?.[0]?.occupancyError ||
            "No rooms meet your occupancy and date requirements. Adjust guest count or rooms."
        );
        return;
      }
      setLiveOffer({
        totalUsdCents: firstAvailable.rateOffers[0].pricing.totalUsdCents,
        nights: data.nights,
        roomName: firstAvailable.roomType.name,
        availableUnits: firstAvailable.availableUnits,
      });
    } catch {
      setSearchError("Network error while checking availability.");
    } finally {
      setSearching(false);
    }
  }

  function handleContinue() {
    const qs = new URLSearchParams({
      checkIn,
      checkOut,
      adults: String(adults),
      children: String(children),
      rooms: String(roomCount),
      payment: paymentMethod,
    });
    router.push(`/properties/${selectedSlug}?${qs.toString()}`);
  }

  return (
    <aside
      id="reserve-panel"
      aria-label="Reservation planner"
      className="w-full max-w-[400px] bg-[#FAF8F3] border border-[#E2DACB] shadow-2xl p-6 sm:p-7 text-[#111111]"
    >
      <h2 className="font-serif text-[28px] leading-tight text-[#111111] mb-5">
        Plan your next stay
      </h2>

      <div className="border-t border-[#DFD7C8]">
        {/* Destination */}
        <div className="py-3 border-b border-[#DFD7C8]">
          <label
            htmlFor="hero-destination"
            className="flex items-center justify-between gap-3 cursor-pointer"
          >
            <span className="flex items-center gap-3 min-w-0 flex-1">
              <MapPin
                className="w-4 h-4 text-[#5C5549] shrink-0"
                strokeWidth={1.6}
                aria-hidden="true"
              />
              <select
                id="hero-destination"
                value={selectedSlug}
                onChange={(e) => {
                  setSelectedSlug(e.target.value);
                  setLiveOffer(null);
                  setSearchError(null);
                }}
                className="w-full bg-transparent text-sm font-medium text-[#111111] focus:outline-none cursor-pointer truncate pr-2"
              >
                {properties.map((p) => (
                  <option key={p.id} value={p.slug}>
                    {p.city} — {p.name}
                  </option>
                ))}
              </select>
            </span>
            <ChevronDown className="w-4 h-4 text-[#5C5549] shrink-0" aria-hidden="true" />
          </label>
        </div>

        {/* Dates */}
        <div className="py-3 border-b border-[#DFD7C8]">
          <button
            type="button"
            onClick={() => setShowDates((v) => !v)}
            aria-expanded={showDates}
            className="w-full flex items-center justify-between gap-3 text-left"
          >
            <span className="flex items-center gap-3 text-sm font-medium text-[#111111]">
              <Calendar
                className="w-4 h-4 text-[#5C5549] shrink-0"
                strokeWidth={1.6}
                aria-hidden="true"
              />
              <span>
                {isDefaultIllustrative
                  ? "18\u201420 December"
                  : formatReadableRange(checkIn, checkOut)}
              </span>
            </span>
            <ChevronDown
              className={`w-4 h-4 text-[#5C5549] transition-transform ${
                showDates ? "rotate-180" : ""
              }`}
              aria-hidden="true"
            />
          </button>

          {showDates && (
            <div className="mt-3 pt-3 border-t border-[#EBE4D6] grid grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="hero-checkin"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#6A6256] mb-1"
                >
                  Arrival
                </label>
                <input
                  id="hero-checkin"
                  type="date"
                  value={checkIn}
                  min={addDaysIso(0)}
                  onChange={(e) => {
                    setCheckIn(e.target.value);
                    setLiveOffer(null);
                  }}
                  className="w-full border border-[#D8D0C1] bg-white px-2.5 py-1.5 text-xs font-mono"
                />
              </div>
              <div>
                <label
                  htmlFor="hero-checkout"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#6A6256] mb-1"
                >
                  Departure
                </label>
                <input
                  id="hero-checkout"
                  type="date"
                  value={checkOut}
                  min={checkIn}
                  onChange={(e) => {
                    setCheckOut(e.target.value);
                    setLiveOffer(null);
                  }}
                  className="w-full border border-[#D8D0C1] bg-white px-2.5 py-1.5 text-xs font-mono"
                />
              </div>
            </div>
          )}
        </div>

        {/* Guests & Rooms */}
        <div className="py-3 border-b border-[#DFD7C8]">
          <button
            type="button"
            onClick={() => setShowGuests((v) => !v)}
            aria-expanded={showGuests}
            className="w-full flex items-center justify-between gap-3 text-left"
          >
            <span className="flex items-center gap-3 text-sm font-medium text-[#111111]">
              <Users
                className="w-4 h-4 text-[#5C5549] shrink-0"
                strokeWidth={1.6}
                aria-hidden="true"
              />
              <span>
                {adults + children} {adults + children === 1 ? "guest" : "guests"}
                {roomCount > 1 ? ` \u00b7 ${roomCount} rooms` : ""}
              </span>
            </span>
            <ChevronDown
              className={`w-4 h-4 text-[#5C5549] transition-transform ${
                showGuests ? "rotate-180" : ""
              }`}
              aria-hidden="true"
            />
          </button>

          {showGuests && (
            <div className="mt-3 pt-3 border-t border-[#EBE4D6] grid grid-cols-3 gap-2">
              <div>
                <label
                  htmlFor="hero-adults"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#6A6256] mb-1"
                >
                  Adults
                </label>
                <input
                  id="hero-adults"
                  type="number"
                  min={1}
                  max={12}
                  value={adults}
                  onChange={(e) => {
                    setAdults(Math.max(1, Number(e.target.value) || 1));
                    setLiveOffer(null);
                  }}
                  className="w-full border border-[#D8D0C1] bg-white px-2 py-1.5 text-xs font-mono"
                />
              </div>
              <div>
                <label
                  htmlFor="hero-children"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#6A6256] mb-1"
                >
                  Children
                </label>
                <input
                  id="hero-children"
                  type="number"
                  min={0}
                  max={12}
                  value={children}
                  onChange={(e) => {
                    setChildren(Math.max(0, Number(e.target.value) || 0));
                    setLiveOffer(null);
                  }}
                  className="w-full border border-[#D8D0C1] bg-white px-2 py-1.5 text-xs font-mono"
                />
              </div>
              <div>
                <label
                  htmlFor="hero-rooms"
                  className="block text-[10px] uppercase tracking-[0.16em] text-[#6A6256] mb-1"
                >
                  Rooms
                </label>
                <input
                  id="hero-rooms"
                  type="number"
                  min={1}
                  max={8}
                  value={roomCount}
                  onChange={(e) => {
                    setRoomCount(Math.max(1, Number(e.target.value) || 1));
                    setLiveOffer(null);
                  }}
                  className="w-full border border-[#D8D0C1] bg-white px-2 py-1.5 text-xs font-mono"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Total / Availability Offer Box */}
      <div className="mt-4 bg-[#F2ECE0] border border-[#E2DACB] px-4 py-3">
        <div className="flex items-baseline justify-between gap-2">
          <span className="text-sm font-medium text-[#111111]">
            {liveOffer ? "Calculated Offer" : "Total"}
          </span>
          <span className="font-mono tabular-nums text-base font-semibold text-[#111111]">
            {formatUsdCents(displayedTotalCents)} USD
          </span>
        </div>
        <div className="mt-1 flex items-center justify-between gap-2">
          <span className="text-[11px] italic text-[#686054]">
            {liveOffer
              ? `${liveOffer.nights} nights \u00b7 ${liveOffer.roomName} (${liveOffer.availableUnits} left)`
              : "Illustrative booking (starting rate basis)"}
          </span>
          <button
            type="button"
            onClick={handleAvailabilitySearch}
            disabled={searching}
            className="inline-flex items-center gap-1 text-[10px] uppercase tracking-[0.16em] font-semibold text-[#8A6B2F] hover:text-[#111111] transition-colors shrink-0"
          >
            <Search className="w-3 h-3" aria-hidden="true" />
            {searching ? "Checking..." : "Check Rates"}
          </button>
        </div>
      </div>

      {searchError && (
        <p
          role="alert"
          className="mt-2.5 text-xs text-[#8C2D19] bg-[#FDF2F0] border border-[#E9C5BD] px-3 py-2"
        >
          {searchError}
        </p>
      )}

      {/* Payment Method Selection */}
      <div className="mt-5">
        <p className="font-serif text-lg text-[#111111] mb-2.5">
          Choose your payment
        </p>

        <div className="space-y-2" role="radiogroup" aria-label="Payment method">
          {[
            {
              id: "usd_card" as PaymentMethod,
              label: "$ US dollars",
            },
            {
              id: "trump_token" as PaymentMethod,
              label: "$TRUMP Token",
            },
            {
              id: "usd1_stablecoin" as PaymentMethod,
              label: "USD1 Stablecoin",
            },
          ].map((opt) => {
            const active = paymentMethod === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                role="radio"
                aria-checked={active}
                onClick={() => setPaymentMethod(opt.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-left text-sm transition-colors border ${
                  active
                    ? "border-[#C5A25D] bg-white font-medium text-[#111111]"
                    : "border-[#DDD5C7] bg-[#FAF8F3] text-[#332F28] hover:border-[#C5A25D]/60"
                }`}
              >
                <span
                  className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                    active ? "border-[#111111]" : "border-[#9C9383]"
                  }`}
                >
                  {active && (
                    <span className="w-2 h-2 rounded-full bg-[#111111]" />
                  )}
                </span>
                <span>{opt.label}</span>
              </button>
            );
          })}
        </div>

        <p className="mt-2 text-[11px] italic text-[#686054]">
          Proposed crypto checkout &bull; Network and quote confirmed at checkout
        </p>
      </div>

      {/* Primary Action */}
      <button
        type="button"
        onClick={handleContinue}
        className="mt-5 w-full inline-flex items-center justify-center gap-2.5 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] py-3.5 px-5 text-[11px] font-medium tracking-[0.2em] uppercase hover:bg-[#1E1E1E] transition-colors"
      >
        <span>Continue to Reservation</span>
        <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
      </button>
    </aside>
  );
}
