"use client";

import React, { useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, MapPin } from "lucide-react";
import type { Property, PropertyCategory } from "@/lib/types";
import { formatUsdCents } from "@/lib/crypto-assets";

interface PropertiesCatalogClientProps {
  properties: Property[];
  initialCategory?: string;
}

const CATEGORY_TABS: { id: "all" | PropertyCategory; label: string }[] = [
  { id: "all", label: "All Properties" },
  { id: "city_landmark", label: "City Landmarks" },
  { id: "coastal_retreat", label: "Coastal Retreats" },
  { id: "championship_golf", label: "Championship Golf" },
  { id: "residence", label: "Residences" },
];

const CATEGORY_LABELS: Record<PropertyCategory, string> = {
  city_landmark: "City Landmark",
  coastal_retreat: "Coastal Retreat",
  championship_golf: "Championship Golf",
  residence: "Private Residence",
};

export function PropertiesCatalogClient({
  properties,
  initialCategory,
}: PropertiesCatalogClientProps) {
  const validInit =
    initialCategory &&
    CATEGORY_TABS.some((t) => t.id === initialCategory)
      ? (initialCategory as "all" | PropertyCategory)
      : "all";

  const [category, setCategory] = useState<"all" | PropertyCategory>(validInit);
  const [cityFilter, setCityFilter] = useState("all");

  const cities = useMemo(
    () => Array.from(new Set(properties.map((p) => p.city))),
    [properties]
  );

  const filtered = useMemo(() => {
    return properties.filter((p) => {
      if (category !== "all" && p.category !== category) return false;
      if (cityFilter !== "all" && p.city !== cityFilter) return false;
      return true;
    });
  }, [properties, category, cityFilter]);

  return (
    <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 py-12 sm:py-16">
      <div className="max-w-2xl mb-10">
        <p className="text-[11px] font-medium tracking-[0.24em] uppercase text-[#8A6B2F] mb-3">
          Fictional Demonstration Collection
        </p>
        <h1 className="font-serif text-4xl sm:text-5xl text-[#111111] text-balance">
          Landmark Stays &amp; Private Estates
        </h1>
        <p className="mt-4 text-sm sm:text-base text-[#4A453C] leading-relaxed">
          Displayed rates indicate illustrative starting nightly tariffs before
          taxes and resort fees. Select a property to calculate live availability
          and exact USD stay pricing.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 border-b border-[#E2DACB]">
        <div
          role="tablist"
          aria-label="Property categories"
          className="flex flex-wrap items-center gap-2"
        >
          {CATEGORY_TABS.map((tab) => {
            const active = category === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setCategory(tab.id)}
                className={`px-4 py-2 text-[11px] tracking-[0.18em] uppercase border transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? "bg-[#111111] text-[#FAF8F3] border-[#C5A25D]"
                    : "bg-[#FAF8F3] text-[#332F28] border-[#DFD7C8] hover:border-[#C5A25D]"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-3">
          <label
            htmlFor="city-filter"
            className="text-[11px] tracking-[0.18em] uppercase text-[#686054] whitespace-nowrap"
          >
            Destination
          </label>
          <select
            id="city-filter"
            value={cityFilter}
            onChange={(e) => setCityFilter(e.target.value)}
            className="border border-[#DFD7C8] bg-white px-3.5 py-2 text-xs text-[#111111] focus:border-[#C5A25D]"
          >
            <option value="all">All Destinations</option>
            {cities.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Property Grid */}
      {filtered.length === 0 ? (
        <div className="py-20 text-center border border-[#E2DACB] bg-white mt-8">
          <p className="font-serif text-2xl text-[#111111] mb-2">
            No properties match the selected filters.
          </p>
          <button
            type="button"
            onClick={() => {
              setCategory("all");
              setCityFilter("all");
            }}
            className="mt-4 px-5 py-2.5 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] text-[11px] tracking-[0.18em] uppercase"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((prop) => (
            <article
              key={prop.id}
              className="bg-white border border-[#E2DACB] flex flex-col justify-between group"
            >
              <div>
                <Link
                  href={`/properties/${prop.slug}`}
                  className="block relative aspect-[4/3] overflow-hidden bg-[#221F1B]"
                >
                  <Image
                    src={prop.heroImage}
                    alt={prop.name}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                    referrerPolicy="no-referrer"
                  />
                </Link>

                <div className="p-6 space-y-3">
                  <div className="flex items-center gap-2 text-[11px] tracking-[0.16em] uppercase text-[#8A6B2F]">
                    <span>{CATEGORY_LABELS[prop.category]}</span>
                    <span aria-hidden="true">&middot;</span>
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="w-3 h-3" aria-hidden="true" />
                      {prop.city}, {prop.country}
                    </span>
                  </div>

                  <h2 className="font-serif text-2xl text-[#111111]">
                    <Link
                      href={`/properties/${prop.slug}`}
                      className="hover:text-[#8A6B2F] transition-colors"
                    >
                      {prop.name}
                    </Link>
                  </h2>

                  <p className="text-xs text-[#575147] leading-relaxed">
                    {prop.tagline}
                  </p>
                </div>
              </div>

              <div className="px-6 py-4 border-t border-[#EBE4D6] bg-[#FAF8F3]/70 flex items-center justify-between gap-4">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.16em] text-[#686054]">
                    Starting Nightly Rate
                  </p>
                  <p className="font-mono tabular-nums text-sm font-semibold text-[#111111]">
                    {formatUsdCents(prop.startingRateUsdCents)} USD
                  </p>
                </div>

                <Link
                  href={`/properties/${prop.slug}`}
                  className="inline-flex items-center gap-2 bg-[#111111] text-[#FAF8F3] border border-[#C5A25D] px-4 py-2.5 text-[10px] font-medium tracking-[0.18em] uppercase hover:bg-[#1E1E1E] transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Check Dates</span>
                  <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
                </Link>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
