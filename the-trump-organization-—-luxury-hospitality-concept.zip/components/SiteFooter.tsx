import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="bg-[#FAF8F3] border-t border-[#E5DFD2] text-[#111111]">
      <div className="border-b border-[#E5DFD2] py-4 px-5 text-center">
        <p className="text-[10px] sm:text-[11px] tracking-[0.24em] uppercase text-[#4A453C]">
          Independent Design Concept &nbsp;&bull;&nbsp; Illustrative Pricing &nbsp;&bull;&nbsp; Proposed Payment Options
        </p>
      </div>

      <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 py-12 grid grid-cols-1 md:grid-cols-4 gap-10">
        <div className="md:col-span-2 space-y-3">
          <p className="font-serif text-lg tracking-[0.2em] uppercase">
            The Trump Organization
          </p>
          <p className="text-xs leading-relaxed text-[#575147] max-w-md">
            Independent architectural hospitality and reservation concept. All properties,
            room inventory, rates, and proposed digital asset settlement options ($TRUMP
            Token and USD1 Stablecoin) are presented exclusively for demonstration and are
            not confirmed acceptance by the real organization.
          </p>
        </div>

        <div className="space-y-3">
          <p className="text-[11px] font-semibold tracking-[0.2em] uppercase text-[#8A6B2F]">
            Collection
          </p>
          <ul className="space-y-2 text-xs text-[#3D3830]">
            <li>
              <Link href="/properties" className="hover:text-[#111111] underline-offset-4 hover:underline">
                All Properties
              </Link>
            </li>
            <li>
              <Link href="/properties?category=city_landmark" className="hover:text-[#111111] underline-offset-4 hover:underline">
                City Landmarks
              </Link>
            </li>
            <li>
              <Link href="/properties?category=coastal_retreat" className="hover:text-[#111111] underline-offset-4 hover:underline">
                Coastal Retreats
              </Link>
            </li>
            <li>
              <Link href="/properties?category=championship_golf" className="hover:text-[#111111] underline-offset-4 hover:underline">
                Championship Golf
              </Link>
            </li>
            <li>
              <Link href="/experiences" className="hover:text-[#111111] underline-offset-4 hover:underline">
                Private Experiences
              </Link>
            </li>
          </ul>
        </div>

        <div className="space-y-3">
          <p className="text-[11px] font-semibold tracking-[0.2em] uppercase text-[#8A6B2F]">
            Guest Services
          </p>
          <ul className="space-y-2 text-xs text-[#3D3830]">
            <li>
              <Link href="/manage" className="hover:text-[#111111] underline-offset-4 hover:underline">
                Manage Reservation
              </Link>
            </li>
            <li>
              <Link href="/contact" className="hover:text-[#111111] underline-offset-4 hover:underline">
                Private Client Services
              </Link>
            </li>
            <li>
              <Link href="/terms" className="hover:text-[#111111] underline-offset-4 hover:underline">
                Privacy &amp; Booking Terms
              </Link>
            </li>
            <li>
              <Link href="/admin" className="hover:text-[#111111] underline-offset-4 hover:underline">
                Demonstration Administration
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
