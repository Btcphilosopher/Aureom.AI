export type PropertyCategory =
  | "city_landmark"
  | "coastal_retreat"
  | "championship_golf"
  | "residence";

export type PaymentMethod = "usd_card" | "trump_token" | "usd1_stablecoin";

export type HoldStatus = "active" | "converted" | "expired" | "released";

export type ReservationStatus =
  | "pending_payment"
  | "confirmed"
  | "cancelled"
  | "reconciliation_required"
  | "expired";

export type PaymentStatus =
  | "unpaid"
  | "awaiting_payment"
  | "confirming"
  | "paid"
  | "failed"
  | "underpaid"
  | "overpaid"
  | "refund_pending"
  | "refunded"
  | "reconciliation_required";

export type FulfillmentStatus =
  | "pending"
  | "ready_for_arrival"
  | "checked_in"
  | "cancelled"
  | "on_hold";

export type PaymentAttemptStatus =
  | "initiated"
  | "awaiting_payment"
  | "transaction_observed"
  | "confirming"
  | "paid"
  | "failed"
  | "expired"
  | "underpaid"
  | "overpaid"
  | "review_required";

export type CryptoQuoteStatus =
  | "quote_created"
  | "awaiting_payment"
  | "transaction_observed"
  | "confirming"
  | "paid"
  | "expired"
  | "underpaid"
  | "overpaid"
  | "review_required";

export type RefundStatus =
  | "requested"
  | "approved"
  | "rejected"
  | "processing"
  | "completed"
  | "failed";

export type AdminRole =
  | "super_admin"
  | "reservations_manager"
  | "finance_operator";

export interface Property {
  id: string;
  slug: string;
  name: string;
  category: PropertyCategory;
  city: string;
  region: string;
  country: string;
  address: string;
  tagline: string;
  description: string;
  heroImage: string;
  galleryImages: string[];
  amenities: string[];
  startingRateUsdCents: number;
  resortFeeUsdCentsPerNight: number;
  taxRateBps: number;
  active: boolean;
  demoOnly: boolean;
}

export interface RoomType {
  id: string;
  propertyId: string;
  slug: string;
  name: string;
  description: string;
  maxAdults: number;
  maxChildren: number;
  maxOccupancy: number;
  totalUnits: number;
  sizeSqFt: number;
  bedConfiguration: string;
  amenities: string[];
  baseRateUsdCents: number;
  imageUrl: string;
}

export interface NightlyInventory {
  id: string;
  propertyId: string;
  roomTypeId: string;
  date: string; // YYYY-MM-DD
  totalUnits: number;
  heldUnits: number;
  bookedUnits: number;
  overrideRateUsdCents?: number;
}

export interface RatePlan {
  id: string;
  propertyId: string;
  code: string;
  name: string;
  description: string;
  multiplierBps: number; // 10000 = 1.0x
  discountBps: number; // e.g., 1000 = 10%
  refundable: boolean;
  cancellationPolicyVersion: string;
  cancellationSummary: string;
  freeCancellationHoursBeforeCheckIn: number;
}

export interface NightlyRateLine {
  date: string;
  baseRateUsdCents: number;
  adjustedRateUsdCents: number;
}

export interface PriceBreakdown {
  nights: number;
  roomCount: number;
  nightlyLines: NightlyRateLine[];
  subtotalUsdCents: number;
  discountUsdCents: number;
  feesUsdCents: number;
  taxesUsdCents: number;
  totalUsdCents: number;
  startingNightlyUsdCents: number;
  averageNightlyUsdCents: number;
}

export interface ReservationHold {
  id: string;
  propertyId: string;
  roomTypeId: string;
  ratePlanId: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  roomCount: number;
  status: HoldStatus;
  pricing: PriceBreakdown;
  rateSnapshot: {
    ratePlanCode: string;
    ratePlanName: string;
    multiplierBps: number;
    discountBps: number;
    roomTypeName: string;
  };
  policySnapshot: {
    version: string;
    refundable: boolean;
    summary: string;
    freeCancellationHoursBeforeCheckIn: number;
  };
  expiresAt: string;
  createdAt: string;
}

export interface Guest {
  id: string;
  uid?: string;
  fullName: string;
  email: string;
  phone: string;
  country: string;
  createdAt: string;
}

export interface Reservation {
  id: string;
  confirmationCode: string;
  accessTokenHash: string;
  propertyId: string;
  propertyName: string;
  propertySlug: string;
  roomTypeId: string;
  roomTypeName: string;
  ratePlanId: string;
  ratePlanName: string;
  holdId: string;
  guestId: string;
  guestUid?: string;
  guestEmail: string;
  guestName: string;
  guestPhone: string;
  specialRequests?: string;
  checkIn: string;
  checkOut: string;
  nights: number;
  adults: number;
  children: number;
  roomCount: number;
  reservationStatus: ReservationStatus;
  paymentStatus: PaymentStatus;
  fulfillmentStatus: FulfillmentStatus;
  currency: "USD";
  pricing: PriceBreakdown;
  totalUsdCents: number;
  paidUsdCents: number;
  paymentMethod: PaymentMethod;
  rateSnapshot: ReservationHold["rateSnapshot"];
  cancellationPolicySnapshot: ReservationHold["policySnapshot"] & {
    acceptedAt: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface PaymentAttempt {
  id: string;
  reservationId: string;
  method: PaymentMethod;
  mode: "demo" | "live";
  status: PaymentAttemptStatus;
  amountUsdCents: number;
  providerSessionId: string;
  idempotencyKey: string;
  quoteId?: string;
  txHash?: string;
  observedNetwork?: string;
  observedTokenIdentifier?: string;
  observedBaseUnits?: string;
  confirmations: number;
  requiredConfirmations: number;
  failureReason?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CryptoAssetConfig {
  assetId: string;
  paymentMethod: "trump_token" | "usd1_stablecoin";
  ticker: "$TRUMP" | "USD1";
  assetName: string;
  network: string;
  tokenIdentifier: string;
  decimals: number;
  liveSupported: boolean;
  simulationOnly: boolean;
  referenceUsdRateString: string;
  rateSource: string;
  networkFeeUsdCents: number;
  requiredConfirmations: number;
  demoDepositAddress: string;
  notes: string;
}

export interface CryptoQuote {
  id: string;
  reservationId: string;
  assetId: string;
  ticker: "$TRUMP" | "USD1";
  network: string;
  tokenIdentifier: string;
  decimals: number;
  usdAmountCents: number;
  feeUsdCents: number;
  totalPayableUsdCents: number;
  exchangeRateUsdPerTokenString: string;
  rateSource: string;
  rateTimestamp: string;
  exactTokenBaseUnits: string;
  displayTokenAmount: string;
  destinationAddress: string;
  requiredConfirmations: number;
  status: CryptoQuoteStatus;
  mode: "demo" | "live";
  expiresAt: string;
  createdAt: string;
}

export interface Refund {
  id: string;
  reservationId: string;
  confirmationCode: string;
  paymentAttemptId?: string;
  requestedBy: string;
  approvedBy?: string;
  status: RefundStatus;
  usdEntitlementCents: number;
  feeUsdCents: number;
  netUsdRefundCents: number;
  refundMethod: PaymentMethod;
  tokenAssetId?: string;
  tokenTicker?: "$TRUMP" | "USD1";
  tokenAmountBaseUnits?: string;
  displayTokenAmount?: string;
  conversionTimestamp?: string;
  destinationWallet?: string;
  walletVerified: boolean;
  reason: string;
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface WebhookEvent {
  id: string;
  provider: string;
  externalEventId: string;
  eventType: string;
  signatureValid: boolean;
  payloadSummary: string;
  status:
    | "processed"
    | "duplicate_ignored"
    | "invalid_signature"
    | "reconciliation_queued";
  reservationId?: string;
  createdAt: string;
}

export interface AdminUser {
  uid: string;
  email: string;
  role: AdminRole;
  active: boolean;
  createdAt: string;
}

export interface AuditEvent {
  id: string;
  actorUid: string;
  actorRole: string;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  createdAt: string;
}

export interface Enquiry {
  id: string;
  reservationId?: string;
  propertyId?: string;
  guestUid?: string;
  guestName: string;
  guestEmail: string;
  subject: string;
  message: string;
  status: "open" | "in_review" | "resolved";
  createdAt: string;
}

export interface EmailOutbox {
  id: string;
  to: string;
  subject: string;
  template: string;
  bodyPreview: string;
  status: "queued" | "simulated_sent" | "provider_confirmed";
  reservationId?: string;
  createdAt: string;
}

export interface ExperienceItem {
  id: string;
  slug: string;
  propertyId: string;
  propertyName: string;
  category: "golf" | "coastal" | "culinary" | "wellness" | "residence";
  title: string;
  subtitle: string;
  description: string;
  duration: string;
  startingPriceUsdCents: number;
  imageUrl: string;
}

export interface SystemIntegrationConfig {
  liveUsdEnabled: boolean;
  liveCryptoEnabled: boolean;
  demoModeEnabled: boolean;
  emailAdapterMode: "local_outbox_preview" | "smtp_configured";
  geminiConciergeMode: "live_gemini" | "offline_mock";
  updatedAt: string;
}
