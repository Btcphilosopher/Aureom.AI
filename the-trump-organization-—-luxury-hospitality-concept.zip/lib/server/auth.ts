import { initializeApp, getApps } from "firebase-admin/app";
import { getAuth, type DecodedIdToken } from "firebase-admin/auth";
import firebaseConfig from "../../firebase-applet-config.json";
import type { AdminRole } from "../types";

if (!getApps().length) {
  initializeApp({
    projectId: firebaseConfig.projectId,
  });
}

const adminAuth = getAuth();

export const BOOTSTRAPPED_ADMIN_EMAILS: Record<string, AdminRole> = {
  "tom@ahyx.org": "super_admin",
};

export async function verifyBearerUser(
  authHeader: string | null
): Promise<DecodedIdToken | null> {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return null;
  }
  const token = authHeader.slice("Bearer ".length).trim();
  if (!token) return null;
  try {
    const decoded = await adminAuth.verifyIdToken(token);
    return decoded;
  } catch {
    return null;
  }
}
