import crypto from "node:crypto";

const DEFAULT_DEV_RESERVATION_SECRET = "demo-dev-only-reservation-signing-key-2026";
const DEFAULT_DEV_WEBHOOK_SECRET = "demo-dev-only-webhook-hmac-secret-2026";

function getReservationSecret(): string {
  return process.env.RESERVATION_SIGNING_SECRET || DEFAULT_DEV_RESERVATION_SECRET;
}

export function getWebhookSecret(): string {
  return process.env.WEBHOOK_SIGNING_SECRET || DEFAULT_DEV_WEBHOOK_SECRET;
}

/**
 * Generates an unpredictable confirmation code (e.g., TRM-8F3K9A2C).
 * Even with non-sequential codes, booking access ALWAYS requires an
 * accompanying cryptographic access token or authenticated owner UID.
 */
export function generateConfirmationCode(): string {
  const random = crypto.randomBytes(4).toString("hex").toUpperCase();
  return `TRM-${random}`;
}

export function generateAccessToken(): { token: string; tokenHash: string } {
  const token = crypto.randomBytes(24).toString("base64url");
  const tokenHash = hashAccessToken(token);
  return { token, tokenHash };
}

export function hashAccessToken(token: string): string {
  return crypto
    .createHmac("sha256", getReservationSecret())
    .update(token)
    .digest("hex");
}

export function verifyAccessToken(token: string, expectedHash: string): boolean {
  if (!token || !expectedHash) return false;
  const computed = hashAccessToken(token);
  const bufA = Buffer.from(computed, "hex");
  const bufB = Buffer.from(expectedHash, "hex");
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

export function signWebhookPayload(rawBody: string): string {
  return crypto
    .createHmac("sha256", getWebhookSecret())
    .update(rawBody)
    .digest("hex");
}

export function verifyWebhookSignature(
  rawBody: string,
  signatureHeader: string | null | undefined
): boolean {
  if (!signatureHeader) return false;
  const cleaned = signatureHeader.replace(/^sha256=/i, "").trim();
  if (!/^[a-f0-9]{64}$/i.test(cleaned)) return false;
  const expected = signWebhookPayload(rawBody);
  const bufA = Buffer.from(expected, "hex");
  const bufB = Buffer.from(cleaned.toLowerCase(), "hex");
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}
