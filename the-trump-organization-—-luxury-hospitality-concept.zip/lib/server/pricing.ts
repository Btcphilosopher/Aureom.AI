import type {
  NightlyInventory,
  NightlyRateLine,
  PriceBreakdown,
  Property,
  RatePlan,
  RoomType,
} from "../types";

export interface DateRangeValidation {
  valid: boolean;
  error?: string;
  nights: number;
  dates: string[]; // Each night check-in date (excludes checkout date)
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function parseUtcDate(dateStr: string): Date | null {
  if (!DATE_RE.test(dateStr)) return null;
  const [y, m, d] = dateStr.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (
    dt.getUTCFullYear() !== y ||
    dt.getUTCMonth() !== m - 1 ||
    dt.getUTCDate() !== d
  ) {
    return null;
  }
  return dt;
}

export function formatUtcDate(dt: Date): string {
  return dt.toISOString().slice(0, 10);
}

export function validateStayDates(
  checkIn: string,
  checkOut: string,
  referenceDateStr?: string
): DateRangeValidation {
  const start = parseUtcDate(checkIn);
  const end = parseUtcDate(checkOut);
  if (!start || !end) {
    return {
      valid: false,
      error: "Arrival and departure dates must be valid YYYY-MM-DD calendar dates.",
      nights: 0,
      dates: [],
    };
  }

  const today = referenceDateStr
    ? parseUtcDate(referenceDateStr)
    : parseUtcDate(new Date().toISOString().slice(0, 10));

  if (today && start.getTime() < today.getTime()) {
    return {
      valid: false,
      error: "Arrival date cannot be in the past.",
      nights: 0,
      dates: [],
    };
  }

  const diffMs = end.getTime() - start.getTime();
  const nights = Math.round(diffMs / 86_400_000);
  if (nights < 1) {
    return {
      valid: false,
      error: "Departure date must be at least one night after arrival date.",
      nights: 0,
      dates: [],
    };
  }
  if (nights > 30) {
    return {
      valid: false,
      error: "Online reservations are limited to 30 nights. Please contact Private Client Services for extended residences.",
      nights: 0,
      dates: [],
    };
  }

  const dates: string[] = [];
  for (let i = 0; i < nights; i++) {
    const nightDt = new Date(start.getTime() + i * 86_400_000);
    dates.push(formatUtcDate(nightDt));
  }

  return { valid: true, nights, dates };
}

export function validateOccupancy(
  roomType: RoomType,
  adults: number,
  children: number,
  roomCount: number
): { valid: boolean; error?: string } {
  if (!Number.isInteger(adults) || adults < 1) {
    return { valid: false, error: "At least 1 adult guest is required." };
  }
  if (!Number.isInteger(children) || children < 0) {
    return { valid: false, error: "Children count cannot be negative." };
  }
  if (!Number.isInteger(roomCount) || roomCount < 1 || roomCount > 8) {
    return { valid: false, error: "Room count must be between 1 and 8." };
  }
  if (adults < roomCount) {
    return {
      valid: false,
      error: "At least one adult is required per reserved room.",
    };
  }
  if (adults > roomType.maxAdults * roomCount) {
    return {
      valid: false,
      error: `${roomType.name} accommodates up to ${roomType.maxAdults} adults per room (${roomType.maxAdults * roomCount} max for ${roomCount} room(s)).`,
    };
  }
  if (children > roomType.maxChildren * roomCount) {
    return {
      valid: false,
      error: `${roomType.name} accommodates up to ${roomType.maxChildren} children per room (${roomType.maxChildren * roomCount} max for ${roomCount} room(s)).`,
    };
  }
  if (adults + children > roomType.maxOccupancy * roomCount) {
    return {
      valid: false,
      error: `Total guests (${adults + children}) exceeds maximum capacity (${roomType.maxOccupancy * roomCount}) for ${roomCount} × ${roomType.name}.`,
    };
  }
  return { valid: true };
}

/**
 * Deterministic server-side USD pricing calculation using integer minor units (cents).
 */
export function calculateStayPricing(params: {
  property: Property;
  roomType: RoomType;
  ratePlan: RatePlan;
  dates: string[];
  roomCount: number;
  inventoryByDate: Map<string, NightlyInventory>;
}): PriceBreakdown {
  const { property, roomType, ratePlan, dates, roomCount, inventoryByDate } = params;
  const nights = dates.length;
  const nightlyLines: NightlyRateLine[] = [];

  let rawRoomSubtotalCents = 0;

  for (const date of dates) {
    const inv = inventoryByDate.get(date);
    const dt = parseUtcDate(date);
    const dayOfWeek = dt ? dt.getUTCDay() : 0;
    const isWeekend = dayOfWeek === 5 || dayOfWeek === 6;

    const baseNightCents =
      inv?.overrideRateUsdCents ??
      (isWeekend
        ? Math.round((roomType.baseRateUsdCents * 10800) / 10000)
        : roomType.baseRateUsdCents);

    const planAdjustedNightCents = Math.round(
      (baseNightCents * ratePlan.multiplierBps) / 10000
    );

    nightlyLines.push({
      date,
      baseRateUsdCents: baseNightCents,
      adjustedRateUsdCents: planAdjustedNightCents,
    });

    rawRoomSubtotalCents += planAdjustedNightCents * roomCount;
  }

  const discountUsdCents = Math.round(
    (rawRoomSubtotalCents * ratePlan.discountBps) / 10000
  );
  const netRoomSubtotalCents = rawRoomSubtotalCents - discountUsdCents;
  const feesUsdCents =
    property.resortFeeUsdCentsPerNight * nights * roomCount;
  const taxesUsdCents = Math.round(
    (netRoomSubtotalCents * property.taxRateBps) / 10000
  );
  const totalUsdCents = netRoomSubtotalCents + feesUsdCents + taxesUsdCents;

  return {
    nights,
    roomCount,
    nightlyLines,
    subtotalUsdCents: rawRoomSubtotalCents,
    discountUsdCents,
    feesUsdCents,
    taxesUsdCents,
    totalUsdCents,
    startingNightlyUsdCents: roomType.baseRateUsdCents,
    averageNightlyUsdCents: Math.round(netRoomSubtotalCents / (nights * roomCount)),
  };
}

/**
 * Calculates USD-denominated refund entitlement based on the policy snapshot
 * accepted by the customer at booking time.
 */
export function calculateRefundEntitlementCents(params: {
  paidUsdCents: number;
  totalUsdCents: number;
  nights: number;
  checkInDate: string;
  refundable: boolean;
  freeCancellationHoursBeforeCheckIn: number;
  now?: Date;
}): {
  eligible: boolean;
  usdEntitlementCents: number;
  feeUsdCents: number;
  netUsdRefundCents: number;
  explanation: string;
} {
  const {
    paidUsdCents,
    nights,
    checkInDate,
    refundable,
    freeCancellationHoursBeforeCheckIn,
    now = new Date(),
  } = params;

  if (paidUsdCents <= 0) {
    return {
      eligible: false,
      usdEntitlementCents: 0,
      feeUsdCents: 0,
      netUsdRefundCents: 0,
      explanation: "No settled USD payment exists to refund; unpaid reservations cancel without charge.",
    };
  }

  if (!refundable || freeCancellationHoursBeforeCheckIn === 0) {
    return {
      eligible: false,
      usdEntitlementCents: 0,
      feeUsdCents: paidUsdCents,
      netUsdRefundCents: 0,
      explanation:
        "Reservation was booked under a Non-Refundable Advance Purchase rate plan (0% automatic refund entitlement; manual exception review may still be requested).",
    };
  }

  const checkInUtc = parseUtcDate(checkInDate);
  const checkInTimestamp = checkInUtc
    ? checkInUtc.getTime() + 15 * 3600 * 1000 // 15:00 check-in
    : now.getTime();
  const hoursUntilCheckIn = (checkInTimestamp - now.getTime()) / 3_600_000;

  if (hoursUntilCheckIn >= freeCancellationHoursBeforeCheckIn) {
    return {
      eligible: true,
      usdEntitlementCents: paidUsdCents,
      feeUsdCents: 0,
      netUsdRefundCents: paidUsdCents,
      explanation: `Cancelled ${Math.floor(hoursUntilCheckIn)} hours prior to arrival (within ${freeCancellationHoursBeforeCheckIn}h free cancellation window). Full 100% USD entitlement applies.`,
    };
  }

  // Late cancellation penalty
  if (freeCancellationHoursBeforeCheckIn >= 48) {
    const oneNightPenalty = Math.min(
      paidUsdCents,
      Math.round(paidUsdCents / Math.max(1, nights))
    );
    const net = Math.max(0, paidUsdCents - oneNightPenalty);
    return {
      eligible: net > 0,
      usdEntitlementCents: paidUsdCents,
      feeUsdCents: oneNightPenalty,
      netUsdRefundCents: net,
      explanation: `Cancelled inside the 48-hour penalty window. A one-night room & tax fee applies; remaining balance is eligible for refund.`,
    };
  }

  const fiftyPercentFee = Math.round(paidUsdCents * 0.5);
  const net = paidUsdCents - fiftyPercentFee;
  return {
    eligible: net > 0,
    usdEntitlementCents: paidUsdCents,
    feeUsdCents: fiftyPercentFee,
    netUsdRefundCents: net,
    explanation: `Cancelled inside the 24-hour penalty window. A 50% late-cancellation fee applies under the accepted policy.`,
  };
}
