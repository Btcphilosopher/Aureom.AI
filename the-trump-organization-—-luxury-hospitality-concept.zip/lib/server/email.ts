import type { EmailOutbox, Reservation } from "../types";
import { formatUsdCents } from "../crypto-assets";

export function isSmtpConfigured(): boolean {
  return Boolean(
    process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS
  );
}

/**
 * Builds an email record. Keeps "queued" strictly separate from
 * "simulated_sent" (local preview mode) or "provider_confirmed" (live SMTP).
 */
export function buildReservationConfirmationEmail(params: {
  id: string;
  reservation: Reservation;
  accessUrl: string;
}): EmailOutbox {
  const { id, reservation, accessUrl } = params;
  const smtpLive = isSmtpConfigured();

  const bodyPreview = [
    `Dear ${reservation.guestName},`,
    "",
    `Your demonstration reservation at ${reservation.propertyName} is recorded.`,
    `Confirmation Reference: ${reservation.confirmationCode}`,
    `Dates: ${reservation.checkIn} to ${reservation.checkOut} (${reservation.nights} night(s))`,
    `Accommodation: ${reservation.roomCount}x ${reservation.roomTypeName} (${reservation.ratePlanName})`,
    `Reservation Status: ${reservation.reservationStatus}`,
    `Payment Status: ${reservation.paymentStatus}`,
    `Total Amount (USD): ${formatUsdCents(reservation.totalUsdCents)}`,
    "",
    `Manage your reservation securely: ${accessUrl}`,
    "",
    "Note: This is an independent demonstration concept; no live hotel charge or real booking was executed.",
  ].join("\n");

  return {
    id,
    to: reservation.guestEmail,
    subject: `Reservation ${reservation.confirmationCode} — ${reservation.propertyName}`,
    template: "reservation_confirmation_v1",
    bodyPreview,
    status: smtpLive ? "queued" : "simulated_sent",
    reservationId: reservation.id,
    createdAt: new Date().toISOString(),
  };
}
