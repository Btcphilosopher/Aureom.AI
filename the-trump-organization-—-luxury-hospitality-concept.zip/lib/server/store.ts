import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {
  DEMO_EXPERIENCES,
  DEMO_PROPERTIES,
  DEMO_RATE_PLANS,
  DEMO_ROOM_TYPES,
} from "../seed-data";
import {
  CRYPTO_ASSET_ALLOWLIST,
  formatTokenBaseUnits,
  usdCentsToTokenBaseUnits,
  validateAssetAllowlist,
} from "../crypto-assets";
import type {
  AdminRole,
  AdminUser,
  AuditEvent,
  CryptoQuote,
  EmailOutbox,
  Enquiry,
  ExperienceItem,
  Guest,
  NightlyInventory,
  PaymentAttempt,
  PaymentMethod,
  PriceBreakdown,
  Property,
  RatePlan,
  Refund,
  Reservation,
  ReservationHold,
  RoomType,
  SystemIntegrationConfig,
  WebhookEvent,
} from "../types";
import {
  calculateRefundEntitlementCents,
  calculateStayPricing,
  formatUtcDate,
  validateOccupancy,
  validateStayDates,
} from "./pricing";
import {
  generateAccessToken,
  generateConfirmationCode,
  verifyAccessToken,
  verifyWebhookSignature,
} from "./crypto-signing";
import { buildReservationConfirmationEmail, isSmtpConfigured } from "./email";

export interface HospitalityDatabase {
  properties: Property[];
  roomTypes: RoomType[];
  ratePlans: RatePlan[];
  experiences: ExperienceItem[];
  nightlyInventory: Record<string, NightlyInventory>;
  holds: Record<string, ReservationHold>;
  guests: Record<string, Guest>;
  reservations: Record<string, Reservation>;
  paymentAttempts: Record<string, PaymentAttempt>;
  cryptoQuotes: Record<string, CryptoQuote>;
  refunds: Record<string, Refund>;
  webhookEvents: Record<string, WebhookEvent>;
  admins: Record<string, AdminUser>;
  auditEvents: AuditEvent[];
  enquiries: Record<string, Enquiry>;
  emailOutbox: EmailOutbox[];
  systemConfig: SystemIntegrationConfig;
}

const DEFAULT_STORE_PATH = path.join(
  process.cwd(),
  ".data",
  "hospitality-store.json"
);

// Async mutex queue per store file path to guarantee atomic concurrent holds
const locks = new Map<string, Promise<void>>();

async function withStoreLock<T>(
  storePath: string,
  fn: () => Promise<T> | T
): Promise<T> {
  const prev = locks.get(storePath) ?? Promise.resolve();
  let release!: () => void;
  const next = new Promise<void>((resolve) => {
    release = resolve;
  });
  locks.set(storePath, next);
  await prev;
  try {
    return await fn();
  } finally {
    release();
  }
}

function buildInitialSeed(baseDateStr?: string): HospitalityDatabase {
  const today = baseDateStr
    ? new Date(`${baseDateStr}T00:00:00Z`)
    : new Date();
  const nightlyInventory: Record<string, NightlyInventory> = {};

  for (const rt of DEMO_ROOM_TYPES) {
    for (let offset = 0; offset < 120; offset++) {
      const dt = new Date(today.getTime() + offset * 86_400_000);
      const dateStr = formatUtcDate(dt);
      const invId = `${rt.propertyId}_${rt.id}_${dateStr}`;
      nightlyInventory[invId] = {
        id: invId,
        propertyId: rt.propertyId,
        roomTypeId: rt.id,
        date: dateStr,
        totalUnits: rt.totalUnits,
        heldUnits: 0,
        bookedUnits: 0,
      };
    }
  }

  return {
    properties: DEMO_PROPERTIES,
    roomTypes: DEMO_ROOM_TYPES,
    ratePlans: DEMO_RATE_PLANS,
    experiences: DEMO_EXPERIENCES,
    nightlyInventory,
    holds: {},
    guests: {},
    reservations: {},
    paymentAttempts: {},
    cryptoQuotes: {},
    refunds: {},
    webhookEvents: {},
    admins: {
      "bootstrapped-owner": {
        uid: "bootstrapped-owner",
        email: "tom@ahyx.org",
        role: "super_admin",
        active: true,
        createdAt: new Date().toISOString(),
      },
    },
    auditEvents: [],
    enquiries: {},
    emailOutbox: [],
    systemConfig: {
      liveUsdEnabled: process.env.PAYMENT_MODE_USD_LIVE === "true",
      liveCryptoEnabled: process.env.PAYMENT_MODE_CRYPTO_LIVE === "true",
      demoModeEnabled: true,
      emailAdapterMode: isSmtpConfigured()
        ? "smtp_configured"
        : "local_outbox_preview",
      geminiConciergeMode: process.env.GEMINI_API_KEY
        ? "live_gemini"
        : "offline_mock",
      updatedAt: new Date().toISOString(),
    },
  };
}

function loadDb(storePath: string): HospitalityDatabase {
  if (!fs.existsSync(storePath)) {
    const dir = path.dirname(storePath);
    fs.mkdirSync(dir, { recursive: true });
    const seed = buildInitialSeed();
    saveDb(storePath, seed);
    return seed;
  }
  const raw = fs.readFileSync(storePath, "utf8");
  const parsed = JSON.parse(raw) as HospitalityDatabase;
  // Refresh dynamic runtime environment flags safely
  parsed.systemConfig = {
    ...parsed.systemConfig,
    liveUsdEnabled: process.env.PAYMENT_MODE_USD_LIVE === "true",
    liveCryptoEnabled: process.env.PAYMENT_MODE_CRYPTO_LIVE === "true",
    emailAdapterMode: isSmtpConfigured()
      ? "smtp_configured"
      : "local_outbox_preview",
    geminiConciergeMode: process.env.GEMINI_API_KEY
      ? "live_gemini"
      : "offline_mock",
  };
  return parsed;
}

function saveDb(storePath: string, db: HospitalityDatabase): void {
  const dir = path.dirname(storePath);
  fs.mkdirSync(dir, { recursive: true });
  const tmpPath = `${storePath}.${crypto.randomBytes(6).toString("hex")}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(db, null, 2), "utf8");
  fs.renameSync(tmpPath, storePath);
}

function ensureInventoryRecord(
  db: HospitalityDatabase,
  propertyId: string,
  roomType: RoomType,
  date: string
): NightlyInventory {
  const invId = `${propertyId}_${roomType.id}_${date}`;
  if (!db.nightlyInventory[invId]) {
    db.nightlyInventory[invId] = {
      id: invId,
      propertyId,
      roomTypeId: roomType.id,
      date,
      totalUnits: roomType.totalUnits,
      heldUnits: 0,
      bookedUnits: 0,
    };
  }
  return db.nightlyInventory[invId];
}

function buildDateRangeForHold(checkIn: string, nights: number): string[] {
  const start = new Date(`${checkIn}T00:00:00Z`);
  const out: string[] = [];
  for (let i = 0; i < nights; i++) {
    out.push(formatUtcDate(new Date(start.getTime() + i * 86_400_000)));
  }
  return out;
}

export function sweepExpiredStateInMemory(
  db: HospitalityDatabase,
  now: Date = new Date()
): { expiredHolds: number; expiredQuotes: number } {
  const nowMs = now.getTime();
  let expiredHolds = 0;
  let expiredQuotes = 0;

  for (const hold of Object.values(db.holds)) {
    if (hold.status === "active" && new Date(hold.expiresAt).getTime() <= nowMs) {
      hold.status = "expired";
      expiredHolds++;
      const rt = db.roomTypes.find((r) => r.id === hold.roomTypeId);
      const dates = buildDateRangeForHold(hold.checkIn, hold.nights);
      for (const d of dates) {
        const invId = `${hold.propertyId}_${hold.roomTypeId}_${d}`;
        const inv = db.nightlyInventory[invId];
        if (inv) {
          inv.heldUnits = Math.max(0, inv.heldUnits - hold.roomCount);
        } else if (rt) {
          ensureInventoryRecord(db, hold.propertyId, rt, d);
        }
      }
      // Mark linked unpaid reservations as expired
      for (const res of Object.values(db.reservations)) {
        if (
          res.holdId === hold.id &&
          res.reservationStatus === "pending_payment" &&
          (res.paymentStatus === "unpaid" || res.paymentStatus === "awaiting_payment")
        ) {
          res.reservationStatus = "expired";
          res.updatedAt = now.toISOString();
        }
      }
    }
  }

  for (const quote of Object.values(db.cryptoQuotes)) {
    if (
      (quote.status === "quote_created" || quote.status === "awaiting_payment") &&
      new Date(quote.expiresAt).getTime() <= nowMs
    ) {
      quote.status = "expired";
      expiredQuotes++;
    }
  }

  return { expiredHolds, expiredQuotes };
}

function appendAudit(
  db: HospitalityDatabase,
  params: {
    actorUid: string;
    actorRole: string;
    action: string;
    targetType: string;
    targetId: string;
    details: string;
  }
) {
  db.auditEvents.unshift({
    id: `aud-${crypto.randomUUID()}`,
    ...params,
    createdAt: new Date().toISOString(),
  });
  if (db.auditEvents.length > 500) {
    db.auditEvents = db.auditEvents.slice(0, 500);
  }
}

export async function runReconciliationSweep(
  storePath: string = DEFAULT_STORE_PATH,
  now?: Date
) {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const res = sweepExpiredStateInMemory(db, now);
    saveDb(storePath, db);
    return res;
  });
}

export async function listProperties(
  storePath: string = DEFAULT_STORE_PATH
): Promise<{
  properties: Property[];
  roomTypes: RoomType[];
  ratePlans: RatePlan[];
  experiences: ExperienceItem[];
  systemConfig: SystemIntegrationConfig;
}> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    return {
      properties: db.properties,
      roomTypes: db.roomTypes,
      ratePlans: db.ratePlans,
      experiences: db.experiences,
      systemConfig: db.systemConfig,
    };
  });
}

export interface RoomAvailabilityOffer {
  roomType: RoomType;
  availableUnits: number;
  isAvailable: boolean;
  occupancyValid: boolean;
  occupancyError?: string;
  rateOffers: {
    ratePlan: RatePlan;
    pricing: PriceBreakdown;
  }[];
}

export async function searchAvailability(
  params: {
    propertyIdOrSlug: string;
    checkIn: string;
    checkOut: string;
    adults: number;
    children: number;
    roomCount: number;
    referenceDateStr?: string;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{
  property: Property;
  checkIn: string;
  checkOut: string;
  nights: number;
  offers: RoomAvailabilityOffer[];
}> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    sweepExpiredStateInMemory(db);

    const property = db.properties.find(
      (p) =>
        p.id === params.propertyIdOrSlug || p.slug === params.propertyIdOrSlug
    );
    if (!property) {
      throw new Error("Property not found.");
    }

    const dateCheck = validateStayDates(
      params.checkIn,
      params.checkOut,
      params.referenceDateStr
    );
    if (!dateCheck.valid) {
      throw new Error(dateCheck.error || "Invalid stay dates.");
    }

    const propertyRooms = db.roomTypes.filter(
      (r) => r.propertyId === property.id
    );
    const propertyPlans = db.ratePlans.filter(
      (rp) => rp.propertyId === property.id
    );

    const offers: RoomAvailabilityOffer[] = propertyRooms.map((roomType) => {
      const occ = validateOccupancy(
        roomType,
        params.adults,
        params.children,
        params.roomCount
      );

      let minAvailable = Infinity;
      const inventoryByDate = new Map<string, NightlyInventory>();
      for (const date of dateCheck.dates) {
        const inv = ensureInventoryRecord(db, property.id, roomType, date);
        inventoryByDate.set(date, inv);
        const remaining = Math.max(
          0,
          inv.totalUnits - inv.heldUnits - inv.bookedUnits
        );
        if (remaining < minAvailable) {
          minAvailable = remaining;
        }
      }
      if (!Number.isFinite(minAvailable)) minAvailable = 0;

      const isAvailable = occ.valid && minAvailable >= params.roomCount;

      const rateOffers = propertyPlans.map((ratePlan) => ({
        ratePlan,
        pricing: calculateStayPricing({
          property,
          roomType,
          ratePlan,
          dates: dateCheck.dates,
          roomCount: params.roomCount,
          inventoryByDate,
        }),
      }));

      return {
        roomType,
        availableUnits: minAvailable,
        isAvailable,
        occupancyValid: occ.valid,
        occupancyError: occ.error,
        rateOffers,
      };
    });

    saveDb(storePath, db);
    return {
      property,
      checkIn: params.checkIn,
      checkOut: params.checkOut,
      nights: dateCheck.nights,
      offers,
    };
  });
}

export async function createInventoryHold(
  params: {
    propertyId: string;
    roomTypeId: string;
    ratePlanId: string;
    checkIn: string;
    checkOut: string;
    adults: number;
    children: number;
    roomCount: number;
    ttlSeconds?: number;
    referenceDateStr?: string;
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<ReservationHold> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();
    sweepExpiredStateInMemory(db, now);

    const property = db.properties.find((p) => p.id === params.propertyId);
    if (!property) throw new Error("Property not found.");

    const roomType = db.roomTypes.find(
      (r) => r.id === params.roomTypeId && r.propertyId === property.id
    );
    if (!roomType) throw new Error("Room type not found for property.");

    const ratePlan = db.ratePlans.find(
      (rp) => rp.id === params.ratePlanId && rp.propertyId === property.id
    );
    if (!ratePlan) throw new Error("Rate plan not found for property.");

    const dateCheck = validateStayDates(
      params.checkIn,
      params.checkOut,
      params.referenceDateStr
    );
    if (!dateCheck.valid) {
      throw new Error(dateCheck.error || "Invalid dates.");
    }

    const occ = validateOccupancy(
      roomType,
      params.adults,
      params.children,
      params.roomCount
    );
    if (!occ.valid) {
      throw new Error(occ.error || "Occupancy validation failed.");
    }

    // Atomic check across all nights
    const inventoryByDate = new Map<string, NightlyInventory>();
    for (const date of dateCheck.dates) {
      const inv = ensureInventoryRecord(db, property.id, roomType, date);
      const remaining = inv.totalUnits - inv.heldUnits - inv.bookedUnits;
      if (remaining < params.roomCount) {
        throw new Error(
          `Insufficient inventory on ${date}: ${remaining} unit(s) remaining, ${params.roomCount} requested.`
        );
      }
      inventoryByDate.set(date, inv);
    }

    // Reserve units atomically
    for (const date of dateCheck.dates) {
      const inv = inventoryByDate.get(date)!;
      inv.heldUnits += params.roomCount;
    }

    const pricing = calculateStayPricing({
      property,
      roomType,
      ratePlan,
      dates: dateCheck.dates,
      roomCount: params.roomCount,
      inventoryByDate,
    });

    const ttlMs = (params.ttlSeconds ?? 900) * 1000;
    const hold: ReservationHold = {
      id: `hold-${crypto.randomUUID()}`,
      propertyId: property.id,
      roomTypeId: roomType.id,
      ratePlanId: ratePlan.id,
      checkIn: params.checkIn,
      checkOut: params.checkOut,
      nights: dateCheck.nights,
      adults: params.adults,
      children: params.children,
      roomCount: params.roomCount,
      status: "active",
      pricing,
      rateSnapshot: {
        ratePlanCode: ratePlan.code,
        ratePlanName: ratePlan.name,
        multiplierBps: ratePlan.multiplierBps,
        discountBps: ratePlan.discountBps,
        roomTypeName: roomType.name,
      },
      policySnapshot: {
        version: ratePlan.cancellationPolicyVersion,
        refundable: ratePlan.refundable,
        summary: ratePlan.cancellationSummary,
        freeCancellationHoursBeforeCheckIn:
          ratePlan.freeCancellationHoursBeforeCheckIn,
      },
      expiresAt: new Date(now.getTime() + ttlMs).toISOString(),
      createdAt: now.toISOString(),
    };

    db.holds[hold.id] = hold;
    saveDb(storePath, db);
    return hold;
  });
}

export async function getHoldById(
  holdId: string,
  storePath: string = DEFAULT_STORE_PATH
): Promise<ReservationHold | null> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    sweepExpiredStateInMemory(db);
    saveDb(storePath, db);
    return db.holds[holdId] ?? null;
  });
}

export async function createReservationFromHold(
  params: {
    holdId: string;
    guestName: string;
    guestEmail: string;
    guestPhone: string;
    guestCountry?: string;
    guestUid?: string;
    specialRequests?: string;
    paymentMethod: PaymentMethod;
    acceptedPolicy: boolean;
    baseUrl?: string;
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{
  reservation: Reservation;
  accessToken: string;
  outboxEmail: EmailOutbox;
}> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();
    sweepExpiredStateInMemory(db, now);

    if (!params.acceptedPolicy) {
      throw new Error(
        "Explicit acceptance of rate and cancellation policy terms is required."
      );
    }

    const hold = db.holds[params.holdId];
    if (!hold) {
      throw new Error("Inventory hold not found.");
    }
    if (hold.status === "expired") {
      throw new Error(
        "Your inventory hold has expired. Please re-verify availability to acquire a fresh hold."
      );
    }
    if (hold.status !== "active") {
      throw new Error(`Hold is no longer active (status: ${hold.status}).`);
    }

    const property = db.properties.find((p) => p.id === hold.propertyId);
    const roomType = db.roomTypes.find((r) => r.id === hold.roomTypeId);
    if (!property || !roomType) {
      throw new Error("Associated property or room type not found.");
    }

    const guestId = `gst-${crypto.randomUUID()}`;
    const guest: Guest = {
      id: guestId,
      uid: params.guestUid,
      fullName: params.guestName.trim(),
      email: params.guestEmail.trim().toLowerCase(),
      phone: params.guestPhone.trim(),
      country: params.guestCountry?.trim() || "United States",
      createdAt: now.toISOString(),
    };
    db.guests[guestId] = guest;

    const confirmationCode = generateConfirmationCode();
    const { token: accessToken, tokenHash } = generateAccessToken();

    const reservation: Reservation = {
      id: `res-${crypto.randomUUID()}`,
      confirmationCode,
      accessTokenHash: tokenHash,
      propertyId: property.id,
      propertyName: property.name,
      propertySlug: property.slug,
      roomTypeId: roomType.id,
      roomTypeName: roomType.name,
      ratePlanId: hold.ratePlanId,
      ratePlanName: hold.rateSnapshot.ratePlanName,
      holdId: hold.id,
      guestId,
      guestUid: params.guestUid,
      guestEmail: guest.email,
      guestName: guest.fullName,
      guestPhone: guest.phone,
      specialRequests: params.specialRequests?.trim(),
      checkIn: hold.checkIn,
      checkOut: hold.checkOut,
      nights: hold.nights,
      adults: hold.adults,
      children: hold.children,
      roomCount: hold.roomCount,
      reservationStatus: "pending_payment",
      paymentStatus: "unpaid",
      fulfillmentStatus: "pending",
      currency: "USD",
      pricing: hold.pricing,
      totalUsdCents: hold.pricing.totalUsdCents,
      paidUsdCents: 0,
      paymentMethod: params.paymentMethod,
      rateSnapshot: hold.rateSnapshot,
      cancellationPolicySnapshot: {
        ...hold.policySnapshot,
        acceptedAt: now.toISOString(),
      },
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    db.reservations[reservation.id] = reservation;

    const base = params.baseUrl || "http://localhost:3000";
    const outboxEmail = buildReservationConfirmationEmail({
      id: `eml-${crypto.randomUUID()}`,
      reservation,
      accessUrl: `${base}/reservations/${reservation.confirmationCode}?token=${encodeURIComponent(accessToken)}`,
    });
    db.emailOutbox.unshift(outboxEmail);

    appendAudit(db, {
      actorUid: params.guestUid || "guest",
      actorRole: "guest",
      action: "reservation.created",
      targetType: "reservation",
      targetId: reservation.id,
      details: `Created ${reservation.confirmationCode} from hold ${hold.id} for ${reservation.totalUsdCents} USD cents.`,
    });

    saveDb(storePath, db);
    return { reservation, accessToken, outboxEmail };
  });
}

export async function createUsdPaymentSession(
  params: {
    reservationId: string;
    idempotencyKey: string;
    mode: "demo" | "live";
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{ attempt: PaymentAttempt; deduplicated: boolean }> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();
    sweepExpiredStateInMemory(db, now);

    const reservation = db.reservations[params.reservationId];
    if (!reservation) throw new Error("Reservation not found.");

    if (params.mode === "live" && !db.systemConfig.liveUsdEnabled) {
      throw new Error(
        "Live USD checkout is disabled until payment-provider secret keys and webhook signing secrets are verified."
      );
    }

    // Idempotency check
    const existing = Object.values(db.paymentAttempts).find(
      (a) =>
        a.reservationId === reservation.id &&
        a.idempotencyKey === params.idempotencyKey
    );
    if (existing) {
      return { attempt: existing, deduplicated: true };
    }

    const hold = db.holds[reservation.holdId];
    if (!hold || hold.status === "expired") {
      throw new Error(
        "Inventory hold expired prior to initiating checkout. Acquire a new hold to continue."
      );
    }

    if (reservation.paymentStatus === "paid") {
      throw new Error("Reservation is already settled.");
    }

    const attempt: PaymentAttempt = {
      id: `pay-${crypto.randomUUID()}`,
      reservationId: reservation.id,
      method: "usd_card",
      mode: params.mode,
      status: "awaiting_payment",
      amountUsdCents: reservation.totalUsdCents,
      providerSessionId: `sim_cs_${crypto.randomBytes(12).toString("hex")}`,
      idempotencyKey: params.idempotencyKey,
      confirmations: 0,
      requiredConfirmations: 1,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    db.paymentAttempts[attempt.id] = attempt;
    reservation.paymentStatus = "awaiting_payment";
    reservation.paymentMethod = "usd_card";
    reservation.updatedAt = now.toISOString();

    saveDb(storePath, db);
    return { attempt, deduplicated: false };
  });
}

export async function createCryptoQuote(
  params: {
    reservationId: string;
    assetId: string;
    network: string;
    tokenIdentifier: string;
    mode: "demo" | "live";
    quoteTtlSeconds?: number;
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{ quote: CryptoQuote; attempt: PaymentAttempt }> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();
    sweepExpiredStateInMemory(db, now);

    const reservation = db.reservations[params.reservationId];
    if (!reservation) throw new Error("Reservation not found.");

    const allow = validateAssetAllowlist(
      params.assetId,
      params.network,
      params.tokenIdentifier
    );
    if (!allow.valid || !allow.asset) {
      throw new Error(allow.reason || "Asset not allowlisted.");
    }

    if (params.mode === "live") {
      if (!db.systemConfig.liveCryptoEnabled || !allow.asset.liveSupported) {
        throw new Error(
          `Live crypto settlement for ${allow.asset.ticker} on ${allow.asset.network} is disabled until verified merchant custody and chain monitoring are configured.`
        );
      }
    }

    const hold = db.holds[reservation.holdId];
    if (!hold || hold.status === "expired") {
      throw new Error(
        "Inventory hold expired prior to creating crypto quote."
      );
    }

    const asset = allow.asset;
    const totalPayableUsdCents =
      reservation.totalUsdCents + asset.networkFeeUsdCents;
    const exactBaseUnits = usdCentsToTokenBaseUnits(
      totalPayableUsdCents,
      asset.referenceUsdRateString,
      asset.decimals,
      "up"
    );
    const displayTokenAmount = formatTokenBaseUnits(
      exactBaseUnits,
      asset.decimals,
      6
    );

    const ttlMs = (params.quoteTtlSeconds ?? 300) * 1000;
    const quote: CryptoQuote = {
      id: `qte-${crypto.randomUUID()}`,
      reservationId: reservation.id,
      assetId: asset.assetId,
      ticker: asset.ticker,
      network: asset.network,
      tokenIdentifier: asset.tokenIdentifier,
      decimals: asset.decimals,
      usdAmountCents: reservation.totalUsdCents,
      feeUsdCents: asset.networkFeeUsdCents,
      totalPayableUsdCents,
      exchangeRateUsdPerTokenString: asset.referenceUsdRateString,
      rateSource: asset.rateSource,
      rateTimestamp: now.toISOString(),
      exactTokenBaseUnits: exactBaseUnits.toString(),
      displayTokenAmount,
      destinationAddress: asset.demoDepositAddress,
      requiredConfirmations: asset.requiredConfirmations,
      status: "quote_created",
      mode: params.mode,
      expiresAt: new Date(now.getTime() + ttlMs).toISOString(),
      createdAt: now.toISOString(),
    };

    const attempt: PaymentAttempt = {
      id: `pay-${crypto.randomUUID()}`,
      reservationId: reservation.id,
      method: asset.paymentMethod,
      mode: params.mode,
      status: "awaiting_payment",
      amountUsdCents: totalPayableUsdCents,
      providerSessionId: `sim_cq_${quote.id}`,
      idempotencyKey: `quote-${quote.id}`,
      quoteId: quote.id,
      confirmations: 0,
      requiredConfirmations: asset.requiredConfirmations,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };

    quote.status = "awaiting_payment";
    db.cryptoQuotes[quote.id] = quote;
    db.paymentAttempts[attempt.id] = attempt;
    reservation.paymentStatus = "awaiting_payment";
    reservation.paymentMethod = asset.paymentMethod;
    reservation.updatedAt = now.toISOString();

    saveDb(storePath, db);
    return { quote, attempt };
  });
}

function finalizeHoldToBookedIfAvailable(
  db: HospitalityDatabase,
  reservation: Reservation,
  now: Date
): { ok: boolean; reason?: string } {
  const hold = db.holds[reservation.holdId];
  const dates = buildDateRangeForHold(reservation.checkIn, reservation.nights);

  if (hold && hold.status === "active" && new Date(hold.expiresAt).getTime() > now.getTime()) {
    // Convert heldUnits -> bookedUnits
    for (const d of dates) {
      const invId = `${reservation.propertyId}_${reservation.roomTypeId}_${d}`;
      const inv = db.nightlyInventory[invId];
      if (inv) {
        inv.heldUnits = Math.max(0, inv.heldUnits - reservation.roomCount);
        inv.bookedUnits += reservation.roomCount;
      }
    }
    hold.status = "converted";
    return { ok: true };
  }

  // Hold expired (late payment!). Must NOT silently create an unavailable booking.
  return {
    ok: false,
    reason:
      "Inventory hold expired before verified payment settlement. Late payment queued for manual reconciliation.",
  };
}

export async function observeCryptoPayment(
  params: {
    quoteId: string;
    observedNetwork: string;
    observedTokenIdentifier: string;
    observedBaseUnits: string;
    txHash: string;
    confirmations: number;
    baseUrl?: string;
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{
  quote: CryptoQuote;
  attempt: PaymentAttempt;
  reservation: Reservation;
}> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();
    // Note: Check quote expiry explicitly BEFORE sweeping or handle late arrival
    const quote = db.cryptoQuotes[params.quoteId];
    if (!quote) throw new Error("Crypto quote not found.");

    const reservation = db.reservations[quote.reservationId];
    if (!reservation) throw new Error("Reservation not found.");

    const attempt = Object.values(db.paymentAttempts).find(
      (a) => a.quoteId === quote.id
    );
    if (!attempt) throw new Error("Payment attempt not found for quote.");

    // 1. Validate network and token identifier match exact quote allowlist
    if (
      params.observedNetwork !== quote.network ||
      params.observedTokenIdentifier !== quote.tokenIdentifier
    ) {
      quote.status = "review_required";
      attempt.status = "review_required";
      attempt.txHash = params.txHash;
      attempt.observedNetwork = params.observedNetwork;
      attempt.observedTokenIdentifier = params.observedTokenIdentifier;
      attempt.failureReason = `Asset/network mismatch: expected ${quote.network} / ${quote.tokenIdentifier}, observed ${params.observedNetwork} / ${params.observedTokenIdentifier}.`;
      attempt.updatedAt = now.toISOString();
      reservation.paymentStatus = "reconciliation_required";
      reservation.reservationStatus = "reconciliation_required";
      reservation.fulfillmentStatus = "on_hold";
      reservation.updatedAt = now.toISOString();
      appendAudit(db, {
        actorUid: "crypto-observer",
        actorRole: "system",
        action: "payment.crypto_mismatch",
        targetType: "reservation",
        targetId: reservation.id,
        details: attempt.failureReason,
      });
      saveDb(storePath, db);
      return { quote, attempt, reservation };
    }

    // 2. Check quote expiry
    const quoteExpired =
      quote.status === "expired" ||
      new Date(quote.expiresAt).getTime() <= now.getTime();
    if (quoteExpired) {
      // Late transaction after quote expiry enters reconciliation / expired review
      quote.status = "review_required";
      attempt.status = "review_required";
      attempt.txHash = params.txHash;
      attempt.observedBaseUnits = params.observedBaseUnits;
      attempt.failureReason =
        "Crypto transfer observed after quote expiry window. Held in reconciliation queue for rate re-quote or refund.";
      attempt.updatedAt = now.toISOString();
      reservation.paymentStatus = "reconciliation_required";
      reservation.reservationStatus = "reconciliation_required";
      reservation.fulfillmentStatus = "on_hold";
      reservation.updatedAt = now.toISOString();
      appendAudit(db, {
        actorUid: "crypto-observer",
        actorRole: "system",
        action: "payment.crypto_late_after_quote_expiry",
        targetType: "reservation",
        targetId: reservation.id,
        details: attempt.failureReason,
      });
      saveDb(storePath, db);
      return { quote, attempt, reservation };
    }

    // 3. Compare exact BigInt base units
    const expectedUnits = BigInt(quote.exactTokenBaseUnits);
    const observedUnits = BigInt(params.observedBaseUnits);

    attempt.txHash = params.txHash;
    attempt.observedNetwork = params.observedNetwork;
    attempt.observedTokenIdentifier = params.observedTokenIdentifier;
    attempt.observedBaseUnits = params.observedBaseUnits;
    attempt.confirmations = params.confirmations;
    attempt.updatedAt = now.toISOString();

    if (observedUnits < expectedUnits) {
      quote.status = "underpaid";
      attempt.status = "underpaid";
      attempt.failureReason = `Observed ${formatTokenBaseUnits(observedUnits, quote.decimals)} ${quote.ticker}, expected ${quote.displayTokenAmount} ${quote.ticker}.`;
      reservation.paymentStatus = "underpaid";
      reservation.fulfillmentStatus = "on_hold";
      reservation.updatedAt = now.toISOString();
      appendAudit(db, {
        actorUid: "crypto-observer",
        actorRole: "system",
        action: "payment.crypto_underpaid",
        targetType: "reservation",
        targetId: reservation.id,
        details: attempt.failureReason,
      });
      saveDb(storePath, db);
      return { quote, attempt, reservation };
    }

    if (observedUnits > expectedUnits) {
      quote.status = "overpaid";
      attempt.status = "overpaid";
      attempt.failureReason = `Observed ${formatTokenBaseUnits(observedUnits, quote.decimals)} ${quote.ticker}, exceeding quoted ${quote.displayTokenAmount} ${quote.ticker}. Requires reconciliation/overpayment refund review.`;
      reservation.paymentStatus = "overpaid";
      reservation.reservationStatus = "reconciliation_required";
      reservation.fulfillmentStatus = "on_hold";
      reservation.updatedAt = now.toISOString();
      appendAudit(db, {
        actorUid: "crypto-observer",
        actorRole: "system",
        action: "payment.crypto_overpaid",
        targetType: "reservation",
        targetId: reservation.id,
        details: attempt.failureReason,
      });
      saveDb(storePath, db);
      return { quote, attempt, reservation };
    }

    // Exact amount observed
    if (params.confirmations === 0) {
      quote.status = "transaction_observed";
      attempt.status = "transaction_observed";
      reservation.paymentStatus = "confirming";
      reservation.updatedAt = now.toISOString();
      saveDb(storePath, db);
      return { quote, attempt, reservation };
    }

    if (params.confirmations < quote.requiredConfirmations) {
      quote.status = "confirming";
      attempt.status = "confirming";
      reservation.paymentStatus = "confirming";
      reservation.updatedAt = now.toISOString();
      saveDb(storePath, db);
      return { quote, attempt, reservation };
    }

    // Finality reached -> check inventory hold validity!
    const holdOutcome = finalizeHoldToBookedIfAvailable(db, reservation, now);
    if (!holdOutcome.ok) {
      quote.status = "review_required";
      attempt.status = "review_required";
      attempt.failureReason = holdOutcome.reason;
      reservation.reservationStatus = "reconciliation_required";
      reservation.paymentStatus = "reconciliation_required";
      reservation.fulfillmentStatus = "on_hold";
      reservation.updatedAt = now.toISOString();
      appendAudit(db, {
        actorUid: "crypto-observer",
        actorRole: "system",
        action: "payment.late_settlement_reconciliation",
        targetType: "reservation",
        targetId: reservation.id,
        details: holdOutcome.reason || "Late crypto settlement.",
      });
      saveDb(storePath, db);
      return { quote, attempt, reservation };
    }

    quote.status = "paid";
    attempt.status = "paid";
    reservation.reservationStatus = "confirmed";
    reservation.paymentStatus = "paid";
    reservation.fulfillmentStatus = "ready_for_arrival";
    reservation.paidUsdCents = reservation.totalUsdCents;
    reservation.updatedAt = now.toISOString();

    const base = params.baseUrl || "http://localhost:3000";
    db.emailOutbox.unshift(
      buildReservationConfirmationEmail({
        id: `eml-${crypto.randomUUID()}`,
        reservation,
        accessUrl: `${base}/reservations/${reservation.confirmationCode}`,
      })
    );

    appendAudit(db, {
      actorUid: "crypto-observer",
      actorRole: "system",
      action: "payment.crypto_confirmed",
      targetType: "reservation",
      targetId: reservation.id,
      details: `Settled ${quote.displayTokenAmount} ${quote.ticker} (${quote.network}) for ${reservation.confirmationCode}.`,
    });

    saveDb(storePath, db);
    return { quote, attempt, reservation };
  });
}

export async function processWebhookEvent(
  params: {
    rawBody: string;
    signatureHeader: string | null | undefined;
    provider: string;
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{
  statusCode: number;
  event: WebhookEvent;
  reservation?: Reservation;
}> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();

    const signatureValid = verifyWebhookSignature(
      params.rawBody,
      params.signatureHeader
    );
    let parsed: {
      externalEventId: string;
      eventType: "payment.succeeded" | "payment.failed";
      attemptId: string;
      reservationId: string;
      failureReason?: string;
    };
    try {
      parsed = JSON.parse(params.rawBody);
    } catch {
      const badEvt: WebhookEvent = {
        id: `whk-${crypto.randomUUID()}`,
        provider: params.provider,
        externalEventId: "malformed",
        eventType: "unknown",
        signatureValid: false,
        payloadSummary: "Malformed JSON webhook body",
        status: "invalid_signature",
        createdAt: now.toISOString(),
      };
      db.webhookEvents[badEvt.id] = badEvt;
      saveDb(storePath, db);
      return { statusCode: 400, event: badEvt };
    }

    if (!signatureValid) {
      const invalidEvt: WebhookEvent = {
        id: `whk-${crypto.randomUUID()}`,
        provider: params.provider,
        externalEventId: parsed.externalEventId || "unknown",
        eventType: parsed.eventType || "unknown",
        signatureValid: false,
        payloadSummary: `Rejected invalid HMAC signature for reservation ${parsed.reservationId}`,
        status: "invalid_signature",
        reservationId: parsed.reservationId,
        createdAt: now.toISOString(),
      };
      db.webhookEvents[invalidEvt.id] = invalidEvt;
      saveDb(storePath, db);
      return { statusCode: 401, event: invalidEvt };
    }

    // Deduplicate by externalEventId
    const duplicate = Object.values(db.webhookEvents).find(
      (e) =>
        e.externalEventId === parsed.externalEventId &&
        e.status !== "invalid_signature"
    );
    if (duplicate) {
      const dupLog: WebhookEvent = {
        id: `whk-${crypto.randomUUID()}`,
        provider: params.provider,
        externalEventId: parsed.externalEventId,
        eventType: parsed.eventType,
        signatureValid: true,
        payloadSummary: `Duplicate webhook event ${parsed.externalEventId} ignored idempotently.`,
        status: "duplicate_ignored",
        reservationId: parsed.reservationId,
        createdAt: now.toISOString(),
      };
      db.webhookEvents[dupLog.id] = dupLog;
      saveDb(storePath, db);
      return {
        statusCode: 200,
        event: dupLog,
        reservation: db.reservations[parsed.reservationId],
      };
    }

    const reservation = db.reservations[parsed.reservationId];
    const attempt = db.paymentAttempts[parsed.attemptId];

    if (!reservation || !attempt) {
      const orphanEvt: WebhookEvent = {
        id: `whk-${crypto.randomUUID()}`,
        provider: params.provider,
        externalEventId: parsed.externalEventId,
        eventType: parsed.eventType,
        signatureValid: true,
        payloadSummary: `Target reservation or attempt not found.`,
        status: "reconciliation_queued",
        reservationId: parsed.reservationId,
        createdAt: now.toISOString(),
      };
      db.webhookEvents[orphanEvt.id] = orphanEvt;
      saveDb(storePath, db);
      return { statusCode: 404, event: orphanEvt };
    }

    if (parsed.eventType === "payment.failed") {
      // Out-of-order guard: do not downgrade an already-paid reservation
      if (reservation.paymentStatus === "paid") {
        const evt: WebhookEvent = {
          id: `whk-${crypto.randomUUID()}`,
          provider: params.provider,
          externalEventId: parsed.externalEventId,
          eventType: parsed.eventType,
          signatureValid: true,
          payloadSummary: `Out-of-order failure event ignored because reservation ${reservation.confirmationCode} is already paid.`,
          status: "processed",
          reservationId: reservation.id,
          createdAt: now.toISOString(),
        };
        db.webhookEvents[evt.id] = evt;
        saveDb(storePath, db);
        return { statusCode: 200, event: evt, reservation };
      }

      attempt.status = "failed";
      attempt.failureReason =
        parsed.failureReason || "Simulated provider payment decline.";
      attempt.updatedAt = now.toISOString();
      reservation.paymentStatus = "failed";
      reservation.updatedAt = now.toISOString();

      const evt: WebhookEvent = {
        id: `whk-${crypto.randomUUID()}`,
        provider: params.provider,
        externalEventId: parsed.externalEventId,
        eventType: parsed.eventType,
        signatureValid: true,
        payloadSummary: `Payment failed for ${reservation.confirmationCode}: ${attempt.failureReason}`,
        status: "processed",
        reservationId: reservation.id,
        createdAt: now.toISOString(),
      };
      db.webhookEvents[evt.id] = evt;
      saveDb(storePath, db);
      return { statusCode: 200, event: evt, reservation };
    }

    // payment.succeeded
    const holdOutcome = finalizeHoldToBookedIfAvailable(db, reservation, now);
    if (!holdOutcome.ok) {
      attempt.status = "review_required";
      attempt.failureReason = holdOutcome.reason;
      attempt.updatedAt = now.toISOString();
      reservation.reservationStatus = "reconciliation_required";
      reservation.paymentStatus = "reconciliation_required";
      reservation.fulfillmentStatus = "on_hold";
      reservation.paidUsdCents = reservation.totalUsdCents;
      reservation.updatedAt = now.toISOString();

      const evt: WebhookEvent = {
        id: `whk-${crypto.randomUUID()}`,
        provider: params.provider,
        externalEventId: parsed.externalEventId,
        eventType: parsed.eventType,
        signatureValid: true,
        payloadSummary: `Late USD payment arrived after hold expiry for ${reservation.confirmationCode}; moved to reconciliation_required.`,
        status: "reconciliation_queued",
        reservationId: reservation.id,
        createdAt: now.toISOString(),
      };
      db.webhookEvents[evt.id] = evt;
      appendAudit(db, {
        actorUid: "webhook-processor",
        actorRole: "system",
        action: "payment.late_usd_reconciliation",
        targetType: "reservation",
        targetId: reservation.id,
        details: holdOutcome.reason || "Late USD payment reconciliation.",
      });
      saveDb(storePath, db);
      return { statusCode: 200, event: evt, reservation };
    }

    attempt.status = "paid";
    attempt.confirmations = 1;
    attempt.updatedAt = now.toISOString();
    reservation.reservationStatus = "confirmed";
    reservation.paymentStatus = "paid";
    reservation.fulfillmentStatus = "ready_for_arrival";
    reservation.paidUsdCents = reservation.totalUsdCents;
    reservation.updatedAt = now.toISOString();

    const evt: WebhookEvent = {
      id: `whk-${crypto.randomUUID()}`,
      provider: params.provider,
      externalEventId: parsed.externalEventId,
      eventType: parsed.eventType,
      signatureValid: true,
      payloadSummary: `Confirmed USD payment for ${reservation.confirmationCode}.`,
      status: "processed",
      reservationId: reservation.id,
      createdAt: now.toISOString(),
    };
    db.webhookEvents[evt.id] = evt;

    db.emailOutbox.unshift(
      buildReservationConfirmationEmail({
        id: `eml-${crypto.randomUUID()}`,
        reservation,
        accessUrl: `/reservations/${reservation.confirmationCode}`,
      })
    );

    appendAudit(db, {
      actorUid: "webhook-processor",
      actorRole: "system",
      action: "payment.usd_confirmed",
      targetType: "reservation",
      targetId: reservation.id,
      details: `Verified webhook ${parsed.externalEventId} settled ${reservation.totalUsdCents} USD cents.`,
    });

    saveDb(storePath, db);
    return { statusCode: 200, event: evt, reservation };
  });
}

export async function getReservationBundle(
  params: {
    confirmationCode: string;
    accessToken?: string | null;
    userUid?: string | null;
    userEmail?: string | null;
    isAdmin?: boolean;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{
  authorized: boolean;
  reservation?: Reservation;
  hold?: ReservationHold;
  paymentAttempts?: PaymentAttempt[];
  cryptoQuotes?: CryptoQuote[];
  refunds?: Refund[];
  emails?: EmailOutbox[];
}> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    sweepExpiredStateInMemory(db);
    saveDb(storePath, db);

    const reservation = Object.values(db.reservations).find(
      (r) =>
        r.confirmationCode.toUpperCase() ===
        params.confirmationCode.toUpperCase()
    );
    if (!reservation) return { authorized: false };

    const tokenValid = params.accessToken
      ? verifyAccessToken(params.accessToken, reservation.accessTokenHash)
      : false;
    const ownerMatch =
      (params.userUid && reservation.guestUid === params.userUid) ||
      (params.userEmail &&
        reservation.guestEmail.toLowerCase() ===
          params.userEmail.toLowerCase());

    if (!tokenValid && !ownerMatch && !params.isAdmin) {
      return { authorized: false };
    }

    return {
      authorized: true,
      reservation,
      hold: db.holds[reservation.holdId],
      paymentAttempts: Object.values(db.paymentAttempts).filter(
        (a) => a.reservationId === reservation.id
      ),
      cryptoQuotes: Object.values(db.cryptoQuotes).filter(
        (q) => q.reservationId === reservation.id
      ),
      refunds: Object.values(db.refunds).filter(
        (rf) => rf.reservationId === reservation.id
      ),
      emails: db.emailOutbox.filter(
        (e) => e.reservationId === reservation.id
      ),
    };
  });
}

export async function lookupReservationWithEmail(
  params: { confirmationCode: string; guestEmail: string },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{ found: boolean; accessToken?: string; confirmationCode?: string }> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const reservation = Object.values(db.reservations).find(
      (r) =>
        r.confirmationCode.toUpperCase() ===
          params.confirmationCode.trim().toUpperCase() &&
        r.guestEmail.toLowerCase() === params.guestEmail.trim().toLowerCase()
    );
    if (!reservation) return { found: false };

    // Rotate and issue a fresh short-lived management token on verified email+code match
    const { token, tokenHash } = generateAccessToken();
    reservation.accessTokenHash = tokenHash;
    reservation.updatedAt = new Date().toISOString();
    saveDb(storePath, db);
    return {
      found: true,
      accessToken: token,
      confirmationCode: reservation.confirmationCode,
    };
  });
}

export async function requestCancellationAndRefund(
  params: {
    confirmationCode: string;
    accessToken?: string | null;
    userUid?: string | null;
    userEmail?: string | null;
    isAdmin?: boolean;
    reason: string;
    destinationWallet?: string;
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<{ reservation: Reservation; refund: Refund | null; explanation: string }> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();
    const reservation = Object.values(db.reservations).find(
      (r) =>
        r.confirmationCode.toUpperCase() ===
        params.confirmationCode.toUpperCase()
    );
    if (!reservation) throw new Error("Reservation not found.");

    const tokenValid = params.accessToken
      ? verifyAccessToken(params.accessToken, reservation.accessTokenHash)
      : false;
    const ownerMatch =
      (params.userUid && reservation.guestUid === params.userUid) ||
      (params.userEmail &&
        reservation.guestEmail.toLowerCase() ===
          params.userEmail.toLowerCase());
    if (!tokenValid && !ownerMatch && !params.isAdmin) {
      throw new Error("Unauthorized to cancel this reservation.");
    }

    if (reservation.reservationStatus === "cancelled") {
      throw new Error("Reservation is already cancelled.");
    }

    // Release held or booked inventory
    const hold = db.holds[reservation.holdId];
    const dates = buildDateRangeForHold(reservation.checkIn, reservation.nights);
    if (hold?.status === "active") {
      for (const d of dates) {
        const inv =
          db.nightlyInventory[`${reservation.propertyId}_${reservation.roomTypeId}_${d}`];
        if (inv) inv.heldUnits = Math.max(0, inv.heldUnits - reservation.roomCount);
      }
      hold.status = "released";
    } else if (hold?.status === "converted") {
      for (const d of dates) {
        const inv =
          db.nightlyInventory[`${reservation.propertyId}_${reservation.roomTypeId}_${d}`];
        if (inv) inv.bookedUnits = Math.max(0, inv.bookedUnits - reservation.roomCount);
      }
    }

    const entitlement = calculateRefundEntitlementCents({
      paidUsdCents: reservation.paidUsdCents,
      totalUsdCents: reservation.totalUsdCents,
      nights: reservation.nights,
      checkInDate: reservation.checkIn,
      refundable: reservation.cancellationPolicySnapshot.refundable,
      freeCancellationHoursBeforeCheckIn:
        reservation.cancellationPolicySnapshot
          .freeCancellationHoursBeforeCheckIn,
      now,
    });

    reservation.reservationStatus = "cancelled";
    reservation.fulfillmentStatus = "cancelled";
    reservation.updatedAt = now.toISOString();

    let refund: Refund | null = null;
    if (reservation.paidUsdCents > 0) {
      reservation.paymentStatus = "refund_pending";
      const settledAttempt = Object.values(db.paymentAttempts).find(
        (a) => a.reservationId === reservation.id && a.status === "paid"
      );
      const settledQuote = settledAttempt?.quoteId
        ? db.cryptoQuotes[settledAttempt.quoteId]
        : undefined;

      let tokenAmountBaseUnits: string | undefined;
      let displayTokenAmount: string | undefined;
      let tokenAssetId: string | undefined;
      let tokenTicker: "$TRUMP" | "USD1" | undefined;
      let conversionTimestamp: string | undefined;

      if (settledQuote && entitlement.netUsdRefundCents > 0) {
        const asset = CRYPTO_ASSET_ALLOWLIST[settledQuote.assetId];
        if (asset) {
          const baseUnits = usdCentsToTokenBaseUnits(
            entitlement.netUsdRefundCents,
            asset.referenceUsdRateString,
            asset.decimals,
            "down"
          );
          tokenAssetId = asset.assetId;
          tokenTicker = asset.ticker;
          tokenAmountBaseUnits = baseUnits.toString();
          displayTokenAmount = formatTokenBaseUnits(baseUnits, asset.decimals, 6);
          conversionTimestamp = now.toISOString();
        }
      }

      refund = {
        id: `rfd-${crypto.randomUUID()}`,
        reservationId: reservation.id,
        confirmationCode: reservation.confirmationCode,
        paymentAttemptId: settledAttempt?.id,
        requestedBy: reservation.guestEmail,
        status: "requested",
        usdEntitlementCents: entitlement.usdEntitlementCents,
        feeUsdCents: entitlement.feeUsdCents,
        netUsdRefundCents: entitlement.netUsdRefundCents,
        refundMethod: reservation.paymentMethod,
        tokenAssetId,
        tokenTicker,
        tokenAmountBaseUnits,
        displayTokenAmount,
        conversionTimestamp,
        destinationWallet: params.destinationWallet?.trim(),
        walletVerified: false,
        reason: params.reason.trim(),
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
      };
      db.refunds[refund.id] = refund;
    }

    appendAudit(db, {
      actorUid: params.userUid || reservation.guestEmail,
      actorRole: params.isAdmin ? "admin" : "guest",
      action: "reservation.cancelled",
      targetType: "reservation",
      targetId: reservation.id,
      details: `${entitlement.explanation}`,
    });

    saveDb(storePath, db);
    return { reservation, refund, explanation: entitlement.explanation };
  });
}

export async function adminResolveRefund(
  params: {
    refundId: string;
    actorUid: string;
    actorRole: AdminRole;
    decision: "approve" | "reject";
    walletVerified?: boolean;
    adminNotes?: string;
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<Refund> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();
    const refund = db.refunds[params.refundId];
    if (!refund) throw new Error("Refund record not found.");
    if (refund.status === "completed" || refund.status === "rejected") {
      throw new Error(`Refund is already finalized (${refund.status}).`);
    }

    const reservation = db.reservations[refund.reservationId];
    if (params.decision === "reject") {
      refund.status = "rejected";
      refund.approvedBy = params.actorUid;
      refund.adminNotes = params.adminNotes;
      refund.updatedAt = now.toISOString();
      if (reservation && reservation.paymentStatus === "refund_pending") {
        reservation.paymentStatus = "paid";
        reservation.updatedAt = now.toISOString();
      }
    } else {
      if (
        refund.refundMethod !== "usd_card" &&
        refund.netUsdRefundCents > 0 &&
        !params.walletVerified &&
        !refund.walletVerified
      ) {
        throw new Error(
          "Crypto refund approval requires explicit destination wallet verification."
        );
      }
      refund.walletVerified = Boolean(
        params.walletVerified || refund.walletVerified
      );
      refund.status = "completed";
      refund.approvedBy = params.actorUid;
      refund.adminNotes = params.adminNotes;
      refund.updatedAt = now.toISOString();
      if (reservation) {
        reservation.paymentStatus = "refunded";
        reservation.updatedAt = now.toISOString();
      }
    }

    appendAudit(db, {
      actorUid: params.actorUid,
      actorRole: params.actorRole,
      action: `refund.${params.decision}`,
      targetType: "refund",
      targetId: refund.id,
      details: `Refund ${refund.id} for ${refund.confirmationCode} marked ${refund.status}.`,
    });

    saveDb(storePath, db);
    return refund;
  });
}

export async function adminReconcileReservation(
  params: {
    reservationId: string;
    actorUid: string;
    actorRole: AdminRole;
    action: "confirm_if_space" | "mark_for_refund";
    notes?: string;
    now?: Date;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<Reservation> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const now = params.now ?? new Date();
    const reservation = db.reservations[params.reservationId];
    if (!reservation) throw new Error("Reservation not found.");

    if (params.action === "confirm_if_space") {
      const dates = buildDateRangeForHold(
        reservation.checkIn,
        reservation.nights
      );
      for (const d of dates) {
        const inv =
          db.nightlyInventory[
            `${reservation.propertyId}_${reservation.roomTypeId}_${d}`
          ];
        if (!inv || inv.totalUnits - inv.heldUnits - inv.bookedUnits < reservation.roomCount) {
          throw new Error(
            `Cannot confirm reservation: insufficient inventory remaining on ${d}. Issue a refund instead.`
          );
        }
      }
      for (const d of dates) {
        const inv =
          db.nightlyInventory[
            `${reservation.propertyId}_${reservation.roomTypeId}_${d}`
          ]!;
        inv.bookedUnits += reservation.roomCount;
      }
      reservation.reservationStatus = "confirmed";
      reservation.paymentStatus = "paid";
      reservation.fulfillmentStatus = "ready_for_arrival";
      reservation.updatedAt = now.toISOString();
    } else {
      reservation.reservationStatus = "cancelled";
      reservation.paymentStatus = "refund_pending";
      reservation.fulfillmentStatus = "cancelled";
      reservation.updatedAt = now.toISOString();

      const rfd: Refund = {
        id: `rfd-${crypto.randomUUID()}`,
        reservationId: reservation.id,
        confirmationCode: reservation.confirmationCode,
        requestedBy: params.actorUid,
        status: "requested",
        usdEntitlementCents: reservation.paidUsdCents || reservation.totalUsdCents,
        feeUsdCents: 0,
        netUsdRefundCents: reservation.paidUsdCents || reservation.totalUsdCents,
        refundMethod: reservation.paymentMethod,
        walletVerified: false,
        reason:
          params.notes ||
          "Reconciliation exception resolved via full refund initiation.",
        createdAt: now.toISOString(),
        updatedAt: now.toISOString(),
      };
      db.refunds[rfd.id] = rfd;
    }

    appendAudit(db, {
      actorUid: params.actorUid,
      actorRole: params.actorRole,
      action: `reconciliation.${params.action}`,
      targetType: "reservation",
      targetId: reservation.id,
      details: params.notes || `Admin reconciled ${reservation.confirmationCode}.`,
    });

    saveDb(storePath, db);
    return reservation;
  });
}

export async function createEnquiry(
  params: {
    guestName: string;
    guestEmail: string;
    subject: string;
    message: string;
    propertyId?: string;
    reservationId?: string;
    guestUid?: string;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<Enquiry> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const enquiry: Enquiry = {
      id: `enq-${crypto.randomUUID()}`,
      guestName: params.guestName.trim(),
      guestEmail: params.guestEmail.trim().toLowerCase(),
      subject: params.subject.trim(),
      message: params.message.trim(),
      propertyId: params.propertyId,
      reservationId: params.reservationId,
      guestUid: params.guestUid,
      status: "open",
      createdAt: new Date().toISOString(),
    };
    db.enquiries[enquiry.id] = enquiry;
    saveDb(storePath, db);
    return enquiry;
  });
}

export async function getAdminRoleForUser(
  uid: string,
  email: string | undefined,
  emailVerified: boolean | undefined,
  storePath: string = DEFAULT_STORE_PATH
): Promise<AdminRole | null> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const byUid = db.admins[uid];
    if (byUid && byUid.active) return byUid.role;
    if (email && emailVerified) {
      const normalized = email.toLowerCase();
      const match = Object.values(db.admins).find(
        (a) => a.active && a.email.toLowerCase() === normalized
      );
      if (match) return match.role;
    }
    return null;
  });
}

export async function getAdminOverview(
  storePath: string = DEFAULT_STORE_PATH
): Promise<HospitalityDatabase> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    sweepExpiredStateInMemory(db);
    saveDb(storePath, db);
    return db;
  });
}

export async function updateInventoryUnitsOrRate(
  params: {
    propertyId: string;
    roomTypeId: string;
    date: string;
    totalUnits?: number;
    overrideRateUsdCents?: number;
    actorUid: string;
    actorRole: AdminRole;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<NightlyInventory> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const rt = db.roomTypes.find(
      (r) => r.id === params.roomTypeId && r.propertyId === params.propertyId
    );
    if (!rt) throw new Error("Room type not found.");
    const inv = ensureInventoryRecord(db, params.propertyId, rt, params.date);
    if (typeof params.totalUnits === "number" && params.totalUnits >= 0) {
      inv.totalUnits = params.totalUnits;
    }
    if (typeof params.overrideRateUsdCents === "number" && params.overrideRateUsdCents > 0) {
      inv.overrideRateUsdCents = params.overrideRateUsdCents;
    }
    appendAudit(db, {
      actorUid: params.actorUid,
      actorRole: params.actorRole,
      action: "inventory.updated",
      targetType: "nightlyInventory",
      targetId: inv.id,
      details: `Updated ${inv.id}: totalUnits=${inv.totalUnits}, overrideRate=${inv.overrideRateUsdCents ?? "default"}.`,
    });
    saveDb(storePath, db);
    return inv;
  });
}

export async function updateEnquiryStatus(
  params: {
    enquiryId: string;
    status: Enquiry["status"];
    actorUid: string;
    actorRole: AdminRole;
  },
  storePath: string = DEFAULT_STORE_PATH
): Promise<Enquiry> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    const enq = db.enquiries[params.enquiryId];
    if (!enq) throw new Error("Enquiry not found.");
    enq.status = params.status;
    appendAudit(db, {
      actorUid: params.actorUid,
      actorRole: params.actorRole,
      action: "enquiry.status_updated",
      targetType: "enquiry",
      targetId: enq.id,
      details: `Status set to ${params.status}.`,
    });
    saveDb(storePath, db);
    return enq;
  });
}

export async function listReservationsForUser(
  params: { uid?: string; email?: string },
  storePath: string = DEFAULT_STORE_PATH
): Promise<Reservation[]> {
  return withStoreLock(storePath, () => {
    const db = loadDb(storePath);
    sweepExpiredStateInMemory(db);
    saveDb(storePath, db);
    return Object.values(db.reservations)
      .filter(
        (r) =>
          (params.uid && r.guestUid === params.uid) ||
          (params.email &&
            r.guestEmail.toLowerCase() === params.email.toLowerCase())
      )
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  });
}
