import type { CryptoAssetConfig } from "./types";

/**
 * Explicit Crypto Asset Allowlist.
 *
 * IMPORTANT COMPLIANCE & DESIGN BOUNDARY:
 * - Never identify a crypto asset by ticker alone.
 * - Each option binds an explicit (assetId, network, tokenIdentifier, decimals).
 * - Because live merchant acceptance and verified production settlement endpoints
 *   are not configured in this independent design concept, all assets default to
 *   `liveSupported: false` and `simulationOnly: true`.
 * - We do NOT assume USD1 always equals exactly $1.000000 USD.
 */
export const CRYPTO_ASSET_ALLOWLIST: Record<string, CryptoAssetConfig> = {
  "trump-solana-spl-sim": {
    assetId: "trump-solana-spl-sim",
    paymentMethod: "trump_token",
    ticker: "$TRUMP",
    assetName: "$TRUMP Token (Proposed Simulation Adapter)",
    network: "Solana Mainnet-Beta (Simulated Settlement)",
    tokenIdentifier: "SOLANA:SPL:SIMULATED_TRUMP_NOT_FOR_LIVE_FUNDS",
    decimals: 6,
    liveSupported: false,
    simulationOnly: true,
    referenceUsdRateString: "8.400000", // 1 token = $8.400000 USD in simulated feed
    rateSource: "Simulated Reference Rate Feed (Demo Only — Non-Executable)",
    networkFeeUsdCents: 150, // $1.50 simulated network settlement fee
    requiredConfirmations: 32,
    demoDepositAddress: "SimDemoVaultTRUMP11111111111111111111111111",
    notes:
      "Proposed $TRUMP checkout option for demonstration only. Do not send real on-chain assets; live acceptance requires verified merchant contract allowlist and custody settlement.",
  },
  "usd1-eth-erc20-sim": {
    assetId: "usd1-eth-erc20-sim",
    paymentMethod: "usd1_stablecoin",
    ticker: "USD1",
    assetName: "USD1 Stablecoin (Ethereum Simulated Adapter)",
    network: "Ethereum Mainnet (Simulated Settlement)",
    tokenIdentifier: "ETHEREUM:ERC20:SIMULATED_USD1_NOT_FOR_LIVE_FUNDS",
    decimals: 6,
    liveSupported: false,
    simulationOnly: true,
    referenceUsdRateString: "0.999400", // Explicitly non-1:1 peg demonstration
    rateSource: "Simulated Reference Peg Feed ($0.9994/USD1 — Non-1:1 Precision)",
    networkFeeUsdCents: 450, // $4.50 simulated L1 gas coverage
    requiredConfirmations: 12,
    demoDepositAddress: "0x000000000000000000000000000000000000dEaD",
    notes:
      "Proposed USD1 stablecoin checkout on Ethereum (Simulated). Does not assume 1:1 USD parity; live support requires verified ERC-20 contract configuration and settlement provider.",
  },
  "usd1-bsc-bep20-sim": {
    assetId: "usd1-bsc-bep20-sim",
    paymentMethod: "usd1_stablecoin",
    ticker: "USD1",
    assetName: "USD1 Stablecoin (BNB Chain Simulated Adapter)",
    network: "BNB Smart Chain (Simulated Settlement)",
    tokenIdentifier: "BSC:BEP20:SIMULATED_USD1_NOT_FOR_LIVE_FUNDS",
    decimals: 18,
    liveSupported: false,
    simulationOnly: true,
    referenceUsdRateString: "0.999600",
    rateSource: "Simulated Reference Peg Feed ($0.9996/USD1 — Non-1:1 Precision)",
    networkFeeUsdCents: 50,
    requiredConfirmations: 15,
    demoDepositAddress: "0x000000000000000000000000000000000000dEaD",
    notes:
      "Proposed USD1 stablecoin checkout on BNB Smart Chain (Simulated, 18 decimals). Distinct network and decimal precision from Ethereum ERC-20.",
  },
};

export function getAllowlistedAssetsForMethod(
  method: "trump_token" | "usd1_stablecoin"
): CryptoAssetConfig[] {
  return Object.values(CRYPTO_ASSET_ALLOWLIST).filter(
    (a) => a.paymentMethod === method
  );
}

export function validateAssetAllowlist(
  assetId: string,
  network: string,
  tokenIdentifier: string
): { valid: boolean; asset?: CryptoAssetConfig; reason?: string } {
  const asset = CRYPTO_ASSET_ALLOWLIST[assetId];
  if (!asset) {
    return { valid: false, reason: `Asset ID '${assetId}' is not on the explicit allowlist.` };
  }
  if (asset.network !== network) {
    return {
      valid: false,
      reason: `Network mismatch: expected '${asset.network}', received '${network}'.`,
    };
  }
  if (asset.tokenIdentifier !== tokenIdentifier) {
    return {
      valid: false,
      reason: `Token identifier mismatch: expected '${asset.tokenIdentifier}', received '${tokenIdentifier}'.`,
    };
  }
  return { valid: true, asset };
}

/**
 * Parse a decimal string (e.g. "8.400000") into scaled integer numerator/denominator
 * without floating point loss.
 */
function parseDecimalToScaledInt(decimalStr: string, targetScale: number): bigint {
  const trimmed = decimalStr.trim();
  if (!/^\d+(\.\d+)?$/.test(trimmed)) {
    throw new Error(`Invalid decimal string: ${decimalStr}`);
  }
  const [intPart, fracPart = ""] = trimmed.split(".");
  const paddedFrac = (fracPart + "0".repeat(targetScale)).slice(0, targetScale);
  return BigInt(intPart + paddedFrac);
}

/**
 * Exact BigInt conversion from USD minor units (cents) to token base units.
 *
 * Formula:
 *   usdDollars = totalUsdCents / 100
 *   tokens = usdDollars / usdPerToken
 *   baseUnits = (totalUsdCents * 10^(decimals + rateScale)) / (100 * rateScaled)
 *
 * Rounding mode:
 * - "up" (ceiling) for customer payment quotes so merchant never under-collects due to truncation.
 * - "down" (floor) for refund token estimates unless rounded half-even.
 */
export function usdCentsToTokenBaseUnits(
  totalUsdCents: number,
  usdPerTokenString: string,
  decimals: number,
  rounding: "up" | "down" = "up"
): bigint {
  if (!Number.isInteger(totalUsdCents) || totalUsdCents < 0) {
    throw new Error("USD cents must be a non-negative integer.");
  }
  const rateScale = 8;
  const rateScaled = parseDecimalToScaledInt(usdPerTokenString, rateScale);
  if (rateScaled <= BigInt(0)) {
    throw new Error("Exchange rate must be strictly positive.");
  }

  const tenPowScale = BigInt("1" + "0".repeat(decimals + rateScale));
  const numerator = BigInt(totalUsdCents) * tenPowScale;
  const denominator = BigInt(100) * rateScaled;

  const quotient = numerator / denominator;
  const remainder = numerator % denominator;

  if (rounding === "up" && remainder > BigInt(0)) {
    return quotient + BigInt(1);
  }
  return quotient;
}

/**
 * Exact BigInt formatting from base units to human-readable decimal string.
 */
export function formatTokenBaseUnits(
  baseUnits: string | bigint,
  decimals: number,
  displayDecimals = 6
): string {
  const value = typeof baseUnits === "string" ? BigInt(baseUnits) : baseUnits;
  const divisor = BigInt("1" + "0".repeat(decimals));
  const whole = value / divisor;
  const remainder = value % divisor;
  const fracFull = remainder.toString().padStart(decimals, "0");
  const fracSliced = fracFull.slice(0, Math.min(decimals, displayDecimals));
  return fracSliced.length > 0 ? `${whole.toString()}.${fracSliced}` : whole.toString();
}

export function formatUsdCents(cents: number): string {
  const negative = cents < 0;
  const abs = Math.abs(cents);
  const dollars = Math.floor(abs / 100);
  const rem = abs % 100;
  return `${negative ? "-" : ""}$${dollars.toLocaleString("en-US")}.${rem
    .toString()
    .padStart(2, "0")}`;
}
