/**
 * AUREOM.AI — BIOMASS.OS
 * Core Data Models & Type Definitions for Biomass Power Plant Digital Twin
 */

export type PlantArchitecture = 
  | 'direct_combustion' 
  | 'chp' 
  | 'gasification' 
  | 'heat_only' 
  | 'co_firing';

export type FurnaceType = 
  | 'moving_grate' 
  | 'bubbling_fluidised_bed' 
  | 'circulating_fluidised_bed' 
  | 'pulverised_biomass';

export type GasifierType = 
  | 'fixed_bed_downdraft' 
  | 'fixed_bed_updraft' 
  | 'bubbling_fluidised_bed' 
  | 'circulating_fluidised_bed';

export type TurbineType = 
  | 'condensing' 
  | 'extraction_condensing' 
  | 'backpressure';

export type CoolingSystemType = 
  | 'wet_cooling_tower' 
  | 'air_cooled_condenser' 
  | 'once_through_water';

export type OperatingMode = 
  | 'start_up' 
  | 'normal_baseload' 
  | 'load_following' 
  | 'reduced_load' 
  | 'controlled_shutdown' 
  | 'tripped' 
  | 'maintenance';

export type AlarmSeverity = 'info' | 'warning' | 'critical';

export interface PlantAlarm {
  id: string;
  code: string;
  timestamp: string;
  subsystem: string;
  message: string;
  severity: AlarmSeverity;
  acknowledged: boolean;
  value: number;
  threshold: number;
  unit: string;
}

export interface BiomassFuel {
  id: string;
  name: string;
  category: 'forestry' | 'agricultural' | 'waste_wood' | 'energy_crop' | 'custom';
  description: string;
  // Proximate Analysis (as-received wt%)
  moisture_ar: number;       // %
  volatile_matter_dry: number; // %
  fixed_carbon_dry: number;    // %
  ash_dry: number;            // %
  // Ultimate Analysis (dry wt%)
  carbon_dry: number;         // %
  hydrogen_dry: number;       // %
  oxygen_dry: number;         // %
  nitrogen_dry: number;       // %
  sulfur_dry: number;         // %
  chlorine_dry: number;       // %
  // Physical & Chemical Properties
  bulk_density: number;       // kg/m³
  ash_deformation_temp: number; // °C
  ash_flow_temp: number;      // °C
  alkali_index: number;       // kg alkali/GJ (fouling indicator)
  cost_per_tonne: number;     // USD / tonne as-received
  upstream_co2_kg_per_tonne: number; // kg CO2e / tonne supply chain
}

export interface PlantDesignSpecs {
  plantName: string;
  architecture: PlantArchitecture;
  ratedElectricalOutputMW: number;     // e.g. 20 MW
  designNetEfficiencyPct: number;      // e.g. 25%
  ratedThermalInputMW: number;         // e.g. 80 MW
  boilerDesignPressureBar: number;     // e.g. 65 bar
  mainSteamTemperatureC: number;       // e.g. 480 °C
  designSteamMassFlowTonnesHr: number; // e.g. 78.5 t/h
  furnaceType: FurnaceType;
  gasifierType?: GasifierType;
  turbineType: TurbineType;
  coolingSystem: CoolingSystemType;
  gridVoltageKV: number;               // e.g. 110 kV or 132 kV
  designAvailabilityPct: number;       // e.g. 90%
  designCapacityFactorPct: number;     // e.g. 85%
}

export interface ThermodynamicStream {
  id: string;
  name: string;
  fluid: 'water' | 'steam' | 'two_phase' | 'flue_gas' | 'air' | 'syngas' | 'biomass';
  massFlowKgS: number;
  pressureBar: number;
  temperatureC: number;
  enthalpyKjKg: number;
  entropyKjKgK?: number;
  vaporFraction?: number; // 0 = subcooled, 1 = dry saturated / superheated
  densityKgM3?: number;
}

export interface FlueGasEmissions {
  o2_dry_pct: number;
  co2_wet_pct: number;
  co2_mass_rate_kg_s: number;
  biogenic_co2_tonnes_day: number;
  fossil_co2_tonnes_day: number;
  nox_ppm: number;
  nox_mg_nm3_ref6o2: number;
  so2_ppm: number;
  so2_mg_nm3_ref6o2: number;
  co_ppm: number;
  co_mg_nm3_ref6o2: number;
  pm_mg_nm3_ref6o2: number;
  hcl_mg_nm3_ref6o2: number;
  flue_gas_flow_nm3_hr: number;
  stack_temperature_c: number;
  sncr_efficiency_pct: number;
  baghouse_efficiency_pct: number;
  scrubber_efficiency_pct: number;
}

export interface BoilerPerformance {
  thermalPowerMW: number;
  steamFlowTonnesHr: number;
  efficiencyASME_pct: number;
  heatLossDryGas_pct: number;
  heatLossFuelMoisture_pct: number;
  heatLossHydrogenMoisture_pct: number;
  heatLossRadiationConvection_pct: number;
  heatLossUnburnedCarbon_pct: number;
  drumPressureBar: number;
  drumWaterLevelMm: number;
  steamTemperatureC: number;
  feedwaterPressureBar: number;
  feedwaterTemperatureC: number;
  economizerExitTempC: number;
  airPreheaterExitTempC: number;
  foulingFactor: number; // 1.0 = clean, >1.0 = degraded
}

export interface TurbinePerformance {
  inletPressureBar: number;
  inletTemperatureC: number;
  exhaustPressureBar: number;
  exhaustTemperatureC: number;
  exhaustVaporFraction: number;
  isentropicEfficiencyPct: number;
  mechanicalPowerMW: number;
  shaftSpeedRPM: number;
  vibrationRMS_mm_s: number;
  bearingTempC: number;
  chpExtractionFlowTonnesHr: number;
  chpExtractionPressureBar: number;
}

export interface ElectricalPerformance {
  grossElectricalPowerMW: number;
  auxiliaryPowerMW: number;
  netElectricalPowerMW: number;
  auxiliaryRatioPct: number;
  netElectricalEfficiencyPct: number;
  chpUsefulHeatMW: number;
  chpTotalEfficiencyPct: number;
  gridFrequencyHz: number;
  powerFactorCosPhi: number;
  reactivePowerMVAR: number;
  generatorTerminalKV: number;
  transformerOutputKV: number;
  annualGenerationMWh: number;
  annualHeatMWh: number;
}

export interface FinancialMetrics {
  capexUSD: number;
  opexAnnualUSD: number;
  fuelCostAnnualUSD: number;
  electricityRevenueAnnualUSD: number;
  heatRevenueAnnualUSD: number;
  carbonCreditsAnnualUSD: number;
  ebitdaAnnualUSD: number;
  lcoeUSDPerMWh: number;
  npvUSD: number;
  irrPct: number;
  simplePaybackYears: number;
}

export interface PIDController {
  id: string;
  name: string;
  unit: string;
  setpoint: number;
  processVariable: number;
  outputPct: number;
  kp: number;
  ti: number; // seconds
  td: number; // seconds
  autoMode: boolean;
  minOutput: number;
  maxOutput: number;
}

export interface SimulationState {
  timestampSeconds: number;
  simulationClockFormatted: string;
  operatingMode: OperatingMode;
  isRunning: boolean;
  timeScale: number;
  selectedEquipmentId: string | null;
  activeScenarioId: string | null;
  
  // Fuel Subsystem
  activeFuel: BiomassFuel;
  fuelFeedRateKgS: number;
  fuelFeedRateTonnesHr: number;
  fuelThermalInputMW: number;
  fuelMoistureAsReceived: number;
  bunkerInventoryTonnes: number;
  dryerActive: boolean;
  dryerHeatInputMW: number;
  fuelMoisturePostDryer: number;

  // Combustion Subsystem
  excessAirRatio: number;
  primaryAirFlowKgS: number;
  secondaryAirFlowKgS: number;
  furnaceTemperatureC: number;
  adiabaticFlameTempC: number;
  grateSpeedPct: number;
  flueGasO2WetPct: number;

  // Boiler & Steam Subsystem
  boiler: BoilerPerformance;
  
  // Turbine Subsystem
  turbine: TurbinePerformance;
  
  // Condenser & Cooling Subsystem
  condenserPressureBar: number;
  condenserCoolingDutyMW: number;
  coolingWaterFlowM3Hr: number;
  coolingWaterSupplyTempC: number;
  coolingWaterReturnTempC: number;

  // CHP
  chpEnabled: boolean;
  districtHeatingDemandMW: number;
  districtHeatingSupplyTempC: number;
  districtHeatingReturnTempC: number;

  // Emissions Subsystem
  emissions: FlueGasEmissions;
  sncrReagentFlowKgH: number;
  limeInjectionKgH: number;

  // Electrical Subsystem
  electrical: ElectricalPerformance;

  // Control Loops
  controllers: {
    boilerMaster: PIDController;
    drumLevel: PIDController;
    steamTemperature: PIDController;
    airFuelRatio: PIDController;
    furnaceDraft: PIDController;
    turbineGovernor: PIDController;
  };

  // Active Alarms
  alarms: PlantAlarm[];

  // Historical Ring Buffer (last 60 time points for telemetry graphs)
  history: {
    times: number[];
    netPowerMW: number[];
    thermalInputMW: number[];
    steamFlowTonnesHr: number[];
    boilerTempC: number[];
    efficiencyPct: number[];
    flueGasO2Pct: number[];
  };
}
