/**
 * AUREOM.AI — BIOMASS.OS
 * Biomass Fuel Laboratory: Characterization, Proximate/Ultimate Basis Conversions & Calorimetry
 */

import { BiomassFuel } from '../models/plant.models';

export const PRESET_BIOMASS_FUELS: BiomassFuel[] = [
  {
    id: 'wood_chips_forestry',
    name: 'Forestry Wood Chips (Softwood/Hardwood mix)',
    category: 'forestry',
    description: 'Fresh whole-tree and sawmill residual wood chips. Typical base fuel for grate-fired biomass power stations.',
    moisture_ar: 35.0,
    volatile_matter_dry: 80.5,
    fixed_carbon_dry: 17.8,
    ash_dry: 1.7,
    carbon_dry: 50.4,
    hydrogen_dry: 6.1,
    oxygen_dry: 42.8,
    nitrogen_dry: 0.45,
    sulfur_dry: 0.03,
    chlorine_dry: 0.02,
    bulk_density: 320,
    ash_deformation_temp: 1240,
    ash_flow_temp: 1390,
    alkali_index: 0.18,
    cost_per_tonne: 75.0,
    upstream_co2_kg_per_tonne: 18.5,
  },
  {
    id: 'wood_pellets_enplus_a1',
    name: 'Premium Wood Pellets (ENplus A1)',
    category: 'forestry',
    description: 'Mechanically densified debarked pine/spruce sawdust. Low moisture, uniform size, high calorific value.',
    moisture_ar: 7.5,
    volatile_matter_dry: 83.2,
    fixed_carbon_dry: 16.2,
    ash_dry: 0.6,
    carbon_dry: 51.2,
    hydrogen_dry: 6.2,
    oxygen_dry: 41.8,
    nitrogen_dry: 0.15,
    sulfur_dry: 0.02,
    chlorine_dry: 0.01,
    bulk_density: 680,
    ash_deformation_temp: 1320,
    ash_flow_temp: 1450,
    alkali_index: 0.08,
    cost_per_tonne: 185.0,
    upstream_co2_kg_per_tonne: 32.0,
  },
  {
    id: 'agricultural_straw_wheat',
    name: 'Agricultural Wheat Straw (Baled/Chopped)',
    category: 'agricultural',
    description: 'Post-harvest cereal straw. Fast pyrolysis, high potassium/silica ash with low melting point.',
    moisture_ar: 14.0,
    volatile_matter_dry: 74.5,
    fixed_carbon_dry: 19.5,
    ash_dry: 6.0,
    carbon_dry: 46.8,
    hydrogen_dry: 5.8,
    oxygen_dry: 40.5,
    nitrogen_dry: 0.72,
    sulfur_dry: 0.11,
    chlorine_dry: 0.28,
    bulk_density: 140,
    ash_deformation_temp: 920,
    ash_flow_temp: 1080,
    alkali_index: 0.58,
    cost_per_tonne: 55.0,
    upstream_co2_kg_per_tonne: 12.0,
  },
  {
    id: 'rice_husks',
    name: 'Milled Rice Husks / Chaff',
    category: 'agricultural',
    description: 'Grain processing by-product. Highly abrasive, elevated amorphous silica content, stable combustion.',
    moisture_ar: 10.5,
    volatile_matter_dry: 63.8,
    fixed_carbon_dry: 18.2,
    ash_dry: 18.0,
    carbon_dry: 39.8,
    hydrogen_dry: 5.0,
    oxygen_dry: 36.4,
    nitrogen_dry: 0.55,
    sulfur_dry: 0.08,
    chlorine_dry: 0.04,
    bulk_density: 125,
    ash_deformation_temp: 1380,
    ash_flow_temp: 1510,
    alkali_index: 0.22,
    cost_per_tonne: 42.0,
    upstream_co2_kg_per_tonne: 8.5,
  },
  {
    id: 'sugarcane_bagasse',
    name: 'Sugar Mill Bagasse (Moist Fibers)',
    category: 'agricultural',
    description: 'Crushed sugarcane stalks from milling. High initial moisture, rapid ignition once surface-dried.',
    moisture_ar: 48.0,
    volatile_matter_dry: 82.0,
    fixed_carbon_dry: 15.5,
    ash_dry: 2.5,
    carbon_dry: 48.5,
    hydrogen_dry: 6.0,
    oxygen_dry: 42.8,
    nitrogen_dry: 0.18,
    sulfur_dry: 0.02,
    chlorine_dry: 0.03,
    bulk_density: 160,
    ash_deformation_temp: 1180,
    ash_flow_temp: 1310,
    alkali_index: 0.19,
    cost_per_tonne: 30.0,
    upstream_co2_kg_per_tonne: 6.0,
  },
  {
    id: 'miscanthus_energy_crop',
    name: 'Miscanthus Giganteus (Elephant Grass)',
    category: 'energy_crop',
    description: 'Perennial rhizomatous C4 grass. High annual biomass yield, moderate ash fusion characteristics.',
    moisture_ar: 18.0,
    volatile_matter_dry: 77.2,
    fixed_carbon_dry: 20.1,
    ash_dry: 2.7,
    carbon_dry: 48.9,
    hydrogen_dry: 6.1,
    oxygen_dry: 41.6,
    nitrogen_dry: 0.58,
    sulfur_dry: 0.09,
    chlorine_dry: 0.12,
    bulk_density: 155,
    ash_deformation_temp: 1040,
    ash_flow_temp: 1190,
    alkali_index: 0.35,
    cost_per_tonne: 68.0,
    upstream_co2_kg_per_tonne: 9.5,
  },
  {
    id: 'clean_waste_wood',
    name: 'Recycled Wood Grade A (Packaging & Pallets)',
    category: 'waste_wood',
    description: 'Untreated demolition timber, packaging skids, and clean shipping pallets. Dry and consistent.',
    moisture_ar: 15.0,
    volatile_matter_dry: 81.0,
    fixed_carbon_dry: 17.5,
    ash_dry: 1.5,
    carbon_dry: 50.8,
    hydrogen_dry: 6.2,
    oxygen_dry: 41.2,
    nitrogen_dry: 0.25,
    sulfur_dry: 0.03,
    chlorine_dry: 0.04,
    bulk_density: 280,
    ash_deformation_temp: 1260,
    ash_flow_temp: 1410,
    alkali_index: 0.14,
    cost_per_tonne: 45.0,
    upstream_co2_kg_per_tonne: 14.0,
  }
];

export class FuelLaboratoryService {
  /**
   * Higher Heating Value (HHV) Dry Basis (MJ/kg)
   * Using Channiwala & Parikh (2002) unified equation:
   * HHV_dry = 0.3491*C + 1.1783*H + 0.1005*S - 0.1034*O - 0.0151*N - 0.0211*A
   */
  public static calculateHhvDry(fuel: BiomassFuel): number {
    const C = fuel.carbon_dry;
    const H = fuel.hydrogen_dry;
    const S = fuel.sulfur_dry;
    const O = fuel.oxygen_dry;
    const N = fuel.nitrogen_dry;
    const A = fuel.ash_dry;

    const hhv = 0.3491 * C + 1.1783 * H + 0.1005 * S - 0.1034 * O - 0.0151 * N - 0.0211 * A;
    return Math.max(10.0, Math.min(26.0, hhv));
  }

  /**
   * Lower Heating Value (LHV) on As-Received Basis (MJ/kg)
   * Accounts for sensible heat + latent heat of water evaporation (2.442 MJ/kg H2O at 25°C)
   * LHV_ar = HHV_dry * (1 - M) - 2.442 * (9 * (H_dry/100) * (1 - M) + M)
   * where M is moisture fraction (0 to 1)
   */
  public static calculateLhvAsReceived(fuel: BiomassFuel, overrideMoisturePct?: number): number {
    const moisturePct = overrideMoisturePct !== undefined ? overrideMoisturePct : fuel.moisture_ar;
    const M = Math.max(0.01, Math.min(0.65, moisturePct / 100));
    const hhvDry = this.calculateHhvDry(fuel);
    const H_dry_fraction = fuel.hydrogen_dry / 100;

    // Latent heat loss due to water formed by combustion of hydrogen + inherent fuel moisture
    const waterProduced = 9 * H_dry_fraction * (1 - M) + M;
    const lhv_ar = hhvDry * (1 - M) - 2.442 * waterProduced;
    return Math.max(4.0, lhv_ar);
  }

  /**
   * Higher Heating Value on As-Received Basis (MJ/kg)
   */
  public static calculateHhvAsReceived(fuel: BiomassFuel, overrideMoisturePct?: number): number {
    const moisturePct = overrideMoisturePct !== undefined ? overrideMoisturePct : fuel.moisture_ar;
    const M = moisturePct / 100;
    const hhvDry = this.calculateHhvDry(fuel);
    return hhvDry * (1 - M);
  }

  /**
   * Basis Conversions
   */
  public static convertAsReceivedToDry(valueAr: number, moisturePct: number): number {
    const factor = 1 - moisturePct / 100;
    return factor > 0 ? valueAr / factor : valueAr;
  }

  public static convertDryToAsReceived(valueDry: number, moisturePct: number): number {
    const factor = 1 - moisturePct / 100;
    return valueDry * factor;
  }

  public static convertDryToDaf(valueDry: number, ashDryPct: number): number {
    const factor = 1 - ashDryPct / 100;
    return factor > 0 ? valueDry / factor : valueDry;
  }

  /**
   * Calculate Stoichiometric Oxygen Requirement (kg O2 per kg dry fuel)
   * C + O2 -> CO2 (32/12 = 2.664)
   * H2 + 0.5 O2 -> H2O (16/2.016 = 7.936)
   * S + O2 -> SO2 (32/32 = 1.0)
   * minus inherent fuel oxygen
   */
  public static stoichiometricOxygenKgPerKgDry(fuel: BiomassFuel): number {
    const C = fuel.carbon_dry / 100;
    const H = fuel.hydrogen_dry / 100;
    const S = fuel.sulfur_dry / 100;
    const O = fuel.oxygen_dry / 100;

    const o2_req = 2.664 * C + 7.936 * H + 1.0 * S - O;
    return Math.max(0.5, o2_req);
  }

  /**
   * Stoichiometric Air Requirement (kg dry air per kg as-received fuel)
   * Dry air is 23.2 wt% O2
   */
  public static stoichiometricAirKgPerKgAr(fuel: BiomassFuel, moisturePct: number): number {
    const o2_dry = this.stoichiometricOxygenKgPerKgDry(fuel);
    const air_dry = o2_dry / 0.232;
    const M = moisturePct / 100;
    return air_dry * (1 - M);
  }

  /**
   * Fuel Consumption & Handling Metrics given Thermal Input
   */
  public static calculateConsumptionMetrics(
    thermalInputMW: number,
    fuel: BiomassFuel,
    moisturePct: number
  ): {
    lhvArMjKg: number;
    feedRateKgS: number;
    feedRateTonnesHr: number;
    feedRateTonnesDay: number;
    annualFeedRateTonnes: number; // 85% capacity factor
    volumeFlowM3Hr: number;
    specificCostUSDPerMWhThermal: number;
  } {
    const lhvAr = this.calculateLhvAsReceived(fuel, moisturePct);
    // thermalInputMW = feedRateKgS * lhvAr (MW = MJ/s)
    const feedRateKgS = thermalInputMW / Math.max(1, lhvAr);
    const feedRateTonnesHr = feedRateKgS * 3.6;
    const feedRateTonnesDay = feedRateTonnesHr * 24;
    const annualFeedRateTonnes = feedRateTonnesHr * 8760 * 0.85;
    const volumeFlowM3Hr = (feedRateTonnesHr * 1000) / Math.max(50, fuel.bulk_density);
    const specificCostUSDPerMWhThermal = (fuel.cost_per_tonne / (lhvAr * 1000 / 3600));

    return {
      lhvArMjKg: lhvAr,
      feedRateKgS,
      feedRateTonnesHr,
      feedRateTonnesDay,
      annualFeedRateTonnes,
      volumeFlowM3Hr,
      specificCostUSDPerMWhThermal,
    };
  }
}
