/**
 * AUREOM.AI — BIOMASS.OS
 * Rankine Steam Cycle, Turbomachinery Expansion, Condenser & Auxiliary Balance
 */

import { TurbinePerformance, ElectricalPerformance } from '../models/plant.models';
import { ThermodynamicEngine } from './thermodynamics';

export interface SteamCycleResult {
  turbine: TurbinePerformance;
  electrical: ElectricalPerformance;
  condenserCoolingDutyMW: number;
  condensateFlowKgS: number;
  feedPumpPowerMW: number;
  cycleThermalEfficiencyPct: number;
}

export class SteamCycleEngine {
  /**
   * Solve the complete Rankine cycle with optional steam extraction for CHP
   */
  public static solveCycle(
    steamMassFlowKgS: number,
    inletPressureBar: number,
    inletTempC: number,
    condenserPressureBar = 0.08,
    isentropicEfficiency = 0.84,
    generatorEfficiency = 0.975,
    chpExtractionFlowTonnesHr = 0,
    chpExtractionPressureBar = 3.5,
    fuelThermalInputMW = 80.0
  ): SteamCycleResult {
    // Inlet state
    const h_in = ThermodynamicEngine.steamEnthalpyKjKg(inletPressureBar, inletTempC);
    
    // CHP Extraction Flow (convert to kg/s)
    const extractionFlowKgS = Math.min(steamMassFlowKgS * 0.85, (chpExtractionFlowTonnesHr * 1000) / 3600);
    const condensingFlowKgS = Math.max(0.1, steamMassFlowKgS - extractionFlowKgS);

    // 1. High-Pressure expansion from inlet down to extraction pressure (or to exhaust if no extraction)
    const eff_hp = isentropicEfficiency;
    const hpExpansion = ThermodynamicEngine.solveTurbineExpansion(
      inletPressureBar,
      inletTempC,
      extractionFlowKgS > 0 ? chpExtractionPressureBar : condenserPressureBar,
      eff_hp
    );

    // 2. Low-Pressure expansion for the remaining steam down to condenser pressure
    let totalShaftPowerKW = 0;
    let finalExhaustTempC = hpExpansion.exhaustTempC;
    let finalVaporFraction = hpExpansion.vaporFraction;
    let h_exhaust = hpExpansion.h_out_act;

    if (extractionFlowKgS > 0) {
      // Steam through HP section produces:
      const w_hp = steamMassFlowKgS * (h_in - hpExpansion.h_out_act);
      
      // Steam through LP section expands from extraction state to condenser:
      const lpExpansion = ThermodynamicEngine.solveTurbineExpansion(
        chpExtractionPressureBar,
        hpExpansion.exhaustTempC,
        condenserPressureBar,
        isentropicEfficiency * 0.97 // LP stages have slight wetness loss
      );
      const w_lp = condensingFlowKgS * (hpExpansion.h_out_act - lpExpansion.h_out_act);
      
      totalShaftPowerKW = w_hp + w_lp;
      finalExhaustTempC = lpExpansion.exhaustTempC;
      finalVaporFraction = lpExpansion.vaporFraction;
      h_exhaust = lpExpansion.h_out_act;
    } else {
      // Pure condensing expansion
      totalShaftPowerKW = steamMassFlowKgS * (h_in - hpExpansion.h_out_act);
      finalExhaustTempC = hpExpansion.exhaustTempC;
      finalVaporFraction = hpExpansion.vaporFraction;
      h_exhaust = hpExpansion.h_out_act;
    }

    const mechanicalPowerMW = Math.max(0, totalShaftPowerKW / 1000);

    // Generator electrical output
    const grossElectricalPowerMW = mechanicalPowerMW * generatorEfficiency;

    // Condenser heat rejection:
    // Q_cond = m_condensing * (h_exhaust - h_f_condenser)
    const h_f_cond = ThermodynamicEngine.saturatedLiquidEnthalpy(condenserPressureBar);
    const condenserCoolingDutyMW = Math.max(0, (condensingFlowKgS * (h_exhaust - h_f_cond)) / 1000);

    // Useful heat output from extraction for CHP:
    // Heat exchanger cools extraction steam down to condensate at 70°C (~293 kJ/kg)
    const h_dh_condensate = 4.186 * 70;
    const chpUsefulHeatMW = extractionFlowKgS > 0
      ? (extractionFlowKgS * (hpExpansion.h_out_act - h_dh_condensate)) / 1000
      : 0;

    // Boiler Feedwater Pump Work:
    // w_p = v * deltaP / eta_pump
    // v ≈ 0.001 m3/kg, deltaP in kPa, eta ≈ 0.78
    const deltaP_kpa = (inletPressureBar * 1.15 - condenserPressureBar) * 100;
    const pumpWorkKjKg = (0.001 * deltaP_kpa) / 0.78;
    const feedPumpPowerMW = (steamMassFlowKgS * pumpWorkKjKg) / 1000;

    // Parasitic Plant Auxiliary Power Breakdown:
    // 1. Boiler feed pump: ~1.2 - 2.5 MW depending on pressure
    // 2. Draft fans (Induced Draft + Forced Draft + Primary Air + Secondary Air): ~1.8 - 2.5% of gross
    // 3. Cooling system pumps & fans: ~1.5 - 2.2% of gross
    // 4. Fuel handling, conveyors, screens, dryers: ~0.8 - 1.5% of gross
    // 5. Flue gas treatment (ESP / Baghouse, SCR, compressors, CEMS): ~0.7 - 1.2% of gross
    // 6. Station lighting, control systems, transformers, auxiliaries: ~0.5%
    const auxFans = grossElectricalPowerMW * 0.022;
    const auxCooling = grossElectricalPowerMW * 0.018;
    const auxFuelHandling = grossElectricalPowerMW * 0.012;
    const auxEmissions = grossElectricalPowerMW * 0.009;
    const auxStation = 0.12; // MW constant base
    const totalAuxiliaryMW = feedPumpPowerMW + auxFans + auxCooling + auxFuelHandling + auxEmissions + auxStation;

    const netElectricalPowerMW = Math.max(0, grossElectricalPowerMW - totalAuxiliaryMW);
    const auxiliaryRatioPct = grossElectricalPowerMW > 0 ? (totalAuxiliaryMW / grossElectricalPowerMW) * 100 : 0;
    const netElectricalEfficiencyPct = fuelThermalInputMW > 0 ? (netElectricalPowerMW / fuelThermalInputMW) * 100 : 0;
    const chpTotalEfficiencyPct = fuelThermalInputMW > 0 ? ((netElectricalPowerMW + chpUsefulHeatMW) / fuelThermalInputMW) * 100 : 0;

    // Standard Grid & Synchronous parameters
    const powerFactorCosPhi = 0.88;
    const apparentPowerMVA = netElectricalPowerMW / powerFactorCosPhi;
    const reactivePowerMVAR = Math.sqrt(Math.max(0, apparentPowerMVA ** 2 - netElectricalPowerMW ** 2));

    // Annual projections at 85% capacity factor
    const annualHours = 8760 * 0.85; // 7,446 operating hours/year
    const annualGenerationMWh = netElectricalPowerMW * annualHours;
    const annualHeatMWh = chpUsefulHeatMW * annualHours;

    const turbine: TurbinePerformance = {
      inletPressureBar,
      inletTemperatureC: inletTempC,
      exhaustPressureBar: condenserPressureBar,
      exhaustTemperatureC: finalExhaustTempC,
      exhaustVaporFraction: finalVaporFraction,
      isentropicEfficiencyPct: isentropicEfficiency * 100,
      mechanicalPowerMW,
      shaftSpeedRPM: 3000, // 50 Hz synchronous
      vibrationRMS_mm_s: 1.85, // healthy limit < 2.8 mm/s
      bearingTempC: 62.4,      // healthy limit < 75 °C
      chpExtractionFlowTonnesHr,
      chpExtractionPressureBar,
    };

    const electrical: ElectricalPerformance = {
      grossElectricalPowerMW,
      auxiliaryPowerMW: totalAuxiliaryMW,
      netElectricalPowerMW,
      auxiliaryRatioPct,
      netElectricalEfficiencyPct,
      chpUsefulHeatMW,
      chpTotalEfficiencyPct,
      gridFrequencyHz: 50.00,
      powerFactorCosPhi,
      reactivePowerMVAR,
      generatorTerminalKV: 11.0,
      transformerOutputKV: 132.0,
      annualGenerationMWh,
      annualHeatMWh,
    };

    const cycleThermalEfficiencyPct = ((h_in - h_exhaust) / (h_in - h_f_cond)) * 100;

    return {
      turbine,
      electrical,
      condenserCoolingDutyMW,
      condensateFlowKgS: condensingFlowKgS,
      feedPumpPowerMW,
      cycleThermalEfficiencyPct,
    };
  }
}
