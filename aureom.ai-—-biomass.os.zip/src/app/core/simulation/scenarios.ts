/**
 * AUREOM.AI — BIOMASS.OS
 * Predefined Engineering Scenarios & Disturbance Laboratory
 */

import { SimulationState } from '../models/plant.models';

export interface SimulationScenarioDef {
  id: string;
  code: string;
  title: string;
  description: string;
  targetSubsystem: string;
  expectedOutcome: string;
  applyModifications: (state: SimulationState) => void;
  resetModifications: (state: SimulationState) => void;
}

export const SCENARIO_LIBRARY: SimulationScenarioDef[] = [
  {
    id: 'scenario_a',
    code: 'SCN-A',
    title: 'Wet Biomass Delivery (Moisture Surge)',
    description: 'Incoming fuel delivery moisture jumps from nominal 35% to 48% due to heavy seasonal rainfall on un-tarped wood chip stockpiles.',
    targetSubsystem: 'Fuel Handling & Combustion',
    expectedOutcome: 'LHV_ar drops from ~10.8 to ~7.8 MJ/kg. Fuel feed rate ramps +38% to hold thermal rating; furnace bed cools by ~120°C; stack moisture loss increases, dropping boiler efficiency.',
    applyModifications: (state) => {
      state.fuelMoistureAsReceived = 48.0;
    },
    resetModifications: (state) => {
      state.fuelMoistureAsReceived = 35.0;
    }
  },
  {
    id: 'scenario_b',
    code: 'SCN-B',
    title: 'Reduced Fuel Quality (High Inert Ash)',
    description: 'Fuel blend contaminated with soil and low-energy agricultural stalks, decreasing dry heating value by 22% and raising ash to 9.5%.',
    targetSubsystem: 'Fuel Lab & Ash Management',
    expectedOutcome: 'Calorific value falls. Fuel master controller drives feeder screws to maximum output; bottom ash discharge rate quadruples.',
    applyModifications: (state) => {
      state.activeFuel = {
        ...state.activeFuel,
        ash_dry: 9.5,
        carbon_dry: 42.0,
      };
    },
    resetModifications: (state) => {
      state.activeFuel = {
        ...state.activeFuel,
        ash_dry: 1.7,
        carbon_dry: 50.4,
      };
    }
  },
  {
    id: 'scenario_c',
    code: 'SCN-C',
    title: 'Superheater & Economiser Tube Fouling',
    description: 'Alkali slagging and fly ash cake accumulation on pendant superheater tube banks increases thermal resistance by 40%.',
    targetSubsystem: 'Boiler & Heat Exchangers',
    expectedOutcome: 'Reduced heat absorption into steam. Flue gas stack exit temperature rises from 142°C to 188°C; boiler efficiency drops ~3.8%; soot-blower sequence recommended.',
    applyModifications: (state) => {
      state.boiler.foulingFactor = 1.40;
    },
    resetModifications: (state) => {
      state.boiler.foulingFactor = 1.00;
    }
  },
  {
    id: 'scenario_d',
    code: 'SCN-D',
    title: 'High Ambient Summer Heatwave',
    description: 'Extreme ambient dry bulb temperature reaches 38°C with high relative humidity, reducing cooling tower thermal rejection capacity.',
    targetSubsystem: 'Cooling & Condenser',
    expectedOutcome: 'Cooling water temperature rises; surface condenser backpressure deteriorates from 0.08 bar to 0.155 bar abs. Turbine enthalpy drop contracts, reducing gross electrical output by 1.6 MW.',
    applyModifications: (state) => {
      state.condenserPressureBar = 0.155;
      state.coolingWaterSupplyTempC = 32.5;
    },
    resetModifications: (state) => {
      state.condenserPressureBar = 0.08;
      state.coolingWaterSupplyTempC = 22.0;
    }
  },
  {
    id: 'scenario_e',
    code: 'SCN-E',
    title: 'District Heating Peak Demand (CHP Cogeneration)',
    description: 'Municipal district heating network requests an immediate 22 MWth heat export surge during sub-zero winter freeze.',
    targetSubsystem: 'Steam Turbine & CHP',
    expectedOutcome: 'Turbine extraction control valve opens, diverting 32 t/h steam from LP cylinder to district heating condenser. Electrical power drops by 3.2 MWe while total plant efficiency surges to 74.5%.',
    applyModifications: (state) => {
      state.chpEnabled = true;
      state.districtHeatingDemandMW = 22.0;
      state.turbine.chpExtractionFlowTonnesHr = 32.0;
    },
    resetModifications: (state) => {
      state.chpEnabled = false;
      state.districtHeatingDemandMW = 0.0;
      state.turbine.chpExtractionFlowTonnesHr = 0.0;
    }
  },
  {
    id: 'scenario_f',
    code: 'SCN-F',
    title: 'Fuel Feed Choke & Conveyor Interruption',
    description: 'Over-sized root wood chunk bridges live-bottom screw feeder B, reducing fuel delivery by 55% abruptly.',
    targetSubsystem: 'Fuel Handling & Boiler Master',
    expectedOutcome: 'Fuel feed rate collapses. Boiler drum pressure begins dropping rapidly; turbine governor closes control valves to protect boiler pressure; plant initiates controlled runback.',
    applyModifications: (state) => {
      state.fuelFeedRateKgS = state.fuelFeedRateKgS * 0.45;
    },
    resetModifications: (state) => {
      state.fuelFeedRateKgS = 7.42;
    }
  },
  {
    id: 'scenario_g',
    code: 'SCN-G',
    title: 'SNCR De-NOx Dosing Pump Trip',
    description: 'Aqueous ammonia reagent delivery pump trips due to thermal overload, halting reagent injection into upper furnace.',
    targetSubsystem: 'Flue Gas Cleaning & Emissions',
    expectedOutcome: 'SNCR NOx abatement efficiency drops to 0%. Stack NOx escalates from 145 mg/Nm3 to 380 mg/Nm3, breaching the 200 mg/Nm3 regulatory limit and triggering high-priority CEMS alarms.',
    applyModifications: (state) => {
      state.sncrReagentFlowKgH = 0.0;
    },
    resetModifications: (state) => {
      state.sncrReagentFlowKgH = 35.0;
    }
  },
  {
    id: 'scenario_h',
    code: 'SCN-H',
    title: 'Start-Up Warming & Synchronization Sequence',
    description: 'Transition boiler and turbomachinery from hot standby to grid-synchronized 100% MCR baseload.',
    targetSubsystem: 'Virtual Control Room & Automation',
    expectedOutcome: 'Controlled ramp of fuel feed, steam pressure elevation to 65 bar, turbine rotor warm-up to 3000 RPM, auto-synchronization and circuit breaker closing.',
    applyModifications: (state) => {
      state.operatingMode = 'start_up';
    },
    resetModifications: (state) => {
      state.operatingMode = 'normal_baseload';
    }
  }
];
