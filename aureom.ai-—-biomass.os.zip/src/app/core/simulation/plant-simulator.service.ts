/**
 * AUREOM.AI — BIOMASS.OS
 * Central Plant Simulator Service
 * Executes dynamic time-domain integration, closed-loop PID control, and physical conservation laws
 */

import { Injectable, signal, computed } from '@angular/core';
import {
  SimulationState,
  PlantAlarm,
  BiomassFuel,
} from '../models/plant.models';
import { PRESET_BIOMASS_FUELS, FuelLaboratoryService } from './fuel-laboratory';
import { CombustionEngine } from './combustion-engine';
import { SteamCycleEngine } from './steam-cycle';
import { EmissionsEngine } from './emissions-engine';
import { SCENARIO_LIBRARY } from './scenarios';

@Injectable({
  providedIn: 'root',
})
export class PlantSimulatorService {
  private timerHandle: ReturnType<typeof setInterval> | null = null;
  private readonly HISTORY_LENGTH = 50;

  // Initial State Factory
  private createInitialState(): SimulationState {
    const defaultFuel = PRESET_BIOMASS_FUELS[0]; // Forestry wood chips
    const initialFeedRateKgS = 7.42; // ~26.7 t/h for ~80 MWth at 10.8 MJ/kg
    const initialMoisture = 35.0;

    const combustion = CombustionEngine.solveCombustion(
      defaultFuel,
      initialFeedRateKgS,
      initialMoisture,
      4.2, // 4.2% dry O2
      0.65,
      20,
      142,
      65,
      480,
      135,
      1.0
    );

    const steamCycle = SteamCycleEngine.solveCycle(
      combustion.boilerPerformance.steamFlowTonnesHr / 3.6,
      65,
      480,
      0.08,
      0.84,
      0.975,
      0,
      3.5,
      initialFeedRateKgS * FuelLaboratoryService.calculateLhvAsReceived(defaultFuel, initialMoisture)
    );

    const emissions = EmissionsEngine.calculateEmissions(
      defaultFuel,
      initialFeedRateKgS,
      initialMoisture,
      combustion.flueGasFlowNm3Hr,
      combustion.flueGasO2DryPct,
      combustion.furnaceBedTempC,
      35,
      25,
      true,
      true
    );

    return {
      timestampSeconds: 0,
      simulationClockFormatted: '00:00:00',
      operatingMode: 'normal_baseload',
      isRunning: true,
      timeScale: 1.0,
      selectedEquipmentId: 'furnace_boiler',
      activeScenarioId: null,

      // Fuel
      activeFuel: defaultFuel,
      fuelFeedRateKgS: initialFeedRateKgS,
      fuelFeedRateTonnesHr: initialFeedRateKgS * 3.6,
      fuelThermalInputMW: initialFeedRateKgS * FuelLaboratoryService.calculateLhvAsReceived(defaultFuel, initialMoisture),
      fuelMoistureAsReceived: initialMoisture,
      bunkerInventoryTonnes: 1450.0,
      dryerActive: false,
      dryerHeatInputMW: 0.0,
      fuelMoisturePostDryer: initialMoisture,

      // Combustion
      excessAirRatio: combustion.excessAirRatioLambda,
      primaryAirFlowKgS: combustion.primaryAirFlowKgS,
      secondaryAirFlowKgS: combustion.secondaryAirFlowKgS,
      furnaceTemperatureC: combustion.furnaceBedTempC,
      adiabaticFlameTempC: combustion.adiabaticFlameTempC,
      grateSpeedPct: 72.0,
      flueGasO2WetPct: combustion.flueGasO2WetPct,

      // Boiler
      boiler: combustion.boilerPerformance,

      // Turbine
      turbine: steamCycle.turbine,

      // Cooling & Condenser
      condenserPressureBar: 0.08,
      condenserCoolingDutyMW: steamCycle.condenserCoolingDutyMW,
      coolingWaterFlowM3Hr: 3400,
      coolingWaterSupplyTempC: 22.0,
      coolingWaterReturnTempC: 32.5,

      // CHP
      chpEnabled: false,
      districtHeatingDemandMW: 0.0,
      districtHeatingSupplyTempC: 95.0,
      districtHeatingReturnTempC: 55.0,

      // Emissions
      emissions,
      sncrReagentFlowKgH: 35.0,
      limeInjectionKgH: 25.0,

      // Electrical
      electrical: steamCycle.electrical,

      // Control Loops
      controllers: {
        boilerMaster: {
          id: 'pic_boiler',
          name: 'Boiler Master (Steam Header Pressure)',
          unit: 'bar',
          setpoint: 65.0,
          processVariable: 65.0,
          outputPct: 75.0,
          kp: 1.8,
          ti: 45.0,
          td: 5.0,
          autoMode: true,
          minOutput: 20,
          maxOutput: 100,
        },
        drumLevel: {
          id: 'lic_drum',
          name: 'Boiler Drum Water Level',
          unit: 'mm',
          setpoint: 0.0,
          processVariable: 0.0,
          outputPct: 62.0,
          kp: 2.2,
          ti: 30.0,
          td: 8.0,
          autoMode: true,
          minOutput: 10,
          maxOutput: 100,
        },
        steamTemperature: {
          id: 'tic_steam',
          name: 'Main Steam Attemperator Temperature',
          unit: '°C',
          setpoint: 480.0,
          processVariable: 480.0,
          outputPct: 15.0,
          kp: 1.2,
          ti: 60.0,
          td: 12.0,
          autoMode: true,
          minOutput: 0,
          maxOutput: 60,
        },
        airFuelRatio: {
          id: 'aic_o2',
          name: 'Excess O2 Air/Fuel Controller',
          unit: '%',
          setpoint: 4.2,
          processVariable: 4.2,
          outputPct: 70.0,
          kp: 1.5,
          ti: 40.0,
          td: 4.0,
          autoMode: true,
          minOutput: 20,
          maxOutput: 100,
        },
        furnaceDraft: {
          id: 'pic_draft',
          name: 'Furnace Draft Pressure (ID Fan)',
          unit: 'Pa',
          setpoint: -50.0,
          processVariable: -50.0,
          outputPct: 68.0,
          kp: 0.8,
          ti: 15.0,
          td: 2.0,
          autoMode: true,
          minOutput: 10,
          maxOutput: 100,
        },
        turbineGovernor: {
          id: 'sic_turbine',
          name: 'Turbine Speed & Load Governor',
          unit: 'MW',
          setpoint: 20.0,
          processVariable: 20.0,
          outputPct: 88.0,
          kp: 2.5,
          ti: 20.0,
          td: 0.0,
          autoMode: true,
          minOutput: 0,
          maxOutput: 100,
        },
      },

      alarms: [],

      history: {
        times: Array.from({ length: this.HISTORY_LENGTH }, (_, i) => i - this.HISTORY_LENGTH),
        netPowerMW: Array.from({ length: this.HISTORY_LENGTH }, () => 20.0),
        thermalInputMW: Array.from({ length: this.HISTORY_LENGTH }, () => 80.0),
        steamFlowTonnesHr: Array.from({ length: this.HISTORY_LENGTH }, () => 78.5),
        boilerTempC: Array.from({ length: this.HISTORY_LENGTH }, () => 920.0),
        efficiencyPct: Array.from({ length: this.HISTORY_LENGTH }, () => 25.0),
        flueGasO2Pct: Array.from({ length: this.HISTORY_LENGTH }, () => 4.2),
      },
    };
  }

  // Reactive state signals
  public readonly state = signal<SimulationState>(this.createInitialState());

  // Computed properties
  public readonly netElectricalMW = computed(() => this.state().electrical.netElectricalPowerMW);
  public readonly grossElectricalMW = computed(() => this.state().electrical.grossElectricalPowerMW);
  public readonly thermalInputMW = computed(() => this.state().fuelThermalInputMW);
  public readonly netEfficiencyPct = computed(() => this.state().electrical.netElectricalEfficiencyPct);
  public readonly boilerEfficiencyPct = computed(() => this.state().boiler.efficiencyASME_pct);
  public readonly steamFlowTonnesHr = computed(() => this.state().boiler.steamFlowTonnesHr);
  public readonly fuelFeedTonnesHr = computed(() => this.state().fuelFeedRateTonnesHr);
  public readonly activeAlarmsCount = computed(() => this.state().alarms.length);

  constructor() {
    this.startSimulationLoop();
  }

  public startSimulationLoop(): void {
    if (this.timerHandle) clearInterval(this.timerHandle);
    this.timerHandle = setInterval(() => {
      if (this.state().isRunning) {
        this.stepSimulation(1.0);
      }
    }, 1000);
  }

  /**
   * Primary time-domain integration step
   */
  public stepSimulation(deltaSec = 1.0): void {
    this.state.update((current) => {
      const dt = deltaSec * current.timeScale;
      const nextTime = current.timestampSeconds + dt;

      // Format clock HH:MM:SS
      const hours = Math.floor(nextTime / 3600);
      const mins = Math.floor((nextTime % 3600) / 60);
      const secs = Math.floor(nextTime % 60);
      const clockStr = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

      // 1. Check PID Controllers
      // Boiler Master: holds steam header pressure at setpoint by modulating fuel feed rate
      let effectiveFeedRate = current.fuelFeedRateKgS;
      if (current.controllers.boilerMaster.autoMode) {
        const pErr = current.controllers.boilerMaster.setpoint - current.boiler.drumPressureBar;
        const feedAdjust = (pErr * 0.08) * (dt / 10);
        effectiveFeedRate = Math.max(1.5, Math.min(14.0, effectiveFeedRate + feedAdjust));
      }

      // Check dryer effect:
      let effectiveMoisture = current.fuelMoistureAsReceived;
      if (current.dryerActive && current.dryerHeatInputMW > 0) {
        // Latent heat evaporation reduces moisture
        const moistureReduction = Math.min(15.0, (current.dryerHeatInputMW / 4.0) * 8.0);
        effectiveMoisture = Math.max(10.0, effectiveMoisture - moistureReduction);
      }

      // 2. Solve Combustion & Boiler
      const targetO2 = current.controllers.airFuelRatio.setpoint;
      const combustion = CombustionEngine.solveCombustion(
        current.activeFuel,
        effectiveFeedRate,
        effectiveMoisture,
        targetO2,
        0.65,
        20,
        142,
        current.boiler.drumPressureBar - 4.5,
        current.boiler.steamTemperatureC,
        current.boiler.feedwaterTemperatureC,
        current.boiler.foulingFactor
      );

      // 3. Solve Steam Cycle & Turbine
      const extractionFlow = current.chpEnabled ? current.turbine.chpExtractionFlowTonnesHr : 0;
      const steamCycle = SteamCycleEngine.solveCycle(
        combustion.boilerPerformance.steamFlowTonnesHr / 3.6,
        combustion.boilerPerformance.drumPressureBar - 4.5,
        combustion.boilerPerformance.steamTemperatureC,
        current.condenserPressureBar,
        0.84,
        0.975,
        extractionFlow,
        3.5,
        effectiveFeedRate * FuelLaboratoryService.calculateLhvAsReceived(current.activeFuel, effectiveMoisture)
      );

      // 4. Solve Emissions
      const emissions = EmissionsEngine.calculateEmissions(
        current.activeFuel,
        effectiveFeedRate,
        effectiveMoisture,
        combustion.flueGasFlowNm3Hr,
        combustion.flueGasO2DryPct,
        combustion.furnaceBedTempC,
        current.sncrReagentFlowKgH,
        current.limeInjectionKgH,
        true,
        current.sncrReagentFlowKgH > 0
      );

      // 5. Update Bunker Inventory
      const fuelBurntTonnes = (effectiveFeedRate * 3.6 * dt) / 3600;
      const newInventory = Math.max(0, current.bunkerInventoryTonnes - fuelBurntTonnes);

      // 6. Check Alarm Limits
      const updatedAlarms: PlantAlarm[] = [];
      const nowStr = clockStr;

      if (combustion.boilerPerformance.drumPressureBar > 71.0) {
        updatedAlarms.push({
          id: 'alm_hp',
          code: 'ALM-101',
          timestamp: nowStr,
          subsystem: 'Boiler Island',
          message: 'Boiler Drum Pressure Approaching Safety Relief Lift (71.0 bar)',
          severity: 'critical',
          acknowledged: false,
          value: combustion.boilerPerformance.drumPressureBar,
          threshold: 71.0,
          unit: 'bar',
        });
      }

      if (emissions.nox_mg_nm3_ref6o2 > 200.0) {
        updatedAlarms.push({
          id: 'alm_nox',
          code: 'ALM-204',
          timestamp: nowStr,
          subsystem: 'Emissions CEMS',
          message: 'Stack NOx Concentration Exceeds Regulatory Threshold (200 mg/Nm3 @ 6% O2)',
          severity: 'warning',
          acknowledged: false,
          value: emissions.nox_mg_nm3_ref6o2,
          threshold: 200.0,
          unit: 'mg/Nm3',
        });
      }

      if (combustion.furnaceBedTempC < 750.0) {
        updatedAlarms.push({
          id: 'alm_bed_low',
          code: 'ALM-302',
          timestamp: nowStr,
          subsystem: 'Combustion Chamber',
          message: 'Furnace Bed Temperature Low (< 750°C) — Incomplete Combustion Risk',
          severity: 'warning',
          acknowledged: false,
          value: combustion.furnaceBedTempC,
          threshold: 750.0,
          unit: '°C',
        });
      }

      if (current.condenserPressureBar > 0.12) {
        updatedAlarms.push({
          id: 'alm_vac',
          code: 'ALM-401',
          timestamp: nowStr,
          subsystem: 'Cooling / Condenser',
          message: 'Condenser Vacuum Deteriorated (> 0.12 bar abs) — High Backpressure',
          severity: 'warning',
          acknowledged: false,
          value: current.condenserPressureBar,
          threshold: 0.12,
          unit: 'bar',
        });
      }

      // 7. Update History Ring Buffer
      const newTimes = [...current.history.times.slice(1), nextTime];
      const newNetPower = [...current.history.netPowerMW.slice(1), steamCycle.electrical.netElectricalPowerMW];
      const newThermal = [...current.history.thermalInputMW.slice(1), effectiveFeedRate * FuelLaboratoryService.calculateLhvAsReceived(current.activeFuel, effectiveMoisture)];
      const newSteam = [...current.history.steamFlowTonnesHr.slice(1), combustion.boilerPerformance.steamFlowTonnesHr];
      const newTemp = [...current.history.boilerTempC.slice(1), combustion.furnaceBedTempC];
      const newEff = [...current.history.efficiencyPct.slice(1), steamCycle.electrical.netElectricalEfficiencyPct];
      const newO2 = [...current.history.flueGasO2Pct.slice(1), combustion.flueGasO2DryPct];

      return {
        ...current,
        timestampSeconds: nextTime,
        simulationClockFormatted: clockStr,
        fuelFeedRateKgS: effectiveFeedRate,
        fuelFeedRateTonnesHr: effectiveFeedRate * 3.6,
        fuelThermalInputMW: effectiveFeedRate * FuelLaboratoryService.calculateLhvAsReceived(current.activeFuel, effectiveMoisture),
        fuelMoisturePostDryer: effectiveMoisture,
        bunkerInventoryTonnes: newInventory,
        excessAirRatio: combustion.excessAirRatioLambda,
        primaryAirFlowKgS: combustion.primaryAirFlowKgS,
        secondaryAirFlowKgS: combustion.secondaryAirFlowKgS,
        furnaceTemperatureC: combustion.furnaceBedTempC,
        adiabaticFlameTempC: combustion.adiabaticFlameTempC,
        flueGasO2WetPct: combustion.flueGasO2WetPct,
        boiler: combustion.boilerPerformance,
        turbine: steamCycle.turbine,
        condenserCoolingDutyMW: steamCycle.condenserCoolingDutyMW,
        emissions,
        electrical: steamCycle.electrical,
        alarms: updatedAlarms,
        history: {
          times: newTimes,
          netPowerMW: newNetPower,
          thermalInputMW: newThermal,
          steamFlowTonnesHr: newSteam,
          boilerTempC: newTemp,
          efficiencyPct: newEff,
          flueGasO2Pct: newO2,
        },
      };
    });
  }

  // Interactive controls
  public togglePlayPause(): void {
    this.state.update((s) => ({ ...s, isRunning: !s.isRunning }));
  }

  public setTimeScale(scale: number): void {
    this.state.update((s) => ({ ...s, timeScale: scale }));
  }

  public selectEquipment(id: string | null): void {
    this.state.update((s) => ({ ...s, selectedEquipmentId: id }));
  }

  public setFuel(fuel: BiomassFuel): void {
    this.state.update((s) => ({
      ...s,
      activeFuel: fuel,
      fuelMoistureAsReceived: fuel.moisture_ar,
    }));
    this.stepSimulation(0.1);
  }

  public setFuelMoisture(moisturePct: number): void {
    this.state.update((s) => ({
      ...s,
      fuelMoistureAsReceived: Math.max(5.0, Math.min(60.0, moisturePct)),
    }));
    this.stepSimulation(0.1);
  }

  public setFuelFeedRate(kgS: number): void {
    this.state.update((s) => ({
      ...s,
      fuelFeedRateKgS: Math.max(1.0, Math.min(18.0, kgS)),
    }));
    this.stepSimulation(0.1);
  }

  public setBoilerPressureSetpoint(bar: number): void {
    this.state.update((s) => ({
      ...s,
      controllers: {
        ...s.controllers,
        boilerMaster: {
          ...s.controllers.boilerMaster,
          setpoint: Math.max(30, Math.min(90, bar)),
        },
      },
    }));
  }

  public setChpExtraction(tonnesHr: number): void {
    this.state.update((s) => ({
      ...s,
      chpEnabled: tonnesHr > 0,
      turbine: {
        ...s.turbine,
        chpExtractionFlowTonnesHr: Math.max(0, Math.min(50, tonnesHr)),
      },
    }));
    this.stepSimulation(0.1);
  }

  public toggleDryer(active: boolean): void {
    this.state.update((s) => ({
      ...s,
      dryerActive: active,
      dryerHeatInputMW: active ? 4.5 : 0.0,
    }));
    this.stepSimulation(0.1);
  }

  public triggerScenario(scenarioId: string): void {
    const scn = SCENARIO_LIBRARY.find((s) => s.id === scenarioId);
    if (!scn) return;

    this.state.update((s) => {
      const copy = { ...s, activeScenarioId: scenarioId };
      scn.applyModifications(copy);
      return copy;
    });
    this.stepSimulation(0.1);
  }

  public clearScenario(): void {
    const scnId = this.state().activeScenarioId;
    if (scnId) {
      const scn = SCENARIO_LIBRARY.find((s) => s.id === scnId);
      if (scn) {
        this.state.update((s) => {
          const copy = { ...s, activeScenarioId: null };
          scn.resetModifications(copy);
          return copy;
        });
      }
    } else {
      this.state.update((s) => ({ ...s, activeScenarioId: null }));
    }
    this.stepSimulation(0.1);
  }

  public resetSimulation(): void {
    this.state.set(this.createInitialState());
  }
}
