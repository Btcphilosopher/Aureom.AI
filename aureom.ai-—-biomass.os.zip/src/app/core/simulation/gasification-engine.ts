/**
 * AUREOM.AI — BIOMASS.OS
 * Gasification Physics, Syngas Equilibrium & Cold Gas Efficiency (CGE)
 */

import { BiomassFuel } from '../models/plant.models';
import { FuelLaboratoryService } from './fuel-laboratory';

export interface GasificationResult {
  equivalenceRatio: number;
  producerGasNm3KgFuel: number;
  producerGasLhvMjNm3: number;
  coldGasEfficiencyPct: number;
  carbonConversionPct: number;
  tarContentGM3: number;
  syngasCompositionVolPct: {
    co: number;
    h2: number;
    ch4: number;
    co2: number;
    n2: number;
    h2o: number;
  };
  gasYieldNm3Hr: number;
  gasThermalPowerMW: number;
}

export class GasificationEngine {
  /**
   * Gasification solver based on modified equilibrium and empirical tar/species correlations
   */
  public static solveGasification(
    fuel: BiomassFuel,
    fuelFeedRateKgS: number,
    moisturePct: number,
    gasifierTempC = 850,
    steamToBiomassRatio = 0.25,
    airEquivalenceRatio = 0.28
  ): GasificationResult {
    const M = moisturePct / 100;
    const dryFraction = 1 - M;

    const lhvFuelAr = FuelLaboratoryService.calculateLhvAsReceived(fuel, moisturePct);
    const fuelThermalInputMW = fuelFeedRateKgS * lhvFuelAr;

    // Equivalence ratio phi (air provided / stoich air)
    const ER = Math.max(0.18, Math.min(0.45, airEquivalenceRatio));

    // Gas composition empirical model calibrated to downdraft/fluidized gasifiers at 800-900°C:
    // As ER increases, CO and H2 decrease while CO2 and N2 increase
    // Higher moisture lowers CO and increases H2/CO2 via water-gas shift: CO + H2O <-> CO2 + H2
    const T_norm = (gasifierTempC - 700) / 300; // 0 to 1

    let co_vol = 21.5 - 22.0 * (ER - 0.25) + 3.5 * T_norm - 8.0 * M;
    let h2_vol = 16.0 - 15.0 * (ER - 0.25) + 4.0 * (steamToBiomassRatio - 0.2) + 2.0 * T_norm;
    let ch4_vol = 3.2 - 3.5 * (ER - 0.25) - 1.2 * T_norm;
    let co2_vol = 12.5 + 14.0 * (ER - 0.25) + 6.0 * M;
    let n2_vol = 45.0 + 35.0 * (ER - 0.25);
    let h2o_vol = 4.5 + 8.0 * M + 5.0 * steamToBiomassRatio;

    // Normalize sum to 100%
    const total = co_vol + h2_vol + ch4_vol + co2_vol + n2_vol + h2o_vol;
    co_vol = Math.max(8.0, (co_vol / total) * 100);
    h2_vol = Math.max(8.0, (h2_vol / total) * 100);
    ch4_vol = Math.max(0.5, (ch4_vol / total) * 100);
    co2_vol = Math.max(8.0, (co2_vol / total) * 100);
    n2_vol = Math.max(35.0, (n2_vol / total) * 100);
    h2o_vol = Math.max(2.0, (h2o_vol / total) * 100);

    // Dry syngas LHV:
    // LHV = 0.126 * CO + 0.108 * H2 + 0.358 * CH4 (MJ/Nm3)
    const producerGasLhvMjNm3 = 0.126 * co_vol + 0.108 * h2_vol + 0.358 * ch4_vol;

    // Specific producer gas yield: ~2.1 - 2.8 Nm3 / kg dry fuel
    const producerGasNm3KgFuel = (2.1 + 1.8 * (ER - 0.2)) * dryFraction;
    const gasYieldNm3Hr = producerGasNm3KgFuel * (fuelFeedRateKgS * 3600);
    const gasThermalPowerMW = (gasYieldNm3Hr * producerGasLhvMjNm3) / 3600;

    // Cold Gas Efficiency (CGE) = (V_gas * LHV_gas) / (m_fuel * LHV_fuel)
    const coldGasEfficiencyPct = Math.min(88, Math.max(55, (gasThermalPowerMW / Math.max(0.1, fuelThermalInputMW)) * 100));
    
    // Carbon conversion efficiency
    const carbonConversionPct = Math.min(99.2, 92.0 + 12.0 * (ER - 0.2) + 4.0 * T_norm);

    // Tar content decreases with higher bed temperature
    const tarContentGM3 = Math.max(0.2, 12.0 * Math.exp(-0.0045 * (gasifierTempC - 700)));

    return {
      equivalenceRatio: ER,
      producerGasNm3KgFuel,
      producerGasLhvMjNm3,
      coldGasEfficiencyPct,
      carbonConversionPct,
      tarContentGM3,
      syngasCompositionVolPct: {
        co: co_vol,
        h2: h2_vol,
        ch4: ch4_vol,
        co2: co2_vol,
        n2: n2_vol,
        h2o: h2o_vol,
      },
      gasYieldNm3Hr,
      gasThermalPowerMW,
    };
  }
}
