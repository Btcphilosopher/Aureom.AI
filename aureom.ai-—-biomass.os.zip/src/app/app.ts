/**
 * AUREOM.AI — BIOMASS.OS
 * Industrial Biomass Power Plant Digital Twin, Engineering Simulator & Virtual Control Room
 * "FROM BIOMASS TO BASELOAD."
 */

import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PlantSimulatorService } from './core/simulation/plant-simulator.service';
import { PRESET_BIOMASS_FUELS } from './core/simulation/fuel-laboratory';
import { SCENARIO_LIBRARY } from './core/simulation/scenarios';
import { PlantOptimisationEngine, OptimisationResult } from './core/simulation/optimisation';
import { FinancialAndCarbonEngine, CarbonAccountingMetrics } from './core/simulation/financial-carbon';
import { GasificationEngine, GasificationResult } from './core/simulation/gasification-engine';
import { BiomassFuel, FinancialMetrics } from './core/models/plant.models';
import { DigitalTwinComponent } from './features/digital-twin/digital-twin.component';
import { PfdEditorComponent } from './features/pfd-editor/pfd-editor.component';
import { ControlRoomComponent } from './features/control-room/control-room.component';

export type SubsystemView =
  | 'overview'
  | 'digital_twin'
  | 'fuel_lab'
  | 'fuel_reception'
  | 'fuel_handling'
  | 'combustion'
  | 'gasification'
  | 'boiler'
  | 'turbine'
  | 'chp'
  | 'emissions'
  | 'cooling'
  | 'electrical'
  | 'control_room'
  | 'scenarios'
  | 'optimisation'
  | 'reliability'
  | 'financial'
  | 'sustainability'
  | 'reports';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    DigitalTwinComponent,
    PfdEditorComponent,
    ControlRoomComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public readonly simService = inject(PlantSimulatorService);

  // Active Navigation View
  public readonly activeView = signal<SubsystemView>('overview');
  public readonly isSidebarCollapsed = signal<boolean>(false);
  public readonly isAlarmsDrawerOpen = signal<boolean>(false);

  // Math helper for templates
  public readonly Math = Math;

  // Preset fuels & scenario lists
  public readonly presetFuels = PRESET_BIOMASS_FUELS;
  public readonly scenarios = SCENARIO_LIBRARY;

  // Navigation Items (The 20 Subsystems)
  public readonly navItems: { id: SubsystemView; label: string; icon: string; category: string }[] = [
    { id: 'overview', label: 'Plant Overview', icon: 'dashboard', category: 'Executive' },
    { id: 'digital_twin', label: '3D Digital Twin', icon: 'view_in_ar', category: 'Executive' },
    { id: 'control_room', label: 'Control Room', icon: 'tune', category: 'Operations' },
    { id: 'reports', label: 'PFD & Balances', icon: 'schema', category: 'Operations' },
    { id: 'scenarios', label: 'Scenario Laboratory', icon: 'science', category: 'Operations' },
    { id: 'fuel_lab', label: 'Fuel Laboratory', icon: 'biotech', category: 'Thermal Island' },
    { id: 'fuel_reception', label: 'Fuel Reception & Storage', icon: 'warehouse', category: 'Thermal Island' },
    { id: 'fuel_handling', label: 'Handling & Drying', icon: 'conveyor_belt', category: 'Thermal Island' },
    { id: 'combustion', label: 'Combustion Systems', icon: 'local_fire_department', category: 'Thermal Island' },
    { id: 'gasification', label: 'Gasification Systems', icon: 'cloud_sync', category: 'Thermal Island' },
    { id: 'boiler', label: 'Boiler & Steam Gen', icon: 'boiler', category: 'Thermal Island' },
    { id: 'turbine', label: 'Turbine & Generator', icon: 'cyclone', category: 'Power Block' },
    { id: 'chp', label: 'Heat Recovery & CHP', icon: 'heat_pump', category: 'Power Block' },
    { id: 'cooling', label: 'Cooling & Condenser', icon: 'water', category: 'Power Block' },
    { id: 'electrical', label: 'Electrical Grid', icon: 'bolt', category: 'Power Block' },
    { id: 'emissions', label: 'Flue Gas & Emissions', icon: 'air', category: 'Environmental' },
    { id: 'sustainability', label: 'Carbon Accounting', icon: 'eco', category: 'Environmental' },
    { id: 'optimisation', label: 'Plant Optimisation', icon: 'auto_graph', category: 'Engineering' },
    { id: 'reliability', label: 'Reliability & MTBF', icon: 'build_circle', category: 'Engineering' },
    { id: 'financial', label: 'Financial (LCOE/NPV)', icon: 'payments', category: 'Engineering' },
  ];

  // Fuel Lab State
  public readonly selectedLabFuel = signal<BiomassFuel>(PRESET_BIOMASS_FUELS[0]);
  public readonly labMoistureOverride = signal<number>(35.0);

  // Gasification State
  public readonly gasifierEquivalenceRatio = signal<number>(0.28);
  public readonly gasifierTempC = signal<number>(850);
  public readonly gasificationResult = computed<GasificationResult>(() => {
    return GasificationEngine.solveGasification(
      this.simService.state().activeFuel,
      this.simService.state().fuelFeedRateKgS,
      this.simService.state().fuelMoistureAsReceived,
      this.gasifierTempC(),
      0.25,
      this.gasifierEquivalenceRatio()
    );
  });

  // Optimisation Engine State
  public readonly optObjective = signal<'max_power' | 'max_margin' | 'min_cost' | 'min_emissions' | 'max_chp'>('max_margin');
  public readonly optFuel2 = signal<BiomassFuel>(PRESET_BIOMASS_FUELS[1]); // Wood pellets
  public readonly optResult = computed<OptimisationResult>(() => {
    return PlantOptimisationEngine.optimizePlant(
      this.simService.state().activeFuel,
      this.optFuel2(),
      this.optObjective()
    );
  });

  // Financial Metrics State
  public readonly financialTariffUSD = signal<number>(115.0);
  public readonly financialMetrics = computed<FinancialMetrics>(() => {
    const s = this.simService.state();
    const annualFuel = s.fuelFeedRateTonnesHr * 8760 * 0.85;
    return FinancialAndCarbonEngine.calculateFinancials(
      20.0,
      s.electrical.netElectricalPowerMW,
      annualFuel,
      s.activeFuel.cost_per_tonne,
      s.electrical.annualGenerationMWh,
      s.electrical.annualHeatMWh,
      this.financialTariffUSD(),
      42.0,
      35.0,
      7.5,
      25
    );
  });

  // Carbon Accounting State
  public readonly carbonMetrics = computed<CarbonAccountingMetrics>(() => {
    const s = this.simService.state();
    const annualFuel = s.fuelFeedRateTonnesHr * 8760 * 0.85;
    return FinancialAndCarbonEngine.calculateCarbonAccounting(
      s.activeFuel,
      annualFuel,
      s.electrical.annualGenerationMWh,
      s.electrical.annualHeatMWh,
      75
    );
  });

  // Reliability Equipment Items
  public readonly reliabilityItems = [
    { name: 'Live-Bottom Screw Feeder A', mtbfHours: 8500, vibrationMmS: 1.45, tempC: 45.2, status: 'Healthy', wearPct: 18 },
    { name: 'Primary Air Forced Draft Fan', mtbfHours: 18200, vibrationMmS: 1.82, tempC: 58.1, status: 'Healthy', wearPct: 32 },
    { name: 'Induced Draft (ID) Flue Gas Fan', mtbfHours: 12400, vibrationMmS: 2.35, tempC: 68.4, status: 'Monitoring', wearPct: 62 },
    { name: 'High-Pressure Boiler Feed Pump #1', mtbfHours: 24000, vibrationMmS: 1.15, tempC: 52.0, status: 'Healthy', wearPct: 24 },
    { name: 'Steam Turbine Front Radial Bearing', mtbfHours: 45000, vibrationMmS: 1.85, tempC: 62.4, status: 'Healthy', wearPct: 15 },
    { name: 'Generator Drive-End Journal Bearing', mtbfHours: 50000, vibrationMmS: 1.62, tempC: 59.8, status: 'Healthy', wearPct: 12 },
    { name: 'Pulse-Jet Baghouse Solenoid Valves', mtbfHours: 9200, vibrationMmS: 0.80, tempC: 38.5, status: 'Healthy', wearPct: 40 },
    { name: 'Cooling Water Circulation Pump #1', mtbfHours: 16000, vibrationMmS: 1.95, tempC: 48.6, status: 'Healthy', wearPct: 38 },
  ];

  public navigateTo(view: SubsystemView): void {
    this.activeView.set(view);
  }

  public setLabFuel(fuelId: string): void {
    const f = PRESET_BIOMASS_FUELS.find((fuel) => fuel.id === fuelId);
    if (f) {
      this.selectedLabFuel.set(f);
      this.labMoistureOverride.set(f.moisture_ar);
    }
  }

  public applyLabFuelToPlant(): void {
    const f = this.selectedLabFuel();
    this.simService.setFuel(f);
    this.simService.setFuelMoisture(this.labMoistureOverride());
  }

  public updateLabMoisture(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.labMoistureOverride.set(val);
  }

  public toggleSidebar(): void {
    this.isSidebarCollapsed.update((v) => !v);
  }

  public toggleAlarmsDrawer(): void {
    this.isAlarmsDrawerOpen.update((v) => !v);
  }

  public acknowledgeAlarm(alarmId: string): void {
    this.simService.state.update((s) => ({
      ...s,
      alarms: s.alarms.map((a) => (a.id === alarmId ? { ...a, acknowledged: true } : a)),
    }));
  }

  public triggerScenario(id: string): void {
    this.simService.triggerScenario(id);
  }

  public clearScenario(): void {
    this.simService.clearScenario();
  }

  public getActiveScenarioTitle(): string | null {
    const id = this.simService.state().activeScenarioId;
    if (!id) return null;
    const scn = SCENARIO_LIBRARY.find((s) => s.id === id);
    return scn ? scn.title : null;
  }

  // Quick export telemetry to CSV
  public exportTelemetryCsv(): void {
    const s = this.simService.state();
    const rows = [
      ['Timestamp', s.simulationClockFormatted],
      ['Plant Architecture', 'Direct Combustion Steam Rankine'],
      ['Active Fuel', s.activeFuel.name],
      ['Fuel Moisture (% AR)', s.fuelMoistureAsReceived.toString()],
      ['Fuel Feed Rate (kg/s)', s.fuelFeedRateKgS.toFixed(3)],
      ['Fuel Feed Rate (t/h)', s.fuelFeedRateTonnesHr.toFixed(2)],
      ['Thermal Input (MW)', s.fuelThermalInputMW.toFixed(2)],
      ['Boiler Steam Flow (t/h)', s.boiler.steamFlowTonnesHr.toFixed(2)],
      ['Drum Pressure (bar)', s.boiler.drumPressureBar.toFixed(2)],
      ['Steam Temperature (°C)', s.boiler.steamTemperatureC.toFixed(1)],
      ['Boiler ASME Efficiency (%)', s.boiler.efficiencyASME_pct.toFixed(2)],
      ['Turbine Mechanical Power (MW)', s.turbine.mechanicalPowerMW.toFixed(2)],
      ['Gross Electrical Power (MW)', s.electrical.grossElectricalPowerMW.toFixed(2)],
      ['Auxiliary Power (MW)', s.electrical.auxiliaryPowerMW.toFixed(2)],
      ['Net Electrical Power (MW)', s.electrical.netElectricalPowerMW.toFixed(2)],
      ['Net Electrical Efficiency (%)', s.electrical.netElectricalEfficiencyPct.toFixed(2)],
      ['Stack NOx (mg/Nm3 @ 6% O2)', s.emissions.nox_mg_nm3_ref6o2.toFixed(1)],
      ['Stack SO2 (mg/Nm3 @ 6% O2)', s.emissions.so2_mg_nm3_ref6o2.toFixed(1)],
      ['Stack Dust PM (mg/Nm3 @ 6% O2)', s.emissions.pm_mg_nm3_ref6o2.toFixed(2)],
      ['Biogenic CO2 (tonnes/day)', s.emissions.biogenic_co2_tonnes_day.toFixed(1)],
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `AUREOM_Biomass_Telemetry_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}
