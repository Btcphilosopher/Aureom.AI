/**
 * AUREOM.AI — BIOMASS.OS
 * Virtual Control Room & Supervisory Control (DCS / SCADA Mimic & PID Controllers)
 */

import { Component, inject, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PlantSimulatorService } from '../../core/simulation/plant-simulator.service';
import { OperatingMode, PIDController } from '../../core/models/plant.models';

@Component({
  selector: 'app-control-room',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full w-full flex flex-col bg-[#080d14] text-slate-100 overflow-y-auto p-6 space-y-6">
      <!-- Control Room Header: Operating Mode & Safety Interlock Banner -->
      <div class="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
        <div class="flex items-center gap-4">
          <div class="p-3 bg-sky-950/70 border border-sky-800/80 rounded-xl text-sky-400">
            <mat-icon class="text-2xl">tune</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-mono uppercase tracking-wider text-sky-400">Supervisory DCS</span>
              <span class="text-slate-500 font-mono">·</span>
              <span class="text-xs font-mono text-slate-400">Siemens / ABB Industrial Automation Mimic</span>
            </div>
            <h1 class="text-lg font-bold text-white tracking-tight">Virtual Control Room & Automation Loops</h1>
          </div>
        </div>

        <!-- Operating Mode State Selector -->
        <div class="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
          @for (mode of operatingModes; track mode.id) {
            <button
              (click)="setOperatingMode(mode.id)"
              class="px-3 py-1.5 text-xs font-medium rounded-lg transition-all whitespace-nowrap"
              [class.bg-sky-600]="simService.state().operatingMode === mode.id"
              [class.text-white]="simService.state().operatingMode === mode.id"
              [class.text-slate-400]="simService.state().operatingMode !== mode.id"
              [class.hover:text-slate-200]="simService.state().operatingMode !== mode.id"
            >
              {{ mode.label }}
            </button>
          }
        </div>

        <!-- Emergency Trip Action -->
        <button
          (click)="emergencyTrip()"
          class="flex items-center gap-2 px-4 py-2 bg-rose-950/80 border border-rose-800 text-rose-300 hover:bg-rose-900 rounded-xl font-bold text-xs uppercase tracking-wider transition-colors shadow-lg"
        >
          <mat-icon class="text-base">gpp_bad</mat-icon>
          Emergency Trip
        </button>
      </div>

      <!-- PID Controllers Grid (6 Key Control Loops) -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        <!-- Controller 1: Boiler Master -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-[10px] font-mono uppercase text-sky-400">PIC-101 · Loop #1</span>
              <h3 class="text-sm font-bold text-white">Boiler Header Pressure</h3>
            </div>
            <button
              (click)="toggleAuto('boilerMaster')"
              class="px-2 py-0.5 text-xs font-mono rounded"
              [class.bg-emerald-950]="simService.state().controllers.boilerMaster.autoMode"
              [class.text-emerald-400]="simService.state().controllers.boilerMaster.autoMode"
              [class.border]="true"
              [class.border-emerald-800]="simService.state().controllers.boilerMaster.autoMode"
              [class.bg-amber-950]="!simService.state().controllers.boilerMaster.autoMode"
              [class.text-amber-400]="!simService.state().controllers.boilerMaster.autoMode"
              [class.border-amber-800]="!simService.state().controllers.boilerMaster.autoMode"
            >
              {{ simService.state().controllers.boilerMaster.autoMode ? 'AUTO' : 'MANUAL' }}
            </button>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Process Variable</span>
              <p class="text-base font-bold text-white tabular-nums">
                {{ simService.state().boiler.drumPressureBar | number:'1.1-1' }} <span class="text-xs font-normal text-slate-400">bar</span>
              </p>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Setpoint (SP)</span>
              <p class="text-base font-bold text-sky-400 tabular-nums">
                {{ simService.state().controllers.boilerMaster.setpoint | number:'1.1-1' }} <span class="text-xs font-normal text-slate-400">bar</span>
              </p>
            </div>
          </div>

          <!-- Slider Setpoint -->
          <div class="space-y-1">
            <div class="flex justify-between text-xs text-slate-400">
              <span>Adjust Setpoint:</span>
              <span class="font-mono text-white">{{ simService.state().controllers.boilerMaster.setpoint }} bar</span>
            </div>
            <input
              type="range"
              min="40"
              max="80"
              step="0.5"
              [value]="simService.state().controllers.boilerMaster.setpoint"
              (input)="updatePressureSetpoint($event)"
              class="w-full h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
          </div>

          <div class="flex justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800">
            <span>Tuning: Kp: 1.8 · Ti: 45s</span>
            <span class="text-emerald-400">Out: {{ simService.state().fuelFeedRateKgS | number:'1.2-2' }} kg/s</span>
          </div>
        </div>

        <!-- Controller 2: Drum Water Level -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-[10px] font-mono uppercase text-sky-400">LIC-102 · Loop #2</span>
              <h3 class="text-sm font-bold text-white">Drum Water Level (3-Element)</h3>
            </div>
            <span class="px-2 py-0.5 text-xs font-mono rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              AUTO
            </span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Level PV</span>
              <p class="text-base font-bold text-emerald-400 tabular-nums">
                {{ simService.state().boiler.drumWaterLevelMm | number:'1.0-0' }} <span class="text-xs font-normal text-slate-400">mm</span>
              </p>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Level SP</span>
              <p class="text-base font-bold text-sky-400 tabular-nums">
                0 <span class="text-xs font-normal text-slate-400">mm</span>
              </p>
            </div>
          </div>

          <div class="space-y-1">
            <div class="flex justify-between text-xs text-slate-400">
              <span>Feedwater Valve Demand:</span>
              <span class="font-mono text-white">62.5%</span>
            </div>
            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div class="bg-sky-500 h-full rounded-full" style="width: 62.5%"></div>
            </div>
          </div>

          <div class="flex justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800">
            <span>Steam Flow / Feedwater Balanced</span>
            <span class="text-sky-400">P_fw: 77 bar</span>
          </div>
        </div>

        <!-- Controller 3: Steam Temp Attemperator -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-[10px] font-mono uppercase text-sky-400">TIC-103 · Loop #3</span>
              <h3 class="text-sm font-bold text-white">Superheater Attemperator Spray</h3>
            </div>
            <span class="px-2 py-0.5 text-xs font-mono rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              CASCADE
            </span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Steam Temp</span>
              <p class="text-base font-bold text-amber-400 tabular-nums">
                {{ simService.state().boiler.steamTemperatureC | number:'1.1-1' }} <span class="text-xs font-normal text-slate-400">°C</span>
              </p>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Target SP</span>
              <p class="text-base font-bold text-sky-400 tabular-nums">
                480.0 <span class="text-xs font-normal text-slate-400">°C</span>
              </p>
            </div>
          </div>

          <div class="space-y-1">
            <div class="flex justify-between text-xs text-slate-400">
              <span>Spray Water Flow:</span>
              <span class="font-mono text-white">1.8 t/h (14% CV)</span>
            </div>
            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div class="bg-cyan-500 h-full rounded-full" style="width: 28%"></div>
            </div>
          </div>

          <div class="flex justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800">
            <span>Thermal Shock Protection: Active</span>
            <span class="text-emerald-400">Within ±1.5°C</span>
          </div>
        </div>

        <!-- Controller 4: Air/Fuel Excess O2 -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-[10px] font-mono uppercase text-sky-400">AIC-104 · Loop #4</span>
              <h3 class="text-sm font-bold text-white">Combustion Excess O2 Trim</h3>
            </div>
            <span class="px-2 py-0.5 text-xs font-mono rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              AUTO
            </span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Flue Gas O2</span>
              <p class="text-base font-bold text-white tabular-nums">
                {{ simService.state().emissions.o2_dry_pct | number:'1.2-2' }} <span class="text-xs font-normal text-slate-400">% dry</span>
              </p>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Lambda λ</span>
              <p class="text-base font-bold text-sky-400 tabular-nums">
                {{ simService.state().excessAirRatio | number:'1.3-3' }}
              </p>
            </div>
          </div>

          <div class="space-y-1">
            <div class="flex justify-between text-xs text-slate-400">
              <span>Primary / Secondary Air Split:</span>
              <span class="font-mono text-white">65% / 35%</span>
            </div>
            <div class="flex gap-1 h-2 rounded-full overflow-hidden">
              <div class="bg-blue-500 h-full" style="width: 65%"></div>
              <div class="bg-sky-400 h-full" style="width: 35%"></div>
            </div>
          </div>

          <div class="flex justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800">
            <span>Air Ingress Monitor: Normal</span>
            <span class="text-emerald-400">CO < 50 mg/Nm3</span>
          </div>
        </div>

        <!-- Controller 5: Furnace Draft Pressure -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-[10px] font-mono uppercase text-sky-400">PIC-105 · Loop #5</span>
              <h3 class="text-sm font-bold text-white">Furnace Draft (ID Fan VFD)</h3>
            </div>
            <span class="px-2 py-0.5 text-xs font-mono rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              AUTO
            </span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Draft PV</span>
              <p class="text-base font-bold text-white tabular-nums">
                -52 <span class="text-xs font-normal text-slate-400">Pa</span>
              </p>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Draft SP</span>
              <p class="text-base font-bold text-sky-400 tabular-nums">
                -50 <span class="text-xs font-normal text-slate-400">Pa</span>
              </p>
            </div>
          </div>

          <div class="space-y-1">
            <div class="flex justify-between text-xs text-slate-400">
              <span>ID Fan Speed (VFD):</span>
              <span class="font-mono text-white">74.2% (1,113 RPM)</span>
            </div>
            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div class="bg-amber-500 h-full rounded-full" style="width: 74.2%"></div>
            </div>
          </div>

          <div class="flex justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800">
            <span>Draft Envelope: -30 to -80 Pa</span>
            <span class="text-emerald-400">Stable Negative</span>
          </div>
        </div>

        <!-- Controller 6: Turbine Governor -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div class="flex justify-between items-start">
            <div>
              <span class="text-[10px] font-mono uppercase text-sky-400">SIC-106 · Loop #6</span>
              <h3 class="text-sm font-bold text-white">Turbine Governor & Active Power</h3>
            </div>
            <span class="px-2 py-0.5 text-xs font-mono rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
              DROOP 4%
            </span>
          </div>

          <div class="grid grid-cols-2 gap-3 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Net Generation</span>
              <p class="text-base font-bold text-sky-400 tabular-nums">
                {{ simService.netElectricalMW() | number:'1.2-2' }} <span class="text-xs font-normal text-slate-400">MW</span>
              </p>
            </div>
            <div>
              <span class="text-slate-400 text-[10px] uppercase">Rotor Speed</span>
              <p class="text-base font-bold text-white tabular-nums">
                3,000 <span class="text-xs font-normal text-slate-400">RPM</span>
              </p>
            </div>
          </div>

          <div class="space-y-1">
            <div class="flex justify-between text-xs text-slate-400">
              <span>Governor Throttle Valve:</span>
              <span class="font-mono text-white">88.4% open</span>
            </div>
            <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div class="bg-emerald-500 h-full rounded-full" style="width: 88.4%"></div>
            </div>
          </div>

          <div class="flex justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800">
            <span>Grid Freq: 50.00 Hz</span>
            <span class="text-sky-400">cos φ 0.88</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ControlRoomComponent {
  public readonly simService = inject(PlantSimulatorService);

  public readonly operatingModes = [
    { id: 'start_up' as OperatingMode, label: 'Start-Up Sequence' },
    { id: 'normal_baseload' as OperatingMode, label: '100% Baseload' },
    { id: 'load_following' as OperatingMode, label: 'Load Following' },
    { id: 'reduced_load' as OperatingMode, label: 'Reduced Load (60%)' },
    { id: 'controlled_shutdown' as OperatingMode, label: 'Shutdown' },
  ];

  public setOperatingMode(mode: OperatingMode): void {
    this.simService.state.update((s) => ({ ...s, operatingMode: mode }));
  }

  public emergencyTrip(): void {
    this.simService.state.update((s) => ({
      ...s,
      operatingMode: 'tripped',
      fuelFeedRateKgS: 0,
      fuelThermalInputMW: 0,
      isRunning: false,
      alarms: [
        {
          id: 'trip_manual',
          code: 'TRIP-999',
          timestamp: s.simulationClockFormatted,
          subsystem: 'Control Room',
          message: 'EMERGENCY TRIP INITIATED BY OPERATOR — Fuel & Turbine Master Trip Valves Closed',
          severity: 'critical',
          acknowledged: false,
          value: 0,
          threshold: 0,
          unit: 'TRIP',
        },
      ],
    }));
  }

  public toggleAuto(loopKey: string): void {
    this.simService.state.update((s) => {
      const controllers = s.controllers as unknown as Record<string, PIDController>;
      const ctrl = controllers[loopKey];
      if (!ctrl) return s;
      return {
        ...s,
        controllers: {
          ...s.controllers,
          [loopKey]: { ...ctrl, autoMode: !ctrl.autoMode },
        },
      };
    });
  }

  public updatePressureSetpoint(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.simService.setBoilerPressureSetpoint(val);
  }
}
