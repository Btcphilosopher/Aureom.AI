import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// In-memory simulation state for API
const serverSimulation = {
  id: 'sim_default_20mw',
  status: 'running',
  ratedElectricalMW: 20.0,
  ratedThermalMW: 80.0,
  netPowerMW: 19.85,
  grossPowerMW: 22.05,
  fuelFeedTonnesHr: 26.8,
  steamFlowTonnesHr: 78.5,
  boilerEfficiencyPct: 86.4,
  netEfficiencyPct: 24.8,
  furnaceBedTempC: 915.0,
  drumPressureBar: 65.0,
  alarmsCount: 0,
};

app.get('/api/plants', (req, res) => {
  res.json({
    plants: [
      {
        id: 'plant_aureom_01',
        name: 'AUREOM Biomass Station #1',
        architecture: 'direct_combustion',
        capacityMW: 20.0,
        thermalMW: 80.0,
        boilerPressureBar: 65.0,
        mainSteamTempC: 480.0,
        fuel: 'Forestry Wood Chips',
        status: 'Operational Baseload',
      },
    ],
  });
});

app.get('/api/fuels', (req, res) => {
  res.json({
    fuels: [
      { id: 'wood_chips', name: 'Forestry Wood Chips', moisture: 35.0, lhv_ar: 10.8, cost_per_tonne: 75 },
      { id: 'wood_pellets', name: 'Premium Wood Pellets', moisture: 7.5, lhv_ar: 17.2, cost_per_tonne: 185 },
      { id: 'straw', name: 'Wheat Straw', moisture: 14.0, lhv_ar: 14.5, cost_per_tonne: 55 },
      { id: 'bagasse', name: 'Sugarcane Bagasse', moisture: 48.0, lhv_ar: 7.5, cost_per_tonne: 30 },
    ],
  });
});

app.get('/api/telemetry', (req, res) => {
  res.json({
    timestamp: new Date().toISOString(),
    telemetry: serverSimulation,
  });
});

app.get('/api/alarms', (req, res) => {
  res.json({ alarms: [] });
});

app.post('/api/simulations/run', (req, res) => {
  serverSimulation.status = 'running';
  res.json({ message: 'Simulation running', simulation: serverSimulation });
});

app.post('/api/simulations/pause', (req, res) => {
  serverSimulation.status = 'paused';
  res.json({ message: 'Simulation paused', simulation: serverSimulation });
});

app.post('/api/simulations/reset', (req, res) => {
  serverSimulation.netPowerMW = 19.85;
  serverSimulation.status = 'running';
  res.json({ message: 'Simulation reset', simulation: serverSimulation });
});

app.get('/api/reports', (req, res) => {
  res.json({
    stationReport: {
      generatedAt: new Date().toISOString(),
      plant: 'AUREOM.AI — BIOMASS.OS 20 MWe Baseload Station',
      annualGenerationMWh: 148920,
      annualFuelTonnes: 214445,
      capacityFactor: 0.85,
      netHeatRateKjPerKwh: 14516,
      ghgAvoidedTonnesYear: 88500,
      massBalanceResidualPct: 0.002,
      energyBalanceResidualPct: -0.005,
    },
  });
});


/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
