/**
 * Aureom TV OS - WebOS Main Controller
 */

import { SpatialNavigation } from './services/spatialNavigation.js';
import { WebOsBridge } from './services/webosBridge.js';
import { ApiClient } from './services/apiClient.js';
import { ContentItem } from './types/tv.js';

class AureomWebOsApp {
  private nav: SpatialNavigation;
  private bridge: WebOsBridge;
  private api: ApiClient;
  private currentTab: string = 'home';
  private catalogue: any = null;
  private isPlaying: boolean = false;

  constructor() {
    this.nav = new SpatialNavigation();
    this.bridge = new WebOsBridge();
    this.api = new ApiClient();
  }

  public async start() {
    this.initClock();
    this.initNavTabs();
    this.initPlayerControls();

    // Set Back button behavior
    this.nav.setOnBack(() => {
      if (this.isPlaying) {
        this.closePlayer();
      } else if (this.currentTab !== 'home') {
        this.switchTab('home');
      }
    });

    // Fetch catalogue and render home
    this.catalogue = await this.api.getCatalogue();
    this.renderHome();

    // Initial focus
    setTimeout(() => {
      this.nav.focusFirst();
    }, 150);
  }

  private initClock() {
    const updateTime = () => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const clockEl = document.getElementById('header-clock');
      if (clockEl) clockEl.textContent = timeStr;
    };
    updateTime();
    setInterval(updateTime, 30000);
  }

  private initNavTabs() {
    const tabs = document.querySelectorAll('.nav-tab-btn');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const target = tab.getAttribute('data-tab');
        if (target) this.switchTab(target);
      });
    });
  }

  private switchTab(tabName: string) {
    this.currentTab = tabName;
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
    });

    switch (tabName) {
      case 'home':
        this.renderHome();
        break;
      case 'livetv':
        this.renderLiveTv();
        break;
      case 'apps':
        this.renderApps();
        break;
      case 'settings':
        this.renderSettings();
        break;
    }

    setTimeout(() => {
      const container = document.getElementById('view-container');
      if (container) this.nav.focusFirst(container);
    }, 50);
  }

  private renderHome() {
    const container = document.getElementById('view-container');
    if (!container || !this.catalogue) return;

    const featured = this.catalogue.featured;

    container.innerHTML = `
      <div style="overflow-y: auto; height: 100%; padding-right: 12px;">
        <!-- Featured Hero -->
        <section class="hero-banner" style="background-image: url('${featured.backdropUrl}')">
          <div class="hero-overlay"></div>
          <div class="hero-content">
            <div class="hero-badges">
              <span class="badge badge-gold">4K ULTRA HD</span>
              <span class="badge">${featured.hdrFormat}</span>
              <span class="badge">${featured.audioFormat}</span>
              <span class="badge">${featured.rating}</span>
            </div>
            <h1 class="hero-title">${featured.title}</h1>
            <p class="hero-synopsis">${featured.synopsis}</p>
            <div class="hero-actions">
              <button id="hero-play-btn" class="tv-btn primary focusable" tabindex="0">▶ Play Feature</button>
              <button id="hero-trailer-btn" class="tv-btn focusable" tabindex="0">Watch Trailer</button>
              <button id="hero-info-btn" class="tv-btn focusable" tabindex="0">More Info</button>
            </div>
          </div>
        </section>

        <!-- Categories -->
        ${this.catalogue.categories.map((cat: any, catIdx: number) => `
          <section class="content-section">
            <h2 class="section-title">${cat.name}</h2>
            <div class="horizontal-shelf">
              ${cat.items.map((item: ContentItem, idx: number) => `
                <div class="shelf-card focusable" tabindex="0" data-item-id="${item.id}" data-cat-idx="${catIdx}" data-item-idx="${idx}">
                  <img src="${item.posterUrl || item.backdropUrl}" alt="${item.title}" />
                  <div class="card-meta">
                    <div class="card-title">${item.title}</div>
                    <div class="card-subtitle">${item.genre} • ${item.releaseYear}</div>
                  </div>
                </div>
              `).join('')}
            </div>
          </section>
        `).join('')}
      </div>
    `;

    // Attach click events
    document.getElementById('hero-play-btn')?.addEventListener('click', () => {
      this.playMedia(featured);
    });

    container.querySelectorAll('.shelf-card').forEach(card => {
      card.addEventListener('click', () => {
        const itemId = card.getAttribute('data-item-id');
        const allItems = this.catalogue.categories.flatMap((c: any) => c.items);
        const item = allItems.find((i: any) => i.id === itemId);
        if (item) this.playMedia(item);
      });
    });
  }

  private renderLiveTv() {
    const container = document.getElementById('view-container');
    if (!container) return;

    const channels = [
      { num: '01', name: 'Aureom News 24/7', now: 'Global Market Briefing', prog: 65, cat: 'News' },
      { num: '02', name: 'Ultra Cinema 4K', now: 'Interstellar Odyssey (HDR10+)', prog: 30, cat: 'Movies' },
      { num: '03', name: 'Apex Sports HD', now: 'Super GT Championship Round 4', prog: 80, cat: 'Sports' },
      { num: '04', name: 'Horizon Discovery', now: 'Secrets of the Hadal Zone', prog: 45, cat: 'Docs' }
    ];

    container.innerHTML = `
      <div style="padding: 10px;">
        <h2 class="section-title" style="margin-bottom: 24px;">Live Television & EPG Broadcast Grid</h2>
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px;">
          ${channels.map(ch => `
            <div class="tv-card focusable" tabindex="0" style="background: var(--bg-surface); padding: 24px; border-radius: 12px; border: 2px solid transparent;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                <div style="display: flex; align-items: center; gap: 14px;">
                  <span style="font-size: 28px; font-weight: 800; color: var(--accent-amber);">${ch.num}</span>
                  <span style="font-size: 20px; font-weight: 700;">${ch.name}</span>
                </div>
                <span class="badge badge-gold">LIVE</span>
              </div>
              <div style="font-size: 16px; color: var(--text-muted); margin-bottom: 12px;">Now Playing: <strong style="color: #FFF;">${ch.now}</strong></div>
              <div class="progress-bar-container" style="height: 6px; margin-bottom: 8px;">
                <div class="progress-fill" style="width: ${ch.prog}%;"></div>
              </div>
              <div style="font-size: 13px; color: var(--text-muted); display: flex; justify-content: space-between;">
                <span>EPG Synced</span>
                <span>${ch.cat}</span>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  private renderApps() {
    const container = document.getElementById('view-container');
    if (!container) return;

    const apps = [
      { name: 'YouTube TV', status: 'INSTALLED', icon: '▶' },
      { name: 'Netflix 4K', status: 'INSTALLED', icon: 'N' },
      { name: 'Prime Video', status: 'INSTALLED', icon: 'P' },
      { name: 'Disney+', status: 'AVAILABLE', icon: 'D' },
      { name: 'Apple TV', status: 'AVAILABLE', icon: 'A' },
      { name: 'HDMI 1 (eARC Soundbar)', status: 'EXTERNAL_DEVICE', icon: 'H1' },
      { name: 'HDMI 2 (PlayStation 5)', status: 'EXTERNAL_DEVICE', icon: 'H2' }
    ];

    container.innerHTML = `
      <div style="padding: 10px;">
        <h2 class="section-title">Application Registry & Connected HDMI Inputs</h2>
        <p style="color: var(--text-muted); margin-bottom: 24px;">Hardware connected inputs and verified native applications.</p>
        <div style="display: flex; flex-wrap: wrap; gap: 20px;">
          ${apps.map(app => `
            <div class="app-card focusable" tabindex="0">
              <div class="app-icon-circle">${app.icon}</div>
              <div class="app-title">${app.name}</div>
              <span class="app-status-tag">${app.status}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  private async renderSettings() {
    const container = document.getElementById('view-container');
    if (!container) return;

    const sysInfo = await this.bridge.getSystemInfo();
    const netInfo = await this.bridge.getNetworkStatus();

    container.innerHTML = `
      <div class="settings-grid">
        <aside class="settings-sidebar">
          <button class="settings-nav-btn focusable active" tabindex="0">Device & System</button>
          <button class="settings-nav-btn focusable" tabindex="0">Picture & Display</button>
          <button class="settings-nav-btn focusable" tabindex="0">Audio & Passthrough</button>
          <button class="settings-nav-btn focusable" tabindex="0">Network Diagnostics</button>
          <button class="settings-nav-btn focusable" tabindex="0">OEM Integration Matrix</button>
        </aside>

        <section class="settings-content-panel">
          <h2 style="font-size: 24px; font-weight: 700; margin-bottom: 20px;">Device & System Information</h2>
          <div class="setting-row">
            <div>
              <div class="setting-label">Hardware Model</div>
              <div class="setting-desc">${sysInfo.modelName}</div>
            </div>
            <span class="badge ${sysInfo.isRealDevice ? 'badge-gold' : ''}">${sysInfo.isRealDevice ? 'Verified Hardware' : 'Simulator Mode'}</span>
          </div>
          <div class="setting-row">
            <div>
              <div class="setting-label">Operating System Build</div>
              <div class="setting-desc">${sysInfo.sdkVersion} (${sysInfo.firmwareVersion})</div>
            </div>
            <span class="badge">Aureom TV 1.0</span>
          </div>
          <div class="setting-row">
            <div>
              <div class="setting-label">Panel Resolution</div>
              <div class="setting-desc">${sysInfo.screenResolution} @ 120Hz Native OLED</div>
            </div>
            <span class="badge badge-gold">4K HDR10+</span>
          </div>
          <div class="setting-row">
            <div>
              <div class="setting-label">Network Status</div>
              <div class="setting-desc">${netInfo.networkType.toUpperCase()} • IP: ${netInfo.ipAddress}</div>
            </div>
            <span class="badge">${netInfo.isConnected ? 'Connected' : 'Offline'}</span>
          </div>
          <div class="setting-row">
            <div>
              <div class="setting-label">Shared Backend Sync</div>
              <div class="setting-desc">http://localhost:8000/api/v1 (FastAPI Cluster)</div>
            </div>
            <span class="badge badge-gold">Online</span>
          </div>
        </section>
      </div>
    `;
  }

  private playMedia(item: ContentItem) {
    const modal = document.getElementById('player-modal');
    const video = document.getElementById('tv-video-element') as HTMLVideoElement;
    const title = document.getElementById('player-title');
    if (!modal || !video) return;

    this.isPlaying = true;
    modal.style.display = 'flex';
    if (title) title.textContent = item.title;

    video.src = item.streamUrl;
    video.play().catch(e => console.warn('Autoplay prevented or stream error', e));

    setTimeout(() => {
      const playBtn = document.getElementById('btn-play-pause');
      if (playBtn) this.nav.focus(playBtn);
    }, 100);
  }

  private closePlayer() {
    const modal = document.getElementById('player-modal');
    const video = document.getElementById('tv-video-element') as HTMLVideoElement;
    if (modal) modal.style.display = 'none';
    if (video) {
      video.pause();
      video.src = '';
    }
    this.isPlaying = false;
    this.renderHome();
  }

  private initPlayerControls() {
    const video = document.getElementById('tv-video-element') as HTMLVideoElement;
    const playPauseBtn = document.getElementById('btn-play-pause');
    const closeBtn = document.getElementById('btn-close-player');
    const progressBar = document.getElementById('player-progress-bar');
    const timeBadge = document.getElementById('player-time-badge');

    if (playPauseBtn && video) {
      playPauseBtn.addEventListener('click', () => {
        if (video.paused) {
          video.play();
          playPauseBtn.textContent = 'Pause';
        } else {
          video.pause();
          playPauseBtn.textContent = 'Play';
        }
      });
    }

    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.closePlayer());
    }

    if (video && progressBar) {
      video.addEventListener('timeupdate', () => {
        if (video.duration) {
          const pct = (video.currentTime / video.duration) * 100;
          progressBar.style.width = `${pct}%`;
          if (timeBadge) {
            const cur = Math.floor(video.currentTime);
            const dur = Math.floor(video.duration);
            timeBadge.textContent = `${Math.floor(cur/60)}:${(cur%60).toString().padStart(2, '0')} / ${Math.floor(dur/60)}:${(dur%60).toString().padStart(2, '0')}`;
          }
        }
      });
    }
  }
}

// Bootstrap
window.addEventListener('DOMContentLoaded', () => {
  const app = new AureomWebOsApp();
  app.start();
});
