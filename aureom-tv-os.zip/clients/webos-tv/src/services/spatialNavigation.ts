/**
 * TV Spatial Navigation Engine for LG webOS TV Remote & D-Pad Keyboards.
 */

export class SpatialNavigation {
  private currentFocusedElement: HTMLElement | null = null;
  private onBackCallback: (() => void) | null = null;
  private onSelectCallback: ((el: HTMLElement) => void) | null = null;

  constructor() {
    this.initKeyListeners();
  }

  public setOnBack(cb: () => void) {
    this.onBackCallback = cb;
  }

  public setOnSelect(cb: (el: HTMLElement) => void) {
    this.onSelectCallback = cb;
  }

  public focus(el: HTMLElement) {
    if (this.currentFocusedElement) {
      this.currentFocusedElement.classList.remove('focused');
      this.currentFocusedElement.blur();
    }
    this.currentFocusedElement = el;
    el.classList.add('focused');
    el.focus();
    el.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
  }

  public getFocused(): HTMLElement | null {
    return this.currentFocusedElement;
  }

  public focusFirst(container: HTMLElement = document.body) {
    const focusable = container.querySelector('.focusable') as HTMLElement;
    if (focusable) {
      this.focus(focusable);
    }
  }

  private initKeyListeners() {
    window.addEventListener('keydown', (e: KeyboardEvent) => {
      // webOS remote key codes & standard keyboard codes
      switch (e.keyCode) {
        case 37: // ArrowLeft
          e.preventDefault();
          this.navigate('left');
          break;
        case 38: // ArrowUp
          e.preventDefault();
          this.navigate('up');
          break;
        case 39: // ArrowRight
          e.preventDefault();
          this.navigate('right');
          break;
        case 40: // ArrowDown
          e.preventDefault();
          this.navigate('down');
          break;
        case 13: // Enter / OK
          e.preventDefault();
          if (this.currentFocusedElement) {
            this.currentFocusedElement.click();
            if (this.onSelectCallback) {
              this.onSelectCallback(this.currentFocusedElement);
            }
          }
          break;
        case 461: // webOS Back Button
        case 27:  // Esc
        case 8:   // Backspace
          e.preventDefault();
          if (this.onBackCallback) {
            this.onBackCallback();
          }
          break;
        case 415: // MediaPlay
        case 19:  // Pause
          // Handled by active media player
          break;
      }
    });
  }

  private navigate(direction: 'left' | 'right' | 'up' | 'down') {
    const all = Array.from(document.querySelectorAll('.focusable:not([disabled])')) as HTMLElement[];
    const visible = all.filter(el => {
      const rect = el.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && el.offsetParent !== null;
    });

    if (visible.length === 0) return;

    if (!this.currentFocusedElement || !visible.includes(this.currentFocusedElement)) {
      this.focus(visible[0]);
      return;
    }

    const currentRect = this.currentFocusedElement.getBoundingClientRect();
    const currentCenter = {
      x: currentRect.left + currentRect.width / 2,
      y: currentRect.top + currentRect.height / 2
    };

    let bestCandidate: HTMLElement | null = null;
    let minDistance = Infinity;

    for (const el of visible) {
      if (el === this.currentFocusedElement) continue;

      const rect = el.getBoundingClientRect();
      const center = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2
      };

      const dx = center.x - currentCenter.x;
      const dy = center.y - currentCenter.y;

      let isCandidate = false;
      if (direction === 'left' && dx < -10) isCandidate = true;
      if (direction === 'right' && dx > 10) isCandidate = true;
      if (direction === 'up' && dy < -10) isCandidate = true;
      if (direction === 'down' && dy > 10) isCandidate = true;

      if (isCandidate) {
        // Weighted distance emphasizing primary axis
        let distance = 0;
        if (direction === 'left' || direction === 'right') {
          distance = Math.abs(dx) + Math.abs(dy) * 2.5;
        } else {
          distance = Math.abs(dy) + Math.abs(dx) * 2.5;
        }

        if (distance < minDistance) {
          minDistance = distance;
          bestCandidate = el;
        }
      }
    }

    if (bestCandidate) {
      this.focus(bestCandidate);
    }
  }
}
