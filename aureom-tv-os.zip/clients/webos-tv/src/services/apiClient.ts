/**
 * Aureom TV OS - Shared Backend API Client for webOS
 */

import { ContentItem, OemConfig } from '../types/tv';

export class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string = 'http://localhost:8000/api/v1') {
    this.baseUrl = baseUrl;
  }

  public async getCatalogue(): Promise<{ featured: ContentItem; categories: { name: string; items: ContentItem[] }[] }> {
    try {
      const res = await fetch(`${this.baseUrl}/catalogue`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      return this.transformCatalogue(data);
    } catch (e) {
      console.warn('Backend unavailable, falling back to bundled offline catalogue', e);
      return this.getOfflineCatalogue();
    }
  }

  public async getOemConfig(deviceId: string): Promise<OemConfig> {
    try {
      const res = await fetch(`${this.baseUrl}/devices/${deviceId}/configuration`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      return {
        oemBrand: data.oem_brand,
        productFamily: data.product_family,
        accentColor: data.accent_color,
        featureFlags: {
          liveTvEnabled: data.feature_flags.live_tv_enabled,
          externalInputsEnabled: data.feature_flags.external_inputs_enabled,
          cloudSyncEnabled: data.feature_flags.cloud_sync_enabled,
          telemetryOptIn: data.feature_flags.telemetry_opt_in
        },
        supportedInputs: data.supported_inputs
      };
    } catch {
      return {
        oemBrand: 'Aureom',
        productFamily: 'Horizon OLED 4K Reference',
        accentColor: '#F59E0B',
        featureFlags: {
          liveTvEnabled: true,
          externalInputsEnabled: true,
          cloudSyncEnabled: false,
          telemetryOptIn: true
        },
        supportedInputs: ['HDMI 1 (eARC)', 'HDMI 2 (4K 120Hz)', 'Tuner / Antenna']
      };
    }
  }

  private transformCatalogue(data: any) {
    const mapItem = (item: any): ContentItem => ({
      id: item.id,
      title: item.title,
      tagline: item.tagline,
      synopsis: item.synopsis,
      backdropUrl: item.backdrop_url,
      posterUrl: item.poster_url,
      durationMinutes: item.duration_minutes,
      releaseYear: item.release_year,
      rating: item.rating,
      genre: item.genre,
      is4K: item.is_4k,
      hdrFormat: item.hdr_format,
      audioFormat: item.audio_format,
      streamUrl: item.stream_url,
      category: item.category
    });

    return {
      featured: mapItem(data.featured),
      categories: data.categories.map((c: any) => ({
        name: c.name,
        items: c.items.map(mapItem)
      }))
    };
  }

  private getOfflineCatalogue() {
    const featured: ContentItem = {
      id: 'aureom-ft-01',
      title: 'Chronicles of Orion',
      tagline: 'Beyond the frontier of known space',
      synopsis: 'An interstellar expedition discovers an ancient broadcast relay transmitting signals from a human colony founded three thousand years in the future.',
      backdropUrl: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=1920&q=80',
      posterUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&q=80',
      durationMinutes: 148,
      releaseYear: 2026,
      rating: 'TV-MA',
      genre: 'Sci-Fi Epic',
      is4K: true,
      hdrFormat: 'Dolby Vision',
      audioFormat: 'Dolby Atmos 7.1',
      streamUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      category: 'Featured'
    };

    const items: ContentItem[] = [
      featured,
      {
        id: 'aureom-ct-02',
        title: 'Apex Velocity',
        tagline: 'The engineering limits of speed',
        synopsis: 'Inside the elite prototype racing garages where next-generation aerodynamicists test hypercars on night circuits.',
        backdropUrl: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=1920&q=80',
        posterUrl: 'https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?w=600&q=80',
        durationMinutes: 112,
        releaseYear: 2025,
        rating: 'PG-13',
        genre: 'Motorsport Documentary',
        is4K: true,
        hdrFormat: 'HDR10+',
        audioFormat: 'Dolby Atmos',
        streamUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
        category: '4K HDR Cinema'
      },
      {
        id: 'aureom-ct-03',
        title: 'Echoes of Kyoto',
        tagline: 'Tradition in the shadow of neon',
        synopsis: 'A meditative journey through historical tea gardens, hidden craftsmen studios, and the architectural symmetry of Kansai.',
        backdropUrl: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1920&q=80',
        posterUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=600&q=80',
        durationMinutes: 94,
        releaseYear: 2026,
        rating: 'G',
        genre: 'Culture & Heritage',
        is4K: true,
        hdrFormat: 'Dolby Vision',
        audioFormat: 'PCM 5.1',
        streamUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        category: 'Documentaries'
      }
    ];

    return {
      featured,
      categories: [
        { name: 'Featured & Trending', items },
        { name: '4K HDR Cinema', items: [items[1]] },
        { name: 'Documentaries', items: [items[2]] }
      ]
    };
  }
}
