/**
 * LG webOS TV Luna Bus Service Bridge.
 * Accesses documented webOS APIs with transparent simulation fallback for developer environments.
 */

declare const webOS: any;

export interface WebOsSystemInfo {
  modelName: string;
  firmwareVersion: string;
  sdkVersion: string;
  screenResolution: string;
  isRealDevice: boolean;
}

export interface WebOsNetworkStatus {
  isConnected: boolean;
  networkType: 'wired' | 'wifi' | 'none';
  ipAddress: string;
  isRealDevice: boolean;
}

export class WebOsBridge {
  private hasNativeWebOS: boolean;

  constructor() {
    this.hasNativeWebOS = typeof webOS !== 'undefined' && typeof webOS.service !== 'undefined';
  }

  public isRunningOnRealWebOS(): boolean {
    return this.hasNativeWebOS;
  }

  public async getSystemInfo(): Promise<WebOsSystemInfo> {
    if (!this.hasNativeWebOS) {
      return {
        modelName: 'Aureom TV Simulator (webOS Target)',
        firmwareVersion: '05.20.10',
        sdkVersion: 'webOS TV 24 (v9.0.0)',
        screenResolution: `${window.innerWidth}x${window.innerHeight}`,
        isRealDevice: false
      };
    }

    return new Promise((resolve) => {
      try {
        webOS.service.request('luna://com.webos.service.tv.systemproperty', {
          method: 'getSystemInfo',
          parameters: { keys: ['modelName', 'firmwareVersion', 'sdkVersion', 'resolution'] },
          onSuccess: (res: any) => {
            resolve({
              modelName: res.modelName || 'LG Smart TV',
              firmwareVersion: res.firmwareVersion || '04.40.10',
              sdkVersion: res.sdkVersion || 'webOS TV',
              screenResolution: res.resolution || '1920x1080',
              isRealDevice: true
            });
          },
          onFailure: () => {
            resolve({
              modelName: 'LG Smart TV (Restricted Mode)',
              firmwareVersion: '04.00.00',
              sdkVersion: 'webOS TV',
              screenResolution: '1920x1080',
              isRealDevice: true
            });
          }
        });
      } catch {
        resolve({
          modelName: 'LG Smart TV (Fallback)',
          firmwareVersion: '04.00.00',
          sdkVersion: 'webOS TV',
          screenResolution: '1920x1080',
          isRealDevice: true
        });
      }
    });
  }

  public async getNetworkStatus(): Promise<WebOsNetworkStatus> {
    if (!this.hasNativeWebOS) {
      return {
        isConnected: navigator.onLine,
        networkType: 'wifi',
        ipAddress: '192.168.1.150',
        isRealDevice: false
      };
    }

    return new Promise((resolve) => {
      try {
        webOS.service.request('luna://com.webos.service.connectionmanager', {
          method: 'getStatus',
          parameters: {},
          onSuccess: (res: any) => {
            const isWired = res.wired && res.wired.state === 'connected';
            const isWifi = res.wifi && res.wifi.state === 'connected';
            resolve({
              isConnected: isWired || isWifi,
              networkType: isWired ? 'wired' : (isWifi ? 'wifi' : 'none'),
              ipAddress: (res.wifi && res.wifi.ipAddress) || (res.wired && res.wired.ipAddress) || '192.168.1.100',
              isRealDevice: true
            });
          },
          onFailure: () => {
            resolve({
              isConnected: navigator.onLine,
              networkType: 'wifi',
              ipAddress: '127.0.0.1',
              isRealDevice: true
            });
          }
        });
      } catch {
        resolve({
          isConnected: true,
          networkType: 'wifi',
          ipAddress: '192.168.1.100',
          isRealDevice: false
        });
      }
    });
  }

  public launchApp(appId: string): Promise<boolean> {
    if (!this.hasNativeWebOS) {
      console.log(`[Simulator] App launch requested for: ${appId}`);
      alert(`[Simulator] Launching external application: ${appId}`);
      return Promise.resolve(true);
    }

    return new Promise((resolve) => {
      webOS.service.request('luna://com.webos.applicationManager', {
        method: 'launch',
        parameters: { id: appId },
        onSuccess: () => resolve(true),
        onFailure: (err: any) => {
          console.error('Failed to launch webOS app:', err);
          resolve(false);
        }
      });
    });
  }
}
