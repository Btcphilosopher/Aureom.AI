/**
 * Aureom TV OS - Shared Domain and Contract Types for webOS
 */

export interface ContentItem {
  id: string;
  title: string;
  tagline?: string;
  synopsis?: string;
  backdropUrl?: string;
  posterUrl?: string;
  durationMinutes: number;
  releaseYear: number;
  rating: string;
  genre: string;
  is4K: boolean;
  hdrFormat: string;
  audioFormat: string;
  streamUrl: string;
  category: string;
}

export type AppInstallStatus = 
  | 'INSTALLED' 
  | 'AVAILABLE' 
  | 'SUBSCRIPTION_REQUIRED' 
  | 'UNSUPPORTED' 
  | 'EXTERNAL_DEVICE';

export interface TVAppItem {
  id: string;
  name: string;
  status: AppInstallStatus;
  iconUrl: string;
  appId?: string;
  inputPort?: string;
  badge?: string;
}

export interface LiveChannel {
  channelNumber: string;
  name: string;
  logoUrl?: string;
  currentProgram: string;
  programProgressPercent: number;
  streamUrl: string;
}

export interface OemConfig {
  oemBrand: string;
  productFamily: string;
  accentColor: string;
  featureFlags: {
    liveTvEnabled: boolean;
    externalInputsEnabled: boolean;
    cloudSyncEnabled: boolean;
    telemetryOptIn: boolean;
  };
  supportedInputs: string[];
}

export interface PlaybackState {
  isPlaying: boolean;
  currentTimeMs: number;
  durationMs: number;
  isBuffering: boolean;
  activeAudioTrack: string;
  activeSubtitleTrack: string;
  volume: number;
}
