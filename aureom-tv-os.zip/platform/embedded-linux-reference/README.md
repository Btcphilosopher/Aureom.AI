# Aureom TV OS - Custom Embedded Linux Reference Architecture

## 1. System Stack
For standalone television chipsets (e.g. MediaTek Pentonic, Realtek RTD, Amlogic T962X) without Android or webOS:

- **Kernel**: Linux 6.6 LTS with DRM/KMS, V4L2 DVB, ALSA, CEC drivers.
- **Init & Service Manager**: systemd 255.
- **Display Compositor**: Weston 13 Wayland Compositor running fullscreen kiosk mode on `/dev/dri/card0`.
- **Application Runtime**: WPE WebKit 2.42+ with hardware WebGL and EGL acceleration, or native Flutter/Qt TV engine.
- **Media Pipeline**: GStreamer 1.24 with hardware decoders (`v4l2slmp2dec`, `v4l2h264dec`, `v4l2h265dec`, `v4l2av1dec`).
- **Update System**: RAUC (Robust Auto-Update Controller) managing A/B bootable rootfs partitions with dm-verity and hardware rollback protection.

## 2. Service Orchestration
The television boots directly into `aureom-compositor.service` followed by `aureom-runtime.service`.
