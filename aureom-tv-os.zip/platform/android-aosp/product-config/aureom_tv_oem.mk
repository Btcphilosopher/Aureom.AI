# Aureom TV OS OEM Product Configuration
PRODUCT_NAME := aureom_tv_oem
PRODUCT_DEVICE := aureom_soc_reference
PRODUCT_BRAND := Aureom
PRODUCT_MODEL := Aureom Horizon OLED 4K

# Leanback & TV Feature Inclusions
PRODUCT_COPY_FILES += \
    frameworks/native/data/etc/android.software.leanback.xml:system/etc/permissions/android.software.leanback.xml \
    frameworks/native/data/etc/android.hardware.hdmi.cec.xml:system/etc/permissions/android.hardware.hdmi.cec.xml \
    frameworks/native/data/etc/android.hardware.tv.tuner.xml:system/etc/permissions/android.hardware.tv.tuner.xml

# System packages
PRODUCT_PACKAGES += \
    AureomTvHomeLauncher \
    AureomPlatformService \
    LiveTvTunerService \
    privapp-permissions-aureom.xml

# Default System Properties
PRODUCT_PROPERTY_OVERRIDES += \
    ro.oem.brand=Aureom \
    ro.oem.model=Horizon_OLED_4K \
    ro.sf.lcd_density=320 \
    persist.sys.display.memc=true \
    ro.audio.passthrough.supported=true
