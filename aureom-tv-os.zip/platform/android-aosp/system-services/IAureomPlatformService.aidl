// IAureomPlatformService.aidl
package com.aureom.tv.platform;

/**
 * Privileged OEM Platform Interface for Aureom TV OS (AOSP).
 * Provides hardware control for display modes, audio routing, and tuner.
 */
interface IAureomPlatformService {
    /**
     * Switch physical HDMI input port via HDMI-CEC HAL.
     */
    boolean selectHdmiInput(int portId);

    /**
     * Set panel picture profile (Standard, Cinema, Game, Vivid, Calibrated).
     */
    void setPictureMode(int pictureMode);

    /**
     * Configure motion estimation / motion compensation (MEMC) level (0 = Off, 1 = Low, 2 = Medium, 3 = High).
     */
    void setMemcLevel(int level);

    /**
     * Switch audio output routing (Internal Speakers, eARC Passthrough, Optical SPDIF).
     */
    void setAudioOutputMode(int outputMode);

    /**
     * Query hardware panel temperature and thermal throttle status.
     */
    int getPanelTemperatureCelsius();

    /**
     * Trigger dual-bank A/B system partition update verification and reboot.
     */
    boolean applySystemUpdate(String otaPayloadPath, String payloadSignature);
}
