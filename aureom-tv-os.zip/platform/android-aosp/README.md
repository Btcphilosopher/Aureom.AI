# Aureom TV OS - Android AOSP Platform Integration Architecture

## 1. System Overview
The Aureom TV OS AOSP track provides genuine Android Open Source Project (Android 14/15 TV) OEM platform components. It distinguishes between:

1. **Standard Client Application (`com.aistudio.aureomtv.oem`)**:
   Runs as a user application in standard runtime sandbox without privileged OS access.
2. **Aureom Platform System Service (`com.aureom.tv.platform`)**:
   Runs inside `system_server` or as a persistent privileged process (`system/priv-app`), exposing `IAureomPlatformService` via Android Binder.
3. **Hardware Abstraction Layer (HAL)**:
   Integrates directly with SoC vendor BSPs for HDMI-CEC, TV Input Framework (TIF / Tuner HAL 2.0), Audio HAL (eARC passthrough), and Display Mode HAL (MEMC / refresh rate switching).

---

## 2. Directory Structure
```text
platform/android-aosp/
├── product-config/
│   └── aureom_tv_oem.mk        # AOSP product makefile and packages
├── system-services/
│   ├── IAureomPlatformService.aidl   # Binder IPC definition
│   └── AureomPlatformManagerService.java # OEM Platform Manager
├── security-policy/
│   ├── permissions/
│   │   └── privapp-permissions-aureom.xml # Privileged permission whitelist
│   └── sepolicy/
│       └── aureom_tv.te       # SELinux domain & policy
└── device-integration/
    └── hdmi_cec_hal.md        # HDMI-CEC HAL & Tuner integration notes
```

---

## 3. Privileged Boundaries & Permissions
Under Android TV security architecture, ordinary applications cannot modify HDMI port routing, alter display panel LUTs, reboot into recovery, or perform silent OTA updates.

The `privapp-permissions-aureom.xml` grants these system capabilities strictly to the OEM platform package:
- `android.permission.HDMI_CEC`
- `android.permission.MODIFY_PARENTAL_CONTROLS`
- `android.permission.REBOOT`
- `android.permission.RECOVERY`
- `android.permission.SET_TIME_ZONE`
- `android.permission.ACCESS_SURFACE_FLINGER`
- `android.permission.TUNER_RESOURCE_ACCESS`
