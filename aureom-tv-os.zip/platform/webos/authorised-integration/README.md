# Aureom TV OS - Authorised webOS OEM Integration

## 1. Scope & Privileges
On commercial LG webOS hardware (such as LG Commercial Displays, Hospitality TVs running Pro:Centric, or authorized OEM partners):

- Standard 3rd-party webOS applications run in a sandboxed WebKit/Chromium container.
- Privileged Luna services (e.g. `luna://com.webos.service.tv.broadcast`, direct CEC, panel picture controls) require OEM cryptographic signatures, Pro:Centric authorization tokens, or partner developer credentials.

## 2. Luna Service Registration
The service descriptor file registered at `/var/luna/services/` defines the authorized role:

```json
{
  "name": "com.aureom.tv.service",
  "executable": "/usr/palm/services/com.aureom.tv.service/run.sh",
  "description": "Aureom OEM Platform Service for webOS TV",
  "permissions": [
    {"service": "com.webos.service.tv.broadcast", "inbound": ["*"], "outbound": ["*"]},
    {"service": "com.webos.service.tv.systemproperty", "inbound": ["*"], "outbound": ["*"]}
  ]
}
```

The TV client communicates with this service via `webOS.service.request('luna://com.aureom.tv.service/...')`.
