# Aureom TV OS - Security Architecture & Threat Model

## 1. Threat Scenarios & Mitigations

### Threat 1: Malicious Firmware Execution (OTA Spoofing)
- **Risk**: An attacker on the local network or DNS interceptor returns an altered firmware binary URL.
- **Mitigation**: Update metadata requires cryptographic RSA-SHA256 signatures validated against an OEM public key pre-baked into the bootloader/system image. Unsigned payloads are discarded. On AOSP/Linux, dm-verity and secure boot prevent booting altered partitions.

### Threat 2: Device Impersonation
- **Risk**: A rogue client registers with cloned device IDs to harvest configuration or flood telemetry.
- **Mitigation**: Initial device registration issues an ephemeral HMAC device token with 30-day rotation. Hardware serial numbers alone are never used as auth credentials.

### Threat 3: Telemetry & User Privacy Leakage
- **Risk**: Unauthorized telemetry captures private viewing logs.
- **Mitigation**: Telemetry is strictly opt-in, pseudonymous, and redacted of personally identifiable content. All client communications use TLS 1.3.

### Threat 4: Sandbox Escape on Smart TVs
- **Risk**: Web app exploits browser vulnerabilities to hijack the television.
- **Mitigation**: WebOS sandboxes apps inside restricted containers. Privileged Luna services enforce outbound access-control lists.
