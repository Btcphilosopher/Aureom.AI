# Aureom TV OS - System Architecture

## 1. Architectural Philosophy
Aureom TV OS is an OEM-grade television software ecosystem structured into four distinct, loosely coupled deliverables:

1. **Native Android TV Client**: Built with Kotlin, Jetpack Compose for TV, Room, and Media3/ExoPlayer. Runs on Android TV 11+ and AOSP 14/15 TV.
2. **Native LG webOS TV Client**: Built with TypeScript, HTML5, CSS, and webOS Luna Bus service bridges. Runs on webOS TV 6.0 through webOS 24.
3. **Shared Backend Services**: High-performance Python 3.12+ FastAPI platform managing device registries, dynamic configuration, catalogue, sessions, telemetry, and updates.
4. **OEM Operating System Integration Track**: AOSP system service specs, webOS authorized integration guides, and custom embedded Linux reference BSP.

```
       +-----------------------+-----------------------+
       |   Android TV Client   |   LG webOS TV Client  |
       |  (Kotlin / Media3)    | (TypeScript / HTML5)  |
       +-----------------------+-----------------------+
                   |                       |
                   +-----------+-----------+
                               | REST / v1
                               v
               +-------------------------------+
               |    Aureom Shared Backend      |
               | (FastAPI / PostgreSQL / Redis)|
               +-------------------------------+
                               |
            +------------------+------------------+
            v                                     v
+-----------------------+             +-----------------------+
|  AOSP Privileged HAL  |             | Embedded Linux BSP    |
| (HDMI-CEC / TIF / SE) |             | (Weston / RAUC A/B)   |
+-----------------------+             +-----------------------+
```

## 2. Remote-First 10-Foot Design Principles
- **Restrained Cinematic Visuals**: Deep graphite (`#0D0F14`), warm white typography, and amber/gold accents (`#F59E0B`).
- **Predictable Spatial Navigation**: Directional D-pad navigation with explicit focus rings, scale animation (1.05x), and zero touch-dependent affordances.
- **TV Safe Margins**: Strictly obeys title-safe and action-safe overscan margins (5% screen border).
- **Graceful Fallbacks**: Fully operational in offline mode with cached Room / local storage metadata.
