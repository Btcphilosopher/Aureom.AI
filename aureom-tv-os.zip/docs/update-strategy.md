# Aureom TV OS - Update & Rollback Strategy

## 1. Multi-Tier Update Hierarchy
Aureom TV OS decouples updates into three separate channels:

1. **Dynamic Configuration Updates (Hot)**:
   - Delivered via `/api/v1/devices/{id}/configuration`
   - Zero-downtime, alters UI layouts, branding, active content providers, and feature flags without APK/applet restarts.
   - Immediate rollback capability via admin API.

2. **Application Layer Updates**:
   - Android TV APK / WebOS IPK package updates.
   - Verified via manifest signatures and package managers.

3. **System & Firmware Updates (Cold / A/B)**:
   - Full OS image updates using dual-bank (Slot A / Slot B) architecture.
   - The inactive slot is flashed in the background while user watches media.
   - Post-reboot health check: if boot fails or kernel panics within 120 seconds, bootloader automatically reverts to the previous slot.

## 2. Hardware Qualification Matrix
Qualification tests verify:
- Maximum cold boot to home screen under 4.5 seconds.
- 60fps / 120fps UI render stability with zero frame drops during carousel scrolling.
- 4K 60fps AV1/HEVC hardware decoding with < 1% CPU utilization.
- D-pad repeat latency under 80ms.
- Memory consumption capped under 180MB for the launcher application.
