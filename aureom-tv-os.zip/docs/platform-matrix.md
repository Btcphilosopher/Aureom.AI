# Aureom TV OS - Platform Capability Matrix

| Feature Domain | Android TV (User App) | Android AOSP (OEM Mode) | LG webOS (User App) | LG webOS (OEM / Pro:Centric) | Custom Embedded Linux |
|---|---|---|---|---|---|
| **Home Launcher UI** | Compose for TV | System Default Home (`HOME` intent) | Sandboxed Web App | System Tile Launcher | Weston Fullscreen Kiosk |
| **Media Engine** | Media3 / ExoPlayer | Media3 + Codec2 Vendor HAL | HTML5 Video / MSE | webOS Media Pipeline | GStreamer 1.24 V4L2 |
| **Video Codecs** | H.264, HEVC, VP9, AV1 | H.264, HEVC, VP9, AV1 | H.264, HEVC, VP9 | H.264, HEVC, VP9, AV1 | HW Accel per SoC BSP |
| **Audio Passthrough**| AudioTrack Standard | eARC / Dolby Atmos Passthrough | Web Audio / Passthrough | Luna direct sound service | ALSA / PipeWire direct |
| **HDMI-CEC Control** | Read-only / MediaSession | Full CEC Port Switching | Unsupported | Pro:Centric CEC API | Linux `/dev/cec0` driver |
| **Tuner / Live Broadcast** | Simulated EPG / TIF preview | Real Tuner HAL 2.0 / DVB | Simulated EPG | Luna `tv.broadcast` tuner | Linux DVB API (`/dev/dvb`) |
| **Display Modes & MEMC** | Simulated Setting | SurfaceFlinger Mode Switch | Unsupported | Luna Picture Profile API | DRM/KMS Modesetting |
| **Firmware Updates** | Play Store / In-App | Recovery / `update_engine` A/B | LG Content Store | Signed Pro:Centric Package | RAUC Dual-Bank A/B OTA |
| **Remote Control** | D-Pad Android Keycodes | Keycodes + Custom OEM Hotkeys | D-Pad + Magic Remote Cursor | Keycodes + Pro:Centric IR | Linux `evdev` driver |
