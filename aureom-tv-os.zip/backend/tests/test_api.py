"""Test suite for Aureom TV OS Backend API."""
import pytest
from fastapi.testclient import TestClient
from aureom_tv.main import app

client = TestClient(app)

def test_health():
    res = client.get("/api/v1/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "healthy"
    assert data["version"] == "1.0.0"

def test_capabilities_matrix():
    res = client.get("/api/v1/capabilities")
    assert res.status_code == 200
    data = res.json()
    assert "android_tv" in data
    assert "webos_tv" in data
    assert "custom_linux" in data

def test_device_registration_and_config():
    payload = {
        "device_id": "test-tv-device-001",
        "platform_family": "android-tv",
        "platform_version": "14.0",
        "model": "Aureom Reference 55 OLED",
        "screen_resolution": "3840x2160",
        "hdr_capabilities": ["HDR10", "DolbyVision"],
        "audio_capabilities": ["DolbyAtmos"],
        "update_channel": "stable",
        "region": "US"
    }
    reg_res = client.post("/api/v1/devices/register", json=payload)
    assert reg_res.status_code == 200
    reg_data = reg_res.json()
    assert "device_token" in reg_data
    assert reg_data["assigned_configuration_id"] == "cfg-v1"
    
    # Check device configuration
    cfg_res = client.get("/api/v1/devices/test-tv-device-001/configuration")
    assert cfg_res.status_code == 200
    cfg_data = cfg_res.json()
    assert cfg_data["oem_brand"] == "Aureom"
    assert cfg_data["feature_flags"]["live_tv_enabled"] is True

def test_catalogue_and_detail():
    cat_res = client.get("/api/v1/catalogue")
    assert cat_res.status_code == 200
    cat_data = cat_res.json()
    assert "featured" in cat_data
    assert len(cat_data["categories"]) > 0
    
    item_id = cat_data["featured"]["id"]
    detail_res = client.get(f"/api/v1/catalogue/{item_id}")
    assert detail_res.status_code == 200
    assert detail_res.json()["title"] == cat_data["featured"]["title"]

def test_search():
    search_res = client.get("/api/v1/search?q=Kyoto")
    assert search_res.status_code == 200
    data = search_res.json()
    assert data["total_results"] >= 1
    assert "Kyoto" in data["results"][0]["title"]

def test_updates_metadata():
    update_res = client.get("/api/v1/updates/metadata?platform=android-tv&current_version=1.4.0")
    assert update_res.status_code == 200
    data = update_res.json()
    assert data["update_available"] is True
    assert "signature" in data
    assert "sha256_hash" in data
