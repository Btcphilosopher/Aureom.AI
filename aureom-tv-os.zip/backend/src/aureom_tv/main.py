"""Aureom TV OS - Main Application Entrypoint."""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .api.v1.router import api_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize registries, warm up cache
    print("Aureom TV OS Shared Backend starting up...")
    yield
    # Shutdown
    print("Aureom TV OS Shared Backend shutting down...")

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Enterprise OEM Television Platform Backend serving WebOS, Android TV, and Embedded Linux clients.",
    openapi_url="/api/v1/openapi.json",
    docs_url="/api/v1/docs",
    redoc_url="/api/v1/redoc",
    lifespan=lifespan
)

# CORS Middleware for WebOS TV and TV Simulators
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix=settings.API_V1_PREFIX)

@app.get("/")
async def root():
    return {
        "platform": "Aureom TV OS Enterprise Backend",
        "version": settings.VERSION,
        "docs": "/api/v1/docs",
        "health": "/api/v1/health"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("aureom_tv.main:app", host="0.0.0.0", port=8000, reload=True)
