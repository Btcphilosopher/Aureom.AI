"""Pydantic V2 schemas for Aureom TV OS Backend."""
import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class DeviceRegistrationRequest(BaseModel):
    device_id: str
    platform_family: str = Field(..., pattern="^(android-tv|webos-tv|custom-linux)$")
    platform_version: str
    model: str
    screen_resolution: str = "3840x2160"
    hdr_capabilities: List[str] = ["HDR10", "DolbyVision"]
    audio_capabilities: List[str] = ["DolbyAtmos", "Stereo"]
    update_channel: str = "stable"
    region: str = "GLOBAL"

class DeviceRegistrationResponse(BaseModel):
    device_token: str
    token_expiry: datetime.datetime
    registered_at: datetime.datetime
    assigned_configuration_id: str

class HeartbeatRequest(BaseModel):
    memory_usage_mb: Optional[float] = None
    storage_free_mb: Optional[float] = None
    uptime_seconds: Optional[int] = None
    active_profile_id: Optional[str] = None

class OemConfigurationResponse(BaseModel):
    config_id: str
    version: str
    oem_brand: str
    product_family: str
    accent_color: str
    feature_flags: Dict[str, bool]
    supported_inputs: List[str]

class ContentItemSchema(BaseModel):
    id: str
    title: str
    tagline: Optional[str] = None
    synopsis: Optional[str] = None
    backdrop_url: Optional[str] = None
    poster_url: Optional[str] = None
    duration_minutes: int
    release_year: int
    rating: str
    genre: str
    is_4k: bool = True
    hdr_format: str = "Dolby Vision"
    audio_format: str = "Dolby Atmos 5.1"
    stream_url: str
    category: str = "Featured"

class CategoryGroup(BaseModel):
    name: str
    items: List[ContentItemSchema]

class CatalogueResponse(BaseModel):
    featured: ContentItemSchema
    categories: List[CategoryGroup]

class SearchResponse(BaseModel):
    query: str
    total_results: int
    results: List[ContentItemSchema]

class ProfileSchema(BaseModel):
    id: str
    name: str
    avatar_color: str
    is_kid: bool
    preferred_audio: str
    subtitles_enabled: bool

class PlaybackSessionRequest(BaseModel):
    content_id: str
    device_id: str
    preferred_codec: Optional[str] = None
    max_resolution: Optional[str] = "3840x2160"

class PlaybackSessionResponse(BaseModel):
    session_id: str
    stream_url: str
    drm_scheme: str = "none"
    license_server_url: Optional[str] = None
    audio_tracks: List[str] = ["en (Dolby Atmos)", "es (Dolby Digital)", "fr (Stereo)"]
    subtitle_tracks: List[str] = ["en (English)", "es (Spanish)", "fr (French)"]
    resume_position_ms: int = 0

class UpdateMetadataResponse(BaseModel):
    update_available: bool
    version: str
    type: str # application, configuration, firmware_ab
    payload_url: str
    sha256_hash: str
    signature: str
    release_notes: str
    critical_security_patch: bool

class TelemetryEvent(BaseModel):
    event_type: str
    timestamp: datetime.datetime = Field(default_factory=datetime.datetime.utcnow)
    payload: Dict[str, Any]

class TelemetrySubmissionRequest(BaseModel):
    device_id: str
    events: List[TelemetryEvent]
