"""Aureom TV OS Shared Backend Platform."""
__version__ = "1.0.0"
