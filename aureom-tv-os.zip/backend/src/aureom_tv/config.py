"""Aureom TV Configuration and Environment Settings."""
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    PROJECT_NAME: str = "Aureom TV OS Backend"
    VERSION: str = "1.0.0"
    API_V1_PREFIX: str = "/api/v1"
    
    # Database
    DATABASE_URL: str = "sqlite+aiosqlite:///./aureom_tv.db"
    
    # Security
    SECRET_KEY: str = "aureom-tv-enterprise-secret-key-production-rotatable"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days for TV sessions
    
    # CORS
    CORS_ORIGINS: List[str] = ["*"]
    
    # OEM Defaults
    DEFAULT_OEM_BRAND: str = "Aureom"
    DEFAULT_PRODUCT_FAMILY: str = "Horizon OLED 4K"
    DEFAULT_ACCENT_COLOR: str = "#F59E0B"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
