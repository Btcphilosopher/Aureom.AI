"""SQLAlchemy models for Aureom TV OS."""
import datetime
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, JSON, Text, ForeignKey
from sqlalchemy.orm import relationship
from ..database import Base

class Device(Base):
    __tablename__ = "devices"
    
    device_id = Column(String(128), primary_key=True, index=True)
    platform_family = Column(String(32), nullable=False) # android-tv, webos-tv, custom-linux
    platform_version = Column(String(64), nullable=False)
    model = Column(String(64), nullable=False)
    screen_resolution = Column(String(32), default="3840x2160")
    hdr_capabilities = Column(JSON, default=list)
    audio_capabilities = Column(JSON, default=list)
    update_channel = Column(String(32), default="stable")
    region = Column(String(32), default="GLOBAL")
    registered_at = Column(DateTime, default=datetime.datetime.utcnow)
    last_heartbeat = Column(DateTime, default=datetime.datetime.utcnow)
    lifecycle_status = Column(String(32), default="ACTIVE")
    assigned_config_id = Column(String(64), default="default-oem-v1")

class ContentItem(Base):
    __tablename__ = "catalogue_items"
    
    id = Column(String(64), primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    tagline = Column(String(255))
    synopsis = Column(Text)
    backdrop_url = Column(String(512))
    poster_url = Column(String(512))
    duration_minutes = Column(Integer, default=120)
    release_year = Column(Integer, default=2026)
    rating = Column(String(16), default="PG-13")
    genre = Column(String(64), default="Cinematic Sci-Fi")
    is_4k = Column(Boolean, default=True)
    hdr_format = Column(String(32), default="Dolby Vision")
    audio_format = Column(String(32), default="Dolby Atmos 5.1")
    stream_url = Column(String(512), nullable=False)
    category = Column(String(64), default="Featured")

class UserProfile(Base):
    __tablename__ = "profiles"
    
    id = Column(String(64), primary_key=True, index=True)
    name = Column(String(64), nullable=False)
    avatar_color = Column(String(16), default="#F59E0B")
    is_kid = Column(Boolean, default=False)
    preferred_audio = Column(String(16), default="en")
    subtitles_enabled = Column(Boolean, default=False)

class OemConfiguration(Base):
    __tablename__ = "oem_configurations"
    
    id = Column(String(64), primary_key=True)
    version = Column(String(32), nullable=False)
    oem_brand = Column(String(64), default="Aureom")
    product_family = Column(String(64), default="Horizon OLED 4K")
    accent_color = Column(String(16), default="#F59E0B")
    feature_flags = Column(JSON, default=dict)
    supported_inputs = Column(JSON, default=list)
    published_at = Column(DateTime, default=datetime.datetime.utcnow)
    is_active = Column(Boolean, default=True)

class TelemetryRecord(Base):
    __tablename__ = "telemetry_records"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    device_id = Column(String(128), index=True)
    event_type = Column(String(64), nullable=False)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
    payload = Column(JSON)
