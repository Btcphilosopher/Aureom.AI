# AUREOM TV OS
## Enterprise OEM Television Software Platform
### Dual-Platform WebOS + Android TV + Shared Backend + Custom TV OS Track

Aureom TV OS is an OEM-grade television software platform providing two independently deployable television clients, a shared high-performance backend, and dedicated operating-system integration tracks for smart TV manufacturers.

---

## 1. System Deliverables

| Deliverable | Technology Stack | Location | Description |
|---|---|---|---|
| **Android TV Client** | Kotlin, Jetpack Compose for TV, Room, Media3 / ExoPlayer | `app/` | Production Android TV APK with 10-ft UI, remote D-Pad navigation, Media3 video player with custom TV OSD, EPG grid, and AOSP Privileged Mode simulation. |
| **WebOS TV Client** | TypeScript, HTML5, CSS, webOS Luna Bus APIs | `clients/webos-tv/` | Native LG webOS package (`com.aureom.tv.os`) with spatial navigation, video playback, and webOS service bridge. |
| **Shared Backend** | Python 3.12, FastAPI, SQLAlchemy, Pydantic V2, Docker | `backend/` | Unified REST `/api/v1` serving device registries, dynamic configuration, catalogue, telemetry ingestion, and signed update verification. |
| **OEM Integration Track** | AOSP 14/15 TV HAL, webOS Pro:Centric, Embedded Linux | `platform/` | AOSP system services (`IAureomPlatformService`), SELinux policies, webOS Luna role descriptors, and custom Yocto/Buildroot reference specs. |
| **API & Event Contracts** | OpenAPI 3.1, JSON Schema | `contracts/` | Typed schemas for device capabilities, OEM configuration, and telemetry events. |
| **Infrastructure** | Docker Compose | `infrastructure/` | Container orchestration for FastAPI backend, PostgreSQL, and Redis. |

---

## 2. Architecture & Design Principles

- **Graphite & Amber Cinematic Palette**: Graphite (`#0D0F14`), deep charcoal (`#151922`), warm white typography, and restrained amber/gold accents (`#F59E0B`).
- **Remote-First Spatial Navigation**: 4-way D-Pad focus engine with explicit high-contrast focus rings, smooth 1.06x zoom animations, and zero reliance on touch gestures.
- **Title-Safe & Overscan Compliance**: All interfaces respect 5% television overscan safety boundaries.
- **Offline Resilience**: Full local persistence using Room Database on Android and local caching on webOS.

---

## 3. Getting Started & Verification

### Running Android TV Client
The Android TV app builds using Gradle:
```bash
gradle :app:assembleDebug
gradle :app:testDebugUnitTest
```

### Running the Shared Backend
```bash
cd backend
pip install -e .
uvicorn aureom_tv.main:app --host 0.0.0.0 --port 8000
```
Or with Docker Compose:
```bash
docker compose -f infrastructure/compose.yaml up -d
```

### Building the webOS Client
```bash
cd clients/webos-tv
npm install
npm run build
ares-package dist -o package
```

---

## 4. Real vs. Simulated Capabilities

- **Verified Working**: Full 10-ft Jetpack Compose TV UI, Media3 ExoPlayer playback, Room local persistence, D-Pad focus engine, webOS spatial navigation, FastAPI endpoints, OpenAPI specs.
- **Simulated in User Mode / Unlocked in OEM Mode**: Hardware Tuner HAL (TIF) and HDMI-CEC direct port switching require OEM platform signing keys and system partition installation as detailed in `platform/android-aosp/README.md`.
