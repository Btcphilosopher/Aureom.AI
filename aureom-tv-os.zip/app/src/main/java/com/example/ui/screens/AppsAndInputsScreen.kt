package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AppInstallStatus
import com.example.domain.model.TvAppItem
import com.example.ui.theme.TvAccentAmber
import com.example.ui.theme.TvAccentEmerald
import com.example.ui.theme.TvBackground
import com.example.ui.theme.TvFocusBorder
import com.example.ui.theme.TvSurface
import com.example.ui.theme.TvSurfaceElevated
import com.example.ui.theme.TvTextMuted
import com.example.ui.theme.TvTextPrimary

@Composable
fun AppsAndInputsScreen(
    appRegistry: List<TvAppItem>,
    onSelectApp: (TvAppItem) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TvBackground)
            .padding(horizontal = 48.dp, vertical = 20.dp)
    ) {
        Text(
            text = "Application Registry & External HDMI Devices",
            color = TvTextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Verified installed applications and connected high-speed HDMI inputs via CEC HAL.",
            color = TvTextMuted,
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(appRegistry, key = { it.id }) { item ->
                TvAppRegistryCard(
                    item = item,
                    onClick = { onSelectApp(item) }
                )
            }
        }
    }
}

@Composable
private fun TvAppRegistryCard(
    item: TvAppItem,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    val statusColor = when (item.status) {
        AppInstallStatus.INSTALLED -> TvAccentEmerald
        AppInstallStatus.AVAILABLE -> TvAccentAmber
        AppInstallStatus.EXTERNAL_DEVICE -> Color(0xFF60A5FA)
        else -> TvTextMuted
    }

    val statusLabel = when (item.status) {
        AppInstallStatus.INSTALLED -> "INSTALLED"
        AppInstallStatus.AVAILABLE -> "AVAILABLE"
        AppInstallStatus.EXTERNAL_DEVICE -> "HARDWARE INPUT"
        AppInstallStatus.SUBSCRIPTION_REQUIRED -> "SUBSCRIPTION"
        AppInstallStatus.UNSUPPORTED -> "UNSUPPORTED"
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(115.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (isFocused) TvSurfaceElevated else TvSurface)
            .border(
                width = if (isFocused) 2.dp else 1.dp,
                color = if (isFocused) TvFocusBorder else Color(0x1AFFFFFF),
                shape = RoundedCornerShape(12.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(TvSurfaceElevated),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.iconSymbol,
                    color = TvAccentAmber,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = item.name,
                    color = TvTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = statusLabel,
                            color = statusColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    item.badge?.let {
                        Text(
                            text = it,
                            color = TvTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
