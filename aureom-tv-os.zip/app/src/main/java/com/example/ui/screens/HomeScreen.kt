package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.ContentItem
import com.example.domain.model.TvAppItem
import com.example.domain.model.TvCategory
import com.example.ui.components.TvFocusCard
import com.example.ui.components.TvHeroBillboard
import com.example.ui.theme.TvAccentAmber
import com.example.ui.theme.TvBackground
import com.example.ui.theme.TvSurface
import com.example.ui.theme.TvSurfaceElevated
import com.example.ui.theme.TvTextMuted
import com.example.ui.theme.TvTextPrimary

@Composable
fun HomeScreen(
    categories: List<TvCategory>,
    continueWatching: List<ContentItem>,
    appRegistry: List<TvAppItem>,
    onPlayContent: (ContentItem) -> Unit,
    onAppClick: (TvAppItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val featuredItem = categories.firstOrNull()?.items?.firstOrNull()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TvBackground),
        contentPadding = PaddingValues(bottom = 60.dp)
    ) {
        // Hero Billboard
        if (featuredItem != null) {
            item {
                Box(modifier = Modifier.padding(horizontal = 48.dp, vertical = 12.dp)) {
                    TvHeroBillboard(
                        featuredItem = featuredItem,
                        onPlayClick = { onPlayContent(featuredItem) }
                    )
                }
            }
        }

        // Continue Watching Row (if any items)
        if (continueWatching.isNotEmpty()) {
            item {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    Text(
                        text = "Continue Watching",
                        color = TvTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 48.dp, vertical = 8.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(horizontal = 48.dp)
                    ) {
                        items(continueWatching, key = { "cw_${it.id}" }) { item ->
                            TvFocusCard(
                                item = item,
                                onClick = { onPlayContent(item) }
                            )
                        }
                    }
                }
            }
        }

        // Quick Apps & Inputs Shelf
        item {
            Column(modifier = Modifier.padding(top = 20.dp)) {
                Text(
                    text = "Applications & Connected Inputs",
                    color = TvTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 48.dp, vertical = 8.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(horizontal = 48.dp)
                ) {
                    items(appRegistry.take(6), key = { it.id }) { app ->
                        TvQuickAppCard(app = app, onClick = { onAppClick(app) })
                    }
                }
            }
        }

        // Category Rows (4K Cinema, Documentaries, etc.)
        categories.forEach { category ->
            item {
                Column(modifier = Modifier.padding(top = 24.dp)) {
                    Text(
                        text = category.name,
                        color = TvTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 48.dp, vertical = 8.dp)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        contentPadding = PaddingValues(horizontal = 48.dp)
                    ) {
                        items(category.items, key = { "${category.name}_${it.id}" }) { item ->
                            TvFocusCard(
                                item = item,
                                onClick = { onPlayContent(item) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TvQuickAppCard(
    app: TvAppItem,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(160.dp)
            .height(90.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(TvSurface)
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(32.dp)
                        .height(32.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(TvSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = app.iconSymbol,
                        color = TvAccentAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (app.badge != null) {
                    Box(
                        modifier = Modifier
                            .background(Color(0x33F59E0B), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = app.badge,
                            color = TvAccentAmber,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Text(
                text = app.name,
                color = TvTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}
