package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aureom TV OS Palette: Restrained Cinematic Graphite, Charcoal, and Warm Amber
val TvBackground = Color(0xFF0D0F14)
val TvSurface = Color(0xFF151922)
val TvSurfaceElevated = Color(0xFF1E232E)
val TvSurfaceHighlight = Color(0xFF2B3242)

val TvAccentAmber = Color(0xFFF59E0B)
val TvAccentGold = Color(0xFFD97706)
val TvAccentCrimson = Color(0xFFEF4444)
val TvAccentEmerald = Color(0xFF10B981)

val TvTextPrimary = Color(0xFFF8FAFC)
val TvTextSecondary = Color(0xFFCBD5E1)
val TvTextMuted = Color(0xFF94A3B8)
val TvBorderSubtle = Color(0x1FFFFFFF)
val TvFocusBorder = Color(0xFFF59E0B)
val TvFocusGlow = Color(0x66F59E0B)
