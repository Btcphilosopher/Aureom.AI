package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AureomTvRepository
import com.example.domain.model.ContentItem
import com.example.domain.model.DeviceCapability
import com.example.domain.model.OemSystemSettings
import com.example.domain.model.TvAppItem
import com.example.domain.model.TvCategory
import com.example.domain.model.TvChannel
import com.example.domain.model.TvProfile
import com.example.playback.TvPlaybackManager
import com.example.ui.components.TvNavScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TvViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = AureomTvRepository(application)
    val playbackManager = TvPlaybackManager(application, viewModelScope)

    private val _categories = MutableStateFlow<List<TvCategory>>(emptyList())
    val categories: StateFlow<List<TvCategory>> = _categories.asStateFlow()

    val continueWatching: StateFlow<List<ContentItem>> = repository.continueWatchingFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<OemSystemSettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), OemSystemSettings())

    private val _appRegistry = MutableStateFlow<List<TvAppItem>>(repository.getVerifiedAppRegistry())
    val appRegistry: StateFlow<List<TvAppItem>> = _appRegistry.asStateFlow()

    private val _liveChannels = MutableStateFlow<List<TvChannel>>(repository.getLiveChannels())
    val liveChannels: StateFlow<List<TvChannel>> = _liveChannels.asStateFlow()

    private val _profiles = MutableStateFlow<List<TvProfile>>(repository.getProfiles())
    val profiles: StateFlow<List<TvProfile>> = _profiles.asStateFlow()

    private val _activeProfileId = MutableStateFlow("p1")
    val activeProfileId: StateFlow<String> = _activeProfileId.asStateFlow()

    private val _currentScreen = MutableStateFlow(TvNavScreen.HOME)
    val currentScreen: StateFlow<TvNavScreen> = _currentScreen.asStateFlow()

    private val _activeContentForPlayback = MutableStateFlow<ContentItem?>(null)
    val activeContentForPlayback: StateFlow<ContentItem?> = _activeContentForPlayback.asStateFlow()

    private val _deviceCapability = MutableStateFlow(repository.detectDeviceCapabilities(false))
    val deviceCapability: StateFlow<DeviceCapability> = _deviceCapability.asStateFlow()

    private val _currentTimeString = MutableStateFlow(getCurrentFormattedTime())
    val currentTimeString: StateFlow<String> = _currentTimeString.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>("Aureom TV OS Ready")
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        loadInitialData()
        startClockTicker()
    }

    private fun loadInitialData() {
        viewModelScope.launch {
            _categories.value = repository.getInitialCategories()
            // Proactively try backend sync
            repository.syncWithBackend()
            _deviceCapability.value = repository.detectDeviceCapabilities(settings.value.isAospPrivilegedMode)
        }
    }

    private fun startClockTicker() {
        viewModelScope.launch {
            while (isActive) {
                _currentTimeString.value = getCurrentFormattedTime()
                delay(30000)
            }
        }
    }

    private fun getCurrentFormattedTime(): String {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        return sdf.format(Date())
    }

    fun navigateTo(screen: TvNavScreen) {
        _currentScreen.value = screen
    }

    fun playContent(item: ContentItem) {
        _activeContentForPlayback.value = item
        viewModelScope.launch {
            repository.logTelemetry("PLAYBACK_REQUEST", "Playing ${item.title} (${item.streamUrl})")
        }
    }

    fun playChannel(channel: TvChannel) {
        val streamItem = ContentItem(
            id = "live_${channel.number}",
            title = "Live: ${channel.name} (${channel.currentShow})",
            synopsis = "Now playing: ${channel.currentShow}. Next: ${channel.nextShow}",
            streamUrl = channel.streamUrl,
            category = "Live TV",
            is4K = true
        )
        playContent(streamItem)
    }

    fun closePlayer(lastPositionMs: Long) {
        val item = _activeContentForPlayback.value
        if (item != null && lastPositionMs > 1000L) {
            viewModelScope.launch {
                repository.updateResumePosition(item.id, lastPositionMs)
            }
        }
        _activeContentForPlayback.value = null
    }

    fun updateSettings(newSettings: OemSystemSettings) {
        viewModelScope.launch {
            repository.saveSettings(newSettings)
            _deviceCapability.value = repository.detectDeviceCapabilities(newSettings.isAospPrivilegedMode)
            _statusMessage.value = "Settings updated"
        }
    }

    fun selectProfile(profileId: String) {
        _activeProfileId.value = profileId
        _statusMessage.value = "Switched to profile: ${profiles.value.find { it.id == profileId }?.name}"
    }

    fun syncWithBackend() {
        viewModelScope.launch {
            _statusMessage.value = "Connecting to shared backend..."
            val success = repository.syncWithBackend()
            if (success) {
                _categories.value = repository.getInitialCategories()
                _statusMessage.value = "Synchronized with Aureom Cloud"
            } else {
                _statusMessage.value = "Backend offline. Using local resilient cache."
            }
        }
    }

    fun handleAppLaunch(app: TvAppItem) {
        _statusMessage.value = "Launched: ${app.name} (${app.status})"
        viewModelScope.launch {
            repository.logTelemetry("APP_LAUNCH_ACTION", "App: ${app.name}, status: ${app.status}")
        }
    }

    override fun onCleared() {
        super.onCleared()
        playbackManager.release()
    }
}
