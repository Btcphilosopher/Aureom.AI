package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TvAccentAmber
import com.example.ui.theme.TvAccentEmerald
import com.example.ui.theme.TvFocusBorder
import com.example.ui.theme.TvSurfaceElevated
import com.example.ui.theme.TvTextMuted
import com.example.ui.theme.TvTextPrimary

enum class TvNavScreen {
    HOME,
    LIVE_TV,
    APPS_AND_INPUTS,
    SETTINGS
}

@Composable
fun TvTopBar(
    currentScreen: TvNavScreen,
    onNavigate: (TvNavScreen) -> Unit,
    activeProfileName: String,
    isNetworkConnected: Boolean,
    currentTimeString: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 48.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Brand Mark
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(TvAccentAmber),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "A",
                    color = Color.Black,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "AUREOM",
                color = TvTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .background(TvSurfaceElevated, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "TV OS",
                    color = TvAccentAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
        }

        // Navigation Tabs
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TvNavTab(
                title = "Home",
                isSelected = currentScreen == TvNavScreen.HOME,
                onClick = { onNavigate(TvNavScreen.HOME) },
                testTag = "nav_home"
            )
            TvNavTab(
                title = "Live TV",
                isSelected = currentScreen == TvNavScreen.LIVE_TV,
                onClick = { onNavigate(TvNavScreen.LIVE_TV) },
                testTag = "nav_livetv"
            )
            TvNavTab(
                title = "Apps & Inputs",
                isSelected = currentScreen == TvNavScreen.APPS_AND_INPUTS,
                onClick = { onNavigate(TvNavScreen.APPS_AND_INPUTS) },
                testTag = "nav_apps"
            )
            TvNavTab(
                title = "Settings",
                isSelected = currentScreen == TvNavScreen.SETTINGS,
                onClick = { onNavigate(TvNavScreen.SETTINGS) },
                testTag = "nav_settings"
            )
        }

        // System Status & Profile Pill
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isNetworkConnected) TvAccentEmerald else Color.Red)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isNetworkConnected) "Online" else "Offline",
                    color = TvTextMuted,
                    fontSize = 12.sp
                )
            }

            Text(
                text = currentTimeString,
                color = TvTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            // Profile Tag
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(TvSurfaceElevated)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = activeProfileName,
                    color = TvTextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun TvNavTab(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    var isFocused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isFocused) 1.08f else 1.0f,
        label = "tab_scale"
    )

    val bgColor = when {
        isFocused -> TvAccentAmber
        isSelected -> TvSurfaceElevated
        else -> Color.Transparent
    }

    val textColor = when {
        isFocused -> Color.Black
        isSelected -> TvTextPrimary
        else -> TvTextMuted
    }

    Box(
        modifier = Modifier
            .scale(scale)
            .clip(RoundedCornerShape(20.dp))
            .background(bgColor)
            .border(
                width = if (isFocused) 2.dp else 0.dp,
                color = if (isFocused) TvFocusBorder else Color.Transparent,
                shape = RoundedCornerShape(20.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = textColor,
            fontSize = 14.sp,
            fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Medium
        )
    }
}
