package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DeviceCapability
import com.example.domain.model.OemSystemSettings
import com.example.domain.model.TvProfile
import com.example.ui.components.TvFocusButton
import com.example.ui.theme.TvAccentAmber
import com.example.ui.theme.TvAccentCrimson
import com.example.ui.theme.TvAccentEmerald
import com.example.ui.theme.TvBackground
import com.example.ui.theme.TvFocusBorder
import com.example.ui.theme.TvSurface
import com.example.ui.theme.TvSurfaceElevated
import com.example.ui.theme.TvTextMuted
import com.example.ui.theme.TvTextPrimary

enum class SettingsTab {
    DEVICE_INFO,
    PICTURE_DISPLAY,
    AUDIO_PASSTHROUGH,
    NETWORK_DIAGNOSTICS,
    PROFILES_PRIVACY,
    OEM_INTEGRATION_MODE
}

@Composable
fun SettingsScreen(
    deviceCapability: DeviceCapability,
    settings: OemSystemSettings,
    profiles: List<TvProfile>,
    activeProfileId: String,
    onUpdateSettings: (OemSystemSettings) -> Unit,
    onSelectProfile: (String) -> Unit,
    onTriggerSync: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableStateOf(SettingsTab.DEVICE_INFO) }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(TvBackground)
            .padding(horizontal = 48.dp, vertical = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(36.dp)
    ) {
        // Left Column: Settings Categories Navigation
        Column(
            modifier = Modifier
                .width(260.dp)
                .fillMaxHeight(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "System Settings",
                color = TvTextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            TvSettingsNavButton(
                title = "Device & Hardware",
                isSelected = activeTab == SettingsTab.DEVICE_INFO,
                onClick = { activeTab = SettingsTab.DEVICE_INFO },
                testTag = "tab_device_info"
            )

            TvSettingsNavButton(
                title = "Picture & Display",
                isSelected = activeTab == SettingsTab.PICTURE_DISPLAY,
                onClick = { activeTab = SettingsTab.PICTURE_DISPLAY },
                testTag = "tab_picture"
            )

            TvSettingsNavButton(
                title = "Audio & Passthrough",
                isSelected = activeTab == SettingsTab.AUDIO_PASSTHROUGH,
                onClick = { activeTab = SettingsTab.AUDIO_PASSTHROUGH },
                testTag = "tab_audio"
            )

            TvSettingsNavButton(
                title = "Network Diagnostics",
                isSelected = activeTab == SettingsTab.NETWORK_DIAGNOSTICS,
                onClick = { activeTab = SettingsTab.NETWORK_DIAGNOSTICS },
                testTag = "tab_network"
            )

            TvSettingsNavButton(
                title = "Profiles & Privacy",
                isSelected = activeTab == SettingsTab.PROFILES_PRIVACY,
                onClick = { activeTab = SettingsTab.PROFILES_PRIVACY },
                testTag = "tab_profiles"
            )

            TvSettingsNavButton(
                title = "OEM Platform Mode",
                isSelected = activeTab == SettingsTab.OEM_INTEGRATION_MODE,
                onClick = { activeTab = SettingsTab.OEM_INTEGRATION_MODE },
                testTag = "tab_oem_mode"
            )
        }

        // Right Column: Setting Content Panel
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(TvSurface)
                .padding(32.dp)
        ) {
            when (activeTab) {
                SettingsTab.DEVICE_INFO -> DeviceInfoContent(deviceCapability, onTriggerSync)
                SettingsTab.PICTURE_DISPLAY -> PictureDisplayContent(settings, deviceCapability.isOemPrivilegedMode, onUpdateSettings)
                SettingsTab.AUDIO_PASSTHROUGH -> AudioPassthroughContent(settings, onUpdateSettings)
                SettingsTab.NETWORK_DIAGNOSTICS -> NetworkDiagnosticsContent(deviceCapability, onTriggerSync)
                SettingsTab.PROFILES_PRIVACY -> ProfilesPrivacyContent(profiles, activeProfileId, onSelectProfile, settings, onUpdateSettings)
                SettingsTab.OEM_INTEGRATION_MODE -> OemIntegrationModeContent(settings, onUpdateSettings)
            }
        }
    }
}

@Composable
private fun DeviceInfoContent(
    cap: DeviceCapability,
    onTriggerSync: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text(
                text = "Device & Operating System Information",
                color = TvTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(14.dp))
        }

        item {
            TvSettingRow(
                title = "Hardware Model & Chipset",
                subtitle = "${cap.hardwareModel} • ARM64 SoC Reference",
                badge = if (cap.isOemPrivilegedMode) "OEM Verified Hardware" else "User Application Mode",
                isVerified = cap.isOemPrivilegedMode
            )
        }

        item {
            TvSettingRow(
                title = "Operating System Platform",
                subtitle = "${cap.platformFamily} • ${cap.platformVersion}",
                badge = "Aureom TV 1.0 (Build 2026.10)"
            )
        }

        item {
            TvSettingRow(
                title = "Screen Resolution & Panel Refresh",
                subtitle = "${cap.screenResolution} @ ${cap.refreshRateHz}Hz OLED Ultra HD",
                badge = "Hardware Native"
            )
        }

        item {
            TvSettingRow(
                title = "Decoders & Codec Capabilities",
                subtitle = cap.supportedCodecs.joinToString(", "),
                badge = "Hardware Accelerated"
            )
        }

        item {
            TvSettingRow(
                title = "System Memory / Process Allocation",
                subtitle = "${cap.memoryUsageMb} MB Allocated of ${cap.totalMemoryMb} MB Total",
                badge = "Within TV Budget"
            )
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            TvFocusButton(
                text = "Synchronize with Shared Backend",
                onClick = onTriggerSync,
                isPrimary = true,
                testTag = "btn_sync_backend"
            )
        }
    }
}

@Composable
private fun PictureDisplayContent(
    settings: OemSystemSettings,
    isPrivileged: Boolean,
    onUpdate: (OemSystemSettings) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Text(
                text = "Picture & Display Profiles",
                color = TvTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (isPrivileged) "System-level panel LUT calibration enabled via OEM HAL." else "Simulated UI preferences in User Mode.",
                color = TvTextMuted,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        item {
            val modes = listOf("Cinema HDR", "Game Mode (ALLM)", "Standard", "Vivid", "Calibrated Filmmaker")
            TvChoiceRow(
                label = "Active Picture Mode",
                currentChoice = settings.pictureMode,
                choices = modes,
                onSelect = { onUpdate(settings.copy(pictureMode = it)) }
            )
        }

        item {
            val memcLevels = listOf("Off", "Cinematic (Low)", "Standard (Medium)", "Ultra Smooth (High)")
            TvChoiceRow(
                label = "Motion Estimation / Smoothing (MEMC)",
                currentChoice = settings.memcLevel,
                choices = memcLevels,
                onSelect = { onUpdate(settings.copy(memcLevel = it)) }
            )
        }

        item {
            TvToggleRow(
                label = "Ambient Artwork Standby Mode",
                description = "Display curated museum artwork when idle for 10 minutes",
                isEnabled = settings.ambientModeEnabled,
                onToggle = { onUpdate(settings.copy(ambientModeEnabled = !settings.ambientModeEnabled)) }
            )
        }
    }
}

@Composable
private fun AudioPassthroughContent(
    settings: OemSystemSettings,
    onUpdate: (OemSystemSettings) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Text(
                text = "Audio & Passthrough Configuration",
                color = TvTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        item {
            val outputs = listOf("eARC Passthrough (Dolby Atmos)", "Internal TV Speakers", "Optical SPDIF")
            TvChoiceRow(
                label = "Audio Output Route",
                currentChoice = settings.audioOutput,
                choices = outputs,
                onSelect = { onUpdate(settings.copy(audioOutput = it)) }
            )
        }

        item {
            TvSettingRow(
                title = "Dolby Atmos & Spatial Audio Pipeline",
                subtitle = "Hardware bitstream passthrough to AV receiver or soundbar via HDMI-eARC.",
                badge = "Bitstream Active"
            )
        }
    }
}

@Composable
private fun NetworkDiagnosticsContent(
    cap: DeviceCapability,
    onPing: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text(
                text = "Network & Cloud Connectivity Diagnostics",
                color = TvTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        item {
            TvSettingRow(
                title = "Network Connection Status",
                subtitle = "${cap.networkType} • IP: 10.0.2.15 (Loopback)",
                badge = if (cap.isNetworkConnected) "ONLINE" else "DISCONNECTED",
                isVerified = cap.isNetworkConnected
            )
        }

        item {
            TvSettingRow(
                title = "Backend Service Endpoint",
                subtitle = "http://10.0.2.2:8000/api/v1 (FastAPI Platform)",
                badge = "Ready"
            )
        }

        item {
            TvSettingRow(
                title = "Telemetry Heartbeat & Channel",
                subtitle = "Channel: stable • Interval: 60s • Opt-in active",
                badge = "Healthy"
            )
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            TvFocusButton(
                text = "Run Connectivity Diagnostic Test",
                onClick = onPing,
                isPrimary = true,
                testTag = "btn_diag_ping"
            )
        }
    }
}

@Composable
private fun ProfilesPrivacyContent(
    profiles: List<TvProfile>,
    activeProfileId: String,
    onSelectProfile: (String) -> Unit,
    settings: OemSystemSettings,
    onUpdateSettings: (OemSystemSettings) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text(
                text = "Household Profiles & Privacy",
                color = TvTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        item {
            Text(
                text = "Switch Active Household Profile:",
                color = TvTextMuted,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                profiles.forEach { profile ->
                    val isActive = profile.id == activeProfileId
                    TvFocusButton(
                        text = if (isActive) "✓ ${profile.name}" else profile.name,
                        onClick = { onSelectProfile(profile.id) },
                        isPrimary = isActive,
                        testTag = "btn_profile_${profile.id}"
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
            TvToggleRow(
                label = "Operational Diagnostics & Telemetry Opt-in",
                description = "Sends crash reports and playback QoS stats to OEM backend without personal viewing logs.",
                isEnabled = settings.telemetryOptIn,
                onToggle = { onUpdateSettings(settings.copy(telemetryOptIn = !settings.telemetryOptIn)) }
            )
        }
    }
}

@Composable
private fun OemIntegrationModeContent(
    settings: OemSystemSettings,
    onUpdate: (OemSystemSettings) -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text(
                text = "OEM Platform Integration Mode",
                color = TvTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Distinguish between standard 3rd-party user application sandboxing and authorized OEM AOSP system-service privilege level.",
                color = TvTextMuted,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        item {
            TvToggleRow(
                label = "Simulate AOSP Privileged OEM Mode",
                description = if (settings.isAospPrivilegedMode) {
                    "Privileged system service active: Tuner HAL, HDMI-CEC direct routing, and system recovery A/B update authorization unlocked."
                } else {
                    "Standard User Application Sandbox: Hardware operations restricted to standard Android APIs."
                },
                isEnabled = settings.isAospPrivilegedMode,
                onToggle = { onUpdate(settings.copy(isAospPrivilegedMode = !settings.isAospPrivilegedMode)) }
            )
        }

        item {
            TvSettingRow(
                title = "AOSP System Service Binder Contract",
                subtitle = "com.aureom.tv.platform.IAureomPlatformService",
                badge = if (settings.isAospPrivilegedMode) "Privileged System Server" else "User App Fallback"
            )
        }

        item {
            TvSettingRow(
                title = "OTA Firmware Dual-Bank A/B Protection",
                subtitle = "Signed payload verification with dm-verity and automatic rollback watchdog.",
                badge = "Hardware Integrity Enforced"
            )
        }
    }
}

@Composable
private fun TvSettingsNavButton(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    var isFocused by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) TvSurfaceElevated else Color.Transparent)
            .border(
                width = if (isFocused) 2.dp else 0.dp,
                color = if (isFocused) TvFocusBorder else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 14.dp)
            .testTag(testTag)
    ) {
        Text(
            text = title,
            color = if (isSelected || isFocused) TvTextPrimary else TvTextMuted,
            fontSize = 15.sp,
            fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun TvSettingRow(
    title: String,
    subtitle: String,
    badge: String,
    isVerified: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(TvSurfaceElevated)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = TvTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = TvTextMuted,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Box(
            modifier = Modifier
                .background(
                    if (isVerified) Color(0x3310B981) else Color(0x33F59E0B),
                    RoundedCornerShape(4.dp)
                )
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = badge,
                color = if (isVerified) TvAccentEmerald else TvAccentAmber,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun TvChoiceRow(
    label: String,
    currentChoice: String,
    choices: List<String>,
    onSelect: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(TvSurfaceElevated)
            .padding(16.dp)
    ) {
        Text(
            text = label,
            color = TvTextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            choices.forEach { choice ->
                val isSelected = choice == currentChoice
                TvFocusButton(
                    text = choice,
                    onClick = { onSelect(choice) },
                    isPrimary = isSelected,
                    testTag = "choice_${choice.take(6)}"
                )
            }
        }
    }
}

@Composable
private fun TvToggleRow(
    label: String,
    description: String,
    isEnabled: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(TvSurfaceElevated)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                color = TvTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                color = TvTextMuted,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        TvFocusButton(
            text = if (isEnabled) "ENABLED" else "DISABLED",
            onClick = onToggle,
            isPrimary = isEnabled,
            testTag = "toggle_${label.take(6)}"
        )
    }
}
