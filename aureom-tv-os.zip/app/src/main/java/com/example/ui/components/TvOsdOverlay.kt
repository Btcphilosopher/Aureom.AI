package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.playback.TvPlayerState
import com.example.ui.theme.TvAccentAmber
import com.example.ui.theme.TvSurfaceElevated
import com.example.ui.theme.TvTextMuted
import com.example.ui.theme.TvTextPrimary

@Composable
fun TvOsdOverlay(
    playerState: TvPlayerState,
    onPlayPause: () -> Unit,
    onSeekRewind: () -> Unit,
    onSeekForward: () -> Unit,
    onCycleAudio: () -> Unit,
    onCycleSubtitles: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0x99000000),
                        Color.Transparent,
                        Color(0xEE000000)
                    ),
                    startY = 0f
                )
            )
            .padding(horizontal = 48.dp, vertical = 32.dp)
    ) {
        // Top Stream Diagnostics
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = playerState.title,
                    color = TvTextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .background(TvAccentAmber, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "LIVE STREAM",
                            color = Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = playerState.activeResolution,
                        color = TvTextMuted,
                        fontSize = 12.sp
                    )
                }
            }

            TvFocusButton(
                text = "Close Player [Back]",
                onClick = onClose,
                isPrimary = false,
                testTag = "btn_osd_close"
            )
        }

        // Center Buffering Indicator if loading
        if (playerState.isBuffering) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0xAA000000), RoundedCornerShape(12.dp))
                    .padding(horizontal = 24.dp, vertical = 14.dp)
            ) {
                Text(
                    text = "Buffering Stream...",
                    color = TvAccentAmber,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Bottom Controls & Timeline
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            // Timeline progress bar
            val currentSec = (playerState.currentPositionMs / 1000).coerceAtLeast(0L)
            val durationSec = (playerState.durationMs / 1000).coerceAtLeast(1L)
            val progressFraction = (currentSec.toFloat() / durationSec.toFloat()).coerceIn(0f, 1f)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(TvSurfaceElevated)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progressFraction)
                        .height(8.dp)
                        .background(TvAccentAmber)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Time labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatTime(currentSec),
                    color = TvTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = formatTime(durationSec),
                    color = TvTextMuted,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Playback buttons
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TvFocusButton(
                    text = if (playerState.isPlaying) "Pause" else "Play",
                    onClick = onPlayPause,
                    isPrimary = true,
                    testTag = "btn_osd_play_pause"
                )

                TvFocusButton(
                    text = "-10s",
                    onClick = onSeekRewind,
                    testTag = "btn_osd_rewind"
                )

                TvFocusButton(
                    text = "+30s",
                    onClick = onSeekForward,
                    testTag = "btn_osd_forward"
                )

                TvFocusButton(
                    text = "Audio: ${playerState.activeAudio}",
                    onClick = onCycleAudio,
                    testTag = "btn_osd_audio"
                )

                TvFocusButton(
                    text = "Subtitles: ${playerState.activeSubtitles}",
                    onClick = onCycleSubtitles,
                    testTag = "btn_osd_subs"
                )
            }
        }
    }
}

private fun formatTime(seconds: Long): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format("%02d:%02d", m, s)
}
