package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TvColorScheme = darkColorScheme(
    primary = TvAccentAmber,
    onPrimary = TvBackground,
    primaryContainer = TvAccentGold,
    onPrimaryContainer = TvTextPrimary,
    secondary = TvSurfaceElevated,
    onSecondary = TvTextPrimary,
    tertiary = TvAccentEmerald,
    background = TvBackground,
    onBackground = TvTextPrimary,
    surface = TvSurface,
    onSurface = TvTextPrimary,
    surfaceVariant = TvSurfaceElevated,
    onSurfaceVariant = TvTextSecondary,
    outline = TvBorderSubtle,
    error = TvAccentCrimson,
    onError = TvTextPrimary
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TvColorScheme,
        typography = Typography,
        content = content
    )
}
