package com.example.ui.screens

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.example.domain.model.ContentItem
import com.example.playback.TvPlaybackManager
import com.example.ui.components.TvOsdOverlay
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    item: ContentItem,
    playbackManager: TvPlaybackManager,
    onClose: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val playerState by playbackManager.playerState.collectAsState()
    var isOsdVisible by remember { mutableStateOf(true) }

    // Start playback when screen enters composition
    LaunchedEffect(item.id) {
        playbackManager.loadAndPlay(
            streamUrl = item.streamUrl,
            title = item.title,
            startPositionMs = item.resumePositionMs
        )
    }

    // Auto-hide OSD after 6 seconds of inactivity
    LaunchedEffect(isOsdVisible, playerState.isPlaying) {
        if (isOsdVisible && playerState.isPlaying) {
            delay(6000)
            isOsdVisible = false
        }
    }

    // BackHandler to exit player safely and report resume timestamp
    BackHandler {
        onClose(playerState.currentPositionMs)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                isOsdVisible = !isOsdVisible
            }
            .focusable()
    ) {
        // Media3 ExoPlayer AndroidView
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = playbackManager.getPlayer()
                    useController = false // Custom TV OSD overlay used
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // TV On-Screen Display Overlay
        if (isOsdVisible) {
            TvOsdOverlay(
                playerState = playerState,
                onPlayPause = { playbackManager.togglePlayPause() },
                onSeekRewind = { playbackManager.seekBy(-10000L) },
                onSeekForward = { playbackManager.seekBy(30000L) },
                onCycleAudio = { playbackManager.cycleAudioTrack() },
                onCycleSubtitles = { playbackManager.cycleSubtitles() },
                onClose = { onClose(playerState.currentPositionMs) }
            )
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            playbackManager.release()
        }
    }
}
