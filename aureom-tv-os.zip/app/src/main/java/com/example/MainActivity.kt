package com.example

import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.ui.TvViewModel
import com.example.ui.components.TvNavScreen
import com.example.ui.components.TvTopBar
import com.example.ui.screens.AppsAndInputsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveTvScreen
import com.example.ui.screens.PlayerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TvBackground

class MainActivity : ComponentActivity() {
    private val viewModel: TvViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                AureomTvApp(viewModel = viewModel)
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Intercept TV media remote keys
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (viewModel.activeContentForPlayback.value != null) {
                    viewModel.playbackManager.togglePlayPause()
                    return true
                }
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (viewModel.activeContentForPlayback.value != null) {
                    viewModel.playbackManager.seekBy(-10000L)
                    return true
                }
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (viewModel.activeContentForPlayback.value != null) {
                    viewModel.playbackManager.seekBy(30000L)
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
fun AureomTvApp(viewModel: TvViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val activeContent by viewModel.activeContentForPlayback.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val continueWatching by viewModel.continueWatching.collectAsState()
    val appRegistry by viewModel.appRegistry.collectAsState()
    val liveChannels by viewModel.liveChannels.collectAsState()
    val profiles by viewModel.profiles.collectAsState()
    val activeProfileId by viewModel.activeProfileId.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val deviceCapability by viewModel.deviceCapability.collectAsState()
    val currentTimeString by viewModel.currentTimeString.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()

    val activeProfile = profiles.find { it.id == activeProfileId }

    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            if (it != "Aureom TV OS Ready") {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Secondary Screen Back Navigation
    BackHandler(enabled = activeContent == null && currentScreen != TvNavScreen.HOME) {
        viewModel.navigateTo(TvNavScreen.HOME)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(TvBackground)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .safeDrawingPadding()
                .background(TvBackground)
        ) {
            if (activeContent != null) {
                // Fullscreen Player View
                PlayerScreen(
                    item = activeContent!!,
                    playbackManager = viewModel.playbackManager,
                    onClose = { lastPos ->
                        viewModel.closePlayer(lastPos)
                    }
                )
            } else {
                // Main TV Shell
                Column(modifier = Modifier.fillMaxSize()) {
                    TvTopBar(
                        currentScreen = currentScreen,
                        onNavigate = { viewModel.navigateTo(it) },
                        activeProfileName = activeProfile?.name ?: "Living Room",
                        isNetworkConnected = deviceCapability.isNetworkConnected,
                        currentTimeString = currentTimeString
                    )

                    Box(modifier = Modifier.weight(1f)) {
                        when (currentScreen) {
                            TvNavScreen.HOME -> {
                                HomeScreen(
                                    categories = categories,
                                    continueWatching = continueWatching,
                                    appRegistry = appRegistry,
                                    onPlayContent = { viewModel.playContent(it) },
                                    onAppClick = { viewModel.handleAppLaunch(it) }
                                )
                            }
                            TvNavScreen.LIVE_TV -> {
                                LiveTvScreen(
                                    channels = liveChannels,
                                    isTunerAvailable = deviceCapability.isTunerAvailable,
                                    onSelectChannel = { viewModel.playChannel(it) }
                                )
                            }
                            TvNavScreen.APPS_AND_INPUTS -> {
                                AppsAndInputsScreen(
                                    appRegistry = appRegistry,
                                    onSelectApp = { viewModel.handleAppLaunch(it) }
                                )
                            }
                            TvNavScreen.SETTINGS -> {
                                SettingsScreen(
                                    deviceCapability = deviceCapability,
                                    settings = settings,
                                    profiles = profiles,
                                    activeProfileId = activeProfileId,
                                    onUpdateSettings = { viewModel.updateSettings(it) },
                                    onSelectProfile = { viewModel.selectProfile(it) },
                                    onTriggerSync = { viewModel.syncWithBackend() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
