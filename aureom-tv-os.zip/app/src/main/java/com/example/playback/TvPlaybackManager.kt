package com.example.playback

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class TvPlayerState(
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val title: String = "",
    val error: String? = null,
    val activeResolution: String = "3840x2160 (4K UHD)",
    val activeAudio: String = "Dolby Atmos 5.1",
    val activeSubtitles: String = "Off"
)

@OptIn(UnstableApi::class)
class TvPlaybackManager(
    private val context: Context,
    private val coroutineScope: CoroutineScope
) {
    private var exoPlayer: ExoPlayer? = null
    private var progressPollJob: Job? = null

    private val _playerState = MutableStateFlow(TvPlayerState())
    val playerState: StateFlow<TvPlayerState> = _playerState.asStateFlow()

    fun getPlayer(): ExoPlayer {
        return exoPlayer ?: initializePlayer()
    }

    private fun initializePlayer(): ExoPlayer {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(context)
            .setAudioAttributes(audioAttributes, true) // Handles audio focus automatically
            .build().apply {
                playWhenReady = true
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(state: Int) {
                        val isBuffering = state == Player.STATE_BUFFERING
                        _playerState.value = _playerState.value.copy(
                            isBuffering = isBuffering,
                            durationMs = duration.coerceAtLeast(0L)
                        )
                        if (state == Player.STATE_READY) {
                            startPollingProgress()
                        } else if (state == Player.STATE_ENDED) {
                            _playerState.value = _playerState.value.copy(isPlaying = false)
                        }
                    }

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        _playerState.value = _playerState.value.copy(isPlaying = isPlaying)
                        if (isPlaying) {
                            startPollingProgress()
                        }
                    }

                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        _playerState.value = _playerState.value.copy(
                            error = "Playback error: ${error.message}",
                            isBuffering = false
                        )
                    }
                })
            }
        exoPlayer = player
        return player
    }

    fun loadAndPlay(streamUrl: String, title: String, startPositionMs: Long = 0L) {
        val player = getPlayer()
        _playerState.value = TvPlayerState(
            title = title,
            currentPositionMs = startPositionMs,
            isBuffering = true
        )

        val mediaItem = MediaItem.fromUri(streamUrl)
        player.setMediaItem(mediaItem, startPositionMs)
        player.prepare()
        player.play()
    }

    fun togglePlayPause() {
        exoPlayer?.let { player ->
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }
        }
    }

    fun seekBy(offsetMs: Long) {
        exoPlayer?.let { player ->
            val newPos = (player.currentPosition + offsetMs).coerceIn(0L, player.duration.coerceAtLeast(0L))
            player.seekTo(newPos)
            _playerState.value = _playerState.value.copy(currentPositionMs = newPos)
        }
    }

    fun cycleAudioTrack() {
        val current = _playerState.value.activeAudio
        val next = when (current) {
            "Dolby Atmos 5.1" -> "Dolby Digital 5.1"
            "Dolby Digital 5.1" -> "Stereo PCM"
            else -> "Dolby Atmos 5.1"
        }
        _playerState.value = _playerState.value.copy(activeAudio = next)
    }

    fun cycleSubtitles() {
        val current = _playerState.value.activeSubtitles
        val next = when (current) {
            "Off" -> "English (CC)"
            "English (CC)" -> "Spanish"
            "Spanish" -> "French"
            else -> "Off"
        }
        _playerState.value = _playerState.value.copy(activeSubtitles = next)
    }

    fun release() {
        progressPollJob?.cancel()
        progressPollJob = null
        exoPlayer?.release()
        exoPlayer = null
        _playerState.value = TvPlayerState()
    }

    private fun startPollingProgress() {
        progressPollJob?.cancel()
        progressPollJob = coroutineScope.launch(Dispatchers.Main) {
            while (isActive) {
                exoPlayer?.let { player ->
                    _playerState.value = _playerState.value.copy(
                        currentPositionMs = player.currentPosition.coerceAtLeast(0L),
                        durationMs = player.duration.coerceAtLeast(0L)
                    )
                }
                delay(500)
            }
        }
    }
}
