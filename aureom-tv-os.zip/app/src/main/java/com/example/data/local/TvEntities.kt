package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "content_items")
data class ContentItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val tagline: String,
    val synopsis: String,
    val backdropUrl: String,
    val posterUrl: String,
    val durationMinutes: Int,
    val releaseYear: Int,
    val rating: String,
    val genre: String,
    val is4K: Boolean,
    val hdrFormat: String,
    val audioFormat: String,
    val streamUrl: String,
    val category: String,
    val resumePositionMs: Long = 0L,
    val lastWatchedTimestamp: Long = 0L
)

@Entity(tableName = "device_settings")
data class DeviceSettingsEntity(
    @PrimaryKey val id: String = "primary_settings",
    val pictureMode: String = "Cinema HDR",
    val memcLevel: String = "Cinematic (Low)",
    val audioOutput: String = "eARC Passthrough (Dolby Atmos)",
    val ambientModeEnabled: Boolean = true,
    val silentOtaUpdates: Boolean = true,
    val telemetryOptIn: Boolean = true,
    val isAospPrivilegedMode: Boolean = false
)

@Entity(tableName = "telemetry_logs")
data class TelemetryLogEntity(
    @PrimaryKey(autoGenerate = true) val logId: Long = 0L,
    val eventType: String,
    val timestamp: Long,
    val detailsJson: String
)
