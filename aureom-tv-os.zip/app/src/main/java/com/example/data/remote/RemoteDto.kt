package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class RemoteContentItem(
    @Json(name = "id") val id: String,
    @Json(name = "title") val title: String,
    @Json(name = "tagline") val tagline: String?,
    @Json(name = "synopsis") val synopsis: String?,
    @Json(name = "backdrop_url") val backdropUrl: String?,
    @Json(name = "poster_url") val posterUrl: String?,
    @Json(name = "duration_minutes") val durationMinutes: Int?,
    @Json(name = "release_year") val releaseYear: Int?,
    @Json(name = "rating") val rating: String?,
    @Json(name = "genre") val genre: String?,
    @Json(name = "is_4k") val is4K: Boolean?,
    @Json(name = "hdr_format") val hdrFormat: String?,
    @Json(name = "audio_format") val audioFormat: String?,
    @Json(name = "stream_url") val streamUrl: String?,
    @Json(name = "category") val category: String?
)

@JsonClass(generateAdapter = true)
data class RemoteCategoryGroup(
    @Json(name = "name") val name: String,
    @Json(name = "items") val items: List<RemoteContentItem>
)

@JsonClass(generateAdapter = true)
data class RemoteCatalogueResponse(
    @Json(name = "featured") val featured: RemoteContentItem,
    @Json(name = "categories") val categories: List<RemoteCategoryGroup>
)

@JsonClass(generateAdapter = true)
data class RemoteOemConfig(
    @Json(name = "config_id") val configId: String,
    @Json(name = "version") val version: String,
    @Json(name = "oem_brand") val oemBrand: String,
    @Json(name = "product_family") val productFamily: String,
    @Json(name = "accent_color") val accentColor: String,
    @Json(name = "feature_flags") val featureFlags: Map<String, Boolean>,
    @Json(name = "supported_inputs") val supportedInputs: List<String>
)

@JsonClass(generateAdapter = true)
data class RemoteUpdateCheckResponse(
    @Json(name = "update_available") val updateAvailable: Boolean,
    @Json(name = "version") val version: String,
    @Json(name = "type") val type: String,
    @Json(name = "payload_url") val payloadUrl: String,
    @Json(name = "sha256_hash") val sha256Hash: String,
    @Json(name = "signature") val signature: String,
    @Json(name = "release_notes") val releaseNotes: String,
    @Json(name = "critical_security_patch") val criticalSecurityPatch: Boolean
)
