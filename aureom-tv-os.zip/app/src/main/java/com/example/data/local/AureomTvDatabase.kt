package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ContentItemEntity::class,
        DeviceSettingsEntity::class,
        TelemetryLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AureomTvDatabase : RoomDatabase() {
    abstract fun tvDao(): TvDao

    companion object {
        @Volatile
        private var INSTANCE: AureomTvDatabase? = null

        fun getInstance(context: Context): AureomTvDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AureomTvDatabase::class.java,
                    "aureom_tv.db"
                ).fallbackToDestructiveMigration()
                 .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
