package com.example.data.remote

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface AureomTvApi {
    @GET("catalogue")
    suspend fun getCatalogue(): RemoteCatalogueResponse

    @GET("devices/{device_id}/configuration")
    suspend fun getConfiguration(@Path("device_id") deviceId: String): RemoteOemConfig

    @GET("updates/metadata")
    suspend fun checkUpdates(
        @Query("platform") platform: String = "android-tv",
        @Query("current_version") currentVersion: String,
        @Query("channel") channel: String = "stable"
    ): RemoteUpdateCheckResponse

    companion object {
        private const val BASE_URL = "http://10.0.2.2:8000/api/v1/" // Standard Android emulator loopback to host

        fun create(): AureomTvApi {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            val client = OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(AureomTvApi::class.java)
        }
    }
}
