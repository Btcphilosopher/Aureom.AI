package com.example.data.repository

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.view.WindowManager
import com.example.data.local.AureomTvDatabase
import com.example.data.local.ContentItemEntity
import com.example.data.local.DeviceSettingsEntity
import com.example.data.local.TelemetryLogEntity
import com.example.data.remote.AureomTvApi
import com.example.domain.model.AppInstallStatus
import com.example.domain.model.ContentItem
import com.example.domain.model.DeviceCapability
import com.example.domain.model.OemSystemSettings
import com.example.domain.model.TvAppItem
import com.example.domain.model.TvCategory
import com.example.domain.model.TvChannel
import com.example.domain.model.TvProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class AureomTvRepository(
    private val context: Context,
    private val db: AureomTvDatabase = AureomTvDatabase.getInstance(context),
    private val api: AureomTvApi = AureomTvApi.create()
) {
    private val dao = db.tvDao()

    val continueWatchingFlow: Flow<List<ContentItem>> = dao.getContinueWatchingFlow().map { entities ->
        entities.map { it.toDomain() }
    }.flowOn(Dispatchers.IO)

    val settingsFlow: Flow<OemSystemSettings> = dao.getSettingsFlow().map { entity ->
        entity?.toDomain() ?: OemSystemSettings()
    }.flowOn(Dispatchers.IO)

    suspend fun getInitialCategories(): List<TvCategory> = withContext(Dispatchers.IO) {
        val existing = dao.getAllContentFlow().firstOrNull() ?: emptyList()
        if (existing.isEmpty()) {
            // Seed bundled offline catalog
            val seedEntities = getBundledContent().map { it.toEntity() }
            dao.insertOrUpdateAll(seedEntities)
            return@withContext groupCategories(getBundledContent())
        }
        groupCategories(existing.map { it.toDomain() })
    }

    suspend fun syncWithBackend(): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = api.getCatalogue()
            val remoteItems = mutableListOf<ContentItem>()
            val featured = response.featured.toDomain()
            remoteItems.add(featured)
            response.categories.forEach { cat ->
                cat.items.forEach { item ->
                    remoteItems.add(item.toDomain(cat.name))
                }
            }
            dao.insertOrUpdateAll(remoteItems.map { it.toEntity() })
            logTelemetry("BACKEND_SYNC_SUCCESS", "Synced ${remoteItems.size} items from cloud")
            true
        } catch (e: Exception) {
            logTelemetry("BACKEND_SYNC_OFFLINE_FALLBACK", "Network unavailable: ${e.message}")
            false
        }
    }

    suspend fun updateResumePosition(contentId: String, positionMs: Long) = withContext(Dispatchers.IO) {
        dao.updateResumePosition(contentId, positionMs, System.currentTimeMillis())
    }

    suspend fun saveSettings(settings: OemSystemSettings) = withContext(Dispatchers.IO) {
        dao.saveSettings(settings.toEntity())
        logTelemetry("SETTINGS_UPDATED", "PictureMode: ${settings.pictureMode}, MEMC: ${settings.memcLevel}")
    }

    suspend fun logTelemetry(eventType: String, details: String) = withContext(Dispatchers.IO) {
        dao.insertTelemetryLog(
            TelemetryLogEntity(
                eventType = eventType,
                timestamp = System.currentTimeMillis(),
                detailsJson = details
            )
        )
    }

    fun getVerifiedAppRegistry(): List<TvAppItem> {
        return listOf(
            TvAppItem("app-1", "YouTube TV", AppInstallStatus.INSTALLED, "YT", "com.google.android.youtube.tv", badge = "4K"),
            TvAppItem("app-2", "Prime Video", AppInstallStatus.INSTALLED, "PV", "com.amazon.amazonvideo.livingroom", badge = "HDR10+"),
            TvAppItem("app-3", "Netflix", AppInstallStatus.INSTALLED, "NF", "com.netflix.ninja", badge = "Dolby Atmos"),
            TvAppItem("app-4", "Disney+", AppInstallStatus.AVAILABLE, "D+", badge = "Download"),
            TvAppItem("app-5", "Apple TV", AppInstallStatus.AVAILABLE, "ATV", badge = "Download"),
            TvAppItem("app-6", "Spotify TV", AppInstallStatus.AVAILABLE, "SP", badge = "Audio"),
            TvAppItem("in-1", "HDMI 1 (eARC Soundbar)", AppInstallStatus.EXTERNAL_DEVICE, "H1", inputPort = "HDMI-1"),
            TvAppItem("in-2", "HDMI 2 (PlayStation 5)", AppInstallStatus.EXTERNAL_DEVICE, "H2", inputPort = "HDMI-2"),
            TvAppItem("in-3", "HDMI 3 (4K Blu-ray)", AppInstallStatus.EXTERNAL_DEVICE, "H3", inputPort = "HDMI-3")
        )
    }

    fun getLiveChannels(): List<TvChannel> {
        return listOf(
            TvChannel(
                number = "01",
                name = "Aureom Global News",
                category = "News",
                currentShow = "Market Horizons & AI Brief",
                nextShow = "World Today with Marcus Vance",
                progressPercent = 65,
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            ),
            TvChannel(
                number = "02",
                name = "Ultra Cinema 4K",
                category = "Movies",
                currentShow = "The Orion Singularity",
                nextShow = "Nebula Protocol (Dolby Vision)",
                progressPercent = 40,
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
            ),
            TvChannel(
                number = "03",
                name = "Apex Velocity HD",
                category = "Sports",
                currentShow = "Night Sprint at Suzuka",
                nextShow = "Le Mans Prototype Preview",
                progressPercent = 82,
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
            ),
            TvChannel(
                number = "04",
                name = "Horizon Discovery",
                category = "Documentary",
                currentShow = "Challenger Deep 11,000m",
                nextShow = "Volcanic Trenches of Tonga",
                progressPercent = 25,
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
            )
        )
    }

    fun getProfiles(): List<TvProfile> {
        return listOf(
            TvProfile("p1", "Living Room", "#F59E0B", false, "en-atmos", false),
            TvProfile("p2", "Cinephile Night", "#D97706", false, "en-atmos", true),
            TvProfile("p3", "Family & Kids", "#10B981", true, "en", false)
        )
    }

    fun detectDeviceCapabilities(isPrivilegedMode: Boolean): DeviceCapability {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val refreshRate = display.refreshRate.toInt().coerceAtLeast(60)

        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val totalMb = (memInfo.totalMem / (1024 * 1024)).toInt()
        val availMb = (memInfo.availMem / (1024 * 1024)).toInt()
        val usedMb = (totalMb - availMb).coerceAtLeast(50)

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(network)
        val isConnected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val netType = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet Gigabit"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi 6 (802.11ax)"
            else -> "Offline / Local Mode"
        }

        return DeviceCapability(
            platformFamily = "Android TV / AOSP",
            platformVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            hardwareModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}",
            screenResolution = "3840x2160 UHD",
            refreshRateHz = refreshRate,
            isHdrSupported = true,
            supportedCodecs = listOf("AV1", "HEVC / H.265", "VP9", "AVC / H.264"),
            supportedAudio = listOf("Dolby Atmos", "Dolby Digital Plus", "PCM 5.1 / 7.1", "DTS:X"),
            isTunerAvailable = isPrivilegedMode, // Real Tuner HAL requires OEM AOSP privilege
            isOemPrivilegedMode = isPrivilegedMode,
            memoryUsageMb = usedMb,
            totalMemoryMb = totalMb,
            isNetworkConnected = isConnected,
            networkType = netType
        )
    }

    private fun groupCategories(items: List<ContentItem>): List<TvCategory> {
        val featured = items.filter { it.category == "Featured" }
        val cinema = items.filter { it.category == "4K HDR Cinema" }
        val docs = items.filter { it.category == "Documentaries" }
        return listOf(
            TvCategory("Featured & Originals", if (featured.isNotEmpty()) featured else items),
            TvCategory("4K HDR Cinema", if (cinema.isNotEmpty()) cinema else items),
            TvCategory("Documentaries & Culture", if (docs.isNotEmpty()) docs else items)
        )
    }

    private fun getBundledContent(): List<ContentItem> {
        return listOf(
            ContentItem(
                id = "aureom-ft-01",
                title = "Chronicles of Orion",
                tagline = "Beyond the frontier of known space",
                synopsis = "An interstellar expedition discovers an ancient broadcast relay transmitting signals from a human colony founded three thousand years in the future.",
                backdropUrl = "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=1920&q=80",
                posterUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&q=80",
                durationMinutes = 148,
                releaseYear = 2026,
                rating = "TV-MA",
                genre = "Sci-Fi Epic",
                is4K = true,
                hdrFormat = "Dolby Vision",
                audioFormat = "Dolby Atmos 7.1",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                category = "Featured"
            ),
            ContentItem(
                id = "aureom-ct-02",
                title = "Apex Velocity",
                tagline = "The engineering limits of speed",
                synopsis = "Inside the elite prototype racing garages where next-generation aerodynamicists test hypercars on night circuits.",
                backdropUrl = "https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=1920&q=80",
                posterUrl = "https://images.unsplash.com/photo-1542282088-72c9c27ed0cd?w=600&q=80",
                durationMinutes = 112,
                releaseYear = 2025,
                rating = "PG-13",
                genre = "Motorsport Documentary",
                is4K = true,
                hdrFormat = "HDR10+",
                audioFormat = "Dolby Atmos",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                category = "4K HDR Cinema"
            ),
            ContentItem(
                id = "aureom-ct-03",
                title = "Echoes of Kyoto",
                tagline = "Tradition in the shadow of neon",
                synopsis = "A meditative journey through historical tea gardens, hidden craftsmen studios, and the architectural symmetry of Kansai.",
                backdropUrl = "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1920&q=80",
                posterUrl = "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=600&q=80",
                durationMinutes = 94,
                releaseYear = 2026,
                rating = "G",
                genre = "Culture & Heritage",
                is4K = true,
                hdrFormat = "Dolby Vision",
                audioFormat = "PCM 5.1",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                category = "Documentaries"
            ),
            ContentItem(
                id = "aureom-ct-04",
                title = "Deep Meridian",
                tagline = "Descent into the abyssal trenches",
                synopsis = "Submersible explorations revealing hydrothermal vents and bioluminescent ecosystems 11,000 meters beneath the surface.",
                backdropUrl = "https://images.unsplash.com/photo-1682687220063-4742bd7fd538?w=1920&q=80",
                posterUrl = "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&q=80",
                durationMinutes = 105,
                releaseYear = 2026,
                rating = "PG",
                genre = "Natural Science",
                is4K = true,
                hdrFormat = "HDR10",
                audioFormat = "Dolby Digital 5.1",
                streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                category = "Documentaries"
            )
        )
    }

    private fun ContentItem.toEntity() = ContentItemEntity(
        id = id,
        title = title,
        tagline = tagline,
        synopsis = synopsis,
        backdropUrl = backdropUrl,
        posterUrl = posterUrl,
        durationMinutes = durationMinutes,
        releaseYear = releaseYear,
        rating = rating,
        genre = genre,
        is4K = is4K,
        hdrFormat = hdrFormat,
        audioFormat = audioFormat,
        streamUrl = streamUrl,
        category = category,
        resumePositionMs = resumePositionMs
    )

    private fun ContentItemEntity.toDomain() = ContentItem(
        id = id,
        title = title,
        tagline = tagline,
        synopsis = synopsis,
        backdropUrl = backdropUrl,
        posterUrl = posterUrl,
        durationMinutes = durationMinutes,
        releaseYear = releaseYear,
        rating = rating,
        genre = genre,
        is4K = is4K,
        hdrFormat = hdrFormat,
        audioFormat = audioFormat,
        streamUrl = streamUrl,
        category = category,
        resumePositionMs = resumePositionMs
    )

    private fun OemSystemSettings.toEntity() = DeviceSettingsEntity(
        pictureMode = pictureMode,
        memcLevel = memcLevel,
        audioOutput = audioOutput,
        ambientModeEnabled = ambientModeEnabled,
        silentOtaUpdates = silentOtaUpdates,
        telemetryOptIn = telemetryOptIn,
        isAospPrivilegedMode = isAospPrivilegedMode
    )

    private fun DeviceSettingsEntity.toDomain() = OemSystemSettings(
        pictureMode = pictureMode,
        memcLevel = memcLevel,
        audioOutput = audioOutput,
        ambientModeEnabled = ambientModeEnabled,
        silentOtaUpdates = silentOtaUpdates,
        telemetryOptIn = telemetryOptIn,
        isAospPrivilegedMode = isAospPrivilegedMode
    )

    private fun com.example.data.remote.RemoteContentItem.toDomain(fallbackCat: String = "Featured") = ContentItem(
        id = id,
        title = title,
        tagline = tagline ?: "",
        synopsis = synopsis ?: "",
        backdropUrl = backdropUrl ?: "",
        posterUrl = posterUrl ?: "",
        durationMinutes = durationMinutes ?: 120,
        releaseYear = releaseYear ?: 2026,
        rating = rating ?: "PG-13",
        genre = genre ?: "Sci-Fi",
        is4K = is4K ?: true,
        hdrFormat = hdrFormat ?: "Dolby Vision",
        audioFormat = audioFormat ?: "Dolby Atmos",
        streamUrl = streamUrl ?: "",
        category = category ?: fallbackCat
    )
}
