package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TvDao {
    @Query("SELECT * FROM content_items ORDER BY id ASC")
    fun getAllContentFlow(): Flow<List<ContentItemEntity>>

    @Query("SELECT * FROM content_items WHERE lastWatchedTimestamp > 0 ORDER BY lastWatchedTimestamp DESC LIMIT 10")
    fun getContinueWatchingFlow(): Flow<List<ContentItemEntity>>

    @Query("SELECT * FROM content_items WHERE id = :id LIMIT 1")
    suspend fun getContentById(id: String): ContentItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAll(items: List<ContentItemEntity>)

    @Query("UPDATE content_items SET resumePositionMs = :positionMs, lastWatchedTimestamp = :timestamp WHERE id = :id")
    suspend fun updateResumePosition(id: String, positionMs: Long, timestamp: Long)

    @Query("SELECT * FROM device_settings WHERE id = 'primary_settings' LIMIT 1")
    fun getSettingsFlow(): Flow<DeviceSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: DeviceSettingsEntity)

    @Insert
    suspend fun insertTelemetryLog(log: TelemetryLogEntity)

    @Query("SELECT * FROM telemetry_logs ORDER BY logId DESC LIMIT 20")
    fun getRecentTelemetryFlow(): Flow<List<TelemetryLogEntity>>
}
