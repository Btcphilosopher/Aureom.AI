package com.example.domain.model

data class ContentItem(
    val id: String,
    val title: String,
    val tagline: String = "",
    val synopsis: String = "",
    val backdropUrl: String = "",
    val posterUrl: String = "",
    val durationMinutes: Int = 120,
    val releaseYear: Int = 2026,
    val rating: String = "PG-13",
    val genre: String = "Sci-Fi",
    val is4K: Boolean = true,
    val hdrFormat: String = "Dolby Vision",
    val audioFormat: String = "Dolby Atmos 5.1",
    val streamUrl: String = "",
    val category: String = "Featured",
    val resumePositionMs: Long = 0L
)

data class TvCategory(
    val name: String,
    val items: List<ContentItem>
)

enum class AppInstallStatus {
    INSTALLED,
    AVAILABLE,
    SUBSCRIPTION_REQUIRED,
    UNSUPPORTED,
    EXTERNAL_DEVICE
}

data class TvAppItem(
    val id: String,
    val name: String,
    val status: AppInstallStatus,
    val iconSymbol: String,
    val packageName: String? = null,
    val inputPort: String? = null,
    val badge: String? = null
)

data class TvChannel(
    val number: String,
    val name: String,
    val category: String,
    val currentShow: String,
    val nextShow: String,
    val progressPercent: Int,
    val streamUrl: String
)

data class DeviceCapability(
    val platformFamily: String,
    val platformVersion: String,
    val hardwareModel: String,
    val screenResolution: String,
    val refreshRateHz: Int,
    val isHdrSupported: Boolean,
    val supportedCodecs: List<String>,
    val supportedAudio: List<String>,
    val isTunerAvailable: Boolean,
    val isOemPrivilegedMode: Boolean,
    val memoryUsageMb: Int,
    val totalMemoryMb: Int,
    val isNetworkConnected: Boolean,
    val networkType: String
)

data class TvProfile(
    val id: String,
    val name: String,
    val avatarColorHex: String,
    val isKid: Boolean,
    val preferredAudio: String,
    val subtitlesEnabled: Boolean
)

data class OemSystemSettings(
    val oemBrand: String = "Aureom",
    val productFamily: String = "Horizon OLED 4K",
    val accentColorHex: String = "#F59E0B",
    val pictureMode: String = "Cinema HDR", // Cinema, Game, Standard, Vivid, Calibrated
    val memcLevel: String = "Cinematic (Low)", // Off, Low, Medium, High
    val audioOutput: String = "eARC Passthrough (Dolby Atmos)", // Internal, eARC, Optical
    val ambientModeEnabled: Boolean = true,
    val silentOtaUpdates: Boolean = true,
    val telemetryOptIn: Boolean = true,
    val isAospPrivilegedMode: Boolean = false // Toggle between User App & OEM System Mode
)
