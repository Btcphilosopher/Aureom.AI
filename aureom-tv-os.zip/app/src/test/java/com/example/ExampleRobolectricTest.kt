package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AureomTvDatabase
import com.example.data.local.ContentItemEntity
import com.example.data.local.DeviceSettingsEntity
import com.example.data.repository.AureomTvRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches Aureom TV`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aureom TV", appName)
    }

    @Test
    fun `room database stores and retrieves content entity`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AureomTvDatabase.getInstance(context)
        val dao = db.tvDao()

        val item = ContentItemEntity(
            id = "test-item-1",
            title = "Test Cosmic Drift",
            tagline = "Speed of light",
            synopsis = "A journey into space",
            backdropUrl = "http://example.com/bd.jpg",
            posterUrl = "http://example.com/poster.jpg",
            durationMinutes = 110,
            releaseYear = 2026,
            rating = "PG-13",
            genre = "Sci-Fi",
            is4K = true,
            hdrFormat = "Dolby Vision",
            audioFormat = "Dolby Atmos",
            streamUrl = "http://example.com/stream.mp4",
            category = "Featured"
        )

        dao.insertOrUpdateAll(listOf(item))
        val retrieved = dao.getContentById("test-item-1")

        assertNotNull(retrieved)
        assertEquals("Test Cosmic Drift", retrieved?.title)
        assertTrue(retrieved?.is4K == true)
    }

    @Test
    fun `repository provides bundled categories and detects capabilities`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = AureomTvRepository(context)

        val categories = repository.getInitialCategories()
        assertTrue("Categories must not be empty", categories.isNotEmpty())
        assertTrue("Must include featured item", categories.first().items.isNotEmpty())

        val caps = repository.detectDeviceCapabilities(false)
        assertEquals("Android TV / AOSP", caps.platformFamily)
        assertTrue(caps.supportedCodecs.contains("AV1"))
    }
}
