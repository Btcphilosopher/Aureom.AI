package com.example

import com.example.domain.model.AppInstallStatus
import com.example.domain.model.ContentItem
import com.example.domain.model.TvAppItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun contentItem_defaults_areValid() {
        val item = ContentItem(
            id = "c-101",
            title = "Aureom Reference Showcase"
        )
        assertEquals("c-101", item.id)
        assertTrue(item.is4K)
        assertEquals("Dolby Vision", item.hdrFormat)
    }

    @Test
    fun tvAppRegistry_handlesExternalDevices() {
        val app = TvAppItem(
            id = "hdmi-1",
            name = "HDMI 1 (eARC)",
            status = AppInstallStatus.EXTERNAL_DEVICE,
            iconSymbol = "H1",
            inputPort = "PORT_1"
        )
        assertEquals(AppInstallStatus.EXTERNAL_DEVICE, app.status)
        assertEquals("PORT_1", app.inputPort)
    }
}
