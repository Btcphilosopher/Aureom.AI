package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.simulator.LiveGameSimulator
import com.example.data.simulator.LiveNotification
import com.example.ui.dialogs.AskSportsDialog
import com.example.ui.dialogs.DevControlRoomDialog
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.flow.collectLatest

enum class MainNavDestination(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    HOME("Home", Icons.Default.Home, "nav_home"),
    LIVE("Live 4K", Icons.Default.PlayCircle, "nav_live"),
    SCORES("Scores", Icons.Default.FormatListNumbered, "nav_scores"),
    HUBS("Hubs", Icons.Default.Public, "nav_hubs"),
    MY_SPORTS("My Sports", Icons.Default.Star, "nav_my_sports"),
    PROFILE("Profile", Icons.Default.Person, "nav_profile")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainSportsApp()
            }
        }
    }
}

@Composable
fun MainSportsApp() {
    val games by LiveGameSimulator.games.collectAsState()
    val news by LiveGameSimulator.news.collectAsState()

    var currentTab by remember { mutableStateOf(MainNavDestination.HOME) }

    // Screen State
    var activePlayerGame by remember { mutableStateOf<Game?>(null) }
    var isMultiviewOpen by remember { mutableStateOf(false) }
    var selectedTeam by remember { mutableStateOf<Team?>(null) }
    var selectedPlayer by remember { mutableStateOf<Player?>(null) }
    var selectedShow by remember { mutableStateOf<OriginalShow?>(null) }
    var selectedNewsStory by remember { mutableStateOf<NewsStory?>(null) }
    var isSearchOpen by remember { mutableStateOf(false) }

    // Dialogs
    var askSportsGameContext by remember { mutableStateOf<Game?>(null) }
    var showAskSportsDialog by remember { mutableStateOf(false) }
    var showDevControlRoom by remember { mutableStateOf(false) }

    // Live Notification Toast Banner
    var activeToast by remember { mutableStateOf<LiveNotification?>(null) }

    LaunchedEffect(Unit) {
        LiveGameSimulator.notifications.collectLatest { notification ->
            activeToast = notification
            kotlinx.coroutines.delay(4000L)
            if (activeToast?.id == notification.id) {
                activeToast = null
            }
        }
    }

    // Handle System Back Press
    BackHandler(
        enabled = activePlayerGame != null || isMultiviewOpen || selectedTeam != null ||
                selectedPlayer != null || selectedShow != null || selectedNewsStory != null || isSearchOpen
    ) {
        when {
            activePlayerGame != null -> activePlayerGame = null
            isMultiviewOpen -> isMultiviewOpen = false
            selectedTeam != null -> selectedTeam = null
            selectedPlayer != null -> selectedPlayer = null
            selectedShow != null -> selectedShow = null
            selectedNewsStory != null -> selectedNewsStory = null
            isSearchOpen -> isSearchOpen = false
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack),
        bottomBar = {
            // Hide bottom bar when in immersive player or multiview
            if (activePlayerGame == null && !isMultiviewOpen) {
                LuxuryBottomNavigation(
                    currentTab = currentTab,
                    onSelectTab = { tab ->
                        // Clear subviews when switching root tabs
                        selectedTeam = null
                        selectedPlayer = null
                        selectedShow = null
                        selectedNewsStory = null
                        isSearchOpen = false
                        currentTab = tab
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CanvasPureBlack)
        ) {
            // Main View Routing
            when {
                // 1. Live 4K Player View
                activePlayerGame != null -> {
                    val gameToPlay = games.find { it.id == activePlayerGame?.id } ?: activePlayerGame!!
                    LivePlayerScreen(
                        game = gameToPlay,
                        onBack = { activePlayerGame = null },
                        onOpenMultiview = {
                            activePlayerGame = null
                            isMultiviewOpen = true
                        },
                        onAskGameAi = { g ->
                            askSportsGameContext = g
                            showAskSportsDialog = true
                        }
                    )
                }

                // 2. Multiview 4K Quad Grid
                isMultiviewOpen -> {
                    MultiviewScreen(
                        allGames = games,
                        onBack = { isMultiviewOpen = false },
                        onExpandGame = { g ->
                            isMultiviewOpen = false
                            activePlayerGame = g
                        }
                    )
                }

                // 3. Team Detail Page
                selectedTeam != null -> {
                    TeamDetailScreen(
                        team = selectedTeam!!,
                        onBack = { selectedTeam = null },
                        onSelectPlayer = { p -> selectedPlayer = p }
                    )
                }

                // 4. Player Detail Page
                selectedPlayer != null -> {
                    PlayerDetailScreen(
                        player = selectedPlayer!!,
                        onBack = { selectedPlayer = null }
                    )
                }

                // 5. Original Show Detail
                selectedShow != null -> {
                    ShowDetailScreen(
                        show = selectedShow!!,
                        onBack = { selectedShow = null }
                    )
                }

                // 6. News Story Reader
                selectedNewsStory != null -> {
                    NewsScreen(
                        news = news,
                        selectedNews = selectedNewsStory,
                        onSelectStory = { selectedNewsStory = it },
                        onBack = { selectedNewsStory = null }
                    )
                }

                // 7. Universal Search
                isSearchOpen -> {
                    SearchScreen(
                        onSelectGame = { g ->
                            isSearchOpen = false
                            activePlayerGame = g
                        },
                        onSelectTeam = { t ->
                            isSearchOpen = false
                            selectedTeam = t
                        },
                        onSelectPlayer = { p ->
                            isSearchOpen = false
                            selectedPlayer = p
                        },
                        onSelectShow = { s ->
                            isSearchOpen = false
                            selectedShow = s
                        }
                    )
                }

                // 8. Primary Tabs
                else -> {
                    when (currentTab) {
                        MainNavDestination.HOME -> {
                            HomeScreen(
                                games = games,
                                news = news,
                                onSelectGame = { g -> activePlayerGame = g },
                                onOpenMultiview = { isMultiviewOpen = true },
                                onOpenAskSports = { g ->
                                    askSportsGameContext = g
                                    showAskSportsDialog = true
                                },
                                onOpenDevControl = { showDevControlRoom = true },
                                onSelectTeam = { t -> selectedTeam = t },
                                onSelectPlayer = { p -> selectedPlayer = p },
                                onSelectShow = { s -> selectedShow = s },
                                onSelectNews = { n -> selectedNewsStory = n }
                            )
                        }
                        MainNavDestination.LIVE -> {
                            LiveScreen(
                                games = games,
                                onSelectGame = { g -> activePlayerGame = g },
                                onOpenMultiview = { isMultiviewOpen = true }
                            )
                        }
                        MainNavDestination.SCORES -> {
                            ScoresScreen(
                                games = games,
                                onSelectGame = { g -> activePlayerGame = g }
                            )
                        }
                        MainNavDestination.HUBS -> {
                            SportsHubScreen(
                                onSelectTeam = { t -> selectedTeam = t },
                                onSelectPlayer = { p -> selectedPlayer = p },
                                onSelectGame = { g -> activePlayerGame = g }
                            )
                        }
                        MainNavDestination.MY_SPORTS -> {
                            MySportsScreen(
                                onSelectTeam = { t -> selectedTeam = t },
                                onSelectPlayer = { p -> selectedPlayer = p }
                            )
                        }
                        MainNavDestination.PROFILE -> {
                            ProfileScreen(
                                onOpenDevControl = { showDevControlRoom = true }
                            )
                        }
                    }
                }
            }

            // Top Real-time Event Toast Banner
            AnimatedVisibility(
                visible = activeToast != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp)
            ) {
                activeToast?.let { toast ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFFFEF7FF))
                            .border(1.dp, Color(0xFFE7E0EC), RoundedCornerShape(20.dp))
                            .clickable {
                                if (toast.gameId != null) {
                                    val target = games.find { it.id == toast.gameId }
                                    if (target != null) activePlayerGame = target
                                }
                                activeToast = null
                            }
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFFDDE5D7)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(NeonSportsRed)
                                    )
                                }

                                Column {
                                    Text(
                                        text = toast.title.uppercase(),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            color = NeonAmberGold,
                                            letterSpacing = 0.5.sp
                                        )
                                    )
                                    Text(
                                        text = toast.message,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextWhitePrimary
                                        ),
                                        maxLines = 1
                                    )
                                }
                            }

                            IconButton(
                                onClick = { activeToast = null },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = TextSilverSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // AI Sports Assistant Dialog
    if (showAskSportsDialog) {
        AskSportsDialog(
            contextGame = askSportsGameContext,
            onDismiss = {
                showAskSportsDialog = false
                askSportsGameContext = null
            }
        )
    }

    // Developer Control Room Dialog
    if (showDevControlRoom) {
        DevControlRoomDialog(
            games = games,
            onDismiss = { showDevControlRoom = false }
        )
    }
}

@Composable
private fun LuxuryBottomNavigation(
    currentTab: MainNavDestination,
    onSelectTab: (MainNavDestination) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF3EDF7))
            .border(
                1.dp,
                Color(0xFFE7E0EC),
                RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            )
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MainNavDestination.values().forEach { destination ->
                val isSelected = destination == currentTab
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onSelectTab(destination) }
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                        .testTag(destination.testTag),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) Color(0xFFDDE5D7) else Color.Transparent)
                            .padding(horizontal = 14.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = destination.icon,
                            contentDescription = destination.title,
                            tint = if (isSelected) Color(0xFF1D192B) else Color(0xFF49454F).copy(alpha = 0.7f),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Text(
                        text = destination.title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 11.sp,
                            color = if (isSelected) Color(0xFF1D192B) else Color(0xFF49454F).copy(alpha = 0.7f)
                        )
                    )
                }
            }
        }
    }
}
