package com.example.data.simulator

import com.example.data.model.*
import com.example.data.repository.SportsRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

data class LiveNotification(
    val id: String,
    val title: String,
    val message: String,
    val type: String = "SCORE", // "SCORE", "BREAKING", "GAME_START", "HEAT"
    val timestamp: String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()),
    val gameId: String? = null
)

object LiveGameSimulator {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val _games = MutableStateFlow<List<Game>>(SportsRepository.createInitialGames())
    val games = _games.asStateFlow()

    private val _news = MutableStateFlow<List<NewsStory>>(SportsRepository.newsStories)
    val news = _news.asStateFlow()

    private val _notifications = MutableSharedFlow<LiveNotification>(extraBufferCapacity = 64)
    val notifications = _notifications.asSharedFlow()

    private val _isSimulationRunning = MutableStateFlow(true)
    val isSimulationRunning = _isSimulationRunning.asStateFlow()

    private val _speedMultiplier = MutableStateFlow(1) // 1x, 2x, 5x, 10x
    val speedMultiplier = _speedMultiplier.asStateFlow()

    private var simulationJob: Job? = null

    init {
        startSimulationLoop()
    }

    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            while (isActive) {
                val delayMs = (2500L / _speedMultiplier.value.coerceAtLeast(1)).coerceAtLeast(300L)
                delay(delayMs)

                if (!_isSimulationRunning.value) continue

                tickSimulatedGames()
            }
        }
    }

    private suspend fun tickSimulatedGames() {
        val currentGames = _games.value.toMutableList()
        val updatedGames = currentGames.map { game ->
            if (game.status != GameStatus.LIVE) return@map game

            when (game.sport) {
                SportType.BASKETBALL -> tickBasketballGame(game)
                SportType.FOOTBALL -> tickFootballGame(game)
                SportType.SOCCER -> tickSoccerGame(game)
                SportType.RACING -> tickRacingGame(game)
                else -> game
            }
        }
        _games.value = updatedGames
    }

    private suspend fun tickBasketballGame(game: Game): Game {
        // Parse clock "02:44"
        val parts = game.clock.split(":")
        var minutes = parts.getOrNull(0)?.toIntOrNull() ?: 2
        var seconds = parts.getOrNull(1)?.toIntOrNull() ?: 44

        seconds -= (2 * _speedMultiplier.value).coerceAtLeast(1)
        if (seconds < 0) {
            minutes -= 1
            seconds = 59
        }

        if (minutes < 0) {
            minutes = 0
            seconds = 0
        }

        val newClock = String.format(Locale.US, "%02d:%02d", minutes, seconds)
        var homeScore = game.homeScore
        var awayScore = game.awayScore
        var possession = game.possession
        val newPlays = game.playByPlay.toMutableList()
        val newKeyPlays = game.keyPlays.toMutableList()
        var newShotClock = (game.shotClock?.toIntOrNull() ?: 24) - 2
        if (newShotClock <= 0) newShotClock = 24

        // Random scoring event ~25% chance
        if (Random.nextFloat() < 0.28f && (minutes > 0 || seconds > 0)) {
            val isHomeScoring = Random.nextBoolean()
            val pts = if (Random.nextFloat() < 0.40f) 3 else 2
            val scorer = if (isHomeScoring) "Jack Carter" else "Marcus Vance"
            val teamCode = if (isHomeScoring) game.homeTeam.shortCode else game.awayTeam.shortCode

            if (isHomeScoring) homeScore += pts else awayScore += pts
            possession = if (isHomeScoring) game.awayTeam.shortCode else game.homeTeam.shortCode
            newShotClock = 24

            val actionDesc = if (pts == 3) {
                "$scorer drains a clutch step-back 3-pointer from 27 feet!"
            } else {
                "$scorer drives through the lane with a baseline layup."
            }

            val playEvent = GamePlayEvent(
                id = "ev_${System.currentTimeMillis()}_${Random.nextInt(1000)}",
                clock = newClock,
                period = game.period,
                title = if (pts == 3) "$scorer 3PT Jumper" else "$scorer 2PT Layup",
                description = actionDesc,
                teamCode = teamCode,
                isScore = true,
                isKeyPlay = (pts == 3 || Math.abs(homeScore - awayScore) <= 3)
            )
            newPlays.add(0, playEvent)

            if (playEvent.isKeyPlay) {
                newKeyPlays.add(0, KeyPlay(
                    id = "kp_${System.currentTimeMillis()}",
                    timeString = newClock,
                    quarter = game.period,
                    title = playEvent.title,
                    description = playEvent.description,
                    scoreSnapshot = "$homeScore-$awayScore",
                    durationSec = 15
                ))

                _notifications.emit(LiveNotification(
                    id = UUID.randomUUID().toString(),
                    title = "${game.homeTeam.shortCode} vs ${game.awayTeam.shortCode} • $newClock",
                    message = "${playEvent.title} ($homeScore - $awayScore)",
                    type = "SCORE",
                    gameId = game.id
                ))
            }
        }

        // Dynamically compute Game Heat (closeness + time remaining)
        val scoreDiff = Math.abs(homeScore - awayScore)
        val heat = (100 - (scoreDiff * 4) + (if (minutes <= 3) 15 else 5)).coerceIn(60, 99)

        return game.copy(
            clock = newClock,
            homeScore = homeScore,
            awayScore = awayScore,
            possession = possession,
            shotClock = newShotClock.toString(),
            heatScore = heat,
            playByPlay = newPlays.take(30),
            keyPlays = newKeyPlays.take(10)
        )
    }

    private suspend fun tickFootballGame(game: Game): Game {
        val parts = game.clock.split(":")
        var minutes = parts.getOrNull(0)?.toIntOrNull() ?: 4
        var seconds = parts.getOrNull(1)?.toIntOrNull() ?: 18

        seconds -= (3 * _speedMultiplier.value).coerceAtLeast(1)
        if (seconds < 0) {
            minutes -= 1
            seconds = 59
        }
        if (minutes < 0) { minutes = 0; seconds = 0 }
        val newClock = String.format(Locale.US, "%02d:%02d", minutes, seconds)

        var homeScore = game.homeScore
        var awayScore = game.awayScore
        val newPlays = game.playByPlay.toMutableList()

        if (Random.nextFloat() < 0.12f && (minutes > 0 || seconds > 0)) {
            val isHome = Random.nextBoolean()
            val isTouchdown = Random.nextBoolean()
            val pts = if (isTouchdown) 7 else 3
            if (isHome) homeScore += pts else awayScore += pts
            val team = if (isHome) game.homeTeam else game.awayTeam

            val eventTitle = if (isTouchdown) "TOUCHDOWN ${team.shortCode}!" else "FIELD GOAL ${team.shortCode} (46 yds)"
            val eventDesc = if (isTouchdown) "Sensational 34-yard touchdown reception in the back of the end zone!" else "Kicker splits the uprights cleanly."

            newPlays.add(0, GamePlayEvent(
                id = "ev_f_${System.currentTimeMillis()}",
                clock = newClock,
                period = game.period,
                title = eventTitle,
                description = eventDesc,
                teamCode = team.shortCode,
                isScore = true,
                isKeyPlay = true
            ))

            _notifications.emit(LiveNotification(
                id = UUID.randomUUID().toString(),
                title = "TOUCHDOWN ALERT • ${team.name}",
                message = "$eventTitle | Score: $homeScore - $awayScore",
                type = "SCORE",
                gameId = game.id
            ))
        }

        return game.copy(
            clock = newClock,
            homeScore = homeScore,
            awayScore = awayScore,
            playByPlay = newPlays.take(30)
        )
    }

    private suspend fun tickSoccerGame(game: Game): Game {
        val currentMin = game.soccerMinute?.replace("'", "")?.toIntOrNull() ?: 78
        val nextMin = (currentMin + 1).coerceAtMost(90)
        val soccerMinuteFormatted = "$nextMin'"

        var homeScore = game.homeScore
        var awayScore = game.awayScore
        val newPlays = game.playByPlay.toMutableList()

        if (Random.nextFloat() < 0.08f && nextMin < 90) {
            val isHome = Random.nextBoolean()
            if (isHome) homeScore += 1 else awayScore += 1
            val team = if (isHome) game.homeTeam else game.awayTeam

            newPlays.add(0, GamePlayEvent(
                id = "ev_s_${System.currentTimeMillis()}",
                clock = soccerMinuteFormatted,
                period = game.period,
                title = "GOAL! ${team.name}",
                description = "Spectacular volley from outside the penalty box!",
                teamCode = team.shortCode,
                isScore = true,
                isKeyPlay = true
            ))

            _notifications.emit(LiveNotification(
                id = UUID.randomUUID().toString(),
                title = "GOAL ALERT • ${team.name}",
                message = "Goal at $soccerMinuteFormatted! Score: $homeScore - $awayScore",
                type = "SCORE",
                gameId = game.id
            ))
        }

        return game.copy(
            clock = soccerMinuteFormatted,
            soccerMinute = soccerMinuteFormatted,
            homeScore = homeScore,
            awayScore = awayScore,
            playByPlay = newPlays.take(30)
        )
    }

    private fun tickRacingGame(game: Game): Game {
        val lapStr = game.racingLap ?: "48/57"
        val currentLap = lapStr.split("/").getOrNull(0)?.toIntOrNull() ?: 48
        val totalLaps = 57
        val nextLap = if (currentLap < totalLaps) currentLap + 1 else totalLaps
        val newLapFormatted = "$nextLap/$totalLaps"

        return game.copy(
            clock = "Lap $nextLap",
            racingLap = newLapFormatted,
            period = "Lap $newLapFormatted"
        )
    }

    // --- DEVELOPER CONTROL ROOM ACTIONS ---

    fun triggerScoreManual(gameId: String, isHome: Boolean, points: Int) {
        scope.launch {
            val currentGames = _games.value.toMutableList()
            val idx = currentGames.indexOfFirst { it.id == gameId }
            if (idx != -1) {
                val game = currentGames[idx]
                val newHome = if (isHome) game.homeScore + points else game.homeScore
                val newAway = if (!isHome) game.awayScore + points else game.awayScore
                val scoringTeam = if (isHome) game.homeTeam else game.awayTeam

                val newPlays = game.playByPlay.toMutableList()
                newPlays.add(0, GamePlayEvent(
                    id = "ev_man_${System.currentTimeMillis()}",
                    clock = game.clock,
                    period = game.period,
                    title = "Manual Score: +$points pts by ${scoringTeam.shortCode}",
                    description = "Triggered via Dev Broadcast Control Room",
                    teamCode = scoringTeam.shortCode,
                    isScore = true,
                    isKeyPlay = true
                ))

                currentGames[idx] = game.copy(
                    homeScore = newHome,
                    awayScore = newAway,
                    playByPlay = newPlays
                )
                _games.value = currentGames

                _notifications.emit(LiveNotification(
                    id = UUID.randomUUID().toString(),
                    title = "BROADCAST CONTROL: SCORE EVENT",
                    message = "${scoringTeam.shortCode} +$points pts ($newHome - $newAway)",
                    type = "SCORE",
                    gameId = gameId
                ))
            }
        }
    }

    fun advancePeriodManual(gameId: String) {
        val currentGames = _games.value.toMutableList()
        val idx = currentGames.indexOfFirst { it.id == gameId }
        if (idx != -1) {
            val game = currentGames[idx]
            val nextPeriod = when (game.period) {
                "Q1" -> "Q2"
                "Q2" -> "HALFTIME"
                "HALFTIME" -> "Q3"
                "Q3" -> "Q4"
                "Q4" -> "FINAL"
                "1st Half" -> "HALFTIME"
                "HALFTIME" -> "2nd Half"
                "2nd Half" -> "FINAL"
                else -> "FINAL"
            }
            val newClock = if (nextPeriod == "FINAL") "00:00" else "12:00"
            val newStatus = if (nextPeriod == "FINAL") GameStatus.FINAL else GameStatus.LIVE

            currentGames[idx] = game.copy(
                period = nextPeriod,
                clock = newClock,
                status = newStatus
            )
            _games.value = currentGames
        }
    }

    fun injectPlayEvent(gameId: String, title: String, description: String, teamCode: String, isScore: Boolean) {
        scope.launch {
            val currentGames = _games.value.toMutableList()
            val idx = currentGames.indexOfFirst { it.id == gameId }
            if (idx != -1) {
                val game = currentGames[idx]
                val newPlays = game.playByPlay.toMutableList()
                val event = GamePlayEvent(
                    id = "ev_inj_${System.currentTimeMillis()}",
                    clock = game.clock,
                    period = game.period,
                    title = title,
                    description = description,
                    teamCode = teamCode,
                    isScore = isScore,
                    isKeyPlay = true
                )
                newPlays.add(0, event)
                currentGames[idx] = game.copy(playByPlay = newPlays)
                _games.value = currentGames

                _notifications.emit(LiveNotification(
                    id = UUID.randomUUID().toString(),
                    title = "KEY EVENT: $title",
                    message = description,
                    type = "HEAT",
                    gameId = gameId
                ))
            }
        }
    }

    fun triggerBreakingNews(headline: String, summary: String) {
        scope.launch {
            val currentNews = _news.value.toMutableList()
            val breaking = NewsStory(
                id = "nw_brk_${System.currentTimeMillis()}",
                headline = headline,
                summary = summary,
                content = summary,
                category = "BREAKING ALERT",
                readTimeMin = 2,
                timestamp = "Just Now",
                isBreaking = true,
                author = "ESPN+ Control Room"
            )
            currentNews.add(0, breaking)
            _news.value = currentNews

            _notifications.emit(LiveNotification(
                id = UUID.randomUUID().toString(),
                title = "🚨 BREAKING NEWS ALERT",
                message = headline,
                type = "BREAKING"
            ))
        }
    }

    fun toggleSimulationPause() {
        _isSimulationRunning.value = !_isSimulationRunning.value
    }

    fun setSpeedMultiplier(multiplier: Int) {
        _speedMultiplier.value = multiplier
        startSimulationLoop()
    }

    fun resetGames() {
        _games.value = SportsRepository.createInitialGames()
    }
}
