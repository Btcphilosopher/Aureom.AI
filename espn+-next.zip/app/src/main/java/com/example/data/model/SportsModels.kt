package com.example.data.model

enum class SportType(val displayName: String, val iconLabel: String) {
    BASKETBALL("Basketball", "🏀"),
    FOOTBALL("Football", "🏈"),
    SOCCER("Soccer", "⚽"),
    TENNIS("Tennis", "🎾"),
    RACING("Racing", "🏎️"),
    BASEBALL("Baseball", "⚾"),
    HOCKEY("Hockey", "🏒"),
    GOLF("Golf", "⛳"),
    MMA("Combat Sports", "🥊")
}

data class League(
    val id: String,
    val name: String,
    val shortName: String,
    val sport: SportType,
    val colorHex: Long,
    val season: String = "2026-2027",
    val conferenceNames: List<String> = listOf("Eastern", "Western")
)

data class Team(
    val id: String,
    val name: String,
    val city: String,
    val nickname: String,
    val shortCode: String,
    val leagueId: String,
    val sport: SportType,
    val primaryColor: Long,
    val secondaryColor: Long,
    val winRecord: Int,
    val lossRecord: Int,
    val standingRank: Int,
    val conference: String,
    val venueName: String,
    val streak: String = "W3",
    val l10: String = "8-2"
) {
    val recordFormatted: String get() = "$winRecord-$lossRecord"
}

data class GameLog(
    val date: String,
    val opponent: String,
    val result: String,
    val pts: Int,
    val reb: Int,
    val ast: Int,
    val minutes: String,
    val fgPct: String
)

data class Player(
    val id: String,
    val name: String,
    val teamId: String,
    val teamCode: String,
    val sport: SportType,
    val position: String,
    val jerseyNumber: String,
    val height: String,
    val weight: String,
    val age: Int,
    val seasonStats: Map<String, String>,
    val careerStats: Map<String, String>,
    val recentGameLogs: List<GameLog> = emptyList(),
    val isAllStar: Boolean = true
)

enum class GameStatus {
    SCHEDULED,
    PREGAME,
    LIVE,
    HALFTIME,
    FINAL,
    POSTPONED
}

data class GamePlayEvent(
    val id: String,
    val clock: String,
    val period: String,
    val title: String,
    val description: String,
    val teamCode: String,
    val isScore: Boolean = false,
    val isKeyPlay: Boolean = false,
    val videoTimestampSec: Int = 0
)

data class KeyPlay(
    val id: String,
    val timeString: String,
    val quarter: String,
    val title: String,
    val description: String,
    val scoreSnapshot: String,
    val durationSec: Int = 15
)

data class TeamGameStats(
    val fieldGoalPct: String = "48.2%",
    val threePtPct: String = "39.1%",
    val freeThrowPct: String = "82.5%",
    val rebounds: Int = 42,
    val assists: Int = 26,
    val turnovers: Int = 9,
    val fouls: Int = 14,
    val fastBreakPts: Int = 18,
    val ptsInPaint: Int = 48,
    // Sport specific metrics
    val passingYards: Int = 284,
    val rushingYards: Int = 132,
    val thirdDownEff: String = "7/12",
    val shotsOnTarget: Int = 7,
    val xG: String = "2.14",
    val possessionPct: String = "54%"
)

data class Game(
    val id: String,
    val sport: SportType,
    val leagueId: String,
    val homeTeam: Team,
    val awayTeam: Team,
    val homeScore: Int,
    val awayScore: Int,
    val status: GameStatus,
    val period: String,
    val clock: String,
    val venue: String,
    val broadcastNetwork: String = "ESPN+ ULTRA 4K",
    val qualityTag: String = "4K HDR • 60 FPS",
    val heatScore: Int = 85, // 0 - 100
    val isFeatured: Boolean = false,
    val headline: String = "",
    val possession: String? = "BOS",
    val downDistance: String? = null,
    val shotClock: String? = "14",
    val tennisSets: List<Pair<Int, Int>>? = null,
    val tennisPoints: String? = null,
    val soccerMinute: String? = null,
    val racingLap: String? = null,
    val playByPlay: List<GamePlayEvent> = emptyList(),
    val keyPlays: List<KeyPlay> = emptyList(),
    val homeStats: TeamGameStats = TeamGameStats(),
    val awayStats: TeamGameStats = TeamGameStats(),
    val isStreamActive: Boolean = true,
    val startTimeFormatted: String = "LIVE NOW",
    val audioFeeds: List<String> = listOf("Main Stadium Feed", "Home Radio Network", "Away Broadcast", "Court FX Only")
)

data class NewsStory(
    val id: String,
    val headline: String,
    val summary: String,
    val content: String,
    val category: String,
    val readTimeMin: Int,
    val timestamp: String,
    val isBreaking: Boolean = false,
    val relatedTeamId: String? = null,
    val relatedSport: SportType = SportType.BASKETBALL,
    val videoDuration: String? = null,
    val author: String = "ESPN+ Senior Insider"
)

data class ShowEpisode(
    val id: String,
    val episodeNumber: Int,
    val title: String,
    val duration: String,
    val description: String
)

data class OriginalShow(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val totalEpisodes: Int,
    val category: String,
    val rating: String = "TV-MA",
    val duration: String = "6 Episodes",
    val episodes: List<ShowEpisode> = emptyList()
)

data class FantasyPlayer(
    val id: String,
    val playerId: String,
    val playerName: String,
    val teamCode: String,
    val position: String,
    val fantasyPoints: Double,
    val projectedPoints: Double,
    val status: String = "ACTIVE",
    val recentAction: String = "3PT Made (+3.0 pts)"
)

data class UserProfile(
    val userId: String = "usr_99812",
    val username: String = "ApexFan2026",
    val email: String = "tom@ahyx.org",
    val subscriptionPlan: String = "SPORTS UNLIMITED (4K MULTIVIEW)",
    val favoriteTeamIds: Set<String> = setOf("tm_bos", "tm_ny", "tm_sf"),
    val favoriteLeagueIds: Set<String> = setOf("lg_pbl", "lg_nfl", "lg_prem"),
    val favoriteSportTypes: Set<SportType> = setOf(SportType.BASKETBALL, SportType.FOOTBALL, SportType.RACING, SportType.SOCCER),
    val watchlistGameIds: Set<String> = setOf("gm_101", "gm_103"),
    val breakingNewsAlerts: Boolean = true,
    val closeGameAlerts: Boolean = true,
    val scoreChangeAlerts: Boolean = true
)

data class AiMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val contextGameId: String? = null,
    val suggestedChips: List<String> = emptyList()
)
