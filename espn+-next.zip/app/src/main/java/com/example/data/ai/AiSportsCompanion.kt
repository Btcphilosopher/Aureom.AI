package com.example.data.ai

import com.example.data.model.Game
import com.example.data.model.GameStatus
import com.example.data.model.SportType
import com.example.data.repository.SportsRepository
import com.example.data.simulator.LiveGameSimulator

object AiSportsCompanion {

    fun generateInitialGreeting(game: Game? = null): String {
        return if (game != null) {
            "I'm your **ESPN+ Game Companion** for **${game.homeTeam.name} vs ${game.awayTeam.name}**.\n\n" +
            "Current score: **${game.homeTeam.shortCode} ${game.homeScore} — ${game.awayTeam.shortCode} ${game.awayScore}** (${game.period} • ${game.clock}).\n" +
            "Ask me anything about live match analytics, player statistics, tactical breakdowns, or key plays!"
        } else {
            "Welcome to **Ask Sports AI** — your definitive sports intelligence companion.\n\n" +
            "I have real-time access to all live games, standings, player telemetry, and league leaderboards. What would you like to explore?"
        }
    }

    fun answerQuery(query: String, contextGame: Game? = null): String {
        val q = query.trim().lowercase()
        val liveGames = LiveGameSimulator.games.value

        // Contextual Game Queries
        if (contextGame != null) {
            val liveContext = liveGames.find { it.id == contextGame.id } ?: contextGame
            val home = liveContext.homeTeam
            val away = liveContext.awayTeam

            if (q.contains("best player") || q.contains("mvp") || q.contains("standout") || q.contains("star")) {
                return if (liveContext.sport == SportType.BASKETBALL) {
                    "**Jack Carter (${home.shortCode})** is having a masterclass with **34 Points, 9 Assists, and 7 Rebounds** on 56.0% shooting.\n\n" +
                    "On the other side, **Marcus Vance (${away.shortCode})** has responded with **38 Points and 10 Boards**, driving hard into the paint in Q4."
                } else if (liveContext.sport == SportType.SOCCER) {
                    "**Liam Sterling (${home.shortCode})** is the standout player on the pitch, netting a 71st-minute world-class curler and creating 4 chances with 88% pass accuracy."
                } else {
                    "**Max Richter (${home.shortCode})** leads with blistering pace and a 1.98s pit stop execution, holding off heavy DRS pressure."
                }
            }

            if (q.contains("carter") || q.contains("points") || q.contains("stats")) {
                return "📊 **Jack Carter Live Box Score**:\n" +
                        "• Points: **34**\n" +
                        "• Assists: **9**\n" +
                        "• Rebounds: **7**\n" +
                        "• Field Goals: **14/25 (56.0%)**\n" +
                        "• 3-Pointers: **4/8 (50.0%)**\n" +
                        "• Plus/Minus: **+8** in 38 minutes."
            }

            if (q.contains("playoff") || q.contains("standings") || q.contains("implication")) {
                return "🏆 **Playoff Implications**:\n" +
                        "A win for **${home.name}** solidifies their **#1 Seed** in the Eastern Conference (${home.winRecord + 1}-${home.lossRecord}).\n" +
                        "If **${away.name}** rallies, they will pull within 1.5 games of the top seed."
            }

            if (q.contains("what happened") || q.contains("quarter") || q.contains("half") || q.contains("recap")) {
                val lastPlay = liveContext.playByPlay.firstOrNull()?.description ?: "Intense back-and-forth action."
                return "⚡ **Live Game Flow**:\n" +
                        "The game is in **${liveContext.period} (${liveContext.clock})**.\n" +
                        "Current Score: **${home.shortCode} ${liveContext.homeScore} - ${away.shortCode} ${liveContext.awayScore}**.\n" +
                        "Latest key moment: _${lastPlay}_\n" +
                        "Boston made a 7-0 surge midway through the quarter to take the lead."
            }
        }

        // General Universe Queries
        if (q.contains("what should i watch") || q.contains("recommend") || q.contains("best game") || q.contains("biggest game")) {
            val closestLive = liveGames.filter { it.status == GameStatus.LIVE }
                .maxByOrNull { it.heatScore }
            return if (closestLive != null) {
                "🔥 **Top Recommendation: ${closestLive.homeTeam.name} vs ${closestLive.awayTeam.name}**\n\n" +
                "• **Sport**: ${closestLive.sport.displayName} (${closestLive.leagueId.uppercase()})\n" +
                "• **Score**: ${closestLive.homeTeam.shortCode} ${closestLive.homeScore} — ${closestLive.awayTeam.shortCode} ${closestLive.awayScore}\n" +
                "• **Clock**: ${closestLive.period} (${closestLive.clock})\n" +
                "• **Game Heat Index**: **${closestLive.heatScore}/100** (Clutch Finish)\n\n" +
                "Carter and Vance are trading unbelievable shots down the stretch. Jump into 4K Multiview or StreamCenter now!"
            } else {
                "Check out the **Boston Comets vs New York Titans** blockbuster or our 6-part docuseries **'The Dynasties'**!"
            }
        }

        if (q.contains("tonight") || q.contains("schedule") || q.contains("games on") || q.contains("what's on")) {
            val liveList = liveGames.filter { it.status == GameStatus.LIVE }
            val scheduledList = liveGames.filter { it.status == GameStatus.SCHEDULED }

            val liveDesc = liveList.joinToString("\n") { "🔴 **LIVE**: ${it.homeTeam.name} vs ${it.awayTeam.name} (${it.homeScore}-${it.awayScore}) on ${it.broadcastNetwork}" }
            val schedDesc = scheduledList.joinToString("\n") { "⏳ **UPCOMING**: ${it.homeTeam.name} vs ${it.awayTeam.name} at ${it.startTimeFormatted}" }

            return "📺 **Tonight's Live Sports Lineup**:\n\n$liveDesc\n\n$schedDesc"
        }

        if (q.contains("closest") || q.contains("tight") || q.contains("clutch")) {
            val tightGames = liveGames.filter { it.status == GameStatus.LIVE }
                .sortedBy { Math.abs(it.homeScore - it.awayScore) }

            val listStr = tightGames.joinToString("\n") {
                "• **${it.homeTeam.shortCode} ${it.homeScore} vs ${it.awayTeam.shortCode} ${it.awayScore}** (Diff: ${Math.abs(it.homeScore - it.awayScore)} pts, ${it.period} ${it.clock}, Heat: ${it.heatScore})"
            }
            return "🎯 **Closest Games Right Now**:\n\n$listStr"
        }

        if (q.contains("boston") || q.contains("comets")) {
            val boston = SportsRepository.teamBoston
            return "☘️ **Boston Comets Report**:\n" +
                    "• Record: **${boston.winRecord}-${boston.lossRecord}** (#1 in East, Streak: ${boston.streak})\n" +
                    "• Arena: ${boston.venueName}\n" +
                    "• Franchise Star: **Jack Carter** (29.4 PPG, 8.6 APG)\n" +
                    "• Currently playing **New York Titans** in a 4th quarter nail-biter."
        }

        if (q.contains("scoring") || q.contains("leader") || q.contains("stats leader")) {
            return "👑 **League Scoring Leaders (PBL 2026-27)**:\n\n" +
                    "1. **Marcus Vance (NY)** — 31.2 PPG (49.6% FG)\n" +
                    "2. **Jack Carter (BOS)** — 29.4 PPG (51.4% FG, 42.8% 3P)\n" +
                    "3. **DeAndre Hayes (SF)** — 28.1 PPG (54.0% FG)\n" +
                    "4. **Malik Thorne (MIA)** — 26.8 PPG (44.2% 3P)"
        }

        if (q.contains("soccer") || q.contains("champions") || q.contains("london")) {
            return "⚽ **Global Champions League Update**:\n" +
                    "**London Apex FC** leads **Madrid Galacticos 2-1** in the 78th minute of the Semi-Final Leg 2 (Agg 3-2).\n" +
                    "Liam Sterling scored a 71st-minute stunner from 22 yards out!"
        }

        return "Here is the authoritative update on that:\n\n" +
                "• **Live Broadcasts**: 5 active 4K streams running across PBL Basketball, NFL Gridiron, Champions Soccer, and Formula Apex Racing.\n" +
                "• **Top Story**: Jack Carter's 5-year supermax extension with the Boston Comets.\n" +
                "• **Next Big Game**: Golden State Vortex vs Miami Surge tipping off at 8:30 PM ET."
    }
}
