package com.example.data.repository

import com.example.data.model.*

object SportsRepository {

    // --- LEAGUES ---
    val leagues = listOf(
        League("lg_pbl", "Premier Basketball League", "PBL", SportType.BASKETBALL, 0xFFFF3B30),
        League("lg_nfl", "National Football Championship", "NFC", SportType.FOOTBALL, 0xFF007AFF),
        League("lg_prem", "Global Champions Soccer League", "GCL", SportType.SOCCER, 0xFF34C759),
        League("lg_f1", "Formula Apex Grand Prix", "F-APEX", SportType.RACING, 0xFFFF9500),
        League("lg_atp", "World Tennis Tour Masters", "WTT", SportType.TENNIS, 0xFFAFD600),
        League("lg_nhl", "Premier Ice Hockey League", "PIHL", SportType.HOCKEY, 0xFF5856D6),
        League("lg_mlb", "Diamond Baseball Association", "DBA", SportType.BASEBALL, 0xFFFF2D55),
        League("lg_golf", "World Masters Golf Tour", "WMGT", SportType.GOLF, 0xFF30D158),
        League("lg_combat", "Apex Combat Championship", "ACC", SportType.MMA, 0xFFFF453A)
    )

    // --- TEAMS ---
    val teamBoston = Team("tm_bos", "Boston Comets", "Boston", "Comets", "BOS", "lg_pbl", SportType.BASKETBALL, 0xFF008348, 0xFFD4AF37, 24, 6, 1, "Eastern", "TD Apex Garden")
    val teamNewYork = Team("tm_ny", "New York Titans", "New York", "Titans", "NY", "lg_pbl", SportType.BASKETBALL, 0xFF006BB6, 0xFFF58426, 22, 9, 2, "Eastern", "Madison Cyber Arena")
    val teamLA = Team("tm_la", "Los Angeles Hawks", "Los Angeles", "Hawks", "LA", "lg_pbl", SportType.BASKETBALL, 0xFF552583, 0xFFFDB927, 21, 10, 3, "Western", "Crypto Spectrum Arena")
    val teamChicago = Team("tm_chi", "Chicago Blaze", "Chicago", "Blaze", "CHI", "lg_pbl", SportType.BASKETBALL, 0xFFCE1141, 0xFF000000, 19, 12, 4, "Eastern", "United United Center")
    val teamMiami = Team("tm_mia", "Miami Surge", "Miami", "Surge", "MIA", "lg_pbl", SportType.BASKETBALL, 0xFF98002E, 0xFFF9A01B, 20, 11, 3, "Eastern", "Kaseya Bay Center")
    val teamGoldenState = Team("tm_gs", "San Francisco Vortex", "San Francisco", "Vortex", "SF", "lg_pbl", SportType.BASKETBALL, 0xFF1D428A, 0xFFFFC72C, 23, 8, 2, "Western", "Chase Zenith Center")
    val teamDallas = Team("tm_dal", "Dallas Mustangs", "Dallas", "Mustangs", "DAL", "lg_pbl", SportType.BASKETBALL, 0xFF00538C, 0xFFB8C4CA, 18, 13, 5, "Western", "American Airlines Hub")

    // Football Teams
    val teamKCCity = Team("tm_kc", "Kansas City Monarchs", "Kansas City", "Monarchs", "KC", "lg_nfl", SportType.FOOTBALL, 0xFFE31837, 0xFFFFB81C, 12, 3, 1, "AFC", "Arrowhead Stadium")
    val teamPhilly = Team("tm_phi", "Philadelphia Vipers", "Philadelphia", "Vipers", "PHI", "lg_nfl", SportType.FOOTBALL, 0xFF004C54, 0xFFA5ACAF, 11, 4, 2, "NFC", "Lincoln Financial Field")
    val teamDetroit = Team("tm_det", "Detroit Roar", "Detroit", "Roar", "DET", "lg_nfl", SportType.FOOTBALL, 0xFF0076B6, 0xFFB0B7BC, 13, 2, 1, "NFC", "Ford Dome")
    val teamBuffalo = Team("tm_buf", "Buffalo Blizzard", "Buffalo", "Blizzard", "BUF", "lg_nfl", SportType.FOOTBALL, 0xFF00338D, 0xFFC60C30, 11, 4, 2, "AFC", "Highmark Colosseum")

    // Soccer Teams
    val teamLondon = Team("tm_lon", "London Apex FC", "London", "Apex FC", "LON", "lg_prem", SportType.SOCCER, 0xFFDC0714, 0xFFFFFFFF, 16, 2, 1, "Premier", "Emirates Sovereign Stadium")
    val teamMadrid = Team("tm_mad", "Madrid Galacticos", "Madrid", "Galacticos", "MAD", "lg_prem", SportType.SOCCER, 0xFFFFFFFF, 0xFFFEBE10, 15, 3, 2, "European", "Santiago Bernabéu Ultra")
    val teamMunich = Team("tm_mun", "Munich Dynamo", "Munich", "Dynamo", "MUN", "lg_prem", SportType.SOCCER, 0xFFDC052D, 0xFF0066B2, 14, 4, 3, "European", "Allianz Arena")
    val teamParis = Team("tm_par", "Paris Vanguard", "Paris", "Vanguard", "PAR", "lg_prem", SportType.SOCCER, 0xFF004170, 0xFFDA291C, 16, 1, 1, "European", "Parc des Princes")

    // Racing Teams
    val teamRedApex = Team("tm_red_apex", "Red Apex Racing", "Milton Keynes", "Red Apex", "RAR", "lg_f1", SportType.RACING, 0xFF1E41FF, 0xFFE10600, 380, 0, 1, "Constructor", "Silverstone Super Circuit")
    val teamScuderia = Team("tm_scuderia", "Scuderia Corsa", "Maranello", "Scuderia", "SCU", "lg_f1", SportType.RACING, 0xFFFF1801, 0xFFFFF200, 342, 0, 2, "Constructor", "Monza Autodromo")

    val allTeams = listOf(
        teamBoston, teamNewYork, teamLA, teamChicago, teamMiami, teamGoldenState, teamDallas,
        teamKCCity, teamPhilly, teamDetroit, teamBuffalo,
        teamLondon, teamMadrid, teamMunich, teamParis,
        teamRedApex, teamScuderia
    )

    // --- PLAYERS ---
    val playerJackCarter = Player(
        id = "pl_1",
        name = "Jack Carter",
        teamId = "tm_bos",
        teamCode = "BOS",
        sport = SportType.BASKETBALL,
        position = "Point Guard",
        jerseyNumber = "7",
        height = "6'4\"",
        weight = "205 lbs",
        age = 26,
        seasonStats = mapOf(
            "PPG" to "29.4",
            "APG" to "8.6",
            "RPG" to "6.2",
            "FG%" to "51.4%",
            "3P%" to "42.8%",
            "FT%" to "91.2%",
            "+/-" to "+9.8",
            "PER" to "27.8"
        ),
        careerStats = mapOf(
            "Games" to "382",
            "PPG" to "24.8",
            "APG" to "7.1",
            "RPG" to "5.4",
            "All-Star" to "4x",
            "Titles" to "1"
        ),
        recentGameLogs = listOf(
            GameLog("Feb 18", "vs NY", "W 112-108", 34, 7, 9, "38:20", "56.0%"),
            GameLog("Feb 15", "@ MIA", "W 104-98", 28, 5, 11, "36:15", "48.0%"),
            GameLog("Feb 12", "vs CHI", "W 119-105", 31, 8, 7, "35:40", "52.5%"),
            GameLog("Feb 09", "@ SF", "L 102-106", 26, 4, 8, "39:00", "44.0%")
        )
    )

    val playerMarcusVance = Player(
        id = "pl_2",
        name = "Marcus Vance",
        teamId = "tm_ny",
        teamCode = "NY",
        sport = SportType.BASKETBALL,
        position = "Small Forward",
        jerseyNumber = "23",
        height = "6'8\"",
        weight = "235 lbs",
        age = 28,
        seasonStats = mapOf(
            "PPG" to "31.2",
            "APG" to "5.8",
            "RPG" to "8.9",
            "FG%" to "49.6%",
            "3P%" to "39.4%",
            "BLK" to "1.8",
            "+/-" to "+8.4",
            "PER" to "29.1"
        ),
        careerStats = mapOf(
            "Games" to "490",
            "PPG" to "27.5",
            "APG" to "5.2",
            "RPG" to "7.8",
            "All-Star" to "6x",
            "Titles" to "2"
        ),
        recentGameLogs = listOf(
            GameLog("Feb 18", "@ BOS", "L 108-112", 38, 10, 6, "40:10", "51.0%"),
            GameLog("Feb 14", "vs CHI", "W 122-110", 33, 9, 7, "36:00", "53.2%"),
            GameLog("Feb 10", "vs LA", "W 115-111", 29, 12, 4, "38:45", "47.5%")
        )
    )

    val playerLiamSterling = Player(
        id = "pl_3",
        name = "Liam Sterling",
        teamId = "tm_lon",
        teamCode = "LON",
        sport = SportType.SOCCER,
        position = "Striker",
        jerseyNumber = "9",
        height = "6'1\"",
        weight = "180 lbs",
        age = 24,
        seasonStats = mapOf(
            "Goals" to "22",
            "Assists" to "9",
            "Shots/90" to "4.2",
            "xG" to "19.4",
            "Pass Acc" to "84.2%",
            "MOM" to "7"
        ),
        careerStats = mapOf(
            "Matches" to "188",
            "Goals" to "114",
            "Assists" to "42",
            "Golden Boot" to "2"
        )
    )

    val playerMaxVerstappen = Player(
        id = "pl_4",
        name = "Max Richter",
        teamId = "tm_red_apex",
        teamCode = "RAR",
        sport = SportType.RACING,
        position = "Lead Driver",
        jerseyNumber = "1",
        height = "5'11\"",
        weight = "160 lbs",
        age = 27,
        seasonStats = mapOf(
            "Wins" to "14",
            "Podiums" to "18",
            "Pole Positions" to "12",
            "Fastest Laps" to "9",
            "Championship Pts" to "395"
        ),
        careerStats = mapOf(
            "Races" to "195",
            "Wins" to "68",
            "World Championships" to "4"
        )
    )

    val allPlayers = listOf(playerJackCarter, playerMarcusVance, playerLiamSterling, playerMaxVerstappen)

    // --- INITIAL LIVE GAMES ---
    fun createInitialGames(): List<Game> {
        return listOf(
            Game(
                id = "gm_101",
                sport = SportType.BASKETBALL,
                leagueId = "lg_pbl",
                homeTeam = teamBoston,
                awayTeam = teamNewYork,
                homeScore = 98,
                awayScore = 95,
                status = GameStatus.LIVE,
                period = "Q4",
                clock = "02:44",
                venue = "TD Apex Garden, Boston",
                broadcastNetwork = "ESPN+ ULTRA 4K",
                qualityTag = "4K HDR • 60 FPS",
                heatScore = 98,
                isFeatured = true,
                headline = "THRILLER IN BOSTON: Carter and Vance trade clutch buckets in final 3 minutes",
                possession = "BOS",
                shotClock = "11",
                playByPlay = listOf(
                    GamePlayEvent("ev_1", "02:44", "Q4", "Carter Step-back 3PT", "Jack Carter hits a deep 28-foot three over Vance to take the lead!", "BOS", isScore = true, isKeyPlay = true),
                    GamePlayEvent("ev_2", "03:12", "Q4", "Vance Driving Dunk", "Marcus Vance powers through traffic for a ferocious two-handed slam.", "NY", isScore = true, isKeyPlay = true),
                    GamePlayEvent("ev_3", "03:35", "Q4", "Defensive Rebound - Boston", "Thompson secures the board after NY missed corner three.", "BOS"),
                    GamePlayEvent("ev_4", "04:02", "Q4", "Timeout New York", "Head coach calls full 60s timeout following 7-0 Boston run.", "NY")
                ),
                keyPlays = listOf(
                    KeyPlay("kp_1", "02:44", "Q4", "Carter Go-Ahead 3-Pointer", "Deep contested triple putting Boston ahead 98-95.", "98-95", 15),
                    KeyPlay("kp_2", "04:50", "Q4", "Thompson Chase-down Block", "Huge defensive rejection at the rim denying Vance layup.", "91-91", 12),
                    KeyPlay("kp_3", "07:15", "Q3", "Alley-Oop Hammer Slam", "Carter lob to Hayes for stadium-shaking jam.", "76-72", 10)
                ),
                homeStats = TeamGameStats(
                    fieldGoalPct = "52.4%",
                    threePtPct = "41.6%",
                    freeThrowPct = "85.7%",
                    rebounds = 44,
                    assists = 28,
                    turnovers = 8,
                    fastBreakPts = 22,
                    ptsInPaint = 50
                ),
                awayStats = TeamGameStats(
                    fieldGoalPct = "49.1%",
                    threePtPct = "38.5%",
                    freeThrowPct = "80.0%",
                    rebounds = 41,
                    assists = 24,
                    turnovers = 10,
                    fastBreakPts = 16,
                    ptsInPaint = 46
                )
            ),
            Game(
                id = "gm_102",
                sport = SportType.FOOTBALL,
                leagueId = "lg_nfl",
                homeTeam = teamKCCity,
                awayTeam = teamPhilly,
                homeScore = 27,
                awayScore = 24,
                status = GameStatus.LIVE,
                period = "Q4",
                clock = "04:18",
                venue = "Arrowhead Colosseum",
                broadcastNetwork = "ESPN+ SUNDAY NIGHT LIVE",
                qualityTag = "4K HDR • 60 FPS",
                heatScore = 95,
                isFeatured = true,
                headline = "CHAMPIONSHIP REMATCH: 4th & 2 on the 32-yard line with 4 mins left",
                possession = "KC",
                downDistance = "4th & 2 at PHI 32",
                playByPlay = listOf(
                    GamePlayEvent("ev_f1", "04:18", "Q4", "24-Yard Deep Strike", "Mahomes connects down the sideline for a clutch first down.", "KC", isScore = false, isKeyPlay = true),
                    GamePlayEvent("ev_f2", "06:05", "Q4", "Field Goal 48 yds - PHI", "Elliott nails 48-yard FG to cut deficit to 3.", "PHI", isScore = true, isKeyPlay = true)
                ),
                keyPlays = listOf(
                    KeyPlay("kp_f1", "09:30", "Q3", "65-Yard Pick Six", "Cornerback jumps route for shocking defensive touchdown.", "27-21", 18)
                )
            ),
            Game(
                id = "gm_103",
                sport = SportType.SOCCER,
                leagueId = "lg_prem",
                homeTeam = teamLondon,
                awayTeam = teamMadrid,
                homeScore = 2,
                awayScore = 1,
                status = GameStatus.LIVE,
                period = "2nd Half",
                clock = "78'",
                soccerMinute = "78'",
                venue = "Emirates Sovereign Stadium, London",
                broadcastNetwork = "ESPN+ GLOBAL CHAMPIONS",
                qualityTag = "4K ULTRA HD",
                heatScore = 91,
                isFeatured = true,
                headline = "SEMI-FINAL LEG 2: Sterling scores curler into top right corner in 71st minute",
                possession = "LON",
                playByPlay = listOf(
                    GamePlayEvent("ev_s1", "71'", "2H", "GOAL! Liam Sterling", "Breathtaking curling effort from 22 yards out beats keeper!", "LON", isScore = true, isKeyPlay = true),
                    GamePlayEvent("ev_s2", "54'", "2H", "GOAL! Rodrygo", "Madrid equalizes with slick one-two touch finish inside the box.", "MAD", isScore = true, isKeyPlay = true)
                ),
                keyPlays = listOf(
                    KeyPlay("kp_s1", "71'", "2H", "Sterling Spectacular Curler", "Golazo into top corner to restore London's aggregate lead.", "2-1 (Agg 3-2)", 15)
                )
            ),
            Game(
                id = "gm_104",
                sport = SportType.RACING,
                leagueId = "lg_f1",
                homeTeam = teamRedApex,
                awayTeam = teamScuderia,
                homeScore = 1, // Position 1
                awayScore = 2, // Position 2
                status = GameStatus.LIVE,
                period = "Lap 48/57",
                clock = "Lap 48",
                racingLap = "48/57",
                venue = "Silverstone Ultra Grand Prix",
                broadcastNetwork = "ESPN+ SPEED PASS ONBOARD",
                qualityTag = "4K 60FPS DUAL HELMET CAM",
                heatScore = 89,
                isFeatured = false,
                headline = "DRS BATTLE: Interval under 0.380s entering the final 9 laps",
                playByPlay = listOf(
                    GamePlayEvent("ev_r1", "Lap 46", "R", "DRS Overtake Attempt", "Scuderia dives into Stowe corner wheel to wheel!", "SCU", isKeyPlay = true),
                    GamePlayEvent("ev_r2", "Lap 34", "R", "Rapid Pit Stop - 1.98s", "Red Apex crew executes lightning tire change.", "RAR")
                )
            ),
            Game(
                id = "gm_105",
                sport = SportType.BASKETBALL,
                leagueId = "lg_pbl",
                homeTeam = teamLA,
                awayTeam = teamChicago,
                homeScore = 88,
                awayScore = 86,
                status = GameStatus.LIVE,
                period = "Q3",
                clock = "01:15",
                venue = "Crypto Spectrum Arena, LA",
                broadcastNetwork = "ESPN+ 2 LIVE",
                qualityTag = "1080p HDR",
                heatScore = 86,
                isFeatured = false,
                possession = "LA",
                shotClock = "18"
            ),
            Game(
                id = "gm_106",
                sport = SportType.BASKETBALL,
                leagueId = "lg_pbl",
                homeTeam = teamGoldenState,
                awayTeam = teamMiami,
                homeScore = 0,
                awayScore = 0,
                status = GameStatus.SCHEDULED,
                period = "Tonight",
                clock = "8:30 PM ET",
                venue = "Chase Zenith Center, SF",
                broadcastNetwork = "ESPN+ PRIMETIME EXCLUSIVE",
                qualityTag = "4K HDR",
                heatScore = 82,
                isFeatured = false,
                startTimeFormatted = "8:30 PM ET"
            ),
            Game(
                id = "gm_107",
                sport = SportType.FOOTBALL,
                leagueId = "lg_nfl",
                homeTeam = teamDetroit,
                awayTeam = teamBuffalo,
                homeScore = 31,
                awayScore = 28,
                status = GameStatus.FINAL,
                period = "FINAL",
                clock = "00:00",
                venue = "Ford Dome",
                broadcastNetwork = "ESPN+ ON DEMAND REPLAY",
                qualityTag = "4K FULL REPLAY & CONDENSED",
                heatScore = 94,
                isFeatured = false,
                headline = "INSTANT CLASSIC: Detroit clinches division in walk-off 52-yard field goal"
            )
        )
    }

    // --- ORIGINALS & SHOWS ---
    val originalShows = listOf(
        OriginalShow(
            id = "show_1",
            title = "THE DYNASTIES",
            subtitle = "Inside the 5-Year Reign of the Boston Comets",
            description = "An unprecedented 6-part all-access documentary capturing the locker room dynamics, tactical masterminds, and intense personal rivalries behind the greatest modern sports dynasty.",
            totalEpisodes = 6,
            category = "Docuseries",
            rating = "TV-MA",
            duration = "6 Episodes",
            episodes = listOf(
                ShowEpisode("ep_1", 1, "The Architect's Blueprint", "54m", "How GM Sarah Sterling assembled the highest scoring lineup in league history."),
                ShowEpisode("ep_2", 2, "Game 7 in the Garden", "58m", "The legendary triple-overtime thriller that birthed a championship era."),
                ShowEpisode("ep_3", 3, "Fractures in the Core", "51m", "Contract disputes and ego clashes threaten to derail the repeat campaign."),
                ShowEpisode("ep_4", 4, "The Vegas Reckoning", "55m", "Behind closed doors during the turbulent 2025 mid-season tournament.")
            )
        ),
        OriginalShow(
            id = "show_2",
            title = "APEX: INSIDE FORMULA ONE",
            subtitle = "Speed, Aerodynamics, and Billion-Dollar Stakes",
            description = "Engineers, telemetry analysts, and elite drivers push the boundaries of physics in a 350 km/h battle for global supremacy.",
            totalEpisodes = 8,
            category = "Motorsport Original",
            rating = "TV-14",
            duration = "8 Episodes",
            episodes = listOf(
                ShowEpisode("ep_f1_1", 1, "The Millisecond Margin", "48m", "Wind tunnel innovations and carbon-fiber aero developments."),
                ShowEpisode("ep_f1_2", 2, "Monaco at Twilight", "52m", "Qualifying on the world's most unforgiving street circuit.")
            )
        ),
        OriginalShow(
            id = "show_3",
            title = "SPORTSCENTER NEXT: 360",
            subtitle = "Daily AI-Curated Sports Breakdown",
            description = "The definitive daily flagship analysis program with predictive machine-learning analytics, tactical touchscreen breakdowns, and exclusive player interviews.",
            totalEpisodes = 120,
            category = "Studio Program",
            rating = "TV-PG",
            duration = "Daily • 45m"
        )
    )

    // --- NEWS STORIES ---
    val newsStories = listOf(
        NewsStory(
            id = "nw_1",
            headline = "BREAKING: Supermax Extension Agreed for All-Star Point Guard Jack Carter",
            summary = "Sources confirm Boston Comets and Jack Carter have finalized a historic 5-year, $318M designated veteran extension.",
            content = "The Boston Comets front office has officially locked in their franchise cornerstone. With Carter averaging career highs in scoring and playmaking efficiency, the deal secures Boston's championship window through 2031. League executives widely praise the move following back-to-back Finals appearances.",
            category = "NBA / PBL",
            readTimeMin = 3,
            timestamp = "4 mins ago",
            isBreaking = true,
            relatedTeamId = "tm_bos",
            relatedSport = SportType.BASKETBALL,
            videoDuration = "02:45"
        ),
        NewsStory(
            id = "nw_2",
            headline = "Tactical Masterclass: How London Apex Dismantled Madrid's High Press",
            summary = "Advanced passing network telemetry reveals the crucial halftime adjustment that created Liam Sterling's decisive winner.",
            content = "By dropping the central midfielder into a temporary back-three during possession phases, London bypassed Madrid's intense pressing trap with 94% progressive pass completion. Sterling's heat map shows devastating efficiency in half-spaces.",
            category = "Champions League",
            readTimeMin = 5,
            timestamp = "22 mins ago",
            isBreaking = false,
            relatedTeamId = "tm_lon",
            relatedSport = SportType.SOCCER,
            videoDuration = "04:10"
        ),
        NewsStory(
            id = "nw_3",
            headline = "F1 Apex Telemetry Deep Dive: Red Apex Floor Upgrade Delivers 0.25s Per Lap",
            summary = "Wind tunnel data and GPS traces from sector 2 at Silverstone show massive low-speed downforce gains.",
            content = "Max Richter's pole lap featured unprecedented apex velocity through Copse and Maggots/Becketts. Rival teams are already lodging inquiries regarding flexible wing surfaces ahead of the night race.",
            category = "Formula Apex",
            readTimeMin = 4,
            timestamp = "1 hour ago",
            isBreaking = false,
            relatedTeamId = "tm_red_apex",
            relatedSport = SportType.RACING
        ),
        NewsStory(
            id = "nw_4",
            headline = "NFL Playoff Picture: Buffalo Blizzard and Kansas City on Collision Course",
            summary = "With only two weeks remaining in the regular season, the race for the AFC #1 seed comes down to point differentials.",
            content = "Both offenses are generating over 420 yards per contest. If both franchises win out this weekend, next Sunday's head-to-head matchup will determine home-field advantage all the way to the Super Bowl.",
            category = "NFL / NFC",
            readTimeMin = 4,
            timestamp = "3 hours ago",
            isBreaking = false,
            relatedTeamId = "tm_kc",
            relatedSport = SportType.FOOTBALL
        )
    )

    // --- FANTASY ROSTER ---
    val myFantasyRoster = listOf(
        FantasyPlayer("fan_1", "pl_1", "Jack Carter", "BOS", "PG", 48.6, 44.0, "ACTIVE", "3PT Made (+3.0 pts)"),
        FantasyPlayer("fan_2", "pl_2", "Marcus Vance", "NY", "SF", 52.4, 49.5, "ACTIVE", "Slam Dunk + Foul (+4.5 pts)"),
        FantasyPlayer("fan_3", "pl_3", "Liam Sterling", "LON", "FWD", 28.0, 22.0, "ACTIVE", "Curling Goal + 90m (+10.0 pts)"),
        FantasyPlayer("fan_4", "pl_4", "Max Richter", "RAR", "DRV", 35.0, 32.0, "RACING", "Fastest Lap Bonus (+5.0 pts)")
    )

    // --- FUZZY SEARCH FUNCTION ---
    fun searchAll(query: String): SearchResults {
        if (query.isBlank()) return SearchResults()
        val q = query.trim().lowercase()

        val matchedTeams = allTeams.filter {
            it.name.lowercase().contains(q) || it.city.lowercase().contains(q) || it.shortCode.lowercase().contains(q)
        }
        val matchedPlayers = allPlayers.filter {
            it.name.lowercase().contains(q) || it.teamCode.lowercase().contains(q)
        }
        val matchedLeagues = leagues.filter {
            it.name.lowercase().contains(q) || it.shortName.lowercase().contains(q)
        }
        val matchedGames = createInitialGames().filter {
            it.homeTeam.name.lowercase().contains(q) || it.awayTeam.name.lowercase().contains(q) ||
            it.sport.displayName.lowercase().contains(q) || it.venue.lowercase().contains(q)
        }
        val matchedShows = originalShows.filter {
            it.title.lowercase().contains(q) || it.subtitle.lowercase().contains(q) || it.description.lowercase().contains(q)
        }
        val matchedNews = newsStories.filter {
            it.headline.lowercase().contains(q) || it.summary.lowercase().contains(q) || it.category.lowercase().contains(q)
        }

        return SearchResults(
            teams = matchedTeams,
            players = matchedPlayers,
            leagues = matchedLeagues,
            games = matchedGames,
            shows = matchedShows,
            news = matchedNews
        )
    }
}

data class SearchResults(
    val teams: List<Team> = emptyList(),
    val players: List<Player> = emptyList(),
    val leagues: List<League> = emptyList(),
    val games: List<Game> = emptyList(),
    val shows: List<OriginalShow> = emptyList(),
    val news: List<NewsStory> = emptyList()
) {
    val totalMatches: Int get() = teams.size + players.size + leagues.size + games.size + shows.size + news.size
}
