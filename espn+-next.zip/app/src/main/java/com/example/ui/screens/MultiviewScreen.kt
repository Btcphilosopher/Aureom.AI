package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Game
import com.example.data.model.GameStatus
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun MultiviewScreen(
    allGames: List<Game>,
    onBack: () -> Unit,
    onExpandGame: (Game) -> Unit
) {
    val liveGames = allGames.filter { it.status == GameStatus.LIVE }

    // Active multiview game IDs (up to 4)
    var multiviewGameIds by remember {
        mutableStateOf(liveGames.take(4).map { it.id }.toMutableList())
    }

    var focusedGameId by remember {
        mutableStateOf(multiviewGameIds.firstOrNull() ?: "")
    }

    var multiviewLayoutMode by remember { mutableStateOf("2-UP") } // "2-UP", "3-UP", "4-UP"
    var showAddGameSheet by remember { mutableStateOf(false) }

    val activeGames = multiviewGameIds.mapNotNull { id -> allGames.find { it.id == id } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("multiview_screen")
    ) {
        // --- TOP TOOLBAR ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(SurfaceElevated)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhitePrimary
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GridView,
                            contentDescription = "Multiview",
                            tint = Color(0xFF818C78),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "MULTIVIEW 4K",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                color = TextWhitePrimary
                            )
                        )
                    }
                    Text(
                        text = "TAP STREAM TO ROUTE AUDIO FOCUS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 8.sp,
                            color = NeonAmberGold
                        )
                    )
                }
            }

            // Layout Mode Buttons (2-UP, 3-UP, 4-UP) & Add Stream
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("2-UP", "3-UP", "4-UP").forEach { mode ->
                    val isSelected = mode == multiviewLayoutMode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
                            .border(1.dp, if (isSelected) Color(0xFF818C78) else SurfaceBorder, RoundedCornerShape(20.dp))
                            .clickable { multiviewLayoutMode = mode }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = mode,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                            )
                        )
                    }
                }

                IconButton(
                    onClick = { showAddGameSheet = true },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SurfaceElevated)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Game",
                        tint = TextWhitePrimary
                    )
                }
            }
        }

        // --- MULTIVIEW GRID VIEWPORT ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(8.dp)
        ) {
            when (multiviewLayoutMode) {
                "2-UP" -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        activeGames.take(2).forEach { game ->
                            MultiviewStreamTile(
                                game = game,
                                isFocused = game.id == focusedGameId,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                onFocus = { focusedGameId = game.id },
                                onExpand = { onExpandGame(game) }
                            )
                        }
                    }
                }
                "3-UP" -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Top Primary Tile (Focused / First)
                        activeGames.firstOrNull()?.let { topGame ->
                            MultiviewStreamTile(
                                game = topGame,
                                isFocused = topGame.id == focusedGameId,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1.3f),
                                onFocus = { focusedGameId = topGame.id },
                                onExpand = { onExpandGame(topGame) }
                            )
                        }

                        // Bottom 2 Split Tiles
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            activeGames.drop(1).take(2).forEach { game ->
                                MultiviewStreamTile(
                                    game = game,
                                    isFocused = game.id == focusedGameId,
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(1f),
                                    onFocus = { focusedGameId = game.id },
                                    onExpand = { onExpandGame(game) }
                                )
                            }
                        }
                    }
                }
                "4-UP" -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Top Row (2 games)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            activeGames.take(2).forEach { game ->
                                MultiviewStreamTile(
                                    game = game,
                                    isFocused = game.id == focusedGameId,
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(1f),
                                    onFocus = { focusedGameId = game.id },
                                    onExpand = { onExpandGame(game) }
                                )
                            }
                        }

                        // Bottom Row (2 games)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            activeGames.drop(2).take(2).forEach { game ->
                                MultiviewStreamTile(
                                    game = game,
                                    isFocused = game.id == focusedGameId,
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(1f),
                                    onFocus = { focusedGameId = game.id },
                                    onExpand = { onExpandGame(game) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- BOTTOM AUDIO FOCUS STATUS BAR ---
        val currentFocus = allGames.find { it.id == focusedGameId }
        if (currentFocus != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceObsidian)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Audio Focus",
                        tint = ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Column {
                        Text(
                            text = "PRIMARY AUDIO: ${currentFocus.homeTeam.name} vs ${currentFocus.awayTeam.name}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhitePrimary
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${currentFocus.period} • ${currentFocus.clock} | Score: ${currentFocus.homeScore}-${currentFocus.awayScore}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                color = NeonAmberGold
                            )
                        )
                    }
                }

                Button(
                    onClick = { onExpandGame(currentFocus) },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonSportsRed),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Fullscreen,
                        contentDescription = "Expand",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("EXPAND", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black))
                }
            }
        }
    }

    // Modal Sheet to Add / Replace Multiview Game
    if (showAddGameSheet) {
        AlertDialog(
            onDismissRequest = { showAddGameSheet = false },
            title = { Text("Add Stream to Multiview", color = Color.White, fontWeight = FontWeight.Black) },
            text = {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(liveGames) { game ->
                        val isAlreadyIn = multiviewGameIds.contains(game.id)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isAlreadyIn) ElectricCyan.copy(alpha = 0.15f) else SurfaceElevated)
                                .clickable {
                                    if (isAlreadyIn) {
                                        multiviewGameIds.remove(game.id)
                                    } else {
                                        if (multiviewGameIds.size < 4) {
                                            multiviewGameIds.add(game.id)
                                        }
                                    }
                                    showAddGameSheet = false
                                }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${game.homeTeam.shortCode} vs ${game.awayTeam.shortCode}",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "${game.sport.displayName} • ${game.period} ${game.clock}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSilverSecondary)
                                )
                            }
                            Icon(
                                imageVector = if (isAlreadyIn) Icons.Default.CheckCircle else Icons.Default.AddCircleOutline,
                                contentDescription = "Toggle",
                                tint = if (isAlreadyIn) ElectricCyan else Color.White
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddGameSheet = false }) { Text("CLOSE", color = ElectricCyan) }
            },
            containerColor = SurfaceObsidian
        )
    }
}

@Composable
private fun MultiviewStreamTile(
    game: Game,
    isFocused: Boolean,
    modifier: Modifier = Modifier,
    onFocus: () -> Unit,
    onExpand: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(
                border = BorderStroke(
                    width = if (isFocused) 2.dp else 1.dp,
                    color = if (isFocused) Color(0xFF818C78) else SurfaceBorder
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onFocus)
    ) {
        SimulatedBroadcastView(
            game = game,
            showHud = false,
            isMuted = !isFocused
        )

        // Top Overlay: Live score bug & audio focus icon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BroadcastScoreBug(game = game)

            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isFocused) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFDDE5D7))
                            .border(1.dp, Color(0xFF818C78), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Audio Active",
                                tint = Color(0xFF1D192B),
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "AUDIO",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 9.sp,
                                    color = Color(0xFF1D192B)
                                )
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onExpand,
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color(0x80000000))
                ) {
                    Icon(
                        imageVector = Icons.Default.Fullscreen,
                        contentDescription = "Expand",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}
