package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Game
import com.example.data.model.KeyPlay
import com.example.data.model.SportType
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun LivePlayerScreen(
    game: Game,
    onBack: () -> Unit,
    onOpenMultiview: () -> Unit,
    onAskGameAi: (Game) -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var isFullscreen by remember { mutableStateOf(false) }
    var selectedAudioTrack by remember { mutableStateOf(game.audioFeeds.firstOrNull() ?: "Main Stadium Feed") }
    var selectedQuality by remember { mutableStateOf("4K UHD • 60 FPS") }
    var showQualityDialog by remember { mutableStateOf(false) }
    var showAudioDialog by remember { mutableStateOf(false) }
    var showCastDialog by remember { mutableStateOf(false) }

    // StreamCenter companion tab selection
    var companionTab by remember { mutableStateOf("LIVE STATS") }
    val companionTabs = listOf("LIVE STATS", "PLAY-BY-PLAY", "KEY PLAYS", "FAN POLL", "GAME AI")

    // Fan cheer reaction counter
    var fireCount by remember { mutableIntStateOf(1420) }
    var thunderCount by remember { mutableIntStateOf(980) }
    var clapCount by remember { mutableIntStateOf(812) }

    // Poll selection state
    var selectedPollOption by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("live_player_screen")
    ) {
        // --- TOP BROADCAST APP BAR ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(SurfaceElevated)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = TextWhitePrimary
                )
            }

            BroadcastScoreBug(game = game)

            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { showCastDialog = true },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Cast,
                        contentDescription = "Cast to TV",
                        tint = TextWhitePrimary
                    )
                }

                IconButton(
                    onClick = onOpenMultiview,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.GridView,
                        contentDescription = "Multiview",
                        tint = Color(0xFF818C78)
                    )
                }
            }
        }

        // --- PRIMARY SIMULATED 4K VIDEO PLAYER CANVAS ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .padding(horizontal = 12.dp)
        ) {
            SimulatedBroadcastView(
                game = game,
                isPlaying = isPlaying,
                isMuted = isMuted,
                showHud = true,
                onTogglePlay = { isPlaying = !isPlaying },
                onToggleMute = { isMuted = !isMuted },
                onToggleFullscreen = { isFullscreen = !isFullscreen }
            )
        }

        // --- ADVANCED PLAYER CONTROLS & HUD TOOLBAR ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Audio Selector Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(SurfaceElevated)
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(20.dp))
                        .clickable { showAudioDialog = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = "Audio",
                            tint = TextWhitePrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = selectedAudioTrack,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhitePrimary
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 100.dp)
                        )
                    }
                }

                // Quality Selector Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(SurfaceElevated)
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(20.dp))
                        .clickable { showQualityDialog = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = selectedQuality,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF818C78)
                        )
                    )
                }
            }

            // Ask AI Companion Quick Button
            Button(
                onClick = { onAskGameAi(game) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFEDE8D0),
                    contentColor = Color(0xFF1D192B)
                ),
                border = BorderStroke(1.dp, Color(0xFF818C78)),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Ask AI",
                    tint = Color(0xFF818C78),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "COMPANION",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black, color = Color(0xFF1D192B))
                )
            }
        }

        // --- STREAMCENTER COMPANION MODE HEADER & TABS ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceObsidian)
                .padding(top = 8.dp, bottom = 4.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(text = "📱", fontSize = 12.sp)
                        Text(
                            text = "STREAMCENTER COMPANION",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.8.sp,
                                color = NeonAmberGold
                            )
                        )
                    }

                    Text(
                        text = "LIVE SYNCED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = StadiumGreen
                        )
                    )
                }

                // Companion Tabs Rail
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(companionTabs) { tab ->
                        val isSelected = tab == companionTab
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
                                .border(1.dp, if (isSelected) Color(0xFF818C78) else SurfaceBorder, RoundedCornerShape(20.dp))
                                .clickable { companionTab = tab }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = tab,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                                )
                            )
                        }
                    }
                }
            }
        }

        // --- STREAMCENTER ACTIVE TAB CONTENT ---
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            when (companionTab) {
                "LIVE STATS" -> LiveStatsCompanionView(game = game)
                "PLAY-BY-PLAY" -> PlayByPlayCompanionView(game = game)
                "KEY PLAYS" -> KeyPlaysCompanionView(game = game)
                "FAN POLL" -> FanPollAndReactionsView(
                    fireCount = fireCount,
                    thunderCount = thunderCount,
                    clapCount = clapCount,
                    onCheer = { type ->
                        when (type) {
                            "fire" -> fireCount++
                            "thunder" -> thunderCount++
                            "clap" -> clapCount++
                        }
                    },
                    selectedPollOption = selectedPollOption,
                    onVote = { selectedPollOption = it }
                )
                "GAME AI" -> GameAiQuickCompanionView(
                    game = game,
                    onOpenFullAi = { onAskGameAi(game) }
                )
            }
        }
    }

    // Audio Track Modal Dialog
    if (showAudioDialog) {
        AlertDialog(
            onDismissRequest = { showAudioDialog = false },
            title = { Text("Select Audio Feed", style = MaterialTheme.typography.titleLarge.copy(color = Color.White)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    game.audioFeeds.forEach { track ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (track == selectedAudioTrack) NeonSportsRed.copy(alpha = 0.2f) else SurfaceElevated)
                                .clickable {
                                    selectedAudioTrack = track
                                    showAudioDialog = false
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = track, color = Color.White, fontWeight = FontWeight.Bold)
                            if (track == selectedAudioTrack) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = "Active", tint = NeonSportsRed)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAudioDialog = false }) { Text("DONE", color = ElectricCyan) }
            },
            containerColor = SurfaceObsidian
        )
    }

    // Quality Selector Dialog
    if (showQualityDialog) {
        val qualities = listOf("4K UHD • 60 FPS (HDR)", "1080p • 60 FPS (High Bitrate)", "720p • 60 FPS (Data Saver)", "Auto Adaptive")
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("Select Stream Quality", style = MaterialTheme.typography.titleLarge.copy(color = Color.White)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    qualities.forEach { q ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (q == selectedQuality) ElectricCyan.copy(alpha = 0.2f) else SurfaceElevated)
                                .clickable {
                                    selectedQuality = q
                                    showQualityDialog = false
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = q, color = Color.White, fontWeight = FontWeight.Bold)
                            if (q == selectedQuality) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = "Active", tint = ElectricCyan)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) { Text("DONE", color = ElectricCyan) }
            },
            containerColor = SurfaceObsidian
        )
    }

    // Cast Dialog
    if (showCastDialog) {
        AlertDialog(
            onDismissRequest = { showCastDialog = false },
            title = { Text("Cast to Living Room TV", style = MaterialTheme.typography.titleLarge.copy(color = Color.White)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select target screen for synchronized ultra-low latency playback:", color = TextSilverSecondary)
                    CastDeviceRow(name = "Living Room 85\" OLED (Apple TV 4K)", isConnected = false, onConnect = { showCastDialog = false })
                    CastDeviceRow(name = "Media Room Projector (Chromecast Ultra)", isConnected = false, onConnect = { showCastDialog = false })
                    CastDeviceRow(name = "Den Samsung Smart TV", isConnected = false, onConnect = { showCastDialog = false })
                }
            },
            confirmButton = {
                TextButton(onClick = { showCastDialog = false }) { Text("CLOSE", color = ElectricCyan) }
            },
            containerColor = SurfaceObsidian
        )
    }
}

@Composable
private fun CastDeviceRow(
    name: String,
    isConnected: Boolean,
    onConnect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceElevated)
            .clickable(onClick = onConnect)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = Icons.Default.Tv, contentDescription = "TV", tint = ElectricCyan)
            Text(text = name, color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
        }
        Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Connect", tint = TextSilverSecondary)
    }
}

@Composable
private fun LiveStatsCompanionView(game: Game) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ShinyCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "TEAM STATISTICAL COMPARISON",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = TextWhitePrimary
                        )
                    )

                    ComparisonStatBar(
                        title = "Field Goal %",
                        homeValue = game.homeStats.fieldGoalPct,
                        awayValue = game.awayStats.fieldGoalPct,
                        homeRatio = 0.52f,
                        homeColor = Color(game.homeTeam.primaryColor),
                        awayColor = Color(game.awayTeam.primaryColor)
                    )

                    ComparisonStatBar(
                        title = "3-Point %",
                        homeValue = game.homeStats.threePtPct,
                        awayValue = game.awayStats.threePtPct,
                        homeRatio = 0.48f,
                        homeColor = Color(game.homeTeam.primaryColor),
                        awayColor = Color(game.awayTeam.primaryColor)
                    )

                    ComparisonStatBar(
                        title = "Rebounds",
                        homeValue = "${game.homeStats.rebounds}",
                        awayValue = "${game.awayStats.rebounds}",
                        homeRatio = 0.51f,
                        homeColor = Color(game.homeTeam.primaryColor),
                        awayColor = Color(game.awayTeam.primaryColor)
                    )

                    ComparisonStatBar(
                        title = "Assists",
                        homeValue = "${game.homeStats.assists}",
                        awayValue = "${game.awayStats.assists}",
                        homeRatio = 0.54f,
                        homeColor = Color(game.homeTeam.primaryColor),
                        awayColor = Color(game.awayTeam.primaryColor)
                    )

                    ComparisonStatBar(
                        title = "Fast Break Pts",
                        homeValue = "${game.homeStats.fastBreakPts}",
                        awayValue = "${game.awayStats.fastBreakPts}",
                        homeRatio = 0.58f,
                        homeColor = Color(game.homeTeam.primaryColor),
                        awayColor = Color(game.awayTeam.primaryColor)
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayByPlayCompanionView(game: Game) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(game.playByPlay, key = { it.id }) { play ->
            ShinyCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = if (play.isKeyPlay) NeonSportsRed.copy(alpha = 0.6f) else SurfaceBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SurfaceElevated)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = play.clock,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = NeonAmberGold
                            )
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "[${play.teamCode}] ${play.title}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (play.isKeyPlay) NeonSportsRed else TextWhitePrimary
                                )
                            )
                        }
                        Text(
                            text = play.description,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextSilverSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun KeyPlaysCompanionView(game: Game) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(game.keyPlays, key = { it.id }) { keyPlay ->
            ShinyCard(
                modifier = Modifier.fillMaxWidth(),
                onClick = {}
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(NeonSportsRed)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${keyPlay.quarter} • ${keyPlay.timeString}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                )
                            }
                            Text(
                                text = "Score: ${keyPlay.scoreSnapshot}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSilverSecondary
                                )
                            )
                        }

                        Text(
                            text = keyPlay.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextWhitePrimary
                            )
                        )
                        Text(
                            text = keyPlay.description,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextSilverSecondary
                            )
                        )
                    }

                    IconButton(
                        onClick = {},
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(SurfaceElevated)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Watch Clip",
                            tint = ElectricCyan
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FanPollAndReactionsView(
    fireCount: Int,
    thunderCount: Int,
    clapCount: Int,
    onCheer: (String) -> Unit,
    selectedPollOption: Int?,
    onVote: (Int) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Live Fan Emoji Cheer Bar
        ShinyCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "LIVE STADIUM FAN REACTIONS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = TextWhitePrimary
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ReactionButton(emoji = "🔥", count = fireCount, onClick = { onCheer("fire") })
                    ReactionButton(emoji = "⚡", count = thunderCount, onClick = { onCheer("thunder") })
                    ReactionButton(emoji = "👏", count = clapCount, onClick = { onCheer("clap") })
                }
            }
        }

        // Live Match Poll
        ShinyCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "LIVE FAN POLL",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonAmberGold
                    )
                )
                Text(
                    text = "Who hits the final clutch shot in the closing minute?",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary
                    )
                )

                PollOptionItem(
                    label = "Jack Carter (BOS)",
                    pct = if (selectedPollOption != null) "62%" else "",
                    isSelected = selectedPollOption == 0,
                    onClick = { onVote(0) }
                )

                PollOptionItem(
                    label = "Marcus Vance (NY)",
                    pct = if (selectedPollOption != null) "38%" else "",
                    isSelected = selectedPollOption == 1,
                    onClick = { onVote(1) }
                )
            }
        }
    }
}

@Composable
private fun ReactionButton(
    emoji: String,
    count: Int,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = SurfaceElevated,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(text = emoji, fontSize = 22.sp)
            Text(
                text = "$count",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

@Composable
private fun PollOptionItem(
    label: String,
    pct: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) NeonSportsRed.copy(alpha = 0.25f) else SurfaceElevated)
            .border(
                1.dp,
                if (isSelected) NeonSportsRed else SurfaceBorder,
                RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextWhitePrimary
                )
            )
            if (pct.isNotBlank()) {
                Text(
                    text = pct,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        color = NeonAmberGold
                    )
                )
            }
        }
    }
}

@Composable
private fun GameAiQuickCompanionView(
    game: Game,
    onOpenFullAi: () -> Unit
) {
    ShinyCard(
        modifier = Modifier.fillMaxWidth(),
        borderColor = Color(0xFFD05CE3)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "AI",
                        tint = Color(0xFFFF80AB)
                    )
                    Text(
                        text = "AI GAME COMPANION",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFFF80AB)
                        )
                    )
                }

                TextButton(onClick = onOpenFullAi) {
                    Text("FULL CHAT", color = ElectricCyan, fontWeight = FontWeight.Bold)
                }
            }

            Text(
                text = "⚡ Real-Time Tactical Breakdown:",
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextWhitePrimary
                )
            )

            Text(
                text = "• Boston is dominating points in the paint (50-46) thanks to Carter's aggressive penetration.\n" +
                        "• New York's 3-point shooting cooled down in Q4 (2/7), allowing Boston to mount their 7-0 surge.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextSilverSecondary
                )
            )

            Button(
                onClick = onOpenFullAi,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3C184A)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Ask Question About This Match", fontWeight = FontWeight.Bold)
            }
        }
    }
}
