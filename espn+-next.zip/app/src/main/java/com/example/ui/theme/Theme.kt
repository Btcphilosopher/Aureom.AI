package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NaturalTonesColorScheme = lightColorScheme(
    primary = NeonSportsRed, // #818C78
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE5D7),
    onPrimaryContainer = Color(0xFF1C1B1F),
    secondary = NeonAmberGold, // #8B7E6B
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF0F4EF),
    onSecondaryContainer = Color(0xFF1C1B1F),
    tertiary = ElectricCyan, // #5A6354
    onTertiary = Color.White,
    background = CanvasPureBlack, // #F7F2EA
    onBackground = TextWhitePrimary, // #1C1B1F
    surface = SurfaceObsidian, // #FFFFFF
    onSurface = TextWhitePrimary, // #1C1B1F
    surfaceVariant = SurfaceElevated, // #F0F4EF
    onSurfaceVariant = TextSilverSecondary, // #49454F
    outline = SurfaceBorder, // #E7E0EC
    outlineVariant = MetalGraphite // #DDE5D7
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NaturalTonesColorScheme,
        typography = Typography,
        content = content
    )
}


