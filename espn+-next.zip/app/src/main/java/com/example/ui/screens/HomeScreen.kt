package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.data.repository.SportsRepository
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    games: List<Game>,
    news: List<NewsStory>,
    onSelectGame: (Game) -> Unit,
    onOpenMultiview: () -> Unit,
    onOpenAskSports: (Game?) -> Unit,
    onOpenDevControl: () -> Unit,
    onSelectTeam: (Team) -> Unit,
    onSelectPlayer: (Player) -> Unit,
    onSelectShow: (OriginalShow) -> Unit,
    onSelectNews: (NewsStory) -> Unit
) {
    val featuredLiveGame = games.find { it.isFeatured && it.status == GameStatus.LIVE } ?: games.firstOrNull()
    val liveGames = games.filter { it.status == GameStatus.LIVE }
    val upcomingGames = games.filter { it.status == GameStatus.SCHEDULED }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // --- TOP BROADCAST STATUS BAR & LOGO ---
        item {
            HomeHeaderBar(
                onOpenAskSports = { onOpenAskSports(null) },
                onOpenMultiview = onOpenMultiview,
                onOpenDevControl = onOpenDevControl
            )
        }

        // --- SPECTACULAR CINEMATIC HERO EVENT ---
        if (featuredLiveGame != null) {
            item {
                HomeCinematicHero(
                    game = featuredLiveGame,
                    onWatch = { onSelectGame(featuredLiveGame) },
                    onAskAi = { onOpenAskSports(featuredLiveGame) },
                    onMultiview = onOpenMultiview
                )
            }
        }

        // --- SPORTS RADAR / REAL-TIME EXCITEMENT MATRIX ---
        item {
            SportsRadarSection(
                liveGames = liveGames,
                onSelectGame = onSelectGame
            )
        }

        // --- LIVE NOW RAIL ---
        item {
            SectionHeader(title = "LIVE NOW", badgeText = "${liveGames.size} STREAMS", isLive = true)
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(liveGames, key = { it.id }) { game ->
                    LiveStreamCard(
                        game = game,
                        onClick = { onSelectGame(game) }
                    )
                }
            }
        }

        // --- MY TEAMS & FANTASY ACTION RAIL ---
        item {
            SectionHeader(title = "MY TEAMS & FANTASY", badgeText = "PERSONALIZED")
            Spacer(modifier = Modifier.height(10.dp))
            MyTeamsQuickRail(
                onSelectTeam = onSelectTeam,
                onSelectPlayer = onSelectPlayer
            )
        }

        // --- BREAKING & TOP STORIES ---
        item {
            SectionHeader(title = "SPORTSCENTER FOR YOU", badgeText = "CURATED NEWS")
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(news, key = { it.id }) { item ->
                    NewsHighlightCard(
                        story = item,
                        onClick = { onSelectNews(item) }
                    )
                }
            }
        }

        // --- ORIGINAL SHOWS & 30 FOR 30 ---
        item {
            SectionHeader(title = "ESPN+ ORIGINALS & 30 FOR 30", badgeText = "4K HDR")
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(SportsRepository.originalShows, key = { it.id }) { show ->
                    OriginalShowCard(
                        show = show,
                        onClick = { onSelectShow(show) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeHeaderBar(
    onOpenAskSports: () -> Unit,
    onOpenMultiview: () -> Unit,
    onOpenDevControl: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title & Tagline
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_app_icon),
                contentDescription = "ESPN+ NEXT",
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "ESPN+",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = NeonSportsRed
                        )
                    )
                    Text(
                        text = " NEXT",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = TextWhitePrimary
                        )
                    )
                }
                Text(
                    text = "THE DEFINITIVE DIGITAL HOME FOR SPORT",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 8.sp,
                        letterSpacing = 0.8.sp,
                        color = TextMutedSlate
                    )
                )
            }
        }

        // Quick Action Action Buttons (Ask AI, Multiview, Control Room)
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Multiview Button
            IconButton(
                onClick = onOpenMultiview,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(SurfaceElevated)
                    .border(1.dp, SurfaceBorderHighlight, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.GridView,
                    contentDescription = "Multiview",
                    tint = TextWhitePrimary,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Ask AI Assistant Button
            IconButton(
                onClick = onOpenAskSports,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFDDE5D7))
                    .border(1.dp, Color(0xFF818C78), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Ask Sports AI",
                    tint = Color(0xFF1D192B),
                    modifier = Modifier.size(18.dp)
                )
            }

            // Dev Broadcast Control Room Button
            IconButton(
                onClick = onOpenDevControl,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(SurfaceElevated)
                    .border(1.dp, NeonAmberGold.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Control Room",
                    tint = NeonAmberGold,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun HomeCinematicHero(
    game: Game,
    onWatch: () -> Unit,
    onAskAi: () -> Unit,
    onMultiview: () -> Unit
) {
    val heroImageRes = when (game.sport) {
        SportType.BASKETBALL -> R.drawable.img_hero_basketball
        SportType.FOOTBALL -> R.drawable.img_hero_football
        SportType.SOCCER -> R.drawable.img_hero_soccer
        SportType.RACING -> R.drawable.img_hero_racing
        else -> R.drawable.img_hero_basketball
    }

    ShinyCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        onClick = onWatch
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Hero Image with Gradient Overlay & Live Badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(10.dp))
            ) {
                Image(
                    painter = painterResource(id = heroImageRes),
                    contentDescription = "Featured Live Stream",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(HeroGradientOverlay)
                )

                // Top badges: Live indicator & Game Heat
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LivePillBadge(isUltra4K = true)
                        SportBadge(sport = game.sport)
                    }
                    GameHeatBadge(heatScore = game.heatScore)
                }

                // Middle/Bottom of image: Large cinematic live score display
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "${game.homeTeam.name.uppercase()} vs ${game.awayTeam.name.uppercase()}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = Color.White
                        )
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${game.homeTeam.shortCode} ${game.homeScore} — ${game.awayTeam.shortCode} ${game.awayScore}",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                color = NeonAmberGold
                            )
                        )

                        Text(
                            text = "• ${game.period} ${game.clock}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }
            }

            // Headline description
            Text(
                text = game.headline.ifBlank { "Live Championship action streaming exclusively in 4K HDR." },
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSilverSecondary),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            // Primary Call to Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onWatch,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonSportsRed,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Watch Live",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "WATCH LIVE 4K",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Black)
                    )
                }

                OutlinedButton(
                    onClick = onAskAi,
                    modifier = Modifier.height(44.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = TextWhitePrimary
                    ),
                    border = BorderStroke(1.dp, SurfaceBorderHighlight),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Ask AI",
                        tint = NeonAmberGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ASK AI",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                OutlinedButton(
                    onClick = onMultiview,
                    modifier = Modifier.height(44.dp),
                    border = BorderStroke(1.dp, SurfaceBorderHighlight),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhitePrimary),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.GridView,
                        contentDescription = "Multiview",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SportsRadarSection(
    liveGames: List<Game>,
    onSelectGame: (Game) -> Unit
) {
    ShinyCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = "📡", fontSize = 14.sp)
                    Text(
                        text = "SPORTS RADAR",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.8.sp,
                            color = ElectricCyan
                        )
                    )
                }

                Text(
                    text = "REAL-TIME ENGINE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = TextMutedSlate
                    )
                )
            }

            // Radar Metrics Grid (Live Streams, High Heat, Close Finishes)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RadarMetricTile(
                    modifier = Modifier.weight(1f),
                    title = "LIVE NOW",
                    value = "${liveGames.size} GAMES",
                    subtext = "Active Broadcasts",
                    accentColor = NeonSportsRed
                )
                RadarMetricTile(
                    modifier = Modifier.weight(1f),
                    title = "HIGH HEAT",
                    value = "${liveGames.count { it.heatScore >= 90 }} GAMES",
                    subtext = "Heat Score > 90",
                    accentColor = HighHeatOrange
                )
                RadarMetricTile(
                    modifier = Modifier.weight(1f),
                    title = "CLOSE BATTLES",
                    value = "${liveGames.count { Math.abs(it.homeScore - it.awayScore) <= 3 }} GAMES",
                    subtext = "Within 1 Possession",
                    accentColor = NeonAmberGold
                )
            }
        }
    }
}

@Composable
private fun RadarMetricTile(
    title: String,
    value: String,
    subtext: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceElevated)
            .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    color = TextSilverSecondary
                )
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Black,
                    color = accentColor
                )
            )
            Text(
                text = subtext,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    color = TextMutedSlate
                ),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun LiveStreamCard(
    game: Game,
    onClick: () -> Unit
) {
    ShinyCard(
        modifier = Modifier
            .width(260.dp),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Mini Simulated Broadcast Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                SimulatedBroadcastView(
                    game = game,
                    showHud = false
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                ) {
                    LivePillBadge()
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                ) {
                    GameHeatBadge(heatScore = game.heatScore)
                }
            }

            // Teams & Live Score
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${game.homeTeam.shortCode} vs ${game.awayTeam.shortCode}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = TextWhitePrimary
                        )
                    )
                    Text(
                        text = "${game.period} • ${game.clock}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = NeonAmberGold
                        )
                    )
                }

                Text(
                    text = "${game.homeScore} - ${game.awayScore}",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        color = TextWhitePrimary
                    )
                )
            }
        }
    }
}

@Composable
private fun MyTeamsQuickRail(
    onSelectTeam: (Team) -> Unit,
    onSelectPlayer: (Player) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(listOf(SportsRepository.teamBoston, SportsRepository.teamKCCity, SportsRepository.teamLondon)) { team ->
            ShinyCard(
                modifier = Modifier.width(180.dp),
                onClick = { onSelectTeam(team) }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = team.shortCode,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = Color(team.primaryColor)
                            )
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(SurfaceElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = team.recordFormatted,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhitePrimary
                                )
                            )
                        }
                    }

                    Text(
                        text = team.name,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhitePrimary
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = "Next: Friday 7:30 PM",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSilverSecondary
                        )
                    )
                }
            }
        }

        // Fantasy Player Star Tile
        item {
            val star = SportsRepository.playerJackCarter
            ShinyCard(
                modifier = Modifier.width(200.dp),
                onClick = { onSelectPlayer(star) },
                borderColor = Color(0x66FFD700)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⭐ FANTASY STAR",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonAmberGold
                            )
                        )
                        Text(
                            text = "48.6 FP",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = StadiumGreen
                            )
                        )
                    }
                    Text(
                        text = star.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhitePrimary
                        )
                    )
                    Text(
                        text = "34 PTS • 9 AST • 7 REB",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = TextSilverSecondary
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun NewsHighlightCard(
    story: NewsStory,
    onClick: () -> Unit
) {
    ShinyCard(
        modifier = Modifier.width(260.dp),
        onClick = onClick
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (story.isBreaking) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(NeonSportsRed)
                        )
                        Text(
                            text = "BREAKING",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = NeonSportsRed
                            )
                        )
                    }
                } else {
                    Text(
                        text = story.category.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSilverSecondary
                        )
                    )
                }

                Text(
                    text = story.timestamp,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextMutedSlate
                    )
                )
            }

            Text(
                text = story.headline,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextWhitePrimary
                ),
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = story.summary,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextSilverSecondary
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun OriginalShowCard(
    show: OriginalShow,
    onClick: () -> Unit
) {
    ShinyCard(
        modifier = Modifier.width(220.dp),
        onClick = onClick
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF3A4034), Color(0xFF5A6354))
                        )
                    )
                    .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text(
                        text = "30 FOR 30",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = Color(0xFFDDE5D7)
                        )
                    )
                    Text(
                        text = show.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            color = Color.White
                        )
                    )
                    Text(
                        text = show.category,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFFFAF7F2)
                        )
                    )
                }
            }

            Text(
                text = show.subtitle,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = TextSilverSecondary
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    badgeText: String? = null,
    isLive: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (isLive) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(HighHeatOrange)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    color = TextWhitePrimary
                )
            )
        }

        if (badgeText != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, SurfaceBorderHighlight, RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isLive) HighHeatOrange else NeonSportsRed
                    )
                )
            }
        }
    }
}
