package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.SportsRepository
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun SportsHubScreen(
    onSelectTeam: (Team) -> Unit,
    onSelectPlayer: (Player) -> Unit,
    onSelectGame: (Game) -> Unit
) {
    var selectedSport by remember { mutableStateOf(SportType.BASKETBALL) }
    var selectedTab by remember { mutableStateOf("STANDINGS") } // "STANDINGS", "SCHEDULE", "TEAMS", "LEADERS"

    val currentLeague = SportsRepository.leagues.find { it.sport == selectedSport } ?: SportsRepository.leagues.first()
    val sportTeams = SportsRepository.allTeams.filter { it.sport == selectedSport }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("sports_hub_screen")
    ) {
        // Top Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "SPORTS & LEAGUE HUBS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    color = TextWhitePrimary
                )
            )
            Text(
                text = "OFFICIAL TELEMETRY, ROSTERS & STANDINGS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedSlate
                )
            )
        }

        // Sport Selector Bar
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(SportType.values()) { sport ->
                val isSelected = sport == selectedSport
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFF818C78) else SurfaceBorder,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedSport = sport }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = sport.iconLabel, fontSize = 12.sp)
                        Text(
                            text = sport.displayName.uppercase(),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // League Overview Banner
        ShinyCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = currentLeague.name.uppercase(),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = TextWhitePrimary
                        )
                    )
                    Text(
                        text = "Season ${currentLeague.season} • 30 Franchises",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextSilverSecondary
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(currentLeague.colorHex).copy(alpha = 0.15f))
                        .border(1.dp, Color(currentLeague.colorHex), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = currentLeague.shortName,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(currentLeague.colorHex)
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Subtabs: STANDINGS, TEAMS, LEADERS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("STANDINGS", "TEAMS", "LEADERS").forEach { tab ->
                val isSelected = tab == selectedTab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFF818C78) else SurfaceBorder,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedTab = tab }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = tab,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content Area
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (selectedTab) {
                "STANDINGS" -> {
                    item {
                        ShinyCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                // Standings Table Header
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "FRANCHISE",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextMutedSlate
                                        ),
                                        modifier = Modifier.weight(1.8f)
                                    )
                                    Text(
                                        text = "W-L",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextMutedSlate,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "PCT",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextMutedSlate,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "STRK",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextMutedSlate,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.End
                                        ),
                                        modifier = Modifier.weight(0.8f)
                                    )
                                }

                                Divider(color = SurfaceBorder)

                                // Rows
                                sportTeams.sortedBy { it.standingRank }.forEach { team ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onSelectTeam(team) }
                                            .padding(vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1.8f),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                text = "${team.standingRank}",
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    fontWeight = FontWeight.Black,
                                                    color = if (team.standingRank <= 3) NeonAmberGold else TextSilverSecondary
                                                )
                                            )
                                            Text(
                                                text = team.name,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = TextWhitePrimary
                                                ),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        Text(
                                            text = team.recordFormatted,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = TextWhitePrimary,
                                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )

                                        val pct = String.format(java.util.Locale.US, ".%03d", (team.winRecord * 1000) / (team.winRecord + team.lossRecord).coerceAtLeast(1))
                                        Text(
                                            text = pct,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontFamily = FontFamily.Monospace,
                                                color = TextSilverSecondary,
                                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )

                                        Text(
                                            text = team.streak,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (team.streak.startsWith("W")) StadiumGreen else NeonSportsRed,
                                                textAlign = androidx.compose.ui.text.style.TextAlign.End
                                            ),
                                            modifier = Modifier.weight(0.8f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                "TEAMS" -> {
                    items(sportTeams) { team ->
                        ShinyCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onSelectTeam(team) }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(team.primaryColor)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = team.shortCode,
                                            style = MaterialTheme.typography.labelLarge.copy(
                                                fontWeight = FontWeight.Black,
                                                color = Color.White
                                            )
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = team.name,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = TextWhitePrimary
                                            )
                                        )
                                        Text(
                                            text = "${team.venueName} • Rank #${team.standingRank}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = TextSilverSecondary
                                            )
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.ChevronRight,
                                    contentDescription = "Open Team",
                                    tint = TextMutedSlate
                                )
                            }
                        }
                    }
                }
                "LEADERS" -> {
                    item {
                        LeaderCard(
                            category = "POINTS PER GAME",
                            leaderName = "Marcus Vance (NY Titans)",
                            statValue = "31.2 PPG",
                            onClick = { onSelectPlayer(SportsRepository.playerMarcusVance) }
                        )
                    }
                    item {
                        LeaderCard(
                            category = "ASSISTS PER GAME",
                            leaderName = "Jack Carter (Boston Comets)",
                            statValue = "8.6 APG",
                            onClick = { onSelectPlayer(SportsRepository.playerJackCarter) }
                        )
                    }
                    item {
                        LeaderCard(
                            category = "CHAMPIONS LEAGUE GOALS",
                            leaderName = "Liam Sterling (London Apex)",
                            statValue = "22 GOALS",
                            onClick = { onSelectPlayer(SportsRepository.playerLiamSterling) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LeaderCard(
    category: String,
    leaderName: String,
    statValue: String,
    onClick: () -> Unit
) {
    ShinyCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = category,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Black,
                        color = NeonAmberGold,
                        letterSpacing = 0.5.sp
                    )
                )
                Text(
                    text = leaderName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextWhitePrimary
                    )
                )
            }

            Text(
                text = statValue,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    color = TextWhitePrimary
                )
            )
        }
    }
}
