package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Game
import com.example.data.model.GameStatus
import com.example.data.model.SportType
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ScoresScreen(
    games: List<Game>,
    onSelectGame: (Game) -> Unit
) {
    var selectedFilter by remember { mutableStateOf("TODAY") }
    var selectedSport by remember { mutableStateOf<SportType?>(null) }

    val filterTabs = listOf("ALL", "MY SPORTS", "TODAY", "LIVE NOW", "UPCOMING", "FINAL")

    val filteredGames = games.filter { game ->
        val matchesTab = when (selectedFilter) {
            "ALL" -> true
            "MY SPORTS" -> game.homeTeam.shortCode in listOf("BOS", "KC", "LON", "NY") || game.awayTeam.shortCode in listOf("BOS", "KC", "LON", "NY")
            "TODAY" -> true
            "LIVE NOW" -> game.status == GameStatus.LIVE
            "UPCOMING" -> game.status == GameStatus.SCHEDULED
            "FINAL" -> game.status == GameStatus.FINAL
            else -> true
        }
        val matchesSport = selectedSport == null || game.sport == selectedSport
        matchesTab && matchesSport
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("scores_screen")
    ) {
        // Top Header
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "REAL-TIME SCORES",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp,
                    color = TextWhitePrimary
                )
            )
            Text(
                text = "LIVE LATENCY < 50MS • TICKER DATA AUTHORITATIVE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedSlate
                )
            )
        }

        // Filter Tabs
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filterTabs) { tab ->
                val isSelected = tab == selectedFilter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFF818C78) else SurfaceBorder,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedFilter = tab }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = tab,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sport Filter Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selectedSport == null) Color(0xFFDDE5D7) else SurfaceElevated)
                        .border(1.dp, if (selectedSport == null) Color(0xFF818C78) else SurfaceBorder, RoundedCornerShape(12.dp))
                        .clickable { selectedSport = null }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "ALL SPORTS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (selectedSport == null) Color(0xFF1D192B) else TextSilverSecondary
                        )
                    )
                }
            }
            items(SportType.values()) { sport ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selectedSport == sport) Color(0xFFDDE5D7) else SurfaceElevated)
                        .border(1.dp, if (selectedSport == sport) Color(0xFF818C78) else SurfaceBorder, RoundedCornerShape(12.dp))
                        .clickable { selectedSport = sport }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${sport.iconLabel} ${sport.displayName.uppercase()}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (selectedSport == sport) Color(0xFF1D192B) else TextSilverSecondary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Main Scores Grid
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredGames, key = { it.id }) { game ->
                ScoreBoardWidget(
                    game = game,
                    onClick = { onSelectGame(game) }
                )
            }
        }
    }
}
