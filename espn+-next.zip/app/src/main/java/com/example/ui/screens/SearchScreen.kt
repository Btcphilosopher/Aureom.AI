package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.SportsRepository
import com.example.ui.components.ShinyCard
import com.example.ui.theme.*

@Composable
fun SearchScreen(
    onSelectGame: (Game) -> Unit,
    onSelectTeam: (Team) -> Unit,
    onSelectPlayer: (Player) -> Unit,
    onSelectShow: (OriginalShow) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val searchResults = remember(searchQuery) {
        SportsRepository.searchAll(searchQuery)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("search_screen")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "SEARCH & DISCOVER",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = TextWhitePrimary
                )
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search games, teams, players, shows...", color = TextMutedSlate) },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF818C78)) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = TextSilverSecondary)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceElevated),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF818C78),
                    unfocusedBorderColor = SurfaceBorder,
                    focusedTextColor = TextWhitePrimary,
                    unfocusedTextColor = TextWhitePrimary
                ),
                singleLine = true
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (searchResults.totalMatches == 0 && searchQuery.isNotBlank()) {
                item {
                    ShinyCard(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "No results found for \"$searchQuery\". Try searching 'Carter', 'Boston', 'Formula', or 'London'.",
                            color = TextSilverSecondary
                        )
                    }
                }
            } else {
                // Games
                if (searchResults.games.isNotEmpty()) {
                    item {
                        Text(text = "MATCHES & BROADCASTS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black, color = TextMutedSlate))
                    }
                    items(searchResults.games, key = { it.id }) { game ->
                        ShinyCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onSelectGame(game) }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${game.sport.displayName.uppercase()} • ${game.period}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = NeonSportsRed)
                                    )
                                    Text(
                                        text = "${game.homeTeam.name} vs ${game.awayTeam.name}",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextWhitePrimary)
                                    )
                                }
                                Text(
                                    text = "${game.homeScore} - ${game.awayScore}",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = NeonAmberGold)
                                )
                            }
                        }
                    }
                }

                // Teams
                if (searchResults.teams.isNotEmpty()) {
                    item {
                        Text(text = "TEAMS & FRANCHISES", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black, color = TextMutedSlate))
                    }
                    items(searchResults.teams, key = { it.id }) { team ->
                        ShinyCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onSelectTeam(team) }
                        ) {
                            Column {
                                Text(
                                    text = team.sport.displayName.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = NeonAmberGold)
                                )
                                Text(
                                    text = team.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextWhitePrimary)
                                )
                            }
                        }
                    }
                }

                // Players
                if (searchResults.players.isNotEmpty()) {
                    item {
                        Text(text = "ATHLETES & DRIVERS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black, color = TextMutedSlate))
                    }
                    items(searchResults.players, key = { it.id }) { player ->
                        ShinyCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onSelectPlayer(player) }
                        ) {
                            Column {
                                Text(
                                    text = "#${player.jerseyNumber} • ${player.position}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = NeonAmberGold)
                                )
                                Text(
                                    text = player.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextWhitePrimary)
                                )
                            }
                        }
                    }
                }

                // Shows
                if (searchResults.shows.isNotEmpty()) {
                    item {
                        Text(text = "ESPN+ ORIGINALS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black, color = TextMutedSlate))
                    }
                    items(searchResults.shows, key = { it.id }) { show ->
                        ShinyCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onSelectShow(show) }
                        ) {
                            Column {
                                Text(
                                    text = show.category.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = NeonSportsRed)
                                )
                                Text(
                                    text = show.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextWhitePrimary)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
