package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Player
import com.example.data.model.Team
import com.example.data.repository.SportsRepository
import com.example.ui.components.ShinyCard
import com.example.ui.theme.*

@Composable
fun MySportsScreen(
    onSelectTeam: (Team) -> Unit,
    onSelectPlayer: (Player) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("my_sports_screen")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "MY SPORTS & FANTASY",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = TextWhitePrimary
                )
            )
            Text(
                text = "CUSTOM FEEDS • FANTASY TRACKER • ALERTS",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedSlate
                )
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live Fantasy Summary Card
            item {
                ShinyCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = NeonAmberGold.copy(alpha = 0.6f)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🏆 FANTASY LEAGUE LIVE",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = NeonAmberGold
                                )
                            )
                            Text(
                                text = "WEEK 18 • MATCHUP #4",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = TextSilverSecondary
                                )
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Apex Predators (You)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text("134.8 PTS (Proj: 142.0)", style = MaterialTheme.typography.bodyMedium.copy(color = StadiumGreen))
                            }
                            Text("vs", style = MaterialTheme.typography.labelSmall.copy(color = TextMutedSlate))
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Gotham Knights", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text("118.2 PTS (Proj: 129.5)", style = MaterialTheme.typography.bodyMedium.copy(color = TextSilverSecondary))
                            }
                        }
                    }
                }
            }

            // Followed Teams Section
            item {
                Text(
                    text = "FAVORITE TEAMS",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = TextWhitePrimary
                    )
                )
            }

            items(listOf(SportsRepository.teamBoston, SportsRepository.teamKCCity, SportsRepository.teamLondon)) { team ->
                ShinyCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onSelectTeam(team) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(team.primaryColor)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = team.shortCode,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                )
                            }
                            Column {
                                Text(text = team.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text(text = "Next: Friday 7:30 PM • Live Game Alerts On", style = MaterialTheme.typography.labelSmall.copy(color = TextSilverSecondary))
                            }
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Open", tint = TextMutedSlate)
                    }
                }
            }

            // Followed Star Athletes
            item {
                Text(
                    text = "TRACKED ATHLETES",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = TextWhitePrimary
                    )
                )
            }

            items(listOf(SportsRepository.playerJackCarter, SportsRepository.playerMarcusVance, SportsRepository.playerLiamSterling)) { player ->
                ShinyCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onSelectPlayer(player) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = player.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text(text = "${player.position} • 48.6 Fantasy Avg", style = MaterialTheme.typography.labelSmall.copy(color = TextSilverSecondary))
                        }
                        Icon(imageVector = Icons.Default.Star, contentDescription = "Star", tint = NeonAmberGold)
                    }
                }
            }
        }
    }
}
