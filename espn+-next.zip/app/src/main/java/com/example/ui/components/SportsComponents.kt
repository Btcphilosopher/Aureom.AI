package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Game
import com.example.data.model.GameStatus
import com.example.data.model.SportType
import com.example.data.model.Team
import com.example.ui.theme.*

// --- LUXURY SHINY CARD ---
@Composable
fun ShinyCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    shape: RoundedCornerShape = RoundedCornerShape(20.dp),
    backgroundColor: Color = SurfaceObsidian,
    borderColor: Color = SurfaceBorder,
    borderWidth: Dp = 1.dp,
    hasShine: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "shine")
    val shineOffset by infiniteTransition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shineOffset"
    )

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        backgroundColor,
                        backgroundColor.copy(alpha = 0.96f),
                        Color(0xFFFAF7F2)
                    )
                ),
                shape = shape
            )
            .border(
                border = BorderStroke(
                    borderWidth,
                    Brush.linearGradient(
                        colors = listOf(
                            borderColor,
                            Color(0xFFDDE5D7),
                            borderColor.copy(alpha = 0.7f)
                        )
                    )
                ),
                shape = shape
            )
            .then(
                if (hasShine) {
                    Modifier.drawBehind {
                        val width = size.width
                        val x = shineOffset * width
                        drawLine(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0x30FFFFFF),
                                    Color.Transparent
                                ),
                                start = Offset(x - 80f, 0f),
                                end = Offset(x + 80f, size.height)
                            ),
                            start = Offset(x - 80f, 0f),
                            end = Offset(x + 80f, size.height),
                            strokeWidth = 40f
                        )
                    }
                } else Modifier
            )
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            )
            .padding(16.dp),
        content = content
    )
}

// --- PULSING LIVE BADGE ---
@Composable
fun LivePillBadge(
    modifier: Modifier = Modifier,
    label: String = "LIVE",
    isUltra4K: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "livePulse")
    val alphaGlow by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        HighHeatOrange,
                        Color(0xFFB85D43)
                    )
                )
            )
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = alphaGlow))
        )
        Text(
            text = if (isUltra4K) "$label 4K" else label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = Color.White
            )
        )
    }
}

// --- GAME HEAT GAUGE ---
@Composable
fun GameHeatBadge(
    heatScore: Int,
    modifier: Modifier = Modifier
) {
    val isHighHeat = heatScore >= 90
    val badgeColor = if (isHighHeat) HighHeatOrange else NeonAmberGold

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF3ECE0))
            .border(1.dp, badgeColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(horizontal = 7.dp, vertical = 2.5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(
            text = "🔥",
            fontSize = 10.sp
        )
        Text(
            text = "$heatScore HEAT",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.ExtraBold,
                color = badgeColor
            )
        )
    }
}

// --- SPORT BADGE ICON ---
@Composable
fun SportBadge(
    sport: SportType,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceElevated)
            .border(1.dp, SurfaceBorderHighlight, RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(text = sport.iconLabel, fontSize = 10.sp)
        Text(
            text = sport.displayName.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = TextSilverSecondary,
                letterSpacing = 0.5.sp
            )
        )
    }
}

// --- ANIMATED SCORE BOARD TILE ---
@Composable
fun ScoreBoardWidget(
    game: Game,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    ShinyCard(
        modifier = modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: League, Period, Clock, Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SportBadge(sport = game.sport)
                    if (game.status == GameStatus.LIVE) {
                        LivePillBadge()
                    } else if (game.status == GameStatus.FINAL) {
                        Text(
                            text = "FINAL",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextMutedSlate
                            )
                        )
                    } else {
                        Text(
                            text = game.startTimeFormatted,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NeonAmberGold
                            )
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (game.status == GameStatus.LIVE) {
                        GameHeatBadge(heatScore = game.heatScore)
                        Text(
                            text = "${game.period} • ${game.clock}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TextWhitePrimary
                            )
                        )
                    }
                }
            }

            // Teams and Animated Scores
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TeamScoreRow(
                    team = game.homeTeam,
                    score = game.homeScore,
                    isPossession = game.possession == game.homeTeam.shortCode && game.status == GameStatus.LIVE,
                    isLive = game.status == GameStatus.LIVE
                )
                TeamScoreRow(
                    team = game.awayTeam,
                    score = game.awayScore,
                    isPossession = game.possession == game.awayTeam.shortCode && game.status == GameStatus.LIVE,
                    isLive = game.status == GameStatus.LIVE
                )
            }

            // Subtitle info: Network / Venue / Down & Distance
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = game.downDistance ?: game.headline.ifBlank { game.venue },
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextSilverSecondary
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = game.broadcastNetwork,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF64B5F6)
                    )
                )
            }
        }
    }
}

@Composable
private fun TeamScoreRow(
    team: Team,
    score: Int,
    isPossession: Boolean,
    isLive: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Team primary color pill
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(20.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(team.primaryColor))
            )

            Text(
                text = team.shortCode,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            )

            Text(
                text = team.name,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Medium,
                    color = TextWhitePrimary
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (isPossession) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(NeonAmberGold)
                )
            }
        }

        // Animated Score Counter
        AnimatedContent(
            targetState = score,
            transitionSpec = {
                slideInVertically { height -> height } + fadeIn() togetherWith
                        slideOutVertically { height -> -height } + fadeOut()
            },
            label = "scoreFlip"
        ) { targetScore ->
            Text(
                text = if (isLive || targetScore > 0) targetScore.toString() else "-",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp,
                    color = if (isPossession) NeonAmberGold else TextWhitePrimary
                )
            )
        }
    }
}

// --- REALISTIC VIDEO STREAM HUD SIMULATION ---
@Composable
fun SimulatedBroadcastView(
    game: Game,
    modifier: Modifier = Modifier,
    isMuted: Boolean = false,
    isPlaying: Boolean = true,
    showHud: Boolean = true,
    onTogglePlay: () -> Unit = {},
    onToggleMute: () -> Unit = {},
    onToggleFullscreen: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "stadiumLight")
    val sweepX by infiniteTransition.animateFloat(
        initialValue = -0.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "lightSweep"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF090A0F))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp))
    ) {
        // Dynamic broadcast canvas with stadium spotlights & pitch visual simulation
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Gradient pitch/court background based on sport
            val courtBaseColor = when (game.sport) {
                SportType.BASKETBALL -> Color(0xFF1E1308) // Dark mahogany polished court
                SportType.FOOTBALL -> Color(0xFF0B1A0E) // Night turf green
                SportType.SOCCER -> Color(0xFF081C10) // Grand stadium pitch
                SportType.RACING -> Color(0xFF0F1014) // Asphalt circuit
                SportType.TENNIS -> Color(0xFF09142A) // Hard court midnight blue
                else -> Color(0xFF12141A)
            }

            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(
                        courtBaseColor.copy(alpha = 0.9f),
                        Color(0xFF050608)
                    ),
                    center = Offset(width * 0.5f, height * 0.4f),
                    radius = width * 0.7f
                )
            )

            // Dynamic floodlight cone
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0x30FFFFFF),
                        Color.Transparent
                    ),
                    center = Offset(width * sweepX, height * 0.2f),
                    radius = width * 0.4f
                )
            )

            // Court / Field Markings (simulated broadcast lines)
            val lineColor = Color(0x20FFFFFF)
            drawLine(
                color = lineColor,
                start = Offset(width * 0.1f, height * 0.8f),
                end = Offset(width * 0.9f, height * 0.8f),
                strokeWidth = 2f
            )
            drawLine(
                color = lineColor,
                start = Offset(width * 0.5f, height * 0.1f),
                end = Offset(width * 0.5f, height * 0.9f),
                strokeWidth = 2f
            )
            drawCircle(
                color = lineColor,
                center = Offset(width * 0.5f, height * 0.5f),
                radius = height * 0.25f,
                style = Stroke(width = 2f)
            )
        }

        // Overlay: Top Left Live Scoreboard HUD Bug
        if (showHud) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
            ) {
                BroadcastScoreBug(game = game)
            }

            // Top Right: Broadcast Logo & Quality
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = game.qualityTag,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xCCFFFFFF),
                        fontFamily = FontFamily.Monospace
                    ),
                    modifier = Modifier
                        .background(Color(0x80000000), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
                LivePillBadge(isUltra4K = true)
            }

            // Bottom Player Quick Controls Bar
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color(0xCC000000))
                        )
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onTogglePlay,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = onToggleMute,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            contentDescription = "Mute",
                            tint = if (isMuted) Color(0xFFFF5252) else Color.White
                        )
                    }

                    Text(
                        text = "LIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = NeonSportsRed
                        )
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleFullscreen,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fullscreen,
                            contentDescription = "Fullscreen",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

// --- BROADCAST SCORE BUG OVERLAY ---
@Composable
fun BroadcastScoreBug(
    game: Game,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xF2FFFFFF))
            .border(1.dp, Color(0xFFE7E0EC), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Home Team
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(Color(game.homeTeam.primaryColor))
            )
            Text(
                text = game.homeTeam.shortCode,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = TextWhitePrimary
                )
            )
            Text(
                text = "${game.homeScore}",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    color = TextWhitePrimary
                )
            )
        }

        Text(
            text = "vs",
            style = MaterialTheme.typography.labelSmall.copy(color = TextMutedSlate)
        )

        // Away Team
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(Color(game.awayTeam.primaryColor))
            )
            Text(
                text = game.awayTeam.shortCode,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = TextWhitePrimary
                )
            )
            Text(
                text = "${game.awayScore}",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    color = TextWhitePrimary
                )
            )
        }

        // Period & Clock
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFDDE5D7))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = "${game.period} ${game.clock}",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1D192B)
                )
            )
        }
    }
}

// --- STAT PROGRESS BAR ---
@Composable
fun ComparisonStatBar(
    title: String,
    homeValue: String,
    awayValue: String,
    homeRatio: Float,
    homeColor: Color = NeonSportsRed,
    awayColor: Color = NeonAmberGold,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = homeValue,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextWhitePrimary
                )
            )
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextSilverSecondary,
                    letterSpacing = 0.5.sp
                )
            )
            Text(
                text = awayValue,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextWhitePrimary
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(SurfaceElevated)
        ) {
            Row(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(homeRatio.coerceIn(0.05f, 0.95f))
                        .background(homeColor)
                )
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight((1f - homeRatio).coerceIn(0.05f, 0.95f))
                        .background(awayColor)
                )
            }
        }
    }
}
