package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// --- NATURAL TONES PALETTE ---
// Warm organic canvas & surfaces
val CanvasPureBlack = Color(0xFFF7F2EA) // Primary Warm Sand/Cream Background
val CanvasDeepDark = Color(0xFFEFE9DF) // Secondary Warm Linen
val SurfaceObsidian = Color(0xFFFFFFFF) // Crisp Pure White Card Surface
val SurfaceElevated = Color(0xFFF0F4EF) // Soft Botanical Sage Container
val SurfaceBorder = Color(0xFFE7E0EC) // Delicate Warm Outline
val SurfaceBorderHighlight = Color(0xFFDDE5D7) // Sage Border Highlight

// Metallic & Organic Earth Accents
val MetalGraphite = Color(0xFFDDE5D7)
val MetalTitanium = Color(0xFF818C78)
val MetalChrome = Color(0xFFF7F2EA)
val GlassTranslucent = Color(0x66FFFFFF)
val GlassHighlight = Color(0x99FFFFFF)

// Natural Botanical & Earth Accents
val NeonSportsRed = Color(0xFF818C78) // Signature Primary Botanical Sage Green
val NeonSportsRedGlow = Color(0x33818C78)
val NeonAmberGold = Color(0xFF8B7E6B) // Warm Earth Ochre / Sandstone
val ElectricCyan = Color(0xFF5A6354) // Deep Moss Forest
val StadiumGreen = Color(0xFF43603F) // Lush Botanical Green
val HighHeatOrange = Color(0xFFC86D51) // Warm Earth Terracotta

// Typography Colors (High contrast on Cream & White surfaces)
val TextWhitePrimary = Color(0xFF1C1B1F) // Deep Charcoal
val TextSilverSecondary = Color(0xFF49454F) // Medium Warm Charcoal
val TextMutedSlate = Color(0xFF7A757F) // Soft Earth Slate

// Natural Gradient Brushes
val HeroGradientOverlay = Brush.verticalGradient(
    colors = listOf(
        Color.Transparent,
        Color(0x66F7F2EA),
        Color(0xFFF7F2EA)
    )
)

val CardShineGradient = Brush.linearGradient(
    colors = listOf(
        Color(0x00FFFFFF),
        Color(0x40FFFFFF),
        Color(0x00FFFFFF)
    )
)

val RedEnergyGlowBrush = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFF818C78),
        Color(0xFFA2AD9B)
    )
)

val GoldenLeaderBrush = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFF8B7E6B),
        Color(0xFFA89B88)
    )
)


