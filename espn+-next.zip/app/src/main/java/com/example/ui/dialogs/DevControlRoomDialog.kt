package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Game
import com.example.data.simulator.LiveGameSimulator
import com.example.ui.components.ShinyCard
import com.example.ui.theme.*

@Composable
fun DevControlRoomDialog(
    games: List<Game>,
    onDismiss: () -> Unit
) {
    val isRunning by LiveGameSimulator.isSimulationRunning.collectAsState()
    val speed by LiveGameSimulator.speedMultiplier.collectAsState()

    var breakingHeadline by remember { mutableStateOf("BLOCKBUSTER TRADE AGREED") }
    var breakingSummary by remember { mutableStateOf("League sources confirm superstar center dealt in 4-team blockbuster.") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xE6000000))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.9f)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, Color(0xFF818C78), RoundedCornerShape(20.dp)),
                color = SurfaceObsidian
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFEDE8D0))
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "BROADCAST CONTROL ROOM",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1D192B)
                                )
                            )
                            Text(
                                text = "REAL-TIME SIMULATION & TELEMETRY ENGINE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF49454F)
                                )
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SurfaceElevated)
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextWhitePrimary)
                        }
                    }

                    // Main Controls Body
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Simulation Status & Speed
                        item {
                            ShinyCard(modifier = Modifier.fillMaxWidth()) {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "SIMULATION ENGINE",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Black,
                                                color = Color.White
                                            )
                                        )

                                        Button(
                                            onClick = { LiveGameSimulator.toggleSimulationPause() },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (isRunning) StadiumGreen else NeonSportsRed
                                            ),
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                contentDescription = "Toggle",
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(if (isRunning) "ACTIVE" else "PAUSED", fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Speed Multipliers
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Clock Speed: ", style = MaterialTheme.typography.labelSmall.copy(color = TextSilverSecondary))
                                        listOf(1, 2, 5, 10).forEach { mult ->
                                            val isSelected = mult == speed
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
                                                    .border(1.dp, if (isSelected) Color(0xFF818C78) else SurfaceBorder, RoundedCornerShape(12.dp))
                                                    .clickable { LiveGameSimulator.setSpeedMultiplier(mult) }
                                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Text(
                                                    text = "${mult}x",
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        fontWeight = FontWeight.Black,
                                                        color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                                                    )
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.weight(1f))

                                        IconButton(
                                            onClick = { LiveGameSimulator.resetGames() },
                                            modifier = Modifier.size(36.dp).clip(CircleShape).background(SurfaceElevated)
                                        ) {
                                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset", tint = TextWhitePrimary)
                                        }
                                    }
                                }
                            }
                        }

                        // Trigger Breaking News
                        item {
                            ShinyCard(
                                modifier = Modifier.fillMaxWidth(),
                                borderColor = NeonSportsRed
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "🚨 INJECT BREAKING NEWS ALERT",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Black,
                                            color = NeonSportsRed
                                        )
                                    )

                                    OutlinedTextField(
                                        value = breakingHeadline,
                                        onValueChange = { breakingHeadline = it },
                                        label = { Text("Headline") },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color(0xFF818C78),
                                            focusedTextColor = TextWhitePrimary,
                                            unfocusedTextColor = TextWhitePrimary,
                                            unfocusedBorderColor = SurfaceBorder
                                        ),
                                        singleLine = true
                                    )

                                    Button(
                                        onClick = {
                                            LiveGameSimulator.triggerBreakingNews(breakingHeadline, breakingSummary)
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonSportsRed),
                                        shape = RoundedCornerShape(20.dp)
                                    ) {
                                        Text("TRIGGER REAL-TIME ALERT", fontWeight = FontWeight.Black, color = Color.White)
                                    }
                                }
                            }
                        }

                        // Live Game Score Injections
                        item {
                            Text(
                                text = "ACTIVE BROADCASTS SCORE INJECTORS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = TextWhitePrimary
                                )
                            )
                        }

                        items(games.filter { it.status == com.example.data.model.GameStatus.LIVE }) { game ->
                            ShinyCard(modifier = Modifier.fillMaxWidth()) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${game.homeTeam.shortCode} ${game.homeScore} vs ${game.awayTeam.shortCode} ${game.awayScore}",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Black,
                                                color = TextWhitePrimary
                                            )
                                        )

                                        Button(
                                            onClick = { LiveGameSimulator.advancePeriodManual(game.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated),
                                            shape = RoundedCornerShape(12.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("ADVANCE: ${game.period}", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF818C78)))
                                        }
                                    }

                                    // Score Add Buttons
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        // Home Team Add
                                        Button(
                                            onClick = { LiveGameSimulator.triggerScoreManual(game.id, isHome = true, points = 2) },
                                            modifier = Modifier.weight(1f).height(34.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(game.homeTeam.primaryColor)),
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("+2 ${game.homeTeam.shortCode}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                        Button(
                                            onClick = { LiveGameSimulator.triggerScoreManual(game.id, isHome = true, points = 3) },
                                            modifier = Modifier.weight(1f).height(34.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(game.homeTeam.primaryColor)),
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("+3 3PT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }

                                        // Away Team Add
                                        Button(
                                            onClick = { LiveGameSimulator.triggerScoreManual(game.id, isHome = false, points = 2) },
                                            modifier = Modifier.weight(1f).height(34.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(game.awayTeam.primaryColor)),
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("+2 ${game.awayTeam.shortCode}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                        Button(
                                            onClick = { LiveGameSimulator.triggerScoreManual(game.id, isHome = false, points = 3) },
                                            modifier = Modifier.weight(1f).height(34.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(game.awayTeam.primaryColor)),
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("+3 3PT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Footer
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceElevated)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Button(
                            onClick = onDismiss,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDDE5D7)),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Text("DONE", color = Color(0xFF1D192B), fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}
