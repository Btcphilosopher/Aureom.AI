package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NewsStory
import com.example.ui.components.ShinyCard
import com.example.ui.theme.*

@Composable
fun NewsScreen(
    news: List<NewsStory>,
    selectedNews: NewsStory?,
    onSelectStory: (NewsStory) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("news_screen")
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (selectedNews != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(SurfaceElevated)
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = TextWhitePrimary)
                    }
                }
                Text(
                    text = if (selectedNews != null) "STORY REPORT" else "SPORTSCENTER NEWS",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = TextWhitePrimary
                    )
                )
            }
        }

        if (selectedNews != null) {
            // Full story reader
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    ShinyCard(modifier = Modifier.fillMaxWidth()) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = selectedNews.category.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = if (selectedNews.isBreaking) NeonSportsRed else Color(0xFF818C78)
                                    )
                                )
                                Text(
                                    text = "${selectedNews.readTimeMin} min read • ${selectedNews.timestamp}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMutedSlate)
                                )
                            }

                            Text(
                                text = selectedNews.headline,
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = TextWhitePrimary
                                )
                            )

                            Text(
                                text = "By ${selectedNews.author}",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = NeonAmberGold
                                )
                            )

                            Divider(color = SurfaceBorder)

                            Text(
                                text = selectedNews.content,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = TextWhitePrimary,
                                    lineHeight = 24.sp
                                )
                            )
                        }
                    }
                }
            }
        } else {
            // News list
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(news, key = { it.id }) { story ->
                    ShinyCard(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { onSelectStory(story) },
                        borderColor = if (story.isBreaking) NeonSportsRed.copy(alpha = 0.5f) else SurfaceBorder
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = story.category.uppercase(),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (story.isBreaking) NeonSportsRed else Color(0xFF818C78)
                                    )
                                )
                                Text(
                                    text = story.timestamp,
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMutedSlate)
                                )
                            }

                            Text(
                                text = story.headline,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhitePrimary
                                )
                            )

                            Text(
                                text = story.summary,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = TextSilverSecondary
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
