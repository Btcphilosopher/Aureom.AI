package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ShinyCard
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    onOpenDevControl: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("profile_screen")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ACCOUNT & SETTINGS",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Black,
                    color = TextWhitePrimary
                )
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // User Profile Card
            item {
                ShinyCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(NeonSportsRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "T",
                                    style = MaterialTheme.typography.headlineMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                )
                            }

                            Column {
                                Text(
                                    text = "Tom (VIP Member)",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhitePrimary
                                    )
                                )
                                Text(
                                    text = "tom@ahyx.org",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSilverSecondary)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(NeonAmberGold.copy(alpha = 0.15f))
                                .border(1.dp, NeonAmberGold, RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "VIP PASS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = NeonAmberGold
                                )
                            )
                        }
                    }
                }
            }

            // Active Subscription Tier
            item {
                ShinyCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = Color(0xFF818C78)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ESPN+ UNLIMITED 4K ALL-ACCESS",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFF1D192B)
                                )
                            )
                            Text(
                                text = "ACTIVE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = StadiumGreen
                                )
                            )
                        }

                        Text("• 4K UHD 60FPS with HDR10 & Dolby Atmos", color = TextSilverSecondary)
                        Text("• Quad Multiview simultaneous streaming enabled", color = TextSilverSecondary)
                        Text("• Live telemetry, pitlane audio & multi-angle camera feeds", color = TextSilverSecondary)
                        Text("• Ad-free DVR with unlimited cloud recording", color = TextSilverSecondary)
                    }
                }
            }

            // Developer Control Room Shortcut
            item {
                ShinyCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = onOpenDevControl,
                    borderColor = NeonAmberGold
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Tune, contentDescription = "Dev", tint = NeonAmberGold)
                            Column {
                                Text(
                                    text = "BROADCAST CONTROL ROOM",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = NeonAmberGold
                                    )
                                )
                                Text(
                                    text = "Real-time engine simulator, clock speeds & custom score injections",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSilverSecondary)
                                )
                            }
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Open", tint = NeonAmberGold)
                    }
                }
            }

            // App Build Telemetry
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "ESPN+ NEXT v4.0.0 PROD",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            color = TextMutedSlate
                        )
                    )
                    Text(
                        text = "Build 2026.08 • Antigravity Engine Core",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            color = TextMutedSlate
                        )
                    )
                }
            }
        }
    }
}
