package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Game
import com.example.data.model.GameStatus
import com.example.data.model.SportType
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun LiveScreen(
    games: List<Game>,
    onSelectGame: (Game) -> Unit,
    onOpenMultiview: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf("LIVE NOW") }
    var selectedSport by remember { mutableStateOf<SportType?>(null) }

    val categories = listOf("LIVE NOW", "STARTING SOON", "24/7 CHANNELS", "REPLAYS")

    val liveGames = games.filter { it.status == GameStatus.LIVE }
    val scheduledGames = games.filter { it.status == GameStatus.SCHEDULED }
    val finalGames = games.filter { it.status == GameStatus.FINAL }

    val filteredGames = when (selectedCategory) {
        "LIVE NOW" -> liveGames
        "STARTING SOON" -> scheduledGames
        "REPLAYS" -> finalGames
        else -> liveGames
    }.filter { selectedSport == null || it.sport == selectedSport }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("live_screen")
    ) {
        // Top Header with Multiview Callout
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LivePillBadge(isUltra4K = true)
                    Text(
                        text = "LIVE BROADCASTS",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp,
                            color = TextWhitePrimary
                        )
                    )
                }
                Text(
                    text = "ULTRA 4K HDR • MULTI-ANGLE TELEMETRY",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = FontFamily.Monospace,
                        color = TextMutedSlate
                    )
                )
            }

            Button(
                onClick = onOpenMultiview,
                colors = ButtonDefaults.buttonColors(
                    containerColor = SurfaceElevated,
                    contentColor = TextWhitePrimary
                ),
                border = BorderStroke(1.dp, SurfaceBorderHighlight),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.GridView,
                    contentDescription = "Multiview",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "MULTIVIEW",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black)
                )
            }
        }

        // Category Navigation Tabs (LIVE NOW, STARTING SOON, 24/7 CHANNELS, REPLAYS)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val isSelected = cat == selectedCategory
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFF818C78) else SurfaceBorder,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = cat,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sport Filter Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                SportPillChip(
                    label = "ALL SPORTS",
                    icon = "⚡",
                    isSelected = selectedSport == null,
                    onClick = { selectedSport = null }
                )
            }
            items(SportType.values()) { sport ->
                SportPillChip(
                    label = sport.displayName.uppercase(),
                    icon = sport.iconLabel,
                    isSelected = selectedSport == sport,
                    onClick = { selectedSport = sport }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Main Live Events Stream List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (selectedCategory == "24/7 CHANNELS") {
                item {
                    Channel24x7Tile(name = "ESPN+ 1 ULTRA", desc = "Live flagship marquee events & coverage in 4K UHD 60FPS", onSelect = {})
                }
                item {
                    Channel24x7Tile(name = "SPORTSCENTER 360", desc = "24/7 continuous breaking sports analysis, scores & highlights", onSelect = {})
                }
                item {
                    Channel24x7Tile(name = "SPEED CHANNEL PRO", desc = "Formula racing, telemetry feeds, helmet cams & pitlane audio", onSelect = {})
                }
            } else {
                items(filteredGames, key = { it.id }) { game ->
                    LiveEventExpandedCard(
                        game = game,
                        onClick = { onSelectGame(game) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SportPillChip(
    label: String,
    icon: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
            .border(
                1.dp,
                if (isSelected) Color(0xFF818C78) else SurfaceBorder,
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = icon, fontSize = 11.sp)
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                )
            )
        }
    }
}

@Composable
private fun LiveEventExpandedCard(
    game: Game,
    onClick: () -> Unit
) {
    ShinyCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SportBadge(sport = game.sport)
                    if (game.status == GameStatus.LIVE) {
                        LivePillBadge()
                    } else if (game.status == GameStatus.FINAL) {
                        Text(
                            text = "FINAL",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextMutedSlate
                            )
                        )
                    } else {
                        Text(
                            text = game.startTimeFormatted,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NeonAmberGold
                            )
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (game.status == GameStatus.LIVE) {
                        GameHeatBadge(heatScore = game.heatScore)
                    }
                    Text(
                        text = game.qualityTag,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = FontFamily.Monospace,
                            color = TextSilverSecondary
                        )
                    )
                }
            }

            // Teams & Score Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "${game.homeTeam.name} vs ${game.awayTeam.name}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhitePrimary
                        )
                    )
                    Text(
                        text = game.venue,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextSilverSecondary
                        )
                    )
                }

                if (game.status == GameStatus.LIVE) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = "${game.homeScore} - ${game.awayScore}",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Black,
                                color = NeonAmberGold
                            )
                        )
                        Text(
                            text = "${game.period} • ${game.clock}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TextWhitePrimary
                            )
                        )
                    }
                }
            }

            // Bottom Actions Bar: Watch Button, Stream Quality
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = game.broadcastNetwork,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF64B5F6)
                    )
                )

                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (game.status == GameStatus.LIVE) NeonSportsRed else SurfaceElevated,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = if (game.status == GameStatus.LIVE) Icons.Default.PlayArrow else Icons.Default.Schedule,
                        contentDescription = "Action",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (game.status == GameStatus.LIVE) "WATCH LIVE" else if (game.status == GameStatus.FINAL) "REPLAY" else "SET REMINDER",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black)
                    )
                }
            }
        }
    }
}

@Composable
private fun Channel24x7Tile(
    name: String,
    desc: String,
    onSelect: () -> Unit
) {
    ShinyCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onSelect
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LivePillBadge(isUltra4K = true)
                    Text(
                        text = name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = TextWhitePrimary
                        )
                    )
                }
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSilverSecondary)
                )
            }

            IconButton(
                onClick = onSelect,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(NeonSportsRed)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Watch Channel",
                    tint = Color.White
                )
            }
        }
    }
}
