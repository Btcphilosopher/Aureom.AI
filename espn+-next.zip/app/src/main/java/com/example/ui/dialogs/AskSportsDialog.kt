package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ai.AiSportsCompanion
import com.example.data.model.Game
import com.example.ui.theme.*

data class ChatMessage(
    val id: String,
    val sender: String, // "AI" or "USER"
    val text: String,
    val timestamp: String = "Now"
)

@Composable
fun AskSportsDialog(
    contextGame: Game?,
    onDismiss: () -> Unit
) {
    var messages by remember {
        mutableStateOf(
            listOf(
                ChatMessage(
                    id = "msg_init",
                    sender = "AI",
                    text = AiSportsCompanion.generateInitialGreeting(contextGame)
                )
            )
        )
    }

    var inputText by remember { mutableStateOf("") }

    val suggestedQuestions = if (contextGame != null) {
        listOf(
            "Who has been the best player in this game?",
            "What happened in the 3rd quarter?",
            "What are the playoff implications?",
            "Jack Carter stats today"
        )
    } else {
        listOf(
            "What should I watch right now?",
            "Which games are closest tonight?",
            "Who leads the league in scoring?",
            "Boston Comets report"
        )
    }

    fun submitQuery(query: String) {
        if (query.isBlank()) return
        val userMsg = ChatMessage(id = "usr_${System.currentTimeMillis()}", sender = "USER", text = query)
        val response = AiSportsCompanion.answerQuery(query, contextGame)
        val aiMsg = ChatMessage(id = "ai_${System.currentTimeMillis()}", sender = "AI", text = response)
        messages = messages + userMsg + aiMsg
        inputText = ""
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x66000000))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.9f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, Color(0xFF818C78), RoundedCornerShape(24.dp)),
                color = SurfaceObsidian
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Dialog Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFDDE5D7))
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI",
                                tint = Color(0xFF504838)
                            )
                            Column {
                                Text(
                                    text = if (contextGame != null) "GAME COMPANION AI" else "ASK SPORTS AI",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFF1D192B)
                                    )
                                )
                                Text(
                                    text = if (contextGame != null) "${contextGame.homeTeam.name} vs ${contextGame.awayTeam.name}" else "Real-Time Sports Intelligence",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color(0xFF49454F)
                                    )
                                )
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SurfaceElevated)
                        ) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextWhitePrimary)
                        }
                    }

                    // Chat messages list
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            val isAi = msg.sender == "AI"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = if (isAi) Arrangement.Start else Arrangement.End
                            ) {
                                Box(
                                    modifier = Modifier
                                        .widthIn(max = 300.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(if (isAi) Color(0xFFEDE8D0) else Color(0xFF818C78))
                                        .border(
                                            1.dp,
                                            if (isAi) Color(0xFFDDE5D7) else Color.Transparent,
                                            RoundedCornerShape(16.dp)
                                        )
                                        .padding(14.dp)
                                ) {
                                    Text(
                                        text = msg.text,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = if (isAi) Color(0xFF1D192B) else Color.White,
                                            lineHeight = 20.sp
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Suggested Questions Chips
                    LazyRow(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(suggestedQuestions) { q ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(SurfaceElevated)
                                    .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                                    .clickable { submitQuery(q) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = q,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = TextWhitePrimary
                                    )
                                )
                            }
                        }
                    }

                    // Input Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceElevated)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text("Ask about scores, stats, rules...", color = TextMutedSlate) },
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(SurfaceObsidian),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF818C78),
                                unfocusedBorderColor = SurfaceBorder,
                                focusedTextColor = TextWhitePrimary,
                                unfocusedTextColor = TextWhitePrimary
                            ),
                            singleLine = true
                        )

                        IconButton(
                            onClick = { submitQuery(inputText) },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF818C78))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
