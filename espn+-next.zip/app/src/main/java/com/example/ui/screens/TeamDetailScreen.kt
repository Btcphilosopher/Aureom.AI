package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Player
import com.example.data.model.Team
import com.example.data.repository.SportsRepository
import com.example.ui.components.ShinyCard
import com.example.ui.theme.*

@Composable
fun TeamDetailScreen(
    team: Team,
    onBack: () -> Unit,
    onSelectPlayer: (Player) -> Unit
) {
    var isFollowed by remember { mutableStateOf(true) }
    var selectedSection by remember { mutableStateOf("ROSTER") } // "ROSTER", "STATS", "SCHEDULE"

    val teamPlayers = SportsRepository.allPlayers.filter { it.teamId == team.id }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasPureBlack)
            .testTag("team_detail_screen")
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(SurfaceElevated)
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = TextWhitePrimary)
            }

            Button(
                onClick = { isFollowed = !isFollowed },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isFollowed) NeonSportsRed else SurfaceElevated,
                    contentColor = if (isFollowed) Color.White else TextWhitePrimary
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Icon(
                    imageVector = if (isFollowed) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Follow",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = if (isFollowed) "MY TEAM" else "FOLLOW", fontWeight = FontWeight.Black)
            }
        }

        // Team Hero Header Card
        ShinyCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            backgroundColor = Color(team.primaryColor).copy(alpha = 0.15f)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = team.city.uppercase(),
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = TextSilverSecondary,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = team.nickname,
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = TextWhitePrimary
                        )
                    )
                    Text(
                        text = "${team.venueName} • ${team.conference} Conference",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSilverSecondary)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = team.recordFormatted,
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Black,
                            color = NeonAmberGold
                        )
                    )
                    Text(
                        text = "Rank #${team.standingRank} in East",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSilverSecondary)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Navigation Tabs (ROSTER, STATS, SCHEDULE)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ROSTER", "STATS", "SCHEDULE").forEach { section ->
                val isSelected = section == selectedSection
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) Color(0xFFDDE5D7) else SurfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFF818C78) else SurfaceBorder,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { selectedSection = section }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = section,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = if (isSelected) Color(0xFF1D192B) else TextSilverSecondary
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (selectedSection) {
                "ROSTER" -> {
                    if (teamPlayers.isEmpty()) {
                        item {
                            ShinyCard(modifier = Modifier.fillMaxWidth()) {
                                Text("Full 15-man active roster updated for 2026-27 championship season.", color = TextSilverSecondary)
                            }
                        }
                    } else {
                        items(teamPlayers) { player ->
                            ShinyCard(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { onSelectPlayer(player) }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(SurfaceElevated),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = "#${player.jerseyNumber}",
                                                style = MaterialTheme.typography.labelLarge.copy(
                                                    fontWeight = FontWeight.Black,
                                                    color = NeonAmberGold
                                                )
                                            )
                                        }

                                        Column {
                                            Text(
                                                text = player.name,
                                                style = MaterialTheme.typography.titleMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = TextWhitePrimary
                                                )
                                            )
                                            Text(
                                                text = "${player.position} • ${player.height} • ${player.weight}",
                                                style = MaterialTheme.typography.labelSmall.copy(color = TextSilverSecondary)
                                            )
                                        }
                                    }

                                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "View", tint = TextMutedSlate)
                                }
                            }
                        }
                    }
                }
                "STATS" -> {
                    item {
                        ShinyCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("TEAM SEASON TOTALS", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black))
                                Text("• Points Per Game: 118.4 (2nd in League)", color = TextSilverSecondary)
                                Text("• Offensive Rating: 119.8 (1st)", color = TextSilverSecondary)
                                Text("• Defensive Rating: 110.2 (4th)", color = TextSilverSecondary)
                                Text("• Net Rating: +9.6", color = StadiumGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                "SCHEDULE" -> {
                    item {
                        ShinyCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("UPCOMING FIXTURES", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black))
                                Text("• Fri, Feb 24 vs Los Angeles Hawks (7:30 PM ET - ESPN+ ULTRA)", color = TextWhitePrimary)
                                Text("• Sun, Feb 26 @ Chicago Blaze (3:00 PM ET - ESPN+)", color = TextSilverSecondary)
                                Text("• Wed, Mar 01 vs San Francisco Vortex (8:00 PM ET - ESPN+ PRIMETIME)", color = TextSilverSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}
