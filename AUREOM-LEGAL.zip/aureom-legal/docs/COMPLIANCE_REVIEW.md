# Professional and regulatory review required before real client accounting or live use

AUREOM LEGAL is a **demonstration build with synthetic data**. It does not claim compliance certification of any kind.
Before any real client data, client money or live legal-deadline reliance is introduced, the firm must obtain review from the appropriate people and bodies.

## 1. Client money and accounting (SRA Accounts Rules context)
* The demonstration chart of accounts, journal workflow, receipts, allocations, client-to-office transfers, reconciliation and revenue-recognition steps are **illustrative**.
  A qualified legal-accounts professional (the firm's COFA / finance director / external accountants) must define the real chart of accounts, VAT treatment,
  billing and transfer rules, interest handling, residual-balance procedures, reconciliation frequency and sign-off roles.
* Confirm that separate-ledger design, four-eyes approvals, negative-client-balance prevention and audit trail meet the firm's written procedures and professional obligations.
* Bank integration is a **mock**. A real bank feed needs security review, credentials management, reconciliation design and operational runbooks; payment initiation is deliberately not implemented.
* Revenue recognition here is a labelled, manual step with a free-text basis. Accounting policy must be set by the firm's accountants.

## 2. Anti-money-laundering, identity and conflicts
* Identity "checks" are a **simulated** adapter (`passed_simulated`). They are never verified identity. Integrate a regulated provider, define risk assessment, ongoing monitoring,
  PEP/sanctions screening, record-keeping, and the MLRO's review and escalation procedure.
* Conflict search is a decision-support tool. It never declares a matter conflict-free; a human reviewer records the outcome. The matching logic (names, aliases, relationships) must be validated against the firm's real data quality and policies.

## 3. Deadlines and limitation
* Deadline rules are **illustrative configuration**, not legal advice or authoritative rules. Suggested deadlines (calculated or AI-identified) require confirmation by a responsible solicitor
  who verifies the governing rule, agreement or order, the trigger date, the calendar and any extensions. Bank-holiday data is administrator-supplied input and must be verified.

## 4. Data protection and confidentiality
* Complete a DPIA covering matter content, special-category data, retention, AI processing, international transfers and sub-processors. Define lawful bases, retention schedules,
  subject-access and erasure procedures (note legal-hold and regulatory retention interplay) and breach response.
* Retention policies shipped are defaults only; the compliance function sets real periods. Destruction is not automated.
* Confirm data residency and encryption (at rest and in transit), key management, backup locations and access reviews.

## 5. Artificial intelligence
* The default provider is a local mock: no content leaves the application. Enabling an external model requires: contractual terms (no training on firm/client data), residency review,
  client-consent analysis, sub-processor assessment, a documented list of content classes sent (see Administration → AI provider), supervision procedures and a solicitor-review standard for outputs.
* Agents are read-only by default; substantive changes need human approval bound to the exact proposal. Do not widen agent tools (sending, sharing, issuing invoices, moving money, clearing conflicts, confirming deadlines) without a formal risk assessment.
* Do not rely on AI output as legal authority. The knowledge agent searches only approved internal materials; external research requires a configured, attributed source adapter.

## 6. Security assurance
* Independent penetration test, dependency and container scanning, secrets management, SSO/MFA integration, session-policy review, backup/restore drills, logging and monitoring, incident response.
* Replace the demonstration persona picker (`DEMO_MODE`) and default secrets. Review row-level-security configuration and database role privileges in your environment.
* Malware scanning is a mock plus an integration point; connect a real scanner (e.g. ClamAV or a managed service) and block downloads when scanning is unavailable.

## 7. Professional indemnity and regulatory notifications
* Inform insurers and, where relevant, regulators about the use of new systems and outsourcing arrangements as required by the firm's compliance framework.
