# Backup and restore

AUREOM LEGAL has two stores that must be backed up **together** and restored to the same point in time:

| Store | Contents | Backup method |
|---|---|---|
| PostgreSQL | all records, extracted text, audit log, ledgers | `pg_dump` (logical) and/or WAL archiving / PITR (physical) |
| Object storage (S3/MinIO bucket) | immutable original document files, export bundles | bucket versioning + replication, or `mc mirror` / `aws s3 sync` |

Document version rows reference objects by `storage_key` and `sha256`; a restore is only consistent if every `storage_key` exists in the bucket.

## Backup (Docker Compose example)

```bash
# 1. database (custom format, compressed). Use the OWNER role; row-level security is bypassed for the owner so the dump is complete.
docker compose exec -T postgres pg_dump -U aureom -Fc aureom > backups/aureom-$(date +%F).dump

# 2. documents bucket
docker compose run --rm --entrypoint sh minio -c \
  "mc alias set local http://minio:9000 \$MINIO_ROOT_USER \$MINIO_ROOT_PASSWORD && mc mirror --overwrite local/aureom-documents /backup/documents" 
```

Production guidance: enable object-store versioning and object lock for the documents bucket (originals are write-once by design),
enable PostgreSQL WAL archiving for point-in-time recovery, encrypt backups at rest, keep them in the configured data-residency region,
and restrict access to backups as tightly as to production.

## Restore

```bash
docker compose down
docker volume rm aureom-legal_pgdata                # only when restoring into a clean database
docker compose up -d postgres
docker compose exec -T postgres pg_restore -U aureom -d aureom --clean --if-exists < backups/aureom-YYYY-MM-DD.dump
# restore the bucket contents (mc mirror in the opposite direction), then:
docker compose up -d
```

After restore:
1. Run `alembic upgrade head` (the api container does this on start).
2. **Verify the audit chain**: sign in as an administrator or compliance user → Administration → Audit log → *Verify chain*
   (or `GET /api/v1/admin/audit/verify`). `ok: true` means no audit row was altered or removed.
3. Spot-check documents: download a few versions and compare their SHA-256 with the version history.
4. Confirm the row-level-security role exists: `\du aureom_app` (created by `docker/postgres/10-app-role.sh`; recreate with `NOSUPERUSER NOBYPASSRLS` if missing, then re-run `app/db/safeguards.sql` grants by running `alembic upgrade head` on a fresh database or executing that file as the owner).

## Not covered by this demonstration
Automated scheduling, off-site replication, restore drills and RPO/RTO targets must be defined and tested by the operator before any real use.
