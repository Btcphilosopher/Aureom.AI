# Architecture

AUREOM LEGAL is a **modular monolith**: one FastAPI application with clear domain boundaries, a PostgreSQL database,
S3-compatible object storage, a database-backed background worker, and a React/TypeScript single-page frontend.

```
 Browser (React + TS + Tailwind) ──HTTPS──▶ nginx / Vite proxy ──▶ FastAPI  /api/v1/*
                                                                    │  ├─ api/      thin routers (HTTP, validation, permission deps)
                                                                    │  ├─ services/ business rules; every user action takes a Ctx
                                                                    │  ├─ agents/   AI workspace: policy layer, tools, retrieval, verifier, runner
                                                                    │  ├─ integrations/ interfaces + labelled mocks (email, calendar, e-sign, identity, bank, scan, OCR, research, SSO)
                                                                    │  └─ models/   SQLAlchemy 2.0 (63 tables)
                                                                    ├──▶ PostgreSQL 16   relational records, full-text search (tsvector/GIN), RLS, triggers
                                                                    └──▶ S3 / MinIO      immutable original document files, export bundles
 Worker process (python -m app.worker) ──▶ PostgreSQL `jobs` queue (FOR UPDATE SKIP LOCKED): malware scan, OCR/extract, index, exports, agent runs, reminders
```

## Domain modules

| Domain | Tables (selection) | Notes |
|---|---|---|
| Platform | firms, offices, teams, roles, users, sessions, audit_events, approvals, jobs, notifications, retention_policies, business_calendars | server-side sessions, hash-chained append-only audit, generic hash-bound approvals |
| Parties | contacts, contact_addresses, contact_relationships, onboarding_records/checks, conflict_searches/matches/review_events, contact_merges | roles on matters (not on contacts); simulated identity adapter; reviewed merge |
| Matters | matters, matter_parties, matter_members, matter_templates, matter_checklist_items, matter_state_events, chronology_entries | explicit state machine, restricted matters + ethical walls |
| Documents | documents, document_versions (immutable), document_chunks (FTS + citations), folders, templates, signature_requests, export_requests | write-once object storage, scan/OCR/index pipeline |
| Correspondence | correspondence, attachments, internal_notes | untrusted bodies rendered as text; internal notes kept separate |
| Tasks & diary | tasks, task_dependencies, diary_events, deadlines, deadline_rules | suggestions vs confirmed (DB CHECK) |
| Finance | rate_cards, time_entries, expenses, invoices(+lines), ledger_accounts, journals(+lines), bank_statement_lines, payments, payment_allocations, reconciliations, revenue_recognitions | Decimal money, separate office/client ledgers, DB-enforced balanced journals |
| AI | knowledge_items, agent_runs, agent_proposed_actions, agent_run_events | state machine, bound approvals, evidence log (no model reasoning) |

## Cross-cutting design decisions

* **Tenancy.** Every business table has `firm_id`. The app role is a non-superuser, non-owner role; PostgreSQL **row-level security** policies filter on the transaction-local setting `app.firm_id`, which is applied by a SQLAlchemy `after_begin` hook for every transaction of a firm-bound session. Application code also filters by firm; RLS is the safety net if a WHERE clause is forgotten. `users`, `sessions` and `jobs` are exempt (login and the worker queue must resolve a row before a tenant is known).
* **Matter-level access.** `permissions.matter_clause(ctx)` is the single SQL predicate used for lists, search, home dashboard and AI retrieval; `can_access_matter / can_preview / can_export / can_ai_retrieve` guard single records. A restricted matter needs allow-list membership (or being responsible partner/fee earner); an ethical-wall *deny* (user or team) always wins.
* **Audit.** `audit.log()` writes an append-only, SHA-256 hash-chained record in the same transaction as the change. Triggers reject UPDATE/DELETE/TRUNCATE; chain verification is exposed to auditors.
* **Optimistic concurrency.** Mutable rows carry a `version` column wired to SQLAlchemy `version_id_col`; PATCH bodies send `expected_version`; mismatch ⇒ HTTP 409 `version_conflict`.
* **Approvals bind to content.** `approvals.payload_hash = SHA-256(canonical JSON of the exact proposal)`. Changing the content after approval makes `assert_approved` fail (`approval_stale`). Four-eyes kinds forbid self-approval.
* **Money.** `Decimal` / `NUMERIC(14,2)` everywhere, half-up rounding, explicit currency. Office and client funds live in separate ledgers; a trigger refuses to post unbalanced journals or journals mixing ledgers; posted journals/lines are immutable; reversal creates a new journal.
* **Documents.** Originals are write-once in object storage; `document_versions` rows are immutable (trigger) apart from worker-owned scan/OCR/index status. Text is extracted into page/paragraph chunks for full-text search and for AI citations (document + version + page + paragraph).
* **Untrusted content.** Uploads are type-restricted (extension + magic bytes), size-limited and scanned; previews are extracted-text only; downloads are `attachment` with `nosniff` and a sandbox CSP; email bodies are plain text.
* **Jobs.** A PostgreSQL queue (`SELECT … FOR UPDATE SKIP LOCKED`), retry with backoff, idempotency keys, ids-only payloads. The worker binds the tenant for each job.
* **Integrations.** Each external dependency is an interface registered in `integrations/base.py` with a `mode` (`mock | live | unavailable`) and a plain-language statement of what data would leave the app. Mocks are labelled and produce clearly SIMULATED results.

## AI workspace

```
request ─▶ policy (agent allowlist, prohibited tools, budgets, permissions of requesting user)
        ─▶ retrieval tools (matter_clause + ai_retrieval_allowed + knowledge approved only)  ──▶ evidence blocks (DATA, delimited)
        ─▶ LLMProvider (mock | anthropic)  ─▶ structured output {facts, inferences, recommendations, missing, contradictions}
        ─▶ verifier (every citation exists in retrieved set; quotes are verbatim substrings)
        ─▶ proposed actions (hash-bound)  ─▶ human review ─▶ re-check permissions + hash ─▶ idempotent execution
```
Agents are read-only by default and can only *propose*. Prohibited tools (send email, share documents, post journals, transfer or release funds, change bank details, issue invoices, confirm deadlines, clear conflicts, delete) are denied and audited. Run events store retrieval ids/counts, tool calls, denials, injection flags and human decisions — never model reasoning or document text.

## Scaling notes
Stateless API containers; the worker scales horizontally via `SKIP LOCKED`; full-text search is PostgreSQL-native (swap in a search service behind `GET /search` if volumes require); object storage is external. Domain modules can be extracted later along the `services/` boundaries.
