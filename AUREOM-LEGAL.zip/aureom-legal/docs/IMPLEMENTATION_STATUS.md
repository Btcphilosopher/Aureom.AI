# Implementation status

Legend: ✅ implemented and exercised by tests · 🧪 implemented, but a **simulation/mock** (clearly labelled in the UI and API) · 🔌 needs an **external service** to be real · ⚠️ implemented but **not run/tested here**.

## 1. Implemented (real logic, tested)

| Area | What exists |
|---|---|
| Platform | ✅ Server-side sessions, CSRF header, lockout, role + matter-level authorisation, tenant isolation (app filters **and** PostgreSQL row-level security with a non-superuser role), hash-chained append-only audit log with verification endpoint, generic hash-bound approvals with four-eyes, PostgreSQL job queue + worker, optimistic concurrency, pagination, notifications, global search, administration (users, roles with audited permission changes, offices/teams, settings, retention policies, audit viewer/CSV, system info) |
| Parties | ✅ Individuals/organisations, addresses, relationships, aliases, roles per matter, duplicate detection, **reviewed merge** (references repointed, history preserved), conflict search (exact/alias/fuzzy/relationship) with masked restricted-matter evidence, human review history, never auto-cleared, onboarding workflow with configurable check types |
| Matters | ✅ Templates (stages, checklists, required fields, default tasks), explicit state machine with approvals and blockers (checklists, legal hold, WIP, client balance, retention), restricted matters, ethical-wall deny entries, exports/AI-retrieval switches, chronology, activity feed |
| Documents | ✅ Upload with type allow-list + magic-byte sniffing + size limit, write-once object storage, immutable version rows (DB trigger), hashes, folders/tags/metadata, text extraction (txt/md/csv/pdf/docx/eml), page/paragraph chunks, PostgreSQL full-text search, safe text-only preview, attachment-only downloads with `nosniff`/CSP, version comparison, review → approve → signature states, templates with previewed substitution, approval-gated time-limited exports, legal hold/retention fields |
| Correspondence | ✅ Inbox, filing to matters (attachments filed as documents), plain-text rendering, internal notes kept separate, drafts, approval bound to content hash, send blocked after edits, duplicate-send prevention, client-visible view |
| Tasks & diary | ✅ Tasks with dependencies (cycle rejection), recurrence, reminders, escalation, diary events, business calendars with administrator-supplied holidays, deadline rules (illustrative), calculated suggestions with source/jurisdiction/assumptions/timezone/steps, human confirmation required (API + DB CHECK), ICS export |
| Finance | ✅ Time entries, timers, expenses, rate cards, budgets, draft/approved/issued invoices with VAT, credit notes, **balanced double-entry journals** (service + DB trigger), separate office/client ledgers, posted-journal immutability, receipts, payment allocation (row-locked, no over-/duplicate allocation), client→office transfers (four-eyes, never overdrawn), explicit revenue-recognition step, reconciliation with sign-off, reports stating period/filters/basis, audited CSV export |
| AI workspace | ✅ Seven agents (briefing, document review, chronology, drafting, knowledge, intake, billing assistant) behind a policy layer: read-only default, per-agent tool allow-lists, prohibited tools denied and audited, permissions re-checked at execution, citation verifier (quotes must be verbatim), facts/inferences/recommendations separation, injection detector, run state machine with timeouts/retries/cancel/idempotency/budgets, per-action hash-bound approvals with human-correction history, run events without model reasoning, provider-independent adapter |
| Client portal | ✅ Own matters only; client-visible, scanned-clean documents; client-visible correspondence; issued invoices |
| Frontend | ✅ Every sidebar section, home dashboard, matter workspace, AI review UI, guided demonstration; loading / empty / error / permission-denied / integration-unavailable states |
| Ops | ✅ Alembic migrations (initial schema + SQL safeguards; `alembic check` clean), seed data, local setup script |

## 2. Simulated (mock implementations, labelled)

| Integration | Mock behaviour |
|---|---|
| Identity checks | 🧪 `SimulatedIdentityProvider`: deterministic; results are `passed_simulated` / `needs_review` / `failed` and always labelled simulated — never "verified" |
| Email | 🧪 `MockEmailProvider`: deterministic demo mailbox (including a hostile message); "send" records an integration event and marks the message sent (SIMULATED) |
| Calendar | 🧪 Mock sync; **ICS export is real** |
| E-signature | 🧪 Mock provider; "simulate signer completes" stores a plain-text signed artefact labelled SIMULATED |
| Bank feed | 🧪 Deterministic **synthetic** statement lines; read-only interface (no payment initiation exists) |
| Malware scanning | 🧪 Mock scanner (flags the EICAR test string); scan gate fails closed when the scanner is unavailable |
| OCR | 🧪 Mock engine: output flagged simulated (`is_ocr`); PDFs with a text layer are extracted for real |
| AI model | 🧪 Local deterministic mock provider (heuristic extraction, not a language model); nothing leaves the application |
| Companies House / legal research / SSO | 🧪 Adapters registered with mode **unavailable**: callers get HTTP 503 `integration_unavailable` with a setup hint |

## 3. Depends on external services / further work

* 🔌 Real identity-verification, sanctions/PEP, bank/open-banking, email (IMAP/Graph/Gmail), calendar, e-signature, antivirus (ClamAV or managed), OCR engine, SSO/OIDC (+MFA), legal-research source.
* 🔌 A real language model: `AnthropicProvider` is written (server-side key only; Messages API via httpx) but ⚠️ **was not exercised** — there is no key or network use in the tests. Its `data_leaves_application` statement is shown on Administration → AI provider.
* ⚠️ `S3Storage` (MinIO/S3) and the ClamAV adapter are implemented but were not exercised; tests use the local-filesystem storage.
* ⚠️ `docker compose up` and the Docker images were **not built or run** in the development environment (no Docker daemon). The same code path was run natively: `scripts/local_setup.sh`, migrations, seed, API, worker, frontend.
* Not implemented: automated retention destruction, break-glass access to restricted matters, MFA, rate limiting beyond account lockout, real e-signature document handling, DOCX generation of templates (templates generate text documents), document comparison for scanned/OCR text, production logging/monitoring/backup automation.
* Professional and regulatory review (client accounting, AML, deadlines, DPIA, AI governance, security assurance): see [`COMPLIANCE_REVIEW.md`](COMPLIANCE_REVIEW.md). Nothing here is certified.

## 4. Known simplifications
* Invoice issue uses the partner's hash-bound approval as the authorisation of the issue journal (finance must hold both `billing.issue` and `ledger.post`); other journals/allocations/transfers/revenue recognition each need a separate four-eyes approval.
* Expense recharges are booked to "fees billed – unrecognised" (documented simplification of a demonstration chart of accounts).
* Duplicate scanning is O(n²) and capped at 1,500 contacts; conflict fuzzy matching is deliberately over-inclusive (token containment) so that reviewers see borderline matches.
* The mock AI provider extracts dates, parties, obligations and clauses with heuristics (regular expressions); quality is illustrative.
* Correspondence approval is not four-eyes (a second reviewer is recommended in the UI); document-export four-eyes is enforced in the export service.

## 5. Checks actually run (development environment, PostgreSQL 16.15 on localhost, Python 3.13, Node 22)

| Check | Result |
|---|---|
| `pytest` — full backend suite (183 test functions, 205 collected cases) on a schema built from the models + `safeguards.sql` | **205 passed** (≈74 s) |
| Same full suite on a schema built by **Alembic migrations** (`TEST_USE_MIGRATIONS=1`) | **205 passed** |
| `alembic check` against a migrated database | “No new upgrade operations detected” |
| End-to-end demonstration (`tests/test_e2e_demo.py`, 12 tests, all 11 workflow steps through the HTTP API as the relevant personas) | passed |
| AI/agent security tests (70): retrieval permissions, restricted/ethical-wall/AI-blocked matters, other firms, fabricated-citation rejection, state machine, approval binding, duplicate-execution prevention, budgets, prompt-injection document, prohibited tool calls, permissions re-checked at execution | passed |
| Finance tests (35): decimal arithmetic, balanced journals (service + DB trigger), four-eyes, client-account overdraw, allocation limits/duplicates, receipt ≠ revenue, invoice hash binding, reconciliation | passed |
| Cross-firm / restricted-matter / search / portal / safeguard tests, conflict-review history, deadline confirmation (API + DB CHECK), document version immutability and references | passed |
| `npm run typecheck` and `npm run build` (frontend) | passed |
| Seed (`python -m app.seed.demo`) on a freshly migrated database; `scripts/local_setup.sh` from scratch | passed |
| Browser sweep (Playwright/Chromium, desktop 1440 px) of every sidebar section as solicitor, finance, administrator and client personas against the seeded API | no HTTP 5xx and no page errors; screenshots reviewed for the home, matter, billing, AI-run screens |

**Not run:** `docker compose up` / image builds (no Docker daemon available), S3/MinIO storage, the ClamAV adapter, the Anthropic provider, automated accessibility audits (keyboard navigation and focus styles were implemented and spot-checked in forks' browser runs, not audited with a tool), load/performance tests, tablet-width screenshots of every page.
