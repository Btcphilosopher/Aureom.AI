# Security model (summary)

| Concern | Implementation |
|---|---|
| Authentication | Server-side opaque sessions (SHA-256 of token stored), HttpOnly + SameSite=Lax cookie (`Secure` via `COOKIE_SECURE`), scrypt password hashes, lockout after 5 failures, session revocation on password reset/deactivation. SSO: `GET /auth/sso/start` is the OIDC adapter boundary (reports *integration unavailable* until configured). |
| CSRF | Double-submit style: every unsafe request must send `X-CSRF-Token` equal to the session's token (returned by login/`/auth/me`). |
| Authorisation | Role permissions (`permissions.py`, editable per firm with audited changes) **and** matter-level visibility (restricted matters, ethical walls). Enforced in services, again at AI tool execution, and for search/preview/export/AI retrieval. |
| Tenant isolation | `firm_id` on every row + PostgreSQL RLS keyed to a transaction-local GUC; non-superuser app role. Cross-firm ids return 404. |
| Audit | Append-only hash-chained log; triggers block mutation; verification endpoint; permission changes, approvals, exports, agent tool actions and denials are recorded. Confidential text is redacted from audit details. |
| Documents | Type allow-list + magic-byte sniff, size limits, malware-scan gate (mock + ClamAV adapter point), immutable originals, text-only previews, attachment-only downloads with `nosniff` and CSP sandbox, controlled approval-gated exports. |
| Secrets | Server-side only (env). The Anthropic key (if used) is never sent to the browser. No credentials in the repo. |
| AI safety | No training on matter content by default (cannot be enabled in the admin API); provider config page lists what would leave the application; retrieval scoped by firm+matter+user; injection-like text is flagged and treated as data; prohibited tools denied; human approval bound to exact content; budgets and timeouts. |
| Logging | Application logs contain ids and error classes, never document/email text. |
| Headers | `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`, `Cache-Control: no-store`, restrictive CSP on API responses. |

## Known limitations of this build
* `DEMO_MODE` exposes a persona picker that bypasses passwords — for demonstrations only.
* No MFA, no SSO callback implementation, no rate limiting beyond account lockout, no WAF.
* Malware scanning and OCR are mocks; identity checks are simulated; the bank feed is synthetic.
* Break-glass access to restricted matters is intentionally not implemented.
* Retention *expiry* is calculated and displayed; automated destruction is not implemented.
